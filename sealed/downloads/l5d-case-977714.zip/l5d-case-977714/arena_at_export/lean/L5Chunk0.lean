import L5Defs

namespace L5

set_option maxRecDepth 100000

theorem tabC0_ok : tabC0.all (ok tab) = true := by decide +kernel

end L5
