import L5Defs

namespace L5

set_option maxRecDepth 100000

theorem tabC4_ok : tabC4.all (ok tab) = true := by decide +kernel

end L5
