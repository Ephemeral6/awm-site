import L5Defs

namespace L5

set_option maxRecDepth 100000

theorem tabC14_ok : tabC14.all (ok tab) = true := by decide +kernel

end L5
