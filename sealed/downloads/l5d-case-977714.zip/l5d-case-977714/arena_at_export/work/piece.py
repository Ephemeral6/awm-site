import json,sys
L=[json.loads(l) for l in open('transitions.jsonl')]
H='0123456789abcdef'
for r in L[-int(sys.argv[1]):]:
    g=r['nxt']
    cells=[(y,x,g[y][x]) for y in range(15,45) for x in range(30,60) if g[y][x] in (9,10)]
    ys=[c[0] for c in cells]; xs=[c[1] for c in cells]
    print(r['action'], min(ys),max(ys),min(xs),max(xs))
    for y in range(min(ys),max(ys)+1): print('  ',''.join(H[g[y][x]] for x in range(min(xs),max(xs)+1)))
