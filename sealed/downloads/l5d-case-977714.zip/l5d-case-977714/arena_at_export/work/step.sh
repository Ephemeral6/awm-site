#!/bin/sh
# usage: step.sh "bet text" ACTION...
cd D:/arc-arena/l5d-case-977714
python play.py settle > work/last_settle.txt 2>&1; tail -3 work/last_settle.txt
python play.py bet "$1" >/dev/null; shift
python play.py act "$@" && python work/d.py $#; python work/piece.py $# 2>/dev/null
