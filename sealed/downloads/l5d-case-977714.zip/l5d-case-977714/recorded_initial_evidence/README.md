# L5 / Claude Opus 5.5 + AWM / 977714

- **实验类别**：主表：AWM原始实验
- **关卡/受试**：L5 / Claude Opus 5.5 + AWM
- **论文位置**：主表原始阶段
- **预算/轮次**：8次
- **结果**：impossible_in_model_proved；界：47
- **最终声明**：impossible_in_model_proved
- **注意**：射线参数10或11是模型前提；原始界47错误，随后进入repair。
- **初始数值计分**：未计为正确界

## 从哪里检查

1. [受试逐轮/汇总答复](interviews.md)。这是阅读入口。
2. [原始JSON / 会话提取](run.json)。摘录与索引有歧义时以原始记录为准。
3. [本阶段主证明](proof_sources/L5Model.lean)；主定理 `L5.l5_impossible`。
   Model parameter T=10 or11; incorrect model bound47, repaired later.
- [既有主定理/公理核查输出](proof_sources/_check.out)。
- [原始游戏服务记录](server)。
- [完整证明源码目录](proof_sources)。

## 同一case的其他阶段

- [外部反馈后：AWM修复](../../05_awm_repair/within_four_attempts_L5/README.md)

## 采集来源

`D:\THU\2026 Summer\ARC-AGI\ours\benchmarks\armkit-v2\l5\run_v2_l5d_l5d-case-977714.json`

这是采集时的来源路径；当前arena可能已经经过后续修复，不能代替本目录保存的阶段快照。

[返回本类实验](../README.md) · [返回实验总表](../../EXPERIMENTS.md)
