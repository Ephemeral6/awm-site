# L5 / Claude Opus 5.5 + AWM / 977714

- **实验类别**：外部反馈后：AWM修复
- **关卡/受试**：L5 / Claude Opus 5.5 + AWM
- **论文位置**：主表修复后阶段；与原始阶段分开
- **预算/轮次**：4次（服务日志计数；不是0次，也不是1个CLI回合）
- **结果**：47 → 37（含赢步）/36（不含）
- **最终声明**：impossible_in_model_proved
- **注意**：L4采用最新严格v7，L5采用较早v3；不是同一字节协议的独立重复。

## 从哪里检查

1. [受试逐轮/汇总答复](answers.md)。这是阅读入口。
2. [原始JSON / 会话提取](run.json)。摘录与索引有歧义时以原始记录为准。
3. [既有独立重编报告](rebuild/rebuild.json)。

## 同一case的其他阶段

- [主表：AWM原始实验](../../02_awm_main/l5d-case-977714/README.md)

## 采集来源

`D:\THU\2026 Summer\ARC-AGI\ours\benchmarks\armkit-v2\selfaudit\runs\l5d-case-977714.json`

这是采集时的来源路径；当前arena可能已经经过后续修复，不能代替本目录保存的阶段快照。

[返回本类实验](../README.md) · [返回实验总表](../../EXPERIMENTS.md)
