"""Create a fresh local six-run plan. Local setup only; no subject calls."""
from pathlib import Path
import argparse,json,platform,sys,datetime
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import protocol as P

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--arena-root',required=True);a.add_argument('--base-port',type=int,default=9631);args=a.parse_args()
    root=Path(args.arena_root).resolve();package=R.parent.resolve()
    if root.is_relative_to(package) or package.is_relative_to(root):raise SystemExit('Use a separate short arena directory outside this delivery package')
    if not 1024<=args.base_port<=65530:raise SystemExit('Choose six consecutive nonprivileged ports')
    path=R/'operator_only/batch-plan.json'
    if path.exists():raise SystemExit('Plan exists. Do not regenerate cases; inspect it or create a new versioned package/batch')
    if any((R/x).exists() and any((R/x).iterdir()) for x in ('results','checkpoints')):raise SystemExit('Existing run data: refusing a new plan in place')
    plan=P.create_plan(path,str(root),args.base_port)
    plan['device']=dict(host=platform.node(),platform=platform.platform(),python=sys.version,python_executable=sys.executable,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    (R/'adjudications').mkdir(exist_ok=True)
    print(json.dumps({'models_called':False,'servers_started':False,'plan':str(path),'stage':str(root),'cases':[(x['case'],x['win_level'],x['port']) for x in plan['arms']]},ensure_ascii=False,indent=2))
