"""Apply the remaining isolated edits once. Does not launch any experiment."""
from pathlib import Path
import json,shutil,difflib,hashlib
R=Path(__file__).resolve().parent;V2=R/'harness/ARC-AGI/ours/benchmarks/armkit-v2'
def once(s,a,b):
    assert s.count(a)==1,(a[:90],s.count(a));return s.replace(a,b,1)
def save(p,before,after):
    p.write_text(after,encoding='utf-8')
    q=R/'diffs'/(p.name+'.diff');orig=R/'before_patch'/p.relative_to(R)
    if not orig.exists():orig.parent.mkdir(parents=True,exist_ok=True);orig.write_text(before,encoding='utf-8')
    q.write_text(''.join(difflib.unified_diff(orig.read_text(encoding='utf-8').splitlines(True),after.splitlines(True),fromfile='v7h/'+p.name,tofile='4t8plus4/'+p.name)),encoding='utf-8')

shutil.copy2(R/'four_transforms_gate.py',V2/'four_transforms_gate.py')
p=V2/'run_v2.py';s=p.read_text(encoding='utf-8');before=s
assert 'strict_protocol = ' not in s,'Already finalized'
s=once(s,'    PROOF[0] = a.proof_gate','''    PROOF[0] = a.proof_gate
    strict_protocol = bool(getattr(CG, '_strict_enabled', False))
    if strict_protocol:
        if a.selfaudit_gate or a.skeptic_gate:
            ap.error('four-transform 8+4 keeps built-in audit/skeptic gates OFF; feedback is only after a locked initial checkpoint')
        if not a.proof_gate or a.rounds != (4 if a.resume_session else 8):
            ap.error('strict protocol requires --proof-gate and exactly 8 initial / 4 continuation attempts')
''')
s=once(s,'                                 "retried": "retry_of" in out_}', '                                 "retried": "retry_of" in out_, "response_text": out_.get("text"), "resource_report": out_.get("resource_report")}')
s=once(s,'                    b0 = CG.snap(d)','''                    b0 = CG.snap(d)
                    file_only_actions = RM.srv_read(ARMKIT / 'srvlog' / case)['actions']''')
s=once(s,'                    chk.update({"tries": ctries,','''                    if strict_protocol:
                        file_only_delta = RM.srv_read(ARMKIT / 'srvlog' / case)['actions'] - file_only_actions
                        if file_only_delta or cr.get('returncode') != 0 or (ctries and cr2.get('returncode') != 0):
                            chk['why'].append('file-only stage performed game actions or a CLI call failed')
                            chk['ok'] = False
                        chk['file_only_action_delta'] = file_only_delta
                        chk['response_text'] = ctxt
                    chk.update({"tries": ctries,''')
s=once(s,'            prev_after = after','''            if strict_protocol:
                freshness = CG.FT.check_current(d)
                valid = gate.get('ok', False) and freshness['ok'] and (proof is None or proof.get('ok', False)) and acts_in_probe == 0
                if not valid:
                    rec['rounds'].append({'k': k, 'logical_attempt': k + a.attempt_offset,
                                          'protocol_valid': False, 'play': play, 'probe': probe,
                                          'gate': gate, 'cards_gate': cards_rec, 'proof_gate': proof,
                                          'four_transformations': freshness, 'acts_in_probe': acts_in_probe})
                    rec['stop'] = 'protocol_blocked_end_of_attempt'
                    break
            prev_after = after''')
s=once(s,'                "k": k, "closed_by_reset": rs,','                "k": k, "logical_attempt": k + a.attempt_offset, "protocol_valid": True if strict_protocol else None, "closed_by_reset": rs,')
s=once(s,'            rec["final"] = fin','''            rec["final"] = fin
            if strict_protocol:
                rec['final_four_transformations'] = CG.FT.check_current(d)
                if fin.get('returncode') != 0 or not rec['final_four_transformations']['ok']:
                    rec['stop'] = 'protocol_blocked_final'
''')
s=once(s,'            print("  \u6536\u5de5 \u2192 %s / %s"','''            if strict_protocol and rec.get('final_proof_gate') and not rec['final_proof_gate']['ok']:
                rec['stop'] = 'protocol_blocked_final_proof'
            print("  \u6536\u5de5 \u2192 %s / %s"''')
s=once(s,'        results.append(rec)','''        if strict_protocol:
            rec['protocol'] += '+four-transforms'
            rec['protocol_valid'] = rec['stop'] in ('win', 'exhausted') and all(q.get('protocol_valid') for q in rec['rounds'])
        results.append(rec)''')
save(p,before,s)
p=V2/'proof_gate.py';s=p.read_text(encoding='utf-8');before=s
s=s.replace('impossible_in_model, and closing the proof is the first thing to do after the next attempt.','undecided until a closed proof is available. A failed proof gate is a protocol blockage, not an accepted impossibility certificate.')
save(p,before,s)
(R/'finish-status.json').write_text(json.dumps({'status':'offline implementation; tests pending','models_called':False,'modified':['run_v2.py','cards_gate.py','proof_gate.py','four_transforms_gate.py']},indent=2),encoding='utf-8')
print('Isolated native driver finalized; no services or model calls.')
