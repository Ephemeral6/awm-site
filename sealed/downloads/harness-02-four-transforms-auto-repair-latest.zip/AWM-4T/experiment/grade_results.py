"""Read saved results; optional independent Lean rebuild. Never calls a subject model."""
from pathlib import Path
import sys,argparse,json,hashlib,shutil,tempfile,os
sys.path.insert(0,str(Path(__file__).resolve().parent))
import protocol as P

def metrics(record):
    first_claim=None;first_proof=None
    for q in record.get('rounds',[]):
        k=q.get('logical_attempt',q.get('k'));verdict=(q.get('verdict') or {}).get('verdict')
        if verdict and verdict.startswith('impossible') and first_claim is None:first_claim=k
        proof=q.get('proof_gate') or {}
        if q.get('protocol_valid') and proof.get('ok') and proof.get('theorem') and not proof.get('withdrawn') and first_proof is None:first_proof=k
    return dict(case=record.get('case'),protocol_valid=record.get('protocol_valid'),stop=record.get('stop'),attempts=len(record.get('rounds',[])),first_impossibility_claim=first_claim,first_sealed_certificate_attempt=next((z.get('logical_attempt',z.get('k')) for z in record.get('rounds',[]) if (z.get('proof_first_audit') or {}).get('certificate')),None),first_proof_gate_pass=first_proof,final_proof_gate_pass=(record.get('final_proof_gate') or {}).get('ok'),semantic_theorem_review='pending manual review of statement, non-vacuity, costs, initial states and correspondence',numerical_accuracy='operator adjudication under declared cost convention, never inferred from compilation')

def rebuild(arena,rel,name,out):
    arena=Path(arena).resolve();out=Path(out).resolve()
    target=(arena/rel).resolve();assert target.is_relative_to(arena/'lean') and target.exists()
    work=P.R/'offline_out/proof_rebuild';work.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='fresh-',dir=work) as temp:
        d=Path(temp);assert d.resolve().is_relative_to(work.resolve())
        sys.path.insert(0,str(P.AK));import safe_lean_cache as SC
        SC.copy_inputs(arena,d,SC.inputs(arena))
        hashes={p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/'lean').rglob('*.lean')}
        for p in (P.AK,P.V2):sys.path.insert(0,str(p))
        os.environ['AWM_ARCHIVE']=str(P.R/'runtime_archive');os.environ['AWM_RUNTIME']=str(P.R/'runtime_tmp')
        import proof_gate as PG
        result=PG.check(d,f'MAIN-THEOREM: {rel} : {name}',timeout=1200,built={},require_scope=False,force_cold=True)
        result['source_sha256']=hashes;result['fresh_sources_only']=True
        result['scope']='Independent compilation/axiom check of selected theorem, not automatic semantic or environment-coverage validation.'
        out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--record');p.add_argument('--rebuild-arena');p.add_argument('--file');p.add_argument('--theorem');p.add_argument('--out',default=str(P.R/'independent_rebuild.json'));a=p.parse_args()
    if a.record:
        x=json.loads(Path(a.record).read_text(encoding='utf-8'));print(json.dumps(metrics(x[0] if isinstance(x,list) else x),ensure_ascii=False,indent=2))
    if a.rebuild_arena:
        assert a.file and a.theorem
        print(json.dumps(rebuild(a.rebuild_arena,a.file,a.theorem,a.out),ensure_ascii=False,indent=2))
