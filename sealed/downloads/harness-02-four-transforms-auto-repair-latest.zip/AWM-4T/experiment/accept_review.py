"""Record the operator agent's substantive review, not user permission or a proof."""
from pathlib import Path
import argparse,sys,json,datetime
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from device_support import unwrap,sha,protocol_hashes

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--note',required=True);p.add_argument('--confirm-four-transforms',action='store_true');p.add_argument('--confirm-memory-guard',action='store_true');p.add_argument('--confirm-no-answer-leak',action='store_true');a=p.parse_args()
    check=unwrap(R/'receiver_validation/preflight.json')
    if not check.get('ok') or check.get('protocol_sha256')!=protocol_hashes(R):raise SystemExit('A current successful receiver preflight is required')
    if not all([a.confirm_four_transforms,a.confirm_memory_guard,a.confirm_no_answer_leak]) or len(a.note.strip())<30:raise SystemExit('Review all three areas and record a concrete substantive note, not a checkbox-only assertion')
    r=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),four_transforms_reviewed=True,memory_guard_reviewed=True,no_answer_leak_reviewed=True,note=a.note,protocol_sha256=protocol_hashes(R),plan_sha256=sha(R/'operator_only/batch-plan.json'),prompt_manifest_sha256=sha(R/'prompts/manifest.json'),scope='Operator review receipt, not formal verification of transformation semantics.')
    (R/'receiver_validation/review_acceptance.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print('Receiver protocol review recorded. No model call made.')
