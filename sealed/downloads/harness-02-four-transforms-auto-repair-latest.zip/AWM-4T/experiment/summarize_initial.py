from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from device_support import summarize_initial
if __name__=='__main__':
    out=summarize_initial(R);print(json.dumps({'phase':out['phase'],'correct_bounds':out['correct_bounds'],'denominator':6,'proof_gate_passes':out['proof_gate_passes'],'summary':str(R/'results/initial_summary.json')},indent=2))
