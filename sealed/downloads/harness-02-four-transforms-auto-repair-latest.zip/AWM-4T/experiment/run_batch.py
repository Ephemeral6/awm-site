"""Serial operator queue. Default prints commands; never guesses a reported bound."""
from pathlib import Path
import argparse,sys,subprocess,json
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import protocol as P
from device_support import require_initial_batch_summary,require_receiver_review

if __name__=='__main__':
    ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group();g.add_argument('--execute-initials',action='store_true');g.add_argument('--execute-repairs',action='store_true');a=ap.parse_args()
    plan=json.loads((R/'operator_only/batch-plan.json').read_text(encoding='utf-8'))
    P.require_awm_plan(plan)
    if a.execute_initials or a.execute_repairs:require_receiver_review(R)
    summary=require_initial_batch_summary(R) if a.execute_repairs else None
    for row in plan['arms']:
        case=row['case'];initial=R/'results'/(case+'-initial8.json');repair=R/'results'/(case+'-feedback4.json')
        if a.execute_repairs:
            score=next(x for x in summary['rows'] if x['case']==case)
            if score['status'] not in ('wrong_high_bound','wrong_low_bound') or not score['protocol_valid']:continue
            if repair.exists():print('Preserving existing repair: '+case);continue
            cmd=[sys.executable,str(R/'run_experiment.py'),'--execute-feedback','--case',case,'--adjudication',str(R/score['adjudication'])]
        else:
            cmd=[sys.executable,str(R/'run_experiment.py'),'--execute-initial','--case',case]
            if a.execute_initials and initial.exists():print('Preserving initial record: '+case);continue
        print(subprocess.list2cmdline(cmd),flush=True)
        if a.execute_initials or a.execute_repairs:
            x=subprocess.run(cmd,cwd=R)
            if x.returncode:raise SystemExit('Run stopped with code '+str(x.returncode)+'; inspect and preserve failure before continuing')
    if a.execute_initials:print('All initial records are preserved. Adjudicate all six and run summarize_initial.py before any feedback.')
