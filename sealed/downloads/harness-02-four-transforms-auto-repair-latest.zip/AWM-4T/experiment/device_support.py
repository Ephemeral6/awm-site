"""Portable operator-only phase separation. No model or game-service calls."""
from pathlib import Path
import json,hashlib,datetime

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def unwrap(path):
    x=json.loads(Path(path).read_text(encoding='utf-8'))
    if isinstance(x,list):
        if len(x)!=1:raise ValueError('One case per result file required')
        x=x[0]
    return x

def canonical_record_sha(record):return hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()

def protocol_hashes(root):
    root=Path(root);out={}
    skip={'offline_out','receiver_validation','runtime_archive','runtime_tmp','results','checkpoints','adjudications','prompts','audit','prompts_old','__pycache__','before_patch','diffs','reference_validation'}
    generated={'baseline','srvlog','srvout','selftest_out','prompts_log','generated_methods','runs','changes_v7h','old'}
    for p in root.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if rel.parts[0] in skip or any(x in generated or x=='__pycache__' for x in rel.parts):continue
        if len(rel.parts)==1 and p.name in {'PROMPTS-ALL.md','PROMPT-DELTA.md','REPORT-审计与重跑方案.md'}:continue
        if p.suffix in ('.py','.md','.txt') or ('cards_fourtransforms' in rel.parts and p.suffix=='.json'):
            out[rel.as_posix()]=sha(p)
    return out

def require_receiver_review(root):
    root=Path(root);p=root/'receiver_validation/review_acceptance.json'
    if not p.exists():raise ValueError('Run preflight_device.py and record the four-transform review with accept_review.py before model execution')
    r=unwrap(p)
    if not all(r.get(x) for x in ('four_transforms_reviewed','memory_guard_reviewed','no_answer_leak_reviewed')):raise ValueError('Receiver protocol review is incomplete')
    if r.get('protocol_sha256')!=protocol_hashes(root) or r.get('plan_sha256')!=sha(root/'operator_only/batch-plan.json') or r.get('prompt_manifest_sha256')!=sha(root/'prompts/manifest.json'):raise ValueError('Code, plan or prompts changed after receiver review; repeat preflight and freeze the new version')
    return r

def summarize_initial(root):
    root=Path(root);planpath=root/'operator_only/batch-plan.json';plan=unwrap(planpath)
    arms=plan['arms']
    if len(arms)!=6 or [sum(a['win_level']==k for a in arms) for k in (4,5)]!=[3,3]:raise ValueError('Exactly three L4 and three L5 initial runs required')
    rows=[]
    allowed={'correct','wrong_high_bound','wrong_low_bound','undecided','unscorable','protocol_failure','infrastructure_failure'}
    for arm in arms:
        case=arm['case'];record_path=root/'results'/(case+'-initial8.json');score_path=root/'adjudications'/(case+'.json')
        if not record_path.exists() or not score_path.exists():raise ValueError('Initial result/adjudication missing: '+case)
        r=unwrap(record_path);s=unwrap(score_path)
        if s.get('initial_record_sha256')!=canonical_record_sha(r):raise ValueError('Adjudication does not match locked initial result: '+case)
        if s.get('status') not in allowed or not s.get('evidence'):raise ValueError('Explicit adjudication and source evidence required: '+case)
        valid=bool(r.get('protocol_valid') and r.get('stop')=='exhausted' and len(r.get('rounds',[]))==8)
        truth={4:19,5:36}[arm['win_level']];n=s.get('normalized_engine_bound')
        if s['status']=='correct' and (not valid or type(n) is not int or n!=truth):raise ValueError('Correct classification conflicts with record/accounting: '+case)
        if s['status']=='wrong_high_bound' and (not valid or type(n) is not int or n<=truth):raise ValueError('Wrong-bound classification would not be justified: '+case)
        if s['status']=='wrong_low_bound' and (not valid or type(n) is not int or n>=truth):raise ValueError('Wrong-low classification conflicts with cost convention: '+case)
        q=r.get('final_proof_gate') or {}
        rows.append(dict(case=case,level=arm['win_level'],replicate=arm['replicate'],attempts=len(r.get('rounds',[])),protocol_valid=valid,status=s['status'],reported_bound=s.get('reported_bound'),normalized_engine_bound=n,cost_convention=s.get('cost_convention'),evidence=s['evidence'],proof_gate_pass=bool(valid and q.get('ok') and q.get('theorem')),final_impossible=bool(valid and ((r.get('final_verdict') or {}).get('verdict') or '').startswith('impossible')),ever_certified_impossible=any((z.get('proof_first_audit') or {}).get('certificate') for z in r.get('rounds',[])),semantic_proof_review=s.get('semantic_proof_review','pending'),record=record_path.relative_to(root).as_posix(),record_sha256=sha(record_path),adjudication=score_path.relative_to(root).as_posix(),adjudication_sha256=sha(score_path)))
    out=dict(cost_convention_id=plan.get('cost_convention_id'),phase='initial8_only',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),plan_sha256=sha(planpath),denominator=6,correct_bounds=sum(x['status']=='correct' for x in rows),proof_gate_passes=sum(x['proof_gate_pass'] for x in rows),impossible_verdicts=sum(x['final_impossible'] for x in rows),ever_certified_impossibilities=sum(x['ever_certified_impossible'] for x in rows),rows=rows,scope='Initial subject reports only. Operator local searches are not substituted; semantic proof and environment coverage require separate review.')
    dst=root/'results/initial_summary.json';dst.parent.mkdir(exist_ok=True)
    if dst.exists() and unwrap(dst).get('rows')!=rows:raise ValueError('Initial summary already frozen with different data; preserve it and version the change')
    if not dst.exists():dst.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# Initial 8-attempt results, before any repair\n\n',f"Correct bounds: {out['correct_bounds']}/6. Final impossible verdicts: {out['impossible_verdicts']}/6. Ever certified model-impossibilities: {out['ever_certified_impossibilities']}/6. Final proof-gate passes: {out['proof_gate_passes']}/6; semantic theorem review is separate.\n\n",'| Case | Level | Attempts | Protocol valid | Status | Reported | Normalized | Proof gate |\n|---|---:|---:|---|---|---|---|---|\n']
    for x in rows:md.append(f"| {x['case']} | {x['level']} | {x['attempts']} | {x['protocol_valid']} | {x['status']} | {x['reported_bound']} | {x['normalized_engine_bound']} | {x['proof_gate_pass']} |\n")
    (root/'results/INITIAL-RESULTS.md').write_text(''.join(md),encoding='utf-8');return out

def require_initial_batch_summary(root):
    root=Path(root);p=root/'results/initial_summary.json'
    if not p.exists():raise ValueError('Repair locked: complete and adjudicate all six initial runs, then run summarize_initial.py')
    x=unwrap(p);plan=unwrap(root/'operator_only/batch-plan.json')
    cases={a['case'] for a in plan['arms']}
    if x.get('phase')!='initial8_only' or x.get('denominator')!=6 or len(x.get('rows',[]))!=6 or {r['case'] for r in x['rows']}!=cases:raise ValueError('Initial summary does not cover the six planned runs')
    if x['plan_sha256']!=sha(root/'operator_only/batch-plan.json'):raise ValueError('Plan changed after initial summary')
    for row in x['rows']:
        if sha(root/row['record'])!=row['record_sha256'] or sha(root/row['adjudication'])!=row['adjudication_sha256']:raise ValueError('Initial data/adjudication changed after summary: '+row['case'])
    return x
