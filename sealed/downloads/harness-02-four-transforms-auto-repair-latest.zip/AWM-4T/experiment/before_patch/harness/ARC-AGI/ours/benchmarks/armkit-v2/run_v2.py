# -*- coding: utf-8 -*-
"""armkit-v2 的跑臂驱动：把那四条真正接进每一轮。

    python run_v2.py --arms arms_plan_sc25v2.json --rounds 8
    python run_v2.py --arms arms_plan_sc25v2.json --rounds 1 --smoke   # 冒烟，几块钱

和 `armkit/run_multi.py` 的差别**只在追问那一段**。游玩、服务读数、记忆清理、
Lean 编译全部**复用 armkit 的那几个件**（只 import，不改）—— 那一侧已经跑过十六条臂。

## 一轮长什么样

```
1. 游玩                drive(受试, 跑场, 题面)
2. 服务侧读数          srv_read
3. snap_before         这一轮形式化系统在**追问之前**的样子
4. 追问                ASK_round.txt(1-3) + armkit-v2/ASK_round_lean.txt(4-6)
                       —— 第 4 问要求先把第二步走完，第 5 问要求**在它之上**证
5. snap_after          追问之后的样子
6. 台架自己编新写/改过的 .lean
7. 闸 gate_round        动过（且编得过、公理干净）或 明说没动并给理由
   没过就补问一次（--gate-retry），再判一次
8. correspond          Lean 定义 ↔ 规则层，**只报不拦**
9. 落盘                diff 正文 + 闸的路线与结论 + 对应表三个数，全进这一轮读数
```

第 3/5/9 步是新的。不记逐轮 diff 的话，「在上一轮的形式化上改」就没有凭据 ——
上一批里这件事只剩一个计数。

## 停止条件

和上一批**一样**，不改：A 打过了这一关 · D 次数用尽。
闸没过**不是**停止条件 —— 它只影响这一轮算不算完成，以及要不要补问一次。
（设成停止条件就又是一道可能不可满足的闸，我们栽过。）
"""
from __future__ import annotations

import argparse
import io
import hashlib
import re
import json
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARMKIT = HERE.parent / "armkit"
sys.path.insert(0, str(ARMKIT))
sys.path.insert(0, str(HERE))

import leancheck as LC                                          # noqa: E402
import memclean as MC                                           # noqa: E402
import run_multi as RM                                          # noqa: E402

import correspond as CO                                         # noqa: E402
import formal_state as FS                                       # noqa: E402
import gate_round as GR                                         # noqa: E402
import replay_gate as RG                                        # noqa: E402
import cards_gate as CG                                         # noqa: E402
import proof_gate as PG                                         # noqa: E402

ASK_123 = ARMKIT / "ASK_round.txt"            # 1-3 问：原样复用
ASK_456 = HERE / "ASK_round_lean.txt"         # 4-6 问：v2 改写的那一份
ASK_TAIL = ARMKIT / "ASK_round_tail.txt"
# **第 7 问（2026-10-14 加，默认关，`--rigor` 才发）**：三条自审 ——
#   a 代价参数要拟合并报解集大小   b 承重规则要点名判决性实验
#   c 自己扫预算常量、报自己那条定理成立的区间
# 三条都只问**它自己的件**，不向它透露本局任何信息 ⇒ 不泄题。
# 加它的理由：框架臂第 4 次 attempt 把判定边界从 21 推到 26（加了一条测错的退费规则），
# 而「改不重写」的纪律把那条错误锁了四轮 —— 没有任何一道闸会在那一刻报警。
ASK_RIGOR = HERE / "ASK_round_rigor.txt"
FINAL_CORE = ARMKIT / "ASK_core.txt"
FINAL_LEAN = ARMKIT / "ASK_lean.txt"
FINAL_TAIL = ARMKIT / "ASK_tail.txt"

GATE_RETRY = """Your answer did not close out this attempt's formalization step.

%s

Fix just that, now. Either bring the formal system up to date (objects, rules, simplify,
Lean definitions - amending what you already have, not starting over), or state plainly
that this attempt changed nothing in it, on its own line in exactly this form:

    FORMAL-UNCHANGED: <why this attempt added nothing to the model>

Do not replay the game and do not restate your earlier answer. Just this."""


def force_reset(port: int, timeout: int = 60) -> dict:
    """**每一次 attempt 开跑前，驱动自己把关卡 reset 掉。**

    不这么做的话，一次 attempt 可能**开局就无事可做** —— 实测：框架臂第 3 轮接手时
    关 4 的 18 格预算只剩 1 格，它只发得出 1 个动作，而题面又明令它不许自己 `/reset`
    （`prompt_rounds.txt`：「Do not call /reset to start over on your own. Wait.」）。
    它在回话里写得很清楚：「The level was not reset for this attempt … I'm waiting for
    a fresh level 4.」于是那一轮在读数里和「它选择不再探索」长得一模一样。

    这是**旧驱动也有**的缺陷（`run_multi.py` 轮间同样不重置），所以上一批的读数
    也受影响 —— 模型臂那串 `57 5 2 0 0 25 26 2` 里的 0 和 2 多半就是死局轮。

    服务带 `--retries`（没有 `--one-life`），`/reset` 只重开**当前关**，关 1–3 的进度保留，
    所以第 2 轮起 reset 给到的就是一个满预算的关 4。
    首帧 md5 一并记下来：**轮与轮之间应当逐像素相同**，这是「每次都从同一个起点开打」的凭据。
    """
    req = urllib.request.Request("http://127.0.0.1:%d/reset" % port,
                                 data=b"{}", method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        out = json.loads(r.read().decode("utf-8"))
    frames = out.get("frames") or []
    head = hashlib.md5(json.dumps(frames[0] if frames else [],
                                  separators=(",", ":")).encode()).hexdigest()
    return {"level": out.get("level"), "state": out.get("state"),
            "levels_completed": out.get("levels_completed"),
            "frame_md5": head, "n_frames": len(frames)}


def srv_state(logdir: Path) -> dict:
    """服务日志最后一条的 state —— `srv_read` 不给这个字段。

    `--retries` 档下没有 `ep=end` 记录（那是 `--one-life` 才写的），
    所以「这一局完了没有」只能看最后一条 action 的 `state`。
    """
    last = {}
    if logdir.exists():
        for f in sorted(logdir.glob("*.jsonl")):
            for line in io.open(f, encoding="utf-8", errors="replace"):
                line = line.strip()
                if line:
                    try:
                        last = json.loads(line)
                    except Exception:
                        pass
    return {"state": last.get("state"), "level": last.get("level"),
            "levels_completed": last.get("levels_completed"), "ep": last.get("ep")}


KEEP_PLAYING = """Your attempt is not over: the game has not ended. The service still reports
`%s` on level %s.

Keep playing this attempt until the game ends on its own. Do not call /reset - the attempt is
closed for you once the game is over, and you will be given another one. Report again when the
game has ended."""


# `--rigor` 的开关。用一个单元素 list 而不是模块级 bool，是为了让 round_ask
# 不必改签名（它在两处被调用），同时仍然只有 main 能写它。
RIGOR = [False]
# **三层量表（2026-10-14 加，默认关，`--decide` 才用）**：把非裸臂的五档
# （多 impossible_in_model[_proved]）收回成裸臂那三档 winnable|impossible|undecided，
# 并把 `impossible` **operationally** 定义成「在我已建立的规则下无解」、前提要点名。
# 两个作用：① 拆掉「框架臂最常给的那个答案裸臂字面上说不出来」这个混淆；
# ② 让模型臂敢按自己的模型下结论 —— 严谨性由 Lean + 边界探针承担，不由那个词承担。
# **注意**：这一版**没有**写「游戏不隐藏影响通关的规则」。那句话对这台引擎是**假的**
# （退费的碰撞框在 :3137 不乘 scale、在 :2733 乘 —— 正好值那 3 个单位；获胜那一步还免费），
# 写进去等于教它一个假前提，然后它会自信地对 8 张可做盘喊 impossible。
# 换成的是**举证责任**那一版：没查过的细节本身不构成 undecided 的理由，
# 但要能**点名**具体机制与定向实验；泛泛的「可能还有我没找到的东西」不算理由。
DECIDE = [False]
# **闭合证明（2026-10-19 加，默认关，`--closed` 才用）**：第 5 问换成 ASK_q5_closed.txt，
# 判定词说明里 `_proved` 那一段换成 ASK_tail_closed_note.txt。起因：关 5 上 15 条 AWM 跑里
# 13 条的「不可做」承重一步是 Lean 外的 Python 搜索 / 手数，以**假设**进定理（原第 5 问
# 「If the proof needs a premise you did not establish, write it as an explicit hypothesis」
# 正好允许这么做），其中 7ab6c5 的假设在它自己的 Lean 模型里就是假的。新版要求：
# 主定理对模型的全部动作串成立；搜索结果不许当假设，要在 Lean 里用 decide 核表；
# 同一份文件里给非空洞性（放宽一个限制就能赢）；用 MAIN-THEOREM 行点名主定理。
# 只改非裸臂；第 4、6 问与第 1–3 问逐字不动；不含本局任何事实。
CLOSED = [False]
# **Lean 重放闸（2026-10-20 加，默认关，`--replay-gate` 才用）**：每轮核受试的 Lean 模型是否复现它在本关
# 记录过的每一条转移（受试维护 work/abstract.py 与 lean/ReplaySpec.lean；数据由台架生成）。
# 不过就补问（次数同 --gate-retry）。另把每轮的 lean/ concepts/ work/*.md 存档，中间各版事后可审。
# 受试要知道这道闸：建场时用 --method-addendum 带上 METHOD_addendum_replay.md。详见 replay_gate.py。
REPLAY = [False]
# **自审闸（2026-10-21 加，默认关，`--selfaudit-gate` 才用）**：METHOD 的自审节要求「第一次闭合主定理之后
# （最迟第 4 次 attempt）写 work/selfaudit/pass1.md，之后每次 attempt 做探测并记下来」。第二阶段 l4s 那条跑
# 闭合了两次都没写 —— 节里写了，台架不查，它就不做。这道闸只查**有没有做**（文件在不在、这一轮动没动），
# 不查内容、不点任何规则、不给任何本局信息；补问措辞写死在下面，METHOD 正文一个字不动。
SELFAUDIT = [False]
SA_DIR = "work/selfaudit"
SA_MISSING = """Your answer states that the level cannot be won (or this is attempt 4 or later), but the self-audit that
METHOD.md requires after a closed proof has not been written: `work/selfaudit/pass1.md` does not exist.

Write it now, as the section "自审" in METHOD.md describes: step (a) - every rule and its cases, the loosenings your
records allow, the least cost under each, the trigger grids with every cell marked covered / uncovered / unreachable
(unreachable only with a reachability search), the bite steps, the ranking and the experiment plan. The probes are
played in the next attempt. Do not send any game actions now, and do not restate your earlier answer."""
SA_STALE = """This attempt did not update your self-audit: nothing under `work/selfaudit/` changed. Record what this
attempt tested, as METHOD.md's section "自审" requires: the probes you played, what the game did, the outcome per rule
(CONFIRMED / REFUTED / UNTESTABLE), and, if a rule was refuted, the repair and the next pass.

If the audit is already complete as that section's (d) defines it, or this attempt could not probe anything, say so
instead, on its own line in exactly this form, and then give the reason:

    SELF-AUDIT-UNCHANGED: <why>

Do not send any game actions now."""


# **怀疑闸（2026-10-21 加，默认关，`--skeptic-gate` 才用）**：用户：「每次 attempt 完后如果 impossible，模型都假设
# 自己的证明不够严谨，带着这样的信号，尽可能不带其他先验地去重新检验所有的 rule」。无条件发（只看它自己的判定，
# 不看引擎），所以不含任何本局信息；最后一次 attempt 之后不发（没有下一次可以探测）。措辞经用户确认。
SKEPTIC = [False]
# **卡片闸（2026-10-22 加，默认关，`--cards-gate DIR` 才用）**：见 cards_gate.py。
CARDS: list = []
PROOF = [False]     # --proof-gate (2026-10-22 v7e)
SA_SKEPTIC = """Treat your impossibility proof as not yet tight. Assume that at least one rule of your model is stricter than
the game - it forbids a move the game allows, or charges more for one - so that your least cost is too high.
The proof cannot show you which; only the game can.

Re-check every rule of your model against the game. Start from the evidence behind each rule, not from your
model's view of which situations matter: a situation your model calls unreachable, unimportant or already
settled is exactly where a too-strict rule hides. For each rule, write down which situations your records
actually cover and which they do not, and plan experiments for the uncovered ones that could lower your least
cost. Write this as the next pass in work/selfaudit/ (as METHOD.md's section "自审" describes), and play the
experiments in the next attempt.

This message is sent after every attempt that ends with an impossibility verdict. It is not a statement about
this game."""


def sa_snapshot(d: Path) -> dict:
    """md5 of every file under work/selfaudit/ (empty dict if the folder is missing)."""
    p = d / SA_DIR
    if not p.exists():
        return {}
    return {str(f.relative_to(p)): hashlib.md5(f.read_bytes()).hexdigest()
            for f in sorted(p.rglob("*")) if f.is_file()}


def sa_check(d: Path, prev: dict, text: str, first: bool) -> dict:
    """ok iff pass1.md exists (non-empty) and, after the round that triggered the audit, the folder changed this
    round or the reply carries a SELF-AUDIT-UNCHANGED line."""
    snap = sa_snapshot(d)
    p1 = d / SA_DIR / "pass1.md"
    has_pass1 = p1.exists() and p1.stat().st_size > 0
    changed = snap != prev
    unchanged_stated = bool(re.search(r"^\s*SELF-AUDIT-UNCHANGED:", text or "", flags=re.M))
    if not has_pass1:
        why = "missing"
    elif not first and not changed and not unchanged_stated:
        why = "stale"
    else:
        why = None
    return {"ok": why is None, "why": why, "has_pass1": has_pass1, "changed": changed,
            "unchanged_stated": unchanged_stated, "files": sorted(snap)}
ASK_Q5_CLOSED = HERE / "ASK_q5_closed.txt"
ASK_TAIL_CLOSED = HERE / "ASK_tail_closed_note.txt"


def _closed_q5(t: str, final: bool) -> str:
    """把一段追问文本里的第 5 问整段换成闭合版。"""
    new = ASK_Q5_CLOSED.read_text(encoding="utf-8")
    if final:
        new = new.replace("5. Now prove your answer to question 2 **on that formal system**:",
                          "5. State your answer to question 2 again, this time as a Lean proof "
                          "**on your formal system**:", 1)
        a = t.index("5. State your answer to question 2 again")
        return t[:a] + new.rstrip("\n") + "\n"
    a = t.index("5. Now prove your answer to question 2")
    b = t.index("6. If this attempt taught you nothing")
    return t[:a] + new + t[b:]


def _closed_tail(t: str) -> str:
    a = t.index("Use `impossible_in_model_proved` only if")
    b = t.index("is worth more.", a) + len("is worth more.")
    return t[:a] + ASK_TAIL_CLOSED.read_text(encoding="utf-8").rstrip("\n") + t[b:]


def round_ask(arm: str) -> str:
    """**裸臂拿到的追问必须和 v1 逐字相同。**

    对裸臂来说 v1 → v2 的差别**只有 attempt 边界那一条**（打到 GAME_OVER 才算一次）。
    第 4–6 问（先做形式化、在其上证、改不重写）本来就只发给非裸臂 ——
    v1 的 `round_ask` 里是 `if arm != "bare"` 才拼 `ASK_round_lean.txt`。
    把形式化的要求发给一条没有形式化工具的臂，它就不再是对照组了。
    """
    t = ASK_123.read_text(encoding="utf-8")
    if arm != "bare":
        t += ASK_456.read_text(encoding="utf-8")
        if RIGOR[0]:
            t += ASK_RIGOR.read_text(encoding="utf-8")
    if arm == "bare":
        tail = ARMKIT / "ASK_round_tail_bare.txt"
    elif DECIDE[0]:
        tail = ARMKIT / "ASK_round_tail_decide.txt"
    else:
        tail = ARMKIT / "ASK_round_tail.txt"
    tt = tail.read_text(encoding="utf-8")
    if CLOSED[0] and arm != "bare":
        t, tt = _closed_q5(t, final=False), _closed_tail(tt)
    return t + tt


def final_ask(arm: str) -> str:
    t = FINAL_CORE.read_text(encoding="utf-8")
    if arm != "bare":
        t += FINAL_LEAN.read_text(encoding="utf-8")
    if arm == "bare":
        tail = ARMKIT / "ASK_tail_bare.txt"
    elif DECIDE[0]:
        tail = ARMKIT / "ASK_tail_decide.txt"
    else:
        tail = ARMKIT / "ASK_tail.txt"
    tt = tail.read_text(encoding="utf-8")
    if CLOSED[0] and arm != "bare":
        t, tt = _closed_q5(t, final=True), _closed_tail(tt)
    return t + tt


def lean_report(d: Path, snap_a: dict, snap_b: dict, built: dict, timeout: int):
    """把 formal_state 的 diff 翻成 leancheck 要的「改过的 .lean 清单」。"""
    changed = [p for p in FS.diff(snap_a, snap_b)["added"] + FS.diff(snap_a, snap_b)["changed"]
               if p.startswith("lean/") and p.endswith(".lean")]
    if not changed:
        return None, []
    return LC.check_files(d, sorted(changed), timeout=timeout, built=built), sorted(changed)


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", default="arms_plan_sc25v2.json")
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--rounds", type=int, default=8)
    ap.add_argument("--conf", type=int, default=90)
    ap.add_argument("--win-level", type=int, default=4)
    ap.add_argument("--lean-timeout", type=int, default=600)
    ap.add_argument("--max-push", type=int, default=3,
                    help="一次 attempt 还没到 GAME_OVER 时，最多催它接着打几次")
    ap.add_argument("--gate-retry", type=int, default=1,
                    help="闸没过时最多补问几次（0 = 只记不补）")
    ap.add_argument("--only", default="")
    ap.add_argument("--decide", action="store_true",
                    help="非裸臂也用三层量表 winnable|impossible|undecided，"
                         "并把 impossible 定义成「在已建立的规则下无解」。默认关 = 旧行为")
    ap.add_argument("--rigor", action="store_true",
                    help="非裸臂每轮多发第 7 问（三条自审：拟合解集 / 判决性实验 / 自报定理成立区间）。默认关 = 旧行为")
    ap.add_argument("--closed", action="store_true",
                    help="非裸臂的第 5 问与 _proved 说明换成闭合证明版（搜索结果不许当假设、"
                         "要在 Lean 里核；点名 MAIN-THEOREM）。默认关 = 旧行为")
    ap.add_argument("--replay-gate", action="store_true",
                    help="非裸臂每轮核 Lean 模型对本关全部记录转移（replay_gate.py），不过就补问；"
                         "并逐轮存档形式化文件。默认关 = 旧行为")
    ap.add_argument("--skeptic-gate", action="store_true",
                    help="(2026-10-21) 非裸臂：每次追问判「到不了」类结论后（最后一次除外），固定追加 SA_SKEPTIC，"
                         "要它假设证明不够紧、按证据逐条重查规则、写下一遍自审。默认关 = 旧行为")
    ap.add_argument("--selfaudit-gate", action="store_true",
                    help="(2026-10-21) 非裸臂：判「到不了」类结论后（最迟第 4 次 attempt）起，每轮查 work/selfaudit/ "
                         "是否写了、这一轮是否更新，不过就补问（措辞固定，不含本局信息）。默认关 = 旧行为")
    ap.add_argument("--cards-gate", default=None,
                    help="(2026-10-22) 非裸臂：每次 attempt 之后、追问之前，逐张发 DIR 下的凝炼与形式化卡（NN-*.md），"
                         "逐张查交付（cards_gate.py），不过就补问。默认关 = 旧行为")
    ap.add_argument("--proof-gate", action="store_true",
                    help="(2026-10-22) 非裸臂：追问判「不可能」类结论时，必须有 MAIN-THEOREM 指向一份台架重编得过、"
                         "公理干净的 Lean 定理（proof_gate.py），不过就补问（--proof-retry 次）。默认关 = 旧行为")
    ap.add_argument("--proof-retry", type=int, default=2)
    ap.add_argument("--smoke", action="store_true",
                    help="冒烟：只跑第 1 轮、不发收工追问，用来确认闸与 diff 真的落进读数")
    ap.add_argument("--out", default="run_v2.json")
    ap.add_argument("--mem-archive", default=(__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/v2-memory"))
    a = ap.parse_args(argv)
    RIGOR[0] = a.rigor
    DECIDE[0] = a.decide
    CLOSED[0] = a.closed
    REPLAY[0] = a.replay_gate
    SELFAUDIT[0] = a.selfaudit_gate
    SKEPTIC[0] = a.skeptic_gate
    CARDS[:] = CG.load(a.cards_gate) if a.cards_gate else []
    PROOF[0] = a.proof_gate
    rounds_dir = HERE / (Path(a.out).stem + "_rounds")
    # **消息日志（2026-10-22 加）**：发给受试的每一条消息原文、发送时间、属于哪一步，逐条落进
    # prompts_log/<out 名>.jsonl；回话只记长度、用时、返回码（全文在 run 读数里）。用户要逐步核对输入了什么。
    plog = HERE / "prompts_log" / (Path(a.out).stem + ".jsonl")
    plog.parent.mkdir(exist_ok=True)
    _orig_dr = RM.drive_retry

    def _logged_drive_retry(agent_, d_, text_, first=False, label="", pause=20):
        t_send = time.strftime("%Y-%m-%d %H:%M:%S")
        out_ = _orig_dr(agent_, d_, text_, first=first, label=label, pause=pause)
        with open(plog, "a", encoding="utf-8") as fo:
            fo.write(json.dumps({"sent": t_send, "case": Path(d_).name, "label": label, "new_session": bool(first),
                                 "text": text_, "reply_chars": len(out_.get("text") or ""),
                                 "wall_s": out_.get("wall_s"), "returncode": out_.get("returncode"),
                                 "retried": "retry_of" in out_}, ensure_ascii=False) + chr(10))
        return out_
    RM.drive_retry = _logged_drive_retry

    stage = Path(a.stage)
    plan = json.loads((HERE / a.arms).read_text(encoding="utf-8"))
    arms = plan["arms"]
    if a.only:
        arms = [r for r in arms if any(w in r["case"] for w in a.only.split(","))]

    print("协议 armkit-v2 —— 每轮：第二步走完 → 在它之上证 → 过闸 → 记 diff")
    print("停止条件和上一批一样：A 打过了这一关 · D 次数用尽（%d）" % a.rounds)
    print("闸没过**不停**，只补问 %d 次并记进读数" % a.gate_retry)
    print()

    results = []
    for r in arms:
        case, arm, agent, side = r["case"], r["arm"], r["agent"], r["side"]
        d = stage / case
        if not d.exists():
            print("跳过 %s：跑场不在（先用 armkit/build.py --arms 本表 --retries --serve 造）" % case)
            continue
        print("=" * 92)
        # 两分法（"派生" if side == "no" else "原"）踩过坑：2026-10-16 加的
        # side="nofix"（派生盘 + 引擎退费修正）掉进 else，日志把它写成「原 盘」。
        # 改成查表 + 兜底打原始 key —— 没映射上的档宁可难看，不许冒充别的档。
        SIDE_LABEL = {"ok": "原", "no": "派生", "nofix": "派生·修正"}
        print("%s  %s/%s  %s 盘  端口 %s"
              % (case, arm, agent, SIDE_LABEL.get(side, "side=%s" % side),
                 r["port"]))

        rec = {"case": case, "arm": arm, "agent": agent, "side": side,
               "port": r["port"], "protocol": "armkit-v2" + ("+closed" if CLOSED[0] else "") + ("+replay" if REPLAY[0] else "") + ("+selfaudit" if SELFAUDIT[0] else "") + ("+skeptic" if SKEPTIC[0] else "") + ("+cards" if CARDS else "") + ("+proof" if PROOF[0] else ""),
               "ask_md5": {"round": hashlib.md5(round_ask(arm).encode("utf-8")).hexdigest(),
                           "final": hashlib.md5(final_ask(arm).encode("utf-8")).hexdigest()},
               "rounds": [],
               "stop": None, "conf_threshold": a.conf,
               "milestones": {}, "first_reached": {}}
        rec["mem_on_entry"] = MC.clear(d, Path(a.mem_archive), tag="v2")
        if rec["mem_on_entry"]["n"]:
            print("  !! 进场有 %d 份跨轮记忆，已存走并清空" % rec["mem_on_entry"]["n"])

        built: dict = {}
        sa_state = {"triggered": False, "prev": {}}     # --selfaudit-gate
        prev_srv = {"actions": 0}
        # **开跑前先照一张。** 第一版把它设成 None、让第 1 轮退回只看追问窗口，
        # 于是第 1 轮的规则层工作全部漏掉 —— 冒烟实测：受试在**游玩阶段**写了
        # concepts/move_dir.py 与 panel_click.py（17:49/17:50），追问是 17:54 才发的，
        # 读数却报 rules_touched=0。一轮的形式化工作横跨游玩与追问两段，
        # 基准必须取在**这一轮开始之前**。
        prev_after: dict = FS.snap(d)
        text = (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8")
        first = True
        t0 = time.time()

        # **attempt 以 reset 划界。** 开臂先 reset 一次，这一下开启第 1 次 attempt。
        resets: list = [force_reset(r["port"])]
        print("  开臂 reset → 第 %s 关 · 首帧 %s"
              % (resets[0]["level"], resets[0]["frame_md5"][:12]))
        for k in range(1, a.rounds + 1):
            # **一次 attempt 到 GAME_OVER 才结束。**
            # 驱动不主动掐断：它自己打到游戏结束，之后才由驱动 reset 关掉这一次。
            # 它中途停下来（「我没路走了」）**不算**结束 —— 上一版就是把这种停当成了
            # 一次 attempt，于是读数里「开局没预算的死局轮」和「它选择不再探索」
            # 长得一模一样。
            play = RM.drive_retry(agent, d, text, first=first, label="第 %d 次的游玩" % k)
            play0 = play          # 这一轮第一次游玩（被催之后 play 会换成续打那一次）
            first = False
            pushes = []
            while len(pushes) < a.max_push:
                st = srv_state(ARMKIT / "srvlog" / case)
                if st["state"] in ("GAME_OVER", "WIN"):
                    break
                if play["returncode"] != 0 or not (play.get("text") or "").strip():
                    break                      # 它根本没回话，催也没用，交给下面的 dead 判
                print("    这一次还没结束（%s，第 %s 关）—— 催它接着打（第 %d 次）"
                      % (st["state"], st["level"], len(pushes) + 1))
                play = RM.drive_retry(agent, d, KEEP_PLAYING % (st["state"], st["level"]),
                                      first=False, label="第 %d 次的续打" % k)
                pushes.append({"wall_s": play.get("wall_s"),
                               "text": (play.get("text") or "").strip()})
            end_state = srv_state(ARMKIT / "srvlog" / case)
            if end_state["state"] not in ("GAME_OVER", "WIN"):
                print("    !! 催了 %d 次仍未结束（%s）—— 这一次标为**未闭合**"
                      % (len(pushes), end_state["state"]))
            txt = (play.get("text") or "").strip()
            # **按这一轮第一次游玩判**（2026-10-17 修）：原来用的是最后一次续打，
            # fx2a 上限 11，续打 3 步就 GAME_OVER、31 秒返回，被误判成「第 1 轮没跑起来」。
            txt0 = (play0.get("text") or "").strip()
            dead = (play0["returncode"] != 0 or not txt0
                    or (k == 1 and play0["wall_s"] < 60))
            if dead:
                print("!! 第 %d 轮没跑起来：rc=%s wall=%.0fs"
                      % (k, play["returncode"], play["wall_s"]))
                rec["rounds"].append({"k": k, "play": play, "play_first": play0, "dead": True})
                rec["stop"] = "died_at_round_%d" % k
                break

            srv = RM.srv_read(ARMKIT / "srvlog" / case)
            srv_round = {"actions": srv["actions"] - prev_srv["actions"],
                         "level": srv.get("level"),
                         "levels_completed": srv.get("levels_completed")}
            prev_srv["actions"] = srv["actions"]
            print("  第 %d 次 · %.0f 分钟 · 这一轮 %d 个动作 · 到第 %s 关"
                  % (k, play["wall_s"] / 60, srv_round["actions"], srv_round["level"]))

            # —— **用 reset 关掉这一次 attempt。** ——
            # 顺序是用户定的：attempt 按 reset 划界，**reset 之前不算结束、也不进
            # 形式化与追问环节**。原来把 reset 放在每轮开头，等于追问发生在
            # 「上一次还没关掉」的板子上 —— 实测框架臂第 3 轮接手时关 4 只剩 1 格预算，
            # 它只发得出 1 个动作，而那一轮在读数里和「它选择不再探索」长得一样。
            try:
                rs = force_reset(r["port"])
            except Exception as e:
                print("!! 第 %d 轮收尾 reset 失败：%s —— 这条臂停在这里" % (k, e))
                rec["stop"] = "reset_failed_at_round_%d" % k
                break
            # **和「这一关最常见的那个起点」比，不要和「所有早先的」比。**
            # 第一版写成「与所有同关起点都相同」，于是一旦出现过一次不同，
            # 后面每一次都报 False —— 实测第 3/4/5 次首帧明明一样却全被标成不同。
            same = [x["frame_md5"] for x in resets if x["level"] == rs["level"]]
            from collections import Counter
            common = Counter(same).most_common(1)[0][0] if same else None
            rs["same_start_as_earlier"] = (common is None or rs["frame_md5"] == common)
            rs["n_starts_seen"] = len(set(same + [rs["frame_md5"]]))
            resets.append(rs)
            print("    reset 关掉第 %d 次 → 第 %s 关 · 首帧 %s%s"
                  % (k, rs["level"], rs["frame_md5"][:12],
                     "" if not same else
                     ("（与前面同关的起点逐像素相同）" if rs["same_start_as_earlier"]
                      else " **与前面同关的起点不同**")))

            # —— 卡片闸（--cards-gate）：追问之前按阶段发凝炼与形式化卡（k=1 五条全文，k>1 两条增量），逐阶段查交付 ——
            cards_rec = None
            if CARDS and arm != "bare":
                cards_rec = []
                for stages, cmsg in CG.plan(CARDS, k):
                    tag = "+".join(stages)
                    b0 = CG.snap(d)
                    cr = RM.drive_retry(agent, d, cmsg, first=False, label="第 %d 次的卡 %s" % (k, tag))
                    ctxt = (cr.get("text") or "").strip()
                    chk = CG.check(d, stages, b0, CG.snap(d), ctxt, k)
                    ctries = 0
                    while not chk["ok"] and ctries < a.gate_retry:
                        ctries += 1
                        print("  卡 %s 没过：%s —— 补问第 %d 次" % (tag, chk["why"], ctries))
                        cr2 = RM.drive_retry(agent, d, CG.retry_text(stages, chk["why"], k), first=False,
                                             label="第 %d 次的卡 %s 补问" % (k, tag))
                        ctxt = ctxt + chr(10) + (cr2.get("text") or "").strip()
                        chk = CG.check(d, stages, b0, CG.snap(d), ctxt, k)
                    chk.update({"tries": ctries, "wall_s": cr.get("wall_s"), "returncode": cr.get("returncode")})
                    cards_rec.append(chk)
                    print("  卡 %s：%s（%s · 动了 %d 个文件 · 补问 %d 次）"
                          % (tag, "过" if chk["ok"] else "没过",
                             " ".join("%s:%s" % (st, "DONE" if v["done"] else ("UNCH" if v["unchanged"] else "无标记"))
                                      for st, v in chk["per_stage"].items()), chk["n_changed"], ctries))

            # —— 3. 追问**之前**的形式化系统 ——
            before = FS.snap(d)
            acts_before_probe = RM.srv_read(ARMKIT / "srvlog" / case)["actions"]

            probe = RM.drive_retry(agent, d, round_ask(arm), first=False,
                                   label="第 %d 次的追问" % k)
            ptxt = (probe.get("text") or "").strip()
            if probe["returncode"] != 0 or not ptxt:
                print("!! 第 %d 次的追问没回来：rc=%s" % (k, probe["returncode"]))
                rec["rounds"].append({"k": k, "play": play, "srv": srv_round,
                                      "probe": probe, "dead_probe": True})
                rec["stop"] = "probe_failed_at_round_%d" % k
                break

            acts_in_probe = (RM.srv_read(ARMKIT / "srvlog" / case)["actions"]
                             - acts_before_probe)
            if acts_in_probe:
                print("    !! 追问期间它又发了 %d 个动作 —— 那些动作算在**下一次** attempt 的预算里"
                      % acts_in_probe)
            after = FS.snap(d)
            in_round = FS.diff(before, after)
            vs_prev = FS.diff(prev_after, after)
            rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
            # 闸判**整轮**：一轮的形式化工作横跨游玩与追问两段，只判追问窗口会漏掉
            # 游玩阶段写的规则（冒烟实测漏掉过 2 条 concepts）。
            # **裸臂不过闸、不做对账。** 它没有形式化系统可动，闸只会一路走 B 路线判不过，
            # 然后把一条没有形式化工具的臂催去「把形式化系统补上」—— 那就不是对照组了。
            bare = (arm == "bare")
            gate = ({"route": None, "ok": True, "reasons": [], "n/a": "bare"} if bare
                    else GR.judge(vs_prev, ptxt, rep))
            tries = 0

            while not bare and not gate["ok"] and tries < a.gate_retry:
                tries += 1
                why = "\n".join("- " + x for x in gate["reasons"]) or "- 形式化系统一处没动。"
                print("  闸没过（%s 路线）：%s —— 补问第 %d 次"
                      % (gate["route"], gate["reasons"], tries))
                fix = RM.drive_retry(agent, d, GATE_RETRY % why, first=False,
                                     label="第 %d 次的补问" % k)
                ftxt = (fix.get("text") or "").strip()
                rec.setdefault("gate_retries", []).append(
                    {"k": k, "try": tries, "text": ftxt, "wall_s": fix.get("wall_s")})
                after = FS.snap(d)
                in_round = FS.diff(before, after)
                vs_prev = FS.diff(prev_after, after)
                rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
                # 和第一次判同一个口径：判**整轮**（vs_prev），不是只判追问窗口。
                gate = GR.judge(vs_prev, ptxt + chr(10) + ftxt, rep)

            # —— 闭合证明闸（--proof-gate）：判「不可能」类结论就必须有闭合的 Lean 主定理 ——
            proof = None
            if PROOF[0] and not bare and (RM.verdict_of(ptxt).get("verdict") or "").startswith("impossible"):
                proof = PG.check(d, ptxt, timeout=a.lean_timeout, built=built)
                ptries = 0
                while not proof["ok"] and ptries < a.proof_retry:
                    ptries += 1
                    print("  证明闸没过（%s）—— 补问第 %d 次" % (proof["why"], ptries))
                    pr = RM.drive_retry(agent, d, PG.retry_text(proof["why"]), first=False,
                                        label="第 %d 次的证明补问" % k)
                    ptxt = ptxt + chr(10) + (pr.get("text") or "").strip()
                    if not (RM.verdict_of(ptxt).get("verdict") or "").startswith("impossible"):
                        proof = {"ok": True, "why": [], "withdrawn": RM.verdict_of(ptxt).get("verdict")}
                        break
                    proof = PG.check(d, ptxt, timeout=a.lean_timeout, built=built)
                proof["tries"] = ptries
                if ptries:
                    after = FS.snap(d)
                    in_round = FS.diff(before, after)
                    vs_prev = FS.diff(prev_after, after)
                    rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
                print("  证明闸：%s（%s · %s · 补问 %d 次）" % ("过" if proof["ok"] else "没过", proof.get("file"),
                      proof.get("theorem") or proof.get("withdrawn"), ptries))

            # —— Lean 重放闸（--replay-gate）——
            replay = None
            if REPLAY[0] and not bare:
                lvl = int(srv_round["level"] or 0)
                tmpd = rounds_dir / case / "_tmp"
                keepd = rounds_dir / case / ("r%d" % k) / "replay"
                replay = RG.check(d, lvl, timeout=a.lean_timeout, tmp=tmpd, keep=keepd)
                rtries = 0
                while not replay["ok"] and rtries < a.gate_retry:
                    rtries += 1
                    print("  重放闸没过：%s —— 补问第 %d 次" % (replay["reasons"], rtries))
                    fix = RM.drive_retry(agent, d, RG.retry_text(replay), first=False,
                                         label="第 %d 次的重放补问" % k)
                    rec.setdefault("replay_retries", []).append(
                        {"k": k, "try": rtries, "text": (fix.get("text") or "").strip(),
                         "wall_s": fix.get("wall_s")})
                    replay = RG.check(d, lvl, timeout=a.lean_timeout, tmp=tmpd, keep=keepd)
                replay["tries"] = rtries
                replay.pop("build", None)
                if rtries:
                    # 补问可能改了形式化文件：重新照一张，让这一轮的 diff 与 Lean 编译把它算进去
                    after = FS.snap(d)
                    in_round = FS.diff(before, after)
                    vs_prev = FS.diff(prev_after, after)
                    rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
                print("  重放闸：%s（第 %d 关 %d 条转移：%d 步 / %d STUTTER；读不出 %d；对不上 %d；补问 %d 次）"
                      % ("过" if replay["ok"] else "没过", lvl, replay["n_rows"], replay["n_steps"],
                         replay["n_stutters"], len(replay["unreadable"]), len(replay["mismatch"]), rtries))
            if REPLAY[0]:
                RG.snapshot(d, rounds_dir / case / ("r%d" % k))

            # —— 自审闸（--selfaudit-gate）——
            sa = None
            if SELFAUDIT[0] and not bare:
                vv = (RM.verdict_of(ptxt).get("verdict") or "")
                sa_first = False
                if not sa_state["triggered"] and (vv.startswith("impossible") or k >= 4):
                    sa_state["triggered"], sa_first = True, True
                if sa_state["triggered"]:
                    sa = sa_check(d, sa_state["prev"], ptxt, sa_first)
                    sa["first"] = sa_first
                    satries = 0
                    while not sa["ok"] and satries < a.gate_retry:
                        satries += 1
                        print("  自审闸没过（%s）—— 补问第 %d 次" % (sa["why"], satries))
                        fix = RM.drive_retry(agent, d, SA_MISSING if sa["why"] == "missing" else SA_STALE,
                                             first=False, label="第 %d 次的自审补问" % k)
                        ftxt2 = (fix.get("text") or "").strip()
                        rec.setdefault("selfaudit_retries", []).append(
                            {"k": k, "try": satries, "why": sa["why"], "text": ftxt2, "wall_s": fix.get("wall_s")})
                        sa = sa_check(d, sa_state["prev"], ptxt + chr(10) + ftxt2, sa_first)
                        sa["first"] = sa_first
                    sa["tries"] = satries
                    if satries:
                        after = FS.snap(d)
                        in_round = FS.diff(before, after)
                        vs_prev = FS.diff(prev_after, after)
                        rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
                    print("  自审闸：%s（%s · pass1=%s · 本轮动了=%s · 补问 %d 次）"
                          % ("过" if sa["ok"] else "没过", "触发" if sa_first else "跟进", sa["has_pass1"],
                             sa["changed"], satries))
                    sa_state["prev"] = sa_snapshot(d)

            # —— 怀疑闸（--skeptic-gate）：判「到不了」类结论后，下一次 attempt 之前无条件追加 SA_SKEPTIC ——
            skeptic = None
            if SKEPTIC[0] and not bare and k < a.rounds:
                vk = (RM.verdict_of(ptxt).get("verdict") or "")
                if vk.startswith("impossible"):
                    print("  怀疑闸：判 %s → 追加 SA_SKEPTIC" % vk)
                    sk = RM.drive_retry(agent, d, SA_SKEPTIC, first=False, label="第 %d 次的怀疑追问" % k)
                    sktxt = (sk.get("text") or "").strip()
                    ptxt += chr(10) + sktxt
                    skeptic = {"sent": True, "verdict_before": vk, "wall_s": sk.get("wall_s"),
                               "returncode": sk.get("returncode"), "text": sktxt,
                               "verdict_after": RM.verdict_of(sktxt).get("verdict")}
                    after = FS.snap(d)
                    in_round = FS.diff(before, after)
                    vs_prev = FS.diff(prev_after, after)
                    rep, changed = lean_report(d, prev_after, after, built, a.lean_timeout)
                    if SELFAUDIT[0]:
                        skeptic["selfaudit_changed"] = sa_snapshot(d) != sa_state["prev"]
                        sa_state["prev"] = sa_snapshot(d)
                    print("  怀疑闸：回复 %.0fs · 自审文件%s" % (skeptic["wall_s"] or 0,
                          "有更新" if skeptic.get("selfaudit_changed") else "未更新/未查"))

            # v7h: skepticism can edit the model after the earlier proof check.
            if PROOF[0] and not bare and (RM.verdict_of(ptxt).get("verdict") or "").startswith("impossible"):
                proof = PG.check(d, ptxt, timeout=a.lean_timeout, built={})
                proof["rechecked_after_selfaudit_and_skeptic"] = True
            prev_after = after
            v = RM.verdict_of(ptxt)          # (v7e) the last VERDICT, after any proof-gate follow-up
            corr = ({"n_rules": 0, "n_defs": 0, "n_pairs": 0, "n_cited": 0, "n_silent": 0,
                     "rules_silent": [], "defs_without_rule": [], "n/a": "bare"} if bare
                    else CO.match(CO.rules(d), CO.defs(d),
                                  chr(10).join(f.read_text(encoding="utf-8", errors="replace")
                                               for f in sorted((d / "lean").rglob("*.lean")))
                                  if (d / "lean").exists() else ""))

            print("  追问 %.0fs → VERDICT=%s CONFIDENCE=%s" % (probe["wall_s"],
                                                              v["verdict"], v["confidence"]))
            print("  形式化系统：整轮动了 %d 处（规则层 %d · Lean %d）"
                  "，其中追问期间 %d 处"
                  % (vs_prev["touched"], vs_prev["rules_touched"],
                     vs_prev["lean_touched"], in_round["touched"]))
            for p in vs_prev["added"]:
                print("      新增 %s" % p)
            for p in vs_prev["changed"]:
                print("      改动 %s" % p)
            if rep:
                for f in rep["files"]:
                    print("      %-32s 编得过=%s 公理干净=%s"
                          % (f["file"], f["compiles"], f["clean"]))
            print("  闸：%s（%s 路线，补问 %d 次）· 规则层 %d 条，Lean 里没出现 %d 条"
                  % ("过" if gate["ok"] else "没过", gate["route"], tries,
                     corr["n_rules"], corr["n_silent"]))

            rec["rounds"].append({
                "k": k, "closed_by_reset": rs, "acts_in_probe": acts_in_probe,
                "end_state": end_state, "pushes": pushes, "play_first": play0,
                "closed": end_state["state"] in ("GAME_OVER", "WIN"),
                "play": play, "srv": srv_round, "probe": probe,
                "verdict": v, "lean": rep, "lean_changed": changed,
                "formal_in_round": in_round, "formal_vs_prev_round": vs_prev,
                "formal_after": after, "gate": gate, "gate_tries": tries, "replay_gate": replay, "selfaudit_gate": sa, "skeptic_gate": skeptic, "cards_gate": cards_rec, "proof_gate": proof,
                "correspond": {k2: corr[k2] for k2 in
                               ("n_rules", "n_defs", "n_pairs", "n_cited", "n_silent",
                                "rules_silent", "defs_without_rule")},
            })

            wl = int(r.get("win_level", a.win_level))
            # 第三个判据 2026-10-13 补：**目标关就是最后一关时前两个都不触发**。
            # vk71 目标关 4、总共 4 关 ⇒「关号 > 4」永不成立；`end_reason == "win"`
            # 只有 --one-life 档写。实测 vk71 ok 侧四轮全通关（end_state.state=WIN）
            # 而驱动一轮没停。对 sc25/cd82/su15 是 no-op（它们真通关时前一条早就触发了）。
            if ((srv_round["level"] or 0) > wl or srv.get("end_reason") == "win"
                    or (end_state or {}).get("state") == "WIN"):
                rec["stop"] = "win"
                print("  打过了这一关 ⇒ 停")
                break
            if k == a.rounds:
                rec["stop"] = "exhausted"

        if not a.smoke and rec["stop"] in ("win", "exhausted"):
            fin = RM.drive_retry(agent, d, final_ask(arm), first=False, label="收工追问")
            rec["final"] = fin
            rec["final_verdict"] = RM.verdict_of(fin.get("text") or "")
            if PROOF[0] and not bare and (rec["final_verdict"].get("verdict") or "").startswith("impossible"):
                rec["final_proof_gate"] = PG.check(d, fin.get("text") or "", timeout=a.lean_timeout, built={})
            print("  收工 → %s / %s" % (rec["final_verdict"]["verdict"],
                                        rec["final_verdict"]["confidence"]))
        rec["totals"] = {"rounds": len(rec["rounds"]), "wall_s": round(time.time() - t0, 1)}
        rec["mem_written"] = MC.peek(d) if hasattr(MC, "peek") else None
        results.append(rec)
        (HERE / a.out).write_text(json.dumps(results, ensure_ascii=False, indent=1),
                                  encoding="utf-8", newline="\n")
        print("  落盘 → %s" % (HERE / a.out))

    print()
    print("=" * 92)
    for rec in results:
        gates = [q.get("gate", {}).get("ok") for q in rec["rounds"] if "gate" in q]
        tch = [q.get("formal_in_round", {}).get("touched", 0) for q in rec["rounds"]]
        print("%-22s %-16s %d 轮 · 闸过 %d/%d · 逐轮动了 %s"
              % (rec["case"], rec["arm"], len(rec["rounds"]),
                 sum(1 for g in gates if g), len(gates),
                 " ".join(str(x) for x in tch)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
