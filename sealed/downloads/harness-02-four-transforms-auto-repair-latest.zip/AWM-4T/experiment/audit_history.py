from pathlib import Path
import json,csv,hashlib
R=Path(__file__).resolve().parent
E=R.parent/'paper_evidence_20261023'

def data(p):
    x=json.loads(p.read_text(encoding='utf-8-sig'))
    if isinstance(x,list):
        assert len(x)==1,(p,len(x))
        x=x[0]
    return x

def main():
    dest=R/'audit';dest.mkdir(exist_ok=True)
    cases=[];rounds=[]
    for folder in sorted((E/'02_awm_main').iterdir()):
        if not folder.is_dir():continue
        p=folder/'run.json'
        if not p.exists():
            if folder.name!='l4p-case-2a3cc5':continue
            # This cohort member lacks a normal complete run.json. Do not invent it.
            s=json.loads((folder/'session_text.json').read_text(encoding='utf-8'))
            cases.append(dict(case=folder.name,level=4,attempts=3,protocol='earlier armkit-v2 + element prior',wall_s=None,source=str(folder/'session_text.json'),source_sha256=hashlib.sha256((folder/'session_text.json').read_bytes()).hexdigest(),note='Stopped after attempt3; gate dependency compile failure at3; final V3 has later independent proof evidence. Not eight online completed proofs.'))
            for k,rt,lt,v,ok in [(1,8,1,'winnable',True),(2,1,1,'impossible_in_model_proved',True),(3,None,None,None,False)]:
                rounds.append(dict(case=folder.name,attempt=k,gate_route='A',gate_ok=ok,rules_touched=rt,lean_touched=lt,cards_present=False,verdict=v,source=str(folder/'console.log')))
            continue
        x=data(p);qs=x.get('rounds',[])
        cases.append(dict(case=folder.name,level=5 if folder.name.startswith('l5') else 4,attempts=len(qs),protocol=x.get('protocol'),wall_s=x.get('totals',{}).get('wall_s'),source=str(p),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),note='No per-stage cards in saved protocol.'))
        for q in qs:
            fd=q.get('formal_vs_prev_round') or q.get('formal_in_round') or {}
            rounds.append(dict(case=folder.name,attempt=q.get('k'),gate_route=(q.get('gate') or {}).get('route'),gate_ok=(q.get('gate') or {}).get('ok'),rules_touched=fd.get('rules_touched'),lean_touched=fd.get('lean_touched'),cards_present=bool(q.get('cards_gate')),verdict=(q.get('verdict') or {}).get('verdict'),source=str(p)))
    repairs=[]
    for name,p in [('L4',E/'05_awm_repair/strict_four_attempts/L4-m15fw-case-9ec8d4/run.json'),('L5',E/'05_awm_repair/within_four_attempts_L5/run.json')]:
        x=data(p)
        from datetime import datetime
        duration=(datetime.fromisoformat(x['finished'])-datetime.fromisoformat(x['started'])).total_seconds()
        repairs.append(dict(level=name,source=str(p),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),started=x['started'],finished=x['finished'],wall_s=duration,recorded_rounds=len(x.get('attempts',[])) if isinstance(x.get('attempts'),list) else None,attempt_count_basis='four driver rounds' if name=='L4' else 'four target-level attempts in service log; one aggregate CLI continuation',four_transformation_gate=False))
    (dest/'history.json').write_text(json.dumps(dict(main_runs=cases,per_attempt=rounds,selected_repairs=repairs),ensure_ascii=False,indent=2),encoding='utf-8')
    with (dest/'per-attempt.csv').open('w',encoding='utf-8-sig',newline='') as fo:
        w=csv.DictWriter(fo,fieldnames=list(rounds[0]));w.writeheader();w.writerows(rounds)
    print(json.dumps({'main':[dict(case=x['case'],attempts=x['attempts'],protocol=x['protocol'],wall_s=x['wall_s']) for x in cases],'round_rows':len(rounds),'repairs':repairs},ensure_ascii=True))

if __name__=='__main__':main()
