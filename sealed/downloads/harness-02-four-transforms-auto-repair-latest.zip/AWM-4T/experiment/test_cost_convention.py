"""Shared player contract and receiver AWM-only checks. No model or game server."""
from pathlib import Path
import copy,hashlib,json,sys,tempfile,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import protocol as P
import device_support as S
sys.path[:0]=[str(P.AK),str(P.V2)]
import run_v2 as D
import run_multi as M

class CostTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (R/'offline_out').mkdir(exist_ok=True)
        cls.tmp=tempfile.TemporaryDirectory(prefix='cost-contract-',dir=R/'offline_out');cls.stage=Path(cls.tmp.name)
        cls.B=P.configured_build();cls.shared={};cls.arenas={}
        for level,side in ((4,'no'),(5,'no5')):
            for i,arm in enumerate(('bare','framework')):
                case=f'l{level}s-case-cost-{arm}';p=cls.B.build_one(case,9970+i,arm,side,'claude',cls.stage,cls.shared,prior='none',prior_scope='all',rounds=True)
                cls.arenas[level,arm]=p
        cls.interview=(P.AK/'cost_interview.txt').read_text(encoding='utf-8')
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_bare_and_awm_readme_identical_both_levels(self):
        expected=(P.AK/'README-player-v2.3.md').read_bytes()
        for d in self.arenas.values():self.assertEqual((d/'README.md').read_bytes(),expected)
        self.assertEqual(len(self.shared['README.md']),1);self.assertEqual(len(self.shared['prompt_core']),1)
    def test_player_readme_neutral_and_accounting_explicit(self):
        t=(P.AK/'README-player-v2.3.md').read_text(encoding='utf-8')
        self.assertIn('final movement that enters the exit and completes a level incurs no additional cost',t)
        self.assertNotIn('impossible',t.lower());self.assertNotIn('unsolvable',t.lower())
        self.assertNotIn('least budget',t.lower());self.assertNotIn('36',t);self.assertNotIn('19',t)
    def test_original_collaborator_readme_preserved(self):
        original=self.B.ORIGINAL_README.read_text(encoding='utf-8')
        player=self.B.THEIR_README.read_text(encoding='utf-8')
        self.assertTrue(player.startswith(original.rstrip()+'\n\n'))
        self.assertNotIn('Accounting convention',original)
    def test_all_constructed_arenas_pass_blind_audit(self):
        for d in self.arenas.values():
            bad,hits,_=self.B.audit(d);self.assertEqual((bad,hits),([],[]))
    def test_current_awm_readme_preview_exact(self):
        expected=self.B.THEIR_README.read_bytes()
        self.assertEqual((R/'prompts/00-player-README.md').read_bytes(),expected)
    def test_round_and_final_shared_accounting(self):
        D.CG.load(P.CARDS)
        for func in (D.round_ask,D.final_ask):
            for arm in ('bare','framework'):
                t=func(arm);self.assertTrue(t.startswith(self.interview));self.assertEqual(t.count(self.interview),1)
    def test_legacy_readers_also_use_shared_accounting(self):
        for func in (M.round_ask,M.final_ask):
            for arm in ('bare','framework'):self.assertTrue(func(arm).startswith(self.interview))
    def test_bare_interviews_do_not_receive_framework_requirements(self):
        for func in (D.round_ask,D.final_ask):
            t=func('bare');self.assertNotIn('MAIN-THEOREM',t);self.assertNotIn('four-direction',t);self.assertNotIn('Proof-first reporting',t)
    def test_repair_first_round_final_same_units(self):
        texts=(P.feedback_text(),*P.repair_interviews())
        for t in texts:self.assertTrue(t.startswith(self.interview));self.assertNotIn('in your units>',t)
        self.assertIn("game's budget units",texts[1]);self.assertIn("game's budget units",texts[2])
    def test_awm_proof_retry_cost_definition_aligned(self):
        self.assertIn('Any cost/budget definitions and main theorem must use the README accounting convention',D.PG.retry_text(['dummy']))
    def test_awm_prompt_exports_equal_actual_runtime(self):
        D.CG.load(P.CARDS)
        for name,text in [('20-round-interview.txt',D.round_ask('framework')),('21-final-interview.txt',D.final_ask('framework')),('30-feedback-first.txt',P.feedback_text()),('32-feedback-round.txt',P.repair_interviews()[0]),('33-feedback-final.txt',P.repair_interviews()[1])]:self.assertEqual((R/'prompts'/name).read_text(encoding='utf-8'),text,name)
    def plan(self):
        path=self.stage/('plan-'+str(len(list(self.stage.glob('plan-*'))))+'.json');return P.create_plan(path)
    def test_six_awm_only_plan_and_contract_hash(self):
        plan=self.plan();self.assertEqual(len(plan['arms']),6);self.assertEqual({a['arm'] for a in plan['arms']},{'framework'})
        self.assertEqual(plan['recipient_scope'],'awm_only');self.assertEqual(plan['cost_convention_id'],'exit-terminal-free-v1');self.assertTrue(P.require_awm_plan(plan))
    def test_injected_bare_plan_rejected(self):
        p=self.plan();p['arms'][0]['arm']='bare'
        with self.assertRaises(ValueError):P.require_awm_plan(p)
    def test_old_plan_and_changed_readme_contract_rejected(self):
        p=self.plan();p['version']='old'
        with self.assertRaises(ValueError):P.require_awm_plan(p)
        p=self.plan();p['player_readme_sha256']='stale'
        with self.assertRaises(ValueError):P.require_awm_plan(p)
    def test_existing_foreign_plan_rejected(self):
        path=self.stage/'old-plan.json';path.write_text('{"arms":[]}',encoding='utf-8')
        with self.assertRaises(ValueError):P.create_plan(path)
    def test_staging_bare_through_receiver_entry_rejected(self):
        with self.assertRaises(ValueError):P.stage_one(None,dict(arm='bare'),self.stage,fixture=True)
    def test_incomplete_or_duplicate_replication_rejected(self):
        p=self.plan();p['arms'].pop()
        with self.assertRaises(ValueError):P.require_awm_plan(p)
        p=self.plan();p['arms'][1]['replicate']=1
        with self.assertRaises(ValueError):P.require_awm_plan(p)
    def test_terminal_only_conversion_accepted_without_wrong_bound_feedback(self):
        record=dict(protocol_valid=True,stop='exhausted',rounds=[{}]*8)
        decision=dict(status='correct',reported_bound=37,normalized_engine_bound=36,cost_convention='one hypothetical terminal unit removed',evidence='explicit original accounting',initial_record_sha256=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest())
        self.assertEqual(P.adjudicate(record,decision,5),'complete_initial_no_feedback')
        self.assertEqual(decision['reported_bound'],37)
    def test_no_automatic_plus_minus_one_tolerance(self):
        r=self.stage/'score-fixture';(r/'operator_only').mkdir(parents=True);(r/'results').mkdir();(r/'adjudications').mkdir()
        plan=self.plan();(r/'operator_only/batch-plan.json').write_text(json.dumps(plan),encoding='utf-8')
        for a in plan['arms']:
            rec=dict(protocol_valid=True,stop='exhausted',rounds=[{}]*8,final_proof_gate={'ok':True,'theorem':'Main'})
            (r/'results'/(a['case']+'-initial8.json')).write_text(json.dumps(rec),encoding='utf-8')
            val=19 if a['win_level']==4 else 36
            score=dict(status='correct',reported_bound=val,normalized_engine_bound=val,initial_record_sha256=S.canonical_record_sha(rec),evidence='explicit cost comparison')
            if a is plan['arms'][-1]:score['reported_bound']=37;score['normalized_engine_bound']=37
            (r/'adjudications'/(a['case']+'.json')).write_text(json.dumps(score),encoding='utf-8')
        with self.assertRaises(ValueError):S.summarize_initial(r)
    def test_engine_source_pins_unchanged(self):
        _b,l4,l5=P.modules()
        for p,want in ((l4.L4_SRC,l4.L4_MD5),(l5.L5_SRC,l5.L5_MD5)):self.assertEqual(hashlib.md5(p.read_bytes()).hexdigest(),want)
    def test_receiver_guide_says_only_awm(self):
        t=(R.parent/'给接收方Agent.md').read_text(encoding='utf-8');self.assertIn('不要先跑裸臂',t);self.assertIn('复用已有裸臂记录',t)
        self.assertIn('P.require_awm_plan(plan)',(R/'run_batch.py').read_text(encoding='utf-8'))
        self.assertIn('P.require_awm_plan(plan)',(R/'run_experiment.py').read_text(encoding='utf-8'))

class ReusePolicyTests(unittest.TestCase):
    def test_current_guides_reuse_without_sync_or_rerun(self):
        for name in ('START-HERE.md','使用说明书.md','协议变更与统计口径.md','给接收方Agent.md','V2.3-变更说明.md','旧裸臂复用与重评分.md'):
            t=(R.parent/name).read_text(encoding='utf-8')
            self.assertIn('复用',t,name);self.assertIn('重评分',t,name)
            for obsolete in ('裸臂由发送者本机负责','本机负责裸臂','须同步共同说明','新比较须登记相同计费说明','bare_sync_only/'):
                self.assertNotIn(obsolete,t,name)
    def test_no_bare_sync_directory_or_exported_interviews(self):
        self.assertFalse((R.parent/'bare_sync_only').exists())
        self.assertFalse((R/'prompts/20-bare-round-interview.txt').exists())
        self.assertFalse((R/'prompts/21-bare-final-interview.txt').exists())
    def test_archived_bare_sources_match_pins(self):
        pins=json.loads((R.parent/'BARE-RECORDS-SHA256.json').read_text(encoding='utf-8'))
        self.assertEqual(set(pins['groups']),{'01_baselines','03_bare_8plus4','04_bare_continuations'})
        self.assertTrue(all(n>0 for n in pins['groups'].values()))
        for rel,h in pins['files'].items():self.assertEqual(S.sha(R.parent/'paper_evidence_20261023'/rel),h,rel)
    def test_scoring_template_does_not_fabricate_new_results(self):
        t=json.loads((R.parent/'裸臂重评分表模板.json').read_text(encoding='utf-8'));self.assertEqual(t['rows'],[])
        for field in ('original_sha256','reported_bound','normalized_engine_bound','conversion_evidence','optimality_argument_review','closed_lean_status'):
            self.assertIn(field,t['fields'])
    def test_awm_messages_and_gate_code_unchanged_from_v23(self):
        pins=json.loads((R.parent/'AWM-PROMPTS-UNCHANGED.json').read_text(encoding='utf-8'))
        self.assertTrue(pins['files'])
        for rel,h in pins['files'].items():self.assertEqual(S.sha(R.parent/rel),h,rel)
    def test_disclosure_does_not_rewrite_old_prompt_history(self):
        t=(R.parent/'旧裸臂复用与重评分.md').read_text(encoding='utf-8')
        for phrase in ('旧裸臂没有收到新增计费说明','无需因此重跑','不能声称新旧题面逐字相同','重评分不能给裸臂补论证'):
            self.assertIn(phrase,t)


if __name__=='__main__':unittest.main(verbosity=2)
