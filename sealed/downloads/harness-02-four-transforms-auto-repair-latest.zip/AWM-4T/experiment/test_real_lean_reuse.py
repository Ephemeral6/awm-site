"""Actual Lean 4.34.1 small-module regression; no model or game server.

Production content/toolchain validation is active. Requires the pinned compiler.
"""
from pathlib import Path
import os,sys,tempfile,unittest,time,json
from unittest.mock import patch
R=Path(__file__).resolve().parent;AK=R/'harness/ARC-AGI/ours/benchmarks/armkit'
sys.path.insert(0,str(AK))
import leancheck as L
import safe_lean_cache as S

class RealLeanTests(unittest.TestCase):
    def test_real_transitive_change_same_mtime_cannot_use_stale_olean(self):
        self.assertTrue(L.LEAN.is_file(),'Install pinned Lean 4.34.1 before preflight')
        (R/'offline_out').mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=R/'offline_out',prefix='real-reuse-') as td:
            base=Path(td);d=base/'case';lean=d/'lean';lean.mkdir(parents=True)
            bottom=lean/'Bottom.lean';bottom.write_text('def bottom : Nat := 0\n',encoding='utf-8')
            (lean/'Dep.lean').write_text('import Bottom\ndef dep : Nat := bottom\n',encoding='utf-8')
            main=lean/'Main.lean';main.write_text('import Dep\ntheorem exactBound : dep = 0 := rfl\n#print axioms exactBound\n',encoding='utf-8')
            times=[]
            def check(**kw):
                t=time.monotonic();r=L.check_files(d,['lean/Main.lean'],timeout=60,**kw)['files'][0];times.append(dict(elapsed_s=time.monotonic()-t,cache_hit=r['cache_hit'],compiles=r['compiles'],validation_io_wall_s=r.get('validation_io_wall_s')));print('REAL_LEAN_STEP='+json.dumps(times[-1]),flush=True);return r
            with patch.dict(os.environ,{'AWM_ARCHIVE':str(base/'archive')}):
                try:
                    a=check();self.assertTrue(a['clean'],a['out']);self.assertFalse(a['cache_hit'])
                    b=check();self.assertTrue(b['clean'],b['out']);self.assertTrue(b['cache_hit']);self.assertEqual(a['compiler_receipt'],b['compiler_receipt'])
                    # Recreate the historic stale-artifact failure mode, preserving mtime.
                    c=next(iter(S._CASES[str(d.resolve())]['contexts'].values()))
                    for p in (c.shadow/'lean').glob('*.olean*'):(lean/p.name).write_bytes(p.read_bytes())
                    st=bottom.stat();bottom.write_text('def bottom : Nat := 1\n',encoding='utf-8');os.utime(bottom,ns=(st.st_atime_ns,st.st_mtime_ns))
                    bad=check();self.assertFalse(bad['compiles'],bad['out']);self.assertFalse(bad['cache_hit'])
                    main.write_text('import Dep\ntheorem exactBound : dep = 1 := rfl\n#print axioms exactBound\n',encoding='utf-8')
                    fresh=check(force_cold=True);self.assertTrue(fresh['clean'],fresh['out']);self.assertFalse(fresh['cache_hit'])
                finally:S.clear()
            self.assertFalse(list((base/'archive/safe_build').glob('lean-*')),'Owned build snapshots must be removed')
            print('REAL_LEAN_TIMING='+json.dumps(times),flush=True)

if __name__=='__main__':unittest.main(verbosity=2)
