"""Portable-phase and archived-evidence tests. No live model/service calls."""
from pathlib import Path
import sys,json,tempfile,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import device_support as D

class BatchTests(unittest.TestCase):
    def setUp(self):
        base=R/'offline_out';base.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(prefix='batch-',dir=base);self.r=Path(self.temp.name);assert self.r.resolve().is_relative_to(base.resolve())
        for d in ('operator_only','results','adjudications'):(self.r/d).mkdir()
        arms=[dict(case='sample'+str(i),win_level=4 if i<3 else 5,replicate=i%3+1) for i in range(6)]
        self.plan={'arms':arms};self.write(self.r/'operator_only/batch-plan.json',self.plan)
        for a in arms:
            r=dict(protocol_valid=True,stop='exhausted',rounds=[{}]*8,final_proof_gate={'ok':True,'theorem':'Main'})
            self.write(self.r/'results'/(a['case']+'-initial8.json'),r)
            s=dict(status='correct',initial_record_sha256=D.canonical_record_sha(r),normalized_engine_bound=19 if a['win_level']==4 else 36,evidence='Subject final statement and declared cost accounting checked.')
            self.write(self.r/'adjudications'/(a['case']+'.json'),s)
    def tearDown(self):self.temp.cleanup()
    def write(self,p,x):p.write_text(json.dumps(x),encoding='utf-8')
    def test_no_repair_before_summary(self):
        with self.assertRaises(ValueError):D.require_initial_batch_summary(self.r)
    def test_six_initial_results_then_summary(self):
        s=D.summarize_initial(self.r);self.assertEqual(s['correct_bounds'],6);self.assertEqual(D.require_initial_batch_summary(self.r)['denominator'],6)
    def test_missing_one_initial_prevents_summary(self):
        (self.r/'results/sample5-initial8.json').unlink()
        with self.assertRaises(ValueError):D.summarize_initial(self.r)
    def test_missing_adjudication_prevents_summary(self):
        (self.r/'adjudications/sample0.json').unlink()
        with self.assertRaises(ValueError):D.summarize_initial(self.r)
    def test_changed_result_invalidates_frozen_summary(self):
        D.summarize_initial(self.r);p=self.r/'results/sample0-initial8.json';x=D.unwrap(p);x['edited']=True;self.write(p,x)
        with self.assertRaises(ValueError):D.require_initial_batch_summary(self.r)
    def test_changed_plan_invalidates_frozen_summary(self):
        D.summarize_initial(self.r);self.plan['revision']='new';self.write(self.r/'operator_only/batch-plan.json',self.plan)
        with self.assertRaises(ValueError):D.require_initial_batch_summary(self.r)
    def test_false_correct_bound_rejected(self):
        p=self.r/'adjudications/sample0.json';x=D.unwrap(p);x['normalized_engine_bound']=20;self.write(p,x)
        with self.assertRaises(ValueError):D.summarize_initial(self.r)
    def test_initial_failure_is_retained(self):
        p=self.r/'results/sample0-initial8.json';r=D.unwrap(p);r.update(protocol_valid=False,stop='protocol_blocked_cards',rounds=[{}]);self.write(p,r)
        self.write(self.r/'adjudications/sample0.json',dict(status='protocol_failure',initial_record_sha256=D.canonical_record_sha(r),normalized_engine_bound=None,evidence='Missing required subject deliverable; retained as failure.'))
        x=D.summarize_initial(self.r);self.assertEqual(x['denominator'],6);self.assertEqual(x['correct_bounds'],5)

class EvidenceTests(unittest.TestCase):
    def test_six_main_proof_pins(self):
        e=R.parent/'paper_evidence_20261023';pins=json.loads((e/'proof_source_pins.json').read_text(encoding='utf-8'))
        self.assertEqual(len(pins),6)
        for x in pins:self.assertEqual(D.sha(e/x['file']),x['sha256'])
    def test_only_selected_repairs_delivered(self):
        e=R.parent/'paper_evidence_20261023/05_awm_repair'
        self.assertTrue((e/'strict_four_attempts/L4-m15fw-case-9ec8d4/run.json').exists())
        self.assertTrue((e/'within_four_attempts_L5/run.json').exists())
        self.assertFalse((e/'exploratory_20261021').exists())

class ReceiverReviewTests(unittest.TestCase):
    def setUp(self):
        base=R/'offline_out';base.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(prefix='review-',dir=base);self.r=Path(self.temp.name);assert self.r.resolve().is_relative_to(base.resolve())
        for d in ('operator_only','prompts','receiver_validation'):(self.r/d).mkdir()
        (self.r/'operator_only/batch-plan.json').write_text('{}',encoding='utf-8')
        (self.r/'prompts/manifest.json').write_text('{}',encoding='utf-8')
        (self.r/'protocol.py').write_text('# protocol',encoding='utf-8')
    def tearDown(self):self.temp.cleanup()
    def accept(self):
        r=dict(four_transforms_reviewed=True,memory_guard_reviewed=True,no_answer_leak_reviewed=True,protocol_sha256=D.protocol_hashes(self.r),plan_sha256=D.sha(self.r/'operator_only/batch-plan.json'),prompt_manifest_sha256=D.sha(self.r/'prompts/manifest.json'))
        (self.r/'receiver_validation/review_acceptance.json').write_text(json.dumps(r),encoding='utf-8')
    def test_missing_review_blocks_paid_execution(self):
        with self.assertRaises(ValueError):D.require_receiver_review(self.r)
    def test_source_change_invalidates_review(self):
        self.accept();self.assertTrue(D.require_receiver_review(self.r))
        (self.r/'protocol.py').write_text('# changed treatment',encoding='utf-8')
        with self.assertRaises(ValueError):D.require_receiver_review(self.r)
    def test_actual_prompt_change_invalidates_review(self):
        self.accept();(self.r/'prompts/manifest.json').write_text('{"new":"prompt"}',encoding='utf-8')
        with self.assertRaises(ValueError):D.require_receiver_review(self.r)

if __name__=='__main__':unittest.main(verbosity=2)
