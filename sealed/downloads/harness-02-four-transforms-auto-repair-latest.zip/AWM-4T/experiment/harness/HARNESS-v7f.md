# sc25 自审台架 v7f：完整台架（2026-10-22）

> 可移植包里的说明：这份文件原是审阅包 `ours/sc25-selfaudit-v7/README.md`。文中的 `prompts_l4/` `cards_v7f/` `tools_v7/`
> 在本包的 `ARC-AGI/ours/sc25-selfaudit-v7/` 下；`code/` 里各文件在本包 `ARC-AGI/` 下的原位置；`arena_l4/` `arena_l5/` `old/`
> 没有放进本包（跑场由 `selftest.py` / `run_one.py` 现造，与它们逐字节相同）。


这个文件夹是 v7f 的完整台架，内容包括：
- 受试开局时跑场里的全部文件；
- 驱动在每个时刻发给它的每一段文字；
- 跑起来用到的全部代码。

文字是从两个真实的 v7f 跑场导出的，这两个跑场只造场、不开跑（`l4s-case-v7f4aa`、`l5e-case-v7f5aa`）。导出用 `export_prompts.py` 和 `cards_gate.plan` / `proof_gate`，不是手抄。

正在跑的 v7f run `l4s-case-aafb4f` 和这里逐字节相同：METHOD 的 md5 都是 75952f00，`cards/` 与 `cards_v7f/` 也相同。

更早的版本放在 `old/` 里（v7c、v7d、v7e 的卡片和流程表），只作对照。

---

## 0. 要讲的故事，以及它落在台架的哪一处

```
观测     陌生环境里，用可执行、可判错的规则记下每一条转移            → METHOD 第一步 + play.py 两道闸（硬拦）
凝炼     用范畴论的两种极限、各两个方向，再加删除，把杂乱的规则册     → 阶段 01–03（对象 → 规则 → 回头重查对象）
         凝成一套更简单的对象和规则，已有观察一条都不变
           投射极限（赋，下定义）：上→下 结构分解；下→上 组合重构
           归纳极限（兴，找共性）：上→下 提取共性；下→上 拓展（带参数）
           删除：去掉 x 系统没有区别、观察一样 → 删
形式化   对象和规则写成 Lean 定义，和 Python 规则一一对应              → 阶段 04（定义层）
证明     在一个由这些规则导出的小证明模型上，给出闭合的「走不通」证明    → 阶段 05 + 闭合证明闸
         证明模型的每一条定义都追溯到规则，不新增假设
质疑     闭合之后还要假设模型比游戏严，逐条查承重规则、去游戏里测、     → METHOD 自审一节 + 自审闸 + 怀疑闸
         修规则、重新闭合（没有任何外部信号）
```

## 1. 目录

```
README.md  MANIFEST-md5.txt
prompts_l4/ prompts_l5/   受试看到的每一段文字，逐字（两关只差端口和目录名）
  00 跑场 README（服务怎么用）              01 第一条消息（每次 attempt 开头原样再发）
  02 METHOD.md（v7f，md5 75952f00）        03 每次 attempt 后的 6 问追问      04 收工追问
  05 催打        06 形式化闸补问            07 / 08 自审闸补问（缺 pass1 / 没更新）
  09 权限文件    10 怀疑闸
  11–15 第 1 次 attempt 后的五条阶段消息（前言 + 阶段全文）
  16–17 第 2–8 次 attempt 后的两条增量消息（凝炼：阶段 01–03；形式化：阶段 04–05）
  18 阶段补问模板        19 闭合证明闸补问（PROOF_RETRY）     MANIFEST.json（每份的来源与 md5）
cards_v7f/                五个阶段的全文（= 跑场里的 cards/）
tools_v7/                 field_split.py · criteria_run.py · _v7io.py · CONTRACT.md（跑场里的 tools/）
arena_l4/ arena_l5/       受试开局时跑场里的全部文件
code/
  armkit-v2/  run_v2.py（驱动）· cards_gate.py（阶段闸）· proof_gate.py（闭合证明闸）
              gate_round.py（形式化闸）· formal_state.py · correspond.py · replay_gate.py · ASK_round_lean.txt
  armkit/     run_multi.py（claude CLI：开会话 / -c 续）· build.py（造跑场）· leancheck.py（编 Lean、查公理）
              memclean.py · completion_round.py（看门狗）· ASK_*.txt（追问原文）
  stage/      stage_l4sa.py · stage_l5sa.py（造场）· method_v7.py（METHOD 拼装 + 断言）
              METHOD_step2_cards.md（METHOD 的「第二步」）· METHOD_addendum_selfaudit.md（自审一节 v7）
              stage_l4.py · stage_l5.py（引擎、禁词表）· arms_plan_*.json
  harness/    run_one.py（跑一条；开着 --selfaudit-gate --skeptic-gate --cards-gate cards_v7f --proof-gate）
              grade_one.py（打分 + 独立重编）· orphan_watchdog.py · lean_tracker.py · watch_batch_v7.py
              export_prompts.py · render_prompt_log.py（把每一步发出的 prompt 渲染出来）
  selfaudit/  selfaudit_round.py · rebuild.py
old/                      v7c / v7d / v7e 的卡片、流程表与冒烟记录
```

## 2. 一次 attempt 的完整时序（k = 1…8）

| # | agent 收到 | 要做什么 | 目的（故事里的哪一段） | 是否强制 |
|---|---|---|---|---|
| ① | `01` 第一条消息（k = 1 开新会话，k > 1 续同一个会话） | 玩到 GAME_OVER；动作前押注、动作后结算 | **观测** | 两道闸**硬拦**；中途停下就催（≤3 次） |
| ② | （无）驱动 reset | — | 一次 attempt 到此为止 | 驱动执行 |
| ③ | **k = 1：`11`–`15` 五条**（阶段全文）；**k > 1：`16`、`17` 两条**（各阶段的「必须做到」「做完之前跑这个」，全文在 `cards/`） | 阶段 01 对象：写解析、提对象（七条判据：简化、区分检验、对称，加四个方向）、第一次简化（删 / 合 / 拆 / 降）→ 阶段 02 长规则 → 阶段 03 规则：四个方向用到规则上、回头重查对象（删 / 拆 / 合 / 升降）、读数与反向测试 → 阶段 04 Lean 定义层 → 阶段 05 证明模型与主定理 | **凝炼 → 形式化 → 证明** | **阶段闸**：每个阶段一行 `CARD-DONE`（k > 1 可用 `CARD-UNCHANGED` + 理由）；交付物要在；文件要动过；没过补问 1 次（`18`）。内容不查 |
| ③-05 | 阶段 05 | 在 `lean/Proof/` 建小证明模型；`analysis/proof_model_map.txt` 每条定义一行（来源规则、怎么来的、为什么只会更宽）；能证的模拟就证；**不许加 `Rule/` 里没有的限制**；闭合主定理 + 非空洞性；闭合以后保持闭合；闭合不是终点 | **证明，而且证明模型来自规则** | 阶段闸：`Proof/` 下的 .lean 和对照表都要在。对照表内容由打分核对 |
| ④ | `03` 6 问追问 | 第 5 问：在这套系统上证明，报 `MAIN-THEOREM:` 和 `#print axioms` 原文 | 交出结论和证明 | 由解析器读 |
| ⑤ | 没过才收到 `06` | 改过的 .lean 都要编得过、公理干净，或者写 `FORMAL-UNCHANGED` | 每次 attempt 都要在形式化上有工作 | **闸**（≤1 次） |
| **⑤b** | **判「不可能」类结论、但没核过时，收到 `19`** | 要有 `MAIN-THEOREM` 那一行；那份文件台架重编得过；`#print axioms` 里有这条定理，公理只能是 propext / Quot.sound / Classical.choice；没有 sorry / native_decide | **判不可能，就必须有闭合的 Lean** | **闸**（≤2 次）。撤回判定也算过；读数取补问之后的最后一个判定 |
| ⑥ | 没过才收到 `07` / `08` | 从第一次判「不可能」起（最迟 k = 4）：写 `work/selfaudit/pass1.md`（敏感性表），以后每次都要更新 | **质疑** | **闸**（≤1 次） |
| ⑦ | 判 impossible… 且 k < 8 时收到 `10` | 假设至少一条规则比游戏严；从证据出发逐条重查；写下一遍自审；下一次 attempt 去测 | **质疑：即使 Lean 已经闭合** | **无条件发** |
| ⑧ | （无）记录 | — | 读数 | 驱动执行 |

自审（METHOD「自审」一节）的 (a)–(d)：
- (a) 敏感性：规则拆情形、只做可容许的放松、承重判定、触发类整张表、可达性搜索；
- (b) 探测：咬合步、排序、一次测多条、对照对；
- (c) 修：修规则、重放、重新闭合；
- (d) 做完。

v7f 的阶段 05 还规定：规则一改，先改 `Rule/`，再同步证明模型和对照表，然后重新闭合。

收工时收到 `04`。打分在全新目录里独立重编主定理。

## 3. 机器

- **每条 run 自己的看门狗**：可用内存 < 0.8 GB 时，杀本 run 子孙里最大的 lean。
- **`orphan_watchdog.py`**：整机可用内存 < 1.5 GB 时杀最大的 lean；任何一个 lean 超过 12 GB 也杀。
- **`lean_tracker.py`**：记录每个 lean 的归属。
- **每次查杀都单列为机器事件。**
- **并发**：这台机器同时最多跑两条编大表的 run。

## 4. 和之前版本的差别（细节见 `../sc25-selfaudit-phase2/PREREG-l4s-selfaudit.md`）

- **v7（试跑）**
  - 没有卡片；受试自己写粗模型，很快闭合，但界会偏高；
  - 靠自审和怀疑闸自己修：977afd 在第 5 次修到 19，370f47 第 5 次就是 36。
- **v7c**
  - 十张卡逐张发；卡 08 / 09 要求一一镜像 + 每关重放，证明被挤掉，一条闭合证明都没有。已停。
- **v7d**
  - 卡 10 加上「主定理第一优先，允许抽象」。
- **v7e**
  - 甲：十张并成五个阶段；
  - 乙：第 2–8 次只发两条增量消息；
  - 闭合证明闸；
  - 结果：受试多半直接在凝炼出来的细模型上证明，状态表 8 GB 以上，慢；4276a1 在证明闸补问后闭合了（Φ = 25 对 17 个动作，界偏高）。
- **v7f**（现在）
  - **必须**在一个由规则导出的小证明模型上证，并写对照表；
  - 不做观测重放，也不做打过各关的定理。
