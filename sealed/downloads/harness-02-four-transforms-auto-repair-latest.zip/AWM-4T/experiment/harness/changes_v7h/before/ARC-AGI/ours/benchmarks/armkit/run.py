# -*- coding: utf-8 -*-
"""跑受试：先让它自主打，打完**在同一个会话里**发追问。

    python run.py --arms arms_plan.json --stage D:/arc-arena
    python run.py --arms arms_plan.json --stage D:/arc-arena --only a-bare-no

前提：`build.py` 已经造好跑场、`--serve` 已经把服务起来。
这一份**只跑受试**，不造跑场、不起服务 —— 两件事分开，免得一边出错把另一边带坏。

## 口径

```
题面      跑场里的 _FIRST_MESSAGE.txt（build.py 写的，四条臂核心件逐字节相同）
追问      跑完之后在**同一个会话**里发
          claude  `-c` —— 按**项目路径（cwd）**分桶，并行安全
          codex   `resume <session_id>` —— id 由 `tokens.from_codex_rollout` 按
                  `session_meta.payload.cwd` 配出来。**不能用 `--last`**：
                  它取的是**全局最新**那条会话、不按 cwd，两条 codex 臂并行时会串台
          裸臂发核心四问；其余三条多发第 5 问（Lean）
算力      claude 走 --output-format json 的 usage；codex 走 tokens.py 的两个口径
服务侧    合并该 case 的**全部** jsonl（早先栽过：每个 case 起过两次服务，
          取最新那个空的，读数全成了 0）
```

**追问文本不写进跑场**，由这个脚本从 `armkit/ASK_*.txt` 现拼现发 ——
写进跑场等于让受试提前看见题。
"""
from __future__ import annotations

import argparse
import io
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tokens as TK                                            # noqa: E402

NPM = Path(os.environ.get("APPDATA", "")) / "npm"
CLI = {"claude": os.environ.get("AWM_CLAUDE") or str(NPM / "claude.cmd"), "codex": str(NPM / "codex.cmd")}

# ============================ codex 的模型与权限（2026-10-15 加，**默认行为一字不变**）
#
# **实测查出来的两个问题**（见 DECISIONS.md 同日那条）：
#   ① 第 1 轮写死 `gpt-6.1-sol` ⇒ 「astra 臂」从来不是 astra
#      （rollout 的 `collaboration_mode.model` 实测就是 gpt-6.1-sol）
#   ② `exec resume` **不带** `-s`，于是第 2 轮起 sandbox 掉回默认 **read-only**
#      （同一条 rollout：turn1 workspace-write、turn2-27 全是 read-only）
#      后果：受试从第 2 轮起**写不了文件** —— claude 臂全程写了 3 个 BFS 脚本，
#      codex 臂只有第 1 轮那两三个文件。这是一条**没控制住的不对称**。
#
# 改法是**加开关、不改默认**：不传就和以前逐字节相同，老读数仍可复现。
# `resume` 没有 `-s`，所以权限走 `-c sandbox_mode=...`（codex 的 config key）。
# 两个开关都从环境变量取默认值 ⇒ 不设环境变量时与旧版**逐项相同**，
# 设了就能逐跑控制（run_v2.py / run_multi.py 不必改）。
CODEX_MODEL = [os.environ.get("ARMKIT_CODEX_MODEL") or "gpt-6.1-sol"]
CODEX_PIN_RESUME = [os.environ.get("ARMKIT_CODEX_PIN_RESUME") == "1"]



def ask_text(arm: str) -> str:
    t = (HERE / "ASK_core.txt").read_text(encoding="utf-8")
    if arm != "bare":
        t += (HERE / "ASK_lean.txt").read_text(encoding="utf-8")
    return t + (HERE / "ASK_tail.txt").read_text(encoding="utf-8")


def drive(agent: str, d: Path, text: str, first: bool) -> dict:
    """发一段话给受试。`first=False` 时**续同一个会话**。"""
    env = dict(os.environ)
    # —— 环境怎么处理，全部是实测定下来的 ——
    #
    # **清掉**桌面应用注入的会话变量：受试继承它们等于和实验者的会话绑在一起，
    # 既是污染，也会让认证走岔路。
    for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
              "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN",
              "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_HOST_SESSION_ID",
              "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SDK_HAS_HOST_AUTH_REFRESH",
              "CLAUDE_CODE_ENTRYPOINT", "CLAUDECODE", "CLAUDE_CODE_SESSION_ATTENDED",
              "CLAUDE_CODE_TERMINAL_MCP_TOOLS", "CLAUDE_CODE_EXECPATH", "BAGGAGE"):
        env.pop(k, None)
    #
    # **保留并补齐代理**。这台机器上两个站要走相反的路（实测）：
    #     claude.ai          直连 302 通，走代理 403
    #     api.anthropic.com  直连 403，走代理 404 通
    # 一刀切设代理，授权那一跳断；完全不设，换 token 那一跳 403。
    # 所以：代理照用，但把 claude.ai 放进 NO_PROXY 走直连。
    if env.get("HTTPS_PROXY") or env.get("HTTP_PROXY"):
        no = env.get("NO_PROXY", "")
        for host in ("claude.ai", ".claude.ai"):
            if host not in no:
                no = (no + "," if no else "") + host
        env["NO_PROXY"] = no
        env["no_proxy"] = no
    t0 = time.time()
    if agent == "claude":
        cmd = [CLI["claude"], "-p", "--model", "opus", "--output-format", "json",
               "--dangerously-skip-permissions"]
        if not first:
            cmd.append("-c")
    elif first:
        cmd = [CLI["codex"], "exec", "-m", CODEX_MODEL[0],
               "-c", 'model_reasoning_effort="high"', "-s", "workspace-write",
               "-c", "sandbox_workspace_write.network_access=true",
               "-c", "shell_environment_policy.inherit=all",
               "--skip-git-repo-check", "-"]
    else:
        # **按 id 续，不用 `--last`。** `--last` 取全局最新那条会话、不按 cwd；
        # 两条 codex 臂并行时会互相串台。id 从该跑场自己的 rollout 里配出来
        # （`session_meta.payload.cwd`），配不到才退回 `--last` 并在读数里标出来。
        sid = None
        try:
            ro = TK.from_codex_rollout(d)
            sid = (ro or {}).get("session_id")
        except Exception:
            sid = None
        cmd = [CLI["codex"], "exec", "resume"]
        cmd += ([sid] if sid else ["--last"])
        cmd += ["--skip-git-repo-check", "-c", 'model_reasoning_effort="high"']
        if CODEX_PIN_RESUME[0]:
            # `resume` 没有 `-s`，权限只能走 config key；模型也要重新钉
            cmd += ["-m", CODEX_MODEL[0],
                    "-c", 'sandbox_mode="workspace-write"',
                    "-c", "sandbox_workspace_write.network_access=true",
                    "-c", "shell_environment_policy.inherit=all"]
        cmd += ["-"]
    r = subprocess.run(cmd, cwd=str(d), input=text, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=env)
    out = {"returncode": r.returncode, "wall_s": round(time.time() - t0, 1),
           "stderr": (r.stderr or "")[-1500:]}
    if agent == "codex":
        out["codex_env"] = {"model": CODEX_MODEL[0], "pin_resume": CODEX_PIN_RESUME[0],
                            "first": first}
    if agent == "codex" and not first:
        out["resumed"] = sid or "--last（配不到 session_id，**并行时不可靠**）"
    if agent == "claude":
        try:
            j = json.loads(r.stdout)
            out["text"] = j.get("result") or j.get("text") or ""
            out["tokens"] = TK.claude(j)
        except Exception:
            out["text"] = r.stdout
            out["tokens"] = {"cli": "claude", "note": "返回不是 json，抓不到 usage"}
    else:
        out["text"] = r.stdout
        out["tokens"] = TK.codex(r.stdout, d)
    return out


def srv_read(logdir: Path) -> dict:
    """**合并该 case 的全部 jsonl**。"""
    recs = []
    if logdir.exists():
        for f in sorted(logdir.glob("*.jsonl")):
            for line in io.open(f, encoding="utf-8", errors="replace"):
                line = line.strip()
                if line:
                    try:
                        recs.append(json.loads(line))
                    except Exception:
                        pass
    acts = [r for r in recs if r.get("ep") == "action"]
    last = recs[-1] if recs else {}
    end = [r for r in recs if r.get("ep") == "end"]
    return {"actions": len(acts),
            "level": last.get("level"),
            "levels_completed": last.get("levels_completed"),
            # `state` 是 2026-10-13 补的（只增不改，老调用方忽略它即可）：
            # `--retries` 档没有 `ep=end` 记录，「这一局赢没赢」只能看最后一条 action 的 state。
            # 目标关就是最后一关的游戏（vk71：第 4 关、一共 4 关）靠它才停得下来 ——
            # 「关号 > 胜负线」对它永远不成立。
            # **取最后一条 action、不是最后一条记录**：日志末尾往往是收尾的 `/reset`，
            # 那条会把关卡拨回去（实测 vk71 ok 侧：最后一条是 reset ⇒ level 1 / NOT_FINISHED，
            # 而它其实四轮全通关）。
            "state": (acts[-1].get("state") if acts else last.get("state")),
            "end_reason": (end[-1].get("end_reason") if end else last.get("end_reason")),
            "logs": len(list(logdir.glob("*.jsonl"))) if logdir.exists() else 0}


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", default="arms_plan.json")
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default="run.json")
    a = ap.parse_args(argv)
    stage = Path(a.stage)
    arms = json.loads((HERE / a.arms).read_text(encoding="utf-8"))["arms"]
    if a.only:
        pick = a.only.split(",")
        arms = [r for r in arms if any(w in r["case"] for w in pick)]

    results = []
    # **连续失败就停。** 第一轮栽过：前两条 claude 臂因 OAuth 过期 33s / 46s 就退了，
    # 脚本照样闷头往下跑，差点跑完一整轮废数据。
    # 受试自己打输了（预算耗尽、没通关）**不算失败** —— 那是读数；
    # 这里说的失败是**受试根本没跑起来**：退出码非 0，或者墙钟短得不可能真打过。
    streak = 0
    for r in arms:
        case, arm, agent = r["case"], r["arm"], r["agent"]
        d = stage / case
        if not d.exists():
            print("跳过 %s：跑场不在（先 build.py）" % case)
            continue
        prompt = (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8")
        print("=" * 92)
        print("%s  %s/%s  %s  端口 %s" % (case, arm, agent,
                                          "派生盘" if r["side"] == "no" else "原盘", r["port"]))
        rec = {"case": case, "arm": arm, "agent": agent, "side": r["side"], "port": r["port"]}
        rec["attempt"] = drive(agent, d, prompt, first=True)
        at = rec["attempt"]
        dead = (at["returncode"] != 0) or (at["wall_s"] < 60)
        if dead:
            streak += 1
            head = (at.get("text") or at.get("stderr") or "")[:200].replace(chr(10), " ")
            print("!! 这条没跑起来：rc=%s wall=%.0fs  %s" % (at["returncode"], at["wall_s"], head))
            if streak >= 2:
                print()
                print("**连续 %d 条没跑起来，停。** 不接着跑一整轮废数据。" % streak)
                print("   常见原因：CLI 认证过期、模型名写错、服务没起。")
                print("   修好之后重跑：python run.py --only <还没跑的那几个 case>")
                rec["server"] = srv_read(HERE / "srvlog" / case)
                results.append(rec)
                (HERE / a.out).write_text(json.dumps(results, ensure_ascii=False, indent=1),
                                          encoding="utf-8")
                return 3
        else:
            streak = 0
        print("① 尝试 %.0fs：%s" % (rec["attempt"]["wall_s"],
                                    (rec["attempt"]["text"] or "")[-300:].replace("\n", " ")))
        rec["ask"] = drive(agent, d, ask_text(arm), first=False)
        print("② 追问 %.0fs：" % rec["ask"]["wall_s"])
        print(rec["ask"]["text"] or "")
        rec["server"] = srv_read(HERE / "srvlog" / case)
        print("   服务侧：%s" % rec["server"])
        print("   算力：%s" % json.dumps(rec["attempt"].get("tokens"), ensure_ascii=False)[:200])
        results.append(rec)
        (HERE / a.out).write_text(json.dumps(results, ensure_ascii=False, indent=1),
                                  encoding="utf-8")
    print("写了 %s" % (HERE / a.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
