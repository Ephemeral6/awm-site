# -*- coding: utf-8 -*-
"""v7f -> v7g (2026-10-22): one addition to the v7f harness, nothing else changes.

User (2026-10-22): when deciding whether a level can be done and proving it, the subject may find that its rules lack
some necessary elements and regularities; it must record them and either add them to the rules now or confirm them by
exploring in the next attempt. Added, with the same wording, to
  - METHOD step two (sc25-selfaudit-phase2/METHOD_step2_cards.md), right after "proof model only from Rule/", and
  - stage 05 (sc25-selfaudit-v7/cards_v7f/05-主定理.md), item 2 of "必须做到", which the driver re-sends after every attempt.
The folder keeps its name cards_v7f (cards_gate.py keys its v7f mode on that name; stages and checks are unchanged).

    python -I apply_v7g.py                       # in the portable bundle (default --ours = ./ARC-AGI/ours)
    python -I apply_v7g.py --ours "D:/THU/2026 Summer/ARC-AGI/ours"
    python -I apply_v7g.py --check               # only report which version is on disk

Idempotent. Before editing it copies the two files to sc25-selfaudit-v7/old/v7f-before-v7g/. Afterwards it
regenerates the reference prompts (prompts_l4/ prompts_l5/: 02_METHOD.md and the stage messages 11-17) from the same
code the driver uses, and, in the portable bundle, updates selftest.py's expected METHOD md5.
Arenas that are already staged (runs in progress) are not touched: they keep the METHOD and cards they were built with.
"""
import argparse
import hashlib
import importlib.util
import re
import shutil
import sys
from pathlib import Path

MARK = "缺少一些必要的元素和规律"

METHOD_ANCHOR = "逐条写明来源，以及为什么只会比 `Step` 更宽、不会更严；能在 Lean 里证的就证（阶段 05）。\n"
METHOD_ADD = ("**要判定一关走得通还是走不通、并给出证明时，你可能会发现已有的规则缺少一些必要的元素和规律。**\n"
              "把它们记录下来（`analysis/record.txt`）：已经能从语料确认的，现在就加进规则（先 `rule/`、再 Lean 的 `Rule/`，\n"
              "照常在全部转移上判错）；还确认不了的，列成待测，在下一次 attempt 里通过探索去确认，确认之后再加进规则。\n"
              "证明模型只用已经加进 `Rule/` 的规则。\n")

CARD_ANCHOR = "   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。\n"
CARD_ADD = ("   - **要判定走得通还是走不通、并给出证明时，你可能会发现已有的规则缺少一些必要的元素和规律。**\n"
            "     把它们记录下来（`analysis/record.txt`）：已经能从语料确认的，现在就加进规则（先 `rule/`、再 `Rule/`，\n"
            "     照常在全部转移上判错）；还确认不了的，列成待测，在下一次 attempt 里通过探索去确认，确认之后再加进规则。\n"
            "     证明模型只用已经加进 `Rule/` 的规则。\n")

V7F_METHOD_MD5 = "75952f00c8ae"


def md5b(b):
    return hashlib.md5(b).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def insert_after(p: Path, anchor: str, add: str):
    s = p.read_bytes().decode("utf-8")
    nl = "\r\n" if "\r\n" in s else "\n"
    a, b = anchor.replace("\n", nl), add.replace("\n", nl)
    if MARK in s:
        return False
    assert s.count(a) == 1, "anchor not found exactly once in %s" % p
    p.write_bytes(s.replace(a, a + b).encode("utf-8"))
    return True


def composed_method(ours: Path) -> str:
    p2 = ours / "sc25-selfaudit-phase2"
    sys.path.insert(0, str(p2))
    for k in ("method_v7",):
        sys.modules.pop(k, None)
    mv7 = load("method_v7", p2 / "method_v7.py")
    l4p = ours / "benchmarks" / "armkit-v2" / "l4" / "METHOD_variant_2adf4911_584ce37c.md"
    sec = p2 / "METHOD_addendum_selfaudit.md"
    base, add = l4p.read_text(encoding="utf-8"), sec.read_text(encoding="utf-8")
    text = mv7.compose(base, add, "`mathlib` **没有**。")
    assert mv7.undo(text, base, add) == base
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ours", default=str(Path(__file__).resolve().parent / "ARC-AGI" / "ours"))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    ours = Path(a.ours)
    step2 = ours / "sc25-selfaudit-phase2" / "METHOD_step2_cards.md"
    card5 = ours / "sc25-selfaudit-v7" / "cards_v7f" / "05-主定理.md"
    for p in (step2, card5):
        assert p.exists(), "missing %s" % p
    on = [MARK in p.read_text(encoding="utf-8") for p in (step2, card5)]
    print("on disk: METHOD step two %s, stage 05 %s" % tuple("v7g" if x else "v7f" for x in on))
    if a.check:
        print("composed METHOD md5", md5b(composed_method(ours).encode("utf-8"))[:12])
        return 0

    bak = ours / "sc25-selfaudit-v7" / "old" / "v7f-before-v7g"
    bak.mkdir(parents=True, exist_ok=True)
    for p in (step2, card5):
        if not (bak / p.name).exists() and MARK not in p.read_text(encoding="utf-8"):
            shutil.copyfile(p, bak / p.name)
    print("METHOD step two:", "edited" if insert_after(step2, METHOD_ANCHOR, METHOD_ADD) else "already v7g")
    print("stage 05 card  :", "edited" if insert_after(card5, CARD_ANCHOR, CARD_ADD) else "already v7g")

    # leak scan with the same lists the stage scripts use
    armkit, v2 = ours / "benchmarks" / "armkit", ours / "benchmarks" / "armkit-v2"
    sys.path.insert(0, str(armkit))
    B = load("armkit_build_v7g", armkit / "build.py")
    S4 = load("stage_l4_lists_v7g", v2 / "l4" / "stage_l4.py")
    S5 = load("stage_l5_lists_v7g", v2 / "l5" / "stage_l5.py")
    words = list(B.LEAK_WORDS) + list(S4.L4_LEAK_WORDS) + list(S5.NEW_LEAK_WORDS)
    for p in (step2, card5):
        t = p.read_text(encoding="utf-8").lower()
        hit = [w for w in words if w.lower() in t]
        assert not hit, "leak word in %s: %r" % (p.name, hit)
    print("leak scan      : clean (%d words)" % len(words))

    # regenerate the reference prompts from the driver's own code
    text = composed_method(ours)
    m_md5 = md5b(text.encode("utf-8"))
    sys.path[:0] = [str(v2)]
    for k in ("cards_gate",):
        sys.modules.pop(k, None)
    CG = load("cards_gate", v2 / "cards_gate.py")
    cards = CG.load(ours / "sc25-selfaudit-v7" / "cards_v7f")
    gen = {"02_METHOD.md": text}
    for i, (st, m) in enumerate(CG.plan(cards, 1)):
        gen["%d_CARDS_attempt1_stage%s.txt" % (11 + i, st[0])] = m
    for i, (st, m) in enumerate(CG.plan(cards, 2)):
        gen["%d_CARDS_attempt2-8_stage%s.txt" % (16 + i, "+".join(st))] = m
    for lv in ("prompts_l4", "prompts_l5"):
        d = ours / "sc25-selfaudit-v7" / lv
        if not d.exists():
            continue
        old = d.parent / "old" / "v7f-before-v7g" / lv
        if not old.exists():
            shutil.copytree(d, old)
        changed = []
        for name, t in gen.items():
            f = d / name
            if not f.exists() or f.read_text(encoding="utf-8") != t:
                f.write_text(t, encoding="utf-8", newline="\n")
                changed.append(name)
        print("%s     : regenerated %s" % (lv, changed or "nothing (already v7g)"))

    st = Path(a.ours).resolve().parent.parent / "selftest.py"
    if st.exists():
        s = st.read_text(encoding="utf-8")
        s2 = re.sub(r'"METHOD.md": "[0-9a-f]{10}"', '"METHOD.md": "%s"' % m_md5[:10], s)
        if s2 != s:
            st.write_text(s2, encoding="utf-8")
        print("selftest.py    : expects METHOD md5 %s" % m_md5[:10])
    print("v7g METHOD md5 %s (v7f was %s). Arenas staged from now on get v7g; running arenas are unchanged."
          % (m_md5[:12], V7F_METHOD_MD5))
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())
