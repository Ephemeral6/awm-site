# -*- coding: utf-8 -*-
"""Self-test of the portable v7f bundle on a new Windows machine. Runs no subject and spends no model tokens
unless --claude is given.

    python -I selftest.py                 # environment + staging + byte-identity + game server + Lean
    python -I selftest.py --env-only      # environment checks only
    python -I selftest.py --claude        # also one tiny `claude -p` call (checks login and --model opus)
    python -I selftest.py --keep          # keep the two test arenas (default: delete them afterwards)

Environment variables (same as the real runs):
    AWM_STAGE    where arenas are built (default D:/arc-arena). Only letters, digits, '-' and '/' after the drive.
    AWM_ARCHIVE  where memory snapshots / rebuilds go (default D:/arc-arena-archive)
    AWM_CLAUDE   path of the claude CLI (default %APPDATA%/npm/claude.cmd)
"""
import argparse
import hashlib
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OURS = ROOT / "ARC-AGI" / "ours"
ARMKIT = OURS / "benchmarks" / "armkit"
V2 = OURS / "benchmarks" / "armkit-v2"
P2 = OURS / "sc25-selfaudit-phase2"
V7 = OURS / "sc25-selfaudit-v7"
STAGE = Path(os.environ.get("AWM_STAGE", "D:/arc-arena"))
LEAN = Path.home() / ".elan" / "toolchains" / "leanprover--lean4---v4.34.1" / "bin" / "lean.exe"
CLAUDE = os.environ.get("AWM_CLAUDE") or str(Path(os.environ.get("APPDATA", "")) / "npm" / "claude.cmd")

# what the reference v7f arenas got (sc25-selfaudit-v7/prompts_l4, prompts_l5; running run aafb4f is identical)
REF_MD5 = {"README.md": "24ee332e3a", "METHOD.md": "75952f00c8", ".claude/settings.local.json": "1eddecee3b"}
ROUND_ASK_MD5, FINAL_ASK_MD5 = "5085f83a9231a3deb7ec5a41c1b07c23", "b31b79e68bf083320232497df15afcae"

RESULTS = []


def ok(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print("[%s] %s%s" % ("PASS" if cond else "FAIL", name, ("  -- " + detail) if detail else ""), flush=True)
    return bool(cond)


def md5(b):
    return hashlib.md5(b).hexdigest()


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def free_port(start):
    p = start
    while not port_free(p):
        p += 1
    return p


def avail_gb():
    import ctypes

    class MS(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
    m = MS()
    m.dwLength = ctypes.sizeof(MS)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return m.ullTotalPhys / 2 ** 30, m.ullAvailPhys / 2 ** 30


def env_checks():
    ok("Windows", os.name == "nt", sys.platform)
    ok("Python >= 3.10 (tested with 3.13.2)", sys.version_info >= (3, 10), sys.version.split()[0])
    try:
        import importlib.metadata as md
        ok("arcengine == 0.9.3", md.version("arcengine") == "0.9.3", md.version("arcengine"))
    except Exception as e:  # noqa: BLE001
        ok("arcengine == 0.9.3", False, "not installed: pip install arcengine==0.9.3 (%s)" % e)
    try:
        import numpy
        ok("numpy importable (tested with 2.2.3)", True, numpy.__version__)
    except Exception as e:  # noqa: BLE001
        ok("numpy importable", False, str(e))
    if ok("Lean v4.34.1 at ~/.elan/toolchains/leanprover--lean4---v4.34.1", LEAN.exists(), str(LEAN)):
        r = subprocess.run([str(LEAN), "--version"], capture_output=True, text=True)
        ok("lean --version says 4.34.1", "4.34.1" in r.stdout, r.stdout.strip()[:80])
    if ok("claude CLI found", Path(CLAUDE).exists() or shutil.which(CLAUDE), CLAUDE):
        r = subprocess.run([CLAUDE, "--version"], capture_output=True, text=True, encoding="utf-8", errors="replace")
        ok("claude --version runs", r.returncode == 0, r.stdout.strip()[:60] + " (runs here used 2.1.296)")
    s = str(STAGE).replace("\\", "/")
    ok("AWM_STAGE is a simple path (memory-folder slug depends on it)",
       re.fullmatch(r"[A-Za-z]:(/[A-Za-z0-9-]+)+", s), s)
    ok("AWM_STAGE is not inside this bundle (the arena must not see the engines)",
       ROOT.resolve() not in STAGE.resolve().parents and STAGE.resolve() != ROOT.resolve(), s)
    longest = max(len(str(p)) for p in ROOT.rglob("*")) + 40
    ok("bundle path short enough for Windows' 260-character limit (unpack to e.g. D:/awm)", longest < 250,
       "longest path in the bundle + 40 for generated names = %d" % longest)
    tot, av = avail_gb()
    ok("RAM: >= 24 GB total (one Lean table can reach 8-12 GB; 28 GB ran two subjects at once)", tot >= 24,
       "%.1f GB total, %.1f GB free" % (tot, av))
    proj = Path.home() / ".claude" / "projects"
    slug = re.sub(r"[:\\/]", "-", s) + "-"
    stale = [p.name for p in proj.glob(slug + "*")] if proj.exists() else []
    ok("no old Claude memory folders for arenas under AWM_STAGE", not stale,
       ("found %d, e.g. %s (they would leak between runs; memclean archives them, but check)" % (len(stale), stale[:3]))
       if stale else "")


def stage(level, case, port, serve):
    plan = ROOT / "selftest_out" / ("arms_plan_%s.json" % case)
    plan.parent.mkdir(exist_ok=True)
    main = json.loads((P2 / ("arms_plan_l%ds_selfaudit.json" % level)).read_text(encoding="utf-8"))
    body = {k: v for k, v in main.items() if k != "arms"}
    body["stage"] = str(STAGE).replace("\\", "/")
    body["arms"] = [{"case": case, "port": port, "arm": "framework", "side": "no" if level == 4 else "no5",
                     "agent": "claude", "win_level": level}]
    plan.write_text(json.dumps(body, ensure_ascii=False, indent=1), encoding="utf-8")
    cmd = [sys.executable, "-I", str(P2 / ("stage_l%dsa.py" % (4 if level == 4 else 5))), "--plan", str(plan)]
    if serve:
        cmd.append("--serve")
    r = subprocess.run(cmd, cwd=str(ARMKIT), capture_output=True, text=True, encoding="utf-8", errors="replace",
                       env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    (ROOT / "selftest_out" / ("stage_%s.log" % case)).write_text(r.stdout + r.stderr, encoding="utf-8")
    return ok("stage level %d arena %s" % (level, case), r.returncode == 0 and (STAGE / case).exists(),
              (r.stdout + r.stderr).strip().splitlines()[-1][:160] if (r.stdout + r.stderr).strip() else "")


def identity(level, case, port):
    d = STAGE / case
    ref = V7 / ("prompts_l%d" % level)
    for rel, want in REF_MD5.items():
        got = md5((d / rel).read_bytes())
        ok("L%d %s byte-identical to the reference v7f arena" % (level, rel), got.startswith(want), got[:10])
    fm = (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8")
    rf = (ref / "01_FIRST_MESSAGE.txt").read_text(encoding="utf-8")
    norm = lambda t: re.sub(r"127\.0\.0\.1:\d+", "127.0.0.1:PORT", re.sub(r"[A-Za-z]:/[\w/-]*?/l[45][a-z]-case-\w+", "ARENA", t))  # noqa: E731
    ok("L%d first message identical up to port and arena path" % level, norm(fm) == norm(rf))
    for sub, src in (("cards", V7 / "cards_v7f"), ("tools", V7 / "tools_v7")):
        a = {p.name: md5(p.read_bytes()) for p in (d / sub).glob("*") if p.is_file()}
        b = {p.name: md5(p.read_bytes()) for p in src.glob("*") if p.is_file() and (sub == "cards" or p.name != "README.md")}
        ok("L%d arena %s/ == bundle %s" % (level, sub, src.name), all(a.get(k) == v for k, v in b.items()) and a, "%d files" % len(a))
    leak = [p.name for p in d.rglob("*") if p.is_file() and p.suffix == ".py" and p.name.startswith("sc25")]
    ok("L%d arena holds no engine file" % level, not leak, ", ".join(leak))


def driver_texts():
    sys.path[:0] = [str(V2), str(ARMKIT)]
    import run_v2 as R
    import cards_gate as CG
    import proof_gate as PG
    ref = V7 / "prompts_l4"
    ok("round questions (03) identical", md5(R.round_ask("framework").encode("utf-8")) == ROUND_ASK_MD5)
    ok("final questions (04) identical", md5(R.final_ask("framework").encode("utf-8")) == FINAL_ASK_MD5)
    for name, text in [("05_KEEP_PLAYING.template.txt", R.KEEP_PLAYING), ("06_GATE_RETRY.template.txt", R.GATE_RETRY),
                       ("07_SELFAUDIT_MISSING.txt", R.SA_MISSING), ("08_SELFAUDIT_STALE.txt", R.SA_STALE),
                       ("10_SKEPTIC.txt", R.SA_SKEPTIC)]:
        ok("driver text %s identical" % name, (ref / name).read_text(encoding="utf-8") == text)
    cards = CG.load(V7 / "cards_v7f")
    ok("cards gate in v7f mode", CG.MODE[0] == "v7f", CG.MODE[0])
    gen = {}
    for i, (_, m) in enumerate(CG.plan(cards, 1)):
        gen[str(11 + i)] = m
    for i, (_, m) in enumerate(CG.plan(cards, 2)):
        gen[str(16 + i)] = m
    gen["18"], gen["19"] = CG.CARD_RETRY, PG.PROOF_RETRY
    for f in sorted(ref.glob("1[1-9]_*")):
        ok("stage/proof message %s identical" % f.name, f.read_text(encoding="utf-8") == gen.get(f.name[:2]))
    return PG


def server(case, port):
    try:
        req = urllib.request.Request("http://127.0.0.1:%d/reset" % port, data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            j = json.loads(r.read().decode("utf-8"))
        fr = j["frames"][-1]
        ok("game server %s answers /reset with a 64x64 frame at level 1" % case.split("-")[0],
           len(fr) == 64 and len(fr[0]) == 64 and j.get("level") == 1, "state %s, levels_total %s" % (j.get("state"), j.get("levels_total")))
    except Exception as e:  # noqa: BLE001
        ok("game server answers /reset", False, repr(e)[:200])


def kill_port(port):
    r = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True)
    for ln in r.stdout.splitlines():
        p = ln.split()
        if len(p) >= 5 and p[1].endswith(":%d" % port) and p[3] == "LISTENING":
            subprocess.run(["taskkill", "/F", "/T", "/PID", p[4]], capture_output=True)


def lean(PG, case):
    d = STAGE / case
    f = d / "lean" / "Proof" / "SelfTest.lean"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text("theorem selftest_two : (1 : Nat) + 1 = 2 := by decide\n#print axioms selftest_two\n", encoding="utf-8")
    r = PG.check(d, "MAIN-THEOREM: lean/Proof/SelfTest.lean : selftest_two", timeout=300)
    ok("proof gate compiles a closed theorem with the pinned Lean", r.get("ok"), "; ".join(r.get("why") or []))
    f.write_text("theorem selftest_bad : (1 : Nat) + 1 = 3 := by sorry\n#print axioms selftest_bad\n", encoding="utf-8")
    r = PG.check(d, "MAIN-THEOREM: lean/Proof/SelfTest.lean : selftest_bad", timeout=300)
    ok("proof gate rejects a sorry", not r.get("ok"), "; ".join(r.get("why") or [])[:120])
    f.unlink()


def claude_call():
    tmp = ROOT / "selftest_out" / "claude_probe"
    tmp.mkdir(parents=True, exist_ok=True)
    r = subprocess.run([CLAUDE, "-p", "Reply with the single word OK.", "--model", "opus", "--output-format", "json"],
                       cwd=str(tmp), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    try:
        j = json.loads(r.stdout)
        ok("claude -p --model opus answers", "OK" in (j.get("result") or ""), "model(s): %s" % list((j.get("modelUsage") or {}).keys()))
    except Exception:  # noqa: BLE001
        ok("claude -p --model opus answers", False, (r.stdout + r.stderr)[:200])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env-only", action="store_true")
    ap.add_argument("--claude", action="store_true")
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    print("bundle %s\nAWM_STAGE %s\n" % (ROOT, STAGE))
    env_checks()
    if not a.env_only:
        STAGE.mkdir(parents=True, exist_ok=True)
        tag = secrets.token_hex(2)
        c4, c5 = "l4s-case-st%s" % tag, "l5e-case-st%s" % tag
        p4 = free_port(9471)
        made = []
        if stage(4, c4, p4, serve=True):
            made.append(c4)
            time.sleep(8)
            identity(4, c4, p4)
            server(c4, p4)
        p5 = free_port(p4 + 1)
        if stage(5, c5, p5, serve=True):
            made.append(c5)
            time.sleep(8)
            identity(5, c5, p5)
            server(c5, p5)
        PG = driver_texts()
        if made:
            lean(PG, made[0])
        kill_port(p4)
        kill_port(p5)
        if not a.keep:
            time.sleep(2)
            for c in made:
                for p in (STAGE / c, ARMKIT / "baseline" / c, ARMKIT / "srvlog" / c, ARMKIT / "srvout" / (c + ".out")):
                    if p.is_dir():
                        shutil.rmtree(p, ignore_errors=True)
                    elif p.exists():
                        p.unlink()
    if a.claude:
        claude_call()
    bad = [r for r in RESULTS if not r[1]]
    print("\n%d checks, %d failed" % (len(RESULTS), len(bad)))
    for n, _, d in bad:
        print("  FAIL", n, d)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())
