# -*- coding: utf-8 -*-
"""Stage the **l5s** arena (phase 2, level 5: self-audit built into the framework METHOD), via `armkit/build.py`,
without editing it, `l5/stage_l5.py` or `l4/stage_l4.py`.

    python -I stage_l5sa.py --plan arms_plan_l5s_selfaudit.json --dry-run
    python -I stage_l5sa.py --plan arms_plan_l5s_selfaudit.json --serve        # only at launch time

- engine side "no5" = sc25_L5_b35.py (md5 0f2d4207…), injected exactly as `l5/stage_l5.py` does;
- blinding lists: stage_l5.py's level-5 truth files and leak words, plus stage_l4.py's level-4 ones (additive);
- METHOD.md: **byte-identical to the level-4 phase-2 METHOD** = l5d's METHOD (armkit/METHOD.md + closed-proof v4)
  + the element prior (the user's decision for level 5, 2026-10-21) + the self-audit section. METHOD.md carries no
  level-specific content (the l4p METHOD is l5d's + the element prior). Re-derived here from l4p's METHOD file and
  the section, asserted equal to what stage_l4sa.py stages;
- build.py is called with the same arguments stage_l5.py passes (--prior none --prior-scope all --retries).
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = Path(str(Path(__file__).resolve().parents[1] / "benchmarks")) / "armkit-v2"      # (folder moved to ours/sc25-selfaudit-phase2 on 2026-10-21)
L4DIR, L5DIR = V2 / "l4", V2 / "l5"
ARMKIT = V2.parent / "armkit"
L4P_METHOD = L4DIR / "METHOD_variant_2adf4911_584ce37c.md"
L4P_METHOD_MD5 = "64a7116d3a6c5330bd4cf0db93c02dd9"
L5D_METHOD = L5DIR / "METHOD_variant_2adf4911.md"
SECTION = HERE / "METHOD_addendum_selfaudit.md"
ELEMENTS = L4DIR / "METHOD_addendum_elements.md"
ANCHOR3 = "`mathlib` **没有**。"


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()

# ---- v7 (2026-10-22): step two by cards, tools/ and cards/ in the arena ----
sys.path.insert(0, str(HERE))
import method_v7 as MV7                                            # noqa: E402
V7 = HERE.parent / "sc25-selfaudit-v7"
CARDS_DIR = V7 / "cards_v7f"
TOOLS_DIR = V7 / "tools_v7"
TOOL_FILES = ("field_split.py", "criteria_run.py", "CONTRACT.md")


def v7_extra(B):
    """Add cards/ and tools/ to the framework arena, and scan them for leak words."""
    ex = B.EXTRA["framework"]
    ex["dirs"] = [x for x in ex["dirs"] if x[0] != "cards"] + [("cards", CARDS_DIR)]
    extra_tools = sorted(p for p in TOOLS_DIR.glob("*") if p.is_file() and p.suffix in (".py", ".md")
                         and p.name != "README.md")
    names = {p.name for p in extra_tools}
    assert set(TOOL_FILES) <= names, "tools_v7 lacks %s" % (set(TOOL_FILES) - names)
    ex["files"] = [x for x in ex["files"] if not x[0].startswith("tools/")] + \
        [("tools/" + p.name, p) for p in extra_tools]
    texts = [f.read_text(encoding="utf-8") for f in sorted(CARDS_DIR.glob("*.md"))] + \
        [p.read_text(encoding="utf-8") for p in extra_tools] + [MV7.STEP2_NEW.read_text(encoding="utf-8")]
    for w in B.LEAK_WORDS:
        for t in texts:
            assert w.lower() not in t.lower(), "leak word in cards/tools/step two: %r" % w



def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--serve", action="store_true")
    a = ap.parse_args(argv)

    S5 = load("stage_l5_lists", L5DIR / "stage_l5.py")
    S4 = load("stage_l4_lists", L4DIR / "stage_l4.py")
    if md5(S5.L5_SRC) != S5.L5_MD5:
        raise SystemExit("level-5 sealed engine md5 mismatch")
    assert md5(L4P_METHOD) == L4P_METHOD_MD5, "l4p METHOD variant changed on disk"
    # the l4p METHOD is l5d's METHOD + the element prior, nothing else
    assert L4P_METHOD.read_text(encoding="utf-8").replace(ELEMENTS.read_text(encoding="utf-8"), "", 1) \
        == L5D_METHOD.read_text(encoding="utf-8")

    sys.path.insert(0, str(ARMKIT))
    B = load("armkit_build", ARMKIT / "build.py")
    B.SIDES["no5"] = (S5.L5_SRC, S5.L5_MD5)
    before = (len(B.LEAK_WORDS), len(B.FORBIDDEN_FILES))
    for w in S5.NEW_LEAK_WORDS + S4.L4_LEAK_WORDS:
        if w not in B.LEAK_WORDS:
            B.LEAK_WORDS.append(w)
    B.FORBIDDEN_FILES |= S5.NEW_TRUTH_FILES | S4.L4_TRUTH_FILES
    print("injected (additive only): SIDES['no5'] = %s; LEAK_WORDS %d->%d, FORBIDDEN_FILES %d->%d"
          % (S5.L5_SRC.name, before[0], len(B.LEAK_WORDS), before[1], len(B.FORBIDDEN_FILES)))

    base = L4P_METHOD.read_text(encoding="utf-8")
    add = SECTION.read_text(encoding="utf-8")
    assert base.count(ANCHOR3) == 1
    i = base.index(ANCHOR3)
    var = HERE / ("METHOD_variant_2adf4911_584ce37c_%s_c%s.md" % (md5(SECTION)[:8], md5(MV7.STEP2_NEW)[:8]))
    text = MV7.compose(base, add, ANCHOR3)
    assert MV7.undo(text, base, add) == base, "v7 METHOD is not base + step two by cards + self-audit"
    v7_extra(B)
    if var.exists():
        assert var.read_text(encoding="utf-8") == text, "staged METHOD differs from the level-4 phase-2 METHOD"
    else:
        var.write_text(text, encoding="utf-8", newline="\n")
    for w in B.LEAK_WORDS:
        assert w not in add, "leak word in the self-audit section: %r" % w
    B.EXTRA["framework"]["doc"] = ("METHOD.md", var)
    B.EXTRA["framework_model"]["docs2"] = [("METHOD.md", var)]
    print("   METHOD.md -> %s (md5 %s) = l4p's METHOD + %s; identical to the level-4 phase-2 METHOD"
          % (var.name, md5(var)[:12], SECTION.name), flush=True)

    args = ["--arms", str(Path(a.plan).resolve()), "--stage", a.stage, "--prior", "none", "--prior-scope", "all",
            "--retries"]
    if a.dry_run:
        args.append("--dry-run")
    if a.serve:
        args.append("--serve")
    return B.main(args)


if __name__ == "__main__":
    raise SystemExit(main())
