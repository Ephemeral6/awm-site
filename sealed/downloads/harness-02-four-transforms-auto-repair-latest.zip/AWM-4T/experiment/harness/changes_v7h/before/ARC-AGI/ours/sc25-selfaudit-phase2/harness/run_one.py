# -*- coding: utf-8 -*-
"""Run ONE phase-2 subject end to end, exactly as the l4s queue would, with one command.

    python -I run_one.py --dry-run                         # print what it would stage/run; touches nothing
    python -I run_one.py --case l4s-case-672e2a            # run an arena that stage_l4sa.py already built
    python -I run_one.py --new --port 9297                 # build a fresh arena (new random id) and run it

What it does
1. (--new) writes a one-arm plan `runs/arms_plan_<case>.json` with the same terms as ../arms_plan_l4s_selfaudit.json
   and builds the arena with ../stage_l4sa.py --serve (METHOD = l4p's + the self-audit section; the stage script
   asserts that byte for byte).
2. machine guard: refuses to start while another subject driver runs (run_v2 / run_multi / selfaudit_round / queues)
   unless --allow-concurrent; waits for >= 6 GB free.
3. runs armkit-v2/run_v2.py with the queue's flags:
       --rounds 8 --win-level 4 --only <case> --lean-timeout 1200 --mem-archive D:/arc-arena-archive/l4s-selfaudit
   (no --closed / --rigor / --decide / --replay-gate; the messages it sends are exported verbatim in prompts/).
   A watchdog kills the largest lean.exe among this script's descendants if free RAM drops below 0.8 GB (as in l4p).
4. writes runs/run_v2_<case>.json (run_v2's own readout) and runs/<case>.log; then call grade_one.py.
"""
import argparse
import datetime
import json
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
P2 = HERE.parent
V2 = Path(str(Path(__file__).resolve().parents[2] / "benchmarks")) / "armkit-v2"      # (folder moved to ours/sc25-selfaudit-phase2 on 2026-10-21)
SA = V2 / "selfaudit"
ARMKIT = V2.parent / "armkit"
sys.path.insert(0, str(SA))
sys.path.insert(0, str(ARMKIT))
import selfaudit_round as S            # noqa: E402  (other_drivers, port_free)
import completion_round as CR          # noqa: E402  (avail_gb, Watchdog)

STAGE = __import__("os").environ.get("AWM_STAGE", "D:/arc-arena")
MEM_ARCHIVE = (__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/l4s-selfaudit")
RUNS = HERE / "runs"


LEVELS = {   # level -> (plan, stage script, run_v2 --win-level, case prefix, engine side); terms as l4p / l5d
    4: ("arms_plan_l4s_selfaudit.json", "stage_l4sa.py", "4", "l4s-case-", "no"),
    5: ("arms_plan_l5s_selfaudit.json", "stage_l5sa.py", "5", "l5e-case-", "no5"),
}


def flags(case, plan, out, level):
    return [sys.executable, "-u", str(V2 / "run_v2.py"), "--arms", str(plan), "--stage", STAGE,
            "--rounds", "8", "--win-level", LEVELS[level][2], "--only", case, "--out", str(out),
            "--mem-archive", MEM_ARCHIVE, "--lean-timeout", "1200",
            "--selfaudit-gate",   # (2026-10-21, user: enforce the self-audit in the harness, not in METHOD)
            "--skeptic-gate",     # (2026-10-21, user: after every impossibility verdict, assume the proof is not tight)
            # (2026-10-22, user: before the questions, feed the condensation/formalization cards one by one)
            "--cards-gate", str(P2.parent / "sc25-selfaudit-v7" / "cards_v7f"),
            "--proof-gate"]   # (2026-10-22 v7e, user: an impossibility claim must come with a closed Lean proof)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--level", type=int, choices=[4, 5], default=4)
    ap.add_argument("--case")
    ap.add_argument("--new", action="store_true")
    ap.add_argument("--port", type=int, default=9297)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--allow-concurrent", action="store_true")
    ap.add_argument("--smoke", action="store_true", help="(2026-10-22) run_v2 --smoke: attempt 1 only (play, ten cards, questions, gates), no final interview")
    a = ap.parse_args()
    RUNS.mkdir(exist_ok=True)
    plan_name, stage_script, _, prefix, side = LEVELS[a.level]
    main_plan = json.loads((P2 / plan_name).read_text(encoding="utf-8"))
    if a.new:
        case = prefix + secrets.token_hex(3)
        plan = RUNS / ("arms_plan_%s.json" % case)
        body = {k: v for k, v in main_plan.items() if k != "arms"}
        body["_comment"] = "harness run_one.py, %s: one fresh arm, same terms as %s" % (datetime.date.today(), plan_name)
        body["arms"] = [{"case": case, "port": a.port, "arm": "framework", "side": side, "agent": "claude",
                         "win_level": a.level}]
    else:
        assert a.case, "--case or --new"
        case = a.case
        plan = P2 / plan_name
        assert any(r["case"] == case for r in main_plan["arms"]), "case not in %s" % plan_name
    out = RUNS / ("run_v2_%s.json" % case)
    cmd = flags(case, plan, out, a.level)
    if a.smoke:
        cmd.append("--smoke")
        cmd[cmd.index("--rounds") + 1] = "1"      # smoke = attempt 1 only
    print("case     ", case)
    print("plan     ", plan)
    print("stage    ", "python -I %s --plan %s --serve" % (P2 / stage_script, plan) if a.new else "(already staged)")
    print("run      ", " ".join('"%s"' % x if " " in x else x for x in cmd))
    print("cwd      ", V2)
    print("readout  ", out)
    if a.dry_run:
        return 0
    if a.new:
        # (2026-10-22 03:15) a second run on a busy port talked to the other run's game server: refuse instead
        if not S.port_free(a.port):
            raise SystemExit("port %d is already listening: refusing to stage a second server there" % a.port)
        plan.write_text(json.dumps(body, ensure_ascii=False, indent=1), encoding="utf-8")
        r = subprocess.run([sys.executable, "-I", str(P2 / stage_script), "--plan", str(plan), "--serve"],
                           cwd=str(ARMKIT), capture_output=True, text=True, encoding="utf-8", errors="replace",   # servers must not hold this folder
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        print(r.stdout[-1500:], r.stderr[-800:])
        if r.returncode != 0:
            return 2
        time.sleep(8)
    assert Path(STAGE, case).exists(), "arena missing: build it first"
    assert not out.exists(), "readout exists already: %s" % out
    while True:
        busy = [] if a.allow_concurrent else S.other_drivers()
        if CR.avail_gb() < 6.0:
            busy.append("free %.1f GB < 6" % CR.avail_gb())
        if not busy:
            break
        print("[%s] waiting: %s" % (time.strftime("%H:%M:%S"), "; ".join(busy)), flush=True)
        time.sleep(300)
    CR.LEAN_CAP_GB = 1e9                 # floor-only watchdog, as in the l4p queue
    CR.LOG = RUNS / ("%s.watchdog.log" % case)
    wd = CR.Watchdog("run_one-" + case)
    wd.start()
    t0 = time.time()
    with open(RUNS / ("%s.log" % case), "w", encoding="utf-8") as fo:
        p = subprocess.run(cmd, cwd=str(V2), stdout=fo, stderr=subprocess.STDOUT,
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    wd.stop.set()
    print("run_v2 rc=%s, %.0f min, watchdog events %s" % (p.returncode, (time.time() - t0) / 60, wd.events))
    print("next: python -I grade_one.py --case %s" % case)
    return p.returncode


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())
