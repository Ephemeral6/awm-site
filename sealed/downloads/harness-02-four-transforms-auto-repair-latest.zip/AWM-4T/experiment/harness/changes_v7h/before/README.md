# AWM · sc25 自审台架 v7f：可移植包（Windows）

这个包可以在另一台 Windows 机器上，原样复现我们这边正在跑的 v7f 实验（L4 与 L5 的密封关，框架臂，每条 8 次 attempt）。

这台机器上已验证过两件事：
- 用包里的代码造出来的跑场，与正在跑的 `l4s-case-aafb4f` 以及参考跑场 `l4s-case-v7f4aa` / `l5e-case-v7f5aa` **逐字节相同**；
- 驱动发出的每一段文字也逐字节相同。

`selftest.py` 会在新机器上把这些再核一遍。

> **故事和每一步的 prompt 在哪里看**：[`HARNESS-v7f.md`](HARNESS-v7f.md)（每次 attempt 的时序表、哪一步强制）。
> 逐字的 prompt 在 `ARC-AGI/ours/sc25-selfaudit-v7/prompts_l4/`、`prompts_l5/`（00–19），阶段卡片全文在 `cards_v7f/`。

---

## 1. 包里有什么

```
README.md            本文件
HARNESS-v7f.md       台架说明：故事 → 台架的哪一处；一次 attempt 里 agent 收到什么、要做什么、是否强制
selftest.py          新机器上先跑它（不跑受试、默认不花 token）
PATCHES.txt          相对原件改了哪些行（只有路径，见第 6 节）
MANIFEST-md5.txt     每个文件的 md5
ARC-AGI/             按原机器的目录结构摆放（代码里的相对路径因此不用改）
  ours/benchmarks/armkit/          v1 驱动层：run.py（调 claude CLI）· run_multi.py · build.py（造跑场、起服务）
                                   leancheck.py · memclean.py · completion_round.py（看门狗）· ASK_*.txt · METHOD.md
                                   fwkit/（play.py settle.py geo.py）· lean/（骨架）· ledger-sc25/
  ours/benchmarks/armkit-v2/       run_v2.py（v7f 驱动）· cards_gate.py（阶段闸）· proof_gate.py（闭合证明闸）
                                   gate_round.py · formal_state.py · correspond.py · replay_gate.py · ASK_*.txt
                                   selfaudit/（selfaudit_round.py、rebuild.py）· l4/ l5/（禁词表与 METHOD 底稿）
  ours/benchmarks/sc25-budget/variant/   密封引擎（L4 = sc25_L4_b18.py，L5 = sc25_L5_b35.py，另有核 md5 用的几档）
  ours/benchmarks/sc25-oracle/pack-v2/   build.py 造场时要读（oracle 臂的包；v7f 不发给受试）
  collab/pilot4-astra-pack/…/      游戏服务 cd82/code/server_pilot.py、sc25 原版代码与给玩家的 README
  ours/sc25-selfaudit-phase2/      stage_l4sa.py · stage_l5sa.py · method_v7.py · METHOD 的第二步与自审一节 · 两份 plan
    harness/                       run_one.py（跑一条）· grade_one.py（打分 + 独立重编）
                                   orphan_watchdog.py · lean_tracker.py · export_prompts.py · render_prompt_log.py
  ours/sc25-selfaudit-v7/          cards_v7f/（五个阶段）· tools_v7/（给受试的工具）· prompts_l4/ prompts_l5/（参考 prompt）
```

**包里有答案。** 密封引擎、oracle 包、各关证书相关的代码都在 `ARC-AGI/` 里。台架保证受试只拿到跑场目录：
- 跑场造在 `AWM_STAGE`；
- 受试的规则要求它不许看工作目录以外的东西；
- `build.py` 造场时按禁文件名、禁词表扫一遍。

所以**跑场必须放在这个包外面**（`selftest.py` 会检查）。也不要把这个包放进 agent 能随手看到的位置，比如受试工作目录的上级。

## 2. 新机器上要装的东西

| 东西 | 版本 | 怎么装 / 说明 |
|---|---|---|
| Windows 10/11 | — | 看门狗用 PowerShell `Get-CimInstance` 和 `taskkill` |
| Python | 3.13（≥ 3.10 能跑；这边是 3.13.2） | 装好后 `python` 要在 PATH 里 |
| arcengine、numpy | `arcengine==0.9.3`（必须）、`numpy==2.2.3` | 用 `pip` 安装（命令见下方） |
| Lean | **v4.34.1**，必须装在 `~/.elan/toolchains/leanprover--lean4---v4.34.1/` | 先装 elan，再用 `elan` 安装这个版本（命令见下方）。不需要 Mathlib，也不需要 lake。METHOD.md 告诉受试的就是这个路径 |
| Claude Code CLI | 这边是 **2.1.296**，`--model opus` | 用 npm 全局安装（命令见下方），然后在任意目录运行一次 `claude` 并登录。不是 npm 装的，就设 `AWM_CLAUDE` 指向 `claude.exe` |
| 内存 | ≥ 24 GB；同时跑两条要 28 GB 以上 | 受试的一张 Lean 状态表能到 8–12 GB |
| 磁盘 | 每条 run 几百 MB 到几 GB | 主要是受试的 `.olean`、状态表、转移记录 |

```bash
pip install arcengine==0.9.3 numpy==2.2.3
```

```bash
elan toolchain install leanprover/lean4:v4.34.1
```

```bash
npm i -g @anthropic-ai/claude-code@2.1.296
```

版本不同（CLI 或背后的模型）照样能跑，但读数就不能和这边的直接比了。**报告时请写明 CLI 版本和模型。**

## 3. 解压与设置

1. **解压到短路径**，例如 `D:\awm`。Windows 有 260 字符的路径上限：解压得太深，造场时写文件会失败（这边实测过）。路径里有空格没关系。
2. 设三个环境变量（不设就用这边的默认值）。在 PowerShell 里：
   ```powershell
   $env:AWM_STAGE   = "D:/arc-arena"           # 造跑场的地方；盘符后只能有字母、数字、- 和 /
   $env:AWM_ARCHIVE = "D:/arc-arena-archive"   # 记忆快照、独立重编的输出
   # $env:AWM_CLAUDE = "C:/Users/<you>/.local/bin/claude.exe"   # 只有 claude 不在 %APPDATA%\npm 时才要
   ```
   要长期生效，就把 `$env:X = "..."` 换成 `setx X "..."`，然后开一个新窗口。
   `AWM_STAGE` 有字符限制，是因为 Claude 会按工作目录名在 `~/.claude/projects/` 下建记忆文件夹，记忆检查和打分要按同样的规则找到它。
3. 跑自检：
   ```bash
   python -I selftest.py
   ```
   会检查下面这些（这边是 49 项全过）：
   - 环境：Python、arcengine、Lean v4.34.1、claude CLI、`AWM_STAGE` 的写法与位置、路径长度、内存、有没有残留的旧记忆文件夹；
   - 造场：各造一个 L4、L5 测试跑场。README.md、METHOD.md（md5 75952f00）、权限文件要与参考跑场逐字节相同；第一条消息只差端口和目录；`cards/`、`tools/` 与包里的一致；跑场里没有引擎文件；
   - 游戏服务：起一个 L4 游戏服务，`/reset` 能拿到 64×64 的第 1 关画面；
   - 驱动文字：追问、催打、各个闸的补问、五条阶段消息、两条增量消息、证明闸补问，逐字节与 `prompts_l4/` 相同；
   - Lean：证明闸用钉死的 Lean 编过一条闭合定理，并拒绝一条带 sorry 的定理；
   - 做完就删掉测试跑场，关掉测试服务。

   再运行带 `--claude` 的版本（命令见下方），会多调一次 `claude -p --model opus`，用来确认已登录、模型可用（花很少的 token）。

```bash
python -I selftest.py --claude
```

## 4. 跑一条

在 `ARC-AGI/ours/sc25-selfaudit-phase2/harness/` 下操作，**每条 run 开三个窗口**。

**窗口 1：跑受试**（造新跑场、起游戏服务、跑满 8 次 attempt，大约 6–20 小时）

```bash
python -I run_one.py --new --level 4 --port 9301
```

L5 把 `--level 4` 换成 `--level 5`，端口换一个没被占用的。先运行一次带 `--dry-run` 的版本（命令见下方），可以只打印它会做什么、什么都不动。

```bash
python -I run_one.py --new --level 4 --port 9301 --dry-run
```

`run_one.py` 做的事：
- 写一份单臂 plan（`runs/arms_plan_<case>.json`）；
- 调 `stage_l4sa.py --serve` 造跑场、起服务；
- 等到机器上没有别的驱动在跑、可用内存 ≥ 6 GB；
- 用以下参数跑 `armkit-v2/run_v2.py`：
  ```
  --rounds 8 --win-level 4 --lean-timeout 1200
  --selfaudit-gate --skeptic-gate --cards-gate <cards_v7f> --proof-gate
  ```
- 自带一个看门狗：可用内存 < 0.8 GB 时，杀本 run 子孙里最大的 lean。

**同时跑两条**：第二条要加 `--allow-concurrent`，否则它会一直等第一条跑完。这台 28 GB 的机器上，最多同时跑两条会编大表的 run。

**L5 一次跑三条（推荐用批处理）**：`run_batch_l5.py` 会依次起三条 L5 run（v7f，每条 8 次 attempt），每起一条就补起两个辅助进程，全部跑完后对每条跑一次 `grade_one.py`。先运行带 `--dry-run` 的版本，确认端口和命令（命令见下方）。
- 默认一次只跑一条，可用内存 ≥ 10 GB 才起下一条。L5 受试的 Lean 表单条能到 10 GB 左右，48 GB 以上的机器才建议 `--max-concurrent 2`。
- 日志在 `runs/batch_l5.log`；每条 run 自己的输出在 `runs/run_one_L5_<port>.out` 和 `runs/<case>.log`。
- 批处理开着时，不用另开窗口 2、3。
- 判对错的口径：L5 的上限是 35，引擎最少要 36 步。

```bash
python -I run_batch_l5.py --dry-run
```

```bash
python -I run_batch_l5.py --n 3
```

**窗口 2、3：两个辅助进程**。在 run_one 起来之后再开（命令见下方）。它们在机器上没有 run_one 时会自己退出，所以**每次新开 run 都要重新起**。
- `orphan_watchdog.py`：受试经 Bash 起的 lean 脱离了 run_one 的进程树时，由它来管。整机可用内存 < 1.5 GB 时杀最大的 lean，任何一个 lean 超过 12 GB 也杀。记录写在 `runs/orphan.watchdog.log`。
- `lean_tracker.py`：记录每个 lean 属于哪条 run，写在 `runs/lean_tracker.jsonl`。

```bash
python -I orphan_watchdog.py
```

```bash
python -I lean_tracker.py
```

**看进度**：
- `runs/<case>.log`：驱动日志，包括每次 attempt、阶段闸、证明闸、自审闸、怀疑闸；
- `../../benchmarks/armkit-v2/prompts_log/run_v2_<case>.jsonl`：发给受试的每一条消息原文、回复长度和耗时。用 `render_prompt_log.py` 可以把它渲染出来。

**跑完以后**：
- 先运行 `grade_one.py`，拿到每次 attempt 的判定、自审轨迹、游戏使用情况；
- 再带上 `--rebuild` 运行一次：在 `AWM_ARCHIVE` 下的新目录里，从源码独立重编受试的主定理，并查公理表；
- 主定理的文件和名字，来自最后一次追问里的 `MAIN-THEOREM:` 那一行；
- 输出在 `harness/grade/<case>.json` 和 `.md`。

```bash
python -I grade_one.py --case <case>
```

```bash
python -I grade_one.py --case <case> --rebuild lean/Proof/<Main>.lean <定理全名>
```

**怎么判对错**（预注册的口径）：
- L4 的引擎最少要 19 步（上限 18），L5 最少要 36 步（上限 35）。
- 受试给的界恰好等于这两个数，才算对。
- 多 1 的情况，只有多出来的那 1 正好是「赢的那一步」的收费时才算对（引擎不收赢的那一步）。这一条要人看证据来判。

## 5. 跑的时候不要做的事

- 不要动跑场目录（受试正在里面写），也不要在跑场里开别的 Claude 会话。
- 不要在这台机器的 Claude 账号里，用同一个跑场路径开别的会话：记忆文件夹按路径命名。旧的同名记忆文件夹会被 memclean 归档，但最好一开始就没有。
- 游戏服务是一次性的：重启机器、或服务进程被杀，那条 run 就作废（记成 VOID，重新 `--new`）。
- 不要把跑场造在这个包里面，也不要把这个包放进 `AWM_STAGE`。
- 不要给 agent 额外的权限。跑场里的 `.claude/settings.local.json` 只允许 Bash/Read/Write/Edit/Glob/Grep，以及访问 127.0.0.1。

## 5b. v7g（2026-10-22）

`apply_v7g.py` 把台架从 v7f 升到 v7g。只加一段话：在要判定走得通还是走不通、并给出证明时，规则里缺了必要的元素和规律，就记下来，能确认的现在加进规则，确认不了的下一次 attempt 去探索确认。

这段话同时加在 METHOD 的第二步和阶段卡片 05 里，原文见 `PROMPT-另一台机器-v7g.md`。

运行 `python -I apply_v7g.py`，然后再跑一遍 `selftest.py`。之后新造的跑场都是 v7g（METHOD 的 md5 是 0dd9363540ad），已经造好的跑场不变。

## 6. 相对原件的改动

只改了路径（33 处，逐条列在 `PATCHES.txt`），行为不变：
- 写死的 `D:/arc-arena` 改为 `$AWM_STAGE`，默认值仍是 `D:/arc-arena`；
- `D:/arc-arena-archive/...` 改为 `$AWM_ARCHIVE/...`；
- `D:/THU/2026 Summer/ARC-AGI/ours/benchmarks` 改为由文件自身位置推出的相对路径；
- claude CLI 改为 `$AWM_CLAUDE`，没设时仍用 `%APPDATA%\npm\claude.cmd`；
- 打分和记忆检查里，Claude 记忆文件夹的名字改为由 `AWM_STAGE` 推出。

不设这几个环境变量时，代码的行为与原机器上完全一样。其余文件都与原件逐字节相同。

受试看到的东西（README、METHOD、卡片、工具、各条消息）没有一个字的改动；`selftest.py` 核的就是这一点。

`PATCHES.txt` 末尾列的「还含盘符的字符串」都是有意保留的：
- 上面那些环境变量的默认值；
- 正则表达式；
- 合作者包里 v7f 用不到的 `sc25/code/run/` 脚本。
