# AWM 可移植台架 v7h（Windows，2026-10-23）

这个目录已升级到 v7h，保留原目录名 `awm-v7f-portable`。不需要再运行 `apply_v7g.py`。
旧文件备份在 `changes_v7h/before/`，历史说明 `HARNESS-v7f.md` 只描述旧协议。
新提示、资源限制和运行读数不可冒充旧 v7f/v7g 的完全同条件复现。

## 四项变化

1. 凝练只用四个方向：投射极限的结构分解、组合重构，归纳极限的提取共性、带参数拓展。
   删除是共同验收条件；分离表、消融和变异是诊断工具，不再是额外的必答判据。
   这是论文术语与操作的对应，不是自动验证范畴论泛性质的声明。
2. 平时重点凝练证明依赖、新证据和反例影响的部分。其余规则仍保留在模型和全量拒绝集回归中。
   每次更新前后检查全部历史转移和确定性变异；真实修错可以改变拒绝集，但须显式记录证据与差异。
3. 任何 impossible 类结论必须逐条审查完整规则清单（包括暂缓凝练的规则）。
   `full_rule_audit.json`、当前源码/语料哈希和拒绝集收据是机械闸；自由文本的语义正确性仍须独立审阅。
   自审/怀疑引起修改之后重新核验闭合性，不沿用修改前的通过记录。
4. 每次 CLI 或独立 Lean 编译调用及其整个子进程树：**提交内存硬上限 8 GiB**；
   驻留内存（RSS）每 50ms 检测，合计超过上限则终止该调用树。内核硬限可拒绝采样间隔内的提交分配。
   不杀游戏服务或其他 run。超限强制在同一会话进行无游戏动作的资源 repair，再重发中断阶段；
   最多两次资源修复机会，未修好就明确资源阻塞，不计为游戏终判。

8 GiB = 8×1024³ 字节。检测的是运行内存，不是 `.py`/`.lean` 的文件大小；流式处理和证明分块可降低峰值，
删除日志或删合法路线不算修复。资源事件和实际修复 prompt 留在 `$AWM_ARCHIVE/resource_events/`，
驱动读数还保留 `resource_report`、`resource_calls`/`resource_recovery`。计入中断和修复的耗时。

## 安装与隔离

建议复制到短路径，例如 `D:\awm`。需要 Windows 10/11、Python ≥3.10（推荐3.13）、
`arcengine==0.9.3`、`numpy==2.2.3`、Lean **4.34.1**，以及已登录的 Claude Code CLI。
不需要 Mathlib 或新的 Python 内存监控库。

```powershell
pip install arcengine==0.9.3 numpy==2.2.3
elan toolchain install leanprover/lean4:v4.34.1
# 若还未安装 Claude Code：
npm install -g @anthropic-ai/claude-code
claude
```

记录实际 CLI 版本；更换版本后先重跑自检。台架源码包含密封引擎和答案侧代码，**不能放进受试跑场**。
在包根目录设置：

```powershell
$env:AWM_STAGE = 'D:/awm-arena'         # 必须在本包外，路径只用字母、数字、横杠
$env:AWM_ARCHIVE = 'D:/awm-archive'
$env:AWM_RUNTIME = 'D:/awm-runtime'     # 每次调用的私有临时目录，结束后清理
$env:AWM_CLAUDE_MODEL = 'claude-opus-5-5'
$env:AWM_EXPECTED_MODEL = 'claude-opus-5-5'
# CLI 不在 %APPDATA%\npm 时：
# $env:AWM_CLAUDE = 'C:/path/to/claude.exe'
```

模型名按服务实际支持的完整 ID 设置；默认请求 Opus5.5。每次正常返回检查 `modelUsage`，
缺失或不匹配不计有效调用，不会静默换成另一个模型。可以配置服务要求的请求别名，
但 `AWM_EXPECTED_MODEL` 必须是目标模型的实际完整 ID；先用下面的可选认证自检确认。
没有标准 CLI seed 参数，三次 run 是**三个独立会话/跑场的重复**，不声称可复现的数值 seed。

```powershell
python -I test_v7h.py          # 离线：小内存阈值实测、互不误杀、资源修复、全规则闸、拒绝集
python -I selftest.py         # 离线：造L4/L5场、密封引擎、实际prompt、闭合Lean/拒绝sorry
python -I selftest.py --claude # 可选；会付费调用一次很小的请求，核对登录与模型
```

自检的内存测试用128MiB小阈值，不会故意申请8GiB物理内存。实际游戏服务和受试调用仍是不同进程。
如 `selftest` 报路径过长，把完整包移到短路径；如有旧会话同名记忆，不要混入新实验。

## 一条命令：L4三个run、L5三个run，最多三个并行

每条 run 内仍为 8 次 attempt，同一会话连续学习；各 run 的目录、会话、端口独立。
并行由三个独立工作进程实现，运行计划和结果单独落盘，不共享受试记忆。

```powershell
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/run_replicates.py --dry-run
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/run_replicates.py --levels 4 5 --runs-per-level 3 --max-concurrent 3 --base-port 9531
```

三并行启动前要求至少 **28 GiB可用内存**（3×8+4余量），48GB物理内存的机器较合适。
不足时明确退出，可改 `--max-concurrent 1` 或 `2`；不会为凑并发偷偷提高内存上限。
只跑一个关卡可用 `--levels 4` 或 `--levels 5`。默认端口9531—9536，已占用会拒绝启动。

新批次目录：`ARC-AGI/ours/sc25-selfaudit-phase2/harness/runs/batch-v7h-<时间>-<编号>/`：

- `plan.json`：六项计划、请求模型与并发数。
- `L4-rep1.out` 等：每条运行的入口日志，开头有 case 名和端口。
- `results.json`：完成状态、case、退出码和日志位置；退出码0只说明调度完成，不代表证明正确。
- `<case>.grade.out`：自动调用 `grade_one.py` 的初步评分。

更细的阶段日志在 `harness/runs/<case>.log`；逐条提示在
`ARC-AGI/ours/benchmarks/armkit-v2/prompts_log/run_v2_<case>.jsonl`。
内存事故额外看 `$AWM_ARCHIVE/resource_events/`，不要把中断当作 undecided 或 impossible。
批次正常结束或 Ctrl-C/异常退出时，均按本批次 PID 与 case 归属清理；清理结果保存在 results.json。
中断的 run 标为中断，不要重启游戏服务后沿用同一个 case。

单条运行和干跑：

```powershell
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/run_one.py --new --level 4 --port 9541 --dry-run
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/run_one.py --new --level 4 --port 9541
```

**不再需要开 orphan_watchdog.py 或 lean_tracker.py 窗口。** 旧的名字扫描型看门狗和旧
`run_batch_l5.py` 是历史入口，新实验使用上面的 `run_replicates.py`；不要混用全局助手。
单条入口结束后可显式清理该 case 的服务（先核对 case 名）：

```powershell
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/stop_server.py --case <case>
```

脚本核对保存的 PID、服务器命令路径和 case 日志路径；身份不符就拒绝终止，不按进程名扫杀。
游戏服务须保持一次性状态：中途重启服务就将该 run 标为 VOID，新建 case，不能冒充续跑。

## 跑完与交付结果

对每个 case 报：level/重复编号、模型完整ID、CLI版本、台架版本、8次attempt记录、内存事故、
最终VERDICT、MAIN-THEOREM、证明闸/全规则闸结果、独立重编结果。

```powershell
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/grade_one.py --case <case>
python -I ARC-AGI/ours/sc25-selfaudit-phase2/harness/grade_one.py --case <case> --rebuild lean/Proof/Main.lean Namespace.theorem
```

文件/定理名取最终答复的 MAIN-THEOREM 行，不要照抄示例。闭合定理、公理干净、模型与游戏对应是三件事；
人工仍须查动作覆盖、收费、抽象是否放宽、未知交互及反例。机械闸不能保证自然语言理由正确。
不同prompt/资源/模型版本分开报告；不要把失败的资源调用补记成有效实验或偷偷替换原数据。

## 代码地图

| 位置（ARC-AGI/ours/ 下） | 作用 |
|---|---|
| sc25-selfaudit-phase2/harness/run_replicates.py | 六条独立run与最多三进程调度 |
| sc25-selfaudit-phase2/harness/run_one.py | 新case、造场、单条run、已有各闸的启动参数 |
| sc25-selfaudit-phase2/stage_l4sa.py、stage_l5sa.py | 密封引擎与盲化跑场；旧跑场不改 |
| sc25-selfaudit-phase2/METHOD_step2_cards.md | 新凝练主提示，由 method_v7.py 拼入 METHOD |
| sc25-selfaudit-v7/cards_v7h/ | 四方向、聚焦凝练、全规则审查的五阶段原文 |
| sc25-selfaudit-v7/tools_v7/rejection_check.py | 全语料/固定变异前后比较，带哈希收据 |
| benchmarks/armkit-v2/run_v2.py、cards_gate.py | 阶段调度、怀疑自审后重验闭合 |
| benchmarks/armkit-v2/scope_gate.py、proof_gate.py | 全规则清单/新鲜度闸、主定理内核与公理检查 |
| benchmarks/armkit/run.py、resource_guard.py | 固定模型、同会话资源修复、Windows调用树内存硬限和RSS检测 |
| benchmarks/armkit/leancheck.py | 独立重编也受相同资源保护 |
| sc25-selfaudit-v7/prompts_l4/、prompts_l5/ | 由实际代码生成的当前参考prompt；20是强制资源修复全文 |

`HARNESS_VERSION.json` 标识本次版本；`MANIFEST-v7h-sha256.json` 标识交付源文件。
`selftest_out/` 是本机检查输出，不是受试结果；已存在的跑场/运行记录没有被补丁改写。
