"""Offline targeted tests: no paid model calls; allocation tests use128MiB caps."""
import concurrent.futures,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
AK=ROOT/'ARC-AGI/ours/benchmarks/armkit';V2=AK.parent/'armkit-v2'
sys.path[:0]=[str(AK),str(V2)]
import resource_guard as RG
import scope_gate as SG

class GuardTests(unittest.TestCase):
    def test_normal_input_and_oom_words_are_not_a_failure(self):
        r=RG.run_capture([sys.executable,'-c','import sys; print(sys.stdin.read()); print("std::bad_alloc was repaired")'],cwd=ROOT,input='ping',timeout=15,limit_bytes=128*1024**2)
        self.assertEqual(r.returncode,0);self.assertIn('ping',r.stdout);self.assertFalse(r.resource_report['resource_exceeded'])
        self.assertTrue(r.resource_report['temporary_directory_removed'])
    def test_grandchild_is_capped_and_other_run_survives(self):
        large='import subprocess,sys; subprocess.run([sys.executable,"-c","x=bytearray(256*1024*1024)"])'
        def big():return RG.run_capture([sys.executable,'-c',large],cwd=ROOT,timeout=20,limit_bytes=128*1024**2)
        def small():return RG.run_capture([sys.executable,'-c','import time; time.sleep(.6); print("other-run-ok")'],cwd=ROOT,timeout=20,limit_bytes=128*1024**2)
        with concurrent.futures.ThreadPoolExecutor(2) as pool:a,b=pool.submit(big),pool.submit(small);a,b=a.result(),b.result()
        self.assertEqual(a.returncode,137);self.assertTrue(a.resource_report['resource_exceeded']);self.assertEqual(b.returncode,0);self.assertIn('other-run-ok',b.stdout)
    def test_no_cap_increase(self):
        with self.assertRaises(ValueError):RG.run_capture(['unused'],cwd=ROOT,limit_bytes=RG.MAX_BYTES+1)
    def test_repair_same_session_and_original_stage_replayed(self):
        calls=[]
        def invoke(text,first):
            calls.append((text,first))
            if len(calls)==1:return dict(returncode=137,text='VERDICT: impossible',resource_exceeded=True,wall_s=1)
            if len(calls)==2:return dict(returncode=0,text='RESOURCE-REPAIRED: bounded lemmas',resource_exceeded=False,wall_s=1)
            return dict(returncode=0,text='VERDICT: undecided',resource_exceeded=False,wall_s=1)
        r=RG.recover(invoke,'original stage',True)
        self.assertEqual(calls, [('original stage',True),(RG.REPAIR_PROMPT,False),('original stage',False)])
        self.assertEqual(r['text'],'VERDICT: undecided');self.assertIn('NO game actions',calls[1][0])
    def test_failed_repair_has_no_verdict(self):
        r=RG.recover(lambda t,f:dict(returncode=137,text='VERDICT: impossible',resource_exceeded=True), 'stage',True)
        self.assertEqual(r['text'],'');self.assertTrue(r['resource_blocked'])

class ScopeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='scope-',dir=ROOT/'selftest_out');self.d=Path(self.tmp.name)
        (self.d/'rule').mkdir();(self.d/'analysis').mkdir()
        for n in ('a','b'):(self.d/'rule'/f'{n}.py').write_text('def assert_(*a): return "TRUE"\n',encoding='utf-8')
        (self.d/'transitions.jsonl').write_text('{}\n',encoding='utf-8')
        self.scope=dict(selected_rules=['rule/a.py'],deferred_rules=['rule/b.py'])
        self.audit=dict(rules=[dict(path='rule/a.py',status='proof_dependency',reason='x'*25),dict(path='rule/b.py',status='irrelevant_with_reason',reason='y'*25)],source_sha256=SG.source_hashes(self.d),corpus_sha256=hashlib.sha256((self.d/'transitions.jsonl').read_bytes()).hexdigest())
        self.receipt=dict(source_sha256=self.audit['source_sha256'],corpus_sha256=self.audit['corpus_sha256'],ok=True,compared_to='before.json')
        self.write()
    def write(self):
        for n,v in [('refinement_scope',self.scope),('full_rule_audit',self.audit),('rejection_after',self.receipt)]:
            (self.d/'analysis'/f'{n}.json').write_text(json.dumps(v),encoding='utf-8')
    def tearDown(self):self.tmp.cleanup()
    def test_complete_and_current_passes(self):self.assertTrue(SG.check(self.d)['ok'])
    def test_deferred_rule_change_invalidates_old_proof_audit(self):
        (self.d/'rule/b.py').write_text('# new behavior\n',encoding='utf-8');self.assertFalse(SG.check(self.d)['ok'])
    def test_omission_and_unresolved_fail(self):
        self.audit['rules'][1]['status']='unresolved';self.write();self.assertFalse(SG.check(self.d)['ok'])
        self.audit['rules']=self.audit['rules'][:1];self.write();self.assertFalse(SG.check(self.d)['ok'])

class RejectionTests(unittest.TestCase):
    def test_full_regression_catches_silent_rule_removal(self):
        tool=ROOT/'ARC-AGI/ours/sc25-selfaudit-v7/tools_v7/rejection_check.py'
        with tempfile.TemporaryDirectory(prefix='reject-',dir=ROOT/'selftest_out') as td:
            d=Path(td);(d/'objects').mkdir();(d/'rule/test').mkdir(parents=True)
            (d/'objects/__init__.py').write_text('from dataclasses import dataclass\n@dataclass\nclass World:\n v:int\nclass ParseError(Exception):pass\ndef parse(f):return World(f[0][0])\n',encoding='utf-8')
            rule=d/'rule/test/change.py';rule.write_text('def scope_(p,a,n,c=None): return None\ndef assert_(p,a,n,c=None): return "TRUE" if n[0][0]==p[0][0]+1 else "FALSE"\n',encoding='utf-8')
            (d/'transitions.jsonl').write_text(json.dumps(dict(tid='sample',prev=[[0]],nxt=[[1]],action='ACTION1',ctx={}))+'\n',encoding='utf-8')
            def run(*args):return subprocess.run([sys.executable,'-I',str(tool),*args],cwd=d,capture_output=True,text=True,encoding='utf-8')
            self.assertEqual(run('--out','before.json').returncode,0)
            self.assertEqual(run('--out','after.json','--compare','before.json').returncode,0)
            rule.write_text('def scope_(p,a,n,c=None): return None\ndef assert_(p,a,n,c=None): return "TRUE"\n',encoding='utf-8')
            self.assertEqual(run('--out','bad.json','--compare','before.json').returncode,2)
            note=d/'repair.md';note.write_text('Observed a genuine counterexample; explain what rule was false and how all routes are preserved. '*3,encoding='utf-8')
            self.assertEqual(run('--out','repair.json','--compare','before.json','--repair-note','repair.md').returncode,0)


class ServerCleanupTests(unittest.TestCase):
    def test_owner_mismatch_is_preserved_and_owned_server_is_stopped(self):
        import secrets
        case='l4s-case-'+secrets.token_hex(3)
        owner_file=AK/'srvout'/(case+'.process.json');owner_file.parent.mkdir(exist_ok=True)
        marker=str(ROOT/'selftest_out'/'owned-server-marker')
        log=str(ROOT/'selftest_out'/case)
        proc=subprocess.Popen([sys.executable,'-c','import time;time.sleep(45)',marker,log],creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            owner=dict(case=case,pid=proc.pid,server=marker+'-mismatch',log=log)
            owner_file.write_text(json.dumps(owner),encoding='utf-8')
            cmd=[sys.executable,'-I',str(ROOT/'ARC-AGI/ours/sc25-selfaudit-phase2/harness/stop_server.py'),'--case',case]
            self.assertEqual(subprocess.run(cmd,capture_output=True,timeout=20).returncode,2)
            self.assertIsNone(proc.poll())
            owner['server']=marker;owner_file.write_text(json.dumps(owner),encoding='utf-8')
            self.assertEqual(subprocess.run(cmd,capture_output=True,timeout=20).returncode,0)
            proc.wait(timeout=5);self.assertIsNotNone(proc.returncode)
        finally:
            if proc.poll() is None:proc.terminate();proc.wait(timeout=5)
            owner_file.unlink(missing_ok=True)


class ModelIdentityTests(unittest.TestCase):
    def test_wrong_missing_and_non_json_identity_never_yield_a_verdict(self):
        from types import SimpleNamespace
        from unittest.mock import patch
        import run as driver
        samples=[('VERDICT: impossible',False),
                 (json.dumps(dict(result='VERDICT: impossible')),False),
                 (json.dumps(dict(result='VERDICT: impossible',modelUsage={'claude-opus-5-1':{}})),False),
                 (json.dumps(dict(result='VERDICT: undecided',modelUsage={'claude-opus-5-5':{}})),True)]
        with patch.dict(os.environ,{'AWM_EXPECTED_MODEL':'claude-opus-5-5'}):
            for stdout,valid in samples:
                reply=SimpleNamespace(returncode=0,stdout=stdout,stderr='',resource_report={'resource_exceeded':False})
                with patch.object(driver.RG,'run_capture',return_value=reply):
                    result=driver._drive_once('claude',ROOT,'no real API invocation',True)
                self.assertEqual(result['model_verified'],valid)
                self.assertEqual(result['returncode'],0 if valid else 125)
                if valid:self.assertIn('VERDICT',result['text'])
                else:self.assertEqual(result['text'],'');self.assertTrue(result['unverified_text'])

if __name__=='__main__':
    (ROOT/'selftest_out').mkdir(exist_ok=True)
    unittest.main(verbosity=2)
