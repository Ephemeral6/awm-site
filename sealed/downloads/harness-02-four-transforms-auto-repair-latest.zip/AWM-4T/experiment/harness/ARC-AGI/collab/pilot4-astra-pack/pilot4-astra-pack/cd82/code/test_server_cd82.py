"""server_pilot.py 对 cd82 变体的自测（起真实服务进程，经 HTTP 打）。

    python test_server_cd82.py      → 逐项 PASS/FAIL；退出码 0 = 全过
  T1 沿 solution.json 从一次 /reset 打通 6 关 → 最后一步 state=WIN、game_ended；之后 /action、/reset 都 410
  T2 第 1 关沿解过关，第 2 关送死：连按 99 次无效键（大桶在 0 号位按 1 = 原地不动，仍计步）仍 NOT_FINISHED，
     第 100 次 → GAME_OVER、game_ended；之后 /action、/reset 都 410；服务日志 end 行 end_reason=budget
  T3 开局后再 /reset → state=GAME_OVER、game_ended（end_reason=reset）；之后 410
  T4 输入校验：action 6 缺 x/y、坐标越界 → 400；action 7（不在 available_actions）→ 400；未 reset 先 action → 409
  T5 md5 不符 → 服务拒绝启动（进程非 0 退出）
服务日志写 selftest/（服务侧目录）。
"""
from __future__ import annotations

import hashlib
import json
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERVER = HERE.parent / "server_pilot.py"
VARIANT = HERE / "variant" / "cd82.py"
SOL = json.loads((HERE / "solution.json").read_text(encoding="utf-8"))
LOGDIR = HERE / "selftest"
MD5 = hashlib.md5(VARIANT.read_bytes()).hexdigest()
results = []


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start(md5=MD5, one_life=True):
    port = free_port()
    cmd = [sys.executable, str(SERVER), "--game", "cd82", "--variant-path", str(VARIANT), "--md5", md5,
           "--port", str(port), "--log", str(LOGDIR)] + (["--one-life"] if one_life else [])
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    for _ in range(100):
        if p.poll() is not None:
            return p, port
        try:
            post(port, "/nope", {})
            return p, port
        except Exception:
            time.sleep(0.1)
    return p, port


def post(port, path, body):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def check(name, cond, detail=""):
    results.append(cond)
    print(f"{'PASS' if cond else 'FAIL'} {name} {detail}", flush=True)


def last_log_end():
    files = sorted(LOGDIR.glob("cd82pilot-*.jsonl"), key=lambda p: p.stat().st_mtime)
    recs = [json.loads(l) for l in files[-1].read_text(encoding="utf-8").splitlines()]
    ends = [r for r in recs if r["ep"] == "end"]
    return files[-1].name, (ends[-1]["end_reason"] if ends else None), recs


def t1():
    p, port = start()
    try:
        c, r = post(port, "/reset", {})
        check("T1 reset", c == 200 and r["level"] == 1 and r["state"] == "NOT_FINISHED" and len(r["frames"][-1]) == 64)
        per = []
        for k in range(1, 7):
            for a in SOL["paths"][str(k)]:
                c, r = post(port, "/action", a)
                assert c == 200, (c, r)
            per.append((k, r["level"], r["levels_completed"], r["state"]))
        check("T1 solution plays through", r["state"] == "WIN" and r["levels_completed"] == 6 and r.get("game_ended") is True,
              f"per-level (level_done, level_now, completed, state)={per}")
        c1, _ = post(port, "/action", {"action": 1})
        c2, _ = post(port, "/reset", {})
        check("T1 after WIN: action 410, reset 410", c1 == 410 and c2 == 410, f"{c1} {c2}")
        time.sleep(0.2)
        name, reason, _ = last_log_end()
        check("T1 log end_reason=win", reason == "win", f"{name} {reason}")
    finally:
        p.kill()


def t2():
    p, port = start()
    try:
        post(port, "/reset", {})
        for a in SOL["paths"]["1"]:
            c, r = post(port, "/action", a)
        check("T2 level 1 passed", r["level"] == 2 and r["levels_completed"] == 1, str((r["level"], r["levels_completed"])))
        states = []
        for i in range(99):
            c, r = post(port, "/action", {"action": 1})
            states.append(r["state"])
        check("T2 99 wasted actions still alive", all(s == "NOT_FINISHED" for s in states) and "game_ended" not in r,
              f"last={states[-1]}")
        c, r = post(port, "/action", {"action": 1})
        check("T2 100th action -> GAME_OVER, game_ended", c == 200 and r["state"] == "GAME_OVER" and r.get("game_ended") is True,
              f"code={c} state={r.get('state')} level={r.get('level')}")
        c1, r1 = post(port, "/action", {"action": 1})
        c2, r2 = post(port, "/reset", {})
        c3, _ = post(port, "/action", {"action": 6, "x": 30, "y": 4})
        check("T2 after death: action 410, reset 410, click 410", (c1, c2, c3) == (410, 410, 410), f"{c1} {c2} {c3} {r1}")
        time.sleep(0.2)
        name, reason, recs = last_log_end()
        refused = sum(1 for x in recs if x["ep"] == "refused")
        check("T2 log end_reason=budget, refused lines", reason == "budget" and refused == 3, f"{name} {reason} refused={refused}")
    finally:
        p.kill()


def t3():
    p, port = start()
    try:
        post(port, "/reset", {})
        post(port, "/action", {"action": 4})
        c, r = post(port, "/reset", {})
        check("T3 second reset ends game", c == 200 and r["state"] == "GAME_OVER" and r.get("game_ended") is True)
        c1, _ = post(port, "/action", {"action": 1})
        c2, _ = post(port, "/reset", {})
        check("T3 afterwards 410", (c1, c2) == (410, 410), f"{c1} {c2}")
        time.sleep(0.2)
        _, reason, _ = last_log_end()
        check("T3 log end_reason=reset", reason == "reset", str(reason))
    finally:
        p.kill()


def t4():
    p, port = start()
    try:
        c0, _ = post(port, "/action", {"action": 1})
        post(port, "/reset", {})
        ca, _ = post(port, "/action", {"action": 6})
        cb, _ = post(port, "/action", {"action": 6, "x": 64, "y": 3})
        cc, _ = post(port, "/action", {"action": 7})
        cd, _ = post(port, "/action", {"action": "x"})
        ce, r = post(port, "/action", {"action": 6, "x": 0, "y": 0})
        check("T4 validation", (c0, ca, cb, cc, cd, ce) == (409, 400, 400, 400, 400, 200),
              f"{(c0, ca, cb, cc, cd, ce)}")
    finally:
        p.kill()


def t5():
    p, port = start(md5="0" * 32)
    try:
        rc = p.wait(timeout=30)
        err = p.stderr.read()
        check("T5 wrong md5 refused", rc != 0 and "refuse to serve" in err, f"rc={rc} {err.strip().splitlines()[-1] if err else ''}")
    finally:
        p.kill()


def main():
    print(f"server={SERVER} variant md5={MD5}")
    for t in (t1, t2, t3, t4, t5):
        t()
    ok = all(results)
    print(f"{'ALL PASS' if ok else 'SOME FAIL'} ({sum(results)}/{len(results)})")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
