"""原版参照：用 lib_cd82.solve 在原版 6 关上求模型内精确最短解，翻译成真实动作，
在**官方原版源码**（envs/cd82/fb555c5d/cd82.py，核 md5）上从开局 RESET 连续重放 6 关到 WIN。

    python ref_orig.py            → 打印每关最短步数与动作串，写 ref_orig.json
"""
from __future__ import annotations

import json
import os
import sys

os.environ["ONLY_RESET_LEVELS"] = "true"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib_cd82 as L  # noqa: E402
from arcengine import ActionInput, GameAction, GameState  # noqa: E402


def main():
    mod, md5 = L.load_module(L.ORIG, "cd82_orig")
    assert md5 == L.ORIG_MD5, md5
    data = L.level_data(mod)
    per = []
    for k, d in enumerate(data):
        cost, seq = L.solve(d["target"], [c for _, _, c in d["palettes"]], d["small"])
        g = mod.Cd82()
        g.set_level(k)
        acts = L.to_actions(g, seq)
        assert len(acts) == cost, (k, len(acts), cost)
        per.append({"level": k + 1, "model_min": cost, "strokes": seq, "actions": acts,
                    "palettes": d["palettes"], "small": d["small"]})
        print(f"L{k+1}: model_min={cost} strokes={seq}", flush=True)
    # 连续重放
    g = mod.Cd82()
    f = g.perform_action(ActionInput(id=GameAction.RESET), raw=True)
    for rec in per:
        lv0 = g.level_index
        for i, a in enumerate(rec["actions"]):
            f = g.perform_action(L.action_input(a), raw=True)
            last = i == len(rec["actions"]) - 1
            if not last:
                assert g.level_index == lv0 and f.state == GameState.NOT_FINISHED, (rec["level"], i)
        rec["after"] = {"state": f.state.name, "levels_completed": f.levels_completed, "level_index": g.level_index}
        print(f"  replay L{rec['level']}: {len(rec['actions'])} actions -> state={f.state.name} "
              f"levels_completed={f.levels_completed} :: {' '.join(L.fmt(a) for a in rec['actions'])}", flush=True)
    print(f"FINAL state={f.state.name} levels_completed={f.levels_completed}/{f.win_levels}")
    with open(os.path.join(L.HERE, "ref_orig.json"), "w", encoding="utf-8") as fh:
        json.dump({"source": str(L.ORIG), "md5": md5, "final_state": f.state.name,
                   "levels": [{k: v for k, v in r.items() if k != "strokes"} | {"strokes": [list(s) for s in r["strokes"]]}
                              for r in per]}, fh, indent=1)
    sys.exit(0 if f.state == GameState.WIN else 1)


if __name__ == "__main__":
    main()
