"""导出包自带：在官方 arcengine 上加载变体 cd82.py，逐步重放一串动作，记录每步后的状态。

用法：
    python trace_replay.py solution            # 重放 design/src/solution.json，逐步打印（PLAYBOOK 的核对依据）
    python trace_replay.py srvlog <file.jsonl>  # 重放某槽服务端日志里的动作（只取 ep=action 行）

每步记录：关卡、大杯位置（0 北 1 东北 2 东 3 东南 4 南 5 西南 6 西 7 西北）、当前颜色、
容器与目标图在「去掉两条对角线的 80 格」上的不同格数（mismatch）、本步效果分类。
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

os.environ["ONLY_RESET_LEVELS"] = "true"
import numpy as np  # noqa: E402
from arcengine import ActionInput, GameAction  # noqa: E402

HERE = Path(__file__).resolve().parent
VARIANT = HERE / "variant" / "cd82.py"
VARIANT_MD5 = "37ecc926c5f1e6babbe9b1292b23aff2"
POS = {0: "北", 1: "东北", 2: "东", 3: "东南", 4: "南", 5: "西南", 6: "西", 7: "西北"}
KEYS = {1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3, 4: GameAction.ACTION4,
        5: GameAction.ACTION5}
MASK = np.ones((10, 10), dtype=bool)
for _i in range(10):
    MASK[_i, _i] = False
    MASK[_i, 9 - _i] = False


def load():
    b = VARIANT.read_bytes()
    assert hashlib.md5(b).hexdigest() == VARIANT_MD5
    spec = importlib.util.spec_from_file_location("cd82_export", VARIANT)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def snap(g):
    lv = g.current_level
    canvas = np.array(lv.get_sprites_by_name("xytrjjbyib")[0].pixels, dtype=int)
    tgt = np.array([s for s in lv.get_sprites() if s.name.startswith("eoqnvkspoa-")][0].pixels, dtype=int)
    return {"level": g.level_index + 1, "pos": int(g.xwmfgtlso), "color": int(g.knqmgavuh),
            "canvas": canvas, "mismatch": int((canvas[MASK] != tgt[MASK]).sum())}


def run(actions):
    """actions: [{"action": n} | {"action": 6, "x":, "y":}]，从开局一次 RESET 起。返回逐步记录。"""
    m = load()
    g = m.Cd82()
    f = g.perform_action(ActionInput(id=GameAction.RESET), raw=True)
    cur = snap(g)
    out = []
    for k, a in enumerate(actions, 1):
        before = cur
        hit = None
        if a["action"] == 6:
            gp = g.camera.display_to_grid(a["x"], a["y"])
            sp = g.current_level.get_sprite_at(gp[0], gp[1], ignore_collidable=True) if gp else None
            hit = None if sp is None else ("palette" if sp.name.startswith("pqkenviek")
                                            else "small" if sp.name == "ctwspzkygu" else None)
        if a["action"] == 6:
            ai = ActionInput(id=GameAction.ACTION6, data={"x": a["x"], "y": a["y"]})
        else:
            ai = ActionInput(id=KEYS[a["action"]])
        f = g.perform_action(ai, raw=True)
        st = f.state.name
        cur = snap(g)
        if cur["level"] != before["level"] or st == "WIN":
            eff = "过关"
        elif a["action"] in (1, 2, 3, 4):
            eff = f"移到{POS[cur['pos']]}" if cur["pos"] != before["pos"] else "无效键（不动）"
        elif a["action"] == 5:
            eff = "倒" if not np.array_equal(cur["canvas"], before["canvas"]) else "倒（画布未变）"
        else:
            if cur["color"] != before["color"]:
                eff = f"选色{cur['color']}"
            elif hit == "palette":
                eff = "重选同色（无变化）"
            elif hit == "small":
                eff = "盖章" if not np.array_equal(cur["canvas"], before["canvas"]) else "盖章（画布未变）"
            else:
                eff = "点击落空（无效）"
        lab = f"6@{a['x']},{a['y']}" if a["action"] == 6 else str(a["action"])
        out.append({"k": k, "act": lab, "level_before": before["level"], "level": cur["level"],
                    "pos": POS[cur["pos"]], "color": cur["color"], "mismatch": cur["mismatch"],
                    "effect": eff, "state": st})
        if st in ("WIN", "GAME_OVER"):
            break
    return out


def main():
    if sys.argv[1] == "solution":
        sol = json.loads((HERE.parent / "design" / "src" / "solution.json").read_text(encoding="utf-8"))
        acts = [a for k in sorted(sol["paths"], key=int) for a in sol["paths"][k]]
    else:
        acts = []
        for line in open(sys.argv[2], encoding="utf-8"):
            d = json.loads(line)
            if d.get("ep") == "action":
                acts.append({"action": d["a"], **({"x": d["x"], "y": d["y"]} if d["a"] == 6 else {})})
    for r in run(acts):
        print(f"{r['k']:3d} L{r['level_before']} {r['act']:>8s} -> pos={r['pos']} colour={r['color']:2d} "
              f"mismatch={r['mismatch']:2d} {r['effect']} {r['state']}")


if __name__ == "__main__":
    main()
