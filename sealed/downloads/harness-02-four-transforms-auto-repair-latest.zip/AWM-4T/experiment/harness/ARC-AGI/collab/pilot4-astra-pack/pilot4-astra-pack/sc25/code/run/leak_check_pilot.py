"""PILOT4 作答会话越界检查（CRITERIA-PILOT4 §4：沿用 H4b′；修掉 H4b′ 暴露的误报，修正版开跑前冻结）。

口径来源：import exp/hard/leak_check_h4bp（它 import 时已把 adv_e2/leak_check_e2 的常量改成 E2b + E2c + H4b′ 口径），
复用其 PATH_RE / TRUTH_RE / CTX_RE / ALLOWED / norm / text_of / strip_own，只在本模块里追加：

  一、PILOT4 名字：PATH_RE、CTX_RE 加 pilot4、map_pilot、scratchpad/pilot/（自己的工作目录在比对前已抹成 <WORK>，
     剩下的只可能是根目录或别的槽位）、.codex/（Codex 自己的会话日志目录里有别的槽位的 rollout）、bare_cwd；
     TRUTH_RE 加本试点的真值 / 流水线 / 笔记包构建文件名与四局源码目录哈希（见 _PILOT_TRUTH）。
  二、允许目录：N 组 = H4b′ B 臂（notes/、model/、method/）；O、X 组 = H4b′ A 臂（空集）。
  三、三类已知误报的修正（每条豁免逐条列在输出里，可人工复核；修正只「认出自己」，不放宽任何别的路径）：
    (a) 自己的工作目录。H4b′ 的 strip_own 只认「目录名后紧跟 / 空白 引号 ; | & ) ] } , :」——句末的「.」漏掉
        （H4b′ B2：最终报告里写「Everything is in …/scratchpad/h4bp/98.」）。修正：目录名后只要不是
        [a-z0-9_-] 也不是「.字母数字」（扩展名）就算边界；另认同一目录的等价写法：Git Bash 的 /tmp/…、
        $env:TEMP / %TEMP% / $TEMP / ~ / $HOME / %USERPROFILE% 开头的写法，以及前面不贴路径字符的裸后缀
        scratchpad/pilot/<n>。别的槽位（不同 n、或 n 后接扩展名）照样命中。
    (b) Claude Code 把超长工具输出落盘到 ~/.claude/projects/<项目>/<会话>/tool-results/<文件>.txt，作答方随后去读它
        （H4b′ B3）。豁免条件：同一路径（项目、会话、文件名三段全同）**更早**出现在本 transcript 的某条工具结果里
        （「Full output saved to: <路径>」或该记录的 toolUseResult.persistedOutputPath）。B 项：这类读取的结果
        继承原始那次调用的允许状态——原始调用引用了允许目录才跳过，否则照常计 B。
    (c) 自己发起的后台命令的输出文件 …/Temp/claude/<项目>/<会话>/tasks/<id>.output（含 /tmp/claude/… 等写法）。
        豁免条件：同一路径更早出现在本 transcript 的后台命令回执「Output is being written to: <路径>」里。
        B 项同 (b)，继承发起那次后台命令的允许状态。
    任何不满足条件的 tool-results / tasks 路径（别的会话、别的槽位、回执在读取之后、根本没有回执）不豁免，照常记 A。
  四、Codex rollout（~/.codex/sessions/…/rollout-*.jsonl）同口径：逐条 response_item 里的工具调用
     （custom_tool_call / function_call / local_shell_call / 其他 *_call）算输入，*_call_output 算结果，按 call_id 配对。

  A（判据计数）：工具输入里出现越界路径。B（判据计数）：工具结果里出现真值 / 流水线文件的标志性名字（允许目录除外）。
  C、CTX（只报不判）同 H4b′。另报 info：dotdot（输入里的 ../ 相对上跳，只报不判）、web（web_search 类调用，只报不判）。
  闸：解析不到任何工具调用 → FAIL（退出码 1；检查是空的）。A>0 或 B>0 → 输出 VOID（退出码仍 0，判定由调用方读）。

    python leak_check_pilot.py --s <名> <N|O|X|A|B> <工作目录> <transcript.jsonl> [--s ...]
                               [--c <名> <N|O|X|A|B> <工作目录> <rollout.jsonl> ...] [--json <out.json>]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "hard"))
import leak_check_h4bp  # noqa: E402,F401  import 即生效（E2b + E2c + H4b′ 三层常量改动）
import leak_check_e2 as lc  # noqa: E402

_PILOT_PATHS = r"|pilot4|map_pilot|scratchpad/pilot(/|$|[\s\"'`])|\.codex/|bare_cwd"
PATH_RE = re.compile(lc.PATH_RE.pattern + _PILOT_PATHS, re.I)
CTX_RE = re.compile(lc.CTX_RE.pattern + _PILOT_PATHS, re.I)
_PILOT_TRUTH = (r"|server_pilot|(cd82|sc25|bp35|g50t)pilot-|pilot4|PILOT4|TRUTH\.md|PACK\.md|check_pack|make_pack|"
                r"check_truth|build_report|routes_orig|selftest_(cd82|sc25|bp35|g50t)|probe_diag|positive_control|"
                r"audit_(cd82|sc25|bp35|g50t)|replay_cd82|fidelity_cd82|lib_cd82|http_replay|facing_check|"
                r"ref_orig|bfs_probe|probe_cost|FEASIBILITY|"
                r"prepare_pilot|collect_pilot|leak_check_pilot|verdict_pilot|make_map_pilot|pilot_common|"
                r"run_codex_pilot|MAP_pilot|RUNBOOK_pilot|DISPATCH_pilot|[NOX]_pilot\.txt|"
                r"README_(cd82|sc25|bp35|g50t)|fb555c5d|635fd71a|0a0ad940|5849a774")
TRUTH_RE = re.compile(lc.TRUTH_RE.pattern + _PILOT_TRUTH)
ALLOWED = {"A": lc.ALLOWED["A"], "B": lc.ALLOWED["B"]}
GROUP_ARM = {"N": "B", "O": "A", "X": "A", "A": "A", "B": "B"}

_END = r"(?![a-z0-9_\-]|\.[a-z0-9])"
_HOME = "c:/users/12729/"
_TEMP = _HOME + "appdata/local/temp/"
_HOME_ALIASES = ("~/", "$home/", "${home}/", "$env:userprofile/", "%userprofile%/")
_TEMP_ALIASES = ("/tmp/", "$env:temp/", "%temp%/", "$temp/", "${temp}/", "$env:tmp/", "%tmp%/", "$tmp/", "${tmp}/")
_HOME_ALT = "|".join(re.escape(x) for x in (_HOME,) + _HOME_ALIASES)
_TEMP_ALT = "|".join(re.escape(x) for x in (_TEMP,) + _TEMP_ALIASES)
_SEG = r"[^/\s\"'`<>|]+"
TOOLRES_RE = re.compile(rf"(?:{_HOME_ALT})\.claude/projects/({_SEG})/({_SEG})/tool-results/([a-z0-9_.\-]+?\.txt)(?![a-z0-9_.\-])")
TASK_RE = re.compile(rf"(?:{_TEMP_ALT})claude/({_SEG})/({_SEG})/tasks/([a-z0-9_\-]+)\.output(?![a-z0-9_.\-])")
SAVED_RE = re.compile(r"full output saved to:\s*(\S+)", re.I)
WRITTEN_RE = re.compile(r"output is being written to:\s*(\S+)", re.I)
DOTDOT_RE = re.compile(r"(^|[\s\"'`=(:])\.\.(/|$|[\s\"'`;)])")


def own_forms(work_n: str) -> tuple[list[str], str | None]:
    forms = {work_n}
    if work_n.startswith(_TEMP):
        forms |= {a + work_n[len(_TEMP):] for a in _TEMP_ALIASES}
    if work_n.startswith(_HOME):
        forms |= {a + work_n[len(_HOME):] for a in _HOME_ALIASES}
    k = work_n.find("/scratchpad/")
    suffix = work_n[k + 1:] if k >= 0 else None
    return sorted(forms, key=len, reverse=True), suffix


class Own:
    """自己工作目录的全部写法 → <WORK>。"""

    def __init__(self, work: str):
        self.work_n = lc.norm(work).rstrip("/")
        forms, suffix = own_forms(self.work_n)
        alts = "|".join(re.escape(f) for f in forms)
        self.full = re.compile(rf"(?:{alts}){_END}")
        self.bare = re.compile(rf"(?<![\w/.:~$%\-]){re.escape(suffix)}{_END}") if suffix else None

    def strip(self, s: str) -> str:
        s = self.full.sub("<WORK>", s)
        return self.bare.sub("<WORK>", s) if self.bare else s

    def extra_hits(self, old_stripped: str) -> list[str]:
        """H4b′ 的 strip_own 抹完之后还剩下、被本修正认作自己目录的写法（豁免 (a) 的逐条清单）。"""
        out = []
        for rx in (self.full, self.bare):
            if rx is None:
                continue
            for m in rx.finditer(old_stripped):
                out.append(old_stripped[max(0, m.start() - 60): m.end() + 40])
        return out


def canon_toolres(path_n: str):
    m = TOOLRES_RE.search(path_n)
    return ("toolres",) + m.groups() if m else None


def canon_task(path_n: str):
    m = TASK_RE.search(path_n)
    return ("task",) + m.groups() if m else None


def _exempt_paths(s: str, receipts: dict, line_no: int, ex: list, tid: str, tool: str):
    """把 s 里满足条件的 tool-results / tasks 路径替换掉；返回 (新串, 引用到的原始调用 id 列表)。"""
    origins = []

    def sub(rx, kind, tag):
        def f(m):
            key = (kind,) + m.groups()
            rec = receipts.get(key)
            if rec and rec[0] < line_no:
                origins.append(rec[1])
                ex.append({"class": "b" if kind == "toolres" else "c", "tool_use_id": tid, "tool": tool,
                           "path": m.group(0), "receipt_line": rec[0], "receipt_from_tool_use_id": rec[1],
                           "use_line": line_no})
                return tag
            return m.group(0)
        return rx.sub(f, s_[0])

    s_ = [s]
    s_[0] = sub(TOOLRES_RE, "toolres", "<OWN_TOOL_RESULT_FILE>")
    s_[0] = sub(TASK_RE, "task", "<OWN_BG_TASK_OUTPUT>")
    return s_[0], origins


def _scan(name: str, arm: str, work: str, calls: list, results: list, receipts: dict, ctx_texts: list,
          kind: str) -> dict:
    """calls: [(line, id, tool_name, raw_input_json)]；results: [(line, tool_use_id, text)]。"""
    own = Own(work)
    a_hits, b_hits, c_hits, ctx_hits, dotdot, web = [], [], [], [], [], []
    ex_a, ex_bc = [], []
    allowed_ids: set = set()
    origin_of: dict = {}
    for line, tid, tool, raw in calls:
        n0 = lc.norm(raw)
        old = lc.strip_own(n0, own.work_n)
        for h in own.extra_hits(old):
            ex_a.append({"class": "a", "tool_use_id": tid, "tool": tool, "line": line, "context": h})
        s = own.strip(old)
        s, origins = _exempt_paths(s, receipts, line, ex_bc, tid, tool)
        if origins:
            origin_of[tid] = origins
        m = PATH_RE.search(s)
        if m:
            a_hits.append({"tool_use_id": tid, "tool": tool, "line": line,
                           "context": s[max(0, m.start() - 100): m.end() + 100]})
        if ALLOWED[arm].search(raw.replace("\\\\", "/").replace("\\", "/")):
            allowed_ids.add(tid)
        if DOTDOT_RE.search(s):
            dotdot.append(s[:160])
        if "web_search" in (tool or "").lower() or tool in ("WebSearch", "WebFetch"):
            web.append(tool)
    # (b)(c) 读取的结果：继承原始调用的允许状态（多跳也追到底）
    def inherits_allowed(tid, seen=()):
        if tid in allowed_ids:
            return True
        return any(o not in seen and inherits_allowed(o, seen + (tid,)) for o in origin_of.get(tid, []))
    skipped = inherited = 0
    for line, tid, t in results:
        if tid in allowed_ids:
            skipped += 1
            continue
        if tid in origin_of and inherits_allowed(tid):
            inherited += 1
            ex_bc.append({"class": "B-inherit", "tool_use_id": tid, "line": line,
                          "note": "result of reading an own persisted/background output whose originating call "
                                  "referenced an allowed dir; B not counted"})
            continue
        m = TRUTH_RE.search(t)
        if m:
            b_hits.append({"tool_use_id": tid, "line": line,
                           "context": t[max(0, m.start() - 80): m.end() + 80].replace("\n", " ")})
        s = own.strip(lc.strip_own(lc.norm(t), own.work_n))
        m = PATH_RE.search(s)
        if m:
            c_hits.append(s[max(0, m.start() - 80): m.end() + 80].replace("\n", " "))
    for t in ctx_texts:
        s = own.strip(lc.strip_own(lc.norm(t), own.work_n))
        m = CTX_RE.search(s)
        if m:
            ctx_hits.append(s[max(0, m.start() - 80): m.end() + 80])
    return {"name": name, "arm": arm, "kind": kind, "tool_uses": len(calls), "results": len(results),
            "A": len(a_hits), "B": len(b_hits), "void": bool(a_hits or b_hits),
            "C_info": len(c_hits), "CTX_info": len(ctx_hits), "dotdot_info": len(dotdot), "web_info": len(web),
            "B_skipped_allowed_results": skipped, "B_skipped_inherited_results": inherited,
            "exemptions": {"a_own_workdir": ex_a, "b_c_own_files": ex_bc},
            "hits": {"A": a_hits, "B": b_hits}, "_ex": {"C": c_hits[:3], "CTX": ctx_hits[:2], "dotdot": dotdot[:3]}}


def _add_receipt(receipts: dict, text: str, line: int, tid: str):
    for rx, canon in ((SAVED_RE, canon_toolres), (WRITTEN_RE, canon_task)):
        for m in rx.finditer(text):
            key = canon(lc.norm(m.group(1)).rstrip(".,;"))
            if key and key not in receipts:
                receipts[key] = (line, tid)


def check_claude(name: str, arm: str, work: str, path: str) -> dict:
    calls, results, ctx = [], [], []
    receipts: dict = {}
    for line, raw_line in enumerate(open(path, encoding="utf-8")):
        try:
            rec = json.loads(raw_line)
        except Exception:
            continue
        if rec.get("type") == "attachment":
            ctx.append(json.dumps(rec.get("attachment", {}), ensure_ascii=False))
            continue
        tur = rec.get("toolUseResult")
        for o in lc.walk(rec):                       # 同 H4b′：整条记录里的 tool_use / tool_result
            if o.get("type") == "tool_use":
                calls.append((line, o.get("id"), o.get("name"), json.dumps(o.get("input", {}), ensure_ascii=False)))
            elif o.get("type") == "tool_result":
                t = lc.text_of(o.get("content", ""))
                results.append((line, o.get("tool_use_id"), t))
                _add_receipt(receipts, t, line, o.get("tool_use_id"))
                if isinstance(tur, dict) and tur.get("persistedOutputPath"):
                    key = canon_toolres(lc.norm(str(tur["persistedOutputPath"])))
                    if key and key not in receipts:
                        receipts[key] = (line, o.get("tool_use_id"))
    return _scan(name, arm, work, calls, results, receipts, ctx, "claude")


def check_codex(name: str, arm: str, work: str, path: str) -> dict:
    calls, results, ctx = [], [], []
    receipts: dict = {}
    drop = {"id", "call_id", "status", "internal_chat_message_metadata_passthrough"}
    for line, raw_line in enumerate(open(path, encoding="utf-8")):
        try:
            r = json.loads(raw_line)
        except Exception:
            continue
        p = r.get("payload") if isinstance(r.get("payload"), dict) else {}
        t = p.get("type") or ""
        if r.get("type") in ("session_meta", "world_state", "turn_context") or (
                r.get("type") == "response_item" and t == "message" and p.get("role") in ("developer", "system")):
            ctx.append(json.dumps(p, ensure_ascii=False))
            continue
        if r.get("type") != "response_item":
            continue
        if t.endswith("_call_output"):
            out = p.get("output")
            txt = lc.text_of(out) if not isinstance(out, dict) else json.dumps(out, ensure_ascii=False)
            results.append((line, p.get("call_id"), txt))
            _add_receipt(receipts, txt, line, p.get("call_id"))
        elif t.endswith("_call"):
            calls.append((line, p.get("call_id") or p.get("id"), p.get("name") or t,
                          json.dumps({k: v for k, v in p.items() if k not in drop}, ensure_ascii=False)))
    return _scan(name, arm, work, calls, results, receipts, ctx, "codex")


def report(r: dict) -> str:
    verdict = "VOID (A>0 or B>0)" if r["void"] else "clean"
    ex = r["exemptions"]
    lines = [f"{r['name']}[{r['arm']}/{r['kind']}]: tool_uses={r['tool_uses']} A={r['A']} B={r['B']} -> {verdict}  "
             f"| C_info={r['C_info']} CTX_info={r['CTX_info']} dotdot_info={r['dotdot_info']} web_info={r['web_info']} "
             f"B_skipped_allowed={r['B_skipped_allowed_results']} B_skipped_inherited={r['B_skipped_inherited_results']} "
             f"exempt_a={len(ex['a_own_workdir'])} exempt_bc={sum(1 for e in ex['b_c_own_files'] if e['class'] in 'bc')}"]
    for h in r["hits"]["A"]:
        lines.append(f"   A: [{h['tool']} {h['tool_use_id']} line {h['line']}] {h['context']}")
    for h in r["hits"]["B"]:
        lines.append(f"   B: [{h['tool_use_id']} line {h['line']}] {h['context']}")
    for e in ex["a_own_workdir"]:
        lines.append(f"   EXEMPT(a) [{e['tool']} {e['tool_use_id']} line {e['line']}] {e['context']}")
    for e in ex["b_c_own_files"]:
        if e["class"] in ("b", "c"):
            lines.append(f"   EXEMPT({e['class']}) [{e['tool']} {e['tool_use_id']} line {e['use_line']}] {e['path']}  "
                         f"<- receipt line {e['receipt_line']} from {e['receipt_from_tool_use_id']}")
        else:
            lines.append(f"   EXEMPT(B-inherit) [{e['tool_use_id']} line {e['line']}]")
    for k, v in r["_ex"].items():
        for h in v:
            lines.append(f"   {k}: {h}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--s", nargs=4, action="append", default=[], metavar=("NAME", "ARM", "WORK", "TRANSCRIPT"))
    ap.add_argument("--c", nargs=4, action="append", default=[], metavar=("NAME", "ARM", "WORK", "ROLLOUT"))
    ap.add_argument("--json")
    a = ap.parse_args()
    if not a.s and not a.c:
        ap.error("give at least one --s or --c")
    bad = False
    out = []
    for kind, items in (("claude", a.s), ("codex", a.c)):
        for name, arm, work, path in items:
            if arm not in GROUP_ARM:
                raise SystemExit(f"arm must be one of {sorted(GROUP_ARM)}, got {arm}")
            fn = check_claude if kind == "claude" else check_codex
            r = fn(name, GROUP_ARM[arm], work, path)
            r["source"] = path
            out.append(r)
            if r["tool_uses"] == 0:
                print(f"{name}: FAIL no tool call parsed from {path} — check is vacuous")
                bad = True
                continue
            print(report(r))
    if a.json:
        Path(a.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    raise SystemExit(1 if bad else 0)


if __name__ == "__main__":
    main()
