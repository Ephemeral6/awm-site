"""X 组（裸 Astra）的一个槽位：codex exec，指令从 stdin 文件喂（runs/<slot>/prompt.txt，prepare_pilot.py 写的，一字不加）。
照 exp/demo/run_codex.py 改写（不追加 DEMO_LINE；stdin 直接是文件句柄）。由主会话用 PowerShell Start-Process 脱离启动：

    Start-Process -FilePath python -ArgumentList @('<本文件>', '<slot>') -WindowStyle Hidden `
        -RedirectStandardOutput '<runs>\\<slot>\\runner.out' -RedirectStandardError '<runs>\\<slot>\\runner.err' -PassThru

写 runs/<slot>/：codex_events.jsonl（exec --json 每行 stdout 加本机收到时刻；原行放 "ev"）、codex.err、
codex_manifest.json（完整命令、指令 sha256、起止时刻、**codex 进程的真实退出码**）、结束落 DONE 或 FAILED。
沙箱 workspace-write（只许写工作目录）+ 放开网络（本机游戏服务要用）；-C 工作目录（不继承主会话 cwd）。
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import pilot_common as pc


def iso(t: float) -> str:
    return dt.datetime.fromtimestamp(t, dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slot")
    ap.add_argument("--model", default="gpt-6-astra")
    ap.add_argument("--runs", default=str(pc.DEFAULT_RUNS))
    ap.add_argument("--root", default=str(pc.DEFAULT_ROOT))
    a = ap.parse_args()
    r = pc.map_rows()[a.slot]
    if r["agent"] != "codex":
        raise SystemExit(f"{a.slot} is a {r['agent']} slot, not codex")
    run = Path(a.runs).resolve() / a.slot
    work = Path(a.root) / r["n"]
    pfile = run / "prompt.txt"
    man0 = json.loads((run / "work_manifest.json").read_text(encoding="utf-8"))
    if pc.sha256(pfile) != man0["prompt_sha256"]:
        raise SystemExit("prompt.txt changed since prepare")
    for f in ("DONE", "FAILED", "codex_events.jsonl"):
        if (run / f).exists():
            raise SystemExit(f"{run / f} exists; this slot already ran")
    cmd = ["codex", "exec", "--json", "--skip-git-repo-check", "-m", a.model, "-C", str(work),
           "-s", "workspace-write", "-c", "sandbox_workspace_write.network_access=true", "-"]
    man = {"slot": a.slot, "game": r["game"], "group": r["group"], "work": str(work), "model_requested": a.model,
           "cmd": cmd, "stdin_file": str(pfile), "prompt_sha256": pc.sha256(pfile),
           "server_md5_at_launch": pc.md5(pc.SERVER), "t_start": time.time()}
    man["iso_start"] = iso(man["t_start"])
    (run / "codex_manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    exe = "codex.cmd" if sys.platform == "win32" else "codex"
    with open(pfile, "rb") as fin, open(run / "codex_events.jsonl", "w", encoding="utf-8") as fo, \
            open(run / "codex.err", "w", encoding="utf-8") as fe:
        p = subprocess.Popen([exe] + cmd[1:], stdin=fin, stdout=subprocess.PIPE, stderr=fe,
                             text=True, encoding="utf-8", errors="replace")
        for line in p.stdout:
            t = time.time()
            line = line.rstrip("\n")
            try:
                ev = json.loads(line)
            except Exception:
                ev = {"_raw": line}
            fo.write(json.dumps({"t": t, "iso": iso(t), "ev": ev}, ensure_ascii=False) + "\n")
            fo.flush()
        rc = p.wait()
    man.update({"t_end": time.time(), "exit_code": rc})
    man["iso_end"] = iso(man["t_end"])
    (run / "codex_manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    (run / ("DONE" if rc == 0 else "FAILED")).write_text(str(rc), encoding="utf-8")
    print(f"exit_code={rc}")
    sys.exit(rc)


if __name__ == "__main__":
    main()
