# code/ 文件对照

全部为只读拷贝，源路径相对 `paper/exp/pilot4/`。拷贝后 md5 已核（变体 / 原版 / 服务三件与登记值相同）。

| 本目录 | 源 | 说明 |
|---|---|---|
| `variant/sc25.py` | `sc25/variant/sc25.py` | **变体引擎**，md5 `bcfc8f30a27383c23e35a3858507bdc6`；15 槽服务加载的就是它（`traces/*/result.json` → `variant_md5`） |
| `variant/sc25.diff` | `sc25/variant/sc25.diff` | 原版 → 变体 diff |
| `original/sc25.py` | `envs/sc25/635fd71a/sc25.py` | **原版引擎**（官方 sc25-635fd71a），md5 `2c8d57eda90e81a3582826e4d5444e9d` |
| `original/metadata.json` | `envs/sc25/635fd71a/metadata.json` | 官方元数据（baseline_actions 36/6/32/83/143/50） |
| `build/make_variant.py` | `sc25/make_variant.py` | 确定性生成器：原版 → 变体（只追加墙图、重写 levels 表；断言规则段逐字相同） |
| `build/solve.py` | `sc25/solve.py` | 真实引擎宏动作 BFS，求每关动作数最短解（原版参照与变体同一份） |
| `build/replay.py` | `sc25/replay.py` | 拼 `solution.json`（`--build`）并在真实引擎上连打 6 关、逐关记账 |
| `build/http_replay.py` | `sc25/http_replay.py` | 经 HTTP 一条命服务重放解 |
| `build/render.py` | `sc25/render.py` | 每关开局画面字符画 |
| `build/facing_check.py` | `sc25/facing_check.py` | 开局朝向跨关保留核对 |
| `server_pilot.py` | `server_pilot.py` | 游戏 HTTP 服务（`--one-life`），md5 `39777774a62992aefbd455aeda1aeeda`，与 15 槽 prepare/collect 时记录相同 |
| `run/prepare_pilot.py` | `run/prepare_pilot.py` | 建槽：拷 README（N 组另拷笔记包）、写 prompt.txt / work_manifest.json |
| `run/run_codex_pilot.py` | `run/run_codex_pilot.py` | X 组：`codex exec --json -m gpt-6-astra`，写 codex_events.jsonl |
| `run/collect_pilot.py` | `run/collect_pilot.py` | 从服务日志出读数，写 result.json |
| `run/leak_check_pilot.py` | `run/leak_check_pilot.py` | 泄漏检查 |
| `run/verdict_pilot.py` | `run/verdict_pilot.py` | 判定（终判用的是同族 `verdict_pilot3.py`，未拷；输出见 `run/runs/verdict_final.out`） |
| `run/pilot_common.py` | `run/pilot_common.py` | 共用常量（GAMES 登记、指令核对） |
| `run/MAP_pilot.tsv` | `run/MAP_pilot.tsv` | cd82/sc25 30 槽的槽位—编号—端口表 |
| `run/prompts/{N,O,X}_pilot.txt` | `run/prompts/` | 三组指令模板（O 与 X 逐字节相同）；`AM/AP/NV_pilot.txt` 为同目录其他模板，本实验未用 |

注意：`build/*.py` 内的相对路径按原位置（`pilot4/sc25/`）写，在本目录直接运行需改路径或放回原处。

服务启动命令（TRUTH.md §5）：
`python server_pilot.py --game sc25 --variant-path sc25/variant/sc25.py --md5 bcfc8f30a27383c23e35a3858507bdc6 --one-life --port <p>`
