"""PILOT4 的游戏服务（通用：cd82 / sc25 / bp35 / g50t）。复制改写自 exp/hard/server_hard.py（已冻结，不改）。

    python server_pilot.py --game cd82 --variant-path cd82/variant/cd82.py --md5 <登记的 md5> --one-life --port 8971 --log <服务侧日志目录>

  --game          cd82 | sc25 | bp35 | g50t（决定类名 Cd82 / Sc25 / Bp35 / G50t）
  --variant-path  变体源码；启动时算 md5，与 --md5 不符拒绝服务（变体与登记的那一份逐字节相同才开）
  --one-life      整局只有一条命（同 server_hard.py --one-life）：
                    · 第一次 /reset 开局；此后任何 /reset 都使整局终止（end_reason="reset"）；
                    · 任何 GAME_OVER 使整局终止（end_reason 见 GAME_OVER_REASON；cd82 / sc25 只有预算一种死法 → "budget"；
                      bp35 / g50t 有多种死法，这里不区分，记 "game_over"）；
                    · 打完最后一关 WIN 也终止（end_reason="win"）；
                    · 终止之后 /reset、/action、/declare 一律 410 拒绝，日志记 ep=refused；
                    · 终止那一次请求照常返回（含 frames/state/level/...），另加 "game_ended": true。
                  不加 --one-life：reset 只重开当前关，可无限重开（同 server_hard.py 不加 --one-life）。
接口：POST /reset；POST /action，body {"action": n}，n 取该局 available_actions；n = 6 时另需 "x"、"y"（0–63 的整数，
屏幕坐标）；POST /declare 与 server_hard.py 相同（README 不写它）。
返回 frames（64×64 整数网格的列表）、state、level（1 起）、levels_completed、levels_total。
日志字段同 server_hard.py（i, t, ep, a, level_before, level, state, levels_completed, end_reason；终止时另写 ep=end），
点击另记 x、y。日志写服务侧目录，作答方看不到。
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# 官方引擎的「只重开当前关」语义，与 server_hard.py 相同
os.environ["ONLY_RESET_LEVELS"] = "true"

from arcengine import ActionInput, GameAction, GameState  # noqa: E402

CLASSES = {"cd82": "Cd82", "sc25": "Sc25", "bp35": "Bp35", "g50t": "G50t"}
GAME_OVER_REASON = {"cd82": "budget", "sc25": "budget", "bp35": "game_over", "g50t": "game_over"}
ACTS = {1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3, 4: GameAction.ACTION4,
        5: GameAction.ACTION5, 6: GameAction.ACTION6, 7: GameAction.ACTION7}
ENDED_MSG = "the game has ended (this copy has no retries)"


def load_game(game: str, path: Path, md5_expected: str):
    md5 = hashlib.md5(path.read_bytes()).hexdigest()
    if md5 != md5_expected:
        raise SystemExit(f"{game} source md5 {md5} != registered {md5_expected}; refuse to serve a different game")
    spec = importlib.util.spec_from_file_location(f"g_pilot_{game}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, CLASSES[game]), md5


class World:
    def __init__(self, game: str, path: Path, md5_expected: str, one_life: bool, logdir: Path, port: int):
        self.game = game
        self.cls, md5 = load_game(game, path, md5_expected)
        self.one_life = one_life
        self.g = None
        self.allowed = sorted(self.cls()._available_actions)
        self.last = None
        self.ended: str | None = None
        self.declared: dict[int, dict] = {}
        self.lock = threading.Lock()
        logdir.mkdir(parents=True, exist_ok=True)
        self.log = open(logdir / f"{game}pilot-{time.strftime('%Y%m%d-%H%M%S')}-p{port}.jsonl", "a", encoding="utf-8")
        self.n = 0
        self._log({"ep": "start", "game": game, "one_life": one_life, "src": str(path), "md5": md5, "port": port,
                   "available_actions": self.allowed})

    def _log(self, rec: dict) -> None:
        self.n += 1
        rec = {"i": self.n, "t": time.time(), **rec, "end_reason": self.ended}
        self.log.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.log.flush()

    def _pub(self, f) -> dict:
        out = {
            "frames": [fr.tolist() for fr in f.frame],
            "state": f.state.name,
            "level": self.g.level_index + 1,
            "levels_completed": f.levels_completed,
            "levels_total": f.win_levels,
        }
        self.last = out
        return out

    def _end(self, reason: str) -> None:
        self.ended = reason
        self._log({"ep": "end", "level": self.g.level_index + 1, "state": self.g._state.name,
                   "levels_completed": self.g._score})

    def _refuse(self, ep: str, **kw) -> tuple[int, dict]:
        self._log({"ep": "refused", "request": ep, **kw})
        return 410, {"error": ENDED_MSG, "game_ended": True}

    def reset(self) -> tuple[int, dict]:
        with self.lock:
            if self.ended:
                return self._refuse("reset")
            fresh = self.g is None
            if not fresh and self.one_life:
                self._log({"ep": "reset", "fresh": False, "level": self.g.level_index + 1, "state": self.g._state.name,
                           "levels_completed": self.g._score, "ends_game": True})
                self._end("reset")
                out = dict(self.last or {})
                out.update(state="GAME_OVER", game_ended=True)
                return 200, out
            if fresh:
                self.g = self.cls()
            f = self.g.perform_action(ActionInput(id=GameAction.RESET), raw=True)
            self._log({"ep": "reset", "fresh": fresh, "level": self.g.level_index + 1,
                       "state": f.state.name, "levels_completed": f.levels_completed})
            return 200, self._pub(f)

    def action(self, body: dict) -> tuple[int, dict]:
        with self.lock:
            try:
                a = int(body.get("action"))
            except Exception:
                a = -1
            if self.ended:
                return self._refuse("action", a=a)
            if self.g is None:
                return 409, {"error": "call /reset first"}
            if a not in self.allowed:
                return 400, {"error": f"action must be one of {self.allowed}"}
            data = {}
            if a == 6:
                try:
                    x, y = body.get("x"), body.get("y")
                    if isinstance(x, bool) or isinstance(y, bool) or int(x) != x or int(y) != y:
                        raise ValueError
                    x, y = int(x), int(y)
                    if not (0 <= x <= 63 and 0 <= y <= 63):
                        raise ValueError
                except Exception:
                    return 400, {"error": 'action 6 needs integer "x" and "y" in 0..63'}
                data = {"x": x, "y": y}
            if self.g._state in (GameState.GAME_OVER, GameState.WIN):
                return 409, {"error": f"game is {self.g._state.name}; call /reset"}
            lv0 = self.g.level_index + 1
            f = self.g.perform_action(ActionInput(id=ACTS[a], data=data), raw=True)
            rec = {"ep": "action", "a": a}
            if data:
                rec.update(data)
            rec.update({"level_before": lv0, "level": self.g.level_index + 1,
                        "state": f.state.name, "levels_completed": f.levels_completed})
            self._log(rec)
            out = self._pub(f)
            if self.one_life and f.state in (GameState.GAME_OVER, GameState.WIN):
                self._end("win" if f.state == GameState.WIN else GAME_OVER_REASON[self.game])
                out = dict(out, game_ended=True)
            return 200, out

    def declare(self, body: dict) -> tuple[int, dict]:
        with self.lock:
            if self.ended:
                return self._refuse("declare")
            if self.g is None:
                return 409, {"error": "call /reset first"}
            if body.get("verdict") != "unwinnable":
                return 400, {"error": 'verdict must be "unwinnable" (winnability is shown by winning)'}
            lv = self.g.level_index + 1
            if lv in self.declared:
                self._log({"ep": "declare", "level": lv, "refused": True})
                return 409, {"error": f"level {lv} already has a declaration"}
            note = str(body.get("note", ""))
            self.declared[lv] = {"verdict": "unwinnable", "note": note, "t": time.time()}
            self._log({"ep": "declare", "level": lv, "verdict": "unwinnable", "note": note,
                       "levels_completed": self.g._score})
            return 200, {"recorded": True, "level": lv}


def make_handler(w: World):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj: dict) -> None:
            b = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if not n:
                return {}
            try:
                obj = json.loads(self.rfile.read(n))
                return obj if isinstance(obj, dict) else {}
            except Exception:
                return {}

        def do_GET(self):
            self._send(404, {"error": "use POST /reset, /action"})

        def do_POST(self):
            p = self.path.rstrip("/")
            body = self._body()
            if p == "/reset":
                self._send(*w.reset())
            elif p == "/action":
                self._send(*w.action(body))
            elif p == "/declare":
                self._send(*w.declare(body))
            else:
                self._send(404, {"error": "unknown endpoint"})

    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", required=True, choices=sorted(CLASSES))
    ap.add_argument("--variant-path", required=True)
    ap.add_argument("--md5", required=True, help="registered md5 of the variant source; mismatch -> refuse to serve")
    ap.add_argument("--one-life", action="store_true")
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--log", required=True)
    a = ap.parse_args()
    w = World(a.game, Path(a.variant_path), a.md5, a.one_life, Path(a.log), a.port)
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(w))
    print(f"{a.game} ({'one life' if a.one_life else 'retries'}) on 127.0.0.1:{a.port}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
