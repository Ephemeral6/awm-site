"""抽象模型（lib_cd82）与真实引擎的逐步对拍：在 variant/cd82.py 每关上跑随机动作串，
每一步比较 画布 10×10 全像素、大桶位、当前色、是否过关。用来支撑「模型内最短」这个数字（重放只证可达，不证最短）。

    python fidelity_cd82.py [每关串数=300] [串长=30]
动作池：键 1–5、游戏自带的有效点击（调色板中心 / 小桶中心）、一个随机的无效点击。固定种子。
"""
from __future__ import annotations

import os
import random
import sys
from pathlib import Path

import numpy as np

os.environ["ONLY_RESET_LEVELS"] = "true"
sys.path.insert(0, str(Path(__file__).resolve().parent))
import lib_cd82 as L  # noqa: E402
from arcengine import ActionInput, GameAction  # noqa: E402

KEYS = {1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3, 4: GameAction.ACTION4, 5: GameAction.ACTION5}


def model_move(pos, a):
    r, c = L.RING[pos]
    r2, c2 = {1: (max(0, r - 1), c), 2: (min(2, r + 1), c), 3: (r, max(0, c - 1)), 4: (r, min(2, c + 1))}[a]
    if (r2, c2) == (1, 1):
        return pos
    return L.RING_INV[(r2, c2)]


def main():
    nseq = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    slen = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    vpath = L.HERE / "variant" / "cd82.py"
    mod, md5 = L.load_module(vpath, "cd82_fid")
    data = L.level_data(mod)
    pour = {p: L._pour(p) for p in range(8)}
    strip = {p: L._strip(p) for p in (0, 2, 4, 6)}
    rng = random.Random(20261003)
    total = mism = wins = 0
    for k, d in enumerate(data):
        pal_at = {(x + 2, y + 2): c for x, y, c in d["palettes"]}
        for s in range(nseq):
            g = mod.Cd82()
            g.set_level(k)
            canvas = np.zeros((10, 10), dtype=int)
            pos, col = 0, 15
            for t in range(slen):
                pool = [("k", a) for a in (1, 2, 3, 4, 5)]
                pool += [("c", int(ai.data["x"]), int(ai.data["y"])) for ai in g.yrfgxhebei() + g.bmwcxxvjum()]
                pool.append(("c", rng.randrange(64), rng.randrange(64)))
                act = rng.choice(pool)
                # 模型预测
                painted = False
                if act[0] == "k" and act[1] <= 4:
                    pos = model_move(pos, act[1])
                elif act[0] == "k":
                    canvas[pour[pos]] = col
                    painted = True
                else:
                    x, y = act[1], act[2]
                    hit_pal = [c for (cx, cy), c in pal_at.items() if abs(x - cx) <= 2 and abs(y - cy) <= 2]
                    # 小桶的点击几何（旋转后的 6×5 精灵、透明像素）向引擎查一次「点到的是不是小桶」，只借几何，不借规则
                    top = g.current_level.get_sprite_at(x, y, ignore_collidable=True)
                    if hit_pal:
                        col = hit_pal[0]
                    elif d["small"] and pos in strip and top is not None and top.name == "ctwspzkygu":
                        canvas[strip[pos]] = col
                        painted = True
                pred_win = painted and np.array_equal(canvas[L.MASK], d["target"][L.MASK])
                # 真实引擎
                ai = ActionInput(id=KEYS[act[1]]) if act[0] == "k" else \
                    ActionInput(id=GameAction.ACTION6, data={"x": act[1], "y": act[2]})
                g.perform_action(ai, raw=True)
                total += 1
                real_win = g.level_index != k or g._state.name == "WIN"
                if real_win or pred_win:
                    if real_win != pred_win:
                        mism += 1
                        print(f"MISMATCH win L{k+1} seq{s} t{t} act={act} pred={pred_win} real={real_win}")
                    wins += real_win
                    break
                real = np.array(g.current_level.get_sprites_by_name("xytrjjbyib")[0].pixels, dtype=int)
                if not (np.array_equal(real, canvas) and g.xwmfgtlso == pos and g.knqmgavuh == col):
                    mism += 1
                    print(f"MISMATCH L{k+1} seq{s} t{t} act={act} pos {g.xwmfgtlso}/{pos} col {g.knqmgavuh}/{col}")
                    break
    print(f"variant md5={md5} actions_compared={total} mismatches={mism} level_passes_seen={wins}")
    sys.exit(1 if mism else 0)


if __name__ == "__main__":
    main()
