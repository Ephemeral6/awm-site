"""PILOT4 判定（CRITERIA-PILOT4 §4，照原文机械执行）。读 runs/*/result.json 与 MAP_pilot*.tsv，出单局与汇总判定。

    python verdict_pilot.py [--runs <runs 目录>] [--json <out.json>]

计数口径：
  - 每局每组 5 个 rep（MAP_pilot.tsv）。一个 rep 的读数取「有效」的那一槽：原槽 valid=true 就用原槽；原槽作废
    （leak_void 或 collect 判 valid=false）且 MAP_pilot_rerun*.tsv 里有 replaces=<原槽> 的补跑槽且它 valid=true → 用补跑槽。
    判据：A>0 或 B>0 作废、补跑一次——补跑也作废时这一 rep 记「缺」，不再补（照报，由主会话 / 用户定）。
  - 通关 = result.json 的 primary_win（9/9 式全通：服务日志 ep=end 的 end_reason == win 且 levels_completed == 关数）。
  - 次读数：到达关卡、过关数（每 rep 一个数，照报）。
单局「N 优于对照 C」：N 通关次数 ≥ 3 且 ≥ C 通关次数 + 2。
汇总（对 O、对 X 各判一次）：成立 = 4 局中 ≥ 3 局 N 优于 C 且没有一局 C 通关次数 > N；
                            不成立 = 4 局中 ≥ 2 局 C 通关次数 ≥ N；其余 = 未定。
数据不全（局不到 4 个、或某局某组有效 rep 不到 5）时，只报「暂读」（provisional），不出终判；
另报在现有数据下汇总是否已锁定（无论缺的 rep 结果如何判定都不变）——只在两端都算过时才说锁定。
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import pilot_common as pc


def load_results(runs: Path) -> dict:
    out = {}
    for p in sorted(runs.glob("*/result.json")):
        r = json.loads(p.read_text(encoding="utf-8"))
        out[r["slot"]] = r
    return out


def pick(rows: list[dict], results: dict) -> dict:
    """(game, group, rep) -> {"slot": 用到的槽, "win": bool|None, ...}；None = 缺。"""
    reruns = {}
    for r in rows:
        if r.get("replaces"):
            reruns.setdefault(r["replaces"], []).append(r["slot"])
    main = [r for r in rows if not r.get("replaces")]
    cells = {}
    for r in main:
        key = (r["game"], r["group"], int(r["rep"]))
        chain = [r["slot"]] + reruns.get(r["slot"], [])
        used, notes = None, []
        for s in chain[:2]:                             # 原槽 + 至多一次补跑
            res = results.get(s)
            if res is None:
                notes.append(f"{s}: no result.json (待跑)")
                break
            if res.get("valid"):
                used = res
                break
            notes.append(f"{s}: invalid (leak_void={res.get('leak_void')}, errors={sorted(res.get('errors') or {})})")
        if len(chain) > 2:
            notes.append(f"more than one rerun registered for {r['slot']}: {chain[1:]} — only the first counts")
        cells[key] = {"slot": used["slot"] if used else None, "win": bool(used["primary_win"]) if used else None,
                      "level_reached": used.get("level_reached") if used else None,
                      "levels_completed": used.get("levels_completed") if used else None,
                      "end_reason": used.get("end_reason") if used else None, "notes": notes}
    return cells


def per_game(cells: dict, game: str) -> dict:
    out = {}
    for grp in pc.GROUPS:
        reps = [cells.get((game, grp, k)) for k in range(1, pc.REPS + 1)]
        out[grp] = {"wins": sum(1 for c in reps if c and c["win"]),
                    "valid": sum(1 for c in reps if c and c["win"] is not None),
                    "missing": sum(1 for c in reps if not c or c["win"] is None),
                    "level_reached": [c["level_reached"] if c else None for c in reps],
                    "levels_completed": [c["levels_completed"] if c else None for c in reps],
                    "end_reason": [c["end_reason"] if c else None for c in reps],
                    "slots": [c["slot"] if c else None for c in reps],
                    "notes": [n for c in reps if c for n in c["notes"]]}
    return out


def n_better(nw: int, cw: int) -> bool:
    return nw >= 3 and nw >= cw + 2


def summarize(wins: dict, ctrl: str, games: list[str]) -> str:
    better = sum(1 for g in games if n_better(wins[g]["N"], wins[g][ctrl]))
    ctrl_higher = any(wins[g][ctrl] > wins[g]["N"] for g in games)
    ctrl_ge = sum(1 for g in games if wins[g][ctrl] >= wins[g]["N"])
    if better >= 3 and not ctrl_higher:
        return "成立"
    if ctrl_ge >= 2:
        return "不成立"
    return "未定"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default=str(pc.DEFAULT_RUNS))
    ap.add_argument("--json")
    a = ap.parse_args()
    rows = pc.read_maps()
    results = load_results(Path(a.runs))
    cells = pick(rows, results)
    games = [g for g in pc.GAME_ORDER_ALL if any(r["game"] == g for r in rows)]
    table = {g: per_game(cells, g) for g in games}
    complete = len(games) == len(pc.GAME_ORDER_ALL) and all(
        table[g][grp]["valid"] == pc.REPS for g in games for grp in pc.GROUPS)

    print(f"games in MAP: {games} (criteria needs {list(pc.GAME_ORDER_ALL)}); results found: {len(results)}")
    for g in games:
        t = table[g]
        line = "  ".join(f"{grp} {t[grp]['wins']}/{t[grp]['valid']}" + (f" (缺 {t[grp]['missing']})" if t[grp]['missing'] else "")
                         for grp in pc.GROUPS)
        better = {c: n_better(t["N"]["wins"], t[c]["wins"]) for c in ("O", "X")}
        print(f"[{g}] wins: {line} | N优于O={better['O']} N优于X={better['X']}")
        for grp in pc.GROUPS:
            print(f"    {grp}: level_reached={t[grp]['level_reached']} levels_completed={t[grp]['levels_completed']} "
                  f"end={t[grp]['end_reason']} slots={t[grp]['slots']}")
            for n in t[grp]["notes"]:
                print(f"      note: {n}")

    out = {"games": games, "complete": complete, "table": table, "summary": {}}
    for ctrl in ("O", "X"):
        if complete:
            v = summarize({g: {k: table[g][k]["wins"] for k in pc.GROUPS} for g in games}, ctrl, games)
            out["summary"][ctrl] = {"verdict": v, "final": True}
            print(f"汇总 N vs {ctrl}: {v}（终判）")
            continue
        # 暂读：缺的 rep 取 0 / 1 两端穷举（缺的局整局未知时不穷举，只报暂读）
        miss = [(g, grp) for g in games for grp in pc.GROUPS if table[g][grp]["missing"]]
        absent = len(pc.GAME_ORDER_ALL) - len(games)
        prov = summarize({g: {k: table[g][k]["wins"] for k in pc.GROUPS} for g in games}, ctrl, games)
        locked = None
        if absent == 0 and sum(table[g][grp]["missing"] for g, grp in miss) <= 12:
            outcomes = set()
            slots = [(g, grp) for g, grp in miss for _ in range(table[g][grp]["missing"])]
            for bits in itertools.product((0, 1), repeat=len(slots)):
                w = {g: {k: table[g][k]["wins"] for k in pc.GROUPS} for g in games}
                for (g, grp), b in zip(slots, bits):
                    w[g][grp] += b
                outcomes.add(summarize(w, ctrl, games))
            locked = next(iter(outcomes)) if len(outcomes) == 1 else None
            out["summary"][ctrl] = {"verdict": None, "final": False, "provisional_on_current": prov,
                                    "possible_outcomes": sorted(outcomes), "locked": locked}
        else:
            out["summary"][ctrl] = {"verdict": None, "final": False, "provisional_on_current": prov,
                                    "games_absent": absent, "locked": None}
        print(f"汇总 N vs {ctrl}: 未完成——暂读（按现有有效 rep、缺的不计）= {prov}；"
              f"{'已锁定 = ' + locked if locked else '未锁定'}"
              + (f"；尚缺 {absent} 局（判据 4 局）" if absent else ""))
    if a.json:
        Path(a.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
