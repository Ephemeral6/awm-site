"""cd82 变体生成器（PILOT4 §2）。确定性：固定种子，候选按编号顺序评估，取第一个满足全部条件的。

    python make_variant.py        → variant/cd82.py、levels.json、solution.json、diff.txt

只改布局数据，规则代码一行不动，预算常量（:431 iewrsdwok = 100）不动，关数 6 不变：
  (a) 6 张目标图的像素行（sprites 字典里 "eoqnvkspoa-pqwmeK-1" 的 pixels，原版 :50–150）；
  (b) 关卡表（原版 :257–361）里每关的调色板行（位置、颜色）与当前色标记 ydiwkzjkgl 的位置
      （标记放在 15 号色板下方，与开局当前色 15 一致，同原版）。
  有无小桶：与原版逐关相同（第 1–2 关无，第 3–6 关有）。调色板块数与色集：与原版逐关相同（2 / 3 / 7 / 7 / 7 / 7）。
每关新布局的条件（全部在模型内精确算，再由 replay_cd82.py 在写出的文件上用真实引擎从开局连续重放到 WIN）：
  - 模型内精确最短 m 落在 [LO_k, HI_k]：LO = max(ceil(0.8 r), r - 2)（≥ 判据要求的 0.7 r），HI = r + 3，r = 原版该关模型内精确最短
    （ref_orig.py 求出并在原版上真实重放到 WIN：5 6 16 13 13 16）；m ≤ 99。
  - 最优笔数与原版该关差 ≤ 1；目标图（去对角线）用到的颜色数 ∈ [原版该关, 原版该关 + 1]（不比原版少色）。
  - 「样子不同」：对原版 6 张目标图与已选中的新图，在 8 种旋转/翻转 × 任意颜色一一对应下，
    去对角线后的 80 个像素至少有 MIN_DIFF 个不同（所以既不是平移/换色/旋转的同构复制，也不是只差几个像素）。
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import os
import random
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import lib_cd82 as L  # noqa: E402

SEED = 20261003
OUT = HERE / "variant" / "cd82.py"
REF = [5, 6, 16, 13, 13, 16]          # ref_orig.out：原版各关模型内精确最短，已在原版真实引擎上重放到 WIN
MIN_DIFF = 16                         # 80 个可比像素里至少 16 个（20%）不同
MAX_CAND = 200000
PAL_STEP = 6
PAL_Y = 2


def band(r):
    return max(math.ceil(0.8 * r), r - 2), r + 3


def d4(a):
    out = []
    b = np.asarray(a)
    for k in range(4):
        r = np.rot90(b, k)
        out.append(r)
        out.append(np.fliplr(r))
    return out


def min_disagreement(a, b):
    """a 经 8 种旋转/翻转、颜色经任意一一对应后，与 b 在去对角线 80 像素上的最少不同数。"""
    best = 80
    bm = np.asarray(b)[L.MASK]
    for t in d4(a):
        am = t[L.MASK]
        ca, cb = sorted(set(am.tolist())), sorted(set(bm.tolist()))
        cnt = {(x, y): int(np.sum((am == x) & (bm == y))) for x in ca for y in cb}
        # 最大权一一对应（色数 ≤ 7，暴力即可）
        if len(ca) <= len(cb):
            agree = max(sum(cnt[(x, y)] for x, y in zip(ca, p)) for p in itertools.permutations(cb, len(ca)))
        else:
            agree = max(sum(cnt[(x, y)] for x, y in zip(p, cb)) for p in itertools.permutations(ca, len(cb)))
        best = min(best, 80 - agree)
    return best


def gen_candidate(k, idx, orig):
    rng = random.Random(f"{SEED}-L{k + 1}-{idx}")
    o = orig[k]
    colors = [c for _, _, c in o["palettes"]]
    n = len(colors)
    x0 = rng.randint(19, 63 - 5 - PAL_STEP * (n - 1))
    perm = colors[:]
    rng.shuffle(perm)
    pals = [(x0 + PAL_STEP * i, PAL_Y, perm[i]) for i in range(n)]
    ops = L.ops_for(o["small"])
    n_orig_strokes = o["n_strokes"]
    m = rng.randint(max(1, n_orig_strokes), n_orig_strokes + 2)
    seq = []
    for _ in range(m):
        kind, p, _ = ops[rng.randrange(len(ops))]
        seq.append((kind, p, rng.choice(colors)))
    target = L.render(seq)
    return pals, seq, target


def main():
    mod, md5 = L.load_module(L.ORIG, "cd82_orig")
    assert md5 == L.ORIG_MD5
    orig = L.level_data(mod)
    for k, o in enumerate(orig):
        r, s = L.solve(o["target"], [c for _, _, c in o["palettes"]], o["small"])
        assert r == REF[k], (k, r)
        o["n_strokes"] = len(s)
        o["n_colors"] = len(set(o["target"][L.MASK].tolist()))
    chosen = []
    for k, o in enumerate(orig):
        lo, hi = band(REF[k])
        for idx in range(MAX_CAND):
            pals, gen_seq, target = gen_candidate(k, idx, orig)
            tm = target[L.MASK]
            nc = len(set(tm.tolist()))
            if not (o["n_colors"] <= nc <= o["n_colors"] + 1):
                continue
            cost, seq = L.solve(target, [c for _, _, c in pals], o["small"])
            if cost is None or not (lo <= cost <= hi) or cost > L.BUDGET_USABLE:
                continue
            if abs(len(seq) - o["n_strokes"]) > 1:
                continue
            diffs = [min_disagreement(target, oo["target"]) for oo in orig]
            diffs_new = [min_disagreement(target, c["target"]) for c in chosen]
            if min(diffs + diffs_new) < MIN_DIFF:
                continue
            chosen.append({"level": k + 1, "cand": idx, "palettes": pals, "small": o["small"], "target": target,
                           "gen_strokes": gen_seq, "model_min": cost, "strokes": seq, "ref": REF[k], "band": [lo, hi],
                           "n_colors": nc, "orig_n_colors": o["n_colors"], "orig_n_strokes": o["n_strokes"],
                           "min_diff_vs_orig": diffs, "min_diff_vs_prev_new": diffs_new})
            print(f"L{k+1}: cand={idx} model_min={cost} (ref {REF[k]}, band {lo}-{hi}) strokes={seq} "
                  f"colors={nc} pals={pals} min_diff_vs_orig={diffs} vs_prev_new={diffs_new}", flush=True)
            break
        else:
            raise SystemExit(f"L{k+1}: no candidate within {MAX_CAND}")

    # ------------------------------------------------ 写源码（按锚点改文本，保留 CRLF）
    raw = L.ORIG.read_bytes()
    text = raw.decode("utf-8")
    nl = "\r\n"
    assert nl in text
    new = text
    for c in chosen:
        k = c["level"]
        head = f'    "eoqnvkspoa-pqwme{k}-1": Sprite({nl}        pixels=[{nl}'
        i = new.index(head) + len(head)
        j = new.index(f"        ],{nl}        name=\"eoqnvkspoa-pqwme{k}-1\"", i)
        rows = "".join("            [" + ", ".join(str(int(v)) for v in row) + "]," + nl for row in c["target"])
        assert new[i:j].count(nl) == 10
        new = new[:i] + rows + new[j:]
    for c in chosen:
        k = c["level"]
        a = new.index(f"    # Level {k}{nl}")
        b = new.index(f"    # Level {k + 1}{nl}", a) if k < 6 else new.index(f"]{nl}BACKGROUND_COLOR", a)
        block = new[a:b]
        lines = block.split(nl)
        pal_idx = [i for i, ln in enumerate(lines) if 'sprites["pqkenviek"]' in ln]
        mk_idx = [i for i, ln in enumerate(lines) if 'sprites["ydiwkzjkgl"]' in ln]
        assert pal_idx == list(range(pal_idx[0], pal_idx[0] + len(pal_idx))) and len(pal_idx) == len(c["palettes"])
        assert len(mk_idx) == 1
        new_pal = []
        for x, y, col in c["palettes"]:
            s = f'            sprites["pqkenviek"].clone().set_position({x}, {y})'
            s += "," if col == 0 else f".color_remap(0, {col}),"
            new_pal.append(s)
        x15 = [x for x, _, col in c["palettes"] if col == 15][0]
        lines[pal_idx[0]:pal_idx[-1] + 1] = new_pal
        lines[mk_idx[0]] = f'            sprites["ydiwkzjkgl"].clone().set_position({x15}, 7),'
        new = new[:a] + nl.join(lines) + new[b:]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(new.encode("utf-8"))
    vmd5 = hashlib.md5(OUT.read_bytes()).hexdigest()

    # diff 与改动范围核对：只许落在目标图像素行（原版 :50–150）与关卡表（原版 :257–361）
    a_lines, b_lines = text.split(nl), new.split(nl)
    assert len(a_lines) == len(b_lines), "行数变了"
    changed = [i + 1 for i, (x, y) in enumerate(zip(a_lines, b_lines)) if x != y]
    bad = [n for n in changed if not (50 <= n <= 150 or 257 <= n <= 361)]
    assert not bad, f"改动落在布局数据之外: {bad}"
    assert all(a_lines[i] == b_lines[i] for i in range(361, len(a_lines))), "规则代码被动了"
    # 行数不变、逐行对位比较（difflib 会把相同的像素行错位对齐，读起来像插删）
    diff = ["--- envs/cd82/fb555c5d/cd82.py", "+++ cd82/variant/cd82.py",
            f"# positional line diff: {len(changed)} changed lines, all within :50-150 (target pixels) or :257-361 (level table)"]
    for n in changed:
        diff += [f"@@ line {n} @@", "-" + a_lines[n - 1], "+" + b_lines[n - 1]]
    (HERE / "diff.txt").write_text("\n".join(diff) + "\n", encoding="utf-8")
    print(f"variant md5={vmd5} changed_lines={len(changed)} ranges: target-pixels "
          f"{sum(1 for n in changed if n <= 150)} lines, level-table {sum(1 for n in changed if n >= 257)} lines; "
          f"rules code (:362-{len(a_lines)}) identical; lines {len(a_lines)}", flush=True)

    # ------------------------------------------------ 在写出的文件上把笔序翻译成真实动作
    vmod, vmd5b = L.load_module(OUT, "cd82_variant")
    assert vmd5b == vmd5
    vdata = L.level_data(vmod)
    sol = {}
    for c, vd in zip(chosen, vdata):
        assert np.array_equal(vd["target"], c["target"]) and vd["palettes"] == c["palettes"] and vd["small"] == c["small"]
        g = vmod.Cd82()
        g.set_level(c["level"] - 1)
        acts = L.to_actions(g, c["strokes"])
        assert len(acts) == c["model_min"]
        sol[str(c["level"])] = acts
    levels_json = [{**{k: v for k, v in c.items() if k not in ("target", "gen_strokes", "strokes")},
                    "target": c["target"].tolist(), "gen_strokes": [list(s) for s in c["gen_strokes"]],
                    "strokes": [list(s) for s in c["strokes"]]} for c in chosen]
    (HERE / "levels.json").write_text(json.dumps({"seed": SEED, "variant_md5": vmd5, "levels": levels_json}, indent=1),
                                      encoding="utf-8")
    (HERE / "solution.json").write_text(json.dumps({
        "source_md5": vmd5,
        "budget_usable_per_level": L.BUDGET_USABLE,
        "note": "each level from its start; actions {action:1-5} or {action:6,x,y}; replay with a single RESET at game start",
        "paths": sol,
        "lengths": {k: len(v) for k, v in sol.items()},
    }, indent=1), encoding="utf-8")
    print("lengths", {k: len(v) for k, v in sol.items()})


if __name__ == "__main__":
    main()
