"""cd82 抽象模型 + 精确最短求解 + 真实引擎辅助（make_variant.py / replay_cd82.py / fidelity_cd82.py 共用）。

抽象模型（逐条对应官方源码 envs/cd82/fb555c5d/cd82.py 的行号）：
  - 画布 10×10，开局全 0（:231–247）；过关 = 画布与目标图在去掉两条对角线后逐像素相等（:740–753），
    只在一次涂画（倒大桶 / 点小桶）的动画结束时判（:610、:706）。
  - 大桶在 3×3 环的 8 格上（:393–412），开局在 0 号位（:448）；ACTION1–4 = 行-1 / 行+1 / 列-1 / 列+1，
    不能进中心（:531–549）→ 位与位之间的最少步数 = 环上距离。
  - 当前色开局 15（:449）；点调色板 = 换成该板中心色（:566–572），1 步。
  - ACTION5 倒大桶：0/2/4/6 号位涂上/右/下/左半幅，1/3/5/7 号位涂一个含对角线的三角（:709–738），1 步。
  - 有小桶的关（:459）：大桶在 0/2/4/6 号位时点小桶 = 在对应边涂 3×4 条（:613–628），1 步。
  - 每关可用 99 步（:631–635：计数先 +1，再判 >=100）。
精确最短（模型内）：最优解里每一笔都至少有一个像素留到最后（否则删掉这一笔不增步数），
所以最优解 = 一串「逆向剥层」：从全部像素出发，每次取一笔，它覆盖的未定像素目标色必须一致，剥掉；
剩下的未定像素目标色必须都是 0（开局色）。步数 = Σ（环距离 + 换色与否 + 1）。对（未定集, 最早一笔, 其颜色）做记忆化，精确。
"""
from __future__ import annotations

import hashlib
import importlib.util
from functools import lru_cache
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ORIG = HERE.parent / "envs" / "cd82" / "fb555c5d" / "cd82.py"
ORIG_MD5 = "0d1713f60bfccaf043a8b38c8aeedb92"
BUDGET_USABLE = 99

RING = {0: (0, 1), 1: (0, 2), 2: (1, 2), 3: (2, 2), 4: (2, 1), 5: (2, 0), 6: (1, 0), 7: (0, 0)}
RING_INV = {v: k for k, v in RING.items()}

MASK = np.ones((10, 10), dtype=bool)
for _i in range(10):
    MASK[_i, _i] = False
    MASK[_i, 9 - _i] = False


def _pour(p):
    m = np.zeros((10, 10), dtype=bool)
    if p == 0:
        m[0:5, :] = True
    elif p == 2:
        m[:, 5:10] = True
    elif p == 4:
        m[5:10, :] = True
    elif p == 6:
        m[:, 0:5] = True
    else:
        for i in range(10):
            if p == 1:
                m[i, i:10] = True
            elif p == 3:
                m[i, 9 - i:10] = True
            elif p == 5:
                m[i, 0:i + 1] = True
            elif p == 7:
                m[i, 0:10 - i] = True
    return m


def _strip(p):
    m = np.zeros((10, 10), dtype=bool)
    if p == 0:
        m[0:3, 3:7] = True
    elif p == 4:
        m[7:10, 3:7] = True
    elif p == 6:
        m[3:7, 0:3] = True
    elif p == 2:
        m[3:7, 7:10] = True
    return m


def ops_for(small: bool):
    """(kind, pos, mask)。kind: 'pour' / 'strip'。"""
    ops = [("pour", p, _pour(p)) for p in range(8)]
    if small:
        ops += [("strip", p, _strip(p)) for p in (0, 2, 4, 6)]
    return ops


def ring_dist(a, b):
    d = abs(a - b) % 8
    return min(d, 8 - d)


def render(seq, small=True):
    """seq: [(kind, pos, color)] → 画布（从全 0 开始）。"""
    c = np.zeros((10, 10), dtype=int)
    table = {(k, p): m for k, p, m in ops_for(True)}
    for k, p, col in seq:
        c[table[(k, p)]] = col
    return c


def solve(target, palette_colors, small, start_pos=0, start_color=15):
    """模型内精确最短。返回 (步数, [(kind,pos,color)...]) 或 (None, None)。"""
    target = np.asarray(target)
    ops = ops_for(small)
    pix = [(i, j) for i in range(10) for j in range(10) if MASK[i, j]]
    sig = {}
    for (i, j) in pix:
        s = tuple(bool(m[i, j]) for _, _, m in ops)
        sig.setdefault(s, []).append((i, j))
    atoms = list(sig.values())
    acol = []
    for a in atoms:
        cols = {int(target[i, j]) for i, j in a}
        if len(cols) != 1:
            return None, None  # 同一原子内目标色不一致：模型内不可达
        acol.append(cols.pop())
    n = len(atoms)
    full = (1 << n) - 1
    opmask = []
    for _, _, m in ops:
        b = 0
        for ai, a in enumerate(atoms):
            if m[a[0]]:
                b |= 1 << ai
        opmask.append(b)
    avail = set(palette_colors)

    def can_use(c):
        return c in avail or c == start_color

    def uniform(bits):
        cs = {acol[ai] for ai in range(n) if bits >> ai & 1}
        return cs.pop() if len(cs) == 1 else None

    def trans(pos1, c1, oi, c2):
        return ring_dist(pos1, ops[oi][1]) + (0 if c1 == c2 else 1) + 1

    @lru_cache(maxsize=None)
    def F(U, oi, c):
        """U = 留给前缀去做对的原子；oi,c = 后缀里最早的一笔。返回（前缀代价 + 进入 oi 的代价, 前缀笔序）。"""
        best = (10 ** 9, None)
        if all(acol[ai] == 0 for ai in range(n) if U >> ai & 1):
            if c == start_color or c in avail:
                best = (trans(start_pos, start_color, oi, c), ())
        for oj in range(len(ops)):
            inter = opmask[oj] & U
            if not inter:
                continue
            cj = uniform(inter)
            if cj is None or not can_use(cj):
                continue
            sub, path = F(U & ~opmask[oj], oj, cj)
            if path is None:
                continue
            cost = sub + trans(ops[oj][1], cj, oi, c)
            if cost < best[0]:
                best = (cost, path + ((oj, cj),))
        return best

    best = (10 ** 9, None)
    for oi in range(len(ops)):
        inter = opmask[oi] & full
        ci = uniform(inter)
        if ci is None or not can_use(ci):
            continue
        cost, path = F(full & ~opmask[oi], oi, ci)
        if path is None:
            continue
        if cost < best[0]:
            best = (cost, path + ((oi, ci),))
    if best[1] is None:
        return None, None
    seq = [(ops[oi][0], ops[oi][1], c) for oi, c in best[1]]
    return best[0], seq


# ---------------------------------------------------------------- 真实引擎
def load_module(path, name="cd82_mod"):
    path = Path(path)
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m, hashlib.md5(path.read_bytes()).hexdigest()


def level_data(mod):
    """从模块的 levels 读出每关：目标图、调色板 [(x, y, color)]、有无小桶。"""
    out = []
    for lv in mod.levels:
        sps = lv.get_sprites()
        tgt = [s for s in sps if s.name.startswith("eoqnvkspoa-")][0]
        pals = sorted((s.x, s.y, int(s.pixels[2, 2])) for s in sps if s.name.startswith("pqkenviek"))
        small = any(s.name == "ctwspzkygu" for s in sps)
        out.append({"target": np.array(tgt.pixels, dtype=int), "palettes": pals, "small": small})
    return out


def move_actions(a, b):
    """环上 a→b 的一条最短动作串（ACTION 编号 1–4）。顺时针 / 逆时针取短的，平手取顺时针。"""
    d = (b - a) % 8
    step = 1 if d <= 4 else -1
    acts = []
    cur = a
    while cur != b:
        nxt = (cur + step) % 8
        (r0, c0), (r1, c1) = RING[cur], RING[nxt]
        if r1 == r0 - 1:
            acts.append(1)
        elif r1 == r0 + 1:
            acts.append(2)
        elif c1 == c0 - 1:
            acts.append(3)
        else:
            acts.append(4)
        cur = nxt
    return acts


def to_actions(game, seq, start_pos=0, start_color=15):
    """在真实引擎实例 game（已 set_level 到该关、未动）上，把笔序翻译成真实动作并执行，返回动作列表
    （{"action": n} / {"action": 6, "x":, "y":}）。点击坐标取自游戏自带的枚举 yrfgxhebei / bmwcxxvjum。"""
    from arcengine import ActionInput, GameAction
    A = {1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3, 4: GameAction.ACTION4,
         5: GameAction.ACTION5}
    out = []

    def do(rec):
        if rec["action"] == 6:
            ai = ActionInput(id=GameAction.ACTION6, data={"x": rec["x"], "y": rec["y"]})
        else:
            ai = ActionInput(id=A[rec["action"]])
        game.perform_action(ai, raw=True)
        out.append(rec)

    pos, col = start_pos, start_color
    for kind, p, c in seq:
        for a in move_actions(pos, p):
            do({"action": a})
        pos = p
        assert game.xwmfgtlso == pos, (game.xwmfgtlso, pos)
        if c != col:
            hits = [ai for ai in game.yrfgxhebei()
                    if int(game.current_level.get_sprite_at(ai.data["x"], ai.data["y"], ignore_collidable=True).pixels[2, 2]) == c]
            assert hits, f"no palette with colour {c}"
            do({"action": 6, "x": int(hits[0].data["x"]), "y": int(hits[0].data["y"])})
            col = c
            assert game.knqmgavuh == c
        if kind == "pour":
            do({"action": 5})
        else:
            sb = game.bmwcxxvjum()
            assert len(sb) == 1, "small bucket not clickable here"
            do({"action": 6, "x": int(sb[0].data["x"]), "y": int(sb[0].data["y"])})
    return out


def action_input(rec):
    from arcengine import ActionInput, GameAction
    if rec["action"] == 6:
        return ActionInput(id=GameAction.ACTION6, data={"x": rec["x"], "y": rec["y"]})
    return ActionInput(id={1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3,
                           4: GameAction.ACTION4, 5: GameAction.ACTION5}[rec["action"]])


def fmt(rec):
    return f"6@{rec['x']},{rec['y']}" if rec["action"] == 6 else str(rec["action"])
