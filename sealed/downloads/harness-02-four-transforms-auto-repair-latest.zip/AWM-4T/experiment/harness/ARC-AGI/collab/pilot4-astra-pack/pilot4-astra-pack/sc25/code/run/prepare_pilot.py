"""PILOT4 派发前准备一个槽位（主会话在派发前调用；本脚本不派发任何作答方、不起服务）。判据 paper/CRITERIA-PILOT4.md。

    python prepare_pilot.py <slot，如 cd82-N1> [--root <工作目录根>] [--runs <runs 目录>]
    python prepare_pilot.py --check          # 只核材料 / 指令 / MAP，不建任何东西

核（任一不满足 → 退出码 1，不留半成品）：
  - 三组指令逐字节（pilot_common.check_prompts：O == H4b′ A 臂、X == O、N == O + 空行 + H4b′ B 臂末段 == B_h4bp）；
  - 该局变体 md5、README md5 与 pilot_common.GAMES 登记一致，README 不提 declare / unwinnable；
  - 笔记包三目录非空、packs/<局>/check_truth.out 末行 PACK_CHECK PASS；
  - MAP_pilot*.tsv 结构、中性编号不与 paper/exp 下已用编号 / MAP_bare.tsv 重复、每局每轮 N/O/X 各一；
  - WORK = <root>/<n> 已存在且非空 → 拒绝；runs/<slot>/work_manifest.json 已存在 → 拒绝。
做：
  - 建 WORK：所有组拷该局 README → WORK/README.md；N 组另拷 packs/<局>/{notes,model,method}（不含 __pycache__）；
    拷完逐文件 sha256 与源树核对（多一个、少一个、内容不同都失败）；O / X 组 WORK 里只能有 README.md；
  - 复扫 WORK：该局变体逐关解的字面写法（packs/check_pack.route_forms 口径）不得出现；有命中删 WORK 并失败；
  - 填 {PORT}/{WORK} 写 runs/<slot>/prompt.txt；写 runs/<slot>/work_manifest.json（变体 md5、server_pilot.py md5、
    README md5、指令模板 sha256、包三目录 sha256 树与摘要、WORK 每个文件 sha256、判据 md5）；
  - 打印起服务命令（后台：PowerShell Start-Process 脱离，或 Bash run_in_background 带显式长超时）与指令全文。
注：server_pilot.py 未冻结（bp35 建造者可能还会改它），这里只记 md5；collect 时再核一次，前后不一致会在 result.json 里标出。
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import time
from pathlib import Path

import pilot_common as pc


def scan_work(work: Path, game: str) -> int:
    forms = pc.truth_routes(game)
    hits = 0
    files = sorted(x for x in work.rglob("*") if x.is_file())
    for f in files:
        flat = re.sub(r"\s+", " ", f.read_text(encoding="utf-8", errors="replace"))
        for s in forms:
            if s in flat:
                hits += 1
                print(f"FAIL TRUTHROUTE {f.relative_to(work)}: contains a variant solution route {s[:40]!r}")
    print(f"truth-route scan: {len(files)} files, {len(forms)} route forms, hits = {hits}")
    return hits


def server_cmds(game: str, port: int, run: Path) -> dict:
    cfg = pc.GAMES[game]
    args = [str(pc.SERVER), "--game", game, "--variant-path", str(cfg["variant"]), "--md5", cfg["variant_md5"],
            "--one-life", "--port", str(port), "--log", str(run / "srvlog")]
    ps_args = ", ".join("'" + a.replace("'", "''") + "'" for a in args)
    return {
        "powershell_start_process": (
            f"$p = Start-Process -FilePath python -ArgumentList @({ps_args}) -WindowStyle Hidden -PassThru "
            f"-RedirectStandardOutput '{run / 'server.out'}' -RedirectStandardError '{run / 'server.err'}'; $p.Id"),
        "bash_run_in_background": " ".join(['python'] + [f'"{a}"'.replace("\\", "/") for a in args])
                                  + "    # Bash 工具 run_in_background=true, timeout=7200000（显式上限 2 小时，默认 30 分钟会被杀；"
                                    "会话可能超过 2 小时 → 首选上面的 Start-Process）",
        "probe": f"curl -s -X POST http://127.0.0.1:{port}/nope   # 404 = 在听；不进日志。不要自己调 /reset",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slot", nargs="?")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--root", default=str(pc.DEFAULT_ROOT))
    ap.add_argument("--runs", default=str(pc.DEFAULT_RUNS), help="服务日志与填好的指令放哪（自测时改到临时目录）")
    a = ap.parse_args()
    try:
        pinfo = pc.check_prompts()
        pc.check_map()
        rows = pc.map_rows()
        if a.check:
            games = sorted({r["game"] for r in rows.values()})
            for g in games:
                pc.check_game(g)
                pc.truth_routes(g)
            print(f"CHECK OK: prompts (O==A_h4bp, X==O, N==B_h4bp), MAP ({len(rows)} slots), games {games}")
            return
        if a.slot not in rows:
            pc.die(f"unknown slot {a.slot}; have {sorted(rows)}")
        r = rows[a.slot]
        game, group, n, port = r["game"], r["group"], r["n"], int(r["port"])
        ginfo = pc.check_game(game)
        cfg = pc.GAMES[game]
        work = Path(a.root) / n
        run = Path(a.runs).resolve() / a.slot
        print(f"materials OK: prompts, MAP, {game} variant md5 {ginfo['variant_md5']}, README md5 {ginfo['readme_md5']}, "
              f"pack digests {ginfo['pack_digest']}")
        if work.exists() and any(work.iterdir()):
            pc.die(f"{work} exists and is not empty")
        if (run / "work_manifest.json").exists():
            pc.die(f"{run / 'work_manifest.json'} already exists; this slot was prepared before")

        work.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copyfile(cfg["readme"], work / "README.md")
            if group == "N":
                for d in pc.PACK_DIRS:
                    shutil.copytree(cfg["pack"] / d, work / d, ignore=shutil.ignore_patterns("__pycache__"))
            got = pc.tree(work)
            want = {"README.md": pc.sha256(cfg["readme"])}
            if group == "N":
                for d in pc.PACK_DIRS:
                    want.update({f"{d}/{k}": v for k, v in ginfo["pack_tree"][d].items()})
            if got != want:
                extra = sorted(set(got) - set(want))
                miss = sorted(set(want) - set(got))
                diff = sorted(k for k in set(got) & set(want) if got[k] != want[k])
                pc.die(f"WORK tree != expected (extra {extra[:5]}, missing {miss[:5]}, differ {diff[:5]})")
            if scan_work(work, game):
                pc.die("truth-route scan of the prepared WORK found hits")
        except BaseException:
            shutil.rmtree(work, ignore_errors=True)
            raise

        prompt = pc.fill(pc.PROMPTS[group].read_bytes().decode("utf-8"), port, work)
        run.mkdir(parents=True, exist_ok=True)
        (run / "prompt.txt").write_bytes(prompt.encode("utf-8"))
        man = {"slot": a.slot, "game": game, "group": group, "rep": r["rep"], "agent": r["agent"],
               "model": pc.MODEL[group], "leak_arm": pc.LEAK_ARM[group], "n": n, "port": port, "work": str(work),
               "prepared_at": time.time(), "prepared_iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
               "criteria": pc.CRITERIA.name, "criteria_md5": pc.md5(pc.CRITERIA),
               "variant": str(cfg["variant"]), "variant_md5": ginfo["variant_md5"],
               "server": str(pc.SERVER), "server_md5": pc.md5(pc.SERVER),
               "readme": str(cfg["readme"]), "readme_md5": ginfo["readme_md5"],
               "prompt_template": pc.PROMPTS[group].name, "prompt_template_sha256": pc.sha256(pc.PROMPTS[group]),
               "prompt_sha256": pc.sha256(run / "prompt.txt"), "prompts_check": pinfo,
               "pack": str(cfg["pack"]) if group == "N" else None,
               "pack_digest": ginfo["pack_digest"] if group == "N" else None,
               "pack_sha256": ginfo["pack_tree"] if group == "N" else None,
               "check_truth_out_md5": ginfo["check_truth_out_md5"],
               "files": pc.tree(work)}
        cmds = server_cmds(game, port, run)
        man["server_cmds"] = cmds
        (run / "work_manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    except pc.Fail as e:
        print("FAIL:", e)
        sys.exit(1)

    listing = sorted(p.relative_to(work).as_posix() for p in work.iterdir())
    print(f"slot={a.slot} game={game} group={group} agent={r['agent']} n={n} port={port}")
    print(f"WORK={work}")
    print(f"WORK top level: {listing}  ({len(man['files'])} files)")
    print(f"prompt -> {run / 'prompt.txt'}")
    print(f"manifest -> {run / 'work_manifest.json'}  (variant md5 {man['variant_md5']}, server_pilot.py md5 {man['server_md5']})")
    print("start server — detached (PowerShell):")
    print("  " + cmds["powershell_start_process"])
    print("  or (Bash tool):")
    print("  " + cmds["bash_run_in_background"])
    print("  probe: " + cmds["probe"])
    print("---- prompt ----")
    print(prompt)


if __name__ == "__main__":
    main()
