# code/

| 文件 | 来源 | 作用 |
|---|---|---|
| `variant/cd82.py` | `pilot4/cd82/variant/cd82.py`，md5 `37ecc926c5f1e6babbe9b1292b23aff2` | 变体引擎（作答方实际玩的） |
| `original/cd82.py`、`original/metadata.json` | `pilot4/envs/cd82/fb555c5d/`，md5 `0d1713f60bfccaf043a8b38c8aeedb92` | 原版引擎 |
| `make_variant.py` | `pilot4/cd82/` | 变体生成器（SEED 20261003） |
| `lib_cd82.py` | `pilot4/cd82/` | 抽象模型 + 模型内精确最短求解 + 笔序翻成真实动作 |
| `replay_cd82.py`、`fidelity_cd82.py`、`ref_orig.py`、`test_server_cd82.py` | `pilot4/cd82/` | 参考解重放、模型对拍、原版参照解、服务自测 |
| `server_pilot.py` | `pilot4/server_pilot.py`，md5 `39777774a62992aefbd455aeda1aeeda` | 一条命 HTTP 服务（`--one-life`） |
| `trace_replay.py` | 本包新写 | 在变体引擎上逐步重放一串动作，记录位置/颜色/差格数/效果 |
| `make_actions_md.py` | 本包新写 | 生成 `traces/<slot>/actions.md` 与 `traces/summary.json` |
| `check_full100.py` | 本包新写 | 核对参考解在 100 格（含对角）上也与目标全等 |

依赖：Python 3.13、`arcengine` 0.9.3、numpy；`ONLY_RESET_LEVELS=true`（`design/src/TRUTH.md:5`）。

注意：从原位置拷来的脚本里写死了原工作区的相对路径（如 `lib_cd82.py:26` 的 `HERE.parent / "envs" / …`、`replay_cd82.py:20`），在本包里直接运行需改路径。本包新写的三个脚本只依赖本包内文件：

```
python code/trace_replay.py solution                      # → design/solution_trace.out
python code/trace_replay.py srvlog traces/cd82-X1/srvlog/<file>.jsonl
python code/make_actions_md.py
python code/check_full100.py                              # → design/full100_check.out
```

起服务（原位置）：`python server_pilot.py --game cd82 --variant-path cd82/variant/cd82.py --md5 37ecc926c5f1e6babbe9b1292b23aff2 --one-life --port <p> --log <dir>`（`design/src/TRUTH.md:134`）。
