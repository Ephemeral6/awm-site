"""导出包自带：为 traces/<slot>/ 生成 actions.md（可读时间线）与 traces/summary.json（逐槽统计）。

动作与状态：取 srvlog 里 ep=action 的行，经 trace_replay.run 在变体引擎上重放得到每步后的大杯位置、颜色、
与目标的不同格数（80 格口径）、效果分类。服务端日志自带的 level/state 与重放结果逐步核对，不一致会写进文件头。
X 槽：交错 codex_events.jsonl 的 agent_message / command_execution（命令与输出截断）。
N/O 槽：交错 Claude transcript 的 assistant 文本 / 思考 / 工具调用（截断）。
    python make_actions_md.py
"""
from __future__ import annotations

import datetime as dt
import glob
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from trace_replay import run  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent / "traces"
SHORTEST = {1: 5, 2: 5, 3: 16, 4: 16, 5: 13, 6: 17}


def iso2t(s):
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def cut(s, n):
    s = (s or "").replace("\r", "")
    s = s.replace("\n", " ⏎ ")
    return s if len(s) <= n else s[:n] + f" …（截断，原长 {len(s)} 字符）"


def agent_events(slot_dir, agent):
    ev = []
    if agent == "codex":
        for line in open(slot_dir / "codex_events.jsonl", encoding="utf-8"):
            d = json.loads(line)
            e = d["ev"]
            if e.get("type") != "item.completed":
                continue
            it = e["item"]
            if it["type"] == "agent_message":
                ev.append((d["t"], "Astra 消息", cut(it["text"], 1500)))
            elif it["type"] == "command_execution":
                ev.append((d["t"], "Astra 命令", cut(it["command"], 500) + f"  [exit={it.get('exit_code')}]"
                           + "\n    输出: " + cut(it.get("aggregated_output", ""), 300)))
            elif it["type"] == "reasoning":
                ev.append((d["t"], "Astra 推理摘要", cut(it.get("text", ""), 800)))
    else:
        tr = [p for p in slot_dir.glob("claude_transcript_*.jsonl")]
        if not tr:
            return ev
        for line in open(tr[0], encoding="utf-8"):
            d = json.loads(line)
            if d.get("type") != "assistant":
                continue
            t = iso2t(d["timestamp"])
            for c in d["message"].get("content") or []:
                if c.get("type") == "text" and c["text"].strip():
                    ev.append((t, "Opus 文本", cut(c["text"], 1500)))
                elif c.get("type") == "thinking" and c.get("thinking", "").strip():
                    ev.append((t, "Opus 思考", cut(c["thinking"], 1000)))
                elif c.get("type") == "tool_use":
                    inp = c["input"]
                    if c["name"] == "Bash" or c["name"] == "PowerShell":
                        s = inp.get("command", "")
                    elif c["name"] in ("Write",):
                        s = f"{inp.get('file_path')} :: " + inp.get("content", "")
                    elif c["name"] == "Edit":
                        s = f"{inp.get('file_path')} :: {inp.get('old_string','')} -> {inp.get('new_string','')}"
                    else:
                        s = json.dumps(inp, ensure_ascii=False)
                    ev.append((t, f"Opus 工具 {c['name']}", cut(s, 500)))
    return ev


def main():
    summary = {}
    for slot_dir in sorted(ROOT.glob("cd82-*")):
        slot = slot_dir.name
        res = json.loads((slot_dir / "result.json").read_text(encoding="utf-8"))
        logf = sorted((slot_dir / "srvlog").glob("*.jsonl"))[0]
        recs = [json.loads(l) for l in open(logf, encoding="utf-8")]
        reset_t = [r["t"] for r in recs if r.get("ep") == "reset"][0]
        acts = [r for r in recs if r.get("ep") == "action"]
        seq = [{"action": r["a"], **({"x": r["x"], "y": r["y"]} if r["a"] == 6 else {})} for r in acts]
        rep = run(seq)
        mism = [k for k, (r, s) in enumerate(zip(acts, rep), 1)
                if r["level"] != s["level"] or r["state"] != s["state"]]
        # 逐关统计
        per = {}
        for s in rep:
            p = per.setdefault(s["level_before"], {"actions": 0, "noop_key": 0, "dead_click": 0, "pour": 0,
                                                    "stamp": 0, "recolor": 0, "move": 0, "idle_paint": 0})
            p["actions"] += 1
            e = s["effect"]
            if e.startswith("无效键"):
                p["noop_key"] += 1
            elif e in ("点击落空（无效）", "重选同色（无变化）"):
                p["dead_click"] += 1
            elif e.endswith("（画布未变）"):
                p["idle_paint"] += 1
            elif e.startswith("倒"):
                p["pour"] += 1
            elif e == "盖章":
                p["stamp"] += 1
            elif e.startswith("选色"):
                p["recolor"] += 1
            elif e.startswith("移到"):
                p["move"] += 1
            elif e == "过关":
                a = s["act"]
                if a == "5":
                    p["pour"] += 1
                else:
                    p["stamp"] += 1
        for lv, p in per.items():
            p["shortest"] = SHORTEST[lv]
            p["excess"] = p["actions"] - SHORTEST[lv]
        ev = [(r["t"], "动作", s) for r, s in zip(acts, rep)]
        ev += agent_events(slot_dir, res["agent"])
        ev.sort(key=lambda x: x[0])
        first_t = min(e[0] for e in ev) if ev else reset_t
        g = res["grade"]
        summary[slot] = {"group": res["group"], "rep": res["rep"], "win": res["primary_win"],
                         "levels_completed": res["levels_completed"], "actions": res["actions"],
                         "wall_s": res["wall_s"], "cost_usd_to_end": res["cost_usd_to_end"],
                         "equivalent_input_side_to_end": res["equivalent_input_side_to_end"],
                         "end_reason": res["end_reason"], "per_level": per,
                         "replay_mismatch_steps": mism,
                         "level_seconds": {k: v["seconds"] for k, v in g["levels"].items()},
                         "agent_first_event_to_reset_s": round(reset_t - first_t, 1)}
        L = []
        L.append(f"# {slot} 动作时间线\n")
        L.append(f"组 {res['group']}，第 {res['rep']} 次；agent={res['agent']}；结果 {res['end_reason']}，"
                 f"过关 {res['levels_completed']}/6，动作 {res['actions']}，墙钟 {res['wall_s']} s（判分口径：首个请求到终局，"
                 f"result.json grade）。")
        L.append(f"来源：`srvlog/{logf.name}`（动作、服务端 level/state）；状态列由 `code/trace_replay.py` 在变体引擎上重放同一串动作得到；"
                 f"重放与服务端 level/state 不一致的步：{mism if mism else '无'}。")
        L.append("消息来源：" + ("`codex_events.jsonl`（item.completed）" if res["agent"] == "codex"
                                 else "`claude_transcript_*.jsonl`（assistant 内容块）") + "；长文本截断。")
        L.append("时间：相对 /reset 的秒数（负数 = reset 之前）；绝对时间 UTC。位置：大杯在容器周围 8 个工位之一。"
                 "mismatch = 容器与目标图在去掉两条对角线的 80 格里的不同格数（0 即过关）。\n")
        L.append("## 逐关统计\n")
        L.append("| 关 | 动作 | 最短 | 多用 | 移动 | 无效键 | 选色 | 倒 | 盖章 | 空涂 | 无效点击 | 用时 s |")
        L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for lv in sorted(per):
            p = per[lv]
            sec = g["levels"].get(str(lv), {}).get("seconds", "")
            L.append(f"| {lv} | {p['actions']} | {p['shortest']} | {p['excess']} | {p['move']} | {p['noop_key']} | "
                     f"{p['recolor']} | {p['pour']} | {p['stamp']} | {p['idle_paint']} | {p['dead_click']} | {sec} |")
        L.append("\n## 时间线\n")
        L.append("```")
        for t, kind, x in ev:
            rel = t - reset_t
            ts = dt.datetime.fromtimestamp(t, dt.timezone.utc).strftime("%H:%M:%S")
            if kind == "动作":
                s = x
                L.append(f"[{rel:+7.1f}s {ts}] #{s['k']:3d} L{s['level_before']} 动作 {s['act']:>8s} → 位置={s['pos']} "
                         f"颜色={s['color']} mismatch={s['mismatch']} {s['effect']} {s['state']}")
            else:
                L.append(f"[{rel:+7.1f}s {ts}] 【{kind}】 {x}")
        L.append("```")
        (slot_dir / "actions.md").write_text("\n".join(L) + "\n", encoding="utf-8")
        print(slot, res["actions"], {k: v["excess"] for k, v in per.items()}, "mism", mism)
    (ROOT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
