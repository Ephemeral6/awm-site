"""在真实引擎（官方 arcengine 加载 variant/cd82.py，核 md5）上，从开局一次 RESET 起连续重放 solution.json 的 6 关到 WIN。
不用 lib_cd82 的求解器，只用 solution.json 里的原始动作（键 1–5 / 点击 6@x,y）。

    python replay_cd82.py [variant/cd82.py] [solution.json]   → 打印逐关读数；退出码 0 = 6 关全过且终局 WIN
另打印原版与变体的 6 张目标图（去对角线位置标 '.'），供肉眼比较「样子」。
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

os.environ["ONLY_RESET_LEVELS"] = "true"
from arcengine import ActionInput, GameAction, GameState  # noqa: E402

HERE = Path(__file__).resolve().parent
ORIG = HERE.parent / "envs" / "cd82" / "fb555c5d" / "cd82.py"
KEYS = {1: GameAction.ACTION1, 2: GameAction.ACTION2, 3: GameAction.ACTION3, 4: GameAction.ACTION4, 5: GameAction.ACTION5}
HEX = "0123456789abcdef"


def load(p, name):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def targets(mod):
    out = []
    for lv in mod.levels:
        t = [s for s in lv.get_sprites() if s.name.startswith("eoqnvkspoa-")][0].pixels
        out.append(["".join("." if (j == i or j == 9 - i) else HEX[int(t[i][j])] for j in range(10)) for i in range(10)])
    return out


def main():
    vpath = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "variant" / "cd82.py"
    spath = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / "solution.json"
    sol = json.loads(spath.read_text(encoding="utf-8"))
    md5 = hashlib.md5(vpath.read_bytes()).hexdigest()
    print(f"variant={vpath} md5={md5} solution.source_md5={sol['source_md5']}")
    assert md5 == sol["source_md5"], "solution 与变体不对应"
    mod = load(vpath, "cd82_replay")
    g = mod.Cd82()
    print(f"budget constant iewrsdwok={g.iewrsdwok} (usable per level = {g.iewrsdwok - 1})")
    f = g.perform_action(ActionInput(id=GameAction.RESET), raw=True)
    print(f"RESET -> level={g.level_index + 1} state={f.state.name}")
    ok = True
    nlv = len(mod.levels)
    for k in range(1, nlv + 1):
        path = sol["paths"][str(k)]
        assert g.level_index == k - 1, (g.level_index, k)
        for i, a in enumerate(path):
            if a["action"] == 6:
                ai = ActionInput(id=GameAction.ACTION6, data={"x": a["x"], "y": a["y"]})
            else:
                ai = ActionInput(id=KEYS[a["action"]])
            count_before = g._action_count
            f = g.perform_action(ai, raw=True)
            if i < len(path) - 1 and (g.level_index != k - 1 or f.state != GameState.NOT_FINISHED):
                print(f"  L{k}: FAIL early transition at action {i + 1}: level={g.level_index + 1} state={f.state.name}")
                ok = False
        passed = (g.level_index == k) if k < nlv else (f.state == GameState.WIN)
        within = len(path) <= g.iewrsdwok - 1
        ok = ok and passed and within
        s = " ".join(f"6@{a['x']},{a['y']}" if a["action"] == 6 else str(a["action"]) for a in path)
        print(f"  L{k}: {len(path)} actions (<= 99: {within}) -> passed={passed} state={f.state.name} "
              f"levels_completed={f.levels_completed}/{f.win_levels} :: {s}")
    print(f"FINAL state={f.state.name} levels_completed={f.levels_completed}/{f.win_levels} total_actions="
          f"{sum(len(v) for v in sol['paths'].values())} -> {'PASS' if ok and f.state == GameState.WIN else 'FAIL'}")
    print("\ntargets (diagonals shown as '.'; colours hex):  original | variant")
    to, tv = targets(load(ORIG, "cd82_orig_r")), targets(mod)
    for k in range(nlv):
        print(f"  L{k + 1}")
        for a, b in zip(to[k], tv[k]):
            print(f"    {a}   {b}")
    sys.exit(0 if ok and f.state == GameState.WIN else 1)


if __name__ == "__main__":
    main()
