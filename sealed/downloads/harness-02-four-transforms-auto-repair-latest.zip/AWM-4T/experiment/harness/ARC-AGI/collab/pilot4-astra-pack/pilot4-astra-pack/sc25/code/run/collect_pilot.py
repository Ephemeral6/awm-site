"""PILOT4 跑完后对一个槽位出全部机械读数（CRITERIA-PILOT4 §4）。只读服务侧日志，不采信作答方自述。

    python collect_pilot.py <slot> [<Claude transcript .../subagents/agent-<id>.jsonl | Codex rollout-*.jsonl>]
                            [--runs <runs 目录>] [--root <工作目录根>] [--start <epoch秒|ISO>] [--agent-total <N>]

X 组（Codex）不给第二个参数时：从 runs/<slot>/codex_events.jsonl 的 thread.started.thread_id 到 ~/.codex/sessions 下找
rollout-*-<thread_id>.jsonl（恰好一个才用）。

读数（写 runs/<slot>/result.json，脚本生成，不手改；并打印摘要）：
  主：win = 服务日志 ep=end 那条 end_reason == "win" 且 levels_completed == 该局关数（「9/9 式全通」= 打完最后一关 WIN）。
      判据 PILOT4 没有时间删失，这里不截 2 小时（墙钟照报）。
  次：level_reached（日志里最高 level）、levels_completed（最高）、end_reason（win / budget / game_over / reset；
      无 ep=end → null，game_ended=false）、actions、resets、refused_after_end、declares（README 不写 /declare，照报）、
      wall_s（起点 → ep=end；没有则最后一条记录。起点默认 = 第一条非 start 记录；--start 给派发时刻时用它）、逐关窗口。
  服务核对：日志 ep=start 的 md5 == 登记变体 md5、one_life == true、port == MAP 端口、game == 该局；
      server_pilot.py 当前 md5 与 prepare 时记的是否相同（不同照报 server_md5_changed_since_prepare=true）。
  token：
    Claude：adv_e2/tokens_e2.measure（按 message.id 去重、同 id 取各字段最大；输入侧等效 = in + 1.25·cache_creation
            + 0.1·cache_read）；截至整局结束（ep=end；没有则日志最后一条）与整份 transcript 各报一次；另报 message.model 计数。
    Codex：rollout 里 type=token_usage_record，按 response_id 去重；逐请求按官方价算 $（import demo/codex_rollout_cost.req_cost：
            $10 入 / $1 缓存入 / $12.5 缓存写 / $50 出 每百万；单次输入 > 272K 整次加价）；同样截至结束与整份各一次；
            另报 codex_manifest.json 的真实退出码（run_codex_pilot.py 写）。
  越界：leak_check_pilot（N 组 = H4b′ B 臂口径，O / X = A 臂口径；三类误报的豁免逐条列在 result.json 的 leak.exemptions）；
        leak_void = A>0 或 B>0（判据：作废、补跑一次）。
  材料改动：WORK 与 work_manifest.json 的 files 比，列出 notes/ model/ method/ README.md 的改动（N 组按流程会改 model/，照报）。
各子步骤出错照记进结果；任一出错 → 退出码 1。
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from collections import Counter
from pathlib import Path

import pilot_common as pc

sys.path.insert(0, str(pc.EXP / "adv_e2"))
sys.path.insert(0, str(pc.EXP / "demo"))
from collect_e2b import text_diff  # noqa: E402
from grade_e2 import load  # noqa: E402
from tokens_e2 import measure  # noqa: E402
from codex_rollout_cost import req_cost  # noqa: E402
import leak_check_pilot as leak  # noqa: E402

CODEX_SESSIONS = Path.home() / ".codex" / "sessions"
HARD_ERRORS = {"manifest", "log", "rollout", "grade", "server", "leak"}


def iso(t: float) -> str:
    return dt.datetime.fromtimestamp(t, dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def parse_t(s: str) -> float:
    try:
        return float(s)
    except ValueError:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def level_windows(play: list[dict], t0: float, t_end: float, n_levels: int) -> dict:
    clear = {}
    for r in play:
        if r.get("ep") == "action":
            for k in range(1, (r.get("levels_completed") or 0) + 1):
                clear.setdefault(k, r["t"])
    out, lo = {}, t0
    for k in range(1, n_levels + 1):
        hi = clear.get(k, t_end)
        win = [r for r in play if (lo <= r["t"] if k == 1 else lo < r["t"]) and r["t"] <= hi]
        out[str(k)] = {"clear_t": clear.get(k), "clear_iso": iso(clear[k]) if k in clear else None,
                       "seconds": round(hi - lo, 3), "actions": sum(1 for r in win if r.get("ep") == "action")}
        if k not in clear:
            break
        lo = hi
    return out


def grade(logdir: Path, start: float | None, game: str, port: int) -> dict:
    cfg = pc.GAMES[game]
    recs = load(logdir)                          # 多份 *.jsonl 按时间合并；没有 → SystemExit
    heads = [r for r in recs if r.get("ep") == "start"]
    play = [r for r in recs if r.get("ep") != "start"]
    out = {"logdir": str(logdir), "log_files": len(list(logdir.glob("*.jsonl"))),
           "server_start": [{k: h.get(k) for k in ("game", "one_life", "md5", "port", "src")} for h in heads]}
    problems = []
    if not heads:
        problems.append("no ep=start record")
    for h in heads:
        if h.get("md5") != cfg["variant_md5"]:
            problems.append(f"server md5 {h.get('md5')} != registered {cfg['variant_md5']}")
        if h.get("one_life") is not True:
            problems.append("server not started with --one-life")
        if h.get("port") != port:
            problems.append(f"server port {h.get('port')} != MAP port {port}")
        if h.get("game") != game:
            problems.append(f"server game {h.get('game')} != {game}")
    out["server_problems"] = problems
    if not play:
        return {**out, "error": "no requests logged"}
    t0 = start if start is not None else play[0]["t"]
    ends = [r for r in play if r.get("ep") == "end"]
    end = ends[0] if ends else None
    last = play[-1]
    t_end = end["t"] if end else last["t"]
    lc = [r.get("levels_completed") for r in play if r.get("levels_completed") is not None]
    win = bool(end and end.get("end_reason") == "win" and end.get("levels_completed") == cfg["n_levels"])
    out.update({
        "n_levels": cfg["n_levels"],
        "start_t": t0, "start_iso": iso(t0), "start_source": "--start" if start is not None else "first request in log",
        "game_ended": end is not None, "end_reason": end.get("end_reason") if end else None,
        "end_i": end.get("i") if end else None, "end_t": end["t"] if end else None,
        "end_iso": iso(end["t"]) if end else None,
        "win": win,
        "level_reached": max(r.get("level") or 1 for r in play),
        "levels_completed": max(lc) if lc else 0,
        "actions": sum(1 for r in play if r.get("ep") == "action"),
        "actions_to_end": sum(1 for r in play if r.get("ep") == "action" and r["t"] <= t_end),
        "resets": sum(1 for r in play if r.get("ep") == "reset"),
        "refused_after_end": sum(1 for r in play if r.get("ep") == "refused"),
        "declares": [{"i": r.get("i"), "level": r.get("level"), "refused": bool(r.get("refused")),
                      "note_head": (r.get("note") or "")[:300]} for r in play if r.get("ep") == "declare"],
        "last_record_t": last["t"], "last_record_iso": iso(last["t"]),
        "wall_s": round(t_end - t0, 3),
        "cutoff_t": t_end, "cutoff_rule": "ep=end time" if end else "last record time (no ep=end in log)",
        "levels": level_windows(play, t0, t_end, cfg["n_levels"]),
    })
    return out


def claude_tokens(path: str, cutoff: float | None) -> dict:
    out = {"whole": measure(path, 4.0e9)}               # 4e9 s ≈ 2096 年：整份 transcript（inf 会让 iso() 溢出）
    out["whole"].pop("_diag", None)
    if cutoff is not None:
        m = measure(path, cutoff)
        m.pop("_diag", None)
        out["to_end"] = m
    models = Counter()
    seen = set()
    for raw in open(path, encoding="utf-8"):
        try:
            r = json.loads(raw)
        except Exception:
            continue
        if r.get("type") == "assistant":
            m = r.get("message") or {}
            if m.get("id") and m["id"] not in seen:
                seen.add(m["id"])
                models[m.get("model")] += 1
    out["models_by_message_id"] = dict(models)
    out["equivalent_input_side_to_end"] = out.get("to_end", out["whole"])["equivalent_input_side"]
    return out


def codex_tokens(path: str, cutoff: float | None) -> dict:
    reqs, seen, models = [], set(), Counter()
    for raw in open(path, encoding="utf-8"):
        try:
            r = json.loads(raw)
        except Exception:
            continue
        p = r.get("payload") if isinstance(r.get("payload"), dict) else {}
        if r.get("type") == "turn_context" and p.get("model"):
            models[p["model"]] += 1
        if r.get("type") == "token_usage_record" and p.get("usage") and p.get("response_id") not in seen:
            seen.add(p.get("response_id"))
            reqs.append((parse_t(r["timestamp"]), p["usage"]))
    if not reqs:
        raise SystemExit(f"FAIL: no token_usage_record in {path} — refusing to report 0")

    def agg(rows):
        keys = ("input_tokens", "cached_input_tokens", "cache_write_input_tokens", "output_tokens", "reasoning_output_tokens")
        s = {k: sum(int(u.get(k) or 0) for _, u in rows) for k in keys}
        costs = [req_cost(u) for _, u in rows]
        return {"requests": len(rows), **s, "requests_over_272k": sum(1 for _, l in costs if l),
                "cost_usd": round(sum(c for c, _ in costs), 4)}
    out = {"whole": agg(reqs), "models_turn_context": dict(models),
           "price_source": "developers.openai.com/api/docs/models/gpt-6-astra (read 2026-10-03), via demo/codex_rollout_cost.req_cost"}
    if cutoff is not None:
        out["to_end"] = agg([x for x in reqs if x[0] <= cutoff])
    out["cost_usd_to_end"] = out.get("to_end", out["whole"])["cost_usd"]
    return out


def find_rollout(run: Path) -> str:
    ev = run / "codex_events.jsonl"
    if not ev.is_file():
        raise SystemExit(f"FAIL: no rollout given and no {ev}")
    tid = None
    for line in open(ev, encoding="utf-8"):
        try:
            e = json.loads(line).get("ev") or {}
        except Exception:
            continue
        if e.get("type") == "thread.started":
            tid = e.get("thread_id")
            break
    if not tid:
        raise SystemExit("FAIL: no thread.started in codex_events.jsonl")
    hits = sorted(CODEX_SESSIONS.rglob(f"rollout-*{tid}.jsonl"))
    if len(hits) != 1:
        raise SystemExit(f"FAIL: expected exactly one rollout for thread {tid}, found {len(hits)}")
    return str(hits[0])


def material_diff(work: Path, man: dict, game: str) -> dict:
    if not work.is_dir():
        return {"error": f"WORK {work} does not exist"}
    before, now = man["files"], pc.tree(work)
    cfg = pc.GAMES[game]
    mat = ("notes/", "model/", "method/")
    modified = sorted(k for k in before if k in now and now[k] != before[k])
    removed = sorted(k for k in before if k not in now)
    added = sorted(k for k in now if k not in before and k.startswith(mat))
    other = sorted(k for k in now if k not in before and not k.startswith(mat))
    out = {"files_at_prepare": len(before), "modified": {}, "removed": removed, "added_in_material_dirs": added,
           "other_new_files_count": len(other), "other_new_files_head": other[:40]}
    for k in modified:
        src = cfg["readme"] if k == "README.md" else cfg["pack"] / k
        out["modified"][k] = text_diff(src, work / k) if src.is_file() else {}
    out["summary"] = {d.rstrip("/") + "_touched": any(k.startswith(d) for k in modified + removed + added) for d in mat}
    out["summary"]["readme_touched"] = "README.md" in modified + removed
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slot")
    ap.add_argument("log", nargs="?", help="Claude subagent transcript 或 Codex rollout")
    ap.add_argument("--runs", default=str(pc.DEFAULT_RUNS))
    ap.add_argument("--root", default=str(pc.DEFAULT_ROOT))
    ap.add_argument("--start", default=None)
    ap.add_argument("--agent-total", default=None, help="Agent 工具回报的会话总 token（参考，照报）")
    a = ap.parse_args()
    rows = pc.map_rows()
    if a.slot not in rows:
        print(f"FAIL: unknown slot {a.slot}; have {sorted(rows)}")
        sys.exit(1)
    r = rows[a.slot]
    game, group, port = r["game"], r["group"], int(r["port"])
    run = Path(a.runs).resolve() / a.slot
    work = Path(a.root) / r["n"]
    errors = {}
    man = json.loads((run / "work_manifest.json").read_text(encoding="utf-8"))
    if man["slot"] != a.slot or man["work"] != str(work):
        errors["manifest"] = "work_manifest.json does not match this slot / root"
    log = a.log
    if log is None and r["agent"] == "codex":
        try:
            log = find_rollout(run)
        except SystemExit as e:
            errors["rollout"] = str(e)
    if log is None and "rollout" not in errors:
        errors["log"] = "no transcript / rollout given"

    try:
        g = grade(run / "srvlog", parse_t(a.start) if a.start else None, game, port)
        if "error" in g:
            errors["grade"] = g["error"]
        if g.get("server_problems"):
            errors["server"] = g["server_problems"]
    except SystemExit as e:
        g = {}
        errors["grade"] = str(e)

    tokens = leak_r = None
    codex_run = None
    if log:
        cutoff = g.get("cutoff_t")
        try:
            tokens = codex_tokens(log, cutoff) if r["agent"] == "codex" else claude_tokens(log, cutoff)
        except (SystemExit, Exception) as e:  # noqa: BLE001
            errors["tokens"] = f"{type(e).__name__}: {e}"
        try:
            fn = leak.check_codex if r["agent"] == "codex" else leak.check_claude
            leak_r = fn(a.slot, pc.LEAK_ARM[group], str(work), log)
            if leak_r["tool_uses"] == 0:
                errors["leak"] = "no tool call parsed — leak check vacuous"
        except Exception as e:  # noqa: BLE001
            errors["leak"] = f"{type(e).__name__}: {e}"
    if r["agent"] == "codex":
        cm = run / "codex_manifest.json"
        codex_run = json.loads(cm.read_text(encoding="utf-8")) if cm.is_file() else None
        if codex_run is None:
            errors["codex_manifest"] = "no codex_manifest.json (run_codex_pilot.py writes it)"
        elif codex_run.get("exit_code") not in (0,):
            errors["codex_exit"] = f"codex exit_code = {codex_run.get('exit_code')}"
    mdiff = material_diff(work, man, game)
    if "error" in mdiff:
        errors["material_diff"] = mdiff["error"]
    srv_md5_now = pc.md5(pc.SERVER)
    res = {"slot": a.slot, "game": game, "group": group, "rep": r["rep"], "agent": r["agent"], "n": r["n"],
           "port": port, "work": str(work), "log": log, "criteria": pc.CRITERIA.name,
           "primary_win": g.get("win"), "end_reason": g.get("end_reason"), "level_reached": g.get("level_reached"),
           "levels_completed": g.get("levels_completed"), "n_levels": g.get("n_levels"),
           "actions": g.get("actions"), "wall_s": g.get("wall_s"),
           "equivalent_input_side_to_end": (tokens or {}).get("equivalent_input_side_to_end"),
           "cost_usd_to_end": (tokens or {}).get("cost_usd_to_end"),
           "agent_tool_reported_total_ref": a.agent_total,
           "leak_void": None if leak_r is None else leak_r["void"],
           "leak_A": None if leak_r is None else leak_r["A"], "leak_B": None if leak_r is None else leak_r["B"],
           # valid：本槽读数可进判定 = 越界检查跑通且干净，且服务侧 / 日志 / 清单无错。token、Codex 退出码、材料比对的问题
           # 只记 errors，不改 valid（基础设施中断要不要续跑 / 作废由主会话按判据 §4 定，记 PILOT4-LOG.md）。
           "valid": (leak_r is not None and not leak_r["void"] and not (set(errors) & HARD_ERRORS)),
           "errors": errors,
           "variant_md5": man.get("variant_md5"), "server_md5_at_prepare": man.get("server_md5"),
           "server_md5_at_collect": srv_md5_now,
           "server_md5_changed_since_prepare": srv_md5_now != man.get("server_md5"),
           "grade": g, "tokens": tokens, "codex_run": codex_run, "leak": leak_r, "material_diff": mdiff}
    run.mkdir(parents=True, exist_ok=True)
    (run / "result.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    summary = {k: res[k] for k in ("slot", "game", "group", "primary_win", "end_reason", "level_reached",
                                   "levels_completed", "n_levels", "actions", "wall_s", "equivalent_input_side_to_end",
                                   "cost_usd_to_end", "leak_void", "leak_A", "leak_B", "valid", "errors",
                                   "server_md5_changed_since_prepare")}
    print(json.dumps(summary, ensure_ascii=False, indent=1))
    if leak_r is not None:
        print(leak.report(leak_r))
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
