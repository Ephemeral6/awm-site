"""核对：参考解每关最后一笔之后，容器与目标图在全部 100 格（含两条对角线）上是否也相等。
（笔记包模型的过关判据要求 100 格全等，引擎只比 80 格；见 PILOT4-LOG.md:37。）"""
import json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from trace_replay import load, KEYS  # noqa: E402
import numpy as np  # noqa: E402
from arcengine import ActionInput, GameAction  # noqa: E402

def ai(a):
    return ActionInput(id=GameAction.ACTION6, data={"x": a["x"], "y": a["y"]}) if a["action"] == 6 else ActionInput(id=KEYS[a["action"]])

m = load(); g = m.Cd82(); g.perform_action(ActionInput(id=GameAction.RESET), raw=True)
sol = json.loads((Path(__file__).resolve().parent.parent / "design" / "src" / "solution.json").read_text(encoding="utf-8"))
for k in sorted(sol["paths"], key=int):
    p = sol["paths"][k]
    for a in p[:-1]:
        g.perform_action(ai(a), raw=True)
    lv = g.current_level
    tgt = np.array([s for s in lv.get_sprites() if s.name.startswith("eoqnvkspoa-")][0].pixels)
    can = lv.get_sprites_by_name("xytrjjbyib")[0]
    g.perform_action(ai(p[-1]), raw=True)
    c = np.array(can.pixels)
    print(f"L{k}: 100 格全等={np.array_equal(c, tgt)} 不同格={int((c != tgt).sum())}")
