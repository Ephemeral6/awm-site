"""PILOT4 派发流水线的共用常量与检查（判据 paper/CRITERIA-PILOT4.md，已冻结；本模块不派发、不起服务）。

按局参数化：GAMES[<局>] 写变体、README、笔记包、关数。bp35 / g50t 建成并登记 frozen.txt 后在这里补一行
（变体 md5、README md5、n_levels、solution 路径），prepare 才肯为它们建槽；未补时 prepare 直接拒绝。

本模块提供：
  - check_prompts()：三组指令逐字节核
      O_pilot.txt == exp/hard/prompts/A_h4bp.txt（H4b′ A 臂指令；工作目录里 README 一律叫 README.md，所以「按局换 README 名」
                     落在 prepare 拷哪一份 README，指令正文不变）；
      X_pilot.txt == O_pilot.txt；
      N_pilot.txt == O_pilot.txt + b"\n" + B_h4bp.txt 从「工作目录里的 notes/」起到末尾的原字节，且 == B_h4bp.txt；
      三者都不含 declare / unwinnable / cannot be beaten 以外的差异来源：只允许 {PORT}、{WORK} 两个占位符。
  - check_game(game)：变体 md5、README md5（与 GAMES 登记一致）、README 不提 declare / unwinnable；
  - read_maps() / used_numbers() / check_map()：MAP_pilot.tsv 的结构与编号不重复。
"""
from __future__ import annotations

import csv
import hashlib
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent              # paper/exp/pilot4/run
PILOT = HERE.parent                                 # paper/exp/pilot4
EXP = PILOT.parent                                  # paper/exp
PAPER = EXP.parent
SCRATCH = Path(r"C:\Users\12729\AppData\Local\Temp\claude\E--Desktop-programmatic-world-models"
               r"\974801d8-c599-4481-96a8-2813f38c1c4e\scratchpad")
DEFAULT_ROOT = SCRATCH / "pilot"
DEFAULT_RUNS = HERE / "runs"
BARE_CWD = PAPER.parent / "scratch" / "bare_cwd"
CRITERIA = PAPER / "CRITERIA-PILOT4.md"
SERVER = PILOT / "server_pilot.py"

H4BP_PROMPTS = EXP / "hard" / "prompts"
PROMPTS = {"O": HERE / "prompts" / "O_pilot.txt", "N": HERE / "prompts" / "N_pilot.txt",
           "X": HERE / "prompts" / "X_pilot.txt"}
B_TAIL_START = "工作目录里的 notes/"
FORBIDDEN = re.compile(r"declare|unwinnable|cannot be beaten", re.I)
GROUPS = ("N", "O", "X")
AGENT = {"N": "claude", "O": "claude", "X": "codex"}
MODEL = {"N": "opus (Claude Code subagent)", "O": "opus (Claude Code subagent)", "X": "gpt-6-astra (codex exec)"}
LEAK_ARM = {"N": "B", "O": "A", "X": "A"}            # H4b′ 口径：B 臂允许读 notes/ model/ method/；A 臂允许集为空
REPS = 5
GAME_ORDER_ALL = ("cd82", "sc25", "bp35", "g50t")   # 判据 §1 的四局（verdict 要求全部到齐才出终判）

MAP = HERE / "MAP_pilot.tsv"
PORT_BASE = 9301

GAMES = {
    "cd82": {"variant": PILOT / "cd82" / "variant" / "cd82.py", "variant_md5": "37ecc926c5f1e6babbe9b1292b23aff2",
             "readme": PILOT / "public" / "README_cd82.md", "readme_md5": "6d96e0fb1b6235d0651aa21da12e4260",
             "pack": PILOT / "packs" / "cd82", "solution": PILOT / "cd82" / "solution.json", "n_levels": 6},
    "sc25": {"variant": PILOT / "sc25" / "variant" / "sc25.py", "variant_md5": "bcfc8f30a27383c23e35a3858507bdc6",
             "readme": PILOT / "public" / "README_sc25.md", "readme_md5": "24ee332e3ae6597b0fe0629ba3cd0120",
             "pack": PILOT / "packs" / "sc25", "solution": PILOT / "sc25" / "solution.json", "n_levels": 6},
    # bp35 / g50t：变体建成、审计、登记 frozen.txt 后补齐（None = 未就绪，prepare 拒绝）
    "bp35": {"variant": PILOT / "bp35" / "variant" / "bp35.py", "variant_md5": None,
             "readme": PILOT / "public" / "README_bp35.md", "readme_md5": None,
             "pack": PILOT / "packs" / "bp35", "solution": PILOT / "bp35" / "solution.json", "n_levels": None},
    "g50t": {"variant": PILOT / "g50t" / "variant" / "g50t.py", "variant_md5": None,
             "readme": PILOT / "public" / "README_g50t.md", "readme_md5": None,
             "pack": PILOT / "packs" / "g50t", "solution": PILOT / "g50t" / "solution.json", "n_levels": None},
}
PACK_DIRS = ("notes", "model", "method")

# 中性编号不得重复的来源（扫描时排除本流水线自己的 MAP_pilot*.tsv）
EXTERNAL_MAPS = [Path(r"E:\Desktop\pwm-benchmarks\envs\baselines\llm\MAP_bare.tsv")]


class Fail(Exception):
    pass


def die(msg: str):
    raise Fail(msg)


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def tree(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): sha256(p) for p in sorted(root.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts}


def tree_digest(t: dict) -> str:
    h = hashlib.sha256()
    for k in sorted(t):
        h.update(f"{k}\t{t[k]}\n".encode("utf-8"))
    return h.hexdigest()


# ---------------------------------------------------------------- 指令
def check_prompts() -> dict:
    a = (H4BP_PROMPTS / "A_h4bp.txt").read_bytes()
    b = (H4BP_PROMPTS / "B_h4bp.txt").read_bytes()
    o, n, x = (PROMPTS[g].read_bytes() for g in ("O", "N", "X"))
    if o != a:
        die("O_pilot.txt != exp/hard/prompts/A_h4bp.txt")
    if x != o:
        die("X_pilot.txt != O_pilot.txt")
    k = b.find(B_TAIL_START.encode("utf-8"))
    if k < 0 or b.count(B_TAIL_START.encode("utf-8")) != 1:
        die("B_h4bp.txt: closing paragraph start not found exactly once")
    tail = b[k:]
    if n != o + b"\n" + tail:
        die("N_pilot.txt != O_pilot.txt + blank line + B_h4bp closing paragraph")
    if n != b:
        die("N_pilot.txt != B_h4bp.txt")
    for g, t in (("O", o), ("X", x)):
        s = t.decode("utf-8")
        if FORBIDDEN.search(s):
            die(f"{g}_pilot.txt mentions declare / unwinnable")
    for g, t in (("O", o), ("N", n), ("X", x)):
        if set(re.findall(r"\{[A-Z]+\}", t.decode("utf-8"))) != {"{PORT}", "{WORK}"}:
            die(f"{g}_pilot.txt placeholders are not exactly {{PORT}} and {{WORK}}")
    return {"O_sha256": hashlib.sha256(o).hexdigest(), "N_sha256": hashlib.sha256(n).hexdigest(),
            "X_sha256": hashlib.sha256(x).hexdigest(), "N_tail_bytes": len(tail) + 1,
            "N_tail_note": "N 末段原样保留 H4b′ B 臂第 (4) 步「声明不可解」字样（README 无 declare 文档），照报"}


def fill(template: str, port: int, work: Path) -> str:
    out = template.replace("{PORT}", str(port)).replace("{WORK}", str(work))
    if "{PORT}" in out or "{WORK}" in out:
        die("placeholder left in prompt")
    return out


# ---------------------------------------------------------------- 局
def game_cfg(game: str) -> dict:
    if game not in GAMES:
        die(f"unknown game {game}; have {sorted(GAMES)}")
    cfg = GAMES[game]
    missing = [k for k in ("variant_md5", "readme_md5", "n_levels") if cfg[k] is None]
    if missing:
        die(f"game {game} is not configured yet ({', '.join(missing)} = None in pilot_common.GAMES); "
            "fill them after its variant / README / pack are audited and frozen")
    return cfg


def check_game(game: str) -> dict:
    cfg = game_cfg(game)
    v = md5(cfg["variant"])
    if v != cfg["variant_md5"]:
        die(f"{game} variant md5 {v} != registered {cfg['variant_md5']}")
    r = md5(cfg["readme"])
    if r != cfg["readme_md5"]:
        die(f"{game} README md5 {r} != registered {cfg['readme_md5']}")
    if FORBIDDEN.search(cfg["readme"].read_text(encoding="utf-8")):
        die(f"{cfg['readme'].name} mentions declare / unwinnable / cannot be beaten")
    pack = {}
    for d in PACK_DIRS:
        p = cfg["pack"] / d
        if not p.is_dir():
            die(f"pack dir missing: {p}")
        t = tree(p)
        if not t:
            die(f"pack dir empty: {p}")
        pack[d] = t
    ct = cfg["pack"] / "check_truth.out"
    if not ct.exists() or "PACK_CHECK PASS" not in ct.read_text(encoding="utf-8", errors="replace").splitlines()[-1]:
        die(f"{ct} missing or its last line is not PACK_CHECK PASS (the --truth scan must pass before dispatch)")
    return {"variant_md5": v, "readme_md5": r, "pack_tree": pack,
            "pack_digest": {d: tree_digest(pack[d]) for d in PACK_DIRS},
            "check_truth_out_md5": md5(ct)}


def action_no(x) -> int:
    """解文件里一步动作的各种写法 → 动作号：cd82 是 {"action": n, ...}，sc25 是 "n" 或 "6@x,y"，也接受 [n, x, y] 与 n。
    （check_pack.route_forms 对 dict 元素会直接 str(dict)，得到 "{'action': 3}" 这类写法——那样的 TRUTH 扫描是空的；
    这里先归一成动作号再交给它。）"""
    if isinstance(x, dict):
        return int(x["action"])
    if isinstance(x, (list, tuple)):
        return int(x[0])
    if isinstance(x, str):
        return int(x.split("@", 1)[0])
    return int(x)


def truth_routes(game: str) -> list[str]:
    """变体逐关解的字面写法（同 packs/check_pack.route_forms 口径），用于复扫工作目录。"""
    import json
    import sys
    sys.path.insert(0, str(PILOT / "packs"))
    from check_pack import route_forms  # noqa: E402  已冻结流水线的同一口径
    t = json.loads(game_cfg(game)["solution"].read_text(encoding="utf-8"))
    if isinstance(t.get("paths"), dict):
        routes = list(t["paths"].values())
    elif isinstance(t.get("levels"), list):
        routes = [lv["actions"] for lv in t["levels"]]
    else:
        die(f"{game} solution.json has neither 'paths' nor 'levels'")
    routes = [[action_no(x) for x in rt] for rt in routes]
    forms = route_forms(routes)
    if any("{" in f or "@" in f or "'" in f for f in forms):
        die(f"{game}: route forms still contain non-action characters — normalisation failed")
    if not forms:
        die(f"{game}: no route of length >= 5 found in solution.json — scan would be vacuous")
    return forms


# ---------------------------------------------------------------- MAP
MAP_COLS = ["slot", "game", "group", "rep", "n", "port", "dispatch_order", "agent"]


def read_tsv(p: Path) -> list[dict]:
    with open(p, encoding="utf-8") as f:
        rd = csv.DictReader(f, delimiter="\t")
        first = rd.fieldnames[0]
        return [r for r in rd if (r.get(first) or "").strip() and not r[first].startswith("#")]


def read_maps() -> list[dict]:
    """MAP_pilot.tsv（主表）+ MAP_pilot_rerun*.tsv（补跑，带 replaces / why 列）。"""
    rows = read_tsv(MAP)
    for p in sorted(HERE.glob("MAP_pilot_rerun*.tsv")):
        rows += read_tsv(p)
    return rows


def map_rows() -> dict:
    return {r["slot"]: r for r in read_maps()}


def used_numbers() -> dict:
    """paper/exp 下全部 MAP*.tsv、DISPATCH*.log、SCREEN*.log（本流水线自己的 MAP_pilot* 除外）+ MAP_bare.tsv：
    任一制表符分隔字段恰为两位数字、或任一字段以 \\<两位数字> / /<两位数字> 结尾（工作目录路径）→ 记为已用。宁多勿少。"""
    files = [p for pat in ("MAP*.tsv", "DISPATCH*.log", "SCREEN*.log") for p in EXP.rglob(pat)
             if not p.name.startswith("MAP_pilot")]
    files += [p for p in EXTERNAL_MAPS if p.exists()]
    used: dict[str, list[str]] = {}
    for p in sorted(set(files)):
        for ln in p.read_text(encoding="utf-8", errors="replace").splitlines():
            for fld in ln.split("\t"):
                fld = fld.strip()
                m = re.fullmatch(r"\d{2}", fld) or re.search(r"[\\/](\d{2})$", fld)
                if m:
                    used.setdefault(m.group(1) if m.lastindex else m.group(0), []).append(str(p))
    return used


def check_map(rows: list[dict] | None = None) -> None:
    main = read_tsv(MAP)
    if not main or list(main[0].keys())[:len(MAP_COLS)] != MAP_COLS:
        die(f"MAP_pilot.tsv columns must start with {MAP_COLS}")
    rows = rows if rows is not None else read_maps()
    slots = [r["slot"] for r in rows]
    ns = [r["n"] for r in rows]
    ports = [int(r["port"]) for r in rows]
    if len(set(slots)) != len(slots) or len(set(ns)) != len(ns) or len(set(ports)) != len(ports):
        die("MAP_pilot*: duplicate slot, n or port")
    if any(not re.fullmatch(r"\d{2}", n) for n in ns):
        die("MAP_pilot*: n must be two digits")
    clash = set(ns) & set(used_numbers())
    if clash:
        die(f"MAP_pilot* reuses neutral numbers already used elsewhere: {sorted(clash)}")
    for r in main:
        if r["group"] not in GROUPS or r["agent"] != AGENT[r["group"]]:
            die(f"MAP_pilot.tsv row {r['slot']}: bad group/agent")
        if r["slot"] != f"{r['game']}-{r['group']}{r['rep']}":
            die(f"MAP_pilot.tsv row {r['slot']}: slot name != <game>-<group><rep>")
    orders = sorted(int(r["dispatch_order"]) for r in main)
    if orders != list(range(1, len(main) + 1)):
        die("MAP_pilot.tsv dispatch_order is not 1..N")
    by_game: dict[str, list[dict]] = {}
    for r in main:
        by_game.setdefault(r["game"], []).append(r)
    for g, rs in by_game.items():
        cnt = {grp: sorted(int(r["rep"]) for r in rs if r["group"] == grp) for grp in GROUPS}
        if any(cnt[grp] != list(range(1, REPS + 1)) for grp in GROUPS):
            die(f"MAP_pilot.tsv game {g}: each group must have reps 1..{REPS}")
        rs = sorted(rs, key=lambda r: int(r["dispatch_order"]))
        # 交错：按派发顺序每连续 3 个槽恰好是 N、O、X 各一（轮次内顺序轮转）
        for i in range(0, len(rs), 3):
            if sorted(r["group"] for r in rs[i:i + 3]) != sorted(GROUPS):
                die(f"MAP_pilot.tsv game {g}: dispatch round {i // 3 + 1} is not one each of N/O/X")
            if len({r["rep"] for r in rs[i:i + 3]}) != 1:
                die(f"MAP_pilot.tsv game {g}: dispatch round {i // 3 + 1} mixes reps")
