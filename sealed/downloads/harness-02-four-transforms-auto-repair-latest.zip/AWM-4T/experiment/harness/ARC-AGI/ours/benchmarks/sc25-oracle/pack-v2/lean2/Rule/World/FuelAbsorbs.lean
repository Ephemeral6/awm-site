/-
# fuel_absorbs —— 压到燃料（对应 rule/world/fuel_absorbs.py 的「地面」那一半）

**定义，不是定理。** 这一步结束时我压住了场上一坨燃料的至少一格：整坨记成吃掉（`Render` 把它画成地板）。
竖条净涨那一半**不进模型**（竖条整个不进，理由在 `Obj/Panel/Bar.lean`）。
-/

import Obj.Model.Render

namespace Game

/-- 场上此刻还在的燃料坨：(编号, 格)。开局的第 j 坨记 j，第 i 个抹除框留下的那一坨记 100 + i。 -/
def presentPieces (b : Board) (s : St) : List (Nat × List (Nat × Nat)) :=
  let base := ((List.range b.fuels.length).zip b.fuels).filter fun q => !(s.eaten.contains q.1)
  let caches := ((List.range b.eboxes.length).zip b.eboxes).filterMap fun q =>
    if s.erased.contains q.1 && q.2.cache && !(s.eaten.contains (100 + q.1))
    then some (100 + q.1, cacheCells q.2) else none
  base ++ caches

def eatFuel (b : Board) (s : St) : St :=
  let mine := s.me.cells
  let hit := (presentPieces b s).filter fun q => q.2.any fun p => mine.contains p
  { s with eaten := s.eaten ++ hit.map (·.1) }

end Game
