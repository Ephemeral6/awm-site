# -*- coding: utf-8 -*-
"""Close the watchdog's blind spot for detached lean processes (added 2026-10-21 23:15, while the runs were going).

run_one.py's watchdog only sees lean.exe among its own descendants. A subject that compiles through its Bash tool
(for example `timeout 600 lean X.lean`) leaves a lean whose parent chain no longer reaches run_one.py, so neither
watchdog sees it. At 23:12 such a lean (L5Impossible.lean, 11.6 GB) took the machine to 0.34 GB free and the L4 run's
watchdog killed three of L4's own small leans instead.

Same rule as run_one.py (free RAM < 0.8 GB -> kill the largest lean), applied only when the largest lean on the
machine is detached. Every kill is logged to runs/orphan.watchdog.log with the owner guessed from the file name, and
is reported as a watchdog intervention on that run.

    python -I orphan_watchdog.py       # runs until no run_one.py process is left
"""
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lean_tracker import table, owner  # noqa: E402

LOG = Path(__file__).resolve().parent / "runs" / "orphan.watchdog.log"
MIN_FREE_GB = 1.5   # (10:00) was 0.8; with free RAM < this, the largest lean (attached or not) is killed
DETACHED_CAP_GB = 12.0   # (10:00) was 7: it killed a 7.3 GB proof compile while 10.5 GB were free
ANY_CAP_GB = 12.0       # (2026-10-22 09:55) any lean above this (attached or not) is killed at once: one run's 10 GB compile starved the others   # (2026-10-22 04:25) a detached lean above this is killed at once, before it starves other runs


def free_gb():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory"],
                       capture_output=True, text=True)
    return int(r.stdout.strip() or 0) / 2 ** 20


def arena_of(cmd):
    """Guess the run from the file the lean compiles: the arena whose lean/<file> was modified most recently."""
    toks = [t for t in cmd.replace("\\", "/").split() if t.endswith(".lean")]
    if not toks:
        return "?"
    rel = toks[-1].strip('"')
    best = None
    for a in Path(__import__("os").environ.get("AWM_STAGE", "D:/arc-arena")).iterdir():
        for base in (a / "lean", a):
            f = base / rel
            if f.exists():
                m = f.stat().st_mtime
                if best is None or m > best[0]:
                    best = (m, a.name)
    return best[1] if best else "?"


def main():
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] start (rule: free < {MIN_FREE_GB} GB and the largest lean is detached)\n")
        f.flush()
        while True:
            rows = table()
            if not any("run_one.py" in v[3] for v in rows.values()):
                f.write(f"[{time.strftime('%H:%M:%S')}] stop: no run_one.py left\n")
                return 0
            fg = free_gb()
            for pid, v in rows.items():
                gb = v[2] / 2 ** 30
                if v[1].lower() == "lean.exe" and (gb > ANY_CAP_GB or (gb > DETACHED_CAP_GB and owner(rows, pid) == "unknown")):
                    subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
                    f.write(f"[{time.strftime('%H:%M:%S')}] **看门狗干预（lean 超过上限：脱离进程树 {DETACHED_CAP_GB:.0f} GB / 任何 {ANY_CAP_GB:.0f} GB；归属 {owner(rows, pid)}）**："
                            f"杀 lean pid={pid}（{v[2] / 2 ** 30:.1f} GB，整机可用 {fg:.2f} GB）· {arena_of(v[3])} · {v[3][-80:]}" + chr(10))
                    f.flush()
            if fg < MIN_FREE_GB:
                leans = sorted(((v[2], pid, v) for pid, v in rows.items() if v[1].lower() == "lean.exe"), reverse=True)
                if leans:
                    ws, pid, v = leans[0]
                    if True:   # (10:00) any owner: the largest lean goes first when the machine is short
                        fname = v[3].replace("\\", "/").split("/")[-1]
                        guess = "L4" if "L4" in fname else "L5" if "L5" in fname else "?"
                        subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
                        f.write(f"[{time.strftime('%H:%M:%S')}] **看门狗干预（脱离进程树的 lean，归属 {arena_of(v[3])}）**："
                                f"杀 lean pid={pid}（{ws / 2 ** 30:.1f} GB，整机可用 {fg:.2f} GB）· {v[3][-80:]}\n")
                        f.flush()
            time.sleep(2)


if __name__ == "__main__":
    sys.exit(main())
