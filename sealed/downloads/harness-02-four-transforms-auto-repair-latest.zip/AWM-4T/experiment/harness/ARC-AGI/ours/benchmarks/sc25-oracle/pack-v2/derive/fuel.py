"""这一步被我吃掉的燃料格。**只算量，不下断言。**

被吃掉 = 上一帧场上的一坨燃料（四连通），这一步结束时我压住了它至少一格。
「整坨消失、竖条净涨」是 rule/world/fuel_absorbs.py 的主张。
"""
from __future__ import annotations


def pieces(w):
    """场上的燃料，按四连通分坨。"""
    left = set(w.ground.fuel)
    out = []
    while left:
        s = left.pop()
        comp, stack = {s}, [s]
        while stack:
            r, c = stack.pop()
            for q in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if q in left:
                    left.remove(q)
                    comp.add(q)
                    stack.append(q)
        out.append(frozenset(comp))
    return out


def eaten(w, nw):
    here = nw.me.cells()
    out = set()
    for comp in pieces(w):
        if comp & here:
            out |= comp
    return frozenset(out)
