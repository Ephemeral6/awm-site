"""一个世界会话（开局或换卡）收到的第一条动作被世界吞掉：整帧逐格不变，右边缘竖条也不动。"""
LEVEL = "L7"
SCOPE = "只看 ctx.step 落在 _lib.SESSION_FIRST_STEPS 里的那条转移（每个世界会话的第一步）；没有 ctx 或不在其中返回 NA。" \
        "RESET 之后的第一步不在其中——四次 RESET 之后的第一条动作都没被吞。"
NOTE = "v1 由两处独立读数逼出来：第 1 步的 ACTION1 既没转向也没走，而后面同样被挡住的 ACTION1 会转向；" \
       "且竖条消耗量按 n = step-1 拟合才对得上（见 bar_rate）。v1 的 scope 写的是「本 run 的第 1 步」。" \
       "v2：换终局卡之后的第一条动作（第 251 步 ACTION3，目标整块地板）又被吞了——和第 1 步一模一样，" \
       "而 v1 因为只认 step == 1 在那里闭嘴，让 move_iff_floor 一个人去押「挪窝」、挨了打。" \
       "所以主语从「一个 run 的第一条动作」改成「一个世界会话的第一条动作」：这一格状态帧上和 ctx 里都读不出来" \
       "（第 1、251 步与第 2 步的 prev 帧逐格相同），只能靠装置记的换卡步数（SESSION_FIRST_STEPS）认。" \
       "v2 同时加了 apply：整帧原样——这一步谁也别往前押。"
EVIDENCE = ["86e0735e73235325", "13fcb5b3e3fa0714"]

from _lib import SESSION_FIRST_STEPS


def _fires(ctx):
    return ctx is not None and ctx.get("step") in SESSION_FIRST_STEPS


def assert_(prev, action, nxt, ctx=None):
    if not _fires(ctx):
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"


def apply(prev, action, ctx=None):
    if not _fires(ctx):
        return None
    return {(r, c): prev[r][c] for r in range(len(prev)) for c in range(len(prev[0]))}
