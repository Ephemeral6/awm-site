# -*- coding: utf-8 -*-
"""多轮跑受试：打一次 → 追问 → 不满足停止条件就让它**重开这一关**，上限 5 次。

    python run_multi.py --arms arms_plan.json --stage D:/arc-arena --rounds 5
    python run_multi.py --rounds 5 --only a-bare-no

前提：`build.py --retries` 已经造好跑场并起好服务（**不带 `--one-life`**）。
这一份只跑受试，不造跑场、不起服务。

## 和上一轮（单轮）的区别

```
上一轮   服务 --one-life：GAME_OVER 整局终止 → 追问一次 → 收工
这一轮   服务**不带** --one-life：`/reset` 只重开**当前关**（关 1–3 的进度保留）
         每轮：它自己打 → 台架追问「这一次怎么没过、为什么」→ 判停止条件
                → 不停就发 RETRY，让它重开这一关再打
         全程**同一个会话**（claude 用 `-c` 续、codex 用 `resume --last`），
         所以它身上带着前几轮的全部上下文 —— 这正是「反复试了几次还是不确定」要的东西
```

`ONLY_RESET_LEVELS=true` 是服务无条件设的，所以 RESET 始终是「重开这一关」，
不是「整局重来」。因此**每一次尝试仍然是一条独立的命**，
我们那份 Lean 定理（量化在一条命之内的任意动作串上）照样适用。

## 停止条件（**跑之前登记的，不许事后改**）

```
A  服务侧显示它**打过了这一关**（关号 > 胜负线，或 end_reason == "win"）→ 停  win
   胜负线 = 臂表里的 `win_level`，没写就用 `--win-level`（默认 4 = sc25 的目标关）
B  追问的回答里 `VERDICT` 是 `impossible` 或 `impossible_in_model`
   且 `CONFIDENCE >= 90`                                            → 停  confident
C  非裸臂：它自己写的 Lean 里有**台架编得过且公理干净**的那一份        → 停  lean
D  轮数用尽（默认 5）                                                → 停  exhausted
```

B 和 C 就是你说的「非常肯定这关不可做」和「给出不可做的严谨 lean 证明」。
C **不看它自述**，由 `leancheck.py` 自己把文件编一遍（见那一份的文件头）。

裸臂没拿到形式化那一包，所以 C 对它不适用 —— 它只能走 B 或 D。
这是口径上的不对称，**是设计如此**：形式化那一包正是框架 / oracle 臂多出来的东西。

**在可解那一侧（side=ok）触发 B 或 C，就是预先登记的 E 桶（把可解的判成不可解），
最坏的一桶。** 台账里会单独标出来。

## 留痕

```
run_multi.json   每条臂每一轮的：墙钟、算力、服务侧读数、追问原文、VERDICT/CONFIDENCE、
                 Lean 编译读数（逐字输出留底）
收工前再发一次**完整追问**（核心四问 + 第 5 问 Lean），和上一轮的读数可比
```
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import leancheck as LC                                         # noqa: E402
import memclean as MC                                          # noqa: E402
from run import drive, srv_read                                # noqa: E402

V_RE = re.compile(r"^\s*VERDICT:\s*([A-Za-z_]+)", re.M | re.I)
# **词表四档，强弱次序 undecided < impossible_in_model < impossible**（见 DECISIONS.md）。
# `impossible_in_model` = 「在我自己量出来的规则里打不过去，而『这套规则 = 真游戏』
# 是我声明的假设」—— 这是受试**能达到的上限**，我自己那份 Lean 证明也只到这一档。
IMPOSSIBLE = ("impossible", "impossible_in_model", "impossible_in_model_proved")


def verified_level(claimed: str | None, lean: dict | None,
                   clean_so_far: set | None = None) -> str | None:
    """`_proved` **不采信自述** —— 由台架编译结果定。

    声称 `_proved` 而**手上没有**编得过且公理干净的证明 ⇒ 摘掉 `_proved`；
    声称 `impossible_in_model` 而 Lean 确实干净 ⇒ 也不擅自升格，只把两者都记下来，
    由报告去说。这里只做**降格**，因为升格属于解释，不属于读数。

    **「手上有」要跨轮累积，不能只看这一次。** 第四轮栽过：框架臂第 4 次写的
    `lean/Level4c.lean` 编得过且公理干净，第 6 次它援引同一份、没再改动，
    于是「这一次改过的 .lean」是空集，被**误判**成虚报。
    诚实的问法是「它**现在**手上有没有一份」，所以这里看累积集合。
    """
    if claimed is None:
        return None
    have = bool(lean and lean.get("any_clean")) or bool(clean_so_far)
    if claimed == "impossible_in_model_proved" and not have:
        return "impossible_in_model"
    return claimed
C_RE = re.compile(r"^\s*CONFIDENCE:\s*(\d{1,3})", re.M | re.I)


# **裸臂的词表只有三档。** 把 `impossible_in_model` 递给裸臂等于把
# 「用模型表示整个世界」这个念头提示给它 —— 而那正是我们框架要测的东西，
# 不能由追问的措辞免费送给对照组。所以：
#     裸臂     winnable | impossible | undecided
#     非裸臂   winnable | impossible | impossible_in_model_proved | impossible_in_model | undecided
# 这处不对称是**设计如此**，和「裸臂不发 Lean 那一问」同一个理由。
# 瞬断的指纹。实测两轮都栽在同一句上，墙钟都卡在 196–198 秒：
#     API Error: Connection dropped (ECONNRESET)
# 一次瞬断就废掉整条臂（第三轮 oracle、第四轮 oracle + 框架+模型），所以重试一次。
# 2026-10-11 又加一条：**CLI 自己被 npm 升级了**。
# `run.py` 调的是 `claude.cmd`（批处理外壳），它内部再去调
# `…\claude-code\bin\claude.exe`。升级那一瞬那个 exe 被替换，外壳就报
#     '"…\bin\claude.exe"' is not recognized as an internal or external command
# 实测：cd82 framework_model/no 那条臂的第 5 轮栽在这里，整条臂被截断成 4 轮、
# 收工追问也成了 0s（进程表里前面几轮是 2.1.295，事后查是 2.1.296）。
TRANSIENT = ("ECONNRESET", "Connection dropped", "Connection error",
             "ETIMEDOUT", "socket hang up", "EPIPE",
             "is not recognized as an internal or external command",
             "cannot find the path specified", "Access is denied")


def is_transient(out: dict) -> bool:
    if out.get("returncode") == 0 and (out.get("text") or "").strip():
        return False
    blob = (out.get("text") or "") + (out.get("stderr") or "")
    return any(w in blob for w in TRANSIENT)


def drive_retry(agent, d, text, first, label="", pause=20):
    """发一段话；撞上瞬断就**重试一次**，两次的读数都留在记录里。

    重试一律用 `first=False` 续同一个会话 —— 第一次调用可能已经建好会话、
    甚至已经发过动作，重新开一个会话会把那一段上下文丢掉。
    """
    out = drive(agent, d, text, first=first)
    if not is_transient(out):
        return out
    print("     !! %s 撞上瞬断（rc=%s, %.0fs）：%s —— 等 %ds 重试一次"
          % (label or "这一步", out["returncode"], out["wall_s"],
             ((out.get("text") or "")[:80]).replace(chr(10), " "), pause))
    time.sleep(pause)
    again = drive(agent, d, text, first=False)
    again["retry_of"] = {k: out.get(k) for k in ("returncode", "wall_s", "text", "stderr")}
    again["wall_s"] = round(out["wall_s"] + again["wall_s"], 1)   # 墙钟算两次之和
    return again


# **`bare_asked`（2026-10-14 加）**：跑场和 `bare` 逐字节相同（`EXTRA` 里都是 None），
# 但追问发完整的第 4 问与五选量表。为的是把两件事拆开：
#   「裸臂给不出严谨证明」 vs 「我们从来没要求裸臂给证明」
# 第 4 问只换掉「using the formal apparatus you were given」那半句（它没有装置），
# 其余逐字相同 —— diff 只在那一句和「Lean 在 PATH 上」这条必要告知。
# 这**不泄答案**：第 4 问原话两个方向对称（can be won, or cannot）。
ASKS_LEAN = ("framework", "framework_model", "oracle", "bare_asked")


def round_ask(arm: str) -> str:
    t = (HERE / "ASK_round.txt").read_text(encoding="utf-8")
    if arm in ASKS_LEAN:
        t += (HERE / ("ASK_round_lean_bare.txt" if arm == "bare_asked"
                      else "ASK_round_lean.txt")).read_text(encoding="utf-8")
    tail = "ASK_round_tail.txt" if arm in ASKS_LEAN else "ASK_round_tail_bare.txt"
    return t + (HERE / tail).read_text(encoding="utf-8")


def final_ask(arm: str) -> str:
    t = (HERE / "ASK_core.txt").read_text(encoding="utf-8")
    if arm in ASKS_LEAN:
        t += (HERE / ("ASK_lean_bare.txt" if arm == "bare_asked"
                      else "ASK_lean.txt")).read_text(encoding="utf-8")
    tail = "ASK_tail.txt" if arm in ASKS_LEAN else "ASK_tail_bare.txt"
    return t + (HERE / tail).read_text(encoding="utf-8")


def verdict_of(text: str) -> dict:
    """取**最后**出现的那一对 VERDICT / CONFIDENCE。"""
    t = text or ""
    v = V_RE.findall(t)
    c = C_RE.findall(t)
    return {"verdict": (v[-1].lower() if v else None),
            "confidence": (int(c[-1]) if c else None),
            "stated": bool(v)}


def lean_snapshot(workdir: Path) -> dict:
    out = {}
    for f in workdir.rglob("*.lean"):
        try:
            out[str(f.relative_to(workdir)).replace("\\", "/")] = LC.md5(f)
        except Exception:
            pass
    return out


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", default="arms_plan.json")
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--conf", type=int, default=90, help="「非常肯定」的门槛")
    ap.add_argument("--only", default="")
    # **停止条件 A 的胜负线**：服务侧关号 > 这个数 ⇒ 判「打过了」。
    # 默认 4 是 sc25 的目标关 —— 那四轮的行为逐字不变。
    # 臂表里每条可以写 `win_level` 覆盖它：cd82 目标关 3、su15 目标关 1。
    # 不覆盖的话 su15 打过关 1（到关 2）会被判成「没打过」。
    ap.add_argument("--win-level", type=int, default=4,
                    help="停止条件 A 的胜负线（关号 > 它算打过了）；臂表里的 win_level 优先")
    ap.add_argument("--lean-timeout", type=int, default=600)
    ap.add_argument("--out", default="run_multi.json")
    ap.add_argument("--mem-archive", default=(__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/LEAK-memory-20261010"),
                    help="开跑前把跑场的跨轮记忆存到这里再清空")
    ap.add_argument("--tag", default="", help="存记忆时加的后缀，便于分轮")
    a = ap.parse_args(argv)
    stage = Path(a.stage)
    arms = json.loads((HERE / a.arms).read_text(encoding="utf-8"))["arms"]
    if a.only:
        pick = a.only.split(",")
        arms = [r for r in arms if any(w in r["case"] for w in pick)]

    print("停止条件（登记在 DECISIONS.md）：**只有两条**")
    print("  A 打过了这一关          D 次数用尽（%d）" % a.rounds)
    print("里程碑（记录，**不停**）：")
    print("  confident  判定属不可做族且 CONFIDENCE>=%d" % a.conf)
    print("  proved     非裸臂：台架编得过且公理干净（`_proved` 不采信自述）")
    print("词表：裸臂三档（winnable|impossible|undecided）· "
          "非裸臂五档（多 impossible_in_model[_proved]）")
    print("每条臂开跑前清空该跑场的跨轮记忆（~/.claude/projects/<路径>/memory/），"
          "进场份数必须是 0")
    print()

    results = []
    streak = 0
    for r in arms:
        case, arm, agent, side = r["case"], r["arm"], r["agent"], r["side"]
        d = stage / case
        if not d.exists():
            print("跳过 %s：跑场不在（先 build.py --retries）" % case)
            continue
        print("=" * 92)
        print("%s  %s/%s  %s  端口 %s" % (case, arm, agent,
                                          "派生盘" if side == "no" else "原盘", r["port"]))
        rec = {"case": case, "arm": arm, "agent": agent, "side": side,
               "port": r["port"], "rounds": [], "stop": None,
               "conf_threshold": a.conf,
               # 里程碑：哪一次**第一次**到达各档（B/C 不再是停止条件）
               "milestones": {}, "first_reached": {}}
        # —— **按项目路径的记忆**：开跑前存走并清空 ——
        # claude CLI 的记忆按**工作目录路径**分桶（`~/.claude/projects/<改写>/memory/`），
        # 跑场目录名一复用，上一轮的结论就会在新会话开场被注入。
        # 实测栽过：a-or-no-claude 的受试在第一轮写下「cap L=18 … peak no less than 19」，
        # 第二轮同一个目录**进场就带着那段话**。`baseline/` 的逐字节复原管不到它。
        rec["mem_on_entry"] = MC.clear(d, Path(a.mem_archive), tag=a.tag)
        if rec["mem_on_entry"]["n"]:
            print("  !! 进场时有 %d 份跨轮记忆，已存走并清空（%s）"
                  % (rec["mem_on_entry"]["n"],
                     ", ".join(f["name"] for f in rec["mem_on_entry"]["files"])))
        snap = lean_snapshot(d)
        built: dict = {}
        clean_so_far: set = set()      # 跨轮累积：编得过且公理干净的那些文件
        prev = {"actions": 0, "resets": 0}
        text = (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8")
        first = True
        broke = False

        for k in range(1, a.rounds + 1):
            play = drive_retry(agent, d, text, first=first,
                               label="第 %d 次的游玩" % k)
            first = False
            # **「没跑起来」怎么判。** 第一版写的是「rc≠0 或墙钟 < 60s」，**错了**：
            # 到了后几轮受试本来就越打越快（实测 a-bare-no-claude 的动作数
            # 72 → 25 → 14 → 22，第 3 轮只用了 66 秒），第 5 轮 40 秒被误判成没跑起来，
            # 于是那一轮的追问被跳过、停止原因也标错。
            #
            # 墙钟只在**第 1 轮**才是可靠信号（那一轮要从关 1 打起，40 秒退出
            # 只可能是认证挂了）。后面几轮一律看退出码和有没有真回话。
            txt = (play.get("text") or "").strip()
            if k == 1:
                dead = play["returncode"] != 0 or play["wall_s"] < 60 or not txt
            else:
                dead = play["returncode"] != 0 or not txt
            if dead:
                if k == 1:
                    streak += 1
                head = (txt or play.get("stderr") or "")[:200]
                print("!! 第 %d 轮没跑起来：rc=%s wall=%.0fs  %s"
                      % (k, play["returncode"], play["wall_s"],
                         head.replace(chr(10), " ")))
                rec["rounds"].append({"k": k, "play": play, "dead": True})
                rec["stop"] = "died_at_round_%d" % k
                broke = (k == 1)        # 第 1 轮就挂 ⇒ 这条臂没读数；后面挂还能收尾
                break
            streak = 0
            srv = srv_read(HERE / "srvlog" / case)
            srv_round = {"actions": srv["actions"] - prev["actions"],
                         "level": srv.get("level"),
                         "levels_completed": srv.get("levels_completed")}
            prev["actions"] = srv["actions"]
            print("  第 %d 次 · 打了 %.0f 分钟 · 这一轮发了 %d 个动作 · 到第 %s 关"
                  % (k, play["wall_s"] / 60, srv_round["actions"], srv_round["level"]))

            probe = drive_retry(agent, d, round_ask(arm), first=False,
                                label="第 %d 次的追问" % k)
            # **追问也要守。** 只守 `play` 不够：第三轮 a-or-no-claude 的第 2 次追问
            # 撞上 `API Error: Connection dropped (ECONNRESET)`，rc=1、没有回话，
            # 于是判定解析成 None/None，而循环当它「没表态」继续往下跑，
            # 后面两次也全挂在同一个错误上 —— 整条臂的读数废了却没报警。
            ptxt = (probe.get("text") or "").strip()
            if probe["returncode"] != 0 or not ptxt:
                print("!! 第 %d 次的**追问**没回来：rc=%s  %s"
                      % (k, probe["returncode"], ptxt[:160].replace(chr(10), " ")))
                rec["rounds"].append({"k": k, "play": play, "srv": srv_round,
                                      "probe": probe, "dead_probe": True})
                rec["stop"] = "probe_failed_at_round_%d" % k
                broke = True          # 这条臂的读数不完整，不发收工追问、不算合计
                break
            v = verdict_of(probe["text"])
            print("  追问 %.0fs → VERDICT=%s CONFIDENCE=%s"
                  % (probe["wall_s"], v["verdict"], v["confidence"]))

            lean = None
            if arm in ASKS_LEAN:
                now = lean_snapshot(d)
                changed = sorted([p for p, h in now.items() if snap.get(p) != h])
                snap = now
                if changed:
                    print("  这一轮新写/改了 %d 份 .lean，台架自己编一遍……" % len(changed))
                    lean = LC.check_files(d, changed, timeout=a.lean_timeout, built=built)
                    for f in lean["files"]:
                        print("    %-34s 编得过=%s 公理干净=%s"
                              % (f["file"], f["compiles"], f["clean"]))
                        for l in f["axiom_lines"]:
                            print("        %s" % l)

            wl = int(r.get("win_level", a.win_level))
            # 第三个判据是 2026-10-13 补的：**目标关就是最后一关时，前两个都不触发**。
            # vk71 的目标关是第 4 关、而它一共就 4 关 ⇒ 「关号 > 4」永远不成立；
            # 而 `end_reason == "win"` 只有 `--one-life` 档才写。实测：vk71 的 ok 侧
            # **四轮全部通关**（服务侧 state=WIN、levels_completed=4），驱动却一轮没停、
            # 白跑三轮。对 cd82/su15/sc25 是 no-op —— 它们的目标关不是最后一关，
            # 真通关时「关号 > 胜负线」早就先触发了。
            won = ((srv_round["level"] or 0) > wl
                   or srv.get("end_reason") == "win"
                   or (srv_round.get("state") or srv.get("state")) == "WIN")

            # —— **到了「模型内不可做」不再停。** ——
            # 原来 B（很肯定）和 C（交出干净 Lean）都是停止条件，于是一碰到就收工：
            # 第三轮框架+模型臂**第 1 次**就停了，框架臂第 2 次就停了，拿不到后续。
            # 但真正想看的是：**它到了那一档之后，会不会去试探和修自己的模型，
            # 最后能不能完全相信它** —— 以及反过来会不会退回去（实测裸 Astra
            # 就从 imp_m/75 退回 und/90）。
            # 所以 B / C 降格成**里程碑记录**，循环只在「打过了」或「次数用尽」时停。
            if lean:
                clean_so_far.update(lean.get("clean_files") or [])
            ver = verified_level(v["verdict"], lean, clean_so_far)
            mile = None
            if v["verdict"] in IMPOSSIBLE and (v["confidence"] or 0) >= a.conf:
                mile = "confident"
            if ver == "impossible_in_model_proved":
                mile = "proved" if mile is None else "confident+proved"
            if mile and mile not in rec["milestones"]:
                rec["milestones"][mile] = k
            if ver and ver not in rec["first_reached"]:
                rec["first_reached"][ver] = k
            if mile:
                print("     里程碑：%s（第 %d 次）—— **不停**，继续让它修模型" % (mile, k))
            if v["verdict"] != ver:
                print("     !! 它声称 %s，但台架编译后降格为 %s" % (v["verdict"], ver))

            stop = "win" if won else ("exhausted" if k == a.rounds else None)
            rec["rounds"].append({"k": k, "play": play, "srv": srv_round,
                                  "probe": probe, "verdict": v,
                                  "verdict_verified": ver, "milestone": mile,
                                  "lean": lean, "clean_so_far": sorted(clean_so_far),
                                  "stop": stop})
            (HERE / a.out).write_text(
                json.dumps(results + [rec], ensure_ascii=False, indent=1),
                encoding="utf-8")
            if stop:
                rec["stop"] = stop
                print("  ⇒ 停：%s" % stop)
                break
            text = (HERE / "RETRY.txt").read_text(encoding="utf-8")
            print("  ⇒ 不停，让它重开这一关")

        if not broke:
            rec["final"] = drive_retry(agent, d, final_ask(arm), first=False,
                                       label="收工追问")
            print("  收工追问 %.0fs" % rec["final"]["wall_s"])
            # **收工之后也要编一遍。** 第二轮栽过：两条臂的 Lean 是收工那一步才写的，
            # 循环里一份都没有（那时第 4 问是有条件的），我是跑完手工补编才发现。
            rec["final_verdict"] = verdict_of(rec["final"]["text"])
            if arm in ASKS_LEAN:
                now = lean_snapshot(d)
                changed = sorted([p for p, h in now.items() if snap.get(p) != h])
                snap = now
                if changed:
                    print("  收工这一步新写/改了 %d 份 .lean，编一遍……" % len(changed))
                    rec["final_lean"] = LC.check_files(d, changed,
                                                       timeout=a.lean_timeout, built=built)
                    for f in rec["final_lean"]["files"]:
                        print("    %-34s 编得过=%s 公理干净=%s"
                              % (f["file"], f["compiles"], f["clean"]))
                        for l in f["axiom_lines"]:
                            print("        %s" % l)
                    clean_so_far.update(rec["final_lean"].get("clean_files") or [])
                    if rec["final_lean"]["any_clean"] and rec["stop"] == "exhausted":
                        print("  （注意：循环已判 exhausted，但**收工这一步交出了干净的 Lean** ——"
                              "按 DECISIONS.md 这算条件 C 晚一步满足）")
            rec["server"] = srv_read(HERE / "srvlog" / case)
            rec["totals"] = {
                "rounds": len([x for x in rec["rounds"] if not x.get("dead")]),
                "wall_s": round(sum(x["play"]["wall_s"] for x in rec["rounds"])
                                + sum(x["probe"]["wall_s"] for x in rec["rounds"]
                                      if "probe" in x)
                                + rec["final"]["wall_s"], 1),
                "actions": rec["server"]["actions"]}
            print("  合计：%d 轮 · %.1f 小时 · %d 个动作"
                  % (rec["totals"]["rounds"], rec["totals"]["wall_s"] / 3600,
                     rec["totals"]["actions"]))
            if side == "ok" and rec["stop"] in ("confident", "lean"):
                print("  !! **可解那一侧判了不可做 —— 预先登记的 E 桶**")
        # —— 跑完记下它这一轮**写了**什么（这本身是读数）——
        rec["mem_written"] = MC.peek(d)
        if rec["mem_written"]["n"]:
            print("  这一轮它写了 %d 份记忆：%s"
                  % (rec["mem_written"]["n"],
                     ", ".join(f["name"] for f in rec["mem_written"]["files"])))
        results.append(rec)
        (HERE / a.out).write_text(json.dumps(results, ensure_ascii=False, indent=1),
                                  encoding="utf-8")
        if streak >= 2:
            print()
            print("**连续 %d 条没跑起来，停。** 不接着跑一整轮废数据。" % streak)
            return 3

    print()
    # **一条都没跑就不要写输出。** 否则 `--only` 打错字（匹配不到任何臂）会把
    # 上一轮的读数覆盖成空列表 —— 实测踩过，靠归档才捞回来。
    if not results:
        print("一条臂都没跑（--only 匹配不到？）—— **不写 %s**，免得覆盖已有读数。" % a.out)
        return 2
    print("写了 %s" % (HERE / a.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
