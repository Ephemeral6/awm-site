# -*- coding: utf-8 -*-
"""跑场的**按项目路径记忆**：开跑前清空，跑完记下它写了什么。

    python memclean.py --stage D:/arc-arena --check      # 只看，不动
    python memclean.py --stage D:/arc-arena --clear      # 存走并清空

## 为什么要这一份

claude CLI 把记忆存在 `~/.claude/projects/<路径改写>/memory/`，**按工作目录的路径分桶**。
跑场复用同一个目录名，于是：

```
第一轮  a-or-no-claude 的受试在 2026-10-09 21:57 写下
        「Level 4 has a budget cap of L=18 … the exhaustive BFS still finds a peak of
         no less than 19 … never rely on the 8-of-16 overlap win」
第二轮  同一个跑场目录 ⇒ **新会话一开场就被注入这段话**，并在 05:57/06:07 续写
```

这不是受试的错，是台架的错：**跑场目录名复用 + 记忆按路径分桶 = 跨轮泄露**。
`baseline/` 的逐字节复原管不到它 —— 那份记忆不在跑场目录里，在 `~/.claude` 下。

## 两件事

```
开跑前   把该跑场的 memory/ **存走再清空**，并记下「进场时有几份」——
         这个数必须是 0，不是 0 就说明上一轮的结论漏进来了
跑完     记下它这一轮**写了**几份、写了什么（这本身是读数：它认为什么值得记）
```

codex 那一侧查过：`~/.codex` 下没有记忆目录，跑场里也没有 `AGENTS.md`，
`config.toml` 不注入指令 —— 所以只有 claude 这一侧要管。
"""
from __future__ import annotations

import argparse
import io
import json
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJ = Path.home() / ".claude" / "projects"


def memdir(workdir: Path) -> Path:
    """工作目录 → `~/.claude/projects/<路径改写>/memory`。

    改写规则实测：盘符的 `:` 和每个分隔符都变成 `-`
    （`D:\\arc-arena\\a-or-no-claude` → `D--arc-arena-a-or-no-claude`）。
    """
    s = str(Path(workdir).resolve())
    s = s.replace(":", "-").replace("\\", "-").replace("/", "-")
    return PROJ / s / "memory"


def peek(workdir: Path) -> dict:
    d = memdir(workdir)
    files = sorted(f for f in d.rglob("*") if f.is_file()) if d.exists() else []
    return {"dir": str(d), "n": len(files),
            "files": [{"name": str(f.relative_to(d)).replace("\\", "/"),
                       "bytes": f.stat().st_size,
                       "mtime": time.strftime("%Y-%m-%dT%H:%M:%S",
                                              time.localtime(f.stat().st_mtime)),
                       "head": f.read_text(encoding="utf-8", errors="replace")[:600]}
                      for f in files]}


def clear(workdir: Path, archive: Path | None, tag: str = "") -> dict:
    """存走再清空。返回清空**之前**的内容（即「进场时有什么」）。"""
    r = peek(workdir)
    d = Path(r["dir"])
    if r["n"] and archive is not None:
        t = archive / (Path(workdir).name + (("-" + tag) if tag else ""))
        t.mkdir(parents=True, exist_ok=True)
        for f in d.rglob("*"):
            if f.is_file():
                g = t / f.relative_to(d)
                g.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, g)
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)
    return r


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--arms", default="arms_plan.json")
    ap.add_argument("--clear", action="store_true", help="存走并清空（默认只看）")
    ap.add_argument("--archive", default=(__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/LEAK-memory-20261010"))
    ap.add_argument("--tag", default="")
    a = ap.parse_args(argv)
    stage = Path(a.stage)
    arms = json.loads((HERE / a.arms).read_text(encoding="utf-8"))["arms"]
    tot = 0
    for r in arms:
        d = stage / r["case"]
        info = clear(d, Path(a.archive), a.tag) if a.clear else peek(d)
        tot += info["n"]
        mark = "" if info["n"] == 0 else "  **%d 份**" % info["n"]
        print("%-22s %s%s" % (r["case"], "清空了" if a.clear else "有 %d 份" % info["n"], mark))
        for f in info["files"]:
            print("      %-34s %6d 字节  %s" % (f["name"], f["bytes"], f["mtime"]))
    print()
    if a.clear:
        print("清空完毕。原件存在 %s" % a.archive)
    print("合计 %d 份%s" % (tot, "" if tot == 0 else "  —— **不是 0 就是跨轮泄露**"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
