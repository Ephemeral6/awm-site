"""`Pad` —— 屏幕下方那块 3×3 的大面板：九个格位，每格三态之一。

    "off"    没点亮，而且画着「该点这一格」的提示色
    "blank"  没点亮，和地板同色
    "lit"    点亮了

它记两件事：九个格位的状态（行优先），和九个格位各自在帧上占的矩形
（点击是按帧上的坐标给的，要知道点中了哪一格，就得知道每一格在哪）。

## 为什么删不掉

  cells —— 「点亮的格位凑齐了哪一块小面板的图案」只能从它读；凑齐那一下是三台机器的开关。
  rects —— 同一个点击坐标点不点得中格子，只看它。**整批语料里它从没变过**
           （九格一直在同一处），所以分离表上它分不开任何一对世界——那不是它没用，
           是这批语料没有第二种版面。见 analysis/Pad.txt。

## off 和 blank 的区别谁在用

凑齐判据只看 lit。off/blank 的差别只在「凑齐那一下全部变 blank」这一条上被读——
它是渲染层面的事实，不是开关。留着它是因为不留的话那条规则说不出话（见 analysis/Pad.txt）。
"""
from __future__ import annotations

from dataclasses import dataclass

STATES = ("off", "blank", "lit")


@dataclass(frozen=True)
class Pad:
    cells: tuple            # 9 个状态，行优先
    rects: tuple            # 9 个 (top, left, bottom, right)，与 cells 对齐

    def lit(self) -> frozenset:
        """点亮的格位，(行号, 列号) 0..2。"""
        return frozenset((i // 3, i % 3) for i, s in enumerate(self.cells) if s == "lit")

    def hit(self, x: int, y: int):
        """帧坐标 (x=列, y=行) 点中的格位 (行号, 列号)；没点中返回 None。"""
        for i, (t, l, b, r) in enumerate(self.rects):
            if t <= y <= b and l <= x <= r:
                return (i // 3, i % 3)
        return None

    def state(self, cell) -> str:
        return self.cells[cell[0] * 3 + cell[1]]
