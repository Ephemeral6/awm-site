"""三台机器各认哪个记号色。

**这是一条没被排除替代读法的假设，写在明处**：认机器的也可能是图案而不是色——
整批语料里色与图案完全共变（菱形 ↔ 15、拐角 ↔ 11、竖线 ↔ 6），这批语料分不开。
按色写，是因为「场上哪些格是这台机器的记号」也按色认，两处用同一个 id 最省。
"""
from __future__ import annotations

RESIZE = 15      # 翻尺寸：边长在 4 和 2 之间翻转
TELEPORT = 11    # 搬家：整块搬进一个框
ERASE = 6        # 抹除：把我面前那个框里的标本连同场上同色一起抹掉


def machine(color):
    return {RESIZE: "resize", TELEPORT: "teleport", ERASE: "erase"}.get(color)
