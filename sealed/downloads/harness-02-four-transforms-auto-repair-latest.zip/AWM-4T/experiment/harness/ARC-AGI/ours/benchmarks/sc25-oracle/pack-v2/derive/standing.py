"""站得上去吗：一格的「可站性」。

    走得上去   地板、记号（记号是画在地上的）
    涨得上去   走得上去的 + 燃料（涨上去当场吃掉）+ 我自己此刻压着的格
    挡路       虚空、实心块（墙 / 标本 / 插座的边）、插座内胆（内胆只有「整块踏进去」这一种进法）

这一份只算量；「走得上去就挪窝」是 rule/step/move.py 的主张。
"""
from __future__ import annotations

from .geometry import inside


def walkable(w, p) -> bool:
    if not inside(p):
        return False
    return p in w.ground.floor or w.ground.is_mark(p)


def growable(w, p) -> bool:
    if not inside(p):
        return False
    return walkable(w, p) or p in w.ground.fuel or p in w.me.cells()


def all_walkable(w, cells) -> bool:
    return all(walkable(w, p) for p in cells)


def all_socket(w, cells) -> bool:
    return all(p in w.ground.socket for p in cells)
