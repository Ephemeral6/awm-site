# -*- coding: utf-8 -*-
"""Render run_v2's prompt log (prompts_log/<run>.jsonl) as a readable Markdown file: every message the driver sent to
the subject, in order, verbatim, with the step it belongs to, when it was sent, and how long the reply took.

    python -I render_prompt_log.py <prompts_log jsonl> <out.md>
"""
import json
import sys
from pathlib import Path


def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    rows = [json.loads(l) for l in src.read_text(encoding="utf-8").splitlines() if l.strip()]
    lines = ["# 每一步发给受试的 prompt（逐字）", "",
             "来源：`%s`，共 %d 条，按发送顺序。每条下面是驱动发出的原文；回复只记长度和用时（全文在 run 读数里）。" % (src.name, len(rows)), ""]
    lines += ["| # | 发送时间 | 哪一步 | 新会话 | 字数 | 回复字数 | 用时 s | rc |", "|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        lines.append("| %d | %s | %s | %s | %d | %s | %s | %s |" % (i, r["sent"], r["label"], "是" if r["new_session"] else "",
                     len(r["text"]), r.get("reply_chars"), r.get("wall_s"), r.get("returncode")))
    lines.append("")
    for i, r in enumerate(rows, 1):
        lines += ["---", "", "## %d · %s（%s）" % (i, r["label"], r["sent"]), "", "````text", r["text"].rstrip("\n"), "````", ""]
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out, len(rows), "messages")


if __name__ == "__main__":
    main()
