/-
# Broken —— **这一份应当编不过**，而且只在标记那一行红

一套证明如果什么都证得出来，它一条也没证。验收对这一份的要求：编不过（退出码非 0），
而且**只有一处**错误、落在带标记的那一行。

挑的这一条和现有主张**正面冲突**：第 0 关开局我在右边、插座在左边隔着好几个身位，
「往左按一下就到插座里」不可能；`L0_winnable` 的见证要走 12 步。`decide` 当场算出这一条是错的。
-/

import Proof.Levels

open Game Game.Levels

theorem L0_in_one_step : stepsReachGoal (Replay.board 0) L0_start [.dir .L] = true := by
  decide +kernel      -- ← 这一行应当红
