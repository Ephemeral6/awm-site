"""Six independent runs by default, up to three worker processes; no global helpers."""
import argparse,datetime,json,os,re,secrets,socket,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ARMKIT=HERE.parent.parent/'benchmarks/armkit'
sys.path.insert(0,str(ARMKIT));import completion_round as CR

def case_from_log(log):
    match=re.search(r'^case\s+(\S+)',log.read_text(encoding='utf-8',errors='replace'),re.M)
    return match.group(1) if match else None

def cleanup_case(case):
    result=subprocess.run([sys.executable,'-I',str(HERE/'stop_server.py'),'--case',case],cwd=HERE,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
    return dict(server_cleanup_returncode=result.returncode,server_cleanup_output=(result.stdout+result.stderr).decode('utf-8',errors='replace').strip())

def main():
    p=argparse.ArgumentParser();p.add_argument('--levels',nargs='+',type=int,choices=[4,5],default=[4,5]);p.add_argument('--runs-per-level',type=int,default=3)
    p.add_argument('--max-concurrent',type=int,choices=[1,2,3],default=3);p.add_argument('--base-port',type=int,default=9531);p.add_argument('--reserve-gib',type=float,default=4);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    if not 1<=a.runs_per_level<=20 or a.reserve_gib<2:p.error('runs-per-level1..20 and reserve-gib>=2 required')
    todo=[(lv,rep) for rep in range(1,a.runs_per_level+1) for lv in dict.fromkeys(a.levels)]
    if a.base_port<1024 or a.base_port+len(todo)>65535:p.error('invalid port range')
    jobs=[]
    for i,(lv,rep) in enumerate(todo):
        port=a.base_port+i;cmd=[sys.executable,'-u','-I',str(HERE/'run_one.py'),'--new','--level',str(lv),'--port',str(port),'--allow-concurrent']
        jobs.append(dict(level=lv,replicate=rep,port=port,command=cmd))
    if a.dry_run:
        print(json.dumps(dict(max_concurrent=a.max_concurrent,required_initial_free_gib=8*a.max_concurrent+a.reserve_gib,jobs=jobs),ensure_ascii=False,indent=2));return 0
    if CR.avail_gb()<8*a.max_concurrent+a.reserve_gib:raise SystemExit('Not enough free RAM for worst-case8GiB/run plus reserve. Lower --max-concurrent; three slots require>=28GiB FREE,48GiB installed recommended.')
    for j in jobs:
        with socket.socket() as s:
            try:s.bind(('127.0.0.1',j['port']))
            except OSError:raise SystemExit('Port busy: '+str(j['port']))
    folder=HERE/'runs'/('batch-v7h-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(2));folder.mkdir(parents=True)
    (folder/'plan.json').write_text(json.dumps(dict(version='v7h',model=os.environ.get('AWM_CLAUDE_MODEL','claude-opus-5-5'),max_concurrent=a.max_concurrent,jobs=jobs),ensure_ascii=False,indent=2),encoding='utf-8')
    active=[];done=[]
    try:
        while jobs or active:
            while jobs and len(active)<a.max_concurrent:
                j=jobs.pop(0);log=folder/('L%d-rep%d.out'%(j['level'],j['replicate']));f=log.open('w',encoding='utf-8')
                proc=subprocess.Popen(j['command'],cwd=HERE,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);active.append((j,proc,f,log));print('started',j['level'],j['replicate'],proc.pid,flush=True)
            for item in list(active):
                j,proc,f,log=item
                if proc.poll() is not None:
                    f.close();case=case_from_log(log)
                    record={**j,'returncode':proc.returncode,'case':case,'log':str(log)};done.append(record);active.remove(item)
                    if case:
                        try:
                            with (folder/(case+'.grade.out')).open('w',encoding='utf-8') as out:
                                grade=subprocess.run([sys.executable,'-I',str(HERE/'grade_one.py'),'--case',case],cwd=HERE,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                            record['grade_returncode']=grade.returncode
                        finally:
                            record.update(cleanup_case(case))
                    (folder/'results.json').write_text(json.dumps(done,ensure_ascii=False,indent=2),encoding='utf-8');print('finished',case,proc.returncode,flush=True)
            if active:time.sleep(2)
    except BaseException as error:
        # Only PIDs this launcher created, never name-wide process kills.
        # Detached game servers are checked separately against their owner file.
        for j,proc,f,log in active:
            if proc.poll() is None:
                subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: pass
            f.close();case=case_from_log(log)
            record={**j,'returncode':proc.poll(),'case':case,'log':str(log),'aborted':type(error).__name__}
            if case:record.update(cleanup_case(case))
            done.append(record)
        (folder/'results.json').write_text(json.dumps(done,ensure_ascii=False,indent=2),encoding='utf-8')
        raise
    finally:
        for _,_,f,_ in active:f.close()
    print('Results:',folder);return 0 if all(j['returncode']==0 for j in done) else 2
if __name__=='__main__':raise SystemExit(main())
