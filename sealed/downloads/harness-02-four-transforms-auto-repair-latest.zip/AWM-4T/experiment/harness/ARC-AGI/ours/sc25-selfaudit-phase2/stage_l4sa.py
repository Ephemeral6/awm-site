# -*- coding: utf-8 -*-
"""Stage the **l4s** arenas (phase 2: self-audit built into the framework METHOD), via `armkit/build.py`,
without editing it or `l4/stage_l4.py`.

    python -I stage_l4sa.py --plan arms_plan_l4s_selfaudit.json --dry-run
    python -I stage_l4sa.py --plan arms_plan_l4s_selfaudit.json --serve        # only at launch time

Identical to `l4/stage_l4.py` as used for the l4p batch (`--method-addendum ../l5/METHOD_addendum_closed_v4.md
--method-addendum2 METHOD_addendum_elements.md`), except one more section: `METHOD_addendum_selfaudit.md`, inserted
right after the closed-proof section (i.e. before the paragraph "`mathlib` **没有**。"). The script asserts that the
staged METHOD.md minus that one section is byte-identical to the l4p batch's METHOD_variant_2adf4911_584ce37c.md.
Blinding lists and leak words: stage_l4.py's, injected the same way (reused from that module).
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = Path(str(Path(__file__).resolve().parents[1] / "benchmarks")) / "armkit-v2"      # (folder moved to ours/sc25-selfaudit-phase2 on 2026-10-21)
L4DIR = V2 / "l4"
L5DIR = V2 / "l5"
ARMKIT = V2.parent / "armkit"
L4P_METHOD = L4DIR / "METHOD_variant_2adf4911_584ce37c.md"   # what the l4p arenas got
L4P_METHOD_MD5 = "64a7116d3a6c5330bd4cf0db93c02dd9"
SECTION = HERE / "METHOD_addendum_selfaudit.md"
ANCHOR3 = "`mathlib` **没有**。"


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()

# ---- v7 (2026-10-22): step two by cards, tools/ and cards/ in the arena ----
sys.path.insert(0, str(HERE))
import method_v7 as MV7                                            # noqa: E402
V7 = HERE.parent / "sc25-selfaudit-v7"
CARDS_DIR = V7 / "cards_v7h"
TOOLS_DIR = V7 / "tools_v7"
TOOL_FILES = ("field_split.py", "criteria_run.py", "CONTRACT.md")


def v7_extra(B):
    """Add cards/ and tools/ to the framework arena, and scan them for leak words."""
    ex = B.EXTRA["framework"]
    ex["dirs"] = [x for x in ex["dirs"] if x[0] != "cards"] + [("cards", CARDS_DIR)]
    extra_tools = sorted(p for p in TOOLS_DIR.glob("*") if p.is_file() and p.suffix in (".py", ".md")
                         and p.name != "README.md")
    names = {p.name for p in extra_tools}
    assert set(TOOL_FILES) <= names, "tools_v7 lacks %s" % (set(TOOL_FILES) - names)
    ex["files"] = [x for x in ex["files"] if not x[0].startswith("tools/")] + \
        [("tools/" + p.name, p) for p in extra_tools]
    texts = [f.read_text(encoding="utf-8") for f in sorted(CARDS_DIR.glob("*.md"))] + \
        [p.read_text(encoding="utf-8") for p in extra_tools] + [MV7.STEP2_NEW.read_text(encoding="utf-8")]
    for w in B.LEAK_WORDS:
        for t in texts:
            assert w.lower() not in t.lower(), "leak word in cards/tools/step two: %r" % w



def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--serve", action="store_true")
    a = ap.parse_args(argv)

    S4 = load("stage_l4_lists", L4DIR / "stage_l4.py")          # lists only; its main() is not called
    if md5(S4.L4_SRC) != S4.L4_MD5:
        raise SystemExit("level-4 sealed engine md5 mismatch")
    assert md5(L4P_METHOD) == L4P_METHOD_MD5, "l4p METHOD variant changed on disk"

    sys.path.insert(0, str(ARMKIT))
    B = load("armkit_build", ARMKIT / "build.py")
    S5 = load("stage_l5_lists", L5DIR / "stage_l5.py")
    assert B.SIDES["no"] == (S4.L4_SRC, S4.L4_MD5), B.SIDES["no"]
    before = (len(B.LEAK_WORDS), len(B.FORBIDDEN_FILES))
    for w in S4.L4_LEAK_WORDS + S5.NEW_LEAK_WORDS:
        if w not in B.LEAK_WORDS:
            B.LEAK_WORDS.append(w)
    B.FORBIDDEN_FILES |= S4.L4_TRUTH_FILES | S5.NEW_TRUTH_FILES
    print("injected (additive only): LEAK_WORDS %d->%d, FORBIDDEN_FILES %d->%d"
          % (before[0], len(B.LEAK_WORDS), before[1], len(B.FORBIDDEN_FILES)))

    base = L4P_METHOD.read_text(encoding="utf-8")
    add = SECTION.read_text(encoding="utf-8")
    assert base.count(ANCHOR3) == 1, "anchor not found exactly once"
    i = base.index(ANCHOR3)
    var = HERE / ("METHOD_variant_2adf4911_584ce37c_%s_c%s.md" % (md5(SECTION)[:8], md5(MV7.STEP2_NEW)[:8]))
    var = HERE / "generated_methods" / (hashlib.sha256(str(Path(a.plan).resolve()).encode()).hexdigest()[:16] + ".md")
    var.parent.mkdir(parents=True, exist_ok=True)
    text = MV7.compose(base, add, ANCHOR3)
    assert MV7.undo(text, base, add) == base, "v7 METHOD is not base + step two by cards + self-audit"
    var.write_text(text, encoding="utf-8", newline="\n")
    v7_extra(B)
    for w in B.LEAK_WORDS:
        assert w not in add, "leak word in the self-audit section: %r" % w
    B.EXTRA["framework"]["doc"] = ("METHOD.md", var)
    B.EXTRA["framework_model"]["docs2"] = [("METHOD.md", var)]
    print("   METHOD.md -> %s (md5 %s) == l4p's %s + %s"
          % (var.name, md5(var)[:12], L4P_METHOD.name, SECTION.name), flush=True)

    args = ["--arms", str(Path(a.plan).resolve()), "--stage", a.stage, "--retries"]
    if a.dry_run:
        args.append("--dry-run")
    if a.serve:
        args.append("--serve")
    return B.main(args)


if __name__ == "__main__":
    raise SystemExit(main())
