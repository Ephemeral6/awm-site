# -*- coding: utf-8 -*-
r"""**Self-audit round** (2026-10-21): can a framework run locate and repair the rule behind a wrong bound
*without* anyone naming the rule?  Pre-registration: PREREG-selfaudit-20261021.md (same folder).

    python -I selfaudit_round.py --dry-run                 # print the exact prompts and the plan; touches nothing
    python -I selfaudit_round.py --prepare --case <case>   # archive the post-hint arena + memory, restore the
                                                           # pre-hint snapshot, write the truncated session copy
    python -I selfaudit_round.py --run --case <case>       # wait for the machine, start the service, send ONE prompt

Subjects (each resumed from its own session, cut right before the first hint it ever got):
    m15fw-case-9ec8d4   level 4, :9100, sc25_L4_b18.py   transcript lines [0, 1618)  (before hint_round R1)
    l5d-case-977714     level 5, :9262, sc25_L5_b35.py   transcript lines [0, 1367)  (before repair_l5d R1)

The only external information is the generic R1 message that 9ec8d4 already received once in hint_round.py
(there without the self-audit section, result: not found, least 20 against the engine's 19). No rule is named.
"""
from __future__ import annotations

import argparse
import datetime
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
OURS = HERE.parent.parent.parent                       # ...\ours
ARMKIT = OURS / "benchmarks" / "armkit"
sys.path.insert(0, str(ARMKIT))
import completion_round as CR                          # noqa: E402  (watchdog, memory probes, static scan)
import leancheck as LC                                 # noqa: E402
import tokens as TK                                    # noqa: E402
from run import CLI                                    # noqa: E402

STAGE = Path(__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
ARCHIVE = Path((__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/selfaudit-20261021"))
PROJECTS = Path(os.path.expanduser("~")) / ".claude" / "projects"
OUTD = HERE / "runs"
LOG = HERE / "selfaudit_round.log"
STATE = HERE / "state.json"
CR.LOG = LOG
SERVER = OURS.parent / "collab" / "pilot4-astra-pack" / "pilot4-astra-pack" / "cd82" / "code" / "server_pilot.py"
VARDIR = OURS / "benchmarks" / "sc25-budget" / "variant"
METHOD_SA = HERE / "METHOD_selfaudit.md"
MODEL = "claude-opus-5-5"          # the originals ran as `--model opus`, verified claude-opus-5-5 in both transcripts
L4P_QUEUE_PID = 30444              # rerun-l4-framework-runs' l4p queue (launch_l4p_prior.py); wait until it is gone
MIN_FREE_GB = 6.0
ALLOW_CONCURRENT = [False]

# ---------------------------------------------------------------------------------------------------- prompts
# The R1 head is hint_round.py's R1 text, verbatim; only the self-audit sentence is added.
R1 = ("One more task on this level. We compared your model with the actual game engine. The engine has a cheaper "
      "winning route than your model allows when every rule is taken as your evidence supports it: at least one "
      "rule of your model forbids, or charges more for, a move that the engine allows. I am not telling you which "
      "rule, or anything about the true cost. Find the discrepancy yourself.")
SA = ("Find it with the self-audit in `METHOD_selfaudit.md` (in your working directory; read it now). It is part of "
      "how you are required to work, like METHOD.md. Write its step 1, the sensitivity table, before you send any "
      "request to the game in this round.")
SA_LINES = """LOAD_BEARING=<the load-bearing rules of your first pass, in table order, separated by " | ">
PROBES=<one entry per probed rule, "rule: CONFIRMED|REFUTED|UNTESTABLE", separated by " | ">
PASSES=<number of self-audit passes>
REPLAY=<recorded transitions replayed against the corrected model>/<of those, agreeing>
LEAST_BUDGET_IF_UNTESTABLE_LOOSENED=<least budget with every UNTESTABLE load-bearing rule step-loosened, or "none">"""

# 9ec8d4: hint_round.py's TAIL, verbatim, plus the self-audit lines (its proof standard: unverified rules may be
# explicit hypotheses, as in every round it had).
TAIL_L4 = """
You may play the level again: the service at the same address has been restarted from level 1 (your earlier solutions for levels 1-3 still work), and you may reset as often as you like.

When you are done:
1. Say which rules of your model you changed, what you observed that made you change them (attempt, step, the values before and after), and which experiments you ran to separate the possibilities.
2. Update your Lean model and `lean/FinalProof.lean` to the corrected rules. As before, we will accept it only if: one theorem quantifies over all action lists of your model and states that none wins within the level's budget as you measured it; it is kernel-checked with no `sorry`, `native_decide` or `axiom` declarations and ends with `#print axioms` (only `propext`, `Classical.choice`, `Quot.sound`); every rule you have not verified appears as an explicit hypothesis, as weak as your evidence allows; a second theorem gives the least budget at which your model admits a win, with a winning action list; and the file compiles with the toolchain in METHOD.md in under 15 minutes and under 4 GB.
3. End with these lines:
CHANGED_RULES=<one sentence per rule you changed, separated by " | ">
LEAST_BUDGET_FULL_EVIDENCE=<the least budget at which your corrected model, with every rule as your evidence supports it, admits a win>
""" + SA_LINES + """
VERDICT=...
CONFIDENCE=...
"""

# 977714: repair_l5d.py's TAIL, verbatim, plus the self-audit lines (its proof standard: METHOD closed v4).
TAIL_L5 = """
You may play the level again: the service at the same address has been restarted from level 1 (your earlier solutions for levels 1-4 still work), and you may reset as often as you like.

When you are done:
1. Say which rules of your model you changed, what you observed that made you change them (attempt, step, the values before and after), and which experiments you ran to separate the possibilities.
2. Update your Lean model and your proof as METHOD.md requires (the section on when a proof counts as finished): the main theorem holds for every action sequence of your corrected model and is closed in Lean, with the relaxed-model theorem in the same file. Your corrected model must still reproduce every transition you have recorded on this level.
3. End with these lines:
MAIN-THEOREM: lean/<file>.lean : <theorem name>
CHANGED_RULES=<one sentence per rule you changed, separated by " | ">
LEAST_BUDGET=<the least starting budget, in your model's units, at which your corrected model admits a win>
MEASURED_BUDGET=<the level's starting budget as you measured it, in the same units>
""" + SA_LINES + """
VERDICT=...
CONFIDENCE=...
"""

# Sent only if the CLI returns without a final report because of a connection/API error (pre-registered, max 2).
CONTINUE = ("Your previous turn was cut off by a connection error, not by us. Continue the same task where you left "
            "off and finish with the lines asked for.")

CASES = {
    "m15fw-case-9ec8d4": dict(
        level=4, port=9100, variant="sc25_L4_b18.py", md5="7a922000d167e160fa69886c3ff24686",
        snapshot=Path((__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/hint-20261017/m15fw-case-9ec8d4")),
        session="850b584e-a2ce-4331-8f95-3318341e3ef5", cut=1618,
        cut_expect="One more task on this level. We compared your model with the actual game engine.",
        memory={"m15fw-game-rules.md": [("line", "- **2026-10-17 re-check:**"), ("line", "- **Attempt 10:**")]},
        tail=TAIL_L4, lean_cap_gb=4.0, truth="engine least budget 19 (cap 18 no win)",
        min_free_gb=3.0),   # (15:55) its Lean peaks at 0.72 GB; the 6 GB floor kept it waiting at 5.0 GB free
    "l5d-case-977714": dict(
        level=5, port=9262, variant="sc25_L5_b35.py", md5="0f2d4207224d46a655a678782df22e64",
        snapshot=Path((__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/repair-l5d-20261020/l5d-case-977714")),
        session="7b7e15d8-1bc4-453e-8080-dd3e3acbbeca", cut=1367,
        cut_expect="One more task on this level. We compared your model with the actual game engine.",
        memory={"game-mechanics-attempt1.md": [("from", "\nAttempt 9 (engine said R-col wrong)")]},
        tail=TAIL_L5, lean_cap_gb=1e9, truth="engine least budget 36 (cap 35 no win), i.e. relaxation +1"),
}


# (addenda 2026-10-21, the user's instructions) ~11:50 "only on the bound's level" was replaced at ~12:00 by:
# experiments may use any level the service serves, but only through the service -- no self-built levels/engine calls
ONLY_LEVEL = ("You may run experiments on any level the service gives you (level {n} is the level of your bound; levels "
              "1-{m} use the same rules). Every experiment must go through the service, following the rules of "
              "engagement you were given: do not build levels or game states of your own and run them outside it.")


def prompt(case):
    n = CASES[case]["level"]
    return (R1 + "\n\n" + SA + " " + ONLY_LEVEL.format(n=n, m=n - 1) + "\n" + CASES[case]["tail"])


def count_tests(case, level):
    """From the round's server log: resets, attempts and actions on the bound's level, actions elsewhere."""
    logs = sorted((ARMKIT / "srvlog" / (case + "-selfaudit")).glob("*.jsonl"))
    c = {"resets": 0, "resets_by_level": {}, "actions_by_level": {}, "game_overs": 0, "game_overs_by_level": {},
         "attempts_on_level": 0, "actions_on_level": 0, "actions_on_other_levels_after_first_reach": 0,
         "wins_of_level": 0, "logs": [p.name for p in logs]}
    reached = False
    for p in logs:
        for line in p.read_text(encoding="utf-8").splitlines():
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if e.get("ep") == "reset":
                c["resets"] += 1
                lv = str(e.get("level"))
                c["resets_by_level"][lv] = c["resets_by_level"].get(lv, 0) + 1
                if e.get("level") == level:
                    c["attempts_on_level"] += 1
            elif e.get("ep") == "action":
                lb = e.get("level_before")
                c["actions_by_level"][str(lb)] = c["actions_by_level"].get(str(lb), 0) + 1
                if lb == level:
                    c["actions_on_level"] += 1
                    if e.get("level") != level:
                        c["wins_of_level"] += 1
                elif reached:
                    c["actions_on_other_levels_after_first_reach"] += 1
                if e.get("level") == level and lb == level - 1:
                    reached = True
                    c["attempts_on_level"] += 1          # arriving from the previous level opens an attempt
                if e.get("state") == "GAME_OVER":
                    c["game_overs"] += 1
                    c["game_overs_by_level"][str(lb)] = c["game_overs_by_level"].get(str(lb), 0) + 1
    return c


def say(msg):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    with io.open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_state():
    return json.loads(STATE.read_text(encoding="utf-8")) if STATE.exists() else {}


def save_state(st):
    STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")


def proj_dir(case):
    return PROJECTS / ((__import__("re").sub(r"[:\\/]", "-", __import__("os").environ.get("AWM_STAGE", "D:/arc-arena")) + "-") + case)


# ---------------------------------------------------------------------------------------------------- prepare
def strip_memory(text, ops):
    for kind, key in ops:
        if kind == "line":
            lines = text.split("\n")
            hit = [i for i, l in enumerate(lines) if l.startswith(key)]
            assert len(hit) == 1, (key, hit)
            del lines[hit[0]]
            text = "\n".join(lines)
        else:
            i = text.find(key)
            assert i > 0 and text.count(key) == 1, key
            text = text[:i] + "\n"
    return text


def prepare(case, method=None):
    spec = CASES[case]
    st = load_state()
    assert case not in st, "already prepared: %s" % st.get(case)
    arena, snap, pd = STAGE / case, spec["snapshot"], proj_dir(case)
    assert snap.exists() and (snap / "transitions.jsonl").exists(), snap
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    # 1. the post-hint arena and memory are moved aside, not deleted (skipped on a re-prepare after a void,
    #    where they were archived the first time and the arena path has been emptied by void())
    post = ARCHIVE / (case + "__posthint-arena")
    postmem = ARCHIVE / (case + "__posthint-memory")
    if post.exists():
        assert not arena.exists() and postmem.exists(), (arena, postmem)
        say("%s: re-prepare; post-hint arena already archived at %s" % (case, post))
    else:
        shutil.move(str(arena), str(post))
        shutil.copytree(pd / "memory", postmem)
        say("%s: post-hint arena -> %s; memory copied -> %s" % (case, post, postmem))
    # 2. the pre-hint snapshot is restored at the original path (the transcript refers to it), + the method section
    shutil.copytree(snap, arena)
    msrc = Path(method) if method else METHOD_SA
    shutil.copy2(msrc, arena / "METHOD_selfaudit.md")
    say("%s: snapshot %s restored -> %s (+ METHOD_selfaudit.md from %s, md5 %s)" % (case, snap, arena, msrc.name, CR.md5(msrc)))
    # 3. memory back to its state at the cut (every post-cut edit was an insertion; see PREREG §Restore)
    # (2026-10-21) the whole folder is reset to the archived post-hint copy first, so nothing a voided start
    # wrote can carry over; then the post-cut insertions are stripped
    for f in (pd / "memory").iterdir():
        if not (postmem / f.name).exists():
            shutil.move(str(f), str(ARCHIVE / ("%s__memory-extra-%s-%s" % (case, datetime.datetime.now()
                                                                            .strftime("%H%M%S"), f.name))))
            say("%s: memory/%s was not in the post-hint copy -> archived" % (case, f.name))
    for f in postmem.iterdir():
        shutil.copy2(f, pd / "memory" / f.name)
    for fn, ops in spec["memory"].items():
        p = pd / "memory" / fn
        old = (postmem / fn).read_text(encoding="utf-8")       # always from the archived post-hint copy
        new = strip_memory(old, ops)
        p.write_text(new, encoding="utf-8")
        say("%s: memory/%s %d -> %d chars" % (case, fn, len(old), len(new)))
    # 4. truncated session copy under a new id (the original transcript is not touched)
    src = pd / (spec["session"] + ".jsonl")
    lines = src.read_text(encoding="utf-8").splitlines(keepends=True)
    first_cut = json.loads(lines[spec["cut"]])
    assert first_cut.get("type") == "user" and str(first_cut["message"]["content"]).startswith(spec["cut_expect"])
    keep = lines[:spec["cut"]]
    assert json.loads(keep[-1]).get("type") in ("queue-operation", "cost-state", "last-prompt")
    sid = str(uuid.uuid4())
    old = '"sessionId":"%s"' % spec["session"]
    out = [l.replace(old, '"sessionId":"%s"' % sid) for l in keep]
    (pd / (sid + ".jsonl")).write_text("".join(out), encoding="utf-8")
    say("%s: session copy %s.jsonl = lines [0, %d) of %s.jsonl" % (case, sid, spec["cut"], spec["session"]))
    st[case] = {"session": sid, "prepared": datetime.datetime.now().isoformat(timespec="seconds"),
                "method": str(msrc), "method_md5": CR.md5(msrc),
                "posthint_arena": str(post)}
    save_state(st)


def void(case, reason):
    """Archive everything a started run left (arena, session copy, server log, readout); nothing is deleted.
    Afterwards `--prepare` restores the pre-hint state again from the same sources."""
    st = load_state()
    assert case in st, case
    # a finished run is archived under its own tag (e.g. "DONE-v3"), anything else as VOID-<reason>
    tag = ("%s-%s" if reason.startswith("DONE") else "VOID-%s-%s") % (reason, datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    pd, sid = proj_dir(case), st[case]["session"]
    moves = [(STAGE / case, ARCHIVE / ("%s__%s-arena" % (case, tag))),
             (pd / (sid + ".jsonl"), ARCHIVE / ("%s__%s-session-%s.jsonl" % (case, tag, sid))),
             (ARMKIT / "srvlog" / (case + "-selfaudit"), ARMKIT / "srvlog" / ("%s-selfaudit-%s" % (case, tag))),
             (OUTD / ("%s.json" % case), OUTD / ("%s-%s.json" % (tag, case))),
             (OUTD / ("%s.lock" % case), OUTD / ("%s-%s.lock" % (tag, case)))]
    for a, b in moves:
        if a.exists():
            shutil.move(str(a), str(b))
            say("%s: %s -> %s" % (case, a, b))
    st.setdefault("done" if reason.startswith("DONE") else "voids", []).append({"case": case, "tag": tag, **st.pop(case)})
    save_state(st)


# ---------------------------------------------------------------------------------------------------- run
# Any other subject driver still running blocks a start (2026-10-21: the l4p queue pid had exited on the user's
# instruction while its last run continued under watch_one_l4p.py; the pid-only guard let 9ec8d4 start -> void).
BUSY = re.compile(r"run_v2\.py|watch_one|launch_l[0-9]|launch_|repair_l5d|hint_round|run_multi|completion_round|"
                  r"run_hosts|run_seeds|selfaudit_round\.py --run")


def other_drivers():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python' } | "
                        "ForEach-Object { \"$($_.ProcessId)`t$($_.CommandLine)\" }"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    me = os.getpid()
    out = []
    for line in r.stdout.splitlines():
        pid, _, cmd = line.partition("\t")
        if pid.strip().isdigit() and int(pid) != me and BUSY.search(cmd or ""):
            out.append("%s %s" % (pid, BUSY.search(cmd).group(0)))
    return out


def alive(pid):
    r = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid, "/NH"], capture_output=True, text=True)
    return str(pid) in r.stdout


def port_free(port):
    r = subprocess.run(["netstat", "-ano"], capture_output=True, text=True)
    return not re.search(r":%d\s.*LISTENING" % port, r.stdout)


def drive_resume(d, sid, text):
    """run.drive("claude", ...) with `--resume <sid>` in place of `-c`, and the model pinned; env handling copied."""
    env = dict(os.environ)
    for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
              "CLAUDE_CODE_MESSAGING_SOCKET", "CLAUDE_CODE_MESSAGING_TOKEN",
              "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_HOST_SESSION_ID",
              "CLAUDE_CODE_CHILD_SESSION", "CLAUDE_CODE_SDK_HAS_HOST_AUTH_REFRESH",
              "CLAUDE_CODE_ENTRYPOINT", "CLAUDECODE", "CLAUDE_CODE_SESSION_ATTENDED",
              "CLAUDE_CODE_TERMINAL_MCP_TOOLS", "CLAUDE_CODE_EXECPATH", "BAGGAGE"):
        env.pop(k, None)
    if env.get("HTTPS_PROXY") or env.get("HTTP_PROXY"):
        no = env.get("NO_PROXY", "")
        for host in ("claude.ai", ".claude.ai"):
            if host not in no:
                no = (no + "," if no else "") + host
        env["NO_PROXY"] = no
        env["no_proxy"] = no
    cmd = [CLI["claude"], "-p", "--model", MODEL, "--output-format", "json",
           "--dangerously-skip-permissions", "--resume", sid]
    t0 = time.time()
    # (fix 2026-10-21 after VOID-rulechange) remember the subject's descendant processes while it runs; whatever is
    # still alive after the CLI returns (e.g. `timeout 1700 python sens.py` from a background task) is an orphan
    # that keeps files in the arena locked -> killed and logged
    p = subprocess.Popen(cmd, cwd=str(d), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         text=True, encoding="utf-8", errors="replace", env=env)
    seen = set()
    stop = [False]

    def track():
        while not stop[0]:
            try:
                seen.update(descendants_of(p.pid))
            except Exception:
                pass
            time.sleep(20)
    import threading
    th = threading.Thread(target=track, daemon=True)
    th.start()
    so, se = p.communicate(text)
    stop[0] = True
    now = proc_table()
    orphans = sorted(pid for pid, ct in seen if now.get(pid, (None, None))[1] == ct)   # same pid AND creation time
    for x in orphans:
        subprocess.run(["taskkill", "/PID", str(x), "/T", "/F"], capture_output=True)
    if orphans:
        say("killed %d orphan subject processes after the CLI returned: %s" % (len(orphans), orphans))
    out = {"returncode": p.returncode, "wall_s": round(time.time() - t0, 1), "stderr": (se or "")[-1500:],
           "cmd": cmd[1:], "orphans_killed": orphans}
    try:
        j = json.loads(so)
        out["text"] = j.get("result") or j.get("text") or ""
        out["is_error"] = j.get("is_error")
        out["session_id"] = j.get("session_id")
        out["tokens"] = TK.claude(j)
    except Exception:
        out["text"] = so
        out["tokens"] = {"cli": "claude", "note": "not json, no usage"}
    return out


def proc_table():
    """pid -> (ppid, creation time) for every process."""
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process | ForEach-Object { \"$($_.ProcessId) $($_.ParentProcessId) "
                        "$($_.CreationDate.Ticks)\" }"], capture_output=True, text=True)
    t = {}
    for line in r.stdout.split("\n"):
        a = line.split()
        if len(a) == 3 and all(x.isdigit() for x in a):
            t[int(a[0])] = (int(a[1]), a[2])
    return t


def descendants_of(root):
    """{(pid, creation time)} of every live descendant of root."""
    t = proc_table()
    kids = {}
    for pid, (ppid, ct) in t.items():
        kids.setdefault(ppid, []).append(pid)
    out, stack = set(), [root]
    while stack:
        for k in kids.get(stack.pop(), []):
            if (k, t[k][1]) not in out:
                out.add((k, t[k][1]))
                stack.append(k)
    return out


def start_server(case, spec):
    logdir = ARMKIT / "srvlog" / (case + "-selfaudit")
    (ARMKIT / "srvout").mkdir(exist_ok=True)
    var = VARDIR / spec["variant"]
    assert CR.md5(var) == spec["md5"], var
    cmd = [sys.executable, str(SERVER), "--game", "sc25", "--variant-path", str(var), "--md5", spec["md5"],
           "--port", str(spec["port"]), "--log", str(logdir)]
    out = open(ARMKIT / "srvout" / ("%s.selfaudit.out" % case), "w", encoding="utf-8")
    p = subprocess.Popen(cmd, stdout=out, stderr=subprocess.STDOUT,
                         creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    time.sleep(6)
    say("service on :%d (pid %d, %s, md5 %s…, log %s)" % (spec["port"], p.pid, var.name, spec["md5"][:12], logdir))
    return p


def lines_of(text, key, sep="="):
    return re.findall(r"^\s*%s\s*%s\s*(.+?)\s*$" % (re.escape(key), re.escape(sep)), text or "", flags=re.M)


def finished(text):
    return bool(lines_of(text, "VERDICT"))


def run(case):
    spec = CASES[case]
    st = load_state()
    assert case in st, "run --prepare first"
    assert not (OUTD / ("%s.json" % case)).exists(), "already has a readout"
    # (2026-10-21 ~13:35) lock: 977714 was started by hand alongside 9ec8d4 while the queued chain would start it
    # again after 9ec8d4; the second start must refuse
    OUTD.mkdir(exist_ok=True)
    lock = OUTD / ("%s.lock" % case)
    if lock.exists():
        say("%s already started (lock %s: %s); not starting again" % (case, lock.name, lock.read_text()))
        return None
    lock.write_text("pid %d %s" % (os.getpid(), datetime.datetime.now().isoformat(timespec="seconds")))
    d = STAGE / case
    sid = st[case]["session"]
    say("=" * 70)
    say("%s · level %d · :%d · session %s" % (case, spec["level"], spec["port"], sid))
    drv_note, rec_concurrent = [None], []
    while True:                                           # machine guard (PREREG §Machine)
        busy = []
        if drv_note[0] is None and ALLOW_CONCURRENT[0]:
            drv_note[0] = other_drivers()
            rec_concurrent.extend(drv_note[0])
            say("--allow-concurrent (user, 2026-10-21): other drivers running now: %s" % (drv_note[0] or "none"))
        if alive(L4P_QUEUE_PID):
            busy.append("l4p queue pid %d alive" % L4P_QUEUE_PID)
        drv = other_drivers()
        if drv and not ALLOW_CONCURRENT[0]:
            busy.append("other subject drivers running: " + ", ".join(drv))
        floor = spec.get("min_free_gb", MIN_FREE_GB)
        if CR.avail_gb() < floor:
            busy.append("free %.1f GB < %.0f" % (CR.avail_gb(), floor))
        if not port_free(spec["port"]):
            busy.append("port %d in use" % spec["port"])
        if not busy:
            break
        say("waiting: " + "; ".join(busy))
        time.sleep(300)
    CR.LEAN_CAP_GB = spec["lean_cap_gb"]
    srv = start_server(case, spec)
    rec = {"case": case, "method_md5": st[case].get("method_md5"), "truth": spec["truth"], "session": sid, "model": MODEL, "turns": [],
           "server_variant_md5": spec["md5"], "started": datetime.datetime.now().isoformat(timespec="seconds"),
           "allow_concurrent": ALLOW_CONCURRENT[0], "concurrent_drivers_at_start": rec_concurrent}
    try:
        before = CR.lean_snapshot(d)
        msgs = [prompt(case)]
        while msgs:
            text_in = msgs.pop(0)
            wd = CR.Watchdog("drive")
            wd.start()
            out = drive_resume(d, sid, text_in)
            wd.stop.set()
            rec["turns"].append({"prompt": text_in, "reply": out, "watchdog": wd.events})
            say("turn %d · rc %s · %.0f s · finished=%s · %s" % (len(rec["turns"]), out["returncode"], out["wall_s"],
                                                                 finished(out.get("text")), (out.get("text") or "")[-200:].replace("\n", " ")))
            OUTD.mkdir(exist_ok=True)
            (OUTD / ("%s.json" % case)).write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
            if not finished(out.get("text")) and len(rec["turns"]) <= 2 and (out["returncode"] != 0 or out.get("is_error")):
                msgs.append(CONTINUE)
        text = rec["turns"][-1]["reply"].get("text") or ""
        if not finished(text):
            # (fix 2026-10-21) the CLI returns only the last assistant message; if a background task woke the subject
            # after its report, the report is in the transcript -> take the last assistant text with VERDICT=
            try:
                for line in (proj_dir(case) / (sid + ".jsonl")).read_text(encoding="utf-8").splitlines():
                    j = json.loads(line)
                    m = j.get("message") if isinstance(j.get("message"), dict) else {}
                    if j.get("type") == "assistant" and isinstance(m.get("content"), list):
                        t = "".join(x.get("text", "") for x in m["content"] if x.get("type") == "text")
                        if "VERDICT=" in t:
                            text, rec["report_source"] = t, "transcript " + str(j.get("timestamp"))
            except Exception as ex:
                rec["report_source"] = "transcript read failed: %r" % ex
        keys = ["CHANGED_RULES", "LEAST_BUDGET_FULL_EVIDENCE", "LEAST_BUDGET", "MEASURED_BUDGET", "LOAD_BEARING",
                "PROBES", "PASSES", "REPLAY", "LEAST_BUDGET_IF_UNTESTABLE_LOOSENED", "VERDICT", "CONFIDENCE"]
        rec["lines"] = {k: (lines_of(text, k) or [None])[-1] for k in keys}
        rec["lines"]["MAIN-THEOREM"] = (lines_of(text, "MAIN-THEOREM", ":") or [None])[-1]
        rec["changed_lean"] = sorted(k for k, v in CR.lean_snapshot(d).items() if before.get(k) != v)
        rec["selfaudit_files"] = sorted(str(p.relative_to(d)) for p in (d / "work" / "selfaudit").glob("*")) \
            if (d / "work" / "selfaudit").exists() else []
        rec["tests"] = count_tests(case, spec["level"])
        say("%s server log: %s" % (case, json.dumps(rec["tests"], ensure_ascii=False)[:500]))
        rec["finished"] = datetime.datetime.now().isoformat(timespec="seconds")
        (OUTD / ("%s.json" % case)).write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
        say("%s done · lines %s" % (case, json.dumps(rec["lines"], ensure_ascii=False)[:600]))
    finally:
        subprocess.run(["taskkill", "/PID", str(srv.pid), "/T", "/F"], capture_output=True)
        say("service stopped")
    return rec


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=list(CASES))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--prepare", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--void", default=None, help="reason tag; archive a started run before re-preparing")
    ap.add_argument("--method", default=None, help="method section file for --prepare (default METHOD_selfaudit.md)")
    ap.add_argument("--allow-concurrent", action="store_true",
                    help="(user decision 2026-10-21 for 9ec8d4) start even if another subject driver runs; RAM floor kept")
    a = ap.parse_args(argv)
    ALLOW_CONCURRENT[0] = a.allow_concurrent
    if a.void:
        void(a.case, a.void)
        return 0
    if a.dry_run:
        for c in ([a.case] if a.case else list(CASES)):
            print("=" * 30, c, "· resume session copy of", CASES[c]["session"], "cut at line", CASES[c]["cut"])
            print(prompt(c))
        return 0
    assert a.case, "--case"
    if a.prepare:
        prepare(a.case, a.method)
    if a.run:
        run(a.case)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
