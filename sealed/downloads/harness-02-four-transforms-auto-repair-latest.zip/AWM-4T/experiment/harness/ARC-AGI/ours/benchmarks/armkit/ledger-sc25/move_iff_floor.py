"""方向动作让标记块真的挪窝，当且仅当目标方区里每一格要么是地板色、要么是记号色（小面板挂着的那几色）。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1/2/3/4；换关的那一步（ctx.level_prev != ctx.level_next）返回 NA；" \
        "目标方区整块是插座内胆（at_socket）时返回 NA——那一步归 socket_ends_level 管；" \
        "标记块定位不到返回 NA；每个世界会话的第一条动作（ctx.step 在 _lib.SESSION_FIRST_STEPS 里，世界吞掉的那一条）返回 NA"
NOTE = "apply 里标记块的两种半边颜色借用 _lib.FACE（那是 facing_marks_action 的主张）；若 FACE 错，P 会先打出来。" \
       "v2：边长从写死的 4 改成 marker() 读出来的边长（第 19 步标记块缩了一半）。" \
       "v3：挪窝后腾出来的格子从一律地板色改成 ground_color——第 28 步在这里扣了 4 格：" \
       "标记块从角标方框里走出来，它盖过的 4 个角标原样露出来，说明角标画在地面上，被盖住只是看不见，不是被擦掉。" \
       "assert_ 一直只看左上角，所以那一步 assert 判 TRUE 而 apply 打出反例——这条概念的「判」比「生成」窄，是它活下来的原因。" \
       "v4：换关那一步返回 NA。第 23 步走进插座过关，整屏重画；「标记块挪没挪窝」在换关帧上没有意义（新关的标记块是世界摆的）。" \
       "口径注意：预测时 ctx 的 level_next 恒等于 level_prev，所以这道闸只在结算时关——" \
       "动作发出去之前我并不知道这一步会过关，所以 v5 另加了一条纯看帧的闸：" \
       "v5：目标方区整块是插座内胆时也返回 NA（`at_socket`）。册子已经由 socket_ends_level 断言那一步会过关、整屏重画，" \
       "再让这条生成「原地不动」，等于明知会错还押——两副口径下都不该说话。它让出的那块地盘由 socket_ends_level 管。" \
       "v9：判据从「目标方区整块地板」改成「每一格要么地板色、要么记号色」。第 208 步的反例：" \
       "目标方区里有角标色、没有虚空，我照样挪了进去。" \
       "这一条从 v1 起就写着「整块地板」，一路 S≈0.99 —— 可全语料按目标方区色号集合分桶后只有四种局面：" \
       "纯地板（挪 53 次）、含虚空（不挪）、地板加一种墙色（不挪 1 次）、地板加记号色（0 次）。" \
       "也就是说「记号色挡路」这半句一次都没被检验过，它只是「整块地板」这个写法顺带宣称的东西。" \
       "S=1 不等于抽得全：一条概念在两百条转移上判 TRUE，只说明它没被推翻，不说明它管的那一片被走过。" \
       "v9 仍然宣称「非地板非记号色挡路」，而那只有第 32 步一次观测——同样是薄的，撞上了就再改。" \
       "v10：主张没动，只把 apply 让出去的那四个角闭了嘴。第 236 步我从一个**只有内画四角**的色 11 框上走开，" \
       "露出来的是四格角标，而 apply 按 ground_color 押了地板色——四格全错，--strict 当场停批。" \
       "ground_color 那一半本来有防线（standing_in_ring 时返回 None），可它只认外描边那种画法；" \
       "内画四角的框正好扣在我自己的四个角上，我一站上去，帧上就一点痕迹都不剩，单帧无论如何读不出来。" \
       "所以 apply 从此不碰「我让出来的那四个角」：能藏在我身下不被发现的东西，只可能是这四格" \
       "（框的内画法就是四个角，而它必须和我同边长同位置才扣得住）。" \
       "代价是每走一步少认领 4 格；换来的是这一类意外从此不会再发生。" \
       "这不改断言，也不改 scope——assert_ 本来就不看让出来的格子。" \
       "v11：终局卡第一条动作（第 251 步 ACTION3，目标整块地板）被世界吞掉，整帧不变，这条判 FALSE。" \
       "和第 1 步是同一件事——每个世界会话的第一条动作都被吞，而 v10 的 scope 只让出了「第 1 步」。" \
       "改成让出 _lib.SESSION_FIRST_STEPS 里的每一步，那一步归 first_action_void 管；主张本身一字未动。"
EVIDENCE = ["da3e01cff498c8a1", "2e40e31fa60834cc", "fd67f106b9c9aa15", "d181e84f3fb7a473",
            "9dabb54dca80d95d", "24b4fa49fe16626f", "13fcb5b3e3fa0714"]

from _lib import (DIR, FACE, FLOOR, MARK, SESSION_FIRST_STEPS, _corners, at_socket, ground_color, legends, marker,
                  step_to, target_colors)


def _passable(prev, action):
    """目标方区能不能站进去：每一格要么地板色、要么记号色；越界算不能。"""
    tc = target_colors(prev, action)
    if tc is None:
        return None if marker(prev) is None or action not in DIR else False
    return not (tc - {FLOOR} - set(legends(prev)))


def _dest(prev, action, ctx):
    if action not in DIR:
        return None
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if at_socket(prev, action) is True:
        return None
    if ctx is not None and ctx.get("step") in SESSION_FIRST_STEPS:
        return None
    m = marker(prev)
    if m is None:
        return None
    ok = _passable(prev, action)
    if ok is None:
        return None
    return m, (step_to(prev, action) if ok else (m[0], m[1]))


def assert_(prev, action, nxt, ctx=None):
    d = _dest(prev, action, ctx)
    if d is None:
        return "NA"
    m, want = d
    b = marker(nxt)
    if b is None:
        return "NA"
    return "TRUE" if (b[0], b[1]) == want else "FALSE"


def apply(prev, action, ctx=None):
    d = _dest(prev, action, ctx)
    if d is None:
        return None
    m, (r0, c0) = d
    k = m[2]
    face = FACE[action]
    h = k // 2
    out = {}
    for r in range(r0, r0 + k):
        for c in range(c0, c0 + k):
            dr, dc = r - r0, c - c0
            nine = (dr < h) if face == "U" else (dr >= h) if face == "D" else \
                   (dc < h) if face == "L" else (dc >= h)
            out[(r, c)] = MARK[0] if nine else MARK[1]
    corners = _corners(m[0], m[1], k)
    for r in range(m[0], m[0] + k):
        for c in range(m[1], m[1] + k):
            if (r, c) in out or (r, c) in corners:
                continue                      # 我自己那四个角：只有内画四角的框会正好扣在这儿，单帧读不出来
            v = ground_color(prev, (r, c))
            if v is not None:
                out[(r, c)] = v
    return out
