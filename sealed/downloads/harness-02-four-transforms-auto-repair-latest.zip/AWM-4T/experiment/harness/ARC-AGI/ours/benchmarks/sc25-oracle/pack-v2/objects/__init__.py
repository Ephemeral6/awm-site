"""这一局的**对象层**。一个文件一个类，按「它在这一帧里是什么」收进子文件夹。

    objects/
      parse.py        唯一碰像素的地方（留在根上，它最该显眼）
      world.py        World —— 一帧里读得出来的全部状态
      player/         我
      panel/          屏幕边上那几块版面：大面板、小面板、竖条
      ground/         场地上的东西：地板、记号、实心块、燃料、插座

契约（装置按名字找）：`World`（dataclass）/ `parse(frame) -> World` / `ParseError`。
"""
from __future__ import annotations

from .parse import ParseError, parse, parse_action          # noqa: F401
from .world import World                                   # noqa: F401

__all__ = ["World", "parse", "ParseError", "parse_action", "read"]


def read(frame):
    """帧 → World；读不成返回 None（规则拿到 None 就闭嘴，这一帧归「读不成世界」那一档）。

    **`parse` 在调用时按本模块的全局名现取**：字段消融会把 `objects.parse` 换掉，
    换掉之后这里当场用上新的那个。规则层 `from objects import read` 不怕这个坑——
    被换的是 `parse`，不是 `read`。
    """
    try:
        return parse(frame)
    except ParseError:
        return None
