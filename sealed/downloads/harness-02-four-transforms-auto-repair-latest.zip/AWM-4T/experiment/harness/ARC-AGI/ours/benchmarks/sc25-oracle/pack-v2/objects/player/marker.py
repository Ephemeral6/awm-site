"""`Marker` —— 我：一块正方形，一半「脸」色一半「背」色，脸朝哪边就是朝向。

它记四件事：左上角（行、列）、边长、朝向。

## 为什么删不掉（每一位都要答）

  row / col  —— 同一张盘上两个位置不同的我，走同一步会撞上不同的墙。
  side       —— 边长 4 与 2 的我，同一个动作走的格数不同、塞得进的洞不同（见 analysis/Marker.txt）。
  face       —— 朝向决定「抹除」那台机器瞄的是哪个框；方向键只转向不挪窝时，只有它变。

## 不存什么

  身下压着什么 —— 帧上看不见（被我盖住了），**表示不出来的就不存**。
  要知道底下是什么，只能等我走开；那是模型那一侧（Lean 的 `Board`）按整关拼出来的，
  口径写在 `lean2/Obs/Replay.lean` 的文件头。
"""
from __future__ import annotations

from dataclasses import dataclass

# 朝向 → 单位位移（行, 列）。方向动作 1/2/3/4 = 上/下/左/右。
STEP = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}


@dataclass(frozen=True)
class Marker:
    row: int
    col: int
    side: int
    face: str          # "U" / "D" / "L" / "R"：脸那一半压在哪一侧

    def cells(self) -> frozenset:
        """我占的格。"""
        return frozenset((r, c) for r in range(self.row, self.row + self.side)
                         for c in range(self.col, self.col + self.side))

    def face_cells(self) -> frozenset:
        """脸那一半占的格（朝向那一侧的半边）。"""
        k, h = self.side, self.side // 2
        out = set()
        for r in range(k):
            for c in range(k):
                if ((self.face == "U" and r < h) or (self.face == "D" and r >= h)
                        or (self.face == "L" and c < h) or (self.face == "R" and c >= h)):
                    out.add((self.row + r, self.col + c))
        return frozenset(out)
