# 对象层 / 规则层契约（field_split.py 与 criteria_run.py 认的那一套）

把 `tools_v7/` 整个拷成跑场根下的 `tools/`，在跑场根上跑：

```bash
python tools/field_split.py  objects transitions.jsonl            [--json out.json]
python tools/criteria_run.py objects rule transitions.jsonl       [--json out.json] [--analysis analysis]
```

只用标准库。不加 `--analysis` 就什么都不往跑场里写（也不写 `__pycache__`）。

## 一、`objects/`：帧 → 世界

| 名字 | 在哪 | 是什么 |
|---|---|---|
| `World` | `objects/world.py`，经 `objects/__init__.py` 导出 | `@dataclass(frozen=True)`；**字段就是对象**，字段值要可比较（int / str / tuple / frozenset…） |
| `parse(frame) -> World` | `objects/parse.py` | **唯一碰像素的地方**。帧 = 行的列表，每行是整数列表（`frame[y][x]`）。读不出来**抛** `ParseError`，别返回 None |
| `ParseError` | `objects/parse.py` | 「这一帧读不成世界」。一张空帧 `[]` 必须抛（变异测试拿它当必拒的那一个） |

规则拿世界要**经 `objects` 的模块全局名现取 `parse`**（`from objects import parse`，或在 `objects/__init__.py` 里写一个
`read(frame)` 去调 `parse`）。消融会把 `objects.parse` 换掉再重新导入 `rule/`（以及跑场根下除 `objects/` 以外的模块）；
在 `objects/` 的**别的子模块**里 `from .parse import parse` 绑走的那份换不到——消融自检会把这种规则点名报出来。

## 二、`rule/`：一条规则一个文件，按「它管什么」分子文件夹

```
rule/<组>/<规则>.py      文件名就是规则名（不许重名）；以 _ 开头的文件（_common.py、_scope.py）不是规则
```

每个规则文件两个函数（ctx 可省，三参也认）：

```python
def scope_(prev, action, nxt, ctx=None):   # None = 这一步我管；一句非空的理由 = 我不管（记 NA）
def assert_(prev, action, nxt, ctx=None):  # 只许返回 "TRUE" / "FALSE" / "NA"；别的值或抛异常记 ERROR
```

* `prev` / `nxt` 是**帧**；`action` 是 play.py 记的字符串（`"ACTION1"`、`"ACTION6:x,y"`、`"RESET"`）；`ctx` 是那一行的 `ctx` 原样
  （`level_prev` / `level_next` / `state_next` / `levels_completed`）。
* 理由里写「读不成世界」的 NA 记进 U；写「→ 规则名」（多个用 `/` 隔开）的，会去核那条规则在那些步上开没开口。
* 可选：`CLAIM = "一句人话"`（读数表里照抄）。

## 三、最小的例子

```python
# objects/world.py
from dataclasses import dataclass
@dataclass(frozen=True)
class World:
    n_one: int          # 第 1 行往下值为 1 的格数
    top: tuple          # 第 0 行

# objects/parse.py
from .world import World
class ParseError(Exception): ...
def parse(frame):
    if not frame or len(frame) < 2:
        raise ParseError("少于两行")
    return World(n_one=sum(v == 1 for r in frame[1:] for v in r), top=tuple(frame[0]))

# objects/__init__.py
from .parse import ParseError, parse
from .world import World
def read(frame):
    try:
        return parse(frame)          # 按全局名现取：消融换掉 objects.parse 时这里跟着换
    except ParseError:
        return None

# rule/计数/one_adds.py
from objects import read
def scope_(prev, action, nxt, ctx=None):
    if action != "ACTION1":
        return "不是 ACTION1"
    if read(prev) is None or read(nxt) is None:
        return "读不成世界"
    return None
def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(nxt).n_one == read(prev).n_one + 1 else "FALSE"
```

完整可跑的一份在 `selftest/`（`python selftest/run_selftest.py`）。
