# -*- coding: utf-8 -*-
"""Write out, verbatim, every text a phase-2 (l4s) subject receives, from the same code paths the run uses.

    python -I export_prompts.py [--arena D:/arc-arena/l4s-case-672e2a]   ->  prompts/  +  prompts/MANIFEST.json

Sources (nothing is retyped):
- files the subject finds in its arena: README.md, _FIRST_MESSAGE.txt, METHOD.md, .claude/settings.local.json,
  taken from the staged arena (default: the pre-run baseline snapshot armkit/baseline/<case>/ that build.py makes);
- the messages the driver sends, built by armkit-v2/run_v2.py itself with the flags the queue uses (no --closed,
  --rigor, --decide or --replay-gate): run_v2.round_ask("framework"), run_v2.final_ask("framework"),
  run_v2.KEEP_PLAYING and run_v2.GATE_RETRY (templates; the driver fills in the %s).
The MANIFEST records each file's md5 and where it came from, plus the md5s run_v2 itself logs as `ask_md5`.
"""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = Path(str(Path(__file__).resolve().parents[2] / "benchmarks")) / "armkit-v2"      # (folder moved to ours/sc25-selfaudit-phase2 on 2026-10-21)
ARMKIT = V2.parent / "armkit"
sys.path.insert(0, str(V2))
sys.path.insert(0, str(ARMKIT))
import run_v2 as R                         # noqa: E402


def md5(b: bytes) -> str:
    return hashlib.md5(b).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="l4s-case-672e2a")
    ap.add_argument("--out", default="prompts")
    a = ap.parse_args()
    base = ARMKIT / "baseline" / a.case
    src = base if base.exists() else Path(__import__("os").environ.get("AWM_STAGE", "D:/arc-arena")) / a.case
    out = HERE / a.out
    out.mkdir(exist_ok=True)
    man = {"source_arena": str(src), "flags": "run_v2 --selfaudit-gate --skeptic-gate, without --closed/--rigor/--decide/--replay-gate "
                                              "(as harness/run_one.py starts it)", "files": {}}
    for name, rel in [("00_README_service.md", "README.md"), ("01_FIRST_MESSAGE.txt", "_FIRST_MESSAGE.txt"),
                      ("02_METHOD.md", "METHOD.md"), ("09_settings.local.json", ".claude/settings.local.json")]:
        p = src / rel
        shutil.copy2(p, out / name)
        man["files"][name] = {"md5": md5(p.read_bytes()), "from": "arena:" + rel}
    for name, text, frm in [
        ("03_ROUND_ASK.txt", R.round_ask("framework"), "run_v2.round_ask('framework') - sent after every attempt"),
        ("04_FINAL_ASK.txt", R.final_ask("framework"), "run_v2.final_ask('framework') - sent once at the end"),
        ("05_KEEP_PLAYING.template.txt", R.KEEP_PLAYING,
         "run_v2.KEEP_PLAYING - sent (max 3x) if an attempt stops before GAME_OVER; %s = state, level"),
        ("06_GATE_RETRY.template.txt", R.GATE_RETRY,
         "run_v2.GATE_RETRY - sent (max 1x) if the round's formalization gate fails; %s = the gate's reasons"),
        ("07_SELFAUDIT_MISSING.txt", R.SA_MISSING,
         "run_v2.SA_MISSING (--selfaudit-gate) - sent (max 1x) when the audit is due and work/selfaudit/pass1.md is missing"),
        ("08_SELFAUDIT_STALE.txt", R.SA_STALE,
         "run_v2.SA_STALE (--selfaudit-gate) - sent (max 1x) in a later round when work/selfaudit/ did not change"),
        ("10_SKEPTIC.txt", R.SA_SKEPTIC,
         "run_v2.SA_SKEPTIC (--skeptic-gate) - sent after every interview whose verdict is in the impossible family, except after the last attempt"),
    ]:
        (out / name).write_text(text, encoding="utf-8", newline="\n")
        man["files"][name] = {"md5": md5(text.encode("utf-8")), "from": frm}
    man["run_v2_ask_md5"] = {"round": md5(R.round_ask("framework").encode("utf-8")),
                             "final": md5(R.final_ask("framework").encode("utf-8"))}
    (out / "MANIFEST.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    for k, v in man["files"].items():
        print("%-32s %s  %s" % (k, v["md5"][:12], v["from"]))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
