"""过关那一步竖条回满——整局通关那一步除外（没有下一关，也就没有下一关的预算）。"""
from __future__ import annotations

from objects import read

CLAIM = "上游关号变了、而且这一步之后不是整局通关：下一帧竖条 64 行全满。"
SCOPE = "关号没变、上游说这一步之后整局赢了、RESET（→ reset_restores）、下一帧读不成世界，不管。"
NOT_CLAIMED = ["不说新关的开局长什么样"]
NOTE = ["起点：册子 level_up_refills_bar v2（第 250 步：最后一关踏进插座，竖条不回满——那一下没有下一关）。"]
EVIDENCE = ["9dabb54dca80d95d", "fca17365c9aa8fc6"]


def scope_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "ctx 缺关号"
    if ctx["level_prev"] == ctx["level_next"]:
        return "没换关"
    if action == "RESET":
        return "RESET → reset_restores"
    if ctx.get("state_next") == "WIN":
        return "整局通关那一步"
    if read(nxt) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(nxt).bar.rows == 64 else "FALSE"
