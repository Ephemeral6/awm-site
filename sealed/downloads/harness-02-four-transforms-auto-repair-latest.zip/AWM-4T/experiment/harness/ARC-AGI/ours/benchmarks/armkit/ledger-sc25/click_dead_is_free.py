"""点空是免费的：一条 ACTION6 若没改动竖条以外的任何格子，整帧就一格不变——连预算尺都不走。"""
LEVEL = "L4"
SCOPE = "只看 ACTION6；方向键返回 NA"
NOTE = "这条是 bar_rate 从等号退成不等号的原因：预算尺量的是「被接受的动作」，空点击不算一条。"
EVIDENCE = ["6900c748911db55b", "a58dabe7ec5e29d9"]

from _lib import BAR_COLS


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    off_bar = any(prev[r][c] != nxt[r][c]
                  for r in range(len(prev)) for c in range(len(prev[0]))
                  if c not in BAR_COLS)
    if off_bar:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"
