# -*- coding: utf-8 -*-
"""Run the level-5 v7f runs one after another (or a few at a time), with the two helper processes restarted for every
run, then collect a first grade for each. Same per-run command as the 6/6 batch on the original machine:
run_one.py --new --level 5 --port P --allow-concurrent (v7f: --selfaudit-gate --skeptic-gate --cards-gate cards_v7f
--proof-gate, 8 attempts, --win-level 5).

    python -I run_batch_l5.py --dry-run                       # print the plan, start nothing
    python -I run_batch_l5.py                                 # 3 runs, ports 9301-9303, one at a time
    python -I run_batch_l5.py --n 3 --ports 9301 9302 9303 --max-concurrent 2 --free-gb 10

- starts a run only while fewer than --max-concurrent level-5 run_one.py are alive and free RAM >= --free-gb
  (one level-5 subject's Lean tables reached about 10 GB; with < 48 GB RAM keep --max-concurrent 1);
- a port that is already listening is skipped (a second server on a busy port would talk to the wrong game);
- 90 s after each start it (re)starts orphan_watchdog.py and lean_tracker.py if they are not running
  (they exit by themselves whenever no run_one.py is left);
- when every run has ended: grade_one.py --case <case> for each (the independent rebuild of the main theorem needs the
  theorem name from the last interview, so run grade_one.py --rebuild by hand afterwards, see README section 4).
Log: runs/batch_l5.log; each run's own output: runs/run_one_L5_<port>.out, runs/<case>.log.
"""
import argparse
import re
import socket
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
ARMKIT = HERE.parent.parent / "benchmarks" / "armkit"
sys.path.insert(0, str(ARMKIT))
import completion_round as CR          # noqa: E402  (avail_gb)

LOG = RUNS / "batch_l5.log"


def log(msg):
    line = "[%s] %s" % (time.strftime("%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def cmdlines():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ForEach-Object { $_.CommandLine }"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.stdout.splitlines()


def n_l5():
    return sum(1 for c in cmdlines() if "run_one.py" in c and "--level 5" in c)


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def helpers():
    cl = cmdlines()
    for name in ("orphan_watchdog.py", "lean_tracker.py"):
        if not any(name in c for c in cl):
            p = subprocess.Popen([sys.executable, "-I", str(HERE / name)], cwd=str(HERE),
                                 stdout=open(RUNS / (name[:-3] + ".out"), "a", encoding="utf-8"),
                                 stderr=subprocess.STDOUT, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            log("helper %s started, pid %d" % (name, p.pid))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=3)
    ap.add_argument("--ports", type=int, nargs="*", default=[9301, 9302, 9303, 9304, 9305, 9306])
    ap.add_argument("--max-concurrent", type=int, default=1)
    ap.add_argument("--free-gb", type=float, default=10.0)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    RUNS.mkdir(exist_ok=True)
    queue = [p for p in a.ports if port_free(p)][:a.n]
    if len(queue) < a.n:
        raise SystemExit("only %d free ports among %s" % (len(queue), a.ports))
    log("L5 batch: %d runs on ports %s, at most %d at a time, start when >= %.0f GB free"
        % (a.n, queue, a.max_concurrent, a.free_gb))
    if a.dry_run:
        r = subprocess.run([sys.executable, "-I", str(HERE / "run_one.py"), "--new", "--level", "5", "--port",
                            str(queue[0]), "--dry-run"], capture_output=True, text=True, encoding="utf-8", errors="replace")
        print(r.stdout)
        return 0
    procs = []
    while queue:
        if n_l5() < a.max_concurrent and CR.avail_gb() >= a.free_gb:
            port = queue.pop(0)
            if not port_free(port):
                log("port %d became busy, skipped" % port)
                continue
            out = RUNS / ("run_one_L5_%d.out" % port)
            p = subprocess.Popen([sys.executable, "-I", str(HERE / "run_one.py"), "--new", "--level", "5", "--port",
                                  str(port), "--allow-concurrent"], cwd=str(ARMKIT),
                                 stdout=open(out, "w", encoding="utf-8"), stderr=subprocess.STDOUT)
            procs.append((port, p, out))
            log("started L5 :%d pid %d -> %s" % (port, p.pid, out.name))
            time.sleep(90)
            helpers()
            time.sleep(30)
        else:
            time.sleep(60)
    cases = []
    for port, p, out in procs:
        while p.poll() is None:
            time.sleep(300)
            helpers() if n_l5() else None
        m = re.search(r"^case\s+(\S+)", out.read_text(encoding="utf-8", errors="replace"), re.M)
        case = m.group(1) if m else None
        log("finished L5 :%d rc %s case %s" % (port, p.returncode, case))
        if case:
            cases.append(case)
    for case in cases:
        r = subprocess.run([sys.executable, "-I", str(HERE / "grade_one.py"), "--case", case],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        log("grade_one %s rc %s; %s" % (case, r.returncode, (r.stdout.strip().splitlines() or [""])[-1][:200]))
    log("L5 batch done: %s" % cases)
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())
