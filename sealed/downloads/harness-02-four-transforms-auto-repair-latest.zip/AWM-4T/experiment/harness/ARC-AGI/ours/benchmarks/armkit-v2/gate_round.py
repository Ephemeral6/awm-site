# -*- coding: utf-8 -*-
"""这一轮**算不算完成**：一道**可满足**的闸。

    python gate_round.py --before r3.json --after r4.json --answer ans.txt

## 闸的内容

```
这一轮完成  ⇔  (A) 形式化系统**动过**（规则层或 Lean 有新增/改动/删除）
                 且 新写/改过的 .lean 都编得过、公理表干净
            或 (B) 明写「这一轮形式化系统没有变化」**并给出理由**
                 —— 标记行 `FORMAL-UNCHANGED:` 后面至少 80 个字
```

## 为什么一定要留 (B) 这条出路

我们栽过一次：设了一道**原理上不可满足**的闸（「必须见过门接受一次」，
而那是一张不可解的盘，永远满足不了）⇒ 框架臂只剩交 giveup 一条路，
那一轮的读数等于没有。

这里同样的风险是：某一轮它确实没有新发现 —— 盘没走到新的地方、规则一条没推翻。
这时逼它改形式化系统，只会逼出**为改而改**的噪声，把「逐轮收敛」这条曲线弄脏。
所以 (B) 是合法的，但要它**明说并说明理由** —— 「没变化」本身也是读数。

## 它不查什么

不查 Lean 证的对不对、也不查规则层和 Lean 对不对得上（那是 `correspond.py`，
**只报不拦**）。这道闸只回答一个问题：**这一轮它到底有没有在形式化系统上工作。**
"""
from __future__ import annotations

import argparse
import io
import json
import sys
from pathlib import Path

import formal_state as FS

MARK = "FORMAL-UNCHANGED:"
MIN_WHY = 80
DIRTY = ("sorryAx", "ofReduceBool", "trustCompiler", "native_decide")


def why_len(answer: str) -> int:
    i = answer.find(MARK)
    if i < 0:
        return -1
    return len(answer[i + len(MARK):].strip())


def judge(d: dict, answer: str, lean_report: dict | None = None) -> dict:
    out = {"touched": d["touched"], "rules_touched": d["rules_touched"],
           "lean_touched": d["lean_touched"], "route": None, "ok": False,
           "reasons": []}

    # —— 路线 A：动过 ——
    if d["touched"] > 0:
        out["route"] = "A"
        bad = []
        for f in (lean_report or {}).get("files", []):
            if not f.get("compiles"):
                bad.append("%s 编不过" % f.get("file"))
                continue
            ax = " ".join(f.get("axiom_lines") or [])
            hit = [k for k in DIRTY if k in ax]
            if hit:
                bad.append("%s 公理表里有 %s" % (f.get("file"), "/".join(hit)))
        if bad:
            out["reasons"] = bad
        else:
            out["ok"] = True
        return out

    # —— 路线 B：没动，但明说并说明理由 ——
    out["route"] = "B"
    n = why_len(answer or "")
    if n < 0:
        out["reasons"] = [u"形式化系统一处没动，回答里也没有 `%s` 这一行" % MARK]
    elif n < MIN_WHY:
        out["reasons"] = [u"`%s` 后面只有 %d 个字，少于 %d" % (MARK, n, MIN_WHY)]
    else:
        out["ok"] = True
    return out


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--before", required=True, help="上一轮的 formal_state snap")
    ap.add_argument("--after", required=True, help="这一轮的 formal_state snap")
    ap.add_argument("--answer", help="这一轮追问的回答全文（查 B 路线的标记行）")
    ap.add_argument("--lean-report", help="台架编 Lean 的结果 json（查 A 路线的干净度）")
    a = ap.parse_args(argv)

    d = FS.diff(json.loads(Path(a.before).read_text(encoding="utf-8")),
                json.loads(Path(a.after).read_text(encoding="utf-8")))
    ans = Path(a.answer).read_text(encoding="utf-8", errors="replace") if a.answer else ""
    rep = json.loads(Path(a.lean_report).read_text(encoding="utf-8")) if a.lean_report else None
    r = judge(d, ans, rep)

    print("这一轮动了 %d 处（规则层 %d · Lean %d）→ 走 %s 路线"
          % (r["touched"], r["rules_touched"], r["lean_touched"], r["route"]))
    print("闸：%s" % ("**过**" if r["ok"] else "**没过**"))
    for x in r["reasons"]:
        print("  ✗ %s" % x)
    if r["ok"] and r["route"] == "B":
        print("  （合法出路：它明说了这一轮形式化系统没变化，并给了理由）")
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
