"""按 ACTION2：第 0 行整体左移一格（首格绕到尾），下面的盘面不变。"""
from __future__ import annotations

from objects import read

from .._scope import unreadable

CLAIM = "按 ACTION2：第 0 行左移一格、首格绕到尾；值为 1 的格子数不变。"
EVIDENCE = []


def scope_(prev, action, nxt, ctx=None):
    if action != "ACTION2":
        return "不是 ACTION2"
    return unreadable(read(prev), read(nxt))


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    ok = nw.top == w.top[1:] + w.top[:1] and nw.n_one == w.n_one
    return "TRUE" if ok else "FALSE"
