/-
# 三台机器的分发（对应 rule/machines/__init__.py）

凑齐的是哪一块小面板的图案，就动哪一台：认机器靠记号色（`Obj/Derive/Machines.lean`）。
别的色（语料里 0 次）：什么也不动。
-/

import Obj.Model.St
import Rule.Machines.Resize
import Rule.Machines.Teleport
import Rule.Machines.Erase

namespace Game

def machine (b : Board) (s : St) (c : Nat) : St :=
  if c == RESIZE then resize b s
  else if c == TELEPORT then teleport b s
  else if c == ERASE then erase b s
  else s

end Game
