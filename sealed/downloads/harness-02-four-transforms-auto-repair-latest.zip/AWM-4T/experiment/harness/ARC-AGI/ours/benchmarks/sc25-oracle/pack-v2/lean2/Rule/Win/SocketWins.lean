/-
# socket_wins —— 过关（对应 rule/outcome/socket_wins.py）

**定义，不是定理。** 「赢」是一个**状态**性质：我整块站在插座内胆上。
方向键的前方方区整块是内胆，那一步就整块挪进去——下一个状态满足 `isGoal`。

Python 那一侧的说法是「上游的关号 +1 当且仅当整块踏进内胆」：关号是现实那一侧的信号，
模型这一侧没有关号，只有 `isGoal`。两边在「每一关的最后一步」上对账（Levels.lean 的 `_winnable`）。
-/

import Obj.Model.Render

namespace Game

def intoSocket (b : Board) (s : St) (f : Face) : Option (Nat × Nat) :=
  match ahead s.me f with
  | none => none
  | some (r, c) =>
    let pic := render b s
    if (square r c s.me.side).all (fun p => colorAt pic p == SOCKET) then some (r, c) else none

def isGoal (b : Board) (s : St) : Bool :=
  s.me.cells.all (fun p => colorAt b.base p == SOCKET)

end Game
