# -*- coding: utf-8 -*-
"""**Lean 重放闸**（2026-10-20 加；`run_v2.py --replay-gate` 才用，默认关）。

## 为什么

现行闸（`gate_round.py`）只查「形式化系统动过 + 新 .lean 编得过 + 公理干净」；
`correspond.py` 只报不拦。证明所在的 Lean 模型是否对得上**受试自己记录过的转移**，台架从来不核。
l5d 批三条的最终模型事后重放全对（`l5/replay_obs_l5d.py`），但那是碰巧，不是台架保证的。

## 受试要维护的两样东西（写在 METHOD 的附加节 `METHOD_addendum_replay.md` 里）

```
work/abstract.py      state(frame) -> str             一帧 → 它 Lean 模型里状态的字面量
                      action(name, prev, nxt) -> str   一个动作 → 它 Lean 模型里动作的字面量，或 "STUTTER"
lean/ReplaySpec.lean  ReplaySpec.S / ReplaySpec.A / ReplaySpec.step : S → A → S / ReplaySpec.proj : S → P（P 有 DecidableEq）
```

## 台架每轮做什么

```
1 选转移    transitions.jsonl 里 ctx.level_prev == ctx.level_next == 本轮所在关、且 state_next 不是 GAME_OVER / WIN 的全部
            （让一局结束的那一步各家预算语义不同，不进闸；这一条写在 METHOD 附加节里）
2 抽象      台架自己的 runner（python -I）import 受试的 work/abstract.py，**逐条**调用 —— 受试删不了数据
            任何一条抛异常 / 返回非字符串 ⇒ 记作「读不出」，闸不过
3 生成数据  lean/ReplayData.lean（台架写，每轮覆盖）：steps = [(s, a, s')]，stutters = [(s, s')]，按 200 条分块
4 核        lean/ReplayCheck.lean（台架写）：每块一条定理，decide +kernel：
              steps.all  (fun (s,a,t) => decide (proj (step s a) = proj t))
              stutters.all (fun (s,t) => decide (proj s = proj t))
            另用 lean --run 求出哪几条对不上（失败时给受试的 tid 清单）
5 判        全部定理编得过、公理干净 ⇒ 过；否则不过，失败的 tid 与原因发回，补问次数同现行闸
6 存档      每轮把 lean/ concepts/ work/*.md 复制到 <out>_rounds/<case>/r<k>/（中间各版事后可审）
```

## 已知局限（照实写进读数）

受试的 `proj` / `abstract.py` 可能写得太粗（把所有帧映成同一状态也能过）。台架每轮报
「不同 proj 值的个数」与「STUTTER 占比」两个数，事后再用引擎侧重放（`l5/replay_obs_l5d.py` 的做法）兜底审。
这道闸保证「模型不和已有证据矛盾」，挡不住「在没观察过的地方概括错」（l5d-977714 的 R-col）。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

LEAN = os.path.join(os.path.expanduser("~"), ".elan", "toolchains", "leanprover--lean4---v4.34.1", "bin", "lean.exe")
CHUNK = 200
DIRTY = ("sorryAx", "ofReduceBool", "trustCompiler", "native_decide")

RUNNER = r'''
import importlib.util, json, sys, traceback
arena, rows_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
spec = importlib.util.spec_from_file_location("abstract_subject", arena + "/work/abstract.py")
m = importlib.util.module_from_spec(spec)
sys.path.insert(0, arena + "/work")
spec.loader.exec_module(m)
out = []
for r in json.load(open(rows_path, encoding="utf-8")):
    try:
        s = m.state(r["prev"]); a = m.action(r["action"], r["prev"], r["nxt"]); t = m.state(r["nxt"])
        ok = all(isinstance(x, str) and x.strip() for x in (s, a, t))
        out.append({"tid": r["tid"], "s": s, "a": a, "t": t} if ok else {"tid": r["tid"], "err": "non-string or empty"})
    except Exception as e:
        out.append({"tid": r["tid"], "err": (type(e).__name__ + ": " + str(e))[:300]})
json.dump(out, open(out_path, "w", encoding="utf-8"))
'''


def snapshot(d: Path, dst: Path) -> int:
    """lean/*.lean、concepts/*.py、work/*.md 原样复制到 dst。返回文件数。"""
    n = 0
    for sub, pat in (("lean", "*.lean"), ("concepts", "*.py"), ("work", "*.md"), ("work", "abstract.py")):
        src = d / sub
        if not src.exists():
            continue
        for f in src.glob(pat):
            if f.is_file():
                (dst / sub).mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dst / sub / f.name)
                n += 1
    return n


def select(d: Path, level: int) -> list:
    rows = []
    p = d / "transitions.jsonl"
    if not p.exists():
        return rows
    for line in p.open(encoding="utf-8"):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        c = r.get("ctx") or {}
        if c.get("level_prev") == level and c.get("level_next") == level and c.get("state_next") not in ("GAME_OVER", "WIN"):
            rows.append(r)
    return rows


def _lean(args, cwd, timeout):
    try:
        p = subprocess.run([LEAN] + args, cwd=cwd, env=dict(os.environ, LEAN_PATH=str(cwd)), capture_output=True,
                           text=True, encoding="utf-8", errors="replace", timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -9, "timeout after %ds" % timeout


def _imports(f: Path):
    import re
    return re.findall(r"^import\s+(\S+)", f.read_text(encoding="utf-8", errors="replace"), re.M)


def _build_deps(lean_dir: Path, mod: str, timeout: int, seen=None):
    """按依赖顺序把 mod 及其 import 编成 .olean（只在 lean/ 一个根里找）。返回 (ok, 记录)。"""
    seen = set() if seen is None else seen
    log = []
    f = lean_dir / (mod + ".lean")
    if mod in seen or not f.exists():
        return True, log
    seen.add(mod)
    for dep in _imports(f):
        ok, l2 = _build_deps(lean_dir, dep, timeout, seen)
        log += l2
        if not ok:
            return False, log
    rc, out = _lean(["-o", mod + ".olean", mod + ".lean"], lean_dir, timeout)
    log.append({"module": mod, "rc": rc, "tail": out[-800:]})
    return rc == 0 and "error" not in out.lower(), log


def check(d: Path, level: int, timeout: int = 1200, tmp: Path | None = None, keep: Path | None = None) -> dict:
    """跑一次重放闸。返回 dict（ok、计数、失败清单、原因）。

    tmp   台架自己的临时目录（runner、抽象结果）—— 放在跑场**外面**，不进受试的形式化快照
    keep  生成的 ReplayData/ReplayCheck 复制到这里存档；跑场里的那两份核完就删
          （它们在 lean/ 下，不删的话会被 formal_state 当成受试的改动，污染现行闸的「动过」）
    """
    try:
        return _check(d, level, timeout, tmp or (d.parent / ("_replay_gate_" + d.name)), keep)
    finally:
        for n in ("ReplayData", "ReplayCheck"):
            for ext in (".lean", ".olean", ".ilean"):
                f = d / "lean" / (n + ext)
                if f.exists():
                    if keep is not None and ext == ".lean":
                        keep.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(f, keep / f.name)
                    f.unlink()


def _check(d: Path, level: int, timeout: int, tmp: Path, keep) -> dict:
    res = {"level": level, "ok": False, "reasons": [], "n_rows": 0, "n_steps": 0, "n_stutters": 0,
           "unreadable": [], "mismatch": [], "n_distinct_proj": None}
    rows = select(d, level)
    res["n_rows"] = len(rows)
    lean_dir = d / "lean"
    if not (d / "work" / "abstract.py").exists():
        res["reasons"].append("work/abstract.py is missing")
    if not (lean_dir / "ReplaySpec.lean").exists():
        res["reasons"].append("lean/ReplaySpec.lean is missing")
    if res["reasons"]:
        return res
    if not rows:
        res.update(ok=True, note="no recorded transitions on this level yet")
        return res
    tmp.mkdir(parents=True, exist_ok=True)
    (tmp / "rows.json").write_text(json.dumps([{k: r[k] for k in ("tid", "action", "prev", "nxt")} for r in rows]),
                                   encoding="utf-8")
    (tmp / "runner.py").write_text(RUNNER, encoding="utf-8")
    try:
        p = subprocess.run([sys.executable, "-I", str(tmp / "runner.py"), str(d), str(tmp / "rows.json"),
                            str(tmp / "abs.json")], cwd=str(d), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
    except subprocess.TimeoutExpired:
        res["reasons"].append("work/abstract.py took longer than 600 s")
        return res
    if p.returncode != 0 or not (tmp / "abs.json").exists():
        res["reasons"].append("work/abstract.py could not be run: " + ((p.stderr or "")[-600:]))
        return res
    ab = json.loads((tmp / "abs.json").read_text(encoding="utf-8"))
    res["unreadable"] = [{"tid": x["tid"], "why": x["err"]} for x in ab if "err" in x]
    good = [x for x in ab if "err" not in x]
    steps = [x for x in good if x["a"].strip() != "STUTTER"]
    stut = [x for x in good if x["a"].strip() == "STUTTER"]
    res["n_steps"], res["n_stutters"] = len(steps), len(stut)
    # ---- ReplayData.lean（台架写，每轮覆盖）----
    def chunks(xs):
        return [xs[i:i + CHUNK] for i in range(0, len(xs), CHUNK)] or [[]]
    sc, tc = chunks(steps), chunks(stut)
    L = ["import ReplaySpec", "/-! Generated by the harness every round from transitions.jsonl via work/abstract.py. Do not edit. -/", "", "namespace ReplayData", "open ReplaySpec", ""]
    for i, c in enumerate(sc):
        L.append("def steps%d : List (S × A × S) := [" % i)
        L.append(",\n".join("  ((%s), (%s), (%s))" % (x["s"], x["a"], x["t"]) for x in c))
        L.append("]")
    for i, c in enumerate(tc):
        L.append("def stutters%d : List (S × S) := [" % i)
        L.append(",\n".join("  ((%s), (%s))" % (x["s"], x["t"]) for x in c))
        L.append("]")
    L.append("def tids_steps : List String := [%s]" % ", ".join(json.dumps(x["tid"]) for x in steps))
    L.append("def tids_stutters : List String := [%s]" % ", ".join(json.dumps(x["tid"]) for x in stut))
    L += ["", "end ReplayData", ""]
    (lean_dir / "ReplayData.lean").write_text("\n".join(L), encoding="utf-8", newline="\n")
    C = ["import ReplayData", "/-! Written by the harness. Do not edit. -/", "", "namespace ReplayCheck",
         "open ReplaySpec ReplayData", ""]
    names = []
    for i in range(len(sc)):
        C.append("theorem steps_ok_%d : (steps%d.all fun x => decide (proj (step x.1 x.2.1) = proj x.2.2)) = true := by decide +kernel" % (i, i))
        names.append("ReplayCheck.steps_ok_%d" % i)
    for i in range(len(tc)):
        C.append("theorem stutters_ok_%d : (stutters%d.all fun x => decide (proj x.1 = proj x.2)) = true := by decide +kernel" % (i, i))
        names.append("ReplayCheck.stutters_ok_%d" % i)
    C += ["", "end ReplayCheck", ""] + ["#print axioms %s" % n for n in names] + [""]
    (lean_dir / "ReplayCheck.lean").write_text("\n".join(C), encoding="utf-8", newline="\n")
    # ---- 编译 ----
    ok_deps, blog = _build_deps(lean_dir, "ReplayData", timeout)
    res["build"] = blog
    if not ok_deps:
        res["reasons"].append("lean/ReplaySpec.lean or the generated lean/ReplayData.lean does not compile: "
                              + (blog[-1]["tail"] if blog else ""))
        return res
    rc, out = _lean(["ReplayCheck.lean"], lean_dir, timeout)
    res["check_rc"] = rc
    axioms_ok = ("depends on axioms" in out or "does not depend on any axioms" in out) and not any(x in out for x in DIRTY)
    proved = rc == 0 and "error" not in out.lower() and axioms_ok
    # ---- 失败清单（lean --run，逐条给出是哪一条）----
    R2 = ["import ReplayData", "open ReplaySpec ReplayData", "def main : IO Unit := do"]
    for i in range(len(sc)):
        R2.append("  for (x, j) in steps%d.zip (List.range steps%d.length) do" % (i, i))
        R2.append("    if !(decide (proj (step x.1 x.2.1) = proj x.2.2)) then IO.println s!\"BAD|step|%d|{j}\"" % i)
    for i in range(len(tc)):
        R2.append("  for (x, j) in stutters%d.zip (List.range stutters%d.length) do" % (i, i))
        R2.append("    if !(decide (proj x.1 = proj x.2)) then IO.println s!\"BAD|stutter|%d|{j}\"" % i)
    (lean_dir / "_ReplayDiag.lean").write_text("\n".join(R2) + "\n", encoding="utf-8", newline="\n")
    rc2, out2 = _lean(["--run", "_ReplayDiag.lean"], lean_dir, timeout)
    (lean_dir / "_ReplayDiag.lean").unlink(missing_ok=True)
    for l in out2.splitlines():
        if l.startswith("BAD|"):
            _, kind, ci, j = l.split("|")
            src = (sc if kind == "step" else tc)[int(ci)][int(j)]
            res["mismatch"].append({"tid": src["tid"], "kind": kind, "s": src["s"][:200], "a": src.get("a"),
                                    "t": src["t"][:200]})
    bad_steps = sum(1 for x in res["mismatch"] if x["kind"] == "step")
    bad_stut = sum(1 for x in res["mismatch"] if x["kind"] == "stutter")
    res["diag_rc"] = rc2
    res["n_distinct_state_literals"] = len({x["s"] for x in good} | {x["t"] for x in good})
    res["stutter_share"] = round(len(stut) / max(1, len(good)), 3)
    if res["unreadable"]:
        res["reasons"].append("%d recorded transitions could not be abstracted by work/abstract.py" % len(res["unreadable"]))
    if res["mismatch"] or not proved:
        res["reasons"].append("your model disagrees with %d recorded transitions (%d steps, %d stutters)%s"
                              % (len(res["mismatch"]) or (bad_steps + bad_stut), bad_steps, bad_stut,
                                 "" if proved else "; lean/ReplayCheck.lean was not proved"
                                 + ("" if rc == 0 else ": " + out[-600:])))
    res["ok"] = proved and not res["unreadable"] and not res["mismatch"]
    return res


def retry_text(res: dict, limit: int = 20) -> str:
    """闸不过时发回给受试的话：只有失败的 tid 和原因，不含任何别的信息。"""
    lines = ["The replay check of your Lean model against your recorded transitions on this level did not pass.", ""]
    for r in res["reasons"]:
        lines.append("- " + r)
    if res["unreadable"]:
        lines.append("")
        lines.append("Transitions work/abstract.py could not handle (tid: error):")
        lines += ["  %s: %s" % (x["tid"], x["why"]) for x in res["unreadable"][:limit]]
    if res["mismatch"]:
        lines.append("")
        lines.append("Transitions your model gets wrong (tid, kind):")
        lines += ["  %s (%s)" % (x["tid"], x["kind"]) for x in res["mismatch"][:limit]]
        if len(res["mismatch"]) > limit:
            lines.append("  ... and %d more" % (len(res["mismatch"]) - limit))
    lines += ["", "Fix your model (not the data, which the harness regenerates every round) so that it reproduces "
              "these transitions, then answer briefly. Do not replay the game."]
    return "\n".join(lines)
