"""Coverage/freshness gate; contents still require substantive review."""
import hashlib,json
from pathlib import Path
def source_hashes(d):
    result={}
    for top in ('objects','derive','rule','concepts','lean/Obj','lean/Rule'):
        for f in (d/top).rglob('*'):
            if f.is_file() and f.suffix in ('.py','.lean'):result[f.relative_to(d).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
    if (d/'lean/Step.lean').exists():result['lean/Step.lean']=hashlib.sha256((d/'lean/Step.lean').read_bytes()).hexdigest()
    return result
def check(d):
    d=Path(d);why=[]
    try:
        scope=json.loads((d/'analysis/refinement_scope.json').read_text(encoding='utf-8'))
        audit=json.loads((d/'analysis/full_rule_audit.json').read_text(encoding='utf-8'))
        receipt=json.loads((d/'analysis/rejection_after.json').read_text(encoding='utf-8'))
        paths={p.relative_to(d).as_posix() for p in (d/'rule').rglob('*.py') if not p.name.startswith('_')}
        rows=audit['rules'];names=[r['path'] for r in rows]
        if not paths or len(names)!=len(set(names)) or set(names)!=paths:why.append('full_rule_audit must cover every current rule exactly once')
        for row in rows:
            if row['status'] not in ('proof_dependency','irrelevant_with_reason') or len(row.get('reason','').strip())<20:why.append('unresolved/unsupported rule audit: '+row['path'])
        selected=scope['selected_rules'];deferred=scope['deferred_rules']
        if not selected or set(selected)&set(deferred) or set(selected)|set(deferred)!=paths:why.append('refinement_scope must partition the current rule book')
        if set(r['path'] for r in rows if r['status']=='proof_dependency')-set(selected):why.append('proof dependencies omitted from selected scope')
        hashes=source_hashes(d)
        if audit['source_sha256']!=hashes or receipt['source_sha256']!=hashes:why.append('audit/rejection receipt stale after model edits')
        corpus=hashlib.sha256((d/'transitions.jsonl').read_bytes()).hexdigest()
        if audit['corpus_sha256']!=corpus or receipt['corpus_sha256']!=corpus:why.append('audit/rejection receipt stale after new evidence')
        if not receipt.get('ok') or not receipt.get('compared_to'):why.append('missing successful before/after full rejection comparison')
    except (OSError,ValueError,KeyError,TypeError) as e:why.append('missing/invalid scoped-refinement or full-audit artifact: '+str(e))
    return dict(ok=not why,why=why,scope='Coverage/freshness only; reasons and model-to-game correspondence are not machine-proved.')
