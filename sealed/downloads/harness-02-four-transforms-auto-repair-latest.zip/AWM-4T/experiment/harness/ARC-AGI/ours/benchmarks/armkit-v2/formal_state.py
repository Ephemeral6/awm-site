# -*- coding: utf-8 -*-
"""形式化系统的**逐轮快照与 diff**。

    python formal_state.py snap <跑场> -o r3.json
    python formal_state.py diff r3.json r4.json

## 为什么要有它

上一批（cd82 / su15 十六条臂）里，「形式化系统」只以**最终跑场**的形式存在 ——
受试第 3 轮把 `Su15Reach2.lean` 改成 `Su15Reach3.lean` 这件事，读数里只剩一个
「这一轮新写/改了 1 份 .lean」的计数，改了**什么**没有留痕。

而「在上一轮的形式化上改」正是框架臂与裸臂的分野所在：
裸臂攒的是尝试次数，框架臂攒的应该是一个**逐轮收敛的形式化系统**。
那条收敛曲线不记下来，就没有凭据。

## 算哪些文件

```
concepts/**.py     规则层（受试自己写的，或 model 给的被它改过的）
model/**           对象层与规则层（framework_model 才有）
lean/**.lean       形式化（骨架 Skeleton*/Selftest 也算 —— 它们被实例化就是改动）
work/**.md         它自己的笔记（只记数，不进 diff 的正文）
```

**不算** `.olean`（编译产物）、`__pycache__`、`.lake`。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import sys
from pathlib import Path

TRACKED = (("concepts", "*.py"), ("model", "*"), ("lean", "*.lean"))
NOTES = ("work", "*.md")
SKIP = (".olean", ".pyc", ".lake", "__pycache__", ".git")


def _md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def snap(arena: Path) -> dict:
    out = {"files": {}, "notes": {}}
    for sub, pat in TRACKED:
        d = arena / sub
        if not d.exists():
            continue
        for f in sorted(d.rglob(pat)):
            if not f.is_file() or any(s in str(f) for s in SKIP):
                continue
            out["files"][str(f.relative_to(arena)).replace("\\", "/")] = _md5(f)
    d = arena / NOTES[0]
    if d.exists():
        for f in sorted(d.rglob(NOTES[1])):
            if f.is_file():
                out["notes"][str(f.relative_to(arena)).replace("\\", "/")] = _md5(f)
    out["n_files"] = len(out["files"])
    return out


def diff(a: dict, b: dict) -> dict:
    fa, fb = a.get("files", {}), b.get("files", {})
    added = sorted(k for k in fb if k not in fa)
    removed = sorted(k for k in fa if k not in fb)
    changed = sorted(k for k in fb if k in fa and fa[k] != fb[k])
    return {
        "added": added, "removed": removed, "changed": changed,
        "n_added": len(added), "n_removed": len(removed), "n_changed": len(changed),
        "touched": len(added) + len(removed) + len(changed),
        "lean_touched": len([k for k in added + changed + removed
                             if k.startswith("lean/")]),
        "rules_touched": len([k for k in added + changed + removed
                              if k.startswith(("concepts/", "model/"))]),
        "n_before": a.get("n_files", 0), "n_after": b.get("n_files", 0),
    }


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("snap"); s.add_argument("arena"); s.add_argument("-o", "--out")
    d = sub.add_parser("diff"); d.add_argument("before"); d.add_argument("after")
    a = ap.parse_args(argv)

    if a.cmd == "snap":
        r = snap(Path(a.arena))
        txt = json.dumps(r, ensure_ascii=False, indent=1)
        if a.out:
            Path(a.out).write_text(txt, encoding="utf-8", newline="\n")
            print("形式化系统 %d 份文件 → %s" % (r["n_files"], a.out))
        else:
            print(txt)
        return 0

    before = json.loads(Path(a.before).read_text(encoding="utf-8"))
    after = json.loads(Path(a.after).read_text(encoding="utf-8"))
    r = diff(before, after)
    print("形式化系统 %d → %d 份 · 这一轮动了 %d 处"
          % (r["n_before"], r["n_after"], r["touched"]))
    print("  规则层 %d 处 · Lean %d 处" % (r["rules_touched"], r["lean_touched"]))
    for k, name in (("added", "新增"), ("changed", "改动"), ("removed", "删掉")):
        for p in r[k]:
            print("  %s %s" % (name, p))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
