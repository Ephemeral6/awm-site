"""凑齐抹除色：从我身上射出一条单像素射线，第一个撞到的是标本就开火——那个标本色在场上每一格都变地板，框那一圈也变地板；撞到别的就空放，场上一格不动。我自己始终不动。"""
from __future__ import annotations

from derive.boxes import boxes, ring
from derive.machines import ERASE, machine
from derive.pad_hits import completes
from derive.ray import ray_first, specimen_cells, target_kind
from objects import parse_action, read

from .._common import flat, ground_diff
from .._scope import unreadable

CLAIM = ("凑齐抹除那块小面板的图案：从我身上朝我的朝向射出一条**单像素射线**"
         "（竖着打取我的左列、横着打取我的上行，从我的边界外一格起逐格推进），"
         "**开火当且仅当它第一个撞到的是标本**（扣在某个抹除色框里的实心块）；"
         "撞到墙、栅栏、别的实心块、或者出界 ⇒ **空放**，场上一格不动。"
         "开火时：那个标本色在场上的每一格都变地板；那个框外扩一圈里的记号与标本都变地板——"
         "唯独那一圈的**左上 2×2** 可以变成燃料。**露出来的是底下本来那样东西**——有地板露地板，没有就是虚空。两种情形我都不动。")
SCOPE = "只看凑齐抹除色的那一下；读不成世界，不管。"
NOT_CLAIMED = ["不说左上 2×2 什么时候变燃料、什么时候变地板——那是那个框自己的性质，帧上读不出",
               "不说射线从我身上哪一格起算在**边长 2** 时和引擎差半格的边缘情形（两种读法在这批料上同值）"]
NOTE = [
    "起点：册子 panel_done_erases_specimen v11。",
    "**更正（CORRECTIONS.md D）**：封存版的 `fire(w)` 要三条——我面前恰好一个抹除色框、框里扣着标本、"
    "我到它之间有一条每格都走得上去的**车道**。三条都不对。引擎 sc25.py:2381-2441 放的是一条单像素射线，"
    "既不要求整个身位对着框，也没有「车道」这一位。",
    "对拍（../../sc25-budget/rule_D.py）：那条 132 步动作串上的 6 次抹除施法，新规则 **6/6**，封存版 **1/6**；"
    "随机走 15 次施法 15/15；合计 **21/21**。",
    "这同时解释了合作者 pilot4 那条全员误读：到关 4 的 14 槽第一发火球全部打墙——因为射线只取左列，"
    "而他们按「身体压住竖井」瞄。",
    "燃料那一格：十次抹除里两次在那一圈左上 2×2 留下燃料；帧上看不出哪个框底下埋着燃料，"
    "所以这里只断言位置，不断言有没有。",
]
EVIDENCE = ["ba14e367ea32768c", "d8d189f611166e29", "49035d9b5f1477ab", "25c05c6fae3f0b72",
            "cdcea5429f94b620", "529d37185eaa3d7f", "75848d842701e19d", "f65ebad14e5cdf86",
            "f0e3ac74249bb2d9", "e6f709fa5a735ad8"]


def _box_of(w, p):
    """标本格 p 落在哪个抹除色框里（边长、左上角）；找不到返回 None。

    **先试边长 4**：同一片记号在 k=2 下也可能圈出一个「框」（内层四个记号恰好成角），
    但引擎删的是真正那一个框精灵。实测关 3 第 29 步：k=2 认出 (1,29)、k=4 认出 (0,28)，
    引擎清掉的是 **4×4 那一片**。取大的那个才对得上。
    """
    for k in (4, 2):
        for b in boxes(w, ERASE, k):
            if b[0] <= p[0] < b[0] + k and b[1] <= p[1] < b[1] + k:
                return b, k
    return None


def fire(w):
    """开火的话返回 (框, 边长, 标本色, 那一圈)；空放返回 None。"""
    spec = target_kind(w)
    if spec is None:
        return None
    hit = ray_first(w)
    bk = _box_of(w, hit)
    if bk is None:
        return None
    box, k = bk
    return box, k, spec, ring(w, box, ERASE, k)


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if machine(completes(w, action)) != "erase":
        return "没凑齐抹除色"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    if nw.me != w.me:
        return "FALSE"
    d = fire(w)
    diff = ground_diff(w, nw)
    if d is None:
        return "TRUE" if not diff else "FALSE"
    box, k, spec, rg = d
    zone = {(r, c) for r in range(box[0] - 1, box[0] + k + 1)
            for c in range(box[1] - 1, box[1] + k + 1)}
    r0, c0 = min(r for r, _ in rg), min(c for _, c in rg)
    soft = {(r0, c0), (r0, c0 + 1), (r0 + 1, c0), (r0 + 1, c0 + 1)}
    before = flat(w)
    gone = {p for p, t in before.items() if t == spec}                      # 场上那个标本色的每一格
    gone |= {p for p in zone if before.get(p) in (spec, ("mark", ERASE))}   # 那一圈与框里的
    changed = {p for p, _, _ in diff}
    if changed - gone:
        return "FALSE"                                                      # 别处动了
    after = flat(nw)
    for p in gone:
        if p in nw.me.cells() or p in w.me.cells():
            continue
        t = after.get(p, ("void",))
        # **更正**：抹掉之后露出的是「底下本来是什么」——有地板露地板，没有就是**虚空**。
        # 封存版只允许地板；关 3 第 29 步那一片（行 0-3 × 列 28-31）实测全变虚空。
        if t in (("floor",), ("void",)):
            continue
        if t == ("fuel",) and p in soft:
            continue
        return "FALSE"
    return "TRUE"


# `specimen_cells` 在这里重新导出，方便别处查「场上哪些格是标本」。
__all__ = ["CLAIM", "SCOPE", "NOT_CLAIMED", "NOTE", "EVIDENCE",
           "fire", "scope_", "assert_", "specimen_cells"]
