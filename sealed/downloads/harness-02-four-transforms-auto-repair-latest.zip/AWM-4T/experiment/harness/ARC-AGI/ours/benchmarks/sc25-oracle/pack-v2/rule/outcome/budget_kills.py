"""计数超过本关上限就判负：上游置 GAME_OVER 当且仅当这一步之后 计数 > 上限。"""
from __future__ import annotations

from derive.budget import cap_bounds, counter
from objects import read

from .._scope import is_reset

CLAIM = ("上游把 state 置成 GAME_OVER（这一局死了）**当且仅当**这一步之后的计数 **>** 本关上限 L，"
         "L 就是 bar_budget 里那个常数。"
         "**例外：获胜那一步既不加费、也不判负。** 方向键撞到出口精灵时，引擎推半步之后"
         "直接返回，根本走不到加费与判负那一支（sc25.py:3145-3161 的 return 在 "
         "gmznianfeg() 之前）。所以「赢所需要的峰值」**不含最后那一步**。")
SCOPE = "所有转移；RESET、上游没给本关历史、读不成世界、这一步换了关，不管。"
NOT_CLAIMED = [
    "不说 L 的具体值——它由历史夹出来（见 derive/budget.py:cap_bounds）；"
    "夹不到唯一值时，这一条按**区间**判：只要区间里存在一个 L 能解释观察到的死/没死，就算过。",
    "不说死了之后那一帧长什么样",
    "sc25 只有预算这一种死法（合作者 server_pilot.py 的 GAME_OVER_REASON 写死 'budget'）；"
    "别的游戏不一定。",
]
NOTE = [
    "**这一条是补的，封存件里没有。** 封存模型整块不含预算，所以也说不出「什么时候死」。",
    "**为什么必须补**：没有这一条，模型连「计数超了会怎样」都说不出来，"
    "于是任何关于「某条路线走不走得完」的推理都落不了地。",
    "和 bar_budget 的分工：bar_budget 说竖条怎么显示、计数怎么走；这一条只说**越界就死**。",
    "**补（2026-10-09，判决实验）**：获胜那一步**不收费**。引擎方向键那一支的顺序是 "
    "① try_move ② 燃料退费 ③ 撞到出口 → 推半步 → **return** ④ gmznianfeg()（加费 +1 与判负）。"
    "③ 一旦命中就直接返回，④ 永远走不到。",
    "判决实验（关 1，获胜前计数 14）：上限设成 **14** 时获胜那一步**没死、过关了**；"
    "对照上限 **13** 时第 14 步就 GAME_OVER —— 证明闸是活的，第一组不是闸没生效。",
    "**为什么这一条是承重的**：判「这一关在预算 L 内做不做得到」时，门槛是"
    "**不含获胜步的峰值 ≤ L**，不是「全部动作的总开销 ≤ L」。按后者算会把一类真能赢的路线误判成输。",
    "**补（2026-10-09，判决实验）**：获胜那一步**不收费**。引擎方向键那一支的顺序是 "
    "① try_move ② 燃料退费 ③ 撞到出口 → 推半步 → **return** ④ `gmznianfeg()`（加费 +1 与判负）。"
    "③ 一旦命中就直接返回，④ 永远走不到。",
    "判决实验（关 1，获胜前计数 14）：上限设成 **14** 时获胜那一步**没死、过关了**；"
    "对照上限 **13** 时第 14 步就 GAME_OVER —— 证明闸是活的，第一组不是闸没生效。",
    "**为什么这一条是承重的**：判「这一关在预算 L 内做不做得到」时，门槛是"
    "**不含获胜步的峰值 ≤ L**，不是「全部动作的总开销 ≤ L」。按后者算会把一类真能赢的路线误判成输。",
]
EVIDENCE = []


def scope_(prev, action, nxt, ctx=None):
    if is_reset(action):
        return "RESET → reset_restores"
    if not ctx or not ctx.get("level_hist"):
        return "ctx 缺 level_hist"
    if ctx.get("level_next") != ctx.get("level_prev"):
        return "换关 → socket_wins / level_up_refills"
    if read(prev) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    hist = ctx["level_hist"]
    first = ctx.get("level_prev") == 0
    bounds = cap_bounds(hist, level_is_first=first)
    died = ctx.get("state_next") == "GAME_OVER" and ctx.get("state_prev") != "GAME_OVER"
    if bounds is None:
        # 区间空：那是 bar_budget 的事，这里不重复报
        return "NA"
    lo, hi = bounds
    c = counter(hist, level_is_first=first)
    if died:
        return "TRUE" if c > lo else "FALSE"        # 区间里存在一个 L < c
    return "TRUE" if c <= hi else "FALSE"           # 区间里存在一个 L ≥ c
