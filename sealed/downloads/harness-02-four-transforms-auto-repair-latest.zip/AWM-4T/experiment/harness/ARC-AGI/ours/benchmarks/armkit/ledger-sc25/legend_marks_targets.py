"""小面板是任务书：大面板里还没点亮（色 0）的格位，一定都在小面板有标记的那些格位里。"""
LEVEL = "L3"
SCOPE = "所有转移，prev 与 nxt 两帧各查一次；任一帧的面板读不出来就返回 NA。"
NOTE = "两关的开局都是精确相等：第 0 关小面板四个色 15 的标记在 (1,0)(0,1)(1,2)(2,1)，大面板色 0 的正是这四格；" \
       "第 1 关小面板三个色 11 的标记在 (0,0)(0,1)(1,1)，大面板色 0 的正是这三格。写成子集而不是相等，" \
       "是因为点亮一个之后色 0 那边就少一格，相等会当场被自己打掉。" \
       "标记的颜色两关不同（15 / 11），这条不管颜色——颜色可能另有含义，没想好之前不写进主张。"
EVIDENCE = ["9dabb54dca80d95d", "477bf0b6c6fc98eb"]

from _lib import OFF, legend_grid, panel_grid


def _ok(g):
    p, m = panel_grid(g), legend_grid(g)
    if p is None or m is None:
        return None
    return {cell for cell, color in p.items() if color == OFF} <= set(m)


def assert_(prev, action, nxt, ctx=None):
    a, b = _ok(prev), _ok(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if a and b else "FALSE"
