"""帧 → 世界。唯一碰像素的地方。读不出来抛 ParseError。"""
from __future__ import annotations

from .world import World


class ParseError(Exception):
    """这一帧读不成一个世界。"""


def parse(frame) -> World:
    if not isinstance(frame, (list, tuple)) or len(frame) < 2:
        raise ParseError("少于两行：没有第 0 行之外的盘面")
    w = len(frame[0])
    if w == 0 or any(len(r) != w for r in frame):
        raise ParseError("不是矩形")
    if any(not isinstance(v, int) for r in frame for v in r):
        raise ParseError("格子不是整数")
    return World(n_one=sum(1 for r in frame[1:] for v in r if v == 1),
                 top=tuple(frame[0]), width=w)
