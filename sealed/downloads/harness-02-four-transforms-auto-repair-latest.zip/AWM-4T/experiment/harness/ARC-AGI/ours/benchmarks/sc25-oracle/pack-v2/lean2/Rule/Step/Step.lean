/-
# step —— 按方向键（对应 rule/step/step.py）

**定义，不是定理。** 脸转到那一侧；前方一个自身边长的方区整块走得上去（地板或记号）就整块挪过去，
否则原地不动；边长不变。整块踏进插座那一支不在这里（`Rule/Win/SocketWins.lean`）。
-/

import Obj.Model.Render
import Obj.Derive.Standing

namespace Game

def stepDir (b : Board) (s : St) (f : Face) : St :=
  let turned : Marker := { s.me with face := f }
  match ahead s.me f with
  | none => { s with me := turned }
  | some (r, c) =>
    let pic := render b s
    if (square r c s.me.side).all (walkable pic b.legends) then
      { s with me := { turned with row := r, col := c } }
    else
      { s with me := turned }

end Game
