"""共享的**论域**：几句被好几条规则说的「这一步我不管」。

每个函数返回**不管的理由**（一个短字符串）；这一步归它管就返回 `None`。
理由里写着 `→ 规则名` 的，是一句可判错的话：run_rules.py 会核那条规则在那些步上是不是真的开口了。

抄很多遍的「我不管」会慢慢分叉，所以提到这里只写一遍。
"""
from __future__ import annotations


def level_changed(ctx):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "ctx 缺关号"
    return "换关 → socket_wins/reset_restores" if ctx["level_prev"] != ctx["level_next"] else None


def is_reset(action):
    return "RESET → reset_restores" if action == "RESET" else None


def session_first(ctx):
    return "会话第一下 → session_first_void" if ctx and ctx.get("first_of_session") else None


def unreadable(*ws):
    return "读不成世界" if any(w is None for w in ws) else None


def first(*reasons):
    for r in reasons:
        if r:
            return r
    return None
