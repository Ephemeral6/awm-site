"""凑齐搬家色：我整块搬进**某一个**和我同边长的搬家色框（边长、朝向不变）；一个都没有时什么都不动。挑哪一个由一个帧上读不出的游标决定。"""
from __future__ import annotations

from derive.machines import TELEPORT, machine
from derive.pad_hits import completes
from derive.portals import candidates
from objects import parse_action, read
from objects.player.marker import Marker

from .._scope import unreadable

CLAIM = ("凑齐搬家那块小面板的图案：\n"
         "  · 场上有**和我同边长**的搬家色合法框时：我整块搬进**其中某一个**，边长与朝向不变；\n"
         "  · 一个都没有：我不动。\n"
         "**没有奇偶条件，也不要求那个框戴着外圈。**")
SCOPE = "只看凑齐搬家色的那一下；读不成世界，不管。地面那一半不看（见 NOT_CLAIMED）。"
NOT_CLAIMED = [
    "**不说搬进哪一个**。引擎按**尺寸**选一组目标表（小身一组、大身另一组），取**游标**指的那一个，"
    "搬完游标 +1 轮转（sc25.py:2600-2625）。游标是引擎里的一个计数，**帧上读不出**，"
    "这里不装作读得出。要钉死它得靠「本关到现在传送过几次」那段历史——留给后续。",
    "不说外圈（指路牌）搬完之后换到哪里。封存版在这里写了一整套「换到另一个同奇偶的框上」，"
    "那是建立在奇偶条件之上的，**前提已经被推翻**，所以整段撤掉，不是改写。",
    "不说搬完地面别处变不变（撤掉外圈那套之后，这条规则不再管地面）",
]
NOTE = [
    "起点：册子 panel_done_teleports_me v16 + teleport_swaps_gate v2。",
    "**更正（CORRECTIONS.md H）**：封存版要求「和我**同奇偶**而且**戴着外圈**的恰好一个」。"
    "引擎两样都不看：按尺寸选表、按游标取一个、游标轮转，**没有奇偶条件**；"
    "戴外圈只是渲染出来的指路牌。",
    "两次独立的实测各自撞到这一条："
    "「teleport **ignores the same-parity condition**, because it moved me from row 14 to row 17」；"
    "「A teleport moved my size-4 player from (row 12, column 41) to (row 33, column 13)」。",
    "**对拍没闭合，照实记**：定向扫（关 2 / 5 / 6，各 25 次「随机走 0-4 步 → 凑齐搬家图案」×4 轮）"
    "合计 **295 / 300**。那 5 处全在关 2、大身、游标 0：预测落点恒为 (45,15)，实际像是「只走了一步没传送」。"
    "已排除「那一下过关了」这个解释（5 处都没过关）。**原因没查出来 ⇒ 这一条记成「基本证实，未闭合」，"
    "不许当钉死的用。**",
    "一个待查方向：缺陷 B（点击是翻转）会让一次失败的施法在面板上留下 3 个亮格，"
    "下一次点同样三格就把它们灭掉，于是接连几次都不施法——这能解释「连续失败」，"
    "但解释不了**第一次**为什么失败。",
]
EVIDENCE = ["2657799cd7a750eb", "58293a15fc50c8fa", "1848d086ef1e56e4", "ab02ba4d56a16c8d",
            "025efe620ab28db3", "340bcaf4c04e8b0e", "74f526b322436d7f", "545138eb8e7f6ed1",
            "00348bdc51b3bc76", "1d55cbe2e26095d8", "1ca2093db355cef8"]


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if machine(completes(w, action)) != "teleport":
        return "没凑齐搬家色"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    me, k = w.me, w.me.side
    cands = candidates(w, TELEPORT)
    if not cands:
        return "TRUE" if nw.me == me else "FALSE"          # 表为空 ⇒ 什么都不发生
    want = {Marker(b[0], b[1], k, me.face) for b in cands}
    want.add(Marker(me.row, me.col, k, me.face))           # 搬到我自己脚下这一格也算（游标指回原处）
    return "TRUE" if nw.me in want else "FALSE"
