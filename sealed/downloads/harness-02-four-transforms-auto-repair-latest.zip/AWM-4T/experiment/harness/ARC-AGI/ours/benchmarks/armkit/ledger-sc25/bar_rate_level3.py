"""第 3 关里，除了进关后的第一个动作（它一行不扣），每个动作都扣竖条 2 行；凑齐某块小面板图案的那一下扣 4 行或 2 行。"""
LEVEL = "L4"
SCOPE = "只看第 3 关之内（ctx.level_prev == ctx.level_next == 3）、不是 RESET 的转移；" \
        "进关后的第一个动作认不出来，所以「扣 0 行」也放过（见 NOTE）；没有 ctx 返回 NA。"
NOTE = "这条是为了把「烧掉一块图案」这件看不见的事钉成读数才写的。第 3 关的竖条口径干净：" \
       "每个动作整整扣 2 行，第 45~54 步九个动作无一例外。唯独两下扣了 4 行——第 47 步（凑齐色 6）和" \
       "第 51 步（凑齐色 15）；第 54 步又凑齐一次色 6，只扣 2 行，场上也一格没动。" \
       "第 51 步扣 4 行时标记块当场从 4x4 缩成 2x2，第 47 步扣 4 行时场上一格没动——" \
       "**双倍的那一下就是「这块图案兑现了」的唯一痕迹**，哪怕它什么也没做出来。由此我推断" \
       "「一关里每块小面板的图案只兑现一次」，并据此重开了本关。" \
       "但那句推断**写不进概念**：概念一次只看一条转移，「本关是不是第一次凑齐这块图案」不是单条转移里的量。" \
       "所以这里只断言读得出的外壳（2 行 / 4 行），推断本身留在 journal 和这段 NOTE 里，等终局卡上兑现或落空。" \
       "第 0-2 关的竖条不是这个口径：那几关约每两个动作才掉 2 行（量化到 2 行一跳），所以这条只敢管第 3 关。" \
       "「扣 0 行」放过是因为进关后的第一个动作（第 45 步）确实一行不扣，而单条转移看不出自己是不是进关第一步。"
EVIDENCE = ["08ac5cbf4f4fffd8", "d8d189f611166e29", "49035d9b5f1477ab"]

from _lib import BAR_COLS, BAR_FULL, completed_legend


def _bar_rows(g):
    return sum(1 for r in range(len(g)) if all(g[r][c] == BAR_FULL for c in BAR_COLS))


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != 3 or ctx.get("level_next") != 3:
        return "NA"
    if action == "RESET":
        return "NA"
    eaten = _bar_rows(prev) - _bar_rows(nxt)
    if eaten == 0:
        return "NA"
    if completed_legend(prev, action) is not None:
        return "TRUE" if eaten in (2, 4) else "FALSE"
    return "TRUE" if eaten == 2 else "FALSE"
