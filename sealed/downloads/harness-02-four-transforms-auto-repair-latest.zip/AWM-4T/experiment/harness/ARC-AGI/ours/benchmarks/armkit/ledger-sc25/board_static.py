"""方向键只动两处：标记块动作前后占的那两块方区，和右边缘竖条那两列。别处一格不动。"""
LEVEL = "L0"
SCOPE = "只看 ACTION1/2/3/4；ACTION6 返回 NA（点击会改下方大面板，见 click_lights_panel）；" \
        "换关的那一步（ctx.level_prev != ctx.level_next）返回 NA；标记块定位不到返回 NA"
NOTE = "v1 说的是「所有动作」，在第 15 步被一次点中的 ACTION6 打掉：点击把大面板里一个 3x3 块从色0 涂成色14。" \
       "缩到方向键之后，这条仍然锁着凹槽、两块面板和整片地板。v3：方区边长改成 marker() 读出来的，不再写死 4。" \
       "v4：把换关那一步排除掉。第 23 步走进插座过关，整屏重画 389 格——那不是「方向键动了别处」，是世界换了一张图。" \
       "这条转移本来靠 marker() 读不出来蒙混成 NA，词汇表把标记块贴着插座的情形修好之后它立刻判 FALSE，" \
       "说明之前的 TRUE 里有一部分是词汇的盲区撑着的。"
EVIDENCE = ["da3e01cff498c8a1", "fd67f106b9c9aa15", "477bf0b6c6fc98eb", "9dabb54dca80d95d"]

from _lib import BAR_COLS, DIR, marker


def assert_(prev, action, nxt, ctx=None):
    if action not in DIR:
        return "NA"
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = marker(prev), marker(nxt)
    if a is None or b is None:
        return "NA"
    ok = set(BAR_COLS)
    box = {(r, c) for r0, c0, k in (a, b)
           for r in range(r0, r0 + k) for c in range(c0, c0 + k)}
    for r, row in enumerate(prev):
        for c, v in enumerate(row):
            if v != nxt[r][c] and c not in ok and (r, c) not in box:
                return "FALSE"
    return "TRUE"
