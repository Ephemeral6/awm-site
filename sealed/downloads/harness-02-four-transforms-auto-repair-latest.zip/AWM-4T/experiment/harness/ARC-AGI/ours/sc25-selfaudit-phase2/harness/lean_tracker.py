# -*- coding: utf-8 -*-
"""Record every lean.exe of the phase-2 runs (start, end, peak working set, which run it belongs to), every 5 s.

    python -I lean_tracker.py          # runs until no run_one.py process is left; writes runs/lean_tracker.jsonl

Purpose (user, 2026-10-21): the L5 subject ran `taskkill //F //IM lean.exe`, which kills every lean on the machine.
With this log, a lean of one run that ended at the same moment as the other run's taskkill can be flagged as a
cross-run kill, separately from the watchdog's interventions.
"""
import json
import re
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent / "runs" / "lean_tracker.jsonl"


def table():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process | ForEach-Object { \"$($_.ProcessId)`t$($_.ParentProcessId)`t"
                        "$($_.Name)`t$($_.WorkingSetSize)`t$($_.CommandLine)\" }"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    rows = {}
    for line in r.stdout.splitlines():
        p = line.split("\t", 4)
        if len(p) == 5 and p[0].isdigit() and p[1].isdigit():
            rows[int(p[0])] = (int(p[1]), p[2], int(p[3] or 0), p[4])
    return rows


def owner(rows, pid):
    seen = set()
    while pid in rows and pid not in seen:
        seen.add(pid)
        ppid, name, _, cmd = rows[pid]
        if "run_one.py" in cmd:
            for case in ("l4s-case-", "l5e-case-"):
                i = cmd.find(case)
                if i >= 0:
                    return cmd[i:i + len(case) + 6]
            for lv in ("4", "5"):
                if "--level " + lv in cmd:
                    return "L" + lv
            return "run_one"
        pid = ppid
    return "unknown"


def main():
    live = {}
    with open(OUT, "a", encoding="utf-8") as f:
        while True:
            rows = table()
            now = time.strftime("%H:%M:%S")
            if not any("run_one.py" in v[3] for v in rows.values()):
                f.write(json.dumps({"t": now, "ev": "stop", "why": "no run_one.py left"}) + "\n")
                break
            leans = {pid: v for pid, v in rows.items() if v[1].lower() == "lean.exe"}
            for pid, v in leans.items():
                if pid not in live:
                    own = owner(rows, pid)
                    guess = None
                    if own == "unknown":      # detached compile (parent exited): guess from the file name
                        f_ = v[3].replace("\\", "/").split("/")[-1]
                        if "L4" in f_:
                            guess = "L4"
                        elif "L5" in f_ or re.search(r"T\d+\.lean", f_):
                            guess = "L5"
                    live[pid] = {"pid": pid, "start": now, "owner": own, "owner_guess": guess, "cmd": v[3][-120:],
                                 "peak_gb": 0}
                    f.write(json.dumps({"t": now, "ev": "start", **live[pid]}) + "\n")
                live[pid]["peak_gb"] = max(live[pid]["peak_gb"], round(v[2] / 2 ** 30, 2))
            for pid in [p for p in live if p not in leans]:
                rec = live.pop(pid)
                f.write(json.dumps({"t": now, "ev": "end", **rec}) + "\n")
            f.flush()
            time.sleep(5)


if __name__ == "__main__":
    sys.exit(main())
