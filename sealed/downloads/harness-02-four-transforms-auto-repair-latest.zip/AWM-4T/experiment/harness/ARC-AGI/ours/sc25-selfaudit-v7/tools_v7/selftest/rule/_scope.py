"""共享的论域：返回「不管的理由」，归它管返回 None。"""
from __future__ import annotations


def unreadable(*ws):
    return "读不成世界" if any(w is None for w in ws) else None
