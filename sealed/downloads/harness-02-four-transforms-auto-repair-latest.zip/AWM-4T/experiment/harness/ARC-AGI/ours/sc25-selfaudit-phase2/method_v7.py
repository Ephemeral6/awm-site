# -*- coding: utf-8 -*-
"""Compose the v7 METHOD.md from l4p's METHOD (64a7116d): replace step two with the card-driven text
(METHOD_step2_cards.md), adjust the three sentences that said step two happens only at the end, and insert the
self-audit section (METHOD_addendum_selfaudit.md) at the same anchor as before.

Every replacement is asserted to match exactly once, and the result is checked to be the base with exactly
these changes (compose() and undo() are inverse on the base).
"""
from __future__ import annotations

from pathlib import Path

HERE = Path(__file__).resolve().parent
STEP2_NEW = HERE / "METHOD_step2_cards.md"

STEP2_START = "# 第二步：把规则变成对象 / 规则 / Lean（**收工时才做**）\n"
STEP2_END = "## Lean 这一侧\n"

SENTENCES = [
    ("第二步  把规则**变成 Lean** —— 形式化，**收工时才做**",
     "第二步  把规则**凝炼成对象 / 规则，再变成 Lean** —— 每次 attempt 之后，台架逐张发卡"),
    ("**跑的时候做第一步就够了。** 第二步（Lean 那一侧）在这一局结束之后才会要你交 ——\n"
     "所以不要为了赶形式化而缩短实验。中途想写点 Lean 定义当笔记可以，但别让它挤掉探索。",
     "**跑的时候只做第一步。** 第二步在每次 attempt 结束之后、台架逐张发卡的时候做 ——\n"
     "所以不要在游玩中途为了赶形式化而缩短实验。"),
    ("· 第二步的产物：对象表、Lean 文件，以及每条定理的 `#print axioms` 原文输出",
     "· 第二步的产物：objects/ derive/ rule/ analysis/（每张卡的读数）、lean/ 下的 Lean 文件，"
     "以及每条定理的 `#print axioms` 原文输出"),
]


def compose(base: str, selfaudit: str, anchor: str) -> str:
    new2 = STEP2_NEW.read_text(encoding="utf-8").replace("\r\n", "\n")
    assert base.count(STEP2_START) == 1 and base.count(STEP2_END) == 1, "step-two block not found exactly once"
    i, j = base.index(STEP2_START), base.index(STEP2_END)
    assert i < j
    s = base[:i] + new2 + base[j:]
    for old, new in SENTENCES:
        assert s.count(old) == 1, "sentence not found exactly once: %r" % old[:40]
        s = s.replace(old, new)
    assert s.count(anchor) == 1, "self-audit anchor not found exactly once"
    k = s.index(anchor)
    return s[:k] + selfaudit + s[k:]


def undo(var: str, base: str, selfaudit: str) -> str:
    """Remove the self-audit section and restore step two and the three sentences; must give back `base`."""
    s = var.replace(selfaudit, "", 1)
    for old, new in SENTENCES:
        s = s.replace(new, old, 1)
    new2 = STEP2_NEW.read_text(encoding="utf-8").replace("\r\n", "\n")
    i, j = base.index(STEP2_START), base.index(STEP2_END)
    return s.replace(new2, base[i:j], 1)
