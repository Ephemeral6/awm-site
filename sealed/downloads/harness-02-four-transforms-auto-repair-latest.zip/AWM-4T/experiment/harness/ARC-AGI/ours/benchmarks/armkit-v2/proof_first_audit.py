"""Proof-first v7h-style audit. No model calls on import, no truth/bound oracle.

Mechanical coverage/freshness is not semantic proof of coverage or tightness.
"""
from pathlib import Path
import hashlib,json,shutil,re,datetime

POLICY='proof-first-audit-v2-20261024'
NEXT_ATTEMPT='''
Read the most recent work/selfaudit/attempt_*.json, if one exists. Within this attempt's normal game budget,
execute the planned discriminating probes where feasible; record exact transitions and unresolved cases.
Use new evidence to repair the model, then follow all four transforms, full regression and Lean re-certification.
'''
PRIORITY='''
Proof-first reporting: prioritize a closed Lean theorem as early as evidence allows. If the current model rules
out winning, explicitly report VERDICT: impossible_in_model_proved and MAIN-THEOREM after closing the proof.
Separate uncertainty about game/model coverage from this model-relative result; uncertainty alone does not
invalidate a checked theorem. Without a closed theorem, do not claim proved impossibility: record undecided
or the precise failed proof obligation. Never invent a proof or change the game conclusion to meet a quota.
Only AFTER a checked certificate will the driver request rule-loosening sensitivity audit and next-attempt probes.
After evidence changes any rule, refresh all four transforms and full regression and prove the revised model.
'''
PROMPT='''Your current model-impossibility verdict and closed Lean theorem have ALREADY passed the driver checks.
The driver has sealed that certificate and its model sources. Preserve that model-relative conclusion.
Now audit whether your MODEL is too restrictive, without treating this message as evidence of an actual error.
This same instruction is sent independently of the true bound, after every certified impossibility attempt.

FILES ONLY: no game actions, no reset, no edits to current objects/, derive/, rule/, concepts/, lean/ or
transitions.jsonl. Do not issue a new VERDICT or withdraw a checked model theorem merely because environment
coverage is uncertain. Write counterfactual candidates and plans, not replacement active rules. Apply a repair
only with the next attempt's evidence, then perform all four transforms, full regression and re-prove in Lean.

Read METHOD.md's proof-first audit section. Examine EVERY current rule and each case, including deferred
mechanisms, action types, contact/state combinations and charge/refund timing. For EACH load-bearing rule,
consider a small and widest evidence-compatible relaxation; compute its cost effect if feasible within the
8GiB limit, otherwise report unknown and a concrete bounded plan. A rule is load-bearing if loosening lowers
the model optimum, even when the relaxed optimum remains above the sealed budget. Do not label an unknown
effect irrelevant. Test every load-bearing candidate in subsequent attempts as resources allow, prioritize
informative bite steps, and explicitly retain untested/untestable candidates at the end. Existing observations
only support their actual contexts; model-unreachable is not evidence of environment-unreachable.

Write work/selfaudit/attempt_{attempt:02d}.md and work/selfaudit/attempt_{attempt:02d}.json.
JSON fields: attempt ({attempt}), certificate_sha256 ({certificate_sha256}),
rules (one or more entries for EVERY source path in rule_inventory below), prior_probe_results, next_probes.
Each rules entry needs: path, rule_name, load_bearing (true/false/"unknown"), rationale (>=40 characters),
relaxations (nonempty list, with original, small, widest, effect, compatibility_evidence_ids), and
coverage (specific covered/uncovered trigger cases; explain immutable observations explicitly).
Use effect="unknown" if computation was not completed. Compatibility IDs must belong to recorded transitions.
For evidence-fixed/already-maximally-permissive cases, state why both relaxation entries add nothing;
do not invent a change just to satisfy a schema.
Each next_probes entry needs id (unique), rule_path, prediction_original, prediction_relaxed, actions_or_plan
(specific, >=20 characters), target_attempt (the next global attempt number, or null when no attempts remain).
Every rules entry with load_bearing=true/"unknown" must have a matching next_probes entry, including
explicitly untestable/deferred cases with their reason. A plan is not a completed probe.
For EVERY prior probe ID listed below, prior_probe_results needs probe_id, outcome
(CONFIRMED/REFUTED/UNTESTABLE/UNTESTED), reason (>=30 characters), evidence_ids. CONFIRMED/REFUTED require
actual recorded transition IDs. UNTESTED/UNTESTABLE remain unresolved; never count them as confirmed.

rule_inventory: {rule_inventory}
prior_probe_ids: {prior_probe_ids}
has_next_attempt: {has_next}
Do not spend an extra gameplay attempt here. If none remain, list unresolved cases and a proposed plan only.
'''

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def protected(d):
    d=Path(d);paths=[p for p in d.rglob('*') if p.is_file() and p.suffix in ('.py','.lean')
        and '__pycache__' not in p.parts and not p.relative_to(d).as_posix().startswith('work/selfaudit/')]
    if (d/'transitions.jsonl').exists():paths.append(d/'transitions.jsonl')
    return {p.relative_to(d).as_posix():sha(p) for p in sorted(paths)}

def inventory(d):
    d=Path(d)
    return sorted(p.relative_to(d).as_posix() for top in ('rule','concepts','lean/Rule')
                  for p in (d/top).rglob('*') if p.is_file() and p.suffix in ('.py','.lean') and '__pycache__' not in p.parts)

def certified(text,proof):
    matches=re.findall(r'^\s*VERDICT:\s*(\S+)',text or '',re.M|re.I)
    return bool(matches and matches[-1].lower().startswith('impossible') and proof and proof.get('ok') and
                proof.get('theorem') and proof.get('file') and not proof.get('withdrawn'))

def reset_count(logdir):
    n=0
    for p in Path(logdir).glob('*.jsonl'):
        with p.open(encoding='utf-8') as f:
            for line in f:
                if line.strip() and json.loads(line).get('ep')=='reset':n+=1
    return n

def seal(d,attempt,text,proof,archive):
    if not certified(text,proof):raise ValueError('No audit before a checked impossibility theorem')
    d=Path(d);dest=Path(archive)/f'attempt_{attempt:02d}'
    if dest.exists():raise ValueError('Certificate slot exists; preserve it, do not replay an attempt')
    files=protected(d)
    if not files or not inventory(d):raise ValueError('A current rule inventory is required')
    dest.mkdir(parents=True)
    for rel in files:
        out=dest/'sources'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(d/rel,out)
        if sha(out)!=files[rel]:raise ValueError('Source changed during certificate snapshot')
    value=dict(policy=POLICY,attempt=attempt,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               verdict_text=text,proof_gate=proof,source_sha256=files,
               scope='Kernel/axiom gate passed under the saved model; theorem semantics and environment coverage require independent review.')
    p=dest/'certificate.json';p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    return dict(path=str(p),sha256=sha(p),source_sha256=files,attempt=attempt)

def check(d,attempt,cert,previous,has_next):
    d=Path(d);why=[];rec=None
    try:
        if protected(d)!=cert['source_sha256']:raise ValueError('Active model or corpus changed in file-only audit; next evidence/refinement/re-proof required')
        rec=json.loads((d/f'work/selfaudit/attempt_{attempt:02d}.json').read_text(encoding='utf-8'))
        note=d/f'work/selfaudit/attempt_{attempt:02d}.md'
        if not note.is_file() or note.stat().st_size<80:why.append('Concrete audit narrative missing')
        if rec.get('attempt')!=attempt or rec.get('certificate_sha256')!=cert['sha256']:why.append('Audit not bound to this checked certificate')
        rows=rec.get('rules',[]);known=inventory(d)
        if not isinstance(rows,list) or not rows or not all(isinstance(x,dict) for x in rows):raise ValueError('rules must be a nonempty list')
        if {x.get('path') for x in rows}!=set(known):why.append('Audit must cover every rule-source path, not only selected proof dependencies')
        ids=set()
        for i,line in enumerate((d/'transitions.jsonl').read_text(encoding='utf-8').splitlines()):
            if line.strip():
                x=json.loads(line);ids.add(str(x.get('tid',x.get('id',i))))
        for row in rows:
            if not row.get('rule_name') or row.get('load_bearing') not in (True,False,'unknown') or len(row.get('rationale',''))<40 or not row.get('coverage'):why.append('Each named rule needs sensitivity status, rationale and trigger coverage')
            rels=row.get('relaxations')
            if not isinstance(rels,list) or not rels:why.append('Each rule needs explicit relaxation analysis');continue
            for item in rels:
                if not isinstance(item,dict) or not all(item.get(k) is not None for k in ('original','small','widest','effect','compatibility_evidence_ids')):why.append('Small/widest relaxation and bounded cost effect/evidence required');continue
                if not {str(x) for x in item['compatibility_evidence_ids']}<=ids:why.append('Unknown relaxation evidence ID')
                if item['effect']=='unknown' and row.get('load_bearing') is False:why.append('Unknown sensitivity cannot be classified irrelevant')
        probes=rec.get('next_probes',[])
        if not isinstance(probes,list) or not all(isinstance(x,dict) for x in probes):raise ValueError('next_probes must be a list')
        if len({x.get('id') for x in probes})!=len(probes):why.append('Probe IDs must be unique')
        for x in probes:
            if not x.get('id') or x.get('rule_path') not in known or not x.get('prediction_original') or not x.get('prediction_relaxed') or len(x.get('actions_or_plan',''))<20:why.append('Concrete discriminating probe plan required')
            if x.get('target_attempt')!=(attempt+1 if has_next else None):why.append('Probe must target the next available attempt, or be explicitly deferred at the cap')
        for row in rows:
            if row.get('load_bearing') is not False and row.get('path') not in {x.get('rule_path') for x in probes}:why.append('Every load-bearing/unknown rule needs a probe or explicit deferral plan')
        prior={x['id'] for x in (previous or {}).get('next_probes',[])}
        results=rec.get('prior_probe_results',[])
        if not isinstance(results,list) or not all(isinstance(x,dict) for x in results):raise ValueError('prior_probe_results must be a list')
        if {x.get('probe_id') for x in results}!=prior or len(results)!=len(prior):why.append('Every prior probe needs exactly one observed/unresolved outcome')
        for x in results:
            ev={str(y) for y in x.get('evidence_ids',[])}
            if x.get('outcome') not in ('CONFIRMED','REFUTED','UNTESTABLE','UNTESTED') or len(x.get('reason',''))<30 or not ev<=ids:why.append('Invalid probe outcome/reason/evidence')
            if x.get('outcome') in ('CONFIRMED','REFUTED') and not ev:why.append('Observed probe outcome requires actual transition IDs')
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as exc:why.append(str(exc))
    return dict(ok=not why,why=why,record=rec,scope='Coverage and provenance checks; not semantic proof of the relaxation analysis or game coverage.')

def run(d,attempt,text,proof,drive,actions,archive,has_next,retries=1,resets=None):
    if not certified(text,proof):return dict(triggered=False,ok=True,reason='No checked impossibility certificate yet; audit not triggered')
    archive=Path(archive);state=archive/'state.json'
    previous=json.loads(state.read_text(encoding='utf-8')).get('audit') if state.exists() else None
    cert=seal(d,attempt,text,proof,archive)
    prompt=PROMPT.format(attempt=attempt,certificate_sha256=cert['sha256'],rule_inventory=json.dumps(inventory(d)),
                         prior_probe_ids=json.dumps([x['id'] for x in (previous or {}).get('next_probes',[])]),has_next=has_next)
    start=actions();start_resets=resets() if resets else 0;replies=[];result={'ok':False,'why':['not run']}
    for n in range(retries+1):
        msg=prompt if n==0 else 'Complete this same file-only audit without changing the sealed model. Missing items: '+ '; '.join(result['why'])+'\n\n'+prompt
        reply=drive(msg,n);replies.append(reply)
        result=check(d,attempt,cert,previous,has_next)
        if reply.get('returncode')!=0:result['why'].append('Audit CLI failed/resource-blocked')
        if re.search(r'^\s*VERDICT:',reply.get('text') or '',re.M):result['why'].append('Audit is a separate coverage task; do not issue a new verdict here')
        if actions()!=start:result['why'].append('Audit performed game actions')
        reset_delta=(resets()-start_resets) if resets else 0
        if reset_delta:result['why'].append('Audit performed a reset')
        result['ok']=not result['why']
        if result['ok'] or protected(d)!=cert['source_sha256'] or actions()!=start or reset_delta or reply.get('returncode')!=0:break
    report=dict(policy=POLICY,triggered=True,ok=result['ok'],certificate=cert,check=result,replies=replies,
                has_next_attempt=has_next,game_action_delta=actions()-start,reset_delta=(resets()-start_resets) if resets else None)
    (archive/f'attempt_{attempt:02d}'/'audit-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if result['ok']:state.write_text(json.dumps(dict(attempt=attempt,audit=result['record']),ensure_ascii=False,indent=2),encoding='utf-8')
    return report
