/-
# teleport —— 搬家那台机器（对应 rule/machines/teleport.py）

**定义，不是定理。** 候选 = 和我同边长的搬家框里、戴着外圈的那些（边长 4：`St.gate` 指的那一个；
边长 2：2×2 框的外圈是画死的，全都算），再筛「行列奇偶都和我相同」「不是我此刻站着的那一个」。
恰好一个：我整块搬进去（边长、朝向不变）；边长 4 时外圈换到另一个同奇偶的 4×4 框上（没有另一个就留在原处）。
一个都没有：不动。

Python 那一侧说「另一个同奇偶的框——包括我搬走之后才露出四角的原地那一个」：
在这里那只是 `portals4` 里的另一个元素，不用任何特殊说法。**说不出来的那一位，在这边是一个下标。**
-/

import Obj.Model.Render

namespace Game

def sameParity (a b : Nat) : Bool := (a + b) % 2 == 0

def teleCands (b : Board) (s : St) : List Portal :=
  let m := s.me
  let pool :=
    if m.side == 4 then (match b.portals4[s.gate]? with | some p => [p] | none => [])
    else if m.side == 2 then b.portals2 else []
  pool.filter fun p => sameParity p.row m.row && sameParity p.col m.col && !(p.row == m.row && p.col == m.col)

def otherGateAux (d : Portal) : List Portal → Nat → Option Nat
  | [], _ => none
  | p :: rest, i =>
    if p != d && sameParity p.row d.row && sameParity p.col d.col then some i else otherGateAux d rest (i + 1)

def teleport (b : Board) (s : St) : St :=
  match teleCands b s with
  | [d] =>
    let s1 := { s with me := { s.me with row := d.row, col := d.col } }
    if s.me.side == 4 then
      (match otherGateAux d b.portals4 0 with
       | some j => { s1 with gate := j }
       | none => s1)
    else s1
  | _ => s

end Game
