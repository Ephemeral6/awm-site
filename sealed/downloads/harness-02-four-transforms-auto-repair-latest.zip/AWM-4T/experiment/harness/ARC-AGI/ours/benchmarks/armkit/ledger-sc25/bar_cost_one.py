"""除了收尾那一下（点亮的格位凑齐某块小面板的图案），同一关之内任何一个动作最多消耗竖条一块。"""
LEVEL = "L4"
SCOPE = "只看不换关、且不是重开本关（action != \"RESET\"）的转移；" \
        "点亮的格位凑齐某块小面板图案的那一下返回 NA（那一下另算，见 bar_monotone 的 NOTE）；没有 ctx 返回 NA"
NOTE = "第 27 步之前一直藏在 bar_monotone 里；那一步一口气扣 3 块，把两件事逼得分开写。" \
       "收尾点击扣多少还没写成概念：唯一一次是 3 块，和它替我走的 3 步对得上，但一次不算数。" \
       "v2：收尾那一下的认法换成 completed_legend——第 3 关的大面板没有色 0 块，" \
       "「点掉最后一个色 0 块」这句话在那一关没有指称。" \
       "v3：和 bar_monotone 一起被第一次 RESET 打掉——重开本关关号不变，竖条却补满了，等于扣了 -32 块。"
EVIDENCE = ["da3e01cff498c8a1", "6897595a49047211", "56b830dc960999ad"]

from _lib import bar_blocks, completed_legend


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action == "RESET" or completed_legend(prev, action) is not None:
        return "NA"
    return "TRUE" if 0 <= bar_blocks(prev) - bar_blocks(nxt) <= 1 else "FALSE"
