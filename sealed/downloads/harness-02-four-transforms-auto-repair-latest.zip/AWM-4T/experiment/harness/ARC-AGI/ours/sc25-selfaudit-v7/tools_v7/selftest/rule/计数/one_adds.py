"""按 ACTION1：值为 1 的格子多一个。"""
from __future__ import annotations

from objects import read

from .._scope import unreadable

CLAIM = "按 ACTION1：第 1 行往下值为 1 的格子正好多一个。"
EVIDENCE = []


def scope_(prev, action, nxt, ctx=None):
    if action != "ACTION1":
        return "不是 ACTION1"
    return unreadable(read(prev), read(nxt))


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    return "TRUE" if nw.n_one == w.n_one + 1 else "FALSE"
