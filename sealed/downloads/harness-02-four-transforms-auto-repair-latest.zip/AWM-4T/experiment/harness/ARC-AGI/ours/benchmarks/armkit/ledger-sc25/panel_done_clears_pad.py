"""点亮的格位凑齐某块小面板的图案那一下，大面板九块**全部**变成地板色——包括刚点中的那一块和还没点过的那些。"""
LEVEL = "L1"
SCOPE = "只看 ACTION6 且这一下点击让大面板点亮的格位正好凑齐某一块小面板的图案（completed_legend 读得出）；" \
        "大面板在 prev 或 nxt 里读不出来返回 NA。其余情况 NA。不管场上发生了什么，只管大面板。"
NOTE = "第 47 步逼出来的：那一步凑齐了图案，大面板照常清空，可是场上一格没动——" \
       "panel_done_erases_specimen / teleports_me / shrinks_me 三条把「清空面板」和「场上的效果」" \
       "捆在一句话里写，捆法在第 3 关散架了。这条只抽出四次观测（第 19 / 27 / 35 / 47 步）都成立的那一半：" \
       "**凑齐图案一定清空大面板**。场上发生什么是另一件事，另外几条去管。" \
       "写成单独一条的好处是它在两块小面板的关里照样开口，而那三条现在全哑了。"
EVIDENCE = ["bcf6976ebd8e9446", "2657799cd7a750eb", "ba14e367ea32768c", "d8d189f611166e29"]

from _lib import FLOOR, PANEL_SIDE, completed_legend, panel


def _fire(prev, action):
    return completed_legend(prev, action) is not None


def assert_(prev, action, nxt, ctx=None):
    if not _fire(prev, action):
        return "NA"
    p = panel(nxt)
    if not p:
        return "NA"
    return "TRUE" if all(color == FLOOR for color in p.values()) else "FALSE"


def apply(prev, action, ctx=None):
    if not _fire(prev, action):
        return None
    p = panel(prev)
    if not p:
        return None
    return {(r, c): FLOOR
            for (t, l) in p
            for r in range(t, t + PANEL_SIDE)
            for c in range(l, l + PANEL_SIDE)}
