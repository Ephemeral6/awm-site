"""我面前是哪个框、我到它之间的车道通不通。

## 在我面前（瞄准）

  · 整个框落在朝向那一侧；
  · 我的带子（朝上下时是我那 k 列，朝左右时是我那 k 行）和框那一圈记号的跨度**一个套住另一个**：
    我的带子整条落在环的跨度里，或者环整条落在我的带子里。只擦到边缘一行不算。

恰好一个才算；没有或不止一个返回 None。

## 车道

我到框之间、按我的带子数的那一截。**有一条从头通到底的线**（横着瞄看每一行、竖着瞄看每一列），
而那条线上每一格都走得上去（地板或记号），才算通。紧贴着（那一截是空的）算通。
"""
from __future__ import annotations

from .boxes import boxes, ring
from .standing import walkable


def in_front(w, color):
    me = w.me
    r0, c0, k, f = me.row, me.col, me.side, me.face
    hits = []
    for (br, bc) in boxes(w, color, k):
        rg = ring(w, (br, bc), color, k)
        if not rg:
            continue
        if f in ("U", "D"):
            lo, hi = min(c for _, c in rg), max(c for _, c in rg)
            mlo, mhi = c0, c0 + k - 1
            fwd = br + k <= r0 if f == "U" else br >= r0 + k
        else:
            lo, hi = min(r for r, _ in rg), max(r for r, _ in rg)
            mlo, mhi = r0, r0 + k - 1
            fwd = bc + k <= c0 if f == "L" else bc >= c0 + k
        nested = (lo <= mlo and mhi <= hi) or (mlo <= lo and hi <= mhi)
        if nested and fwd:
            hits.append((br, bc))
    return hits[0] if len(hits) == 1 else None


def band(w, box):
    """我到框之间那一截，按线分组：{线号: [格...]}。"""
    me = w.me
    r0, c0, k, f = me.row, me.col, me.side, me.face
    br, bc = box
    lines: dict = {}
    if f in ("U", "D"):
        lo, hi = (br + k, r0) if f == "U" else (r0 + k, br)
        for r in range(lo, hi):
            for c in range(c0, c0 + k):
                lines.setdefault(c, []).append((r, c))
    else:
        lo, hi = (bc + k, c0) if f == "L" else (c0 + k, bc)
        for r in range(r0, r0 + k):
            for c in range(lo, hi):
                lines.setdefault(r, []).append((r, c))
    return lines


def lane_open(w, box) -> bool:
    lines = band(w, box)
    if not lines:
        return True
    return any(all(walkable(w, p) for p in cells) for cells in lines.values())
