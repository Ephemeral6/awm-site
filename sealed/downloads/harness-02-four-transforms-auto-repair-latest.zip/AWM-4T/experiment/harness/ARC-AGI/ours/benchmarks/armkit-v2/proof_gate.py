# -*- coding: utf-8 -*-
"""闭合证明闸（--proof-gate）：追问里只要判「不可能」类结论，就必须交出一条闭合的 Lean 证明。

用户 2026-10-22：「关于 lean 的部分请一定要追问时确保模型如果要证明不可做必须给出闭合的 lean 证明」。

机械判据（缺一条就补问，最多 n 次；台架**不判断定理内容是不是证的那件事**，那由打分和独立重编判）：
1. 回答里有 `MAIN-THEOREM: lean/<文件>.lean : <定理全名>`（取最后一行）；
2. 文件在跑场里，由台架用钉死的 lean 重新编译（leancheck，依赖一并编），编得过；
3. 编译输出里有这条定理的 `#print axioms` 行（全名或末段名对得上），公理只在 {propext, Quot.sound, Classical.choice}
   之内（或不依赖任何公理），输出里没有 sorryAx / ofReduceBool / trustCompiler 等脏词；
4. 文件里没有 `sorry`、`native_decide`。
"""
from __future__ import annotations

import re
from pathlib import Path

import leancheck as LC
import scope_gate as SG
import resource_guard as RG

OK_AXIOMS = {"propext", "Quot.sound", "Classical.choice"}
MT = re.compile(r"MAIN-THEOREM:\s*`?([^\s`:]+\.lean)`?\s*:\s*`?([\w.'’]+)`?")

PROOF_RETRY = """Your answer states that the level cannot be won. Under METHOD.md ("证到哪一步才算证完") that claim must be backed
by a closed Lean proof on your model, and the driver checks it mechanically. It is not there yet: {why}

Do it now (files only, no game actions):
- a main theorem that holds for every action list of your model (a table checked by decide against your Step, an
  invariant or a potential; no search result from outside Lean as a hypothesis; the only allowed hypotheses restrict
  which actions are legal); the proof may run on an abstraction layer in lean/Proof/ (stage 05 of the cards);
- it compiles with the pinned Lean, and `#print axioms <theorem>` shows only propext / Quot.sound / Classical.choice;
- end your reply with the line MAIN-THEOREM: lean/<file>.lean : <full theorem name>, then the VERDICT and CONFIDENCE
  lines.
If you have truly hit a wall, say exactly which step does not go through and why; then the verdict is
undecided until a closed proof is available. A failed proof gate is a protocol blockage, not an accepted impossibility certificate."""


PROOF_RETRY = (Path(__file__).resolve().parent.parent / "armkit/cost_proof_note.txt").read_text(encoding="utf-8") + PROOF_RETRY

PROOF_RETRY = PROOF_RETRY + "\nBefore reporting a model theorem, complete the current-model rule/dependency checks under cards/05; refresh analysis/full_rule_audit.json and the successful full rejection receipt after model edits. The systematic rule-loosening audit is requested only AFTER this theorem passes.\n"

def main_theorem(text: str):
    m = None
    for m in MT.finditer(text or ""):
        pass
    return (m.group(1), m.group(2)) if m else (None, None)


def check(d: Path, text: str, timeout: int = 1200, built: dict | None = None, require_scope: bool = True, force_cold: bool = False) -> dict:
    rel, name = main_theorem(text)
    res = {"ok": False, "file": rel, "theorem": name, "why": []}
    if require_scope and (d / "cards/PROTOCOL-v7h.json").exists():
        res["full_rule_audit"] = SG.check(d)
        res["why"].extend(res["full_rule_audit"]["why"])
        if res["why"]: return res
    if require_scope and (d / 'cards/PROTOCOL-four-transforms.json').exists():
        import four_transforms_gate as FT
        res['four_transformations'] = FT.check_current(d)
        res['why'].extend(res['four_transformations']['why'])
        if res['why']: return res
    if not rel:
        res["why"].append("there is no line MAIN-THEOREM: lean/<file>.lean : <theorem>")
        return res
    rel = rel.replace("\\", "/").lstrip("./")
    if not rel.startswith("lean/") and (d / "lean" / rel).exists():
        rel = "lean/" + rel
    f = d / rel
    if not (d / "lean").resolve() in f.resolve().parents:
        res["why"].append("MAIN-THEOREM must resolve inside this arena lean/ tree")
        return res
    if not f.exists():
        res["why"].append("the file %s named in MAIN-THEOREM does not exist" % rel)
        return res
    src = f.read_text(encoding="utf-8", errors="replace")
    if re.search(r"\bsorry\b", src) or "native_decide" in src:
        res["why"].append("%s contains sorry or native_decide" % rel)
    rep = LC.check_files(d, [rel], timeout=timeout, built=built if built is not None else {}, force_cold=force_cold)
    fr = (rep.get("files") or [{}])[0]
    res["compiler_receipt"] = fr.get("compiler_receipt")
    res["compile_cache_hit"] = fr.get("cache_hit",False)
    res["compile_check_wall_s"] = fr.get("check_wall_s",fr.get("wall_s"))
    res["compiles"] = fr.get("compiles")
    res["errors"] = fr.get("errors")
    if fr.get("rc") == 137 or "AWM_RESOURCE_LIMIT" in (fr.get("out") or ""):
        res["why"].append("AWM_RESOURCE_LIMIT: independent compiler allocation exceeded the budget; repair memory usage, not a logical refutation")
    res["axiom_lines"] = fr.get("axiom_lines")
    if not fr.get("compiles"):
        res["why"].append("%s does not compile with the pinned Lean (%s)" % (rel, "; ".join((fr.get("errors") or [])[:2]) or "rc %s" % fr.get("rc")))
    if fr.get("dirty"):
        res["why"].append("the compile output contains %s" % ", ".join(fr["dirty"]))
    short = name.split(".")[-1]
    line = next((l for l in (fr.get("axiom_lines") or []) if ("'%s'" % name) in l or re.search(r"[.']%s'" % re.escape(short), l)), None)
    if fr.get("compiles"):
        if not line:
            res["why"].append("the compile output has no `#print axioms` line for %s (add `#print axioms %s` to the file)" % (name, name))
        else:
            axs = set(re.findall(r"[\w.]+", line.split("axioms:", 1)[1])) if "axioms:" in line else set()
            bad = axs - OK_AXIOMS
            if bad:
                res["why"].append("%s depends on axioms outside propext / Quot.sound / Classical.choice: %s" % (name, sorted(bad)))
            res["axioms"] = sorted(axs)
    res["ok"] = not res["why"]
    return res


def retry_text(why: list) -> str:
    text = PROOF_RETRY.format(why="; ".join(why))
    if any("memory" in w.lower() or "awm_resource" in w.lower() or "alloc" in w.lower() for w in why):
        text = "RESOURCE REPAIR REQUIRED FIRST: reduce live state/proof memory, factor lemmas or stream data. Do not repeat the same computation or drop legal routes. Record the change and measured/bounded memory in analysis/resource_repair.md, refresh full rejection/audit artifacts after model changes, then complete the proof task below. No game actions.\n\n" + text
    return text
