# -*- coding: utf-8 -*-
"""把**关 5 那个实例**的跑场造出来，用 `armkit/build.py`，但**不改它一个字节**。

    python stage_l5.py --dry-run          # 只打清单，什么都不落地
    python stage_l5.py --serve            # 造跑场 + 起服务（仍不跑受试、不花钱）

## 为什么要这么一层

`armkit/build.py` 把孪生两盘写死在 `SIDES` 里（只有关 4 那一对），而且：

```
LEAK_WORDS       有「上限 18」，**没有**关 5 那一档的「上限 35 / 36」
FORBIDDEN_FILES  有 sc25_L4_b18.py，**没有** sc25_L5_b35.py
                 ⇒ 关 5 的孪生源码万一落进跑场，那道检查抓不住
```

直接改 `build.py` 有两个问题：① `armkit/` 是上一批十六条臂的台架，读数还要拿来对照，
`armkit-v2/README.md` 明写「一个字没动」；② **另一段对话此刻正在用它跑 sc25v2 那批**
（端口 8961/8962）。所以这里走**运行时注入**：import 进来，把三样东西加上去，再调它的 `main`。
加法式注入 —— 原有的 `ok` / `no` 两档行为一个字不变。

## 注入了什么

```
SIDES["no5"]      = (sc25_L5_b35.py, 0f2d4207224d46a655a678782df22e64)
LEAK_WORDS       += 上限 35 / 上限 36 / B*(关 5) / 第 5 关不可做 ...
FORBIDDEN_FILES  += sc25_L5_b35.py / L5Bank35.lean / L5BankWin36.lean / cert_l5bank_cap35.json
                    A-L5-RECORD.md / SC25-HARDER-VARIANTS.md / certify_lv.py ...
```

后面这一串是**这一轮新造出来的真值件**：闭包证书、Lean 证明、实做记录、认证器。
一个都不许进跑场。
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = HERE.parent
ARMKIT = V2.parent / "armkit"
ROOT = V2.parent.parent.parent
BENCH = ROOT / "ours" / "benchmarks"

L5_SRC = BENCH / "sc25-budget" / "variant" / "sc25_L5_b35.py"
L5_MD5 = "0f2d4207224d46a655a678782df22e64"

# 这一轮新造的真值件 —— 名字进黑名单（`build.py` 是按**文件名**查的）
NEW_TRUTH_FILES = {
    "sc25_L5_b35.py",
    "L5Bank35.lean", "L5BankWin36.lean",
    "cert_l5bank_cap35.json", "closure_l5_b35.json",
    "bstar_l5.json", "bstar_l5_atomic.json", "witness_l5_36.json",
    "A-L5-RECORD.md", "SC25-HARDER-VARIANTS.md",
    "certify_lv.py", "genlean_lv.py", "nonvac_lv.py", "diag_winrule.py",
    "diag_teleport.py", "diag_teleport_scan.py", "diag_teleport_fail.py",
    "DECISIONS.md", "READINGS.md",
}

# 关 5 那一档的漏词。`build.py` 原表里是「上限 18」，对关 5 不设防。
NEW_LEAK_WORDS = [
    "上限 35", "上限 36", "上限 34", "B*(关 5)", "B*(L5)",
    "关 5 不可做", "第 5 关不可做", "slfh 35", "slfh\": 35",
    "11,243", "166,027", "两头掐死", "bank 闭包",
]


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def load_build():
    spec = importlib.util.spec_from_file_location("armkit_build", ARMKIT / "build.py")
    m = importlib.util.module_from_spec(spec)
    sys.modules["armkit_build"] = m
    sys.path.insert(0, str(ARMKIT))
    spec.loader.exec_module(m)
    return m


def main(argv=None) -> int:
    # **这里不重包 sys.stdout** —— `build.py` 的 main 自己会包一层
    # （`io.TextIOWrapper(sys.stdout.buffer, ...)`）。两层都包的话，外层那个
    # 被重新绑定后会被回收、顺手把共用的 buffer 关掉，于是它一 print 就
    # `ValueError: I/O operation on closed file`。靠 PYTHONIOENCODING=utf-8 就够。
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", default=str(HERE / "arms_plan_l5.json"))
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--serve", action="store_true")
    ap.add_argument("--prior", default="none",
                    help="转给 build.py：接一段先验")
    ap.add_argument("--prior-scope", default="all",
                    help="转给 build.py：all / nonbare")
    ap.add_argument("--no-retries", action="store_true",
                    help="不给 rounds 那一套（默认给 —— v2 要逐轮重试）")
    ap.add_argument("--method-addendum", default="",
                    help="（2026-10-19 加，默认不用）把这份补充插进框架臂拿到的 METHOD.md，"
                         "位置在「四条硬纪律」之后、mathlib 那段之前；armkit/METHOD.md 原件不动")
    a = ap.parse_args(argv)

    if not L5_SRC.exists():
        raise SystemExit("关 5 的孪生不在：%s" % L5_SRC)
    got = md5(L5_SRC)
    if got != L5_MD5:
        raise SystemExit("关 5 孪生的 md5 %s ≠ 登记的 %s，拒绝开跑" % (got, L5_MD5))

    B = load_build()

    # —— 注入三样，全是加法 ——
    before = (len(B.SIDES), len(B.LEAK_WORDS), len(B.FORBIDDEN_FILES))
    B.SIDES["no5"] = (L5_SRC, L5_MD5)
    for w in NEW_LEAK_WORDS:
        if w not in B.LEAK_WORDS:
            B.LEAK_WORDS.append(w)
    B.FORBIDDEN_FILES |= NEW_TRUTH_FILES
    after = (len(B.SIDES), len(B.LEAK_WORDS), len(B.FORBIDDEN_FILES))

    print("注入（只加不改）：SIDES %d→%d · LEAK_WORDS %d→%d · FORBIDDEN_FILES %d→%d"
          % (before[0], after[0], before[1], after[1], before[2], after[2]))
    print("   SIDES['no5'] = %s" % L5_SRC.name)
    print("   原有的 ok / no 两档一个字没动：ok=%s no=%s"
          % (B.SIDES["ok"][0].name, B.SIDES["no"][0].name))
    # armkit/build.py 本体必须还是原样 —— 注入只在内存里
    print("   armkit/build.py 的磁盘 md5 %s（注入不落盘）" % md5(ARMKIT / "build.py")[:16])
    if a.method_addendum:
        src = (ARMKIT / "METHOD.md").read_text(encoding="utf-8")
        add = Path(a.method_addendum).read_text(encoding="utf-8")
        anchor = "`mathlib` **没有**。"
        assert src.count(anchor) == 1, "METHOD.md 里找不到 mathlib 那段"
        i = src.index(anchor)
        var = HERE / ("METHOD_variant_%s.md" % md5(Path(a.method_addendum))[:8])
        var.write_text(src[:i] + add + src[i:], encoding="utf-8", newline="\n")
        B.EXTRA["framework"]["doc"] = ("METHOD.md", var)
        B.EXTRA["framework_model"]["docs2"] = [("METHOD.md", var)]
        print("   METHOD.md 换成 %s（= 原件 + %s，md5 %s）"
              % (var.name, Path(a.method_addendum).name, md5(var)[:12]))
    print()

    args = ["--arms", a.plan, "--stage", a.stage, "--prior", a.prior, "--prior-scope", a.prior_scope]
    if not a.no_retries:
        args.append("--retries")
    if a.dry_run:
        args.append("--dry-run")
    if a.serve:
        args.append("--serve")
    return B.main(args)


if __name__ == "__main__":
    raise SystemExit(main())
