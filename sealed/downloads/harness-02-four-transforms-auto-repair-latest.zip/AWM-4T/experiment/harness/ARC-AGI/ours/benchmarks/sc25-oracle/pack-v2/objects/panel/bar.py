"""`Bar` —— 右边缘那根竖条：还剩几行是「满」的。

竖条两列，满的那一段从底往上数，消耗从顶上开始。**它只记一个数：满了几行。**

## 为什么删不掉

  rows —— 预算还剩多少只能从它读（「同一关之内只减不增」「过关回满」「压到燃料净涨」
          三条规则都读它，见 rule/world/）。

## 不存什么

  已经用掉了几「份」—— 竖条按整块（两行）量化显示，一次动作的开销小于一块时帧上看不出来。
  那一位是**历史**，帧上读不出来，所以不存；按它写的「每一步扣多少」也就不进模型
  （见 rule/out_of_model/bar_rate.py）。
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Bar:
    rows: int
