"""`World` —— 一帧里读得出来的全部状态。字段就是这一局的对象。

每个字段都要答判据 2：**抹掉它之后，哪一对世界从能区分变成不能区分？**
答案在 `analysis/<对象>.txt`，分离表在 `analysis/field_split.txt`，字段消融在 `analysis/readings.json`。

## 没进 World 的东西（写在明处）

  · 关卡号、状态字符串 —— 上游 API 给的，规则要用就从 `ctx` 读（戒律 3）。
  · 我身下压着什么 —— 帧上看不见，**表示不出来的就不存**。
  · 竖条用掉了几「份」—— 竖条按整块量化，帧上读不出来（见 objects/panel/bar.py）。
  · 场上那几圈「外圈角标」此刻藏着的那一半（涨缩时亮灭的那几组）——帧上是虚空，读不出来。
    它们在模型那一侧（Lean 的 `Board`）按整关拼出来，口径写在 lean2/Obs/Replay.lean。
"""
from __future__ import annotations

from dataclasses import dataclass

from .ground.ground import Ground
from .panel.bar import Bar
from .panel.legend import Legend  # noqa: F401  (legends 字段里的元素类型)
from .panel.pad import Pad
from .player.marker import Marker


@dataclass(frozen=True)
class World:
    me: Marker
    pad: Pad
    legends: frozenset          # {Legend}
    bar: Bar
    ground: Ground

    def legend_colors(self) -> frozenset:
        return frozenset(l.color for l in self.legends)

    def tile(self, p):
        """一格上是什么：Ground 的五种之一 / ("me",)（我压着，看不见）/ ("void",)。**只是查表。**"""
        if p in self.me.cells():
            return ("me",)
        return self.ground.kind(p)
