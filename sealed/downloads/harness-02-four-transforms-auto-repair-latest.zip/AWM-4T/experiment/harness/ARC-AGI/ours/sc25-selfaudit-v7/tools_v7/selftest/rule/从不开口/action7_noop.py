"""按 ACTION7：什么都不变。**自检故意放的一条**：语料里没有 ACTION7，它的 |scope| 必须是 0、必须判红。"""
from __future__ import annotations

from objects import read

CLAIM = "按 ACTION7：世界不变。"
EVIDENCE = []


def scope_(prev, action, nxt, ctx=None):
    return None if action == "ACTION7" else "不是 ACTION7"


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(prev) == read(nxt) else "FALSE"
