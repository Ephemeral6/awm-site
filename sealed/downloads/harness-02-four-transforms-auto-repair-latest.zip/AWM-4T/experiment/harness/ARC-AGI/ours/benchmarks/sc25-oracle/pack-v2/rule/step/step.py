"""按方向键：我的脸转到那一侧；前方一个自身边长的方区整块走得上去（地板或记号）就整块挪过去，否则原地不动。边长不变。"""
from __future__ import annotations

from derive.geometry import ahead, ahead_by, square
from derive.standing import all_socket, all_walkable
from objects import parse_action, read

from .._scope import first, level_changed, session_first, unreadable

CLAIM = ("按方向键（1 上 2 下 3 左 4 右）：我的脸转到那一侧（挪不挪都转）；"
         "先试**整块挪一个自身边长**（每一格都走得上去＝地板或记号）；"
         "**挪不动时，边长 4 的我再试挪 2**（半步）；两次都不行才原地不动；边长不变。")
SCOPE = ("只看方向键；换关那一步（→ socket_wins）、会话第一下（→ session_first_void）、读不成世界不管；"
         "前方方区整块是插座内胆那一步不管（→ socket_wins）。")
NOT_CLAIMED = ["不说边长 2 的我有没有半步（引擎只给 scale==2 那一支，边长 2 没有）",
               "不说燃料能不能走上去（语料里没有一次朝燃料走的方向键）",
               "不说越出场地会怎样（语料里 0 次）",
               "不说腾出来的格露出什么（ground_still 管：那是地面的事）"]
NOTE = [
    "起点：册子 move_iff_floor v11 + dir_delta v3 + facing_marks_action v2。",
    "第 1 轮（rules_v1）是两条：turn（朝向）与 move（位置）。卡 05 合成这一条：两条的论域逐字相同"
    "（方向键、同一关、不是会话第一下），只是结论各说一半——同一条规则被拆成了两条。",
    "合并的验收：拒绝集不缩（变异语料两条独家 9+1 → 合并后见 analysis/record.txt 第 2 轮）、无人区不增、判错不增。",
    "**更正（CORRECTIONS.md C）**：封存版写「否则原地不动」。引擎 sc25.py:3127-3132 在整块挪不动时，"
    "对 scale==2（边长 4）**再试挪 dx//2, dy//2**。实测：关 1 第 6 步按左，横坐标 37 → **35**（只挪 2）。",
    "所以**大身能停在非 4 格点上**——任何「大身只落在 4 的格点」的推理都不成立。",
]
EVIDENCE = ["da3e01cff498c8a1", "2e40e31fa60834cc", "fd67f106b9c9aa15", "d181e84f3fb7a473",
            "24b4fa49fe16626f", "15262396f435b24d"]


def _target(w, face):
    me = w.me
    r, c = ahead(me.row, me.col, me.side, face)
    return (r, c), square(r, c, me.side)


def scope_(prev, action, nxt, ctx=None):
    a = parse_action(action)
    if a[0] != "dir":
        return "不是方向键"
    w, nw = read(prev), read(nxt)
    r = first(level_changed(ctx), session_first(ctx), unreadable(w, nw))
    if r:
        return r
    if all_socket(w, _target(w, a[1])[1]):
        return "踏进插座 → socket_wins"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    face = parse_action(action)[1]
    (r, c), cells = _target(w, face)
    if all_walkable(w, cells):
        want = (r, c)
    else:
        # **更正 C**：整块挪不动时，边长 4 的我再试挪 2。
        half = w.me.side // 2
        hr, hc = ahead_by(w.me.row, w.me.col, half, face)
        # 半步的落点**和我现在压着的格重叠**，而模型不存我身下那几格
        # （看不见的不存，见 objects/ground/ground.py）。所以那几格按「我自己占着＝过得去」算。
        rest = square(hr, hc, w.me.side) - w.me.cells()
        want = ((hr, hc) if w.me.side == 4 and all_walkable(w, rest)
                else (w.me.row, w.me.col))
    ok = (nw.me.row, nw.me.col) == want and nw.me.side == w.me.side and nw.me.face == face
    return "TRUE" if ok else "FALSE"
