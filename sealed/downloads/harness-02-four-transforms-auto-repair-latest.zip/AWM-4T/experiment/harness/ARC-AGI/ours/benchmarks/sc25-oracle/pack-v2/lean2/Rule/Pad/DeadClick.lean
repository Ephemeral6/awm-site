/-
# dead_click —— 点空（对应 rule/pad/dead_click.py）

**定义，不是定理。** 点击没点中任何一个还没亮的格位，世界一格不变。
`padHit` 说点中了哪一格（版面在 `Board.padRects`）；`deadClick` 为真的那一下，`step` 原样返回。
-/

import Obj.Model.Board
import Obj.Model.St

namespace Game

def padHitAux (x y : Nat) : List (Nat × Nat × Nat × Nat) → Nat → Option Nat
  | [], _ => none
  | (t, l, bt, r) :: rest, i =>
    if t ≤ y && y ≤ bt && l ≤ x && x ≤ r then some i else padHitAux x y rest (i + 1)

def padHit (b : Board) (x y : Nat) : Option Nat := padHitAux x y b.padRects 0

def deadClick (b : Board) (s : St) (x y : Nat) : Bool :=
  match padHit b x y with
  | none => true
  | some i => s.pad[i]? == some PadCell.lit

end Game
