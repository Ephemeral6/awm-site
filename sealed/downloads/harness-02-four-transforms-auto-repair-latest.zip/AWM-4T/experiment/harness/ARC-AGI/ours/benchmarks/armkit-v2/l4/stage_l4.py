# -*- coding: utf-8 -*-
"""Stage the **level-4** arenas for the closed-proof rerun (l4c batch), via `armkit/build.py`, without editing it.

    python stage_l4.py --plan arms_plan_l4c_closed4.json --method-addendum ../l5/METHOD_addendum_closed_v4.md --dry-run
    python stage_l4.py --plan arms_plan_l4c_closed4.json --method-addendum ../l5/METHOD_addendum_closed_v4.md --serve

Same mechanism as `../l5/stage_l5.py` (runtime injection, additive only; armkit/build.py and armkit/METHOD.md
stay byte-identical on disk). Differences from stage_l5.py:

- no new SIDES entry: level 4 sealed is build.py's own side "no" (sc25_L4_b18.py, md5 7a922000...), checked by
  build.py before staging;
- the blinding lists get the **level-4** ground-truth files made since build.py's FORBIDDEN_FILES was written
  (sc25-budget certificates / certifiers / Lean bank proofs / exhaustive-search logs, the 19-cap witness), plus
  the level-5 names stage_l5.py adds (so these arenas are audited at least as strictly as the l5d ones);
- level-4 leak words (cap 19 / B* for level 4 / "level 4 not doable" phrasings) are added to LEAK_WORDS.

The METHOD addendum injection is copied verbatim from stage_l5.py, so with the same addendum file the staged
METHOD.md is byte-identical to the l5d batch's (`../l5/METHOD_variant_2adf4911.md`); this script checks that.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
V2 = HERE.parent
ARMKIT = V2.parent / "armkit"
BENCH = V2.parent
L5DIR = V2 / "l5"

L4_SRC = BENCH / "sc25-budget" / "variant" / "sc25_L4_b18.py"
L4_MD5 = "7a922000d167e160fa69886c3ff24686"
L5D_METHOD = L5DIR / "METHOD_variant_2adf4911.md"      # what the l5d arenas got

# level-4 ground truth made after build.py's list (matched by file NAME, like build.py)
L4_TRUTH_FILES = {
    "sc25_L4_b18.py", "sc25_L4_b18_fuelfix.py", "sc25_L4_b19.py", "sc25_L4_b20.py", "sc25_L4_b21.py",
    "sc25_L4_b25.py", "sc25_L4_fx2.py", "sc25_L4_fx2a_c11.py", "sc25_L4_fx2a_c12.py",
    "sc25_L4_fx2b_c16.py", "sc25_L4_fx2b_c17.py",
    "L4Bank18.lean", "L4BankWin19.lean", "L4Cert18.lean", "L4Cert18_broken.lean", "L4Model18.lean",
    "L4Win19.lean",
    "witness.json", "witness_l4.py",
    "exhaust17.log", "exhaust18.log", "exhaust18_counters.log", "exhaust19.log", "exhaust20.log",
    "exhaust_crosscheck.py", "recheck18.out", "colb_pad2bank_l4_cap18.json",
    "certify_l4.py", "certify_l4_fuelfix.py", "certify_l4_fx2.py", "certify_l4_naiveray.py", "certify_l4_pad.py",
    "certify_l4_relax.py", "certify_l4_smallfire.py", "certify_l4_smallfire_fuelfix.py",
    "genlean.py", "genlean2.py", "genlean3.py", "genlean_bank.py", "nonvac.py", "nonvac_bank.py",
    "ray_lv4.json", "ray_lv4.py", "rule_D.json", "rule_D.py", "bar_exact.json", "bar_rule.json",
    "REVIEW-20261012.md", "READINGS.md", "DECISIONS.md", "ASK.txt", "ask.json",
}
L4_TRUTH_FILES |= {"cert_l4_cap%d.json" % c for c in (17, 18, 19, 20)}
L4_TRUTH_FILES |= {"cert_l4bank_cap%d.json" % c for c in (17, 18, 19, 20)}
L4_TRUTH_FILES |= {"cert_l4pad_cap%d.json" % c for c in (17, 18, 19, 20)}
L4_TRUTH_FILES |= {"cert_l4naive_cap%d.json" % c for c in range(14, 20)}
L4_TRUTH_FILES |= {"cert_l4small_cap%d.json" % c for c in range(19, 25)}

L4_LEAK_WORDS = [
    "上限 19", "上限 17", "B*(关 4)", "B*(L4)", "关 4 不可做", "第 4 关不可做",
    "slfh 18", "slfh\": 18", "cap 18", "cap 19", "exhaust18", "exhaust19",
]


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--serve", action="store_true")
    ap.add_argument("--method-addendum", required=True)
    ap.add_argument("--method-addendum2", default="",
                    help="(2026-10-21) optional second METHOD section, inserted before --anchor2")
    ap.add_argument("--anchor2", default="# 第二步：把规则变成对象")
    a = ap.parse_args(argv)

    if md5(L4_SRC) != L4_MD5:
        raise SystemExit("level-4 sealed engine md5 %s != registered %s" % (md5(L4_SRC), L4_MD5))

    sys.path.insert(0, str(ARMKIT))
    B = load("armkit_build", ARMKIT / "build.py")
    S5 = load("stage_l5_lists", L5DIR / "stage_l5.py")    # only for its two lists; its main() is not called

    assert B.SIDES["no"] == (L4_SRC, L4_MD5), B.SIDES["no"]
    before = (len(B.LEAK_WORDS), len(B.FORBIDDEN_FILES))
    for w in L4_LEAK_WORDS + S5.NEW_LEAK_WORDS:
        if w not in B.LEAK_WORDS:
            B.LEAK_WORDS.append(w)
    B.FORBIDDEN_FILES |= L4_TRUTH_FILES | S5.NEW_TRUTH_FILES
    print("injected (additive only): LEAK_WORDS %d->%d, FORBIDDEN_FILES %d->%d"
          % (before[0], len(B.LEAK_WORDS), before[1], len(B.FORBIDDEN_FILES)))
    print("   side 'no' = %s (md5 %s)" % (L4_SRC.name, L4_MD5))
    print("   armkit/build.py on-disk md5 %s (injection is in memory only)" % md5(ARMKIT / "build.py")[:16])

    # METHOD addendum: verbatim the stage_l5.py logic
    src = (ARMKIT / "METHOD.md").read_text(encoding="utf-8")
    add = Path(a.method_addendum).read_text(encoding="utf-8")
    anchor = "`mathlib` **没有**。"
    assert src.count(anchor) == 1, "anchor paragraph not found in METHOD.md"
    i = src.index(anchor)
    var = HERE / ("METHOD_variant_%s.md" % md5(Path(a.method_addendum))[:8])
    var.write_text(src[:i] + add + src[i:], encoding="utf-8", newline="\n")
    B.EXTRA["framework"]["doc"] = ("METHOD.md", var)
    B.EXTRA["framework_model"]["docs2"] = [("METHOD.md", var)]
    same = L5D_METHOD.exists() and md5(var) == md5(L5D_METHOD)
    print("   METHOD.md -> %s (md5 %s) %s l5d's %s"
          % (var.name, md5(var)[:12], "==" if same else "!= (DIFFERENT FROM)", L5D_METHOD.name))
    if not same:
        raise SystemExit("staged METHOD.md differs from the l5d batch's; refusing")
    if a.method_addendum2:
        # (2026-10-21) a second section at its own anchor; the result must be l5d's METHOD.md + exactly that section
        base = var.read_text(encoding="utf-8")
        add2 = Path(a.method_addendum2).read_text(encoding="utf-8")
        assert base.count(a.anchor2) == 1, "anchor2 not found exactly once in METHOD.md"
        j = base.index(a.anchor2)
        var2 = HERE / ("METHOD_variant_%s_%s.md" % (md5(Path(a.method_addendum))[:8], md5(Path(a.method_addendum2))[:8]))
        var2.write_text(base[:j] + add2 + base[j:], encoding="utf-8", newline="\n")
        assert var2.read_text(encoding="utf-8").replace(add2, "", 1) == L5D_METHOD.read_text(encoding="utf-8")
        B.EXTRA["framework"]["doc"] = ("METHOD.md", var2)
        B.EXTRA["framework_model"]["docs2"] = [("METHOD.md", var2)]
        print("   + %s inserted before %r -> %s (md5 %s) == l5d's METHOD.md + that section"
              % (Path(a.method_addendum2).name, a.anchor2, var2.name, md5(var2)[:12]))
    print(flush=True)                   # build.py re-wraps sys.stdout; flush ours first or it is lost

    args =["--arms", str(Path(a.plan).resolve()), "--stage", a.stage, "--retries"]
    if a.dry_run:
        args.append("--dry-run")
    if a.serve:
        args.append("--serve")
    return B.main(args)


if __name__ == "__main__":
    raise SystemExit(main())
