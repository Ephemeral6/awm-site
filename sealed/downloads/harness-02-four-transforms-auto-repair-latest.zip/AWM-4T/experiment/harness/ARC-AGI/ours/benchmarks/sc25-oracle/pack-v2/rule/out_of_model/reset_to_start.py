"""RESET 把局面放回这一关的开局：RESET 之后那一帧读出来的世界，和这一段里这一关的第一帧读出来的世界一模一样。"""
from __future__ import annotations

from objects import read

CLAIM = "关号不变的 RESET 之后，世界等于这一段语料里这一关第一帧的世界（我、面板、竖条、地面，全部）。"
SCOPE = "只看关号不变的 RESET；上游没给这一关的第一帧、读不成世界，不管。"
NOT_CLAIMED = ["不说换卡那一下（关号归零）之后是什么——那是另一个会话的开局"]
WHY_OUT = ("「这一关的开局长什么样」不是当前状态的函数，是历史，一帧上读不出来。"
           "硬塞一个「开局」字段进世界，就是给模型加一位帧上读不出来的信息。"
           "所以在 Lean 那一侧它是一条写在明处的假设，不是一条定义。")
NOTE = ["新写的一条：册子 reset_restores_level 说过「没断言位置」，map_static v8 记过「重开会把被吃掉的标本吐回来」；"
        "这里把两句话合成一句更强的、可判错的话。",
        "ctx.level_start 是语料里记下的那一帧（上游事实：这一关在这一段的第一帧），不是从像素推出来的。"]
EVIDENCE = ["56b830dc960999ad", "539080c3ab54f231"]


def scope_(prev, action, nxt, ctx=None):
    if action != "RESET":
        return "不是 RESET"
    if not ctx or ctx.get("level_prev") != ctx.get("level_next"):
        return "关号变了（换卡）"
    if ctx.get("level_start") is None:
        return "ctx 缺这一关的第一帧"
    if read(nxt) is None or read(ctx["level_start"]) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(nxt) == read(ctx["level_start"]) else "FALSE"
