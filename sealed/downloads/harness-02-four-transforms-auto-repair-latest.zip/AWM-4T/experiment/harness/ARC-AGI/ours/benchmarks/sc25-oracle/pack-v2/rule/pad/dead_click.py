"""点在大面板外是免费的：整帧一格不变——连竖条都不走。点在**已经亮的格位上不是空点**（那是翻转）。"""
from __future__ import annotations

from derive.pad_hits import clicked
from objects import parse_action, read

from .._scope import unreadable

CLAIM = "点击**没点中大面板的任何一个格位**（点在面板外）：世界一格不变，竖条也不扣。"
SCOPE = "只看点击；点中了大面板任何一个格位的（→ click_lights / completion_clears）、读不成世界，不管。"
NOT_CLAIMED = ["不说点在场地别处（燃料、框、插座上）和点在小面板上有没有区别——两者都没点中大面板，这里一视同仁"]
NOTE = [
    "起点：册子 click_dead_is_free。",
    "**更正（CORRECTIONS.md B）**：封存版把「点在已经亮的格位上」也算成空点，并声明那一支是推广。",
    "那条推广是错的：引擎 sc25.py:3072 是翻转，那一格会灭掉，而且 rrinmfkkstu 照 +1。",
    "随机走 1391 条转移里，封存版这一条判错 **381 处**；论域收窄到「点在面板外」之后那 381 处全部归位。",
]
EVIDENCE = ["6900c748911db55b", "a58dabe7ec5e29d9"]


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if clicked(w, action) is not None:
        return "点中了大面板 → click_lights / completion_clears"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(prev) == read(nxt) else "FALSE"
