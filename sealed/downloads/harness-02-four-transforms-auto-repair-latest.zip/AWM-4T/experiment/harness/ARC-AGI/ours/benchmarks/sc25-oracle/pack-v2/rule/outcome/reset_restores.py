"""RESET 之后：竖条满格、大面板一格不亮、我的边长回到 4；关号要么不变、要么归零。"""
from __future__ import annotations

from objects import read

CLAIM = "RESET 之后：竖条 64 行全满、大面板一格不亮、我的边长是 4；上游关号要么不变，要么归零。"
SCOPE = "只看 RESET；RESET 之后那一帧读不成世界，不管。"
NOT_CLAIMED = ["不说我被放回哪（「放回这一关的开局」是一条更强的话，归 说了但不进模型/reset_to_start）"]
NOTE = [
    "起点：册子 reset_restores_level v2（关号那半句被换卡那一下打成「不变或归零」）。",
]
EVIDENCE = ["56b830dc960999ad", "539080c3ab54f231"]


def scope_(prev, action, nxt, ctx=None):
    if action != "RESET":
        return "不是 RESET"
    if read(nxt) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    nw = read(nxt)
    if not (nw.bar.rows == 64 and not nw.pad.lit() and nw.me.side == 4):
        return "FALSE"
    lp, ln = (ctx or {}).get("level_prev"), (ctx or {}).get("level_next")
    if lp is None or ln is None:
        return "TRUE"
    return "TRUE" if ln in (lp, 0) else "FALSE"
