# -*- coding: utf-8 -*-
r"""**补全轮**（2026-10-16）：续上 AWM 臂原来的会话，请它把不可做的证明补成**完整**的。

    python completion_round.py --case m15fw-case-ff069f --dry-run
    python completion_round.py --case m15fw-case-ff069f
    python completion_round.py --all                      # 五条顺序跑

## 这一轮回答哪个问题

论文 §4 里 AWM 臂的 Lean 有两类缺口（见 DECISIONS 2026-10-16「补全轮」）：

```
① 全称定理没收口     关 4 ff069f：界 19 只来自它对自己模型的穷举，Lean 界证明没被核过（13 GB 那份）
                     关 5 模型臂 6b1c90：证明的前提放在 Lean 之外
② 模型与引擎不符     关 4 9ec8d4（界 20）、关 5 a4e7d2（三条规则不符、误差抵消）
```

这一轮只问 ①：**不告诉它任何关于真值、关于引擎、关于它哪里错的信息**，只给一份「完整证明」的验收清单，
看它能不能在**当时的 AWM**（它自己的跑场、规则、Lean、记录）上把证明补完整。
② 不是这一轮能回答的（要么给反馈 —— 那是 repair_round.py，要么拿引擎核 —— 那是我们的事）。

## 追问原文（预登记，一个字不许临场改）

见 `PROMPT`。要点：不再玩、不给数；五条验收（全称定理 / 内核收口 / 前提进陈述且尽量弱 / 不空洞：证出模型里
的最小可赢预算并给见证 / 15 分钟 4 GB 内编得过）。

## 判据（预登记）

```
完整      我们自己编 lean/FinalProof.lean：编得过、公理只有 propext/Classical.choice/Quot.sound、
          无 sorry / native_decide / axiom 声明；主定理对全部动作串量化；有见证定理
部分      编得过且干净，但主定理不是全称（只对某条路线 / 某个子集）或缺见证
失败      编不过、超时、超内存（看门狗杀掉）、公理不干净、或没交 FinalProof.lean
```

「主定理是不是全称」「前提是否都写进陈述」要读文件判，读完写进 `completion/<case>.json` 的 `audit` 字段。
**完整 ≠ 对**：界与引擎 B*（关 4 = 19、关 5 = 36）是否一致、前提在引擎上是否成立，单列，另做。

## 机器安全

每条开跑前等可用内存 >= 4 GB；跑的时候看门狗每 15 秒看一次：任何 lean.exe 工作集 > 4 GB、或整机可用 < 0.8 GB，
杀掉最大的那个 lean.exe 并**记进读数**（那是一次干预）。开跑前把整个跑场复制到
`D:/arc-arena-archive/completion-20261016/<case>/`，原件的改动可追溯。
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import io
import json
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run import drive                                            # noqa: E402
import leancheck as LC                                           # noqa: E402

STAGE = Path(__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
ARCHIVE = Path((__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/completion-20261016"))
OUTD = HERE / "completion"
CASES = {
    "m15fw-case-ff069f": dict(level=4, budget=18, why="Lean 界证明没被核过（BoundCheck 吃过 13 GB）"),
    "l5v2-case-6b1c90": dict(level=5, budget=35, why="模型臂：前提在 Lean 之外"),
    "m15fw-case-69fe87": dict(level=4, budget=18, why="已完整（界 19）—— 对照：看它会不会改坏"),
    "m15fw-case-9ec8d4": dict(level=4, budget=18, why="模型内完整但界 20 —— 对照：只问完整性不会修正模型"),
    "l5v2-case-a4e7d2": dict(level=5, budget=35, why="模型内完整（36）—— 对照"),
}
ORDER = list(CASES)

PROMPT = """One more task on the same level. Do not play any more; work only from your own records, rules and Lean files.

We want the most complete proof you can give of your verdict about this level, as Lean that we will compile ourselves. Put it in `lean/FinalProof.lean` (it may import your other files). We will accept it only if every point below holds, and we will check each one:

1. Main theorem. One theorem stating that no action list of your model wins within the level's budget as you have measured it. It must quantify over all action lists: not a statement about one plan, not a search you ran outside Lean, not a hand count.
2. Kernel-checked. No `sorry`, no `native_decide`, no `axiom` declarations. End the file with `#print axioms` for the main theorem; only `propext`, `Classical.choice` and `Quot.sound` may appear.
3. Assumptions in the statement. Every rule of your model that you have not verified against recorded steps must appear as an explicit hypothesis of the main theorem, with a comment naming the observations it rests on. Where your evidence leaves a rule open, state the hypothesis as weakly as the evidence allows, so that the theorem covers every reading consistent with what you saw.
4. Not vacuous. In the same model, prove the least budget at which a win exists, with a second theorem that exhibits a winning action list at that budget, and say what that budget is.
5. Feasible. The file must compile with the toolchain described in METHOD.md in under 15 minutes and under 4 GB of memory on this machine. If deciding the whole state space directly is too large, use a smaller abstraction and prove in Lean that it is sound.

Then write `lean/FINAL_README.md`: the main theorem's name and what it says in plain words, each hypothesis and the evidence for it, the bound, the witness theorem, and anything you could not close.

End with the usual two lines: VERDICT=... and CONFIDENCE=...
"""

LOG = HERE / "completion_round.log"
LEAN_CAP_GB = 4.0
FLOOR_GB = 0.8


def say(msg):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with io.open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def ps(cmd):
    r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True,
                       timeout=90, encoding="utf-8", errors="replace")
    return r.stdout or ""


def avail_gb():
    try:
        return float(ps("(Get-Counter '\\Memory\\Available MBytes').CounterSamples[0].CookedValue").strip()) / 1024
    except Exception:                                       # noqa: BLE001
        return 0.0


def leans():
    """**只认本脚本的子孙** lean.exe（沿父进程链往上找到本进程 PID）。
    另一个会话的框架臂也在跑 Lean，不能误杀它的。"""
    import os
    me = os.getpid()
    # **看私有提交内存，不看工作集**（2026-10-17 踩过）：整机内存紧时进程被换出，工作集会显得很小，
    # 一个占 13.9 GB 的 lean.exe 在工作集上只有 1 GB 上下，看门狗就漏过了它。取两者较大的那个。
    out = ps("Get-CimInstance Win32_Process | ForEach-Object { '{0} {1} {2} {3}' -f $_.ProcessId, $_.ParentProcessId, "
             "[Math]::Max([int64]$_.WorkingSetSize, [int64]$_.PrivatePageCount), $_.Name }")
    parent, info = {}, {}
    for ln in out.splitlines():
        p = ln.split(None, 3)
        if len(p) == 4 and p[0].isdigit() and p[1].isdigit():
            parent[int(p[0])] = int(p[1])
            info[int(p[0])] = (p[3].strip().lower(), int(p[2]) if p[2].isdigit() else 0)
    res = []
    for pid, (name, ws) in info.items():
        if name != "lean.exe":
            continue
        q, hops = pid, 0
        while q in parent and hops < 15:
            q = parent[q]
            hops += 1
            if q == me:
                res.append((pid, ws / 2 ** 30))
                break
    return res


class Watchdog(threading.Thread):
    def __init__(self, tag):
        super().__init__(daemon=True)
        self.tag, self.stop, self.events = tag, threading.Event(), []

    def run(self):
        while not self.stop.wait(15):
            ls = leans()
            a = avail_gb()
            big = [x for x in ls if x[1] > LEAN_CAP_GB]
            if big or (ls and a < FLOOR_GB):
                pid, gb = max(big or ls, key=lambda x: x[1])
                subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
                ev = {"t": time.time(), "phase": self.tag, "pid": pid, "lean_gb": round(gb, 2), "avail_gb": round(a, 2)}
                self.events.append(ev)
                say("**看门狗干预**（%s）：杀 lean pid=%d（%.1f GB，整机可用 %.2f GB）" % (self.tag, pid, gb, a))


def md5(p):
    return hashlib.md5(p.read_bytes()).hexdigest()


def lean_snapshot(d):
    return {str(f.relative_to(d)).replace("\\", "/"): md5(f) for f in sorted(d.rglob("*.lean"))
            if ".lake" not in f.parts}


def static_scan(f: Path):
    t = f.read_text(encoding="utf-8", errors="replace")
    body = re.sub(r"--[^\n]*", "", re.sub(r"/-.*?-/", "", t, flags=re.S))
    return {"sorry": len(re.findall(r"\bsorry\b", body)),
            "native_decide": len(re.findall(r"\bnative_decide\b", body)),
            "axiom_decl": len(re.findall(r"^\s*axiom\s", body, flags=re.M)),
            "theorems": re.findall(r"^\s*theorem\s+(\S+)", body, flags=re.M),
            "print_axioms": re.findall(r"#print\s+axioms\s+(\S+)", body)}


def one(case, dry):
    spec = CASES[case]
    d = STAGE / case
    assert d.exists(), d
    say("=" * 70)
    say("%s · 关 %d · 预算 %d · %s" % (case, spec["level"], spec["budget"], spec["why"]))
    if dry:
        print(PROMPT)
        return None
    while avail_gb() < 4.0:
        say("等内存：可用 %.1f GB < 4 GB" % avail_gb())
        time.sleep(60)
    dst = ARCHIVE / case
    if not dst.exists():
        shutil.copytree(d, dst, ignore=shutil.ignore_patterns("*.olean", "*.ilean", ".lake"))
        say("跑场已存档 → %s" % dst)
    before = lean_snapshot(d)
    wd = Watchdog("drive")
    wd.start()
    t0 = time.time()
    out = drive("claude", d, PROMPT, first=False)
    wd.stop.set()
    say("续问结束 rc=%s · %.0f 秒" % (out.get("returncode"), time.time() - t0))
    after = lean_snapshot(d)
    changed = sorted(k for k in after if before.get(k) != after[k])
    final = d / "lean" / "FinalProof.lean"
    rec = {"case": case, **spec, "prompt": PROMPT, "reply": out, "changed_lean": changed,
           "final_exists": final.exists(), "watchdog_drive": wd.events}
    if final.exists():
        rec["static"] = static_scan(final)
        wd2 = Watchdog("check")
        wd2.start()
        res = LC.check_files(d, ["lean/FinalProof.lean"], timeout=900, built={})
        wd2.stop.set()
        rec["check"] = res
        rec["watchdog_check"] = wd2.events
        f0 = (res.get("files") or [{}])[0]
        say("我们自己编 FinalProof.lean：compiles=%s clean=%s · 定理 %d 条 · sorry %d · native_decide %d · axiom %d"
            % (f0.get("compiles"), f0.get("clean"), len(rec["static"]["theorems"]), rec["static"]["sorry"],
               rec["static"]["native_decide"], rec["static"]["axiom_decl"]))
        rd = d / "lean" / "FINAL_README.md"
        rec["readme"] = rd.read_text(encoding="utf-8", errors="replace") if rd.exists() else None
    else:
        say("**没交 lean/FinalProof.lean**")
    m = re.findall(r"VERDICT\s*=\s*(\S+)", out.get("text") or "")
    c = re.findall(r"CONFIDENCE\s*=\s*(\d+)", out.get("text") or "")
    rec["verdict"] = {"verdict": m[-1] if m else None, "confidence": c[-1] if c else None}
    say("判定 %s / %s · 改过/新增 .lean %d 份" % (rec["verdict"]["verdict"], rec["verdict"]["confidence"], len(changed)))
    OUTD.mkdir(exist_ok=True)
    (OUTD / ("%s.json" % case)).write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
    return rec


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default=None)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    cases = ORDER if a.all else [a.case]
    for c in cases:
        if not a.dry_run and (OUTD / ("%s.json" % c)).exists():
            say("%s 已有读数，跳过（要重跑先挪走 completion/%s.json）" % (c, c))
            continue
        one(c, a.dry_run)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
