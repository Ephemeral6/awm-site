"""地面在动作之间是死的：凑齐图案那一下之外，两帧都看得见的每一格，地面的五层一格不变——被我吃掉的那坨燃料除外。"""
from __future__ import annotations

from derive.fuel import eaten
from derive.pad_hits import completes
from objects import read

from .._common import ground_diff
from .._scope import first, is_reset, level_changed, unreadable

CLAIM = ("凑齐图案那一下之外，一关之内的任何一步：两帧都看得见的格子上，地板、记号、实心块、燃料、插座五层一格不变；"
         "唯一的例外是这一步被我压到的那一坨燃料（它归 fuel_absorbs）。")
SCOPE = "换关那一步、RESET、凑齐图案那一下（→ 三台机器/）、读不成世界，不管。我前后两帧压着的格不看。"
NOT_CLAIMED = ["不说我身下压着什么（看不见的格不比）"]
NOTE = [
    "起点：册子 board_static v4 + map_static v10 + marks_are_ground v4——三条都在说「地面在动作之间是死的」，"
    "各看一部分格子（方向键只动两块方区 / 地板+记号+我是同一个集合 / 记号是死层），合成一条、五层一起比。",
    "map_static 那几版挖掉的「站在外描边框里」「内画四角」两种情形这里不用挖：比的是两帧都看得见的格，"
    "我身下的那几格本来就不在比较里——那一坑是「把看不见的格按地板算」挖出来的，这里不按任何东西算。",
]
EVIDENCE = ["da3e01cff498c8a1", "fd67f106b9c9aa15", "477bf0b6c6fc98eb", "9dabb54dca80d95d",
            "2657799cd7a750eb", "d181e84f3fb7a473", "58293a15fc50c8fa", "fb8f919988b954c8",
            "3845a0fa0ef1f599", "8946dcc83255fbab"]


def scope_(prev, action, nxt, ctx=None):
    w, nw = read(prev), read(nxt)
    r = first(level_changed(ctx), is_reset(action), unreadable(w, nw))
    if r:
        return r
    if completes(w, action) is not None:
        return "凑齐图案 → resize/teleport/erase"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    return "TRUE" if not ground_diff(w, nw, skip=eaten(w, nw)) else "FALSE"
