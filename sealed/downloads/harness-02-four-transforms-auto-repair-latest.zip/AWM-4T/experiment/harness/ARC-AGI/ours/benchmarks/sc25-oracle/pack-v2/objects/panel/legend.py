"""`Legend` —— 一块小面板：一个记号色 + 一套 3×3 图案（哪几个格位画着记号）。

一关可以挂好几块。每块小面板对应场上一台「机器」，**认机器靠记号色**：
凑齐的是哪一块的图案，动的就是哪一台（见 rule/machines/）。

## 为什么删不掉

  color   —— 同一套图案、不同的记号色，凑齐之后动的是不同的机器；场上哪些格是「记号」也按它认。
  pattern —— 凑齐判据就是「点亮的格位 == 某块的 pattern」。

## 没被排除的替代读法（写在明处）

「认机器靠记号色」和「认机器靠图案」在整批语料里**完全共变**
（菱形总是一个色、竖线总是一个色、拐角总是一个色），这批语料分不开它们。
所以这里两样都存，规则按色认；哪天出现同色异图案，分离表会第一个报出来。
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Legend:
    color: int
    pattern: frozenset      # {(行号, 列号)}，0..2
