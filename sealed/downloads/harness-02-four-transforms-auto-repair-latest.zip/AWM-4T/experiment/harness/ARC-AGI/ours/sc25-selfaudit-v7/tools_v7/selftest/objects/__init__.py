"""自检用的**玩具对象层**（和任何一局都无关）。契约三样：World / parse / ParseError。"""
from __future__ import annotations

from .parse import ParseError, parse          # noqa: F401
from .world import World                      # noqa: F401

__all__ = ["World", "parse", "ParseError", "read"]


def read(frame):
    """帧 → World；读不成返回 None。**parse 按本模块的全局名现取**，消融换掉 objects.parse 时这里当场用上新的。"""
    try:
        return parse(frame)
    except ParseError:
        return None
