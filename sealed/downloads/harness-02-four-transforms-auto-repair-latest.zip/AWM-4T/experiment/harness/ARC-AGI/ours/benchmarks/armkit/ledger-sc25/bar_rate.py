"""预算尺跑不过 32/50 块每步：已消耗块数 ≤ floor((step-1)*32/50)。"""
LEVEL = "L4"
SCOPE = "只看第 0 关内的转移（ctx.level_prev == ctx.level_next == 0）；没有 ctx 返回 NA。换关后预算尺怎么走还没测过。"
NOTE = "v2 断言的是等号（已消耗 = floor((step-1)*32/50)），在第 14、16 步被两次空点击打掉：" \
       "空点击不推动这把尺子，所以尺子量的是「被世界接受的动作数 n」而不是 step-1，而 n 不是单条转移读得出来的量" \
       "（c = floor(n*32/50)，0.64<1 让 c 对应两个可能的 n）。等号改成不等号后仍然可判错，而且给出预算的硬上界：" \
       "尺子满格 32 块 ⇒ 至少还能发 (32-c)*50/32 条动作。exact 那一版的数据留在 history/bar_rate.v2.py。"
EVIDENCE = ["da3e01cff498c8a1", "57d8819abf0ed7b8", "959d794af724ea4a",
            "6900c748911db55b", "a58dabe7ec5e29d9"]

TOTAL_BLOCKS = 32
BUDGET = 50

from _lib import bar_blocks


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("step") is None:
        return "NA"
    if ctx.get("level_prev") != 0 or ctx.get("level_next") != 0:
        return "NA"
    n = ctx["step"] - 1
    spent = TOTAL_BLOCKS - bar_blocks(nxt)
    return "TRUE" if spent <= (n * TOTAL_BLOCKS) // BUDGET else "FALSE"
