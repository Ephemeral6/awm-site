# -*- coding: utf-8 -*-
"""Diagnostic readouts for four-direction condensation. These are tests, not extra criteria.
See tools/CONTRACT.md; finite-corpus readings never establish universal redundancy.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import random
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _v7io import ObjLayer, load_rules, load_transitions, reloader, utf8_stdout   # noqa: E402

MARK_A = "# ===== 装置读数（每次结算重写，别手改这一段）====="
MARK_B = "# ===== 以上由装置写；下面是你的 ====="
# 新文件里分隔线下面先铺这一段。**它算「还没交代」**——关口按这个判有没有人写过话，
# 拿模板当交代的话，关口会对着装置自己写的字变绿。
PLACEHOLDER = ("（下面是你写的：为什么它必要 / 为什么删得掉。\n"
               " 判据是**信息抹去**——抹掉这一位之后，玩法还能不能正确运行？\n"
               " 抹不掉就写出那一对**具体的**世界状态：原来能区分、抹掉之后无论如何都区分不了。）\n")
MUT_CAP = 120                    # 变异上限。再多边际信息很小，而每一批都要付这笔钱
ABL_CAP = None                   # 消融默认用**全语料**。原来默认等距抽 200 条：
                                 # 只在少数帧出现的字段一条都抽不进来，就被报成「没人用」；
                                 # 规则要往回翻的历史也被截断。省下的那一两分钟不值这个误报。
                                 # 要抽样就显式传 `ablate(..., sample=N)`，分母照实公示。
LAST_ABLATE: dict = {}           # 最近一次消融的分母拆分（行数 / 真实 / 变异 / 语料），读数照它写
MUT_CELLS = 3                   # 「改几格」那一种改几格
SEED = 0x5EED                     # 固定种子：**变异要可复现**，否则读数每批都在抖
ENDED = ("WIN", "GAME_OVER")     # 上游说「这一步之后整局结束了」：那一帧多半不是一张可玩的盘
HANDOFF_RE = re.compile(r"(?:→|->)\s*([^\s，,。；;）)]+(?:\s*/\s*[^\s，,。；;）)]+)*)")


# ---------------------------------------------------------------- 能不能跑

def can_run(mod, concepts: list[dict]) -> str | None:
    """跑不了就说清为什么。返回 None = 能跑。"""
    if mod is None:
        return "对象层还没立起来（跑场根上的 objects/）"
    W = getattr(mod, "World", None)
    if W is None or not dataclasses.is_dataclass(W):
        return "objects/ 里没有 dataclass 的 World —— 字段数不出来，判据无处施力"
    if not callable(getattr(mod, "parse", None)):
        return "objects/ 里没有 parse(frame) -> World"
    if not concepts:
        return "册子还是空的"
    return None


def pick(trs: list[dict], cap: int | None) -> list[dict]:
    """等距抽样。**不取前 N 条**：前 N 条全是第一关，后面几关一条都进不来。`cap=None` = 全要。"""
    if cap is None or len(trs) <= cap:
        return list(trs)
    step = len(trs) / cap
    return [trs[int(i * step)] for i in range(cap)]


def _key(g) -> str:
    return hashlib.sha1(repr(g).encode("utf-8")).hexdigest()[:16]


def parse_all(mod, frames: list) -> tuple[dict, list]:
    """每一帧只解析一次。返回（指纹 → World，读不出来的那些指纹）。"""
    worlds, bad = {}, []
    for g in frames:
        k = _key(g)
        if k in worlds or k in bad:
            continue
        try:
            worlds[k] = mod.parse(g)
        except Exception:                                         # noqa: BLE001
            bad.append(k)
    return worlds, bad


# ---------------------------------------------------------------- 跑一遍册子

def _call(c: dict, prev, action: str, nxt, ctx) -> str:
    """一条规则在一条转移上说什么。抛异常算 ERROR（**不算 NA**：没跑起来不等于不管）。"""
    try:
        sc = c.get("scope_fn")          # 键名跟 settle.load_concepts 走，别另起一套
        if callable(sc):
            r = sc(prev, action, nxt, ctx) if c.get("scope_arity", 4) == 4 else sc(prev, action, nxt)
            if r:
                return "NA"
        f = c["fn"]
        v = f(prev, action, nxt, ctx) if c.get("arity", 4) == 4 else f(prev, action, nxt)
        return v if v in ("TRUE", "FALSE", "NA") else "ERROR"
    except Exception:                                             # noqa: BLE001
        return "ERROR"


def verdicts(concepts: list[dict], rows: list[dict], ctx_of) -> dict[str, dict[str, str]]:
    """{概念: {行号: 裁定}}。这是消融要比对的那张表。

    按**行号**不按 tid：分母里有变异，而一条真实转移会派生出好几个变异，tid 是一样的。
    用 tid 当键，同一个 tid 的几行会互相覆盖——读数会**变小**，而且不会报错。
    """
    out: dict[str, dict[str, str]] = {}
    for c in concepts:
        row = {}
        for i, t in enumerate(rows):
            row[i] = _call(c, t["prev"], t["action"], t["next"], ctx_of(t))
        out[c["name"]] = row
    return out


# ---------------------------------------------------------------- 一、字段消融

def ablate(mod, concepts: list[dict], trs: list[dict], ctx_of,
           reload_fn, muts: list[dict] | None = None,
           sample: int | None | object = ...) -> tuple[dict[str, dict], int]:
    """逐个字段抹成常量，重跑全部规则，数判决变了几处。

    `reload_fn()` 要在 `objects.parse` 被换掉之后**重新导入概念**——
    概念是 `from objects import parse` 绑定的函数对象，不重新导入就还拿着旧的那个，
    抹了等于没抹，而且**不会报错**，只会安静地全都「没变化」。

    不传 `sample` = 按模块级 `ABL_CAP`（默认 None = 全语料；调用时读，局里的脚本改它照样生效）；
    `sample=N` = 等距抽 N 条。返回的分母 = 真实行数 + 变异数。
    """
    fields = [f.name for f in dataclasses.fields(mod.World)]
    sample = pick(trs, ABL_CAP if sample is ... else sample)
    rows = sample + list(muts or [])             # **分母含变异**，理由见文件头
    LAST_ABLATE.clear()
    LAST_ABLATE.update(rows=len(rows), real=len(sample), muts=len(muts or []), corpus=len(trs))
    frames = [t[k] for t in rows for k in ("prev", "next")]
    worlds, bad = parse_all(mod, frames)
    if not worlds:
        return {f: {"changed": -1, "note": "一帧都读不出来"} for f in fields}, len(rows)

    real = getattr(mod, "parse")
    first = worlds[next(iter(worlds))]
    base = verdicts(concepts, rows, ctx_of)

    out = {}
    for name in fields:
        const = getattr(first, name)

        def patched(g, _n=name, _c=const):
            k = _key(g)
            if k not in worlds:
                raise mod.ParseError("这一帧读不出来")
            return dataclasses.replace(worlds[k], **{_n: _c})

        setattr(mod, "parse", patched)
        try:
            cs = reload_fn()
            got = verdicts(cs, rows, ctx_of)
        except Exception as e:                                    # noqa: BLE001
            out[name] = {"changed": -1, "note": f"重跑炸了：{type(e).__name__}"}
            continue
        finally:
            setattr(mod, "parse", real)

        chg = err = 0
        for cn, row in base.items():
            new = got.get(cn, {})
            for i, v in row.items():
                w = new.get(i)
                if w != v:
                    chg += 1
                    if w == "ERROR" and v != "ERROR":
                        err += 1
        out[name] = {"changed": chg, "errors": err}
    reload_fn()                        # 把真的 parse 装回去，别让后面拿到打过补丁的册子
    return out, len(rows)


def ablate_selfcheck(mod, concepts: list[dict], rows: list[dict], ctx_of, reload_fn) -> dict:
    """**必红的补丁**：parse 换成「每一帧都读不出来」，重跑。判决一处都没变 ⇒ 补丁打不到规则。

    这是卡 07「先验证变异机制自己是活的」在消融这一侧的那一刀：
    `from X import f` 之后再给 `X.f` 打补丁不生效，十个字段于是全报「没人用」，
    而那和「真没人用」读数上长得一模一样。只在开过口的规则上才有意义（全是 NA 的册子换了 parse 也还是 NA）。
    """
    base = verdicts(concepts, rows, ctx_of)
    opened = sum(1 for row in base.values() for v in row.values() if v in ("TRUE", "FALSE"))
    real = getattr(mod, "parse")

    def broken(g):
        raise mod.ParseError("必红的补丁：每一帧都读不出来")

    setattr(mod, "parse", broken)
    try:
        got = verdicts(reload_fn(), rows, ctx_of)
    finally:
        setattr(mod, "parse", real)
        reload_fn()
    chg = sum(1 for cn, row in base.items() for i, v in row.items() if got.get(cn, {}).get(i) != v)
    deaf = sorted(cn for cn, row in base.items()
                  if any(v in ("TRUE", "FALSE") for v in row.values())
                  and all(got.get(cn, {}).get(i) == v for i, v in row.items()))
    return {"opened": opened, "changed": chg, "alive": chg > 0 or opened == 0, "deaf_rules": deaf}


# ---------------------------------------------------------------- 二、变异测试

def hot_cells(trs: list[dict]) -> list[tuple[int, int]]:
    """语料里**真的会变**的那些格。只有它们携带信息。"""
    hot = set()
    for t in trs:
        for i, (a, b) in enumerate(zip(t["prev"], t["next"])):
            for j, (u, v) in enumerate(zip(a, b)):
                if u != v:
                    hot.add((i, j))
    return sorted(hot)


def make_mutants(trs: list[dict], cap: int = MUT_CAP) -> list[dict]:
    """造一批**错的转移**。五种造法都与这一局无关。

    **第五种是补出来的，补之前这批变异对一整类规则系统性失真。**
    前四种改的全是 `next`。于是一条**只读 `prev`**的规则
    （「这一下点在哪」「动作合不合法」这一类，判决完全不看后果）
    **永远不会被这批变异碰到**：它拒掉 0 个、独家 0 ——
    而「独家 0」在账面上正是该撤册的样子。实测真有这么一条，
    它不是冗余，**它是测不到**。

    所以补一类**只换 `prev`、`next` 原样留着**的：
    前提换了而后果没换，读 `prev` 的规则这下就有话说了。

    v7：改过格的那一帧仍是**行的列表、每行一个列表**（和 transitions.jsonl 里的帧同一个形状）。
    原来交回的是元组的行；v7 的帧是列表，规则里 `prev == nxt` 这种比较拿列表和元组比，恒不等。
    """
    rnd = random.Random(SEED)
    by_action: dict[str, list] = {}
    for t in trs:
        by_action.setdefault(t["action"], []).append(t)
    hot = hot_cells(trs)
    out = []
    for t in trs:
        if t["prev"] != t["next"]:
            out.append({**t, "next": t["prev"], "mut": "什么都没发生"})
        peers = [p for p in by_action.get(t["action"], []) if p["tid"] != t["tid"]
                 and p["next"] != t["next"]]
        if peers:
            out.append({**t, "next": rnd.choice(peers)["next"], "mut": "结果张冠李戴"})
        others = [p for p in trs if p["tid"] != t["tid"] and p["prev"] != t["next"]]
        if others:
            out.append({**t, "next": rnd.choice(others)["prev"], "mut": "回到了别处"})
        g = [list(r) for r in t["next"]]
        if g and g[0]:
            vals = sorted({v for r in g for v in r})
            # **只改语料里真会变的格**：随机挑多半改在从不变化的背景上，造出来的变异太软
            pool = [c for c in hot if c[0] < len(g) and c[1] < len(g[0])] or \
                   [(i, j) for i in range(len(g)) for j in range(len(g[0]))]
            for _ in range(min(MUT_CELLS, len(pool))):
                i, j = rnd.choice(pool)
                alt = [v for v in vals if v != g[i][j]]
                if alt:
                    g[i][j] = rnd.choice(alt)
            if g != [list(r) for r in t["next"]]:
                out.append({**t, "next": g, "mut": "改了会变的格"})
        # 第五种：**只换前提**。上面四种一律动 next，只读 prev 的规则碰都碰不到。
        pre = [p for p in trs if p["tid"] != t["tid"] and p["prev"] != t["prev"]]
        if pre:
            out.append({**t, "prev": rnd.choice(pre)["prev"], "mut": "换了个前提"})
    rnd.shuffle(out)
    return out[:cap]


def planted_mutant(trs: list[dict]) -> dict | None:
    """**必拒的一个**：下一帧换成一张空帧 `[]`。任何一台像样的对象层都读不成它，册子必须拒。

    原来的必拒变异是按局挑的（「下一帧换成另一关的一帧」）；这里要和局无关，只好挑一个
    **不依赖规则**也该被拒的：它不被拒，说明对象层把一张空帧读成了世界——拒绝集的「读不成」那一半是空转的。
    """
    if not trs:
        return None
    return {**trs[0], "next": [], "mut": "必拒：下一帧是空帧"}


def rejections(mod, concepts: list[dict], muts: list[dict], ctx_of) -> dict:
    """每条规则拒掉哪些变异；对象层读不出来的算另一类拒绝。"""
    by_rule: dict[str, set] = {c["name"]: set() for c in concepts}
    by_parse: set = set()
    for n, m in enumerate(muts):
        tag = f"{m['tid']}#{n}"
        try:
            mod.parse(m["next"])
        except Exception:                                         # noqa: BLE001
            by_parse.add(tag)                                     # 读不出来也是拒绝，而且更早更响
            continue
        for c in concepts:
            if _call(c, m["prev"], m["action"], m["next"], ctx_of(m)) == "FALSE":
                by_rule[c["name"]].add(tag)
    covered = set().union(*by_rule.values()) if by_rule else set()
    unique = {n: s - set().union(*(v for k, v in by_rule.items() if k != n))
              for n, s in by_rule.items()} if len(by_rule) > 1 else \
             {n: set(s) for n, s in by_rule.items()}
    return {"by_rule": by_rule, "unique": unique, "by_parse": by_parse,
            "total": len(muts), "rejected": len(covered | by_parse)}


def by_kind(muts: list[dict], rej: dict) -> dict[str, list[int]]:
    """按造法分：{造法: [造了几个, 拒掉几个]}。拒得少的那一种，就是变异最软的那一种。"""
    tags = set().union(*rej["by_rule"].values()) | rej["by_parse"] if rej["by_rule"] else rej["by_parse"]
    out: dict[str, list[int]] = {}
    for n, m in enumerate(muts):
        k = out.setdefault(m["mut"], [0, 0])
        k[0] += 1
        k[1] += f"{m['tid']}#{n}" in tags
    return out


# ---------------------------------------------------------------- 三、读数：解析两档、五个数、无人区、交接

def parse_census(mod, trs: list[dict]) -> dict:
    """每一帧读一遍。读不成的分两档：(a) 不是局面 / (b) 是局面却读不出。**(b) == 0 才算过。**

    分档靠上游（ParseError 只管抛、不管归类）：v7 的 ctx 只记了 `state_next`，
    于是 nxt 那一帧在 `state_next` 是 WIN / GAME_OVER 时归 (a)，其余一律归 (b)。
    """
    a, b, frames, bad_rows = [], [], 0, set()
    cache: dict[str, str | None] = {}
    for t in trs:
        for which in ("prev", "next"):
            frames += 1
            k = _key(t[which])
            if k not in cache:
                try:
                    mod.parse(t[which])
                    cache[k] = None
                except Exception as e:                            # noqa: BLE001
                    cache[k] = f"{type(e).__name__}: {e}"[:120]
            why = cache[k]
            if why is None:
                continue
            bad_rows.add(t["seq"])
            st = (t.get("ctx") or {}).get("state_next") if which == "next" else None
            rec = {"seq": t["seq"], "which": "nxt" if which == "next" else "prev", "why": why}
            (a if st in ENDED else b).append(rec)
    return {"frames": frames, "a": a, "b": b, "bad_rows": bad_rows}


def judge(rule: dict, t: dict) -> tuple[str, str | None, bool]:
    """一条规则在一行上说什么：(裁定, 理由, scope_ 返回值合不合法)。理由只在 NA / ERROR 时有。抛异常算 ERROR。"""
    ctx = t.get("ctx")
    ok = True
    try:
        sc = rule.get("scope_fn")
        if callable(sc):
            why = sc(t["prev"], t["action"], t["next"], ctx) if rule["scope_arity"] == 4 \
                else sc(t["prev"], t["action"], t["next"])
            if why:
                ok = isinstance(why, str) and bool(why.strip())
                return "NA", str(why), ok
        f = rule["fn"]
        v = f(t["prev"], t["action"], t["next"], ctx) if rule["arity"] == 4 \
            else f(t["prev"], t["action"], t["next"])
        if v in ("TRUE", "FALSE", "NA"):
            return v, ("assert_ 返回 NA" if v == "NA" else None), ok
        return "ERROR", f"返回了 {v!r}，只许 TRUE/FALSE/NA", ok
    except Exception as e:                                        # noqa: BLE001
        return "ERROR", f"{type(e).__name__}: {e}"[:160], ok


def readings(trs: list[dict], rules: list[dict], census: dict):
    """每条规则五个数 + 无人区 + 交接缺口。口径照原来的 run_rules.py。"""
    bad_rows = census["bad_rows"]
    per, table, handoff = {}, {}, defaultdict(set)
    for r in rules:
        v, why_ct, U, bad_scope = [], Counter(), 0, 0
        for i, t in enumerate(trs):
            x, why, ok = judge(r, t)
            v.append(x)
            bad_scope += not ok
            if x == "NA":
                why_ct[why or "assert_ 返回 NA"] += 1
                # U 照原口径：理由里写着「读不成世界」。scope_ 没给理由、是 assert_ 自己说 NA 的那种，
                # 这一行又真有一帧读不成，也记 U（理由是别的——「不是这个动作」——就不算，那是 N）。
                if (why and "读不成世界" in why) or (why == "assert_ 返回 NA" and t["seq"] in bad_rows):
                    U += 1
                for m in HANDOFF_RE.finditer(why or ""):
                    # 「→ a / b」说的是「这些步归 a 或 b 管」：核的是**至少一条**开了口
                    names = tuple(sorted(x.strip() for x in m.group(1).split("/") if x.strip()))
                    handoff[names].add(i)
            elif x == "ERROR":
                why_ct[f"ERROR {why}"] += 1
        table[r["name"]] = v
        C, E, ERR = v.count("TRUE"), v.count("FALSE"), v.count("ERROR")
        opened = C + E
        per[r["name"]] = {
            "group": r["group"], "path": r["path"], "claim": r.get("claim", ""),
            "scope": opened, "N": len(trs) - opened - U - ERR, "C": C, "E": E, "U": U, "ERROR": ERR,
            "bad_scope_returns": bad_scope,
            "false_rows": [trs[i]["seq"] for i, x in enumerate(v) if x == "FALSE"],
            "na_reasons": dict(why_ct.most_common()),
        }
    silent = [trs[i]["seq"] for i in range(len(trs))
              if all(table[n][i] not in ("TRUE", "FALSE") for n in table)]
    gaps, names = {}, set(table)
    for nms, idx in handoff.items():
        key = "/".join(nms)
        unknown = [n for n in nms if n not in names]
        if unknown:
            gaps[key] = {"missing_rule": unknown, "rows": len(idx)}
            continue
        miss = [trs[i]["seq"] for i in sorted(idx)
                if all(table[n][i] not in ("TRUE", "FALSE") for n in nms)]
        if miss:
            gaps[key] = {"missing_rule": [], "rows": len(idx), "silent_on": miss}
    return per, table, silent, gaps


def n0_kind(stat: dict) -> str | None:
    """|scope| == 0 的死因。三种：没人做过那个动作 / 论域把自己写没了 / 唯一那条被读不成世界挡住。"""
    if stat["scope"] > 0:
        return None
    if stat["U"] > 0:
        return "唯一那几条被别的原因挡住（读不成世界）"
    return "论域把自己写没了，或语料里没人做过那个动作（看下面的 NA 理由）"


def real_rejections(trs: list[dict], table: dict, census: dict) -> dict:
    """真实转移上的拒绝集 = 规则判 FALSE 的 ∪ 对象层读不出来的。**两半都要算**（卡 05）。"""
    false_rows = {trs[i]["seq"] for row in table.values() for i, v in enumerate(row) if v == "FALSE"}
    parse_rows = set(census["bad_rows"])
    return {"false": sorted(false_rows), "parse": sorted(parse_rows),
            "union": sorted(false_rows | parse_rows)}


# ---------------------------------------------------------------- 写进 analysis/（只在 --analysis 时）

def _merge(path: Path, block: str) -> None:
    """只重写装置那一段，**人写的一个字都不动**。"""
    old = path.read_text(encoding="utf-8") if path.exists() else ""
    mine = f"{MARK_A}\n{block.rstrip()}\n{MARK_B}\n"
    if MARK_A in old and MARK_B in old:
        head, rest = old.split(MARK_A, 1)
        tail = rest.split(MARK_B, 1)[1]
        new = head + mine + tail
    else:
        new = mine + ("\n" + old.lstrip() if old.strip() else "\n" + PLACEHOLDER)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(new, encoding="utf-8")


def write_files(an: Path, ab: dict, rej: dict, n_trs: int) -> None:
    for name, r in sorted(ab.items()):
        chg = r.get("changed", -1)
        if chg < 0:
            verdict = f"跑不出来：{r.get('note', '')}"
        elif chg == 0:
            verdict = ("**判决一个字都没变** ⇒ 没有任何一条规则用到这一位信息。\n"
                       "按判据 1 / 2 它**不必要**——要么删掉，要么在下面写清"
                       "「哪一对世界状态靠它才分得开」，并说明为什么还没有规则用它。")
        else:
            verdict = (f"抹掉之后判决变了 **{chg}** 处"
                       + (f"（其中 {r['errors']} 处是规则直接跑不起来）" if r.get("errors") else "")
                       + "。**有规则在用这一位**。")
        _merge(an / f"字段-{name}.txt",
               f"字段 `{name}`　消融读数（分母：{n_trs} 条转移）\n\n{verdict}")

    tot, rejd = rej.get("total", 0), rej.get("rejected", 0)
    for name, s in sorted(rej.get("by_rule", {}).items()):
        u = rej["unique"].get(name, set())
        verdict = ("**独家拒绝 0 个** ⇒ 它拒掉的，别的规则也都拒掉了。\n"
                   "按拒绝集判据它**是写法不是概念**——要么删掉，要么在下面写清"
                   "它说了什么别人没说的话，并给出一条能打到它的变异。"
                   if not u else
                   f"拒掉 {len(s)} 个变异，其中 **{len(u)} 个是独家**。")
        _merge(an / f"规则-{name}.txt",
               f"规则 `{name}`　变异测试读数（{tot} 个变异，册子共拒掉 {rejd} 个）\n\n{verdict}\n\n"
               "**盲区**：「独家拒绝 0」不等于「被证明冗余」，只等于"
               "「在这一批变异上没说出别人没说的话」。变异是造出来的，不是穷举的。")


# ---------------------------------------------------------------- 报表

def lines(why: str | None, ab: dict, rej: dict, n_rows: int, n_trs: int = 0,
          wrote: bool = False) -> list[str]:
    if why:
        return [f"  判据跑不了：{why}（这一期只报不拦）"]
    out = []
    dead = [k for k, v in ab.items() if v.get("changed") == 0]
    # 分母拆开写：真实几条（全语料还是抽样）+ 变异几条。**抽样的分母不写出来就会被读成全量。**
    meta = LAST_ABLATE if LAST_ABLATE.get("rows") == n_rows else {}
    n_mut = meta.get("muts", rej.get("total", 0))
    n_real = meta.get("real", n_rows - n_mut)
    how = ("全语料" if n_trs and n_real >= n_trs else
           f"等距抽样，语料的 {n_real}/{n_trs}" if n_trs else "真实转移")
    out.append(f"  **字段消融**（判据 1 / 2，分母 {n_rows} 条 = 真实转移 {n_real} 条（{how}）"
               f"+ 变异 {n_mut} 条{f'；语料共 {n_trs} 条' if n_trs else ''}）："
               f"{len(ab)} 个字段，**{len(dead)} 个抹掉之后判决一个字没变**")
    for k, v in sorted(ab.items(), key=lambda kv: kv[1].get("changed", -1)):
        c = v.get("changed", -1)
        mark = "  ← **没人用**" if c == 0 else ""
        out.append(f"     {k:<24}{'跑不出' if c < 0 else str(c) + ' 处判决变了':<18}{mark}")
    tot, rejd = rej.get("total", 0), rej.get("rejected", 0)
    npf = len(rej.get("by_parse", set()))
    out.append(f"  **变异测试**（拒绝集）：造了 {tot} 个错的 next，册子拒掉 **{rejd}**"
               f"（其中对象层读不出来 {npf} 个）")
    if tot and rejd / tot < 0.25:
        out.append("     ← **册子拒掉的比例偏低**。这不是好消息：要么规则太少太软，"
                   "要么变异造得太容易被放过。**变异的力度决定读数的力度**——"
                   "拒得少的时候，下面那些「独家 0」多半是变异不够狠，不是规则冗余。")
    solo = [n for n, u in rej.get("unique", {}).items() if not u]
    if solo:
        out.append(f"     **独家拒绝 0 个的规则 {len(solo)} 条**：{'、'.join(sorted(solo)[:6])}"
                   + (" …" if len(solo) > 6 else ""))
        out.append("     它们拒掉的别人也都拒掉了——按拒绝集判据是**写法不是概念**。")
    if wrote:
        out.append("     逐条的账写进了 analysis/：**装置写读数，你补为什么**。")
    else:
        out.append("     **装置写读数，你补为什么**（加 `--analysis analysis` 把逐条的账写进 analysis/）。")
    out.append("  **盲区**：「独家拒绝 0」不等于「被证明冗余」，只等于「在这一批变异上没说出别人没说的话」；"
               "消融只看得见「有没有规则在用」，看不见「玩法需不需要」——这一期只报不拦。")
    return out


def main(argv: list[str] | None = None) -> int:
    utf8_stdout()
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) < 3 or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("objects")
    ap.add_argument("rule")
    ap.add_argument("transitions")
    ap.add_argument("--json", default=None)
    ap.add_argument("--analysis", default=None)
    a = ap.parse_args(argv)
    t0 = time.time()

    trs, meta = load_transitions(Path(a.transitions))
    obj = ObjLayer(Path(a.objects))
    rules, problems = load_rules(Path(a.rule), obj)
    problems = list(problems)
    if not rules:
        problems.append("rule/ 下一条规则都没找到（rglob）——这一整节等于没核")
    reload_fn = reloader(Path(a.rule), obj)
    ctx_of = (lambda t: t.get("ctx"))

    # ---- 解析两档 ----
    census = parse_census(obj, trs)
    for t in trs:                                             # World 没导出时，拿第一个读出来的世界认类型
        if obj.World is not None:
            break
        try:
            obj.learn_world(obj.parse(t["prev"]))
        except Exception:                                     # noqa: BLE001
            pass
    miss = obj.contract()
    for m in miss:
        problems.append(f"对象层契约：{m}")
    if census["b"]:
        problems.append(f"(b) 是局面却读不出：{len(census['b'])} 帧")

    # ---- 五个数 / 无人区 / 交接 ----
    per, table, silent, gaps = readings(trs, rules, census)
    for n, s in per.items():
        if s["scope"] == 0:
            problems.append(f"{n}：|scope| == 0（{n0_kind(s)}）")
        if s["ERROR"]:
            problems.append(f"{n}：跑炸了 {s['ERROR']} 行")
        if s["bad_scope_returns"]:
            problems.append(f"{n}：scope_ 有 {s['bad_scope_returns']} 次返回的不是一句理由 —— "
                            "要么 None（我管），要么一句非空的理由（这几次按「不管」记了 NA）")
    for k, g in gaps.items():
        problems.append(f"交接缺口：说归「{k}」管的 {g['rows']} 行里，"
                        + (f"规则不存在 {g['missing_rule']}" if g["missing_rule"]
                           else f"{len(g['silent_on'])} 行没人开口 {g['silent_on'][:6]}"))
    rr = real_rejections(trs, table, census)

    # ---- 变异测试 / 字段消融 ----
    why = can_run(obj, rules)
    ab, abn, rej, kinds, planted, selfck = {}, 0, {}, {}, None, None
    muts = []
    if not why:
        muts = make_mutants(trs)
        rej = rejections(obj, rules, muts, ctx_of)
        kinds = by_kind(muts, rej)
        pm = planted_mutant(trs)
        if pm is not None:
            planted = rejections(obj, rules, [pm], ctx_of)["rejected"] == 1
            if not planted:
                problems.append("必拒的变异（下一帧是空帧）没被拒 —— 对象层把空帧读成了世界，"
                                "拒绝集「读不成」那一半是空转的")
        selfck = ablate_selfcheck(obj, rules, trs + muts, ctx_of, reload_fn)
        if not selfck["alive"]:
            problems.append("消融的必红补丁（parse 每帧都读不出）一处判决都没改 —— 补丁打不到规则，"
                            "下面的消融读数一个都不能信")
        elif selfck["deaf_rules"]:
            problems.append(f"消融补丁打不到这几条规则：{'、'.join(selfck['deaf_rules'])} —— "
                            "它们不是经 objects.parse 读世界的，消融对它们是瞎的")
        ab, abn = ablate(obj, rules, trs, ctx_of, reload_fn, muts)
        if a.analysis:
            write_files(Path(a.analysis), ab, rej, abn)

    # ---- 报 ----
    print(f"语料：{a.transitions}，{meta['lines']} 行，按 tid 去重 {meta['uniq']} 条转移"
          + (f"；{meta['broken_tail']}" if meta["broken_tail"] else ""))
    wf = [f.name for f in dataclasses.fields(obj.World)] if obj.World and dataclasses.is_dataclass(obj.World) else []
    print(f"对象层：{obj.dir.name}/，World {len(wf)} 个字段（{'、'.join(wf)}）"
          + ("；规则读的 `objects` 已指到这一份" if obj.aliased else ""))
    print(f"解析：{census['frames']} 帧；(a) 不是局面 {len(census['a'])} 帧；"
          f"(b) 是局面却读不出 **{len(census['b'])}** 帧")
    print(f"\n规则 {len(rules)} 条。每条五个数：|scope| 开口 / N 论域外 / C 判对 / E 判错 / U 读不成世界而闭嘴")
    print(f"{'规则':<34}{'|scope|':>8}{'N':>6}{'C':>6}{'E':>5}{'U':>5}{'ERR':>5}")
    for n, s in sorted(per.items(), key=lambda kv: (kv[1]["group"], kv[0])):
        red = "   ← **|scope| == 0，判红**" if s["scope"] == 0 else ""
        print(f"{(s['group'] + '/' if s['group'] else '') + n:<34}{s['scope']:>8}{s['N']:>6}{s['C']:>6}"
              f"{s['E']:>5}{s['U']:>5}{s['ERROR']:>5}"
              + (f"   判错在第 {s['false_rows'][:8]} 行" if s["E"] else "") + red)
        if s["scope"] == 0:
            for r, c in list(s["na_reasons"].items())[:3]:
                print(f"     NA 理由：{r} × {c}")
    print("（|scope| == 0 的规则在四个数下长得和「全过了」一模一样：N=全部, C=0, E=0, U=0。）")
    print(f"无人区（一条规则都没开口的转移）：{len(silent)} 条，第 {silent[:12]} 行")
    print(f"交接缺口：{gaps if gaps else '0'}")
    print(f"\n**拒绝集**（真实转移，规则判 FALSE 的 ∪ 对象层读不出来的）：{len(rr['union'])} 条 "
          f"= 判 FALSE {len(rr['false'])} 条 ∪ 读不成世界 {len(rr['parse'])} 条")
    print("  （两半都要算：只数 FALSE、忘了「读不成」那一半，同一批数据同一句判准，读数能差十倍。）\n")
    for ln in lines(why, ab, rej, abn, len(trs), wrote=bool(a.analysis)):
        print(ln)
    if not why:
        print(f"     按造法（造了几个 / 拒掉几个）：" + "  ".join(f"{k} {v[0]}/{v[1]}" for k, v in kinds.items()))
        print("     每条规则拒掉 / 独家：" + "  ".join(
            f"{n} {len(rej['by_rule'][n])}/{len(rej['unique'].get(n, ()))}" for n in sorted(rej["by_rule"])))
        print(f"     必拒的那个（下一帧是空帧）：{'拒了' if planted else '**没拒**'}")
        print(f"     消融自检（必红补丁：每帧都读不出）：判决变了 {selfck['changed']} 处 → "
              f"{'补丁打得上' if selfck['alive'] else '**补丁打不上**'}"
              + (f"；打不到的规则：{'、'.join(selfck['deaf_rules'])}" if selfck["deaf_rules"] else ""))
    for p in problems:
        print("  **问题**：" + p)
    secs = round(time.time() - t0, 2)
    print(f"用时 {secs}s")

    if a.json:
        Path(a.json).write_text(json.dumps({
            "corpus": meta, "parse": {k: v for k, v in census.items() if k != "bad_rows"},
            "rules": per, "silent_rows": silent, "handoff_gaps": gaps, "real_rejections": rr,
            "ablation": ab, "ablation_rows": abn, "ablation_split": dict(LAST_ABLATE),
            "ablation_selfcheck": selfck, "mutants": {
                "total": rej.get("total", 0), "rejected": rej.get("rejected", 0),
                "by_parse": len(rej.get("by_parse", ())),
                "by_rule": {k: len(v) for k, v in rej.get("by_rule", {}).items()},
                "unique": {k: len(v) for k, v in rej.get("unique", {}).items()},
                "by_kind": kinds, "planted_rejected": planted},
            "cannot_run": why, "problems": problems, "seconds": secs,
        }, ensure_ascii=False, indent=1, default=list), encoding="utf-8")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
