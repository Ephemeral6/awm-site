"""Windows per-invocation hard memory limit for a CLI/compiler and ALL descendants.

The game server is launched separately and is never assigned to this JobObject.
No process-name scans or cross-run kills. Kernel allocation limits act before
the 50ms event poll; a resource failure is never a model verdict.
"""
from __future__ import annotations
import ctypes as C
from ctypes import wintypes as W
import json, os, shutil, subprocess, sys, tempfile, threading, time
from pathlib import Path

MAX_BYTES = 8 * 1024**3
_PSAPI = None
REPAIR_PROMPT = '''RESOURCE REPAIR REQUIRED — the last program exceeded the memory budget or reported an allocation failure.
Do not repeat the same large computation. Work on files only: NO game actions and NO reset.
Reduce live memory below 8 GiB: reduce the representation/state count, factor the proof into bounded lemmas,
use a justified quotient, stream data, or release intermediate results. A small file can still allocate huge memory;
deleting logs or hiding data on disk is not a repair. Do not drop a rule or legal route just to make a proof fit:
any proof abstraction must preserve all relevant routes and charge no more than the original model.
Run a bounded check of the revised program. Record the failure, changes, and measured/bounded memory in
analysis/resource_repair.md. Re-run the rejection check on ALL rules and transitions if the model changes.
End with RESOURCE-REPAIRED: <program and concrete change>, or RESOURCE-BLOCKED: <remaining obstacle>.
Do not claim a new game verdict in this repair reply. The interrupted stage will be sent again afterwards.'''

class BASIC(C.Structure):
    _fields_=[('t1',C.c_int64),('t2',C.c_int64),('flags',W.DWORD),('minws',C.c_size_t),('maxws',C.c_size_t),('n',W.DWORD),('affinity',C.c_size_t),('priority',W.DWORD),('sched',W.DWORD)]
class IO(C.Structure):
    _fields_=[(str(i),C.c_uint64) for i in range(6)]
class EXT(C.Structure):
    _fields_=[('basic',BASIC),('io',IO),('process_mem',C.c_size_t),('job_mem',C.c_size_t),('peak_process',C.c_size_t),('peak_job',C.c_size_t)]
class ASSOC(C.Structure):
    _fields_=[('key',C.c_void_p),('port',W.HANDLE)]
class MEM(C.Structure):
    _fields_=[('cb',W.DWORD),('faults',W.DWORD)]+[(n,C.c_size_t) for n in ('peak_ws','ws','qpp','qp','qnpp','qnp','page','peak_page','private')]

def _kernel():
    k=C.WinDLL('kernel32',use_last_error=True)
    signatures={
      'CreateJobObjectW':([C.c_void_p,W.LPCWSTR],W.HANDLE),
      'SetInformationJobObject':([W.HANDLE,C.c_int,C.c_void_p,W.DWORD],W.BOOL),
      'QueryInformationJobObject':([W.HANDLE,C.c_int,C.c_void_p,W.DWORD,C.c_void_p],W.BOOL),
      'AssignProcessToJobObject':([W.HANDLE,W.HANDLE],W.BOOL),
      'TerminateJobObject':([W.HANDLE,W.UINT],W.BOOL),
      'CloseHandle':([W.HANDLE],W.BOOL),
      'OpenProcess':([W.DWORD,W.BOOL,W.DWORD],W.HANDLE),
      'IsProcessInJob':([W.HANDLE,W.HANDLE,C.POINTER(W.BOOL)],W.BOOL),
      'CreateIoCompletionPort':([W.HANDLE,W.HANDLE,C.c_size_t,W.DWORD],W.HANDLE),
      'GetQueuedCompletionStatus':([W.HANDLE,C.POINTER(W.DWORD),C.POINTER(C.c_size_t),C.POINTER(C.c_void_p),W.DWORD],W.BOOL)}
    for n,(a,r) in signatures.items():getattr(k,n).argtypes=a;getattr(k,n).restype=r
    return k

def _resident(k,job):
    """Only job members, re-check membership after opening against PID reuse."""
    buf=C.create_string_buffer(8+4096*C.sizeof(C.c_size_t))
    if not k.QueryInformationJobObject(job,3,buf,len(buf),None):return None
    n=C.c_uint32.from_buffer(buf,4).value;rss=0;private=0
    global _PSAPI
    if _PSAPI is None:
        _PSAPI=C.WinDLL('psapi',use_last_error=True);_PSAPI.GetProcessMemoryInfo.argtypes=[W.HANDLE,C.POINTER(MEM),W.DWORD];_PSAPI.GetProcessMemoryInfo.restype=W.BOOL
    ps=_PSAPI
    for i in range(min(n,4096)):
        pid=C.c_size_t.from_buffer(buf,8+i*C.sizeof(C.c_size_t)).value
        h=k.OpenProcess(0x1000|0x10,False,pid)
        if not h:continue
        try:
            member=W.BOOL()
            if k.IsProcessInJob(h,job,C.byref(member)) and member.value:
                m=MEM();m.cb=C.sizeof(m)
                if ps.GetProcessMemoryInfo(h,C.byref(m),C.sizeof(m)):rss+=m.ws;private+=m.private
        finally:k.CloseHandle(h)
    return rss,private

def _oom(text):
    s=text.lower()
    return any(x in s for x in ('std::bad_alloc','excessive memory consumption','out of memory','memory allocation of','cannot allocate memory','memoryerror'))

def run_capture(cmd, *, cwd, input=None, env=None, timeout=None, limit_bytes=MAX_BYTES, **ignored):
    """CompletedProcess + resource_report. Fail closed outside Windows/job setup.

    limit_bytes can only be LOWER than8GiB (small limits are used in tests).
    Raw stdout/stderr survive; clients record resource reports separately.
    """
    if os.name!='nt':raise RuntimeError('AWM v7h requires Windows JobObjects; refusing an unguarded launch')
    if not 0<limit_bytes<=MAX_BYTES:raise ValueError('memory cap must be in(0,8GiB]')
    cwd=Path(cwd).resolve();base=Path(os.environ.get('AWM_RUNTIME',os.environ.get('AWM_ARCHIVE','D:/arc-arena-archive')+'/runtime'))
    base.mkdir(parents=True,exist_ok=True)
    k=_kernel();job=k.CreateJobObjectW(None,None);port=None;p=None;thread=None;result={};start=time.monotonic()
    report=dict(limit_bytes=limit_bytes,metric='tree commit hard cap; summed resident working sets sampled every50ms',resource_exceeded=False,peak_commit_bytes=0,peak_rss_bytes=0,events=[])
    if not job:raise C.WinError(C.get_last_error())
    try:
        info=EXT();info.basic.flags=0x2000|0x200|0x100;info.job_mem=limit_bytes;info.process_mem=limit_bytes
        if not k.SetInformationJobObject(job,9,C.byref(info),C.sizeof(info)):raise C.WinError(C.get_last_error())
        port=k.CreateIoCompletionPort(W.HANDLE(-1),None,0,1)
        if not port:raise C.WinError(C.get_last_error())
        assoc=ASSOC(None,port)
        if not k.SetInformationJobObject(job,7,C.byref(assoc),C.sizeof(assoc)):raise C.WinError(C.get_last_error())
        with tempfile.TemporaryDirectory(prefix='awm-call-',dir=base,ignore_cleanup_errors=True) as td:
            folder=Path(td);config=folder/'command.json';gate=folder/'ready'
            config.write_text(json.dumps(dict(cmd=list(map(str,cmd)),cwd=str(cwd))),encoding='utf-8')
            child_env=dict(env or os.environ);(folder/'cc').mkdir()
            child_env.update(TEMP=str(folder),TMP=str(folder),CLAUDE_CODE_TMPDIR=str(folder/'cc'),PYTHONDONTWRITEBYTECODE='1')
            p=subprocess.Popen([sys.executable,'-I',str(Path(__file__).resolve()),'--child',str(config),str(gate)],
                cwd=cwd,env=child_env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                text=True,encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
            if not k.AssignProcessToJobObject(job,W.HANDLE(int(p._handle))):
                p.terminate();p.wait();raise C.WinError(C.get_last_error())
            gate.write_text('assigned',encoding='utf-8')
            def collect():
                try:result['stdout'],result['stderr']=p.communicate(input=input)
                except Exception as e:result['collector_error']=repr(e)
            thread=threading.Thread(target=collect,daemon=True);thread.start()
            timed=False
            while True:
                msg=W.DWORD();key=C.c_size_t();ov=C.c_void_p()
                while k.GetQueuedCompletionStatus(port,C.byref(msg),C.byref(key),C.byref(ov),0):
                    if msg.value in (9,10):report['events'].append(dict(message=msg.value,pid=ov.value));report['resource_exceeded']=True
                peak=EXT()
                if k.QueryInformationJobObject(job,9,C.byref(peak),C.sizeof(peak),None):report['peak_commit_bytes']=max(report['peak_commit_bytes'],peak.peak_job)
                resident=_resident(k,job)
                if resident:
                    report['peak_rss_bytes']=max(report['peak_rss_bytes'],resident[0])
                    if resident[0]>limit_bytes:
                        report['events'].append(dict(message='RSS_LIMIT',bytes=resident[0]));report['resource_exceeded']=True
                if report['resource_exceeded']:
                    k.TerminateJobObject(job,137);break
                if timeout is not None and time.monotonic()-start>timeout:
                    timed=True;k.TerminateJobObject(job,124);break
                if p.poll() is not None:break
                time.sleep(.05)
            p.wait(timeout=15)
            # Normal CLI replies cannot leave a detached compiler behind.
            k.TerminateJobObject(job,125);thread.join(timeout=15)
            if thread.is_alive():raise RuntimeError('capture thread did not terminate after owned-job cleanup')
            stdout=result.get('stdout','');stderr=result.get('stderr','')
            # Also catch an internal lower compiler cap or an allocation request
            # rejected before a usable peak sample is recorded.
            if _oom(stderr) or (p.returncode != 0 and _oom(stdout)):report['resource_exceeded']=True
            report.update(seconds=round(time.monotonic()-start,3),timed_out=timed,owned_descendants_cleaned=True)
            rc=137 if report['resource_exceeded'] else 124 if timed else p.returncode
            if report['resource_exceeded'] or input==REPAIR_PROMPT:
                logs=Path(os.environ.get('AWM_ARCHIVE','D:/arc-arena-archive'))/'resource_events';logs.mkdir(parents=True,exist_ok=True)
                (logs/(folder.name+'.json')).write_text(json.dumps(dict(cwd=str(cwd),command=list(map(str,cmd)),prompt=input,returncode=rc,resource_report=report,stdout=stdout,stderr=stderr),ensure_ascii=False,indent=2),encoding='utf-8')
        # TerminateJobObject cleanup can briefly outlive process exit.
        assert folder.resolve().parent == base.resolve() and folder.name.startswith('awm-call-')
        for cleanup_try in range(40):
            if not folder.exists(): break
            try: shutil.rmtree('\\\\?\\' + str(folder.resolve()))
            except OSError: time.sleep(.1)
        report['temporary_directory_removed'] = not folder.exists()
        if not report['temporary_directory_removed']: raise RuntimeError('Owned temporary directory could not be removed: ' + str(folder))
        out=subprocess.CompletedProcess(cmd,rc,stdout,stderr);out.resource_report=report
        return out
    finally:
        k.TerminateJobObject(job,125)
        if p is not None and p.poll() is None:p.wait(timeout=15)
        if port:k.CloseHandle(port)
        k.CloseHandle(job)

def recover(invoke, text, first, attempts=2):
    """Same-session resource repair. Interrupted calls never become verdicts."""
    history=[]
    def call(prompt,fresh):
        value=invoke(prompt,fresh);history.append(dict(prompt=prompt,first=fresh,reply=dict(value)));return value
    out=call(text,first);incidents=[]
    for _ in range(attempts):
        if not out.get('resource_exceeded'):break
        incidents.append(out)
        repair=call(REPAIR_PROMPT,False)
        incidents.append(dict(repair_reply=repair))
        if repair.get('resource_exceeded'):
            out=repair;continue
        if repair.get('returncode')!=0 or 'RESOURCE-REPAIRED:' not in repair.get('text',''):
            out=dict(returncode=137,text='',stderr='Resource repair not completed; no verdict.',resource_exceeded=True);break
        out=call(text,False)
    if out.get('resource_exceeded'):out={**out,'text':'','returncode':137,'resource_blocked':True}
    if incidents:
        out['resource_recovery']=incidents;out['resource_calls']=history
        out['wall_s']=round(sum(h['reply'].get('wall_s',0) for h in history),3)
    return out

if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--child':
        config,gate=Path(sys.argv[2]),Path(sys.argv[3]);deadline=time.monotonic()+20
        while not gate.exists():
            if time.monotonic()>deadline:raise SystemExit(126)
            time.sleep(.01)
        j=json.loads(config.read_text(encoding='utf-8'))
        p=subprocess.Popen(j['cmd'],cwd=j['cwd'],stdin=sys.stdin,stdout=sys.stdout,stderr=sys.stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        raise SystemExit(p.wait())
    raise SystemExit('Internal resource guard; import run_capture from the harness.')
