"""Cache ONLY deterministic mutation inputs, never rule judgments or a pass flag.

Store is operator-configured outside the arena, like the compiler archive. The
subject must not browse/edit it. Checksums detect corruption, not a hostile host.
"""
from pathlib import Path
import hashlib,json,os,sys,time,tempfile

VERSION='mutant-inputs-v2.2'
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')
def native_path(p):
    # Windows rename APIs otherwise fail on deeply relocated delivery paths.
    p=str(Path(p).resolve())
    if os.name=='nt' and not p.startswith('\\\\?\\'):
        return '\\\\?\\UNC\\'+p[2:] if p.startswith('\\\\') else '\\\\?\\'+p
    return p
def generator_id(C):
    folder=Path(C.__file__).resolve().parent
    return dict(files={p.name:sha_bytes(p.read_bytes()) for p in sorted(folder.glob('*.py'))},
                python=sys.version,seed=C.SEED,cap=C.MUT_CAP,cells=C.MUT_CELLS,policy=VERSION)
def get(d,trs,C,corpus_raw=None):
    t0=time.monotonic();d=Path(d).resolve();raw=corpus_raw if corpus_raw is not None else (d/'transitions.jsonl').read_bytes()
    identity=generator_id(C);meta=dict(case=str(d),corpus_sha256=sha_bytes(raw),normalized_sha256=sha_bytes(encoded(trs)),generator=identity)
    key=sha_bytes(encoded(meta));root=os.environ.get('AWM_MUTANT_CACHE');disabled=os.environ.get('AWM_DISABLE_MUTANT_CACHE')=='1'
    file=None;hit=False;reason='not configured' if not root else 'disabled' if disabled else 'miss'
    if root and not disabled:
        base=Path(root).resolve()
        if base.is_relative_to(d) or d.is_relative_to(base):raise ValueError('Mutation input cache must be an independent operator directory')
        folder=base;folder.mkdir(parents=True,exist_ok=True);file=folder/(key+'.json')
        if file.is_file():
            try:
                record=json.loads(file.read_text(encoding='utf-8'));payload=record['mutants']
                if record.get('key')!=key or record.get('metadata')!=meta or record.get('payload_sha256')!=sha_bytes(encoded(payload)):raise ValueError('checksum/key mismatch')
                if not isinstance(payload,list) or len(payload)>C.MUT_CAP or not all(isinstance(x,dict) for x in payload):raise ValueError('invalid mutation input list')
                hit=True;reason='verified input hit'
            except (OSError,ValueError,KeyError,TypeError):reason='corrupt input entry; regenerated'
    if not hit:
        payload=C.make_mutants(trs)
        if generator_id(C)!=identity:raise ValueError('Mutation generator changed during execution')
        if (d/'transitions.jsonl').read_bytes()!=raw:raise ValueError('Corpus changed during mutation input generation')
        if file is not None:
            record=dict(key=key,metadata=meta,mutants=payload,payload_sha256=sha_bytes(encoded(payload)))
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',prefix='input-',suffix='.tmp',dir=file.parent,delete=False) as f:
                tmp=Path(f.name);json.dump(record,f,ensure_ascii=False,separators=(',',':'))
            try:os.replace(native_path(tmp),native_path(file))
            finally:
                if tmp.exists():tmp.unlink()
    # Neither callers nor rule functions can mutate the stored payload by alias.
    fresh=json.loads(encoded(payload))
    info=dict(hit=hit,key=key,reason=reason,count=len(fresh),wall_s=round(time.monotonic()-t0,4),
              scope='Inputs only. All real transitions and all current mutations must still be evaluated by every current rule.')
    return fresh,info
