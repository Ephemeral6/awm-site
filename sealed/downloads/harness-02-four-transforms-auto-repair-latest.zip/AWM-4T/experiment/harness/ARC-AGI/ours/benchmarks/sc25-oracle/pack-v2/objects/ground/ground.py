"""`Ground` —— 场地上看得见的每一格是什么。一格一种，五种之一：

    ("floor",)          地板：走得上去
    ("mark", 色)        记号：画在地上的、某块小面板的记号色；走得上去，被我盖住不等于被擦掉
    ("block", 色)       实心块：墙、框里扣着的标本、插座的边；挡路。色是不透明的 id（抹除按它认同类）
    ("fuel",)           燃料：和竖条「满」同色；压到就整坨吃掉
    ("socket",)         插座内胆：整块踏进去就过关

虚空不存（不在表里的格就是虚空）；**我身下那几格不存**（看不见，表示不出来的就不存）。

## 为什么是一个对象、不是五个

第一版是五个字段（Floor / Marks / Blocks / Fuel / Socket）。分离表说五个**没有一个单独分得开**
（analysis/history/field_split.v1.out）：地面一变，总是好几层一起变（抹除时地板、记号、实心块同时变），
而且它们本来就是**同一张地面的一个分割**——每一格恰好属于一层。卡 03 的「同生共死 ⇒ 合」，合成这一个。
合并不抹信息：每一格的「种类」就是它的值。见 analysis/record.txt 第 1 轮。

## 为什么删不掉

走不走得过去、框在哪、燃料在哪、插座在哪，全从它读。字段消融读数见 analysis/Ground.txt。
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property

FLOOR = ("floor",)
FUEL = ("fuel",)
SOCKET = ("socket",)


@dataclass(frozen=True)
class Ground:
    tiles: frozenset        # {((行, 列), 种类)}

    @cached_property
    def at(self) -> dict:
        """格 → 种类。只是换个查法，不加信息。"""
        return dict(self.tiles)

    def kind(self, p):
        return self.at.get(p, ("void",))

    @cached_property
    def floor(self) -> frozenset:
        return frozenset(p for p, t in self.tiles if t == FLOOR)

    @cached_property
    def fuel(self) -> frozenset:
        return frozenset(p for p, t in self.tiles if t == FUEL)

    @cached_property
    def socket(self) -> frozenset:
        return frozenset(p for p, t in self.tiles if t == SOCKET)

    def marks_of(self, color) -> frozenset:
        return frozenset(p for p, t in self.tiles if t == ("mark", color))

    def is_mark(self, p) -> bool:
        return self.at.get(p, ("void",))[0] == "mark"
