# -*- coding: utf-8 -*-
"""自检：造一份玩具语料（v7 transitions.jsonl 的格式），对玩具 objects/ 与 rule/ 跑两个工具，核四件事。

    python selftest/run_selftest.py        # 在 tools_v7/ 下跑，或任何地方跑都行

核的四件事：
  1. 恒定字段 `width` 在分离表上报「分不开（恒定）」；
  2. 只有一条规则读的字段 `top`，消融报「判决变了」（> 0 处）；没人读的 `width` 报 0 处；
  3. 从不开口的规则 `action7_noop` 的 |scope| == 0，并被列成问题（判红）；
  4. 变异测试拒得掉：册子拒掉 > 0 个、`one_adds` 有独家拒绝、必拒的空帧被拒、消融补丁打得上。
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOLS = HERE.parent
OUT = HERE / "_out"


def tid_of(prev, action, nxt) -> str:
    h = hashlib.md5()
    h.update(json.dumps(prev, separators=(",", ":")).encode())
    h.update(str(action).encode())
    h.update(json.dumps(nxt, separators=(",", ":")).encode())
    return h.hexdigest()[:16]


def synth() -> Path:
    """3×4 的小帧。ACTION1：下面添一个 1；ACTION2：第 0 行左移一格；ACTION3：什么都不发生；
    最后一步 ACTION5 之后是一张一行的「终局画面」（state_next = WIN），对象层读不成它。另有一行重复（测去重）。"""
    f = [[1, 2, 3, 4], [0, 0, 0, 0], [0, 0, 0, 0]]
    cells = iter([(1, 0), (1, 1), (2, 2), (2, 3)])
    steps = ["ACTION1", "ACTION1", "ACTION2", "ACTION1", "ACTION2", "ACTION3", "ACTION1", "ACTION5"]
    rows = []
    for k, a in enumerate(steps):
        g = [list(r) for r in f]
        state = "NOT_FINISHED"
        if a == "ACTION1":
            r, c = next(cells)
            g[r][c] = 1
        elif a == "ACTION2":
            g[0] = g[0][1:] + g[0][:1]
        elif a == "ACTION5":
            g, state = [[7, 7, 7, 7]], "WIN"
        rows.append({"t": 1000.0 + k, "tid": tid_of(f, a, g), "action": a, "prev": f, "nxt": g,
                     "ctx": {"level_prev": 1, "level_next": 1, "state_next": state, "levels_completed": 0}})
        f = g
    rows.insert(2, dict(rows[0]))                                 # 重复一行：按 tid 去重后不该多算
    p = HERE / "transitions.jsonl"
    p.write_text("".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8")
    return p


def run(args: list[str]) -> str:
    r = subprocess.run([sys.executable, *args], cwd=str(HERE), capture_output=True,
                       encoding="utf-8", errors="replace")
    return r.stdout + r.stderr


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass
    synth()
    OUT.mkdir(exist_ok=True)
    fs_txt = run([str(TOOLS / "field_split.py"), "objects", "transitions.jsonl", "--json", str(OUT / "fs.json")])
    cr_txt = run([str(TOOLS / "criteria_run.py"), "objects", "rule", "transitions.jsonl",
                  "--json", str(OUT / "cr.json")])
    (OUT / "field_split.txt").write_text(fs_txt, encoding="utf-8")
    (OUT / "criteria_run.txt").write_text(cr_txt, encoding="utf-8")
    print(fs_txt)
    print(cr_txt)
    fs = json.loads((OUT / "fs.json").read_text(encoding="utf-8"))
    cr = json.loads((OUT / "cr.json").read_text(encoding="utf-8"))
    f = {r["field"]: r for r in fs["fields"]}
    ab = cr["ablation"]
    mu = cr["mutants"]
    checks = [
        ("1 恒定字段 width 报「分不开 / 恒定」", not f["width"]["split"] and f["width"]["constant"]
         and "width" in fs["constant"]),
        ("1' n_one、top 分得开（有见证）", f["n_one"]["split"] and f["top"]["split"]),
        ("2 只有一条规则读的 top，消融判决变了 > 0", ab["top"]["changed"] > 0),
        ("2' 没人读的 width，消融 0 处", ab["width"]["changed"] == 0),
        ("3 action7_noop |scope| == 0 且判红", cr["rules"]["action7_noop"]["scope"] == 0
         and any("action7_noop" in p and "|scope| == 0" in p for p in cr["problems"])),
        ("4 变异测试拒掉 > 0 个，one_adds 有独家", mu["rejected"] > 0 and mu["unique"]["one_adds"] > 0),
        ("4' 必拒的空帧被拒", mu["planted_rejected"] is True),
        ("4'' 消融补丁打得上", cr["ablation_selfcheck"]["alive"] and not cr["ablation_selfcheck"]["deaf_rules"]),
        ("  去重：9 行 → 8 条转移", cr["corpus"]["lines"] == 9 and cr["corpus"]["uniq"] == 8),
        ("  终局那一帧归 (a)、(b) == 0", len(cr["parse"]["a"]) == 1 and not cr["parse"]["b"]),
    ]
    print("=" * 60)
    bad = 0
    for name, ok in checks:
        print(("PASS  " if ok else "FAIL  ") + name)
        bad += not ok
    print(f"{len(checks) - bad}/{len(checks)} 通过")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
