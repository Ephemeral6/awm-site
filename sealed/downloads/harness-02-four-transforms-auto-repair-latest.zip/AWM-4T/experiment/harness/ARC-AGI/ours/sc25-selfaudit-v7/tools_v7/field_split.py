# -*- coding: utf-8 -*-
"""Diagnostic readouts for four-direction condensation. These are tests, not extra criteria.
See tools/CONTRACT.md; finite-corpus readings never establish universal redundancy.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import fields as dc_fields, is_dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _v7io import ObjLayer, frames_of, utf8_stdout                          # noqa: E402


def _key(v):
    """字段值变成可哈希的。列表 / 字典照结构冻成元组。"""
    if isinstance(v, (list, tuple)):
        return tuple(_key(x) for x in v)
    if isinstance(v, dict):
        return tuple(sorted((k, _key(x)) for k, x in v.items()))
    if isinstance(v, set):
        return tuple(sorted(_key(x) for x in v))
    return v


# 计数带的门槛：「这个字段的取值个数 / 不同世界的个数」≥ 它就算计数带。写成参数，读数里照实报出来。
COUNTER_MIN_RATIO = 0.9
COUNTER_MIN_WORLDS = 3


def counter_stats(worlds: list, min_ratio: float = COUNTER_MIN_RATIO,
                  min_worlds: int = COUNTER_MIN_WORLDS) -> dict:
    """计数带的判据，连分子分母一起交出来。

    分母 = 语料里**不同世界**的个数；分子 = 这个字段见过几个不同的值。比例 ≥ `min_ratio` 就算计数带。
    原来的判据是「比例 = 1」（每个不同的世界上取值都不同）：一个几乎每帧都变、偶有两帧相同的计数带
    （19 个值落在 20 个世界上）就认不出来，整张表照样退化，而读数上看不出是它害的。
    不用「相邻两帧变没变」当判据：一个在几格之间来回走的位置也是每步都变，但它的取值反复出现——
    按取值个数算，它的比例很低，不会被扣掉。
    至少要有 `min_worlds` 个不同的世界才判（两个世界时任何变了的字段比例都是 1）。
    **只认数值型标量字段**（int / float，或能无损转成数值的；见 `_numeric`）。记着整盘局面的字段
    （元组 / 列表 / 字典 / 盘面）取值比例也高——每一步都是一个没见过的新局面——但它不是时钟，
    扣掉它之后的见证是假的；只按比例认的时候，它就被当成计数带扣掉过。结构型字段一律不认，标量再过比例门槛。
    返回 {"worlds": 分母, "values": {字段: 分子}, "min_ratio", "min_worlds", "counters": [...]}。
    """
    out = {"worlds": 0, "values": {}, "min_ratio": min_ratio, "min_worlds": min_worlds, "counters": []}
    if not worlds or not is_dataclass(worlds[0]):
        return out
    names = [f.name for f in dc_fields(worlds[0])]
    distinct = {tuple(_key(getattr(w, x)) for x in names) for w in worlds}
    out["worlds"] = len(distinct)
    out["values"] = {f: len({row[i] for row in distinct}) for i, f in enumerate(names)}
    out["scalar"] = [f for i, f in enumerate(names) if all(_numeric(row[i]) for row in distinct)]
    if len(distinct) >= min_worlds:
        out["counters"] = [f for f in out["scalar"] if out["values"][f] / len(distinct) >= min_ratio]
    return out


def _numeric(v) -> bool:
    """数值型标量：int / float，或能无损转成数值的（`"17"`、numpy 标量）。元组、列表、字典、盘面、bool 一律不算。"""
    if isinstance(v, bool) or v is None:
        return False
    if isinstance(v, (int, float)):
        return True
    if isinstance(v, str):
        s = v.strip()
        try:
            x = float(s)
        except ValueError:
            return False
        return s == repr(x) or (x.is_integer() and s == str(int(x)))
    # numpy 一类的数值标量：有 .item()、没有长度
    if hasattr(v, "item") and not hasattr(v, "__len__"):
        try:
            return _numeric(v.item())
        except Exception:                                   # noqa: BLE001
            return False
    return False


def counters(worlds: list, min_ratio: float = COUNTER_MIN_RATIO,
             min_worlds: int = COUNTER_MIN_WORLDS) -> list[str]:
    """取值个数 / 不同世界个数 ≥ `min_ratio` 的字段（每帧自增的计数条、时间戳一类）。判据见 `counter_stats`。

    有这样一个字段在，按「除 f 以外全部相等」分组时每一组都只剩一个世界——
    **每一个别的字段都退化成「分不开」**，整张表失去信息，而读数上看不出是它害的。
    """
    return counter_stats(worlds, min_ratio, min_worlds)["counters"]


def table(worlds: list, exclude: tuple[str, ...] | list[str] = ()) -> list[dict]:
    """每个字段一行：分不分得开、同一组里见过几个值、见证是哪两个。

    `exclude`：分组时**不看**的字段（通常是 `counters()` 认出来的计数条）。
    严格那张表（`exclude=()`）照旧：「只差 f」的那一对才算见证。
    扣掉计数条的那张表的见证是「**除了 f 和计数条**全部相等」的一对——
    **代价**：它把计数条当成与状态无关的时钟；如果 f 其实是由计数条算出来的
    （比如 `tick % 2`），这张表会给 f 一个假见证。所以两张表并排报，扣掉了谁点名写出来，
    严格那张不因为有计数条就改口径。
    """
    if not worlds:
        return []
    w0 = worlds[0]
    if not is_dataclass(w0):
        raise SystemExit("World 不是 dataclass —— 这一份靠字段列表干活。")
    names = [f.name for f in dc_fields(w0)]
    rows = []
    for f in names:
        others = [x for x in names if x != f and x not in exclude]
        groups: dict[tuple, dict] = {}
        for i, w in enumerate(worlds):
            g = tuple(_key(getattr(w, x)) for x in others)
            v = _key(getattr(w, f))
            groups.setdefault(g, {}).setdefault(v, i)
        best = max((len(v) for v in groups.values()), default=0)
        wit = next(((list(v.values())[0], list(v.values())[1])
                    for v in groups.values() if len(v) > 1), None)
        n_vals = len({_key(getattr(w, f)) for w in worlds})
        rows.append({"field": f, "split": best > 1, "max_values": best,
                     "groups": len(groups), "witness": wit, "constant": n_vals == 1})
    return rows


def _wit(r: dict, where: list[str]) -> str:
    if not r["witness"]:
        return "—"
    a, b = r["witness"]
    return f"{where[a]} / {where[b]}"


def main(argv: list[str] | None = None) -> int:
    utf8_stdout()
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) < 2 or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("objects")
    ap.add_argument("frames")
    ap.add_argument("--json", default=None)
    a = ap.parse_args(argv)

    obj = ObjLayer(Path(a.objects))
    parse = obj.parse

    worlds, where, unreadable, n_frames = [], [], 0, 0
    for fr, origin in frames_of(Path(a.frames)):
        n_frames += 1
        try:
            w = parse(fr)
        except Exception:                                         # noqa: BLE001
            unreadable += 1                                       # 单独计数，不进表
            continue
        worlds.append(w)
        where.append(origin)

    rows = table(worlds)
    if not rows:
        raise SystemExit("一个世界都没读出来 —— 这张表等于没跑。")

    print(f"不同的帧 {n_frames} 帧（prev 与 nxt 按内容去重）：读成世界 {len(worlds)} 帧，"
          f"读不成 {unreadable} 帧（不进下表）\n")
    print(f"{'字段':<22}{'单独分得开':<12}{'同组里的取值数':>14}{'分组数':>8}  见证")
    print("-" * 78)
    for r in sorted(rows, key=lambda x: (x["split"], x["max_values"]), reverse=True):
        tag = "分得开" if r["split"] else ("**分不开**（恒定）" if r["constant"] else "**分不开**")
        print(f"{r['field']:<22}{tag:<12}{r['max_values']:>14}{r['groups']:>8}  {_wit(r, where)}")

    n_split = sum(r["split"] for r in rows)
    const = [r["field"] for r in rows if r["constant"]]
    print(f"\n{len(rows)} 个字段，{n_split} 个单独分得开，{len(rows) - n_split} 个没有见证。")
    if const:
        print(f"其中**恒定**（整批语料只取过一个值）：{'、'.join(const)} —— 它一位信息都没带（卡 03「删」的第一种）。")
    st = counter_stats(worlds)
    cnt = st["counters"]
    print(f"\n计数带判据：数值型标量字段里，取值个数 / 不同世界个数 ≥ {st['min_ratio']}（不同世界 {st['worlds']} 个，"
          f"至少 {st['min_worlds']} 个才判）。比例最高的三个："
          + "、".join(f"{f} {v}/{st['worlds']}" for f, v in
                     sorted(st["values"].items(), key=lambda kv: -kv[1])[:3]))
    rel = {}
    if cnt:
        rel = {r["field"]: r for r in table(worlds, exclude=cnt)}
        print(f"\n**有几乎每帧都不同的字段：{'、'.join(cnt)}**（过了上面那道门槛）。它在的时候，"
              "按「除 f 以外全部相等」分组几乎每组只剩一个世界，上面那张表对别的字段全体退化。"
              "（只认数值型标量；整盘结构的字段比例再高也不扣。）")
        print("下面是**扣掉它们**再分一次（见证 = 除了 f 和这几个字段以外全部相等的一对）。"
              "代价：若 f 其实是由计数条算出来的，这里会给出假见证——两张表对着看。\n")
        print(f"{'字段':<22}{'扣掉计数条后':<12}{'同组里的取值数':>14}{'分组数':>8}  见证")
        print("-" * 78)
        for f in sorted(rel, key=lambda k: (rel[k]["split"], rel[k]["max_values"]), reverse=True):
            if f in cnt:
                continue
            r = rel[f]
            print(f"{f:<22}{'分得开' if r['split'] else '**分不开**':<12}"
                  f"{r['max_values']:>14}{r['groups']:>8}  {_wit(r, where)}")
    if n_split < len(rows):
        print("没有见证的那些**不等于该删**：可能是没人读、可能是和别的字段同生共死、"
              "也可能是这批语料分不开。\n这张表只说「有没有见证」——接着问是哪一种。")

    if a.json:
        def _j(r):
            return {**r, "witness": [where[i] for i in r["witness"]] if r["witness"] else None}
        Path(a.json).write_text(json.dumps({
            "frames": n_frames, "worlds": len(worlds), "unreadable": unreadable,
            "fields": [_j(r) for r in rows], "constant": const, "counter_stats": st,
            "without_counters": [_j(r) for f, r in rel.items() if f not in cnt],
        }, ensure_ascii=False, indent=1, default=list), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
