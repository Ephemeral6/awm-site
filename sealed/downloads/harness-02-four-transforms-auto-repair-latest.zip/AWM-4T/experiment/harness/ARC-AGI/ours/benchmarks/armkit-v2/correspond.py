# -*- coding: utf-8 -*-
"""**Lean 定义 ↔ 规则层** 的弱对应检查。

    python correspond.py <跑场>

## 这一条堵的是什么洞

上一批的台架只做两件事：把新写/改过的 `.lean` 自己编一遍、查 `#print axioms` 干不干净。
**概念层和 Lean 定义之间没有任何对应检查** —— 受试完全可以绕开自己辛苦建的规则层，
另写一份和它无关的 Lean，台架照样放行、照样算「公理干净」。

这正是我自己在 sc25 上栽过的那一类错：Lean 编得过、公理干净，
但它证的是**另一个系统**（我把四下点击的施法当成了原子动作，抽象偏严，
结论传不过去）。受试当然也会栽，而且自造的实例没有第三方真值，更不容易被发现。

## 为什么是**弱**的、而且**只报不拦**

名字对不上不等于证错了：同一条规则在 Lean 里可以叫别的名、可以被拆成几条、
也可以合并进一个大的 `step` 函数。所以这里只给出一个**可看的对照表**和两个数：

```
规则层有、Lean 里找不到对应名字的   —— 可能是「这条没进模型」，要它明说
Lean 里有、规则层没有对应条目的     —— 可能是凭空多出来的假设，要它明说
```

硬拦会变成一道**不可满足的闸** —— 我们为此栽过一次（要求「必须见过门接受一次」，
在不可解盘上永远满足不了，框架臂只能交 giveup）。所以这一条的用法是：
把两个数放进读数，并在追问里要求受试**逐条交代**对不上的那几项。
"""
from __future__ import annotations

import argparse
import io
import json
import re
import sys
from pathlib import Path

DEF = re.compile(r'^\s*(?:private\s+|protected\s+|noncomputable\s+)*'
                 r'(def|abbrev|structure|inductive|theorem|lemma)\s+([A-Za-z_][\w\'.]*)',
                 re.M)
CLAIM = re.compile(r'^\s*CLAIM\s*=\s*[\"\']{1,3}(.{0,160})', re.M | re.S)


def _norm(s: str) -> str:
    """把 `a5_fill_halfplane` 和 `A5FillHalfplane` / `fillHalfPlane` 归一到一串小写词。"""
    s = re.sub(r'[^0-9A-Za-z]+', ' ', s)
    s = re.sub(r'(?<=[a-z0-9])(?=[A-Z])', ' ', s)
    return " ".join(sorted(set(w.lower() for w in s.split() if len(w) > 1)))


def rules(arena: Path) -> list:
    out = []
    for sub in ("concepts", "model"):
        d = arena / sub
        if not d.exists():
            continue
        for f in sorted(d.rglob("*.py")):
            if f.name.startswith("_") or f.name == "TEMPLATE.py":
                continue
            m = CLAIM.search(f.read_text(encoding="utf-8", errors="replace"))
            out.append({"name": f.stem, "file": str(f.relative_to(arena)).replace("\\", "/"),
                        "claim": (m.group(1).strip().splitlines() or [""])[0] if m else ""})
    return out


def defs(arena: Path) -> list:
    out = []
    d = arena / "lean"
    if not d.exists():
        return out
    for f in sorted(d.rglob("*.lean")):
        txt = f.read_text(encoding="utf-8", errors="replace")
        txt = re.sub(r'/-.*?-/', ' ', txt, flags=re.S)          # 先剥注释，别把注释里的名字当定义
        txt = re.sub(r'--[^\n]*', ' ', txt)
        for kind, name in DEF.findall(txt):
            out.append({"kind": kind, "name": name,
                        "file": str(f.relative_to(arena)).replace("\\", "/")})
    return out


def match(rs: list, ds: list, lean_text: str = "") -> dict:
    """两个信号，不是一个。

    **只看同名定义是不够的** —— 实测两个框架臂的 Lean 都把规则烤进了一个单体
    `step` / `bigR` 里，定义叫 `St` / `Act` / `goal`，和规则名 `bar_tick` / `tilt_limit`
    一个词都不沾，纯名字匹配在这种写法上**永远报 0**，没有信息量。
    所以再看一个弱得多但管用的信号：**这条规则的名字有没有在 Lean 正文（含注释）里出现过。**
    被引用说明作者至少想着它；一次都没出现，就值得问一句「这条进模型了吗」。
    """
    low = lean_text.lower()
    dn = {d["name"]: _norm(d["name"]) for d in ds}
    pairs, cited, silent = [], [], []
    for r in rs:
        words = set(_norm(r["name"]).split())
        best, score = None, 0.0
        for d, dk in dn.items():
            dw = set(dk.split())
            if not words or not dw:
                continue
            s = len(words & dw) / len(words | dw)
            if s > score:
                best, score = d, s
        if best and score >= 0.34:
            pairs.append({"rule": r["name"], "lean": best, "score": round(score, 2)})
        elif r["name"].lower() in low or all(w in low for w in words if len(w) > 3):
            cited.append(r["name"])
        else:
            silent.append(r["name"])
    paired = {p["lean"] for p in pairs}
    lonely_def = [d["name"] for d in ds
                  if d["kind"] in ("def", "abbrev", "structure", "inductive")
                  and d["name"] not in paired]
    return {"pairs": pairs, "cited_only": cited, "rules_silent": silent,
            "defs_without_rule": sorted(set(lonely_def)),
            "n_rules": len(rs), "n_defs": len(ds), "n_pairs": len(pairs),
            "n_cited": len(cited), "n_silent": len(silent)}


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("arena")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    arena = Path(a.arena)
    rs, ds = rules(arena), defs(arena)
    text = "\n".join(f.read_text(encoding="utf-8", errors="replace")
                     for f in sorted((arena / "lean").rglob("*.lean"))) \
        if (arena / "lean").exists() else ""
    r = match(rs, ds, text)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=1))
        return 0
    print("规则层 %d 条 · Lean 定义/定理 %d 个" % (r["n_rules"], r["n_defs"]))
    print("  有同名定义 %d · 仅在正文/注释里被引用 %d · **一次都没出现 %d**"
          % (r["n_pairs"], r["n_cited"], r["n_silent"]))
    print()
    print("**只报不拦** —— 名字对不上不等于证错了，但要它逐条交代。")
    if r["pairs"]:
        print("\n有同名定义：")
        for p in r["pairs"][:20]:
            print("  %-34s ↔ %-28s %.2f" % (p["rule"], p["lean"], p["score"]))
    if r["cited_only"]:
        print("\n只在正文/注释里被引用（规则进了模型，但没有自己的定义）%d 条："
              % len(r["cited_only"]))
        for n in r["cited_only"][:25]:
            print("  %s" % n)
    if r["rules_silent"]:
        print("\n**在 Lean 里一次都没出现的 %d 条**（要它说明：是「没进模型」还是漏了）："
              % len(r["rules_silent"]))
        for n in r["rules_silent"][:25]:
            print("  %s" % n)
    if r["defs_without_rule"]:
        print("\nLean 里有、规则层没有对应条目的 %d 个（要它说明：是凭空多出来的假设吗）："
              % len(r["defs_without_rule"]))
        for n in r["defs_without_rule"][:25]:
            print("  %s" % n)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
