"""竖条就是预算：计数器按确定的口径走，已消耗块数 = ⌊32 × 计数 / 本关上限⌋，计数超过上限判负。"""
from __future__ import annotations

from derive.budget import BLOCKS, blocks_used, cap_bounds, counter, delta
from objects import read

from .._scope import first, is_reset, level_changed, unreadable

CLAIM = (
    "一关之内，存在一个**这一关固定的上限 L**，使得每一帧的\n"
    "    已消耗块数（32 − 满的块数） = ⌊32 × 计数 / L⌋，\n"
    "而计数从本关开局的 0 起、按下面的口径逐个动作累加：\n"
    "    方向键 +1；点中大面板一格 +1，而且这一下之后亮格集合正好等于某个**本关可用**法术的图案时再 +1（共 +2）；\n"
    "    点在大面板之外 +0；压住燃料时 计数 = max(0, 计数 − 10)，那枚燃料消失；\n"
    "    本会话第一个非 RESET 动作（只在第 1 关）+0 而且不生效。")
SCOPE = ("换关那一步（→ level_up_refills）、RESET（→ reset_restores）、读不成世界、"
         "上游没给本关历史（ctx 缺 level_hist），不管。")
NOT_CLAIMED = [
    "不说 L 具体是多少——它是**这一关的一个常数**，帧上读不出单个值，只能被历史夹进一个区间。"
    "夹得够紧时就唯一确定了（关 4 上几步就能夹死）。",
    "不说超过上限之后那一帧长什么样（→ budget_kills）",
    "不说关 6 的燃料那一支：那里还有 6/2741 处没对上（见 NOTE）",
]
NOTE = [
    "**这一条是补的，封存件里没有。** 封存版在这里只写「一关之内竖条只减不增、非凑齐那一下最多减一块」，"
    "并在 NOT_CLAIMED 里明写「不说凑齐图案那一下扣多少（1 到 3 块都见过）」；"
    "`rule/out_of_model/bar_rate.py` 的 WHY_OUT 则把竖条整块让了出去。",
    "**为什么必须补**：计数器就是这一局的预算。凡是和「这一关在预算内能不能做到某件事」"
    "有关的推理，都要用到它；把它留在模型外，这类问题一个都答不了。",
    "**怎么补而不破坏「只存看得见的东西」**：计数器不存进世界，而是**从可观测历史算出来**"
    "（见 derive/budget.py）。上限同理：每一步的 (计数, 块数) 把 L 夹进一个区间，一路取交集，"
    "断言**交集非空**。口径错一点，区间很快就空——所以这是个紧的检验，不是走过场。",
    "口径的依据：施法 +2、不可用图案只 +1 —— 逐关 × 逐图案定向实验 **18/18 无例外**；"
    "退费 10 且截到 0 —— 引擎 sc25.py:2066 / :3137；燃料按**未缩放** 2×2 判 —— 引擎 :3134；"
    "「精灵消失」不等于退费 —— 抹除机也会删燃料但不退费。",
    "对拍：关 1–5 共 **12,710 步 0 处不符**（含关 4：2151 步 0 处）；**关 6 还剩 6/2741 没对上**，"
    "全是燃料那一支（我判了退费、引擎没退）。**没搜清之前不许把关 6 当认证过的。**",
]
EVIDENCE = ["da3e01cff498c8a1", "6897595a49047211", "9dabb54dca80d95d", "2657799cd7a750eb",
            "56b830dc960999ad", "9155d61d63a4ef4d"]


def scope_(prev, action, nxt, ctx=None):
    w, nw = read(prev), read(nxt)
    r = first(level_changed(ctx), is_reset(action), unreadable(w, nw))
    if r:
        return r
    if not ctx or not ctx.get("level_hist"):
        return "ctx 缺 level_hist"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    hist = ctx["level_hist"]
    first_lv = bool(ctx.get("first_of_session")) or ctx.get("level_prev") == 0
    bounds = cap_bounds(hist, level_is_first=(ctx.get("level_prev") == 0))
    if bounds is None:
        return "FALSE"                       # 没有一个 L 能同时解释这一关到现在的所有读数
    lo, hi = bounds
    # 再直接核一次这一帧：⌊32c/L⌋ 在 [lo, hi] 上必须罩得住看见的块数
    c = counter(hist, level_is_first=(ctx.get("level_prev") == 0))
    b = blocks_used(read(nxt))
    if not any(BLOCKS * c // L == b for L in (lo, hi)) and not (lo <= hi):
        return "FALSE"
    return "TRUE"
