"""Stop only the recorded case's server after checking its current command."""
import argparse,json,re,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent;AK=HERE.parent.parent/'benchmarks/armkit'
def main():
    p=argparse.ArgumentParser();p.add_argument('--case',required=True);a=p.parse_args()
    if not re.fullmatch(r'l[45][se]-case-[0-9a-f]{6}',a.case):p.error('only a generated case ID is accepted')
    f=AK/'srvout'/(a.case+'.process.json')
    if not f.exists():return 0
    owner=json.loads(f.read_text(encoding='utf-8'));pid=int(owner['pid'])
    r=subprocess.run(['powershell','-NoProfile','-Command',f'(Get-CimInstance Win32_Process -Filter "ProcessId={pid}").CommandLine'],capture_output=True,text=True,encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
    line=r.stdout.lower().replace('/','\\')
    if not line.strip():return 0
    if str(owner['server']).lower().replace('/','\\') not in line or str(owner['log']).lower().replace('/','\\') not in line:
        print('PID identity changed; not killed:',pid);return 2
    return subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW).returncode
if __name__=='__main__':raise SystemExit(main())
