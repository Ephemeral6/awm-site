"""我压到场上一坨燃料的任何一格：整坨消失（没被我压住的那几格变地板），竖条净涨不少于那一坨的格数（按块数，一块两行）。"""
from __future__ import annotations

from derive.fuel import eaten
from objects import read

from .._scope import first, is_reset, level_changed, unreadable

CLAIM = ("这一步结束时我压住了上一帧场上一坨燃料（四连通）的至少一格：整坨都消失——没被我压住的那几格变成地板；"
         "竖条净涨**不少于**「那一坨的格数」块（一块两行）。")
SCOPE = "换关那一步、RESET、读不成世界、这一步一坨燃料都没压到，不管。"
NOT_CLAIMED = ["不说净涨恰好几块（两次观测：4 格涨 4 块、4 格涨 5 块，量具只数整块）",
               "不说只挨着不压住会怎样（语料里 0 次）"]
NOTE = ["起点：册子 fuel_absorbs v2（「按格数」被第二次观测打成下界）。"]
EVIDENCE = ["9155d61d63a4ef4d", "2bd4ea89a01958ec"]


def scope_(prev, action, nxt, ctx=None):
    w, nw = read(prev), read(nxt)
    r = first(level_changed(ctx), is_reset(action), unreadable(w, nw))
    if r:
        return r
    if not eaten(w, nw):
        return "一坨燃料都没压到"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    gone = eaten(w, nw)
    mine = nw.me.cells()
    for p in gone - mine:
        if p not in nw.ground.floor:
            return "FALSE"
    return "TRUE" if nw.bar.rows - w.bar.rows >= 2 * len(gone) else "FALSE"
