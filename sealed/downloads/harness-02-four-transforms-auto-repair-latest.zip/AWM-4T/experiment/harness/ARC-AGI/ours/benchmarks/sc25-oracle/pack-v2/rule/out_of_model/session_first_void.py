"""每个世界会话（开局、换卡）收到的第一条动作被世界吞掉：整个世界一格不变，连竖条也不动。"""
from __future__ import annotations

from objects import read

CLAIM = "上游说这是一个世界会话收到的第一条动作，**而且这一步发生在第 1 关**：世界一格不变，竖条也不动。"
SCOPE = "只看会话第一下（ctx.first_of_session）**且 level_prev == 0**；读不成世界不管。"
NOT_CLAIMED = ["RESET 之后的第一下不算（四次 RESET 之后的第一下都没被吞）",
               "**不说会话从第 1 关之外开局时第一下会怎样** —— 实测**不会**被吞，见 NOTE"]
WHY_OUT = ("「这是不是会话第一下」在帧上、在世界里都读不出（第 1 步和第 2 步的上一帧逐格相同），"
           "只能靠上游的会话身份认。模型只看世界，所以这一步在模型那一侧是一处断点，不是一条定义。")
NOTE = ["起点：册子 first_action_void v2（主语从「一个 run 的第一条」改成「一个世界会话的第一条」）。",
        "**更正（CORRECTIONS.md A）**：封存版写的是「任何世界会话的第一条」，论域里没有关号。"
        "真引擎上随机走（每局新开引擎 + set_level(k) + RESET，k 随机）实测：会话开在第 1 关之外时，"
        "第一下**照常生效**——72 次里 60 次驳倒原主张。被吞那一下来自第 1 关的法术演示。",
        "所以论域收窄到「而且在第 1 关」。这是**收窄**，不是改结论：原来的结论在第 1 关上仍然成立。"]
EVIDENCE = ["86e0735e73235325", "13fcb5b3e3fa0714"]


def scope_(prev, action, nxt, ctx=None):
    if not (ctx and ctx.get("first_of_session")):
        return "不是会话第一下"
    if ctx.get("level_prev") != 0:
        return "会话不是开在第 1 关（更正 A：那一下不被吞）"
    if read(prev) is None or read(nxt) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if read(prev) == read(nxt) else "FALSE"
