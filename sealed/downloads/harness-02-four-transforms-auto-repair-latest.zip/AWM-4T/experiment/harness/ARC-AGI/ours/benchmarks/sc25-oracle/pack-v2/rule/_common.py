"""规则层共用的小东西。**这里不许放判断。**

放得进来的：比两个世界的某几层、常量名。
放不进来的：任何「这一步该变成什么样」的推断 —— 那是规则自己的活。

帧只交给对象层：规则一律 `from objects import read`（读成 World），不在这里转手——
帧交给对象层之外的东西，装置的像素接触检查会记一笔。
"""
from __future__ import annotations


def flat(w):
    """地面摊成一张表：格 → 那一格是什么。**只是换个查法，不加信息。**"""
    return dict(w.ground.at)


def ground_diff(a, b, skip=frozenset()):
    """两个世界的地面在「两帧都看得见、又不在 skip 里」的格上有哪些不同：[(格, 前, 后)]。
    **只比较，不判断。**"""
    fa, fb = flat(a), flat(b)
    hidden = a.me.cells() | b.me.cells() | frozenset(skip)
    out = []
    for p in set(fa) | set(fb):
        if p in hidden:
            continue
        x, y = fa.get(p, ("void",)), fb.get(p, ("void",))
        if x != y:
            out.append((p, x, y))
    return sorted(out)
