"""点中大面板一个还没亮的格位、而且点亮它凑不齐任何一块图案：只有那一格亮起来，别的格位与我都不动。"""
from __future__ import annotations

from derive.pad_hits import completes, toggled
from objects import parse_action, read

from .._scope import unreadable

CLAIM = "点中大面板一个格位、**翻转**它之后凑不齐任何一块小面板的图案：只有那一格翻转（灭↔亮），别的格位不变，我不动。"
SCOPE = "只看点击；没点中大面板（→ dead_click）、这一下凑齐了图案（→ completion_clears）、读不成世界，不管。"
NOT_CLAIMED = ["不说竖条扣多少（bar_budget 管）", "不说地面（ground_still 管）"]
NOTE = [
    "起点：册子 click_lights_panel v3（「没亮」从「色是 0」放宽成「不是亮色」）。",
    "重排：「别处一格不动」拆开——大面板与我归这里，地面归 ground_still，竖条归 bar_*。",
    "**更正（CORRECTIONS.md B）**：点中已亮的格位是**灭掉**它，不是「什么都没发生」，也不是「点亮」。",
]
EVIDENCE = ["477bf0b6c6fc98eb", "bcf6976ebd8e9446"]


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if toggled(w, action) is None:
        return "点在面板外 → dead_click"
    if completes(w, action) is not None:
        return "凑齐 → completion_clears"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    cell = toggled(w, action)
    i = cell[0] * 3 + cell[1]
    # **更正（CORRECTIONS.md B）**：是翻转，不是一律点亮。
    # 灭掉一格之后露出的是 "off"（带提示色）还是 "blank"（和地板同色），**帧上定不下来**：
    # 它还原成被点亮之前那一态，而那一态单帧读不出。所以熄灭那一侧两种都认。
    for j, (a_, b_) in enumerate(zip(w.pad.cells, nw.pad.cells)):
        if j != i:
            if a_ != b_:
                return "FALSE"                      # 别的格位不许动
        elif a_ == "lit":
            if b_ not in ("off", "blank"):
                return "FALSE"                      # 亮 → 灭
        elif b_ != "lit":
            return "FALSE"                          # 灭 → 亮
    return "TRUE" if nw.me == w.me else "FALSE"
