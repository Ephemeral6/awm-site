"""Read current arena Python source; never trust timestamp-based .pyc imports.

This is a freshness measure, not a sandbox. Does not alter files or external imports.
"""
from pathlib import Path
import importlib.abc,importlib.machinery,sys

class _Source(importlib.machinery.SourceFileLoader):
    def get_code(self,fullname):
        return compile(self.get_data(self.path),self.path,'exec',dont_inherit=True)

class _Finder(importlib.abc.MetaPathFinder):
    def __init__(self):self.roots=set()
    def find_spec(self,fullname,path=None,target=None):
        spec=importlib.machinery.PathFinder.find_spec(fullname,path,target)
        if not spec or not spec.origin or spec.origin in ('built-in','frozen'):return None
        p=Path(spec.origin).resolve()
        if not any(p.is_relative_to(root) for root in self.roots):return None
        if p.suffix=='.py':
            spec.loader=_Source(fullname,str(p));return spec
        if p.suffix=='.pyc':raise ImportError('Arena module requires current Python source: '+str(p))
        return None

_finder=_Finder()
def install(root):
    _finder.roots.add(Path(root).resolve())
    if _finder not in sys.meta_path:sys.meta_path.insert(0,_finder)
