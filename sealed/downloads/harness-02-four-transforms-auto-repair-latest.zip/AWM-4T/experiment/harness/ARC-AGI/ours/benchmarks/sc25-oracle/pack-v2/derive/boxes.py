"""框：某个记号色的四个角圈出的、和我同边长的方区。

## 两种画法都认

    内画   四个记号就是方区自己的四角
    外描   四个记号落在方区外扩一圈（跨度 k+2）的四角上

同一片记号在不同边长下圈出的是**不同的**框（边长 2 时「四角」只隔 1 格），
所以「框」永远带着一个边长 k 问。

## 合法

  · 方区整块在场地里；
  · 方区里除了地板与这个记号色之外，**至多一种**别的东西，而且那一种不是虚空；
  · 不能整块都是这个记号色（那是一坨记号，不是框）；
  · 我不在里面（我压着的格看不见，框里有什么说不出来）。

这一份只算「哪几个框」；「凑齐之后搬进哪一个 / 抹哪一个」是 rule/machines/ 的主张。
"""
from __future__ import annotations

from .geometry import corners, inside, square


def boxes(w, color, k):
    marks = w.ground.marks_of(color)
    hits = {(r, c) for (r, c) in marks if corners(r, c, k) <= marks}
    hits |= {(r + 1, c + 1) for (r, c) in marks if corners(r, c, k + 2) <= marks}
    mine = w.me.cells()
    out = []
    for b in sorted(hits):
        sq = square(b[0], b[1], k)
        if not all(inside(p) for p in sq) or sq & mine:
            continue
        if sq <= marks:
            continue
        kinds = set()
        for p in sq:
            t = w.tile(p)
            if t == ("floor",) or t == ("mark", color):
                continue
            kinds.add(t)
        if len(kinds) <= 1 and ("void",) not in kinds:
            out.append(b)
    return out


def specimen(w, box, color, k):
    """框里扣着的那一样东西（地板与这个记号色之外唯一的那一种）；空框返回 None。"""
    kinds = set()
    for p in square(box[0], box[1], k):
        t = w.tile(p)
        if t == ("floor",) or t == ("mark", color):
            continue
        kinds.add(t)
    return next(iter(kinds)) if len(kinds) == 1 else None


def ring(w, box, color, k):
    """画出这个框的那一圈记号：这个色落在「框外扩一圈」矩形里的所有格。两种画法都罩得住。"""
    br, bc = box
    return frozenset(p for p in w.ground.marks_of(color)
                     if br - 1 <= p[0] <= br + k and bc - 1 <= p[1] <= bc + k)


def outer_ring_lit(w, box, color, k) -> bool:
    """这个框戴没戴外圈：外扩一格那个跨度 k+2 方框的四角全是这个记号色。"""
    return corners(box[0] - 1, box[1] - 1, k + 2) <= w.ground.marks_of(color)
