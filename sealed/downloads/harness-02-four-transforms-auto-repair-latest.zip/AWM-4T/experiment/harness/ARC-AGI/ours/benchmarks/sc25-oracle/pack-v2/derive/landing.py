"""涨大的落点：边长 2 的我涨成 4，新的 4×4 必须含住原来那块 2×2，
所以左上角只有九个候选 (r0-2..r0) × (c0-2..c0)。

按**先最左、再最上**扫（dx 外层），取第一个**整块涨得上去**的（derive/standing.growable）；九个都不行返回 None。

## 更正（`CORRECTIONS.md` E1）

封存版写的是 `for dr: for dc:`（dy 外层，「先最上、再最左」）。
引擎 `hsrovbjzdx` 是 `for dx in range(-span,1): for dy in range(-span,1)`，而
`qbdokwllfg(me, newscale, twrcxfjfan, ykaqxdinqs)` 把 `twrcxfjfan` 加到 **x**、`ykaqxdinqs` 加到 **y**
（`sc25.py:2916-2917`）—— 所以**外层是 dx**，枚举序是 (−2,−2) (−2,−1) (−2,0) (−1,−2) … (0,0)。

两种读法在整个盘面上只有 **4** 个位置分得开（3888 个可放下小身的位置里，全在关 5 的
(x,y) ∈ {37,38} × {33,34}）—— 所以他们语料里「10 次涨大两种读法同值」是真的。
**对目标关（关 4）不起作用**，但模型该按引擎写。
这一份只算量；「凑齐翻尺寸色时落在这里」是 rule/machines/resize.py 的主张。
"""
from __future__ import annotations

from .geometry import square
from .standing import growable


def grow_landing(w):
    me = w.me
    if me.side != 2:
        return None
    k, nk = me.side, 2 * me.side
    for dc in range(-k, 1):              # **外层是 dc（引擎的 dx）** —— 见上文更正 E1
        for dr in range(-k, 1):
            rr, cc = me.row + dr, me.col + dc
            if all(growable(w, p) for p in square(rr, cc, nk)):
                return (rr, cc)
    return None
