# -*- coding: utf-8 -*-
"""field_split.py / criteria_run.py 共用的**读入那一层**：v7 跑场的语料、对象层、规则层怎么进来。

这里只管「进来」，不含任何判据。判据留在两个工具里，和原来那两份一字一句对得上。

## 语料（v7 跑场的 transitions.jsonl，play.py 写的）

    {"t": 时间戳, "tid": "16 位哈希", "action": "ACTION1" | "ACTION6:x,y" | "RESET",
     "prev": 帧, "nxt": 帧, "ctx": {"level_prev", "level_next", "state_next", "levels_completed"}}

帧 = 行的列表，每行是整数的列表（`frame[y][x]`）。读进来以后键名统一成 `next`
（原来那两份工具一律用 `next`；`nxt` 和 `next` 两种写法都认）。每条转移另记一个 `seq` = 它在文件里的行号（从 1 起）。

## 对象层（`objects/`）

`objects/parse.py` 里有 `parse(frame) -> World`（World 是 dataclass）和 `ParseError`。
`objects/__init__.py` 把它们再导出一遍最好；没有导出也认（直接去 `objects.parse` 那个子模块里找）。

## 规则层（`rule/`）

`rule/<组>/<规则>.py`，一条一个文件；文件名以 `_` 开头的不是规则（`_common.py` 之类）。
每条规则：`scope_(prev, action, nxt, ctx=None)` 返回 None = 我管 / 一句非空的理由 = 我不管；
`assert_(prev, action, nxt, ctx=None)` 返回 "TRUE" / "FALSE" / "NA"。prev / nxt 是**帧**，规则自己经对象层读成世界。
"""
from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import sys
from dataclasses import is_dataclass
from pathlib import Path


def utf8_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass


# ---------------------------------------------------------------- 语料

def load_transitions(path: Path, raw_text=None) -> tuple[list[dict], dict]:
    """读 transitions.jsonl。返回（去重后的转移，口径）。

    **半截尾行**（写盘时被强杀）跳过并公示；**中间**某行坏了是真损坏，停下来——默默跳过会少算一条语料。
    去重按 tid（v7 的 settle 也是这样：同一条转移只考一次）。口径里同时报「行数」和「去重后的条数」。
    """
    lines = [ln for ln in (Path(path).read_text(encoding="utf-8") if raw_text is None else raw_text).splitlines() if ln.strip()]
    out, seen, broken_tail, dup = [], set(), None, 0
    for i, line in enumerate(lines):
        try:
            r = json.loads(line)
        except Exception as e:                                    # noqa: BLE001
            if i == len(lines) - 1:
                broken_tail = f"最后一行是半截的（{e}），已跳过"
                break
            raise SystemExit(f"{path} 第 {i + 1} 行坏了（{e}），而它不是最后一行 —— 这是真损坏，不自动修。")
        if not isinstance(r, dict) or "prev" not in r or ("nxt" not in r and "next" not in r):
            raise SystemExit(f"{path} 第 {i + 1} 行不是一条转移（要有 prev 和 nxt）")
        nxt = r["nxt"] if "nxt" in r else r["next"]
        tid = r.get("tid") or _tid(r["prev"], r.get("action"), nxt)
        if tid in seen:
            dup += 1
            continue
        seen.add(tid)
        out.append({"seq": i + 1, "tid": tid, "action": r.get("action"), "prev": r["prev"],
                    "next": nxt, "ctx": r.get("ctx") or {}})
    return out, {"lines": len(lines), "uniq": len(out), "dup": dup, "broken_tail": broken_tail}


def _tid(prev, action, nxt) -> str:
    """没记 tid 的老行：照 play.py 的算法补一个。"""
    h = hashlib.md5()
    h.update(json.dumps(prev, separators=(",", ":")).encode())
    h.update(str(action).encode())
    h.update(json.dumps(nxt, separators=(",", ":")).encode())
    return h.hexdigest()[:16]


def frames_of(path: Path):
    """field_split 用的帧流：transitions.jsonl 里**全部不同的** prev 与 nxt；也认一行一帧的 jsonl。

    逐个交出 (帧, 出处)。出处 = 「第 seq 行 prev/nxt」，见证就按它报。
    """
    seen = set()
    for i, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines()):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except Exception:                                         # noqa: BLE001
            continue                                              # 半截尾行
        if isinstance(r, dict) and ("prev" in r or "nxt" in r or "next" in r):
            pairs = [("prev", r.get("prev")), ("nxt", r["nxt"] if "nxt" in r else r.get("next"))]
        else:
            pairs = [("帧", r)]
        for side, fr in pairs:
            if fr is None:
                continue
            k = hashlib.sha1(repr(fr).encode("utf-8")).hexdigest()
            if k in seen:
                continue
            seen.add(k)
            yield fr, f"第 {i + 1} 行 {side}"


# ---------------------------------------------------------------- 对象层

def _add_path(p: Path) -> None:
    s = str(p)
    if s not in sys.path:
        sys.path.insert(0, s)


class ObjLayer:
    """对象层的一个**把手**：`World` / `parse` / `ParseError` 三样，外加「换掉 parse」。

    原来的消融是 `setattr(objects, "parse", 补丁)`。这里换掉的地方有两处：
    包上的 `objects.parse`，和子模块 `objects/parse.py` 里的 `parse`——
    规则经 `from objects import parse` 或经 `objects/parse.py` 里的辅助函数（按模块全局名现取 parse）读世界，
    两条路都要换到。换不到的路（别的模块在导入时就把 parse 绑走了）由消融那一侧的**自检**报出来。
    """

    def __init__(self, objects_dir: Path) -> None:
        d = Path(objects_dir).resolve()
        if not d.is_dir():
            raise SystemExit(f"{objects_dir} 不是目录")
        from source_imports import install
        install(d.parent)
        sys.dont_write_bytecode = True                           # 不往跑场里写 __pycache__
        _add_path(d.parent)
        concepts = d.parent / "concepts"                          # v7 跑场的 _lib / geo 在这两处
        if concepts.is_dir():
            sys.path.append(str(concepts))
        self.dir = d
        self.name = d.name
        try:
            self.pkg = importlib.import_module(d.name)
        except ImportError as e:
            raise SystemExit(f"{objects_dir} 导不进来：{e!r}")
        self.sub = None
        try:
            self.sub = importlib.import_module(f"{d.name}.parse")
        except ImportError:
            pass
        if not callable(getattr(self.pkg, "parse", None)) and self.sub is None:
            raise SystemExit(f"{objects_dir} 里没有 parse —— 这一份不知道怎么把帧变成世界。")
        # 规则写的是 `from objects import …`。传进来的是 objects_2 这种另存的一份时，
        # 不把名字指过去，规则读的还是原来那份，补丁打在副本上——**等于没打，而且不报错**。
        self.aliased = False
        if d.name != "objects" and "objects" not in sys.modules:
            for k in [k for k in sys.modules if k == d.name or k.startswith(d.name + ".")]:
                sys.modules["objects" + k[len(d.name):]] = sys.modules[k]
            self.aliased = True
        self._World = None

    # 三样契约 ----------------------------------------------------------
    def _find(self, name):
        for m in (self.pkg, self.sub):
            v = getattr(m, name, None) if m is not None else None
            if v is not None and not inspect.ismodule(v):
                return v
        return None

    @property
    def parse(self):
        f = getattr(self.pkg, "parse", None)
        if callable(f) and not inspect.ismodule(f):
            return f
        return getattr(self.sub, "parse")

    @parse.setter
    def parse(self, fn) -> None:
        pf = getattr(self.pkg, "parse", None)
        if pf is None or (callable(pf) and not inspect.ismodule(pf)):
            setattr(self.pkg, "parse", fn)
        if self.sub is not None and callable(getattr(self.sub, "parse", None)):
            setattr(self.sub, "parse", fn)

    @property
    def ParseError(self):                                          # noqa: N802
        e = self._find("ParseError")
        return e if isinstance(e, type) else _NoParseError

    @property
    def World(self):                                               # noqa: N802
        W = self._find("World")
        if isinstance(W, type):
            return W
        return self._World

    def learn_world(self, w) -> None:
        """包和 parse.py 都没导出 World 时，拿第一个读出来的世界的类型当 World。"""
        if self._World is None and w is not None and is_dataclass(w):
            self._World = type(w)

    def contract(self) -> list[str]:
        """契约缺了什么（原 objects_layer.contract 的口径）。空列表 = 齐了。"""
        out = []
        W = self.World
        if W is None:
            out.append("没有 World")
        elif not is_dataclass(W):
            out.append("World 不是 dataclass（字段要数得出来，判据才有的问）")
        if not isinstance(self._find("ParseError"), type):
            out.append("没有 ParseError（读不出来要抛，别返回 None）")
        return out


class _NoParseError(Exception):
    """对象层没有 ParseError 时，补丁拿它来抛。契约那一行会把「没有 ParseError」报出来。"""


# ---------------------------------------------------------------- 规则层

def _arity(fn, default: int) -> int:
    try:
        return len(inspect.signature(fn).parameters)
    except (TypeError, ValueError):
        return default


def load_rules(rule_dir: Path, obj: ObjLayer | None = None) -> tuple[list[dict], list[str]]:
    """rglob rule/ 下每一个规则文件。**空表判红**（调用方判）。

    返回（规则列表，问题列表）。每条规则是一个 dict，键名跟原来的 settle.load_concepts 走：
    `name / fn / arity / scope_fn / scope_arity`，外加 `group / path / mod / claim`。
    """
    d = Path(rule_dir).resolve()
    if not d.is_dir():
        return [], [f"{rule_dir} 不是目录"]
    sys.dont_write_bytecode = True
    base = d.parent
    _add_path(base)
    out, bad, names = [], [], {}
    for p in sorted(d.rglob("*.py")):
        if p.name.startswith("_") or "__pycache__" in p.parts:
            continue
        rel = p.relative_to(base).with_suffix("")
        modname = ".".join(rel.parts)
        try:
            m = importlib.import_module(modname)
        except Exception as e:                                    # noqa: BLE001
            bad.append(f"{p.relative_to(base).as_posix()}: 导入失败 {e!r}")
            continue
        fn = getattr(m, "assert_", None)
        if not callable(fn):
            bad.append(f"{p.relative_to(base).as_posix()}: 没有 assert_(prev, action, nxt[, ctx])")
            continue
        ar = _arity(fn, 4)
        if ar not in (3, 4):
            bad.append(f"{p.relative_to(base).as_posix()}: assert_ 要 3 或 4 个参数，现在是 {ar} 个")
            continue
        sc = getattr(m, "scope_", None)
        sc_ar = 0
        if sc is not None:
            if not callable(sc):
                bad.append(f"{p.relative_to(base).as_posix()}: scope_ 不是函数")
                continue
            sc_ar = _arity(sc, 4)
            if sc_ar not in (3, 4):
                bad.append(f"{p.relative_to(base).as_posix()}: scope_ 要 3 或 4 个参数，现在是 {sc_ar} 个")
                continue
        else:
            bad.append(f"{p.relative_to(base).as_posix()}: 没有 scope_ —— 论域不可执行（卡 04），"
                       "这条照跑，NA 全由 assert_ 说")
        group = p.parent.relative_to(d).as_posix()
        if group == ".":
            group = ""
            bad.append(f"{p.relative_to(base).as_posix()}: 直接放在 rule/ 根上 —— "
                       "规则按「它管什么」收进子文件夹（卡 04）")
        if p.stem in names:
            bad.append(f"规则名 {p.stem} 重了：{names[p.stem]} 和 {p.relative_to(base).as_posix()}"
                       "（读数按文件名记账，后一条会盖掉前一条）")
        names[p.stem] = p.relative_to(base).as_posix()
        out.append({"name": p.stem, "group": group, "path": p.relative_to(base).as_posix(),
                    "mod": m, "modname": modname, "fn": fn, "arity": ar,
                    "scope_fn": sc if callable(sc) else None, "scope_arity": sc_ar,
                    "claim": str(getattr(m, "CLAIM", "") or (m.__doc__ or "").strip().split("\n")[0])})
    return out, bad


def reloader(rule_dir: Path, obj: ObjLayer):
    """消融要的 `reload_fn`：把规则**重新导入**，让它们拿到被换掉的那个 parse。

    原来是对每个规则模块 `importlib.reload`。这里多做一步：跑场根下**除对象层以外**导进来过的模块
    （`rule/_common.py`、`derive/…`、`concepts/_lib.py` 之类）一并清掉重导——
    只重导规则文件的话，规则经 `derive/` 里 `from objects import parse` 绑走的那一份读世界，
    补丁打不到，消融安静地全报「没人用」（卡 07 说的第三个入口）。
    """
    d = Path(rule_dir).resolve()
    root = d.parent
    keep = obj.dir
    tools = Path(__file__).resolve().parent              # 只排掉工具自己那几个文件（不是整个目录）

    def _under(f: str | None, top: Path) -> bool:
        if not f:
            return False
        try:
            Path(f).resolve().relative_to(top)
            return True
        except (ValueError, OSError):
            return False

    def _tool(f: str | None) -> bool:
        try:
            return bool(f) and Path(f).resolve().parent == tools
        except OSError:
            return False

    def reload_fn() -> list[dict]:
        for k, m in list(sys.modules.items()):
            f = getattr(m, "__file__", None)
            if _under(f, root) and not _under(f, keep) and not _tool(f):
                del sys.modules[k]
        importlib.invalidate_caches()
        rules, _ = load_rules(d, obj)
        return rules

    return reload_fn
