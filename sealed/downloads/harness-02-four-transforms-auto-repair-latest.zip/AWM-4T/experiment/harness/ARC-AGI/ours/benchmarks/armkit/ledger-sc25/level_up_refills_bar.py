"""过关那一步，右边缘竖条回到满格 32 块——预算是按关给的，不是整局一共那么多；通关那一步除外，那一下没有下一关。"""
LEVEL = "L4"
SCOPE = "只看换关的转移（ctx.level_next != ctx.level_prev）；没有 ctx 返回 NA；" \
        "**这一步之后 state 是 WIN 的（整局通关）返回 NA**——那一下没有下一关，也就没有下一关的预算。"
NOTE = "第 23 步唯一一次观测：竖条从 20 块跳回 32 块。这条和 bar_monotone 是同一把尺子的两段，" \
       "拆开是因为 v1 的 bar_monotone 把过关那一下当成了反例。" \
       "v2：第 250 步打脸——最后一关踏进插座，关卡照样 +1、state 变 WIN，可竖条停在原地没有回满。" \
       "整屏也没有重画：那一步的帧差只有 16 格，就是我的身子沉进插座，别的一格没动。" \
       "所以「过关」这个词一直是两件事捆在一起：**开下一关**（重画 + 补满预算）和**结束这一关**。" \
       "前五次观测里两件事永远同时发生，第六次第一次分开——因为没有第六关。" \
       "教训：一个只在「后面还有一段」时成立的规律，语料里的最后一次一定是它的反例，而语料总会有最后一次。"
EVIDENCE = ["9dabb54dca80d95d", "fca17365c9aa8fc6"]

from _lib import bar_blocks

FULL = 32


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if ctx["level_next"] == ctx["level_prev"]:
        return "NA"
    if ctx.get("state_next") == "WIN":
        return "NA"
    return "TRUE" if bar_blocks(nxt) == FULL else "FALSE"
