/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    方向键    整块踏进插座 → 挪进去（SocketWins）；否则 → stepDir（Step）；然后吃燃料（FuelAbsorbs）
    点击      点空 → 原样（DeadClick）；点亮一格 → lightUp（ClickLights）；
              凑齐图案 → 清面板（CompletionClears）+ 那一台机器（Machine）+ 吃燃料
    RESET     模型说不出话（`na`）：「这一关的开局长什么样」是历史，不是当前状态的函数

`na` 不是 `ok`。它让「赢不了」这句话悄悄变成「**不经过 RESET** 赢不了」——
这半句写在 `Proof/Reachable.lean` 的 `Unsolvable` 上，也写在页面上。
-/

import Rule.Step.Step
import Rule.Win.SocketWins
import Rule.Pad.DeadClick
import Rule.Pad.ClickLights
import Rule.Pad.CompletionClears
import Rule.Machines.Machine
import Rule.World.FuelAbsorbs
import Obj.Act

namespace Game

inductive Res where
  | ok (s : St)
  | na
  deriving DecidableEq, Repr

def step (b : Board) (s : St) : Act → Res
  | .dir f =>
    match intoSocket b s f with
    | some p => .ok { s with me := { s.me with row := p.1, col := p.2, face := f } }
    | none => .ok (eatFuel b (stepDir b s f))
  | .click x y =>
    if deadClick b s x y then .ok s
    else
      match padHit b x y with
      | none => .ok s
      | some i =>
        let s1 := lightUp s i
        match completes b s1.pad with
        | none => .ok s1
        | some c => .ok (eatFuel b (machine b (clearPad s1) c))
  | .reset => .na

end Game
