"""凑齐翻尺寸色：边长 4 的我原地缩成 2、边长 2 的我涨成 4（落在九个候选里第一个涨得上去的）；场上跟着我的尺寸画的那几圈外圈同时换一套。"""
from __future__ import annotations

from derive.fuel import eaten
from derive.geometry import corners
from derive.landing import grow_landing
from derive.machines import RESIZE, TELEPORT, machine
from derive.pad_hits import completes
from derive.rings import halo_of, solid2, span6
from objects import parse_action, read
from objects.player.marker import Marker

from .._common import ground_diff
from .._scope import unreadable

CLAIM = ("凑齐翻尺寸那块小面板的图案：\n"
         "  · 我：边长 4 原地缩成 2（左上角、朝向不变）；边长 2 涨成 4——九个候选（新的 4×4 含住原来那块 2×2）"
         "按先上后左扫，落在第一个整块涨得上去的（地板、记号、燃料、我自己压着的），朝向不变；\n"
         "  · 场地上**只有外圈那几格可能变**：此刻亮着的跨度 6 记号四角可以熄灭（露出地板或虚空，两种都见过）；"
         "缩成 2 时，翻尺寸色的每一块实心 2×2 外隔一格亮起一圈翻尺寸色的四角；"
         "涨回 4 时**最多**亮起搬家色的记号（可以一组都不亮）；别处一格不动。")
SCOPE = ("只看凑齐翻尺寸色的那一下；读不成世界、边长 2 而九个候选都涨不上去（语料里 0 次），不管。"
         "地面那一半不看我前后两帧压着的格，也不看涨上去当场吃掉的燃料（→ fuel_absorbs）。")
NOT_CLAIMED = ["不说九个候选都涨不上去时会怎样（语料里 0 次）",
               "**不再主张「涨回 4 时搬家色恰好一组四角亮起」**——封存版这么写，定向扫 **180/180 全错**"
               "（关 1 / 关 4 上一组都不亮）。亮不亮、亮在哪一组，这里一律不说",
               "涨回 4 时外圈亮在**哪一个** 4×4 框上——帧上读不出；那是世界记着的一位"]
NOTE = [
    "起点：册子 panel_done_shrinks_me v7 + panel_done_grows_me v5 + resize_only_by_diamond_legend + resize_swaps_marks v4。",
    "第 1 轮（rules_v1）是两条：resize（我）与 rings_follow_size（外圈）。卡 05 合成这一条：论域逐字相同，结论各说一半。",
    "rings_follow_size 在第 1 轮第一次跑就挨过打（seq 113：我站在那个框里，v1 要求「合法框」；seq 175：吃掉的燃料被当成别处动了），"
    "改法见 analysis/history/rules_v1 里它的 NOTE。",
    "「凑齐别的色边长一格不动」不在这里说：teleport / erase 各自断言我的边长不变。",
    "**更正（CORRECTIONS.md E）**：先前我把 E 记成「落点和扫描序对不上」，**那个归因是错的**。"
    "`_me_ok`（尺寸、落点、朝向）在 180 次涨大里**一次都没错**；错的是外圈那几句，**180/180 全错**。",
    "两条具体的错：① 涨回 4 时**不一定有**搬家色四角亮起（关 1 / 关 4 上一组都不亮，封存版要求恰好 1 组）；"
    "② 记号熄灭之后露出的是**地板**，不是虚空（关 5 实测 (('mark',15), ('floor',)) ×4）。",
    "扫描序按引擎改成 dx 外层（见 derive/landing.py）——全盘 3888 个位置里只有 **4** 个分得开，关 4 上不起作用。",
    "关 6 的小身：在**开局附近那一带**（缩掉之后随机走 0–10 步）60/60 一次都涨不回去。"
    "**这是样本结论，不是盘面事实** —— 一次实跑在关 6 另一个房间 (31,43) 处涨成功了。"
    "先前我把它写成「关 6 的一条硬限制」，那是把样本当成了全盘，已更正。",
]
EVIDENCE = ["bcf6976ebd8e9446", "1848d086ef1e56e4", "8c61a1545eff2a92", "e59dd405d0d5dedc",
            "9155d61d63a4ef4d", "74f526b322436d7f", "47525092bde0b654", "eda8404aad485ee5",
            "0c33491dcfb52651", "018e8dd7d0448d39", "ee9e9b19882342ae", "53d8df4b82f21b25",
            "2bd4ea89a01958ec"]


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if machine(completes(w, action)) != "resize":
        return "没凑齐翻尺寸色"
    if w.me.side == 2 and grow_landing(w) is None:
        return "九个候选都涨不上去"
    return None


def _me_ok(w, nw):
    me = w.me
    if me.side == 4:
        want = Marker(me.row, me.col, 2, me.face)
    else:
        r, c = grow_landing(w)
        want = Marker(r, c, 4, me.face)
    return nw.me == want


def _rings_ok(w, nw):
    """**更正 E2 之后的版本**：只断言「哪几格**可以**动」，不再断言「必须亮起哪一组」。

    撤掉的两句（封存版有、定向扫 180/180 全错）：
      · 「涨回 4 时搬家色**恰好一组**跨度 6 的四角亮起」—— 关 1 / 关 4 上**一组都不亮**；
      · 「亮着的四角全变**虚空**」—— 关 5 实测变成的是**地板**。
    """
    hidden = w.me.cells() | nw.me.cells()
    off = set()                                        # 此刻亮着的那些跨度 6 四角
    for l in w.legends:
        for (r, c) in span6(w, l.color):
            off |= corners(r, c, 6)
    off -= hidden
    changed = {p: (a, b) for p, a, b in ground_diff(w, nw, skip=eaten(w, nw))}
    for p, (_, b) in changed.items():
        if p in off and b not in (("void",), ("floor",)):
            return False                               # 熄灭之后露出地板或虚空，两种都见过
    rest = {p: ab for p, ab in changed.items() if p not in off}
    if w.me.side == 4:                                 # 缩：翻尺寸色的实心 2×2 外亮一圈
        on = set()
        for p in solid2(w, RESIZE):
            on |= halo_of(p)
        on -= hidden
        return set(rest) == on and all(b == ("mark", RESIZE) for _, b in rest.values())
    # 涨：别处只允许亮起搬家色的记号（**可以一组都不亮** —— 关 1 / 关 4 就是如此）
    return all(b == ("mark", TELEPORT) for _, b in rest.values())

def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    return "TRUE" if _me_ok(w, nw) and _rings_ok(w, nw) else "FALSE"
