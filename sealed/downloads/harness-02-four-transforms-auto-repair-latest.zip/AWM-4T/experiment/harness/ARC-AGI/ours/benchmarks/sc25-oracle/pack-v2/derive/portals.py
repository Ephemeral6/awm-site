"""搬家的落点：某个记号色圈出的、**和我同边长**的那些框。

    candidates(w, color)   和我同边长的合法框（**按行列排好序**）
    same(w, color)         旧名：封存版在这里还要求「和我行列奇偶都相同」——**那一位是错的**
    gated(w, color)        其中戴着外圈的那些（外圈是**指路牌**，不是判据）

## 更正（`CORRECTIONS.md` H）

封存版 `rule/machines/teleport.py` 要求「和我**同奇偶**而且**戴着外圈**的恰好一个」。
引擎 `sc25.py:2600-2625` 根本不看这两样：

```python
def vvsxyfdgok(self):                                 # 传送
    if scale == 1: portals, cur = self.dkwqdbhqspz, self.ibmhvvyrikn   # 小身一组
    else:          portals, cur = self.cmagnysjqzl, self.ydpaogvspcp   # 大身另一组
    if not portals: return                            # 表为空 ⇒ 什么都不发生
    target = portals[cur]                             # 取**游标**指的那一个
    cur = (cur + 1) % len(portals)                    # 游标 **+1 轮转**
```

真语义：

```
按**尺寸**选一组目标（小身一组、大身另一组）
取**游标**指的那一个，整块搬进去；搬完游标 +1 轮转
**没有奇偶条件**；「戴外圈的那一个」只是渲染出来的指路牌，不是判据
目标表为空 ⇒ 什么都不发生
```

两次独立的实测各自撞到这一条：
「teleport **ignores the same-parity condition**, because it moved me from row 14 to row 17」、
「A teleport moved my size-4 player from (row 12, column 41) to (row 33, column 13)」。

**游标帧上读不出**（它是引擎里的一个计数）。所以模型只断言得了「落点是**某一个**同尺寸的框」
和「表为空就什么都不发生」，**挑哪一个**留给 NOT_CLAIMED —— 见 rule/machines/teleport.py。
"""
from __future__ import annotations

from .boxes import boxes, outer_ring_lit


def candidates(w, color):
    """和我同边长的合法框，按 (行, 列) 排好序。**不筛奇偶、不筛外圈。**"""
    return sorted(boxes(w, color, w.me.side))


def same(w, color):
    """旧名。**语义已改**：不再要求同奇偶（更正 H）。"""
    return candidates(w, color)


def gated(w, color):
    """戴着外圈的那些。**这是指路牌，不是判据** —— 留着只为还能把它画出来。"""
    return [b for b in candidates(w, color) if outer_ring_lit(w, b, color, w.me.side)]
