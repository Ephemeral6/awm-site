"""帧 → 世界。**全局唯一碰像素的地方。**

上面每一层（derive / rule / 导出器）只认 `World` 的字段，读不到帧。

## 版面怎么切

    右边缘两列              竖条
    色 FRAME 的空心矩形框    面板：最大的那块是大面板（3×3 格位），其余每块是一张小面板
    其余（框外、竖条之外）  场地

## 良构检查：同一个量的两种读法必须对得上

  · 竖条：两列逐行相同；「满」的那一段必须是**底部一整段**（从顶上开始消耗）。
  · 大面板：框里恰好九块、排成 3×3，每块整块同色、而且是三态之一。
  · 小面板：框里的记号都是整块的方块，落在 3×3 的格位上，一块面板只有一个记号色。
  · 我：场地上**恰好一个**合格的「半脸半背」正方形（边长 2 或 4）。

对不上就抛 `ParseError`——这一帧读不成世界，整条规则链当场没有输入。

## 读不出来要抛，别返回 None

**这里只管抛，不管归类。** 「这一帧本来就不是一个局面」（整局赢了那一帧：我沉进了插座）
和「是局面但我读不出」在像素上分不开；分得开的是 meta（state == WIN）。
归类由拿得到 meta 的那一层（run_rules.py）做，两档分开报。

## 色号

这一局的色号在六关里意思不变（整批 802 帧上核过：每一帧都读得成，见 analysis/parse.txt），
所以这里按色号认、**只在这一个文件里按色号认**。几处同色异义写在明处：

    FACE (9)   是我的脸，也是插座的边     —— 我靠「恰好半个正方形」认，插座边归 Blocks
    BACK (10)  是我的背，也是插座的内胆   —— 同上，我之外的归 Socket
    FULL (14)  是竖条的满、面板的点亮、地上的燃料 —— 按所在的版面分
"""
from __future__ import annotations

from collections import Counter

from .ground.ground import FLOOR as T_FLOOR, FUEL as T_FUEL, SOCKET as T_SOCKET, Ground
from .panel.bar import Bar
from .panel.legend import Legend
from .panel.pad import Pad
from .player.marker import Marker
from .world import World

FLOOR = 2
VOID = 5
FRAME = 3
FACE = 9
BACK = 10
FULL = 14
EMPTY_BAR = 0
PAD_OFF = 0
BAR_COLS = (62, 63)
H = W = 64


class ParseError(Exception):
    """这一帧读不成一个世界。**这是一条可判错的话**，不是一次异常处理。

    这里只管抛，不管归类：(a) 不是局面 / (b) 是局面却读不出，由 run_rules.py 按 meta 分。
    """


_MEMO: dict = {}
_BY_ID: dict = {}


def parse(frame) -> World:
    """一帧像素 → 一个 World。读不出来抛 `ParseError`。结果按帧内容记住（只为省时间）。"""
    hit = _BY_ID.get(id(frame))
    if hit is not None and hit[0] is frame:
        if isinstance(hit[1], ParseError):
            raise hit[1]
        return hit[1]
    try:
        w = _parse_keyed(frame)
    except ParseError as e:
        _BY_ID[id(frame)] = (frame, e)
        raise
    _BY_ID[id(frame)] = (frame, w)
    return w


def _parse_keyed(frame) -> World:
    key = tuple(tuple(r) for r in frame)
    hit = _MEMO.get(key)
    if hit is not None:
        if isinstance(hit, ParseError):
            raise hit
        return hit
    try:
        w = _parse(key)
    except ParseError as e:
        _MEMO[key] = e
        raise
    _MEMO[key] = w
    return w


# ---------------------------------------------------------------- 小工具（只在这里用）

def _components(cells):
    """四连通分量。"""
    left = set(cells)
    out = []
    while left:
        s = left.pop()
        comp, stack = [s], [s]
        while stack:
            r, c = stack.pop()
            for q in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if q in left:
                    left.remove(q)
                    comp.append(q)
                    stack.append(q)
        out.append(comp)
    return out


def _bbox(cells):
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    return min(rs), min(cs), max(rs), max(cs)


# ---------------------------------------------------------------- 竖条

def _bar(g) -> Bar:
    full = []
    for r in range(H):
        a, b = g[r][BAR_COLS[0]], g[r][BAR_COLS[1]]
        if a != b:
            raise ParseError(f"竖条第 {r} 行两列不同色（{a}/{b}）")
        if a not in (FULL, EMPTY_BAR):
            raise ParseError(f"竖条第 {r} 行是色 {a}，既不是满也不是空")
        full.append(a == FULL)
    n = sum(full)
    if any(full[: H - n]) or not all(full[H - n:]):
        raise ParseError("竖条的「满」不是底部一整段")
    return Bar(n)


# ---------------------------------------------------------------- 面板

def _frames(g):
    """色 FRAME 的连通块 → bbox，按格数从大到小。"""
    cells = [(r, c) for r in range(H) for c in range(W - 2) if g[r][c] == FRAME]
    out = []
    for comp in _components(cells):
        out.append((len(comp), _bbox(comp)))
    out.sort(key=lambda x: -x[0])
    return [b for _, b in out]


def _blocks_in(g, box):
    """框里非框色的连通块：[(bbox, 色集合, 格数)]。"""
    t, l, b, r = box
    inner = [(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1) if g[rr][cc] != FRAME]
    out = []
    for comp in _components(inner):
        out.append((_bbox(comp), {g[rr][cc] for rr, cc in comp}, len(comp)))
    return out


def _pad(g, box) -> Pad:
    blocks = _blocks_in(g, box)
    if len(blocks) != 9:
        raise ParseError(f"大面板里有 {len(blocks)} 块，不是 9")
    blocks.sort(key=lambda x: (x[0][0], x[0][1]))
    rows = sorted({bb[0] for bb, _, _ in blocks})
    cols = sorted({bb[1] for bb, _, _ in blocks})
    if len(rows) != 3 or len(cols) != 3:
        raise ParseError("大面板的九块没排成 3×3")
    cells, rects = [], []
    for bb, colors, n in blocks:
        t, l, b, r = bb
        if len(colors) != 1 or (b - t + 1) * (r - l + 1) != n or (b - t) != (r - l):
            raise ParseError(f"大面板 {bb} 那一块不是整块同色的正方形")
        c = next(iter(colors))
        state = "lit" if c == FULL else "blank" if c == FLOOR else "off" if c == PAD_OFF else None
        if state is None:
            raise ParseError(f"大面板 {bb} 是色 {c}，不是三态之一")
        cells.append(state)
        rects.append(bb)
    return Pad(tuple(cells), tuple(rects))


def _legend(g, box):
    t, l, b, r = box
    inner = [(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1) if g[rr][cc] != FRAME]
    if not inner:
        raise ParseError(f"小面板 {box} 是空的")
    bg = Counter(g[rr][cc] for rr, cc in inner).most_common(1)[0][0]
    marks = [(rr, cc) for rr, cc in inner if g[rr][cc] != bg]
    colors = {g[rr][cc] for rr, cc in marks}
    if len(colors) != 1:
        raise ParseError(f"小面板 {box} 的记号不是恰好一色：{sorted(colors)}")
    pattern = set()
    for comp in _components(marks):
        tt, ll, bb, rr = _bbox(comp)
        if (bb - tt + 1) * (rr - ll + 1) != len(comp) or (bb - tt) != (rr - ll):
            raise ParseError(f"小面板 {box} 里有一块记号不是整块方块")
        cell = (int((tt - t) * 3 / (b - t + 1)), int((ll - l) * 3 / (r - l + 1)))
        if cell in pattern:
            raise ParseError(f"小面板 {box} 两块记号落在同一格位 {cell}")
        pattern.add(cell)
    return Legend(next(iter(colors)), frozenset(pattern))


# ---------------------------------------------------------------- 我

def _halves(g, r, c, k):
    """这个 k×k 窗口若是「半脸半背」，返回朝向；否则 None。"""
    h = k // 2
    face = set()
    for dr in range(k):
        for dc in range(k):
            v = g[r + dr][c + dc]
            if v == FACE:
                face.add((dr, dc))
            elif v != BACK:
                return None
    for tag, want in (("U", {(a, b) for a in range(h) for b in range(k)}),
                      ("D", {(a, b) for a in range(h, k) for b in range(k)}),
                      ("L", {(a, b) for a in range(k) for b in range(h)}),
                      ("R", {(a, b) for a in range(k) for b in range(h, k)})):
        if face == want:
            return tag
    return None


def _continues(g, r, c, k, face) -> bool:
    """这个窗口的「背」那一半，越过远端那条边之后还是背色吗？

    插座的内胆也是背色、插座的边也是脸色——在插座边上开一个小窗口，
    会读出一个「半脸半背」的假我。真我的背后不会接着一片背色（接着的是地面），
    假我的背后是插座内胆的其余部分。**这是结构判据，不是位置判据。**
    """
    if face == "U":
        cells = [(r + k, c + j) for j in range(k)]
    elif face == "D":
        cells = [(r - 1, c + j) for j in range(k)]
    elif face == "L":
        cells = [(r + i, c + k) for i in range(k)]
    else:
        cells = [(r + i, c - 1) for i in range(k)]
    return any(0 <= a < H and 0 <= b < W and g[a][b] == BACK for a, b in cells)


def _marker(g, arena) -> Marker:
    hits = []
    seeds = sorted((r, c) for r, c in arena if g[r][c] in (FACE, BACK))
    for k in (4, 2):
        for r, c in seeds:
            if r + k > H or c + k > W - 2:
                continue
            if (r + k - 1, c + k - 1) not in arena:
                continue
            f = _halves(g, r, c, k)
            if f is None or _continues(g, r, c, k, f):
                continue
            hits.append(Marker(r, c, k, f))
    # 边长 4 的我里面套着好几个边长 2 的「半脸半背」窗口吗？不会：它们的背后接着背色，已被上一步排掉。
    if len(hits) != 1:
        raise ParseError(f"场地上合格的「我」有 {len(hits)} 个：{hits[:4]}")
    return hits[0]


# ---------------------------------------------------------------- 总装

def _parse(g) -> World:
    if len(g) != H or any(len(row) != W for row in g):
        raise ParseError("帧不是 64×64")
    bar = _bar(g)
    boxes = _frames(g)
    if not boxes:
        raise ParseError("找不到面板框")
    pad = _pad(g, boxes[0])
    legends = frozenset(_legend(g, b) for b in boxes[1:])
    if len({l.color for l in legends}) != len(legends):
        raise ParseError("两块小面板用了同一个记号色")

    def in_panel(r, c):
        return any(t <= r <= b and l <= c <= rr for t, l, b, rr in boxes)

    arena = {(r, c) for r in range(H) for c in range(W - 2) if not in_panel(r, c)}
    me = _marker(g, arena)
    mine = me.cells()
    mark_colors = {l.color for l in legends}
    tiles = set()
    for (r, c) in arena:
        if (r, c) in mine:
            continue
        v = g[r][c]
        if v == VOID:
            continue
        if v == FLOOR:
            t = T_FLOOR
        elif v in mark_colors:
            t = ("mark", v)
        elif v == FULL:
            t = T_FUEL
        elif v == BACK:
            t = T_SOCKET
        else:
            t = ("block", v)
        tiles.add(((r, c), t))
    return World(me=me, pad=pad, legends=legends, bar=bar, ground=Ground(frozenset(tiles)))


def parse_action(action: str):
    """动作串 → ("dir", "U"/"D"/"L"/"R") / ("click", x, y) / ("reset",) / ("other", 原串)。

    这不是像素，是上游给的动作名；放在这里是因为「动作怎么读」和「帧怎么读」同属读观测。
    """
    a = action or ""
    if a in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return ("dir", {"ACTION1": "U", "ACTION2": "D", "ACTION3": "L", "ACTION4": "R"}[a])
    if a.startswith("ACTION6:"):
        try:
            x, y = (int(v) for v in a.split(":", 1)[1].split(","))
            return ("click", x, y)
        except ValueError:
            return ("other", a)
    if a == "RESET":
        return ("reset",)
    return ("other", a)
