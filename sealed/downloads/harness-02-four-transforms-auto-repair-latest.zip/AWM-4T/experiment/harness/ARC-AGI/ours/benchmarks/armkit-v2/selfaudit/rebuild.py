# -*- coding: utf-8 -*-
"""Independent rebuild of a subject's Lean proof from source (self-audit readout, 2026-10-21).

    python -I rebuild.py <arena> <main file relative to arena> <out dir> <theorem> [<theorem> ...]

- copies only the *.lean files of the main file's directory (no subject .olean / .lake) to a fresh <out dir>;
- builds the local import closure of the main file in dependency order, one lean process at a time, with the
  toolchain pinned in METHOD.md (v4.34.1), recording wall time and peak working set per file;
- static scan of every built file: `sorry`, `native_decide`, `axiom` declarations, `set_option debug.skipKernelTC`;
- compiles <main>_check.lean = the main file + `#check @T` / `#print axioms T` for each named theorem;
- writes <out dir>/rebuild.json.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

LEAN = os.path.join(os.path.expanduser("~"), ".elan", "toolchains", "leanprover--lean4---v4.34.1", "bin", "lean.exe")
DIRTY = re.compile(r"\bsorry\b|\bnative_decide\b|^\s*axiom\s|skipKernelTC", re.M)
OK_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}


def peak_ws(pid, box, stop):
    import ctypes
    from ctypes import wintypes

    class PMC(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
    h = ctypes.windll.kernel32.OpenProcess(0x0410, False, pid)
    while not stop[0]:
        c = PMC()
        c.cb = ctypes.sizeof(c)
        if h and ctypes.windll.psapi.GetProcessMemoryInfo(h, ctypes.byref(c), c.cb):
            box[0] = max(box[0], c.PeakWorkingSetSize)
        time.sleep(0.5)


def build(d, f, out_olean=True, timeout=3600):
    cmd = [LEAN] + (["-o", f.with_suffix(".olean").name] if out_olean else []) + [f.name]
    env = dict(os.environ, LEAN_PATH=str(d))
    t0 = time.time()
    p = subprocess.Popen(cmd, cwd=str(d), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding="utf-8", errors="replace")
    box, stop = [0], [False]
    th = threading.Thread(target=peak_ws, args=(p.pid, box, stop), daemon=True)
    th.start()
    try:
        out, _ = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        out = "TIMEOUT"
    stop[0] = True
    return {"file": f.name, "rc": p.returncode, "wall_s": round(time.time() - t0, 1),
            "peak_gb": round(box[0] / 2 ** 30, 2), "out": out[-3000:]}


def main(arena, main_rel, outdir, theorems, check_only=False):
    arena, outdir = Path(arena), Path(outdir)
    src_dir = (arena / main_rel).parent
    if not check_only:
        if outdir.exists():
            shutil.rmtree(outdir)
        outdir.mkdir(parents=True)
        for f in src_dir.glob("*.lean"):
            if not f.name.endswith("_check.lean"):
                shutil.copy2(f, outdir / f.name)
    local = {f.stem for f in outdir.glob("*.lean")}

    def imports(name):
        txt = (outdir / (name + ".lean")).read_text(encoding="utf-8")
        return [m for m in re.findall(r"^import\s+(\S+)", txt, re.M) if m in local]

    order, seen = [], set()

    def visit(n):
        if n in seen:
            return
        seen.add(n)
        for m in imports(n):
            visit(m)
        order.append(n)
    main_name = Path(main_rel).stem
    visit(main_name)
    res = {"arena": str(arena), "main": main_rel, "order": order, "files": [], "static": {}}
    for n in order:
        txt = (outdir / (n + ".lean")).read_text(encoding="utf-8")
        res["static"][n] = sorted(set(m.group(0).strip() for m in DIRTY.finditer(txt)))
        if check_only:          # reuse the .olean built from source by the earlier full run of this script
            prev = json.loads((outdir / "rebuild_build.json").read_text(encoding="utf-8"))
            r = next(x for x in prev["files"] if x["file"] == n + ".lean")
            res["files"].append(r)
            continue
        r = build(outdir, outdir / (n + ".lean"))
        res["files"].append(r)
        print("%-24s rc=%s %7.1fs peak %.2f GB" % (n, r["rc"], r["wall_s"], r["peak_gb"]), flush=True)
        if r["rc"] != 0:
            print(r["out"][-1500:])
            break
    if all(r["rc"] == 0 for r in res["files"]) and len(res["files"]) == len(order):
        chk = outdir / (main_name + "_check.lean")
        body = (outdir / (main_name + ".lean")).read_text(encoding="utf-8")
        chk.write_text(body + "\n\n-- appended by rebuild.py\n" +
                       "".join("#check @%s\n#print axioms %s\n" % (t, t) for t in theorems), encoding="utf-8")
        r = build(outdir, chk, out_olean=False)
        res["check"] = r
        ax = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", r["out"])
        nodeps = re.findall(r"'([^']+)' does not depend on any axioms", r["out"])
        res["axioms"] = {k: [x.strip() for x in v.split(",") if x.strip()] for k, v in ax}
        res["axioms"].update({k: [] for k in nodeps})
        res["axioms_clean"] = all(set(v) <= OK_AXIOMS for v in res["axioms"].values())
        print(r["out"][-4000:])
    if not check_only:
        (outdir / "rebuild_build.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    res["static_clean"] = not any(res["static"].values())
    res["all_built"] = len(res["files"]) == len(order) and all(r["rc"] == 0 for r in res["files"])
    (outdir / "rebuild.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print("all_built=%s static_clean=%s axioms_clean=%s" % (res["all_built"], res["static_clean"],
                                                           res.get("axioms_clean")))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    a = [x for x in sys.argv[1:] if x != "--check-only"]
    main(a[0], a[1], a[2], a[3:], check_only="--check-only" in sys.argv)
