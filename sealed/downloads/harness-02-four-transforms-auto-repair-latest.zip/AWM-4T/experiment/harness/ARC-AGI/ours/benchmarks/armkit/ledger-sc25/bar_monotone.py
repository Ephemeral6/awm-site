"""同一关之内，右边缘竖条的满块数只减不增——除非这一步标记块压到了场地上的色 14 块。"""
LEVEL = "L4"
SCOPE = "只看不换关、且不是重开本关（action != \"RESET\"）的转移；" \
        "没有 ctx（ctx.level_prev != ctx.level_next 时也）、或竖条读不出（帧不足 64 行）返回 NA；" \
        "**这一步结束时标记块压住了 prev 帧场地上的色 14 格返回 NA**（那一支归 fuel_absorbs）"
NOTE = "v1 说的是「所有转移」，被第 23 步的过关帧打掉：过关那一下竖条从 20 块跳回 32 块（另立 level_up_refills_bar）。" \
       "v2 还带着「一步最多减一个」，被第 27 步打掉：点满面板把我传送出去的那一下，一口气扣了 3 块。" \
       "「一步最多一块」不是错的，只是不该由这条管——挪到 bar_cost_one，那里把收尾点击排除在外。" \
       "那 3 块和传送距离对得上（跳了 12 行、边长 4，正好是 3 步），但只有一次观测，没写成概念。" \
       "v4：第一次 RESET 打掉它——重开本关不换关号，竖条却补满了。「同一关之内」原来漏了一种走法：" \
       "关号不变，关却重开了。RESET 干了什么另立 reset_restores_level。" \
       "v5：第 171 步打掉它，而这一次不是口径问题，是**场上有我一直没看见的东西**。" \
       "那一步涨大的新落点压到了 (40,12)-(41,13) 的一坨 2x2 色 14，它整块消失，竖条从 23 块涨到 27 块。" \
       "色 14 正是竖条「满」那一段的色号，所以那一坨就是地上的一罐燃料——它从第 4 关开局就躺在那里，" \
       "整整 70 步我没认出来，因为我一直把色 14 当成「竖条和面板点亮」的专属色，" \
       "而场地上只有这一处，histogram 里它被 100 多格竖条淹着。教训：**一个色号在两个地方出现，不等于它在两个地方是同一个东西**；" \
       "反过来也一样，我把「这个色我已经认识了」当成了「这个色在哪都不用再看」。" \
       "本关已经没有第二罐了，所以这条豁免在第 4 关之后才会再开口。"
EVIDENCE = ["da3e01cff498c8a1", "6897595a49047211", "9dabb54dca80d95d", "2657799cd7a750eb",
            "56b830dc960999ad", "9155d61d63a4ef4d"]

from _lib import bar_blocks, covered, fuel_cells


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action == "RESET":
        return "NA"
    if fuel_cells(prev) & covered(nxt):
        return "NA"
    return "TRUE" if bar_blocks(prev) >= bar_blocks(nxt) else "FALSE"
