"""过关：这一步是方向键、而且我前方那个方区**碰到了**插座内胆。整块都是内胆只是其中一种情形。"""
from __future__ import annotations

from derive.geometry import ahead, square
from derive.standing import all_socket
from objects import parse_action, read

CLAIM = ("过关（上游的关号 +1，**或者**最后一关那次上游置 WIN）⇒ 这一步是方向键，"
         "而且我前方一个自身边长的方区**和插座内胆有交集**；"
         "反过来，方向键且那个方区**整块**落在内胆上 ⇒ 过关。")
SCOPE = "所有转移；上游没给关号、或者这一步之前那一帧读不成世界（整局赢了之后那一帧），不管。"
NOT_CLAIMED = [
    "**不说精确的过关判据**。引擎 sc25.py:3145-3161 的真条件是「这一下 try_move 撞到了出口精灵」"
    "（撞到之后还会把我往出口中心推半步）。「方区 ∩ 内胆 ≠ ∅」只是它的一个近似："
    "那条 132 步动作串上 77/78、随机走 350/350，**唯一的例外是交集 8 格却没过关** —— "
    "说明真条件是「撞到」而不是「有交集」。所以这里只写**必要**方向，不写当且仅当。",
    "不说过关之后新关长什么样（那是另一张盘）",
    "不说 RESET 之外的整局重开",
]
NOTE = [
    "起点：册子 socket_ends_level v2。",
    "**更正（CORRECTIONS.md G）**：封存版写「当且仅当前方方区**整块**落在内胆上」。那是**窄的**。"
    "同一条动作串上的三处反例：关 1 方区 4 格里内胆只占 **2** 格（另 2 格 floor）—— 过关了；"
    "关 2 方区 16 格里内胆只占 **4** 格（另 12 格 void）—— 过关了；"
    "关 3 方区 16 格里内胆只占 **12** 格（另 4 格 block）—— 过关了。",
    "**更正 G.1**：打完**最后一关**引擎**不把关号 +1**，而是把 state 置成 WIN。"
    "封存版拿「关号 +1」当现实那一侧的信号，所以在最后一关上信号为假而其实赢了"
    "（那条动作串第 132 步就是这一处）。这里把 WIN 也算成过关信号。",
    "判「过了几关」要读上游的 levels_completed，**不要**拿关号自己减。",
    "关号是上游给的事实，这里只拿它当现实那一侧的信号；世界里不存关号。",
]
EVIDENCE = ["9dabb54dca80d95d"]


def _leveled(ctx) -> bool:
    """过关信号：关号 +1，**或者**最后一关那次上游把 state 置成 WIN（更正 G.1）。"""
    if ctx.get("level_next") != ctx.get("level_prev"):
        return True
    return ctx.get("state_next") == "WIN" and ctx.get("state_prev") != "WIN"


def scope_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "ctx 缺关号"
    if action == "RESET":
        return "RESET → reset_restores"
    if read(prev) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w = read(prev)
    a = parse_action(action)
    touches = whole = False
    if a[0] == "dir":
        r, c = ahead(w.me.row, w.me.col, w.me.side, a[1])
        sq = square(r, c, w.me.side)
        touches = bool(sq & w.ground.socket)
        whole = all_socket(w, sq)
    leveled = _leveled(ctx)
    if leveled and not touches:
        return "FALSE"          # 过关了却没碰到内胆
    if whole and not leveled:
        return "FALSE"          # 整块踏进内胆却没过关
    return "TRUE"
