"""玩具 World：三个字段，各演一种读数。"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class World:
    n_one: int          # 第 1 行往下，值为 1 的格子有几个（两条规则都读）
    top: tuple          # 第 0 行（只有 header_rotates 读）
    width: int          # 每行几格（整批语料恒定，没有规则读）
