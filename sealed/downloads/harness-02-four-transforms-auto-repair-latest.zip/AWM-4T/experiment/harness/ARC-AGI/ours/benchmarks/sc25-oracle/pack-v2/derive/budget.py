"""预算：那个帧上读不出的**计数器**，以及这一关的**上限**。

    blocks_used(w)        竖条已经消耗的块数（看得见的那一位）
    delta(w, action, nw)  这一个动作让计数器加多少（吃燃料是退费，见下）
    counter(hist)         从本关开局算到现在的计数器值
    cap_bounds(hist)      这一关的上限 L 被压进哪个区间 [lo, hi]

## 为什么封存件里没有这一块

`rule/out_of_model/bar_rate.py` 的 `WHY_OUT` 写得很清楚：竖条按**整块**量化，
一次动作的开销小于一块，所以「这一步扣了多少」帧上读不出 —— 那是**历史**，
而封存模型只存帧上读得出的东西。

## 为什么现在必须有

计数器就是这一局的**预算**。一个把预算整块留在模型外的世界模型，
凡是和「这一关在预算内能不能做到某件事」有关的推理，都要用到它。

## 怎么并进来而不破坏「只存看得见的东西」

计数器不是引擎的内部秘密，它是**可观测历史的函数**：从本关开局起，
每一个动作加多少由「这个动作是什么 + 这两帧之间发生了什么」完全决定。
所以模型不存它，而是**从历史算它**。上限 L 同理：每一步的
(计数器, 已消耗块数) 把 L 夹进一个区间，一路取交集。

## 精确口径（`CORRECTIONS.md` A，实测）

```
方向键                                   +1
点中大面板一格                            +1
  这一下之后亮格集合 == 某个**本关可用**法术的图案   再 +1（那一下总 +2），施法、清盘
  同样的集合但那个法术本关不可用                    不施法，只 +1
点在大面板之外                            +0（竖条不走 —— 见 rule/pad/dead_click.py）
玩家外接框（**未缩放** 2×2）压住一枚燃料    **先照常加费**，再 计数 = max(0, 计数 − 10)，那枚燃料消失
本会话第一个非 RESET 动作（只在第 1 关）    +0，而且不生效
计数 **>** 上限 ⇒ 判负
```

依据：施法 +2、不可用图案只 +1 —— 逐关 × 逐图案定向实验 **18/18 一致，无例外**；
退费 10 且截到 0 —— 引擎 `sc25.py:2066` `cribhxjrvp = 10`、`:3137` `max(0, c - 10)`；
燃料按**未缩放** 2×2 判 —— 引擎 `:3134` 的 `len(pixels[0])` 不乘 scale；
「精灵消失」不等于退费 —— **抹除机也会删燃料、但不退费**。

## 竖条怎么显示

```
已消耗块数 = ⌊32 × 计数 / 上限⌋          （竖条 32 块，一块两行）
```

这个式子是从帧上**拟合得出来的**：读几帧「满行数」配上算出来的计数，就能把 L 夹死。
所以这一位虽然要靠历史算，**够得着**——不必知道关卡数据就能把它定下来。
"""
from __future__ import annotations

from .fuel import eaten
from .pad_hits import clicked, completes
from objects import parse_action, read

REFUND = 10          # 引擎 sc25.py:2066 cribhxjrvp
BLOCKS = 32          # 竖条总块数（一块两行）


def blocks_used(w) -> int:
    """竖条已经消耗的块数。**这是帧上直接看得见的那一位。**"""
    return BLOCKS - w.bar.rows // 2


def delta(w, action, nw, first_of_session: bool = False):
    """这一个动作让计数器怎么变：返回 (加多少, 退不退费)。

    `first_of_session` 为真时（只在第 1 关）返回 (0, False) —— 那一下不计费也不生效。

    **加费和退费是两件事，同一步可以都发生。**（第一版写成「吃燃料就不加费」，
    真引擎上驳掉了：关 6 实测 c=26 的下一步吃燃料、竖条落到 9 块，
    只有 26 **+1** −10 = 17 配 L=60 才对得上 ⌊32·17/60⌋ = 9；按 26−10 = 16 算出来是 8。）
    """
    if action == "RESET":
        return (0, False)
    if first_of_session:
        return (0, False)
    refund = bool(eaten(w, nw))
    a = parse_action(action)
    if a[0] == "dir":
        return (1, refund)
    if a[0] == "click":
        if clicked(w, action) is None:
            return (0, refund)                # 点在大面板外：竖条不走
        return (2 if completes(w, action) is not None else 1, refund)
    return (0, refund)


def counter(hist, level_is_first: bool = False) -> int:
    """本关开局到现在的计数器值。`hist` = [(前帧, 动作, 后帧), ...]。"""
    c = 0
    for i, (prev, action, nxt) in enumerate(hist):
        w, nw = read(prev), read(nxt)
        if w is None or nw is None:
            continue
        add, refund = delta(w, action, nw, first_of_session=(level_is_first and i == 0))
        c += add
        if refund:
            c = max(0, c - REFUND)            # 先加费，再退费（引擎 :3137）
    return c


def counters(hist, level_is_first: bool = False):
    """逐步的计数器值（和 `hist` 等长）。"""
    out, c = [], 0
    for i, (prev, action, nxt) in enumerate(hist):
        w, nw = read(prev), read(nxt)
        if w is None or nw is None:
            out.append(c)
            continue
        add, refund = delta(w, action, nw, first_of_session=(level_is_first and i == 0))
        c += add
        if refund:
            c = max(0, c - REFUND)            # 先加费，再退费（引擎 :3137）
        out.append(c)
    return out


def cap_bounds(hist, level_is_first: bool = False):
    """这一关的上限 L 被这段历史夹进的区间 [lo, hi]（闭区间）；夹不住返回 None。

    每一步给出一对 (c, b)，b = ⌊32c/L⌋：
        b > 0  ⇒  32c/(b+1) < L ≤ 32c/b
        b = 0  ⇒  L > 32c
    一路取交集。**区间空 ⇒ 这段历史和「计数器口径 + 竖条公式」自相矛盾。**
    """
    lo, hi = 1, 10 ** 9
    cs = counters(hist, level_is_first)
    for (prev, _a, nxt), c in zip(hist, cs):
        nw = read(nxt)
        if nw is None:
            continue
        b = blocks_used(nw)
        if b < 0 or b > BLOCKS:
            return None
        if c == 0:
            continue                       # 计数 0 时 b 必为 0，对 L 没有约束
        if b == 0:
            lo = max(lo, BLOCKS * c + 1)
        else:
            lo = max(lo, BLOCKS * c // (b + 1) + 1)
            hi = min(hi, BLOCKS * c // b)
        if lo > hi:
            return None
    return (lo, hi)
