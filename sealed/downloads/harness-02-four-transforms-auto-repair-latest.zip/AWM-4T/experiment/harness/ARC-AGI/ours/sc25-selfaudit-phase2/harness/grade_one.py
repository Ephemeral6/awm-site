# -*- coding: utf-8 -*-
"""Collect everything needed to grade ONE phase-2 run against PREREG-l4s-selfaudit.md.

    python -I grade_one.py --case l4s-case-672e2a [--readout <run_v2 json>] [--rebuild lean/X.lean Ns.thm1 Ns.thm2 ...]

Writes grade/<case>.json and grade/<case>.md. Mechanical facts only; the judgement calls (is the refill rule found
fully/partly/not, is a residual +1 exactly the winning-move charge) are left to the reader, with the evidence beside
them. Evaluator-side keyword hints (grow / refill / item …) are used here only, never shown to the subject.

Sections
1. verdict per attempt and final (run_v2 readout); the final answer is recovered from the session transcript when
   the CLI's returned text lacks VERDICT (a background-task wake-up can replace it, see selfaudit/report_from_transcript.py)
2. self-audit trail: work/selfaudit/* files; when pass1.md was first written (transcript) and in which attempt
   (server-log resets), and whether the next attempt's first action came after it
3. trigger grid / item rule: lines of pass*.md about the item rule and about grow-produced contact (evaluator hints)
4. game use from the server log: resets, attempts, actions and game overs per level
5. optional independent rebuild of the main theorem file (selfaudit/rebuild.py), axioms
"""
import argparse
import datetime
import glob
import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
P2 = HERE.parent
V2 = Path(str(Path(__file__).resolve().parents[2] / "benchmarks")) / "armkit-v2"      # (folder moved to ours/sc25-selfaudit-phase2 on 2026-10-21)
SA = V2 / "selfaudit"
ARMKIT = V2.parent / "armkit"
PROJECTS = Path.home() / ".claude" / "projects"
HINT_ITEM = re.compile(r"refill|refund|item|fuel|燃料|退费|e-marker|14", re.I)
HINT_GROW = re.compile(r"grow|变大|enlarg|size change|resize", re.I)


def transcript(case):
    fs = sorted(glob.glob(str(PROJECTS / ((__import__("re").sub(r"[:\\/]", "-", __import__("os").environ.get("AWM_STAGE", "D:/arc-arena")) + "-") + case) / "*.jsonl")), key=lambda f: Path(f).stat().st_mtime)
    return Path(fs[-1]) if fs else None


def srv_events(case):
    ev = []
    for f in sorted((ARMKIT / "srvlog" / case).glob("*.jsonl")):
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                ev.append(json.loads(line))
            except ValueError:
                pass
    return ev


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", required=True)
    ap.add_argument("--readout")
    ap.add_argument("--rebuild", nargs="*")
    a = ap.parse_args()
    case = a.case
    arena = Path(__import__("os").environ.get("AWM_STAGE", "D:/arc-arena")) / case
    ro = Path(a.readout) if a.readout else next(
        (Path(p) for p in [HERE / "runs" / ("run_v2_%s.json" % case), P2 / ("run_v2_l4s_%s.json" % case)]
         if Path(p).exists()), None)
    g = {"case": case, "graded": datetime.datetime.now().isoformat(timespec="seconds"), "readout": str(ro)}

    # 1. verdicts
    if ro:
        d = json.loads(ro.read_text(encoding="utf-8"))
        r = d[0] if isinstance(d, list) else d
        g["stop"] = r.get("stop")
        g["ask_md5"] = r.get("ask_md5")
        g["verdicts"] = [(x.get("k"), (x.get("verdict") or {}).get("verdict"), (x.get("verdict") or {}).get("confidence"))
                         for x in r.get("rounds", [])]
        g["final_verdict"] = r.get("final_verdict")
        g["final_text"] = ((r.get("final") or {}).get("text") or "")
    tr = transcript(case)
    g["transcript"] = str(tr) if tr else None
    if tr and "VERDICT" not in (g.get("final_text") or ""):
        last = None
        for line in tr.read_text(encoding="utf-8").splitlines():
            j = json.loads(line)
            m = j.get("message") if isinstance(j.get("message"), dict) else {}
            if j.get("type") == "assistant" and isinstance(m.get("content"), list):
                t = "".join(x.get("text", "") for x in m["content"] if x.get("type") == "text")
                if "VERDICT" in t:
                    last = (j.get("timestamp"), t)
        if last:
            g["final_text_from_transcript"] = {"timestamp": last[0], "text": last[1]}

    # 2. self-audit trail
    sa_dir = arena / "work" / "selfaudit"
    g["selfaudit_files"] = sorted(p.name for p in sa_dir.glob("*")) if sa_dir.exists() else []
    first_pass1 = None
    if tr:
        for line in tr.read_text(encoding="utf-8").splitlines():
            j = json.loads(line)
            m = j.get("message") if isinstance(j.get("message"), dict) else {}
            if j.get("type") == "assistant" and isinstance(m.get("content"), list):
                for x in m["content"]:
                    if x.get("type") == "tool_use" and "pass1.md" in json.dumps(x.get("input")) \
                            and x.get("name") in ("Write", "Edit", "Bash"):
                        first_pass1 = first_pass1 or j.get("timestamp")
    g["pass1_first_written_utc"] = first_pass1
    ev = srv_events(case)
    resets = [e["t"] for e in ev if e.get("ep") == "reset"]
    g["resets_utc"] = [datetime.datetime.utcfromtimestamp(t).isoformat(timespec="seconds") for t in resets]
    if first_pass1:
        t1 = datetime.datetime.fromisoformat(first_pass1.replace("Z", "")).timestamp() - \
            (datetime.datetime.now() - datetime.datetime.utcnow()).total_seconds()
        g["pass1_in_attempt"] = sum(1 for t in resets if t <= t1)          # attempt k = k resets so far
        nxt = [e["t"] for e in ev if e.get("ep") == "action" and e["t"] > t1]
        later_resets = [t for t in resets if t > t1]
        g["pass1_before_next_attempt_first_action"] = (not later_resets) or (not nxt) or nxt[0] >= later_resets[0]

    # 3. item rule / trigger grid hints (evaluator side)
    hits = []
    for p in sorted(sa_dir.glob("pass*.md")) if sa_dir.exists() else []:
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if HINT_ITEM.search(line):
                hits.append({"file": p.name, "line": i, "grow": bool(HINT_GROW.search(line)), "text": line[:240]})
    g["item_rule_lines"] = hits
    g["grow_cell_listed"] = any(h["grow"] for h in hits)

    # 4. game use
    c = {"resets_by_level": {}, "actions_by_level": {}, "game_overs_by_level": {}}
    for e in ev:
        if e.get("ep") == "reset":
            k = str(e.get("level"))
            c["resets_by_level"][k] = c["resets_by_level"].get(k, 0) + 1
        elif e.get("ep") == "action":
            k = str(e.get("level_before"))
            c["actions_by_level"][k] = c["actions_by_level"].get(k, 0) + 1
            if e.get("state") == "GAME_OVER":
                c["game_overs_by_level"][k] = c["game_overs_by_level"].get(k, 0) + 1
    g["game_use"] = c

    # 5. rebuild
    if a.rebuild:
        out = Path((__import__("os").environ.get("AWM_ARCHIVE", "D:/arc-arena-archive") + "/l4s-selfaudit/rebuild")) / case
        r = subprocess.run([sys.executable, "-I", str(SA / "rebuild.py"), str(arena), a.rebuild[0], str(out)]
                           + a.rebuild[1:], capture_output=True, text=True, encoding="utf-8", errors="replace")
        g["rebuild_tail"] = r.stdout[-3000:]
        rj = out / "rebuild.json"
        if rj.exists():
            rb = json.loads(rj.read_text(encoding="utf-8"))
            g["rebuild"] = {k: rb.get(k) for k in ("all_built", "static_clean", "axioms_clean", "axioms", "order")}

    gd = HERE / "grade"
    gd.mkdir(exist_ok=True)
    (gd / ("%s.json" % case)).write_text(json.dumps(g, ensure_ascii=False, indent=1), encoding="utf-8")
    md = ["# %s" % case, "", "- stop: %s" % g.get("stop"), "- verdicts: %s" % g.get("verdicts"),
          "- final verdict: %s" % g.get("final_verdict"),
          "- pass1 first written (UTC): %s, in attempt %s, before the next attempt's first action: %s"
          % (g.get("pass1_first_written_utc"), g.get("pass1_in_attempt"), g.get("pass1_before_next_attempt_first_action")),
          "- self-audit files: %s" % ", ".join(g["selfaudit_files"]),
          "- grow-produced contact listed for the item rule: %s" % g["grow_cell_listed"],
          "- game use: %s" % json.dumps(g["game_use"]),
          "- rebuild: %s" % json.dumps(g.get("rebuild"), ensure_ascii=False), "",
          "## item-rule lines in pass*.md (evaluator hints)"] + \
         ["- %s:%d %s%s" % (h["file"], h["line"], "[grow] " if h["grow"] else "", h["text"]) for h in hits] + \
         ["", "## least cap: read it from the final answer / the Lean relaxed-model theorem; judge by hand"]
    (gd / ("%s.md" % case)).write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md[:12]))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
