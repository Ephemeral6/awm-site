"""记号色是画在地面上的死层：一个动作前后，两张帧里都没被标记块压住的那些格子上，记号色的分布一模一样。"""
LEVEL = "L0"
SCOPE = "同一关之内的转移（ctx.level_prev == ctx.level_next）；换关那一步返回 NA；" \
        "prev 或 nxt 里标记块定位不到返回 NA；两张帧上都没有记号色格子时返回 NA（无话可说）；" \
        "点亮的格位凑齐某块小面板的图案、而且那块小面板圈出的框里扣着标本的那一步返回 NA（那一步记号被整片擦掉）。"
NOTE = "第 28 步逼出来的：标记块从落点方框里走出去，它盖过的记号原样露出来。" \
       "在那之前 move_iff_floor 的 apply 认为标记块底下一律是地板色，那一步扣了 4 格。" \
       "写法上绕开了「记号全集」：全集要靠落点方框反推，而标记块把方框整个盖住时就反推不出来。" \
       "这里只比两张帧共同看得见的那一片——`marks(prev) - 盖住(nxt) == marks(nxt) - 盖住(prev)`——" \
       "不需要知道盖住的底下是什么，所以它在任何画法下都成立，也就抓得住「记号被挪动/被擦掉」这种反例。" \
       "它管不住的那一半（盖住的底下到底是不是记号）留给 _lib.ground_color，那个词认不出落点时返回 None、宁可不说。" \
       "v3：第 35 步被打掉——它抓住的正是自己设计来抓的那种反例（记号被整片擦掉），" \
       "而擦记号的是点满面板认标本那一个事件（见 panel_done_erases_specimen）。所以「死层」缩成" \
       "「除那一下之外的每一步都是死层」，不改说法本身。" \
       "v4：那一下的认法换成 completed_legend——第 3 关的大面板没有色 0 块，该点哪几格只写在小面板上。"
EVIDENCE = ["2657799cd7a750eb", "d181e84f3fb7a473", "ba14e367ea32768c"]

from _lib import arena_marks, completed_legend, covered, marker, specimen


def assert_(prev, action, nxt, ctx=None):
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    color = completed_legend(prev, action)
    if color is not None and specimen(prev, color) is not None:
        return "NA"
    if marker(prev) is None or marker(nxt) is None:
        return "NA"
    a, b = arena_marks(prev), arena_marks(nxt)
    if not a and not b:
        return "NA"
    return "TRUE" if (a - covered(nxt)) == (b - covered(prev)) else "FALSE"
