"""外圈：画在某个 4×4 框外扩一圈上的四个角（跨度 6）。

    span6(w, color)   这个记号色此刻亮着的跨度 6 四角组（左上角）
    solid2(w, color)  这个记号色的实心 2×2（左上角）
    halo_of(p)        围着一块实心 2×2 的那个跨度 6 四角组（外隔一格）

「翻尺寸那一下哪几圈灭、哪几圈亮」是 rule/machines/rings_follow_size.py 的主张，这里只算量。
"""
from __future__ import annotations

from .geometry import corners


def span6(w, color):
    marks = w.ground.marks_of(color)
    return sorted((r, c) for (r, c) in marks if corners(r, c, 6) <= marks)


def solid2(w, color):
    marks = w.ground.marks_of(color)
    return sorted((r, c) for (r, c) in marks
                  if {(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)} <= marks)


def halo_of(p):
    return corners(p[0] - 2, p[1] - 2, 6)
