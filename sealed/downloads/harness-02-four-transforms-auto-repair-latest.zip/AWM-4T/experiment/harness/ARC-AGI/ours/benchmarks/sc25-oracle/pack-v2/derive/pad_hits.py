"""点击落在哪、这一下之后大面板亮着哪几格、凑齐了哪一块小面板。

    clicked(w, act)     点中大面板的哪个格位；没点中 / 不是点击返回 None
    toggled(w, act)     同上（名字说清语义：点中就**翻转**那一格）
    after_lit(w, act)   这一下之后亮着的格位集合；没点中返回 None
    completes(w, act)   这一下之后亮着的格位**正好等于**某一块小面板的图案 → 那块的记号色；否则 None

## 更正（对拍查出来的，`CORRECTIONS.md` B）

封存版的 `lights()` 是「点中了、**而且那一格还没亮**才算数；点在已经亮的格位上返回 None」，
下游的 `completes()` 跟着写成 `after = 已亮 | {这一格}`。

引擎 `sc25.py:3072` 是**翻转**：

```python
self.xhhaqjfncnp[v][w] = not self.xhhaqjfncnp[v][w]
...
self.rrinmfkkstu += 1          # 照扣
```

所以：

```
点在已经亮的格位上  ⇒ 那一格**灭掉**，竖条**照扣** —— 不是「什么都没发生」
after = 已亮 **XOR** {这一格}
```

**后果不止扣费**：灭掉一格能让剩下的正好凑成某个图案 ⇒ 施法。实测撞到过：
亮着 {(0,1),(0,2),(1,0),(1,2),(2,1)}，点掉已亮的 (0,2)，剩下正好是四格十字 ⇒ 施法。

量级（随机走 1391 条转移）：封存版 `dead_click` 判错 381 处，`bar_budget` 跟着错 85 处。
"""
from __future__ import annotations

from objects import parse_action


def clicked(w, action):
    a = parse_action(action)
    if a[0] != "click":
        return None
    return w.pad.hit(a[1], a[2])


# 封存版叫 lights()，语义是「点亮」。这里保留名字只为少改调用点，语义已是**翻转**。
def toggled(w, action):
    """这一下翻转哪个格位（点中大面板就算，不管原来亮没亮）；没点中返回 None。"""
    return clicked(w, action)


lights = toggled          # 兼容旧名；**语义已改**，别再按「点亮」读


def after_lit(w, action):
    """这一下之后亮着的格位集合；没点中大面板返回 None。"""
    cell = toggled(w, action)
    if cell is None:
        return None
    return set(w.pad.lit()) ^ {cell}


def completes(w, action):
    after = after_lit(w, action)
    if after is None:
        return None
    hits = [l.color for l in w.legends if set(l.pattern) == after]
    return hits[0] if len(hits) == 1 else None
