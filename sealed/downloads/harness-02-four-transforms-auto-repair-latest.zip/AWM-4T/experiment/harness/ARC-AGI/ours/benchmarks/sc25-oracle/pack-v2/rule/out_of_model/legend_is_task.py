"""小面板是任务书：大面板上画着提示色（off）的格位，每一个都在某块小面板的图案里。"""
from __future__ import annotations

from objects import read

CLAIM = "任何一帧里，大面板上是提示色（off）的格位，都落在某一块小面板的图案里。"
SCOPE = "前后两帧各查一次；读不成世界不管。"
NOT_CLAIMED = ["不说提示色画在哪块小面板的图案上（有的关一格提示色都没有）"]
WHY_OUT = "这是版面的一句描述，没有任何一步因为它而不同——凑齐判据只看点亮了哪几格，不看提示色。"
NOTE = ["起点：册子 legend_marks_targets（写成子集而不是相等：点亮一格之后提示色那边就少一格）。",
        "重排：从「当前记号色那一块」放宽成「某一块」——那个挑法在两块以上的关里认不准。"]
EVIDENCE = ["9dabb54dca80d95d", "477bf0b6c6fc98eb"]


def scope_(prev, action, nxt, ctx=None):
    if read(prev) is None or read(nxt) is None:
        return "读不成世界"
    return None


def _ok(w):
    off = {(i // 3, i % 3) for i, s in enumerate(w.pad.cells) if s == "off"}
    union = set()
    for l in w.legends:
        union |= set(l.pattern)
    return off <= union


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if _ok(read(prev)) and _ok(read(nxt)) else "FALSE"
