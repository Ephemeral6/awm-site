"""点亮的格位正好凑齐某一块小面板的图案那一下，大面板九格全部变成地板色（包括刚点的那一格）。"""
from __future__ import annotations

from derive.pad_hits import completes
from objects import parse_action, read

from .._scope import unreadable

CLAIM = "这一下点亮之后，点亮的格位正好等于某一块小面板的图案：大面板九格**全部**熄成地板色。"
SCOPE = "只看凑齐图案的那一下点击；其余点击（→ click_lights / dead_click）、读不成世界，不管。"
NOT_CLAIMED = ["不说场上发生什么（三台机器/ 各管一台）", "不说竖条扣多少（凑齐那一下扣得不定，见 bar_budget）"]
NOTE = [
    "起点：册子 panel_done_clears_pad——它就是从三条「清空面板 + 场上效果」捆着写的概念里抽出来的那一半。",
]
EVIDENCE = ["bcf6976ebd8e9446", "2657799cd7a750eb", "ba14e367ea32768c", "d8d189f611166e29"]


def scope_(prev, action, nxt, ctx=None):
    if parse_action(action)[0] != "click":
        return "不是点击"
    w, nw = read(prev), read(nxt)
    if unreadable(w, nw):
        return unreadable(w, nw)
    if completes(w, action) is None:
        return "没凑齐 → click_lights / dead_click"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    return "TRUE" if all(s == "blank" for s in read(nxt).pad.cells) else "FALSE"
