# -*- coding: utf-8 -*-
"""抓算力：claude 和 codex 两边各自怎么拿到 token 数。

    python tokens.py --probe            # 自检：拿最近一次 codex 会话验一遍抓取口径

## 为什么要单独写一份

前几轮「算力」那一栏一直是空的。原因是 codex 那边抓错了行：

```
codex exec 的 stdout 末尾长这样（**两行**）：

    tokens used
    3,577

旧代码找「含 tokens used 的那一行」，抓到的是**表头**，没有数字。
```

## 两个数不是一回事，都要记

```
stdout 的那个数     = 非缓存输入 + 输出      （实测：17003 − 13440 + 14 = 3577，逐位对上）
rollout 里的 usage  = 输入 / 缓存输入 / 输出 / 推理输出 / 总计   —— 完整分项
```

**报算力时两个都报，并写明各自是什么。** 只报一个会误导：
stdout 那个数接近计费口径，rollout 的 `total_tokens` 接近真实上下文吞吐量，差了快 5 倍。

## claude 那边

`claude -p --output-format json` 的返回里直接带 `usage`
（`input_tokens` / `cache_creation_input_tokens` / `cache_read_input_tokens` /
`output_tokens` / `output_tokens_details.thinking_tokens`），还带 `total_cost_usd`。
那一侧本来就是好的，这里只做统一封装。

## 单价

**这一份不换算成钱。** 单价要由实验者提供并注明出处 —— 没有出处的「¥xxx 算力」是编的。
`cost_usd` 那一栏只在 claude 的返回里直接给了的时候才填，并注明「CLI 自报」。
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
from pathlib import Path

CODEX_SESSIONS = Path(os.path.expanduser("~")) / ".codex" / "sessions"


def from_codex_stdout(stdout: str):
    """stdout 末尾那两行。返回 int 或 None。

    形状是**表头一行、数字一行**，所以找到表头之后要往下看。
    """
    lines = (stdout or "").splitlines()
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip().lower() == "tokens used":
            for j in range(i + 1, min(i + 4, len(lines))):
                m = re.search(r"([\d,]+)", lines[j])
                if m:
                    return int(m.group(1).replace(",", ""))
            return None
    # 兜底：有的版本可能写成一行
    m = re.search(r"tokens used[^\d]{0,20}([\d,]+)", stdout or "", re.I)
    return int(m.group(1).replace(",", "")) if m else None


def _rollouts():
    if not CODEX_SESSIONS.exists():
        return []
    return sorted(CODEX_SESSIONS.rglob("rollout-*.jsonl"),
                  key=lambda p: p.stat().st_mtime, reverse=True)


def from_codex_rollout(cwd: str | Path, session_id: str | None = None):
    """按工作目录（或 session id）找到那一次会话的 rollout，取最后一条 token 记录。

    `cwd` 用 `session_meta.payload.cwd` 配 —— 每条臂一个独立跑场，所以这一配是唯一的。
    """
    want = str(Path(cwd).resolve()).lower() if cwd else None
    for p in _rollouts():
        meta = None
        last = None
        try:
            for line in io.open(p, encoding="utf-8", errors="replace"):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                t = d.get("type")
                if t == "session_meta":
                    meta = d.get("payload") or {}
                elif t == "token_usage_record":
                    last = d.get("payload") or {}
        except Exception:
            continue
        if meta is None:
            continue
        if session_id and meta.get("session_id") != session_id:
            continue
        if want and str(Path(meta.get("cwd", "")).resolve()).lower() != want:
            continue
        if last is None:
            return {"rollout": str(p), "note": "找到了会话但里面没有 token 记录"}
        u = last.get("thread_token_usage") or last.get("usage") or {}
        return {"rollout": str(p), "session_id": meta.get("session_id"),
                "cli_version": meta.get("cli_version"),
                "input_tokens": u.get("input_tokens"),
                "cached_input_tokens": u.get("cached_input_tokens"),
                "output_tokens": u.get("output_tokens"),
                "reasoning_output_tokens": u.get("reasoning_output_tokens"),
                "total_tokens": u.get("total_tokens")}
    return None


def codex(stdout: str, cwd: str | Path):
    """codex 一侧的完整读数。两个口径都给。"""
    billed = from_codex_stdout(stdout)
    roll = from_codex_rollout(cwd)
    out = {"cli": "codex", "stdout_tokens": billed, "rollout": roll}
    if billed is not None and roll and roll.get("input_tokens") is not None:
        fresh = (roll["input_tokens"] or 0) - (roll.get("cached_input_tokens") or 0)
        out["consistent"] = (fresh + (roll.get("output_tokens") or 0) == billed)
    return out


def claude(result_json: dict):
    """claude 一侧：`-p --output-format json` 的返回里本来就有 usage。"""
    u = (result_json or {}).get("usage") or {}
    return {"cli": "claude",
            "input_tokens": u.get("input_tokens"),
            "cache_creation_input_tokens": u.get("cache_creation_input_tokens"),
            "cache_read_input_tokens": u.get("cache_read_input_tokens"),
            "output_tokens": u.get("output_tokens"),
            "thinking_tokens": (u.get("output_tokens_details") or {}).get("thinking_tokens"),
            "cost_usd_cli_reported": (result_json or {}).get("total_cost_usd"),
            "num_turns": (result_json or {}).get("num_turns")}


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", action="store_true", help="拿最近一次 codex 会话自检")
    ap.add_argument("--cwd", default=None, help="按这个工作目录找 rollout")
    a = ap.parse_args(argv)
    if a.cwd:
        print(json.dumps(from_codex_rollout(a.cwd), ensure_ascii=False, indent=1))
        return 0
    if a.probe:
        rs = _rollouts()
        print("找到 %d 份 rollout，最近的几份：" % len(rs))
        for p in rs[:3]:
            print("   ", p.name)
        if not rs:
            return 1
        # 最近那一份，按它自己的 cwd 回查
        meta = None
        for line in io.open(rs[0], encoding="utf-8", errors="replace"):
            d = json.loads(line)
            if d.get("type") == "session_meta":
                meta = d.get("payload")
                break
        print()
        print("按 cwd 回查 %s" % (meta or {}).get("cwd"))
        print(json.dumps(from_codex_rollout((meta or {}).get("cwd")),
                         ensure_ascii=False, indent=1))
        print()
        print("stdout 口径自检（拿一段造出来的两行）：",
              from_codex_stdout("...\ntokens used\n3,577\nHi!"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
