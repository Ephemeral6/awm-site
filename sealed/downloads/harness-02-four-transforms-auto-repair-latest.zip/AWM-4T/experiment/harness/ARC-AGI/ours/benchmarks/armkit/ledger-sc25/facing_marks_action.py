"""方向动作之后，标记块里色 9 的那半边一定压在该动作对应的那一侧（1上 2下 3左 4右）。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1/2/3/4；换关的转移（ctx.level_next != ctx.level_prev）返回 NA；" \
        "本 run 第 1 步（世界吞掉的那一条）返回 NA；朝向读不出返回 NA"
NOTE = "v2：换关那一步整屏重画，新关的标记块朝向由世界摆好，和我按的那个方向无关——第 23 步按左、新关朝上。"
EVIDENCE = ["15262396f435b24d", "fd67f106b9c9aa15", "2e40e31fa60834cc", "9dabb54dca80d95d"]

from _lib import FACE, facing


def assert_(prev, action, nxt, ctx=None):
    if action not in FACE:
        return "NA"
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx is not None and ctx.get("step") == 1:
        return "NA"
    f = facing(nxt)
    if f is None:
        return "NA"
    return "TRUE" if f == FACE[action] else "FALSE"
