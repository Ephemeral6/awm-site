"""几何：方区、四角、方向。**没有任何世界断言**——只说「哪几格」，不说「那几格是什么」。"""
from __future__ import annotations

DIRS = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}
H, W = 64, 62          # 场地的行数、列数（竖条那两列不在场地里）


def square(r: int, c: int, k: int) -> frozenset:
    """左上角 (r, c)、边长 k 的方区。"""
    return frozenset((r + i, c + j) for i in range(k) for j in range(k))


def corners(r: int, c: int, k: int) -> frozenset:
    """左上角 (r, c)、跨度 k 的四个角。"""
    return frozenset({(r, c), (r, c + k - 1), (r + k - 1, c), (r + k - 1, c + k - 1)})


def inside(p) -> bool:
    return 0 <= p[0] < H and 0 <= p[1] < W


def ahead(r: int, c: int, k: int, face: str) -> tuple:
    """朝 face 走一个自身边长之后的左上角。"""
    dr, dc = DIRS[face]
    return (r + dr * k, c + dc * k)


def ahead_by(r: int, c: int, n: int, face: str) -> tuple:
    """朝 face 走 n 格之后的左上角。`ahead` 是它在 n = 自身边长时的特例。

    为什么需要任意步长：引擎在整块挪不动时，**大身还会再试挪 2**（见 CORRECTIONS.md C）。
    """
    dr, dc = DIRS[face]
    return (r + dr * n, c + dc * n)
