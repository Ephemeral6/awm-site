/-
# erase —— 抹除那台机器（对应 rule/machines/erase.py）

**定义，不是定理。** 开火当且仅当：还没抹掉、标本还在的抹除框里，**恰好一个**在我面前
（整个框在朝向那一侧；我的带子和它那一圈一个套住另一个），而且我到它之间有一条每格都走得上去的车道。
开火：记下「这个框抹掉了」——场上那个标本色的全部格、那一圈记号怎么变，由 `Render.lean` 画出来。
-/

import Obj.Model.Render
import Obj.Derive.Standing

namespace Game

def nested (lo hi mlo mhi : Nat) : Bool := (lo ≤ mlo && mhi ≤ hi) || (mlo ≤ lo && hi ≤ mhi)

/-- 按我的边长读，这个框的左上角在哪（4：那一圈本身；2：圈里那块 2×2）。 -/
def eboxPos (e : EBox) (k : Nat) : Nat × Nat := if k == 4 then (e.top, e.left) else (e.top + 1, e.left + 1)

def inFront (e : EBox) (m : Marker) : Bool :=
  let k := m.side
  let q := eboxPos e k
  match m.face with
  | .U => nested e.left (e.left + 3) m.col (m.col + k - 1) && q.1 + k ≤ m.row
  | .D => nested e.left (e.left + 3) m.col (m.col + k - 1) && m.row + k ≤ q.1
  | .L => nested e.top (e.top + 3) m.row (m.row + k - 1) && q.2 + k ≤ m.col
  | .R => nested e.top (e.top + 3) m.row (m.row + k - 1) && m.col + k ≤ q.2

/-- 我到框之间那一截，按线分组（横着瞄一行一条，竖着瞄一列一条）。 -/
def laneLines (m : Marker) (q : Nat × Nat) : List (List (Nat × Nat)) :=
  let k := m.side
  match m.face with
  | .U => (List.range k).map fun j => (List.range (m.row - (q.1 + k))).map fun i => (q.1 + k + i, m.col + j)
  | .D => (List.range k).map fun j => (List.range (q.1 - (m.row + k))).map fun i => (m.row + k + i, m.col + j)
  | .L => (List.range k).map fun i => (List.range (m.col - (q.2 + k))).map fun j => (m.row + i, q.2 + k + j)
  | .R => (List.range k).map fun i => (List.range (q.2 - (m.col + k))).map fun j => (m.row + i, m.col + k + j)

/-- 还能抹：没抹掉，而且它的标本色没有被别的框一起抹掉。 -/
def armed (b : Board) (s : St) (i : Nat) (e : EBox) : Bool :=
  !(s.erased.contains i) && !(s.erased.any fun j => (b.eboxes[j]?.map (·.spec)) == some e.spec)

def eraseCandsAux (b : Board) (s : St) : List EBox → Nat → List Nat
  | [], _ => []
  | e :: rest, i =>
    (if armed b s i e && inFront e s.me then [i] else []) ++ eraseCandsAux b s rest (i + 1)

def erase (b : Board) (s : St) : St :=
  match eraseCandsAux b s b.eboxes 0 with
  | [i] =>
    (match b.eboxes[i]? with
     | some e =>
       let pic := render b s
       if (laneLines s.me (eboxPos e s.me.side)).any (fun l => l.all (walkable pic b.legends))
       then { s with erased := s.erased ++ [i] } else s
     | none => s)
  | _ => s

end Game
