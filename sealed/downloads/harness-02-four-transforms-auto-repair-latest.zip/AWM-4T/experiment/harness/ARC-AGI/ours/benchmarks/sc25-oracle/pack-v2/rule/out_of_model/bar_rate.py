"""第 0 关，竖条的消耗追不上 32/50 块每个动作：已消耗块数 ≤ ⌊(本会话已发动作数 − 1) × 32 / 50⌋。"""
from __future__ import annotations

from objects import read

CLAIM = "第 0 关之内：已消耗的块数（32 − 满的块数）不超过 ⌊(n − 1) × 32 / 50⌋，n = 这个世界会话到这一步为止发出的动作数（RESET 不算）。"
SCOPE = "只看第 0 关之内（上游关号前后都是 0）；上游没给会话步数、读不成世界，不管。"
NOT_CLAIMED = ["不说别的关（每关的预算不同，别的关没量过）", "不说等号（空点击不推这把尺子）"]
WHY_OUT = ("它读的是「已经发了几个动作」这一位累计——那是历史，帧上读不出（竖条按整块量化，"
           "一次动作的开销小于一块）。模型只存帧上读得出的东西，所以竖条整个不进 Lean 那一侧。")
NOTE = ["起点：册子 bar_rate v3（等号被两次空点击打成不等号）。",
        "重排：n 从「step − 1」改成「本会话已发动作数 − 1」——换卡之后 step 不从 1 数起，老写法在第二张卡上会错位。"]
EVIDENCE = ["da3e01cff498c8a1", "57d8819abf0ed7b8", "959d794af724ea4a", "6900c748911db55b", "a58dabe7ec5e29d9"]


def scope_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") != 0 or ctx.get("level_next") != 0:
        return "不在第 0 关之内"
    if ctx.get("session_step") is None:
        return "ctx 缺会话步数"
    if action == "RESET":
        return "RESET"
    if read(nxt) is None:
        return "读不成世界"
    return None


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    n = ctx["session_step"] - 1
    spent = 32 - read(nxt).bar.rows // 2
    return "TRUE" if spent <= (n * 32) // 50 else "FALSE"
