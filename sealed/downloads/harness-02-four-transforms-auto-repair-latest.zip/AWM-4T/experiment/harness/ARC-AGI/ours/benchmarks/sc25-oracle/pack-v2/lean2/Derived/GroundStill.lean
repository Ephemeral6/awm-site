/-
# ground_still / panels_fixed —— 在这边是**推论**，不是定义（对应 rule/world/ground_still.py、panels_fixed.py）

Python 那一侧两条规则说「凑齐图案之外，地面一格不动（吃掉的燃料除外）」「小面板一关之内不变，
大面板只在点击时变」。在模型这一侧它们**不是独立的规则**：

  · 地面由 `render` 从 `Board`（版面，`step` 碰不到）和 `St` 的几位算出来；
    方向键与没凑齐的点击**碰不到**其中「抹掉了哪几个框」「戴外圈的是哪一个」「我的尺寸」三位——下面证。
    剩下会变的只有我的位置（我身下本来就不比）和「吃掉了哪几坨燃料」（那一支正是 fuel_absorbs）。
  · 小面板住在 `Board.legends` 里，`see` 原样拿它：「一关之内小面板变了」**表示不出来**。

所以这两条在身份表上落「推论」：一条由架构本身推出，一条由 `step` 的定义推出。

定理写在命名空间外面：装置的 `ledger/lean_check.py` 按**不带前缀的名字**逐条 `#print axioms`。
-/

import Obj.World
import Obj.Model.St
import Obs.Check

open Game

/-- 方向键不碰「抹掉了哪几个框」「戴外圈的是哪一个」「大面板」「我的尺寸」。 -/
theorem dir_step_keeps (b : Board) (s s' : St) (f : Face) (h : step b s (.dir f) = .ok s') :
    s'.erased = s.erased ∧ s'.gate = s.gate ∧ s'.pad = s.pad ∧ s'.me.side = s.me.side := by
  simp only [step] at h
  split at h
  · cases h; exact ⟨rfl, rfl, rfl, rfl⟩
  · cases h
    simp only [eatFuel, stepDir]
    split
    · exact ⟨rfl, rfl, rfl, rfl⟩
    · split <;> exact ⟨rfl, rfl, rfl, rfl⟩

/-- 没凑齐图案的点击：只有大面板可能变（点亮一格）；我、抹掉的框、戴外圈的、吃掉的燃料都不变。 -/
theorem click_nocomplete_keeps (b : Board) (s s' : St) (x y : Nat)
    (hc : ∀ i, padHit b x y = some i → completes b (lightUp s i).pad = none)
    (h : step b s (.click x y) = .ok s') :
    s'.me = s.me ∧ s'.erased = s.erased ∧ s'.gate = s.gate ∧ s'.eaten = s.eaten := by
  simp only [step] at h
  split at h
  · cases h; exact ⟨rfl, rfl, rfl, rfl⟩
  · split at h
    · cases h; exact ⟨rfl, rfl, rfl, rfl⟩
    · rename_i i hi
      rw [hc i hi] at h
      cases h; exact ⟨rfl, rfl, rfl, rfl⟩

/-- 小面板一关之内不变：`see` 出来的小面板永远是版面上那一套——变了**表示不出来**。 -/
theorem legends_fixed (b : Board) (s : St) : (see b s : World).legends = b.legends := rfl

#print axioms dir_step_keeps
#print axioms click_nocomplete_keeps
#print axioms legends_fixed
