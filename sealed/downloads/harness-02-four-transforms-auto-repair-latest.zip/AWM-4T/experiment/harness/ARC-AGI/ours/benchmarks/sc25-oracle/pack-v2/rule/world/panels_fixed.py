"""一关之内小面板从不变；大面板只在点击时变。"""
from __future__ import annotations

from objects import parse_action, read

from .._scope import first, is_reset, level_changed, unreadable

CLAIM = "一关之内（不换关、不 RESET）：小面板（记号色与图案）一格不变；不是点击的动作，大面板也一格不变。"
SCOPE = "换关那一步、RESET、读不成世界，不管。"
NOT_CLAIMED = ["不说点击时大面板怎么变（面板怎么响应/ 三条管）"]
NOTE = ["新写的一条：册子里「小面板是任务书」只说了开局那一刻（legend_marks_targets），「它从不变」没人说过。"]
EVIDENCE = ["da3e01cff498c8a1", "477bf0b6c6fc98eb"]


def scope_(prev, action, nxt, ctx=None):
    return first(level_changed(ctx), is_reset(action), unreadable(read(prev), read(nxt)))


def assert_(prev, action, nxt, ctx=None):
    if scope_(prev, action, nxt, ctx):
        return "NA"
    w, nw = read(prev), read(nxt)
    if w.legends != nw.legends:
        return "FALSE"
    if parse_action(action)[0] != "click" and w.pad != nw.pad:
        return "FALSE"
    return "TRUE"
