"""Operator-owned, same-call-segment Lean build contexts. Never trusts arena oleans.

Only compiler output is reusable. Current proof/gate/observation checks stay outside.
No persistence across model calls, rounds, cases or processes.
"""
from pathlib import Path
import atexit,hashlib,json,os,re,shutil,tempfile,time,unicodedata,datetime,uuid,copy
from concurrent.futures import ThreadPoolExecutor

VERSION='safe-build-v2.2'
_CASES={}
ARTIFACT_SUFFIXES=('.olean','.olean.private','.olean.server','.olean.sig','.ilean','.ir','.pyc')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def inputs(d):
    d=Path(d).resolve();out={}
    for p in sorted(d.rglob('*')):
        rel=p.relative_to(d)
        if any(x in ('.git','__pycache__','.claude') for x in rel.parts):continue
        if p.is_symlink():raise ValueError('Build input symlinks are not accepted: '+str(rel))
        if p.is_file() and not p.name.endswith(ARTIFACT_SUFFIXES):out[rel.as_posix()]=sha(p)
    return out
def copy_inputs(d,dest,manifest):
    d=Path(d);dest=Path(dest)
    for rel,want in manifest.items():
        target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(d/rel,target)
        if sha(target)!=want:raise ValueError('Input changed during snapshot: '+rel)

def toolchain_id(lean):
    """Content hashes, NOT timestamps. Deliberately bounded-memory; includes libraries.

    This has measurable I/O cost; report it separately instead of claiming free hits.
    """
    lean=Path(lean).resolve()
    if not lean.is_file():raise ValueError('Pinned Lean executable missing: '+str(lean))
    home=lean.parent.parent;files={lean}
    files.update(p for p in lean.parent.iterdir() if p.is_file() and p.suffix.lower() in ('.dll','.so','.dylib'))
    lib=home/'lib/lean'
    if lib.exists():files.update(p for p in lib.rglob('*') if p.is_file() and p.suffix not in ('.a','.ilean'))
    # Do not log environment values (they may contain credentials), only a digest.
    # Independent byte reads only: four bounded 1 MiB buffers, no cached hashes,
    # timestamps, background processes or relaxed toolchain validation.
    ordered=sorted(files)
    with ThreadPoolExecutor(max_workers=4,thread_name_prefix='awm-content-hash') as pool:
        hashes=dict(zip((str(p.relative_to(home)) for p in ordered),pool.map(sha,ordered)))
    return dict(executable=str(lean),files=hashes,
                environment_sha256=digest(dict(os.environ)),policy=VERSION,checker_sha256=sha(__file__))

def _strip_comments(s):
    out=[];i=0;depth=0;quote=False
    while i<len(s):
        if not quote and s.startswith('/-',i):depth+=1;out.append('  ');i+=2
        elif depth and s.startswith('-/',i):depth-=1;out.append('  ');i+=2
        elif depth:out.append('\n' if s[i]=='\n' else ' ');i+=1
        elif not quote and s.startswith('--',i):
            j=s.find('\n',i);j=len(s) if j<0 else j;out.append(' '*(j-i));i=j
        else:
            c=s[i];out.append(c)
            if c=='"' and (i==0 or s[i-1]!='\\'):quote=not quote
            i+=1
    if depth:raise ValueError('Unterminated Lean comment')
    return ''.join(out)
def imports(path):
    """Conservative parser for standard Lean headers, including public/meta imports."""
    s=_strip_comments(Path(path).read_text(encoding='utf-8-sig'));out=[]
    for raw in s.splitlines():
        line=raw.strip()
        if not line:continue
        if line in ('module','prelude'):continue
        m=re.fullmatch(r'(?:(?:public|private|meta)\s+)*import\s+(?:all\s+)?([\w\'.]+)',line)
        if m:out.append(m.group(1));continue
        if re.match(r'(?:(?:public|private|meta)\s+)*import\b',line):raise ValueError('Unsupported import header; cannot establish complete dependencies: '+line)
        break
    return out

def reusable_profile(d,manifest):
    """Conservative fast-path eligibility, never a general Lean sandbox.

    Dynamic/meta/file-reading programs remain supported by cold builds, without reuse.
    Unrecognized # commands also disable reuse. Definitions/proofs still checked by Lean.
    """
    bad=re.compile(r'\b(?:unsafe|axiom|opaque|elab|macro|syntax|macro_rules|elab_rules|declare_syntax_cat|initialize|builtin_initialize|run_tac|run_meta|run_cmd|run_elab|include_str|include_bytes|load_dynlib|implemented_by|extern|IO|EIO|BaseIO|System|Environment|MetaM|ElabM)\b|\$|`')
    allowed_hash={'print','check','synth'}
    for rel in manifest:
        if not rel.endswith('.lean'):continue
        s=unicodedata.normalize('NFKC',_strip_comments((Path(d)/rel).read_text(encoding='utf-8-sig')))
        if bad.search(s):return False,'dynamic/meta/opaque input: '+rel
        if any(x not in allowed_hash for x in re.findall(r'#\s*([\w]+)',s)):return False,'unsupported command: '+rel
    return True,'conservative ordinary-definition/proof profile'

def _base():
    p=Path(os.environ.get('AWM_ARCHIVE',str(Path(__file__).resolve().parents[5]/'runtime_archive')))/'safe_build'
    p.mkdir(parents=True,exist_ok=True);return p.resolve()
def invalidate(d,reason='model call/round boundary'):
    key=str(Path(d).resolve());state=_CASES.pop(key,None)
    if state:
        if state['contexts']:
            with (_base()/'events.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(dict(case=key,kind='invalidate',reason=reason,contexts=len(state['contexts'])),ensure_ascii=False)+'\n')
        for c in state['contexts'].values():c.close()
    return reason
def clear():
    for k in list(_CASES):invalidate(k,'process exit')
atexit.register(clear)

class Context:
    def __init__(self,d,roots,manifest,tool,runner,cacheable,reason):
        self.d=Path(d).resolve();self.manifest=manifest;self.tool=tool;self.runner=runner;self.cacheable=cacheable;self.reason=reason
        self.temp=tempfile.TemporaryDirectory(prefix='lean-',dir=_base());self.shadow=Path(self.temp.name).resolve()
        if not self.shadow.is_relative_to(_base()):raise ValueError('Unexpected snapshot location')
        copy_inputs(self.d,self.shadow,manifest)
        self.roots=[self.shadow/Path(r).resolve().relative_to(self.d) for r in roots]
        self.original_roots=[str(Path(r).resolve()) for r in roots]
        self.modules={};self.targets={};self.events=[]
        self.key=digest(dict(case=str(self.d),inputs=manifest,roots=self.original_roots,tool=tool))
    def close(self):
        if self.shadow.is_relative_to(_base()):self.temp.cleanup()
    def resolve(self,mod):
        rel=Path(*mod.split('.')).with_suffix('.lean')
        for r in self.roots:
            p=r/rel
            if p.is_file():return r,p
        return None,None
    def library(self,mod):
        p=Path(self.tool['executable']).parent.parent/'lib/lean'/Path(*mod.split('.')).with_suffix('.olean')
        return p if p.is_file() else None
    def artifacts(self,p):
        stem=p.with_suffix('.olean')
        return {str(x):sha(x) for x in p.parent.glob(stem.name+'*') if x.is_file()}
    def visit(self,mod,timeout,stack=()):
        if mod in stack:raise ValueError('Cyclic local Lean imports: '+str(stack+(mod,)))
        root,p=self.resolve(mod)
        if p is None:
            lib=self.library(mod)
            if lib is None:raise ValueError('Unresolved Lean module: '+mod)
            return dict(module=mod,found=True,bundled=True,rc=0,key=digest((mod,sha(lib))))
        children=[self.visit(x,timeout,stack+(mod,)) for x in imports(p)]
        if any(x['rc']!=0 for x in children):return dict(module=mod,found=True,rc=1,key='failed dependency')
        key=digest((str(p.relative_to(self.shadow)),sha(p),[x['key'] for x in children],self.key))
        old=self.modules.get(mod)
        if old and old['key']==key and old['rc']==0 and old.get('artifacts')==self.artifacts(p):return old
        # Fresh operator shadow contains no arena oleans. Existing shadow artifacts
        # are accepted ONLY with the operator-produced manifest above.
        self.targets.clear()  # Rebuilt/tampered dependency invalidates all target receipts.
        rc,out,dt=self.runner(self.roots,root,p,p.with_suffix('.olean'),timeout)
        rec=dict(module=mod,found=True,rc=rc,key=key,wall_s=dt,artifacts=self.artifacts(p),
                 errors=[s[:180] for s in out.splitlines() if 'error' in s][:5])
        if rc==0 and not p.with_suffix('.olean').is_file():rec['rc']=1;rec['errors'].append('Compiler did not produce expected olean')
        self.modules[mod]=rec;self.events.append(dict(kind='dependency_compile',module=mod,rc=rec['rc'],wall_s=dt));return rec
    def compile(self,rel,timeout):
        p=self.shadow/rel;deps=[self.visit(x,timeout) for x in imports(p)]
        dependency_state={m:r.get('artifacts') for m,r in self.modules.items()}
        old=self.targets.get(rel)
        if self.cacheable and old and old['dependencies']==dependency_state and all(r['rc']==0 and r.get('artifacts')==self.artifacts(self.resolve(m)[1]) for m,r in self.modules.items()):
            out=copy.deepcopy(old['result']);out['cache_hit']=True;out['cache_lookup_s']=0
            self.events.append(dict(kind='target_hit',file=rel));return out
        failed=[x['module'] for x in deps if x['rc']!=0]
        if failed:rc,out,dt=1,'error: failed dependencies '+str(failed),0
        else:rc,out,dt=self.runner(self.roots,p.parent,p,None,timeout)
        axs=[s.strip() for s in out.splitlines() if 'depend on any axioms' in s or 'depends on axioms' in s]
        dirty=sorted({w for w in ('sorryAx','ofReduceBool','trustCompiler','native_decide') if w in out})
        errors=[s.strip()[:200] for s in out.splitlines() if 'error' in s]
        good=rc==0 and not errors
        record=_base()/('compile-'+uuid.uuid4().hex+'.json')
        record.write_text(json.dumps(dict(case=str(self.d),context=self.key,target=rel,rc=rc,wall_s=dt,stdout=out,inputs=self.manifest,toolchain_sha256=digest(self.tool)),ensure_ascii=False,indent=2),encoding='utf-8')
        value=dict(file=rel,rc=rc,wall_s=round(dt,3),deps_built=len(self.modules),deps_failed=failed,imports_unresolved=[],compiles=good,axiom_lines=axs,dirty=dirty,
                   clean=good and bool(axs) and not dirty,errors=errors[:6],out=out[-6000:],cache_hit=False,
                   compiler_receipt=dict(context_sha256=self.key,input_sha256=digest(self.manifest),toolchain_sha256=digest(self.tool),record=str(record),compiled_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       scope='Operator source-only snapshot; same case and uninterrupted driver segment; not a gate or environment-coverage verdict.'),
                   reuse_eligible=self.cacheable,reuse_reason=self.reason)
        self.events.append(dict(kind='target_compile',file=rel,rc=rc,wall_s=dt))
        if good and not dirty:self.targets[rel]=dict(result=copy.deepcopy(value),dependencies=dependency_state)
        return value

def check_files(d,rels,roots,lean,runner,timeout=900,force_cold=False):
    d=Path(d).resolve();t0=time.monotonic();manifest=inputs(d);tool=toolchain_id(lean)
    cacheable,reason=reusable_profile(d,manifest)
    state=_CASES.setdefault(str(d),dict(inputs=None,contexts={}))
    signature=digest((manifest,tool))
    if state['inputs']!=signature:
        invalidate(d,'inputs/toolchain/environment changed');state=_CASES.setdefault(str(d),dict(inputs=signature,contexts={}))
    key=digest(([str(Path(r).resolve()) for r in roots],signature))
    c=state['contexts'].get(key)
    if force_cold or not cacheable:
        c=Context(d,roots,manifest,tool,runner,False,'forced cold' if force_cold else reason)
    elif c is None:
        if len(state['contexts'])>=4:
            victim=next(iter(state['contexts']));state['contexts'].pop(victim).close()
        c=Context(d,roots,manifest,tool,runner,True,reason);state['contexts'][key]=c
    before=len(c.events)
    try:
        values=[c.compile(rel,timeout) for rel in rels]
        # Compile-time source/data mutations cannot make an old receipt current.
        changed=inputs(d)!=manifest or toolchain_id(lean)!=tool or any(not (c.shadow/rel).is_file() or sha(c.shadow/rel)!=h for rel,h in manifest.items())
        if changed:
            for v in values:v.update(compiles=False,clean=False,rc=1,errors=['error: input changed during compiler check']);v['out']+='\nerror: input changed during compiler check'
            invalidate(d,'concurrent input mutation')
        events=c.events[before:];elapsed=time.monotonic()-t0
        compiler_s=sum(e.get('wall_s',0) for e in events)
        for v in values:v['check_wall_s']=round(elapsed,3);v['validation_io_wall_s']=round(max(0,elapsed-compiler_s),3)
        folder=_base();log=folder/'events.jsonl'
        with log.open('a',encoding='utf-8') as f:f.write(json.dumps(dict(case=str(d),context=c.key,elapsed_s=elapsed,force_cold=force_cold,events=events),ensure_ascii=False)+'\n')
        return values
    finally:
        if force_cold or not cacheable:c.close()
