"""抹除的那条**单像素射线**：从我身上射出去，第一个撞到的是什么。

    ray_first(w)    射线第一个撞到的格；出界/什么都没撞到返回 None
    hits_target(w)  第一个撞到的是不是**标本**（扣在抹除色框里的那块实心）

## 为什么要这一份（`CORRECTIONS.md` D）

封存版 `rule/machines/erase.py` 的 `fire(w)` 要三条同时成立：我面前恰好一个抹除色的框、
框里扣着标本、我到它之间有一条每格都走得上去的**车道**。**三条都不对。**

引擎 `sc25.py:2381-2441` 放的是一条**单像素**射线：

```
方向      [(0,-1), (0,1), (-1,0), (1,0)]   按朝向 0上 1下 2左 3右，取 (dx, dy)
边长      size = 2 * scale                 （小身 2、大身 4）
第 i 点   off_x = size-1 if dx > 0 else 0
          off_y = size-1 if dy > 0 else 0
          (me.x + off_x + dx*i,  me.y + off_y + dy*i)      i = 1, 2, 3, …
出界      停
撞实心    停（实心 = 模型里的 block **或** void —— 见 ray_first 里的注）
**开火**  第一个撞到的是**靶**（标本）⇒ 抹除生效；撞到墙/栅栏/别的 ⇒ **空放**（只扣费，场上不变）
```

**竖着打取左列**（off_x = 0），**横着打取上行**（off_y = 0）。
没有「车道」这一位，也不要求整个身位对着框。

模型这边的坐标就是引擎的像素坐标（行 = y，列 = x），所以直接照搬。
「实心」在模型里是 `("block", 色)`：墙、标本、插座的边都归它。
**虚空也挡** —— 引擎的墙图 `duvwsv-*` 在 `pixels != -1` 处算实心，而那些格在模型的
`Ground` 里读出来就是「不在表里」＝虚空。所以模型侧必须把 void 当成挡路的。
（第一版写反了，被一次实跑驳倒，见 ray_first 里的注。）

## 对拍

`../../sc25-budget/rule_D.py`：那条 132 步动作串上的 6 次抹除施法 **6/6 全中**
（封存版 `fire(w)` 只中 1/6）；随机走 15 次施法 **15/15**；合计 **21/21**。
"""
from __future__ import annotations

from .boxes import boxes
from .geometry import DIRS, inside, square
from .machines import ERASE


def ray_first(w):
    """射线第一个撞到的格（模型坐标）；出界或一路畅通返回 None。"""
    me = w.me
    dr, dc = DIRS[me.face]
    k = me.side
    orow = k - 1 if dr > 0 else 0
    ocol = k - 1 if dc > 0 else 0
    for i in range(1, 64):
        p = (me.row + orow + dr * i, me.col + ocol + dc * i)
        if not inside(p):
            return None
        kind = w.ground.kind(p)[0]
        # **挡射线的是 block 和 void 两种。**
        # 引擎那一侧的判据是「墙图 duvwsv-* 的这个像素 != -1 就算实心」，
        # 而墙图不透明的那些格在模型里读出来就是**虚空**（不在 ground 表里）。
        # 第一版只让 block 挡，于是射线会一路穿过墙打到后面的靶上 —— 过度预测开火。
        # 关 5 实测三处：小身在 (15,21)、(15,35)、大身在 (16,33) 朝右，
        # 从第 22 列起就是虚空，引擎当场停、不开火，而旧版判「打中 (15,56) 的靶」。
        if kind in ("block", "void"):
            return p
    return None


def specimen_cells(w):
    """场上所有**标本**格：扣在某个抹除色框里的那些实心格。

    框按**两种边长都找**（2 和 4）——框的边长和我现在的边长未必一样，
    而射线打中的是框里的东西，与我的边长无关。
    """
    out = set()
    for k in (2, 4):
        for b in boxes(w, ERASE, k):
            for p in square(b[0], b[1], k):
                if w.ground.kind(p)[0] == "block":
                    out.add(p)
    return out


def hits_target(w):
    """射线第一个撞到的是不是标本。是 → 开火；否则空放。"""
    p = ray_first(w)
    return p is not None and p in specimen_cells(w)


def target_kind(w):
    """开火时被抹掉的那个**标本色**（`("block", 色)`）；不开火返回 None。"""
    p = ray_first(w)
    if p is None or p not in specimen_cells(w):
        return None
    return w.ground.kind(p)
