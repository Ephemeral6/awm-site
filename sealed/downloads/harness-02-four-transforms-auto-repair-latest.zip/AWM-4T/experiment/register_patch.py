"""Preserve the shipped manifest while documenting a receiver bug fix version."""
from pathlib import Path
import sys,argparse,json
R=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R.parent)]
from verify_package import verify
from device_support import sha

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--reason',required=True);a=p.parse_args()
    if len(a.reason.strip())<30:raise SystemExit('Describe the actual bug, fix and affected runs')
    issues=verify()['issues'];changes={r['path']:sha(R.parent/r['path']) if (R.parent/r['path']).is_file() else None for r in issues}
    out=R/'receiver_validation';out.mkdir(exist_ok=True)
    record=dict(version=a.version,reason=a.reason,changes=changes,scope='Changes to original delivery; original package manifest retained. Passing tests and semantic review still required.')
    (out/'registered_patch.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(record,ensure_ascii=False,indent=2))
