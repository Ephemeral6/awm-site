"""Four-direction coverage and freshness. Not a semantic equivalence proof.

The driver owns the before snapshot; the subject supplies decisions and evidence.
No model, CLI, network or game service is launched by this module.
"""
from pathlib import Path
import hashlib, json

IDS=('decomposition','composition','generalization','specialization')
STATUS={'applied','considered_no_change','not_applicable'}
_BEFORE={}
_CURRENT={}

def source_hashes(d):
    d=Path(d)
    return {p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for top in ('objects','derive','rule','concepts')
            for p in sorted((d/top).rglob('*.py')) if '__pycache__' not in p.parts}

def full_hashes(d):
    d=Path(d);out=source_hashes(d)
    for top in ('lean/Obj','lean/Rule'):
        out.update({p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/top).rglob('*.lean')})
    if (d/'lean/Step.lean').exists():out['lean/Step.lean']=hashlib.sha256((d/'lean/Step.lean').read_bytes()).hexdigest()
    return out

def corpus(d):
    p=Path(d)/'transitions.jsonl';raw=p.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines() if x.strip()]
    ids={str(x.get('tid',x.get('id',i))) for i,x in enumerate(rows)}
    return hashlib.sha256(raw).hexdigest(),ids

def begin(d,attempt):
    d=Path(d);key=str(d.resolve());h,ids=corpus(d)
    value={'attempt':attempt,'before_source_sha256':source_hashes(d),'corpus_sha256':h,'evidence_ids':sorted(ids)}
    _BEFORE[(key,attempt)]=value;_CURRENT[key]=attempt
    folder=d/'analysis/transforms';folder.mkdir(parents=True,exist_ok=True)
    (folder/f'driver_before_{attempt:02d}.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
    return value

def check(d,attempt,before=None):
    d=Path(d);why=[]
    baseline=before if before is not None else _BEFORE.get((str(d.resolve()),attempt))
    try:
        current=source_hashes(d);h,ids=corpus(d)
        if baseline is None:raise ValueError('driver-owned before snapshot is unavailable')
        rec=json.loads((d/f'analysis/transforms/attempt_{attempt:02d}.json').read_text(encoding='utf-8'))
        if rec.get('attempt')!=attempt:why.append('wrong attempt number')
        if rec.get('before_source_sha256')!=baseline['before_source_sha256']:why.append('before snapshot differs from driver capture')
        if rec.get('after_source_sha256')!=current:why.append('transformation receipt is stale after Python model edits')
        if rec.get('corpus_sha256')!=h or baseline['corpus_sha256']!=h:why.append('corpus changed during file-only refinement or receipt is stale')
        if not ids or not current:why.append('empty model/corpus cannot establish refinement compliance')
        rows=rec.get('transformations',[])
        if not isinstance(rows,list) or not all(isinstance(x,dict) for x in rows):raise ValueError('transformations must be a list of objects')
        if len(rows)!=4 or {x.get('id') for x in rows}!=set(IDS):why.append('exactly the four transformation IDs are required, once each')
        changed={x for x in set(current)|set(baseline['before_source_sha256']) if current.get(x)!=baseline['before_source_sha256'].get(x)}
        covered=set();known=set(current)|set(baseline['before_source_sha256'])
        for row in rows:
            ident=row.get('id','?');status=row.get('status');targets=row.get('targets',[])
            if status not in STATUS:why.append(ident+': unresolved/missing decision')
            if len(row.get('reason','').strip())<80:why.append(ident+': requires a specific 80-character rationale')
            for layer in ('object_consideration','rule_consideration'):
                if len(row.get(layer,'').strip())<40:why.append(ident+': requires '+layer+' with at least 40 characters')
            if not targets or not set(targets)<=known:why.append(ident+': targets must name actual model files')
            evidence=row.get('evidence_ids',[])
            if not evidence or not {str(x) for x in evidence}<=ids:why.append(ident+': evidence IDs are missing or outside the full corpus')
            if status=='applied':
                if not set(targets)&changed:why.append(ident+': applied claims require an actual target-file change')
                covered.update(targets)
        if changed-covered:why.append('model edits have no applied transformation record: '+', '.join(sorted(changed-covered)))
        reg=json.loads((d/'analysis/rejection_after.json').read_text(encoding='utf-8'))
        if not reg.get('ok') or not reg.get('compared_to'):why.append('successful before/after full regression receipt required')
        if reg.get('corpus_sha256')!=h or reg.get('source_sha256')!=full_hashes(d):why.append('full regression receipt is stale')
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as e:why.append('missing or invalid four-transformation evidence: '+str(e))
    return {'ok':not why,'attempt':attempt,'why':why,
            'scope':'Checks consideration records, evidence IDs, real edit coverage and freshness; NOT semantic correctness or categorical universal properties.'}

def check_current(d):
    attempt=_CURRENT.get(str(Path(d).resolve()))
    if attempt is None:return {'ok':False,'why':['no driver-owned current attempt for four-transformation audit']}
    return check(d,attempt)

def prompt(attempt):
    return f'''\n## Required four-transformation audit, attempt {attempt}
Before declaring stage 03 complete, write analysis/transforms/attempt_{attempt:02d}.json.
Read analysis/transforms/driver_before_{attempt:02d}.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.
'''
