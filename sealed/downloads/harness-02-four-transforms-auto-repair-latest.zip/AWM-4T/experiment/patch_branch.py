from pathlib import Path
import shutil,json,hashlib,difflib
R=Path(__file__).parent
OURS=R/'harness/ARC-AGI/ours';V2=OURS/'benchmarks/armkit-v2';P2=OURS/'sc25-selfaudit-phase2'
cards=OURS/'sc25-selfaudit-v7/cards_fourtransforms'
assert not (R/'patches.json').exists(),'Branch already patched; inspect rather than patch twice'
shutil.copytree(OURS/'sc25-selfaudit-v7/cards_v7h',cards)
(cards/'PROTOCOL-four-transforms.json').write_text(json.dumps({'version':'4t-8plus4-20261024','criteria':4,'first_eight_selfaudit':False,'first_eight_skeptic':False,'semantic_review_required':True},indent=2),encoding='utf-8')
shutil.copy2(R/'four_transforms_gate.py',V2/'four_transforms_gate.py')
patches=[]
def edit(path,fn):
    before=path.read_text(encoding='utf-8');after=fn(before)
    if before==after:raise RuntimeError('No edit: '+str(path))
    rel=path.relative_to(R).as_posix();b=R/'before_patch'/rel;b.parent.mkdir(parents=True,exist_ok=True);b.write_text(before,encoding='utf-8')
    path.write_text(after,encoding='utf-8')
    q=R/'diffs'/(path.name+'.diff');q.parent.mkdir(parents=True,exist_ok=True)
    q.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='v7h/'+rel,tofile='4t-8plus4/'+rel)),encoding='utf-8')
    patches.append({'file':rel,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest()})
def once(s,a,b):
    if s.count(a)!=1:raise RuntimeError('Expected one match: '+a[:90])
    return s.replace(a,b,1)
def patch_cards(s):
    s+=r'''

# Four-transform branch: explicit consideration receipts, not semantic verification.
import four_transforms_gate as FT
_strict_enabled = False
_original_load, _original_plan, _original_check = load, plan, check
def load(dirpath):
    global _strict_enabled
    _strict_enabled = (Path(dirpath)/'PROTOCOL-four-transforms.json').exists()
    result = _original_load(dirpath)
    if _strict_enabled: MODE[0] = 'v7f'
    return result
def strict_begin(d, k):
    return FT.begin(d, k) if _strict_enabled else None
def plan(cards, k):
    return [(st, msg + (FT.prompt(k) if _strict_enabled and '03' in st else ''))
            for st,msg in _original_plan(cards,k)]
def check(d, stages, before, after, text, k):
    result = _original_check(d, stages, before, after, text, k)
    if _strict_enabled and '03' in stages:
        result['four_transformations'] = FT.check(d,k)
        result['why'] += result['four_transformations']['why']
        result['ok'] = not result['why']
    return result
'''
    return s
edit(V2/'cards_gate.py',patch_cards)
def patch_driver(s):
    needle='    a = ap.parse_args(argv)\n'
    opts='''    ap.add_argument('--resume-session', action='store_true', help='continue the same case; never clear its memory or start a fresh CLI session')
    ap.add_argument('--attempt-offset', type=int, default=0)
    ap.add_argument('--initial-prompt-file', help='generic feedback after the locked eight-attempt checkpoint')
'''
    s=once(s,needle,opts+needle+'''    if a.resume_session and (a.attempt_offset != 8 or not a.initial_prompt_file):
        ap.error('8+4 continuation requires offset 8 and an explicit generic-feedback file')
    if not a.resume_session and a.attempt_offset:
        ap.error('fresh initial runs must start at attempt 1')
''')
    s=once(s,'rec["mem_on_entry"] = MC.clear(d, Path(a.mem_archive), tag="v2")','rec["mem_on_entry"] = ({"n": 0, "continuation": True, "preserved": MC.peek(d)} if a.resume_session else MC.clear(d, Path(a.mem_archive), tag="v2"))')
    s=once(s,'text = (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8")\n        first = True','text = (Path(a.initial_prompt_file).read_text(encoding="utf-8") if a.initial_prompt_file else (d / "_FIRST_MESSAGE.txt").read_text(encoding="utf-8"))\n        first = not a.resume_session')
    s=s.replace('CG.plan(CARDS, k)','CG.plan(CARDS, k + a.attempt_offset)')
    s=s.replace('ctxt, k)','ctxt, k + a.attempt_offset)')
    s=s.replace('CG.retry_text(stages, chk["why"], k)','CG.retry_text(stages, chk["why"], k + a.attempt_offset)')
    s=once(s,'                cards_rec = []\n                for stages, cmsg','                cards_rec = []\n                CG.strict_begin(d, k + a.attempt_offset)\n                for stages, cmsg')
    marker='            # —— 3. 追问**之前**的形式化系统 ——'
    block='''                    if not chk['ok']:
                        break
                if any(not item['ok'] for item in cards_rec):
                    rec['rounds'].append({'k': k, 'logical_attempt': k + a.attempt_offset,
                                          'protocol_valid': False, 'cards_gate': cards_rec})
                    rec['stop'] = 'protocol_blocked_cards'
                    break

'''
    s=once(s,marker,block+marker)
    s=once(s,'(k == 1 and play0["wall_s"] < 60)','(k == 1 and not a.resume_session and play0["wall_s"] < 60)')
    s=once(s,'        rec["totals"] = {','        rec["phase"] = "feedback4" if a.resume_session else "initial8"\n        rec["attempt_offset"] = a.attempt_offset\n        rec["totals"] = {')
    return s
edit(V2/'run_v2.py',patch_driver)
def patch_proof(s):
    needle='    if not rel:\n'
    text='''    if (d / 'cards/PROTOCOL-four-transforms.json').exists():
        import four_transforms_gate as FT
        res['four_transformations'] = FT.check_current(d)
        res['why'].extend(res['four_transformations']['why'])
        if res['why']: return res
'''
    return once(s,needle,text+needle)
edit(V2/'proof_gate.py',patch_proof)
# A uniform initial METHOD for both levels: no element-effect prior, no self-audit
# section and no discrepancy feedback before the locked eight-attempt checkpoint.
import importlib.util
spec=importlib.util.spec_from_file_location('method_four_compose',P2/'method_v7.py');mv=importlib.util.module_from_spec(spec);spec.loader.exec_module(mv)
base=(V2/'l5/METHOD_variant_2adf4911.md').read_text(encoding='utf-8')
method=mv.compose(base,'','`mathlib` **没有**。')
method=method.replace('与后续怀疑自审','；后续外部反馈维修只在初始八轮封存之后进行')
method+='''\n## 本轮四方向记录要求\n每次 attempt 的规则凝练阶段须逐项考虑四个方向，生成驱动要求的结构化记录并通过全量回归。\n不适用时必须给具体理由，不为凑齐四项而作无益变换；文件与理由齐全不等于语义等价已被证明。\n前八次不接收关于当前界是否正确的外部信号，也不额外触发内置怀疑/自审轮。\n'''
(R/'METHOD-initial8.md').write_text(method,encoding='utf-8')
method_repair=(P2/'METHOD_addendum_selfaudit.md').read_text(encoding='utf-8')
(R/'operator_only').mkdir(exist_ok=True)
(R/'operator_only/METHOD_selfaudit.md').write_text(method_repair,encoding='utf-8')
(R/'patches.json').write_text(json.dumps(patches,indent=2),encoding='utf-8')
print('Isolated branch patched:',len(patches),'native modules; no model calls or services launched.')
