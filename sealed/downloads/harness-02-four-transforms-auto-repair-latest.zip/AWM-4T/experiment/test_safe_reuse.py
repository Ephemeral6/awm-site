"""Offline invalidation tests. Fake compiler for boundaries; real regression tools.

test_real_lean_reuse.py separately exercises the real pinned compiler.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,types,unittest,py_compile
from unittest.mock import patch
R=Path(__file__).resolve().parent
AK=R/'harness/ARC-AGI/ours/benchmarks/armkit'
V2=AK.parent/'armkit-v2'
TOOLS=R/'harness/ARC-AGI/ours/sc25-selfaudit-v7/tools_v7'
sys.path[:0]=[str(AK),str(V2),str(TOOLS),str(R)]
import safe_lean_cache as S
import leancheck as L
import mutant_input_cache as M

class CompileTests(unittest.TestCase):
    def setUp(self):
        (R/'offline_out').mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=R/'offline_out',prefix='reuse-')
        self.base=Path(self.tmp.name);self.d=self.base/'case';self.d.mkdir()
        self.lean=self.d/'lean';self.lean.mkdir();self.calls=[]
        self.tool=self.base/'tool';self.tool.mkdir();(self.tool/'lean.exe').write_bytes(b'compiler-v1')
        (self.tool/'runtime.dll').write_bytes(b'runtime-v1')
        self.env=patch.dict(os.environ,{'AWM_ARCHIVE':str(self.base/'archive')});self.env.start()
        self.identity=patch.object(S,'toolchain_id',self.fake_id);self.identity.start()
        self.runner=patch.object(L,'run_lean',self.fake_compile);self.runner.start()
        self.put('Bottom.lean','def bottom : Nat := 0\n')
        self.put('Dep.lean','import Bottom\ndef dep : Nat := bottom\n')
        self.put('Main.lean','import Dep\ntheorem proof : dep = 0 := rfl\n#print axioms proof\n')
    def tearDown(self):
        S.clear();self.runner.stop();self.identity.stop();self.env.stop();self.tmp.cleanup()
    def put(self,rel,s):
        p=self.lean/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8');return p
    def fake_id(self,_):
        return dict(executable=str(self.tool/'lean.exe'),files={p.name:S.sha(p) for p in self.tool.iterdir()},environment_sha256=S.digest(dict(os.environ)))
    def fake_compile(self,roots,root,p,olean,timeout):
        self.calls.append((p.name,str(p),olean is not None))
        self.assertTrue(p.is_relative_to(self.base/'archive/safe_build'))
        if 'FAIL' in p.read_text(encoding='utf-8'):return 1,'error: simulated failure',.01
        if olean:olean.write_bytes(('operator artifact '+S.sha(p)).encode())
        return 0,"'proof' does not depend on any axioms\n",.01
    def check(self,**kwargs):return L.check_files(self.d,['lean/Main.lean'],**kwargs)['files'][0]
    def assert_miss(self,edit):
        self.check();n=len(self.calls);edit();r=self.check();self.assertFalse(r['cache_hit']);self.assertGreater(len(self.calls),n);return r
    def test_three_dispatches_compile_main_only_once(self):
        a,b,c=self.check(),self.check(),self.check()
        self.assertFalse(a['cache_hit']);self.assertTrue(b['cache_hit']);self.assertTrue(c['cache_hit'])
        self.assertEqual([x[0] for x in self.calls],['Bottom.lean','Dep.lean','Main.lean'])
        self.assertEqual(a['compiler_receipt'],b['compiler_receipt'])
    def test_source_edit_same_mtime_invalidates(self):
        p=self.lean/'Main.lean';stamp=p.stat()
        def edit():p.write_text(p.read_text()+'-- new text\n',encoding='utf-8');os.utime(p,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
        self.assert_miss(edit)
    def test_transitive_edit_same_mtime_invalidates(self):
        p=self.lean/'Bottom.lean';stamp=p.stat()
        def edit():p.write_text('def bottom : Nat := 1\n',encoding='utf-8');os.utime(p,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
        self.assert_miss(edit)
    def test_added_source_invalidates(self):self.assert_miss(lambda:self.put('Unused.lean','def extra := 1\n'))
    def test_removed_import_is_failure_not_hit(self):
        self.check();(self.lean/'Bottom.lean').unlink();r=self.check();self.assertFalse(r['compiles']);self.assertFalse(r['cache_hit'])
    def test_corpus_change_invalidates(self):self.assert_miss(lambda:(self.d/'transitions.jsonl').write_text('{}\n',encoding='utf-8'))
    def test_config_change_invalidates(self):self.assert_miss(lambda:(self.d/'config.json').write_text('{"budget":1}',encoding='utf-8'))
    def test_environment_change_invalidates(self):
        self.check();n=len(self.calls)
        with patch.dict(os.environ,{'AWM_TEST_INPUT':'different'}):r=self.check()
        self.assertFalse(r['cache_hit']);self.assertGreater(len(self.calls),n)
    def test_compiler_content_change_invalidates(self):self.assert_miss(lambda:(self.tool/'lean.exe').write_bytes(b'compiler-v2'))
    def test_runtime_dll_same_mtime_invalidates(self):
        p=self.tool/'runtime.dll';st=p.stat()
        def edit():p.write_bytes(b'runtime-v2');os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
        self.assert_miss(edit)
    def test_owned_artifact_tamper_rebuilds_dependencies_and_target(self):
        self.check();c=next(iter(S._CASES[str(self.d.resolve())]['contexts'].values()))
        artifact=c.shadow/'lean/Bottom.olean';artifact.write_bytes(b'tamper')
        n=len(self.calls);self.assertFalse(self.check()['cache_hit']);self.assertGreater(len(self.calls),n)
    def test_arena_forged_olean_never_used(self):
        (self.lean/'Bottom.olean').write_bytes(b'forged')
        self.assertTrue(self.check()['compiles']);self.assertEqual(self.calls[0][0],'Bottom.lean')
        self.assertFalse(any('forged' in str(x) for x in self.calls))
    def test_force_cold_never_hits(self):
        self.check();self.assertFalse(self.check(force_cold=True)['cache_hit']);self.assertTrue(self.check()['cache_hit'])
    def test_disable_flag_never_hits(self):
        self.check()
        with patch.dict(os.environ,{'AWM_DISABLE_COMPILE_REUSE':'1'}):self.assertFalse(self.check()['cache_hit'])
    def test_failure_is_not_cached(self):
        self.put('Main.lean','-- FAIL\n');self.assertFalse(self.check()['compiles']);n=len(self.calls)
        self.assertFalse(self.check()['cache_hit']);self.assertGreater(len(self.calls),n)
    def test_oom_is_not_cached_or_accepted(self):
        self.put('Main.lean','theorem proof : True := True.intro\n#print axioms proof\n')
        with patch.object(L,'run_lean',return_value=(137,'AWM_RESOURCE_LIMIT',.01)) as runner:
            self.assertFalse(self.check()['compiles']);self.assertFalse(self.check()['cache_hit']);self.assertEqual(runner.call_count,2)
    def test_cached_compilation_does_not_bypass_current_rule_or_transform_gate(self):
        import proof_gate as PG
        import four_transforms_gate as FT
        (self.d/'cards').mkdir()
        for name in ('PROTOCOL-v7h.json','PROTOCOL-four-transforms.json'):(self.d/'cards'/name).write_text('{}',encoding='utf-8')
        text='VERDICT: impossible_in_model_proved\nMAIN-THEOREM: lean/Main.lean : proof'
        good={'ok':True,'why':[]};bad={'ok':False,'why':['current receipt stale']}
        with patch.object(PG.SG,'check',return_value=good) as sg,patch.object(FT,'check_current',return_value=good) as ft:
            self.assertTrue(PG.check(self.d,text)['ok']);self.assertTrue(PG.check(self.d,text)['compile_cache_hit'])
            n=len(self.calls);sg.return_value=bad;self.assertFalse(PG.check(self.d,text)['ok']);self.assertEqual(len(self.calls),n)
            sg.return_value=good;ft.return_value=bad;self.assertFalse(PG.check(self.d,text)['ok']);self.assertEqual(len(self.calls),n)
    def test_cached_output_does_not_prove_another_named_theorem(self):
        import proof_gate as PG
        self.assertTrue(PG.check(self.d,'MAIN-THEOREM: lean/Main.lean : proof')['ok'])
        r=PG.check(self.d,'MAIN-THEOREM: lean/Main.lean : unproved')
        self.assertTrue(r['compile_cache_hit']);self.assertFalse(r['ok'])
    def test_dynamic_profile_uses_cold_checks(self):
        self.put('Main.lean','def dynamic : IO Unit := pure ()\n')
        self.assertFalse(self.check()['reuse_eligible']);self.assertFalse(self.check()['cache_hit'])
    def test_boundary_invalidation_cleans_snapshot(self):
        self.check();c=next(iter(S._CASES[str(self.d.resolve())]['contexts'].values()));shadow=c.shadow
        L.invalidate_case(self.d,'model call');self.assertFalse(shadow.exists());self.assertFalse(self.check()['cache_hit'])
    def test_other_case_cannot_hit(self):
        self.check();other=self.base/'case2';other.mkdir();(other/'lean').mkdir()
        for p in self.lean.glob('*.lean'):(other/'lean'/p.name).write_bytes(p.read_bytes())
        self.assertFalse(L.check_files(other,['lean/Main.lean'])['files'][0]['cache_hit'])
    def test_mutation_during_compile_fails_closed(self):
        original=self.fake_compile
        def edit(*a):
            r=original(*a);(self.d/'evidence.json').write_text('{"changed":true}',encoding='utf-8');return r
        with patch.object(L,'run_lean',edit):r=self.check()
        self.assertFalse(r['compiles']);self.assertIn('changed during',str(r['errors']))
    def test_root_resolution_order_is_in_key(self):
        alt=self.d/'alt';alt.mkdir();(alt/'Dep.lean').write_text('def dep := 0\n',encoding='utf-8')
        a=S.check_files(self.d,['lean/Main.lean'],[self.lean,alt],L.LEAN,self.fake_compile)[0]
        b=S.check_files(self.d,['lean/Main.lean'],[alt,self.lean],L.LEAN,self.fake_compile)[0]
        self.assertFalse(b['cache_hit']);self.assertNotEqual(a['compiler_receipt']['context_sha256'],b['compiler_receipt']['context_sha256'])
    def test_import_parser_rejects_unsupported_header(self):
        p=self.put('Other.lean','/- nested /- comment -/ -/\nmodule\npublic meta import Dep\n')
        self.assertEqual(S.imports(p),['Dep'])
        p.write_text('import Dep Bottom\n',encoding='utf-8')
        with self.assertRaises(ValueError):S.imports(p)
    def test_stale_built_dictionary_does_not_skip_new_dependency(self):
        self.check(built={'Bottom':{'rc':0}});self.put('Bottom.lean','-- FAIL\n')
        self.assertFalse(self.check(built={'Bottom':{'rc':0}})['compiles'])
    def test_production_fingerprint_hashes_library_contents(self):
        # Exercise the real fingerprint function on a tiny stand-in toolchain.
        lib=self.base/'lib/lean';lib.mkdir(parents=True);p=lib/'Std.olean';p.write_bytes(b'v1')
        self.identity.stop()
        try:
            a=S.toolchain_id(self.tool/'lean.exe');st=p.stat();p.write_bytes(b'v2');os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
            self.assertNotEqual(a,S.toolchain_id(self.tool/'lean.exe'))
        finally:self.identity.start()

class MutationTests(unittest.TestCase):
    def setUp(self):
        (R/'offline_out').mkdir(exist_ok=True);self.tmp=tempfile.TemporaryDirectory(dir=R/'offline_out',prefix='mut-cache-')
        self.base=Path(self.tmp.name);self.d=self.base/'case';self.d.mkdir();(self.d/'transitions.jsonl').write_text('{}\n',encoding='utf-8')
        self.folder=self.base/'tools';self.folder.mkdir();self.script=self.folder/'criteria_run.py';self.script.write_text('# generator1\n',encoding='utf-8');self.calls=0
        self.c=types.SimpleNamespace(__file__=str(self.script),SEED=7,MUT_CAP=10,MUT_CELLS=4,make_mutants=self.generate)
        self.env=patch.dict(os.environ,{'AWM_MUTANT_CACHE':str(self.base/'cache')});self.env.start();self.trs=[{'v':0}]
    def tearDown(self):self.env.stop();self.tmp.cleanup()
    def generate(self,trs):self.calls+=1;return [{'input':trs,'seed':self.c.SEED}]
    def get(self):return M.get(self.d,self.trs,self.c)
    def miss(self,edit):
        self.get();edit();_,info=self.get();self.assertFalse(info['hit']);self.assertEqual(self.calls,2)
    def test_same_inputs_hit_and_return_deep_copy(self):
        a,_=self.get();a[0]['input'][0]['v']=999;b,i=self.get();self.assertTrue(i['hit']);self.assertEqual(b[0]['input'][0]['v'],0);self.assertEqual(self.calls,1)
    def test_corpus_append_miss(self):self.miss(lambda:(self.d/'transitions.jsonl').write_text('{}\n{}\n',encoding='utf-8'))
    def test_normalized_inputs_change_miss(self):self.miss(lambda:self.trs.append({'v':1}))
    def test_seed_change_miss(self):self.miss(lambda:setattr(self.c,'SEED',8))
    def test_cap_change_miss(self):self.miss(lambda:setattr(self.c,'MUT_CAP',9))
    def test_cell_config_change_miss(self):self.miss(lambda:setattr(self.c,'MUT_CELLS',5))
    def test_generator_change_miss(self):self.miss(lambda:self.script.write_text('# generator2\n',encoding='utf-8'))
    def test_python_identity_change_miss(self):
        self.get()
        with patch.object(M.sys,'version','different-python'):_a,i=self.get()
        self.assertFalse(i['hit'])
    def test_corrupt_payload_regenerates(self):
        self.get();p=next((self.base/'cache').rglob('*.json'));rec=json.loads(p.read_text());rec['mutants']=[];p.write_text(json.dumps(rec),encoding='utf-8')
        _,i=self.get();self.assertFalse(i['hit']);self.assertIn('corrupt',i['reason']);self.assertEqual(self.calls,2)
    def test_case_isolation(self):
        self.get();d=self.base/'other';d.mkdir();(d/'transitions.jsonl').write_text('{}\n',encoding='utf-8')
        _,i=M.get(d,self.trs,self.c);self.assertFalse(i['hit'])
    def test_disabled_generation_still_runs(self):
        self.get()
        with patch.dict(os.environ,{'AWM_DISABLE_MUTANT_CACHE':'1'}):_,i=self.get()
        self.assertFalse(i['hit']);self.assertEqual(self.calls,2)
    def test_cache_cannot_be_inside_case(self):
        with patch.dict(os.environ,{'AWM_MUTANT_CACHE':str(self.d/'cache')}):
            with self.assertRaises(ValueError):self.get()
    def test_generator_concurrent_change_rejected(self):
        def edit(trs):self.script.write_text('# changed\n',encoding='utf-8');return []
        self.c.make_mutants=edit
        with self.assertRaises(ValueError):self.get()
    def test_corpus_concurrent_change_rejected(self):
        def edit(trs):(self.d/'transitions.jsonl').write_text('{}\n{}\n',encoding='utf-8');return []
        self.c.make_mutants=edit
        with self.assertRaises(ValueError):self.get()
    def test_hit_still_runs_complete_current_rules_and_compare(self):
        (self.d/'objects').mkdir();(self.d/'rule/test').mkdir(parents=True)
        (self.d/'objects/__init__.py').write_text('from dataclasses import dataclass\n@dataclass\nclass World:\n v:int\nclass ParseError(Exception):pass\ndef parse(f):return World(f[0][0])\n',encoding='utf-8')
        rule=self.d/'rule/test/change.py';rule.write_text('def scope_(p,a,n,c=None):return None\ndef assert_(p,a,n,c=None):return "TRUE" if n[0][0]==p[0][0]+1 else "FALSE"\n',encoding='utf-8')
        (self.d/'transitions.jsonl').write_text(json.dumps(dict(tid='sample',prev=[[0]],nxt=[[1]],action='ACTION1',ctx={}))+'\n',encoding='utf-8')
        def run(out,*args):
            p=subprocess.run([sys.executable,'-I',str(TOOLS/'rejection_check.py'),'--out',out,*args],cwd=self.d,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
            self.assertTrue((self.d/out).exists(),p.stdout+p.stderr)
            return p,json.loads((self.d/out).read_text(encoding='utf-8'))
        p,a=run('before.json');self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        p,b=run('after.json','--compare','before.json');self.assertEqual(p.returncode,0,p.stdout+p.stderr);self.assertTrue(b['mutation_input_cache']['hit'])
        for key in ('real_rejected','mutant_rejected','silent','verdict_matrix','rule_paths','transitions'):
            self.assertEqual(a[key],b[key],key)
        rule.write_text('def scope_(p,a,n,c=None):return None\ndef assert_(p,a,n,c=None):return "TRUE"\n',encoding='utf-8')
        p,c=run('bad.json','--compare','before.json');self.assertEqual(p.returncode,2,p.stdout+p.stderr);self.assertTrue(c['mutation_input_cache']['hit'])
        self.assertFalse(c['ok'])
    def test_existing_python_bytecode_cannot_hide_same_mtime_same_size_rule_edit(self):
        (self.d/'objects').mkdir();(self.d/'rule/test').mkdir(parents=True)
        (self.d/'objects/__init__.py').write_text('from dataclasses import dataclass\n@dataclass\nclass World:\n v:int\nclass ParseError(Exception):pass\ndef parse(f):return World(f[0][0])\n',encoding='utf-8')
        rule=self.d/'rule/test/change.py';old='def scope_(p,a,n,c=None):return None\ndef assert_(p,a,n,c=None):return "TRUE" \n'
        rule.write_text(old,encoding='utf-8');py_compile.compile(str(rule),doraise=True);stamp=rule.stat()
        fresh=old.replace('"TRUE" ','"FALSE"');self.assertEqual(len(old),len(fresh));rule.write_text(fresh,encoding='utf-8');os.utime(rule,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
        (self.d/'transitions.jsonl').write_text(json.dumps(dict(tid='sample',prev=[[0]],nxt=[[1]],action='ACTION1',ctx={}))+'\n',encoding='utf-8')
        p=subprocess.run([sys.executable,'-I',str(TOOLS/'rejection_check.py'),'--out','actual.json'],cwd=self.d,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        report=json.loads((self.d/'actual.json').read_text(encoding='utf-8'))
        self.assertEqual(next(iter(report['verdict_matrix'].values()))['sample'],'FALSE')

class DriverContractTests(unittest.TestCase):
    def test_boundaries_and_final_cold_check_are_present(self):
        s=(V2/'run_v2.py').read_text(encoding='utf-8')
        for text in ('before model invocation','after model invocation','round boundary','case completed','force_cold=True'):self.assertIn(text,s)
        self.assertIn('REFERENCE_INTERVIEW',s)
    def test_compiler_cache_does_not_replace_gate_checks(self):
        import proof_gate as PG
        import inspect
        s=inspect.getsource(PG.check)
        self.assertIn('FT',s);self.assertIn('SG',s);self.assertIn('LC.check_files',s)
    def test_mutant_cache_never_stores_evaluation_or_gate(self):
        s=(TOOLS/'mutant_input_cache.py').read_text(encoding='utf-8')
        for forbidden in ('C.rejections(',"'ok':",'load_rules('):self.assertNotIn(forbidden,s)

if __name__=='__main__':unittest.main(verbosity=2)
