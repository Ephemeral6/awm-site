"""Prompt alignment tests. No real model or server calls."""
from pathlib import Path
import unittest,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));import protocol as P
sys.path[:0]=[str(P.AK),str(P.V2)]
class PromptOrderTests(unittest.TestCase):
    def test_feedback_does_not_require_new_audit_before_proof(self):
        a,b=P.repair_interviews();self.assertNotIn("Update work/selfaudit/ with this attempt's probes before answering.",a);self.assertIn('only after checking',a)
    def test_feedback_uses_consistent_verdict_vocabulary(self):
        a,b=P.repair_interviews()
        for s in (a,b):self.assertIn('VERDICT: winnable | impossible | impossible_in_model_proved | impossible_in_model | undecided',s)
    def test_card_dependency_check_distinct_from_postproof_audit(self):
        import cards_gate as C
        cards=C.load(P.CARDS)
        for k in (1,2,8,9,12):
            for stages,msg in C.plan(cards,k):
                self.assertNotIn('Before any impossibility claim, audit every deferred rule',msg)
                if '03' in stages or '05' in stages:
                    self.assertIn('证前模型一致性检查' if k==1 else 'only AFTER the driver checks the current theorem',msg)
    def test_all_exported_stage_messages_equal_runtime_templates(self):
        import cards_gate as C
        cards=C.load(P.CARDS)
        for k in range(1,13):
            for stages,msg in C.plan(cards,k):self.assertEqual((R/'prompts'/f'attempt-{k:02d}-stage-{"+".join(stages)}.txt').read_text(encoding='utf-8'),msg)
    def test_no_attempt4_preproof_fallback_in_subject_method(self):
        text=(R/'METHOD-initial8.md').read_text(encoding='utf-8');self.assertNotIn('到第 4 次 attempt 结束还没有闭合证明：照样',text);self.assertIn('METHOD提前介绍方法，不代表要求提前执行',text)
    def test_certificate_trigger_matches_case_insensitive_verdict_parser(self):
        import proof_first_audit as A
        self.assertTrue(A.certified('VERDICT: IMPOSSIBLE_IN_MODEL_PROVED',dict(ok=True,file='lean/Main.lean',theorem='Main')))
if __name__=='__main__':unittest.main(verbosity=2)
