"""Generate manifests, review bundles and offline verification. No experiment execution."""
from pathlib import Path
import json,hashlib,difflib,ast,shutil
R=Path(__file__).resolve().parent
shutil.copy2(R/'four_transforms_gate.py',R/'harness/ARC-AGI/ours/benchmarks/armkit-v2/four_transforms_gate.py')
src=json.loads((R/'source-manifest.json').read_text(encoding='utf-8'))
original=Path(src['source']);original=original if original.is_absolute() else (R/original).resolve();H=R/'harness';different=[];source_drift=[]
for rel,sha in src['files'].items():
    p=original/rel
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:source_drift.append(rel)
    q=H/rel
    if q.exists() and hashlib.sha256(q.read_bytes()).hexdigest()!=sha:different.append(rel)
patches=[]
for rel in different:
    before=original/rel
    # v7h before_patch protects exact originals even if a source folder later changes.
    stored=R/'before_patch'/'harness'/rel
    if not stored.exists() and before.exists() and hashlib.sha256(before.read_bytes()).hexdigest()==src['files'][rel]:
        stored.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(before,stored)
    if stored.exists():
        a=stored.read_text(encoding='utf-8');b=(H/rel).read_text(encoding='utf-8')
        (R/'diffs'/((H/rel).name+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='v7h/'+rel,tofile='4t8plus4/'+rel)),encoding='utf-8')
    patches.append({'path':rel,'before_sha256':src['files'][rel],'after_sha256':hashlib.sha256((H/rel).read_bytes()).hexdigest()})
(R/'patches.json').write_text(json.dumps(patches,indent=2),encoding='utf-8')
parts=['# 实际发送的提示全文（实验者核验用）\n\n不把此文件下发给受试；首条实际消息由build.py将核心题面、多轮说明和框架附加说明拼接，METHOD是跑场文件。占位符只用于状态/轮次及真实失败原因，运行时原文逐条落prompt log。\n\n']
for p in sorted((R/'prompts').glob('*')):
    if p.suffix not in ('.md','.txt'):continue
    parts+=['## '+p.name+'\n\n````text\n',p.read_text(encoding='utf-8'),'\n````\n\n']
(R/'PROMPTS-ALL.md').write_text(''.join(parts),encoding='utf-8')
old=R/'prompts_old';old.mkdir(exist_ok=True)
E=R.parent/'paper_evidence_20261023'
shutil.copy2(E/'02_awm_main/m15fw-case-9ec8d4/frozen_pre_hint_model/METHOD.md',old/'METHOD-L4-9ec8d4.md')
shutil.copy2(H/'ARC-AGI/ours/benchmarks/armkit-v2/l5/METHOD_variant_2adf4911.md',old/'METHOD-L5-closed-v4.md')
v2=H/'ARC-AGI/ours/benchmarks/armkit-v2';ak=v2.parent/'armkit'
round_old=(ak/'ASK_round.txt').read_text(encoding='utf-8')+(v2/'ASK_round_lean.txt').read_text(encoding='utf-8')+(ak/'ASK_round_tail.txt').read_text(encoding='utf-8')
(old/'ASK-round-initial.txt').write_text(round_old,encoding='utf-8')
x=json.loads((E/'05_awm_repair/strict_four_attempts/L4-m15fw-case-9ec8d4/run.json').read_text(encoding='utf-8'))
for key,text in x['texts'].items():
    (old/('actual-L4-v7-'+key+'.txt')).write_text(text,encoding='utf-8')
y=json.loads((E/'05_awm_repair/within_four_attempts_L5/run.json').read_text(encoding='utf-8'))
for i,t in enumerate(y['turns'],1):
    if 'prompt' in t:(old/f'actual-L5-v3-turn{i}-input.txt').write_text(t['prompt'],encoding='utf-8')
delta=['# 旧输入 → 新输入：逐字差异\n\n原L4 selected-v7的实际texts取自run.json；L5 selected-v3的实际输入另列，因为四次attempt在一次CLI continuation内，不能伪造逐attempt独立prompt。新版feedback是统一新协议，参考历史通用M1/M2/M3方案并作显式改造，不声称复制了旧两条完全相同的提示。\n\n']
for a,b in [('METHOD-L5-closed-v4.md','00-METHOD-initial8.md'),('ASK-round-initial.txt','20-round-interview.txt'),('actual-L4-v7-M1.txt','30-feedback-first.txt'),('actual-L4-v7-M2.txt','32-feedback-round.txt'),('actual-L4-v7-M3.txt','33-feedback-final.txt')]:
    delta+=['## '+a+' → '+b+'\n\n```diff\n',''.join(difflib.unified_diff((old/a).read_text(encoding='utf-8').splitlines(True),(R/'prompts'/b).read_text(encoding='utf-8').splitlines(True),fromfile='old/'+a,tofile='new/'+b)),'\n```\n\n']
(R/'PROMPT-DELTA.md').write_text(''.join(delta),encoding='utf-8')
method_before=H/'ARC-AGI/ours/benchmarks/armkit-v2/l5/METHOD_variant_2adf4911.md'
(R/'diffs/METHOD-base-to-initial8.diff').write_text(''.join(difflib.unified_diff(method_before.read_text(encoding='utf-8').splitlines(True),(R/'METHOD-initial8.md').read_text(encoding='utf-8').splitlines(True),fromfile='old-L5-closed-v4-METHOD',tofile='new-uniform-initial8-METHOD')),encoding='utf-8')
syntax=[]
for f in [R/'protocol.py',R/'run_experiment.py',R/'test_offline.py',R/'grade_results.py',R/'audit_history.py',R/'four_transforms_gate.py']+[H/x for x in different if x.endswith('.py')]:
    ast.parse(f.read_text(encoding='utf-8-sig'));syntax.append(str(f.relative_to(R)))
fixtures=[]
for d in (R/'offline_out').glob('stage-*/*'):
    if (d/'_FIRST_MESSAGE.txt').exists():fixtures.append(dict(path=str(d),first_message_sha256=hashlib.sha256((d/'_FIRST_MESSAGE.txt').read_bytes()).hexdigest()))
result=dict(models_called=False,game_servers_started=False,source_files_checked=len(src['files']),source_drift=source_drift,isolated_existing_files_modified=different,syntax_checked=syntax,tests=json.loads((R/'offline_out/test-results.json').read_text()),offline_fixtures=fixtures,prompt_files=len(json.loads((R/'prompts/manifest.json').read_text())),limitations=['No live model/authentication smoke was run.','Mechanical receipts do not establish semantic equivalence or universal properties.','No new experimental proof or bound is counted.'])
(R/'VALIDATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('syntax_checked','isolated_existing_files_modified','offline_fixtures')},ensure_ascii=True))
