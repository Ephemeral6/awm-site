# Proof-first v2

优先阅读包根使用说明书与协议变更与统计口径。旧REPORT/HANDOFF说明旧协议，不能照其关闭证后自审。主入口run_batch.py或run_experiment.py；先六条初始8轮，再统计并按需追加4轮。
