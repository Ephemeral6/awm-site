"""Offline proof-before-audit ordering, artifact binding and actual driver-loop tests."""
from pathlib import Path
import json,sys,tempfile,unittest,copy,contextlib,io
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
import proof_first_audit as A
import protocol as P

class AuditTests(unittest.TestCase):
    def setUp(self):
        base=R/'offline_out';base.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(prefix='pfa-',dir=base);self.root=Path(self.temp.name)
        assert self.root.resolve().is_relative_to(base.resolve())
        self.d=self.root/'arena';self.d.mkdir();self.archive=self.root/'archive'
        for rel,text in [('rule/move.py','# current model'),('lean/Main.lean','theorem Main : True := True.intro'),('transitions.jsonl','{"tid":"t1"}\n')]:
            p=self.d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
        self.text='MAIN-THEOREM: lean/Main.lean : Main\nVERDICT: impossible_in_model_proved'
        self.proof=dict(ok=True,file='lean/Main.lean',theorem='Main',axioms=[])
        self.calls=0;self.actions=0
    def tearDown(self):self.temp.cleanup()
    def certificate(self,k=1):return A.seal(self.d,k,self.text,self.proof,self.archive)
    def record(self,cert,k=1,has_next=True,prior=None):
        return dict(attempt=k,certificate_sha256=cert['sha256'],rules=[dict(path='rule/move.py',rule_name='move',load_bearing=True,rationale='Recorded moves leave a distinct action context insufficiently tested. ',relaxations=[dict(original='cost one',small='free once',widest='free in uncovered contexts',effect='unknown',compatibility_evidence_ids=['t1'])],coverage='covered: observed moves t1; uncovered: alternative trigger order')],prior_probe_results=[dict(probe_id=x['id'],outcome='UNTESTED',reason='No evidence for this probe was obtained in the game budget.',evidence_ids=[]) for x in (prior or {}).get('next_probes',[])],next_probes=[dict(id=f'a{k}.move',rule_path='rule/move.py',prediction_original='cost one',prediction_relaxed='free',actions_or_plan='Reach the differing trigger context and observe its charged cost.',target_attempt=k+1 if has_next else None)])
    def write(self,rec):
        folder=self.d/'work/selfaudit';folder.mkdir(parents=True,exist_ok=True);k=rec['attempt']
        (folder/f'attempt_{k:02d}.json').write_text(json.dumps(rec),encoding='utf-8')
        (folder/f'attempt_{k:02d}.md').write_text('Concrete sensitivity analysis and pending trigger probe. '*5,encoding='utf-8')
    def check(self,rec,cert,**kw):self.write(rec);return A.check(self.d,rec['attempt'],cert,kw.get('previous'),kw.get('has_next',True))
    def test_no_audit_even_attempt4_without_closed_proof(self):
        out=A.run(self.d,4,self.text,dict(ok=False),lambda *a:self.fail('Must not call model'),lambda:0,self.archive,True)
        self.assertFalse(out['triggered']);self.assertFalse(self.archive.exists())
    def test_withdrawn_or_undecided_cannot_be_certificate(self):
        self.assertFalse(A.certified('VERDICT: undecided',self.proof));self.assertFalse(A.certified(self.text,dict(self.proof,withdrawn='undecided')))
    def test_valid_audit_bound_to_snapshot(self):
        c=self.certificate();r=self.record(c);self.assertTrue(self.check(r,c)['ok'])
        self.assertTrue((self.archive/'attempt_01/sources/lean/Main.lean').exists())
    def test_no_duplicate_certificate_overwrite(self):
        self.certificate()
        with self.assertRaises(ValueError):self.certificate()
    def test_wrong_certificate_rejected(self):
        c=self.certificate();r=self.record(c);r['certificate_sha256']='fake';self.assertFalse(self.check(r,c)['ok'])
    def test_omitted_rule_rejected(self):
        (self.d/'rule/refund.py').write_text('# refund');c=self.certificate();self.assertFalse(self.check(self.record(c),c)['ok'])
    def test_unknown_sensitivity_not_irrelevant(self):
        c=self.certificate();r=self.record(c);r['rules'][0]['load_bearing']=False;self.assertFalse(self.check(r,c)['ok'])
    def test_missing_loadbearing_probe_rejected(self):
        c=self.certificate();r=self.record(c);r['next_probes']=[];self.assertFalse(self.check(r,c)['ok'])
    def test_fake_relaxation_evidence_rejected(self):
        c=self.certificate();r=self.record(c);r['rules'][0]['relaxations'][0]['compatibility_evidence_ids']=['invented'];self.assertFalse(self.check(r,c)['ok'])
    def test_model_change_during_audit_invalidates_current_receipt(self):
        c=self.certificate();(self.d/'rule/move.py').write_text('# loosened without evidence');self.assertFalse(self.check(self.record(c),c)['ok'])
        self.assertEqual((self.archive/'attempt_01/sources/rule/move.py').read_text(),'# current model')
    def test_terminal_audit_has_no_invented_next_attempt(self):
        c=self.certificate(8);r=self.record(c,8,False);self.assertTrue(self.check(r,c,has_next=False)['ok'])
        r['next_probes'][0]['target_attempt']=9;self.assertFalse(self.check(r,c,has_next=False)['ok'])
    def test_prior_probe_needs_explicit_result(self):
        c=self.certificate();prior=self.record(c);r=self.record(c,prior=prior);r['prior_probe_results']=[];self.assertFalse(self.check(r,c,previous=prior)['ok'])
    def test_confirmed_probe_needs_real_observation(self):
        c=self.certificate();prior=self.record(c);r=self.record(c,prior=prior);r['prior_probe_results'][0]['outcome']='CONFIRMED';self.assertFalse(self.check(r,c,previous=prior)['ok'])
    def drive(self,msg,n):
        self.calls+=1;c=json.loads((self.archive/'attempt_01/certificate.json').read_text())
        self.assertTrue(c['proof_gate']['ok']);cert=dict(sha256=A.sha(self.archive/'attempt_01/certificate.json'))
        self.write(self.record(cert));return dict(returncode=0,text='Audit planned; unresolved rules retained.')
    def test_real_helper_call_seals_before_message(self):
        r=A.run(self.d,1,self.text,self.proof,self.drive,lambda:self.actions,self.archive,True)
        self.assertTrue(r['ok']);self.assertEqual(self.calls,1);self.assertTrue((self.archive/'state.json').exists())
    def test_audit_cannot_spend_game_action(self):
        def f(msg,n):r=self.drive(msg,n);self.actions+=1;return r
        r=A.run(self.d,1,self.text,self.proof,f,lambda:self.actions,self.archive,True)
        self.assertFalse(r['ok']);self.assertEqual(self.calls,1)
    def test_reset_cannot_escape_action_counter(self):
        count=[0]
        def f(msg,n):r=self.drive(msg,n);count[0]+=1;return r
        r=A.run(self.d,1,self.text,self.proof,f,lambda:0,self.archive,True,resets=lambda:count[0])
        self.assertFalse(r['ok']);self.assertEqual(r['game_action_delta'],0);self.assertEqual(r['reset_delta'],1)
    def test_resource_failure_retains_certificate_without_counting_audit_success(self):
        def f(msg,n):self.drive(msg,n);return dict(returncode=137,text='',resource_blocked=True)
        r=A.run(self.d,1,self.text,self.proof,f,lambda:0,self.archive,True)
        self.assertFalse(r['ok']);self.assertTrue(Path(r['certificate']['path']).exists())
    def test_audit_cannot_replace_verdict(self):
        def f(msg,n):self.drive(msg,n);return dict(returncode=0,text='VERDICT: undecided')
        r=A.run(self.d,1,self.text,self.proof,f,lambda:0,self.archive,True,retries=0)
        self.assertFalse(r['ok'])

class DriverTests(unittest.TestCase):
    def call(self,mode,resume=False):
        from test_offline import DriverIntegrationTests
        output=io.StringIO();output.buffer=None
        with contextlib.redirect_stdout(output):return DriverIntegrationTests().run_driver(mode,resume,audit=True)
    def test_checked_impossibility_triggers_audit_after_proof(self):
        r,c=self.call('certified_audit');self.assertTrue(r['protocol_valid']);self.assertEqual(len(r['rounds']),8)
        self.assertTrue(all(x['proof_first_audit']['triggered'] and x['proof_gate']['ok'] for x in r['rounds']))
    def test_missing_proof_stops_without_any_audit_model_call(self):
        r,c=self.call('proof_fail');self.assertFalse(r['protocol_valid']);self.assertFalse(any(x.get('audit_model_call') for x in c))
    def test_undecided_does_not_trigger_premature_audit(self):
        r,c=self.call('ok');self.assertTrue(r['protocol_valid']);self.assertFalse(any(x.get('audit_model_call') for x in c))
    def test_audit_failure_retains_prior_proof_and_stops(self):
        r,c=self.call('audit_fail');self.assertEqual(r['stop'],'protocol_blocked_postproof_audit');self.assertEqual(len(r['rounds']),1);self.assertTrue(r['rounds'][0]['proof_gate']['ok'])
    def test_same_session_repair_keeps_new_audit_order(self):
        r,c=self.call('certified_audit',True);self.assertEqual([x['logical_attempt'] for x in r['rounds']],[9,10,11,12]);self.assertFalse(any(x['first'] for x in c))
    def test_wrong_low_bound_uses_only_true_neutral_feedback(self):
        r=dict(protocol_valid=True,stop='exhausted',rounds=[{}]*8)
        from device_support import canonical_record_sha
        d=dict(status='wrong_low_bound',normalized_engine_bound=18,initial_record_sha256=canonical_record_sha(r),evidence='Exact original subject statement and declared cost convention checked.')
        self.assertEqual(P.adjudicate(r,d,4),'eligible_feedback4');self.assertNotIn('cheaper',P.feedback_text().lower())

if __name__=='__main__':unittest.main(verbosity=2)
