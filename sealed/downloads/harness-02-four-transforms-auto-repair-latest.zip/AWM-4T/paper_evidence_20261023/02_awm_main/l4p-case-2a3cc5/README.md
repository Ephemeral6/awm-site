# L4 / Claude Opus 5.5 + AWM / 2a3cc5

- **实验类别**：主表：AWM原始实验
- **关卡/受试**：L4 / Claude Opus 5.5 + AWM
- **论文位置**：主表原始阶段
- **预算/轮次**：3次（第三次后停止）
- **结果**：19；第三次后提前停止，无最终访谈
- **最终声明**：no final interview
- **注意**：第3次后停止；协议版本及元素先验与其他run有区别。
- **初始数值计分**：按论文口径记正确

## 从哪里检查

1. [受试逐轮/汇总答复](session_text.json)。这是阅读入口。
2. [原始JSON / 会话提取](session_text.json)。摘录与索引有歧义时以原始记录为准。
3. [本阶段主证明](proof_sources/L4ModelV3.lean)；主定理 `L4.V3.never_wins`。
   Stopped after attempt3; element prior/protocol version differs; console plus dedicated raw session.
- [既有主定理/公理核查输出](proof_sources/_check.out)。
- [原始游戏服务记录](server)。
- [完整证明源码目录](proof_sources)。

[返回本类实验](../README.md) · [返回实验总表](../../EXPERIMENTS.md)
