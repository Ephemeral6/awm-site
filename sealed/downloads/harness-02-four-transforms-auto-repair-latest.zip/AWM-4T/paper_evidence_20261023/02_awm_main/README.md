# 02 主表：AWM原始实验

6条：L4/L5 × 各3次。2a3cc5在第3次后停止。模型证明与数值正确性分开读。

| 关卡 / 受试 / case | 轮次 | 结果 | 使用范围 |
|---|---|---|---|
| [L4 / Claude Opus 5.5 + AWM / 2a3cc5](l4p-case-2a3cc5/README.md) | 3次（第三次后停止） | 19；第三次后提前停止，无最终访谈 | 主表原始阶段 |
| [L4 / Claude Opus 5.5 + AWM / 69fe87](m15fw-case-69fe87/README.md) | 8次 | impossible；界：19 | 主表原始阶段 |
| [L4 / Claude Opus 5.5 + AWM / 9ec8d4](m15fw-case-9ec8d4/README.md) | 8次 | impossible；界：20 | 主表原始阶段 |
| [L5 / Claude Opus 5.5 + AWM / 284967](l5d-case-284967/README.md) | 8次 | impossible_in_model_proved；界：37 (winning move charged) | 主表原始阶段 |
| [L5 / Claude Opus 5.5 + AWM / 4f4628](l5d-case-4f4628/README.md) | 8次 | impossible_in_model_proved；界：36 | 主表原始阶段 |
| [L5 / Claude Opus 5.5 + AWM / 977714](l5d-case-977714/README.md) | 8次 | impossible_in_model_proved；界：47 | 主表原始阶段 |

[返回实验总表](../EXPERIMENTS.md)
