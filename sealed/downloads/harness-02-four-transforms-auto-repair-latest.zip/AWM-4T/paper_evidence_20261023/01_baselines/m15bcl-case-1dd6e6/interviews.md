## Attempt 1

**1. What happened on level 4**

The board had an exit on the right, blocked by a door. A switch box stood at the top of a corridor two cells wide, and destroying it opens the door. You destroy it by setting the bottom panel to a vertical line, which fires a shot in the direction of your last move.

I used up a lot of the timer before getting anywhere:
- I made one accidental move as the level began.
- I fired upward with the full-size 4×4 marker. The shot was 4 wide, couldn't enter the 2-wide corridor and stopped. That cost a move plus three clicks.
- Only then did I set the panel to the plus shape, which shrinks the marker to 2×2, and step it under the corridor.
- By that point there were only about 8 moves left. I gambled on reaching a timer-coloured pickup, hoping it would refill the timer, but each move was now draining 4 rows instead of 2, and the timer ran out short of it.

The cause of failure was spending actions on trial and error: the wasted shot and the late shrink.

**2. Can it be beaten?**

I think so. The plan, starting with the 4×4 marker at rows 29–32, columns 37–40 (that is where it was after my stray move, so the true start may be one step higher):
1. Click the four edge cells of the panel to make the plus shape; the marker shrinks to 2×2, keeping its top-left corner.
2. Move left 3 times to column 31, which lines up with the corridor.
3. Move up once, so the last move points up.
4. Click the three centre-column cells to fire; the shot should go up the corridor, destroy the switch and open the door.
5. Move down to the door's rows, then right about 13 times through the doorway to the exit.

That is roughly 25 actions. Things I still need to check:
- Whether the shot will now pass up the narrow corridor. Level 3 suggests it will, once it is aligned.
- The real timer budget. A move cost 2 rows early in the level and 4 rows late; I don't know if clicks, the panel effects, or the marker's size change the cost.
- Whether the shrunk marker steps 2 cells at a time all the way to the exit.
- If the budget is short, whether the timer-coloured pickup really refills it, and how to reach it cheaply.

**3. Next attempt**

I'll make no stray moves, run the plan above exactly, and check the timer after every action. If the rate projects that it will run out before the exit, I'll detour to the pickup early, while there are still enough moves left to do it.

VERDICT: winnable
CONFIDENCE: 60

## Attempt 2

**1. What happened on level 4**

On level 4 a 4×4 marker has to reach an exit on the right. A door blocks the way, and it opens only when you shoot a switch box at the top of a 2-wide corridor above the board. I confirmed this time that shooting the door directly does nothing. A 4-wide shot can't get into that corridor, so the marker has to be shrunk to 2×2 first, using the plus pattern (4 clicks). Then it must be lined up under the corridor, moved up once so the shot fires upward, and fired (3 clicks).

The timer is the problem. It drains about 3.5 of its 64 rows per action, and each completed panel pattern costs about one extra action's worth. That makes a full bar about 18 actions. The timer-coloured pickup on the board adds about 32 rows, roughly 9 actions. Repeating the plus pattern regrows the marker to 4×4, which moves 4 cells per step instead of 2.

I shrank the marker, saw that the remaining route wouldn't fit, took the pickup and tested the door and the regrow. Then the timer ran out. The failure comes down to the action budget: every route I've found costs more than the timer allows.

**2. Can it be beaten?**

I can't tell. These are my best estimates, counting each completed pattern as one extra unit:
- **Cheapest route without the pickup: about 26 units, against a budget of about 18.** From the start (4×4 at rows 25–28, columns 37–40):
  1. Left 2, down 1, to reach (29,29).
  2. Shrink (4 clicks + 1).
  3. Down 1, right 1, up 1, to reach (29,31) with the last move up.
  4. Shoot (3 clicks + 1).
  5. Regrow (4 clicks + 1).
  6. Right 6 to the exit.
- **Cheapest route with the pickup: about 32 units, against at most about 28.** Collecting it as 4×4 means going to (33,21), a detour of about 6 moves.

So under my cost model the level is short by about 4–8 units.

What this rests on:
- **Established:** the cost per action (measured across both attempts at 3.5–3.7 rows), the step sizes, that the shot follows the last move, that the door can't be shot, that the 4-wide shot was blocked at columns 29–32, that the plus pattern regrows the marker, and the pickup's effect (12 rows went to 44).
- **Assumed:** whether the refill is capped at 64; whether a completed pattern really costs an extra unit; and that no other mechanic exists.

A level designed to be unwinnable seems unlikely, so I probably haven't found some mechanic. Possibilities include a combined pattern (plus shape plus centre cell) that shrinks and shoots in one go, a different shot rule, or a cheaper way to the exit. Testing these would settle it.

**3. Next attempt**

I'll start by checking the cheapest unknowns, measuring the timer after every action:
- whether clicking the plus pattern together with the centre cell (5 clicks) both shrinks and fires;
- whether a completed pattern costs extra.

Then I'll run the 26-unit route above. If the projection runs short, I'll take the pickup, ideally when the bar is below half so none of the refill is lost.

VERDICT: undecided
CONFIDENCE: 40

## Attempt 3

**1. What happened on level 4**

On level 4 the marker has to reach an exit on the right, behind a door. The door opens only when a shot destroys a switch box at the top of a corridor two cells wide. To get there, the marker must:
- shrink from 4×4 to 2×2 using the plus pattern (4 clicks);
- stand at column 31 under the corridor, with its last move upward;
- fire using the vertical-line pattern (3 clicks).

This attempt confirmed the following:
- The 2×2 shot does travel up the corridor and destroy the switch, which opens the door.
- The panel only fires on an exact match. Clicking the plus shape and the centre cell together did nothing.
- Unmatched clicks stay on the panel, so I could unclick the two side cells and leave exactly the vertical line, which fired.

The door opened just as the timer hit zero, and the next move ended the game. It failed on the action budget. Each action costs about 3.4 of the timer's 64 rows, and each completed pattern costs about 4.6 rows more. A full bar is therefore roughly 18 plain actions.

**2. Can it be beaten?**

I cannot tell either way, although my measurements say no.

What I'm claiming: none of the routes I know fits the timer.
- **Cheapest route without the pickup: about 96 rows, against 64.**
  1. Left 2 to column 29.
  2. Shrink.
  3. Right 1, then up 1, so the 2×2 sits at column 31 with an upward last move.
  4. Shoot.
  5. Down 3 to the corridor's rows.
  6. Regrow to 4×4.
  7. Right 6 to the exit.

  That is 24 actions and 3 completed patterns.
- **Cheapest route that collects the pickup: about 113 rows, against at most about 96.** The pickup adds about 32 rows, but collecting it as a 4×4 means an extra 4–6 moves.
- **Either way it is short by roughly 5–9 actions.**

What I measured directly:
- the rows each action costs, across three attempts;
- the step sizes: 4 cells for the 4×4 marker, 2 for the 2×2;
- that the shot needs a 2×2 marker at column 31;
- that the door cannot be shot;
- that repeating the plus pattern regrows the marker;
- the pickup's effect: 12 rows became 44.

What I assumed and didn't check:
- whether the refill is capped at 64 rows;
- that there is no other mechanic, such as a cheaper way to fire or move, another pickup appearing, or a refill when the switch is destroyed;
- that the marker's start position stays the same.

Puzzle levels are normally designed to be solvable, so I most likely haven't found a mechanic. That is why I'm not calling it impossible.

**3. Next attempt**

I'll run the shortest route that includes the pickup:
1. Left 4 and down 2 to collect the pickup as a 4×4.
2. Up 1 and right 2 to column 29.
3. Shrink.
4. Down 1, right 1, up 1, to reach column 31 with an upward last move.
5. Shoot.
6. Regrow.
7. Right 6 to the exit.

I'll record the timer after every action. That will show whether the refill is capped and whether any event, such as destroying the switch, restores time. If the projection falls short, I'll spend the remaining actions testing for other mechanics, for example whether the cleared switch box or the corridor leads anywhere, and whether other panel patterns do anything.

VERDICT: undecided
CONFIDENCE: 50

## Attempt 4

**1. What happened on level 4**

To finish level 4, the marker has to do four things:
- shrink from 4×4 to 2×2 with the plus pattern (4 panel clicks);
- line up under a corridor two cells wide, with its last move upward;
- shoot the switch at the top with the vertical-line pattern (3 clicks), which opens the door;
- walk right through the door to the exit.

Repeating the plus pattern regrows the marker to 4×4, which moves 4 cells per step instead of 2.

The timer runs out first. Each move or click costs about 3.4 of its 64 rows, and each completed pattern costs about 4.6 rows more, so a full bar is roughly 18 plain actions. This attempt showed that the timer pickup sets the timer to 44 rows rather than adding to it. I picked it up early, at 48 rows, so it gave nothing.

I also tested what else the screen does:
- The teleport pattern from level 2 does nothing here.
- Clicking the legend patterns at top-left is free, but it only marks the missing cells and plays a short demo.
- Clicking the board is free and only flashes the panel red.

Then I ran the timer out. The cause of failure is that the route needs more actions than the timer allows.

**2. Can it be beaten?**

Not by any route I know; I can't rule out a mechanic I haven't found.

My claim: under the costs I measured, every route I know of runs short by at least about 20 rows (about 6 actions). The pickup gives at most 64 rows before it plus 44 after, so the best case is about 108 rows in total. Every useful route has to cross the board twice: once to the pickup in the lower-left corner, and once to the exit on the right.

| Route | Cost | Available | Short by |
|---|---|---|---|
| Shrink, aim, shoot, regrow, travel to the pickup, all before taking it | ~86 rows | 64 | ~22 |
| After that, from the pickup: up 1, right 9 to the exit | ~34 rows | 44 | fits |
| Shrink before the pickup; aim, shoot, regrow and walk after it | ~74 rows after the pickup | 44 | ~30 |
| No pickup at all | ~96 rows | 64 | ~32 |

Reordering the steps doesn't help, because they all need the same clicks and the same distances.

What I established:
- the per-action and per-pattern costs, measured over four attempts;
- the step sizes: 4 cells for a 4×4 marker, 2 for a 2×2;
- that the shot follows the last move and needs a 2×2 marker at column 31;
- that shooting the door does nothing;
- that the plus pattern toggles the marker's size;
- that patterns must match exactly;
- that the pickup set the timer to 44 both times.

What I assumed:
- that the refill always sets the timer to 44 (only two data points);
- that there is no other mechanic, such as another action, a second pickup, or a cheaper way to shoot or move;
- that the stem and the cleared switch area lead nowhere.

Puzzle levels are normally designed to be solvable, and that is the main reason I'm not calling it impossible. Finding such a mechanic, or showing there isn't one, would settle it.

**3. Next attempt**

I'll spend the first actions checking cheap unknowns:
- whether action 1 at the very start plays a free demo, as it did on level 1;
- whether the 2×2 marker can travel up the stem into the cleared switch area, and whether anything is up there;
- whether a third pickup reading still gives 44.

Then I'll run the best known route: aim and shoot first, regrow, collect the pickup as 4×4 with the timer as low as possible, and walk right to the exit. I'll log the timer after every action.

VERDICT: undecided
CONFIDENCE: 45

## Attempt 5

**1. What happened on level 4**

To finish level 4, the marker has to do four things:
- shrink from 4×4 to 2×2 using the plus pattern on the panel (4 clicks);
- line up under a corridor two cells wide, with its last move upward;
- fire a shot with the vertical-line pattern (3 clicks), which destroys a switch and opens the door;
- walk right to the exit.

Repeating the plus pattern regrows the marker to 4×4, which moves 4 cells per step instead of 2.

This attempt I shrank the marker and tried shooting left over the timer pickup. The shot passes over it without collecting it. I then collected it with the marker while the timer was low. It again set the timer to exactly 44 of 64 rows, the third time in a row, so the refill is a fixed value, not an addition. With the remaining time I shot the switch, which opened the door, and walked right. The timer ran out about 10 moves short of the exit.

The cause is the action budget, as in every attempt. A full timer is about 18 actions, with each completed pattern costing roughly one extra action. The pickup then provides about 12 more.

**2. Can it be beaten?**

I can't tell. My measurements say no; my only doubt is whether I've found every mechanic.

My claim: with the mechanics I know, no route fits.
- **Timing of the pickup.** Because the refill sets the timer to 44, the best use of it is to arrive just as the timer empties. The route is then two phases: about 18 actions before the pickup and about 12 after. Without the pickup it is 18 in total, which is far too few.
- **After the pickup.** The cheapest finish is from a 4×4 marker on the pickup: up 1 and right 9, which is 10 actions. Arriving as a 2×2 instead costs 14 or more, because the marker either has to regrow (about 5) or walk at 2 cells per step.
- **Before the pickup.** That means shrink (about 5), shoot (about 4) and regrow (about 5) all happen first, plus at least 10 moves to line up and then reach the pickup. That is about 24, against 18.
- **Every other split I checked** comes out 3–6 actions short in total.

What I established, over five attempts:
- the cost per action and per completed pattern;
- the step sizes;
- that the shot follows the last move and needs a 2×2 at column 31;
- that shooting the door does nothing;
- that the plus pattern toggles the marker's size;
- that patterns must match exactly;
- that the teleport pattern does nothing here;
- that legend and board clicks are free but only give hints;
- that a shot doesn't collect the pickup;
- that the refill sets the timer to 44.

What I didn't check:
- whether touching the switch with the marker, by going up the corridor, also opens the door;
- whether a regrown 4×4 sitting at column 31 can shoot up the corridor;
- whether there is an action outside 1–4 and 6, such as undo;
- whether anything respawns or other refills exist.

Puzzle levels are normally designed to be solvable, so I most likely haven't found a mechanic.

**3. Next attempt**

I'll test the unchecked items cheaply first:
- shrink, step to column 31, regrow, and check whether the 4×4 shot passes up the corridor;
- whether walking into the switch triggers it.

If either opens a shorter route, I'll take it. Otherwise I'll run the best two-phase route, collecting the pickup as 4×4 as late as possible, and log the timer after every action.

VERDICT: undecided
CONFIDENCE: 50

## Attempt 6

**1. What happened on level 4**

On level 4 the marker has to do four things:
- shrink from 4×4 to 2×2 with the plus pattern on the panel;
- line up under a narrow corridor;
- shoot a switch at the top of the corridor, which opens the door;
- walk right to the exit.

This attempt I tried to save actions with a different plan:
1. Shrink, step once, then regrow, hoping the regrown 4×4 would sit in line with the corridor.
2. Pick up the timer refill late.
3. Finish the shot after the refill and walk to the exit.

But regrowing expands the marker up and to the left of the 2×2, not from the corner I expected. The 4×4 ended up two cells off the corridor's columns and off the exit passage's rows, which broke the plan.

I then used the rest of the timer to test the pickup. A 4×4 marker, partly or fully covering it, does not collect it; only the 2×2 does. That means one of my earlier readings was not a refill. The two real refills both took the timer from 12 rows to 44, so I still don't know whether the refill adds about 32 rows or sets the timer to 44.

The direct cause of failure was my wrong assumption about where the regrown marker appears. The underlying cause is the same as before: the route needs more actions than the timer gives.

**2. Can it be beaten?**

Not by any route I know; I can't rule out a mechanic I haven't found.

Costs, measured over six attempts:
- a full timer is about 18 actions;
- a move or click is 1 action;
- a completed pattern counts as about 1 extra action, so shrink, shot and regrow each cost about 4–5 actions;
- the pickup adds roughly 6–12 more, depending on when it's taken and how the refill works.

So the most I can hope for is about 28–31 actions in total.

| Route | Cost | Fits? |
|---|---|---|
| Shrink near the pickup, collect it, step to column 31, shoot, regrow, walk 7 to the exit | ~33 actions | No |
| Shoot first, then collect the pickup | ~19–20 actions before the pickup | Over 18 before the refill can arrive |
| Stay 2×2 and walk 13 steps to the exit | ~35 actions | No |

Every ordering I tried comes out 2–5 actions short.

What I established: the action costs, the step sizes, the shot rules (it follows the last move, needs the 2×2 at column 31, and can't break the door), how shrink and regrow anchor, that only the 2×2 collects the pickup, and that patterns must match exactly.

What I didn't establish:
- whether the refill is additive and whether it caps at 64;
- whether a regrown 4×4 at column 31 can shoot up the corridor;
- whether touching the switch opens the door;
- whether some mechanic I haven't seen lowers the cost.

The level is presumably designed to be solvable, so a missing mechanic is likely, and I won't call it impossible.

**3. Next attempt**

1. Shrink near the pickup and collect it with the 2×2 while the timer is still high. If the timer jumps by about 32 rows, the refill is additive; if it shows 44, it sets a fixed value.
2. Run the 33-action route: step to column 31, shoot up, regrow, walk to the exit.
3. If the timer projection shows I'll fall short, spend what's left testing the unchecked mechanics: regrown 4×4 shooting, and touching the switch.

VERDICT: undecided
CONFIDENCE: 45

## Attempt 7

**1. What happened on level 4**

To finish level 4, the marker has to do four things:
- shrink from 4×4 to 2×2 with the plus pattern on the panel;
- line up at column 31 under a narrow corridor, with its last move upward;
- shoot the switch at the top with the vertical-line pattern, which opens the door;
- walk right to the exit.

A timer of 64 rows drains about 3.4 rows per move or click, plus about 4 extra rows whenever a pattern completes.

This time I moved the 4×4 marker down and left, shrank it, and stepped onto the timer pickup with the 2×2. That settled how the refill works: it adds about 36 rows (30 rows became 62); it doesn't set the timer to a fixed value. I then lined up, shot the switch, opened the door, and walked the 2×2 right. The timer ran out at column 49, about 4 moves short of the exit, which starts at column 57. The cause is the total cost of the route, about 14 rows more than the timer gave.

**2. Can it be beaten?**

I can't tell. By my numbers no known route fits; the only doubt is whether a mechanic remains undiscovered.

The total budget is at most about 100 rows: 64 to start plus about 36 from the pickup, with nothing lost to the cap if it's taken below about 28 rows. That is roughly 29 actions.

The cheapest route I can build is:
1. Move the 4×4 left 3 and down 2.
2. Shrink.
3. Step left onto the pickup.
4. Move right 4 and up 1 to reach column 31 with the last move up.
5. Shoot.
6. Step right 1, then regrow, which lands the 4×4 at row 29, column 31.
7. Move right 6 to the exit.

That is 18 moves, 11 clicks and 3 completed patterns, about 32 action-equivalents or about 111 rows. Shooting from a regrown 4×4 costs the same. Every other ordering I worked through costs the same or more, so the best known route is about 3 actions over.

What I established:
- the per-action and per-pattern costs, over seven attempts;
- that the refill is additive and only the 2×2 collects it;
- the step sizes;
- where the marker lands when it shrinks and when it regrows;
- the shot rules: it follows the last move, needs a 2×2 at column 31, and can't break the door;
- that patterns must match exactly.

What I assumed:
- that there are no other mechanics, such as a cheaper way to move, fire or change size, a second pickup, or a refill from destroying the switch;
- that my cost averages hold. The bar drops in uneven steps of 2 and 4 rows, so there's about ±1 action of rounding.

A 3-action gap is small enough that one mechanic I haven't found could close it.

**3. Next attempt**

I'll run the route above exactly, with the regrow before the final walk, and log the timer after every action. On the way I'll check whether a regrown 4×4 at row 29, column 31 can shoot up the corridor. If it can, the shot and the regrow can be done in either order, which may avoid the extra step. If the timer still falls short, I'll walk as far right as it allows.

VERDICT: undecided
CONFIDENCE: 45

## Attempt 8

**1. What happened on level 4**

To finish level 4, the marker has to do three things:
- get a shot up a narrow corridor to destroy a switch, which opens the door;
- get back into a 4×4 shape in line with the doorway;
- walk right to the exit.

A 4×4 marker only ever stops at columns 21, 25, 29, 33, 37 and 41. The shot only goes up the corridor when the corridor sits under the left half of the marker. That means a 2×2 marker at column 31, or a 4×4 at column 31, and neither size reaches that column by plain moves. So the marker has to shrink with the plus pattern and then either shoot as a 2×2 or regrow. Shrinking keeps the top-left corner; regrowing expands up and to the left.

This attempt:
1. Moved the 4×4 to the bottom left and shrank it to 2×2.
2. Collected the timer pickup (30 rows went back to 62).
3. Moved to row 31, column 33 and regrew, which put the 4×4 at row 29, column 31.
4. Fired. The 4×4 shot went up the corridor, destroyed the switch and opened the door.

The timer ran out with the marker at column 43, three moves short of the exit at column 57. It failed because the route costs more timer than the level provides; I lost no actions to mistakes.

**2. Can it be beaten?**

I can't tell. By my measurements no route fits, but I may be missing a mechanic.

Costs, measured over eight attempts:
- a move or click costs about 3.4–3.6 rows of the 64-row timer;
- each completed pattern costs about one extra action;
- so a shrink, a regrow or a shot costs about 4–5 actions each.

The cheapest routes:
- **Without the pickup:** move the 4×4 left 1 and down 2 to (33,33), shrink, step up 1, regrow (the 4×4 lands at row 29, column 31, last move up), shoot, then right 6. That is 10 moves, 11 clicks and 3 completed patterns, about 24 action-equivalents or about 86 rows, against 64.
- **With the pickup:** it adds about 36 rows, but only a 2×2 can collect it, and reaching it costs at least 8 extra moves (about 28 rows). The best version comes to about 114 rows against about 100.
- **Every other ordering I worked out costs the same or more.** The shortfall of about 3–4 actions matches what I saw in the last three attempts.

What I established:
- the action costs;
- the step sizes and the columns a 4×4 can reach;
- where the marker lands when it shrinks and when it regrows;
- the shot rules: it follows the last move, works from a 2×2 at column 31 or a 4×4 at column 31, and can't break the door;
- that the refill is additive and only the 2×2 collects it;
- that patterns must match exactly;
- that clicks on the legend and the board are free but do nothing useful;
- that the pickup doesn't respawn while I'm moving.

What I assumed: that the game has no other mechanic I haven't seen, such as a cheaper action, a way to change facing for free, another refill source, or something hidden in the corridor or switch area. The level was presumably designed to be winnable, which suggests such a mechanic exists, so I can't call it impossible.

**3. Next attempt**

I'll run the cheapest known route with the pickup:
1. Move the 4×4 left 3 and down 2.
2. Shrink.
3. Step left onto the pickup.
4. Move right 5 and up 1.
5. Regrow, then shoot.
6. Move right 6 to the exit.

I'll log the timer after every action. Early on, I'll spend only free actions probing for unseen mechanics: clicks on the marker, the switch box and the exit. When the timer is clearly short, I'll say so.

VERDICT: undecided
CONFIDENCE: 50

## Final interview

**1. What happened on level 4**

The board has a 4×4 marker, an exit on the right behind a door, and a switch box at the top of a corridor two cells wide. Shooting the switch opens the door. Every action drains a 64-row timer, and the game ends when the timer is empty. A pickup in the bottom-left corner refills part of the timer.

The marker's abilities come from matching a 3×3 panel to patterns shown in a legend:
- the **plus pattern** shrinks the marker to 2×2, or regrows it to 4×4;
- the **vertical line** fires a shot in the direction of the last move.

In my best attempts I did the following:
1. Moved the 4×4 to the bottom left and shrank it.
2. Collected the pickup with the 2×2.
3. Moved to the spot where regrowing lines the 4×4 up with the corridor, and regrew.
4. Shot the switch, which opened the door.
5. Walked toward the exit.

The timer ran out about 3 moves short, three attempts in a row. Early attempts also wasted actions on trial and error: a misaligned shot, picking up the refill too early, and a wrong guess about where the regrown marker lands. The underlying failure is that every route I found costs more than the timer provides.

**2. Can it be beaten?**

I can't tell either way.

What I'm claiming: under the mechanics I've found, the cheapest route costs about 14 rows more than the available budget.

The costs and constraints behind that:
- **Timer costs:** a move or click costs about 3.4–3.6 rows; a completed pattern costs about one action's worth extra.
- **Marker positions:** a 4×4 only stops at columns 21, 25, 29, 33, 37 and 41, and rows 21, 25, 29 and 33. The shot needs the corridor (columns 31–32) under the left half of the marker. So shrinking is unavoidable, and then either a 2×2 shot at column 31 or a regrow to a 4×4 at column 31.
- **Cheapest route without the pickup:** 10 moves, 11 clicks and 3 completed patterns, about 86 rows against 64.
- **With the pickup:** it adds about 36 rows, but only a 2×2 collects it, and reaching it costs at least 8 extra moves. That route is about 114 rows against about 100.
- **Other orderings** cost the same or more.

What it rests on: my measurements over eight attempts, and the assumption that no mechanic remains undiscovered. A designed level suggests one does, perhaps a cheaper action, facing changes that cost nothing, or something in the corridor or switch area. Testing those would settle it.

**3. Rules I worked out, and from what**

- **The shot follows the last move.** On level 3 the first shot went right after a rightward last move; the next went up after an upward move.
- **The shot needs the corridor under the marker's left half.** A 4×4 at columns 29–32 was blocked with the corridor at 31–32. A 2×2 at column 31, and a 4×4 at columns 31–34, both passed.
- **Shrink and regrow anchor differently.** Shrinking kept the top-left corner (rows 25–28, columns 37–40 became rows 25–26, columns 37–38). Regrowing expanded up and to the left (a 2×2 at row 25, column 35 became a 4×4 at row 23, column 33).
- **Only the 2×2 collects the pickup, and the refill adds rows.** A 4×4 covering the pickup gave nothing. The 2×2 took the timer from 30 rows to 62.
- **Shooting the door doesn't open it.**
- **Patterns must match exactly.** Plus shape and centre cell together did nothing.
- **Unmatched clicks persist on the panel.**
- **Clicks on the legend or the board are free.** They only give hints or a red flash.

**4. Rules I'm still unsure about**

- **The exact timer cost and whether it varies.** Decrements alternate between 2 and 4 rows, so my budget arithmetic carries about ±1 action of error.
- **Whether the refill is capped at 64.** I've only collected it below about 28 rows.
- **Whether turning without moving changes the shot direction.** A move into a wall turns the marker but costs as much as a move, and I don't know if the shot then follows the new facing.
- **Whether any cheaper or hidden action exists.** That's the doubt behind leaving the verdict undecided.

VERDICT: undecided
CONFIDENCE: 45
