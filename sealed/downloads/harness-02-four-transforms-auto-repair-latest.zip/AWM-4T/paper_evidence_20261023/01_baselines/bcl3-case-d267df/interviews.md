## Attempt 1

**1. What happened on level 4**

The room had a goal on the right, closed off by a barrier. The barrier opens when you shoot a switch box at the top of a narrow passage two pixels wide. There was also a pickup that refills the timer, in the bottom-left corner. Every move or click drains the timer bar, and on this level each action cost about 4 of its 64 rows, roughly twice what earlier levels cost. That gives about 16 actions per full bar.

My first shot, fired as the full 4×4 block, hit the wall at the mouth of the passage. The 4×4 player moves in 4-pixel steps, so it can never line up properly with that passage. I then spent many actions:
- walking to the refill pickup, which did not trigger because the 4×4 player covered it;
- shrinking the player;
- picking the refill up as the 2×2 player;
- lining up and shooting the switch, which did clear the barrier.

By then the timer was at 0, about 13 moves short of the goal, and the next move ended the game.

The failure came from wasted actions: a shot that was bound to miss, and a detour and wrong guesses while I was still exploring. These came on a level where every action cost about twice as much as before, and I didn't notice that rate until it was too late.

**2. Can it be beaten?**

I can't tell. The cheapest route I can build from what I know:
- Move the 4×4 player down 2 and left 4.
- Shrink it (4 clicks).
- Step right 1 to pick up the refill.
- Step right 4 to line up with the passage.
- Move up 1 to face the passage.
- Fire (3 clicks).
- Walk right 13 to the goal.

That is about 32 actions.

The budget is roughly 64 rows plus about 36 from the refill, about 100 rows. At about 3.6 rows per action, that is about 27 actions. On those numbers the route does not fit.

What I established:
- the barrier mechanics, and that the shrunk player's shot works from x=31;
- that the refill adds about 32–36 rows;
- that the 4×4 player covering the refill did not collect it.

What I assumed:
- **Action cost:** the costs I measured were irregular (2, 4 and 8 rows), so the per-action figure is uncertain.
- **Fire cost:** firing seemed to cost extra, but that is also unconfirmed.
- **Cheaper mechanics:** I assumed there are none, such as turning without moving, an action 5, regrowing to walk faster, or the 4×4 collecting the refill front-first.

The level was presumably designed to be winnable, which suggests I'm missing a cheaper mechanic. Two things would settle it:
- exact per-action costs, measured one action at a time early on;
- a test of whether the 4×4 picks up the refill when it touches it with its front edge.

**3. Next attempt**

I'll plan the whole route before the first action and log the timer after every action. I'll follow the route above, without the failed 4×4 shot. Early on I'll test, cheaply:
- whether the 4×4 collects the refill front-first, which would save the shrink detour;
- whether regrowing after the shot makes the long walk right cheaper.

I'll never shoot from a position where the shot can't line up with the passage.

VERDICT: undecided
CONFIDENCE: 55

## Attempt 2

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage only 2 pixels wide. Every action drains a timer bar. On this level an action costs about 3.5 of the bar's 64 rows, which is roughly 18 actions per full bar. One refill block in the corner adds about 36 rows, and only the shrunk 2×2 player can pick it up.

On this attempt I collected the refill, then regrew the player to 4×4 so the walk to the goal would take fewer steps. Regrowing shifted it by 2 pixels back onto a column grid that can't line up with the passage. I then confirmed that a 4×4 shot from the reachable columns (x=29 and x=33) hits the wall. After that there wasn't enough timer left to shrink again, shoot and walk, so it ran out.

The underlying cause is that every route I know costs more timer than the level gives, plus one wasted grow that cost about 5 action-units.

**2. Can it be beaten?**

I can't tell. Under the mechanics I've confirmed, I can't find a route that fits the budget. The argument, counted in units of one ordinary action (about 3.5 rows):

- **Budget:** about 18 units from the bar plus about 10 from the refill, so about 28. I measured this over two attempts. Per-action costs were 2, 4 or 8 rows, and the refill added about 32–36.
- **Fixed costs:**
  - Casting a recipe costs about 5 units (4 clicks, the last one dearer).
  - Firing costs about 4 units.
- **Required steps:**
  - The 4×4 player can only stand at x = 21, 25, …, 41, and I saw its shot fail from x=29 and x=33.
  - So the shot needs the 2×2 player at x=31, which means at least one shrink.
  - The refill is also only collectable as 2×2.
  - The walk from x=31 to the goal is 13 steps as 2×2, or 7 steps after regrowing.

The best routes I can construct:
1. Walk the 4×4 to the refill corner (6 moves), shrink (5), pick up (1), walk under the passage and face up (5), fire (4), walk 13 steps: about 34 units.
2. The same, but regrow at a spot that leaves the 4×4 lined up with the goal corridor before firing: also about 34 units.
3. Skipping the refill gives about 28–29 units needed against a budget of 18.

Every route I found is 6 or more units short.

**What this rests on.** Established: the costs above (with some rounding noise), the 4×4 shot failing from both reachable columns, the 2×2 shot working from x=31, the shrink and grow offsets, and the 4×4 failing to collect the refill. Assumed and not checked:
- that no cheaper mechanic exists, such as a shot collecting the refill, a free way to turn, or a shot passing through the barrier;
- that a 4×4 shot from x=31 would work (this only matters for route 2);
- that my per-action cost averages are right.

Since the level was presumably designed to be solvable, I suspect I'm missing a mechanic. Testing those unchecked points cheaply would settle it.

**3. Next attempt**

Before committing, I'll spend one or two actions on cheap tests:
- whether a projectile fired into the refill block collects it;
- whether firing at the barrier from the corridor side does anything.

If neither helps, I'll run route 1 straight through with no wasted actions and log the timer after every action. If I'm about 5 units short at the end, the result will at least pin down the shortfall exactly.

VERDICT: undecided
CONFIDENCE: 50

## Attempt 3

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. A timer drains about 4 of its 64 rows per action, and that includes each click on the grid used to cast abilities. A refill block adds about 9 more actions, so the level gives about 25 actions in total.

My new idea this time was to collect the refill by shooting it instead of walking the shrunk player over to it. That would have saved several actions, but the shot passed over the block without collecting it. After that no route fit the budget. I spent the remaining timer confirming how growing works:
- the 2×2 player at (x,y) becomes a 4×4 at (x−2,y−2);
- growing keeps the direction the player is facing.

The underlying failure is that every route I know of costs at least 30 actions against roughly 25 available. My test idea also used up actions that a real attempt needed.

**2. Can it be beaten?**

I can't tell. Under the mechanics I know, I can't find a route that fits. The argument:

- **Budget, about 25 actions.** Established: three attempts each ran out at about 25 actions, including the refill.
- **What the route must include:**
  - **The refill.** Without it there are about 16 actions, and the cheapest route without it is about 22. This assumes the cheapest route has to include the shot and the walk, which I believe but haven't proven.
  - **A shrink, about 4 clicks.** Established: only the 2×2 player can collect the refill. Also established: the 4×4 block's columns are fixed at x = 21, 25, …, 41, and its shots from x=29 and x=33 failed.
  - **A shot from x=31, 3 clicks.** Established: a 2×2 player can make it. A 4×4 shifted onto x=31 by shrinking and regrowing might also work, but that is untested.
  - **The walk to the goal.** Established: 13 moves as 2×2 from x=31, or 7 moves as 4×4 after a 4-click regrow.
- **Count.** Getting to the refill corner and picking it up takes about 10 actions (5 moves, 4 clicks to shrink, 1 move). Repositioning, shooting, and walking takes at least about 20 more. Every combination I worked out comes to 30 or more.

The unchecked assumption is that I know every mechanic. One thing is completely untested: clicking the recipe pictures in the top-left corner. On level 1, clicking a recipe picture was free and replayed the hint animation. If clicking one on this level casts the ability more cheaply than the 3–4 grid clicks, the route drops to about 21–25 actions and might fit. Checking that would settle it.

**3. Next attempt**

I'll start with free or cheap probes and watch the timer: click each top-left recipe picture once and see whether it casts. If it does, I'll use that route:
1. Walk the 4×4 to the corner.
2. Shrink, step onto the refill, then move one step right.
3. Regrow so the 4×4 lands on the column grid that can line up under the passage.
4. Line up under the passage, face up and shoot.
5. Walk to the goal.

If the probes show nothing new, I'll run the shortest known route and confirm the shortfall exactly.

VERDICT: undecided
CONFIDENCE: 45

## Attempt 4

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every action drains a timer, including each click on the grid used to cast abilities. This time I measured the costs precisely:
- An ordinary action costs about 4 of the timer's 64 rows, so a full bar is about 16 actions.
- The click that completes a cast costs about one extra action.
- A refill block adds about 9 actions, but only the shrunk 2×2 player can collect it.

This attempt was deliberately spent on tests, because no route I knew of fit the budget. Clicking the recipe pictures or objects in the room is free but does nothing. The teleport recipe from level 2 does nothing here. An ability only casts when the grid matches its recipe exactly. Shrinking and immediately regrowing at the start moved the large player 2 pixels, which let me park it at x=31, facing up under the passage. The timer ran out one click before the shot, so whether that shot works is still unknown.

The cause of failure across all four attempts is the same: every route I can build costs more actions than the level provides.

**2. Can it be beaten?**

I can't tell. Under the mechanics I've observed, I believe it can't be done. In units of one ordinary action, with a cast costing one extra:

- **Budget:** about 16, or about 25 with the refill.
- **Without the refill** (and assuming the untested 4×4 shot from x=31 works), about 25 units:
  - shrink and regrow to line up: about 10;
  - move into position and face up: 2;
  - fire: 4;
  - move down to the corridor row: 2;
  - walk to the goal: 7.

  That is 9 over budget.
- **With the refill:**
  - walk to the corner: 5;
  - shrink: 5;
  - pick up: 1;
  - total so far: about 11, leaving about 14.

  From there, reaching x=31 facing up and firing costs about 9 more. That leaves about 5 for a walk that needs 7 even after a 5-unit regrow, or 13 as 2×2. That is at least 7 short.

Established (measured over four attempts):
- the costs and the refill amount;
- the large player's fixed columns, and its failed shots from x=29 and x=33;
- that only the 2×2 collects the refill, and that a shot passing over it does not;
- that casts need an exact match;
- the shrink and grow positions.

Not established:
- **Completeness of the mechanics.** Above all, I've assumed there are no other abilities beyond the two recipes shown. I haven't tried other grid patterns.
- **Cheaper effects.** I haven't checked whether some walk-saving effect exists.

Since the level was presumably built to be beaten, a missing mechanic is more likely than an impossible level, but I haven't found it. Systematically testing other grid patterns would settle it, though each test costs timer.

**3. Next attempt**

I'll spend the attempt exploring rather than repeating routes that don't fit. I'll try other 3×3 grid patterns, especially ones that might move the player farther or faster, and record what each does. I'll start with patterns that are cheap to enter and watch for any effect. If one cuts the walk to the goal, I'll plan a full route around it on a later attempt.

VERDICT: undecided
CONFIDENCE: 40

## Attempt 5

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every move or click drains a timer. A full bar is about 18 actions, and the click that completes a cast counts as two. A refill block adds about 10 more actions, but only when the shrunk 2×2 player walks onto it.

Before acting, I wrote a small exhaustive search over everything I had measured. It found no route that fits the timer. The only route that fit assumed that a shot from the 2×2 player could collect the refill from a distance. I played that route, and the shot passed over the refill without collecting it, so the attempt was lost. I then collected the refill on foot and moved the large 4×4 player to x=31, facing up under the passage. The timer ran out one click before I could fire.

The cause is the same as on every attempt: the route I needed depended on an untested mechanic that turned out not to exist.

**2. Can it be beaten?**

I can't tell. My claim is that under the mechanics I've observed, no route reaches the goal within the timer.

The argument is the exhaustive search, which explored every position, size, facing direction, refill state and barrier state of the player:
- **Actions modelled:** moves cost 1, shrink or grow costs 5, a shot costs 4.
- **Refill:** adds 10 when the 2×2 overlaps the block.
- **Shot:** opens the barrier if it is fired upward from x=31, by either size of player.
- **Result:** the cheapest route to the goal needs a base budget of about 21. The measured budget is about 18.

The search was generous on two points:
- **4×4 shot:** it counted a shot from the 4×4 player at x=31 as working, which is still unverified.
- **Win condition:** it counted the level as won as soon as the player partly overlaps the goal.

So under these rules it is impossible, by about 3 actions.

Established over five attempts:
- the timer costs and the refill amount (rounding noise is about 1 action);
- the movement grid and the clamping at walls;
- where the player lands after shrinking or growing;
- the failed 4×4 shots from x=29 and x=33, and the working 2×2 shot from x=31;
- that the refill is collected only by the 2×2 walking onto it, not by any shot;
- that casts need an exact grid match;
- that the teleport recipe does nothing here.

Not established is that these are all the mechanics. Grid patterns other than the recipes shown are untested, and so are any moves through the room I haven't thought of. The level was presumably designed to be beatable, which points to a mechanic I haven't found. Systematically testing other grid patterns would settle it. One assumption I didn't check: whether the final action that empties the timer still counts toward a win. That alone could only recover about 1 action, not 3.

**3. Next attempt**

I'll spend the attempt on discovery rather than on routes my search already says can't work. Concretely:
- try other 3×3 grid patterns, especially single cells, rows, columns and diagonals, and watch the player, the room and the timer after each;
- check whether moving into the switch passage or the barrier does anything.

If I find a mechanic that saves 3 or more actions, I'll add it to the search and run the resulting route on a later attempt.

VERDICT: undecided
CONFIDENCE: 45

## Attempt 6

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every move or click drains a timer that allows about 18 actions; the click that completes a cast counts as two. A refill block in the corner adds about 10 more actions, but only when the shrunk 2×2 player steps on it.

My earlier search had shown no route that fits the timer under what I knew, so I spent this attempt hunting for a mechanic I might be missing:
- **Shooting the barrier:** a shot fired straight at the barrier from inside the room is absorbed and does nothing.
- **Other grid patterns:** six patterns not on the recipe list, from the middle row up to the full grid with various cells removed, cast nothing.

The timer ran out during these tests. As in every attempt, the failure is that no known route fits the budget, and this time the exploration found nothing that changes that.

**2. Can it be beaten?**

I can't tell. My claim is that with the mechanics I've seen, the level can't be finished within the timer.

The argument is an exhaustive search of every reachable state: the player's position, size, facing direction, whether the refill has been taken, and whether the barrier is open. It is built on these measurements:
- **Costs:** a move or click costs 1 unit, shrinking or growing costs 5, a shot costs 4.
- **Refill:** adds 10 units, and only when the 2×2 player overlaps the block.
- **Movement:** the 4×4 moves 4 pixels at a time on columns 21, 25, … 41; the 2×2 moves 2 at a time. Moves stop at walls.
- **Shrink and grow:** shrinking keeps the top-left corner in place; growing places the 4×4 2 pixels up and to the left, with the same facing.
- **Opening the barrier:** only an upward shot from x=31 does it.

The search's cheapest route needs a starting budget of about 21 units against about 18 measured. That holds even with two generous assumptions that are both unverified:
- **4×4 shot:** that a shot from the 4×4 player at x=31 works.
- **Win condition:** that only partly entering the goal counts as a win.

Established over six attempts:
- the costs, including that moves into a wall cost too;
- the refill amount, and that shots don't collect the refill, whether fired by the 4×4 or the 2×2;
- that the 4×4 doesn't collect it either;
- the failed 4×4 shots from x=29 and x=33, and that the 2×2 shot from x=31 works;
- that casts need an exact grid match;
- that the teleport recipe and the patterns tested do nothing;
- that shooting the barrier directly does nothing.

Unproven is that I've found every mechanic: most of the 512 grid patterns are untested. Two small uncertainties could each shift the count by about one unit:
- the rounding in how the timer bar displays;
- whether the action that empties the timer can still win.

The level being designed to be beaten argues against my conclusion. What would settle it: finding a mechanic that saves 3 or more units, or ruling out the remaining patterns.

**3. Next attempt**

I'll play the best route from the search exactly, logging the timer after every action:
1. Walk the 4×4 to the corner, shrink, and step onto the refill.
2. Regrow so the 4×4 lands on the column grid that lines up with the passage.
3. Move to x=31 facing up and shoot.
4. Walk to the goal.

This finally tests the 4×4 shot from x=31 and the real end-of-timer behaviour, and it would win if my cost model is about 3 units too pessimistic. If it fails early, I'll spend the remainder testing more patterns.

VERDICT: undecided
CONFIDENCE: 50

## Attempt 7

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every move or click drains a timer. A refill block adds time, but only when the shrunk 2×2 player steps on it.

This attempt I played the cheapest route my exhaustive search had found:
1. Walked the large 4×4 player to the corner, shrank it and collected the refill.
2. Regrew it at a spot that lines the large player up under the passage, at x=31.
3. Turned it to face up and fired. The shot hit the switch and opened the barrier. This confirmed the last open assumption in my model.
4. Walked right toward the goal. The timer reached zero at x=43, three moves short.

It failed because even the cheapest route I know costs about three actions more than the timer allows, and the real game confirmed that shortfall.

**2. Can it be beaten?**

I can't tell. My claim is that no route using the mechanics I've found fits the timer.

The argument is an exhaustive shortest-path search over every combination of position, size, facing direction, refill taken or not, and barrier open or not. It uses these rules:
- **Costs:** a move or click costs 1 unit, about 3.5 timer rows; shrinking or growing costs about 5; a shot costs about 4.
- **Budget:** the bar holds about 18 units, and the refill adds about 10. This attempt it gave a bit more: the timer went from 30 to 62 on the pickup move.
- **Movement:** the 4×4 moves 4 pixels a step, the 2×2 moves 2, and both stop at walls.
- **Shrink and grow:** shrinking keeps the top-left corner in place; growing puts the 4×4 2 pixels up and left of the 2×2, keeping the facing direction.
- **Refill:** collected only when the 2×2 walks onto it.
- **Opening the barrier:** only an upward shot from x=31, by either size.

Every rule above has now been checked in play. The search's cheapest route needs about 3 units more than the budget, and playing that route came up exactly 3 moves short. This matches the model.

What the argument rests on without proof is that these are all the mechanics. I've ruled out:
- clicking objects in the room or the recipe pictures;
- the teleport recipe;
- six patterns that aren't recipes;
- shots collecting the refill;
- shots at the barrier.

About 500 grid patterns remain untested. A level built to be beaten suggests something is still missing, but I haven't found it. Finding a mechanic that saves at least 3 actions would settle it; so would ruling out the remaining patterns.

**3. Next attempt**

I'll play the same verified route, since it's the best known and gets within 3 moves. I'll look for small savings that cut those 3 moves:
- a different order of moves near the regrow and the turn to face up;
- whether stepping into the goal partway counts as a win.

I'll also test a few more grid patterns early if it costs nothing on the route. Realistically, unless a new mechanic turns up, this attempt will fall short by the same margin.

VERDICT: undecided
CONFIDENCE: 50

## Attempt 8

**1. What happened**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every move or click drains a timer. A refill block adds time, but only when the shrunk 2×2 player walks onto it. My best route from earlier attempts already falls 3 moves short.

This attempt I meant to start with free test clicks. Two of them landed on the border of the 3×3 casting grid. A border click toggles the nearest cell and costs timer like a normal click, so they cost about 2 actions, which ruled out a win. Right after those clicks the grid showed a hint marking the shrink pattern, the kind of hint levels 1–3 show at the start. I spent the rest of the timer trying to make a hint appear again for later steps and couldn't.

It failed because of a careless click that cost actions, on top of a route that was already too long.

**2. Can it be beaten?**

I can't tell. My claim is that with the mechanics I've confirmed, no route fits the timer.

The argument is an exhaustive shortest-path search, in units where a move or click costs 1:
- **States:** every combination of position, size, facing, whether the refill is taken, and whether the barrier is open.
- **Costs:** shrink or grow 5, a shot 4.
- **Budget:** about 18 units, plus about 9–10 from the refill.
- **Movement:** the large player moves 4 pixels and the small one 2, stopping at walls.
- **Shrink and grow:** shrinking keeps the top-left corner; growing places the large player 2 pixels up and left, with the same facing.
- **Opening the barrier:** only an upward shot from x=31.

The cheapest route the search finds is about 3 units over budget. Playing that route ended exactly 3 moves short, which supports the model.

Every rule above has been confirmed in play. What remains unproven is that these are all the mechanics.

The hint suggests the intended solution starts by shrinking at the start position. My search's best route instead walks to the refill first. If the hint is reliable, that's a sign the designer's route uses something I haven't modelled. Two things would settle it: reproducing the hint step by step to read off the intended order, or testing more of the roughly 500 grid patterns I haven't tried.

**3. Next attempt**

I'll only make free clicks away from the grid. I'll try to reproduce the hint deliberately: toggle one cell on and off on a fresh level, which costs about 2 actions, and check whether shrink is shown. If hints are reproducible, I'll follow them step by step, querying only at points where the next action is unclear. If they aren't, I'll play the confirmed best route with no wasted actions and test whether partly entering the goal on the final move counts as a win.

VERDICT: undecided
CONFIDENCE: 45

## Final interview

**1. What happened and why it failed**

Level 4 is a room with the goal on the right, closed off by a barrier. The barrier opens when you shoot a switch at the top of a passage 2 pixels wide. Every move or click drains a timer of about 18 actions; the click that completes an ability counts as about two. A refill block in the lower-left corner adds about 9–10 actions, but only when the shrunk 2×2 player walks onto it.

The large 4×4 player moves 4 pixels a step, on a column grid that never lines up with the passage. So the shot needs either the shrunk player, or a shrink followed by a regrow, which moves the large player 2 pixels sideways onto the right grid.

Across eight attempts on this level, I first spent actions learning these rules. Then I tested a series of ideas that didn't pan out:
- collecting the refill with a shot;
- shooting the barrier directly;
- other casting patterns and the teleport recipe from level 2.

On attempt 7 I played the cheapest route my search found. It worked mechanically: the switch was hit and the barrier opened. The timer ran out three moves short of the goal. On the last attempt I wasted two actions by clicking the border of the casting grid. Those clicks toggle a cell and cost timer.

The underlying cause is that every route I know is about three actions longer than the budget.

**2. Can it be beaten?**

I can't tell. My claim is that with the mechanics I've found, no route reaches the goal within the timer.

The argument is an exhaustive shortest-path search over every combination of position, size, facing, whether the refill is taken, and whether the barrier is open. It uses these rules:
- **Costs:** a move or click costs 1 unit; shrinking or growing costs 5, and a shot costs 4.
- **Movement:** the large player moves 4 pixels and the small one 2, stopping at walls.
- **Shrink and grow:** shrinking keeps the top-left corner in place; growing places the large player 2 pixels up and left, with the same facing.
- **Refill:** taken only when the 2×2 overlaps the block.
- **Barrier:** opens only on an upward shot from x=31, by either size.

The cheapest route needs a base budget of about 21 against about 18 measured. Playing that route in the real game ended exactly 3 moves short, which matches.

All of those rules were confirmed by observation. What's assumed and unchecked is that there are no other mechanics. About 500 of the 512 grid patterns are untested. One unexplained observation, a hint pointing to shrinking first, suggests the intended route may differ from mine. Reproducing that hint step by step, or finding a mechanic that saves 3 or more actions, would settle it.

**3. Rules I newly worked out**

- **The 4×4 can be aligned after all.** Its shot does reach the switch once it stands at x=31. I'd believed it couldn't get there. This was established on attempt 7: the barrier opened after the regrow put the large player at x=31.
- **Only some shot positions work.** Shots from x=29 and x=33 hit the wall, although on level 3 a shot overlapping the passage by only half got through. That suggests the passage must line up with the left half of the projectile.
- **Grow and shrink positions:** growing puts the 4×4 at the 2×2's position minus 2 in each direction, with the same facing; shrinking keeps the top-left corner. Seen repeatedly, for example 2×2 at (33,31) growing to 4×4 at (31,29).
- **Refill pickup:** only a 2×2 walking onto the block collects it. A 4×4 covering it, or a shot of either size passing over it, does nothing.
- **Casting:** casting needs an exact match on the grid; a superset of the pattern doesn't cast.
- **Timer:** every move or click costs about 3.5 rows, including moves into a wall and border clicks. The completing click of a cast costs about double. The game ends on the first action after the timer reaches 0.

**4. Rules I'm still unsure about**

- **Hints:** once, on a fresh start of level 4, the grid showed a hint marking the shrink pattern, after a few free clicks and toggling one cell on and off. I couldn't reproduce it, so I don't know what triggers a hint, or whether hints follow the intended solution.
- **Win condition:** I don't know whether partly overlapping the goal counts as a win, or the player has to be fully inside. This could change the walk by one move.
- **Final action:** I don't know whether an action taken as the timer hits 0 can still complete the level.
- **Exact costs:** the timer display rounds, so the exact per-action cost and refill amount are uncertain by about one action.

VERDICT: undecided
CONFIDENCE: 45
