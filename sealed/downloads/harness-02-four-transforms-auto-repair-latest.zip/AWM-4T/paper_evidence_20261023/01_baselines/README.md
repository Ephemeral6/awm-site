# 01 主表：裸臂原始实验

12条：L4/L5 × Claude/Astra × 各3次。均为原始最多8次阶段。

| 关卡 / 受试 / case | 轮次 | 结果 | 使用范围 |
|---|---|---|---|
| [L4 / Claude Opus 5.5 / 2f1a1c](bcl3-case-2f1a1c/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L4 / Claude Opus 5.5 / d267df](bcl3-case-d267df/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L4 / Claude Opus 5.5 / 1dd6e6](m15bcl-case-1dd6e6/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L4 / GPT-6 Astra / 44ec53](bast2-case-44ec53/README.md) | 8次 | undecided；界：22 (claim withdrawn) | 主表原始阶段 |
| [L4 / GPT-6 Astra / 4d3b31](bast2-case-4d3b31/README.md) | 8次 | impossible；界：22 | 主表原始阶段 |
| [L4 / GPT-6 Astra / 98893b](bast2-case-98893b/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L5 / Claude Opus 5.5 / 202da3](l5r-case-202da3/README.md) | 8次 | impossible；界：43 | 主表原始阶段 |
| [L5 / Claude Opus 5.5 / 339b0a](l5r-case-339b0a/README.md) | 8次 | impossible；界：47-49 | 主表原始阶段 |
| [L5 / Claude Opus 5.5 / fbac96](l5r-case-fbac96/README.md) | 8次 | impossible；界：按原稿口径数值正确；最优性未证 | 主表原始阶段 |
| [L5 / GPT-6 Astra / 2cdca5](l5r-case-2cdca5/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L5 / GPT-6 Astra / 3eb226](l5r-case-3eb226/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |
| [L5 / GPT-6 Astra / b3830e](l5r-case-b3830e/README.md) | 8次 | undecided；界：未给出可计分的界 | 主表原始阶段 |

[返回实验总表](../EXPERIMENTS.md)
