import json
d=json.load(open('.last_frame.json'));f=d['frame']
H='0123456789abcdef'
print('grid', [[H[f[50+5*r][25+5*c]] for c in range(3)] for r in range(3)])
print('bar', sum(1 for y in range(64) if f[y][62]==14), 'level', d['level'])
