#!/bin/bash
# usage: step.sh "bet text" ACTION...
cd D:/arc-arena/l4p-case-2a3cc5
bet="$1"; shift
python play.py settle >/dev/null
python play.py bet "$bet" >/dev/null && python play.py act "$@" && python play.py settle | tail -4; python work/diff.py | head -40
