"""ACTION1-4：块平移一个边长后的目标足迹里含有目标槽的 10 色格（非块自身）⇔ 这一步过关（level +1）。"""
LEVEL = "L5"
SCOPE = "只看 ACTION1-4；prev 里定位不到块 NA；两个方向都判"
NOTE = ""
EVIDENCE = ["0ba05691632adb10"]
from _lib import piece, DIRS

def assert_(prev, action, nxt, ctx=None):
    if action not in DIRS or not ctx: return "NA"
    a = piece(prev)
    if a is None: return "NA"
    t, b, l, r = a; s = b - t + 1
    dy, dx = DIRS[action]
    foot = [(y + dy * s, x + dx * s) for y in range(t, b + 1) for x in range(l, r + 1)]
    hits = any(0 <= y < 64 and 0 <= x < 62 and prev[y][x] == 10 and not (t <= y <= b and l <= x <= r) for y, x in foot)
    up = ctx.get("level_next") == (ctx.get("level_prev") or 0) + 1 or ctx.get("state_next") == "WIN"
    return "TRUE" if hits == up else "FALSE"
