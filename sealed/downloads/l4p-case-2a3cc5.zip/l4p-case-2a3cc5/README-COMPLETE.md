# Completed historical run: l4p-case-2a3cc5

All eight attempts and the final interview are archived. The final report is
`impossible_in_model_proved`, confidence 50, with threshold 19 against budget 18.
The receiver cold-build record reports exit 0 and axiom output for
`L4.V4.never_wins`, `route19_wins` and `route19_at18`.

Start with `completed_continuation/final_interview.json`, the complete questions
and answers, and `completed_continuation/session.jsonl`. Attempt 4–8 records are
in `attempts/04` through `attempts/08`; their Python, Lean and notes are under
`completed_continuation/snapshots/attempt04` through `attempt08`. The final
workspace is `completed_continuation/snapshots/final`.

Original archive entries are retained byte for byte except the current
top-level RUN-STATUS.json. Their older pending notes describe the historical
snapshot. The resumed third-attempt check does not retroactively turn its
original online gate failure into a pass. This uses the historical protocol,
not either newer four-transform or automatic-repair release.

The public session retains every available user/assistant message, question,
tool call and tool result, with original source-line references. Added exports
exclude CLI request/debug/account metadata and login configuration. Source
hashes, session identity, CLI versions and completion time are documented in
`completed_continuation/PROVENANCE.json`. The raw completion ZIP remains local.
