## 2026-10-21T01:40:02.628Z · original line 47

Board seen: a shape with a 9/a block, a bordered 3×3 pattern grid, and a key panel. Setting up the bet/act/settle loop and testing actions now.

## 2026-10-21T01:42:15.430Z · original line 97

Testing whether lighting the grid cells to match the key's plus pattern triggers something.

## 2026-10-21T01:43:36.469Z · original line 123

Level 1 beaten (match grid to key → piece shrinks → walk into the slot). Writing the first concepts, then looking at level 2.

## 2026-10-21T01:54:27.429Z · original line 286

Rewriting the three match concepts to use the general key reader.

## 2026-10-21T01:57:17.804Z · original line 315

Testing the hypothesis that the 6-switch needs a real (not blocked) upward move; bar is nearly empty.

## 2026-10-21T01:59:00.876Z · original line 339

I reached level 4 and did not beat the game: I cleared levels 1–3, then hit GAME_OVER on level 4 when the budget bar ran out. I don't know how many levels the game has, because I never read the `levels_total` field.

**How the game works, as far as I could tell:**
- You move a square block with actions 1–4 (up, down, left, right). It moves one block-width at a time, or slides until it touches a wall. Its coloured half shows which way it last moved.
- You win a level by moving the block into the goal slot.
- Clicking cells in the bottom 3×3 grid lights them up. When the lit cells match the pattern on a "key" panel, an effect fires, and it depends on the key's colour:
  - **Level 1:** the key halved the block, so it fit through a 2-wide corridor to the goal.
  - **Level 2:** the key teleported the block to a box marked with bracket corners next to the goal.
  - **Level 3:** the key removed a switch box and the barrier blocking the corridor to the goal. It worked on only one of my three tries, and I never worked out the condition.

**Why level 4 failed:** I tried to open the barrier with that same key three times and it never worked. I tested two explanations: lining the block up under the switch's shaft while facing up, and getting there by an actual upward move. Both were wrong. Level 4 also drains the bar about three times faster than the earlier levels, so roughly 16 actions per level. That left no room for experiments. The next action after the bar emptied ended the game. I did not call reset.

**Lead for another attempt:** level 4 has a second key, the one that halves the block, and a small marked square I never touched. My guess is that the halved block is needed to line up exactly under the switch's shaft. That is untested.

As METHOD.md requires, every action had a bet placed beforehand and was settled afterwards: 83 transitions in all. The final settle showed no counterexamples and no errors. I retired one rule (the level-3 barrier rule) and kept the old versions in `history/`. Two caveats on the evidence:
- The rules for the shrink key and the teleport key each rest on a single observation, so they are effectively untested.
- I didn't write any frame-prediction code (`apply`), so there is no cell-level check of predictions; the bets were plain-text guesses.

The rules table, the dropped-mechanism audit and the level-4 notes are in `work/REPORT.md`. The rules themselves are in `concepts/`. The Lean step (step 2 of METHOD.md) is not done yet.

## 2026-10-21T02:06:49.040Z · original line 381

Waiting for the Lean compile to finish.

## 2026-10-21T02:07:42.412Z · original line 408

The Lean model is compiling. I'm waiting for the result before I write the answers.

## 2026-10-21T02:09:22.979Z · original line 426

**1. What happened on level 4.**
To reach the goal slot, the block has to get past a barrier (colour 13). In level 3, a barrier like this disappeared when I lit the grid in the pattern of the matching key (colour 6). That worked once in level 3, while the block faced up from directly under the switch's shaft. On level 4 I matched that key three times and the barrier never opened:
- once with the block one column-step to the right of the shaft;
- once from directly under the shaft, after a blocked "up" that only turned the block;
- once from the same cell after a real upward move.

Level 4 also drains the bar much faster: about 15 actions in total. With half the budget gone on those tries, the route to the goal no longer fit, and the next action after the bar emptied gave GAME_OVER.

The underlying cause is that I never found what makes the colour-6 effect fire. A second cause is that I ran experiments on a level whose budget leaves no slack.

**2. Can it still be beaten?** I think so, but the route I have in mind is unverified. The candidate is hypothesis H6: level 4 has two key panels and, unlike levels 1–3, shows no hint pattern on the grid at the start. Clicking a key panel shows its hint. So maybe a key's effect only fires if its panel has been selected first. In level 3, my one successful match came after I had clicked the key panel; on level 4 I never clicked one.

The route under H6 is 16 actions, 15 of which use budget:
- left, left, up (to row 21, column 29, facing up, under the shaft);
- click the colour-6 key panel;
- click grid cells 1, 4, 7;
- down, down;
- right ×7 (the last move enters the slot).

What I'd still need to check:
- **(a)** H6 itself: does the match open the barrier after the panel has been selected?
- **(b)** Budget is counted per action, at least 15 are allowed, and a key-panel click is free. In level 4, 15 actions were accepted and the 16th gave GAME_OVER. In level 3, key-panel clicks didn't move the bar.

The fallback hypothesis H5 is that the block must line up exactly under the 2-wide shaft. A 4×4 block can't do that on this board; it would need the shrink key, and that route is far over budget. That is why I lean towards H6.

**3. Next attempt.**
- Do left, left, up, then click the 6-key panel, then make the 6-key match.
- If the barrier opens, go down, down, then right ×7.
- If it doesn't open, use the remaining budget on one test of the shrink key plus alignment, or of the unvisited e-coloured marker. Place a bet before every action.

**4. Formal system.** This is new: it is the first one I've built. The object and rule tables, the simplification step and the drop audit are in `work/MODEL.md`.
- **Objects:**
  - block: row, column, facing
  - grid: 9-bit lit mask
  - key panels: fixed patterns, plus `sel`, the panel last clicked
  - barrier: open / closed
  - budget: `used`
  - `won` flag
  - Walls and slot are static.
- **Rules as definitions:**
  - MOVE: slide up to 4 cells; facing changes even when blocked
  - GOAL
  - CLICK
  - MATCH6, with `trig` left as a parameter
  - KEY
  - LIMIT = 15
- **Not in the model:**
  - the shrink effect and the teleport effect
  - the e-marker
  - the no-op on the very first move of the game

**5. Proof.** The file is `lean/L4Model.lean`. It compiles with no errors.
- `route_wins`: for any `trig` with `trig sPre = true`, the route wins. `sPre` is the state just before the matching click. Here, `trig` firing at `sPre` is an explicit hypothesis I did not establish.
- `route_needs_trig`: if `trig sPre = false`, the same route does not win.
- `closed_never_wins`: if the barrier never opens, no sequence of actions at all wins. This is checked by an invariant over every room position.
- `obs1`–`obs3`: the H6 candidate is false on the three level-4 failures I observed.
- `route_wins_H6`: the route wins under the H6 candidate.

The theorems rest on the rules MOVE, GOAL, CLICK, MATCH6 and KEY, and on the budget limit. Beyond those rules, the Lean model adds the assumptions that budget is counted per action and that panel clicks are free. Both are untested. The model is stricter than the game, so `closed_never_wins` says nothing about whether the real level is impossible.

`#print axioms`, verbatim:
```
'L4.route_wins' depends on axioms: [propext, Quot.sound]
'L4.route_needs_trig' depends on axioms: [propext, Quot.sound]
'L4.closed_never_wins' depends on axioms: [propext, Quot.sound]
'L4.route_wins_H6' depends on axioms: [propext, Quot.sound]
```
MAIN-THEOREM: lean/L4Model.lean : L4.route_wins

**6.** Not applicable: this attempt is where the formal system was first built.

VERDICT: winnable
CONFIDENCE: 60

## 2026-10-21T02:11:23.960Z · original line 464

Fixed a harness bookkeeping bug (duplicate transitions blocked the gate). Continuing the planned level-4 route.

## 2026-10-21T02:14:43.011Z · original line 511

I'm still on level 4 and haven't beaten the game; levels 1–3 are cleared. The bar is at 0 and I've stopped without taking another action, because last time an action at 0 ended the game. The game is not formally over yet.

This attempt was the whole level 4 run:
- **My main guess was wrong.** I thought clicking the colour-6 key panel first would make the barrier-opening match work. With the panel clicked and the block in the planned spot, the match still did nothing.
- **I found what opens the barrier.** It is the colour-6 match while the block faces up and its leftmost columns sit exactly on the 2-wide shaft's columns. The full-size block can't stop at that column, so the shrink key is needed first. Using the shrink key halved the block and kept its top-left corner. I moved the small block into the shaft and made the colour-6 match. The 6-box and the barrier both disappeared. The bar hit 0 on that same action.
- **The rule holds up so far.** I recorded it as `match6_shaft`, and it gives the right answer on all 6 colour-6 matches seen across levels 3 and 4. That is still a small sample.

**What's still unsolved:** the half-size block moves only 2 cells per step. Shrinking, opening the barrier, then walking to the slot comes to about 22 actions, and the level allows about 15. The likely shortcut involves the untouched 2×2 e-coloured marker. It might restore full size, or the opened box might lead somewhere; I haven't tested either.

I also patched one line in the harness's `settle.py`. Repeating the same moves as last attempt produced identical transitions, which left the action gate locked even after settling. The fix counts every logged transition instead of only unique ones.

Notes are in `work/REPORT.md` and the rules are in `concepts/`.

## 2026-10-21T02:15:20.707Z · original line 527

The game is over: GAME_OVER on level 4. I reached level 4 and did not beat the game; levels 1–3 are cleared. The bar was already at 0, so the one move I made ended the game, as it had in attempt 1.

What this attempt established on level 4:
- **Clicking the colour-6 key panel before matching does not open the barrier.** That was my main idea going in, and it was wrong.
- **What does open it:** first use the shrink key to halve the block. Then put the small block in the 2-wide shaft below the switch box, facing up, so its left edge sits on the shaft's left column. Then light the colour-6 key's pattern on the grid. The switch box and the barrier both disappeared. This is recorded as the rule `match6_shaft`. It gives the right result on all 6 colour-6 matches seen in levels 3 and 4, which is still a small sample.
- **Still unsolved:** the half-size block moves only 2 cells per step. Opening the barrier this way and then walking to the slot takes about 22 actions, and level 4 allows only about 15. The untouched 2×2 e-coloured marker is my best guess for the missing shortcut, perhaps by restoring full size.

Notes are in `work/REPORT.md`.

## 2026-10-21T02:20:25.946Z · original line 570

I'm adding the attempt-2 amendment (block size, shrink, the shaft-column trigger, and a budget lower bound) to the Lean model.

## 2026-10-21T02:26:19.659Z · original line 619

Proof compiles clean. Updating the model notes.

## 2026-10-21T02:26:45.508Z · original line 625

**1. What happened.** Level 4 has a barrier between the block and the goal. You open it by lighting the grid in the pattern of the colour-6 key, but only with the block in the right place.
- First I tested my attempt-1 idea: click the colour-6 key panel, then make the match with the full-size block under the switch's shaft. Nothing opened, so that idea is refuted.
- Next I used the other key, which halves the block. I moved the half-size block into the 2-wide shaft, so its left edge sat on the shaft's left column, faced it up, and made the colour-6 match. The barrier and the switch box both vanished.
- That used up the budget, about 15 actions. The next move ended the game.

The failure is structural. The full-size block can never sit on the shaft's columns, so the barrier needs the half-size block. That block moves only 2 cells per step, and the walk to the goal plus 7 grid clicks is longer than the budget.

**2. Can it be beaten?** Not under the rules I measured.
- **Lower bound:** the barrier must be opened. The full-size block only ever stands at columns 21, 25, …, 41, never at 31, so it has to be shrunk first. That takes 4 clicks, plus at least 3 more for the colour-6 match. After opening, the half-size block is at column 31 and moves at most 2 columns per step. Winning needs column ≥ 54, so that is at least 12 moves plus the entering move. Total: at least 20 actions.
- **Measured budget:** 15 actions. In both attempts, 15 actions ran and the 16th gave GAME_OVER.
- **What I did not establish:** that nothing outside the model exists. In particular:
  - nothing re-grows the block (the e-coloured 2×2 marker was never touched);
  - the trigger cannot fire at any column other than 31 (half-size blocks at columns 29 or 33 were not tested);
  - the budget is not larger for some mix of actions;
  - no shortcut through the opened switch box;
  - no effect from actions 5 or 7.

  Since the game presumably has a solution, one of these likely holds. The e-marker is my best guess.

**3. Next attempt.** I'd spend a cheap test on the e-marker: shrink, then step onto it, to see whether it re-grows or teleports the block. I'd also test a half-size block at another column. If something re-grows the block, the route would be: shrink, align, open, grow, then walk at 4 cells per step.

**4. Formal system.** I amended `lean/L4Model.lean` in place. The attempt-1 model `L4` is kept as the record, with a note that H6 is refuted. The new namespace `L4.V2` changes:
- **Block:** new slot `size` (4 or 2).
- **Shrink match:** now a definition: size 4 becomes 2, top-left corner kept.
- **Move and goal rules:** generalised to a block of any side.
- **Floor:** when the barrier opens, the switch box becomes floor too.
- **`sel` dropped:** H6 is refuted and no rule reads it; a key-panel click is a free no-op.
- **Colour-6 match:** `trig` is still a parameter. The theorem assumes only `trig ⇒ column = 31`.
- **Budget:** a parameter `LIM`; measured value 15.

Not in the model: re-grow, the e-marker, halving a size-2 block again, the first-move no-op, actions 5 and 7. The changes are listed in `work/MODEL.md`.

**5. Proof.** File: `lean/L4Model.lean`. It compiles with no errors, no `sorry`, and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V2.never_wins

- **Statement:** for every budget `LIM ≤ 19`, every trigger rule `trig` with `trig s ⇒ s.c = 31`, and every action list, `(run LIM trig start as).won = false`.
- **Proof idea:** an invariant (the block's phase, position grid and lit-cells bound) plus a potential `Φ` with `Φ + used ≥ 20` that no action can lower.
- **Instance at measured values:** `never_wins_measured`, with LIM = 15 and the measured trigger H5.
- **Rules it leans on:**
  - MOVE and GOAL (concepts `piece_step`, `goal_enter`)
  - CLICK (`grid_click`)
  - the shrink match (`grid_match`)
  - the colour-6 match (`match6_shaft`, through its weakened form)
  - the budget limit
- **Where the model goes beyond the rules:**
  - the budget is counted per action, with key-panel clicks free;
  - every mechanism listed as "not in the model" in step 4 is absent.

  Leaving them out makes the model stricter than the game. That is why the verdict is "in model".
- **Non-vacuity:** `route26_wins`: with the budget relaxed to 26 the model is winnable; the same route fails at 25 (`route26_short`). The smallest winning budget is somewhere between 20 and 26; I did not pin it down.

```
'L4.V2.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V2.never_wins_measured' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V2.route26_wins' depends on axioms: [propext]
```

**6.** Not applicable: this attempt changed the model (a new block-size slot, the shrink effect, the opening rule, `sel` dropped).

VERDICT: impossible_in_model_proved
CONFIDENCE: 55

## 2026-10-21T02:38:06.428Z · original line 750

The game is over: GAME_OVER on level 4. I reached level 4 and did not beat the game; levels 1–3 are cleared.

This attempt found three new things on level 4:
- **The e-coloured 2×2 marker refills the budget bar.** It only works for the half-size block: covering it with the full-size block did nothing. With the half-size block on it, the bar went from 16 back up to 48 rows. The marker is then used up, and no new one appeared.
- **The shrink key toggles size.** Matching it again on the half-size block regrows it to full size. Shrinking keeps the top-left corner and regrowing keeps the bottom-right corner. That lets the full-size block reach column 31, under the switch's shaft. Before this, I thought it could never get there.
- **Key matches need the exact pattern.** Lighting a superset of both keys' cells triggered nothing.

**Budget:** one model fits every bar reading across all three attempts. The level allows 18 units. A normal action costs 1, including a blocked move. The click that completes a match costs 2. Clicks that change nothing, including clicks on the key panels, are free. The refill gave back about 10 units.

**Why it's still not winnable:** I searched every route under these rules (`work/plan4.py`). The cheapest win costs 21 units net, or 20 if the block doesn't need to face up for the switch. With 18 available, it is still 2–3 units short, so some mechanism is still missing. I used the rest of the budget on small tests, and the last action ended the game.

The match rule in `concepts/grid_match.py` now says size toggles between 4 and 2. There is a new rule for the refill in `concepts/refill.py`, and the findings are written up in `work/REPORT.md`.

## 2026-10-21T02:44:39.170Z · original line 795

Rebuilding the attempt-3 Lean section (an encoding error lost the temp file).

## 2026-10-21T02:46:50.666Z · original line 822

Now re-writing the two Lean section files and merging.

## 2026-10-21T03:11:27.717Z · original line 866

Compile is running in the background. Meanwhile I'll update the model notes.

## 2026-10-21T03:11:45.848Z · original line 877

Waiting for the Lean compile to finish.

## 2026-10-21T03:27:59.462Z · original line 909

Compiling the table file and the proof; waiting on the background notification.

## 2026-10-21T03:44:07.105Z · original line 946

**1. What happened.** Level 4 is a small room. The goal slot is behind a barrier. Opening the barrier takes the colour-6 key pattern, made while the block sits exactly under a narrow shaft; at full size the block can never stop there.

This attempt found three things:
- **Refill marker:** the small e-coloured square is a one-time bar refill. It only works for the half-size block; the full-size block covering it did nothing.
- **Shrink key toggles:** matching it again on the half-size block grows it back to full size.
- **Exact matches only:** lighting a superset of both keys' cells triggers nothing.

With these, the bar readings from all three attempts fit one cost model:
- the level allows 18 units;
- a move costs 1, including a blocked one;
- the click that completes a match costs 2, other grid clicks cost 1;
- clicks that change nothing are free.

The failure is that, even using the refill and the grow, every route I can construct runs out of budget before reaching the slot.

**2. Can it be beaten?** Not under my measured rules; it falls short by at least one unit.

What I claim: no sequence of actions wins within 18 units. The argument is a search over every reachable state (`work/table4.py`). For each state it records the least budget spent to reach it, then checks every transition against that table. Every move into the slot starts from a state that already costs ≥ 18, so the winning move would be the 19th unit. With 19 units the same model has a winning route.

| Status | What |
|---|---|
| Established by observation | The floor map. Movement and slot entry. The shrink keeps the top-left corner. The grow happened once (it kept the bottom-right corner). The refill works only for the half-size block. Matches are exact. The 18-unit costs. |
| Assumed, loosened in my favour | The barrier trigger is "block's left column = 31" in any facing (H5 also requires facing up). The grow may use any of 5 anchors. The refill may happen anywhere along a slide and resets spent budget to min(k−9, 5). |
| Assumed outright | Nothing else exists: no second marker, no actions 5/7, no 1×1 size. The refill amount rests on one sample. A match can be treated as one atomic macro (argued in the file header; not proved in Lean). |

Given the game is presumably solvable, one of the outright assumptions is probably wrong. My best guesses are the refill size, or the order in which things are used.

**3. Next attempt.**
- Take the route that wins in the model with 19 units. Starting position (25,37), full size:
  1. down, down, left, left, left;
  2. shrink;
  3. left (onto the refill square);
  4. up;
  5. grow;
  6. right, right, then the colour-6 match (block at column 31);
  7. right ×6 into the slot.
- Watch the bar exactly at the refill to pin down its size.
- The route needs the grow to keep the bottom-left corner; the only observed grow kept the bottom-right, so whether this one works is untested.
- If the route stalls on budget, test whether a second refill exists after the first is used.

**4. Formal system (amended).**
- **Shrink rule:** now toggles size 4↔2 (shrink keeps top-left; grow is nondeterministic over 5 anchors).
- **New object:** the e-marker, with slot `rf`, and a new refill rule.
- **Budget:** re-measured in units, B = 18. The attempt-2 version, 15 actions, is superseded.
- **Colour-6 match:** trigger loosened to column 31 alone; the facing slot is dropped because no rule reads it.
- **Abstraction:** a match is modelled as one macro action, shrink/grow = 5 units, colour-6 = 4.
- **Not in the model:** other markers, actions 5/7, size 1.

Definitions are in `lean/L4ModelV3Tab.lean` (it imports `lean/L4Model.lean`, which still holds the attempt-1 and attempt-2 versions). Notes are in `work/MODEL.md`.

**5. Proof.** File: `lean/L4ModelV3.lean`, importing `L4ModelV3Tab.lean`. Both compile with no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4ModelV3.lean : L4.V3.never_wins

It says: for every budget B ≤ 18 and every action list, `(run B start as).won = false`. It relies on:
- **Rules from 4b:** movement, slot entry, shrink/grow, refill, the colour-6 match with c = 31, and the unit budget.
- **The table check:** a 1489-entry table of least spent budget per state, checked against every transition by `decide +kernel` in `checkPart0` through `checkPart15`.

Where the Lean model carries more than the rules:
- The match macro is the one step treated as atomic.
- A blocked grow is a costed no-op (never observed).
- Running out of budget leaves the state unchanged instead of ending the game. That is a no-op, so it adds no winning moves.

The Lean model is looser than the game where I was unsure, and stricter only through the outright assumptions in the table under question 2.

Non-vacuity: `route19_wins` wins at B = 19; `route19_at18` shows the same route does not win at 18.

```
'L4.V3.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V3.route19_wins' does not depend on any axioms
'L4.V3.route19_at18' does not depend on any axioms
```

**6.** Not applicable: the model changed (shrink/grow toggle, refill, unit budget).

VERDICT: impossible_in_model_proved
CONFIDENCE: 45

## 2026-10-25T07:36:27.708Z · original line 970

No response requested.

## 2026-10-25T07:37:24.319Z · original line 1196

Now update the proof file to use `gk_ok`, then compile the table file.

## 2026-10-25T07:39:35.750Z · original line 1236

Fast now (90 s total). One error left; looking at it.

## 2026-10-25T07:41:08.713Z · original line 1251

Single file compiles clean with no imports. Moving the split files out of `lean/` (kept as records in `work/`) and noting the change.

## 2026-10-25T07:41:30.649Z · original line 1270

`lean/L4ModelV3Tab.lean` failed to compile because it imported `L4Model` and no prebuilt `L4Model.olean` was there. Its table check also ran over all 131072 keys and took more than 16 minutes.

The fix is a packaging change. The objects, the rules and the table are the same as before.
- **One file:** the attempt-3 definitions and proofs (`L4.V3`) are now inside `lean/L4Model.lean`, after `L4.V2`. That file has no imports and compiles on its own in about 85 seconds.
- **Faster table check:** the 1489-entry table is now a binary search tree, and the kernel check `checkAll` runs only over its entries. `T.find_mem` proves that a value found by lookup is one of the checked entries.
- **Split files retired:** `L4ModelV3Tab.lean` and `L4ModelV3.lean` are moved out of `lean/`. They are kept as records in `work/*.split-retired.lean`.

The change and the reason are recorded in `work/MODEL.md`.

MAIN-THEOREM: lean/L4Model.lean : L4.V3.never_wins

The compile exits 0, the file has no `sorry` and no `native_decide`, and `#print axioms` gives:
```
'L4.V3.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V3.route19_wins' does not depend on any axioms
'L4.V3.route19_at18' does not depend on any axioms
```
The earlier theorems in the same file (`L4.route_wins` through `L4.V2.route26_wins`) also come back clean.

## 2026-10-25T07:51:14.509Z · original line 1362

Shrunk as predicted. Now growing back (expect 4x4 at (23,35)).

## 2026-10-25T07:51:52.557Z · original line 1382

Refill didn't fire for the 4x4 (hypothesis refuted). Budget is now too small to win; using the rest for one more test.

## 2026-10-25T07:52:16.900Z · original line 1389

Refill fired at (33,23) — bar back to 44 (k≈6, so refill = −10). Replanning from here.

## 2026-10-25T07:53:05.554Z · original line 1440

Gate open. Continuing the planned route: R, R, U, then the 6-match, then right ×6.

## 2026-10-25T07:53:31.302Z · original line 1452

Barrier is open. Six rights to the slot; the last one is on the budget edge.

## 2026-10-25T07:54:54.480Z · original line 1520

The game is over: I reached level 4 and did not beat it, so I did not beat the game. Levels 1–3 are cleared. This attempt ended on GAME_OVER on the very last move, one budget unit short.

What happened on level 4:
- **Route played:**
  1. Shrink the block, then grow it back, at the start.
  2. Walk to the refill marker, which restored the budget.
  3. Line the block up under the switch, facing up.
  4. Make the colour-6 match. This opened the barrier.
  5. Push right ×6 to the slot.
- **The last push failed.** It was made with the bar at 0, and the frame shows the block entering the slot, but the game ended instead of awarding the level. A winning move therefore has to start with budget still left.

What I learned:
- **Refill rule:** the marker only refills when the block covers it with both halves (it straddles the block's middle line). It returns 10 units. All four observations so far fit this rule.
- **Barrier trigger:** the colour-6 match also works with the full-size block in the room. It only needs to face up with its left column on the shaft column; it does not have to be in the shaft.
- **Shrink and grow:** shrink always keeps the top-left corner and grow the bottom-right (two observations each).

**Still short:** re-searching every route under these rules after the game ended, the cheapest win is 19 units and the level allows 18. So one mechanism is still missing. Candidates I haven't tested:
- how the grow behaves when its usual corner is blocked;
- whether the refill can happen a second time;
- whether some click is cheaper than I think.

I revised the refill rule and narrowed the slot-entry rule so it doesn't claim moves made with an empty bar. The notes are in `work/REPORT.md` and the route search is `work/plan5.py`.

## 2026-10-25T07:57:06.897Z · original line 1576

Writing the V4 amendment (facing back in, both-halves refill, clamp-anchor grow) into the Lean model.

## 2026-10-25T08:05:03.614Z · original line 1676

**1. What happened.** Level 4 is a room with a goal slot behind a barrier. The barrier opens when you light the colour-6 key pattern on the grid while the block's left column is at column 31. Every action uses budget, 18 units in total, and a refill marker gives 10 units back once. This attempt I played my best route:
- shrink and grow at the start, which shifts the block onto column 31;
- walk onto the refill marker;
- open the barrier from (29,31) facing up;
- push right six times to the slot.

Every step behaved as predicted, except that the refill fired at a different position than I expected. That corrected my refill rule: the marker has to lie under both halves of the block, at any size. It also confirmed the refill is −10 units, not "reset to 5". The last push started with the bar at 0. The block was drawn entering the slot, but the game declared GAME_OVER, not a win. The route cost 19 units and the budget is 18: it failed by one unit.

**2. Can it still be won?** Not under the rules I've measured, with one exception: how the block grows when facing left or up has never been observed. That is the assumption the impossibility rests on.
- **Claim:** in model V4, no action sequence wins with a budget of 18 or less.
- **Argument:** I computed the least budget needed to reach each of the 2304 reachable states. Lean checks, by kernel computation, that no transition can do better than that table. Every state from which a push enters the slot already costs at least 18. The winning push would then start at 18, and this attempt showed such a push ends the game.
- **Established by observation:**
  - the walls and the slot;
  - movement;
  - shrink keeps the top-left corner;
  - the both-halves refill rule and its −10 amount;
  - exact-pattern matches and the 18-unit costs;
  - that a push starting at k = 18 ends the game.
- **Loosened in my favour:**
  - the refill may fire at any point along a slide;
  - the barrier trigger is column 31 in any facing;
  - a grow whose usual corner is blocked may use any of 5 anchors.
- **Assumed without checking:**
  - a grow keeps the bottom-right corner whenever that fits (seen twice, facing down and facing right);
  - there is no second marker;
  - treating a key match as a single action loses no cheaper click order.

If the first assumption is wrong for a block facing left (keeping top-right instead), a route of exactly 18 exists. That is the only way left I can see.

**3. Next attempt.**
1. Left, shrink, then grow while facing left (11 units), and see where the grown block ends up.
2. If it lands at (25,31), finish with:
   - left, left, down, down (the refill fires here);
   - right, right, up;
   - the colour-6 match;
   - right ×6.

   That is 18 units, with the final push starting at 17.
3. If it lands anywhere else, the level is lost under every rule I know.

**4. Formal system (amended).** The new namespace `L4.V4` in `lean/L4Model.lean` changes:
- **Refill:** the V3 rule "only the half-size block refills" was refuted, so V3 had become stricter than the game. The new rule is the both-halves one, checked along the whole slide. The amount is −10.
- **Facing:** the facing slot is back, because the refill rule reads it.
- **Grow:** keeps bottom-right when that fits; otherwise any of the 5 anchors.
- **Barrier trigger:** column 31, any facing.
- **Budget:** an action only runs if k + cost ≤ 18; this attempt confirmed that.

Not in the model: a second marker, a 1×1 block, actions 5 and 7. `L4`, `L4.V2` and `L4.V3` stay in the file as the record. The changes are listed in `work/MODEL.md`, and the refill concept and the goal-entry concept were both revised.

**5. Proof.** The file `lean/L4Model.lean` compiles on its own with no imports, exit 0, in about 2.5 minutes. It contains no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

- **Statement:** for every budget B ≤ 18 and every action list, `(run B start as).won = false`.
- **Rules it leans on:** movement, slot entry, shrink and grow, refill, the colour-6 match, and the budget limit.
- **Treated as atomic:** a whole key match is one macro step costing 5 (shrink/grow) or 4 (colour-6).
- **Where the model is stricter than the game:** the "grow keeps bottom-right when it fits" assumption, and anything not in the model.
- **Non-vacuity:** `route19_wins` shows the same model wins at B = 19 with the route played this attempt; `route19_at18` shows that route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

VERDICT: impossible_in_model_proved
CONFIDENCE: 40

## 2026-10-25T08:08:36.243Z · original line 1709

BR kept again (3rd observation). Checking whether anything still wins from here.

## 2026-10-25T08:08:42.318Z · original line 1716

Not winnable from here even in the loosest model. Using the remaining budget to test the barrier trigger with the block facing left.

## 2026-10-25T08:09:01.747Z · original line 1726

The trigger needs facing up (confirmed: facing left at c=31 didn't open it). Only 3 units left and no possible win; playing out the remaining moves.

## 2026-10-25T08:09:34.523Z · original line 1742

The game is over: I reached level 4 and did not beat the game. Levels 1–3 are cleared; GAME_OVER came on level 4.

This attempt tested the only idea left that could win level 4 within its 18-unit budget. That idea needed the block, when it grows back to full size facing left, to keep its top-right corner. It kept its bottom-right corner, as in both earlier grows.

From that position I searched every route under the most generous version of my rules and found no win within the budget. I spent 4 of the remaining 7 units on one more test. Lighting the barrier key with the block facing left at column 31 did not open the barrier, so opening it needs the block to face up. That leaves no way through level 4 under any rule I have observed. I used the last few units on filler moves until the game ended.

Both results are added to `work/REPORT.md`.

## 2026-10-25T08:10:12.896Z · original line 1768

**1. What happened.** On level 4 the block has to get through a barrier to a goal slot. To open the barrier you light the colour-6 key pattern on the grid with the block's left column at 31 and the block facing up. The level has 18 units of budget, and one refill marker gives 10 back.

The full-size block can never stop at column 31 by moving; it can only get there by shrinking and then growing back. Last time my search found one way to fit the whole level into 18 units. It needed a grow while facing left to keep the block's top-right corner. This attempt I tested that first:
- the grow kept the bottom-right corner, as it did both earlier times, which leaves no route within 18;
- with the leftover budget I made the colour-6 match facing left at column 31, and the barrier stayed shut, so facing up is required;
- after that, filler moves used up the budget and the game ended.

The cause is the same as before: every opening route costs at least 19 units, and the level allows 18.

**2. Can it still be won?** Not under my measured rules.

The claim is that in model V4, no action sequence wins with a budget of 18 or less. The proof computes the least budget needed to reach each of the 2304 reachable states, and Lean checks every transition against that table. Any push into the slot then has to start at 18, and a push at 18 ends the game (seen in attempt 4).

What the claim rests on:
- **Established by observation:**
  - the walls, the slot and the movement rules;
  - shrink keeps the top-left corner;
  - grow keeps the bottom-right corner when it fits, now seen three times (facing down, right and left);
  - the refill fires when the marker is under both halves of the block, and gives back 10 units;
  - matches must be the exact pattern;
  - the unit costs and the 18-unit budget;
  - the 6-match needs column 31 and facing up.
- **Loosened in the player's favour:**
  - the refill may fire anywhere along a slide;
  - the 6-match trigger ignores facing;
  - a blocked grow may use any of 5 anchors.
- **Assumed, not checked:**
  - a grow facing up also keeps the bottom-right corner;
  - there is only one refill marker;
  - no click order is cheaper than treating each match as one step;
  - there are no other actions or effects.

I can't find a route even when I loosen the rules that much.

**3. Next attempt.** I would spend the budget on the remaining unknowns, since I see no winning route:
- a grow while facing up;
- whether a second refill ever appears;
- other cells and clicks I haven't touched.

**4.** The two attempt-5 observations are recorded in `work/MODEL.md` as evidence. Both were predicted by the existing V4 rules, so no definition changed.

FORMAL-UNCHANGED: Attempt 5 gave two results. First, a grow facing left kept the bottom-right corner; V4's grow rule already says that when the corner fits. Second, a 6-match facing left at column 31 failed; the concept `match6_shaft` already requires facing up, and V4's trigger, which ignores facing, is deliberately looser, so tightening it would only make the model stricter. Neither result contradicts a V4 definition, so `L4.V4` stands as it is. The model would have changed if the grow had kept another corner, or if the facing-left match had opened the barrier.

**5. Proof.** The file is unchanged from last attempt: `lean/L4Model.lean`, which compiles on its own with exit 0 and contains no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

- **What it states:** for every budget B ≤ 18 and every action list, the level is not won.
- **What it rests on:**
  - the rules for movement, slot entry, shrink and grow, refill, the 6-match (loosened to column 31 in any facing) and the budget limit;
  - one simplification: each key match counts as a single step costing 5 or 4 units;
  - the unchecked assumptions from question 2, which are where the model could be stricter than the real game.

Non-vacuity: `route19_wins` shows the same model is winnable with a budget of 19; `route19_at18` shows that route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

VERDICT: impossible_in_model_proved
CONFIDENCE: 50

## 2026-10-25T08:10:33.138Z · original line 1784

Testing an untried contact first: clicking the key panels themselves (only ever clicked when the block was misaligned, and never the f panel in level 4).

## 2026-10-25T08:10:53.216Z · original line 1791

Hint shows for free. Now running the attempt-4 route; at the aligned point I'll click the 6-key panel before doing the match.

## 2026-10-25T08:12:20.095Z · original line 1816

Panel click while aligned only shows the hint. Doing the regular 6-match and reading the bar precisely.

## 2026-10-25T08:12:40.775Z · original line 1823

Barrier open at k=13; 5 units left but 6 pushes needed, so the win is out of reach. First, a few clicks that should be free, on untouched elements.

## 2026-10-25T08:13:11.742Z · original line 1833

All free and inert. Pushing to the slot; the final push will start at k=18, which is known to fail.

## 2026-10-25T08:13:53.219Z · original line 1846

The game is over. I reached level 4 and did not beat the game. Levels 1–3 are cleared, and GAME_OVER came on level 4, one unit short of the budget again.

This attempt tested the one untried contact I could find: clicking the key panels directly. It doesn't help.
- **Key panels:** clicking the shrink-key panel at the start, or the barrier-key panel while the block was lined up correctly, only shows that key's pattern on the grid. It is free and does nothing else.
- **Hint cells:** lighting the grid cells of the shown pattern costs the same as any other click.
- **Other elements:** clicks on the slot, the opened switch box, the bar, the opened barrier and the block change nothing and cost nothing.

I then replayed my best route: shrink and grow, take the refill, open the barrier, and push right toward the slot. It behaved exactly as predicted. Its last push again began with the bar empty and ended the game.

My rules for level 4 still put every winning route at 19 units, against a budget of 18. These results are added to `work/REPORT.md`.

## 2026-10-25T08:14:21.605Z · original line 1869

**1. What happened.** Level 4 needs the block to reach a goal slot behind a barrier, and there are 18 units of budget. I first tested the one contact I had never tried: clicking the key panels directly.
- **Shrink-key panel**, at the start: it only showed the key's pattern on the grid. It cost nothing and did nothing else.
- **Barrier-key panel**, with the block at column 31 facing up (where a match opens the barrier): same result, hint only, free, no effect.
- **Other clicks:** the slot, the opened switch box, the bar, the opened barrier and the block itself all changed nothing and cost nothing.

I then replayed my best route: shrink and regrow to reach column 31, refill, open the barrier with the colour-6 match, push right. Every step went as predicted. That route costs 19 units, so its last push began with the bar empty, and the game ended. It failed because no route I know of fits into 18 units.

**2. Can it still be won?** Not under my measured rules.

What I claim: in model V4, no action sequence wins with a budget of 18 or less. The proof computes the least budget needed to reach each of the 2304 reachable states, and Lean checks every transition against that table by kernel computation. Every state that can push into the slot already costs 18. A push that starts at 18 ends the game, observed twice now.

What this rests on:
- **Established by observation:**
  - walls, movement and slot entry;
  - shrink keeps the top-left corner, grow keeps the bottom-right corner (three observations: facing down, right and left);
  - the refill fires when the marker is under both halves of the block, and gives back 10 units;
  - matches need the exact pattern;
  - the barrier trigger needs column 31 and facing up;
  - the costs and the 18-unit budget;
  - key-panel clicks and clicks that change nothing are free no-ops.
- **Loosened in the player's favour:**
  - the refill may fire at any point along a slide;
  - the barrier trigger ignores facing;
  - a grow whose usual corner is blocked may use any of 5 anchors.
- **Not checked:**
  - a grow while facing up (never observed);
  - there is no second refill marker;
  - doing a match as one atomic step loses no cheaper click order;
  - the game has no actions or effects beyond these.

**3. Next attempt.** I would test a grow while facing up, and any board cell I haven't clicked. If those show nothing new, I'd play the 19-unit route again, knowing it falls one unit short.

**4.** Attempt 6 changed no object, rule or Lean definition. I added its observations to `work/MODEL.md` as evidence.

FORMAL-UNCHANGED: V4 already treats key-panel clicks and zero-change clicks as free no-ops (they aren't in its action set). It already prices a match at 4 or 5 units whatever the hint state. The replayed route behaved exactly as V4 predicts. Attempt 6 only confirmed the panel no-op in the one case not yet seen: clicking the panel while lined up. The model would have changed if a panel click had triggered an effect, a hint cell had cost less, or a route step had behaved unlike V4.

**5. Proof.** The file is unchanged from last attempt: `lean/L4Model.lean`. It compiles on its own (exit 0), with no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

- **Statement:** for every budget B ≤ 18 and every action list, `(run B start as).won = false`.
- **Rules it leans on:** movement, slot entry, shrink and grow, the refill, the barrier trigger in its loosened form, and the budget limit.
- **Treated as atomic:** a whole key match counts as one step costing 5 or 4 units.
- **Where the model could be stricter than the game:** the four unchecked assumptions in question 2.
- **Non-vacuity:** `route19_wins` shows the model is winnable with a budget of 19; `route19_at18` shows the same route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

VERDICT: impossible_in_model_proved
CONFIDENCE: 50

## 2026-10-25T08:15:23.145Z · original line 1889

No new board elements visible. Checking if the one never-observed case (shrink while facing right) could open an 18-unit route.

## 2026-10-25T08:15:43.167Z · original line 1899

Every single-unknown variant still fails at 18. Zero-change clicks are free, so I'll scan the board with clicks to look for any hidden clickable effect.

## 2026-10-25T08:25:57.355Z · original line 1916

The scan has reached row 37 of 45; waiting for it to finish.

## 2026-10-25T08:28:43.570Z · original line 1929

The scan found nothing: every board click is inert. Using this budget to observe the two never-seen cases: grow facing up, then shrink facing right.

## 2026-10-25T08:29:51.563Z · original line 1942

Blocked grow kept top-right, which is in V4's allowed set. Now shrink facing right.

## 2026-10-25T08:30:29.914Z · original line 1952

Shrink facing right also keeps top-left. Budget is spent; finishing out.

## 2026-10-25T08:31:02.429Z · original line 1968

The game is over: I reached level 4 and did not beat the game. Levels 1–3 are cleared, and level 4 ended in GAME_OVER.

I started this attempt knowing my best route costs 19 units against level 4's budget of 18. So I used it to test the remaining unknowns, in case one of them hid a cheaper route:
- **Board click scan:** I clicked every third cell of the board, rows 1–45 and columns 1–60, skipping the key panels. Every click changed nothing and cost nothing, so there are no hidden clickable elements.
- **Shrink facing right:** the block kept its top-left corner. Shrink now keeps top-left in all four facings.
- **Grow facing up, with the usual corner blocked:** with a wall in the way of the usual bottom-right corner, it kept top-right instead, shifting to fit the floor. My model already allowed this case.
- **Search:** I also ran the route search with each of the never-observed shrink and grow variants filled in. None produced a route within 18 units.

None of this opened a cheaper route, and the budget ran out on the tests. The findings are added to `work/REPORT.md`, and the scan script is `work/scan.sh`.

## 2026-10-25T08:31:31.690Z · original line 1989

**1. What happened.** On level 4 the block has to reach a goal slot behind a barrier, and the level allows 18 budget units. My best route costs 19, so a straight attempt could not win. I spent this attempt testing the remaining unknowns, in case one of them hid a cheaper route:
- **Board scan:** I clicked every third cell of the board. All roughly 300 clicks changed nothing and cost nothing, so there is nothing hidden to click.
- **Shrink facing right:** the block kept its top-left corner. That is now seen in all four facings.
- **Grow facing up, with the usual bottom-right result blocked by a wall:** the block kept its top-right corner instead.

None of this opened a cheaper route. The budget ran out on these tests and the game ended. The underlying failure is the same as in earlier attempts: under every rule I have measured, winning needs 19 units and the level gives 18.

**2. Can it be won?** Not under my measured rules.
- **Claim:** in model V4, no action sequence wins with a budget of 18 or less.
- **Argument:** I computed the least budget needed to reach each of the 2304 reachable states. Lean checks, by kernel computation, that every transition respects that table. Every state from which a push could enter the slot already costs 18. A push that starts at 18 ends the game; I saw that twice.
- **Established by observation:**
  - movement and walls;
  - shrink keeps the top-left corner in every facing;
  - grow keeps the bottom-right corner when that fits (three times); when it is blocked, it shifts to fit (once);
  - the refill fires when the marker sits under both halves of the block, and gives back 10 units;
  - a match needs the exact pattern;
  - the barrier opens only at column 31 facing up;
  - the action costs and the 18-unit budget;
  - every other click is a free no-op.
- **Loosened in my favour:** the refill may fire anywhere along a slide; the barrier trigger ignores facing; a blocked grow may pick any of five anchors.
- **Not checked:**
  - there is no second refill marker or other hidden mechanism that only appears in states I never reached;
  - doing a whole match as one step loses no cheaper click order.

**3. Next attempt.** I have no untested lead left. I would play the 19-unit route once more, watching closely for anything that departs from the model, especially around the refill and the barrier. I expect it to fall one unit short again.

**4.** The formal system needed no change.

FORMAL-UNCHANGED: The board scan found only free no-op clicks, which is consistent with V4 having no other click actions. Shrink facing right kept the top-left corner, as V4's shrink rule says. The blocked grow kept the top-right corner, anchor (0,2); that is one of the five anchors V4 already allows when the bottom-right position is blocked. The model would have had to change if a scanned click had an effect, if the shrink had kept another corner, or if the blocked grow had landed outside V4's allowed set. I recorded these as evidence in `work/MODEL.md`.

**5. Proof.** The file is unchanged: `lean/L4Model.lean`. It compiles on its own (exit 0), with no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

- **What it says:** for every budget B ≤ 18 and every list of actions, `(run B start as).won = false`.
- **Rules it leans on:** movement, slot entry, shrink and grow, refill, the barrier match (loosened to ignore facing), and the budget limit.
- **Atomic step:** each match is one step costing 5 or 4 units.
- **Where the model could be stricter than the game:** the two unchecked assumptions in question 2.
- **Non-vacuity:** `route19_wins` shows the model is winnable with a budget of 19; `route19_at18` shows that route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

VERDICT: impossible_in_model_proved
CONFIDENCE: 55

## 2026-10-25T08:32:18.308Z · original line 2003

No new lead. I'll replay the best-known route with a bet at every step and watch for any deviation from V4.

## 2026-10-25T08:36:14.661Z · original line 2035

The game is over: I reached level 4 and did not beat the game. Levels 1–3 are cleared.

On level 4 I replayed my best route, which costs 19 budget units against the level's 18:
1. Shrink, then grow the block back.
2. Take the refill.
3. Open the barrier with the colour-6 match.
4. Push right six times to the slot.

Every step matched my model: block positions, the refill, the barrier opening, and the budget bar after each action. The sixth push started with the bar at 0, so the game ended instead of awarding the level, as it did in earlier attempts.

No new mechanism showed up. Under the rules I have measured, level 4 still cannot be won within its budget. This attempt is recorded in `work/REPORT.md`.

## 2026-10-25T08:36:39.482Z · original line 2061

**1. What happened.** On level 4 the block has to reach a goal slot behind a barrier, and the level allows 18 budget units. I replayed my best-known route:
1. Shrink the block, then grow it back, which shifts it onto column 31.
2. Walk onto the refill marker, which gives back 10 units.
3. Move under the switch facing up and make the colour-6 match, which opens the barrier.
4. Push right six times to the slot.

Every step behaved exactly as my model predicts. The route costs 19 units. The sixth push therefore started with the bar at 0, and the game ended instead of awarding the level, for the third time. It fails because, under every rule I have measured, the cheapest win costs one unit more than the budget.

**2. Can it be won?** Not under my measured rules.
- **Claim:** in model V4, no action sequence wins with a budget of 18 or less.
- **Argument:** I computed the least budget needed to reach each of the 2304 reachable states. Lean checks every transition against that table by kernel computation. Every state from which a push could enter the slot already costs 18, and a push that starts at 18 ends the game (observed three times).
- **Established by observation:**
  - movement and walls;
  - shrink keeps the top-left corner (all four facings);
  - grow keeps the bottom-right corner when that fits; when that is blocked it shifted to fit (seen once);
  - the refill fires when the marker sits under both halves of the block, and gives back 10 units;
  - matches need the exact pattern;
  - the barrier opens only at column 31 facing up;
  - action costs and the 18-unit budget;
  - every other click is a free no-op.
- **Loosened in my favour:**
  - the refill may fire at any point of a slide;
  - the barrier trigger ignores facing;
  - a blocked grow may use any of five anchors.
- **Not checked:**
  - that there is no hidden mechanism appearing only in states I never reached;
  - that treating a whole match as one step loses no cheaper click order.

**3. Next attempt.** I have no untested lead. I would replay the route while watching for any deviation, and use spare free actions to probe anything I haven't touched.

**4.** No change to the formal system. I added the replay to `work/MODEL.md` as evidence.

FORMAL-UNCHANGED: Attempt 8 replayed the route V4 predicts, and every transition matched V4, including the refill, the barrier opening and the game ending on the push at k=18. Nothing new was tried, and no observation contradicted or extended a definition. The model would have changed only if some step had deviated from V4's prediction.

**5. Proof.** The file is unchanged: `lean/L4Model.lean`. It compiles on its own (exit 0), with no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

- **Statement:** for every budget B ≤ 18 and every action list, `(run B start as).won = false`.
- **Rules it leans on:** movement, slot entry, shrink and grow, refill, the barrier match in its loosened form, and the budget limit.
- **Modelling choice:** each match is one atomic step costing 5 or 4 units.
- **Where the model could be stricter than the game:** the two unchecked assumptions in question 2.
- **Non-vacuity:** `route19_wins` shows the model is winnable with a budget of 19; `route19_at18` shows that route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

VERDICT: impossible_in_model_proved
CONFIDENCE: 55

## 2026-10-25T08:37:07.306Z · original line 2074

**1. What happened.** On level 4 the block has to reach a goal slot on the right, behind a barrier, and the level gives 18 budget units.
- **Barrier:** it opens only by lighting the colour-6 key pattern on the grid while the block faces up with its left column at column 31.
- **Column 31:** the full-size block only ever lands on columns 21, 25, 29, 33, 37 or 41, so it can never stop at 31 by moving. Getting there takes a shrink followed by a regrow, which costs 10 units.
- **Refill:** one marker gives back 10 units, once.

My best route does the shrink and regrow, takes the refill, opens the barrier, and pushes right six times to the slot. Every step behaved exactly as my model predicted. The route costs 19 units, so the sixth push starts with the bar empty. A push that starts with the bar empty ends the game instead of winning; I saw this three times. The level failed because, under every rule I measured, the cheapest win costs one unit more than the budget.

**2. Can it still be won?** Not under my measured rules.

What I claim: in my model V4, no sequence of actions wins with a budget of 18 or less.

The argument:
- I computed, for each of the 2304 reachable states, the least budget needed to reach it.
- Lean checks every transition against that table by kernel computation.
- Every state from which a push can enter the slot already costs 18. The winning push would have to start at 18, and that ends the game.

What it rests on:
- **Established by observation:**
  - walls, the 4-cell full-size step and 2-cell half-size step, slot entry;
  - shrink keeps the top-left corner, in all four facings;
  - grow keeps the bottom-right corner when that fits (three times); when that position is blocked it shifted to fit (once);
  - the refill fires when the marker sits under both halves of the block, gives back 10 units, and is used up;
  - key matches must be the exact pattern;
  - the barrier opens only at column 31 facing up;
  - costs: a move is 1, a cell click is 1, the click completing a match is 2; clicks that change nothing are free;
  - the budget of 18, and that an action starting at 18 ends the game.
- **Loosened in my favour:**
  - the refill may fire at any position along a slide;
  - the barrier trigger ignores facing;
  - a blocked grow may land at any of five anchors.
- **Assumed, not checked:**
  - there is no second marker and no mechanism that appears only in states I never reached;
  - treating a whole key match as one step loses no cheaper order of clicks. I believe this, because a match resets the grid and clicks never move the block, but it is not proved in Lean.

**3. Rules I worked out across these attempts:**
- **Barrier trigger.** The full-size block failed at columns 29 and 33 even facing up. A half-size block in the shaft at column 31 facing up succeeded. A full-size block at (29,31) facing up in the room succeeded. A full-size block at (23,31) facing left failed. So the trigger is column 31 and facing up.
- **Shrink key is a toggle.** Matching it on the half-size block grew it back. Shrink keeps the top-left corner; grow keeps the bottom-right corner, seen when (33,23) grew to (31,21).
- **Refill condition.** A full-size block covering the marker with only one half (at (33,21) facing left, and at (31,23) facing down) did nothing. A half-size block at (33,23) facing right, and a full-size block at (33,23) facing down, both refilled. So the marker must sit under both halves of the block. The bar went 12 to 44, which fixes the amount at −10 rather than "reset to 5".
- **Budget.** Bar readings fit 18 units with a move costing 1 and a completing click costing 2. A push that starts at 18 ends the game even when it would enter the slot.
- **Key panels.** Clicking a key panel only shows that key's pattern on the grid. It is free and does nothing else, even with the block correctly lined up.

**4. Rules I'm still unsure about:**
- **Grow when the usual corner is blocked.** Seen once (it kept the top-right corner). The model allows any of five anchors.
- **Refill along a slide.** Whether the refill can fire partway through a slide, or only where the block stops. The model allows both.
- **Barrier trigger.** Whether it reads only the column and facing, or also something like a clear line up the shaft. The model ignores facing.
- **Match cost.** I measured that a cell click costs 1 and the completing click costs 2. I have not proved that no order of clicks undercuts the macro cost of 5 and 4.
- **Completeness.** Whether anything exists beyond what I've seen. A full board click scan and the panel tests found nothing.

**5. Lean proof.** `lean/L4Model.lean` is a single file with no imports. It compiles with exit 0 and contains no `sorry` and no `native_decide`.

MAIN-THEOREM: lean/L4Model.lean : L4.V4.never_wins

```
theorem never_wins (B : Nat) (hB : B ≤ 18) (as : List Act) : (run B start as).won = false
```

- **What it quantifies over:** every budget B ≤ 18 and every finite list of actions: moves in four directions, a grow with any of five anchors, and the colour-6 match.
- **Hypotheses:** none besides B ≤ 18. The modelling choices are in the definitions and listed in the file header: a match is one step costing 5 or 4 units, plus the loosened rules from question 2.
- **How it is proved:** an invariant `J` says the spent budget is at least the tabled least cost for the current state. `checkAll_true` verifies, by `decide +kernel`, every transition of every tabled state. `T.find_mem` connects table lookup to the checked list.
- **Non-vacuity:** `route19_wins` shows the same model wins at B = 19; `route19_at18` shows that route fails at 18.

```
'L4.V4.never_wins' depends on axioms: [propext, Classical.choice, Quot.sound]
'L4.V4.route19_wins' does not depend on any axioms
'L4.V4.route19_at18' does not depend on any axioms
```

The step from my model to the real game is assumed, not established. It needs the game to have no mechanism beyond what I observed, and treating a match as one step to lose no cheaper click order. Since the level presumably has a solution, one of these probably fails, which is why my confidence is moderate.

VERDICT: impossible_in_model_proved
CONFIDENCE: 50