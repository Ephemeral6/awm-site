/-!
# Level 4 model (attempt 1)

Objects (see work/MODEL.md for the object/rule tables and the drop audit):
* piece      : top-left (r, c), side 4 (fixed: shrink effect NOT IN MODEL), facing
* grid       : 9-bit lit mask
* key panels : two fixed patterns (6-key = cells 1,4,7 = 146; f-key = cells 1,3,5,7 = 170),
               plus `sel` = the panel last clicked (0 = none)  -- slot of HYPOTHESIS H6
* barrier    : `op` (true = 6-box and colour-13 barrier gone)
* slot       : static (rows 29-32, cols 57-60)
* walls      : static floor map measured from the L4 frame
* budget     : `used` = number of budget-consuming actions; LIMIT = 15 (measured: 15 actions
               were executed in L4 without GAME_OVER, the 16th gave GAME_OVER)

Rules (each a definition below):
* MOVE   (concept piece_step + piece_facing): slide up to 4 cells, stop at non-floor; facing := dir
         even when blocked (observed L4).
* GOAL   (concept goal_enter): if the footprint shifted by 4 hits a slot cell, the level is won.
* CLICK  (concept grid_click): toggle bit i.
* MATCH6 : lit = 146 ⇒ lit := 0 and op := op || trig s.  `trig` is a PARAMETER: the condition
           under which the 6-match opens the barrier was NOT established (fired once in L3, failed
           3 times in L4). It is never fixed inside a definition; theorems take it as a hypothesis.
* MATCHF : lit = 170 ⇒ lit := 0; the shrink effect is NOT IN MODEL.
* KEY    : clicking a key panel sets `sel`; costs no budget (L3: key-panel clicks did not move the bar).
-/

namespace L4

def box (y0 y1 x0 x1 y x : Nat) : Bool :=
  Nat.ble y0 y && Nat.ble y y1 && Nat.ble x0 x && Nat.ble x x1

def inRoom    : Nat → Nat → Bool := box 21 36 21 44
def inShaft   : Nat → Nat → Bool := box 9 20 31 32
def inBarrier : Nat → Nat → Bool := box 29 32 45 47
def inCorr    : Nat → Nat → Bool := box 29 32 48 56
def inSlot    : Nat → Nat → Bool := box 29 32 57 60

def floorC (op : Bool) (y x : Nat) : Bool :=
  inRoom y x || inShaft y x || inCorr y x || (op && inBarrier y x)

def fpAll (P : Nat → Nat → Bool) (r c : Nat) : Bool :=
  (List.range 4).all (fun i => (List.range 4).all (fun j => P (r + i) (c + j)))

def fpAny (P : Nat → Nat → Bool) (r c : Nat) : Bool :=
  (List.range 4).any (fun i => (List.range 4).any (fun j => P (r + i) (c + j)))

inductive Dir | U | D | L | R
  deriving DecidableEq, Repr

def shift : Dir → Nat → Nat × Nat → Nat × Nat
  | .U, k, (r, c) => (r - k, c)
  | .D, k, (r, c) => (r + k, c)
  | .L, k, (r, c) => (r, c - k)
  | .R, k, (r, c) => (r, c + k)

def slideAux (op : Bool) (d : Dir) (p : Nat × Nat) : Nat → Nat → Nat
  | 0, k => k
  | n + 1, k =>
    let q := shift d (k + 1) p
    if fpAll (floorC op) q.1 q.2 then slideAux op d p n (k + 1) else k

def slide (op : Bool) (d : Dir) (p : Nat × Nat) : Nat := slideAux op d p 4 0

/-- MOVE + GOAL: (won?, new top-left). -/
def move (op : Bool) (d : Dir) (p : Nat × Nat) : Bool × (Nat × Nat) :=
  let q := shift d 4 p
  if fpAny inSlot q.1 q.2 then (true, p) else (false, shift d (slide op d p) p)

structure St where
  r : Nat
  c : Nat
  face : Dir
  lit : Nat
  sel : Nat
  op : Bool
  won : Bool
  used : Nat
  deriving DecidableEq, Repr

inductive Act
  | mv (d : Dir)
  | cell (i : Nat)
  | key (k : Nat)

def LIMIT : Nat := 15
def key6 : Nat := 146
def keyF : Nat := 170

def live (s : St) : Bool := !s.won && !(Nat.ble LIMIT s.used)

def act (trig : St → Bool) (s : St) : Act → St
  | .mv d =>
    let m := move s.op d (s.r, s.c)
    { s with r := m.2.1, c := m.2.2, face := d, won := m.1, used := s.used + 1 }
  | .cell i =>
    if Nat.ble 9 i then s else
    let l := Nat.xor s.lit (2 ^ i)
    if l == key6 then { s with lit := 0, op := s.op || trig s, used := s.used + 1 }
    else if l == keyF then { s with lit := 0, used := s.used + 1 }
    else { s with lit := l, used := s.used + 1 }
  | .key k => { s with sel := k }

def step (trig : St → Bool) (s : St) (a : Act) : St :=
  if live s then act trig s a else s

def run (trig : St → Bool) (s : St) (as : List Act) : St := as.foldl (step trig) s

def start : St := ⟨25, 37, .D, 0, 0, false, false, 0⟩

def pre : List Act := [.mv .L, .mv .L, .mv .U, .key 6, .cell 1, .cell 4]
def rest : List Act :=
  [.cell 7, .mv .D, .mv .D, .mv .R, .mv .R, .mv .R, .mv .R, .mv .R, .mv .R, .mv .R]
def route : List Act := pre ++ rest

/-- The state right before the matching click. -/
def sPre : St := ⟨21, 29, .U, 18, 6, false, false, 5⟩

def never : St → Bool := fun _ => false

/-- an action whose outcome cannot depend on `trig` (it is not a matching 6-click) -/
def safe (s : St) : Act → Bool
  | .cell i => !(Nat.xor s.lit (2 ^ i) == key6)
  | _ => true

def safeRun : St → List Act → Bool
  | _, [] => true
  | s, a :: as => safe s a && safeRun (step never s a) as

theorem step_eq (trig : St → Bool) (s : St) (a : Act) (h : safe s a = true) :
    step trig s a = step never s a := by
  cases a with
  | mv d => rfl
  | key k => rfl
  | cell i =>
    simp only [safe, Bool.not_eq_true', beq_eq_false_iff_ne, ne_eq] at h
    have h' : ¬ (s.lit ^^^ 2 ^ i = key6) := h
    simp [step, act, h']

theorem run_eq (trig : St → Bool) (as : List Act) :
    ∀ s, safeRun s as = true → run trig s as = run never s as := by
  induction as with
  | nil => intro s _; rfl
  | cons a as ih =>
    intro s h
    simp only [safeRun, Bool.and_eq_true] at h
    simp only [run, List.foldl_cons] at *
    rw [step_eq trig s a h.1]
    exact ih _ h.2

theorem pre_run (trig : St → Bool) : run trig start pre = sPre := by
  rw [run_eq trig pre start (by decide)]; decide

def afterMatch (b : Bool) : St := ⟨21, 29, .U, 0, 6, b, false, 6⟩

theorem match_step (trig : St → Bool) : step trig sPre (.cell 7) = afterMatch (trig sPre) := by
  rfl

def rest' : List Act := rest.tail

theorem rest_open (trig : St → Bool) : (run trig (afterMatch true) rest').won = true := by
  rw [run_eq trig rest' _ (by decide)]; decide
theorem rest_closed (trig : St → Bool) : (run trig (afterMatch false) rest').won = false := by
  rw [run_eq trig rest' _ (by decide)]; decide

theorem run_append (trig : St → Bool) (s : St) (a b : List Act) :
    run trig s (a ++ b) = run trig (run trig s a) b := by
  simp [run, List.foldl_append]

/-- MAIN: if the 6-match fires at `sPre`, the 16-action route (15 budget-consuming) wins. -/
theorem route_wins (trig : St → Bool) (h : trig sPre = true) :
    (run trig start route).won = true := by
  have e : route = pre ++ ([.cell 7] ++ rest') := rfl
  rw [e, run_append, run_append, pre_run]
  have : run trig sPre [.cell 7] = afterMatch (trig sPre) := by
    simp [run, match_step]
  rw [this, h]
  exact rest_open trig

/-- Direction check: the hypothesis is used — without it the same route does not win. -/
theorem route_needs_trig (trig : St → Bool) (h : trig sPre = false) :
    (run trig start route).won = false := by
  have e : route = pre ++ ([.cell 7] ++ rest') := rfl
  rw [e, run_append, run_append, pre_run]
  have : run trig sPre [.cell 7] = afterMatch (trig sPre) := by
    simp [run, match_step]
  rw [this, h]
  exact rest_closed trig

/-! ## The premise is a real constraint: if the barrier never opens, NO action string wins. -/

def okB (d : Dir) (r c : Nat) : Bool :=
  let m := move false d (r, c)
  !m.1 && Nat.ble 21 m.2.1 && Nat.ble m.2.1 33 && Nat.ble 21 m.2.2 && Nat.ble m.2.2 41

def checkB : Bool :=
  [Dir.U, Dir.D, Dir.L, Dir.R].all fun d =>
    (List.range 13).all fun i => (List.range 21).all fun j => okB d (21 + i) (21 + j)

theorem checkB_true : checkB = true := by decide

theorem okB_all (d : Dir) (r c : Nat) (h1 : 21 ≤ r) (h2 : r ≤ 33) (h3 : 21 ≤ c) (h4 : c ≤ 41) :
    okB d r c = true := by
  have hc := checkB_true
  simp only [checkB, List.all_eq_true, List.mem_range] at hc
  have hd : d ∈ [Dir.U, Dir.D, Dir.L, Dir.R] := by cases d <;> simp
  have := hc d hd (r - 21) (by omega) (c - 21) (by omega)
  have e1 : 21 + (r - 21) = r := by omega
  have e2 : 21 + (c - 21) = c := by omega
  rw [e1, e2] at this
  exact this

def Inv (s : St) : Prop :=
  s.op = false ∧ s.won = false ∧ 21 ≤ s.r ∧ s.r ≤ 33 ∧ 21 ≤ s.c ∧ s.c ≤ 41

theorem step_inv (s : St) (a : Act) (h : Inv s) : Inv (step never s a) := by
  obtain ⟨hop, hw, h1, h2, h3, h4⟩ := h
  unfold step
  split
  · cases a with
    | mv d =>
      have hk := okB_all d s.r s.c h1 h2 h3 h4
      simp only [okB, Bool.and_eq_true, Bool.not_eq_true', Nat.ble_eq] at hk
      obtain ⟨⟨⟨⟨k0, k1⟩, k2⟩, k3⟩, k4⟩ := hk
      simp only [act, Inv, hop]
      exact ⟨trivial, k0, k1, k2, k3, k4⟩
    | cell i =>
      simp only [act]
      split
      · exact ⟨hop, hw, h1, h2, h3, h4⟩
      · split
        · simp only [Inv, hop, never, Bool.or_false]; exact ⟨trivial, hw, h1, h2, h3, h4⟩
        · split
          · exact ⟨hop, hw, h1, h2, h3, h4⟩
          · exact ⟨hop, hw, h1, h2, h3, h4⟩
    | key k => exact ⟨hop, hw, h1, h2, h3, h4⟩
  · exact ⟨hop, hw, h1, h2, h3, h4⟩

theorem run_inv (as : List Act) : ∀ s, Inv s → Inv (run never s as) := by
  induction as with
  | nil => intro s h; exact h
  | cons a as ih =>
    intro s h
    simp only [run, List.foldl_cons]
    exact ih _ (step_inv s a h)

theorem closed_never_wins (as : List Act) : (run never start as).won = false :=
  (run_inv as start ⟨rfl, rfl, by decide, by decide, by decide, by decide⟩).2.1

/-! ## Candidate H6 for `trig`, checked against the observed L4 failures. -/

/-- H6 (UNVERIFIED): the 6-match opens the barrier iff the 6-key panel was selected and the piece
    faces up at (21,29), the cell under the shaft. -/
def trigH6 (s : St) : Bool := s.sel == 6 && s.face == .U && s.r == 21 && s.c == 29

-- the three observed L4 6-matches that did NOT open the barrier (no panel had been clicked)
theorem obs1 : trigH6 ⟨21, 33, .U, 18, 0, false, false, 4⟩ = false := by decide
theorem obs2 : trigH6 ⟨21, 29, .U, 18, 0, false, false, 9⟩ = false := by decide
theorem obs3 : trigH6 ⟨21, 29, .U, 18, 0, false, false, 13⟩ = false := by decide
theorem h6_fires : trigH6 sPre = true := by decide

theorem route_wins_H6 : (run trigH6 start route).won = true := route_wins trigH6 h6_fires

/-! **Attempt 2 refuted H6**: the real game was driven to exactly `sPre` (panel 6 clicked, piece
    (21,29) facing U, lit {1,4}) and the matching click did NOT open the barrier. So
    `trigH6 sPre = true` is false of the game, and `route_wins_H6` is a theorem about a rejected
    rule. `route_wins` stays true but its hypothesis is now known false for this `sPre`.
    The model is amended in `L4.V2` below. -/

end L4

/-! # Amendment (attempt 2) — `L4.V2`

Changes against `L4` (reused unchanged: `box`, room/shaft/barrier/corridor/slot maps, `shift`,
`Dir`, `key6`, `keyF`):
* object piece gains slot `size` (4 or 2).                     [attempt 2: the f-match halved it]
* rule MATCHF now has its effect: size 4 ⇒ 2, top-left kept.   [attempt 2; L1]
* rules MOVE / GOAL generalised to side `size` (step = side).  [L1: the 2x2 moved by 2]
* floor: when the barrier opens, the 6-box also becomes floor. [attempt 2 frame]
* slot `sel` DROPPED: H6 refuted (attempt 2) and no rule reads it; key-panel click = free no-op.
* rule MATCH6: `trig` stays a parameter. The measured rule H5 ("the block's left column = the
  shaft's left column 31, facing up") is used only through the LOOSER hypothesis
  `trig s = true → s.c = 31` (facing and row are not required).
* budget: `LIM` is a parameter; measured value 15 (both attempts: 15 actions ran, the 16th gave
  GAME_OVER).
* NOT IN MODEL: size-2 → size-1 halving (unobserved), any re-grow, the e-marker at (34,23),
  the first-move no-op, ACTION5/7.
-/
namespace L4.V2
open L4 (box inRoom inShaft inBarrier inCorr inSlot Dir shift key6 keyF)

def inBox : Nat → Nat → Bool := box 5 8 30 33

def floorC (op : Bool) (y x : Nat) : Bool :=
  inRoom y x || inShaft y x || inCorr y x || (op && (inBarrier y x || inBox y x))

def fpAll (P : Nat → Nat → Bool) (n r c : Nat) : Bool :=
  (List.range n).all (fun i => (List.range n).all (fun j => P (r + i) (c + j)))
def fpAny (P : Nat → Nat → Bool) (n r c : Nat) : Bool :=
  (List.range n).any (fun i => (List.range n).any (fun j => P (r + i) (c + j)))

def slideAux (op : Bool) (n : Nat) (d : Dir) (p : Nat × Nat) : Nat → Nat → Nat
  | 0, k => k
  | m + 1, k =>
    let q := shift d (k + 1) p
    if fpAll (floorC op) n q.1 q.2 then slideAux op n d p m (k + 1) else k

/-- MOVE + GOAL for a block of side `n`. -/
def move (op : Bool) (n : Nat) (d : Dir) (p : Nat × Nat) : Bool × (Nat × Nat) :=
  let q := shift d n p
  if fpAny inSlot n q.1 q.2 then (true, p) else (false, shift d (slideAux op n d p n 0) p)

structure St where
  r : Nat
  c : Nat
  face : Dir
  lit : Nat
  op : Bool
  won : Bool
  used : Nat
  size : Nat
  deriving DecidableEq, Repr

inductive Act
  | mv (d : Dir)
  | cell (i : Nat)
  | key

def act (trig : St → Bool) (s : St) : Act → St
  | .mv d =>
    let m := move s.op s.size d (s.r, s.c)
    { s with r := m.2.1, c := m.2.2, face := d, won := m.1, used := s.used + 1 }
  | .cell i =>
    if 9 ≤ i then s else
    if s.lit ^^^ 2 ^ i = key6 then { s with lit := 0, op := s.op || trig s, used := s.used + 1 }
    else if s.lit ^^^ 2 ^ i = keyF then
      { s with lit := 0, size := (if s.size = 4 then 2 else s.size), used := s.used + 1 }
    else { s with lit := s.lit ^^^ 2 ^ i, used := s.used + 1 }
  | .key => s

def step (LIM : Nat) (trig : St → Bool) (s : St) (a : Act) : St :=
  if s.won = false ∧ s.used < LIM then act trig s a else s

def run (LIM : Nat) (trig : St → Bool) (s : St) (as : List Act) : St :=
  as.foldl (step LIM trig) s

def start : St := ⟨25, 37, .D, 0, false, false, 0, 4⟩

/-- H5 as measured (L3 success; attempt-2 L4 success; L4 failures at c = 29, 33). -/
def trigH5 (s : St) : Bool := s.face == .U && s.c == 31

/-! ## Lower bound: potential Φ; no action lowers Φ + used. -/

def popc (n : Nat) : Nat := (List.range 9).foldl (fun a i => a + n / 2 ^ i % 2) 0
def dF (l : Nat) : Nat := popc (l ^^^ keyF)
def d6 (l : Nat) : Nat := popc (l ^^^ key6)
def Rc (c : Nat) : Nat := (55 - c) / 2 + 1

def Φ (s : St) : Nat :=
  if s.won then 0 else if s.op then Rc s.c
  else if s.size = 4 then dF s.lit + 16 else d6 s.lit + 13

def rows4 : List Nat := [21, 25, 29, 33]
def cols4 : List Nat := [21, 25, 29, 33, 37, 41]
def dirs : List Dir := [.U, .D, .L, .R]

def S2 (r c : Nat) : Bool :=
  Nat.ble 9 r && Nat.ble r 35 && Nat.ble 21 c && Nat.ble c 43 && fpAll (floorC false) 2 r c

def Ph (s : St) : Prop :=
  (s.size = 4 ∧ s.op = false ∧ s.r ∈ rows4 ∧ s.c ∈ cols4) ∨
  (s.size = 2 ∧ s.op = false ∧ S2 s.r s.c = true) ∨
  (s.size = 2 ∧ s.op = true)

def J (LIM : Nat) (s : St) : Prop :=
  s.won = false ∧ s.lit < 512 ∧ s.used ≤ LIM ∧ 20 ≤ Φ s + s.used ∧ Ph s

theorem lA : ∀ r ∈ rows4, ∀ c ∈ cols4, ∀ d ∈ dirs,
    (move false 4 d (r, c)).1 = false ∧ (move false 4 d (r, c)).2.1 ∈ rows4 ∧
    (move false 4 d (r, c)).2.2 ∈ cols4 := by decide

theorem lAB : ∀ r ∈ rows4, ∀ c ∈ cols4, S2 r c = true := by decide

theorem lB : ∀ r, r < 36 → ∀ c, c < 44 → S2 r c = true → ∀ d ∈ dirs,
    (move false 2 d (r, c)).1 = false ∧
    S2 (move false 2 d (r, c)).2.1 (move false 2 d (r, c)).2.2 = true := by
  decide

def chk (l i : Nat) : Bool :=
  decide (l ^^^ 2 ^ i < 512) && decide (dF l ≤ dF (l ^^^ 2 ^ i) + 1) &&
  decide (d6 l ≤ d6 (l ^^^ 2 ^ i) + 1) &&
  (!(l ^^^ 2 ^ i == keyF) || (dF l == 1 && decide (d6 l ≤ 4))) &&
  (!(l ^^^ 2 ^ i == key6) || d6 l == 1)

theorem chkAll : ((List.range 512).all fun l => (List.range 9).all fun i => chk l i) = true := by
  decide +kernel

theorem lclk : ∀ l, l < 512 → ∀ i, i < 9 →
    l ^^^ 2 ^ i < 512 ∧ dF l ≤ dF (l ^^^ 2 ^ i) + 1 ∧ d6 l ≤ d6 (l ^^^ 2 ^ i) + 1 ∧
    (l ^^^ 2 ^ i = keyF → dF l = 1 ∧ d6 l ≤ 4) ∧ (l ^^^ 2 ^ i = key6 → d6 l = 1) := by
  intro l hl i hi
  have h := chkAll
  simp only [List.all_eq_true, List.mem_range] at h
  have h := h l hl i hi
  simp only [chk, Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', beq_eq_false_iff_ne,
    beq_iff_eq, decide_eq_true_eq] at h
  obtain ⟨⟨⟨⟨a1, a2⟩, a3⟩, a4⟩, a5⟩ := h
  refine ⟨a1, a2, a3, ?_, ?_⟩
  · intro e; rcases a4 with a4 | a4
    · exact absurd e a4
    · exact a4
  · intro e; rcases a5 with a5 | a5
    · exact absurd e a5
    · exact a5

theorem dF0 : dF 0 = 4 := by decide
theorem d60 : d6 0 = 3 := by decide
theorem c31 : ¬ (31 ∈ cols4) := by decide

theorem mem_dirs (d : Dir) : d ∈ dirs := by cases d <;> decide

theorem S2_bounds (r c : Nat) (h : S2 r c = true) : r < 36 ∧ c < 44 := by
  simp only [S2, Bool.and_eq_true, Nat.ble_eq] at h
  omega

theorem slideAux_le (op : Bool) (n : Nat) (d : Dir) (p : Nat × Nat) :
    ∀ m k, slideAux op n d p m k ≤ k + m := by
  intro m
  induction m with
  | zero => intro k; simp [slideAux]
  | succ m ih =>
    intro k
    simp only [slideAux]
    split
    · have := ih (k + 1); omega
    · omega

theorem shift_c_le (d : Dir) (k r c : Nat) : (shift d k (r, c)).2 ≤ c + k := by
  cases d <;> simp [shift] <;> omega

theorem fpAny_slot2 (r c : Nat) (h : fpAny inSlot 2 r c = true) : 57 ≤ c + 1 := by
  simp only [fpAny, List.any_eq_true, List.mem_range] at h
  obtain ⟨i, _, j, hj, h⟩ := h
  simp only [inSlot, box, Bool.and_eq_true, Nat.ble_eq] at h
  omega

theorem move2_c_le (op : Bool) (d : Dir) (r c : Nat) : (move op 2 d (r, c)).2.2 ≤ c + 2 := by
  simp only [move]
  split
  · simp
  · have h1 := slideAux_le op 2 d (r, c) 2 0
    have h2 := shift_c_le d (slideAux op 2 d (r, c) 2 0) r c
    simp only at h2 ⊢
    omega

theorem move2_win (op : Bool) (d : Dir) (r c : Nat) (h : (move op 2 d (r, c)).1 = true) :
    54 ≤ c := by
  simp only [move] at h
  split at h
  · rename_i hs
    have h1 := fpAny_slot2 _ _ hs
    have h2 := shift_c_le d 2 r c
    omega
  · simp at h

theorem lA' (s : St) (d : Dir) (ho : s.op = false) (hs : s.size = 4) (hr : s.r ∈ rows4)
    (hc : s.c ∈ cols4) :
    (move s.op s.size d (s.r, s.c)).1 = false ∧ (move s.op s.size d (s.r, s.c)).2.1 ∈ rows4 ∧
    (move s.op s.size d (s.r, s.c)).2.2 ∈ cols4 := by
  rw [ho, hs]; exact lA s.r hr s.c hc d (mem_dirs d)

theorem lB' (s : St) (d : Dir) (ho : s.op = false) (hs : s.size = 2) (h2 : S2 s.r s.c = true) :
    (move s.op s.size d (s.r, s.c)).1 = false ∧
    S2 (move s.op s.size d (s.r, s.c)).2.1 (move s.op s.size d (s.r, s.c)).2.2 = true := by
  obtain ⟨b1, b2⟩ := S2_bounds _ _ h2
  rw [ho, hs]; exact lB s.r b1 s.c b2 h2 d (mem_dirs d)

theorem lC' (s : St) (d : Dir) (ho : s.op = true) (hs : s.size = 2) :
    (move s.op s.size d (s.r, s.c)).2.2 ≤ s.c + 2 ∧
    ((move s.op s.size d (s.r, s.c)).1 = true → 54 ≤ s.c) := by
  rw [ho, hs]; exact ⟨move2_c_le true d s.r s.c, move2_win true d s.r s.c⟩

theorem pres (LIM : Nat) (hL : LIM ≤ 19) (trig : St → Bool)
    (ht : ∀ s, trig s = true → s.c = 31)
    (s : St) (a : Act) (h : J LIM s) : J LIM (step LIM trig s a) := by
  obtain ⟨hw, hlit, hu, hΦ, hph⟩ := h
  unfold step
  by_cases hl : s.won = false ∧ s.used < LIM
  · rw [if_pos hl]
    have hΦ' : 20 ≤ (if s.op then Rc s.c
        else if s.size = 4 then dF s.lit + 16 else d6 s.lit + 13) + s.used := by
      simpa [Φ, hw] using hΦ
    cases a with
    | key => exact ⟨hw, hlit, hu, hΦ, hph⟩
    | mv d =>
      simp only [act]
      rcases hph with ⟨hs, ho, hr, hc⟩ | ⟨hs, ho, h2⟩ | ⟨hs, ho⟩
      · obtain ⟨m1, m2, m3⟩ := lA' s d ho hs hr hc
        simp [ho, hs] at hΦ'
        generalize move s.op s.size d (s.r, s.c) = mv at *
        exact ⟨m1, hlit, by simp; omega, by simp [Φ, m1, ho, hs]; omega,
          Or.inl ⟨hs, ho, m2, m3⟩⟩
      · obtain ⟨m1, m2⟩ := lB' s d ho hs h2
        simp [ho, hs] at hΦ'
        generalize move s.op s.size d (s.r, s.c) = mv at *
        exact ⟨m1, hlit, by simp; omega, by simp [Φ, m1, ho, hs]; omega,
          Or.inr (Or.inl ⟨hs, ho, m2⟩)⟩
      · obtain ⟨m1, m2⟩ := lC' s d ho hs
        simp [ho, Rc] at hΦ'
        generalize move s.op s.size d (s.r, s.c) = mv at *
        cases hm : mv.1
        · exact ⟨by simp [hm], hlit, by simp; omega, by simp [Φ, hm, ho, Rc]; omega,
            Or.inr (Or.inr ⟨hs, ho⟩)⟩
        · exfalso
          have := m2 hm
          omega
    | cell i =>
      simp only [act]
      by_cases hi : 9 ≤ i
      · rw [if_pos hi]; exact ⟨hw, hlit, hu, hΦ, hph⟩
      · rw [if_neg hi]
        obtain ⟨k1, k2, k3, k4, k5⟩ := lclk s.lit hlit i (by omega)
        by_cases h6 : s.lit ^^^ 2 ^ i = key6
        · rw [if_pos h6]
          have e6 := k5 h6
          rcases hph with ⟨hs, ho, hr, hc⟩ | ⟨hs, ho, h2⟩ | ⟨hs, ho⟩
          · have htf : trig s = false := by
              cases htt : trig s
              · rfl
              · exact absurd (ht s htt ▸ hc) c31
            exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho, htf, hs, dF0],
              Or.inl ⟨hs, by simp [ho, htf], hr, hc⟩⟩
          · simp [ho, hs, e6] at hΦ'
            cases htt : trig s
            · exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho, htt, hs, d60]; omega,
                Or.inr (Or.inl ⟨hs, by simp [ho, htt], h2⟩)⟩
            · have hc31 := ht s htt
              exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho, htt, hc31, Rc]; omega,
                Or.inr (Or.inr ⟨hs, by simp [ho, htt]⟩)⟩
          · simp [ho] at hΦ'
            exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho]; omega,
              Or.inr (Or.inr ⟨hs, by simp [ho]⟩)⟩
        · rw [if_neg h6]
          by_cases hF : s.lit ^^^ 2 ^ i = keyF
          · rw [if_pos hF]
            obtain ⟨eF1, eF2⟩ := k4 hF
            rcases hph with ⟨hs, ho, hr, hc⟩ | ⟨hs, ho, h2⟩ | ⟨hs, ho⟩
            · simp [ho, hs, eF1] at hΦ'
              exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho, hs, d60]; omega,
                Or.inr (Or.inl ⟨by simp [hs], ho, lAB s.r hr s.c hc⟩)⟩
            · simp [ho, hs] at hΦ'
              exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho, hs, d60]; omega,
                Or.inr (Or.inl ⟨by simp [hs], ho, h2⟩)⟩
            · simp [ho] at hΦ'
              exact ⟨hw, by simp, by simp; omega, by simp [Φ, hw, ho]; omega,
                Or.inr (Or.inr ⟨by simp [hs], ho⟩)⟩
          · rw [if_neg hF]
            rcases hph with ⟨hs, ho, hr, hc⟩ | ⟨hs, ho, h2⟩ | ⟨hs, ho⟩
            · simp [ho, hs] at hΦ'
              exact ⟨hw, k1, by simp; omega, by simp [Φ, hw, ho, hs]; omega,
                Or.inl ⟨hs, ho, hr, hc⟩⟩
            · simp [ho, hs] at hΦ'
              exact ⟨hw, k1, by simp; omega, by simp [Φ, hw, ho, hs]; omega,
                Or.inr (Or.inl ⟨hs, ho, h2⟩)⟩
            · simp [ho] at hΦ'
              exact ⟨hw, k1, by simp; omega, by simp [Φ, hw, ho]; omega,
                Or.inr (Or.inr ⟨hs, ho⟩)⟩
  · rw [if_neg hl]; exact ⟨hw, hlit, hu, hΦ, hph⟩

theorem run_J (LIM : Nat) (hL : LIM ≤ 19) (trig : St → Bool)
    (ht : ∀ s, trig s = true → s.c = 31)
    (as : List Act) : ∀ s, J LIM s → J LIM (run LIM trig s as) := by
  induction as with
  | nil => intro s h; exact h
  | cons a as ih =>
    intro s h
    simp only [run, List.foldl_cons]
    exact ih _ (pres LIM hL trig ht s a h)

theorem J_start (LIM : Nat) : J LIM start :=
  ⟨rfl, by decide, Nat.zero_le _, by decide, Or.inl ⟨rfl, rfl, by decide, by decide⟩⟩

/-- MAIN (attempt 2): for every budget `LIM ≤ 19` and every trigger rule that can only fire
    with the block's left column at 31, NO action sequence wins level 4. -/
theorem never_wins (LIM : Nat) (hL : LIM ≤ 19) (trig : St → Bool)
    (ht : ∀ s, trig s = true → s.c = 31) (as : List Act) :
    (run LIM trig start as).won = false :=
  (run_J LIM hL trig ht as start (J_start LIM)).1

theorem trigH5_ok : ∀ s, trigH5 s = true → s.c = 31 := by
  intro s h
  simp only [trigH5, Bool.and_eq_true, beq_iff_eq] at h
  exact h.2

/-- Measured budget 15, measured trigger H5. -/
theorem never_wins_measured (as : List Act) : (run 15 trigH5 start as).won = false :=
  never_wins 15 (by decide) trigH5 trigH5_ok as

/-- Non-vacuity: relax the budget to 26 actions and the same model (with H5) is winnable. -/
def route26 : List Act :=
  [.mv .L, .mv .L, .mv .D, .cell 1, .cell 3, .cell 5, .cell 7, .mv .R, .mv .U,
   .cell 1, .cell 4, .cell 7, .mv .D] ++ List.replicate 13 (.mv .R)

theorem route26_len : route26.length = 26 := by decide
theorem route26_wins : (run 26 trigH5 start route26).won = true := by decide
theorem route26_short : (run 25 trigH5 start route26).won = false := by decide

end L4.V2






/-! Attempt-3 amendment of the formal system in `L4Model.lean` (namespaces `L4`, `L4.V2` there).
    Kept in a second file only for compile time; it imports and reuses those definitions. -/

/-! # Amendment (attempt 3) — `L4.V3`

What attempt 3 changed (reused from `L4` / `L4.V2`: the floor maps, `floorC`, `fpAll`, `fpAny`):
* rule MATCHF: on a size-2 block it GROWS back to 4 (observed: (33,23) 2x2 → (31,21) 4x4).
  In the model the grow anchor is NONDETERMINISTIC among 5 offsets (observed: (-2,-2)) — looser.
* new object: e-marker (rows 34-35, cols 23-24) with slot `rf`. New rule REFILL: a size-2 move
  whose slide touches the marker sets rf and lowers spent budget k to min(k+1-10, 5)
  (one sample, 15 → 5; both readings allowed — looser). 4x4 covering it: no refill (observed).
* budget in units, not actions: move = 1; a completed match = 2 for the final click plus 1 per
  other click. Measured B = 18 (all three attempts fit). A match is ONE macro action
  (F = 5, M6 = 4). Every match resets the grid and clicks never move the block, so any real click
  sequence that completes a match costs at least that much. This is the one abstraction.
* rule MATCH6 trigger: c = 31, any size, any facing (looser than the measured H5).
* the facing slot is dropped (no rule reads it once the trigger ignores facing).
* blocked grow: a costed no-op (unobserved).
* NOT IN MODEL: anything else unobserved (other markers, ACTION5/7, size 1).
-/
namespace L4.V3
open L4 (Dir shift inSlot box)

def marker (y x : Nat) : Bool := box 34 35 23 24 y x

structure P where
  r : Nat
  c : Nat
  n : Nat
  op : Bool
  rf : Bool
  deriving DecidableEq, Repr

def slideT (op : Bool) (n : Nat) (d : Dir) (p : Nat × Nat) : Nat → Nat → Bool → Nat × Bool
  | 0, k, t => (k, t)
  | m + 1, k, t =>
    let q := shift d (k + 1) p
    if L4.V2.fpAll (L4.V2.floorC op) n q.1 q.2 then
      slideT op n d p m (k + 1) (t || L4.V2.fpAny marker n q.1 q.2)
    else (k, t)

inductive Kind | norm | refill

inductive Res | win | to (t : P) (kd : Kind)

/-- grow anchors (offsets subtracted from the top-left); index ≥ 4 all mean (0,2). -/
def anch : Nat → Nat × Nat
  | 0 => (2, 2) | 1 => (0, 0) | 2 => (1, 1) | 3 => (2, 0) | _ => (0, 2)

inductive Act | mv (d : Dir) | F (i : Nat) | M6

def cost : Act → Nat
  | .mv _ => 1
  | .F _ => 5
  | .M6 => 4

def absStep (p : P) : Act → Res
  | .mv d =>
    let q := shift d p.n (p.r, p.c)
    if L4.V2.fpAny inSlot p.n q.1 q.2 then .win else
    let st := slideT p.op p.n d (p.r, p.c) p.n 0 false
    let t := shift d st.1 (p.r, p.c)
    if p.n == 2 && !p.rf && st.2 then .to ⟨t.1, t.2, p.n, p.op, true⟩ .refill
    else .to ⟨t.1, t.2, p.n, p.op, p.rf⟩ .norm
  | .F i =>
    if p.n == 4 then .to ⟨p.r, p.c, 2, p.op, p.rf⟩ .norm else
    let a := anch i
    if Nat.ble a.1 p.r && Nat.ble a.2 p.c && L4.V2.fpAll (L4.V2.floorC p.op) 4 (p.r - a.1) (p.c - a.2)
    then .to ⟨p.r - a.1, p.c - a.2, 4, p.op, p.rf⟩ .norm else .to p .norm
  | .M6 => .to ⟨p.r, p.c, p.n, p.op || p.c == 31, p.rf⟩ .norm

structure St where
  p : P
  k : Nat
  won : Bool

def step (B : Nat) (s : St) (a : Act) : St :=
  if s.won = false ∧ s.k + cost a ≤ B then
    match absStep s.p a with
    | .win => ⟨s.p, s.k, true⟩
    | .to t .norm => ⟨t, s.k + cost a, false⟩
    | .to t .refill => ⟨t, min (s.k + 1 - 10) 5, false⟩
  else s

def run (B : Nat) (s : St) (as : List Act) : St := as.foldl (step B) s

def startP : P := ⟨25, 37, 4, false, false⟩
def start : St := ⟨startP, 0, false⟩

def key (p : P) : Nat :=
  p.r * 2048 + p.c * 32 + p.n * 4 + (if p.op then 2 else 0) + (if p.rf then 1 else 0)
def decode (k : Nat) : P := ⟨k / 2048, k / 32 % 64, k / 4 % 8, k / 2 % 2 == 1, k % 2 == 1⟩

/-- binary search tree of (key, least spent budget); generated by work/table4.py + work/gen_tab.py -/
inductive T | leaf | node (l : T) (k v : Nat) (r : T)

def T.find : T → Nat → Option Nat
  | .leaf, _ => none
  | .node l k v r, x => if x < k then l.find x else if x = k then some v else r.find x

def T.toList : T → List (Nat × Nat)
  | .leaf => []
  | .node l k v r => l.toList ++ (k, v) :: r.toList

theorem T.find_mem : ∀ (t : T) (x v : Nat), t.find x = some v → (x, v) ∈ t.toList
  | .leaf, x, v, h => by simp [T.find] at h
  | .node l k w r, x, v, h => by
    simp only [T.find] at h
    simp only [T.toList, List.mem_append, List.mem_cons]
    split at h
    · exact Or.inl (T.find_mem l x v h)
    · split at h
      · rename_i hx
        simp only [Option.some.injEq] at h
        subst hx; subst h
        exact Or.inr (Or.inl rfl)
      · exact Or.inr (Or.inr (T.find_mem r x v h))

def tree : T :=
  (.node (.node (.node (.node (.node (.node (.node (.node (.node (.node (.node .leaf 19432 14 .leaf) 19433 17 .leaf) 19434 18 (.node (.node .leaf 23528 13 .leaf) 23529 16 .leaf)) 23530 17 (.node (.node (.node .leaf 27624 12 .leaf) 27625 15 .leaf) 27626 16 (.node (.node .leaf 31720 11 .leaf) 31721 14 .leaf))) 31722 15 (.node (.node (.node (.node .leaf 31723 18 .leaf) 35816 10 .leaf) 35817 13 (.node (.node .leaf 35818 14 .leaf) 35819 17 .leaf)) 39912 9 (.node (.node (.node .leaf 39913 12 .leaf) 39914 13 .leaf) 39915 16 (.node (.node .leaf 43688 10 .leaf) 43689 8 .leaf)))) 43690 17 (.node (.node (.node (.node (.node .leaf 43691 12 .leaf) 43696 5 .leaf) 43697 9 (.node (.node .leaf 43699 13 .leaf) 43721 14 .leaf)) 43723 18 (.node (.node (.node .leaf 43728 15 .leaf) 43729 9 .leaf) 43731 13 (.node (.node .leaf 43752 10 .leaf) 43753 7 .leaf))) 43754 16 (.node (.node (.node (.node .leaf 43755 11 .leaf) 43760 14 .leaf) 43761 9 (.node (.node .leaf 43762 18 .leaf) 43763 13 .leaf)) 43785 15 (.node (.node (.node .leaf 43792 14 .leaf) 43793 10 .leaf) 43795 14 (.node .leaf 43816 9 .leaf))))) 43817 8 (.node (.node (.node (.node (.node (.node .leaf 43818 15 .leaf) 43819 12 .leaf) 43824 4 (.node (.node .leaf 43825 10 .leaf) 43826 18 .leaf)) 43827 14 (.node (.node (.node .leaf 43849 15 .leaf) 43856 14 .leaf) 43857 10 (.node (.node .leaf 43858 18 .leaf) 43859 14 .leaf))) 43880 9 (.node (.node (.node (.node .leaf 43881 9 .leaf) 43882 14 .leaf) 43883 13 (.node (.node .leaf 43888 13 .leaf) 43889 10 .leaf)) 43890 17 (.node (.node (.node .leaf 43891 14 .leaf) 43912 18 .leaf) 43913 16 (.node (.node .leaf 43920 13 .leaf) 43921 11 .leaf)))) 43922 18 (.node (.node (.node (.node (.node .leaf 43923 15 .leaf) 43944 8 .leaf) 43945 10 (.node (.node .leaf 43946 13 .leaf) 43947 14 .leaf)) 43952 3 (.node (.node (.node .leaf 43953 11 .leaf) 43954 17 .leaf) 43955 15 (.node (.node .leaf 43976 18 .leaf) 43977 16 .leaf))) 43984 13 (.node (.node (.node (.node .leaf 43985 11 .leaf) 43986 17 .leaf) 43987 15 (.node (.node .leaf 44008 8 .leaf) 44009 11 .leaf)) 44010 12 (.node (.node (.node .leaf 44011 15 .leaf) 44016 12 .leaf) 44017 11 (.node .leaf 44018 16 .leaf)))))) 44019 15 (.node (.node (.node (.node (.node (.node (.node .leaf 44040 17 .leaf) 44041 17 .leaf) 44048 12 (.node (.node .leaf 44049 12 .leaf) 44050 18 .leaf)) 44051 16 (.node (.node (.node .leaf 44072 7 .leaf) 44073 12 .leaf) 44074 13 (.node (.node .leaf 44075 16 .leaf) 44080 2 .leaf))) 44081 12 (.node (.node (.node (.node .leaf 44082 18 .leaf) 44083 16 .leaf) 44104 17 (.node (.node .leaf 44105 17 .leaf) 44112 12 .leaf)) 44113 12 (.node (.node (.node .leaf 44114 18 .leaf) 44115 16 .leaf) 44136 7 (.node (.node .leaf 44137 13 .leaf) 44138 14 .leaf)))) 44139 17 (.node (.node (.node (.node (.node .leaf 44144 11 .leaf) 44145 12 .leaf) 44146 17 (.node (.node .leaf 44147 16 .leaf) 44168 16 .leaf)) 44169 18 (.node (.node (.node .leaf 44176 11 .leaf) 44177 13 .leaf) 44179 17 (.node (.node .leaf 44200 6 .leaf) 44201 14 .leaf))) 44202 15 (.node (.node (.node (.node .leaf 44203 18 .leaf) 44208 1 .leaf) 44209 13 (.node (.node .leaf 44211 17 .leaf) 44232 17 .leaf)) 44233 18 (.node (.node (.node .leaf 44240 12 .leaf) 44241 13 .leaf) 44243 17 (.node .leaf 44264 7 .leaf))))) 44265 15 (.node (.node (.node (.node (.node (.node .leaf 44266 16 .leaf) 44272 12 .leaf) 44273 13 (.node (.node .leaf 44274 18 .leaf) 44275 17 .leaf)) 44296 17 (.node (.node (.node .leaf 44304 12 .leaf) 44305 14 .leaf) 44307 18 (.node (.node .leaf 44328 7 .leaf) 44329 16 .leaf))) 44330 17 (.node (.node (.node (.node .leaf 44336 2 .leaf) 44337 14 .leaf) 44339 18 (.node (.node .leaf 44360 18 .leaf) 44392 8 .leaf)) 44393 17 (.node (.node (.node .leaf 44394 18 .leaf) 45737 15 .leaf) 45744 15 (.node .leaf 45745 10 .leaf)))) 45747 14 (.node (.node (.node (.node (.node .leaf 45769 14 .leaf) 45771 18 .leaf) 45776 15 (.node (.node .leaf 45777 9 .leaf) 45779 13 .leaf)) 45801 16 (.node (.node (.node .leaf 45833 15 .leaf) 45840 14 .leaf) 45841 10 (.node (.node .leaf 45843 14 .leaf) 45865 16 .leaf))) 45872 16 (.node (.node (.node (.node .leaf 45873 11 .leaf) 45875 15 .leaf) 45897 15 (.node (.node .leaf 45904 14 .leaf) 45905 10 .leaf)) 45906 18 (.node (.node (.node .leaf 45907 14 .leaf) 45929 17 .leaf) 45960 18 (.node .leaf 45961 16 .leaf))))))) 45968 13 (.node (.node (.node (.node (.node (.node (.node (.node .leaf 45969 11 .leaf) 45970 18 .leaf) 45971 15 (.node (.node .leaf 45993 17 .leaf) 46000 16 .leaf)) 46001 12 (.node (.node (.node .leaf 46003 16 .leaf) 46024 18 .leaf) 46025 16 (.node (.node .leaf 46032 13 .leaf) 46033 11 .leaf))) 46034 17 (.node (.node (.node (.node .leaf 46035 15 .leaf) 46057 18 .leaf) 46088 17 (.node (.node .leaf 46089 17 .leaf) 46096 12 .leaf)) 46097 12 (.node (.node (.node .leaf 46098 18 .leaf) 46099 16 .leaf) 46121 18 (.node (.node .leaf 46128 15 .leaf) 46129 13 .leaf)))) 46131 17 (.node (.node (.node (.node (.node .leaf 46152 17 .leaf) 46153 17 .leaf) 46160 12 (.node (.node .leaf 46161 12 .leaf) 46162 18 .leaf)) 46163 16 (.node (.node (.node .leaf 46216 16 .leaf) 46217 18 .leaf) 46224 11 (.node (.node .leaf 46225 13 .leaf) 46227 17 .leaf))) 46256 14 (.node (.node (.node (.node .leaf 46257 14 .leaf) 46259 18 .leaf) 46280 17 (.node (.node .leaf 46281 18 .leaf) 46288 12 .leaf)) 46289 13 (.node (.node (.node .leaf 46291 17 .leaf) 46344 17 .leaf) 46352 12 (.node .leaf 46353 14 .leaf))))) 46355 18 (.node (.node (.node (.node (.node (.node .leaf 46376 18 .leaf) 46384 13 .leaf) 46385 14 (.node (.node .leaf 46387 18 .leaf) 46408 18 .leaf)) 47784 10 (.node (.node (.node .leaf 47785 7 .leaf) 47786 17 .leaf) 47787 11 (.node (.node .leaf 47792 14 .leaf) 47793 8 .leaf))) 47794 18 (.node (.node (.node (.node .leaf 47795 12 .leaf) 47817 15 .leaf) 47848 10 (.node (.node .leaf 47849 6 .leaf) 47850 16 .leaf)) 47851 10 (.node (.node (.node .leaf 47856 13 .leaf) 47857 8 .leaf) 47858 17 (.node .leaf 47859 12 .leaf)))) 47881 16 (.node (.node (.node (.node (.node .leaf 47912 9 .leaf) 47913 7 .leaf) 47914 15 (.node (.node .leaf 47915 11 .leaf) 47920 13 .leaf)) 47921 9 (.node (.node (.node .leaf 47922 17 .leaf) 47923 13 .leaf) 47945 16 (.node (.node .leaf 47976 9 .leaf) 47977 8 .leaf))) 47978 14 (.node (.node (.node (.node .leaf 47979 12 .leaf) 47984 12 .leaf) 47985 9 (.node (.node .leaf 47986 16 .leaf) 47987 13 .leaf)) 48009 17 (.node (.node (.node .leaf 48040 8 .leaf) 48041 9 .leaf) 48042 13 (.node .leaf 48043 13 .leaf)))))) 48048 12 (.node (.node (.node (.node (.node (.node (.node .leaf 48049 10 .leaf) 48050 16 .leaf) 48051 14 (.node (.node .leaf 48073 17 .leaf) 48104 8 .leaf)) 48105 10 (.node (.node (.node .leaf 48106 12 .leaf) 48107 14 .leaf) 48112 11 (.node (.node .leaf 48113 10 .leaf) 48114 15 .leaf))) 48115 14 (.node (.node (.node (.node .leaf 48136 18 .leaf) 48137 18 .leaf) 48168 7 (.node (.node .leaf 48169 11 .leaf) 48170 13 .leaf)) 48171 15 (.node (.node (.node .leaf 48176 11 .leaf) 48177 11 .leaf) 48178 17 (.node (.node .leaf 48179 15 .leaf) 48200 18 .leaf)))) 48201 18 (.node (.node (.node (.node (.node .leaf 48232 7 .leaf) 48233 12 .leaf) 48234 14 (.node (.node .leaf 48235 16 .leaf) 48240 10 .leaf)) 48241 11 (.node (.node (.node .leaf 48242 16 .leaf) 48243 15 .leaf) 48264 17 (.node (.node .leaf 48296 6 .leaf) 48297 13 .leaf))) 48298 15 (.node (.node (.node (.node .leaf 48299 17 .leaf) 48304 10 .leaf) 48305 12 (.node (.node .leaf 48306 18 .leaf) 48307 16 .leaf)) 48328 18 (.node (.node (.node .leaf 48360 7 .leaf) 48361 14 .leaf) 48362 16 (.node .leaf 48363 18 .leaf))))) 48368 11 (.node (.node (.node (.node (.node (.node .leaf 48369 12 .leaf) 48370 17 .leaf) 48371 16 (.node (.node .leaf 48392 18 .leaf) 48424 7 .leaf)) 48425 15 (.node (.node (.node .leaf 48426 17 .leaf) 48432 11 .leaf) 48433 13 (.node (.node .leaf 48434 18 .leaf) 48435 17 .leaf))) 48488 8 (.node (.node (.node (.node .leaf 48489 16 .leaf) 48490 18 .leaf) 49833 14 (.node (.node .leaf 49835 18 .leaf) 49840 14 .leaf)) 49841 9 (.node (.node (.node .leaf 49843 13 .leaf) 49865 13 .leaf) 49867 17 (.node .leaf 49872 14 .leaf)))) 49873 8 (.node (.node (.node (.node (.node .leaf 49874 18 .leaf) 49875 12 .leaf) 49897 15 (.node (.node .leaf 49928 18 .leaf) 49929 14 .leaf)) 49931 18 (.node (.node (.node .leaf 49936 13 .leaf) 49937 9 .leaf) 49938 18 (.node (.node .leaf 49939 13 .leaf) 49961 15 .leaf))) 49968 15 (.node (.node (.node (.node .leaf 49969 10 .leaf) 49971 14 .leaf) 49992 18 (.node (.node .leaf 49993 14 .leaf) 49995 18 .leaf)) 50000 13 (.node (.node (.node .leaf 50001 9 .leaf) 50002 17 .leaf) 50003 13 (.node .leaf 50025 16 .leaf)))))))) 50056 17 (.node (.node (.node (.node (.node (.node (.node (.node (.node .leaf 50057 15 .leaf) 50064 12 .leaf) 50065 10 (.node (.node .leaf 50066 17 .leaf) 50067 14 .leaf)) 50089 16 (.node (.node (.node .leaf 50096 15 .leaf) 50097 11 .leaf) 50099 15 (.node (.node .leaf 50120 17 .leaf) 50121 15 .leaf))) 50128 12 (.node (.node (.node (.node .leaf 50129 10 .leaf) 50130 16 .leaf) 50131 14 (.node (.node .leaf 50153 17 .leaf) 50184 16 .leaf)) 50185 16 (.node (.node (.node .leaf 50192 11 .leaf) 50193 11 .leaf) 50194 17 (.node (.node .leaf 50195 15 .leaf) 50217 17 .leaf)))) 50224 14 (.node (.node (.node (.node (.node .leaf 50225 12 .leaf) 50227 16 .leaf) 50248 16 (.node (.node .leaf 50249 16 .leaf) 50256 11 .leaf)) 50257 11 (.node (.node (.node .leaf 50258 17 .leaf) 50259 15 .leaf) 50281 18 (.node (.node .leaf 50312 15 .leaf) 50313 17 .leaf))) 50320 10 (.node (.node (.node (.node .leaf 50321 12 .leaf) 50322 18 .leaf) 50323 16 (.node (.node .leaf 50344 18 .leaf) 50345 18 .leaf)) 50352 13 (.node (.node (.node .leaf 50353 13 .leaf) 50355 17 .leaf) 50376 16 (.node .leaf 50377 17 .leaf))))) 50384 11 (.node (.node (.node (.node (.node (.node .leaf 50385 12 .leaf) 50386 18 .leaf) 50387 16 (.node (.node .leaf 50408 18 .leaf) 50440 16 .leaf)) 50441 18 (.node (.node (.node .leaf 50448 11 .leaf) 50449 13 .leaf) 50451 17 (.node (.node .leaf 50472 17 .leaf) 50473 18 .leaf))) 50480 12 (.node (.node (.node (.node .leaf 50481 13 .leaf) 50483 17 .leaf) 50504 17 (.node (.node .leaf 50536 18 .leaf) 51880 9 .leaf)) 51881 6 (.node (.node (.node .leaf 51882 16 .leaf) 51883 10 .leaf) 51888 4 (.node .leaf 51889 8 .leaf)))) 51890 18 (.node (.node (.node (.node (.node .leaf 51891 12 .leaf) 51913 14 .leaf) 51915 18 (.node (.node .leaf 51920 16 .leaf) 51921 9 .leaf)) 51923 13 (.node (.node (.node .leaf 51944 9 .leaf) 51945 5 .leaf) 51946 15 (.node (.node .leaf 51947 9 .leaf) 51952 13 .leaf))) 51953 8 (.node (.node (.node (.node .leaf 51954 17 .leaf) 51955 12 .leaf) 51977 15 (.node (.node .leaf 51984 15 .leaf) 51985 10 .leaf)) 51987 14 (.node (.node (.node .leaf 52008 8 .leaf) 52009 6 .leaf) 52010 14 (.node .leaf 52011 10 .leaf)))))) 52016 3 (.node (.node (.node (.node (.node (.node (.node .leaf 52017 9 .leaf) 52018 17 .leaf) 52019 13 (.node (.node .leaf 52041 15 .leaf) 52048 15 .leaf)) 52049 10 (.node (.node (.node .leaf 52051 14 .leaf) 52072 8 .leaf) 52073 7 (.node (.node .leaf 52074 13 .leaf) 52075 11 .leaf))) 52080 12 (.node (.node (.node (.node .leaf 52081 9 .leaf) 52082 16 .leaf) 52083 13 (.node (.node .leaf 52105 16 .leaf) 52112 14 .leaf)) 52113 11 (.node (.node (.node .leaf 52115 15 .leaf) 52136 7 .leaf) 52137 8 (.node (.node .leaf 52138 12 .leaf) 52139 12 .leaf)))) 52144 2 (.node (.node (.node (.node (.node .leaf 52145 10 .leaf) 52146 16 .leaf) 52147 14 (.node (.node .leaf 52169 16 .leaf) 52176 14 .leaf)) 52177 11 (.node (.node (.node .leaf 52178 18 .leaf) 52179 15 .leaf) 52200 7 (.node (.node .leaf 52201 9 .leaf) 52202 11 .leaf))) 52203 13 (.node (.node (.node (.node .leaf 52208 11 .leaf) 52209 10 .leaf) 52210 15 (.node (.node .leaf 52211 14 .leaf) 52232 18 .leaf)) 52233 17 (.node (.node (.node .leaf 52240 13 .leaf) 52241 12 .leaf) 52243 16 (.node .leaf 52264 6 .leaf))))) 52265 10 (.node (.node (.node (.node (.node (.node .leaf 52266 12 .leaf) 52267 14 .leaf) 52272 1 (.node (.node .leaf 52273 11 .leaf) 52274 17 .leaf)) 52275 15 (.node (.node (.node .leaf 52296 18 .leaf) 52297 17 .leaf) 52304 13 (.node (.node .leaf 52305 12 .leaf) 52307 16 .leaf))) 52328 6 (.node (.node (.node (.node .leaf 52329 11 .leaf) 52330 13 .leaf) 52331 15 (.node (.node .leaf 52336 10 .leaf) 52337 11 .leaf)) 52338 16 (.node (.node (.node .leaf 52339 15 .leaf) 52360 17 .leaf) 52361 18 (.node .leaf 52368 12 .leaf)))) 52369 13 (.node (.node (.node (.node (.node .leaf 52371 17 .leaf) 52392 5 .leaf) 52393 12 (.node (.node .leaf 52394 14 .leaf) 52395 16 .leaf)) 52400 0 (.node (.node (.node .leaf 52401 12 .leaf) 52402 18 .leaf) 52403 16 (.node (.node .leaf 52424 18 .leaf) 52425 18 .leaf))) 52432 13 (.node (.node (.node (.node .leaf 52433 13 .leaf) 52435 17 .leaf) 52456 6 (.node (.node .leaf 52457 13 .leaf) 52458 15 .leaf)) 52459 17 (.node (.node (.node .leaf 52464 11 .leaf) 52465 12 .leaf) 52466 17 (.node .leaf 52467 16 .leaf))))))) 52488 18 (.node (.node (.node (.node (.node (.node (.node (.node .leaf 52496 13 .leaf) 52497 14 .leaf) 52499 18 (.node (.node .leaf 52520 6 .leaf) 52521 14 .leaf)) 52522 16 (.node (.node (.node .leaf 52523 18 .leaf) 52528 1 .leaf) 52529 13 (.node (.node .leaf 52530 18 .leaf) 52531 17 .leaf))) 52584 7 (.node (.node (.node (.node .leaf 52585 15 .leaf) 52586 17 .leaf) 53929 14 (.node (.node .leaf 53931 18 .leaf) 53936 15 .leaf)) 53937 9 (.node (.node (.node .leaf 53939 13 .leaf) 53961 13 .leaf) 53963 17 (.node (.node .leaf 53968 15 .leaf) 53969 8 .leaf)))) 53971 12 (.node (.node (.node (.node (.node .leaf 53993 15 .leaf) 54025 14 .leaf) 54027 18 (.node (.node .leaf 54032 14 .leaf) 54033 9 .leaf)) 54035 13 (.node (.node (.node .leaf 54057 15 .leaf) 54064 16 .leaf) 54065 10 (.node (.node .leaf 54067 14 .leaf) 54089 14 .leaf))) 54091 18 (.node (.node (.node (.node .leaf 54096 14 .leaf) 54097 9 .leaf) 54098 18 (.node (.node .leaf 54099 13 .leaf) 54121 16 .leaf)) 54152 18 (.node (.node (.node .leaf 54153 15 .leaf) 54160 13 .leaf) 54161 10 (.node .leaf 54162 18 .leaf))))) 54163 14 (.node (.node (.node (.node (.node (.node .leaf 54185 16 .leaf) 54192 16 .leaf) 54193 11 (.node (.node .leaf 54195 15 .leaf) 54216 18 .leaf)) 54217 15 (.node (.node (.node .leaf 54224 13 .leaf) 54225 10 .leaf) 54226 17 (.node (.node .leaf 54227 14 .leaf) 54249 17 .leaf))) 54280 17 (.node (.node (.node (.node .leaf 54281 16 .leaf) 54288 12 .leaf) 54289 11 (.node (.node .leaf 54290 18 .leaf) 54291 15 .leaf)) 54313 17 (.node (.node (.node .leaf 54320 15 .leaf) 54321 12 .leaf) 54323 16 (.node .leaf 54344 17 .leaf)))) 54345 16 (.node (.node (.node (.node (.node .leaf 54352 12 .leaf) 54353 11 .leaf) 54354 18 (.node (.node .leaf 54355 15 .leaf) 54377 18 .leaf)) 54408 16 (.node (.node (.node .leaf 54409 17 .leaf) 54416 11 .leaf) 54417 12 (.node (.node .leaf 54419 16 .leaf) 54441 18 .leaf))) 54448 14 (.node (.node (.node (.node .leaf 54449 13 .leaf) 54451 17 .leaf) 54472 17 (.node (.node .leaf 54473 17 .leaf) 54480 12 .leaf)) 54481 12 (.node (.node (.node .leaf 54483 16 .leaf) 54536 17 .leaf) 54537 18 (.node .leaf 54544 12 .leaf)))))) 54545 13 (.node (.node (.node (.node (.node (.node (.node .leaf 54547 17 .leaf) 54568 18 .leaf) 54569 18 (.node (.node .leaf 54576 13 .leaf) 54577 13 .leaf)) 54579 17 (.node (.node (.node .leaf 54600 18 .leaf) 55976 10 .leaf) 55977 5 (.node (.node .leaf 55978 17 .leaf) 55979 9 .leaf))) 55984 15 (.node (.node (.node (.node .leaf 55985 7 .leaf) 55987 11 .leaf) 56009 14 (.node (.node .leaf 56011 18 .leaf) 56017 18 .leaf)) 56040 10 (.node (.node (.node .leaf 56041 4 .leaf) 56042 16 .leaf) 56043 8 (.node (.node .leaf 56048 14 .leaf) 56049 7 .leaf)))) 56050 18 (.node (.node (.node (.node (.node .leaf 56051 11 .leaf) 56073 15 .leaf) 56104 9 (.node (.node .leaf 56105 5 .leaf) 56106 15 .leaf)) 56107 9 (.node (.node (.node .leaf 56112 14 .leaf) 56113 8 .leaf) 56114 18 (.node (.node .leaf 56115 12 .leaf) 56137 15 .leaf))) 56168 9 (.node (.node (.node (.node .leaf 56169 6 .leaf) 56170 14 .leaf) 56171 10 (.node (.node .leaf 56176 13 .leaf) 56177 8 .leaf)) 56178 17 (.node (.node (.node .leaf 56179 12 .leaf) 56201 16 .leaf) 56232 8 (.node .leaf 56233 7 .leaf))))) 56234 13 (.node (.node (.node (.node (.node (.node .leaf 56235 11 .leaf) 56240 13 .leaf) 56241 9 (.node (.node .leaf 56242 17 .leaf) 56243 13 .leaf)) 56265 16 (.node (.node (.node .leaf 56296 8 .leaf) 56297 8 .leaf) 56298 12 (.node (.node .leaf 56299 12 .leaf) 56304 12 .leaf))) 56305 9 (.node (.node (.node (.node .leaf 56306 16 .leaf) 56307 13 .leaf) 56329 17 (.node (.node .leaf 56360 7 .leaf) 56361 9 .leaf)) 56362 13 (.node (.node (.node .leaf 56363 13 .leaf) 56368 12 .leaf) 56369 10 (.node .leaf 56370 18 .leaf)))) 56371 14 (.node (.node (.node (.node (.node .leaf 56393 17 .leaf) 56424 7 .leaf) 56425 10 (.node (.node .leaf 56426 14 .leaf) 56427 14 .leaf)) 56432 11 (.node (.node (.node .leaf 56433 10 .leaf) 56434 17 .leaf) 56435 14 (.node (.node .leaf 56456 18 .leaf) 56457 18 .leaf))) 56488 6 (.node (.node (.node (.node .leaf 56489 11 .leaf) 56490 15 .leaf) 56491 15 (.node (.node .leaf 56496 11 .leaf) 56497 11 .leaf)) 56499 15 (.node (.node (.node .leaf 56521 18 .leaf) 56552 7 .leaf) 56553 12 (.node .leaf 56554 16 .leaf))))))))) 56555 16 (.node (.node (.node (.node (.node (.node (.node (.node (.node (.node .leaf 56560 12 .leaf) 56561 11 .leaf) 56562 18 (.node (.node .leaf 56563 15 .leaf) 56616 7 .leaf)) 56617 13 (.node (.node (.node .leaf 56618 17 .leaf) 56619 17 .leaf) 56624 12 (.node (.node .leaf 56625 12 .leaf) 56627 16 .leaf))) 56680 8 (.node (.node (.node (.node .leaf 56681 14 .leaf) 56682 18 .leaf) 56683 18 (.node (.node .leaf 58025 13 .leaf) 58027 17 .leaf)) 58032 15 (.node (.node (.node .leaf 58033 8 .leaf) 58035 12 .leaf) 58057 12 (.node (.node .leaf 58059 16 .leaf) 58064 15 .leaf)))) 58065 7 (.node (.node (.node (.node (.node .leaf 58067 11 .leaf) 58089 14 .leaf) 58091 18 (.node (.node .leaf 58121 13 .leaf) 58123 17 .leaf)) 58128 14 (.node (.node (.node .leaf 58129 8 .leaf) 58131 12 .leaf) 58153 14 (.node (.node .leaf 58155 18 .leaf) 58160 16 .leaf))) 58161 9 (.node (.node (.node (.node .leaf 58163 13 .leaf) 58185 13 .leaf) 58187 17 (.node (.node .leaf 58192 14 .leaf) 58193 8 .leaf)) 58194 18 (.node (.node (.node .leaf 58195 12 .leaf) 58217 15 .leaf) 58248 18 (.node .leaf 58249 14 .leaf))))) 58251 18 (.node (.node (.node (.node (.node (.node .leaf 58256 13 .leaf) 58257 9 .leaf) 58258 18 (.node (.node .leaf 58259 13 .leaf) 58281 15 .leaf)) 58288 16 (.node (.node (.node .leaf 58289 10 .leaf) 58291 14 .leaf) 58312 18 (.node (.node .leaf 58313 14 .leaf) 58315 18 .leaf))) 58320 13 (.node (.node (.node (.node .leaf 58321 9 .leaf) 58322 17 .leaf) 58323 13 (.node (.node .leaf 58345 16 .leaf) 58376 17 .leaf)) 58377 15 (.node (.node (.node .leaf 58384 12 .leaf) 58385 10 .leaf) 58386 18 (.node (.node .leaf 58387 14 .leaf) 58409 16 .leaf)))) 58416 15 (.node (.node (.node (.node (.node .leaf 58417 11 .leaf) 58419 15 .leaf) 58440 17 (.node (.node .leaf 58441 15 .leaf) 58448 12 .leaf)) 58449 10 (.node (.node (.node .leaf 58450 18 .leaf) 58451 14 .leaf) 58473 17 (.node (.node .leaf 58504 16 .leaf) 58505 16 .leaf))) 58512 11 (.node (.node (.node (.node .leaf 58513 11 .leaf) 58515 15 .leaf) 58537 17 (.node (.node .leaf 58544 14 .leaf) 58545 12 .leaf)) 58547 16 (.node (.node (.node .leaf 58568 17 .leaf) 58569 16 .leaf) 58576 12 (.node .leaf 58577 11 .leaf)))))) 58579 15 (.node (.node (.node (.node (.node (.node (.node .leaf 58601 18 .leaf) 58632 17 .leaf) 58633 17 (.node (.node .leaf 58640 12 .leaf) 58641 12 .leaf)) 58643 16 (.node (.node (.node .leaf 58664 18 .leaf) 58665 17 .leaf) 58672 13 (.node (.node .leaf 58673 12 .leaf) 58675 16 .leaf))) 58696 18 (.node (.node (.node (.node .leaf 58697 18 .leaf) 58729 18 .leaf) 60072 10 (.node (.node .leaf 60073 4 .leaf) 60074 17 .leaf)) 60075 8 (.node (.node (.node .leaf 60080 5 .leaf) 60081 7 .leaf) 60083 11 (.node (.node .leaf 60105 13 .leaf) 60107 17 .leaf)))) 60112 17 (.node (.node (.node (.node (.node .leaf 60113 8 .leaf) 60115 12 .leaf) 60136 10 (.node (.node .leaf 60137 3 .leaf) 60138 16 .leaf)) 60139 7 (.node (.node (.node .leaf 60144 14 .leaf) 60145 7 .leaf) 60146 18 (.node (.node .leaf 60147 11 .leaf) 60169 14 .leaf))) 60171 18 (.node (.node (.node (.node .leaf 60176 16 .leaf) 60177 9 .leaf) 60179 13 (.node (.node .leaf 60200 9 .leaf) 60201 4 .leaf)) 60202 15 (.node (.node (.node .leaf 60203 8 .leaf) 60208 4 .leaf) 60209 8 (.node .leaf 60210 18 .leaf))))) 60211 12 (.node (.node (.node (.node (.node (.node .leaf 60233 14 .leaf) 60235 18 .leaf) 60240 16 (.node (.node .leaf 60241 9 .leaf) 60243 13 .leaf)) 60264 9 (.node (.node (.node .leaf 60265 5 .leaf) 60266 14 .leaf) 60267 9 (.node (.node .leaf 60272 13 .leaf) 60273 8 .leaf))) 60274 17 (.node (.node (.node (.node .leaf 60275 12 .leaf) 60297 15 .leaf) 60304 15 (.node (.node .leaf 60305 10 .leaf) 60307 14 .leaf)) 60328 8 (.node (.node (.node .leaf 60329 6 .leaf) 60330 13 .leaf) 60331 10 (.node .leaf 60336 3 .leaf)))) 60337 9 (.node (.node (.node (.node (.node .leaf 60338 17 .leaf) 60339 13 .leaf) 60361 15 (.node (.node .leaf 60368 15 .leaf) 60369 10 .leaf)) 60371 14 (.node (.node (.node .leaf 60392 8 .leaf) 60393 7 .leaf) 60394 12 (.node (.node .leaf 60395 11 .leaf) 60400 12 .leaf))) 60401 9 (.node (.node (.node (.node .leaf 60402 16 .leaf) 60403 13 .leaf) 60425 16 (.node (.node .leaf 60432 14 .leaf) 60433 11 .leaf)) 60435 15 (.node (.node (.node .leaf 60456 7 .leaf) 60457 8 .leaf) 60458 13 (.node .leaf 60459 12 .leaf))))))) 60464 2 (.node (.node (.node (.node (.node (.node (.node (.node .leaf 60465 10 .leaf) 60466 18 .leaf) 60467 14 (.node (.node .leaf 60489 16 .leaf) 60496 14 .leaf)) 60497 11 (.node (.node (.node .leaf 60499 15 .leaf) 60520 7 .leaf) 60521 9 (.node (.node .leaf 60522 14 .leaf) 60523 13 .leaf))) 60528 11 (.node (.node (.node (.node .leaf 60529 10 .leaf) 60530 17 .leaf) 60531 14 (.node (.node .leaf 60552 18 .leaf) 60553 17 .leaf)) 60560 13 (.node (.node (.node .leaf 60561 12 .leaf) 60563 16 .leaf) 60584 6 (.node (.node .leaf 60585 10 .leaf) 60586 15 .leaf)))) 60587 14 (.node (.node (.node (.node (.node .leaf 60592 1 .leaf) 60593 11 .leaf) 60595 15 (.node (.node .leaf 60617 17 .leaf) 60624 14 .leaf)) 60625 12 (.node (.node (.node .leaf 60627 16 .leaf) 60648 7 .leaf) 60649 11 (.node (.node .leaf 60650 16 .leaf) 60651 15 .leaf))) 60656 12 (.node (.node (.node (.node .leaf 60657 11 .leaf) 60658 18 .leaf) 60659 15 (.node (.node .leaf 60681 18 .leaf) 60688 14 .leaf)) 60689 13 (.node (.node (.node .leaf 60691 17 .leaf) 60712 7 .leaf) 60713 12 (.node .leaf 60714 17 .leaf))))) 60715 16 (.node (.node (.node (.node (.node (.node .leaf 60720 2 .leaf) 60721 12 .leaf) 60723 16 (.node (.node .leaf 60755 17 .leaf) 60776 8 .leaf)) 60777 13 (.node (.node (.node .leaf 60778 18 .leaf) 60779 17 .leaf) 60787 16 (.node (.node .leaf 60819 18 .leaf) 60843 18 .leaf))) 60851 17 (.node (.node (.node (.node .leaf 60883 18 .leaf) 60915 17 .leaf) 60979 18 (.node (.node .leaf 61043 18 .leaf) 62121 13 .leaf)) 62123 17 (.node (.node (.node .leaf 62128 16 .leaf) 62129 8 .leaf) 62131 12 (.node .leaf 62153 12 .leaf)))) 62155 16 (.node (.node (.node (.node (.node .leaf 62160 16 .leaf) 62161 7 .leaf) 62163 11 (.node (.node .leaf 62185 14 .leaf) 62187 18 .leaf)) 62193 18 (.node (.node (.node .leaf 62217 13 .leaf) 62219 17 .leaf) 62224 15 (.node (.node .leaf 62225 8 .leaf) 62227 12 .leaf))) 62249 14 (.node (.node (.node (.node .leaf 62251 18 .leaf) 62256 17 .leaf) 62257 9 (.node (.node .leaf 62259 13 .leaf) 62281 13 .leaf)) 62283 17 (.node (.node (.node .leaf 62288 15 .leaf) 62289 8 .leaf) 62291 12 (.node .leaf 62313 15 .leaf)))))) 62345 14 (.node (.node (.node (.node (.node (.node (.node .leaf 62347 18 .leaf) 62352 14 .leaf) 62353 9 (.node (.node .leaf 62355 13 .leaf) 62377 15 .leaf)) 62384 17 (.node (.node (.node .leaf 62385 10 .leaf) 62387 14 .leaf) 62409 14 (.node (.node .leaf 62411 18 .leaf) 62416 14 .leaf))) 62417 9 (.node (.node (.node (.node .leaf 62418 18 .leaf) 62419 13 .leaf) 62441 16 (.node (.node .leaf 62472 18 .leaf) 62473 15 .leaf)) 62480 13 (.node (.node (.node .leaf 62481 10 .leaf) 62483 14 .leaf) 62505 16 (.node (.node .leaf 62512 16 .leaf) 62513 11 .leaf)))) 62515 15 (.node (.node (.node (.node (.node .leaf 62536 18 .leaf) 62537 15 .leaf) 62544 13 (.node (.node .leaf 62545 10 .leaf) 62547 14 .leaf)) 62569 17 (.node (.node (.node .leaf 62600 17 .leaf) 62601 16 .leaf) 62608 12 (.node (.node .leaf 62609 11 .leaf) 62611 15 .leaf))) 62633 17 (.node (.node (.node (.node .leaf 62640 15 .leaf) 62641 12 .leaf) 62643 16 (.node (.node .leaf 62664 18 .leaf) 62665 16 .leaf)) 62672 13 (.node (.node (.node .leaf 62673 11 .leaf) 62675 15 .leaf) 62697 18 (.node .leaf 62728 18 .leaf))))) 62729 17 (.node (.node (.node (.node (.node (.node .leaf 62736 13 .leaf) 62737 12 .leaf) 62739 16 (.node (.node .leaf 62761 17 .leaf) 62768 14 .leaf)) 62769 12 (.node (.node (.node .leaf 62771 16 .leaf) 62793 18 .leaf) 62825 18 (.node (.node .leaf 64168 11 .leaf) 64169 3 .leaf))) 64170 18 (.node (.node (.node (.node .leaf 64171 7 .leaf) 64176 16 .leaf) 64177 6 (.node (.node .leaf 64179 10 .leaf) 64201 13 .leaf)) 64203 17 (.node (.node (.node .leaf 64209 17 .leaf) 64232 11 .leaf) 64233 2 (.node .leaf 64234 17 .leaf)))) 64235 6 (.node (.node (.node (.node (.node .leaf 64240 15 .leaf) 64241 6 .leaf) 64243 10 (.node (.node .leaf 64265 14 .leaf) 64267 18 .leaf)) 64273 18 (.node (.node (.node .leaf 64296 10 .leaf) 64297 3 .leaf) 64298 16 (.node (.node .leaf 64299 7 .leaf) 64304 15 .leaf))) 64305 7 (.node (.node (.node (.node .leaf 64307 11 .leaf) 64329 14 .leaf) 64331 18 (.node (.node .leaf 64337 18 .leaf) 64360 10 .leaf)) 64361 4 (.node (.node (.node .leaf 64362 15 .leaf) 64363 8 .leaf) 64368 14 (.node .leaf 64369 7 .leaf)))))))) 64370 18 (.node (.node (.node (.node (.node (.node (.node (.node (.node .leaf 64371 11 .leaf) 64393 15 .leaf) 64424 9 (.node (.node .leaf 64425 5 .leaf) 64426 14 .leaf)) 64427 9 (.node (.node (.node .leaf 64432 14 .leaf) 64433 8 .leaf) 64434 18 (.node (.node .leaf 64435 12 .leaf) 64457 15 .leaf))) 64488 9 (.node (.node (.node (.node .leaf 64489 6 .leaf) 64490 13 .leaf) 64491 10 (.node (.node .leaf 64496 13 .leaf) 64497 8 .leaf)) 64498 17 (.node (.node (.node .leaf 64499 12 .leaf) 64521 16 .leaf) 64552 8 (.node (.node .leaf 64553 7 .leaf) 64554 14 .leaf)))) 64555 11 (.node (.node (.node (.node (.node .leaf 64560 13 .leaf) 64561 9 .leaf) 64563 13 (.node (.node .leaf 64585 16 .leaf) 64616 8 .leaf)) 64617 8 (.node (.node (.node .leaf 64618 15 .leaf) 64619 12 .leaf) 64624 12 (.node (.node .leaf 64625 9 .leaf) 64626 18 .leaf))) 64627 13 (.node (.node (.node (.node .leaf 64649 17 .leaf) 64680 7 .leaf) 64681 9 (.node (.node .leaf 64682 16 .leaf) 64683 13 .leaf)) 64688 12 (.node (.node (.node .leaf 64689 10 .leaf) 64691 14 .leaf) 64713 17 (.node .leaf 64744 8 .leaf))))) 64745 10 (.node (.node (.node (.node (.node (.node .leaf 64746 17 .leaf) 64747 14 .leaf) 64752 13 (.node (.node .leaf 64753 10 .leaf) 64755 14 .leaf)) 64777 18 (.node (.node (.node .leaf 64808 8 .leaf) 64809 11 .leaf) 64810 18 (.node (.node .leaf 64811 15 .leaf) 64816 13 .leaf))) 64817 11 (.node (.node (.node (.node .leaf 64819 15 .leaf) 64872 9 .leaf) 64873 12 (.node (.node .leaf 64875 16 .leaf) 64939 17 .leaf)) 65003 18 (.node (.node (.node .leaf 66217 12 .leaf) 66219 16 .leaf) 66224 16 (.node .leaf 66225 7 .leaf)))) 66227 11 (.node (.node (.node (.node (.node .leaf 66249 11 .leaf) 66251 15 .leaf) 66256 16 (.node (.node .leaf 66257 6 .leaf) 66259 10 .leaf)) 66281 13 (.node (.node (.node .leaf 66283 17 .leaf) 66289 18 .leaf) 66313 12 (.node (.node .leaf 66315 16 .leaf) 66320 15 .leaf))) 66321 7 (.node (.node (.node (.node .leaf 66323 11 .leaf) 66345 13 .leaf) 66347 17 (.node (.node .leaf 66352 17 .leaf) 66353 8 .leaf)) 66355 12 (.node (.node (.node .leaf 66377 12 .leaf) 66379 16 .leaf) 66384 15 (.node .leaf 66385 7 .leaf)))))) 66387 11 (.node (.node (.node (.node (.node (.node (.node .leaf 66409 14 .leaf) 66411 18 .leaf) 66441 13 (.node (.node .leaf 66443 17 .leaf) 66448 14 .leaf)) 66449 8 (.node (.node (.node .leaf 66451 12 .leaf) 66473 14 .leaf) 66475 18 (.node (.node .leaf 66480 17 .leaf) 66481 9 .leaf))) 66483 13 (.node (.node (.node (.node .leaf 66505 13 .leaf) 66507 17 .leaf) 66512 14 (.node (.node .leaf 66513 8 .leaf) 66514 18 .leaf)) 66515 12 (.node (.node (.node .leaf 66537 15 .leaf) 66568 18 .leaf) 66569 14 (.node (.node .leaf 66571 18 .leaf) 66576 13 .leaf)))) 66577 9 (.node (.node (.node (.node (.node .leaf 66579 13 .leaf) 66601 15 .leaf) 66608 16 (.node (.node .leaf 66609 10 .leaf) 66611 14 .leaf)) 66632 18 (.node (.node (.node .leaf 66633 14 .leaf) 66635 18 .leaf) 66640 13 (.node (.node .leaf 66641 9 .leaf) 66643 13 .leaf))) 66665 16 (.node (.node (.node (.node .leaf 66696 17 .leaf) 66697 15 .leaf) 66704 12 (.node (.node .leaf 66705 10 .leaf) 66707 14 .leaf)) 66729 16 (.node (.node (.node .leaf 66736 15 .leaf) 66737 11 .leaf) 66739 15 (.node .leaf 66760 18 .leaf))))) 66761 15 (.node (.node (.node (.node (.node (.node .leaf 66768 13 .leaf) 66769 10 .leaf) 66771 14 (.node (.node .leaf 66793 17 .leaf) 66824 18 .leaf)) 66825 16 (.node (.node (.node .leaf 66832 13 .leaf) 66833 11 .leaf) 66835 15 (.node (.node .leaf 66857 16 .leaf) 66864 14 .leaf))) 66865 11 (.node (.node (.node (.node .leaf 66867 15 .leaf) 66889 17 .leaf) 66921 17 (.node (.node .leaf 68264 11 .leaf) 68265 2 .leaf)) 68267 6 (.node (.node (.node .leaf 68272 6 .leaf) 68273 6 .leaf) 68275 10 (.node .leaf 68297 12 .leaf)))) 68299 16 (.node (.node (.node (.node (.node .leaf 68304 17 .leaf) 68305 7 .leaf) 68307 11 (.node (.node .leaf 68329 1 .leaf) 68331 5 .leaf)) 68336 15 (.node (.node (.node .leaf 68337 6 .leaf) 68339 10 .leaf) 68361 13 (.node (.node .leaf 68363 17 .leaf) 68368 16 .leaf))) 68369 8 (.node (.node (.node (.node .leaf 68371 12 .leaf) 68392 10 .leaf) 68393 2 (.node (.node .leaf 68394 16 .leaf) 68395 6 .leaf)) 68400 5 (.node (.node (.node .leaf 68401 7 .leaf) 68403 11 .leaf) 68425 13 (.node .leaf 68427 17 .leaf))))))) 68432 16 (.node (.node (.node (.node (.node (.node (.node (.node .leaf 68433 8 .leaf) 68435 12 .leaf) 68456 10 (.node (.node .leaf 68457 3 .leaf) 68458 15 .leaf)) 68459 7 (.node (.node (.node .leaf 68464 14 .leaf) 68465 7 .leaf) 68466 18 (.node (.node .leaf 68467 11 .leaf) 68489 14 .leaf))) 68491 18 (.node (.node (.node (.node .leaf 68496 15 .leaf) 68497 9 .leaf) 68499 13 (.node (.node .leaf 68520 9 .leaf) 68521 4 .leaf)) 68522 14 (.node (.node (.node .leaf 68523 8 .leaf) 68528 4 .leaf) 68529 8 (.node (.node .leaf 68530 18 .leaf) 68531 12 .leaf)))) 68553 14 (.node (.node (.node (.node (.node .leaf 68555 18 .leaf) 68560 15 .leaf) 68561 9 (.node (.node .leaf 68563 13 .leaf) 68584 9 .leaf)) 68585 5 (.node (.node (.node .leaf 68586 13 .leaf) 68587 9 .leaf) 68592 13 (.node (.node .leaf 68593 8 .leaf) 68594 17 .leaf))) 68595 12 (.node (.node (.node (.node .leaf 68617 15 .leaf) 68624 14 .leaf) 68625 10 (.node (.node .leaf 68627 14 .leaf) 68648 8 .leaf)) 68649 6 (.node (.node (.node .leaf 68650 14 .leaf) 68651 10 .leaf) 68656 3 (.node .leaf 68657 9 .leaf))))) 68659 13 (.node (.node (.node (.node (.node (.node .leaf 68681 15 .leaf) 68688 14 .leaf) 68689 10 (.node (.node .leaf 68691 14 .leaf) 68712 8 .leaf)) 68713 7 (.node (.node (.node .leaf 68714 15 .leaf) 68715 11 .leaf) 68720 12 (.node (.node .leaf 68721 9 .leaf) 68722 18 .leaf))) 68723 13 (.node (.node (.node (.node .leaf 68744 18 .leaf) 68745 16 .leaf) 68752 13 (.node (.node .leaf 68753 11 .leaf) 68755 15 .leaf)) 68776 7 (.node (.node (.node .leaf 68777 8 .leaf) 68778 16 .leaf) 68779 12 (.node .leaf 68784 2 .leaf)))) 68785 10 (.node (.node (.node (.node (.node .leaf 68787 14 .leaf) 68809 16 .leaf) 68816 14 (.node (.node .leaf 68817 11 .leaf) 68819 15 .leaf)) 68840 8 (.node (.node (.node .leaf 68841 9 .leaf) 68842 17 .leaf) 68843 13 (.node (.node .leaf 68848 13 .leaf) 68849 10 .leaf))) 68851 14 (.node (.node (.node (.node .leaf 68873 17 .leaf) 68880 14 .leaf) 68881 12 (.node (.node .leaf 68883 16 .leaf) 68904 8 .leaf)) 68905 10 (.node (.node (.node .leaf 68906 18 .leaf) 68907 14 .leaf) 68912 3 (.node .leaf 68913 11 .leaf)))))) 68915 15 (.node (.node (.node (.node (.node (.node (.node .leaf 68937 18 .leaf) 68968 9 .leaf) 68969 11 (.node (.node .leaf 68971 15 .leaf) 70313 13 .leaf)) 70315 17 (.node (.node (.node .leaf 70345 12 .leaf) 70347 16 .leaf) 70377 14 (.node (.node .leaf 70379 18 .leaf) 70409 13 .leaf))) 70411 17 (.node (.node (.node (.node .leaf 70441 14 .leaf) 70443 18 .leaf) 70473 13 (.node (.node .leaf 70475 17 .leaf) 70505 15 .leaf)) 70537 14 (.node (.node (.node .leaf 70539 18 .leaf) 70569 15 .leaf) 70601 14 (.node (.node .leaf 70603 18 .leaf) 70633 16 .leaf)))) 70665 15 (.node (.node (.node (.node (.node .leaf 70697 16 .leaf) 70729 15 .leaf) 70761 17 (.node (.node .leaf 70792 18 .leaf) 70793 16 .leaf)) 70825 17 (.node (.node (.node .leaf 70857 16 .leaf) 70889 18 .leaf) 70921 17 (.node (.node .leaf 70953 17 .leaf) 70985 18 .leaf))) 71017 18 (.node (.node (.node (.node .leaf 72360 12 .leaf) 72361 3 .leaf) 72363 6 (.node (.node .leaf 72393 13 .leaf) 72395 17 .leaf)) 72425 2 (.node (.node (.node .leaf 72427 5 .leaf) 72457 14 .leaf) 72459 18 (.node .leaf 72488 11 .leaf))))) 72489 3 (.node (.node (.node (.node (.node (.node .leaf 72490 17 .leaf) 72491 6 .leaf) 72521 14 (.node (.node .leaf 72523 18 .leaf) 72552 11 .leaf)) 72553 4 (.node (.node (.node .leaf 72554 16 .leaf) 72555 7 .leaf) 72585 15 (.node (.node .leaf 72616 10 .leaf) 72617 5 .leaf))) 72618 15 (.node (.node (.node (.node .leaf 72619 8 .leaf) 72649 15 .leaf) 72680 10 (.node (.node .leaf 72681 6 .leaf) 72682 14 .leaf)) 72683 9 (.node (.node (.node .leaf 72713 16 .leaf) 72744 9 .leaf) 72745 7 (.node .leaf 72746 15 .leaf)))) 72747 10 (.node (.node (.node (.node (.node .leaf 72777 16 .leaf) 72808 9 .leaf) 72809 8 (.node (.node .leaf 72810 16 .leaf) 72811 11 .leaf)) 72841 17 (.node (.node (.node .leaf 72872 8 .leaf) 72873 9 .leaf) 72874 17 (.node (.node .leaf 72875 12 .leaf) 72905 17 .leaf))) 72936 9 (.node (.node (.node (.node .leaf 72937 10 .leaf) 72938 18 .leaf) 72939 13 (.node (.node .leaf 72969 18 .leaf) 73000 9 .leaf)) 73001 11 (.node (.node (.node .leaf 73003 14 .leaf) 73064 10 .leaf) 73065 12 (.node .leaf 73067 15 .leaf))))))))))

def gk (k : Nat) : Option Nat := tree.find k

def inB (t : P) : Bool := decide (t.r < 64) && decide (t.c < 64) && decide (t.n < 8)

def ok (p : P) (g : Nat) (a : Act) : Bool :=
  match absStep p a with
  | .win => decide (18 < g + 1)
  | .to t .norm => decide (18 < g + cost a) ||
      (inB t && match gk (key t) with
                | some v => decide (v ≤ g + cost a)
                | none => false)
  | .to t .refill => decide (18 < g + 1) ||
      (inB t && match gk (key t) with
                | some v => decide (v ≤ min (g + 1 - 10) 5)
                | none => false)

def allActs : List Act :=
  [.mv .U, .mv .D, .mv .L, .mv .R, .F 0, .F 1, .F 2, .F 3, .F 4, .M6]

def checkAll : Bool := tree.toList.all fun e => allActs.all (ok (decode e.1) e.2)

theorem checkAll_true : checkAll = true := by decide +kernel

/-- every state in the table passes the transition check. -/
theorem gk_ok (k v : Nat) (h : gk k = some v) : allActs.all (ok (decode k) v) = true := by
  have hc := checkAll_true
  simp only [checkAll, List.all_eq_true] at hc
  rw [List.all_eq_true]
  exact hc (k, v) (T.find_mem tree k v h)

end L4.V3

namespace L4.V3
open L4 (Dir shift inSlot box)

theorem ok_all (p : P) (g : Nat) (h : allActs.all (ok p g) = true) (a : Act) : ok p g a = true := by
  rw [List.all_eq_true] at h
  cases a with
  | mv d => cases d <;> exact h _ (by simp [allActs])
  | M6 => exact h _ (by simp [allActs])
  | F i =>
    rcases i with _ | _ | _ | _ | i
    · exact h _ (by simp [allActs])
    · exact h _ (by simp [allActs])
    · exact h _ (by simp [allActs])
    · exact h _ (by simp [allActs])
    · have h4 := h (.F 4) (by simp [allActs])
      have e : ok p g (.F (i + 4)) = ok p g (.F 4) := rfl
      rw [e]; exact h4

theorem decode_key (p : P) (h1 : p.r < 64) (h2 : p.c < 64) (h3 : p.n < 8) :
    decode (key p) = p := by
  obtain ⟨r, c, n, op, rf⟩ := p
  simp only at h1 h2 h3
  cases op <;> cases rf <;> simp [key, decode] <;> omega

def J (B : Nat) (s : St) : Prop :=
  s.won = false ∧ s.k ≤ B ∧ s.p.r < 64 ∧ s.p.c < 64 ∧ s.p.n < 8 ∧
  ∃ v, gk (key s.p) = some v ∧ v ≤ s.k

theorem cost_pos (a : Act) : 1 ≤ cost a := by cases a <;> simp [cost]

theorem pres (B : Nat) (hB : B ≤ 18) (s : St) (a : Act) (h : J B s) : J B (step B s a) := by
  obtain ⟨hw, hk, h1, h2, h3, v, hv, hvk⟩ := h
  unfold step
  by_cases hg : s.won = false ∧ s.k + cost a ≤ B
  · rw [if_pos hg]
    have hc := gk_ok (key s.p) v hv
    rw [decode_key s.p h1 h2 h3] at hc
    have hok := ok_all _ _ hc a
    have cp := cost_pos a
    unfold ok at hok
    split at hok
    · rename_i hres
      simp at hok; omega
    · rename_i t hres
      simp only [Bool.or_eq_true, decide_eq_true_eq, Bool.and_eq_true, inB] at hok
      rcases hok with hok | ⟨⟨⟨b1, b2⟩, b3⟩, hl⟩
      · omega
      · split at hl
        · rename_i v' hv'
          simp only [decide_eq_true_eq] at hl
          exact ⟨rfl, by dsimp only; omega, b1, b2, b3, v', hv', by dsimp only; omega⟩
        · simp at hl
    · rename_i t hres
      simp only [Bool.or_eq_true, decide_eq_true_eq, Bool.and_eq_true, inB] at hok
      rcases hok with hok | ⟨⟨⟨b1, b2⟩, b3⟩, hl⟩
      · omega
      · split at hl
        · rename_i v' hv'
          simp only [decide_eq_true_eq] at hl
          exact ⟨rfl, by dsimp only; omega, b1, b2, b3, v', hv', by dsimp only; omega⟩
        · simp at hl
  · rw [if_neg hg]; exact ⟨hw, hk, h1, h2, h3, v, hv, hvk⟩

theorem run_J (B : Nat) (hB : B ≤ 18) (as : List Act) : ∀ s, J B s → J B (run B s as) := by
  induction as with
  | nil => intro s h; exact h
  | cons a as ih =>
    intro s h
    simp only [run, List.foldl_cons]
    exact ih _ (pres B hB s a h)

theorem start_in : gk (key startP) = some 0 := by decide +kernel

theorem J_start (B : Nat) : J B start :=
  ⟨rfl, Nat.zero_le _, by decide, by decide, by decide, 0, start_in, Nat.le_refl _⟩

/-- MAIN (attempt 3): with any budget B ≤ 18 units, no action sequence wins level 4 in the V3
    model (refill, grow with any of 5 anchors, trigger at c = 31 regardless of facing). -/
theorem never_wins (B : Nat) (hB : B ≤ 18) (as : List Act) : (run B start as).won = false :=
  (run_J B hB as start (J_start B)).1

/-- Non-vacuity: one more unit (B = 19) and the same model has a winning route. -/
def route19 : List Act :=
  [.mv .D, .mv .D, .mv .L, .mv .L, .mv .L, .F 0, .mv .L, .mv .U, .F 3, .mv .R, .mv .R, .M6,
   .mv .R, .mv .R, .mv .R, .mv .R, .mv .R, .mv .R]

theorem route19_wins : (run 19 start route19).won = true := by decide +kernel
theorem route19_at18 : (run 18 start route19).won = false := by decide +kernel

end L4.V3

#print axioms L4.route_wins
#print axioms L4.route_needs_trig
#print axioms L4.closed_never_wins
#print axioms L4.route_wins_H6
#print axioms L4.V2.never_wins
#print axioms L4.V2.never_wins_measured
#print axioms L4.V2.route26_wins
#print axioms L4.V3.never_wins
#print axioms L4.V3.route19_wins
#print axioms L4.V3.route19_at18
