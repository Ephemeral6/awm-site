#!/bin/bash
# Free click scan: clicks on a coarse grid of board cells; stops at the first click whose frame diff is non-zero.
cd D:/arc-arena/l4p-case-2a3cc5
for y in $(seq 1 3 45); do
  for x in $(seq 1 3 60); do
    # skip known panels (cols 0-9, rows 0-20): they only show hints
    if [ $x -le 9 ] && [ $y -le 20 ]; then continue; fi
    python play.py settle > /dev/null
    python play.py bet "scan click ($x,$y): predict zero diff, free (no rule covers it)" > /dev/null
    python play.py act ACTION6:$x,$y > /dev/null
    n=$(python work/diff.py | head -1 | awk '{print $3}')
    if [ "$n" != "0" ]; then echo "NONZERO at $x,$y diff $n"; python work/diff.py | head -5; exit 0; fi
  done
done
echo "scan done, all zero"
