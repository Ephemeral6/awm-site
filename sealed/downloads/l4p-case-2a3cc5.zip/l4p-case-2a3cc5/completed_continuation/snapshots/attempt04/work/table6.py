# V4 abstract L4 model: forward least spent budget g over (r,c,n,face,op,rf), budget B.
# Attempt-4 amendment of table4.py: facing is back (the refill rule reads it); refill fires when
# some position along the slide (end included -- looser than end-only) has the marker under BOTH
# the 9 half and the 10 half, any size. Grow anchor: any of 5 (loose). Trigger: c == 31 (any facing).
# Refill: k := min(k+1-10, 5) (looser of the two readings; -10 measured in attempt 4).
import sys, json
def box(y0,y1,x0,x1): return lambda y,x: y0<=y<=y1 and x0<=x<=x1
room=box(21,36,21,44); shaft=box(9,20,31,32); bar_=box(29,32,45,47); corr=box(29,32,48,56); slot=box(29,32,57,60); bx=box(5,8,30,33)
marker={(34,23),(34,24),(35,23),(35,24)}
def floor(op,y,x): return room(y,x) or shaft(y,x) or corr(y,x) or (op and (bar_(y,x) or bx(y,x)))
D={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}
FI={'U':0,'D':1,'L':2,'R':3}
def fp(r,c,n): return [(r+i,c+j) for i in range(n) for j in range(n)]
def nine(r,c,n,d):
    h=n//2
    return {'U':[(r+i,c+j) for i in range(h) for j in range(n)],'D':[(r+n-1-i,c+j) for i in range(h) for j in range(n)],
            'L':[(r+i,c+j) for i in range(n) for j in range(h)],'R':[(r+i,c+n-1-j) for i in range(n) for j in range(h)]}[d]
def straddle(r,c,n,d):
    nn=set(nine(r,c,n,d)); tt=set(fp(r,c,n))-nn
    return bool(nn&marker) and bool(tt&marker)
ANCH=[(2,2),(0,0),(1,1),(2,0),(0,2)] if 'anch' in sys.argv else [(2,2)]
B=int([a for a in sys.argv if a.isdigit()][0]) if any(a.isdigit() for a in sys.argv) else 18
def succ(s):
    r,c,n,f,op,rf=s; out=[]
    for d in 'UDLR':
        dy,dx=D[d]
        if any(slot(y,x) for y,x in fp(r+dy*n,c+dx*n,n)): out.append(('mv'+d,'WIN','norm')); continue
        k=0; touched=('slide' in sys.argv) and straddle(r,c,n,d)   # the start cell, re-faced (looser; flag 'slide')
        while k<n and all(floor(op,y,x) for y,x in fp(r+dy*(k+1),c+dx*(k+1),n)):
            k+=1
            if (k==n or 'slide' in sys.argv) and straddle(r+dy*k,c+dx*k,n,d): touched=True
        if k<n and straddle(r+dy*k,c+dx*k,n,d): touched=True   # end position after a clamped slide
        t=(r+dy*k,c+dx*k,n,d,op,rf)
        if not rf and touched: out.append(('mv'+d,t[:5]+(True,),'refill'))
        else: out.append(('mv'+d,t,'norm'))
    if n==4: out.append(('F0',(r,c,2,f,op,rf),5))
    else:
        if 'clamp' in sys.argv and all(floor(op,y,x) for y,x in fp(r-2,c-2,4)) and r>=2 and c>=2:
            out.append(('F0',(r-2,c-2,4,f,op,rf),5))
        else:
          for i,(ay,ax) in enumerate(ANCH):
            if r>=ay and c>=ax and all(floor(op,y,x) for y,x in fp(r-ay,c-ax,4)): out.append(('F%d'%i,(r-ay,c-ax,4,f,op,rf),5))
            else: out.append(('F%d'%i,s,5))
    out.append(('M6',(r,c,n,f,op or c==31,rf),4))
    return out
def apply_cost(k,kind):
    if kind=='norm': return k+1
    if kind=='refill': return min(max(k+1-10,0),5) if 'set5' in sys.argv else max(k+1-10,0)
    return k+kind
start=(25,37,4,'D',False,False)
g={start:0}; changed=True
while changed:
    changed=False
    for s in list(g):
        for a,t,kind in succ(s):
            if t=='WIN': continue
            if g[s]+(1 if kind in ('norm','refill') else kind)>B: continue
            k2=apply_cost(g[s],kind)
            if k2<g.get(t,99): g[t]=k2; changed=True
wins=[g[s] for s in g for a,t,k in succ(s) if t=='WIN']
print('B',B,'states',len(g),'min g at win-able states', min(wins) if wins else None)
def key(s):
    r,c,n,f,op,rf=s; return ((r*64+c)*8+n)*16+FI[f]*4+(2 if op else 0)+(1 if rf else 0)
if 'emit' in sys.argv:
    ents=sorted((key(s),v) for s,v in g.items())
    with open('work/tab6.txt','w',encoding='utf-8') as fo:
        for k,v in ents: fo.write('%d %d\n'%(k,v))
    print('emitted',len(ents))
