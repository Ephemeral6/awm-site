#!/bin/bash
# usage: step.sh "bet text" ACTION...
cd /d/arc-arena/m15fw-case-69fe87
python play.py settle | tail -3
python play.py bet "$1" >/dev/null
shift
python play.py act "$@" | head -20
python work/d.py
