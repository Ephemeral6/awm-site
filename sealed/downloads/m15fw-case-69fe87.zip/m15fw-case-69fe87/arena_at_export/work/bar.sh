python -c "
import json
d=json.load(open('D:/arc-arena/m15fw-case-69fe87/.last_frame.json'));f=d['frame'];print('bar rows',sum(1 for y in range(64) if f[y][62]==0))"
