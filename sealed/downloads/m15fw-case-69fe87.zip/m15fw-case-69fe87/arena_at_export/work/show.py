import json,sys
d=json.load(open(sys.argv[1] if len(sys.argv)>1 else '.last_frame.json'))
f=d['frame'] if 'frame' in d else d
print('level',d.get('level'))
hexd='0123456789abcdef'
print('   '+''.join(str(i%10) for i in range(64)))
for i,r in enumerate(f): print('%2d '%i+''.join(hexd[v] for v in r))
