## play 1

I reached level 4 and did not beat the game. Levels 1–3 are cleared (3 of the levels completed), and the run ended in GAME_OVER on level 4 when its move budget ran out. I did not call reset.

**How the game works:**
- **Movement:** Actions 1–4 move a 4×4 block up, down, left and right by its own size. Its 9-coloured side turns to face the direction it last moved. Touching the exit box (9 border, a interior) clears the level.
- **Spells:** The 3×3 grid at the bottom is a drawing pad. Clicking a cell selects or deselects it. When the selected cells match a "card" shown on the level, the spell fires and the grid resets. Only the spells whose cards are shown on that level fire; drawing the level-1 diamond on level 3 did nothing.
  - **Diamond (level 1):** shrinks the block to 2×2, so it can climb the narrow stalk to the exit.
  - **L-shape (level 2):** teleports the block into the square marked by b corners, next to the exit.
  - **Middle column (level 3):** fires a block-sized shot in the facing direction. Fired up the stalk at the 6/d box, it removed that box and the d barrier blocking the exit.
- **Budget:** Columns 62–63 fill up with each action. The cost per action differs by level (level 4 allowed only about 20 actions), and spells cost more. One action after the bar is full, the game ends.

**Why level 4 failed:** I set up the same shot that worked on level 3, but it disappeared straight away instead of reaching the box. On a probe across open floor the shot travelled 2 cells per frame and stopped at the wall. I don't know why it failed on level 4. My best guesses are the longer distance to the box (13 rows against 10) or the stalk sitting under the other half of the block. I also never checked a small 2×2 grey-blue (colour 14) patch in the level-4 room. Once the budget left was too small to finish, I spent the last actions learning what running out does.

**Method artefacts:**
- **Concepts:** three files in `concepts/` (moving the block, arrow keys leaving the grid alone, cell-click toggle). All are settled with no counterexamples: S = 1.0, N = 43, 44 and 22, coverage about 0.26–0.52, seen = 0. One was revised after a counterexample on level 3. The spell, teleport and exit rules are written up only in `work/NOTES.md`, not as concepts, so none of the concepts predict frame cells (E = 0).
- **Notes:** `work/NOTES.md` has the rule list with evidence, the audit of mechanisms left out, and notes for another attempt.
- **Not done:** Step 2 (the Lean formalisation) is not started.
- **Harness change:** I edited `play.py` to also save each action's animation frames to `work/lastframes.json`; nothing else in it changed.

## probe 1

**1. What happened on level 4**

Level 4 shows two spell cards: a diamond that shrinks the block, and a vertical column that fires a shot. A d-coloured barrier blocks the only corridor to the exit, and a small 6-bordered switch box sits at the top of a narrow stalk. On level 3, firing the column spell up the stalk at the same kind of box removed both the box and the barrier.

On level 4 I copied that set-up exactly: 4×4 block directly under the stalk, facing up. I cast it twice and nothing happened. When I captured the animation frames, the shot appeared one step ahead of the block and vanished immediately.

A third cast, fired sideways across open floor, showed how the shot behaves: it is the size of the block, travels 2 cells per frame, and dies when its leading edge reaches a wall. Each completing click costs double, so these casts used up the budget. Taking one action past a full budget bar gave GAME_OVER.

The failure was mine: I repeated a manoeuvre that had worked without understanding why it worked, on a level where the budget is only 18 units.

**2. Can the level be beaten?**

Under my rules, no. Claim: with a budget of 18 units, no sequence of actions reaches the exit.

The argument:
- The barrier opens only when a shot reaches the switch box (premise **H**).
- A 4×4 block cannot get such a shot through.
  - At the one position touching the stalk, x=4, it failed twice (transitions 76 and 79).
  - At every other column, the shot's leading edge would start on background, and transition 83 shows that kills it.
- So the block must first shrink to 2×2, then shoot from x=5 (col 31), the stalk column. That needs at least:
  - 4 clicks to shrink, 5 units;
  - 3 clicks to shoot, 4 units;
  - 13 moves right afterwards, from col 31 to the exit at col 57.
- Even letting one click fire both spells together, the cost is at least 21 units, which is more than 18.

Established parts:
- Movement and step sizes.
- Clicks select and deselect cells.
- Only the spells shown on the level's cards fire (transition 54).
- The cost model (a unique fit).
- The 4×4 shot failure at x=4.

Assumptions I did not check:
- **H** itself, in particular that a shot travelling into the d barrier from a distance does not destroy it. That case was never tested.
- What the grey-blue 2×2 pad on the level-4 room floor (colour e) does.

**3. Next attempt**

The first and cheapest experiment, at about 7 units:
1. From the start, move left, then down, then right, so the 4×4 block sits at rows 29–32, cols 37–40, facing right with one cell of floor before the barrier.
2. Cast the column spell.

If the barrier goes, move right 5 times to the exit, about 12 units in total. If it does not, I have learned that within budget and stop probing. I will not repeat a cast whose outcome I already know.

**4. Formal system** (`work/MODEL.md`, `lean/M15L4.lean`)

This is the first formal system, so there was nothing to amend.

- **Objects:**
  - Block: size (big/small) and column x = (col−21)/2.
  - Barrier: opened or closed.
  - Grid: number of selected cells.
  - Rows, facing and walls are dropped; this only adds possible moves, so the model is looser than the game.
- **Rules:**
  - Move: x changes by ±2 (big) or ±1 (small), cost 1.
  - Select / deselect: cost 1.
  - Completing click: cost 2. It clears the grid and then either shrinks the block or fires the shot, which sets opened if the shot opens the barrier.
  - Clicks on world objects or on the cards: cost 0.
  - Goal: opened, and the block reaches the exit column.
- **Lean status:**
  - Definitions: `St`, `Act`, `cost`, `step`, `goal`, `start`, `L4budget = 18`.
  - Consequences: `hstep`, `pot_le_cost`, `L4_unwinnable`.
  - Premise **H** is an explicit hypothesis, `hopen`, not part of any definition.
  - Not in the model: the e pad, a shot destroying the barrier directly, rows and facing.

**5. Proof**

File: `lean/M15L4.lean`. It compiles, and the axiom output is:
```
'M15L4.hstep' depends on axioms: [propext, Quot.sound]
'M15L4.pot_le_cost' depends on axioms: [propext, Quot.sound]
'M15L4.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4.witness_wins' does not depend on any axioms
'M15L4.cheap_wins' does not depend on any axioms
```
- `L4_unwinnable` says: for every opening function satisfying `hopen` ("only a small block at x=5 opens the barrier"), every action list costing at most `L4budget` never reaches the goal.
- It rests on the move, click, completing-click, cost and goal rules above.
- Two checks show the bound is not empty:
  - `witness_wins`: the model can be won with 24 units.
  - `cheap_wins`: if a big block could open the barrier, a 12-unit win fits inside 18.
- Where the Lean model is stricter than the game: `hopen` excludes a shot from any other position, and the e pad is left out. Everywhere else it is looser.

**6.** Not applicable. The formal system is new from this attempt.

**7. Checks on the proof**

a. I searched display granularity (1 or 2 rows), rounding (floor, round, ceil), completing-click cost from 1 to 10 in quarter steps, whether the first action after reset is counted, and each level's total from 8 to 80. The bar never went down, so refunds are 0.

One combination survives:
- 2-row display, floor rounding;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- level budgets: level 1 is 50 or 50.25, level 2 is 25 to 25.5, level 3 is 50, level 4 is 18.

The level-4 conclusions are the same across the surviving variants.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation (attempt 1) | Would differ if… |
|---|---|---|
| Cost and budget = 18 | Transitions 85–86: bar full and still NOT_FINISHED, then GAME_OVER on the next action | the fit were wrong |
| Big shot at x=4 fails | Transition 79 frames: shot dies at the first step | the shot could pass there |
| Only shown cards fire | Transition 54: diamond drawn on level 3 with no effect | other spells were enabled |
| Shrink keeps top-left, then step 2 | Transitions 17–18 | the shrunk block sat elsewhere |

There is no decisive experiment yet for "a shot into the barrier does not open it", or for big shots from other columns. The experiment to run is the cast described in section 3.

c. The proof goes through for budgets up to 20 and first fails at 21. That margin is small, but the measured budget of 18 sits below my model's minimum cost of 21 or more. A level designed to fit its budget implies the model is stricter than the game. The rule I suspect is `hopen`: most likely a shot travelling into the d barrier opens it directly.

VERDICT: impossible
CONFIDENCE: 30