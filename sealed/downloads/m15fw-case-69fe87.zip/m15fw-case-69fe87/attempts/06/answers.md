## play 1

I didn't beat the game: it ended in GAME_OVER on level 4, after levels 1–3. I did not reset.

My rules still say level 4 can't be done within its 18-unit budget, so I spent this attempt testing what was left untested:

- **Partly covering the pad with the big block:** I checked this in the planner before acting. Even if it triggered the refund, there would still be no route within 18, so I skipped the in-game test.
- **One click completing two patterns:** when the selected cells contained both the diamond and the column pattern, nothing fired; that click cost 1. So patterns must match exactly. This was the main untested assumption behind the impossibility proof, and it holds.
- **Deselecting:** removing the extra cell, which left exactly the diamond, fired the shrink. So the pattern check runs after every click on the grid, including deselects. It saves no budget.
- **Growing where the usual spot is blocked:** the grow still happens. The big block keeps the small block's row and shifts 2 columns left, instead of the usual up-and-left. Re-planning with this rule, the cheapest route is still 21 units against a budget of 18.

The remaining budget then ran out and the next move ended the game. Every rule I can test now holds, and under them level 4 has no route within budget.

Notes are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

My rules already said level 4 can't be finished within its 18-unit budget, so I used this attempt to test what was left untested.
- **One click completing two patterns:** I selected five cells containing both the diamond and the column. Nothing fired; the click cost 1.
- **Deselecting into a pattern:** removing one cell, which left exactly the diamond, did fire the shrink. Patterns are checked after every grid click, deselects included.
- **Growing with the usual spot blocked:** I put the small block in the room's top row and grew it. The grow still happened: the big block kept the small block's row and shifted 2 columns left.

The budget then ran out. The failure is unchanged: opening the barrier needs a block whose left edge is at column 31. Getting there costs a shrink and a grow, plus the shot, plus the walk to the exit, and every route comes to more than 18 even with the pad's 10-unit refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. The check covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink placement.** Shrink keeps the top-left corner.
- **Grow placement.** Up-left (r−2, c−2) is preferred; when that is blocked, (r, c−2).
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Exact pattern matching.** Tested this attempt.
- **Shots that open the barrier.** A block with its left column at 31 opens it, from row 21 and from row 29.
- **Shots that fail.** Column 29 (big), column 33 (big and small), and a shot fired straight into the barrier.

Assumptions the bound leans on, not fully tested:
- **`hopen`:** only column 31 opens the barrier. Columns 29 and 33 are tested; these are the only other block positions under the box.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; partial overlap was never tried. The planner found no route within 18 even if partial overlap did trigger it.
- **No other refunds:** the pad is the only refund source.

**3. Next attempt**

I have no route left to try. I would only test the partial-overlap pad trigger directly, and the planner already says it can't produce a win. Short of finding a mechanic I haven't seen at all, I expect the attempt to end on budget again.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 6":
- **Rule revised: grow.** The old model made a blocked grow a no-op, which was stricter than the game. It is now `growOuts`: (r−2, c−2) if it fits; else (r, c−2) if it fits; else any other fitting placement or staying small, which has never been observed and is left permissive.
- **Lean changes.** `toggleWith gp` replaces `toggle`. `step` and `winsWithin` now take the grow choice `gp`. A new hypothesis `hgp` says gp's result is in `growOuts`. `gpReal`, the observed rule, satisfies it (`gpReal_ok`).
- **Premise now tested.** Superset firing off is now backed by this attempt's experiment.
- **Unchanged:** the objects (block size, row, column; barrier open; pad used) and the other rules.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, small blocks only);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen` and the small-only pad trigger. It is looser on facing, on the row a shot is fired from, on when spell costs are charged, and on unobserved grow placements.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the grow rule and its definition changed.

**7. Checks on the proof**

a. `work/fit6.py` searched over every reading from all six attempts. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops or landed elsewhere |
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (28 rows) |
| Budget 18 | Every attempt: GAME_OVER on the first move past a full bar | the budget were larger |
| `hopen`, negative side | Attempt 1, transition 79 (column 29); attempt 5 (column 33, big and small) | another column opened it |
| Column 31 opens, any row | Attempt 3, transition 127; attempt 4, transition 154 | the row mattered |

The small-only pad trigger has no decisive experiment yet. The experiment is to grow into (31,23), partly overlapping the pad, and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. If the model is wrong anywhere, the likeliest place is a mechanic I have never seen.

VERDICT: impossible
CONFIDENCE: 70