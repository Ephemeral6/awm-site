## play 1

I didn't beat the game: it ended in GAME_OVER on level 4, after levels 1–3. I did not reset.

What this attempt established:

- **Refill pad (my model had this wrong):** the pad also refunds when a big block partly covers it after a grow. My model assumed only the small block could trigger it. A big block moving on to cover it fully had not triggered it in attempt 2.
- **Planner re-run:** with this corrected pad rule, the cheapest route from a fresh start is still 21 units. The budget is 18, so the correction doesn't open a winning route.
- **Barrier shot from the shifted row grid:** a big block shooting up from column 31 on this grid still opens the barrier. But it can't fit through the 4-row corridor to the exit, as predicted.
- **Blocked moves:** a move that's blocked still turns the block to face that direction, and still costs a unit.
- **Free clicks:** clicking the pad, the exit, the stalk or the floor does nothing and costs nothing.

The budget then ran out and the next move ended the game. Under every rule I've measured, level 4 still has no route within 18 units. The findings are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

Level 4 needs the column shot fired from a block whose left edge is at column 31, directly under the stalk. Getting a block there costs a shrink and a grow on top of the shot and the walk, and every route I had found came to more than the 18-unit budget. So I used this attempt to test the last thing my model hadn't checked: whether a big block can trigger the refill pad, the grey-blue pad that refunds 10 units.

- I moved the big block down-left to row 33, column 25, shrank it, then grew it. The grow placed it at row 31, column 23, half over the pad.
- The 10-unit refund fired. So a big block can trigger the pad, at least when it arrives by growing. My model had said only a small block could, which made it stricter than the game.
- I then moved the block to column 31, shot upward from row 27, and the barrier opened. But on that row grid the big block can't fit into the 4-row corridor, so the rest of the budget ran out and the game ended.

The failure is the same budget wall. The fix to the pad rule lowers the cheapest route by only one unit.

**2. Can the level be beaten?**

Under my rules, no, by a margin of one unit. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. This covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) is now 19, so the cheapest possible net cost is 19, which is more than 18.
- A separate planner that also requires facing up for the shot gives the same minimum, 19.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Spell rules.** Shrink keeps the top-left corner. Grow goes up-left (r−2, c−2) if that fits, else (r, c−2). Patterns must match the selected cells exactly.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Shots.** A block with its left column at 31 opens the barrier from any row. Columns 29 and 33, and a shot fired straight into the barrier, do not.

Assumptions the bound leans on:
- **`hopen`:** only column 31 opens the barrier. This is now supported by negative tests at columns 29 and 33.
- **One refund:** the pad refunds once, 10 units, and there is no other refund source.

The model is now looser than the game about the pad: it lets any overlap by any block trigger the refund, even full cover by a moving big block, which did not trigger in attempt 2.

The 19-unit route assumes the refund also fires when a grow lands a big block fully over the pad. That case has never been observed.

**3. Next attempt**

Run the 19-unit route and check its untested step:
1. Move left 3 times and down twice, to row 33, column 25.
2. Shrink, move down 1, grow. The block lands at row 33, column 23, fully covering the pad. Watch whether the refund fires.
3. Move right twice and up once, to row 29, column 31, facing up. Fire the shot.
4. Move right 6 times to the exit.

Under my rules this fails one unit short. It is the closest route I have, and walking it is the only way to expose a one-unit error in my cost accounting.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 7":
- **Rule revised: pad trigger.** It was "the first overlap by a small block". It is now "any overlap by a block of either size, after any action". In Lean, `onPad` no longer requires a small block.
- **Recomputed:** the value table; V(start) went from 20 to 19. The non-vacuity witness is now `witness_wins19`.
- **Blocked moves turn facing.** Recorded only, since facing is not in the model (which keeps it looser).
- **Unchanged:** objects, the grow outcome set, `hopen`, and exact pattern matching.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, once, any overlap);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`. It is looser on the pad trigger, on facing, on the row a shot is fired from, on when spell costs are charged, and on grow placements never observed.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins19' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins19`: the same model is winnable with a budget of 19.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the pad-trigger rule and its definition changed.

**7. Checks on the proof**

a. `work/fit7.py` searched over every reading from all seven attempts, including all three pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Pad: any block may trigger | Attempt 7: the bar dropped 46 → 16 rows | only small blocks triggered it |
| Refund subtracts 10 | Attempt 4: bar at 2 rows | the refund reset used to 8 (28 rows) |
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops |
| `hopen`, negative side | Attempt 1, column 29; attempt 5, column 33 (big and small) | another column opened it |
| Budget 18 | Every attempt: GAME_OVER on the first move past a full bar | the budget were larger |

The bound rests on `hopen`, the refund amount, and the budget, and none of these lacks a decisive experiment.

c. The proof goes through for budgets up to 18 and first fails at 19. The bound fails one unit above the measured budget. So the result is tight against my measurements, and any single missed one-unit saving would overturn it. If something is wrong, I would suspect a one-unit cost detail, such as how a completing click is charged when it also triggers the pad, rather than a structural rule.

VERDICT: impossible
CONFIDENCE: 55