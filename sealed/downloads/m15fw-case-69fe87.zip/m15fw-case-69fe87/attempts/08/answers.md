## play 1

I reached level 4 again and did not beat the game. It ended in GAME_OVER on level 4, after levels 1–3; I did not reset.

I played the cheapest route my model allows, which needs 19 units against a budget of 18. It had two untested steps, and each was a chance it could still work.

- **Refund on a full cover: it fires.** Growing the block so it fully covered the refill pad triggered the 10-unit refund (budget used went from 16 to 6).
- **Barrier:** from there I moved under the stalk, shot upward and opened the barrier as expected, then walked right toward the exit. At 18 units used I was one move short.
- **Win before game over: no.** The final move entered the exit and took usage to 19, and the game declared GAME_OVER rather than a win. So the budget check doesn't let you win on an over-budget move.

Every rule I have measured now holds, and under them the cheapest finish is 19 units, one more than level 4 allows. Something cheaper must exist, but I haven't found it.

The findings are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

I played the cheapest route my model allows. It costs 19 units net against a budget of 18, and it had two untested steps that could have made it work:
1. **Refund on full cover.** I moved the big block down-left, shrank it, stepped down once, and grew it back so it landed fully over the refill pad. The 10-unit refund fired.
2. **Barrier.** I moved the block under the stalk (left edge at column 31), faced up and fired the column shot. The barrier opened.
3. **Win versus game over.** I walked right toward the exit. At 18 units I was one move short. The final move entered the exit box, but it took usage to 19 and the game returned GAME_OVER instead of a win.

The level failed because the cheapest route I know is one unit over budget, and the game checks the budget before it checks for a win.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. The check covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) = 19, so the cheapest possible net cost is 19, which is more than 18.
- A step that would take usage past 18 fails, even when it reaches the exit. This attempt confirmed that on the final move.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Spell rules.** Shrink keeps the top-left corner. Grow goes up-left (r−2, c−2) if that fits, else (r, c−2). Patterns must match the selected cells exactly.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Pad.** It refunds 10 units once, on any overlap by a block, including a full cover after a grow.
- **Budget and ordering.** Budget 18, and the budget check comes before the win check.
- **Shots.** A block with its left column at 31 opens the barrier from any row. Columns 29 and 33, and a shot fired straight into the barrier, do not.

Assumptions not fully tested:
- **`hopen`:** only column 31 opens the barrier. Negative tests at columns 29 and 33 back it.
- **One refund:** there is no refund source other than the pad.

The model is looser than the game on facing (blocked moves turn the block for 1 unit), and on when spell costs are charged.

The specific untested mechanism I can name: something that refunds or saves a single unit, for example a cheaper way to complete a pattern. I have no candidate left that the planner says would close the gap.

**3. Next attempt**

I have no route to defend. I would replay the 19-unit route only to look for a one-unit discrepancy in the budget bar's readings. Otherwise I would stop rather than spend the budget.

**4. Formal system**

No definition changed; `work/MODEL.md` records the attempt-8 results.
- **Objects:** block (size, row, column), barrier open or not, pad used or not.
- **Rules:** moves, toggle with `growOuts`, pad refund on any overlap, the column-31 shot, free clicks, the goal, and budgeted runs where any step over budget fails.
- **Lean status:** `lean/M15L4Map.lean` is as amended after attempt 7.

**5. Proof** (`lean/M15L4Map.lean`, unchanged since attempt 7; output from the last compile)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, once, any overlap);
- spell costs 5 and 4;
- the goal condition;
- the budget check coming before the win check.

Where the model is stricter than the game: only through `hopen`. It is looser everywhere else listed above.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins19' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: this attempt confirmed two things the model already encoded and contradicted nothing. A grow that lands a big block fully over the pad triggers the refund, which the any-overlap `onPad` already allowed. A move that reaches the exit while taking usage past 18 is GAME_OVER, which `winsWithin` already handles by failing any step with u + cost > B before looking at the next state. For the model to change, the full-cover refund would have had to not fire, or the over-budget move into the exit would have had to win.

**7. Checks on the proof**

a. `work/fit8.py` searched over every reading from all eight attempts, including all four pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget check before win check | Attempt 8, transition 254: GAME_OVER on the move into the exit | a win were checked first |
| Full-cover refund | Attempt 8, transition 242: bar 20 rows | full cover did not trigger (56 rows) |
| Any block may trigger the pad | Attempt 7, transition 214 | only small blocks triggered it |
| Refund subtracts 10 | Attempt 4, transition 142 | the refund reset used to 8 |
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops |
| `hopen`, negative side | Attempt 1, column 29; attempt 5, column 33 (big and small) | another column opened it |
| Column 31 opens, any row | Attempts 3 and 4 | the row mattered |

None of the load-bearing rules lacks a decisive experiment.

c. The proof goes through for budgets up to 18 and first fails at 19 (from the attempt-7 build; the model is unchanged since). The bound fails one unit above the measured budget, so the result is tight against my measurements. It is not evidence of a model much stricter than the game; if it is wrong, the error is a one-unit cost detail or a mechanic I have never seen.

VERDICT: impossible
CONFIDENCE: 60