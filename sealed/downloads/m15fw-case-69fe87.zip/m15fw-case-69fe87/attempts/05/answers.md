## play 1

The game has ended: GAME_OVER on level 4, with levels 1–3 beaten. I did not beat the game and did not reset.

Going in, my established rules said level 4 cannot be finished within its 18-unit budget: the cheapest route costs at least 20. So I used this attempt to test the rules that conclusion rests on:

- **Card panel:** clicking a card is free and only shows that card's pattern on the grid; it doesn't select anything or make spells cheaper.
- **Shots from column 33:** a column shot from a big block whose left edge is at column 33, under the switch box's edge, did not open the barrier. A small block at column 33 failed too. That matches the rule that only column 31, directly under the stalk, opens it.

Before acting, I also checked in the planner whether placing the grown block elsewhere when its usual spot is blocked could help. It doesn't change the minimum cost.

I then spent the last units and the next move ended the game. The impossibility result still stands; the findings are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

My rules already said level 4 can't be finished within its 18-unit budget, so I spent this attempt testing the rules that conclusion rests on.
- **Card panel:** clicking a card is free. It only redraws that card's pattern as holes in the grid; it selects nothing and makes no spell cheaper.
- **Shots from column 33:** I shot up from a big block with its left edge at column 33, under the switch box's edge. The barrier stayed closed. I then shrank in place and shot from a small block at column 33; the barrier stayed closed again.
- The budget then ran out and the next move ended the game.

The underlying cause is unchanged. The only way to open the barrier is a shot from column 31, directly under the stalk. Getting a big block there needs a shrink and a grow (10 units), and the shot (4) plus the walk to the exit pushes every route past 18, even with the refill pad's 10-unit refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right, up and down.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Shots that open the barrier.** A block with its left column at 31 opens it, from row 21 and from row 29.
- **Shots that fail.** Column 29 (big, attempt 1). Column 33 (big and small, this attempt). A shot fired straight into the barrier (attempt 2).

Assumptions the bound leans on, not fully tested:
- **`hopen`:** no column other than 31 opens the barrier. Columns 29 and 33 are tested; no other column lies under the box.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; a partial overlap by a big block was never tried.
- **No other refunds:** the pad is the only refund source.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

**3. Next attempt**

I have no route to play. The one remaining specific test is whether a big block partly overlapping the pad triggers the refund. The test needs a big block on the shifted position grid: move it to (33,25) (5 moves), shrink, then grow back. Growing lands it at (31,23), partly over the pad. That costs 15 units, then I watch the bar. Even if it does trigger, my model says that alone does not make the level winnable.

**4. Formal system**

No definition changed; `work/MODEL.md` records the attempt-5 results.
- **Objects:** block (size, row, column), barrier open or not, pad used or not.
- **Rules:** moves, the diamond toggle with its placement, the pad refund, the column-31 shot, free clicks, and the goal.
- **Lean status:** `lean/M15L4Map.lean` is unchanged since attempt 3. `hopen` and superset firing (off) remain explicit premises.

**5. Proof** (`lean/M15L4Map.lean`, unchanged; output from the last compile)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win.

It leans on the map, moves, the toggle and its placement, the pad refund (subtract 10, small blocks only), spell costs 5 and 4, and the goal condition.

The model is stricter than the game only through `hopen`, the small-only pad trigger, and superset firing being off. It is looser on facing, on the row a shot is fired from, and on when spell costs are charged.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: the two column-33 shots both failed, which is exactly what `hopen` already says, and the card clicks behaved as the existing free action. No rule or definition needed changing. For the model to change, a shot from a column other than 31 would have had to open the barrier, or a card click would have had to cost budget or select cells.

**7. Checks on the proof**

a. `work/fit5.py` searched over every reading from all five attempts. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 | Each attempt's GAME_OVER on the first move past a full bar (last: attempt 5) | the budget were larger |
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (28 rows) |
| `hopen`, negative side | Attempt 1, transition 79 (column 29); attempt 5 (column 33, big and small) | another column opened it |
| Column 31 opens, any row | Attempt 3, transition 127; attempt 4, transition 154 | the row mattered |
| Grow placement | Attempt 3, transition 124 (facing up); attempt 4, transition 148 (facing down) | placement depended on facing |

The small-only pad trigger has no decisive experiment yet. The experiment is the partial-overlap test described in section 3.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18 (from the attempt-3 build; the model is unchanged since). The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. If something is wrong, the likeliest suspect is the small-only pad trigger.

VERDICT: impossible
CONFIDENCE: 65