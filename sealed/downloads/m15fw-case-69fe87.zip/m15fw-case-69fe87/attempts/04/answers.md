## play 1

The game has ended: GAME_OVER on level 4, with levels 1–3 beaten. I did not beat the game and did not reset.

My model predicted no route fits level 4's 18-unit budget. So this attempt walked the cheapest route it found (net cost 21) to test two open rules along the way:

- **Refill pad:** stepping onto it subtracts 10 units from the budget used. It does not reset it to 8: the bar dropped to 2 rows, where a reset to 8 would have shown 28.
- **Opening shot:** a big block whose left column is 31 opens the barrier when it shoots up from row 29 as well. Firing up from row 21 opened it last attempt, so the shot's starting row doesn't matter.

The route then ran out of budget 3 moves short of the exit, which is where the model said it would run out. Every rule I have measured now holds, and under those rules level 4 cannot be finished within 18 units. Whatever mechanic would make it winnable is one I still haven't found.

Notes are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

My model said no route fits the 18-unit budget, so I walked the cheapest route it knew (net cost 21) to test two open questions on the way:
1. I moved the big block down-left, shrank it, and stepped the small block onto the refill pad. Budget used went from 11 to 1: the pad subtracts 10. The alternative reading, "reset used to 8", would have left the bar at 28 rows instead of 2.
2. I grew the block back so that its left edge sat at column 31, under the stalk, then moved it up to row 29 and fired the column shot upward. The barrier opened.
3. The budget then ran out 3 moves short of the exit, which is what the model predicted.

The cause of failure is the same as before. Opening the barrier needs a shrink-and-grow shift (10 units) plus the shot (4 units), and the exit is still 6 or more moves away afterwards. The pad's refund doesn't pay for its detour.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right, up and down.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **The opening shot.** A block with its left column at 31 opens the barrier from row 21 and from row 29.
- **Negative results.** A big block at column 29 cannot open it (attempt 1), and a shot into the barrier itself does nothing (attempt 2).

Assumptions the bound leans on, not tested:
- **`hopen`:** no shot from any other column opens the barrier.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; a partial overlap by a big block was never tried.
- **No other refunds:** the pad is the only refund source.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

**3. Next attempt**

I don't see an affordable route. I would spend the budget on the specific untested mechanisms that could cut cost, rather than replaying the known route:
- whether a big block that partly overlaps the pad triggers the refund (reachable only on the shifted position grid);
- whether a blocked move also turns the block's facing.

If neither changes anything, I will stop.

**4. Formal system**

No definition changed this attempt. The two observations confirmed choices the model had already made: refund as "subtract 10", and the shot allowed from any row at column 31. `work/MODEL.md` records this. Objects, rules and the Lean definitions in `lean/M15L4Map.lean` are as amended after attempt 3.

**5. Proof** (`lean/M15L4Map.lean`, unchanged; recompiled)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- the diamond toggle and its placement;
- the pad refund (subtract 10, small blocks only);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`, the pad trigger being small-only, and superset firing being off. It is looser on facing and on when spell costs are charged.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: this attempt measured the refund form ("subtract 10" confirmed, "reset to 8" refuted) and confirmed that the shot works from row 29, but the Lean model already used both, so no rule or definition changed. For the model to change, a measurement would have had to contradict one of its definitions, for example the refund resetting used to 8, or the row-29 shot failing.

**7. Checks on the proof**

a. `work/fit4.py` searched over every reading from all four attempts, including both pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each segment's budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (bar at 28 rows) |
| Budget 18 | Attempt 4, transitions 157–158: full bar still NOT_FINISHED, next move GAME_OVER | the budget were larger |
| Col-31 opens, any row | Attempt 3, transition 127 (row 21) and attempt 4, transition 154 (row 29) | the row mattered |
| Grow placement | Attempt 3, transition 124 (facing up) and attempt 4, transition 148 (facing down) | placement depended on facing |
| Column 29 fails | Attempt 1, transition 79 | |
| Barrier can't be shot | Attempt 2, transition 93 | |

The small-only pad trigger has no decisive experiment yet. Only a full cover by a big block was tried (attempt 2, transition 98). The experiment to run: partly overlap the pad with a big block on the shifted position grid and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. Still, the level was presumably built to be winnable, so I suspect `hopen` or the small-only pad trigger is the rule that's wrong.

VERDICT: impossible
CONFIDENCE: 60