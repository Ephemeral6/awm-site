## play 1

The game has now ended: GAME_OVER on level 4, after clearing levels 1–3. I did not beat the game and did not call reset.

The last two actions of this attempt:
- **Free click at a full bar:** with the budget bar full, a click on the card panel was accepted and the game stayed NOT_FINISHED, so clicks off the grid cost nothing even at the limit.
- **Normal move:** the next move, which costs 1 unit, took the budget past 18 and the game ended, as predicted.

Earlier in this attempt I found three things:
- A shot fired straight into the barrier does not open it.
- The grey-blue (colour e) pad gives back about 10 budget units when the small block steps onto it.
- The diamond spell toggles the block between big and small.

Even with these, my planner's cheapest win for level 4 costs at least 24 units against a budget of 18. Some mechanic is still missing from my model. All findings are in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

Level 4 restarted with a fresh budget of 18 units. I tested the one thing that could have broken last attempt's argument: I fired the shot spell straight at the d barrier from one cell away. The shot crossed the floor, hit the barrier and vanished, and the barrier stayed.

With what remained I found two new mechanics:
- **Refill pad.** The grey-blue 2×2 pad (colour e) refunds about 10 units, once, when a *small* block steps onto it. A big block covering it did not trigger it.
- **Diamond toggles size.** Cast on a small block, the diamond grows it back to big, with the small block becoming the big block's bottom-right corner. Shrinking always keeps the top-left corner. Together these let you shift which grid of positions the big block sits on.

The budget then ran out and the next paid move ended the game. The attempt failed because I still have no affordable way to open the barrier. Every route that fits my observations costs more than the budget plus the refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no sequence of actions on level 4 reaches the exit while the budget used stays at or below 18.

The argument:
- I modelled the real map (walls, rows and columns on the odd position grid), moves, the diamond toggle with its placement rules, the one-time pad refund, and spell costs of 5 (shrink/grow) and 4 (shot).
- The shot is allowed to open the barrier whenever the block's left column is 31, at any size and any row, ignoring facing. Every observation supports at most this, so this is generous.
- The cheapest win in that model costs 20 net units, which is more than 18.

Established parts:
- Movement and the step sizes.
- Spell costs and the budget of 18 (two cost fits survive and agree here; see 7a).
- The shrink and grow placement.
- The pad refund.
- Two decisive negatives: a big block at column 29 cannot open the barrier, and a shot into the barrier itself does nothing.

Assumptions I did not check:
- **Exact pattern matching.** A single click that completes two patterns at once is never fired. This is the most dangerous one: a combined grow-and-shoot would save 3 units, and 21 − 3 = 18 is exactly the budget.
- **Positive shot condition.** That a block whose left column is 31 can open the barrier at all, from any row. The bound only needs the negative half.
- **Pad.** That only a small block triggers it, and that it gives at most 10 units.

**3. Next attempt**

The cheapest experiment that could change the verdict is the superset-firing test:
1. Select (0,1), (1,0), (1,2) and (1,1).
2. Click (2,1) last, completing both the diamond and the column at once.

Run on the opening state, that costs 6 units. If both spells fire, I would build the 18-unit route around it. If neither fires, the impossibility result stands, and I would stop and report rather than spend the budget.

**4. Formal system (amended, not rewritten)**

`lean/M15L4.lean` is kept unchanged as attempt 1's column-only model. It is now known to be too loose: its "only a small block at x=5 can shoot" premise was an assumption, and it has no rows. `work/MODEL.md` records the amendments, and the new row-aware model is `lean/M15L4Map.lean`.

- **Objects.** Block (size, top-left row and column), barrier open or not, pad used or not. The grid selection count was dropped: spells are atomic actions costing 5 and 4. That changes no total cost and charges it later, so it is looser.
- **Rules as functions.** Moves (blocked unless every target cell is floor; the barrier counts as floor once opened). The diamond toggle. The pad refund. The shot, which may set "barrier open" if the left column is 31. A no-cost free action. Superset firing as a parameter. The goal: barrier open and the block overlapping the exit box.
- **Simplification.** Dropped facing (looser), the cell identities in the grid, and the selection count.
- **Lean status.**
  - Definitions: everything listed above.
  - Consequences: `checkAll_true`, `edge`, `goal_le`, `step_mem`, `inv`, `L4_unwinnable`.
  - Explicit hypotheses: `hopen`, and superset firing fixed to false.
  - Not in the model: facing, a big block triggering the pad, and any spell other than the two shown on the level-4 cards.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off, every action list fails to win within budget 18. The budget is checked after the refund, which is the generous choice.

How it is proved:
- A Bellman potential V over all 798 valid states, computed in Python.
- The kernel checks that V(s) ≤ net cost + V(s′) on every edge and every allowed shot outcome, and that V ≤ 0 at the goal. This uses `decide +kernel`, not `native_decide`.
- V(start) = 20, and "used + V(state)" can never decrease, so no goal state is reachable with used ≤ 18.

It leans on these rules: moves and walls, the diamond toggle placement, the pad refund (subtract 10), spell costs 5 and 4, and the goal condition. The Lean model is looser than the game on facing, rows for the shot, and macro charging. It is stricter only through `hopen` and superset firing off, and both are stated.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20, so the bound is tight.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice, so `hopen` is a real constraint.

**6.** Not applicable: the formal system changed (diamond toggle, pad and refund, rows and walls, a looser `hopen`).

**7. Checks on the proof**

a. `work/fit2.py` searched over every reading from both attempts: display granularity, rounding, completing-click cost, whether the first post-reset action counts, each segment's budget, and the refund as "subtract R" or "set to R". Two combinations survive. Both use 2-row floor display, ordinary cost 1, completing click 2, first action free, and level-4 budget 18. They differ only in the refund: subtract 10, or set used to 8. The theorem uses subtract 10, which is at least as generous whenever used ≤ 18. So no conclusion changes between them.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 and costs | Attempt 1, transitions 85–86; attempt 2, transitions 111–113: full bar still NOT_FINISHED, next paid action GAME_OVER | the fit were wrong |
| A big block at column 29 can't open the barrier | Attempt 1, transition 79 frames: the shot dies at its first step | |
| A shot into the barrier doesn't open it | Attempt 2, transition 93 | |
| Toggle and grow placement | Attempt 2, transition 107 | grow were not the reverse of shrink |
| Shrink keeps top-left for every facing | Attempt 2, transition 111 (facing right) | it depended on facing |
| Pad refund | Attempt 2, transition 103: bar 60 → 28 rows | |
| Exact pattern matching | No decisive experiment yet | |

For exact matching, the experiment to run is the 5-cell grid draw described in section 3.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. A bound that survives only one unit above the measured budget is not evidence of a model much stricter than the game. But the level was presumably built to fit its budget, so the one-to-two-unit gap still points at the untested exact-matching rule.

VERDICT: impossible
CONFIDENCE: 45

## pushes 1

The game has now ended: GAME_OVER on level 4, after clearing levels 1–3. I did not beat the game and did not call reset.

The last two actions of this attempt:
- **Free click at a full bar:** with the budget bar full, a click on the card panel was accepted and the game stayed NOT_FINISHED, so clicks off the grid cost nothing even at the limit.
- **Normal move:** the next move, which costs 1 unit, took the budget past 18 and the game ended, as predicted.

Earlier in this attempt I found three things:
- A shot fired straight into the barrier does not open it.
- The grey-blue (colour e) pad gives back about 10 budget units when the small block steps onto it.
- The diamond spell toggles the block between big and small.

Even with these, my planner's cheapest win for level 4 costs at least 24 units against a budget of 18. Some mechanic is still missing from my model. All findings are in `work/NOTES.md`.