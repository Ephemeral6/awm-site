## play 1

I reached level 4 again and did not beat the game: it ended in GAME_OVER on level 4, with levels 1–3 cleared. I did not reset.

This attempt confirmed how the barrier opens:
- **Moving to the right column:** a shrink followed by a grow shifts the big block 2 cells up and left. Grow places the old small block at the new big block's bottom-right corner when facing up too, as predicted. That put the big block with its left column at 31, under the stalk, facing up.
- **The shot:** fired from there, it climbed the stalk, destroyed the switch box (which turned into floor) and removed the d barrier. This confirms the rule my proof assumed but had never tested positively.
- **Cost:** that route uses 16 of the 18 units, and the exit is still 8 moves away, so it needs 24 units.

Two free probes found nothing new: clicking the block itself does nothing, and the service rejects ACTION5. With the budget full, my last move ended the game as predicted.

Under every rule I have now confirmed, the cheapest route through level 4 costs more than 18 units, even counting the refill pad. Some cheaper mechanic is still unknown to me.

Everything is recorded in `work/NOTES.md`.

## probe 1

**1. What happened on level 4**

Level 4 restarted with its usual 18-unit budget. I did what my model said should open the barrier:
1. Moved left, shrank the block, moved the small block up, and grew it back. Shrink keeps the top-left corner and grow puts the small block at the new big block's bottom-right, so this shifted the big block 2 cells up and left. It ended with its left edge at column 31, directly under the stalk, facing up.
2. Cast the column shot. It climbed the stalk, destroyed the switch box (which turned into floor), and removed the d barrier.

That confirmed the opening rule for the first time, but it had used 16 of the 18 units. The exit is still 8 moves away (2 down, 6 right), so the budget ran out and the game ended.

The failure is the cost: the only opening I have found costs about 24 units in total.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with total net cost at most 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right and facing up.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund is 10 (two cost fits survive, see 7a).
- **The shot.** It opens the barrier from a block whose left column is 31; this attempt confirmed the positive side.
- **Negative results.** A big block at column 29 cannot open the barrier (attempt 1), and a shot into the barrier itself does nothing (attempt 2).

Assumptions the bound leans on, not fully tested:
- **`hopen`:** no shot from any other column opens the barrier.
- **Pad trigger:** only a small block triggers the refund pad. A big block covering it did not trigger it in attempt 2, but a partial overlap by a big block was never tried.
- **No other refunds:** the refund is at most 10 and there are no other refund sources.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

The model is looser than the game on facing, the row from which the shot may be fired, and when spell costs are charged.

**3. Next attempt**

I don't see an affordable route. I would spend the budget on the cheapest untested mechanism that could change the answer:
- whether a big block partly overlapping the pad triggers the refund (about 6 units: down, left, left, left);
- otherwise, whether the refund grows if the pad is taken later.

If neither shows anything, I will stop.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 3":
- **Floor:** once the barrier is open, the switch-box area (rows 5–8, cols 30–33) counts as floor in `floorCell`. Valid rows now run 5–35, giving 802 valid states. V(start) is still 20.
- **Grow placement:** now observed for facing up as well as right; no definition changed.
- **`hopen`:** still an explicit hypothesis. Only its negative side ("no other column opens it") is used by the proof.

Nothing else changed: objects (block size, row, column; barrier open; pad used), the rules, the macro spells, and the superset-off parameter.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win. The budget is checked after the pad refund, which is the generous choice.

It leans on these rules:
- the map with walls and the opened box as floor;
- moves;
- the diamond toggle and its placement;
- the pad refund of 10, small blocks only;
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`, the pad trigger being small-only, and superset firing being off. Everywhere else it is looser.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the floor definition changed.

**7. Checks on the proof**

a. `work/fit3.py` searched over every reading from all three attempts: display granularity, rounding, completing-click cost, whether the first action counts, each segment's budget, and the refund as "subtract R" or "set to R". Two combinations survive. Both use 2-row floor display, ordinary cost 1, completing click 2, first action free, and level-4 budget 18 in every attempt. They differ only in the refund: subtract 10, or set used to 8. The theorem uses subtract 10, which is at least as generous whenever used ≤ 18, so no conclusion changes between them.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 | Attempt 3, transitions 130–131: full bar still NOT_FINISHED, next move GAME_OVER | the budget were larger |
| Grow placement | Attempt 3, transition 124: big block lands at (21,31) | grow placement depended on facing |
| Col-31 positive | Attempt 3, transition 127: barrier opened | |
| Other columns fail | Attempt 1, transition 79 (column 29) | |
| Barrier can't be shot | Attempt 2, transition 93 | |
| Pad refund 10 | Attempt 2, transition 103 | |
| Pad needs a small block | Attempt 2, transition 98: full cover by a big block, no refund | |

Partial overlap of the pad by a big block was never tried. The experiment is: move the big block down, left, left, left so it partly covers the pad, and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model that is much stricter than the game. The two-unit gap still means a cheaper mechanic probably exists. My suspects are the pad-trigger rule and the "only column 31 opens" rule.

VERDICT: impossible
CONFIDENCE: 55