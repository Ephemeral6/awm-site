## Attempt 1

**1. What happened on level 4**

Level 4 shows two spell cards: a diamond that shrinks the block, and a vertical column that fires a shot. A d-coloured barrier blocks the only corridor to the exit, and a small 6-bordered switch box sits at the top of a narrow stalk. On level 3, firing the column spell up the stalk at the same kind of box removed both the box and the barrier.

On level 4 I copied that set-up exactly: 4×4 block directly under the stalk, facing up. I cast it twice and nothing happened. When I captured the animation frames, the shot appeared one step ahead of the block and vanished immediately.

A third cast, fired sideways across open floor, showed how the shot behaves: it is the size of the block, travels 2 cells per frame, and dies when its leading edge reaches a wall. Each completing click costs double, so these casts used up the budget. Taking one action past a full budget bar gave GAME_OVER.

The failure was mine: I repeated a manoeuvre that had worked without understanding why it worked, on a level where the budget is only 18 units.

**2. Can the level be beaten?**

Under my rules, no. Claim: with a budget of 18 units, no sequence of actions reaches the exit.

The argument:
- The barrier opens only when a shot reaches the switch box (premise **H**).
- A 4×4 block cannot get such a shot through.
  - At the one position touching the stalk, x=4, it failed twice (transitions 76 and 79).
  - At every other column, the shot's leading edge would start on background, and transition 83 shows that kills it.
- So the block must first shrink to 2×2, then shoot from x=5 (col 31), the stalk column. That needs at least:
  - 4 clicks to shrink, 5 units;
  - 3 clicks to shoot, 4 units;
  - 13 moves right afterwards, from col 31 to the exit at col 57.
- Even letting one click fire both spells together, the cost is at least 21 units, which is more than 18.

Established parts:
- Movement and step sizes.
- Clicks select and deselect cells.
- Only the spells shown on the level's cards fire (transition 54).
- The cost model (a unique fit).
- The 4×4 shot failure at x=4.

Assumptions I did not check:
- **H** itself, in particular that a shot travelling into the d barrier from a distance does not destroy it. That case was never tested.
- What the grey-blue 2×2 pad on the level-4 room floor (colour e) does.

**3. Next attempt**

The first and cheapest experiment, at about 7 units:
1. From the start, move left, then down, then right, so the 4×4 block sits at rows 29–32, cols 37–40, facing right with one cell of floor before the barrier.
2. Cast the column spell.

If the barrier goes, move right 5 times to the exit, about 12 units in total. If it does not, I have learned that within budget and stop probing. I will not repeat a cast whose outcome I already know.

**4. Formal system** (`work/MODEL.md`, `lean/M15L4.lean`)

This is the first formal system, so there was nothing to amend.

- **Objects:**
  - Block: size (big/small) and column x = (col−21)/2.
  - Barrier: opened or closed.
  - Grid: number of selected cells.
  - Rows, facing and walls are dropped; this only adds possible moves, so the model is looser than the game.
- **Rules:**
  - Move: x changes by ±2 (big) or ±1 (small), cost 1.
  - Select / deselect: cost 1.
  - Completing click: cost 2. It clears the grid and then either shrinks the block or fires the shot, which sets opened if the shot opens the barrier.
  - Clicks on world objects or on the cards: cost 0.
  - Goal: opened, and the block reaches the exit column.
- **Lean status:**
  - Definitions: `St`, `Act`, `cost`, `step`, `goal`, `start`, `L4budget = 18`.
  - Consequences: `hstep`, `pot_le_cost`, `L4_unwinnable`.
  - Premise **H** is an explicit hypothesis, `hopen`, not part of any definition.
  - Not in the model: the e pad, a shot destroying the barrier directly, rows and facing.

**5. Proof**

File: `lean/M15L4.lean`. It compiles, and the axiom output is:
```
'M15L4.hstep' depends on axioms: [propext, Quot.sound]
'M15L4.pot_le_cost' depends on axioms: [propext, Quot.sound]
'M15L4.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4.witness_wins' does not depend on any axioms
'M15L4.cheap_wins' does not depend on any axioms
```
- `L4_unwinnable` says: for every opening function satisfying `hopen` ("only a small block at x=5 opens the barrier"), every action list costing at most `L4budget` never reaches the goal.
- It rests on the move, click, completing-click, cost and goal rules above.
- Two checks show the bound is not empty:
  - `witness_wins`: the model can be won with 24 units.
  - `cheap_wins`: if a big block could open the barrier, a 12-unit win fits inside 18.
- Where the Lean model is stricter than the game: `hopen` excludes a shot from any other position, and the e pad is left out. Everywhere else it is looser.

**6.** Not applicable. The formal system is new from this attempt.

**7. Checks on the proof**

a. I searched display granularity (1 or 2 rows), rounding (floor, round, ceil), completing-click cost from 1 to 10 in quarter steps, whether the first action after reset is counted, and each level's total from 8 to 80. The bar never went down, so refunds are 0.

One combination survives:
- 2-row display, floor rounding;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- level budgets: level 1 is 50 or 50.25, level 2 is 25 to 25.5, level 3 is 50, level 4 is 18.

The level-4 conclusions are the same across the surviving variants.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation (attempt 1) | Would differ if… |
|---|---|---|
| Cost and budget = 18 | Transitions 85–86: bar full and still NOT_FINISHED, then GAME_OVER on the next action | the fit were wrong |
| Big shot at x=4 fails | Transition 79 frames: shot dies at the first step | the shot could pass there |
| Only shown cards fire | Transition 54: diamond drawn on level 3 with no effect | other spells were enabled |
| Shrink keeps top-left, then step 2 | Transitions 17–18 | the shrunk block sat elsewhere |

There is no decisive experiment yet for "a shot into the barrier does not open it", or for big shots from other columns. The experiment to run is the cast described in section 3.

c. The proof goes through for budgets up to 20 and first fails at 21. That margin is small, but the measured budget of 18 sits below my model's minimum cost of 21 or more. A level designed to fit its budget implies the model is stricter than the game. The rule I suspect is `hopen`: most likely a shot travelling into the d barrier opens it directly.

VERDICT: impossible
CONFIDENCE: 30

## Attempt 2

**1. What happened on level 4**

Level 4 restarted with a fresh budget of 18 units. I tested the one thing that could have broken last attempt's argument: I fired the shot spell straight at the d barrier from one cell away. The shot crossed the floor, hit the barrier and vanished, and the barrier stayed.

With what remained I found two new mechanics:
- **Refill pad.** The grey-blue 2×2 pad (colour e) refunds about 10 units, once, when a *small* block steps onto it. A big block covering it did not trigger it.
- **Diamond toggles size.** Cast on a small block, the diamond grows it back to big, with the small block becoming the big block's bottom-right corner. Shrinking always keeps the top-left corner. Together these let you shift which grid of positions the big block sits on.

The budget then ran out and the next paid move ended the game. The attempt failed because I still have no affordable way to open the barrier. Every route that fits my observations costs more than the budget plus the refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no sequence of actions on level 4 reaches the exit while the budget used stays at or below 18.

The argument:
- I modelled the real map (walls, rows and columns on the odd position grid), moves, the diamond toggle with its placement rules, the one-time pad refund, and spell costs of 5 (shrink/grow) and 4 (shot).
- The shot is allowed to open the barrier whenever the block's left column is 31, at any size and any row, ignoring facing. Every observation supports at most this, so this is generous.
- The cheapest win in that model costs 20 net units, which is more than 18.

Established parts:
- Movement and the step sizes.
- Spell costs and the budget of 18 (two cost fits survive and agree here; see 7a).
- The shrink and grow placement.
- The pad refund.
- Two decisive negatives: a big block at column 29 cannot open the barrier, and a shot into the barrier itself does nothing.

Assumptions I did not check:
- **Exact pattern matching.** A single click that completes two patterns at once is never fired. This is the most dangerous one: a combined grow-and-shoot would save 3 units, and 21 − 3 = 18 is exactly the budget.
- **Positive shot condition.** That a block whose left column is 31 can open the barrier at all, from any row. The bound only needs the negative half.
- **Pad.** That only a small block triggers it, and that it gives at most 10 units.

**3. Next attempt**

The cheapest experiment that could change the verdict is the superset-firing test:
1. Select (0,1), (1,0), (1,2) and (1,1).
2. Click (2,1) last, completing both the diamond and the column at once.

Run on the opening state, that costs 6 units. If both spells fire, I would build the 18-unit route around it. If neither fires, the impossibility result stands, and I would stop and report rather than spend the budget.

**4. Formal system (amended, not rewritten)**

`lean/M15L4.lean` is kept unchanged as attempt 1's column-only model. It is now known to be too loose: its "only a small block at x=5 can shoot" premise was an assumption, and it has no rows. `work/MODEL.md` records the amendments, and the new row-aware model is `lean/M15L4Map.lean`.

- **Objects.** Block (size, top-left row and column), barrier open or not, pad used or not. The grid selection count was dropped: spells are atomic actions costing 5 and 4. That changes no total cost and charges it later, so it is looser.
- **Rules as functions.** Moves (blocked unless every target cell is floor; the barrier counts as floor once opened). The diamond toggle. The pad refund. The shot, which may set "barrier open" if the left column is 31. A no-cost free action. Superset firing as a parameter. The goal: barrier open and the block overlapping the exit box.
- **Simplification.** Dropped facing (looser), the cell identities in the grid, and the selection count.
- **Lean status.**
  - Definitions: everything listed above.
  - Consequences: `checkAll_true`, `edge`, `goal_le`, `step_mem`, `inv`, `L4_unwinnable`.
  - Explicit hypotheses: `hopen`, and superset firing fixed to false.
  - Not in the model: facing, a big block triggering the pad, and any spell other than the two shown on the level-4 cards.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off, every action list fails to win within budget 18. The budget is checked after the refund, which is the generous choice.

How it is proved:
- A Bellman potential V over all 798 valid states, computed in Python.
- The kernel checks that V(s) ≤ net cost + V(s′) on every edge and every allowed shot outcome, and that V ≤ 0 at the goal. This uses `decide +kernel`, not `native_decide`.
- V(start) = 20, and "used + V(state)" can never decrease, so no goal state is reachable with used ≤ 18.

It leans on these rules: moves and walls, the diamond toggle placement, the pad refund (subtract 10), spell costs 5 and 4, and the goal condition. The Lean model is looser than the game on facing, rows for the shot, and macro charging. It is stricter only through `hopen` and superset firing off, and both are stated.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20, so the bound is tight.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice, so `hopen` is a real constraint.

**6.** Not applicable: the formal system changed (diamond toggle, pad and refund, rows and walls, a looser `hopen`).

**7. Checks on the proof**

a. `work/fit2.py` searched over every reading from both attempts: display granularity, rounding, completing-click cost, whether the first post-reset action counts, each segment's budget, and the refund as "subtract R" or "set to R". Two combinations survive. Both use 2-row floor display, ordinary cost 1, completing click 2, first action free, and level-4 budget 18. They differ only in the refund: subtract 10, or set used to 8. The theorem uses subtract 10, which is at least as generous whenever used ≤ 18. So no conclusion changes between them.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 and costs | Attempt 1, transitions 85–86; attempt 2, transitions 111–113: full bar still NOT_FINISHED, next paid action GAME_OVER | the fit were wrong |
| A big block at column 29 can't open the barrier | Attempt 1, transition 79 frames: the shot dies at its first step | |
| A shot into the barrier doesn't open it | Attempt 2, transition 93 | |
| Toggle and grow placement | Attempt 2, transition 107 | grow were not the reverse of shrink |
| Shrink keeps top-left for every facing | Attempt 2, transition 111 (facing right) | it depended on facing |
| Pad refund | Attempt 2, transition 103: bar 60 → 28 rows | |
| Exact pattern matching | No decisive experiment yet | |

For exact matching, the experiment to run is the 5-cell grid draw described in section 3.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. A bound that survives only one unit above the measured budget is not evidence of a model much stricter than the game. But the level was presumably built to fit its budget, so the one-to-two-unit gap still points at the untested exact-matching rule.

VERDICT: impossible
CONFIDENCE: 45

## Attempt 3

**1. What happened on level 4**

Level 4 restarted with its usual 18-unit budget. I did what my model said should open the barrier:
1. Moved left, shrank the block, moved the small block up, and grew it back. Shrink keeps the top-left corner and grow puts the small block at the new big block's bottom-right, so this shifted the big block 2 cells up and left. It ended with its left edge at column 31, directly under the stalk, facing up.
2. Cast the column shot. It climbed the stalk, destroyed the switch box (which turned into floor), and removed the d barrier.

That confirmed the opening rule for the first time, but it had used 16 of the 18 units. The exit is still 8 moves away (2 down, 6 right), so the budget ran out and the game ended.

The failure is the cost: the only opening I have found costs about 24 units in total.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with total net cost at most 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right and facing up.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund is 10 (two cost fits survive, see 7a).
- **The shot.** It opens the barrier from a block whose left column is 31; this attempt confirmed the positive side.
- **Negative results.** A big block at column 29 cannot open the barrier (attempt 1), and a shot into the barrier itself does nothing (attempt 2).

Assumptions the bound leans on, not fully tested:
- **`hopen`:** no shot from any other column opens the barrier.
- **Pad trigger:** only a small block triggers the refund pad. A big block covering it did not trigger it in attempt 2, but a partial overlap by a big block was never tried.
- **No other refunds:** the refund is at most 10 and there are no other refund sources.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

The model is looser than the game on facing, the row from which the shot may be fired, and when spell costs are charged.

**3. Next attempt**

I don't see an affordable route. I would spend the budget on the cheapest untested mechanism that could change the answer:
- whether a big block partly overlapping the pad triggers the refund (about 6 units: down, left, left, left);
- otherwise, whether the refund grows if the pad is taken later.

If neither shows anything, I will stop.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 3":
- **Floor:** once the barrier is open, the switch-box area (rows 5–8, cols 30–33) counts as floor in `floorCell`. Valid rows now run 5–35, giving 802 valid states. V(start) is still 20.
- **Grow placement:** now observed for facing up as well as right; no definition changed.
- **`hopen`:** still an explicit hypothesis. Only its negative side ("no other column opens it") is used by the proof.

Nothing else changed: objects (block size, row, column; barrier open; pad used), the rules, the macro spells, and the superset-off parameter.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win. The budget is checked after the pad refund, which is the generous choice.

It leans on these rules:
- the map with walls and the opened box as floor;
- moves;
- the diamond toggle and its placement;
- the pad refund of 10, small blocks only;
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`, the pad trigger being small-only, and superset firing being off. Everywhere else it is looser.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the floor definition changed.

**7. Checks on the proof**

a. `work/fit3.py` searched over every reading from all three attempts: display granularity, rounding, completing-click cost, whether the first action counts, each segment's budget, and the refund as "subtract R" or "set to R". Two combinations survive. Both use 2-row floor display, ordinary cost 1, completing click 2, first action free, and level-4 budget 18 in every attempt. They differ only in the refund: subtract 10, or set used to 8. The theorem uses subtract 10, which is at least as generous whenever used ≤ 18, so no conclusion changes between them.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 | Attempt 3, transitions 130–131: full bar still NOT_FINISHED, next move GAME_OVER | the budget were larger |
| Grow placement | Attempt 3, transition 124: big block lands at (21,31) | grow placement depended on facing |
| Col-31 positive | Attempt 3, transition 127: barrier opened | |
| Other columns fail | Attempt 1, transition 79 (column 29) | |
| Barrier can't be shot | Attempt 2, transition 93 | |
| Pad refund 10 | Attempt 2, transition 103 | |
| Pad needs a small block | Attempt 2, transition 98: full cover by a big block, no refund | |

Partial overlap of the pad by a big block was never tried. The experiment is: move the big block down, left, left, left so it partly covers the pad, and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model that is much stricter than the game. The two-unit gap still means a cheaper mechanic probably exists. My suspects are the pad-trigger rule and the "only column 31 opens" rule.

VERDICT: impossible
CONFIDENCE: 55

## Attempt 4

**1. What happened on level 4**

My model said no route fits the 18-unit budget, so I walked the cheapest route it knew (net cost 21) to test two open questions on the way:
1. I moved the big block down-left, shrank it, and stepped the small block onto the refill pad. Budget used went from 11 to 1: the pad subtracts 10. The alternative reading, "reset used to 8", would have left the bar at 28 rows instead of 2.
2. I grew the block back so that its left edge sat at column 31, under the stalk, then moved it up to row 29 and fired the column shot upward. The barrier opened.
3. The budget then ran out 3 moves short of the exit, which is what the model predicted.

The cause of failure is the same as before. Opening the barrier needs a shrink-and-grow shift (10 units) plus the shot (4 units), and the exit is still 6 or more moves away afterwards. The pad's refund doesn't pay for its detour.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right, up and down.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **The opening shot.** A block with its left column at 31 opens the barrier from row 21 and from row 29.
- **Negative results.** A big block at column 29 cannot open it (attempt 1), and a shot into the barrier itself does nothing (attempt 2).

Assumptions the bound leans on, not tested:
- **`hopen`:** no shot from any other column opens the barrier.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; a partial overlap by a big block was never tried.
- **No other refunds:** the pad is the only refund source.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

**3. Next attempt**

I don't see an affordable route. I would spend the budget on the specific untested mechanisms that could cut cost, rather than replaying the known route:
- whether a big block that partly overlaps the pad triggers the refund (reachable only on the shifted position grid);
- whether a blocked move also turns the block's facing.

If neither changes anything, I will stop.

**4. Formal system**

No definition changed this attempt. The two observations confirmed choices the model had already made: refund as "subtract 10", and the shot allowed from any row at column 31. `work/MODEL.md` records this. Objects, rules and the Lean definitions in `lean/M15L4Map.lean` are as amended after attempt 3.

**5. Proof** (`lean/M15L4Map.lean`, unchanged; recompiled)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- the diamond toggle and its placement;
- the pad refund (subtract 10, small blocks only);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`, the pad trigger being small-only, and superset firing being off. It is looser on facing and on when spell costs are charged.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: this attempt measured the refund form ("subtract 10" confirmed, "reset to 8" refuted) and confirmed that the shot works from row 29, but the Lean model already used both, so no rule or definition changed. For the model to change, a measurement would have had to contradict one of its definitions, for example the refund resetting used to 8, or the row-29 shot failing.

**7. Checks on the proof**

a. `work/fit4.py` searched over every reading from all four attempts, including both pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each segment's budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (bar at 28 rows) |
| Budget 18 | Attempt 4, transitions 157–158: full bar still NOT_FINISHED, next move GAME_OVER | the budget were larger |
| Col-31 opens, any row | Attempt 3, transition 127 (row 21) and attempt 4, transition 154 (row 29) | the row mattered |
| Grow placement | Attempt 3, transition 124 (facing up) and attempt 4, transition 148 (facing down) | placement depended on facing |
| Column 29 fails | Attempt 1, transition 79 | |
| Barrier can't be shot | Attempt 2, transition 93 | |

The small-only pad trigger has no decisive experiment yet. Only a full cover by a big block was tried (attempt 2, transition 98). The experiment to run: partly overlap the pad with a big block on the shifted position grid and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. Still, the level was presumably built to be winnable, so I suspect `hopen` or the small-only pad trigger is the rule that's wrong.

VERDICT: impossible
CONFIDENCE: 60

## Attempt 5

**1. What happened on level 4**

My rules already said level 4 can't be finished within its 18-unit budget, so I spent this attempt testing the rules that conclusion rests on.
- **Card panel:** clicking a card is free. It only redraws that card's pattern as holes in the grid; it selects nothing and makes no spell cheaper.
- **Shots from column 33:** I shot up from a big block with its left edge at column 33, under the switch box's edge. The barrier stayed closed. I then shrank in place and shot from a small block at column 33; the barrier stayed closed again.
- The budget then ran out and the next move ended the game.

The underlying cause is unchanged. The only way to open the barrier is a shot from column 31, directly under the stalk. Getting a big block there needs a shrink and a grow (10 units), and the shot (4) plus the walk to the exit pushes every route past 18, even with the refill pad's 10-unit refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink and grow placement.** Shrink keeps the top-left corner; grow puts the small block at the big block's bottom-right. Grow was observed facing right, up and down.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Shots that open the barrier.** A block with its left column at 31 opens it, from row 21 and from row 29.
- **Shots that fail.** Column 29 (big, attempt 1). Column 33 (big and small, this attempt). A shot fired straight into the barrier (attempt 2).

Assumptions the bound leans on, not fully tested:
- **`hopen`:** no column other than 31 opens the barrier. Columns 29 and 33 are tested; no other column lies under the box.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; a partial overlap by a big block was never tried.
- **No other refunds:** the pad is the only refund source.
- **Exact pattern matching:** one click never completes two patterns at once. A separate Python search found no win within 18 even if it did.

**3. Next attempt**

I have no route to play. The one remaining specific test is whether a big block partly overlapping the pad triggers the refund. The test needs a big block on the shifted position grid: move it to (33,25) (5 moves), shrink, then grow back. Growing lands it at (31,23), partly over the pad. That costs 15 units, then I watch the bar. Even if it does trigger, my model says that alone does not make the level winnable.

**4. Formal system**

No definition changed; `work/MODEL.md` records the attempt-5 results.
- **Objects:** block (size, row, column), barrier open or not, pad used or not.
- **Rules:** moves, the diamond toggle with its placement, the pad refund, the column-31 shot, free clicks, and the goal.
- **Lean status:** `lean/M15L4Map.lean` is unchanged since attempt 3. `hopen` and superset firing (off) remain explicit premises.

**5. Proof** (`lean/M15L4Map.lean`, unchanged; output from the last compile)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), with superset firing off and budget 18, every action list fails to win.

It leans on the map, moves, the toggle and its placement, the pad refund (subtract 10, small blocks only), spell costs 5 and 4, and the goal condition.

The model is stricter than the game only through `hopen`, the small-only pad trigger, and superset firing being off. It is looser on facing, on the row a shot is fired from, and on when spell costs are charged.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: the two column-33 shots both failed, which is exactly what `hopen` already says, and the card clicks behaved as the existing free action. No rule or definition needed changing. For the model to change, a shot from a column other than 31 would have had to open the barrier, or a card click would have had to cost budget or select cells.

**7. Checks on the proof**

a. `work/fit5.py` searched over every reading from all five attempts. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget 18 | Each attempt's GAME_OVER on the first move past a full bar (last: attempt 5) | the budget were larger |
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (28 rows) |
| `hopen`, negative side | Attempt 1, transition 79 (column 29); attempt 5 (column 33, big and small) | another column opened it |
| Column 31 opens, any row | Attempt 3, transition 127; attempt 4, transition 154 | the row mattered |
| Grow placement | Attempt 3, transition 124 (facing up); attempt 4, transition 148 (facing down) | placement depended on facing |

The small-only pad trigger has no decisive experiment yet. The experiment is the partial-overlap test described in section 3.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18 (from the attempt-3 build; the model is unchanged since). The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. If something is wrong, the likeliest suspect is the small-only pad trigger.

VERDICT: impossible
CONFIDENCE: 65

## Attempt 6

**1. What happened on level 4**

My rules already said level 4 can't be finished within its 18-unit budget, so I used this attempt to test what was left untested.
- **One click completing two patterns:** I selected five cells containing both the diamond and the column. Nothing fired; the click cost 1.
- **Deselecting into a pattern:** removing one cell, which left exactly the diamond, did fire the shrink. Patterns are checked after every grid click, deselects included.
- **Growing with the usual spot blocked:** I put the small block in the room's top row and grew it. The grow still happened: the big block kept the small block's row and shifted 2 columns left.

The budget then ran out. The failure is unchanged: opening the barrier needs a block whose left edge is at column 31. Getting there costs a shrink and a grow, plus the shot, plus the walk to the exit, and every route comes to more than 18 even with the pad's 10-unit refund.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. The check covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) = 20, so the cheapest possible net cost is 20, which is more than 18.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Shrink placement.** Shrink keeps the top-left corner.
- **Grow placement.** Up-left (r−2, c−2) is preferred; when that is blocked, (r, c−2).
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Exact pattern matching.** Tested this attempt.
- **Shots that open the barrier.** A block with its left column at 31 opens it, from row 21 and from row 29.
- **Shots that fail.** Column 29 (big), column 33 (big and small), and a shot fired straight into the barrier.

Assumptions the bound leans on, not fully tested:
- **`hopen`:** only column 31 opens the barrier. Columns 29 and 33 are tested; these are the only other block positions under the box.
- **Pad trigger:** only a small block triggers the pad. A big block fully covering it did nothing; partial overlap was never tried. The planner found no route within 18 even if partial overlap did trigger it.
- **No other refunds:** the pad is the only refund source.

**3. Next attempt**

I have no route left to try. I would only test the partial-overlap pad trigger directly, and the planner already says it can't produce a win. Short of finding a mechanic I haven't seen at all, I expect the attempt to end on budget again.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 6":
- **Rule revised: grow.** The old model made a blocked grow a no-op, which was stricter than the game. It is now `growOuts`: (r−2, c−2) if it fits; else (r, c−2) if it fits; else any other fitting placement or staying small, which has never been observed and is left permissive.
- **Lean changes.** `toggleWith gp` replaces `toggle`. `step` and `winsWithin` now take the grow choice `gp`. A new hypothesis `hgp` says gp's result is in `growOuts`. `gpReal`, the observed rule, satisfies it (`gpReal_ok`).
- **Premise now tested.** Superset firing off is now backed by this attempt's experiment.
- **Unchanged:** the objects (block size, row, column; barrier open; pad used) and the other rules.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, small blocks only);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen` and the small-only pad trigger. It is looser on facing, on the row a shot is fired from, on when spell costs are charged, and on unobserved grow placements.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins20' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins20`: the same model is winnable with a budget of 20.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the grow rule and its definition changed.

**7. Checks on the proof**

a. `work/fit6.py` searched over every reading from all six attempts. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops or landed elsewhere |
| Refund subtracts 10 | Attempt 4, transition 142: bar at 2 rows | the refund reset used to 8 (28 rows) |
| Budget 18 | Every attempt: GAME_OVER on the first move past a full bar | the budget were larger |
| `hopen`, negative side | Attempt 1, transition 79 (column 29); attempt 5 (column 33, big and small) | another column opened it |
| Column 31 opens, any row | Attempt 3, transition 127; attempt 4, transition 154 | the row mattered |

The small-only pad trigger has no decisive experiment yet. The experiment is to grow into (31,23), partly overlapping the pad, and watch the bar.

c. The proof goes through for budgets up to 19 and first fails at 20, against a measured 18. The bound survives only one unit above the measured budget, so this is not a model much stricter than the game. If the model is wrong anywhere, the likeliest place is a mechanic I have never seen.

VERDICT: impossible
CONFIDENCE: 70

## Attempt 7

**1. What happened on level 4**

Level 4 needs the column shot fired from a block whose left edge is at column 31, directly under the stalk. Getting a block there costs a shrink and a grow on top of the shot and the walk, and every route I had found came to more than the 18-unit budget. So I used this attempt to test the last thing my model hadn't checked: whether a big block can trigger the refill pad, the grey-blue pad that refunds 10 units.

- I moved the big block down-left to row 33, column 25, shrank it, then grew it. The grow placed it at row 31, column 23, half over the pad.
- The 10-unit refund fired. So a big block can trigger the pad, at least when it arrives by growing. My model had said only a small block could, which made it stricter than the game.
- I then moved the block to column 31, shot upward from row 27, and the barrier opened. But on that row grid the big block can't fit into the 4-row corridor, so the rest of the budget ran out and the game ended.

The failure is the same budget wall. The fix to the pad rule lowers the cheapest route by only one unit.

**2. Can the level be beaten?**

Under my rules, no, by a margin of one unit. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. This covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) is now 19, so the cheapest possible net cost is 19, which is more than 18.
- A separate planner that also requires facing up for the shot gives the same minimum, 19.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Spell rules.** Shrink keeps the top-left corner. Grow goes up-left (r−2, c−2) if that fits, else (r, c−2). Patterns must match the selected cells exactly.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Budget and refund.** Budget 18; the pad refund subtracts 10. Both come from the single surviving cost fit.
- **Shots.** A block with its left column at 31 opens the barrier from any row. Columns 29 and 33, and a shot fired straight into the barrier, do not.

Assumptions the bound leans on:
- **`hopen`:** only column 31 opens the barrier. This is now supported by negative tests at columns 29 and 33.
- **One refund:** the pad refunds once, 10 units, and there is no other refund source.

The model is now looser than the game about the pad: it lets any overlap by any block trigger the refund, even full cover by a moving big block, which did not trigger in attempt 2.

The 19-unit route assumes the refund also fires when a grow lands a big block fully over the pad. That case has never been observed.

**3. Next attempt**

Run the 19-unit route and check its untested step:
1. Move left 3 times and down twice, to row 33, column 25.
2. Shrink, move down 1, grow. The block lands at row 33, column 23, fully covering the pad. Watch whether the refund fires.
3. Move right twice and up once, to row 29, column 31, facing up. Fire the shot.
4. Move right 6 times to the exit.

Under my rules this fails one unit short. It is the closest route I have, and walking it is the only way to expose a one-unit error in my cost accounting.

**4. Formal system (amended in place)**

Changes, recorded in `work/MODEL.md` under "attempt 7":
- **Rule revised: pad trigger.** It was "the first overlap by a small block". It is now "any overlap by a block of either size, after any action". In Lean, `onPad` no longer requires a small block.
- **Recomputed:** the value table; V(start) went from 20 to 19. The non-vacuity witness is now `witness_wins19`.
- **Blocked moves turn facing.** Recorded only, since facing is not in the model (which keeps it looser).
- **Unchanged:** objects, the grow outcome set, `hopen`, and exact pattern matching.

**5. Proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, once, any overlap);
- spell costs 5 and 4;
- the goal condition.

Where the model is stricter than the game: only through `hopen`. It is looser on the pad trigger, on facing, on the row a shot is fired from, on when spell costs are charged, and on grow placements never observed.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins19' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins19`: the same model is winnable with a budget of 19.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

**6.** Not applicable: the pad-trigger rule and its definition changed.

**7. Checks on the proof**

a. `work/fit7.py` searched over every reading from all seven attempts, including all three pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Pad: any block may trigger | Attempt 7: the bar dropped 46 → 16 rows | only small blocks triggered it |
| Refund subtracts 10 | Attempt 4: bar at 2 rows | the refund reset used to 8 (28 rows) |
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops |
| `hopen`, negative side | Attempt 1, column 29; attempt 5, column 33 (big and small) | another column opened it |
| Budget 18 | Every attempt: GAME_OVER on the first move past a full bar | the budget were larger |

The bound rests on `hopen`, the refund amount, and the budget, and none of these lacks a decisive experiment.

c. The proof goes through for budgets up to 18 and first fails at 19. The bound fails one unit above the measured budget. So the result is tight against my measurements, and any single missed one-unit saving would overturn it. If something is wrong, I would suspect a one-unit cost detail, such as how a completing click is charged when it also triggers the pad, rather than a structural rule.

VERDICT: impossible
CONFIDENCE: 55

## Attempt 8

**1. What happened on level 4**

I played the cheapest route my model allows. It costs 19 units net against a budget of 18, and it had two untested steps that could have made it work:
1. **Refund on full cover.** I moved the big block down-left, shrank it, stepped down once, and grew it back so it landed fully over the refill pad. The 10-unit refund fired.
2. **Barrier.** I moved the block under the stalk (left edge at column 31), faced up and fired the column shot. The barrier opened.
3. **Win versus game over.** I walked right toward the exit. At 18 units I was one move short. The final move entered the exit box, but it took usage to 19 and the game returned GAME_OVER instead of a win.

The level failed because the cheapest route I know is one unit over budget, and the game checks the budget before it checks for a win.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the row-aware map gets a cost-to-go value V. The kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. The check covers every shot outcome `hopen` allows and every grow outcome in the permitted set.
- V(start) = 19, so the cheapest possible net cost is 19, which is more than 18.
- A step that would take usage past 18 fails, even when it reaches the exit. This attempt confirmed that on the final move.

Established parts:
- **Map and moves.** Walls are read off the frame; big blocks step 4, small blocks step 2.
- **Spell rules.** Shrink keeps the top-left corner. Grow goes up-left (r−2, c−2) if that fits, else (r, c−2). Patterns must match the selected cells exactly.
- **Spell costs.** Shrink/grow 5, shot 4.
- **Pad.** It refunds 10 units once, on any overlap by a block, including a full cover after a grow.
- **Budget and ordering.** Budget 18, and the budget check comes before the win check.
- **Shots.** A block with its left column at 31 opens the barrier from any row. Columns 29 and 33, and a shot fired straight into the barrier, do not.

Assumptions not fully tested:
- **`hopen`:** only column 31 opens the barrier. Negative tests at columns 29 and 33 back it.
- **One refund:** there is no refund source other than the pad.

The model is looser than the game on facing (blocked moves turn the block for 1 unit), and on when spell costs are charged.

The specific untested mechanism I can name: something that refunds or saves a single unit, for example a cheaper way to complete a pattern. I have no candidate left that the planner says would close the gap.

**3. Next attempt**

I have no route to defend. I would replay the 19-unit route only to look for a one-unit discrepancy in the budget bar's readings. Otherwise I would stop rather than spend the budget.

**4. Formal system**

No definition changed; `work/MODEL.md` records the attempt-8 results.
- **Objects:** block (size, row, column), barrier open or not, pad used or not.
- **Rules:** moves, toggle with `growOuts`, pad refund on any overlap, the column-31 shot, free clicks, the goal, and budgeted runs where any step over budget fails.
- **Lean status:** `lean/M15L4Map.lean` is as amended after attempt 7.

**5. Proof** (`lean/M15L4Map.lean`, unchanged since attempt 7; output from the last compile)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow resolution `gp` satisfying `hgp`, with exact pattern matching and budget 18, every action list fails to win.

It leans on these rules:
- the map with walls, the opened switch box counting as floor;
- moves;
- shrink and grow (`growOuts`);
- the pad refund (subtract 10, once, any overlap);
- spell costs 5 and 4;
- the goal condition;
- the budget check coming before the win check.

Where the model is stricter than the game: only through `hopen`. It is looser everywhere else listed above.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins19' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

**6.**

FORMAL-UNCHANGED: this attempt confirmed two things the model already encoded and contradicted nothing. A grow that lands a big block fully over the pad triggers the refund, which the any-overlap `onPad` already allowed. A move that reaches the exit while taking usage past 18 is GAME_OVER, which `winsWithin` already handles by failing any step with u + cost > B before looking at the next state. For the model to change, the full-cover refund would have had to not fire, or the over-budget move into the exit would have had to win.

**7. Checks on the proof**

a. `work/fit8.py` searched over every reading from all eight attempts, including all four pad events. It varied display granularity, rounding, completing-click cost, whether the first action counts, each attempt's level-4 budget, and the refund as "subtract R" or "set to R". Exactly one combination survives:
- 2-row floor display;
- ordinary action 1 unit, completing click 2 units;
- first action after reset free;
- refund subtracts 10;
- level-4 budget 18 in every attempt.

b. The decisive experiment behind each load-bearing rule:

| Rule | Decisive observation | Would differ if… |
|---|---|---|
| Budget check before win check | Attempt 8, transition 254: GAME_OVER on the move into the exit | a win were checked first |
| Full-cover refund | Attempt 8, transition 242: bar 20 rows | full cover did not trigger (56 rows) |
| Any block may trigger the pad | Attempt 7, transition 214 | only small blocks triggered it |
| Refund subtracts 10 | Attempt 4, transition 142 | the refund reset used to 8 |
| Exact matching | Attempt 6: superset click, nothing fired | superset clicks fired a spell |
| Grow fallback | Attempt 6: blocked grow landed at (21,35) | blocked grows were no-ops |
| `hopen`, negative side | Attempt 1, column 29; attempt 5, column 33 (big and small) | another column opened it |
| Column 31 opens, any row | Attempts 3 and 4 | the row mattered |

None of the load-bearing rules lacks a decisive experiment.

c. The proof goes through for budgets up to 18 and first fails at 19 (from the attempt-7 build; the model is unchanged since). The bound fails one unit above the measured budget, so the result is tight against my measurements. It is not evidence of a model much stricter than the game; if it is wrong, the error is a one-unit cost detail or a mechanic I have never seen.

VERDICT: impossible
CONFIDENCE: 60

## Final interview

**1. What happened on level 4**

You move a block around a room. To reach the exit it must pass a barrier. Two spells are drawn by clicking cells on a 3×3 grid: a diamond that shrinks the block (or grows it back), and a column that fires a shot in the direction the block faces. Each action costs budget; the level allows 18 units.

The barrier opens only when a shot travels up a narrow stalk and hits a switch box. That works only if the block's left edge is at column 31, directly under the stalk. The block starts on a 4-cell grid of positions that never lands there. Shifting it takes a shrink and a grow (5 units each), the shot costs 4, and the walk to the exit takes several more moves.

A refill pad gives back 10 units once. Even using it, the cheapest route I found costs 19 units net.

In the final attempt I played that 19-unit route:
- I grew the block onto the pad and got the refund.
- I shot from column 31 and opened the barrier.
- I walked to the exit, but the move that entered it took usage to 19. The game ended in GAME_OVER, which shows the budget is checked before the win.

The level failed because the cheapest route I know is one unit over budget.

**2. Can the level be beaten?**

Under my rules, no. Claim: no action sequence reaches the exit with budget used at or below 18.

The argument:
- Each valid state of the level-4 map gets a cost-to-go value V. The Lean kernel checks every edge: V(s) ≤ net cost + V(next), and V ≤ 0 at the goal. This covers every allowed shot outcome and every allowed grow outcome.
- "Used + V" therefore never decreases along a run, and V(start) = 19. Any winning run would end with used ≥ 19, more than 18.

Established parts:
- **Moves.** Big blocks step 4, small blocks step 2; walls are read off the frame. A blocked move still costs 1.
- **Costs and budget.** Ordinary action 1 unit, a click that completes a spell 2 units, budget 18. This is the unique fit over every reading from eight attempts.
- **Spell matching.** Spells fire only on an exact match of the selected cells, checked after every grid click.
- **Shrink and grow.** Shrink keeps the top-left corner. Grow goes up-left (r−2, c−2), or to (r, c−2) if that is blocked.
- **Pad.** It refunds 10 units once, on overlap by a block of either size.
- **Shots.** A block with its left column at 31 opens the barrier from any row. Columns 29 and 33, and a shot fired straight into the barrier, do not.
- **Ordering.** The budget check comes before the win check.

Assumptions not fully tested:
- **`hopen`:** no column other than 31 opens the barrier.
- **One refund:** there is no refund source other than the pad.

The model is looser than the game in several places: facing is ignored, the shot's row is ignored, the pad triggers on any overlap, and grow placements never observed are allowed. The one place it is stricter than the game is `hopen`.

**3. Rules I newly worked out**

- **The spell grid is a free drawing pad.** Any cell can be selected, and only the patterns shown on the level's cards fire (level 3: a diamond drawn there did nothing).
- **The column spell is a block-sized shot.** It travels while its left half is on floor; it opens the barrier only from column 31 (attempts 1, 3, 4 and 5).
- **The diamond toggles size.** Shrink keeps the top-left corner; grow puts the old small block at the new big block's bottom-right. Seen across attempts 2–4.
- **Grow has a fallback.** When the up-left spot is blocked it lands at (r, c−2) (attempt 6).
- **The pad refund subtracts 10.** The alternative, "reset to 8", was refuted in attempt 4. Any block size triggers it (attempt 7), including a full cover after a grow (attempt 8).
- **Patterns must match exactly.** A click completing two patterns at once fired nothing, and a deselect that left an exact pattern did fire (attempt 6).
- **Blocked moves turn the block** to face the attempted direction (attempt 7).
- **Over-budget moves lose even if they reach the exit** (attempt 8).

**4. Rules I'm still unsure about**

- **`hopen`.** It is backed by two negative columns and two positive rows, not by an exhaustive test.
- **Pad edge case.** A big block moving to fully cover the pad did not trigger it, yet a grow landing fully over it did. I don't know the real trigger condition; the model takes the generous side.
- **A hidden one-unit saving.** I can't rule out something like a cheaper way to complete a pattern. The bound sits exactly one unit above the budget, so any such saving would overturn it.

**5. Lean proof** (`lean/M15L4Map.lean`)

`L4_unwinnable` says: for every opening function satisfying `hopen` (a shot can open the barrier only if the block's left column is 31), for every grow choice satisfying `hgp` (the grow lands within the allowed outcomes), with exact pattern matching and budget 18, `winsWithin … start 0 as = false` for every action list `as`.

The premises are explicit hypotheses, not buried in definitions. The supporting lemmas are:
- `checkAll_true`, checked with `decide +kernel`, not `native_decide`: every edge satisfies the V inequality;
- `goalCheck_true`: V ≤ 0 at the goal;
- `step_mem`: each real step lands in the enumerated outcomes;
- `inv`: used + V never decreases along a run;
- `V_start = 19`.

```
'M15L4Map.checkAll_true' depends on axioms: [propext]
'M15L4Map.step_mem' depends on axioms: [propext, Quot.sound]
'M15L4Map.inv' depends on axioms: [propext, Quot.sound]
'M15L4Map.L4_unwinnable' depends on axioms: [propext, Quot.sound]
'M15L4Map.gpReal_ok' depends on axioms: [propext]
'M15L4Map.witness_wins19' does not depend on any axioms
'M15L4Map.cheap_wins' does not depend on any axioms
```

Two checks that the bound is not empty:
- `witness_wins19`: the same model is winnable with a budget of 19.
- `cheap_wins`: if any shot opened the barrier, budget 18 would suffice.

The bound holds for budgets up to 18 and fails at 19.

VERDICT: impossible
CONFIDENCE: 55
