# L4 / Claude Opus 5.5 + AWM / 69fe87

- **实验类别**：主表：AWM原始实验
- **关卡/受试**：L4 / Claude Opus 5.5 + AWM
- **论文位置**：主表原始阶段
- **预算/轮次**：8次
- **结果**：impossible；界：19
- **最终声明**：impossible
- **注意**：开门和增长规则有显式限制；本轮4GB内存限制下未重编通过，不等于发现证明错误。
- **初始数值计分**：按论文口径记正确

## 从哪里检查

1. [受试逐轮/汇总答复](interviews.md)。这是阅读入口。
2. [原始JSON / 会话提取](run.json)。摘录与索引有歧义时以原始记录为准。
3. [本阶段主证明](proof_sources/M15L4Map.lean)；主定理 `L4_unwinnable`。
   Parameterized openings/growth; concrete model instance and witness. New recheck reached 4GB limit; historical evidence retained.
- [原始游戏服务记录](server)。
- [完整证明源码目录](proof_sources)。

## 采集来源

`D:\THU\2026 Summer\ARC-AGI\ours\benchmarks\armkit\run_m15_m15fw-case-69fe87.json`

这是采集时的来源路径；当前arena可能已经经过后续修复，不能代替本目录保存的阶段快照。

[返回本类实验](../README.md) · [返回实验总表](../../EXPERIMENTS.md)
