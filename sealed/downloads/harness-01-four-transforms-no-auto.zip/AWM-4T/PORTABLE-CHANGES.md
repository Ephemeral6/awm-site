# Device release changes

- Source/evidence paths resolve within this package; original upstream bytes are supplied.
- setup_device.py creates fresh host-specific cases and arena paths.
- Repair is blocked until all six initial results/adjudications are summarized and frozen.
- Full model runs remain serial with the8GiB guard.
- Strict initial replies are no longer declared dead merely for taking under60 seconds; return-code/text failures still fail. Integration tests use1-second synthetic replies.
- Old six-attempt repair and evaluator search outputs are not supplied as replacement study outcomes.
- No study model or real game service was invoked while building.
