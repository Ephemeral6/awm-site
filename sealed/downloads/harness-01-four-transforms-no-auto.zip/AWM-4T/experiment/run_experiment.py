"""Dry-run by default. Paid execution is an explicit operator action, never used by tests."""
from pathlib import Path
import argparse,json,os,subprocess,sys,hashlib,socket,time,shutil
sys.path.insert(0,str(Path(__file__).resolve().parent))
import protocol as P

def unwrap(path):
    x=json.loads(Path(path).read_text(encoding='utf-8'));return x[0] if isinstance(x,list) else x

def main():
    a=argparse.ArgumentParser();a.add_argument('--dry-run',action='store_true');a.add_argument('--execute-initial',action='store_true');a.add_argument('--execute-feedback',action='store_true');a.add_argument('--finish-case',action='store_true');a.add_argument('--case');a.add_argument('--adjudication');opts=a.parse_args()
    assert sum([opts.execute_initial,opts.execute_feedback,opts.finish_case])<=1,'Choose one action'
    if opts.dry_run and any([opts.execute_initial,opts.execute_feedback,opts.finish_case]):a.error('--dry-run cannot be combined with execution or cleanup flags')
    planpath=P.R/'operator_only/batch-plan.json';plan=P.create_plan(planpath)
    if not any([opts.execute_initial,opts.execute_feedback,opts.finish_case]):P.dry_run();return 0
    assert opts.case,'Select one case; runs are serial on this machine'
    row=next(x for x in plan['arms'] if x['case']==opts.case)
    outdir=P.R/'results';outdir.mkdir(exist_ok=True)
    initial=outdir/(row['case']+'-initial8.json');feedback=outdir/(row['case']+'-feedback4.json')
    d=Path(plan['stage'])/row['case'];locked=P.R/'checkpoints'/row['case']
    cleanup=[sys.executable,str(P.P2/'harness/stop_server.py'),'--case',row['case']]
    if opts.finish_case:
        return subprocess.run(cleanup,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)).returncode
    # No authentication or remote preflight; checks below use local state only.
    P.export_prompts()
    from device_support import require_receiver_review
    require_receiver_review(P.R)
    import msvcrt,atexit
    controller=P.R/'runtime_archive/controller.lock';controller.parent.mkdir(exist_ok=True)
    lock=controller.open('a+b');lock.seek(0)
    if controller.stat().st_size==0:lock.write(b'0');lock.flush();lock.seek(0)
    try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:lock.close();raise SystemExit('Another model run owns this branch controller; wait for it to finish')
    atexit.register(lock.close)
    sys.path.insert(0,str(P.AK));import completion_round as CR
    assert CR.avail_gb()>=12,'Need at least 12 GiB available; do not raise the 8 GiB per-call limit'
    env=dict(os.environ,AWM_STAGE=plan['stage'],AWM_ARCHIVE=str(P.R/'runtime_archive'),AWM_RUNTIME=str(P.R/'runtime_tmp'),AWM_CLAUDE_MODEL=P.MODEL,AWM_EXPECTED_MODEL=P.MODEL,PYTHONIOENCODING='utf-8')
    pin=outdir/(row['case']+'.session-id')
    env['AWM_SESSION_PIN']=str(pin)
    if opts.execute_initial:
        assert not initial.exists() and not locked.exists() and not pin.exists(),'Fresh runs only; never overwrite previous results'
        with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',row['port']))!=0,'Port is already occupied'
        cmd=P.command(planpath,row,plan['stage'],initial)
    else:
        from device_support import require_initial_batch_summary
        require_initial_batch_summary(P.R)
        assert opts.adjudication and locked.exists(),'Lock initial8 and supply operator adjudication first'
        assert pin.exists(),'Original session pin is unavailable; do not silently open a fresh session'
        assert (locked/'session-id').read_text(encoding='utf-8')==pin.read_text(encoding='utf-8'),'Session differs from the locked checkpoint'
        record=unwrap(locked/'initial8.json');decision=json.loads(Path(opts.adjudication).read_text(encoding='utf-8'))
        assert P.adjudicate(record,decision,row['win_level'])=='eligible_feedback4','Not eligible for the cheaper-win feedback'
        assert not feedback.exists(),'Never replay an already consumed repair'
        # Identity and liveness: retain the original service rather than reconstruct its state.
        owner=json.loads((P.AK/'srvout'/(row['case']+'.process.json')).read_text(encoding='utf-8'))
        with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',row['port']))==0,'Original service unavailable; mark VOID, do not silently restart'
        script=f'(Get-CimInstance Win32_Process -Filter "ProcessId={int(owner["pid"])}").CommandLine'
        check=subprocess.run(['powershell','-NoProfile','-Command',script],capture_output=True,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        line=check.stdout.lower().replace('/','\\')
        assert all(str(owner[k]).lower().replace('/','\\') in line for k in ('server','log')),'Server PID identity mismatch'
        (d/'METHOD_selfaudit.md').write_bytes((P.R/'operator_only/METHOD_selfaudit.md').read_bytes())
        cmd=P.command(planpath,row,plan['stage'],feedback,P.R/'prompts/30-feedback-first.txt')
    try:
        if opts.execute_initial:
            P.stage_one(planpath,row,plan['stage'],serve=True)
            ready=False
            for _ in range(30):
                with socket.socket() as sock:ready=sock.connect_ex(('127.0.0.1',row['port']))==0
                if ready:break
                time.sleep(1)
            assert ready,'Server failed to start; no subject call made'
        log=outdir/(row['case']+('-initial8.log' if opts.execute_initial else '-feedback4.log'))
        with log.open('w',encoding='utf-8') as fo:r=subprocess.run(cmd,cwd=P.V2,env=env,stdout=fo,stderr=subprocess.STDOUT)
        out=initial if opts.execute_initial else feedback
        assert r.returncode==0 and out.exists(),'Driver failed; inspect log, do not silently resume'
        record=unwrap(out)
        if opts.execute_initial:
            P.checkpoint(d,out,locked,P.AK/'srvlog'/row['case'])
            assert pin.exists(),'No verified subject session ID was preserved'
            shutil.copy2(pin,locked/'session-id')
            template=dict(status='pending',initial_record_sha256=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest(),normalized_engine_bound=None,evidence='Record reported units, terminal-move convention, final theorem/witness and original interview lines. Never send this operator file to the subject.')
            (locked/'adjudication-template.json').write_text(json.dumps(template,indent=2),encoding='utf-8')
            print('Initial record locked. Original service intentionally retained for the same-session continuation. Adjudicate now; if no repair is needed, use --finish-case. No follow-up model call was made.')
        if not opts.execute_initial or not record.get('protocol_valid'):
            subprocess.run(cleanup,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        return 0 if record.get('protocol_valid') else 2
    except BaseException:
        subprocess.run(cleanup,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));raise

if __name__=='__main__':raise SystemExit(main())
