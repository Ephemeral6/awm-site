"""No subject CLI, API, game server or large search is launched. All driver calls are mocks."""
from pathlib import Path
import sys,unittest,tempfile,json,copy,hashlib,contextlib,io,ast,os,types
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import protocol as P
import four_transforms_gate as FT
R=P.R;OUT=R/'offline_out';OUT.mkdir(exist_ok=True)
LONG='This pass checked the concrete dependencies against the full recorded transition set and retained each tested distinction without adding unsupported mechanisms. '

class MatrixTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='gate-',dir=OUT);self.d=Path(self.tmp.name)
        assert self.d.resolve().is_relative_to(OUT.resolve())
        for rel,s in {'objects/world.py':'x=1\n','rule/move.py':'x=1\n','transitions.jsonl':json.dumps({'tid':'t1','prev':[[1]],'next':[[1]],'action':'ACTION1'})+'\n'}.items():
            p=self.d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
        self.before=FT.begin(self.d,1)
        self.rec=dict(attempt=1,before_source_sha256=self.before['before_source_sha256'],after_source_sha256=FT.source_hashes(self.d),corpus_sha256=FT.corpus(self.d)[0],transformations=[dict(id=i,status='considered_no_change',targets=['objects/world.py','rule/move.py'],reason=LONG,object_consideration=LONG,rule_consideration=LONG,evidence_ids=['t1']) for i in FT.IDS])
        self.receipt=dict(ok=True,compared_to='analysis/rejection_before.json',source_sha256=FT.full_hashes(self.d),corpus_sha256=FT.corpus(self.d)[0]);self.write()
    def tearDown(self):self.tmp.cleanup()
    def write(self):
        (self.d/'analysis/rejection_after.json').write_text(json.dumps(self.receipt),encoding='utf-8')
        (self.d/'analysis/transforms/attempt_01.json').write_text(json.dumps(self.rec),encoding='utf-8')
    def check(self):self.write();return FT.check(self.d,1)
    def test_valid_no_change(self):self.assertTrue(self.check()['ok'])
    def test_missing_direction(self):self.rec['transformations'].pop();self.assertFalse(self.check()['ok'])
    def test_duplicate_direction(self):self.rec['transformations'][-1]['id']='composition';self.assertFalse(self.check()['ok'])
    def test_unresolved(self):self.rec['transformations'][0]['status']='pending';self.assertFalse(self.check()['ok'])
    def test_fake_evidence(self):self.rec['transformations'][0]['evidence_ids']=['not-seen'];self.assertFalse(self.check()['ok'])
    def test_short_reason(self):self.rec['transformations'][0]['reason']='checked';self.assertFalse(self.check()['ok'])
    def test_missing_object_review(self):self.rec['transformations'][0].pop('object_consideration');self.assertFalse(self.check()['ok'])
    def test_missing_rule_review(self):self.rec['transformations'][0].pop('rule_consideration');self.assertFalse(self.check()['ok'])
    def test_applied_without_edit(self):self.rec['transformations'][0]['status']='applied';self.assertFalse(self.check()['ok'])
    def test_uncovered_edit(self):
        (self.d/'rule/move.py').write_text('x=2\n');self.rec['after_source_sha256']=FT.source_hashes(self.d);self.receipt['source_sha256']=FT.full_hashes(self.d);self.assertFalse(self.check()['ok'])
    def test_valid_edit(self):
        (self.d/'rule/move.py').write_text('x=2\n');self.rec['after_source_sha256']=FT.source_hashes(self.d);self.receipt['source_sha256']=FT.full_hashes(self.d);self.rec['transformations'][0]['status']='applied';self.assertTrue(self.check()['ok'])
    def test_stale_python(self):(self.d/'rule/move.py').write_text('x=2\n');self.assertFalse(self.check()['ok'])
    def test_stale_lean_receipt(self):
        (self.d/'lean').mkdir();(self.d/'lean/Step.lean').write_text('def a := 1\n');self.assertFalse(self.check()['ok'])
    def test_stale_corpus(self):
        with (self.d/'transitions.jsonl').open('a') as fo:fo.write(json.dumps({'tid':'t2'})+'\n')
        self.assertFalse(self.check()['ok'])
    def test_failed_regression(self):self.receipt['ok']=False;self.assertFalse(self.check()['ok'])
    def test_no_comparison(self):self.receipt.pop('compared_to');self.assertFalse(self.check()['ok'])
    def test_driver_file_forgery(self):
        self.rec['before_source_sha256']={};(self.d/'analysis/transforms/driver_before_01.json').write_text(json.dumps(self.rec));self.assertFalse(self.check()['ok'])
    def test_bad_schema(self):self.rec['transformations']={};self.assertFalse(self.check()['ok'])
    def test_unrelated_cwd_attempt(self):self.assertFalse(FT.check(self.d,9)['ok'])
    def test_empty_corpus(self):(self.d/'transitions.jsonl').write_text('');self.assertFalse(self.check()['ok'])

class ProtocolTests(unittest.TestCase):
    def test_initial_flags(self):
        row=dict(case='l4s-case-aabbcc',win_level=4);cmd=P.command(R/'plan.json',row,'D:/test','D:/out.json')
        self.assertNotIn('--selfaudit-gate',cmd);self.assertNotIn('--skeptic-gate',cmd);self.assertIn('--proof-gate',cmd);self.assertNotIn('--resume-session',cmd)
    def test_resume_flags(self):
        cmd=P.command(R/'p.json',dict(case='l4s-case-aabbcc',win_level=4),'D:/test','D:/out.json',R/'f.txt')
        self.assertEqual(cmd[cmd.index('--attempt-offset')+1],'8');self.assertEqual(cmd[cmd.index('--rounds')+1],'4')
    def record(self):return dict(protocol_valid=True,stop='exhausted',rounds=[{}]*8)
    def decision(self,record,bound):return dict(status='wrong_high_bound',initial_record_sha256=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest(),normalized_engine_bound=bound,evidence='Explicit conversion under the final winning-move convention.')
    def test_only_wrong_high_gets_feedback(self):
        r=self.record();self.assertEqual(P.adjudicate(r,self.decision(r,20),4),'eligible_feedback4')
    def test_correct_does_not_get_feedback(self):self.assertEqual(P.adjudicate(self.record(),{'status':'correct'},4),'complete_initial_no_feedback')
    def test_undecided_no_false_signal(self):self.assertEqual(P.adjudicate(self.record(),{'status':'undecided'},4),'manual_adjudication_no_feedback')
    def test_terminal_charge_not_error(self):
        r=self.record()
        with self.assertRaises(ValueError):P.adjudicate(r,self.decision(r,36),5)
    def test_incomplete_no_feedback(self):
        r=self.record();r['rounds']=r['rounds'][:3];self.assertEqual(P.adjudicate(r,{},4),'invalid_or_incomplete_no_feedback')
    def test_scoring_bound_to_checkpoint(self):
        r=self.record();d=self.decision(r,20);r['extra']='changed'
        with self.assertRaises(ValueError):P.adjudicate(r,d,4)
    def test_no_automatic_execution_default(self):
        tree=ast.parse((R/'run_experiment.py').read_text(encoding='utf-8'));self.assertIsInstance(tree,ast.Module)
        self.assertNotIn('19',P.feedback_text());self.assertNotIn('36',P.feedback_text());self.assertNotIn('47',P.feedback_text())

class DriverIntegrationTests(unittest.TestCase):
    """Exercise the actual patched loop. Every model and service function is replaced."""
    def run_driver(self,mode,resume=False):
        D=P.load('four_driver_test_'+mode+str(resume),P.V2/'run_v2.py')
        with tempfile.TemporaryDirectory(prefix='driver-',dir=OUT) as name,contextlib.ExitStack() as stack:
            root=Path(name);assert root.resolve().is_relative_to(OUT.resolve());case='l4s-case-aabbcc';d=root/case;d.mkdir()
            (d/'_FIRST_MESSAGE.txt').write_text('Initial task.');feedback=root/'feedback.txt';feedback.write_text('Generic feedback.')
            plan=root/'plan.json';plan.write_text(json.dumps({'arms':[dict(case=case,arm='framework',agent='claude',side='no',port=9999,win_level=4)]}))
            out=root/'result.json';calls=[]
            def fake(agent,d,text,first=False,label='',**kwargs):
                calls.append(dict(first=first,label=label,text=text))
                return dict(text='VERDICT: '+('impossible_in_model_proved' if mode in ('proof_fail','final_proof_fail') else 'undecided')+'\nCONFIDENCE: 50\n',wall_s=1,returncode=0)
            def chk(*args,**kw):return dict(ok=mode!='cards_fail',why=[] if mode!='cards_fail' else ['missing direction'],per_stage={'03':dict(done=True,unchanged=False)},n_changed=1,stages=['03'])
            def proof(*args,**kwargs):
                fail=mode=='proof_fail' or (mode=='final_proof_fail' and sum('VERDICT' in c['text'] for c in calls)==0 and len(calls)>=24)
                # The final interview has its own call label, but no text marker is assumed.
                if mode=='final_proof_fail' and len([c for c in calls if c['label'].endswith('\u8ffd\u95ee')])>=9:fail=True
                return dict(ok=not fail,why=['test compilation failure'] if fail else [],file='lean/Main.lean',theorem='Main')
            for obj,key,value in [(D.io,'TextIOWrapper',lambda *a,**k:sys.stdout),(D.RM,'drive_retry',fake),(D.RM,'srv_read',lambda *a:dict(actions=0,level=4,levels_completed=3)),(D,'force_reset',lambda *a:dict(level=4,frame_md5='0'*32)),(D,'srv_state',lambda *a:dict(state='GAME_OVER',level=4)),(D.MC,'clear',lambda *a,**k:dict(n=0)),(D.MC,'peek',lambda *a,**k:[]),(D.CG,'load',lambda *a:[('03','test','test')]),(D.CG,'_strict_enabled',True),(D.CG,'strict_begin',lambda *a:None),(D.CG,'plan',lambda cards,k:[(['03'],'File-only stage.')]),(D.CG,'snap',lambda *a:{}),(D.CG,'check',chk),(D.CG.FT,'check_current',lambda *a:dict(ok=mode!='stale_final',why=['stale'] if mode=='stale_final' else [])),(D.PG,'check',proof),(D,'lean_report',lambda *a:(None,[])),(D.FS,'snap',lambda *a:{}),(D.FS,'diff',lambda *a:dict(touched=0,rules_touched=0,lean_touched=0,added=[],changed=[],removed=[])),(D.GR,'judge',lambda *a:dict(ok=True,route='B',reasons=[])),(D.CO,'match',lambda *a:dict(n_rules=0,n_defs=0,n_pairs=0,n_cited=0,n_silent=0,rules_silent=[],defs_without_rule=[]))]:stack.enter_context(patch.object(obj,key,value))
            stack.enter_context(patch.object(D,'HERE',root))
            if mode=='begin_fail':stack.enter_context(patch.object(D.CG,'strict_begin',side_effect=ValueError('missing observation corpus')))
            args=['--arms',str(plan),'--stage',str(root),'--out',str(out),'--cards-gate',str(P.CARDS),'--proof-gate','--rounds','4' if resume else '8']
            if resume:args+=['--resume-session','--attempt-offset','8','--initial-prompt-file',str(feedback)]
            D.main(args);return json.loads(out.read_text(encoding='utf-8'))[0],calls
    def test_missing_card_stops_before_interview(self):
        r,c=self.run_driver('cards_fail');self.assertEqual(r['stop'],'protocol_blocked_cards');self.assertFalse(r['protocol_valid']);self.assertEqual(len(r['rounds']),1)
    def test_missing_corpus_recorded_without_crash(self):
        r,c=self.run_driver('begin_fail');self.assertEqual(r['stop'],'protocol_blocked_before_cards');self.assertFalse(r['protocol_valid'])
    def test_proof_failure_does_not_start_attempt2(self):
        r,c=self.run_driver('proof_fail');self.assertEqual(r['stop'],'protocol_blocked_end_of_attempt');self.assertEqual(len(r['rounds']),1);self.assertFalse(r['protocol_valid'])
    def test_stale_model_stops(self):
        r,c=self.run_driver('stale_final');self.assertFalse(r['protocol_valid']);self.assertEqual(len(r['rounds']),1)
    def test_final_proof_failure_not_counted_valid(self):
        r,c=self.run_driver('final_proof_fail');self.assertEqual(r['stop'],'protocol_blocked_final_proof');self.assertFalse(r['protocol_valid'])
    def test_complete8_and_no_restart(self):
        r,c=self.run_driver('ok');self.assertTrue(r['protocol_valid']);self.assertEqual(len(r['rounds']),8);self.assertEqual(sum(x['first'] for x in c),1)
    def test_same_session_9_to12(self):
        r,c=self.run_driver('ok',True);self.assertEqual([q['logical_attempt'] for q in r['rounds']],[9,10,11,12]);self.assertFalse(any(x['first'] for x in c));self.assertTrue(r['mem_on_entry']['continuation'])

class SessionTests(unittest.TestCase):
    def test_missing_session_id_rejected(self):
        with tempfile.TemporaryDirectory(prefix='session-',dir=OUT) as name:
            root=Path(name);assert root.resolve().is_relative_to(OUT.resolve())
            sys.path.insert(0,str(P.AK));import run as RUN
            reply=types.SimpleNamespace(returncode=0,stdout=json.dumps({'result':'not accepted','modelUsage':{P.MODEL:{}}}),stderr='',resource_report={'resource_exceeded':False})
            with patch.dict(os.environ,{'AWM_SESSION_PIN':str(root/'pin')}),patch.object(RUN.RG,'run_capture',return_value=reply),patch.object(RUN.TK,'claude',return_value={}):out=RUN._drive_once('claude',root,'synthetic',False)
            self.assertEqual(out['returncode'],126);self.assertEqual(out['text'],'')
    def test_session_change_rejected(self):
        with tempfile.TemporaryDirectory(prefix='session-',dir=OUT) as name:
            root=Path(name);assert root.resolve().is_relative_to(OUT.resolve());pin=root/'pin';pin.write_text('original')
            sys.path.insert(0,str(P.AK));import run as RUN
            reply=types.SimpleNamespace(returncode=0,stdout=json.dumps({'session_id':'different','result':'not accepted','modelUsage':{P.MODEL:{}}}),stderr='',resource_report={'resource_exceeded':False})
            with patch.dict(os.environ,{'AWM_SESSION_PIN':str(pin)}),patch.object(RUN.RG,'run_capture',return_value=reply),patch.object(RUN.TK,'claude',return_value={}):out=RUN._drive_once('claude',root,'synthetic',False)
            self.assertEqual(out['returncode'],126);self.assertEqual(out['text'],'');self.assertEqual(pin.read_text(),'original')
    def test_first_success_pins_session(self):
        with tempfile.TemporaryDirectory(prefix='session-',dir=OUT) as name:
            root=Path(name);assert root.resolve().is_relative_to(OUT.resolve());pin=root/'pin'
            sys.path.insert(0,str(P.AK));import run as RUN
            reply=types.SimpleNamespace(returncode=0,stdout=json.dumps({'session_id':'new-id','result':'accepted','modelUsage':{P.MODEL:{}}}),stderr='',resource_report={'resource_exceeded':False})
            with patch.dict(os.environ,{'AWM_SESSION_PIN':str(pin)}),patch.object(RUN.RG,'run_capture',return_value=reply),patch.object(RUN.TK,'claude',return_value={}):out=RUN._drive_once('claude',root,'synthetic',True)
            self.assertEqual(out['returncode'],0);self.assertEqual(pin.read_text(),'new-id')

class MetricTests(unittest.TestCase):
    def test_claim_precedes_proof(self):
        from grade_results import metrics
        r={'rounds':[{'k':1,'verdict':{'verdict':'impossible_in_model'}},{'k':3,'protocol_valid':True,'proof_gate':{'ok':True,'theorem':'Main'}}]}
        m=metrics(r);self.assertEqual(m['first_impossibility_claim'],1);self.assertEqual(m['first_proof_gate_pass'],3)
    def test_withdrawal_not_proof(self):
        from grade_results import metrics
        r={'rounds':[{'k':1,'protocol_valid':True,'proof_gate':{'ok':True,'withdrawn':'undecided'}}]}
        self.assertIsNone(metrics(r)['first_proof_gate_pass'])
    def test_invalid_round_not_certificate(self):
        from grade_results import metrics
        r={'rounds':[{'k':1,'protocol_valid':False,'proof_gate':{'ok':True,'theorem':'Main'}}]}
        self.assertIsNone(metrics(r)['first_proof_gate_pass'])

if __name__=='__main__':
    # Keep synthetic transcripts out of the user console and separate from real evidence.
    log=OUT/'test-offline.log'
    with log.open('w',encoding='utf-8') as fo,contextlib.redirect_stdout(fo):
        # main() expects stdout.buffer; tests patch the wrapper but retain this facade.
        class Facade:
            buffer=None
            def write(self,s):return fo.write(s)
            def flush(self):return fo.flush()
        with contextlib.redirect_stdout(Facade()):
            result=unittest.TextTestRunner(stream=fo,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    report=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),models_called=False,game_servers_started=False,log=str(log))
    (OUT/'test-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report));raise SystemExit(not result.wasSuccessful())
