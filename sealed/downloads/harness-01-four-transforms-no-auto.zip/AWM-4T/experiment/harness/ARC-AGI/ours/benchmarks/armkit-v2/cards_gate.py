# -*- coding: utf-8 -*-
"""卡片闸（--cards-gate DIR）：每次 attempt 之后、追问之前，把凝炼与形式化的各阶段发给受试，逐阶段查交付。

v7e（2026-10-22，用户「甲乙一起做」）：
- 甲：原来十张卡原样并成五个阶段（DIR 下的 `01-*.md` … `05-*.md`）：
    01 对象（原卡 01–03）· 02 长规则（04）· 03 规则（05–07）· 04 Lean 定义与观测（08–09）· 05 主定理（10）
- 乙：k = 1 时五个阶段各发一条（全文）；k > 1 时只发两条：
    凝炼增量 = 阶段 01–03 的「必须做到」「做完之前跑这个」两节；形式化增量 = 阶段 04–05 的这两节。
    全文都在跑场的 `cards/` 里。
- 每个阶段要一行 `CARD-DONE: 0N`（k > 1 也可以 `CARD-UNCHANGED: 0N <理由，至少 40 字>`）。
  机械检查只查交付物在不在、文件动没动，**不看内容对不对**；没过就补问，最多 retry 次。
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

WATCH = ("objects", "derive", "rule", "analysis", "lean")
NAMES: dict = {}

# stage -> the deliverable checks of the original cards it is made of
STAGE_CARDS = {"01": ["01", "02", "03"], "02": ["04"], "03": ["05", "06", "07"], "04": ["08", "09"], "05": ["10"]}
# v7f (2026-10-22): stage 04 = card 08 only (no observation replay); stage 05 = proof model + main theorem
STAGE_CARDS_V7F = {"01": ["01", "02", "03"], "02": ["04"], "03": ["05", "06", "07"], "04": ["08"], "05": ["10f"]}
MODE = ["v7e"]
GROUPS_LATER = [["01", "02", "03"], ["04", "05"]]      # k > 1: two messages

PREFACE = """Condensation and formalization ({what}). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
{mode}
---
"""

MODE_FIRST = """This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: {nn}"""

MODE_LATER = """Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt {k}. Go through the stages below again ({stages}): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>"""

CARD_RETRY = """Stage {nn} is not finished: {why}
Do what the stage asks, write its outputs, and end with the line CARD-DONE: {nn}{unch}."""


def load(dirpath: str | Path) -> list[tuple[str, str, str]]:
    """[(nn, title, text)] sorted by nn; NAMES[nn] = file name."""
    out = []
    for f in sorted(Path(dirpath).glob("[0-9][0-9]-*.md")):
        nn = f.name[:2]
        text = f.read_text(encoding="utf-8")
        m = re.search(r"^#\s*(.+)$", text, re.M)
        out.append((nn, (m.group(1).strip() if m else f.stem), text))
        NAMES[nn] = f.name
    if Path(dirpath).name.endswith(("v7f", "v7h")):
        MODE[0] = "v7f"
    if not out:
        raise SystemExit("cards-gate: no cards in %s" % dirpath)
    return out


def snap(d: Path) -> dict:
    s = {}
    for top in WATCH:
        p = d / top
        if p.exists():
            for f in p.rglob("*"):
                if f.is_file() and "__pycache__" not in f.parts and f.suffix not in (".olean", ".ilean", ".pyc"):
                    try:
                        s[str(f.relative_to(d)).replace("\\", "/")] = hashlib.md5(f.read_bytes()).hexdigest()
                    except OSError:
                        pass
    return s


def _sections(text: str, names=("## 必须做到", "## 做完之前跑这个")) -> str:
    """The operative sections of a stage (every original card in it), with the card titles kept as headers."""
    out, lines, i = [], text.split("\n"), 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("# 卡 "):
            out.append(ln)
            i += 1
        elif any(ln.startswith(nm) for nm in names):
            j = i + 1
            while j < len(lines) and not lines[j].startswith("## ") and not lines[j].startswith("# "):
                j += 1
            out.append("\n".join(lines[i:j]).rstrip())
            i = j
        else:
            i += 1
    return "\n\n".join(out) + "\n"


def plan(cards: list, k: int) -> list[tuple[list, str]]:
    """[(stages, message)] for attempt k."""
    by = {nn: (t, x) for nn, t, x in cards}
    if k == 1:
        return [([nn], PREFACE.format(what="stage %s of %d: %s" % (nn, len(cards), t),
                                       mode=MODE_FIRST.format(nn=nn)) + x) for nn, t, x in cards]
    msgs = []
    for grp in GROUPS_LATER:
        grp = [g for g in grp if g in by]
        if not grp:
            continue
        what = "attempt %d, stages %s: %s" % (k, ", ".join(grp), "; ".join(by[g][0] for g in grp))
        body = "\n\n".join("# %s\n(full text: cards/%s)\n\n%s" % (by[g][0], NAMES.get(g, ""), _sections(by[g][1])) for g in grp)
        msgs.append((grp, PREFACE.format(what=what, mode=MODE_LATER.format(k=k, stages=", ".join(grp))) + body))
    return msgs


def _py(d, sub, exclude=("__init__.py",)):
    p = d / sub
    return [f for f in p.rglob("*.py") if f.name not in exclude and "__pycache__" not in f.parts] if p.exists() else []


def _lean(d, sub):
    p = d / "lean" / sub
    return list(p.rglob("*.lean")) if p.exists() else []


def _nonempty(d, rel):
    p = d / rel
    return p.exists() and p.is_file() and p.stat().st_size > 0


def structural_card(d: Path, nn: str) -> list[str]:
    """Missing deliverables of original card nn."""
    miss = []
    if nn == "01":
        if not _nonempty(d, "objects/parse.py"): miss.append("objects/parse.py is missing")
        if not _nonempty(d, "analysis/parse_report.txt"): miss.append("analysis/parse_report.txt is missing")
    elif nn == "02":
        if not [f for f in _py(d, "objects") if f.name != "parse.py"]: miss.append("no object module under objects/ besides parse.py")
        if not _nonempty(d, "analysis/field_split.txt"): miss.append("analysis/field_split.txt is missing")
        per_obj = [f for f in (d / "analysis").glob("*.txt") if f.name not in
                   ("record.txt", "field_split.txt", "parse_report.txt", "rules_readout.txt", "reverse.txt",
                    "lean_identity.txt", "lean_levels.txt")] if (d / "analysis").exists() else []
        if not per_obj: miss.append("no per-object analysis file analysis/<object>.txt")
    elif nn == "03":
        if not _nonempty(d, "analysis/record.txt"): miss.append("analysis/record.txt is missing")
        h = d / "analysis" / "history"
        if not (h.exists() and any(x.is_dir() for x in h.iterdir())): miss.append("no snapshot under analysis/history/")
    elif nn == "04":
        if not _py(d, "rule"): miss.append("no rule module under rule/")
        if not _nonempty(d, "analysis/rules_readout.txt"): miss.append("analysis/rules_readout.txt is missing")
    elif nn in ("05", "06"):
        if not _nonempty(d, "analysis/record.txt"): miss.append("analysis/record.txt is missing")
    elif nn == "07":
        if not _nonempty(d, "analysis/reverse.txt"): miss.append("analysis/reverse.txt is missing")
    elif nn == "08":
        if not _nonempty(d, "lean/Step.lean"): miss.append("lean/Step.lean is missing")
        if not _lean(d, "Obj"): miss.append("no .lean under lean/Obj/")
        if not _lean(d, "Rule"): miss.append("no .lean under lean/Rule/")
        if not _nonempty(d, "analysis/lean_identity.txt"): miss.append("analysis/lean_identity.txt is missing")
    elif nn == "09":
        if not _lean(d, "Obs"): miss.append("no .lean under lean/Obs/")
    elif nn == "10f":
        if not _lean(d, "Proof"): miss.append("no .lean under lean/Proof/")
        if not _nonempty(d, "analysis/proof_model_map.txt"): miss.append("analysis/proof_model_map.txt is missing")
    elif nn == "10":
        if not _lean(d, "Proof"): miss.append("no .lean under lean/Proof/")
        if not _nonempty(d, "analysis/lean_levels.txt"): miss.append("analysis/lean_levels.txt is missing")
    return miss


def structural(d: Path, stage: str) -> list[str]:
    out = []
    for c in (STAGE_CARDS_V7F if MODE[0] == "v7f" else STAGE_CARDS).get(stage, [stage]):
        out += structural_card(d, c)
    return out


MUST_TOUCH = {"01": "analysis/record.txt", "03": "analysis/record.txt"}   # cards 03, 05, 06 write it every round


def check(d: Path, stages: list, before: dict, after: dict, text: str, k: int) -> dict:
    changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
    per, why = {}, []
    for st in stages:
        done = bool(re.search(r"^\s*CARD-DONE:\s*%s\b" % st, text or "", re.M))
        um = re.search(r"^\s*CARD-UNCHANGED:\s*%s\b\s*(.*)$" % st, text or "", re.M)
        unchanged = bool(um) and len((um.group(1) or "").strip()) >= 40 and k > 1
        w = list(structural(d, st))
        if not (done or unchanged):
            w.append("no line CARD-DONE: %s%s" % (st, " (or CARD-UNCHANGED with a reason of 40+ characters)" if k > 1 else ""))
        if done and st in MUST_TOUCH and MUST_TOUCH[st] not in changed:
            w.append("%s was not updated during stage %s" % (MUST_TOUCH[st], st))
        per[st] = {"done": done, "unchanged": unchanged, "why": w}
        why += ["stage %s: %s" % (st, x) for x in w]
    if any(v["done"] for v in per.values()) and not changed:
        why.append("CARD-DONE was stated but no file under objects/ derive/ rule/ analysis/ lean/ changed")
    return {"stages": stages, "ok": not why, "why": why, "per_stage": per,
            "changed": changed[:40], "n_changed": len(changed)}


def retry_text(stages: list, why: list, k: int) -> str:
    nn = ", ".join(stages)
    return CARD_RETRY.format(nn=nn, why="; ".join(why),
                             unch=(" (one line per stage; or CARD-UNCHANGED: <stage> <reason>)" if k > 1 else ""))


# Four-transform branch: explicit consideration receipts, not semantic verification.
import four_transforms_gate as FT
_strict_enabled = False
_original_load, _original_plan, _original_check = load, plan, check
def load(dirpath):
    global _strict_enabled
    _strict_enabled = (Path(dirpath)/'PROTOCOL-four-transforms.json').exists()
    result = _original_load(dirpath)
    if _strict_enabled: MODE[0] = 'v7f'
    return result
def strict_begin(d, k):
    return FT.begin(d, k) if _strict_enabled else None
def plan(cards, k):
    return [(st, msg + (FT.prompt(k) if _strict_enabled and '03' in st else ''))
            for st,msg in _original_plan(cards,k)]
def check(d, stages, before, after, text, k):
    result = _original_check(d, stages, before, after, text, k)
    if _strict_enabled and '03' in stages:
        result['four_transformations'] = FT.check(d,k)
        result['why'] += result['four_transformations']['why']
        result['ok'] = not result['why']
    return result
