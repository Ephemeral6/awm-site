# -*- coding: utf-8 -*-
"""**一个脚本造全部三条臂。** 先看 `REVIEW.md`，口径没定之前不要真跑。

    python build.py --dry-run                 # 只打清单，不落地、不起服务
    python build.py --stage D:/arc-arena      # 造跑场（仍然不跑受试）
    python build.py --stage D:/arc-arena --serve   # 造 + 起服务

## 为什么重写

旧的做法是**三个脚本**造三条臂（`sc25-budget/setup.py`、`sc25-oracle/setup_and_run.py`、
`sc25-oracle/rounds.py`），于是「三条臂只差被给的东西」这句话没有代码保证。
这一份把核心件做成**同一份**，逐字节核过，差别只在一个附加包。

## 三条臂

```
bare       核心件
framework  核心件 + METHOD.md + lean/ 骨架 + work/
oracle     核心件 + MODEL.md + model/
```

核心件 = 合作者的 `README.md` 原件 + 他们的题面 `O_pilot.txt` 原件 + 跑场内预批。
**三条臂的核心件必须逐字节相同**，本脚本自己核，不同就拒绝。

## 纪律（写死在代码里，不是口头的）

- 跑场在 `--stage`（默认 `D:/arc-arena`），**不在** `D:/THU/2026 Summer` 这棵树里。
- `arms.json` 只给实验者，**绝不进跑场**。
- 造完逐跑场扫泄漏词与禁运文件，**扫到就拒绝**。
- 引擎源码 md5 开跑前核，和登记的不符就拒绝。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
BENCH = HERE.parent
ROOT = BENCH.parent.parent
PACK = ROOT / "collab" / "pilot4-astra-pack" / "pilot4-astra-pack"

SERVER = PACK / "cd82" / "code" / "server_pilot.py"
THEIR_README = PACK / "sc25" / "design" / "README_given_to_players.md"
PROMPT_CORE = HERE / "prompt_core.txt"          # = 他们的 O_pilot.txt 原件
PROMPT_ROUNDS = HERE / "prompt_rounds.txt"      # 多轮口径的附录，**十条臂逐字相同**
# **先验（2026-10-14 加，默认关）**：`--prior rules` 才会把它接在核心题面后面，
# 接在**臂专属说明之前** ⇒ 它落在「核心件逐字节相同」那道闸里面，十条臂逐字相同。
# 默认 `--prior none` 时本文件一个字都不读，旧读数的题面逐字节不变。
PROMPT_PRIORS = {"rules": HERE / "prompt_prior_rules.txt"}
# **先验发给谁（2026-10-14 加）**：
#   all      接在核心题面之后、臂专属说明之前 ⇒ 落在「核心件逐字节相同」那道闸里，
#            各臂逐字相同，先验是**题面的一部分**。
#   nonbare  只发给非裸臂，接在臂专属说明**之后** ⇒ 它是**处理的一部分**；
#            核心件闸照旧（裸臂与非裸臂的核心题面仍然逐字节相同）。
#            报告里必须明写这是一条只给非裸臂的处理差。
BARE_ARMS = ("bare", "bare_asked")
ASK_CORE = HERE / "ASK_core.txt"      # 三条臂都发
ASK_LEAN = HERE / "ASK_lean.txt"      # **只有 oracle / 框架臂多这一问**
ASK_TAIL = HERE / "ASK_tail.txt"

# 孪生两盘。**只读**，开服前核 md5。
SIDES = {
    "ok": (PACK / "sc25" / "code" / "variant" / "sc25.py",
           "bcfc8f30a27383c23e35a3858507bdc6"),
    "no": (BENCH / "sc25-budget" / "variant" / "sc25_L4_b18.py",
           "7a922000d167e160fa69886c3ff24686"),
    # **判别档**：slfh=25。真相是**可做**（合作者自己的 bfs 搜过：2068 状态、深度 28、95.1s），
    # 而裸臂 codex 那套论证给的下界是 32 ⇒ 它会把这一盘判成不可做。
    # 用来证「它的证明是错的」，不是用来证「它判不出来」。
    "mid25": (BENCH / "sc25-budget" / "variant" / "sc25_L4_b25.py",
              "6e7a4ba9268124d8f24d8e7ab52e4703"),
    # **判别阶梯（2026-10-14 加）**：19 / 20 / 21 三档。B* = 19，所以三档**全部可做**，
    # 而三条喊 impossible 的裸臂自报「最便宜毛 32 / 可用 28」⇒ 蕴含边界 slfh ≤ 21
    # ⇒ 它们会把这三档**全判错**。框架臂 dc3f71 那份 Lean 把 budget 换成 19/21/26
    # 照样编得过（实测），所以这三档对非裸臂也是考试。
    # 19 = B* 本身：**只有最优走法能过**，是最难的可做侧对照。
    # 每一份都是 mkvariant.py 只改第 1953 行那一个整数、字节数变化 +0。
    "b19": (BENCH / "sc25-budget" / "variant" / "sc25_L4_b19.py",
            "34a1a3d087d94294b1678aecb163c36f"),
    "b20": (BENCH / "sc25-budget" / "variant" / "sc25_L4_b20.py",
            "08738d362bb2cabceb36e7ddc3a9b1f2"),
    "b21": (BENCH / "sc25-budget" / "variant" / "sc25_L4_b21.py",
            "eeff53518c937b438df080f592208fd6"),
}

# 附加包：**臂之间唯一的差别**
EXTRA = {
    "bare": None,
    # **`bare_asked`（2026-10-14 加）**：跑场与 `bare` 逐字节相同 —— 不给 METHOD.md、
    # 不给 lean/ 骨架、不给 play/settle/geo。差别**只在追问**（run_multi.py 的 ASKS_LEAN）：
    # 它会被问第 4 问（写 Lean）并用五选量表。拆的是「没要求」这个混淆，不是处理内容。
    "bare_asked": None,
    "framework": {"doc": ("METHOD.md", HERE / "METHOD.md"),
                  "dirs": [("lean", HERE / "lean")],
                  "files": [("play.py", HERE / "fwkit" / "play.py"),
                            ("settle.py", HERE / "fwkit" / "settle.py"),
                            ("geo.py", HERE / "fwkit" / "geo.py"),
                            ("concepts/TEMPLATE.py", HERE / "fwkit" / "concepts" / "TEMPLATE.py"),
                            ("concepts/_lib.py", HERE / "fwkit" / "_lib.py")],
                  "mkdirs": ["work"],
                  "blurb": HERE / "extra_framework.txt"},
    # 第四条臂：**框架 + 已有模型**。拿 oracle 那份模型当起手稿，
    # 用 METHOD 的办法去验、去修、去补 —— 和 oracle 臂的差别在**口径**：
    # oracle 的 MODEL.md 说「规则完备且精确，别去验」；
    # 这一条的 MODEL_FW.md 说「这是起手稿，不保证对，验它修它补它」。
    # **拿合作者原版那一局的概念册当起手稿**（harness-v04/archive/sc25-20260912/concepts），
    # 不是 oracle 那份 pack-v2 —— 原版就是 assert_ + apply 的概念格式，正好是这套台架吃的东西，
    # 而且它是「当时打完那一局时的状态」，有真东西可修。
    # 只拿 concepts/，report/ formal/ scorecard.json model.json 全部扣留（那些是答案）。
    "framework_model": {"doc": ("MODEL.md", HERE / "MODEL_FW.md"),
                        "dirs": [("lean", HERE / "lean"),
                                 ("concepts", HERE / "ledger-sc25")],
                        "files": [("play.py", HERE / "fwkit" / "play.py"),
                                  ("settle.py", HERE / "fwkit" / "settle.py"),
                                  ("geo.py", HERE / "fwkit" / "geo.py")],
                        "mkdirs": ["work"],
                        "blurb": HERE / "extra_framework_model.txt",
                        "docs2": [("METHOD.md", HERE / "METHOD.md")]},
    # **lean/ 骨架也给 oracle 臂（2026-10-11 加，见 DECISIONS.md）。**
    # 第四轮它八次都答「我没有 Lean 证明」，理由一致而且**核实为真**：
    # 给它的 `model/lean2/` 里 `structure St` **没有预算字段**（「18 之内赢得了」说不出来）、
    # `Obs.Check` 与 `Proof.Levels` 被 import 但文件不在、**没有 lakefile**。
    # 那是我们的交付缺陷，不是它的失败。`lean2/` 按原样下发的要求**一个字不动**，
    # 所以修法是**加法**：把三条框架臂都编得过的那套通用骨架也给它。
    "oracle": {"doc": ("MODEL.md", HERE / "MODEL.md"),
               "dirs": [("model", BENCH / "sc25-oracle" / "pack-v2"),
                        ("lean", HERE / "lean")],
               "mkdirs": ["work"],
               "blurb": HERE / "extra_oracle.txt"},
}

PREAPPROVE = {
    "permissions": {
        "allow": ["Bash", "Read", "Write", "Edit", "Glob", "Grep",
                  "WebFetch(domain:127.0.0.1)"],
        "deny": [],
        "defaultMode": "acceptEdits",
    }
}

# 造完要扫的：出现任何一个就拒绝开跑
# 跑场里出现任何一个就拒绝开跑。
# **「实例」单独说明**：「实例化骨架」是中性用法，所以只拦「不可做实例 / 不可解实例」
# 那种连写，不拦单独的「实例」—— 第一版连 `METHOD.md` 里「实例化它们」都拦了。
LEAK_WORDS = ["不可解", "无解", "不可做", "最短解", "峰值", "slfh", "上限 18",
              "受试", "孪生", "对照实验", "实验设计",
              "不可做实例", "不可解实例", "这个实例",
              "impossible", "infeasible", "unwinnable", "unsolvable",
              "designed to be", "B*", "/declare"]
FORBIDDEN_FILES = {"sc25.py", "sc25_L4_b18.py", "probe.json", "INSTANCE.md",
                   "MODEL-GAP.md", "solution.json", "TRUTH.md", "levels_data.json",
                   "replay_data.json", "arms.json", "crosscheck.py", "build.py",
                   "CORRECTIONS-APPLIED.md", "REVIEW.md", "PLAN.md"}


def ask_text(arm: str) -> str:
    """跑完发哪一份追问。**判定的事只在这里出现，题面和 METHOD/MODEL 里一个字都没有。**

    裸臂      核心四问
    其余两条  核心四问 + 第 5 问（用自己那套形式化写出 Lean 证明）
    """
    t = ASK_CORE.read_text(encoding="utf-8")
    if arm in ("framework", "framework_model", "oracle"):
        t += ASK_LEAN.read_text(encoding="utf-8")
    return t + ASK_TAIL.read_text(encoding="utf-8")


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def tree_md5(d: Path) -> str:
    h = hashlib.md5()
    for root, dirs, files in sorted(os.walk(d)):
        dirs.sort()
        for n in sorted(files):
            h.update((Path(root).relative_to(d) / n).as_posix().encode())
            h.update((Path(root) / n).read_bytes())
    return h.hexdigest()


def plan(arms, stage: Path):
    """造之前先把要做什么摊开 —— `--dry-run` 就只打这一份。"""
    rows = []
    for (case, port, arm, side, agent) in arms:
        extra = EXTRA[arm]
        files = ["README.md", "_FIRST_MESSAGE.txt", ".claude/settings.local.json"]
        if extra:
            files.append(extra["doc"][0])
            files += [n for n, _ in extra.get("docs2", [])]
            files += ["%s/ …" % n for n, _ in extra["dirs"]]
            files += [n for n, _ in extra.get("files", [])]
            if extra.get("files"):
                files.append("service.json")
            files += ["%s/" % n for n in extra["mkdirs"]]
        rows.append({"case": case, "port": port, "arm": arm, "side": side,
                     "agent": agent, "dir": str(stage / case), "gives": files,
                     "ask": "核心四问" if arm == "bare"
                            else "核心四问 + 第 5 问（Lean）"})
    return rows


def build_one(case, port, arm, side, agent, stage: Path, core_hashes: dict,
              rounds: bool = False, prior: str = "none",
              prior_scope: str = "all"):
    d = stage / case
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)

    # —— 核心件：三条臂逐字节相同 ——
    (d / "README.md").write_text(THEIR_README.read_text(encoding="utf-8"),
                                 encoding="utf-8", newline="\n")
    prompt = (PROMPT_CORE.read_text(encoding="utf-8")
              .replace("{PORT}", str(port))
              .replace("{WORK}", str(d).replace("\\", "/")).strip())
    if rounds:
        # 多轮口径：合作者那份原题面一个字不改，附录加在后面，**十条臂逐字相同**
        prompt = prompt + chr(10) * 2 + PROMPT_ROUNDS.read_text(
            encoding="utf-8").strip()
    if prior != "none" and prior_scope == "all":
        prompt = prompt + chr(10) * 2 + PROMPT_PRIORS[prior].read_text(
            encoding="utf-8").strip()
    core_prompt = prompt                       # 加**臂专属**说明之前的那一份才是核心件
    extra = EXTRA[arm]
    if extra:
        prompt = prompt + "\n\n" + extra["blurb"].read_text(encoding="utf-8").strip() + "\n"
    if prior != "none" and prior_scope == "nonbare" and arm not in BARE_ARMS:
        prompt = prompt + chr(10) + PROMPT_PRIORS[prior].read_text(
            encoding="utf-8").strip() + chr(10)
    (d / "_FIRST_MESSAGE.txt").write_text(prompt, encoding="utf-8", newline="\n")
    (d / ".claude").mkdir()
    (d / ".claude" / "settings.local.json").write_text(
        json.dumps(PREAPPROVE, indent=1), encoding="utf-8")

    core_hashes.setdefault("README.md", set()).add(md5(d / "README.md"))
    core_hashes.setdefault("prompt_core", set()).add(
        hashlib.md5(core_prompt.replace(str(d).replace("\\", "/"), "{WORK}")
                    .replace(str(port), "{PORT}").encode("utf-8")).hexdigest())

    # —— 附加包 ——
    if extra:
        name, src = extra["doc"]
        shutil.copy2(src, d / name)
        for n2, src2 in extra.get("docs2", []):
            shutil.copy2(src2, d / n2)
        for n, src_dir in extra["dirs"]:
            shutil.copytree(src_dir, d / n)
        for n, src_f in extra.get("files", []):
            (d / n).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_f, d / n)
        for n in extra["mkdirs"]:
            (d / n).mkdir(exist_ok=True)
        if extra.get("files"):
            # 台架要知道服务在哪；端口受试本来就从题面知道
            (d / "service.json").write_text(
                json.dumps({"url": "http://127.0.0.1:%d" % port}), encoding="utf-8")
    return d


# 合作者原样给出的两包：model/（封存模型）和 concepts/（他们打那一局的概念册）。
# 这两包**按原样发**（和 model/lean2/ 同一个口径），所以泄漏词在这里**只报告、不拦**。
# 理由：里面偶尔出现的「无解」是原作者诚实的改版史（「据此差点判了一关无解」），
# 洗掉等于动合作者的工作成果，比留着更糟。
# 我们自己写的文件（METHOD.md / MODEL.md / 题面 / 骨架）照旧**扫到就拒**。
AS_IS_DIRS = ("model", "concepts")


def _hit(word: str, text_lower: str) -> bool:
    """词在不在文里。

    **ASCII 的词要带词边界**，中文的词用子串就够。
    不带边界会误伤：`B*` 这个词在 `**不依赖 mathlib**` 里能匹配上
    （小写之后 "mathlib**" 含 "b*"）—— 实测撞到过。
    """
    w = word.lower()
    if re.fullmatch(r"[a-z0-9*/ _.-]+", w):
        return re.search(r"(?<![a-z0-9])" + re.escape(w) + r"(?![a-z0-9])", text_lower) is not None
    return w in text_lower


def audit(d: Path):
    """禁运文件一律拦；泄漏词：我们自己写的拦，合作者原样给的两包只报告。"""
    bad_files = sorted(p.relative_to(d).as_posix() for p in d.rglob("*")
                       if p.is_file() and p.name in FORBIDDEN_FILES)
    hits, as_is = [], []
    for p in d.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in (".md", ".txt", ".py", ".json", ".lean"):
            continue
        try:
            t = p.read_text(encoding="utf-8").lower()
        except Exception:
            continue
        rel = p.relative_to(d).as_posix()
        into = as_is if rel.split("/")[0] in AS_IS_DIRS else hits
        for w in LEAK_WORDS:
            if _hit(w, t):
                into.append("%s: %s" % (rel, w))
    return bad_files, hits, as_is


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--arms", default="arms_plan.json",
                    help="臂表（case, port, arm, side, agent）")
    ap.add_argument("--dry-run", action="store_true", help="只打清单，什么都不落地")
    ap.add_argument("--serve", action="store_true", help="造完顺便起服务（仍不跑受试）")
    ap.add_argument("--prior", default="none", choices=["none"] + sorted(PROMPT_PRIORS),
                    help="接一段先验。默认 none = 旧行为")
    ap.add_argument("--prior-scope", default="all", choices=["all", "nonbare"],
                    help="all = 接进核心题面、各臂逐字相同；"
                         "nonbare = 只发给非裸臂、算**处理差**")
    ap.add_argument("--retries", action="store_true",
                    help="**多轮口径**：服务不带 --one-life（`/reset` 只重开当前关），"
                         "题面加上 prompt_rounds.txt 那段附录。配 run_multi.py 用。")
    ap.add_argument("--dump-ask", action="store_true",
                    help="把各臂的追问导到 <stage>/_ASK-preview/ 供人核对。"
                         "**默认不导** —— 真跑时追问不能出现在跑场里，"
                         "否则受试提前看见题，整轮作废。导出的位置在各跑场之外。")
    a = ap.parse_args(argv)

    stage = Path(a.stage)
    if "2026 Summer" in str(stage.resolve()):
        raise SystemExit("跑场不许放在项目树里（记忆会按路径注入受试上下文）")
    arms = json.loads((HERE / a.arms).read_text(encoding="utf-8"))["arms"]
    arms = [(r["case"], r["port"], r["arm"], r["side"], r["agent"]) for r in arms]

    print("=" * 92)
    for r in plan(arms, stage):
        print("%-22s :%s  %-10s %-4s %-7s" % (r["case"], r["port"], r["arm"], r["side"], r["agent"]))
        print("    给它：%s" % "、".join(r["gives"]))
        print("    跑完发：%s" % r["ask"])
    if a.prior != "none":
        print("先验：--prior %s --prior-scope %s ⇒ 接 %s（%s）"
              % (a.prior, a.prior_scope, PROMPT_PRIORS[a.prior].name,
                 "接进核心题面，各臂逐字相同" if a.prior_scope == "all"
                 else "**只发给非裸臂**，算处理差；裸臂不收"))
    print("=" * 92)
    if a.dry_run:
        print("--dry-run：什么都没落地。口径确认之后再去掉这个开关。")
        return 0

    for k, (p, want) in SIDES.items():
        got = md5(p)
        if got != want:
            raise SystemExit("%s 的引擎源码 md5 %s ≠ 登记的 %s，拒绝开跑" % (k, got, want))

    core = {}
    built = []
    notes = {}
    for (case, port, arm, side, agent) in arms:
        d = build_one(case, port, arm, side, agent, stage, core, prior=a.prior,
                      prior_scope=a.prior_scope,
                      rounds=a.retries)
        bad, hits, as_is = audit(d)
        if bad:
            raise SystemExit("%s 里有禁运文件：%s" % (case, bad))
        if hits:
            raise SystemExit("%s 里有泄漏词（我们自己写的文件，**拒绝开跑**）：" % case
                             + chr(10) + "   " + (chr(10) + "   ").join(hits[:12]))
        if as_is:
            notes[case] = sorted(set(as_is))
        built.append((case, port, arm, side, agent, d))
        print("造好 %-22s %d 个文件" % (case, sum(1 for _ in d.rglob("*") if _.is_file())))

    for k, v in core.items():
        if len(v) != 1:
            raise SystemExit("核心件 %s 在各臂之间**不相同**（%d 种），拒绝开跑" % (k, len(v)))
    print("核心件逐字节相同：%s" % {k: list(v)[0][:12] for k, v in core.items()})
    # **开跑前留一份完整快照**：整个跑场原样存一份，不只是 concepts/。
    # 发给受试的每一个字（题面、README、METHOD.md、MODEL.md、model/、concepts/、lean/、预批）
    # 都要能事后复查；受试跑起来之后会往跑场里写东西，不留快照就分不清哪些是它写的。
    # 快照落在 armkit/baseline/<case>/，**不在跑场里**。
    base_md5 = {}
    for (case, port, arm, side, agent, d) in built:
        dst = HERE / "baseline" / case
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(d, dst)
        base_md5[case] = {f.relative_to(d).as_posix(): md5(f)
                          for f in sorted(d.rglob("*")) if f.is_file()}
        print("开跑前快照 %-22s %d 个文件 → baseline/%s" % (case, len(base_md5[case]), case))

    if notes:
        print()
        print("**原样放行的两包里出现过这些词**（合作者的 model/ 与 concepts/，按口径不洗）：")
        for case_, ws in notes.items():
            for w in ws[:6]:
                print("   %-22s %s" % (case_, w))
        print("   —— 这是**已知的、写进读数**的一处提示面，不是漏网。")

    if a.dump_ask:
        nl = chr(10)
        dd = stage / "_ASK-preview"
        dd.mkdir(parents=True, exist_ok=True)
        (dd / "_README.txt").write_text(nl.join([
            "这个目录只为给人核对追问用。",
            "**它不属于任何一个跑场** —— 受试的工作目录是 <stage>/<case>/，",
            "题面明写不许出工作目录，所以受试看不到这里。",
            "真跑时不要加 --dump-ask。", ""]), encoding="utf-8")
        for k in ("bare", "framework", "framework_model", "oracle"):
            (dd / ("%s.txt" % k)).write_text(ask_text(k), encoding="utf-8",
                                             newline=nl)
        print("追问导到 %s（**不在任何跑场里**）" % dd)

    rec = {"t": time.strftime("%Y-%m-%d %H:%M:%S"), "stage": str(stage),
           # **核心件每一项必须只有一个哈希。** `list(v)[0]` 静默取一个，
           # 集合里有两个值也看不出来 —— 所以这里把全部值都写进去，
           # 并且不止一个就在读数里标成 **!! 不一致**。
           "core_md5": {k: (list(v)[0] if len(v) == 1
                            else {"!! 不一致": sorted(v)}) for k, v in core.items()},
           "engine_md5": {k: md5(p) for k, (p, _) in SIDES.items()},
           "model_pack_md5": tree_md5(BENCH / "sc25-oracle" / "pack-v2"),
           "ask_md5": {k: hashlib.md5(ask_text(k).encode("utf-8")).hexdigest()
                       for k in ("bare", "framework", "framework_model", "oracle")},
           "as_is_leak_notes": notes,
           "baseline_md5": base_md5,
           "arms": [{"case": c, "port": p, "arm": r, "side": s, "agent": g}
                    for (c, p, r, s, g, _) in built]}
    (HERE / "arms.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1),
                                    encoding="utf-8")
    print("arms.json 写在 %s（**只给实验者，不进跑场**）" % HERE)

    if a.serve:
        (HERE / "srvlog").mkdir(exist_ok=True)
        (HERE / "srvout").mkdir(exist_ok=True)
        for (case, port, arm, side, agent, d) in built:
            src, _ = SIDES[side]
            # **`--one-life` 只在单轮口径下加。** 多轮口径要的恰恰是它不在：
            # 不带它时 `/reset` 只重开当前关（关 1–3 的进度保留），可重开。
            cmd = [sys.executable, str(SERVER), "--game", "sc25",
                   "--variant-path", str(src), "--md5", SIDES[side][1]]
            if not a.retries:
                cmd.append("--one-life")
            cmd += ["--port", str(port), "--log", str(HERE / "srvlog" / case)]
            out = open(HERE / "srvout" / ("%s.out" % case), "w", encoding="utf-8")
            server = subprocess.Popen(cmd, stdout=out, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            out.close()
            (HERE / "srvout" / (case + ".process.json")).write_text(json.dumps(dict(case=case,pid=server.pid,port=port,server=str(SERVER),log=str(HERE / "srvlog" / case))), encoding="utf-8")
        print("服务起了 %d 个。**受试还没跑** —— 跑的那一步单独来。" % len(built))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
