"""Fast full-book regression, no field ablation. Run before/after EACH edit.

python tools/rejection_check.py --out analysis/rejection_before.json
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
Mutants are deterministic; observations are never sampled. Finite agreement is
evidence on this corpus, not equivalence on every possible game state.
"""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import criteria_run as C
from _v7io import ObjLayer,load_rules,load_transitions

def fingerprint(d):
    files=[]
    for top in ('objects','derive','rule','concepts','lean/Obj','lean/Rule'):
        files.extend(p for p in (d/top).rglob('*') if p.is_file() and p.suffix in ('.py','.lean'))
    if (d/'lean/Step.lean').exists():files.append(d/'lean/Step.lean')
    return {p.relative_to(d).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}

def evaluate(d):
    obj=ObjLayer(d/'objects');rules,problems=load_rules(d/'rule',obj);trs,meta=load_transitions(d/'transitions.jsonl')
    if not rules:problems.append('empty rule book')
    if not trs:problems.append('empty transition corpus')
    census=C.parse_census(obj,trs);per,table,silent,gaps=C.readings(trs,rules,census)
    real=C.real_rejections(trs,table,census);muts=C.make_mutants(trs);mr=C.rejections(obj,rules,muts,lambda t:t.get('ctx'))
    mutant_reject=set(mr['by_parse'])
    for v in mr['by_rule'].values():mutant_reject.update(v)
    errors=sum(v['ERROR']+v['bad_scope_returns'] for v in per.values())
    return dict(version='v7h',source_sha256=fingerprint(d),corpus_sha256=hashlib.sha256((d/'transitions.jsonl').read_bytes()).hexdigest(),
        transitions=meta,rule_paths=sorted(r['path'] for r in rules),problems=problems,errors=errors,parse_failures=len(census['b']),
        real_rejected=[trs[i]['tid'] for i in range(len(trs)) if trs[i]['seq'] in real['union']],
        mutant_rejected=sorted(mutant_reject),silent=[trs[i]['tid'] for i in range(len(trs)) if trs[i]['seq'] in silent],
        verdict_matrix={r['name']:{t['tid']:table[r['name']][i] for i,t in enumerate(trs)} for r in rules},
        scope='Full recorded corpus and deterministic mutations; no proof of universal model equivalence.')

def main():
    from _v7io import utf8_stdout
    utf8_stdout()
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--compare');p.add_argument('--repair-note');a=p.parse_args();d=Path.cwd()
    result=evaluate(d);why=list(result['problems'])
    if result['errors'] or result['parse_failures']:why.append('rule exception/invalid scope or playable-frame parse failure')
    if a.compare:
        old=json.loads(Path(a.compare).read_text(encoding='utf-8'))
        if old['corpus_sha256']!=result['corpus_sha256']:why.append('corpus changed; recompute baseline on identical full corpus')
        deltas={name:dict(removed=sorted(set(old[name])-set(result[name])),added=sorted(set(result[name])-set(old[name]))) for name in ('real_rejected','mutant_rejected')}
        result['rejection_deltas']=deltas
        changed=any(v['removed'] or v['added'] for v in deltas.values())
        justified=False
        if a.repair_note:
            note=Path(a.repair_note).resolve()
            if note.is_relative_to(d.resolve()) and note.is_file() and len(note.read_text(encoding='utf-8').strip())>=80:
                justified=True;result['repair_note']=dict(path=a.repair_note,sha256=hashlib.sha256(note.read_bytes()).hexdigest(),review='Justification recorded, not machine-proved.')
            else:why.append('repair note must be inside arena and contain80+ characters of evidence and delta explanation')
        if changed and not justified:why.append('rejection set changed; condensation rejected, or supply an explicit evidence-based --repair-note')
        if not set(result['silent'])<=set(old['silent']):why.append('uncovered transition set increased')
        result['compared_to']=a.compare
    result['ok']=not why;result['why']=why;out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(ok=result['ok'],rules=len(result['rule_paths']),transitions=result['transitions'],why=why),ensure_ascii=False))
    return 0 if result['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
