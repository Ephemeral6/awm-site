# -*- coding: utf-8 -*-
"""核受试自己写的 Lean：编得过吗，公理干净吗。

    python leancheck.py --case a-or-no-claude
    python leancheck.py --case a-or-no-claude --json

## 为什么要台架这边自己编

多轮实验的停止条件之一是「**交出了不可做的严谨 Lean 证明**」。
只看它在追问里**说**「编过了、公理干净」那是自述，不是读数。
所以这一份自己把它写的文件编一遍，用的是 `METHOD.md` 里给受试的那条工具链。

## 「它自己写的」怎么认

靠**开跑前的全貌快照**（`baseline/<case>/`，`build.py` 存的）：
快照里没有、或者 md5 变了的 `*.lean`，就是它的产出。不靠猜文件名。

## `LEAN_PATH` 和依赖顺序怎么处理

受试那边不是 lake 工程，`import` 全靠 `LEAN_PATH` 解析，而且 **`import` 要的是 `.olean`
不是 `.lean`** —— 得先按依赖顺序把被 import 的模块编成 `.olean`。
上一轮 oracle 臂的文件还**跨两个包根**（`L4.*` 在 `work/lean/`，`Obj.*` 在 `model/lean2/`），
单根单文件一编就是 `unknown module prefix`。

所以这一份自己做了 lake 的那一小块：

```
① 收集候选根：lean/ · model/lean2/ · work/lean/ · work/ · model/ · 目标文件的各级父目录 · 工作目录
② 解析每份文件的 import，在这些根里把模块名解析成文件
③ 拓扑排序，先编依赖（`-o 模块路径.olean`），再编目标
④ LEAN_PATH 一次给**全部**根（Windows 用 `;` 分隔）
```

依赖里有编不过的、或者有 import 解析不到的，都记下来，目标那一份算编不过。

## 判据（**跑之前登记的**）

```
编得过      退出码 0 且输出里没有 `error`
公理干净    输出里出现过至少一行 `#print axioms` 的结果，
            且**没有** sorryAx / ofReduceBool / trustCompiler / native_decide
```

「主定理是哪一条」没法自动认出来，所以口径取**严**：那份文件里打印出来的
**每一条**公理表都要干净，有一条脏就算不干净。输出逐字留底，我后面按六问量表再核。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import resource_guard as RG
HERE = Path(__file__).resolve().parent
LEAN = (Path.home() / ".elan" / "toolchains" / "leanprover--lean4---v4.34.1"
        / "bin" / "lean.exe")
DIRTY = ("sorryAx", "ofReduceBool", "trustCompiler", "native_decide")
IMPORT = re.compile(r"^\s*import\s+([A-Za-z_][\w.]*)", re.M)


def md5(p: Path) -> str:
    return hashlib.md5(p.read_bytes()).hexdigest()


def own_lean(workdir: Path, baseline: Path | None) -> list[Path]:
    """快照里没有、或者 md5 变了的 `*.lean`。"""
    out = []
    for f in sorted(workdir.rglob("*.lean")):
        rel = f.relative_to(workdir)
        b = (baseline / rel) if baseline else None
        if b is None or not b.exists():
            out.append(f)
        else:
            try:
                if md5(f) != md5(b):
                    out.append(f)
            except Exception:
                out.append(f)
    return out


def all_roots(workdir: Path, targets: list[Path]) -> list[Path]:
    cand = [workdir / n for n in ("lean", "model/lean2", "work/lean", "work", "model")]
    for f in targets:
        p = f.parent
        while True:
            cand.append(p)
            if p == workdir or workdir not in p.parents:
                break
            p = p.parent
    cand.append(workdir)
    seen, out = set(), []
    for p in cand:
        if p.exists() and p.is_dir() and str(p) not in seen:
            seen.add(str(p))
            out.append(p)
    return out


def module_file(roots: list[Path], mod: str):
    rel = Path(*mod.split(".")).with_suffix(".lean")
    for r in roots:
        if (r / rel).exists():
            return r, r / rel
    return None, None


def imports_of(f: Path) -> list[str]:
    try:
        return IMPORT.findall(f.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return []


def run_lean(roots: list[Path], root: Path, f: Path, olean: Path | None,
             timeout: int) -> tuple[int, str, float]:
    """在 `root` 里编 `f`。`LEAN_PATH` 一次给全部根。"""
    env = dict(os.environ)
    env["LEAN_PATH"] = os.pathsep.join(str(r) for r in roots)
    try:
        rel = f.relative_to(root).as_posix()
    except ValueError:
        rel = str(f)
    cmd = [str(LEAN)]
    if olean is not None:
        olean.parent.mkdir(parents=True, exist_ok=True)
        cmd += ["-o", str(olean)]
    cmd.append(rel)
    t0 = time.time()
    try:
        r = RG.run_capture(cmd, cwd=str(root), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", env=env, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "") + ("\nAWM_RESOURCE_LIMIT: reduce state space or factor proof; resource UNKNOWN, not a logical rejection." if r.resource_report["resource_exceeded"] else ""), time.time() - t0
    except subprocess.TimeoutExpired:
        return -9, "**超时 %ds**" % timeout, time.time() - t0


def build_deps(target: Path, roots: list[Path], timeout: int, built: dict) -> list[dict]:
    """按依赖顺序把 `target` 要的模块都编成 `.olean`。返回新编的那几步。"""
    steps = []

    def visit(mod: str, stack: tuple):
        if mod in built or mod in stack:
            return
        root, f = module_file(roots, mod)
        if f is None:
            built[mod] = {"module": mod, "found": False}
            return
        for m2 in imports_of(f):
            visit(m2, stack + (mod,))
        olean = f.with_suffix(".olean")
        if olean.exists() and olean.stat().st_mtime >= f.stat().st_mtime:
            built[mod] = {"module": mod, "found": True, "cached": True, "rc": 0}
            return
        rc, out, dt = run_lean(roots, root, f, olean, timeout)
        rec = {"module": mod, "found": True, "rc": rc, "wall_s": round(dt, 1),
               "errors": [l.strip()[:160] for l in out.splitlines() if "error" in l][:3]}
        built[mod] = rec
        steps.append(rec)

    for m in imports_of(target):
        visit(m, ())
    return steps


def compile_one(workdir: Path, f: Path, roots: list[Path], timeout: int,
                built: dict) -> dict:
    deps = build_deps(f, roots, timeout, built)
    bad = [d for d in deps if d.get("rc") not in (0, None)]
    missing = sorted({m for m in imports_of(f) if not built.get(m, {}).get("found", True)})
    rc, out, dt = run_lean(roots, f.parent, f, None, timeout)
    nerr = sum(1 for l in out.splitlines() if "error" in l)
    ax = [l.strip() for l in out.splitlines()
          if "depend on any axioms" in l or "depends on axioms" in l]
    dirty = sorted({w for w in DIRTY if w in out})
    compiles = rc == 0 and nerr == 0
    return {"file": str(f.relative_to(workdir)).replace("\\", "/"),
            "rc": rc, "wall_s": round(dt, 1),
            "deps_built": len(deps), "deps_failed": [d["module"] for d in bad],
            "imports_unresolved": missing,
            "compiles": compiles, "axiom_lines": ax, "dirty": dirty,
            "clean": compiles and bool(ax) and not dirty,
            "errors": [l.strip()[:200] for l in out.splitlines() if "error" in l][:6],
            "out": out[-6000:]}


def check_files(workdir: Path, rels: list[str], timeout: int = 900,
                built: dict | None = None) -> dict:
    """只核指定的那几份（多轮驱动每轮只核**这一轮新写/改过**的，免得重编一遍）。

    `built` 传进来可以跨轮复用已经编好的依赖。
    """
    files = [workdir / r for r in rels if (workdir / r).exists()]
    roots = all_roots(workdir, files)
    if built is None:
        built = {}
    res = [compile_one(workdir, f, roots, timeout, built) for f in files]
    return {"n_own": len(files), "skipped": [], "files": res,
            "roots": [str(r.relative_to(workdir)) if r != workdir else "." for r in roots],
            "any_clean": any(r["clean"] for r in res),
            "clean_files": [r["file"] for r in res if r["clean"]]}


def check(workdir: Path, baseline: Path | None, limit: int = 40,
          timeout: int = 900) -> dict:
    files = own_lean(workdir, baseline)
    skipped = []
    if len(files) > limit:
        skipped = [str(f.relative_to(workdir)).replace("\\", "/") for f in files[limit:]]
        files = files[:limit]
    roots = all_roots(workdir, files)
    built: dict = {}
    res = [compile_one(workdir, f, roots, timeout, built) for f in files]
    return {"n_own": len(files) + len(skipped), "skipped": skipped,
            "roots": [str(r.relative_to(workdir)) if r != workdir else "." for r in roots],
            "files": res,
            "any_clean": any(r["clean"] for r in res),
            "clean_files": [r["file"] for r in res if r["clean"]]}


def main(argv=None) -> int:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                  errors="replace", line_buffering=True)
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", required=True)
    ap.add_argument("--stage", default=__import__("os").environ.get("AWM_STAGE", "D:/arc-arena"))
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--limit", type=int, default=40)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    workdir = Path(a.stage) / a.case
    baseline = HERE / "baseline" / a.case
    r = check(workdir, baseline if baseline.exists() else None,
              limit=a.limit, timeout=a.timeout)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=1))
        return 0
    if not baseline.exists():
        print("!! 没有 baseline/%s —— 分不清哪些是它自己写的，下面是全部 .lean" % a.case)
    print("候选包根：%s" % " · ".join(r["roots"]))
    print("它自己写的 .lean 共 %d 份%s"
          % (r["n_own"], ("（只编了前 %d 份）" % len(r["files"])) if r["skipped"] else ""))
    for f in r["files"]:
        print()
        print("  %-40s rc=%-3s %5.0fs  先编了 %d 个依赖" % (f["file"], f["rc"], f["wall_s"],
                                                           f["deps_built"]))
        if f["deps_failed"]:
            print("      依赖编不过：%s" % ", ".join(f["deps_failed"][:6]))
        if f["imports_unresolved"]:
            print("      找不到的 import：%s" % ", ".join(f["imports_unresolved"][:6]))
        print("      编得过=%s  公理干净=%s%s"
              % (f["compiles"], f["clean"],
                 ("  **脏：%s**" % ",".join(f["dirty"])) if f["dirty"] else ""))
        for l in f["axiom_lines"]:
            print("      %s" % l)
        for l in f["errors"]:
            print("      %s" % l)
    print()
    print("⇒ 有编得过且公理干净的：%s%s"
          % (r["any_clean"], ("（%s）" % ", ".join(r["clean_files"])) if r["any_clean"] else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
