# 四变换 AWM 8+4：隔离分支

先读 [审计、逐步prompt、差异、时间与论文影响报告](REPORT-审计与重跑方案.md)。完整提示见 [PROMPTS-ALL.md](PROMPTS-ALL.md)，核验结果见 [VALIDATION.json](VALIDATION.json)。这轮没有运行模型。

从此文件所在目录执行；Python应能运行原台架所需依赖，实跑需要Lean4.34.1和已登录的Claude CLI。原包仍在原路径，本分支只改 `harness/` 副本。不要运行复制包原来的 `run_one.py`，其处理条件不同。

只做离线检查，不调用模型：

```powershell
python audit_history.py
python protocol.py --dry-run
python test_offline.py
python finalize_artifacts.py
```

计划在 `operator_only/batch-plan.json`：L4/L5各三个独立会话，端口9631—9636，实际跑场默认`D:/awm-4t-arena`，位于项目树之外。若换机器，应重新导出本机计划/绝对路径，并避免已有case/端口；切勿把 `operator_only/`、历史证据或完整harness源码下发给受试。

以下是**会调用付费模型的显式执行命令，仅供核验后使用，本轮未执行**。先从计划中复制确切case ID，单条串行启动：

```powershell
python run_experiment.py --execute-initial --case <case>
```

结束后 `results/` 有run与日志，`checkpoints/<case>/`有封存的初始arena、run、服务日志、会话ID及评分模板。有效8轮结束后服务有意保持，供同会话追加；不要重启服务。实验者复制评分模板填写status、归一化界及计费/证据。仅确认wrong_high_bound后：

```powershell
python run_experiment.py --execute-feedback --case <case> --adjudication <已填写的评分JSON>
```

这会在同一原服务与会话执行至多四次追加，自动沿用Opus5.5、8GiB调用树上限和新卡片。评分文件不发给受试，受试只收到generic cheaper-win信号和自审方法。反馈结束/异常按PID身份清理服务。若无需追加，或决定终止当前case，用：

```powershell
python run_experiment.py --finish-case --case <case>
```

不要遗留“等待评分”的服务；每条完成评分/追加并清理后再启动下一条。中途服务死掉或会话ID变了应标VOID，不静默重启续跑。跨进程的`--execute-feedback`依赖原case保存的会话与live server，不能靠复制workspace冒充同会话。

查看首判和proof gate时点；默认只读记录：

```powershell
python grade_results.py --record results/<case>-initial8.json
```

最终证明独立重编，不调用模型，但会运行Lean；使用实际主定理文件/全名：

```powershell
python grade_results.py --rebuild-arena D:/awm-4t-arena/<case> --file lean/Proof/Main.lean --theorem Namespace.main --out results/<case>-independent-rebuild.json
```

该入口复制Lean源码、去掉已有olean再编依赖和检查axioms；语句是否覆盖任意合法轨迹、非空性、成本语义与模型对应仍需人工核验。严禁把“first claim”或无关定理编译通过当作正确游戏证明。

`patch_branch.py`和`finish_branch.py`是已经应用过的开发迁移记录，不要重跑。`STATUS-before-paper-review.md`仅为中途检查点，已被当前报告与VALIDATION取代。
