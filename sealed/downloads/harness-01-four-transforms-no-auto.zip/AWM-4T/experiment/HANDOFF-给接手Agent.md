# 给接手 Agent：检查并运行四变换 AWM 8+4 台架

更新时间：2026-10-24，Asia/Shanghai。

你接手的是实验台架审查与新队列运行，不是论文改稿。请先独立检查实现与协议，再按用户在你所在会话中的运行授权执行。此前用户明确要求本分支先完成审计、改造和干跑、不调用模型；**本交接文件本身没有启动实验**。如果用户已明确让你检查通过后直接实跑，就按该授权推进，不必重复索要同一授权。

## 1. 工作位置与阅读顺序

本分支根目录：

```text
D:\THU\2026 Summer\ARC-AGI\ours\collab-handoff-20261014\sc25_4transform_8plus4_20261024
```

优先读本目录下：

1. `REPORT-审计与重跑方案.md`：审计结论、旧流程、逐阶段调度、改动与耗时、论文影响。
2. `README.md`：正确运行入口、评分、追加四次和清理命令。
3. `PROMPT-DELTA.md`：旧实际输入与新提示的逐字差异。
4. `PROMPTS-ALL.md`、`prompts/manifest.json`：52份当前提示/说明的全文与SHA。
5. `VALIDATION.json`、`offline_out/test-results.json`：已有离线验证范围。
6. `protocol.py`、`run_experiment.py`、`four_transforms_gate.py`及被修改的原生驱动。

旧证据根目录：

```text
D:\THU\2026 Summer\ARC-AGI\ours\collab-handoff-20261014\paper_evidence_20261023
```

原始可移植台架：

```text
D:\THU\2026 Summer\ARC-AGI\ours\awm-v7f-portable
```

原包沿用旧文件夹名，复制时实际版本是v7h，包含此前v7g的四变换改造。**本实验使用本分支的 `harness/` 副本**，不要直接使用原包或其默认auto-repair入口。`source-manifest.json`保存复制时361个源文件的SHA；上次比对原包无变化。

论文不在当前修改范围。需要理解主张时，参考工作区的 `final_LLM/Algebraic_World_Model__From_Observations_to_Axioms_and_Proofs_new`；不要自行用新台架的计划或测试结果改掉论文实验数字。

## 2. 研究问题和已经确认的旧事实

目标是检验：当AWM逐attempt完整执行Explore & Prototype → Structure & Simplify → Formalize & Prove，尤其逐项审查最终四个transformation时，能否仍在两个密封关卡上交付闭合Lean模型证明，并得到正确的最小预算界。

旧记录并不是“六组全部完成8+4”，而是六条初始AWM run，其中只有两条初始错误界接受了选定的四次追加修复：

| 关卡 | case尾码 | 初始attempt | 初始界 | 选定修复 |
|---|---|---:|---:|---|
| L4 | 2a3cc5 | 3后停止 | 19 | 无；第3次在线闸有依赖编译失败，最终V3后来有独立检查 |
| L4 | 69fe87 | 8 | 19 | 无 |
| L4 | 9ec8d4 | 8 | 20 | L4 v7，4次报告21、19、19、19 |
| L5 | 284967 | 8 | 37，计赢步 | 不按任意一费误差判错，见费用约定 |
| L5 | 4f4628 | 8 | 36 | 无 |
| L5 | 977714 | 8 | 47 | L5 v3，目标关4次attempt存于一次聚合CLI continuation；改为37计赢步/36否则 |

六条最终模型内证明均有内核检查证据；既定正确界口径是初始4/6、选定修复后6/6。**请勿再次把它改成5条proof或3/6→4/6。** 这不意味着每轮在线都已有最终证明，也不意味着六条证明都已覆盖真实引擎全部行为。

旧流程在游玩时已有可执行Python概念册、bet/act/settle检查；逐轮第4问要求对象→规则→简化→Lean定义，第5问要求在该系统上证明。旧Simplify主要是删除未读字段、合并同判决规则，没有最终四方向的逐项交付与检查。旧机械闸允许“规则或Lean有更新且检查通过”，或 `FORMAL-UNCHANGED` 加足够解释；不能由此认定四个阶段每轮全部严格完成。

本分支的 `audit/history.json` 与 `audit/per-attempt.csv`保存43条初始attempt的索引，缺失字段没有编造。`prompts_old/`保存旧L4选定repair的实际输入与旧L5聚合调用的实际输入；不要用通用草案冒充两条实际输入原本完全相同。

## 3. 当前实现了什么，尚未验证什么

已完成：隔离复制、六新run计划、两关测试场地构造和泄题文件扫描、提示导出、四方向记录检查、失败停止、8后4续接、会话ID校验、只在合适错误界时追加反馈、结果读取与独立重编入口。

已有 **42项离线测试通过**，包括实际驱动循环的模拟测试。测试中模型/服务调用被替换；会话测试也使用模拟CLI返回。没有调用真实Claude、没有认证烟测、没有启动游戏服务、没有新实验Lean结果。`offline_out/`是测试材料，不是新的实验数据。

不要把“42项通过”理解成远端Opus入口已验证可用，也不要理解成语义正确性被机械证明。请检查完整 `VALIDATION.json`，而非只看绿色计数。

## 4. 代码地图

| 文件/位置 | 用途 |
|---|---|
| `protocol.py` | 配置构造器、六run计划、初始/追加命令、提示导出、封存和追加资格判定 |
| `run_experiment.py` | 默认干跑；显式启动一条初始run或其追加四次；单控制器互斥、内存预检、服务身份、session pin与清理 |
| `four_transforms_gate.py` | 四方向ID/决定、对象与规则考量、证据ID、编辑覆盖、语料/源码/回归收据新鲜度 |
| `harness/ARC-AGI/ours/benchmarks/armkit-v2/four_transforms_gate.py` | 上项的运行副本；两者必须同步 |
| `.../armkit-v2/cards_gate.py` | 原生阶段卡检查加四方向闸 |
| `.../armkit-v2/run_v2.py` | 逐attempt游玩、卡片、访谈、证明、失败停止、提示日志和9—12编号 |
| `.../armkit-v2/proof_gate.py` | MAIN-THEOREM编译/公理检查与当前审查记录检查 |
| `.../armkit/run.py` | 实际CLI调用；核对Opus5.5 modelUsage与保存的session ID |
| `.../armkit/resource_guard.py` | 继承v7h的调用树内存限制和资源修复 |
| `harness/.../sc25-selfaudit-v7/cards_fourtransforms/` | 当前五阶段卡片；不要换回别的cards目录 |
| `grade_results.py` | 区分首次声明与首次proof-gate通过；可选干净源码独立Lean重编 |
| `audit_history.py` | 重新提取旧43轮索引与两条repair时间 |
| `test_offline.py` | 离线逻辑与模拟驱动测试，不运行模型 |
| `finalize_artifacts.py` | 同步gate副本、生成diff/prompt汇编/校验与完成状态 |

`patch_branch.py`、`finish_branch.py`是已经应用过的迁移记录，**不要再次执行**。`STATUS-before-paper-review.md`为历史中途检查点，当前状态以本文件、报告和VALIDATION为准。

不要调用复制包原有的 `sc25-selfaudit-phase2/harness/run_one.py` / `run_replicates.py`来运行本队列：它们默认启用内置selfaudit/skeptic，改变前8轮处理条件。

## 5. 先独立检查这些薄弱点

请读代码，不要仅转述前一个agent报告。发现问题先保存diff并补充离线验证，任何会改变提示/停止规则/计分的修复都要登记协议版本，再冻结实际运行版本。

- **从导出的提示反查真实调度。** 首轮五张卡，后续两组；初始访谈中旧Simplify句已替换，避免“未读字段必可删除”与新卡片矛盾。检查导出原文和真正调用路径一致。
- **bootstrap是否可完成。** 第一轮对象/规则尚未建立，不能用空规则册/空语料的“全绿”充数；也不能设计成永远不能从空模型通过的闸。检查缺语料时失败能落盘，而非无记录崩溃。
- **四方向检查的真实范围。** 机械闸检查考虑记录、路径/证据与新鲜度；不证明理由有道理，也不自动证明每一次中间编辑都实际跑过回归。检查真实工具输出，审阅“不适用/不变”理由，不能为凑四项强迫四次修改。
- **proof语句不能偷换。** 编译一条无关的True定理不构成不可做证书；检查任意合法动作列表量词、初态、目标、成本、非空性/正向witness以及Python/Lean对应。当前proof gate主要检查文件/编译/axioms，语义仍需独立审阅。
- **会话与资源恢复。** 核对首次成功响应的session pin、续接的实际session ID、实际modelUsage，以及资源中断/重试时是否保持会话。不能只凭 `first=False` 推断没有重开。
- **服务身份与checkpoint。** 初始8轮结束后留同一服务等待评分；追加不得靠重启服务、恢复workspace冒充连续同会话。检查PID/端口/case身份与封存SHA。
- **外层启动器尚未联机验证。** 核对构造器所有必需路径/MD5、CLI可执行路径、依赖、服务启动等待、异常/Ctrl-C清理、controller锁与内存预检。尤其原驱动保留过“首轮游玩少于60秒判dead”的历史启发式，模拟测试用65秒，需审查是否会误判真实快速返回。
- **失败分类与分母。** gate/resource/session/服务故障不能被写成游戏undecided；失败仍保留在计划队列中，不能只留成功样本或静默换case补到成功。
- **计时与动作边界。** 继承的driver可在催问后记录未闭合/放弃并reset；核对attempt数、目标关attempt、跨关replay、动作和reset实际记录，不把CLI调用数当attempt。

这些是交接审查重点，不表示已确认每一项都有bug；若检查未发现问题，写清检查与证据即可。

## 6. 冻结的实验条件

- 两个密封sc25实例：不改游戏源码、地图或预算，构造器核MD5。
- 受试 **Claude Opus 5.5**，模型ID `claude-opus-5-5`；实际modelUsage不符应拒收，不静默换Opus5或Astra。
- L4/L5各三个独立新会话，每条最多8次初始attempt。此处没有可复现的CLI数值seed，不要将重复编号写成已控制的模型seed。
- 初始METHOD统一采用L5 closed-v4基础加新卡片，不带旧元素先验。
- **前8轮不启用selfaudit-gate/skeptic-gate，也不发送“界过高”信号。** 卡片中的全规则审查/怀疑并未因此删除，仍是处理的一部分。
- 每轮逐项审查：decomposition、composition、generalization、specialization。允许applied、considered_no_change、not_applicable，有具体对象/规则说明与证据；不要求每个方向都实施编辑。
- 所有规则留在全量回归中；impossible类判定前也审查deferred规则。有限语料一致不等于所有状态等价。
- 后4轮只给经核验“归一化最小预算过高”的run，先封存初始结果，再发generic cheaper-win信号与自审方法，不给真实界、轨迹或错误规则名。
- 后4轮自审方法包含通用触发情形枚举提示；新旧提示并非完全相同。本队列是最终流程的一致性验证，**不是只改变四变换的单变量消融**。
- 每CLI/编译调用树8GiB提交内存硬限及RSS检测，最多两次资源修复；不提高内存上限强行完成，不删合法路线缩减证明问题。

## 7. 当前六条计划

以下是交接时 `operator_only/batch-plan.json` 的截图，运行前仍以该JSON为准：

| 关卡/重复 | case | 端口 |
|---|---|---:|
| L4/1 | l4s-case-340db3 | 9631 |
| L4/2 | l4s-case-df5fbc | 9632 |
| L4/3 | l4s-case-8d2cce | 9633 |
| L5/1 | l5e-case-d693f7 | 9634 |
| L5/2 | l5e-case-82c98e | 9635 |
| L5/3 | l5e-case-6d7e2f | 9636 |

实际跑场默认为 `D:/awm-4t-arena/<case>`，位于项目树外；分支里的 `offline_out/stage-*` 只是测试场地，**不要直接拿它跑受试**。

同机不另起第二套相同case/端口；换机器要重建本机绝对路径和计划元数据，核对case全局唯一及原计划的对应。不要覆盖已有结果、pin、checkpoint或arena来冒充重跑。记录主机、Python/依赖/CLI/Lean版本、协议SHA及开始结束时间。

## 8. 操作顺序

### A. 离线审查和干跑

在本分支根目录执行：

```powershell
python audit_history.py
python protocol.py --dry-run
python test_offline.py
python finalize_artifacts.py
```

本机前次使用的Python为：

```text
C:/Users/11596/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe
```

原包说明要求Windows、Python≥3.10、arcengine0.9.3、numpy2.2.3、Lean4.34.1、已登录Claude CLI；**请核对安装现状，不要将此清单当成已实测通过**。`claude --version`、本地依赖检查不等于付费模型烟测。本文不要求你为了写审查报告而先进行付费认证请求。

### B. 有用户运行授权后，先启动一条

```powershell
python run_experiment.py --execute-initial --case l4s-case-340db3
```

该入口会启动真实服务和付费模型。建议先用这一条作为队列首条，核对实际输入、模型/session、stage交付、资源事件和结果落盘，随后按冻结版本继续其余五条。它是六条计划内的一条，不能看到结果后把它当作不计分pilot；如因协议bug作废，要保留记录和理由。

当前入口有单控制器互斥，按单条串行设计；可用内存不足12GiB会拒绝启动。不要绕开锁或调用原并发入口。若用户另要求并行，先单独审查共享构造器/日志、场地/端口/模型会话和内存调度，再变更版本；三并行应至少有28GiB可用内存。

### C. 初始8轮结束，立即评分或清理

`results/<case>-initial8.json`保存读数，`checkpoints/<case>/`封存初始arena、服务日志、run及session ID；生成 `adjudication-template.json`。

有效初始队列结束后，原服务**有意保持**，用于同会话追加。先检查protocol_valid、实际8轮/停止原因、最终界及单位，再复制模板填写独立评分文件。不要在等待评分时遗留服务数天，也不要在此间继续给受试发未登记消息。

评分status：

- `correct`：既定费用约定下正确，不发“存在更便宜赢法”的信号。
- `wrong_high_bound`：有证据确认归一化后的界过高，允许追加。
- 未定、费用单位不清、界过低或协议失败：保留为相应状态，不能自动套用可能为假的反馈。

operator参考最优值是L4=19、L5=36，密封预算为18/35。L5报告37仅在明确因为赢步多收一费时可接受；不是任意±1。填写 `normalized_engine_bound` 时先按其自身计费转换，不能因为原报37便自动启动修复。

评分文件必须绑定模板里的 `initial_record_sha256`，并写evidence：访谈原文、成本单位、赢步约定、主定理/见证与来源。此字段是对解析后record规范化JSON的哈希，**不要拿原文件字节SHA替换**。

### D. 符合条件时，追加四次

```powershell
python run_experiment.py --execute-feedback --case <case> --adjudication <已填写的评分JSON>
```

使用同一live server、arena与session。全局attempt9—12，repair局部1—4；访谈使用统一新M1/M2/M3方案及每轮卡片。评分JSON/真实界不会下发给受试。REPAIR-DONE不绕过本轮闸；当前实现按最多四轮固定调度，不能将CLI消息数当attempt数。

服务死掉或session pin不符，不静默重启继续。标VOID或协议/基础设施中断，保留原始记录；是否另开run按用户授权和预先登记的失败处理执行。

### E. 不需追加或追加完成后的服务清理

```powershell
python run_experiment.py --finish-case --case <case>
```

此命令用于停止该case保存并经身份核对的服务，不是按进程名扫杀。对正在运行的模型任务，先检查控制器状态和正常中断路径；不要把只停服务当成所有CLI/Lean子进程都已结束。核对case、PID/命令行、端口，避免误杀其他agent任务。

完成当前case的评分/追加/清理，再做下一条。不要让“等待评分”的服务被误认作垃圾后重启，然后继续冒充同一连续run。

## 9. 证明与数值必须分别核查

```powershell
python grade_results.py --record results/<case>-initial8.json
python grade_results.py --rebuild-arena D:/awm-4t-arena/<case> --file <真实主定理文件> --theorem <真实全名> --out results/<case>-independent-rebuild.json
```

第二条不调用模型，但会执行Lean、可能耗时。它复制源码并排除已有olean/ilean后重编依赖与检查axioms；不能用浅层目录编译漏掉嵌套import，也不能用旧缓存成功冒充当前源码成功。

至少区分：

1. first impossibility claim——首次声明；
2. first proof-gate pass——该轮当前选定定理通过机械检查；
3. 最终主定理语义审查、非空性与干净源码独立重编；
4. stated/normalized bound、费用约定、与引擎最优值的数值一致性。

`first claim`不能替代证明完成时间。闭合Lean模型证明不能直接等同真实游戏的不可达性证书；模型覆盖/过近似转移还需另证。模型规则错应称wrong model/premise，不要称kernel-checked proof本身逻辑出错。

## 10. 预计耗时与论文边界

尚无此新协议的真实运行时。旧完整8轮约1.6—4.3小时，既有卡片队列约4.57小时，选定旧repair分别1h37m和49m，仅作量级参考。

计划估计：每条初始8轮3—6小时，符合条件的后4轮再1—2小时；六条串行初始18—36小时，两个repair约20—40小时，六条全部repair约24—48小时。网络、证明规模、资源修复和独立重编可能进一步延长。不要把这些估计写成实测。

新队列可能改变初始正确界、证明成功率、首判与完成时间，不能预先承诺仍6/6或4/6→6/6。旧队列与新队列分表，不能拼成功、跨协议凑分母，或用旧within4补新队列未完成的repair。

若需要四变换的因果效果，应另设计同新版其他组件/提示与预算一致的对照。本次新队列还改变卡片、闭合证明/全规则闸、统一METHOD和服务续接等，因此不能单凭其优于旧结果便归因四变换。

## 11. 给用户的交付

请将检查/修复与实验结果分开报告，写入本分支的新子目录，例如 `receiver_review_<日期>/`，保留源码diff、提示SHA与测试输出。

- 审查报告：发现/未发现的问题、严重性、修复、验证范围；说明是否已做真实模型调用。
- 运行manifest：六条计划、实际执行/作废/中断状态、协议与提示SHA、工具/模型版本、主机、时间、tokens/动作/资源事件。
- 每条run：完整输入答复、服务日志、attempt边界、session/model核验、各闸、最终界/单位/计费约定、最终Lean源码、compile/axiom输出、独立重编与语义审查。
- 初始与追加分开封存；报告追加资格及反馈原文，不能抹掉最初错误。
- 汇总表：所有计划样本都保留状态；模型证明率、数值正确率、首次声明与proof gate时点分列；缺失/失败明确标出。
- 论文建议另写讨论稿，不直接覆盖用户论文或重写旧证据。

不要清理/移动原证据、论文、原台架；修改与输出尽量留本分支或新子目录。禁止把本说明、operator_only、旧正确模型、真实界/路线或评估者搜索器交给受试模型。
