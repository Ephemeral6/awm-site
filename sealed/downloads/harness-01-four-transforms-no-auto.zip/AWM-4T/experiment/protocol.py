"""Offline planning/staging helpers. Importing this module never calls a model."""
from pathlib import Path
import hashlib,importlib.util,json,os,secrets,sys,shutil
R=Path(__file__).resolve().parent
OURS=R/'harness/ARC-AGI/ours';V2=OURS/'benchmarks/armkit-v2';AK=V2.parent/'armkit'
P2=OURS/'sc25-selfaudit-phase2';V7=OURS/'sc25-selfaudit-v7';CARDS=V7/'cards_fourtransforms'
VERSION='four-transforms-device-20261024-v1'
MODEL='claude-opus-5-5'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def modules():
    for p in (AK,V2):
        if str(p) not in sys.path:sys.path.insert(0,str(p))
    return load('four_stage_build',AK/'build.py'),load('four_lists4',V2/'l4/stage_l4.py'),load('four_lists5',V2/'l5/stage_l5.py')

def configured_build():
    B,S4,S5=modules()
    for src,want in [(S4.L4_SRC,S4.L4_MD5),(S5.L5_SRC,S5.L5_MD5)]:
        assert hashlib.md5(src.read_bytes()).hexdigest()==want,src
    B.SIDES['no5']=(S5.L5_SRC,S5.L5_MD5)
    B.FORBIDDEN_FILES|=S4.L4_TRUTH_FILES|S5.NEW_TRUTH_FILES
    for w in S4.L4_LEAK_WORDS+S5.NEW_LEAK_WORDS:
        if w not in B.LEAK_WORDS:B.LEAK_WORDS.append(w)
    ex=B.EXTRA['framework'];ex['doc']=('METHOD.md',R/'METHOD-initial8.md')
    ex['dirs']=[x for x in ex['dirs'] if x[0]!='cards']+[('cards',CARDS)]
    ex['files']=[x for x in ex['files'] if not x[0].startswith('tools/')]+[('tools/'+p.name,p) for p in (V7/'tools_v7').iterdir() if p.is_file() and p.suffix in ('.py','.md') and p.name!='README.md']
    return B

def create_plan(path,stage='D:/awm-4t-arena',base_port=9631):
    path=Path(path)
    if path.exists():return json.loads(path.read_text(encoding='utf-8'))
    cases=[dict(case=f'l{level}{"s" if level==4 else "e"}-case-'+secrets.token_hex(3),port=base_port+i,arm='framework',side='no' if level==4 else 'no5',agent='claude',win_level=level,replicate=rep)
           for i,(level,rep) in enumerate((l,n) for l in (4,5) for n in (1,2,3))]
    plan=dict(version=VERSION,stage=stage,model=MODEL,attempts_initial=8,attempts_feedback_max=4,seed_policy='independent CLI sessions, no numeric model seed claim',arms=cases)
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(plan,indent=2),encoding='utf-8');return plan

def command(plan_path,row,stage,out,feedback=None):
    cmd=[sys.executable,'-u',str(V2/'run_v2.py'),'--arms',str(Path(plan_path).resolve()),'--stage',str(stage),'--rounds','4' if feedback else '8','--win-level',str(row['win_level']),'--only',row['case'],'--out',str(Path(out).resolve()),'--mem-archive',str(R/'runtime_archive/memory'),'--lean-timeout','1200','--cards-gate',str(CARDS),'--proof-gate']
    if feedback:cmd+=['--resume-session','--attempt-offset','8','--initial-prompt-file',str(Path(feedback).resolve()),'--round-prompt-file',str(R/'prompts/32-feedback-round.txt'),'--final-prompt-file',str(R/'prompts/33-feedback-final.txt')]
    return cmd

def stage_one(plan_path,row,stage,serve=False,fixture=False):
    """Build fresh data only. Real runs remain outside the project tree."""
    B=configured_build();stage=Path(stage)
    assert not (stage/row['case']).exists(),'Refusing to overwrite an arena'
    if fixture:
        assert stage.resolve().is_relative_to((R/'offline_out').resolve()) and not serve
        d=B.build_one(row['case'],row['port'],'framework',row['side'],'claude',stage,{},prior='none',prior_scope='all',rounds=True)
        bad,hits,notes=B.audit(d);assert not bad and not hits,(bad,hits)
        return d
    assert not stage.resolve().is_relative_to(R.parent.resolve()),'Real subject arenas must be outside the delivery package'
    assert '2026 Summer' not in str(stage.resolve()),'Use a short independent arena directory'
    one=R/'operator_only'/('plan-'+row['case']+'.json');one.parent.mkdir(exist_ok=True)
    one.write_text(json.dumps({'arms':[row]},indent=2),encoding='utf-8')
    args=['--arms',str(one),'--stage',str(stage),'--retries','--prior','none']
    if serve:args.append('--serve')
    assert B.main(args)==0
    return stage/row['case']

def feedback_text():
    doc=(R.parent/'paper_evidence_20261023/07_protocol_and_audits/sc25-repair-8plus4/PROMPTS-draft.md').read_text(encoding='utf-8')
    text=doc.split('### M1-awm',1)[1].split('```',2)[1].strip()
    text=text.replace('The service has been restarted from level 1; your earlier solutions for the earlier levels still work.','The same service has been kept alive; the current level is reset. Your session, files and recorded observations are preserved.')
    text+='\n\nAfter each attempt, complete the four-direction condensation and Lean stages in METHOD.md when the driver sends them. Use the existing model and all recorded evidence. The initial eight-attempt checkpoint is sealed; do not rewrite its reports.\n'
    return text

def repair_interviews():
    doc=(R.parent/'paper_evidence_20261023/07_protocol_and_audits/sc25-repair-8plus4/PROMPTS-draft.md').read_text(encoding='utf-8')
    m2=doc.split('## M2 ',1)[1].split('```',2)[1].strip().replace('[AWM only] ','')
    m3=doc.split('## M3 ',1)[1].split('```',2)[1].strip().replace('[AWM only] ','')
    m2+='\nThe condensation and Lean stages must already be complete. If the verdict is impossible, give the closed theorem from the current model: MAIN-THEOREM: lean/<file>.lean : <full name>. A model-only proof does not certify the game without coverage of its allowed behavior.\n'
    m2=m2.replace('If you need no further attempts, add a line: REPAIR-DONE','You may report REPAIR-DONE, but it does not waive this attempt\'s gates. The preregistered follow-up still records up to four attempts.')
    return m2,m3

def export_prompts():
    B=configured_build()
    CG=load('four_export_cards',V2/'cards_gate.py');cards=CG.load(CARDS)
    D=load('four_export_driver',V2/'run_v2.py')
    D.CG.load(CARDS)
    folder=R/'prompts';folder.mkdir(exist_ok=True)
    texts={'00-METHOD-initial8.md':(R/'METHOD-initial8.md').read_text(encoding='utf-8'),
           '00-task-core.txt':B.PROMPT_CORE.read_text(encoding='utf-8'),
           '00-task-rounds.txt':B.PROMPT_ROUNDS.read_text(encoding='utf-8'),
           '00-framework-blurb.txt':B.EXTRA['framework']['blurb'].read_text(encoding='utf-8'),
           '20-round-interview.txt':D.round_ask('framework'),'21-final-interview.txt':D.final_ask('framework'),
           '22-keep-playing.txt':D.KEEP_PLAYING,'23-old-gate-retry.txt':D.GATE_RETRY,
           '24-proof-retry.txt':D.PG.retry_text(['<actual gate reasons are inserted here>']),
           '30-feedback-first.txt':feedback_text(),
           '31-METHOD_selfaudit.md':(R/'operator_only/METHOD_selfaudit.md').read_text(encoding='utf-8'),
           '32-feedback-round.txt':repair_interviews()[0],'33-feedback-final.txt':repair_interviews()[1]}
    examples=list((R/'offline_out').glob('stage-*/*/_FIRST_MESSAGE.txt'))
    for level in (4,5):
        sample=next((p for p in examples if p.parent.name.startswith('l'+str(level))),None)
        if sample:texts[f'00-initial-L{level}-assembled-example.txt']=sample.read_text(encoding='utf-8')
    for k in range(2,13):
        if k!=9:texts[f'attempt-{k:02d}-start.txt']="Attempt %d: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt." % k
    for k in (1,2,3,4,5,6,7,8,9,10,11,12):
        for stages,msg in CG.plan(cards,k):texts[f'attempt-{k:02d}-stage-{ "+".join(stages)}.txt']=msg
    manifest=[]
    for name,s in texts.items():
        (folder/name).write_text(s,encoding='utf-8');manifest.append(dict(file=name,sha256=hashlib.sha256(s.encode()).hexdigest(),chars=len(s)))
    (folder/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def checkpoint(arena,out,dest,server_log):
    dest=Path(dest);assert not dest.exists(),'Checkpoint is immutable'
    dest.mkdir(parents=True)
    shutil.copytree(arena,dest/'arena');shutil.copy2(out,dest/'initial8.json')
    if Path(server_log).exists():shutil.copytree(server_log,dest/'server-log')
    rows={p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}
    (dest/'sha256.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    return rows

def adjudicate(record,decision,level):
    """Operator-only scoring; no subject text is parsed into a guessed answer."""
    if not record.get('protocol_valid') or record.get('stop')!='exhausted' or len(record.get('rounds',[]))!=8:
        return 'invalid_or_incomplete_no_feedback'
    if decision.get('status')=='correct':return 'complete_initial_no_feedback'
    if decision.get('status')!='wrong_high_bound':return 'manual_adjudication_no_feedback'
    truth={4:19,5:36}[level]
    if decision.get('initial_record_sha256')!=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest():
        raise ValueError('Adjudication is not bound to this locked initial record')
    if not decision.get('evidence') or not isinstance(decision.get('normalized_engine_bound'),int):raise ValueError('Explicit unit/terminal-charge conversion and source evidence required')
    if decision['normalized_engine_bound']<=truth:raise ValueError('The generic cheaper-win feedback would be false under the declared cost convention')
    return 'eligible_feedback4'

def dry_run(materialize=False):
    plan_path=R/'operator_only/batch-plan.json';plan=create_plan(plan_path);prompts=export_prompts()
    commands=[];fixtures=[]
    for row in plan['arms']:
        commands.append(dict(case=row['case'],initial8=command(plan_path,row,plan['stage'],R/'results'/(row['case']+'-initial8.json')),
                             feedback4=command(plan_path,row,plan['stage'],R/'results'/(row['case']+'-feedback4.json'),R/'prompts/30-feedback-first.txt'),feedback_condition='Only a complete valid locked8 run with a confirmed too-high normalized bound.'))
    if materialize:
        stage=R/'offline_out'/('stage-'+secrets.token_hex(3));stage.mkdir(parents=True)
        for level in (4,5):
            row=next(x for x in plan['arms'] if x['win_level']==level)
            d=stage_one(plan_path,row,stage,fixture=True)
            fixtures.append(dict(level=level,path=str(d),first_message_sha256=hashlib.sha256((d/'_FIRST_MESSAGE.txt').read_bytes()).hexdigest(),files=sum(p.is_file() for p in d.rglob('*'))))
    result=dict(version=VERSION,models_called=False,servers_started=False,prompt_files=len(prompts),commands=commands,offline_fixtures=fixtures)
    (R/'dry-run.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='commands'},ensure_ascii=True));return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--dry-run',action='store_true');p.add_argument('--materialize-fixtures',action='store_true');a=p.parse_args()
    dry_run(a.materialize_fixtures)
