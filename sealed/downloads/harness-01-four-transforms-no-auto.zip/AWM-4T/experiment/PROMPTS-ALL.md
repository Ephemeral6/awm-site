# Portable receiver prompts: exact text

Generated within this package; assembled first-message examples are produced by receiver preflight.

## 00-framework-blurb.txt

````text
Also read `METHOD.md`: that is how you are required to work (a requirement, not a suggestion). The files under `lean/` are generic skeletons - they contain no facts about this particular game, and you may use them. Put your own work in `work/`.

````

## 00-METHOD-initial8.md

````text
# 方法：先把规则从实验里提出来，再把它变成对象 / 规则 / Lean

> 这一份是**要求**，不是建议。`README.md` 讲这个服务怎么用；这一份讲**你要怎么做**。
> 两份冲突时以 `README.md` 的约束为准（只走 HTTP、不出工作目录）。

和「随便玩玩然后交个结论」的差别只有一条：

> **你对这一关的任何主张，都要有一份你自己能核、别人也能核的东西撑着。**
> 画面看着像不算，试了几次没出事也不算。

这套方法分两步，**顺序不能颠倒**：

```
第一步  从实验里把规则**提出来、修对** —— 这一步占掉这一局的绝大部分时间
台架    概念怎么写、两道闸怎么关 —— **这个目录里的脚本强制的**，不是靠自觉
第二步  把规则**凝炼成对象 / 规则，再变成 Lean** —— 每次 attempt 之后，台架逐张发卡
```

**先读第 8–12 节（台架）再动手。** 不知道闸在哪，第一个动作就会被拦下来。

**第一步没做完就进第二步，等于把猜测形式化。** 那会让猜测看起来像定理。

**跑的时候只做第一步。** 第二步在每次 attempt 结束之后、台架逐张发卡的时候做 ——
所以不要在游玩中途为了赶形式化而缩短实验。

**如果这个目录里已经给了你一份 `model/`**（见 `MODEL.md`）：
那份模型是**起手稿不是真值**，第一步对你来说就变成**验它、修它、补它** ——
办法完全一样，只是你不必从零发明规则。下面第 7 节专门说怎么改别人的规则。

**拿这套方法去帮你打通这一关。**

---

# 第一步：从实验里把规则提出来

下面这些不是建议清单，每一条后面都跟着「什么时候会翻车、翻车长什么样」——
那一半才是它值钱的地方。

## 0 开工之前的一次性投资

**0.1 先把观测坐标系钉死。** 拿一个坐标对去反查帧里那一格的实际颜色，
确认 `(a, b)` 是 `(x, y)` 还是 `(y, x)`。**定错了后面每一条规则都写反。**
带坐标的动作在顺序没定之前，先点对角线（两个分量相等）—— 这样把「坐标序」
和「点这里有没有用」两个未知拆开。

**0.2 一旦测出移动步长是 k 格，就把整帧折叠成格位图**，每格只报主色。
之后所有路径规划、「哪里是墙」「哪里有东西」都在这张图上看，不再逐格读帧。
折叠图一眼就露出地形、通路与标记，逐格读一张帧的开销是它的几十倍。

**0.3 跨约定的坐标不许靠眼睛搬运。** 两套分量顺序在数字接近时看不出差别，
而读错一次的失败模式**不是「算错了」，是凭空冒出一个不存在的现象** ——
那是最像重大发现、最会让你放下手头实验去追的东西。
判读不一致时，先用所有已知读法各读一遍，全读不通才准动结论。

## 1 怎么设计实验

**1.1 主动证伪，别等证据上门。**「什么条件下这一关会结束」这类规律，
很少会自己撞上反例 —— 因为你很少走到那个状态。对这类规律要**专门设计一段动作去撞它**。
形状：一族「怎样才算过关」的判断常年没被检验过，却一直当知识用着。

**1.2 优先走「两条已有规则给出相反预测」的那一步。** 它保证倒一条、也保证学到东西；
走两条都预测生效的路，最好的结果只是确认已知。

**1.3 连续几批零反例、而局面纹丝不动，是警告不是成功。**
说明你在反复确认已经知道的东西。去做一件你**不知道结果**的事。

**1.4 全部规则对某个候选动作都说不出话的那一步，是没人管的地图**，
不是已知规律的复查，值得优先走进去。

**1.5 绕不过去的时候，把失败本身当实验 —— 但要先押注。**
预算差几步、绕路也补不回来时，不要硬凑，也不要停下：
**先写一条关于「失败会长什么样」的可反驳预测，再走进去。**
押注必须写在动作之前，事后补写等于对着答案填空。
押「仪器会读出什么」，不押「世界是什么样」—— 只有前者可判。

## 2 读动作效果时最容易栽的几处

**2.1 动作被接受 ≠ 动作生效。** 至少三种结局：生效、被受理但没生效、完全不被受理
（前后两帧逐格相同）。把后两种并成「没生效」，和计数有关的规则一定会被推翻，
而且推翻的地方不告诉你真原因。

**「没生效」本身又分好几种成因，分开它们各要一步实验**：

```
键是死的        根本不认这个动作
有条件的        局面没摆到它的前提上
幂等的          当前值恰好已是它要设的值，做了等于没做
被吞掉的        世界刚被重新起头之后的第一个动作常常整帧无差
```

所以「这个动作没用」这个结论必须先过两问：
**局面摆到它的前提上了吗？这个结论在别的局面复现过吗？**

配套一条：一个「设成 X」型动作，在当前值已经是 X 的局面上按出来的空帧，**什么证据都不是**。
得专门在取值不同的局面上再测一次。

**2.2 先在空地上量全，再去窄处量阻挡。** 反过来做，会把地形的形状写进动作表。
还要把「这一步改了几样东西」和「这一步改了多少」分开问。

**2.3 把「这一步改了多少格」拆成整数和**（形如 总数 = 腾空 + 新占 + 计数器），再去猜语义。
格数能直接定出可动对象的尺寸、以及有没有搭便车的计数器，比从图样上猜快得多。
**每一项分开写、各带自己的依据，别写成一个总数** —— 总数错了你只知道「有地方不对」，
分项错了你知道是哪一项不对。

这一条有两种典型翻车：

```
① 那个「一直对」的常数项，只在无聊步上对。
   「新占 = 满格」隐含前提是「目标格是干净地板」，
   可**每一个值得走的步，按定义都是踩到不是干净地板的东西上**，
   于是这个常数专门在关键步上失效。
② 腾空那一侧同样不是常数：身下压着别的东西时，与自己同色的那些格不进帧差。
   被当成「吃掉了」的东西，可能只是被压住，走开后逐格恢复。
```

**2.4 别拿「帧差格数」当判据。** 阈值总是从某一次事件量出来的，换一档就静默失效。
改用结构判据（墙集合变没变、记号少没少），它们不依赖你没测过的量级。

**2.5 每次动作都会变一点的量**（计数器、进度条、资源），先问它依赖什么：
动作次数？只有生效的动作？某一类事件？**不要一上来就写死一个常数。**

**2.6 拿两三个点去外推第四个，是同一个病的另一副面孔。**
两个点能穿过无穷多条曲线。拿不出任何理由说明某个量为什么该跟关卡号走，
就不该把它写成关卡号的函数。找不到机制时，**把表写成表**，
并写明拟合用了哪几个点、还没考过的是哪几个点。
另外：一个「每步扣 q」的读数，往往等价于「本关的预算 = 某个总量 / q」——
**预算才是机制那一侧的量，被画出来的那条读数只是它的显示**。去量那个可能才是真变量的东西。

## 3 规则怎么写才可判错

**3.1 先声明作用域。** 这条规律是**本关之内**成立，还是**跨关**也成立？
没声明作用域，等于悄悄断言了「跨关也成立」—— 那是你还没验证过的强断言。
形状：换关那一步整批规则一起倒，因为它们全都默认了跨关。

**推论：换关之后不要沿用上一关量出来的任何常数。**
规则一条没倒（它们声明了作用域，是对的），倒的是**路线规划的全部算术** ——
而算术没人拦。进新关第一件事是把要用到的每个量重新量一遍。

**3.2 一条规则只许断言一件事。**「A 且 B」写在一起，倒的时候你不知道倒的是 A 还是 B，
会连带把还活着的那一半一起改掉。

**3.3 主张写成蕴含式（A ⇒ B）时，判据必须盖住 A 的每一种取值**，
不然「A 从没成立过」会被判成和「A 成立且 B 也成立」一样的通过。
**这个病最阴**：判据用了、只是漏了一支，代码看着完全正常，而且永远不报错。
把主张里每个「任何 / 所有 / 全部」圈出来，问代码靠什么认它 ——
答案要是「在我列出的那几样里」，那就是个洞。

**3.4 数出来的数属于主张，不属于前提。**「恰好 N 个」这类整数要写进主张去挨打，
不要写进判据的前提里。
否定式的作用域（「只要不是 X 就不变」）是在替所有你没见过的东西担保，
改成正面枚举，猜错的代价是弃权而不是错判。

**3.5 改到第三版还在挨打，就撤掉重写。** 那多半说明你问错了问题，而不是没修对。
撤掉不丢人，改到第七版才丢人。

**3.6 一条规则倒了的时候，先看同一批里没倒的那些** —— 它们是免费的约束，
能把未知量夹出来。别急着去要新证据，先把已有的断言当方程解。

## 4 防自欺

**4.1「到过」不等于「测到」。** 世界按你押的样子动了，不等于你验证了什么 ——
要问的是这条规则**被多少个它本来可能出错的局面考过**。
一条规则靠静默弃权（判据算不出来、返回「不适用」）撑着满分，是最常见的自欺。
报任何「零反例」之前，先报它弃权了多少次。

**4.2 收窄作用域会把样本压小；样本小到个位数时，错的机制也能拿满分。**
触发信号很具体：**改版理由里写着「某某情形不算」，并且改完样本只剩个位数**。
这时不要庆祝，要去问「有没有一个更简单的东西同时管住两边」。

**4.3 放宽作用域时，断言强度必须跟着降回证据支持的那一档。**
从邻居那里把更强的谓词原样搬过来，是最容易犯又最难自查的错 ——
因为**在邻居那里它是对的**：邻居的窄作用域恰好把反例挡在外面。
动手前问一句：这张证据当初是用哪个谓词统计的？断言不许比它更强。

**4.4 多步预测是推演，不是 N 个单步。**
把上一步的预测喂给下一步，得到的是**链口径**的分数；
每条规则各自的分数是**单步口径**（拿真实的上一帧算的）。两个数能差一个量级，混报等于自欺。
某一步塌了，先拿真实的上一帧对那一步单步重跑 —— 全对就说明损失全在链上，别去改规则。

**链子在没人说话的那一步断掉。** 某一块帧差没人认领，链子就把「不知道」压成「不变」，
从那一步起全部推理都在一张残帧上进行。**「不认领的格子被填成什么」必须有人负责**，
不写，实现会替你选，而且从不报错。

**4.5 空白有两种：「没人写」和「写不出来」，它们长得一模一样。**
碰到一整块没人管的地方，先分清是哪种；分不清就去写一次，写不出来的会自己撞上来。
写不出来的要**登记清楚被挡住的是哪一条具体主张** —— 只写「表达不了」，
下一个人会以为那只是没人写。

**4.6 服务不回答和服务不转发是两回事。** 动作发出去了但根本没到世界手里，
那一步什么都没被观测到；把它写成规则，就是把实现细节冒充成世界规律，
而且它永远判通过（世界从没有机会反驳）。

## 5 对账：先报后看

**拿你的规则预测下一帧，再真走一步对照。先写预测，再去走，再对比。**
反过来做（走完再解释）永远对得上，什么也证明不了。

**三个数都要报**：对账过多少帧、对上多少、对不上多少。
对不上的帧**不许删**，要逐条说清是规则错了还是你读错了。

## 6 丢掉机制的审计（进第二步之前必须做）

把你**观测到但没写进规则**的每一条机制列成一张表，逐条说方向：

```
丢掉它之后，模型**允许的迁移变多**  ⇒ 模型比真世界松，不会漏掉真走得通的路
                                   ⇒ **可以丢**（但要记下来）
丢掉它之后，模型**允许的迁移变少**  ⇒ 你把一条真能走的路从模型里删掉了
                                   ⇒ 模型会告诉你「这边走不了」而其实走得了
                                   ⇒ **不许丢**
```

自检：表里每一条都落在上面两行之一，没有「大概不影响」这种话。

**还要单独填这一行：动作可能没摸全。** 你见过的动作未必是全部。
没试过的动作、没试过的参数，列出来。

## 7 修规则（自己写的、别人给的，一视同仁）

一条规则和画面对不上的时候，有且只有三种可能，**先分清是哪一种再动手**：

```
① 你读错了      坐标序、折叠口径、把动画中间帧当成了稳定帧 —— 先排除这一类（见 0.3）
② 规则写窄了    它说的那一支是对的，只是还有别的支没写 —— 该**扩**，不是推翻
③ 规则写错了    它那一支本身就不对 —— 该**撤**
```

**最常见的是 ②，而最常被当成 ③。** 一条规则挨了打，先问「它说对了多少」。

改法四条，一条都不能省：

```
(a) 改之前先写下你凭哪一次观测认定它不对：哪一步、前后两帧差在哪、
    按旧规则该是什么样。**没有这一条就不许改。**
(b) 改完拿它在**你已经观测过的所有转移**上重跑一遍 ——
    对上的条数**不许变少**。变少了说明你修出了新毛病，那比原来的毛病更难发现。
(c) 旧版本不要删，挪进 NOTE 里，写清为什么撤。
    一条规则的改版史本身就是读数：改到第三版还在挨打，撤掉重写（见 3.5）。
(d) 改完回头看一眼这条规则的 `NOT_CLAIMED`：
    你刚补进去的东西，是不是正好是它原来声明「不主张」的那一块？
    是的话，把那一句也跟着改掉 —— 留着假话比没写更糟。
```

**别人给你的规则有一处要额外小心**：它的 `SCOPE` 和 `NOT_CLAIMED` 是**别人的**边界声明，
不是世界的性质。`NOT_CLAIMED` 密集的地方，通常正是那份模型最虚的地方 ——
那是线索，不是禁区。

---

# 台架：概念怎么写，两道闸怎么关

这不是建议，是**这个目录里的脚本强制的**。

## 8 一条概念的形状

一个文件一条，放 `concepts/<短名字>.py`：

```python
"""首行 docstring 就是主张，写成一句能被判错的话。**一条概念只断言一件事。**"""
LEVEL = "L1"          # 地图的哪一块：L1 动作效果 / L2 阻挡 / L4 计数器 / L5 终止 / L6 运动物 / L7 观测
SCOPE = "只看 ACTION1；换关返回 NA；定位不到返回 NA"
NOTE  = ""            # 改版时写清**为什么**改、被哪一步打了脸
EVIDENCE = ["…"]      # 它所依据的 tid，**不能为空**

from _lib import me, CELL      # 本局词汇：这些是假设，跟着概念一起被重审
from geo import diff_sum       # 跨局几何：里面没有任何关于世界的断言


def assert_(prev, action, nxt, ctx=None):
    """**检查器**：让主张可判错。只许返回 "TRUE" / "FALSE" / "NA"。"""
    ...


def apply(prev, action, ctx=None):
    """**生成器**（可选）：这条概念**敢生成**的那部分下一帧，只填它管得着的格子。

    返回 {(行, 列): 颜色} 或 None。
    """
    ...
```

**两半各管一件事，缺哪一半都有代价：**

```
只有 assert_         它只会判，不会生成 —— 对 E（规则图完成度）没有贡献
只有 apply           没有可判错的主张，等于没上闸
两半都有而口径不同    常有的事，而且**是好事**：
                    「判」比「生成」窄的概念活得久 —— assert_ 不看它让出去的格子，
                    apply 多画一格就多一次挨打的机会，两边的差是真线索
```

不变量式的概念（「墙集合不变」）生成不了就别写 `apply`。

`_lib.py` 是本局词汇（色号、边长、定位函数）。**它们是假设，不是事实**：
改 `_lib` 不算改版，但依赖它的概念要一起重审。两条概念都从同一个词取值再互相核对，
**S = 1 不等于这个词被检验过**；要检验一个词，得有一条概念拿它和帧上**另一种**读法对。

## 9 两道闸（脚本强制，不靠自觉）

```
闸一  **没有比最后一条转移更新的押注，`act` 发不出去。**
      python play.py bet "第几步、谁、变成什么样、依据哪条概念"
      只有整条命令就是 `act RESET` 才豁免。
      bet 和 act 是两条独立命令 —— act 在发之前查押注的时间戳，
      **事后补写等于对着答案填空**，闸会认出来。

闸二  **有没结算的转移、没处理的反例、跑不起来的概念，`act` 发不出去。**
      python play.py settle
```

**为什么闸关在发动作这一侧**：反例没处理就接着走，后面每一条转移都是在一个
已知错的模型上记的账，而**错不会自己报出来**。闸关在 `act` 上，
是让「修完再走」成为唯一能走的路。

出反例之后三条出路，**只有这些**：

```
· 改断言，改到在那条转移上判 TRUE；
· 缩 scope 判 NA（缩了就别再声称管那一片）；
· python play.py retire <名字> --why "……"   撤册，源码留进 history/
```

**把反例的 tid 抄进 EVIDENCE 只是登记，不是修好。**
结算会在这条概念自己的 EVIDENCE 上重跑 `assert_`，判 FALSE 照样关闸 ——
把打脸的那条抄进依据里，等于宣称「我是从它推出来的」，而它判自己错。

## 10 五条硬要求（缺一不入册，闸不开）

```
1  EVIDENCE 非空
2  assert_ 三或四参
3  返回值 ∈ {TRUE, FALSE, NA}
4  曾作为这条概念的反例披露过的 tid，必须在它的 EVIDENCE 里
5  它在自己 EVIDENCE 里的转移上**不许判 FALSE**
```

概念 import 失败 / 抛异常 / 返回值不合法，以 `error` 关闸同样处理：
**没被检验不等于没被推翻。**

## 11 报数纪律

结算每批打这几个数，**S 必须与 C、N、seen 同报**：

```
held_out(X)   全部去重转移 − X 自己声明的 EVIDENCE
N             held_out 上返回 TRUE 或 FALSE 的条数（NA 不算）
S             TRUE / N；N = 0 时记 UNMEASURABLE
C             N / |held_out|，**覆盖率**
seen          held_out 里曾因别的概念作为反例披露给你的转移数（污染量，显式报，不剔除）
```

**只报 S 是在报一个把分母藏起来的数。** S = 1 而 N = 3 的概念，和 S = 0.95 而 N = 200 的，
不是一回事；前者多半是 scope 被收窄之后剩下的几个样本恰好对称（见第一步 4.2）。

`apply` 那一侧只报不拦：

```
P      这条概念预测的格子里对了多少
E      **规则图完成度** —— 帧差里被解释的格子占比。**唯一一个写得越多越涨的数**
冲突   两条概念对同一格给了不同颜色 —— **那一步优先去走**（见第一步 1.2）
残差   没人预测对的格子 —— 地图上没人管的地方
```

## 12 一轮长什么样

```
python play.py reset
python play.py status                 # 看两道闸通不通
python play.py bet "……"               # 闸一
python play.py act ACTION1 ACTION1    # 发动作，自动记转移
python play.py settle                 # 闸二：判、报数、出反例
   ├─ 有反例 → 改断言 / 缩 scope / retire，然后再 settle
   └─ 闸开   → 回到 bet
python play.py retire <名字> --why "……"
```

走一步就结算、走十步再结算都行。一个好用的边界是
**押注里最没把握的那一条兑现或落空之后**。

---

# 第二步：凝练与形式化（v7h）
用代码中的类型和关系把杂乱观察凝成可推理的世界模型。凝练只沿下表四个方向开展。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json
# 完成一个独立更新后：
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
```

凝练要求拒绝集保持、无人区不增加。纠正已被证据驳倒的规则是 repair，可能改变拒绝集：
先记录反例、前后差异和理由，再加 --repair-note analysis/<修复说明>.md，不许把它冒充等价凝练。
空规则册的空拒绝集不提供删概念的依据；检查失败就修复、回滚或明确保留欠账。

## 凝练范围与全规则审查

首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。

提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
为每条规则写 analysis/full_rule_audit.json 的 rules 项：
{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。

每次 attempt 后依次：阶段01 对象、02 规则表达、03 规则凝练、04 Lean定义、05 闭合证明。
首轮五条阶段全文；之后发两条增量消息。保留不变部分，可用 CARD-UNCHANGED 加具体理由。
证明模型的每条定义追溯到 Rule/，必须只放宽路线、只降低代价；能证模拟引理的就证。
缺少一些必要的元素和规律时，先记录并验证，再加入规则，不能为证明临时新增限制。
所有 「走不通」 类主张要给 MAIN-THEOREM，经过全规则审查、内核重编、公理检查；后续外部反馈维修只在初始八轮封存之后进行。
内存超限强制修复，不能把资源失败当作走不通证据。以下定义层/主定理仍必须互相对应。

## Lean 这一侧

`lean/` 里有两个**泛型骨架**，已经编过、公理表干净。你要做的是**实例化**它们，不是重写。
两份都不含任何一局的事实。

```
lean/Skeleton1.lean   守恒量：存在 P，所有动作都保持 P
lean/Skeleton2.lean   单调量：存在 Φ，每个动作最多让 Φ 变 1
lean/Selftest.lean    一个小例子，示范怎么实例化（也示范了非空洞性测试怎么写）
```

怎么编（**不依赖 mathlib**，裸 `lean` 直编）：

```bash
# **工具链必须钉死。** 不要用 `ls … | head -1` —— 那样会挑到 v4.28.0，
# 它曾经把四条定理悄悄算成带 `sorryAx` 的，而编译**不报错**。
LEAN=~/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lean.exe
"$LEAN" --version          # 先确认打出来是 4.34.1
cd lean
"$LEAN" -o Skeleton1.olean Skeleton1.lean              # 骨架一
LEAN_PATH=. "$LEAN" -o Skeleton2.olean Skeleton2.lean  # 骨架二（它 import 骨架一）
LEAN_PATH=. "$LEAN" Selftest.lean                      # 样板，应当全绿
LEAN_PATH=. "$LEAN" YourFile.lean                      # 你自己那份
```

### 四条硬纪律

1. **不许 `sorry`**，一处都不许。
2. **不许 `native_decide`** —— 它往公理表里塞 `ofReduceBool` / `trustCompiler`。
   用 `decide` 或 `rfl`。
3. 每条定理后面写 `#print axioms <定理名>`，**公理表只许出现
   `propext` / `Quot.sound` / `Classical.choice`，或者「不依赖任何公理」**。
4. **非空洞性测试**：一条永远用不上的定理也会编过 —— 前提永假时它恒真而毫无内容。
   所以每条主定理旁边都要有一条**方向相反**的，证明那个前提确实是约束。
   `Selftest.lean` 里那三条（用得上 / 方向没反 / 前提是真约束）就是样板。

### 证到哪一步才算证完

Lean 这一侧的模型是拿来**证明**的：证明从某个局面出发**能**到目标，或者**到不了**目标。
两个方向用同一个口径：

```
能到     给一条动作串作见证，用 decide 证它在你的 step 下到达目标
到不了   定理对模型的**全部**动作串成立：从这个局面出发，没有一条到达目标
         只证了一条或几条路线到不了，不算这个结论
```

**证明要在 Lean 里闭合。** 结论依赖的每一个关于模型的事实，都要从你的 Lean 定义里证出来：

- Lean 外算出来的结果 —— 搜索、最短路、路线手数、「到目标至少要几次某种动作」之类的下界 ——
  **不许**写成定理的假设。要用它，就在 Lean 里把它立起来：比如把模型能到达的状态写成一张表，
  或者给每个状态一个界，让 `decide`（或 `decide +kernel`）对着你的 Lean `step` 去核。
  程序可以帮你**找**这张表；**核**它的必须是 Lean，而且核的是定理所说的那份 Lean 定义，
  不是另一种语言写的第二份模型。
- 定理上唯一允许的假设，是限定「哪些动作合法」的那种。每一条都写明为什么它不是你算出来的事实。
- 上面第 4 条（非空洞性）落到这里：同一份文件里再证一条 —— 把模型里的某一个限制放宽
  （说是哪个、放宽多少）之后，同一个模型有动作串能到目标；报出能到的最小放宽量。
- 报主定理时单独占一行：`MAIN-THEOREM: lean/<文件>.lean : <定理全名>`。
- **状态表大得核不动时，改模型的表示，不要放弃核表。** 把模型的动作和状态抽象到可达状态表
  小到能核的粒度：状态里只留会影响以后能不能到目标的量。这个抽象要写进 **Lean 定义本身**，
  不能只在找表的程序里用；把它写成一条明说的建模假设，说明为什么它不会把本来走得通的走法排除掉。
- **闭合不了是一个信号，不是终点。** 它说明模型还有问题：要么表示还不够好，状态空间还能再压小
  （见上一条）；要么目标其实到得了，是你的模型漏了什么。接下来的 attempt 就针对这一点改模型，
  再试着闭合，不要停在「这一步还在 Lean 外」。把缺的那一步写成假设、让定理看起来证完了，仍然不许。

**内存**：这台机器内存有限。单个 lean 进程把可用内存吃光时，
台架会直接杀掉它，那次编译就算失败。核表时把表拆小、
分几个文件分别编，不要一次编一个很大的文件；
先用小规模试出单个文件大约要多少内存，再放大。

`mathlib` **没有**。`by_contra` / `omega` 之外的很多常用 tactic 不在 core 里 ——
`omega` 在，`by_contra` 不在。

---

# 留下什么

`work/` 是你自己的地方，想怎么放都行。但跑完要能拿得出来：

```
· 第一步的产物：规则表（每条的作用域、依据、被多少局面考过、弃权过多少次）
· 丢掉机制的那张审计表
· 对账的三个数：对过几帧、对上几帧、对不上几帧，以及对不上的那几帧怎么解释的
· 第二步的产物：objects/ derive/ rule/ analysis/（每张卡的读数）、lean/ 下的 Lean 文件，以及每条定理的 `#print axioms` 原文输出
```

**这些比「结论对不对」更要紧。** 要量的不是你猜得准不准，是你的主张能不能被别人核。

## 本轮四方向记录要求
每次 attempt 的规则凝练阶段须逐项考虑四个方向，生成驱动要求的结构化记录并通过全量回归。
不适用时必须给具体理由，不为凑齐四项而作无益变换；文件与理由齐全不等于语义等价已被证明。
前八次不接收关于当前界是否正确的外部信号，也不额外触发内置怀疑/自审轮。

````

## 00-task-core.txt

````text
You are playing a video game through an HTTP game service at http://127.0.0.1:{PORT} .

Your working directory is {WORK} . Read README.md there first; it documents the service.

Rules of engagement (strict):
- Interact with the game only through HTTP requests to http://127.0.0.1:{PORT} .
- You may write and run your own code (Python etc.), but only create files inside your working directory.
- Do not read, list, search or open any other file or directory on this machine (in particular nothing outside your working directory), do not use git, and do not use web search or web fetch. Everything you need is the service and the README.
- Other jobs share this machine: keep each process under about 2 GB of memory, do not leave searches running in the background, and pace HTTP requests (no more than ~50 per second).
- Nobody will answer questions; work autonomously until done.

Task: play the game from level 1 as far as you can. Beat every level. You are finished when you have beaten the last level or the game has ended.

When finished, reply with a summary: the level you reached and whether you beat the game.

````

## 00-task-rounds.txt

````text
One more rule about how a run ends:

- When the game ends, or when you decide you cannot make further progress, stop there and
  report. Do not call /reset to start over on your own. Wait. You may be given another attempt.

````

## 20-round-interview.txt

````text
That attempt failed. The game will reset this level, and you may get another attempt.

Answer the following. Keep it to what it needs; do not pad.

1. What happened on the level you were on when the attempt ended, and what do you think made
   it fail? Explain in plain prose, as if to someone who did not watch you play.

2. Do you still see a way to beat this level?
   - If you do: say what it is, and what you would still need to check to be sure of it.
   - If you no longer do: say why not. State precisely what you are claiming, give the
     argument for it, and make clear what the argument rests on - which parts you established
     and which are assumptions you did not check. Someone else should be able to follow it and
     judge whether it holds. The form of the argument is yours to choose.
   - If you cannot tell either way, say so, and say what would settle it.

3. What will you do on the next attempt?

4. Before you answer this one, bring your formal system up to date. It is the thing you are
   building across attempts; the proof is downstream of it. Work in this order, in your
   working directory:

   a. Objects. What things are on the board, and what slots does each thing carry? For every
      object you keep, you should be able to name a pair of positions that stop being
      distinguishable if you drop it.
   b. Rules. Write each rule as a function: given a position and an action, what does it
      change? Each rule needs a domain you can actually execute.
   c. Structure and simplify through decomposition, composition, generalization and specialization. Review each direction separately on objects and rules, including specific no-change reasons where appropriate. Preserve tested distinctions, run the full rejection regression, and refresh this attempt's structured evidence under cards/03. Unread fields are not automatically safe to delete.

   d. Formalize. Turn the objects and rules into Lean *definitions* - not theorems. Each rule
      ends up in exactly one of three states: a definition, a consequence of definitions, or
      explicitly marked "not in the model".

   If you already have a formal system from an earlier attempt, **amend it. Do not start a new
   one.** What you learned this attempt is a change to specific objects, rules or definitions;
   make those changes and leave the rest alone. A rewrite throws away the part of your work
   that was already right, and it destroys the record of what this attempt actually taught you.

5. Now prove your answer to question 2 **on that formal system**: that the level can be won,
   or that it cannot.

   - The proof must compile, and `#print axioms` on your main theorem must come back clean -
     no `sorryAx`, no `native_decide`. Report that output verbatim.
   - Say what your theorem actually quantifies over and what it assumes. If the proof needs a
     premise you did not establish, write it as an explicit hypothesis rather than burying it
     in a definition.
   - Name the rules from step 4b that your theorem leans on. If your Lean definitions carry
     something your rules do not - an extra assumption, a tighter domain, a step treated as
     atomic - say so here. A proof that is clean about the wrong system is worth nothing, and
     a model that is *stricter* than the game is the dangerous direction: "impossible in my
     model" does not transfer to the game.
   - Put the file in `lean/` and tell me its filename.
   - If you cannot complete the proof, say exactly where it breaks and what is missing. An
     honest "it does not go through, here is the gap" is worth more than a theorem that proves
     something weaker than it looks.

6. If this attempt taught you nothing that changes your formal system - no rule revised, no
   definition touched - do not invent a change. Say so instead, on its own line, in exactly
   this form, and then give the reason:

       FORMAL-UNCHANGED: <why this attempt added nothing to the model - what you tried, what
       you already knew, and what would have had to happen for the model to change>

   "No change, and here is why" is a real result. A change made only to look busy is not.

A FORMAL-UNCHANGED line does not waive the four-direction consideration record or the full rejection check.

End your reply with exactly these two lines, on lines of their own, with nothing after them:

VERDICT: winnable | impossible | impossible_in_model_proved | impossible_in_model | undecided
CONFIDENCE: <an integer from 0 to 100>

The two "in_model" words are for when the level cannot be won under the rules you yourself
measured, and the step from "those rules" to "the real game" is an assumption you are stating
rather than something you established. Say which assumption, in your answer to question 2.
Use `impossible_in_model_proved` only if you are also handing over a Lean proof of it that
compiles and whose `#print axioms` is clean - name the file. Otherwise use `impossible_in_model`.
Your proof will be compiled and its axioms checked, so do not claim `_proved` on a file that
does not go through; `impossible_in_model` with an honest account of the gap is worth more.

Answer in writing only. Do not send any more game actions.

````

## 21-final-interview.txt

````text
That attempt failed.

Answer the following in writing. Give each answer the length it needs; do not pad.

1. What happened on the level you were on, and what do you think made it fail?
   Explain in plain prose, as if to someone who did not watch you play.

2. Do you still see a way to beat this level?
   - If you do: give the line of play, and say what you checked it against.
   - If you no longer do: say why not. State precisely what you are claiming, give the
     argument for it, and make clear what the argument rests on - which parts you established
     and which are assumptions you did not check. Someone else should be able to follow it and
     judge whether it holds. The form of the argument is yours to choose.
   - If you cannot tell either way, say so, and say what would settle it.

3. Which rule did you newly work out across these attempts, and from which observation?

4. Which rule are you still unsure about, and unsure in what way?

5. State your answer to question 2 again, this time as a Lean proof, using the formal apparatus
   you were given in this working directory.

   - Whichever way your answer goes, prove it: that the position can be won, or that it cannot.
   - The proof must compile, and `#print axioms` on your main theorem must come back clean -
     no `sorryAx`. Report that output verbatim.
   - Say what your theorem actually quantifies over and what it assumes. If the proof needs a
     premise you did not establish, write it as an explicit hypothesis rather than burying it
     in a definition.
   - If you cannot complete the proof, say exactly where it breaks and what is missing. An
     honest "it does not go through, here is the gap" is worth more than a theorem that proves
     something weaker than it looks.

End your reply with exactly these two lines, on lines of their own, with nothing after them:

VERDICT: winnable | impossible | impossible_in_model_proved | impossible_in_model | undecided
CONFIDENCE: <an integer from 0 to 100>

The two "in_model" words are for when the level cannot be won under the rules you yourself
measured, and the step from "those rules" to "the real game" is an assumption you are stating
rather than something you established. Say which assumption.
Use `impossible_in_model_proved` only if you are also handing over a Lean proof of it that
compiles and whose `#print axioms` is clean - name the file. Otherwise use `impossible_in_model`.
Your proof will be compiled and its axioms checked, so do not claim `_proved` on a file that
does not go through; `impossible_in_model` with an honest account of the gap is worth more.

Answer in writing only. Do not send any more game actions.

````

## 22-keep-playing.txt

````text
Your attempt is not over: the game has not ended. The service still reports
`%s` on level %s.

Keep playing this attempt until the game ends on its own. Do not call /reset - the attempt is
closed for you once the game is over, and you will be given another one. Report again when the
game has ended.
````

## 23-old-gate-retry.txt

````text
Your answer did not close out this attempt's formalization step.

%s

Fix just that, now. Either bring the formal system up to date (objects, rules, simplify,
Lean definitions - amending what you already have, not starting over), or state plainly
that this attempt changed nothing in it, on its own line in exactly this form:

    FORMAL-UNCHANGED: <why this attempt added nothing to the model>

Do not replay the game and do not restate your earlier answer. Just this.
````

## 24-proof-retry.txt

````text
Your answer states that the level cannot be won. Under METHOD.md ("证到哪一步才算证完") that claim must be backed
by a closed Lean proof on your model, and the driver checks it mechanically. It is not there yet: <actual gate reasons are inserted here>

Do it now (files only, no game actions):
- a main theorem that holds for every action list of your model (a table checked by decide against your Step, an
  invariant or a potential; no search result from outside Lean as a hypothesis; the only allowed hypotheses restrict
  which actions are legal); the proof may run on an abstraction layer in lean/Proof/ (stage 05 of the cards);
- it compiles with the pinned Lean, and `#print axioms <theorem>` shows only propext / Quot.sound / Classical.choice;
- end your reply with the line MAIN-THEOREM: lean/<file>.lean : <full theorem name>, then the VERDICT and CONFIDENCE
  lines.
If you have truly hit a wall, say exactly which step does not go through and why; then the verdict is
undecided until a closed proof is available. A failed proof gate is a protocol blockage, not an accepted impossibility certificate.
Before any impossible claim, audit ALL current rules and deferred mechanisms under cards/05; refresh analysis/full_rule_audit.json and the successful full rejection receipt after model edits.

````

## 30-feedback-first.txt

````text
One more task on this level. We compared your model with the actual game engine. The engine has a cheaper winning
route than your model allows when every rule is taken as your evidence supports it: at least one rule of your model
forbids, or charges more for, a move that the engine allows. I am not telling you which rule, or anything about the
true cost. Find the discrepancy yourself. This tells you only that your least cost is too high. It does not tell
you whether the level can be won within its budget: the true least cost may still be above the budget, or it may not.

Find it with the self-audit in `METHOD_selfaudit.md` (in your working directory; read it now). It is part of how you
are required to work, like METHOD.md. Write its step 1, the sensitivity table, before you send any request to the
game in this round. You may run experiments on any level the service gives you; every experiment must go through
the service, following the rules of engagement you were given.

How this round works:
- You have at most 4 attempts on this level. We reset the level at the start of each attempt; an attempt ends
  when the game reports GAME_OVER (or when you beat the level). Do not call /reset yourself.
- The same service has been kept alive; the current level is reset. Your session, files and recorded observations are preserved.
- After each attempt we ask you a few short questions. Keep work/selfaudit/ up to date as the section requires.

Start attempt 1 now.

After each attempt, complete the four-direction condensation and Lean stages in METHOD.md when the driver sends them. Use the existing model and all recorded evidence. The initial eight-attempt checkpoint is sealed; do not rewrite its reports.

````

## 31-METHOD_selfaudit.md

````text
### 自审：证完「到不了」以后，先查你的模型是不是比游戏更严

**主逻辑（先读这一段）。** 你证明了「到不了」，交出了一份在 Lean 里闭合的证明。这只说明**在你的模型里**到不了，
不说明游戏里也到不了，更不说明你报的最少代价（预算）是最紧的那个界。证明会原样继承模型的每一处偏差：

```
模型某条规则比游戏宽   模型允许的走法比游戏多       「到不了」在游戏里仍然成立；最少代价只会偏低
模型某条规则比游戏严   模型禁止了游戏允许的一步，   你的最少代价偏高，界不是最紧的；
                       或者多收了代价              「到不了」在游戏里可能是假的
                                                   —— 而证明本身发现不了：它对你的模型是对的
```

所以**闭合的证明不是终点**。过严是危险的方向，而且它最容易藏在你从没走过的情形里：正是你的模型告诉你
那边不值得走的地方。拿到闭合证明以后，要**逐条核验承重的规则有没有比游戏更严**，下面就是怎么核。

结论只和它依赖的那几条规则一样可靠。模型里大多数规则跟结论无关；有几条是**承重**的。
对这几条，「记录过的转移全都对得上」还不够：要紧的是游戏在**结论用到它们的那个情形**里是不是照办。
这一圈自审和上面的非空洞性测试不是一回事：那一条只放宽**一个**限制、证明前提是真约束；
这里要把**每一条**规则都朝「更容易到达目标」的方向放松一遍，看结论靠的是谁，再去游戏里查那几条。

**什么时候做（attempt 是有限的，探测要花 attempt）：**

```
触发     第一次拿到按上一节闭合的主定理，就在那次 attempt 的追问里做 (a)
         到第 4 次 attempt 结束还没有闭合证明：照样在第 4 次的追问里对当前最好的模型做 (a)，
         闭合证明接着做，探测从第 5 次 attempt 开始
探测     从下一次 attempt 起，每次 attempt 都先做 (b)，直到 (d) 满足；
         这样的 attempt 不必去争取到达目标
修改     (c) 在两次 attempt 之间的追问里做（不发动作）
做完     (d) 满足以后，剩下的 attempt 照常用
```

**(a) 规则敏感性（纸面，不发动作）**

以「每条规则都按证据所支持」的那份模型为准（不是定理里带自由未知量的弱化版）。
记 `L` = 它到达目标的最小代价，口径和你的结论一样；`C` = 本关测得的上限。

1. **列出模型的每一条规则。** 模型的 `step` 决定的每一件事都算一条，包括你觉得「只是编码」的那些。
   至少过一遍下面这几类，每类写出你模型里属于它的规则：

```
前提     动作什么时候被允许 / 有效果 / 被挡住
效果     动作改了什么（每个被改的量单独算）
收费     每个动作扣多少，以及每一条会改变已花或剩余数量的规则
常数     模型里每一个你拟合出来或读出来的数（阈值、数量、位置）
顺序     一个动作的几项效果按什么先后发生
终止     一关在什么情况下结束
抽象     证明的表示里丢掉或打包的东西（宏动作、不跟踪的状态、因为没见过而删掉的选项）
```

2. **只考虑你的记录允许的放松。** 一个放松只有在放松后的模型**仍然复现你记录过的每一条转移**
   （所有关、所有 attempt）时才算候选。和某条记录矛盾的放松已经被游戏否掉了，不要在它上面花搜索。
   每条规则往「只会让到达目标更容易」的方向，找出它能放松的范围：

```
现在的规则       模型现在怎么写
最宽可容许版本   仍然复现全部记录的转移的、这条规则最宽的写法（恰好放宽到记录钉住的地方为止）
```

   候选只在这两者之间。

   **一条规则通常不止一个能放松的地方。** 一条禁止、阻挡或收费的规则排除了好几种不同的情形，
   每一种没被记录钉住的情形都是一个单独的放松，逐个列成这条规则的子行（`R3.1`、`R3.2`、…）。至少过一遍：
   - **它检查的每一样东西**：一条检查好几个量的条件，可以在每个量上分别放松；
   - **这个情形能怎么出现**：同一个状态可以由不同种类的动作造成。从一种动作上学到的规则，
     对别的动作只是外推，所以每一种动作都单独算一个情形；
   - **每条记录过的反例，按最窄的读法**：一条「规则成立」的记录只在它那个确切的情形里钉住规则。
     一个放松如果在别处都允许、只在记录过的反例那里不允许 —— 也就是靠那些反例情形里的另一个量
     把它们区分开 —— 它仍然可容许。写明是哪个量，用重放来核。
   - **触发类规则：把整张表写出来。** 这类游戏里的规则大多是接触触发的（先验）：某个东西什么时候开始起作用、
     某个效果什么时候发生、碰到时状态怎么变。对这种规则，它的情形是下面三样的**组合**：
     （一）每一种能造成这个触发情形的动作（凡是能改变触发条件所看的那些量的动作都算）；
     （二）每一种接触的方式（挨着、部分重叠、完全盖住）；
     （三）行动者自身状态的每一种取值。
     把这张表写进 `pass1.md`，每一格标成三种之一：**已覆盖**（引那条记录的原文）、**未覆盖**、**到不了**。
     **没被覆盖的每一格都是一个没被钉住的情形**；一次「没触发」的记录只钉住它自己那一格。
     每个未覆盖的格子单独作为一个情形去放松，不同行、不同列的格子不要合并。
     **一格只有用你的模型做过可达性检查，才能标成「到不了」**：在模型的可达状态里搜，看有没有一个状态，
     从它出发这个动作会造成这种接触，并报出搜索本身（搜了什么、多少个状态）。搜到了，这一格就是到得了的：
     把那个状态和动作写下来，它就是这一格的咬合情形；没有记录覆盖它的话，这一格就是未覆盖。
     只凭判断（「这不会发生」「这种组合不可能」）不能标「到不了」；没做搜索的格子一律算未覆盖。

   每个情形给两档，写清放松的到底是什么、放松多少：

```
小步放松   可容许的最小改动：多一种情形下允许这个动作或让它生效；它收的少收一个单位；
           它用的常数朝有利方向挪一个单位；两项检查换个先后 —— 每一种都要仍然复现全部记录
最宽放松   最宽可容许版本
```

   可不可容许，要把记录过的转移拿到放松后的模型上**重放**来判，不靠估计。
   现在的规则已经就是最宽可容许版本（被记录钉死）的，写「被记录钉死」，引一两条钉住它的转移；
   这样的情形不用搜索，也不用探测；一条规则的**所有**情形都被钉死，这条规则才算被钉死。直接从画面上读出来的常数（物体的位置）被画面钉死。
   已经是最宽读法的规则（「宽松取向」）写明，没有放松档。
   其余规则一字不动，重算最小代价，记作 `L_小步`、`L_最宽`。

3. **写敏感性表** `work/selfaudit/pass1.md`，在下一次 attempt 发出第一个动作之前写好：

```
规则 | 类 | 小步放松（原文） | L_小步 | 最宽可容许放松（原文） | L_最宽 | 钉住它的记录 / 它凭的记录
```

   表头写 `L = …`、`C = …`，另列一小段「被记录钉死」的规则，各附钉住它的转移。
   每个情形一行。`L_小步 < L` 或 `L_最宽 < L` 的情形是**承重**的（放松它，最小代价就下降，**降多少都算**）。
   其中 `L_小步` 或 `L_最宽` `≤ C` 的单独标出：「到不了」的结论直接靠它们。
   **每个承重情形都要探测，包括放松后最小代价仍高于 `C` 的那些** —— 最小代价高了一个单位，结论照样是错的。

**(b) 在结论用到它的地方去探测承重规则 —— 用尽量少的动作和 attempt**

动作和 attempt 都有限，所以**默认不要按表的顺序一条一条测**。先认真想：哪几条最可能错，
哪些实验能一次测到最多条。

1. **咬合步。** 对每条承重规则，取放松后模型的最便宜路线（小步放松；最宽放松的路线不同时也取），
   找**咬合步**：放松后的模型和全证据模型第一次给出不同预测的那一步。写下那一步之前的状态、
   那个动作、两个模型各预测什么。这就是要把游戏带去的那个情形。
2. **按「多可能是错的」排序**，不只按它让 `L` 降多少。每条承重规则写一行：照你的记录看，它有多可能错：
   - 记录过的转移离它的咬合情形有多近？如果记录只覆盖了这条规则所看的东西的**其他取值**，
     那这条规则在咬合情形里是外推，外推最容易错。
   - 它是不是从一两次观测推广出来的？
   - 它是不是为了方便（编码、抽象）定下的，而不是从游戏里读出来的？
   按「可能错的程度 × 它能让 `L` 降多少」排探测顺序。开打之前把这个顺序和理由写下来。
3. **设计一次能测多条的实验。** 一个动作，如果它的结果在几条候选规则下各不相同，就能同时测这几条；
   一条路线，如果几个咬合情形共用前缀，就能一次走到好几个。开打之前：
   - 写一份**实验计划**：动作串，以及其中每一步转移测的是哪几条规则、每条规则各预测什么；
   - 优先选那种结果在几条候选规则下互不相同的动作（一次观测就能把好几个假设分开），
     以及在一次 attempt 的代价之内能走到好几个咬合情形的路线；
   - 最可能错的排在前面，万一这次 attempt 提前结束也先测到了它们；
   - **对照对。** 触发类规则还有没覆盖的格子时，最有信息量的实验是一对：**用两种不同的动作到达同一种接触方式**
     （或同一个动作、行动者处在两种状态）。一对分开一个因素；几对往往能排进同一次 attempt 的路线里。
   - 把计划写进那次 attempt 的押注里。
   最直接的单条探针是走放松后路线的前缀到咬合步，再做那个动作。前缀太贵，就设计一条更便宜的路，
   走到一个**在这条规则看的每一样东西上都和咬合状态一致**的情形，并说明其余的差别为什么和这条规则无关。
   一条记录过的转移只有在这条规则看的每一样东西上都是同一个情形时，才能顶替这次实验；用了就引原文。
4. 每条规则记结果：

```
CONFIRMED    游戏在咬合步照你的规则办
REFUTED      游戏照放松后的规则办（或做了别的你的规则不允许的事）
UNTESTABLE   你没办法让游戏面对那个情形；写清为什么（例如那个情形只在到达目标的那一步才出现）
```

5. **REFUTED 时不要停在这一次观测上。** 再设计实验（同样尽量一次分开多个假设），把这条规则成立过的
   情形（你的记录）和它失败的这个情形分开，直到你说得出改过的规则，以及它为什么也符合之前的每一次观测。

计划和每个实验的结果写在 `pass1.md` 表下面：测了哪几条规则、发了什么（第几次 attempt、哪几步）、
游戏做了什么（前后的值）、每条规则的结果。

**(c) 被驳倒的规则：修、重放、重新闭合**

照第 7 节修规则（凭哪一次观测、旧版挪进 NOTE）。改过的模型必须仍然**复现你记录过的每一条转移**，
包括探测时新走的；报出重放了几条、对上几条。然后按上一节在 Lean 里重新闭合，
重算 `L`，再做一遍 (a)，写成 `work/selfaudit/pass2.md`，以此类推。探测时新走的转移从此也算记录，
可能把原来没钉住的规则钉住。
之前已经 CONFIRMED 的规则，只有咬合步变了才需要重测。

**(d) 什么时候算做完**

最新一遍里的**每条承重规则都已经被实验 CONFIRMED**，或者记成 UNTESTABLE 并写明了理由。
attempt 用完时还有没测到的承重规则：最后的回答里逐条列出来，并报出把它们（以及所有 UNTESTABLE 的）
全部小步放松之后的最小代价 —— 让读的人看到你的结论有多少是靠游戏没被带去检验过的规则撑着的。
最后的回答里还要报：第一遍之前的 `L`、每一遍的承重规则、每个探针的结果、最后的 `L`。


````

## 32-feedback-round.txt

````text
Attempt {k} of 4 has ended ({state}).

Answer briefly:
1. What did you test in this attempt, and what did the game do (step, values before and after)?
2. Which of your rules did this change, and how?
3. Your current least budget at which the level can be won, under your rules as they now stand.

End with these lines:
LEAST_BUDGET=<n, in your units>
VERDICT: winnable | impossible | undecided
You may report REPAIR-DONE, but it does not waive this attempt's gates. The preregistered follow-up still records up to four attempts.
Update work/selfaudit/ with this attempt's probes before answering.
The condensation and Lean stages must already be complete. If the verdict is impossible, give the closed theorem from the current model: MAIN-THEOREM: lean/<file>.lean : <full name>. A model-only proof does not certify the game without coverage of its allowed behavior.

````

## 33-feedback-final.txt

````text
The repair round is over.

1. Which rules did you change during this round, what did you observe that made you change each one (attempt, step,
   values before and after), and which experiments did you design to separate the possibilities?
2. Which of your rules are you still unsure about, and in what way?
3. State your least budget at which the level can be won, with the argument for it: what it rests on, which parts
   you established and which you assumed.
4. Update your Lean model and proof as METHOD.md requires (closed main theorem, relaxed-model theorem),
   with the corrected rules; your corrected model must reproduce every transition you have recorded.

End with these lines:
CHANGED_RULES=<one sentence per rule you changed, separated by " | ">
LEAST_BUDGET=<the least starting budget at which your corrected rules admit a win, in your units>
MEASURED_BUDGET=<the level's starting budget as you measured it, in the same units>
VERDICT: winnable | impossible | undecided
CONFIDENCE: <0-100>
MAIN-THEOREM: lean/<file>.lean : <theorem name>
LOAD_BEARING= / PROBES= / PASSES= / REPLAY= / LEAST_BUDGET_IF_UNTESTABLE_LOOSENED=   (as in phase 1)
````

## attempt-01-stage-01.txt

````text
Condensation and formalization (stage 01 of 5: 阶段1 · 类型、关系与对象凝练). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: 01
---
# 阶段1 · 类型、关系与对象凝练
## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json
# 完成一个独立更新后：
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
```

凝练要求拒绝集保持、无人区不增加。纠正已被证据驳倒的规则是 repair，可能改变拒绝集：
先记录反例、前后差异和理由，再加 --repair-note analysis/<修复说明>.md，不许把它冒充等价凝练。
空规则册的空拒绝集不提供删概念的依据；检查失败就修复、回滚或明确保留欠账。

## 凝练范围与全规则审查

首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。

提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
为每条规则写 analysis/full_rule_audit.json 的 rules 项：
{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。

````

## attempt-01-stage-02.txt

````text
Condensation and formalization (stage 02 of 5: 阶段2 · 用类型和关系表达规则). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: 02
---
# 阶段2 · 用类型和关系表达规则
## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。
## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。

````

## attempt-01-stage-03.txt

````text
Condensation and formalization (stage 03 of 5: 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: 03
---
# 阶段3 · 规则凝练与反向检查
## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json
# 完成一个独立更新后：
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
```

凝练要求拒绝集保持、无人区不增加。纠正已被证据驳倒的规则是 repair，可能改变拒绝集：
先记录反例、前后差异和理由，再加 --repair-note analysis/<修复说明>.md，不许把它冒充等价凝练。
空规则册的空拒绝集不提供删概念的依据；检查失败就修复、回滚或明确保留欠账。

## 凝练范围与全规则审查

首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。

提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
为每条规则写 analysis/full_rule_audit.json 的 rules 项：
{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 1
Before declaring stage 03 complete, write analysis/transforms/attempt_01.json.
Read analysis/transforms/driver_before_01.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-01-stage-04.txt

````text
Condensation and formalization (stage 04 of 5: 阶段 4 · Lean：定义层). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: 04
---
# 阶段 4 · Lean：定义层

> 这一套是 `METHOD.md`「第二步：凝炼与形式化」的全部内容，分五个阶段，台架在每次 attempt 之后、追问之前发给你。
> 每个阶段由原来的一张或几张卡原样组成；文中提到「卡 0x」，指的是下面对应的那一部分：
> 卡 01–03 在阶段 1，卡 04 在阶段 2，卡 05–07 在阶段 3，卡 08 在阶段 4，阶段 5 是证明模型与主定理。
> **下文的「语料」= 你自己记录下来的全部转移 `transitions.jsonl`**（所有关、所有 attempt，每行有 `prev` / `nxt`
> 两帧和动作）。**「册子」= 你的 `concepts/`**。工具在 `tools/`，接口见 `tools/CONTRACT.md`。


---

# 卡 08 · 形式化 · 骨架

## 你现在在做什么

把对象和规则翻成 Lean。**它们全都是定义，一条定理都没有。**

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 不许做

- 不许把规则写成 `theorem`。
- 不许让根目录堆十几个文件——**一层平铺，哪几份是一伙的看不出来**。

## 做完之前跑这个

```bash
# 用 METHOD「Lean 这一侧」里钉死的那个 lean，逐个文件编（LEAN_PATH 指向 lean/），每条定理后面 #print axioms
# 身份表写进 analysis/lean_identity.txt：每条规则一行，def / Derived 下的定理 / 不进模型（附理由与两个数）
# 破坏测试：把 analysis/broken/X.lean.txt 拷成临时 .lean 编一次，它必须在标记的那一行红；输出存 analysis/broken.out
```

## 这一步最要紧的一个念头

**有些检查不该写成检查，该写成「表示不出来」。**
把一局里永远不变的那半边搬进一个 `step` 碰不到的结构里，
「走一步版面不会变」就**不用证，它根本表示不出来**。
用一句「证不出来」换一句「说都说不出来」，划算。

## 这一步最常见的**静默**失败：改目录会弄坏三样东西

1. Lean 的 `import`（连生成器发出去的那几行一起改）；
2. **按文件名发现东西的加载器**——`glob` 在子目录之下返回**空表**，
   而空表之下那一整节一条都不核，**它会安安静静地全过**。
   **空表判红**：你自己写的加载器，找不到东西必须报错，不许返回空表；
3. 你自己写的文件表（analysis/lean_identity.txt）里的路径。

> **这一版不做观测重放。** 模型和观测对不对得上，由阶段 03 的读数负责（Python 规则层在全部转移上的
> 判错、拒绝集、无人区），Lean 定义和 Python 规则一一对应由上面的身份表负责。


## 凝练范围与全规则审查

首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。

提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
为每条规则写 analysis/full_rule_audit.json 的 rules 项：
{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。

资源约束：调用树硬上限8GiB；必须修复内存超限程序，不能靠删合法路线压小模型。

````

## attempt-01-stage-05.txt

````text
Condensation and formalization (stage 05 of 5: 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
This is the first pass: do this stage in full now, following the text below. When you are done, end your reply
with a line of its own:
CARD-DONE: 05
---
# 阶段 5 · Lean：证明模型与主定理（第一优先）

> 这一套是 `METHOD.md`「第二步：凝炼与形式化」的全部内容，分五个阶段，台架在每次 attempt 之后、追问之前发给你。
> 每个阶段由原来的一张或几张卡原样组成；文中提到「卡 0x」，指的是下面对应的那一部分：
> 卡 01–03 在阶段 1，卡 04 在阶段 2，卡 05–07 在阶段 3，卡 08 在阶段 4，阶段 5 是证明模型与主定理。
> **下文的「语料」= 你自己记录下来的全部转移 `transitions.jsonl`**（所有关、所有 attempt，每行有 `prev` / `nxt`
> 两帧和动作）。**「册子」= 你的 `concepts/`**。工具在 `tools/`，接口见 `tools/CONTRACT.md`。


---

# 证明模型与主定理

## 你现在在做什么

为你判「走不通」的那一关写一条**闭合的主定理**。它是整套形式化里**第一优先**的东西
（METHOD「证到哪一步才算证完」）：定理对模型的**全部**动作串成立，Lean 外的搜索结果不许当假设，
唯一允许的假设是限定「哪些动作合法」的那种，单独一行报 `MAIN-THEOREM:`。
追问里只要你判「不可能」，台架就会重编这条定理、查它的公理表。

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 不许做

- 不许凭「搜不到路」说不可达；不许把「语料里没赢过」当成「赢不了」。
- 不许让证明模型带上 `Rule/` 里没有的东西。
- 这一版**不要求**打过的各关的逐帧重放定理和可赢定理，不要把时间花在那上面。

## 做完之前跑这个

```bash
# 用 METHOD「Lean 这一侧」钉死的 lean 逐个文件编；主定理和非空洞性定理后面各一行 #print axioms，公理表要干净
# analysis/proof_model_map.txt：每条定义一行，来源规则 + 为什么只会更宽
```

## 这一步最常见的**静默**失败

1. **证明模型比游戏严，而对照表没写出来。** 打包宏动作时顺手禁掉了一种中间情形、丢掉一个量时顺手丢掉了它的一种效果
   ——主定理照样闭合，而它证的是一个比 `Step` 更窄的世界。对照表那一栏「为什么只会更宽」就是为了把这件事摊开。
2. **`step` 多一支「模型说不出话」**（重置、整屏重画……），让「走不通」实际变成「不经过那一支就走不通」。
   那半句要写在明处。


## 凝练范围与全规则审查

首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。

提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
为每条规则写 analysis/full_rule_audit.json 的 rules 项：
{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。

## 资源与缺失规则的 repair
缺少必要的元素和规律时，记录到 analysis/record.txt；已被语料确认的现在加进 rule/ 与 Lean Rule/，
未知的下一次 attempt 去确认。证明模型只能使用已建立的规则，不能为闭合新增限制。
遇到内存超限必须减少状态表示、分解引理或流式计算，不能原样重复大表。
重新检查拒绝集、全规则影响及模拟方向，再编主定理。保存 analysis/resource_repair.md。

````

## attempt-02-stage-01+02+03.txt

````text
Condensation and formalization (attempt 2, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 2. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 2
Before declaring stage 03 complete, write analysis/transforms/attempt_02.json.
Read analysis/transforms/driver_before_02.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-02-stage-04+05.txt

````text
Condensation and formalization (attempt 2, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 2. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-02-start.txt

````text
Attempt 2: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-03-stage-01+02+03.txt

````text
Condensation and formalization (attempt 3, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 3. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 3
Before declaring stage 03 complete, write analysis/transforms/attempt_03.json.
Read analysis/transforms/driver_before_03.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-03-stage-04+05.txt

````text
Condensation and formalization (attempt 3, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 3. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-03-start.txt

````text
Attempt 3: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-04-stage-01+02+03.txt

````text
Condensation and formalization (attempt 4, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 4. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 4
Before declaring stage 03 complete, write analysis/transforms/attempt_04.json.
Read analysis/transforms/driver_before_04.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-04-stage-04+05.txt

````text
Condensation and formalization (attempt 4, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 4. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-04-start.txt

````text
Attempt 4: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-05-stage-01+02+03.txt

````text
Condensation and formalization (attempt 5, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 5. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 5
Before declaring stage 03 complete, write analysis/transforms/attempt_05.json.
Read analysis/transforms/driver_before_05.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-05-stage-04+05.txt

````text
Condensation and formalization (attempt 5, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 5. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-05-start.txt

````text
Attempt 5: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-06-stage-01+02+03.txt

````text
Condensation and formalization (attempt 6, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 6. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 6
Before declaring stage 03 complete, write analysis/transforms/attempt_06.json.
Read analysis/transforms/driver_before_06.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-06-stage-04+05.txt

````text
Condensation and formalization (attempt 6, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 6. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-06-start.txt

````text
Attempt 6: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-07-stage-01+02+03.txt

````text
Condensation and formalization (attempt 7, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 7. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 7
Before declaring stage 03 complete, write analysis/transforms/attempt_07.json.
Read analysis/transforms/driver_before_07.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-07-stage-04+05.txt

````text
Condensation and formalization (attempt 7, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 7. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-07-start.txt

````text
Attempt 7: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-08-stage-01+02+03.txt

````text
Condensation and formalization (attempt 8, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 8. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 8
Before declaring stage 03 complete, write analysis/transforms/attempt_08.json.
Read analysis/transforms/driver_before_08.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-08-stage-04+05.txt

````text
Condensation and formalization (attempt 8, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 8. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-08-start.txt

````text
Attempt 8: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-09-stage-01+02+03.txt

````text
Condensation and formalization (attempt 9, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 9. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 9
Before declaring stage 03 complete, write analysis/transforms/attempt_09.json.
Read analysis/transforms/driver_before_09.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-09-stage-04+05.txt

````text
Condensation and formalization (attempt 9, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 9. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-10-stage-01+02+03.txt

````text
Condensation and formalization (attempt 10, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 10. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 10
Before declaring stage 03 complete, write analysis/transforms/attempt_10.json.
Read analysis/transforms/driver_before_10.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-10-stage-04+05.txt

````text
Condensation and formalization (attempt 10, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 10. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-10-start.txt

````text
Attempt 10: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-11-stage-01+02+03.txt

````text
Condensation and formalization (attempt 11, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 11. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 11
Before declaring stage 03 complete, write analysis/transforms/attempt_11.json.
Read analysis/transforms/driver_before_11.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-11-stage-04+05.txt

````text
Condensation and formalization (attempt 11, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 11. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-11-start.txt

````text
Attempt 11: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

## attempt-12-stage-01+02+03.txt

````text
Condensation and formalization (attempt 12, stages 01, 02, 03: 阶段1 · 类型、关系与对象凝练; 阶段2 · 用类型和关系表达规则; 阶段3 · 规则凝练与反向检查). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 12. Go through the stages below again (01, 02, 03): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段1 · 类型、关系与对象凝练
(full text: cards/01-对象阶段.md)

## 必须做到
建立 objects/parse.py（唯一帧解析入口），明确 World、ParseError、对象类型与关系。
每个选定对象单独模块；复合概念放 derive/。analysis/parse_report.txt 记录全语料解析结果，
analysis/<对象>.txt 记录用途、规则读者、所用重构方向、证据与未解决问题。
写 analysis/record.txt，并将非 history 内容保存到 analysis/history/<轮次>/，不递归复制 history。
字段分离或消融是可选诊断，不是额外的凝练判据；未覆盖的差异进入欠账。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
运行上面的全量拒绝集前后检查。首轮规则尚空时先报告解析和欠账，等规则建立后补回归；
不要用空册子的空拒绝集删除信息。analysis/field_split.txt 可记录诊断结果或说明本轮为何不重跑。


# 阶段2 · 用类型和关系表达规则
(full text: cards/02-长规则.md)

## 必须做到
用 objects/ 与 derive/ 重写观察得到的规则，放 rule/<组>/<规则>.py。
保留原始 concepts/ 与全部 transitions.jsonl；每条规则实现 scope_、assert_，可被反例驳倒。
论域覆盖、NA、错误与解析失败都要报告。缺少必要元素和规律时，先把证据加入规则再用于证明；
不确定的列为待测，不许凭“关卡预设可赢”或证明需要硬加规则。
分析优先覆盖证明依赖和新证据影响的部分；不相关规则仍参加全量回归。

## 做完之前跑这个
python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
将读数与欠账写入 analysis/rules_readout.txt。真正修错另加 --repair-note，解释拒绝集变化。


# 阶段3 · 规则凝练与反向检查
(full text: cards/03-规则阶段.md)

## 必须做到
沿四个方向凝练选定规则及其对象依赖，写 analysis/record.txt；其余规则允许保留不改并说明原因。
| # | 方向 | 核心问题 |
|---|---|---|
| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |

只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。

```bash
python tools/rejection_check.py --out analysis/rejection_before.json

## 做完之前跑这个
全量回归真实转移和固定变异；analysis/reverse.txt 记录至少一种故意破坏后应被拒绝的情形。
工具判“无独家拒绝”不等于该删，反例不足时保留欠账。不要按每个字段机械重做所有消融。

## Required four-transformation audit, attempt 12
Before declaring stage 03 complete, write analysis/transforms/attempt_12.json.
Read analysis/transforms/driver_before_12.json; do not edit it.
Fields: attempt, before_source_sha256 (copy the driver capture), after_source_sha256
(current SHA256 map of ALL *.py in objects/, derive/, rule/, concepts/), corpus_sha256,
and transformations: exactly four entries with IDs decomposition, composition,
generalization, specialization. Every entry needs status (applied, considered_no_change,
or not_applicable), targets (actual model paths), reason (specific, at least 80 characters),
and evidence_ids (real tid/id, or zero-based nonblank JSONL-row index when no ID exists).
Each entry must separately give object_consideration and rule_consideration (at least
40 characters each): which concrete object distinctions and rule dependencies you
checked, or why that layer is not affected. These are reviewable explanations, not proofs.
Consider both objects and rules; do not force a harmful edit just to apply a direction.
Every model edit during this refinement pass must be covered by an applied entry.
Run full before/after rejection checks on the same complete corpus. Preserve the
successful fresh analysis/rejection_after.json. Distinguish evidence-based rule repair
from equivalence-preserving condensation. If the checker rejects the audit, fix it
without game actions; the driver will not proceed to Lean or count a valid verdict.
These mechanical checks do not prove the semantic quality of your explanations.

````

## attempt-12-stage-04+05.txt

````text
Condensation and formalization (attempt 12, stages 04, 05: 阶段 4 · Lean：定义层; 阶段 5 · Lean：证明模型与主定理（第一优先）). This is part of the second part of METHOD.md ("第二步：凝炼与形式化"):
after every attempt, before the questions, the driver sends the stages of the second part (the full text is in cards/).
In the cards, 语料 means your own recorded transitions (transitions.jsonl: every level, every attempt) and 册子 means
your concepts/. The tools are in tools/ (interface: tools/CONTRACT.md). Work only on files; send no game actions.
Focus condensation on proof dependencies and new-evidence effects; keep all rules in full rejection regression.
Before any impossibility claim, audit every deferred rule under cards/05.
This is attempt 12. Go through the stages below again (04, 05): change only what this attempt's new
observations affect, but re-run their readings (they go stale when rules or objects change). The full text of each stage
is in cards/ (re-read it if needed). End your reply with one line per stage, each on its own line:
CARD-DONE: <stage>
or, if nothing in that stage needs to change,
CARD-UNCHANGED: <stage> <why: what you checked, at least 40 characters>
---
# 阶段 4 · Lean：定义层
(full text: cards/04-Lean定义层.md)

# 卡 08 · 形式化 · 骨架

## 必须做到

1. **规则不是待证的定理，是定义。**
   「按下某个动作会发生什么」是对**那个动作**的定义，「什么局面算赢」是对**赢**的定义。
   把定义写成待证的定理，形式上过得去、内容上是空的——
   动力学本来就是照着它们写的，**证它等于用它自己证它自己**。
2. **每类对象单独一个 `.lean`，每条规则单独一个 `.lean`，一一对应。**
3. **摆法：Lean 这边和 Python 那边分同一组。**
   一份东西住在哪儿，**两边要一致**——`objects/<组>/<名>.py` 对 `Obj/<组>/<名>.lean`，
   `rule/<组>/<名>.py` 对 `Rule/<组>/<名>.lean`。
   两边各分各的，等于同一套分类有两份，而它们会慢慢分家。
   ```
   lean/
     Skeleton1/2.lean, Selftest.lean   给你的泛型骨架，不动
     Step.lean      装配：只做分发，**0 条定理**
     Obj/<组>/      对象，**按和 Python 同一组分子文件夹**
     Rule/<组>/     规则（全是 def），同上
     Derived/       **推论**——从别的规则或架构本身推出来的
     Proof/         证明模型与主定理（阶段 5）
   analysis/broken/ 破坏测试：**应当编不过**的 Lean，扩展名写 `.lean.txt`
                    （写成 `.lean` 会被台架当成你的形式化去编，编不过就判这一轮没完成）
   ```
   验收那张文件表要**带上组名**，而且**表和目录要对账**：
   目录里有而表上没有的那几份**一条都不会被核到**，
   而它们**不会报错**——少了的那种编译当场红，多出来的那种是静悄悄的。
3b. **一一对应只管定义层**（`Obj/`、`Rule/`、`Step.lean`）。证明用的模型放在 `Proof/`，不受一一对应的约束，
   但它的每一条定义都要追溯到这里的规则，见阶段 5。
   规则的收费如果依赖状态（同一个动作在不同局面下收不同的费），定义里就照实写成依赖状态，
   不要为了「每个动作一个价」把它写错。
4. **每条规则的身份恰好落一种**：`def`（定义）/ `Derived` 下的定理（推论）/
   明说**不进模型**（要写理由）。验收逐条核。

   > **「不进模型」那一组固定打两个数**：
   >
   > ```
   > 论域条数     语料里有多少条转移落在这条说法管的范围里
   > 被驳倒几次   其中有多少条和它对不上
   > ```
   >
   > 不定这两个数的话，这一组会变成几篇散文，**而散文没有分母**。
   > 摆法里写着这一组可以有、状态表里也写着「假设写在明处，
   > 且有一处会因它变红」，**但没有一处说它该打什么数**——
   > 于是「不进这一层」和「没人核」就混成了一件事，而它们是两件。
   >
   > 论域是 0 的话照样判红：一条谁也管不着的假设，
   > 和一条从没被驳倒的假设，在读数上必须分得开。
5. **世界那一份不许依赖规则。** 依赖方向单向。

## 做完之前跑这个

```bash


# 阶段 5 · Lean：证明模型与主定理（第一优先）
(full text: cards/05-主定理.md)

## 必须做到

1. **证明在一个小的「证明模型」上做**，放在 `lean/Proof/`：
   - 抽象状态只留会影响「能不能到目标、还要花多少」的量；几下操作组成的一次操作可以打包成一个宏动作；
     收费可以按状态和动作一起算（`cost : State → Act → Nat`）；
   - 目的只有一个：让可达状态表小到 `decide` 核得动，或者让一个势函数 / 不变量写得出来。
     状态表大得核不动时，继续压小证明模型的表示，不要放弃核表。

2. **证明模型的每一条定义都必须来自 `Rule/` 里的规则，不许新增任何假设。** 逐条核：
   - 写 `analysis/proof_model_map.txt`：证明模型的每个类型、每个动作、每条转移 / 收费 / 终止定义一行 ——
     它来自 `Rule/` 里的哪几条规则（写名字）、怎么从它们得来（打包了哪几步、丢掉了哪些量），
     以及**为什么这样做只会让证明模型比 `Step` 更宽、不会更严**（允许的走法只多不少、收的费只少不多）；
   - 能在 Lean 里证的就证（模拟引理：`Step` 下的每一步或每个宏动作，在证明模型里有对应的一步，
     终点对应、代价相等或更低；这样证明模型上的「走不通」推出 `Step` 上的「走不通」）；
   - 每一处「丢掉」或「打包」都要过一遍这个方向：**更严就不许**；核不了的写成明说的假设，在第 5 问里报；
   - **不许为了让证明闭合，在证明模型里加 `Rule/` 里没有的限制**，也不许把一条规则写得比 `Rule/` 里窄。

3. **非空洞性。** 同一份文件里再证一条：把证明模型的某一个限制放宽（说是哪个、放宽多少）之后，
   能到目标；报出能到的最小放宽量。

4. **闭合以后保持闭合。** 后面的 attempt 里规则一改，先改 `Rule/`，再同步改证明模型和对照表，重新闭合；
   每次改完都重编主定理。只有规则真的被实验驳倒时才改它的内容。

5. **闭合不是终点。** 闭合的「走不通」只说明在你的模型里走不通。接下来照 METHOD 的自审一节，
   逐条查承重的规则是不是比游戏更严（台架每次判「不可能」后都会提醒你）。阶段卡片是固定流程，不替代自审。

## 做完之前跑这个

```bash

````

## attempt-12-start.txt

````text
Attempt 12: the current level has been reset. Play through the service under METHOD.md. Do not reset it yourself. Wait for the driver to send the condensation and Lean stages after this attempt.
````

