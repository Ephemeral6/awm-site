# 旧输入 → 新输入：逐字差异

原L4 selected-v7的实际texts取自run.json；L5 selected-v3的实际输入另列，因为四次attempt在一次CLI continuation内，不能伪造逐attempt独立prompt。新版feedback是统一新协议，参考历史通用M1/M2/M3方案并作显式改造，不声称复制了旧两条完全相同的提示。

## METHOD-L5-closed-v4.md → 00-METHOD-initial8.md

```diff
--- old/METHOD-L5-closed-v4.md
+++ new/00-METHOD-initial8.md
@@ -13,15 +13,15 @@
 ```
 第一步  从实验里把规则**提出来、修对** —— 这一步占掉这一局的绝大部分时间
 台架    概念怎么写、两道闸怎么关 —— **这个目录里的脚本强制的**，不是靠自觉
-第二步  把规则**变成 Lean** —— 形式化，**收工时才做**
+第二步  把规则**凝炼成对象 / 规则，再变成 Lean** —— 每次 attempt 之后，台架逐张发卡
 ```
 
 **先读第 8–12 节（台架）再动手。** 不知道闸在哪，第一个动作就会被拦下来。
 
 **第一步没做完就进第二步，等于把猜测形式化。** 那会让猜测看起来像定理。
 
-**跑的时候做第一步就够了。** 第二步（Lean 那一侧）在这一局结束之后才会要你交 ——
-所以不要为了赶形式化而缩短实验。中途想写点 Lean 定义当笔记可以，但别让它挤掉探索。
+**跑的时候只做第一步。** 第二步在每次 attempt 结束之后、台架逐张发卡的时候做 ——
+所以不要在游玩中途为了赶形式化而缩短实验。
 
 **如果这个目录里已经给了你一份 `model/`**（见 `MODEL.md`）：
 那份模型是**起手稿不是真值**，第一步对你来说就变成**验它、修它、补它** ——
@@ -379,29 +379,53 @@
 
 ---
 
-# 第二步：把规则变成对象 / 规则 / Lean（**收工时才做**）
-
-这一步在这一局结束之后做，不要在跑的时候抢时间做。
-第一步交出来的是一堆经得起打的规则，这一步把它们变成可判错的结构。
-
-```
-1. 提对象     盘上有哪些「东西」，每个东西有哪些「位」
-              自检：每个对象都说得出「拿掉它，哪一对局面从能区分变成不能」
-
-2. 长规则     每条规则写成一个**函数**：给定局面和动作，它改了什么
-              自检：每条规则的论域可执行（你能说出它在哪些局面上适用）
-
-3. 简化       删掉没有任何规则读过的位；合并判决永远一致的规则
-              自检：删完之后，你的模型对**已观测的每一帧**的判决一个字不变
-
-4. 形式化     把对象和规则**写成 Lean 定义**（不是定理）
-              自检：每条规则恰好落一种身份 —— 定义 / 由定义推出的推论 / 明写「不进模型」
-
-5. 用它       拿模型去规划，再去真走。预测对不上就回第一步的第 5 节。
-```
-
-（如果 `model/` 已经给了你对象层和规则层，这一步就是**把你改过的那些落实回去**，
-而不是重写一套。）
+# 第二步：凝练与形式化（v7h）
+用代码中的类型和关系把杂乱观察凝成可推理的世界模型。凝练只沿下表四个方向开展。
+| # | 方向 | 核心问题 |
+|---|---|---|
+| 1 | 投射极限·自顶向下（结构分解） | 能否把复杂概念拆成简单概念及其关系，使整个模型更简单？ |
+| 2 | 投射极限·自底向上（组合重构） | 某个概念能否由已有概念与相容条件组合表达，从基本对象降为 derive/ 定义，使模型更简单？ |
+| 3 | 归纳极限·自顶向下（提取共性） | 能否从多个概念提取一般概念，以一般概念和必要差异替代原概念，使模型更简单？ |
+| 4 | 归纳极限·自底向上（拓展） | 能否去掉过度抽象的概念，改成更具体、带必要参数的概念，使模型更简单？ |
+
+只用上述四个方向组织凝练，不另设简化、区分或对称的判据清单。类型与关系用代码表示。
+删除是共同验收条件：去掉概念 x 后，系统行为和已有观察都没有区别，才可删除；
+有限语料上的恒定、没有分离见证或没有独家拒绝，都不能单独证明它在玩法中无用。
+每个独立更新前后运行全量拒绝集检查，真实转移、固定变异、解析失败和无人区均留痕；
+不得靠缩小论域、丢掉转移或把 FALSE 改成 NA 让读数变绿。
+
+```bash
+python tools/rejection_check.py --out analysis/rejection_before.json
+# 完成一个独立更新后：
+python tools/rejection_check.py --out analysis/rejection_after.json --compare analysis/rejection_before.json
+```
+
+凝练要求拒绝集保持、无人区不增加。纠正已被证据驳倒的规则是 repair，可能改变拒绝集：
+先记录反例、前后差异和理由，再加 --repair-note analysis/<修复说明>.md，不许把它冒充等价凝练。
+空规则册的空拒绝集不提供删概念的依据；检查失败就修复、回滚或明确保留欠账。
+
+## 凝练范围与全规则审查
+
+首轮先建立完整的观察/规则清单。此后允许重点凝练与目标证明相关的依赖闭包，以及新观察、
+反例或对象改动所影响的规则；无需每轮重写所有不变规则的分析。完整规则和全部语料仍保留，
+每次更新后的拒绝集回归仍是全量的；省掉的是重复的概念讨论，不是检查范围。
+写 analysis/refinement_scope.json：selected_rules 与 deferred_rules 是 rule/ 当前规则路径的完整互斥分区。
+被证明依赖的规则必须在 selected_rules；记录选择理由与传递依赖，不许只挑能让证明闭合的规则。
+
+提出任何 「走不通」 类结论之前，必须审查全部规则（包括先前 deferred 的规则）：是否改变可达性、
+代价、合法动作或模型对应？审查未知交互、未测组合与被省略机制，保留怀疑和下一轮判决性实验。
+为每条规则写 analysis/full_rule_audit.json 的 rules 项：
+{"path":"rule/组/规则.py","status":"proof_dependency 或 irrelevant_with_reason","reason":"具体证据和理由，至少20字"}。
+有未解决的影响时写 unresolved，不能给出已闭合的游戏判定。该 JSON 还要有 source_sha256 与
+corpus_sha256，取自刚运行的 analysis/rejection_after.json（必须是完整对象/规则源码与语料的当前哈希）。
+机械闸只核规则清单覆盖、读数成功和哈希新鲜度，不把自由文本理由当成已证明的语义对应。
+
+每次 attempt 后依次：阶段01 对象、02 规则表达、03 规则凝练、04 Lean定义、05 闭合证明。
+首轮五条阶段全文；之后发两条增量消息。保留不变部分，可用 CARD-UNCHANGED 加具体理由。
+证明模型的每条定义追溯到 Rule/，必须只放宽路线、只降低代价；能证模拟引理的就证。
+缺少一些必要的元素和规律时，先记录并验证，再加入规则，不能为证明临时新增限制。
+所有 「走不通」 类主张要给 MAIN-THEOREM，经过全规则审查、内核重编、公理检查；后续外部反馈维修只在初始八轮封存之后进行。
+内存超限强制修复，不能把资源失败当作走不通证据。以下定义层/主定理仍必须互相对应。
 
 ## Lean 这一侧
 
@@ -486,7 +510,12 @@
 · 第一步的产物：规则表（每条的作用域、依据、被多少局面考过、弃权过多少次）
 · 丢掉机制的那张审计表
 · 对账的三个数：对过几帧、对上几帧、对不上几帧，以及对不上的那几帧怎么解释的
-· 第二步的产物：对象表、Lean 文件，以及每条定理的 `#print axioms` 原文输出
+· 第二步的产物：objects/ derive/ rule/ analysis/（每张卡的读数）、lean/ 下的 Lean 文件，以及每条定理的 `#print axioms` 原文输出
 ```
 
 **这些比「结论对不对」更要紧。** 要量的不是你猜得准不准，是你的主张能不能被别人核。
+
+## 本轮四方向记录要求
+每次 attempt 的规则凝练阶段须逐项考虑四个方向，生成驱动要求的结构化记录并通过全量回归。
+不适用时必须给具体理由，不为凑齐四项而作无益变换；文件与理由齐全不等于语义等价已被证明。
+前八次不接收关于当前界是否正确的外部信号，也不额外触发内置怀疑/自审轮。

```

## ASK-round-initial.txt → 20-round-interview.txt

```diff
--- old/ASK-round-initial.txt
+++ new/20-round-interview.txt
@@ -24,8 +24,8 @@
       distinguishable if you drop it.
    b. Rules. Write each rule as a function: given a position and an action, what does it
       change? Each rule needs a domain you can actually execute.
-   c. Simplify. Drop slots no rule reads. Merge rules that always decide alike. After this,
-      your model's verdict on every frame you have observed must be unchanged.
+   c. Structure and simplify through decomposition, composition, generalization and specialization. Review each direction separately on objects and rules, including specific no-change reasons where appropriate. Preserve tested distinctions, run the full rejection regression, and refresh this attempt's structured evidence under cards/03. Unread fields are not automatically safe to delete.
+
    d. Formalize. Turn the objects and rules into Lean *definitions* - not theorems. Each rule
       ends up in exactly one of three states: a definition, a consequence of definitions, or
       explicitly marked "not in the model".
@@ -62,6 +62,8 @@
 
    "No change, and here is why" is a real result. A change made only to look busy is not.
 
+A FORMAL-UNCHANGED line does not waive the four-direction consideration record or the full rejection check.
+
 End your reply with exactly these two lines, on lines of their own, with nothing after them:
 
 VERDICT: winnable | impossible | impossible_in_model_proved | impossible_in_model | undecided

```

## actual-L4-v7-M1.txt → 30-feedback-first.txt

```diff
--- old/actual-L4-v7-M1.txt
+++ new/30-feedback-first.txt
@@ -12,7 +12,9 @@
 How this round works:
 - You have at most 4 attempts on this level. We reset the level at the start of each attempt; an attempt ends
   when the game reports GAME_OVER (or when you beat the level). Do not call /reset yourself.
-- The service has been restarted from level 1; your earlier solutions for the earlier levels still work.
+- The same service has been kept alive; the current level is reset. Your session, files and recorded observations are preserved.
 - After each attempt we ask you a few short questions. Keep work/selfaudit/ up to date as the section requires.
 
-Start attempt 1 now.+Start attempt 1 now.
+
+After each attempt, complete the four-direction condensation and Lean stages in METHOD.md when the driver sends them. Use the existing model and all recorded evidence. The initial eight-attempt checkpoint is sealed; do not rewrite its reports.

```

## actual-L4-v7-M2.txt → 32-feedback-round.txt

```diff
--- old/actual-L4-v7-M2.txt
+++ new/32-feedback-round.txt
@@ -8,5 +8,6 @@
 End with these lines:
 LEAST_BUDGET=<n, in your units>
 VERDICT: winnable | impossible | undecided
-If you need no further attempts, add a line: REPAIR-DONE
-Update work/selfaudit/ with this attempt's probes before answering.+You may report REPAIR-DONE, but it does not waive this attempt's gates. The preregistered follow-up still records up to four attempts.
+Update work/selfaudit/ with this attempt's probes before answering.
+The condensation and Lean stages must already be complete. If the verdict is impossible, give the closed theorem from the current model: MAIN-THEOREM: lean/<file>.lean : <full name>. A model-only proof does not certify the game without coverage of its allowed behavior.

```

## actual-L4-v7-M3.txt → 33-feedback-final.txt

```diff
--- old/actual-L4-v7-M3.txt
+++ new/33-feedback-final.txt
@@ -15,4 +15,4 @@
 VERDICT: winnable | impossible | undecided
 CONFIDENCE: <0-100>
 MAIN-THEOREM: lean/<file>.lean : <theorem name>
-LOAD_BEARING=<the load-bearing rules in your last pass*.md> / PROBES=<how many probe experiments you ran> / PASSES=<how many pass*.md you wrote> / REPLAY=<recorded transitions your final model reproduces, n/N> / LEAST_BUDGET_IF_UNTESTABLE_LOOSENED=<your least budget if every rule you could not test is taken in its looser form>+LOAD_BEARING= / PROBES= / PASSES= / REPLAY= / LEAST_BUDGET_IF_UNTESTABLE_LOOSENED=   (as in phase 1)
```

