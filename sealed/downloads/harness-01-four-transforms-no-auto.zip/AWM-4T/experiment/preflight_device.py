"""Offline checks including 128MiB memory-guard probes; never calls a subject model."""
from pathlib import Path
import sys,os,json,subprocess,platform,importlib.metadata
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R.parent))
import protocol as P
from verify_package import verify
from device_support import protocol_hashes,sha,unwrap

if __name__=='__main__':
    out=R/'receiver_validation';out.mkdir(exist_ok=True)
    integrity=verify()
    patch_record=None
    if not integrity['ok']:
        f=out/'registered_patch.json'
        if f.exists():patch_record=unwrap(f)
        actual={x['path']:sha(R.parent/x['path']) if (R.parent/x['path']).is_file() else None for x in integrity['issues']}
        if not patch_record or not patch_record.get('version') or patch_record.get('changes')!=actual:raise SystemExit('Original package changed. Use register_patch.py to record the real bug fix and version, preserving the original manifest.')
    if os.name!='nt':raise SystemExit('Windows JobObjects required; do not disable the memory guard on other operating systems')
    if not (R/'operator_only/batch-plan.json').exists():raise SystemExit('Run setup_device.py first')
    dependencies={}
    for name,want in [('arcengine','0.9.3'),('numpy','2.2.3')]:
        try:dependencies[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:dependencies[name]='missing'
        if dependencies[name]!=want:raise SystemExit(f'{name}: require {want}, found {dependencies[name]}; install or explicitly version a dependency change')
    for key in ('AWM_SESSION_PIN',):os.environ.pop(key,None)
    env=dict(os.environ,AWM_ARCHIVE=str(R/'runtime_archive'),AWM_RUNTIME=str(R/'runtime_tmp'),PYTHONIOENCODING='utf-8')
    checks=[]
    for name,cmd in [('four_transform_tests',[sys.executable,str(R/'test_offline.py')]),('memory_regression_cleanup',[sys.executable,'-I',str(R/'harness/test_v7h.py')]),('portable_phase_tests',[sys.executable,str(R/'test_device.py')])]:
        with (out/(name+'.log')).open('w',encoding='utf-8') as f:result=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
        checks.append(dict(name=name,returncode=result.returncode))
        if result.returncode:break
    ok=len(checks)==3 and all(x['returncode']==0 for x in checks)
    if ok:
        P.dry_run(materialize=True);P.export_prompts()
    report=dict(models_called=False,real_game_servers_started=False,package_integrity=integrity,registered_patch=patch_record,host=platform.node(),dependencies=dependencies,checks=checks,ok=ok,protocol_sha256=protocol_hashes(R))
    (out/'preflight.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if ok:print('Offline checks passed. Review prompts and local CLI/Lean versions, then run accept_review.py. No model authentication call was made.')
    raise SystemExit(0 if report['ok'] else 2)
