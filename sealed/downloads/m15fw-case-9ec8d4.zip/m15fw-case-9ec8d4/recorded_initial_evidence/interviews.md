## Attempt 1

## 1. What happened on level 4

The cursor (a 4×4 block) starts in a room. The goal sits at the end of a corridor that a colour-13 barrier closes off completely. The only way I know to remove that barrier is the "switch" pattern: on level 3, drawing it on the panel deleted both the switch and the barrier.

On level 4 I drew that same pattern twice:
- once with the cursor facing left, under the switch's stalk;
- once facing up and touching the stalk, which is exactly how it had worked on level 3.

Neither time did anything open. I then spent my remaining actions on a small item the same colour as the budget bar, betting it was a refill. It wasn't, the bar ran out, and the game ended.

Fitting the bar readings afterwards shows level 4's budget is 18 units:
- an ordinary action costs 1 unit;
- a click that completes a pattern costs 2.

There are two causes of failure:
- I don't know what actually triggers the switch.
- I spent 9 of the 18 units testing guesses about it before planning a route.

## 2. Can level 4 still be beaten? I can't tell either way.

It turns on one rule I don't have: what has to be true for the switch to fire. Two explanations both fit all four observations:

- **H (cursor position):** the switch fires only when the cursor's left column is on the stalk (column 31 or 32).
  - The 4×4 cursor moves in steps of 4 and can only stand at columns 21, 25, …, 41. So under H it can never fire the switch itself.
  - It would first have to shrink to 2×2 (4–5 clicks), and a 2×2 cursor moves only 2 columns per step.
  - The cheapest win in my model then costs 20 units, more than the 18 available, so the level would be impossible.
  - What I established: how moves work and their step sizes, that the barrier blocks, that a completed pattern clears the panel, the win rule, and the costs.
  - What I did not establish: H itself.
- **Bump:** the switch fires anywhere, but only after the cursor has bumped into the barrier.
  - On level 3, the successful draw came after a bump and the earlier failed one came before it.
  - On level 4 I never bumped the barrier.
  - Under this explanation the route is: down, right, right (bump), three clicks, then right ×4. That costs 11 units, so the level would be winnable.

One experiment settles it: bump the barrier, then draw the switch pattern. It costs 7 units.

## 3. Next attempt

1. Move down, right, right (the last one bumps the barrier).
2. Click (x=30, y=50), (30,55), (30,60).
3. If the barrier opens, move right four times to win (11 units total).
4. If it doesn't open, H becomes the leading explanation, and under H the level can't be won in my model.

I won't touch the colour-14 item.

## 4. Formal system

This is the first formal version, so there was nothing earlier to amend.
- **Objects and rules:** listed in `work/MODEL.md`, with the slot for each object that would make two observed positions indistinguishable if dropped.
- **Lean definitions:** in `lean/M15fwModel.lean`, each rule marked as a definition, a consequence, or not in the model.
- **Checks:** `example`s in that file, checked by `decide`, reproduce the key observed transitions: the wall shortening a move to 2, the 2×2 stepping by 2, the barrier blocking, the win, and pattern completion.
- **Not in the model:** the switch's precondition. It enters only as the hypothesis `Hyp` in the theorem below.

## 5. Proof (`lean/M15fwL4.lean`)

`no_win_within` states: for every `fires` satisfying `Hyp`, and every choice sequence whose total cost is at most B (any B < 20), the run ends in a non-won state. A won state has no successor, so this covers every prefix too. `l4_no_win_B4` is that statement at B4 = 18.

The method is a potential function Φ, a lower bound on the cost still needed to win. Φ is 20 at the start, and every step lowers it by at most that step's cost.

**What the model abstracts:**
- Rows are dropped; a vertical move is a no-op that costs 1.
- The panel is reduced to two counters that a click may lower freely.
- The shrink may shift the cursor 0 or 2 columns.

All three only add transitions, so the model is looser than the game. The step from the real game to this abstraction is argued in prose, not proved in Lean.

**Rules the theorem leans on:**
- `move_step4`: the cursor moves by its side length, or less at walls.
- The barrier blocks unless opened.
- `goal_win`.
- A completed pattern clears the panel.
- The costs (1 per action, 2 for a completing click).
- `Hyp`, which is the only part stricter than what I observed.

**Non-vacuity checks:**
- `witness_wins`: a run costing exactly 20 does win under a `fires` that satisfies `Hyp`, so the bound is tight.
- `cheap_wins`: with an unrestricted `fires`, a run costing 9 wins.
- `fireAny_not_hyp`: that unrestricted `fires` violates `Hyp`.

Together these show `Hyp` is what the bound depends on.

`#print axioms`, verbatim:
```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Changes to the formal system this attempt

- Added the budget rule.
- The switch precondition "facing up and touching the stalk" was refuted by step t58, so the precondition was moved out of the model.
- The "the item refills the bar" idea was refuted.

## 7. Checks on the proof

**a. Fit (`work/fit_budget.py`).** I searched budget B ≤ 400, action cost c ≤ 20, completion surcharge x ≤ 40, cost of the swallowed first move, and floor, ceil or round for the display.
- **Level 4 alone:** 54 raw combinations survive, 30 distinct, all using ceil and with game over when units go negative. B/c lies in [17.78, 18.27] and x/c in [0.889, 1.133].
- **Same cost ratio on all four levels:** only x/c = 1 survives, giving exactly one fit: B = 18, moves and clicks cost 1, a completing click costs 2.
- **Effect on the verdict:** none, anywhere in the set. Under H the cheapest route costs 19 + x/c ≥ 19.89 action-units, above the largest possible B/c of 18.27. The bump route costs 10 + x/c ≤ 11.2, which fits everywhere.

**b. Decisive experiments** (all from attempt 1):

| Rule | Decisive observation |
|---|---|
| Step equals the cursor's side | Shrunk 2×2 moved 2, not 4 (tid fb6f…, level 1) |
| Walls shorten a move | Left move went only 2 at the wall (2e39…, level 1, step 5) |
| Barrier blocks | Move into colour 13 gave k = 0 (97fd…, level 3, step 32) |
| Win on overlap | Entering the goal frame won the level (fc55…, level 1, step 17) |
| Completing click costs 2 | Bar dropped 6 rows on a completion vs 4 for an ordinary action (level 4, step 54; also level 2, step 20) |
| Game over only once spent > B | Empty bar at step 65, GAME_OVER only at step 66 |
| `Hyp` | **None yet.** The experiment that would test it is the bump test in §3 |

**c. Budget range.** I recompiled with different B4 values:
- B4 = 18: compiles.
- B4 = 19: compiles.
- B4 = 20: fails, because `decide` refutes 20 < Φ init = 20.

So the impossibility result holds only up to 19, one unit above the measured 18. It is not a model that is simply too strict about the budget. Its whole weight rests on `Hyp`, which is the rule I suspect.

One incident: while splitting the Lean file I accidentally wrote a temporary file to `/tmp`, outside the working directory. I deleted it immediately.

VERDICT: undecided
CONFIDENCE: 55

## Attempt 2

## 1. What happened on level 4

The level is a room holding the 4×4 cursor and a corridor leading to the goal. A colour-13 barrier closes the corridor. The only known way to open it is drawing the "switch" pattern (the centre column of the panel), which on level 3 removed both the switch and the barrier. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

This attempt tested the two leading guesses for what the switch needs:
- **Bump the barrier first, then draw the pattern:** nothing opened.
- **Shrink to 2×2 and draw it while touching the barrier:** nothing opened, and the 2×2 is blocked by the barrier too.

Those tests used the whole budget, and the next action ended the game. The cause of failure is the same as before: I do not know what triggers the switch. Each test of a guess costs about a quarter to half of the budget.

## 2. Can level 4 be won? Under my established rules, no.

**Claim:** no action sequence costing at most 18 units wins level 4, given these premises:
- **P1, movement:** the cursor moves by its side length, cut short only by walls. In this room the 4×4 cursor can only stand at left columns 21, 25, 29, 33, 37 or 41. A 2×2 moves 2 columns per step.
- **P2, barrier:** the barrier blocks both cursor sizes until the switch opens it.
- **P3, completing a pattern:** it clears the whole panel. Shrinking needs 4 clicks and the switch needs 3. Completing a pattern costs 2 units, any other action 1.
- **P4, winning:** the level is won when the cursor overlaps the goal (left column ≥ 56 for a 2×2).
- **P5, budget:** 18 units, game over once more than 18 are spent. No refunds.
- **Hyp, the switch trigger:** the switch fires only when the cursor's left column is 31 or 32, the stalk's columns.

**Argument:**
1. Under Hyp and P1, the 4×4 cursor can never trigger the switch, so it must shrink first.
2. After that it must stand at column 31 and complete the switch pattern.
3. It then needs 13 two-column moves to reach the goal.
4. The cheapest total is 20 units, which is more than 18.

**What is established and what is assumed:**
- P1–P5 each have a decisive observation (see 7b).
- Hyp has none. It fits all six recorded switch attempts (1 fired, 5 failed). It is also the only explanation I've tried that hasn't been refuted: "facing up and touching the stalk", "bump first" and "any 2×2" are all refuted.
- **Specific untested mechanism that would change the answer:** the 4×4 firing from a column I never tried (33, facing up, directly under the switch). If that fires, the level is winnable for about 14 units.
- **Also against Hyp:** a designer probably wouldn't ship a level that can't be won, and under Hyp this one can't be.

## 3. Next attempt

One plan of 17 units runs both tests:
1. Left once to column 33, up once to row 21 (facing up, touching the stalk), then draw the switch pattern. That is 6 units.
2. **If it fires:** down twice, then right six times, reaching the goal at 14 units.
3. **If not:** left once to column 29, shrink (5 units), right once to column 31, and draw the switch pattern again. That is 17 units in total and settles Hyp directly: Hyp predicts it fires, and the level stays unwinnable this attempt either way.

## 4. Amendments to the formal system (no rewrite)

- **`lean/M15fwModel.lean`:**
  - New object `CastObs` and a table `casts` of all six switch attempts.
  - `decide` checks:
    - Hyp's predicate "cursor's left column = stalk's left column" matches all six;
    - "facing up and touching the stalk", "bumped the barrier first" and "a 2×2 fires anywhere" each fail against the data.
  - New level-4 board `board4`, with checks that the barrier blocks both the 2×2 and the 4×4.
  - A shrink check: the top-left corner was kept, now seen a second time (facing right).
- **`lean/M15fwL4.lean`:** comments only. The abstraction already treated the barrier as blocking the 2×2, and it keeps the loose shrink offset (0 or 2 columns). The bump alternative is now marked as refuted.
- **`concepts/move_step4.py`:** returns "not applicable" when the previous frame has an empty bar, which marks a transition across the service's restart.
- **`work/fit_budget.py`:** treats each attempt as its own sequence. Details are in `work/MODEL.md`, under "Amendments from attempt 2".

## 5. Proof (`lean/M15fwL4.lean`, theorem `no_win_within`)

**What it says:** for every switch rule `fires` that satisfies `Hyp`, and every choice list whose total cost is at most B (any B < 20), the run ends in a non-won state. `l4_no_win_B4` is the instance at B4 = 18.

**Where the model is looser than the game:**
- rows are abstracted away;
- the panel is reduced to two counters a click may lower freely;
- the shrink may shift the cursor 0 or 2 columns.

All three only add transitions. The step from the real game to this abstraction is argued in prose, not proved in Lean.

**Rules it leans on:** `move_step4` (step size and wall clamps), the barrier blocking, the panel reset on completion, `goal_win`, the costs and budget, and `Hyp`. `Hyp` is the only part stricter than what I observed.

**Non-vacuity checks:**
- `witness_wins`: a 20-unit run wins under a rule satisfying `Hyp`.
- `cheap_wins`: with an unrestricted switch rule, a 9-unit run wins.
- `fireAny_not_hyp`: that unrestricted rule violates `Hyp`.

```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Did the formal system change?

Yes, as listed in §4: one object and its table added, one board added, one scope revised, and the fit tightened.

## 7. Checks on the proof

**a. Cost fit.** The search covered:
- budget B ≤ 400, ordinary action cost c ≤ 20, completion surcharge x ≤ 40;
- the cost of the first action after a reset, which turned out to be 0;
- floor, ceil and round for the display;
- game over when units go negative versus when they reach zero.

Refunds were checked separately: the bar never rose within a level except at the service's restart, so the refund is 0. Using every level-4 reading from both attempts:
- **Level 4 alone:** 20 raw combinations survive, which collapse to exactly 1 distinct one. That is B = 18 action-units, a completing click costing 2 units, ceil rounding, and game over when units go negative.
- **Compared with attempt 1:** level 4's readings alone then left 30 distinct combinations; the two attempts together pin it to this one.
- **Across all four levels:** the same surcharge ratio (1) is the only common value.

With a single survivor, no conclusion varies across the fit set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step = side length | Attempt 1, level 1: the 2×2 moved 2 (tid fb6f…) |
| Walls shorten moves | Attempt 1, level 1, step 5: a 4×4 moved only 2 at the wall (2e39…) |
| Barrier blocks the 4×4 | Attempt 1, level 3, step 32 (97fd…) |
| Barrier blocks the 2×2 | Attempt 2, level 4: k = 0 at column 43 |
| Win on overlap | Attempt 1, level 1, step 17 (fc55…) |
| Completing click costs 2 | Attempt 1, level 4, step 54: 6 rows dropped instead of 4 |
| Game over only when spent exceeds the budget | Attempt 2: bar at 0 after spending exactly 18 with no game over; the next action ended the game |
| **Hyp** | **None yet.** The experiment is the second half of the §3 plan: a 2×2 at column 31 versus the 4×4 at column 33 |

**c. Budget range.** I recompiled with different values of B4:
- B4 = 18: compiles.
- B4 = 19: compiles.
- B4 = 20: fails, because `decide` refutes 20 < Φ init.

So the impossibility result holds only one unit above the measured budget. The model is not stricter than the game on budget; the result's weight rests on Hyp, which is the rule I suspect.

VERDICT: impossible
CONFIDENCE: 50

## Attempt 3

## 1. What happened on level 4

The goal sits behind a barrier. The only way to remove the barrier is the "switch" pattern on the panel, and it fires only when the cursor stands in the right column. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

This attempt was a two-part test:
- **Full-size 4×4 cursor at column 33,** facing up beside the switch's stalk: the pattern did nothing.
- **Shrunk 2×2 cursor at column 31,** inside the stalk: the pattern fired and the barrier disappeared.

That firing took the whole budget, because shrinking and two switch patterns are expensive. The cursor still needed 13 two-column moves to reach the goal, so the next action ended the game.

Why it fails: only the cursor's left column standing on the stalk opens the switch. The full-size cursor can't stand there, and the small cursor is too slow to reach the goal within budget afterwards.

## 2. Can level 4 be beaten? No, under the established rules.

**Claim:** no action sequence costing at most 18 units wins level 4.

**Premises:**
- **P1, movement:** the cursor moves by its side length, cut short only by walls. In this room the 4×4 cursor's left column can only be 21, 25, 29, 33, 37 or 41. A 2×2 cursor moves 2 columns per step.
- **P2, barrier:** it blocks both cursor sizes until it is opened.
- **P3, panel:** completing a pattern clears the panel. Shrinking takes 4 clicks and the switch takes 3.
- **P4, winning:** the cursor must overlap the goal. For a 2×2 that means a left column of at least 56.
- **P5, budget:** 1 unit per action, 2 for a completing click, 18 in total. Game over once more than 18 are spent, with no refunds.
- **Hyp, switch trigger:** the switch fires only when the cursor's left column is 31 or 32.

**Argument:**
1. By P1 and Hyp, the 4×4 cursor can never fire the switch, so it must shrink first.
2. The small cursor must then stand at column 31 and complete the switch pattern.
3. From column 31 it still needs 13 moves to reach the goal.
4. The cheapest total is 20 units, which is more than 18.

**What is established and what is assumed:**
- **P1–P5:** each has a decisive observation (listed in 7b).
- **Hyp's firing direction:** confirmed by the predicted firing in this attempt.
- **Hyp's "only if" direction, which the bound actually uses:**
  - Tested by 4×4 cursors at columns 29 and 33, both facing up beside the stalk; neither fired.
  - Also by the L3 failure at column 37, and the L4 failures at 41 (4×4) and 43 (2×2).
  - **Never tried:** a 4×4 at columns 21 or 25 facing up. Nothing suggests either would fire, but they have not been run.
- **Mechanisms never tried:** clicking an already-marked panel cell, clicks outside the panel, and actions 5 and 7.

## 3. Next attempt

The level is unwinnable under the established rules. I would spend the attempt closing the remaining gap in Hyp: a 4×4 at columns 25 and then 21, facing up, drawing the switch pattern at each. That costs about 6 + 6 units. If either fires, the 4×4 route to the goal is cheap and I'd take it.

## 4. Changes to the formal system

These are amendments only, nothing rewritten:
- **`lean/M15fwModel.lean`:** the `casts` table gains two rows (column 33: no fire; 2×2 at column 31: fired). The `decide` check now confirms Hyp's predicate fits all 8 recorded completions.
- **`lean/M15fwL4.lean`:** `Hyp`'s docstring now cites its evidence. `Hyp` stays an explicit hypothesis.
- **`work/MODEL.md`:** an "Amendments from attempt 3" section, including a third observation that shrinking keeps the top-left corner.
- **`work/fit_budget.py`:** now uses three level-4 attempts.

## 5. Proof: `lean/M15fwL4.lean`, theorem `no_win_within`

**Statement:** for every switch rule `fires` satisfying `Hyp`, and every choice list with total cost ≤ B where B < 20, the run ends un-won. A won state has no successor, so this covers every prefix. `l4_no_win_B4` is the instance at B4 = 18.

**What it leans on:** P1–P5 and `Hyp`.

**Where the model is looser than the game** (all of these only add transitions, which is the safe direction):
- rows are abstracted away;
- the panel is reduced to two counters that a click may lower freely;
- the shrink may shift the cursor by 0 or 2 columns.

The mapping from the real game to this abstraction is argued in prose, not proved in Lean.

**Non-vacuity checks:**
- `witness_wins`: a 20-unit run does win under a `Hyp`-satisfying rule, so the bound is tight.
- `cheap_wins` and `fireAny_not_hyp`: without `Hyp`, a 9-unit run wins, so `Hyp` is load-bearing.

```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** I searched over:
- budget B ≤ 400, ordinary cost c ≤ 20, completion surcharge x ≤ 40;
- the cost of the swallowed first action;
- floor, ceil or round for the display;
- game over at R < 0 versus R ≤ 0, where R is the units left.

Refunds were checked directly: the bar never rose within a level except at the two service restarts, so the refund is 0. Using all three level-4 segments:
- 20 raw combinations survive, which reduce to 1 distinct one: B = 18, a completing click costs one extra unit, ceil rounding, and game over at R < 0.
- Across all four levels, the only common surcharge ratio is 1.

With one survivor, no conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step = side length | Attempt 1, L1: a 2×2 moved 2 (tid fb6f…) |
| Wall clamp | Attempt 1, L1, step 5: moved 2 at the wall (2e39…) |
| Barrier blocks | Attempt 1, L3, step 32 (97fd…) for the 4×4; attempt 2, L4: 2×2 at column 43 with k = 0 |
| Win on overlap | Attempt 1, L1, step 17 (fc55…) |
| Completing click costs 2 | Attempt 1, L4, step 54 (6 rows dropped instead of 4) |
| Game over only once spent exceeds 18 | Attempts 2 and 3: bar at 0 with spent = 18 and still not finished |
| Hyp, firing at the stalk column | Attempt 3: the 2×2 at column 31 fired, as predicted |
| Hyp, failing elsewhere | Attempt 3: the 4×4 at column 33, facing up beside the stalk, didn't fire; attempt 1, step 58: the same at column 29. The cursor size differed from the firing case. |

Hyp has no decisive experiment yet for 4×4 columns 21 and 25. The experiment is the next-attempt plan in section 3.

**c. Budget range:**
- B4 = 18 and B4 = 19 compile.
- B4 = 20 fails: `decide` refutes 20 < Φ init, the potential's starting value.

The bound holds only one unit above the measured budget, so the model is not stricter than the game on cost. What remains uncertain is `Hyp`, specifically 4×4 columns 21 and 25.

VERDICT: impossible
CONFIDENCE: 72

## Attempt 4

## 1. What happened on level 4

The goal is behind a barrier. The barrier opens only when the switch pattern is drawn with the cursor's left column on 31. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

My earlier rules said the level was unwinnable: the full-size 4×4 cursor can't stand on column 31, and the small 2×2 is too slow to reach the goal. So I spent this attempt on experiments and found three rules I had been missing:
- **Refill:** a 2×2 cursor overlapping the colour-14 item consumes it and refills the bar. The 4×4 covering it in attempt 1 did nothing.
- **Switch:** it fires from column 31 anywhere in the room, not only in the stalk.
- **Grow:** completing the shrink pattern on a 2×2 turns it back into a 4×4, with the 2×2 as its bottom-right quarter. That puts a fast 4×4 in column 31.

I found all three too late; nothing was left to finish the level. The attempt failed because the experiments used up the budget. The earlier "impossible" verdicts were wrong because my model had no refill and no grow.

## 2. Yes, I see a winning route

The route has 38 actions:

| Phase | Actions | Units spent after |
|---|---|---|
| Start | 4×4 at row 25, column 37 | 0 |
| Move | down, down, left: 4×4 at (33,33) | 3 |
| Shrink | 4 clicks: 2×2 at (33,33) | 8 |
| Move | left: 2×2 at (33,31), facing left | 9 |
| Switch | 3 clicks: barrier opens | 13 |
| Move | left ×3 | 16 |
| Refill | left onto the item | 1 (budget reset, then this move charged) |
| Move | right ×5, up: 2×2 at (31,33) | 7 |
| Grow | 4 clicks: 4×4 at (29,31) | 12 |
| Move | right ×6: overlaps the goal on the 6th | 18 |

It rests on two premises I have not established:
- **The switch ignores which way the cursor faces.** Every firing so far had it facing up; this plan fires it facing left.
- **The refill resets the budget**, rather than refunding a fixed 10 units. One reading can't tell these apart (see 7a). If it is a 10-unit refund, the plan ends at 24 units and dies.

Everything else in the plan has been observed directly.

## 3. Next attempt

Run the plan exactly as above. It is a one-shot: there is no slack to retry the switch facing up.
- If the switch doesn't fire at step 4 (at 13 units), facing matters. I'd stop and record that.
- The refill bar reading settles the refill question: 62 rows means a reset, 40 rows means a 10-unit refund.

## 4. Changes to the formal system

`lean/M15fwModel.lean` is amended, not rewritten:
- **New board slot:** `item`, the item's cells (level data).
- **New position slot:** `item : Bool`, whether the item is still there. Two attempt-4 positions it tells apart: the move onto (33,23) with the item present resets the bar; the same move without it does not.
- **Refill rule:** added in `stepPos .move`. A 2×2 overlapping the item clears it, sets spent to 0, then charges the move.
- **Grow rule:** `applyEffect .shrink` on a 2×2 now gives a 4×4 at (r−2, c−2). This used to be "not in model". There is a `decide` example of the attempt-4 transition.
- **Switch data:** the `casts` table gains a ninth row, the firing away from the stalk.

The old file `lean/M15fwL4.lean` is marked SUPERSEDED. Its level-4 model had no refill and no grow, so it was stricter than the game.

## 5. Proof: `lean/M15fwL4Win.lean`

The main theorem is `l4_winnable`. For every switch rule `fires` satisfying the explicit hypothesis `HypCol` (fires exactly when the cursor's left column is 31 or 32, whatever its facing, size or row), running the plan from the level-4 start wins:

```
(runA level4 fires start4 plan).2 = true
```

Where the Lean model is stricter or carries premises:
- **Overspending is checked before the win**, the cautious order.
- **The refill semantics is fixed as reset-then-charge.** That is a premise built into the definition, not a separate hypothesis.

It leans on these rules: move_step4, barrier blocking, completion reset, shrink (top-left corner kept), grow, switch effect plus `HypCol`, refill, goal_win, and the costs.

Extra theorems:
- `plan_spent`: the plan ends with spent = 18.
- `plan_dies_without_refill`: without the item the same plan dies, so the refill is load-bearing.
- `plan_needs_switch`: the plan doesn't win if the switch never fires.

```
'M15fw.l4_winnable' depends on axioms: [propext, Quot.sound]
'M15fw.plan_spent' depends on axioms: [propext]
'M15fw.plan_dies_without_refill' depends on axioms: [propext]
'M15fw.plan_needs_switch' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** I searched budget, action cost, completion surcharge, the cost of the swallowed first action, display rounding, the game-over rule, and the refill semantics: reset-then-charge, reset-free, or a refund of 0–40 units. For level 4 across all four attempts, 24 raw combinations survive, which come down to **2 physically distinct** ones. Both have budget 18, completion surcharge 1, ceil rounding, and game over when units go negative. They differ only in the refill:
- (i) the refill resets the budget, then charges the move;
- (ii) the refill refunds exactly 10 units. That happens to equal what had been spent before the only refill I've observed.

The conclusion changes across them: the plan wins under (i) and dies at 24 units under (ii).

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step equals side length | Attempt 1, L1: a 2×2 moved 2 |
| Wall clamp | Attempt 1, L1, step 5 |
| Barrier blocks the 4×4 | Attempt 1, L3, step 32 |
| Barrier blocks the 2×2 | Attempt 2, column 43 |
| Win on overlap | Attempt 1, L1, step 17 |
| Completing click costs 2 | Attempt 1, L4, step 54 |
| Switch, column rule | Attempt 3: column 33 didn't fire, column 31 did; attempt 4: column 31 in the room fired |
| Grow | Attempt 4: 2×2 at (29,31) became 4×4 at (27,29) |
| Refill needs a 2×2 | Attempt 4 refilled; attempt 1 (4×4 covering the item) didn't |

Two premises still lack a decisive experiment:
- **Switch, facing:** never varied at column 31. The plan's own step 4 tests it.
- **Refill, reset versus refund:** separated only by refilling at a different spent value. The plan does this, refilling at 16 rather than 10.

**c. Budget range.** I recompiled with different values of B4:
- **The winnability theorem:** fails at 16 and 17, holds at 18, 19 and 30. So it needs exactly the measured budget, with no margin.
- **The old impossibility theorem:** held up to B = 19 in its abstraction, yet the game turned out winnable at 18 under the new rules. That is the stricter-model failure: it lacked refill and grow.

VERDICT: winnable
CONFIDENCE: 55

## Attempt 5

## 1. What happened on level 4

The level-4 goal sits behind a barrier. A "switch" pattern drawn on the panel removes it, but only when the cursor stands in the switch's column. The plan from last time went exactly as predicted through its first part: shrink to the small 2×2 cursor and move it to column 31. Then I drew the switch pattern with the cursor facing left, and nothing happened. That was the plan's one untested assumption, so the route was dead.

I spent the 5 units left stepping up once, so the cursor faced the switch, and drawing it again. It fired. The attempt failed because the switch needs the cursor to face up, toward it. Every earlier firing happened to face up, so I had never separated facing from column.

## 2. Yes, I see a winning route: `plan2`

The route, with units spent after each stage (budget 18):

| Stage | Actions | Spent |
|---|---|---|
| Start | 4×4 at row 25, column 37 | 0 |
| Move to (33,33) | down, down, left | 3 |
| Shrink | 4 clicks → 2×2 at (33,33) | 8 |
| Reach column 31 facing up | down, left, up → (33,31) | 11 |
| Switch | 3 clicks → barrier opens | 15 |
| Go to the item | left ×4; the 4th lands on it and refills | 18, then 1 |
| Line up | right ×5, up → (31,33) | 7 |
| Grow | 4 clicks → 4×4 at (29,31) | 12 |
| Finish | right ×6 → overlaps the goal | 18 |

It needs two refill details I have not checked:
- **(a) Order:** the step onto the item is taken with all 18 units spent. The game must apply the refill before it checks whether the budget is exceeded.
- **(b) Kind of refill:** it must reset the budget, not refund exactly 10 units. My only refill reading fits both.

The switch rule ("column 31 and facing up") now has a test where only the facing changed. Everything else in the route has been observed.

## 3. Next attempt

Run `plan2` exactly. The bar reading after the refill step settles both open premises:
- 62 rows means a reset, applied before the budget check, and the plan continues.
- If the game ends on that step, the budget is checked first.
- 40 rows means a 10-unit refund.

## 4. Changes to the formal system

I amended the existing files rather than rewriting them:
- **`lean/M15fwModel.lean`:**
  - The switch-trigger data table `casts` gains two attempt-5 rows (facing left at column 31: no fire; facing up: fired).
  - A `decide` check now shows the column-only rule fails against the data.
  - Another shows "column and facing up" fits all 11 recorded completions.
  - New object `RefillSem`: reset or refund, and whether the refill comes before the budget check. It is an explicit parameter of `stepPos`.
- **`lean/M15fwL4Win.lean`:** `runA` now honours `RefillSem`. I added `HypColUp`, `plan2`, and the new theorems. The attempt-4 theorem stays, marked as resting on a premise now known false.
- **`settle.py`:** fixed to record the raw transition count, so the method's gate no longer locks.
- **`work/MODEL.md`:** has an "Amendments from attempt 5" section.

## 5. Proof: `lean/M15fwL4Win.lean`, theorem `l4_winnable2`

**What it says:** for every switch rule `fires` satisfying `HypColUp` (fires exactly when the cursor's left column is 31 or 32 and it faces up), running `plan2` from the level-4 start wins within budget B4 = 18.

**What it assumes:**
- `HypColUp`, stated as an explicit hypothesis.
- The refill semantics: the `RefillSem` defaults are reset, then charge the move, then check the budget. These are visible defaults, but they are premises, not established facts.

**Rules it leans on:** move step size and wall clamping, the barrier blocking, the panel clearing on completion, shrink keeping the top-left corner, grow, the switch effect, refill, the win-on-overlap rule, and the costs (1 per action, 2 for a completing click, game over once over 18).

**Theorems showing which premises matter:**
- `plan2_dies_check_first`: if the budget is checked before the refill, `plan2` dies, so premise (a) matters.
- `plan2_dies_refund10`: under a fixed 10-unit refund, `plan2` dies, so premise (b) matters.
- `plan_fails_colUp`: the attempt-4 plan fails under the new switch rule, as I observed.
- `plan2_needs_switch`: `plan2` does not win if the switch never fires.

```
'M15fw.l4_winnable2' depends on axioms: [propext, Quot.sound]
'M15fw.plan2_dies_check_first' depends on axioms: [propext]
'M15fw.plan2_dies_refund10' depends on axioms: [propext]
'M15fw.plan_fails_colUp' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** The search covered:
- budget B up to 400, ordinary cost c up to 20, completion surcharge x up to 40;
- the cost of the first action after a reset (swallowed);
- floor, ceil or round for the display, and game over at R < 0 versus R ≤ 0, where R is units left;
- refill as reset-then-charge, reset-free, or a refund of 0–40 units.

On level 4 across all five attempts, 24 raw combinations survive. They reduce to 2 physically distinct ones, both with budget 18, completion surcharge 1, ceil rounding and game over at R < 0:
- (i) the refill resets the budget, then charges the move;
- (ii) the refill refunds exactly 10 units.

The conclusion changes between them: `plan2` wins under (i) and dies under (ii). Attempt 5 made no refill, so it couldn't separate them.

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step = side length | Attempt 1, L1: a 2×2 moved 2 (tid fb6f…) |
| Wall clamp | Attempt 1, L1 step 5 (2e39…) |
| Barrier blocks | Attempt 1, L3 step 32, and attempt 2, L4: 2×2 at column 43, k = 0 |
| Win on overlap | Attempt 1, L1 step 17 |
| Completing click costs 2 | Attempt 1, L4 step 54 |
| Grow | Attempt 4: 2×2 (29,31) → 4×4 (27,29) |
| Refill needs a 2×2 | Attempt 4 refilled; attempt 1's 4×4 covering the item did not |
| Switch: column | Attempt 3: column 33 failed, column 31 fired (4×4 vs 2×2) |
| Switch: facing | Attempt 5: column 31 facing left failed, then facing up fired |

**Still missing:** decisive experiments for the refill order and the refill kind. The experiment is `plan2`'s own refill step: refill at spent 18 and read the bar.

**c. Budget range:** this is a winnability result, so the relevant range is the smallest budget at which it holds:
- B4 = 17: fails.
- B4 = 18: holds.
- B4 = 25: holds.

It needs exactly the measured budget, with no slack. At 25 only `plan2_dies_check_first` breaks, as expected, because more budget makes the check-first death go away.

The superseded impossibility theorem in `M15fwL4.lean` survived up to 19 in a model without refill or grow, yet the game turned out to have a cheaper route. That is the stricter-model failure that made attempts 1–3 wrong.

VERDICT: winnable
CONFIDENCE: 50

## Attempt 6

## 1. What happened on level 4

The goal sits behind a barrier. The barrier opens only when the cursor is a small 2×2 in column 31, facing up, and the switch pattern is drawn on the panel. A small cursor can be grown back to the fast full-size 4×4. There is also an item that refunds budget. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

My plan ran exactly as predicted up to the refill:
- shrink to 2×2;
- go to column 31 facing up, where the switch fired and the barrier opened;
- step onto the item with all 18 units spent.

That step was allowed, but the bar came back to only 9 units left, not 17. The item is a fixed refund of 10 units, not a reset to full. Attempt 4's refill read the same way: 10 spent became 1.

My plan had assumed a reset. With 9 units left nothing could reach the goal, and the attempt ended once the budget ran out.

## 2. Can level 4 still be beaten? No, under my established rules

**Claim:** no action sequence wins level 4. This rests on an exhaustive computer search, not on a Lean proof.

**Premises, each observed directly:**
- **Moves:** step size equals the cursor's side, shortened at walls.
- **Barrier:** blocks both cursor sizes until opened.
- **Panel:** clicking toggles a cell; completing a pattern clears the panel.
- **Shrink and grow:** shrinking keeps the top-left corner; growing makes a 4×4 at (r−2, c−2).
- **Switch:** fires only at column 31 or 32 while facing up.
- **Refill:** only a 2×2 overlapping the item triggers it, and it refunds exactly 10.
- **Budget:** 18 units, game over once spent exceeds 18. The refill is applied before that check.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` explores every reachable situation in the full model: position, size, facing, panel marks, barrier state, item and budget.
- It finds no winning route at budget 18, 19 or 20.
- The cheapest win needs a budget of 21 (`DDLLL`, shrink, refill, down, right, grow, right ×2, up, switch, right ×6).
- `work/reach_l4.py` repeats the search with spending floored at 0, in case the bar caps at full. It finds 651,655 reachable situations, none of them won.

**Not checked (assumptions):**
- clicks outside the panel (on the switch, the item, the recipe boxes or the goal);
- actions 5 and 7;
- a 4×4 firing the switch. The search allows it, so it is the loose direction and can't cause a false "impossible".

## 3. Next attempt

The established rules leave no route, so I'll spend the budget on the specific untested mechanisms that could change that:
1. Click the switch (around x=31, y=6).
2. Click the item (x=23, y=34).
3. Click the recipe boxes.
4. Try actions 5 and 7.

Each costs about 1 unit. If any of them opens the barrier or refunds more, I'll re-run the search before playing on.

## 4. Changes to the formal system

These are amendments to the existing files, not a rewrite.

- **Refill semantics:** the `RefillSem` defaults are now a refund of 10 units, applied before the budget check (both observed). The old route theorems now name their refuted "reset" premise explicitly as `resetSem`.
- **Panel toggle:** `setAt` now toggles a cell instead of only setting it, with an example check.
- **Switch observations:** `casts` gains a 12th row, a firing I predicted at (33,31) facing up.
- **New theorems:** `plan2_dies_observed` and `plan3_dies_observed` show the two candidate routes fail under the observed rules.

Details are in `work/MODEL.md` under "Amendments from attempt 6".

## 5. Proof: it does not go through

I have no Lean proof of impossibility. Two things block it:
- **The full model is too big.** 651,655 reachable situations is far beyond what the Lean kernel can check by brute force with `decide`.
- **The small model is too loose.** A version that ignores rows is small enough to check, but it admits a win that uses exactly 18 units, because it skips three row moves the real board forces. So it cannot prove impossibility.

**What would close the gap:** a hand-built potential-function proof (a provable lower bound on remaining cost) that keeps the row positions that matter. I have not written it.

**What does compile** (`lean/M15fwL4Win.lean`) only rules out specific routes, not all of them:

```
'M15fw.plan2_dies_observed' depends on axioms: [propext]
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.l4_winnable2' depends on axioms: [propext, Quot.sound]
```

`l4_winnable2` rests on the reset premise, which this attempt refuted.

**Lean model vs Python search:**
- The Lean model floors spending at 0 on a refund; `search_l4.py` lets it go negative.
- `reach_l4.py` floors it, like Lean.
- Both find no win at budget 18.

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks

**a. Budget fit.** I searched over:
- budget, action cost and completion surcharge;
- refill as reset-then-charge, reset-free, or a refund of 0–40 units;
- display rounding and the game-over rule.

Every recorded reading across all six attempts was kept. Level 4 has 4 raw survivors, which are one physical solution:
- budget 18, completion surcharge 1, refund 10 (the four are the same values at different unit scales);
- ceil rounding, game over when units left go below 0.

"Reset" is eliminated: this attempt's refill read 9 units left, and reset predicts 17. With one survivor, no conclusion varies.

Two bugs in the fit script were fixed before this result:
- it mistook a refill at bar 0 for a service restart;
- it mistook an un-mark click for a pattern completion.

**b. Decisive experiments**, all attempt 1 unless stated:

| Rule | Observation that would have differed |
|---|---|
| Step equals side | A 2×2 moved 2 |
| Wall clamp | Step 5: a 4×4 moved only 2 at the wall |
| Barrier blocks | Level 3 step 32; attempt 2 with a 2×2 |
| Completing click costs 2 | Level 4 step 54 |
| Grow anchor | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refill is a refund of 10 | Attempt 6: 9 units left, against 17 predicted by reset |
| Refill comes before the budget check | Attempt 6: the step at 18 spent survived |
| Toggle | Attempt 6 |

Two rules still have no decisive experiment: whether clicks off the panel do anything, and whether spending can go below 0 on a refund. The second doesn't change the answer, since both variants were searched.

**c. Budget range.** I swept the budget with the Python search, since there's no Lean impossibility theorem:
- B = 18, 19 and 20: impossible.
- B = 21: the first value at which a win appears.

The result holds only up to 3 units above the measured budget. So it is not an artefact of a model much stricter than the game. Its weight rests on the switch, refill and move rules, all of which have decisive observations.

VERDICT: impossible
CONFIDENCE: 65

## Attempt 7

## 1. What happened on level 4

The goal sits behind a barrier. To remove it, a pattern has to be drawn on a panel while the cursor stands in column 31 facing up. The budget is 18 units: 1 per action, 2 for a click that completes a pattern. A refill item gives back 10 units. Going by every rule I had, the cheapest possible win costs 21 units.

This attempt did two things:
- **Checked the remaining unknowns.**
  - Clicking anywhere outside the panel (the switch, the item, the goal, the barrier) does nothing and costs nothing.
  - Clicking the recipe boxes only changes which pattern hint the panel shows.
  - Actions 5 and 7 are refused by the service.
- **Played that cheapest route anyway:** shrink, collect the refill, grow back, fire the switch as a 4×4 (column 31, facing up), then run right. Every step behaved exactly as modelled. The budget ran out on the 4th of the final six moves, two moves short of the goal, exactly where predicted.

It fails because the cheapest winning route needs 21 units and the level gives 18 plus a 10-unit refill.

## 2. Can level 4 be won? No, under my established rules.

**Claim:** no sequence of actions wins level 4 with the 18-unit budget.

**Premises, each observed directly:**
- **Moves:** a cursor moves by its own side length (4 or 2), shortened at walls.
- **Barrier:** it blocks both cursor sizes until it is opened.
- **Panel:** each click toggles one cell (1 unit). Completing a pattern costs 2 and clears the panel.
- **Shrink and grow:** a 4×4 shrinks keeping its top-left corner. A 2×2 grows back to a 4×4 at (r−2, c−2).
- **Switch:** fires only when the cursor is in column 31 or 32 and facing up.
- **Refill:** only a 2×2 overlapping the item collects it. It refunds exactly 10, applied before the budget check.
- **Budget:** 18 units, game over once spent exceeds 18. The only legal actions are 1–4 and 6, and clicks off the panel are free no-ops.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` is an exact shortest-path search over the full model: position, size, facing, panel marks, barrier state, item and budget. With budget 18, 19 or 20 it finds no winning sequence; the first budget with a win is 21.

`work/reach_l4.py` repeats the search with spending floored at 0, in case the bar cannot go above full. It finds 651,655 reachable situations and none is a win.

**Load-bearing premises:** the bound rests most on three rules, each with a decisive observation:
- Switch needs column 31 *and* facing up (attempts 3 and 5).
- The 10-unit refund (attempts 4 and 6).
- Move step equals side length.

**Not established:** this is a computer search over my rules, not a Lean proof (see §5). No specific untested mechanism remains that I can name.

## 3. Next attempt

My rules give no winning route. I would run the cheapest route again and watch for any deviation from the model. If it matches step for step, I stop once the game ends.

## 4. Changes to the formal system

These are amendments, not a rewrite:
- **New action `Act.offClick`:** a click off the panel. It changes nothing and costs 0. Actions 5 and 7 get no constructor, since the service rejects them.
- **Dropped:** the recipe-box hint. It is a display slot that no rule reads.
- **Switch data:** the `casts` table gains a 13th row, a full-size cursor that fired as predicted.
- **New Lean theorems:**
  - `plan3_prefix25_spent` and `plan3_prefix26_dead` reproduce the observed death point exactly.
  - `offClick_noop` shows a free off-panel click changes nothing.
- **`fit_budget.py`:** the cost of off-panel clicks is now searched as a separate case.

## 5. Proof: it does not go through

I have no Lean proof that level 4 is impossible.
- **The full model is too large to certify in Lean:** 651,655 reachable situations.
- **A smaller version that ignores rows is too loose:** it admits a win at exactly 18 units, because it skips three vertical moves the real board forces.
- **What is missing** is a hand-built lower bound on remaining cost that keeps the row positions that matter. I have not written one.

What does compile is in `lean/M15fwL4Win.lean`. These theorems rule out the specific routes I played, not all routes:

```
'M15fw.plan2_dies_observed' depends on axioms: [propext]
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.plan3_prefix26_dead' depends on axioms: [propext]
'M15fw.offClick_noop' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes. One action constructor and one data row were added, a display slot was dropped, and the attempt-7 replay was reproduced in Lean.

## 7. Checks

**a. Budget fit.** I searched over:
- budget, action cost and completion surcharge;
- refill as a reset or a refund of 0–40 units;
- off-panel click cost of 0 or 1 action;
- swallowed first action, display rounding, and the game-over rule.

Every reading from all seven attempts was used. Level 4 has 4 raw survivors, which collapse to one physical solution:
- 18 units, completion costs 2, refund 10, off-panel clicks cost 0;
- ceil rounding, game over when the remainder goes below 0.

No conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step equals side length | Attempt 1: a 2×2 moved 2 |
| Wall clamp | Attempt 1, step 5 |
| Barrier blocks | Attempt 1 L3 step 32; attempt 2 with a 2×2 |
| Completing click costs 2 | Attempt 1, L4 step 54 |
| Grow | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refund 10 | Attempt 6: 9 units left, not 17 |
| Refill before the budget check | Attempt 6 |
| Toggle | Attempt 6 |
| Off-panel no-op | Attempt 7 (switch, item, goal and barrier clicks) |

No load-bearing rule lacks a decisive experiment.

**c. Budget range.** I swept the budget with the Python search, since there is no Lean impossibility theorem:
- B = 18, 19 and 20: impossible.
- B = 21: the first value at which a win appears.

Attempt 7 played out that route and died exactly where the model said. So the result holds only up to 3 units above the measured budget, which is not a model meaningfully stricter than the game.

VERDICT: impossible
CONFIDENCE: 75

## Attempt 8

## 1. What happened on level 4

Level 4 is a room with the cursor, a goal behind a barrier, a switch that removes the barrier, a refill item and a budget of 18 units. I already believed the level could not be won, so this attempt tested the last untried interactions and then replayed the cheapest route.

- **Clicks on the cursor and on an empty floor cell:** both did nothing and cost nothing, like every other click outside the panel.
- **The refill item, collected from a different row:** it again gave back exactly 10 units.
- **The cheapest route, replayed:** shrink, refill, grow back, fire the switch facing up at column 31, then run right toward the goal. Every step behaved as modelled, and the budget ran out on the 4th of the six final moves right, as predicted.

It fails because the cheapest winning route costs 21 units and the level allows 18.

## 2. Can level 4 be won? No, under my established rules

**Claim:** no action sequence wins level 4.

**Premises, each with a decisive observation:**
- **Movement:** a move goes as far as the cursor's own width, shortened at walls.
- **Barrier:** it blocks both cursor sizes until it is opened.
- **Panel:** clicking a cell toggles it and costs 1. Completing a pattern costs 2 and clears the panel.
- **Shrink and grow:** shrinking keeps the top-left corner. Shrinking a small cursor grows it back with the corner offset by (−2, −2).
- **Switch:** it fires only when the cursor is at column 31 or 32 and facing up.
- **Refill:** only the small 2×2 cursor triggers it, it refunds exactly 10, and it is applied before the budget check.
- **Budget and clicks:** 18 units, game over once spending goes above 18. Clicks outside the panel are free and do nothing; actions 5 and 7 don't exist.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` is an exact shortest-path search over every reachable combination of position, size, facing, panel marks, barrier state, item and budget. It finds no win at budgets 18, 19 or 20; the first budget with a win is 21.

**Robustness checks:**
- `work/reach_l4.py` repeats it with the refund capped so spending can't go below zero: 651,655 reachable states, none won.
- `work/search_turn.py` adds a hypothetical rule that a blocked move still turns the cursor: still no win up to 20.

The bound leans most on the switch rule (column and facing), the refund of 10, and step size equal to cursor width.

**What this rests on:** it is a computer search over my rules, not a Lean proof (see §5). I can't name any specific untested mechanism left that would change the answer.

## 3. Next attempt

My rules leave no winning route. I would replay the cheapest route once more to watch for any deviation from the model, and stop when the game ends.

## 4 and 6. Formal system

FORMAL-UNCHANGED: this attempt clicked the cursor and empty floor, collected the refill from row 35, checked the "blocked move turns" variant by search only, and replayed the cheapest route. Each result confirmed a rule already in the model: off-panel clicks are no-ops, a 2×2 overlapping the item in any row refunds 10, and plan3 dies on action 26, which the Lean theorem `plan3_prefix26_dead` already reproduces. The model would have changed only if one of these had deviated: a click doing something, a different refund amount, or the route surviving longer or dying earlier.

## 5. Proof: it does not go through

There is no Lean impossibility theorem.
- **The full model is too large:** about 651,655 reachable states, far beyond what Lean's kernel can check by brute force.
- **The small model is too loose:** a version that ignores row positions is small enough to check, but it admits a win at exactly 18 units because it skips three row moves the real board forces.
- **What is missing:** a hand-built lower bound on remaining cost that keeps the rows that matter. I haven't written it.

What does compile, in `lean/M15fwL4Win.lean`, is a set of theorems about the specific routes I played, not about every route:
```
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.plan3_prefix26_dead' depends on axioms: [propext]
'M15fw.offClick_noop' depends on axioms: [propext]
```

## 7. Checks

**a. Budget fit.** I refitted the cost parameters over every recorded bar reading from all eight attempts. The search covered:
- budget, action cost and completion surcharge;
- refill as a reset or as a refund of 0–40 units;
- off-panel click cost of 0 or 1;
- display rounding and the game-over rule.

Level 4 has 4 raw survivors, which are the same physical solution at different unit scales:
- budget 18, completing click 2, refund 10, off-panel click 0;
- display rounds up, game over when the remaining budget goes below 0.

So no conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step size = cursor width | Attempt 1: the 2×2 moved 2 |
| Wall clamp | Attempt 1, step 5 |
| Barrier blocks | Attempt 1, level 3 step 32; attempt 2 (2×2) |
| Completing click costs 2 | Attempt 1, level 4 step 54 |
| Grow | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refund 10, not a reset | Attempt 6: 9 units left, where a reset would have left 17 |
| Refill before the budget check | Attempt 6 |
| Off-panel clicks are no-ops | Attempts 7 and 8 |

No load-bearing rule lacks one.

**c. Budget range.** With no Lean theorem, I swept the budget with the search instead:
- budgets 18, 19 and 20: no win;
- budget 21: the first value that wins.

Twice the 21-unit route died exactly where the model said. So the result holds only up to 3 units above the measured budget, which means the model isn't much stricter than the game.

VERDICT: impossible
CONFIDENCE: 75

## Final interview

## 1. What happened on level 4

Level 4 is a room with:
- a cursor that starts full-size (4×4);
- a goal at the right end of a corridor, closed off by a barrier;
- a switch above the room;
- a small item;
- a budget of 18 units shown as a bar.

The barrier only disappears if I draw the switch pattern on the panel while the cursor sits in the switch's column (31) facing up. The full-size cursor moves in steps of 4 and can never stand in column 31. So it has to shrink to 2×2 (a 5-unit pattern), go to column 31, and either fire the switch small or grow back to full size (another 5 units) and fire it there. The item refunds 10 units when the small cursor touches it.

Added up, the cheapest complete route costs 31 units against the 18 + 10 = 28 available. In the last attempts I played that route and the budget ran out on the fourth of the final six moves to the goal, two moves short, exactly where my model predicted. Earlier attempts failed because I was still discovering these rules: facing, refund size, grow, the switch column.

## 2. Can level 4 be won? No, under my established rules

**Claim:** no sequence of actions wins level 4 from its start.

**Premises:**
- **P1, movement:** a move goes up to the cursor's side length (4 or 2), stopping short at walls. Colours 5 and 13 block.
- **P2, barrier:** it blocks both cursor sizes until the switch fires.
- **P3, panel:** clicking a panel cell toggles it and costs 1. Completing a pattern costs 2 and clears the panel. Clicks off the panel cost 0 and do nothing. Actions 5 and 7 don't exist.
- **P4, shrink and grow:** the shrink pattern on a 4×4 gives a 2×2 at the same top-left corner. On a 2×2 it gives a 4×4 at (row−2, column−2).
- **P5, switch:** fires only if the cursor's left column is 31 or 32 and it faces up.
- **P6, refill:** only a 2×2 overlapping the item triggers it. It refunds exactly 10, once, applied before the budget check.
- **P7, budget:** game over once spending exceeds 18.
- **P8, win:** any overlap with the goal.

**Argument:** two exhaustive searches over every reachable state of a model built from P1–P8 (position, size, facing, panel marks, barrier state, item, units spent):
- `work/search_l4.py` lets spending go below zero after a refund. It finds no win at budgets 18, 19 or 20. The first winning budget is 21, via the route I played.
- `work/reach_l4.py` caps spending at zero. It reaches 651,655 states and none is a win.

**What the bound leans on:** mostly P5, P6 and P1. Each has a decisive observation (section 3), and the 21-unit route died exactly where predicted in two separate attempts.

**Not established:** the claim rests on these searches, not on a Lean proof. I can't name a specific untested mechanism that would change it. I tested every kind of off-panel click, actions 5 and 7, and both rows for collecting the item.

## 3. Rules I worked out, and the observation behind each

- **Switch needs column 31/32 and facing up.**
  - Attempt 3: the 4×4 at column 33 didn't fire; the 2×2 at column 31 did.
  - Attempt 5: the 2×2 at column 31 facing left didn't fire; one move later, facing up, it did.
- **Shrink on a 2×2 grows it** back to 4×4 at (r−2, c−2). Attempt 4: 2×2 at (29,31) became 4×4 at (27,29).
- **Item refund:** only a 2×2 triggers it; a 4×4 covering the item in attempt 1 did not.
  - Refund is exactly 10, not a reset: attempt 4 went from 10 spent to 1, attempt 6 from 18 spent to 9.
  - Applied before the budget check: the refill move at 18 spent survived in attempt 6.
- **Costs:** 1 per action, 2 for a completing click, level-4 budget 18, game over once spending exceeds it. A search over all bar readings leaves exactly one solution.
- **Panel cells toggle:** attempt 6.
- **Off-panel clicks are free no-ops:** attempts 7 and 8.

## 4. Rules I'm still unsure about

- **Whether a refund can push spending below zero** (that is, whether the bar is capped at full). Both versions were searched and neither wins, so this doesn't change the verdict.
- **What a blocked move does to facing.** I assume it doesn't turn the cursor. The opposite rule was also searched (`work/search_turn.py`) and still finds no win up to budget 20.
- **Switch firing at column 32.** No cursor can stand there, so it's irrelevant.

## 5. Lean proof: the impossibility theorem does not go through

I have no Lean proof of the full claim.
- **The full model is too large.** Its reachable state space (~650k states) is far beyond what Lean's kernel can check by brute force. My compiled `decide` checks run at roughly a tenth of a second per simulated step.
- **The coarser model is too loose.** The version that ignores rows is small enough to check, but it admits a win at exactly 18 units because it skips three row moves the real board forces. So it can't prove impossibility.
- **What's missing:** a hand-built lower bound on remaining cost that keeps the necessary row moves, proven step by step like `lean/M15fwL4.lean` did for an earlier, refill-free model. I didn't write it.

What does compile (`lean/M15fwL4Win.lean`, on top of `lean/M15fwModel.lean`) are theorems about the specific routes I played. Each quantifies over nothing: it evaluates one route under the observed rules (refund 10, firing needs column and facing up).

```
'M15fw.plan2_dies_observed' depends on axioms: [propext]
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.plan3_prefix26_dead' depends on axioms: [propext]
'M15fw.offClick_noop' depends on axioms: [propext]
```

- `plan2_dies_observed`: the attempt-6 route doesn't win.
- `plan3_dies_observed`: the cheapest route doesn't win.
- `plan3_prefix26_dead`: the cheapest route dies on action 26 with 19 spent, matching attempts 7 and 8.
- `offClick_noop`: off-panel clicks change nothing.

They show the model reproduces what I saw. They don't show impossibility over all routes. That claim stands on the Python searches over the same rules, not on a checked proof.

VERDICT: impossible
CONFIDENCE: 75
