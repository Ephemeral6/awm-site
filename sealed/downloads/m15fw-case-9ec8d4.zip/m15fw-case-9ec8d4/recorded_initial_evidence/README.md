# L4 / Claude Opus 5.5 + AWM / 9ec8d4

- **实验类别**：主表：AWM原始实验
- **关卡/受试**：L4 / Claude Opus 5.5 + AWM
- **论文位置**：主表原始阶段
- **预算/轮次**：8次
- **结果**：impossible；界：20
- **最终声明**：impossible
- **注意**：原始界20；射击规则Hyp是显式前提。不要用同目录后来的界19定理替代。
- **初始数值计分**：未计为正确界

## 从哪里检查

1. [受试逐轮/汇总答复](interviews.md)。这是阅读入口。
2. [原始JSON / 会话提取](run.json)。摘录与索引有歧义时以原始记录为准。
3. [本阶段主证明](proof_sources/M15fwL4.lean)；主定理 `M15fwL4.l4_no_win_B4`。
   Explicit Hyp fires; old bound20. FinalProof.lean in same copied directory is a later bound19, not the original main result.
- [原始游戏服务记录](server)。
- [完整证明源码目录](proof_sources)。

## 同一case的其他阶段

- [外部反馈后：AWM修复](../../05_awm_repair/strict_four_attempts/L4-m15fw-case-9ec8d4/README.md)

## 采集来源

`D:\THU\2026 Summer\ARC-AGI\ours\benchmarks\armkit\run_m15_m15fw-case-9ec8d4.json`

这是采集时的来源路径；当前arena可能已经经过后续修复，不能代替本目录保存的阶段快照。

**不要混用**：这里原始界20对应 `M15fwL4.lean`；同目录 `FinalProof.lean` 已是后来的界19。

[返回本类实验](../README.md) · [返回实验总表](../../EXPERIMENTS.md)
