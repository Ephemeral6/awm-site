## play 1

I beat levels 1–3 and the game ended in `GAME_OVER` on level 4, so I did not beat the game. I did not call `/reset`.

**What the game turned out to be:**
- **Moving:** you steer a 9/10-coloured block with actions 1–4 (up, down, left, right). Each move goes as far as the block's own width or height, stopping short at walls. Colours 5 and 13 block it.
- **Panel:** clicking the 3×3 panel at the bottom and completing the pattern shown in the recipe box beside it triggers an effect:
  - colour 15 pattern: shrinks the block to 2×2;
  - colour 11 pattern: teleports the block to a marked spot;
  - colour 6 pattern: removes a switch and a barrier.
- **Winning a level:** any overlap with the goal frame wins it.
- **Action budget:** the bar on the right edge loses rows with every action, faster on each level. On level 4 it was 4 rows per action, about 16 actions in total. The game ended on the action after the bar hit zero.

**Why level 4 failed:**
- **The switch didn't fire:** I completed the switch pattern twice with no effect, although the same set-up had worked on level 3. I still don't know what it needs there.
- **The pickup wasn't a refill:** I spent my last moves on a small item the same colour as the bar, betting it would refill it. It didn't, and the bar ran out.
- **The real mistake:** I didn't plan the whole route before acting on a level where actions cost that much.

**Method:** I followed `METHOD.md` with the provided scripts: a bet before every action, a settle after each batch, every counterexample fixed before moving on. Four rules are on file, all scoring S = 1.000 on the moves they were tested against:

| Rule | Moves tested (N) | Coverage (C) |
|---|---|---|
| `move_step4` (5th version) | 33 | 0.57 |
| `front_leads` | 33 | 0.51 |
| `panel_click` | 6 | 0.09 |
| `goal_win` | 45 | 0.68 |

The Lean step isn't done, because `METHOD.md` puts it after the run. I also saved these mechanics and the level-4 problem to memory in case there's another attempt.

`work/REPORT.md` has the rule table with revision history, the table of mechanisms left out of the rules, the bets that missed, and actions I never tried.

## probe 1

## 1. What happened on level 4

The cursor (a 4×4 block) starts in a room. The goal sits at the end of a corridor that a colour-13 barrier closes off completely. The only way I know to remove that barrier is the "switch" pattern: on level 3, drawing it on the panel deleted both the switch and the barrier.

On level 4 I drew that same pattern twice:
- once with the cursor facing left, under the switch's stalk;
- once facing up and touching the stalk, which is exactly how it had worked on level 3.

Neither time did anything open. I then spent my remaining actions on a small item the same colour as the budget bar, betting it was a refill. It wasn't, the bar ran out, and the game ended.

Fitting the bar readings afterwards shows level 4's budget is 18 units:
- an ordinary action costs 1 unit;
- a click that completes a pattern costs 2.

There are two causes of failure:
- I don't know what actually triggers the switch.
- I spent 9 of the 18 units testing guesses about it before planning a route.

## 2. Can level 4 still be beaten? I can't tell either way.

It turns on one rule I don't have: what has to be true for the switch to fire. Two explanations both fit all four observations:

- **H (cursor position):** the switch fires only when the cursor's left column is on the stalk (column 31 or 32).
  - The 4×4 cursor moves in steps of 4 and can only stand at columns 21, 25, …, 41. So under H it can never fire the switch itself.
  - It would first have to shrink to 2×2 (4–5 clicks), and a 2×2 cursor moves only 2 columns per step.
  - The cheapest win in my model then costs 20 units, more than the 18 available, so the level would be impossible.
  - What I established: how moves work and their step sizes, that the barrier blocks, that a completed pattern clears the panel, the win rule, and the costs.
  - What I did not establish: H itself.
- **Bump:** the switch fires anywhere, but only after the cursor has bumped into the barrier.
  - On level 3, the successful draw came after a bump and the earlier failed one came before it.
  - On level 4 I never bumped the barrier.
  - Under this explanation the route is: down, right, right (bump), three clicks, then right ×4. That costs 11 units, so the level would be winnable.

One experiment settles it: bump the barrier, then draw the switch pattern. It costs 7 units.

## 3. Next attempt

1. Move down, right, right (the last one bumps the barrier).
2. Click (x=30, y=50), (30,55), (30,60).
3. If the barrier opens, move right four times to win (11 units total).
4. If it doesn't open, H becomes the leading explanation, and under H the level can't be won in my model.

I won't touch the colour-14 item.

## 4. Formal system

This is the first formal version, so there was nothing earlier to amend.
- **Objects and rules:** listed in `work/MODEL.md`, with the slot for each object that would make two observed positions indistinguishable if dropped.
- **Lean definitions:** in `lean/M15fwModel.lean`, each rule marked as a definition, a consequence, or not in the model.
- **Checks:** `example`s in that file, checked by `decide`, reproduce the key observed transitions: the wall shortening a move to 2, the 2×2 stepping by 2, the barrier blocking, the win, and pattern completion.
- **Not in the model:** the switch's precondition. It enters only as the hypothesis `Hyp` in the theorem below.

## 5. Proof (`lean/M15fwL4.lean`)

`no_win_within` states: for every `fires` satisfying `Hyp`, and every choice sequence whose total cost is at most B (any B < 20), the run ends in a non-won state. A won state has no successor, so this covers every prefix too. `l4_no_win_B4` is that statement at B4 = 18.

The method is a potential function Φ, a lower bound on the cost still needed to win. Φ is 20 at the start, and every step lowers it by at most that step's cost.

**What the model abstracts:**
- Rows are dropped; a vertical move is a no-op that costs 1.
- The panel is reduced to two counters that a click may lower freely.
- The shrink may shift the cursor 0 or 2 columns.

All three only add transitions, so the model is looser than the game. The step from the real game to this abstraction is argued in prose, not proved in Lean.

**Rules the theorem leans on:**
- `move_step4`: the cursor moves by its side length, or less at walls.
- The barrier blocks unless opened.
- `goal_win`.
- A completed pattern clears the panel.
- The costs (1 per action, 2 for a completing click).
- `Hyp`, which is the only part stricter than what I observed.

**Non-vacuity checks:**
- `witness_wins`: a run costing exactly 20 does win under a `fires` that satisfies `Hyp`, so the bound is tight.
- `cheap_wins`: with an unrestricted `fires`, a run costing 9 wins.
- `fireAny_not_hyp`: that unrestricted `fires` violates `Hyp`.

Together these show `Hyp` is what the bound depends on.

`#print axioms`, verbatim:
```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Changes to the formal system this attempt

- Added the budget rule.
- The switch precondition "facing up and touching the stalk" was refuted by step t58, so the precondition was moved out of the model.
- The "the item refills the bar" idea was refuted.

## 7. Checks on the proof

**a. Fit (`work/fit_budget.py`).** I searched budget B ≤ 400, action cost c ≤ 20, completion surcharge x ≤ 40, cost of the swallowed first move, and floor, ceil or round for the display.
- **Level 4 alone:** 54 raw combinations survive, 30 distinct, all using ceil and with game over when units go negative. B/c lies in [17.78, 18.27] and x/c in [0.889, 1.133].
- **Same cost ratio on all four levels:** only x/c = 1 survives, giving exactly one fit: B = 18, moves and clicks cost 1, a completing click costs 2.
- **Effect on the verdict:** none, anywhere in the set. Under H the cheapest route costs 19 + x/c ≥ 19.89 action-units, above the largest possible B/c of 18.27. The bump route costs 10 + x/c ≤ 11.2, which fits everywhere.

**b. Decisive experiments** (all from attempt 1):

| Rule | Decisive observation |
|---|---|
| Step equals the cursor's side | Shrunk 2×2 moved 2, not 4 (tid fb6f…, level 1) |
| Walls shorten a move | Left move went only 2 at the wall (2e39…, level 1, step 5) |
| Barrier blocks | Move into colour 13 gave k = 0 (97fd…, level 3, step 32) |
| Win on overlap | Entering the goal frame won the level (fc55…, level 1, step 17) |
| Completing click costs 2 | Bar dropped 6 rows on a completion vs 4 for an ordinary action (level 4, step 54; also level 2, step 20) |
| Game over only once spent > B | Empty bar at step 65, GAME_OVER only at step 66 |
| `Hyp` | **None yet.** The experiment that would test it is the bump test in §3 |

**c. Budget range.** I recompiled with different B4 values:
- B4 = 18: compiles.
- B4 = 19: compiles.
- B4 = 20: fails, because `decide` refutes 20 < Φ init = 20.

So the impossibility result holds only up to 19, one unit above the measured 18. It is not a model that is simply too strict about the budget. Its whole weight rests on `Hyp`, which is the rule I suspect.

One incident: while splitting the Lean file I accidentally wrote a temporary file to `/tmp`, outside the working directory. I deleted it immediately.

VERDICT: undecided
CONFIDENCE: 55