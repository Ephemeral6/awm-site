## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed in total. The game ended in `GAME_OVER` on level 4 when the 18-unit budget ran out. I did not call `/reset`.

This attempt ran the two-part test I had planned:
1. **Full-size cursor at column 33, facing up beside the switch's stalk:** the switch pattern did nothing. If it had fired, the level would have been winnable in about 14 units.
2. **Shrunk 2×2 cursor at column 31, moved up into the stalk:** the switch fired and the barrier disappeared. That is the first time I predicted a firing in advance and it happened. It confirms the rule that the cursor's left column must match the stalk's left column, which has now fit all 8 attempts at the switch.

That confirmation is what makes the level look unwinnable. The full-size cursor moves in steps of 4 and can never land on column 31, so it has to shrink first. After firing the switch, the small cursor still needs 13 two-column moves to reach the goal. The cheapest possible win costs 20 units, more than the 18 available, as `lean/M15fwL4.lean` proves. That proof still treats the trigger rule as an explicit assumption, now backed by this test.

The last action I sent, at 18 units spent, produced the expected game over. The attempt-3 results are in `work/REPORT.md`, and the two new switch observations are added to the data table in `lean/M15fwModel.lean`, which still compiles.

## probe 1

## 1. What happened on level 4

The goal sits behind a barrier. The only way to remove the barrier is the "switch" pattern on the panel, and it fires only when the cursor stands in the right column. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

This attempt was a two-part test:
- **Full-size 4×4 cursor at column 33,** facing up beside the switch's stalk: the pattern did nothing.
- **Shrunk 2×2 cursor at column 31,** inside the stalk: the pattern fired and the barrier disappeared.

That firing took the whole budget, because shrinking and two switch patterns are expensive. The cursor still needed 13 two-column moves to reach the goal, so the next action ended the game.

Why it fails: only the cursor's left column standing on the stalk opens the switch. The full-size cursor can't stand there, and the small cursor is too slow to reach the goal within budget afterwards.

## 2. Can level 4 be beaten? No, under the established rules.

**Claim:** no action sequence costing at most 18 units wins level 4.

**Premises:**
- **P1, movement:** the cursor moves by its side length, cut short only by walls. In this room the 4×4 cursor's left column can only be 21, 25, 29, 33, 37 or 41. A 2×2 cursor moves 2 columns per step.
- **P2, barrier:** it blocks both cursor sizes until it is opened.
- **P3, panel:** completing a pattern clears the panel. Shrinking takes 4 clicks and the switch takes 3.
- **P4, winning:** the cursor must overlap the goal. For a 2×2 that means a left column of at least 56.
- **P5, budget:** 1 unit per action, 2 for a completing click, 18 in total. Game over once more than 18 are spent, with no refunds.
- **Hyp, switch trigger:** the switch fires only when the cursor's left column is 31 or 32.

**Argument:**
1. By P1 and Hyp, the 4×4 cursor can never fire the switch, so it must shrink first.
2. The small cursor must then stand at column 31 and complete the switch pattern.
3. From column 31 it still needs 13 moves to reach the goal.
4. The cheapest total is 20 units, which is more than 18.

**What is established and what is assumed:**
- **P1–P5:** each has a decisive observation (listed in 7b).
- **Hyp's firing direction:** confirmed by the predicted firing in this attempt.
- **Hyp's "only if" direction, which the bound actually uses:**
  - Tested by 4×4 cursors at columns 29 and 33, both facing up beside the stalk; neither fired.
  - Also by the L3 failure at column 37, and the L4 failures at 41 (4×4) and 43 (2×2).
  - **Never tried:** a 4×4 at columns 21 or 25 facing up. Nothing suggests either would fire, but they have not been run.
- **Mechanisms never tried:** clicking an already-marked panel cell, clicks outside the panel, and actions 5 and 7.

## 3. Next attempt

The level is unwinnable under the established rules. I would spend the attempt closing the remaining gap in Hyp: a 4×4 at columns 25 and then 21, facing up, drawing the switch pattern at each. That costs about 6 + 6 units. If either fires, the 4×4 route to the goal is cheap and I'd take it.

## 4. Changes to the formal system

These are amendments only, nothing rewritten:
- **`lean/M15fwModel.lean`:** the `casts` table gains two rows (column 33: no fire; 2×2 at column 31: fired). The `decide` check now confirms Hyp's predicate fits all 8 recorded completions.
- **`lean/M15fwL4.lean`:** `Hyp`'s docstring now cites its evidence. `Hyp` stays an explicit hypothesis.
- **`work/MODEL.md`:** an "Amendments from attempt 3" section, including a third observation that shrinking keeps the top-left corner.
- **`work/fit_budget.py`:** now uses three level-4 attempts.

## 5. Proof: `lean/M15fwL4.lean`, theorem `no_win_within`

**Statement:** for every switch rule `fires` satisfying `Hyp`, and every choice list with total cost ≤ B where B < 20, the run ends un-won. A won state has no successor, so this covers every prefix. `l4_no_win_B4` is the instance at B4 = 18.

**What it leans on:** P1–P5 and `Hyp`.

**Where the model is looser than the game** (all of these only add transitions, which is the safe direction):
- rows are abstracted away;
- the panel is reduced to two counters that a click may lower freely;
- the shrink may shift the cursor by 0 or 2 columns.

The mapping from the real game to this abstraction is argued in prose, not proved in Lean.

**Non-vacuity checks:**
- `witness_wins`: a 20-unit run does win under a `Hyp`-satisfying rule, so the bound is tight.
- `cheap_wins` and `fireAny_not_hyp`: without `Hyp`, a 9-unit run wins, so `Hyp` is load-bearing.

```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** I searched over:
- budget B ≤ 400, ordinary cost c ≤ 20, completion surcharge x ≤ 40;
- the cost of the swallowed first action;
- floor, ceil or round for the display;
- game over at R < 0 versus R ≤ 0, where R is the units left.

Refunds were checked directly: the bar never rose within a level except at the two service restarts, so the refund is 0. Using all three level-4 segments:
- 20 raw combinations survive, which reduce to 1 distinct one: B = 18, a completing click costs one extra unit, ceil rounding, and game over at R < 0.
- Across all four levels, the only common surcharge ratio is 1.

With one survivor, no conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step = side length | Attempt 1, L1: a 2×2 moved 2 (tid fb6f…) |
| Wall clamp | Attempt 1, L1, step 5: moved 2 at the wall (2e39…) |
| Barrier blocks | Attempt 1, L3, step 32 (97fd…) for the 4×4; attempt 2, L4: 2×2 at column 43 with k = 0 |
| Win on overlap | Attempt 1, L1, step 17 (fc55…) |
| Completing click costs 2 | Attempt 1, L4, step 54 (6 rows dropped instead of 4) |
| Game over only once spent exceeds 18 | Attempts 2 and 3: bar at 0 with spent = 18 and still not finished |
| Hyp, firing at the stalk column | Attempt 3: the 2×2 at column 31 fired, as predicted |
| Hyp, failing elsewhere | Attempt 3: the 4×4 at column 33, facing up beside the stalk, didn't fire; attempt 1, step 58: the same at column 29. The cursor size differed from the firing case. |

Hyp has no decisive experiment yet for 4×4 columns 21 and 25. The experiment is the next-attempt plan in section 3.

**c. Budget range:**
- B4 = 18 and B4 = 19 compile.
- B4 = 20 fails: `decide` refutes 20 < Φ init, the potential's starting value.

The bound holds only one unit above the measured budget, so the model is not stricter than the game on cost. What remains uncertain is `Hyp`, specifically 4×4 columns 21 and 25.

VERDICT: impossible
CONFIDENCE: 72