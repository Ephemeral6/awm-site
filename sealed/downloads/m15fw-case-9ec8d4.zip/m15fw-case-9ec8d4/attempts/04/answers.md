## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed. The attempt ended in `GAME_OVER` on level 4 when the budget ran out; I did not call `/reset`.

I spent this attempt on experiments, and they found three rules that my earlier "impossible" verdict on level 4 had missed:

- **The colour-14 item refills the budget.** When the small 2×2 cursor overlaps it, the item disappears and the bar goes back to full. A full-size 4×4 cursor covering it in attempt 1 did nothing.
- **The switch only cares about the column.** It fired with the small cursor in column 31 in the corridor rows, not just inside the stalk.
- **Shrinking a small cursor grows it back.** Completing the shrink pattern on the 2×2 turns it into a 4×4, with the small cursor ending up as the bottom-right quarter. That puts the full-size cursor in column 31, a column it can't reach by moving.

These were discovered with too little budget left to use them. They do give a winning route for level 4 that fits the budget, with one unit to spare:

1. Move down, down, left so the 4×4 is at row 33, column 33.
2. Shrink, step left to column 31, and draw the switch pattern, which opens the barrier.
3. Step left four times; the last step onto the item refills the bar.
4. Step right five times and up once, grow back to 4×4 in column 31, then step right six times to reach the goal.

Every step here is something I've now seen work, except one: all switch firings so far had the cursor facing up, and in this route it would be facing left. The route has no room to turn it, so if facing matters the attempt fails at step 2.

The full plan is in `work/REPORT.md`, and I saved it to memory for the next attempt.

## probe 1

## 1. What happened on level 4

The goal is behind a barrier. The barrier opens only when the switch pattern is drawn with the cursor's left column on 31. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

My earlier rules said the level was unwinnable: the full-size 4×4 cursor can't stand on column 31, and the small 2×2 is too slow to reach the goal. So I spent this attempt on experiments and found three rules I had been missing:
- **Refill:** a 2×2 cursor overlapping the colour-14 item consumes it and refills the bar. The 4×4 covering it in attempt 1 did nothing.
- **Switch:** it fires from column 31 anywhere in the room, not only in the stalk.
- **Grow:** completing the shrink pattern on a 2×2 turns it back into a 4×4, with the 2×2 as its bottom-right quarter. That puts a fast 4×4 in column 31.

I found all three too late; nothing was left to finish the level. The attempt failed because the experiments used up the budget. The earlier "impossible" verdicts were wrong because my model had no refill and no grow.

## 2. Yes, I see a winning route

The route has 38 actions:

| Phase | Actions | Units spent after |
|---|---|---|
| Start | 4×4 at row 25, column 37 | 0 |
| Move | down, down, left: 4×4 at (33,33) | 3 |
| Shrink | 4 clicks: 2×2 at (33,33) | 8 |
| Move | left: 2×2 at (33,31), facing left | 9 |
| Switch | 3 clicks: barrier opens | 13 |
| Move | left ×3 | 16 |
| Refill | left onto the item | 1 (budget reset, then this move charged) |
| Move | right ×5, up: 2×2 at (31,33) | 7 |
| Grow | 4 clicks: 4×4 at (29,31) | 12 |
| Move | right ×6: overlaps the goal on the 6th | 18 |

It rests on two premises I have not established:
- **The switch ignores which way the cursor faces.** Every firing so far had it facing up; this plan fires it facing left.
- **The refill resets the budget**, rather than refunding a fixed 10 units. One reading can't tell these apart (see 7a). If it is a 10-unit refund, the plan ends at 24 units and dies.

Everything else in the plan has been observed directly.

## 3. Next attempt

Run the plan exactly as above. It is a one-shot: there is no slack to retry the switch facing up.
- If the switch doesn't fire at step 4 (at 13 units), facing matters. I'd stop and record that.
- The refill bar reading settles the refill question: 62 rows means a reset, 40 rows means a 10-unit refund.

## 4. Changes to the formal system

`lean/M15fwModel.lean` is amended, not rewritten:
- **New board slot:** `item`, the item's cells (level data).
- **New position slot:** `item : Bool`, whether the item is still there. Two attempt-4 positions it tells apart: the move onto (33,23) with the item present resets the bar; the same move without it does not.
- **Refill rule:** added in `stepPos .move`. A 2×2 overlapping the item clears it, sets spent to 0, then charges the move.
- **Grow rule:** `applyEffect .shrink` on a 2×2 now gives a 4×4 at (r−2, c−2). This used to be "not in model". There is a `decide` example of the attempt-4 transition.
- **Switch data:** the `casts` table gains a ninth row, the firing away from the stalk.

The old file `lean/M15fwL4.lean` is marked SUPERSEDED. Its level-4 model had no refill and no grow, so it was stricter than the game.

## 5. Proof: `lean/M15fwL4Win.lean`

The main theorem is `l4_winnable`. For every switch rule `fires` satisfying the explicit hypothesis `HypCol` (fires exactly when the cursor's left column is 31 or 32, whatever its facing, size or row), running the plan from the level-4 start wins:

```
(runA level4 fires start4 plan).2 = true
```

Where the Lean model is stricter or carries premises:
- **Overspending is checked before the win**, the cautious order.
- **The refill semantics is fixed as reset-then-charge.** That is a premise built into the definition, not a separate hypothesis.

It leans on these rules: move_step4, barrier blocking, completion reset, shrink (top-left corner kept), grow, switch effect plus `HypCol`, refill, goal_win, and the costs.

Extra theorems:
- `plan_spent`: the plan ends with spent = 18.
- `plan_dies_without_refill`: without the item the same plan dies, so the refill is load-bearing.
- `plan_needs_switch`: the plan doesn't win if the switch never fires.

```
'M15fw.l4_winnable' depends on axioms: [propext, Quot.sound]
'M15fw.plan_spent' depends on axioms: [propext]
'M15fw.plan_dies_without_refill' depends on axioms: [propext]
'M15fw.plan_needs_switch' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** I searched budget, action cost, completion surcharge, the cost of the swallowed first action, display rounding, the game-over rule, and the refill semantics: reset-then-charge, reset-free, or a refund of 0–40 units. For level 4 across all four attempts, 24 raw combinations survive, which come down to **2 physically distinct** ones. Both have budget 18, completion surcharge 1, ceil rounding, and game over when units go negative. They differ only in the refill:
- (i) the refill resets the budget, then charges the move;
- (ii) the refill refunds exactly 10 units. That happens to equal what had been spent before the only refill I've observed.

The conclusion changes across them: the plan wins under (i) and dies at 24 units under (ii).

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step equals side length | Attempt 1, L1: a 2×2 moved 2 |
| Wall clamp | Attempt 1, L1, step 5 |
| Barrier blocks the 4×4 | Attempt 1, L3, step 32 |
| Barrier blocks the 2×2 | Attempt 2, column 43 |
| Win on overlap | Attempt 1, L1, step 17 |
| Completing click costs 2 | Attempt 1, L4, step 54 |
| Switch, column rule | Attempt 3: column 33 didn't fire, column 31 did; attempt 4: column 31 in the room fired |
| Grow | Attempt 4: 2×2 at (29,31) became 4×4 at (27,29) |
| Refill needs a 2×2 | Attempt 4 refilled; attempt 1 (4×4 covering the item) didn't |

Two premises still lack a decisive experiment:
- **Switch, facing:** never varied at column 31. The plan's own step 4 tests it.
- **Refill, reset versus refund:** separated only by refilling at a different spent value. The plan does this, refilling at 16 rather than 10.

**c. Budget range.** I recompiled with different values of B4:
- **The winnability theorem:** fails at 16 and 17, holds at 18, 19 and 30. So it needs exactly the measured budget, with no margin.
- **The old impossibility theorem:** held up to B = 19 in its abstraction, yet the game turned out winnable at 18 under the new rules. That is the stricter-model failure: it lacked refill and grow.

VERDICT: winnable
CONFIDENCE: 55