## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed in total. The game ended in `GAME_OVER` on level 4 when the budget ran out; I did not call `/reset`.

This attempt tested the last mechanisms I hadn't tried, then replayed the cheapest route:

- **Clicking the cursor or an empty floor cell** does nothing and costs nothing, like every other click outside the panel.
- **A blocked move turning the cursor in place** wouldn't help even if the game did it: my exhaustive search finds no winning route under that rule at budgets of 18, 19 or 20.
- **The refill item** gives back exactly 10 units whichever row the cursor collects it from.
- **The cheapest route** needs 21 units against the 18 available. I played it again and it ran out on the fourth of the final six moves, exactly where my model said it would.

Level 4 can't be won under any rule I've observed. Every observation across all eight attempts is consistent with that model.

## probe 1

## 1. What happened on level 4

Level 4 is a room with the cursor, a goal behind a barrier, a switch that removes the barrier, a refill item and a budget of 18 units. I already believed the level could not be won, so this attempt tested the last untried interactions and then replayed the cheapest route.

- **Clicks on the cursor and on an empty floor cell:** both did nothing and cost nothing, like every other click outside the panel.
- **The refill item, collected from a different row:** it again gave back exactly 10 units.
- **The cheapest route, replayed:** shrink, refill, grow back, fire the switch facing up at column 31, then run right toward the goal. Every step behaved as modelled, and the budget ran out on the 4th of the six final moves right, as predicted.

It fails because the cheapest winning route costs 21 units and the level allows 18.

## 2. Can level 4 be won? No, under my established rules

**Claim:** no action sequence wins level 4.

**Premises, each with a decisive observation:**
- **Movement:** a move goes as far as the cursor's own width, shortened at walls.
- **Barrier:** it blocks both cursor sizes until it is opened.
- **Panel:** clicking a cell toggles it and costs 1. Completing a pattern costs 2 and clears the panel.
- **Shrink and grow:** shrinking keeps the top-left corner. Shrinking a small cursor grows it back with the corner offset by (−2, −2).
- **Switch:** it fires only when the cursor is at column 31 or 32 and facing up.
- **Refill:** only the small 2×2 cursor triggers it, it refunds exactly 10, and it is applied before the budget check.
- **Budget and clicks:** 18 units, game over once spending goes above 18. Clicks outside the panel are free and do nothing; actions 5 and 7 don't exist.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` is an exact shortest-path search over every reachable combination of position, size, facing, panel marks, barrier state, item and budget. It finds no win at budgets 18, 19 or 20; the first budget with a win is 21.

**Robustness checks:**
- `work/reach_l4.py` repeats it with the refund capped so spending can't go below zero: 651,655 reachable states, none won.
- `work/search_turn.py` adds a hypothetical rule that a blocked move still turns the cursor: still no win up to 20.

The bound leans most on the switch rule (column and facing), the refund of 10, and step size equal to cursor width.

**What this rests on:** it is a computer search over my rules, not a Lean proof (see §5). I can't name any specific untested mechanism left that would change the answer.

## 3. Next attempt

My rules leave no winning route. I would replay the cheapest route once more to watch for any deviation from the model, and stop when the game ends.

## 4 and 6. Formal system

FORMAL-UNCHANGED: this attempt clicked the cursor and empty floor, collected the refill from row 35, checked the "blocked move turns" variant by search only, and replayed the cheapest route. Each result confirmed a rule already in the model: off-panel clicks are no-ops, a 2×2 overlapping the item in any row refunds 10, and plan3 dies on action 26, which the Lean theorem `plan3_prefix26_dead` already reproduces. The model would have changed only if one of these had deviated: a click doing something, a different refund amount, or the route surviving longer or dying earlier.

## 5. Proof: it does not go through

There is no Lean impossibility theorem.
- **The full model is too large:** about 651,655 reachable states, far beyond what Lean's kernel can check by brute force.
- **The small model is too loose:** a version that ignores row positions is small enough to check, but it admits a win at exactly 18 units because it skips three row moves the real board forces.
- **What is missing:** a hand-built lower bound on remaining cost that keeps the rows that matter. I haven't written it.

What does compile, in `lean/M15fwL4Win.lean`, is a set of theorems about the specific routes I played, not about every route:
```
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.plan3_prefix26_dead' depends on axioms: [propext]
'M15fw.offClick_noop' depends on axioms: [propext]
```

## 7. Checks

**a. Budget fit.** I refitted the cost parameters over every recorded bar reading from all eight attempts. The search covered:
- budget, action cost and completion surcharge;
- refill as a reset or as a refund of 0–40 units;
- off-panel click cost of 0 or 1;
- display rounding and the game-over rule.

Level 4 has 4 raw survivors, which are the same physical solution at different unit scales:
- budget 18, completing click 2, refund 10, off-panel click 0;
- display rounds up, game over when the remaining budget goes below 0.

So no conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step size = cursor width | Attempt 1: the 2×2 moved 2 |
| Wall clamp | Attempt 1, step 5 |
| Barrier blocks | Attempt 1, level 3 step 32; attempt 2 (2×2) |
| Completing click costs 2 | Attempt 1, level 4 step 54 |
| Grow | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refund 10, not a reset | Attempt 6: 9 units left, where a reset would have left 17 |
| Refill before the budget check | Attempt 6 |
| Off-panel clicks are no-ops | Attempts 7 and 8 |

No load-bearing rule lacks one.

**c. Budget range.** With no Lean theorem, I swept the budget with the search instead:
- budgets 18, 19 and 20: no win;
- budget 21: the first value that wins.

Twice the 21-unit route died exactly where the model said. So the result holds only up to 3 units above the measured budget, which means the model isn't much stricter than the game.

VERDICT: impossible
CONFIDENCE: 75