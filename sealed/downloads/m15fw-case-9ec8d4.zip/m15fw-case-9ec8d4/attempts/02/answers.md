## play 1

The game has now ended: one more action at the exhausted budget gave `GAME_OVER` on level 4, as the budget rule predicted (game over once spending exceeds 18). I did not call `/reset`.

**Result:** I reached level 4 and beat levels 1–3 (3 levels completed). I did not beat level 4 or the game.

In this attempt, the switch on level 4 never fired, so the barrier blocking the corridor to the goal never opened:
- bumping the barrier first and then drawing the switch pattern did nothing;
- the barrier blocks the shrunk 2×2 cursor as well as the 4×4 one;
- drawing the switch pattern with the 2×2 cursor next to the barrier did nothing.

Across both attempts the switch has fired once (level 3) and failed six times. All of these cases fit one rule: the cursor's left column must line up with the column of the switch's stalk. Under that rule, the cheapest win on level 4 costs at least 20 units against a budget of 18, as proved in `lean/M15fwL4.lean`. That rule is inferred from these cases, not confirmed, so I still can't rule out a cheaper trigger I haven't found.

The attempt log is in `work/REPORT.md`.

## probe 1

## 1. What happened on level 4

The level is a room holding the 4×4 cursor and a corridor leading to the goal. A colour-13 barrier closes the corridor. The only known way to open it is drawing the "switch" pattern (the centre column of the panel), which on level 3 removed both the switch and the barrier. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

This attempt tested the two leading guesses for what the switch needs:
- **Bump the barrier first, then draw the pattern:** nothing opened.
- **Shrink to 2×2 and draw it while touching the barrier:** nothing opened, and the 2×2 is blocked by the barrier too.

Those tests used the whole budget, and the next action ended the game. The cause of failure is the same as before: I do not know what triggers the switch. Each test of a guess costs about a quarter to half of the budget.

## 2. Can level 4 be won? Under my established rules, no.

**Claim:** no action sequence costing at most 18 units wins level 4, given these premises:
- **P1, movement:** the cursor moves by its side length, cut short only by walls. In this room the 4×4 cursor can only stand at left columns 21, 25, 29, 33, 37 or 41. A 2×2 moves 2 columns per step.
- **P2, barrier:** the barrier blocks both cursor sizes until the switch opens it.
- **P3, completing a pattern:** it clears the whole panel. Shrinking needs 4 clicks and the switch needs 3. Completing a pattern costs 2 units, any other action 1.
- **P4, winning:** the level is won when the cursor overlaps the goal (left column ≥ 56 for a 2×2).
- **P5, budget:** 18 units, game over once more than 18 are spent. No refunds.
- **Hyp, the switch trigger:** the switch fires only when the cursor's left column is 31 or 32, the stalk's columns.

**Argument:**
1. Under Hyp and P1, the 4×4 cursor can never trigger the switch, so it must shrink first.
2. After that it must stand at column 31 and complete the switch pattern.
3. It then needs 13 two-column moves to reach the goal.
4. The cheapest total is 20 units, which is more than 18.

**What is established and what is assumed:**
- P1–P5 each have a decisive observation (see 7b).
- Hyp has none. It fits all six recorded switch attempts (1 fired, 5 failed). It is also the only explanation I've tried that hasn't been refuted: "facing up and touching the stalk", "bump first" and "any 2×2" are all refuted.
- **Specific untested mechanism that would change the answer:** the 4×4 firing from a column I never tried (33, facing up, directly under the switch). If that fires, the level is winnable for about 14 units.
- **Also against Hyp:** a designer probably wouldn't ship a level that can't be won, and under Hyp this one can't be.

## 3. Next attempt

One plan of 17 units runs both tests:
1. Left once to column 33, up once to row 21 (facing up, touching the stalk), then draw the switch pattern. That is 6 units.
2. **If it fires:** down twice, then right six times, reaching the goal at 14 units.
3. **If not:** left once to column 29, shrink (5 units), right once to column 31, and draw the switch pattern again. That is 17 units in total and settles Hyp directly: Hyp predicts it fires, and the level stays unwinnable this attempt either way.

## 4. Amendments to the formal system (no rewrite)

- **`lean/M15fwModel.lean`:**
  - New object `CastObs` and a table `casts` of all six switch attempts.
  - `decide` checks:
    - Hyp's predicate "cursor's left column = stalk's left column" matches all six;
    - "facing up and touching the stalk", "bumped the barrier first" and "a 2×2 fires anywhere" each fail against the data.
  - New level-4 board `board4`, with checks that the barrier blocks both the 2×2 and the 4×4.
  - A shrink check: the top-left corner was kept, now seen a second time (facing right).
- **`lean/M15fwL4.lean`:** comments only. The abstraction already treated the barrier as blocking the 2×2, and it keeps the loose shrink offset (0 or 2 columns). The bump alternative is now marked as refuted.
- **`concepts/move_step4.py`:** returns "not applicable" when the previous frame has an empty bar, which marks a transition across the service's restart.
- **`work/fit_budget.py`:** treats each attempt as its own sequence. Details are in `work/MODEL.md`, under "Amendments from attempt 2".

## 5. Proof (`lean/M15fwL4.lean`, theorem `no_win_within`)

**What it says:** for every switch rule `fires` that satisfies `Hyp`, and every choice list whose total cost is at most B (any B < 20), the run ends in a non-won state. `l4_no_win_B4` is the instance at B4 = 18.

**Where the model is looser than the game:**
- rows are abstracted away;
- the panel is reduced to two counters a click may lower freely;
- the shrink may shift the cursor 0 or 2 columns.

All three only add transitions. The step from the real game to this abstraction is argued in prose, not proved in Lean.

**Rules it leans on:** `move_step4` (step size and wall clamps), the barrier blocking, the panel reset on completion, `goal_win`, the costs and budget, and `Hyp`. `Hyp` is the only part stricter than what I observed.

**Non-vacuity checks:**
- `witness_wins`: a 20-unit run wins under a rule satisfying `Hyp`.
- `cheap_wins`: with an unrestricted switch rule, a 9-unit run wins.
- `fireAny_not_hyp`: that unrestricted rule violates `Hyp`.

```
'M15fwL4.no_win_within' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.l4_no_win_B4' depends on axioms: [propext, Classical.choice, Quot.sound]
'M15fwL4.witness_wins' does not depend on any axioms
'M15fwL4.cheap_wins' does not depend on any axioms
'M15fwL4.fireAny_not_hyp' depends on axioms: [propext, Quot.sound]
```

## 6. Did the formal system change?

Yes, as listed in §4: one object and its table added, one board added, one scope revised, and the fit tightened.

## 7. Checks on the proof

**a. Cost fit.** The search covered:
- budget B ≤ 400, ordinary action cost c ≤ 20, completion surcharge x ≤ 40;
- the cost of the first action after a reset, which turned out to be 0;
- floor, ceil and round for the display;
- game over when units go negative versus when they reach zero.

Refunds were checked separately: the bar never rose within a level except at the service's restart, so the refund is 0. Using every level-4 reading from both attempts:
- **Level 4 alone:** 20 raw combinations survive, which collapse to exactly 1 distinct one. That is B = 18 action-units, a completing click costing 2 units, ceil rounding, and game over when units go negative.
- **Compared with attempt 1:** level 4's readings alone then left 30 distinct combinations; the two attempts together pin it to this one.
- **Across all four levels:** the same surcharge ratio (1) is the only common value.

With a single survivor, no conclusion varies across the fit set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step = side length | Attempt 1, level 1: the 2×2 moved 2 (tid fb6f…) |
| Walls shorten moves | Attempt 1, level 1, step 5: a 4×4 moved only 2 at the wall (2e39…) |
| Barrier blocks the 4×4 | Attempt 1, level 3, step 32 (97fd…) |
| Barrier blocks the 2×2 | Attempt 2, level 4: k = 0 at column 43 |
| Win on overlap | Attempt 1, level 1, step 17 (fc55…) |
| Completing click costs 2 | Attempt 1, level 4, step 54: 6 rows dropped instead of 4 |
| Game over only when spent exceeds the budget | Attempt 2: bar at 0 after spending exactly 18 with no game over; the next action ended the game |
| **Hyp** | **None yet.** The experiment is the second half of the §3 plan: a 2×2 at column 31 versus the 4×4 at column 33 |

**c. Budget range.** I recompiled with different values of B4:
- B4 = 18: compiles.
- B4 = 19: compiles.
- B4 = 20: fails, because `decide` refutes 20 < Φ init.

So the impossibility result holds only one unit above the measured budget. The model is not stricter than the game on budget; the result's weight rests on Hyp, which is the rule I suspect.

VERDICT: impossible
CONFIDENCE: 50

## pushes 1

The game has now ended: one more action at the exhausted budget gave `GAME_OVER` on level 4, as the budget rule predicted (game over once spending exceeds 18). I did not call `/reset`.

**Result:** I reached level 4 and beat levels 1–3 (3 levels completed). I did not beat level 4 or the game.

In this attempt, the switch on level 4 never fired, so the barrier blocking the corridor to the goal never opened:
- bumping the barrier first and then drawing the switch pattern did nothing;
- the barrier blocks the shrunk 2×2 cursor as well as the 4×4 one;
- drawing the switch pattern with the 2×2 cursor next to the barrier did nothing.

Across both attempts the switch has fired once (level 3) and failed six times. All of these cases fit one rule: the cursor's left column must line up with the column of the switch's stalk. Under that rule, the cheapest win on level 4 costs at least 20 units against a budget of 18, as proved in `lean/M15fwL4.lean`. That rule is inferred from these cases, not confirmed, so I still can't rule out a cheaper trigger I haven't found.

The attempt log is in `work/REPORT.md`.