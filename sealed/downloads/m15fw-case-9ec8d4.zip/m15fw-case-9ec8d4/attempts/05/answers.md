## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed. The attempt ended in `GAME_OVER` on level 4 when the budget ran out; I did not call `/reset`.

**Why the plan failed.** The first part of the planned route went exactly as predicted: I shrank the cursor to 2×2 and moved it to column 31. It was facing left when I drew the switch pattern there, and the switch did not fire. That was the plan's one untested assumption, so the route was dead with 5 units left. I used them to move up one cell, so the cursor faced the switch, and draw the pattern again: the switch fired. The rule is now column 31 **and** facing up toward the switch, and this is the first test where only the facing changed.

**Revised plan.** There is a revised winning route in `work/REPORT.md` that uses this rule. It still rests on two things I haven't tested:
- **Refill at the limit:** the step onto the refill item would be made with all 18 units already spent. The game must apply the refill before it checks the budget, or that step ends the attempt.
- **Full reset:** the refill must reset the budget to full, not refund a fixed 10 units.

**Harness fix.** The script that records results was stuck: it counted deduplicated transitions while the gate counted every recorded one, so the gate never reopened. I changed `settle.py` to count every recorded transition, so the two agree; neither gate is weaker for it. Nothing was sent to the game while it was stuck.

## probe 1

## 1. What happened on level 4

The level-4 goal sits behind a barrier. A "switch" pattern drawn on the panel removes it, but only when the cursor stands in the switch's column. The plan from last time went exactly as predicted through its first part: shrink to the small 2×2 cursor and move it to column 31. Then I drew the switch pattern with the cursor facing left, and nothing happened. That was the plan's one untested assumption, so the route was dead.

I spent the 5 units left stepping up once, so the cursor faced the switch, and drawing it again. It fired. The attempt failed because the switch needs the cursor to face up, toward it. Every earlier firing happened to face up, so I had never separated facing from column.

## 2. Yes, I see a winning route: `plan2`

The route, with units spent after each stage (budget 18):

| Stage | Actions | Spent |
|---|---|---|
| Start | 4×4 at row 25, column 37 | 0 |
| Move to (33,33) | down, down, left | 3 |
| Shrink | 4 clicks → 2×2 at (33,33) | 8 |
| Reach column 31 facing up | down, left, up → (33,31) | 11 |
| Switch | 3 clicks → barrier opens | 15 |
| Go to the item | left ×4; the 4th lands on it and refills | 18, then 1 |
| Line up | right ×5, up → (31,33) | 7 |
| Grow | 4 clicks → 4×4 at (29,31) | 12 |
| Finish | right ×6 → overlaps the goal | 18 |

It needs two refill details I have not checked:
- **(a) Order:** the step onto the item is taken with all 18 units spent. The game must apply the refill before it checks whether the budget is exceeded.
- **(b) Kind of refill:** it must reset the budget, not refund exactly 10 units. My only refill reading fits both.

The switch rule ("column 31 and facing up") now has a test where only the facing changed. Everything else in the route has been observed.

## 3. Next attempt

Run `plan2` exactly. The bar reading after the refill step settles both open premises:
- 62 rows means a reset, applied before the budget check, and the plan continues.
- If the game ends on that step, the budget is checked first.
- 40 rows means a 10-unit refund.

## 4. Changes to the formal system

I amended the existing files rather than rewriting them:
- **`lean/M15fwModel.lean`:**
  - The switch-trigger data table `casts` gains two attempt-5 rows (facing left at column 31: no fire; facing up: fired).
  - A `decide` check now shows the column-only rule fails against the data.
  - Another shows "column and facing up" fits all 11 recorded completions.
  - New object `RefillSem`: reset or refund, and whether the refill comes before the budget check. It is an explicit parameter of `stepPos`.
- **`lean/M15fwL4Win.lean`:** `runA` now honours `RefillSem`. I added `HypColUp`, `plan2`, and the new theorems. The attempt-4 theorem stays, marked as resting on a premise now known false.
- **`settle.py`:** fixed to record the raw transition count, so the method's gate no longer locks.
- **`work/MODEL.md`:** has an "Amendments from attempt 5" section.

## 5. Proof: `lean/M15fwL4Win.lean`, theorem `l4_winnable2`

**What it says:** for every switch rule `fires` satisfying `HypColUp` (fires exactly when the cursor's left column is 31 or 32 and it faces up), running `plan2` from the level-4 start wins within budget B4 = 18.

**What it assumes:**
- `HypColUp`, stated as an explicit hypothesis.
- The refill semantics: the `RefillSem` defaults are reset, then charge the move, then check the budget. These are visible defaults, but they are premises, not established facts.

**Rules it leans on:** move step size and wall clamping, the barrier blocking, the panel clearing on completion, shrink keeping the top-left corner, grow, the switch effect, refill, the win-on-overlap rule, and the costs (1 per action, 2 for a completing click, game over once over 18).

**Theorems showing which premises matter:**
- `plan2_dies_check_first`: if the budget is checked before the refill, `plan2` dies, so premise (a) matters.
- `plan2_dies_refund10`: under a fixed 10-unit refund, `plan2` dies, so premise (b) matters.
- `plan_fails_colUp`: the attempt-4 plan fails under the new switch rule, as I observed.
- `plan2_needs_switch`: `plan2` does not win if the switch never fires.

```
'M15fw.l4_winnable2' depends on axioms: [propext, Quot.sound]
'M15fw.plan2_dies_check_first' depends on axioms: [propext]
'M15fw.plan2_dies_refund10' depends on axioms: [propext]
'M15fw.plan_fails_colUp' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks on the proof

**a. Cost fit.** The search covered:
- budget B up to 400, ordinary cost c up to 20, completion surcharge x up to 40;
- the cost of the first action after a reset (swallowed);
- floor, ceil or round for the display, and game over at R < 0 versus R ≤ 0, where R is units left;
- refill as reset-then-charge, reset-free, or a refund of 0–40 units.

On level 4 across all five attempts, 24 raw combinations survive. They reduce to 2 physically distinct ones, both with budget 18, completion surcharge 1, ceil rounding and game over at R < 0:
- (i) the refill resets the budget, then charges the move;
- (ii) the refill refunds exactly 10 units.

The conclusion changes between them: `plan2` wins under (i) and dies under (ii). Attempt 5 made no refill, so it couldn't separate them.

**b. Decisive experiments:**

| Rule | Observation that would have differed |
|---|---|
| Step = side length | Attempt 1, L1: a 2×2 moved 2 (tid fb6f…) |
| Wall clamp | Attempt 1, L1 step 5 (2e39…) |
| Barrier blocks | Attempt 1, L3 step 32, and attempt 2, L4: 2×2 at column 43, k = 0 |
| Win on overlap | Attempt 1, L1 step 17 |
| Completing click costs 2 | Attempt 1, L4 step 54 |
| Grow | Attempt 4: 2×2 (29,31) → 4×4 (27,29) |
| Refill needs a 2×2 | Attempt 4 refilled; attempt 1's 4×4 covering the item did not |
| Switch: column | Attempt 3: column 33 failed, column 31 fired (4×4 vs 2×2) |
| Switch: facing | Attempt 5: column 31 facing left failed, then facing up fired |

**Still missing:** decisive experiments for the refill order and the refill kind. The experiment is `plan2`'s own refill step: refill at spent 18 and read the bar.

**c. Budget range:** this is a winnability result, so the relevant range is the smallest budget at which it holds:
- B4 = 17: fails.
- B4 = 18: holds.
- B4 = 25: holds.

It needs exactly the measured budget, with no slack. At 25 only `plan2_dies_check_first` breaks, as expected, because more budget makes the check-first death go away.

The superseded impossibility theorem in `M15fwL4.lean` survived up to 19 in a model without refill or grow, yet the game turned out to have a cheaper route. That is the stricter-model failure that made attempts 1–3 wrong.

VERDICT: winnable
CONFIDENCE: 50