## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed. The game ended in `GAME_OVER` on level 4 when the 18-unit budget ran out; I did not call `/reset`.

First I tested the mechanisms that were still unchecked:
- **Clicks outside the panel** (on the switch, the refill item, the goal and the barrier): they do nothing and cost nothing.
- **Clicks on the two recipe boxes:** also free, and they only change which pattern hint the panel shows.
- **Actions 5 and 7:** the service rejects them.

None of these opens a new route.

Then I played the cheapest route my exhaustive search had found: shrink, step onto the item for its 10-unit refund, grow back to full size, fire the switch, then run to the goal. That route needs a budget of 21. Every step behaved exactly as my model predicted, including one new fact: the full-size cursor also fires the switch when it is in column 31 facing up. The game ended on the 4th of the final six moves right, as predicted, two moves short of the goal.

Under every rule I've observed, level 4 can't be won with an 18-unit budget and a 10-unit refund. The search shows the first budget that allows a win is 21. This attempt's findings are logged in `work/REPORT.md` and saved to memory.

## probe 1

## 1. What happened on level 4

The goal sits behind a barrier. To remove it, a pattern has to be drawn on a panel while the cursor stands in column 31 facing up. The budget is 18 units: 1 per action, 2 for a click that completes a pattern. A refill item gives back 10 units. Going by every rule I had, the cheapest possible win costs 21 units.

This attempt did two things:
- **Checked the remaining unknowns.**
  - Clicking anywhere outside the panel (the switch, the item, the goal, the barrier) does nothing and costs nothing.
  - Clicking the recipe boxes only changes which pattern hint the panel shows.
  - Actions 5 and 7 are refused by the service.
- **Played that cheapest route anyway:** shrink, collect the refill, grow back, fire the switch as a 4×4 (column 31, facing up), then run right. Every step behaved exactly as modelled. The budget ran out on the 4th of the final six moves, two moves short of the goal, exactly where predicted.

It fails because the cheapest winning route needs 21 units and the level gives 18 plus a 10-unit refill.

## 2. Can level 4 be won? No, under my established rules.

**Claim:** no sequence of actions wins level 4 with the 18-unit budget.

**Premises, each observed directly:**
- **Moves:** a cursor moves by its own side length (4 or 2), shortened at walls.
- **Barrier:** it blocks both cursor sizes until it is opened.
- **Panel:** each click toggles one cell (1 unit). Completing a pattern costs 2 and clears the panel.
- **Shrink and grow:** a 4×4 shrinks keeping its top-left corner. A 2×2 grows back to a 4×4 at (r−2, c−2).
- **Switch:** fires only when the cursor is in column 31 or 32 and facing up.
- **Refill:** only a 2×2 overlapping the item collects it. It refunds exactly 10, applied before the budget check.
- **Budget:** 18 units, game over once spent exceeds 18. The only legal actions are 1–4 and 6, and clicks off the panel are free no-ops.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` is an exact shortest-path search over the full model: position, size, facing, panel marks, barrier state, item and budget. With budget 18, 19 or 20 it finds no winning sequence; the first budget with a win is 21.

`work/reach_l4.py` repeats the search with spending floored at 0, in case the bar cannot go above full. It finds 651,655 reachable situations and none is a win.

**Load-bearing premises:** the bound rests most on three rules, each with a decisive observation:
- Switch needs column 31 *and* facing up (attempts 3 and 5).
- The 10-unit refund (attempts 4 and 6).
- Move step equals side length.

**Not established:** this is a computer search over my rules, not a Lean proof (see §5). No specific untested mechanism remains that I can name.

## 3. Next attempt

My rules give no winning route. I would run the cheapest route again and watch for any deviation from the model. If it matches step for step, I stop once the game ends.

## 4. Changes to the formal system

These are amendments, not a rewrite:
- **New action `Act.offClick`:** a click off the panel. It changes nothing and costs 0. Actions 5 and 7 get no constructor, since the service rejects them.
- **Dropped:** the recipe-box hint. It is a display slot that no rule reads.
- **Switch data:** the `casts` table gains a 13th row, a full-size cursor that fired as predicted.
- **New Lean theorems:**
  - `plan3_prefix25_spent` and `plan3_prefix26_dead` reproduce the observed death point exactly.
  - `offClick_noop` shows a free off-panel click changes nothing.
- **`fit_budget.py`:** the cost of off-panel clicks is now searched as a separate case.

## 5. Proof: it does not go through

I have no Lean proof that level 4 is impossible.
- **The full model is too large to certify in Lean:** 651,655 reachable situations.
- **A smaller version that ignores rows is too loose:** it admits a win at exactly 18 units, because it skips three vertical moves the real board forces.
- **What is missing** is a hand-built lower bound on remaining cost that keeps the row positions that matter. I have not written one.

What does compile is in `lean/M15fwL4Win.lean`. These theorems rule out the specific routes I played, not all routes:

```
'M15fw.plan2_dies_observed' depends on axioms: [propext]
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.plan3_prefix26_dead' depends on axioms: [propext]
'M15fw.offClick_noop' depends on axioms: [propext]
```

## 6. Did the formal system change?

Yes. One action constructor and one data row were added, a display slot was dropped, and the attempt-7 replay was reproduced in Lean.

## 7. Checks

**a. Budget fit.** I searched over:
- budget, action cost and completion surcharge;
- refill as a reset or a refund of 0–40 units;
- off-panel click cost of 0 or 1 action;
- swallowed first action, display rounding, and the game-over rule.

Every reading from all seven attempts was used. Level 4 has 4 raw survivors, which collapse to one physical solution:
- 18 units, completion costs 2, refund 10, off-panel clicks cost 0;
- ceil rounding, game over when the remainder goes below 0.

No conclusion varies across the set.

**b. Decisive experiments:**

| Rule | Decisive observation |
|---|---|
| Step equals side length | Attempt 1: a 2×2 moved 2 |
| Wall clamp | Attempt 1, step 5 |
| Barrier blocks | Attempt 1 L3 step 32; attempt 2 with a 2×2 |
| Completing click costs 2 | Attempt 1, L4 step 54 |
| Grow | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refund 10 | Attempt 6: 9 units left, not 17 |
| Refill before the budget check | Attempt 6 |
| Toggle | Attempt 6 |
| Off-panel no-op | Attempt 7 (switch, item, goal and barrier clicks) |

No load-bearing rule lacks a decisive experiment.

**c. Budget range.** I swept the budget with the Python search, since there is no Lean impossibility theorem:
- B = 18, 19 and 20: impossible.
- B = 21: the first value at which a win appears.

Attempt 7 played out that route and died exactly where the model said. So the result holds only up to 3 units above the measured budget, which is not a model meaningfully stricter than the game.

VERDICT: impossible
CONFIDENCE: 75