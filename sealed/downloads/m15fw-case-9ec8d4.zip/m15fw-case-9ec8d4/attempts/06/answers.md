## play 1

I reached level 4 again and did not beat it, so the game is not won: levels 1–3 are beaten, 3 levels completed. The game ended in `GAME_OVER` on level 4 when the budget ran out; I did not call `/reset`.

The route I planned last time ran exactly as predicted until the refill: shrink, then the switch fired facing up at column 31, opening the barrier. Then the refill step went wrong:
- **It was allowed:** stepping onto the item with all 18 units already spent did not end the game.
- **But it was a refund of 10 units, not a full reset.** The bar dropped to 9 units left; I had planned on getting the whole 18 back. That's now confirmed from two refills at different spending levels (10 spent became 1, 18 spent became 9). With 9 units the route couldn't finish.

I then wrote an exact search over my rules (`work/search_l4.py`) to look for any winning route:
- **With a 10-unit refund:** no route wins level 4, neither from the start nor from where I was. The cheapest route costs 31 units against an effective 28 (18 plus the 10 refunded).
- **Sanity check:** with a refund of 14 or more it finds a 28-action win, and with 12 or less it finds nothing. So the search is working, and the actual refund is just too small.

Under the rules I've established, level 4 now looks impossible.

I also found that clicking an already-marked panel cell un-marks it. Everything from this attempt is logged in `work/REPORT.md` and saved to memory.

## probe 1

## 1. What happened on level 4

The goal sits behind a barrier. The barrier opens only when the cursor is a small 2×2 in column 31, facing up, and the switch pattern is drawn on the panel. A small cursor can be grown back to the fast full-size 4×4. There is also an item that refunds budget. The budget is 18 units: 1 per action, 2 for a click that completes a pattern.

My plan ran exactly as predicted up to the refill:
- shrink to 2×2;
- go to column 31 facing up, where the switch fired and the barrier opened;
- step onto the item with all 18 units spent.

That step was allowed, but the bar came back to only 9 units left, not 17. The item is a fixed refund of 10 units, not a reset to full. Attempt 4's refill read the same way: 10 spent became 1.

My plan had assumed a reset. With 9 units left nothing could reach the goal, and the attempt ended once the budget ran out.

## 2. Can level 4 still be beaten? No, under my established rules

**Claim:** no action sequence wins level 4. This rests on an exhaustive computer search, not on a Lean proof.

**Premises, each observed directly:**
- **Moves:** step size equals the cursor's side, shortened at walls.
- **Barrier:** blocks both cursor sizes until opened.
- **Panel:** clicking toggles a cell; completing a pattern clears the panel.
- **Shrink and grow:** shrinking keeps the top-left corner; growing makes a 4×4 at (r−2, c−2).
- **Switch:** fires only at column 31 or 32 while facing up.
- **Refill:** only a 2×2 overlapping the item triggers it, and it refunds exactly 10.
- **Budget:** 18 units, game over once spent exceeds 18. The refill is applied before that check.
- **Win:** any overlap with the goal.

**Argument:** `work/search_l4.py` explores every reachable situation in the full model: position, size, facing, panel marks, barrier state, item and budget.
- It finds no winning route at budget 18, 19 or 20.
- The cheapest win needs a budget of 21 (`DDLLL`, shrink, refill, down, right, grow, right ×2, up, switch, right ×6).
- `work/reach_l4.py` repeats the search with spending floored at 0, in case the bar caps at full. It finds 651,655 reachable situations, none of them won.

**Not checked (assumptions):**
- clicks outside the panel (on the switch, the item, the recipe boxes or the goal);
- actions 5 and 7;
- a 4×4 firing the switch. The search allows it, so it is the loose direction and can't cause a false "impossible".

## 3. Next attempt

The established rules leave no route, so I'll spend the budget on the specific untested mechanisms that could change that:
1. Click the switch (around x=31, y=6).
2. Click the item (x=23, y=34).
3. Click the recipe boxes.
4. Try actions 5 and 7.

Each costs about 1 unit. If any of them opens the barrier or refunds more, I'll re-run the search before playing on.

## 4. Changes to the formal system

These are amendments to the existing files, not a rewrite.

- **Refill semantics:** the `RefillSem` defaults are now a refund of 10 units, applied before the budget check (both observed). The old route theorems now name their refuted "reset" premise explicitly as `resetSem`.
- **Panel toggle:** `setAt` now toggles a cell instead of only setting it, with an example check.
- **Switch observations:** `casts` gains a 12th row, a firing I predicted at (33,31) facing up.
- **New theorems:** `plan2_dies_observed` and `plan3_dies_observed` show the two candidate routes fail under the observed rules.

Details are in `work/MODEL.md` under "Amendments from attempt 6".

## 5. Proof: it does not go through

I have no Lean proof of impossibility. Two things block it:
- **The full model is too big.** 651,655 reachable situations is far beyond what the Lean kernel can check by brute force with `decide`.
- **The small model is too loose.** A version that ignores rows is small enough to check, but it admits a win that uses exactly 18 units, because it skips three row moves the real board forces. So it cannot prove impossibility.

**What would close the gap:** a hand-built potential-function proof (a provable lower bound on remaining cost) that keeps the row positions that matter. I have not written it.

**What does compile** (`lean/M15fwL4Win.lean`) only rules out specific routes, not all of them:

```
'M15fw.plan2_dies_observed' depends on axioms: [propext]
'M15fw.plan3_dies_observed' depends on axioms: [propext]
'M15fw.l4_winnable2' depends on axioms: [propext, Quot.sound]
```

`l4_winnable2` rests on the reset premise, which this attempt refuted.

**Lean model vs Python search:**
- The Lean model floors spending at 0 on a refund; `search_l4.py` lets it go negative.
- `reach_l4.py` floors it, like Lean.
- Both find no win at budget 18.

## 6. Did the formal system change?

Yes, as listed in section 4.

## 7. Checks

**a. Budget fit.** I searched over:
- budget, action cost and completion surcharge;
- refill as reset-then-charge, reset-free, or a refund of 0–40 units;
- display rounding and the game-over rule.

Every recorded reading across all six attempts was kept. Level 4 has 4 raw survivors, which are one physical solution:
- budget 18, completion surcharge 1, refund 10 (the four are the same values at different unit scales);
- ceil rounding, game over when units left go below 0.

"Reset" is eliminated: this attempt's refill read 9 units left, and reset predicts 17. With one survivor, no conclusion varies.

Two bugs in the fit script were fixed before this result:
- it mistook a refill at bar 0 for a service restart;
- it mistook an un-mark click for a pattern completion.

**b. Decisive experiments**, all attempt 1 unless stated:

| Rule | Observation that would have differed |
|---|---|
| Step equals side | A 2×2 moved 2 |
| Wall clamp | Step 5: a 4×4 moved only 2 at the wall |
| Barrier blocks | Level 3 step 32; attempt 2 with a 2×2 |
| Completing click costs 2 | Level 4 step 54 |
| Grow anchor | Attempt 4 |
| Switch column | Attempt 3: column 33 failed, column 31 fired |
| Switch facing | Attempt 5: facing left failed, facing up fired |
| Refill is a refund of 10 | Attempt 6: 9 units left, against 17 predicted by reset |
| Refill comes before the budget check | Attempt 6: the step at 18 spent survived |
| Toggle | Attempt 6 |

Two rules still have no decisive experiment: whether clicks off the panel do anything, and whether spending can go below 0 on a refund. The second doesn't change the answer, since both variants were searched.

**c. Budget range.** I swept the budget with the Python search, since there's no Lean impossibility theorem:
- B = 18, 19 and 20: impossible.
- B = 21: the first value at which a win appears.

The result holds only up to 3 units above the measured budget. So it is not an artefact of a model much stricter than the game. Its weight rests on the switch, refill and move rules, all of which have decisive observations.

VERDICT: impossible
CONFIDENCE: 65