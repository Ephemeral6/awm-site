import sys; sys.path.insert(0, 'work')
import search_l4 as S
S.REFUND = 10
for B in range(18, 24):
    S.B = B
    r = S.search((25, 37, 4, 'D', False, True, frozenset()), 0)
    print('B', B, '->', None if r is None else (r[0], ''.join(map(str, r[1]))), flush=True)
    if r: break
