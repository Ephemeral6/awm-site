"""Replay every recorded level-4 transition (all attempts) against a (relaxed) model.
A relaxation is admissible iff every observed outcome is among the model's allowed outcomes
and the bar reading matches the model's spent (B = 18, display 2*ceil(32*(18-spent)/18))."""
import json, math, sys
sys.path[:0] = ['.', 'concepts', 'work/selfaudit']
from _lib import cursor_box
import engine as E

PR, PC = (49, 54, 59), (24, 29, 34)
STRICT_FACING = True
def bar(g): return sum(1 for r in range(64) if g[r][62] == 14)
def facing(g, b):
    r0, c0, h, w = b
    if all(g[r0][c0+j] == 9 for j in range(w)) and h > 1 and all(g[r0+h-1][c0+j] == 10 for j in range(w)): return 0
    if all(g[r0+h-1][c0+j] == 9 for j in range(w)) and all(g[r0][c0+j] == 10 for j in range(w)): return 1
    if all(g[r0+i][c0] == 9 for i in range(h)): return 2
    return 3
def parse(g, prev_it=True):
    b = cursor_box(g)
    if b is None: return None
    r0, c0, h, w = b
    op = g[29][45] != 13
    cells = [(34, 23), (34, 24), (35, 23), (35, 24)]
    vis = [g[r][c] for r, c in cells if not (r0 <= r < r0+h and c0 <= c < c0+w)]
    it = any(v == 14 for v in vis) if vis else None   # item hidden under the cursor: unknown
    marks = frozenset(3*i+j for i in range(3) for j in range(3) if g[PR[i]][PC[j]] == 14)
    return (h, r0, c0, facing(g, b), op, it), marks
def disp(sp): return 2 * math.ceil(32 * (18 - sp) / 18)
SHR = frozenset({1,3,5,7}); SW = frozenset({1,4,7})
def outcomes(m, q, mk, sp, act):
    o = m.o; out = []
    if act.startswith('ACTION6'):
        x, y = map(int, act.split(':')[1].split(','))
        k = None
        for i, r in enumerate(PR):
            for j, c in enumerate(PC):
                if r <= y < r+3 and c <= x < c+3: k = 3*i+j
        if k is None:
            out = [(q, mk, sp, False)]
            if m.refill_ok(q, 'off'):
                sp3 = sp - o['refund'] if o['uncapped'] else max(0, sp - o['refund'])
                out = [(q[:5] + (False,), mk, sp3, False)]
            return out
        m2 = mk ^ {k}
        exS, exW = m2 == SHR, m2 == SW
        doS = exS or (o['superset'] and SHR <= m2); doW = exW or (o['superset'] and SW <= m2)
        res = []
        if doS and doW and o['double']:
            res += [q3 for q1 in m.shrink_res(q) for q3 in m.switch_res(q1)]
            res += [q3 for q1 in m.switch_res(q) for q3 in m.shrink_res(q1)]
        if doS: res += m.shrink_res(q)
        if doW: res += m.switch_res(q)
        if res:
            cand = [(q2, frozenset(), sp + o['complete_cost'], False) for q2 in res]
            kind = 'grow' if (doS and q[0] == 2) else ('shrink' if doS else 'switch')
        else:
            cand = [(q, frozenset(m2), sp + o['click_cost'], False)]
            kind = 'click'
    else:
        d = int(act[-1]); d = {1: 0, 2: 1, 3: 2, 4: 3}[d]
        q2 = m.move(q, d)
        cand = [(q2, mk, sp + o['move_cost'], m.wins(q2[0], q2[1], q2[2]))]
        if q2[1:3] == q[1:3]:   # blocked: facing may or may not turn under blocked_turn
            cand.append((q2[:3] + (q[3],) + q2[4:], mk, sp + o['move_cost'], False))
            if not o['blocked_turn']: cand = cand[1:]
        kind = 'move'
    final = []
    for q2, m2, sp2, won in cand:
        final.append((q2, m2, sp2, won))
        if m.refill_ok(q2, kind):
            sp3 = sp2 - o['refund'] if o['uncapped'] else max(0, sp2 - o['refund'])
            final.append((q2[:5] + (False,), m2, sp3, won))
            final = [f for f in final if not (f[0] == q2 and f[2] == sp2)] if True else final
    return final
def replay(m, verbose=False):
    L = [json.loads(l) for l in open('transitions.jsonl')]
    n = ok = 0; bad = []
    cur = None; prev_over = False
    for i, r in enumerate(L):
        restart = prev_over; prev_over = r['ctx']['state_next'] == 'GAME_OVER'
        if r['ctx']['level_prev'] != 4: cur = None; continue
        if r['ctx']['level_next'] != 4: continue
        if cur is None or restart:
            cur = ((4, 25, 37, 1, False, True), frozenset(), 0)
        q, mk, sp = cur
        po = parse(r['nxt'], q[5])
        outs = outcomes(m, q, mk, sp, r['action'])
        n += 1
        if r['ctx']['state_next'] == 'GAME_OVER':
            match = [x for x in outs if x[2] > 18]
            if match: ok += 1; cur = match[0][:3]
            else: bad.append((i, r['action'], 'expected overdraw', outs))
            continue
        if po is None: bad.append((i, r['action'], 'unparsed')); continue
        obs_q, obs_mk = po
        b = bar(r['nxt'])
        match = [x for x in outs if x[0][:3] == obs_q[:3] and x[0][4] == obs_q[4] and (obs_q[5] is None or x[0][5] == obs_q[5]) and x[1] == obs_mk
                 and disp(x[2]) == b and (x[0][3] == obs_q[3] or x[0][0] != obs_q[0] or True)]
        match_f = [x for x in match if x[0][3] == obs_q[3]] or (match if not STRICT_FACING else [])
        if match_f:
            ok += 1; cur = (obs_q[:3] + (match_f[0][0][3],) + (obs_q[4], match_f[0][0][5]), obs_mk, match_f[0][2])
        else:
            bad.append((i, r['action'], obs_q, obs_mk, b, [(x[0], sorted(x[1]), x[2], disp(x[2])) for x in outs]))
            cur = (obs_q, obs_mk, sp + 1)
    return n, ok, bad
if __name__ == '__main__':
    n, ok, bad = replay(E.M(refill_on_click=False))
    print('baseline replay: %d transitions, %d match, %d mismatch' % (n, ok, len(bad)))
    for b in bad[:12]: print(b)
