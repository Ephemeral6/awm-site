import json,sys
d=json.load(open(sys.argv[1] if len(sys.argv)>1 else '.last_frame.json'))
g=d['frame']; print('level',d.get('level'))
H='0123456789abcdef'
print('   '+''.join(str(i//10) for i in range(64)))
print('   '+''.join(str(i%10) for i in range(64)))
for y,r in enumerate(g): print('%2d '%y+''.join(H[v] for v in r))
