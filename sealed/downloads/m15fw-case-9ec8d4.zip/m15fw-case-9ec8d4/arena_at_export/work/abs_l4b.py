"""Abstract L4 model v2: rows abstracted (loose), everything else per established rules:
exact 9-cell panel marks with toggle, shrink anchor 0, grow anchor -2, facing kept, switch fires iff
c in {31,32} and facing up, refill = refund 10 by a 2x2 whose cols overlap 23-24 (any row: loose)."""
import heapq
REFUND = 10
SHR = frozenset({1,3,5,7}); SW = frozenset({1,4,7})
def w(big): return 4 if big else 2
def maxC(big, op, corr): return (62 - w(big)) if (op and corr) else (45 - w(big))
def leftC(big, c): return c - w(big) if 21 + w(big) <= c else 21
def rightC(big, op, corr, c):
    m = maxC(big, op, corr)
    if c + w(big) <= m: return c + w(big)
    return m if c <= m else c
def wins(big, op, c): return op and 58 <= c + w(big)
def succ(s):
    big, c, f, op, mk, item = s
    def mv(c2, f2):
        wn = wins(big, op, c2)
        yield (big, c2, f2, op, mk, item), 1, False, wn
        if item and not big and c2 in (22, 23, 24):
            yield (big, c2, f2, op, mk, False), 1, True, wn
    yield from mv(c, 'U'); yield from mv(c, 'D')
    yield from mv(leftC(big, c), 'L')
    for corr in (False, True): yield from mv(rightC(big, op, corr, c), 'R')
    for k in (1, 3, 4, 5, 7):   # other cells can only delay a completion (pure waste)
        m = mk ^ {k}
        if m == SHR:
            big2, c2 = (False, c) if big else (True, c - 2)
            yield (big2, c2, f, op, frozenset(), item), 2, False, wins(big2, op, c2)
        elif m == SW:
            op2 = op or (c in (31, 32) and f == 'U')
            yield (big, c, f, op2, frozenset(), item), 2, False, wins(big, op2, c)
        else:
            yield (big, c, f, op, frozenset(m), item), 1, False, False
def best(start, spent0=0, B=18):
    """Dijkstra on (state, spent) with refund semantics; returns min final spent of a win, or None."""
    pq = [(0, spent0, start)]; seen = {}
    gross = {}
    while pq:
        g, sp, s = heapq.heappop(pq)
        key = (s, sp)
        if key in seen: continue
        seen[key] = g
        for t, k, r, wn in succ(s):
            sp2 = sp + k - (REFUND if r else 0)
            if sp2 > B: continue
            if wn: return g + k, sp2
            if (t, sp2) not in seen: heapq.heappush(pq, (g + k, sp2, t))
    return None
if __name__ == '__main__':
    init = (True, 37, 'D', False, frozenset(), True)
    for R in (10, 11, 12, 13, 14, 18):
        REFUND = R
        print('refund', R, '->', best(init))
    REFUND = 10
    for B in (18, 19, 20, 21, 22):
        print('refund 10, budget', B, '->', best(init, 0, B))
