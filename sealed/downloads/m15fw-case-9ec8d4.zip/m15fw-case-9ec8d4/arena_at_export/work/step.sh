#!/bin/bash
# usage: step.sh "bet text" ACTION...
cd D:/arc-arena/m15fw-case-9ec8d4
python play.py bet "$1" >/dev/null && shift && python play.py act "$@" && python play.py settle | tail -n +3 | grep -v '^$' ; python work/diff.py
