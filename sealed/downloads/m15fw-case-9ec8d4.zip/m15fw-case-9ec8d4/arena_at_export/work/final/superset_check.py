"""Does 'a pattern completes when the marks CONTAIN the recipe' (never tested) lower the least
winning budget? Exact search (concrete reading otherwise: fire at col 31/32 any facing, exact grow
anchor, refill when eligible, refund 10, permissive win order). Both effects may fire on one click
(either order)."""
import heapq, sys
sys.path.insert(0, 'work/final')
from gen import moveQ, wins, growOpts, eligible
SHR = {1, 3, 5, 7}; SW = {1, 4, 7}
def eff_shr(q):
    s, r, c, op, it = q
    return [(2, r, c, op, it)] if s == 4 else growOpts(q)
def eff_sw(q):
    s, r, c, op, it = q
    return [q, (s, r, c, True, it)] if c in (31, 32) else [q]
def best(B):
    start = ((4, 25, 37, False, True), frozenset(), 0)
    pq = [(0, 0, start)]; seen = set(); n = 0
    while pq:
        g, _, st = heapq.heappop(pq)
        if st in seen: continue
        seen.add(st); q, m, sp = st
        succ = []
        for d in range(4):
            q2 = moveQ(q, d)
            if wins(q2): return g + 1
            succ.append((q2, m, sp + 1))
        for k in (1, 3, 4, 5, 7):
            m2 = m ^ {k}
            a, b = SHR <= m2, SW <= m2
            if not (a or b):
                succ.append((q, frozenset(m2), sp + 1)); continue
            outs = []
            if a and b:
                outs = [q3 for q2 in eff_shr(q) for q3 in eff_sw(q2)] + [q3 for q2 in eff_sw(q) for q3 in eff_shr(q2)]
            elif a: outs = eff_shr(q)
            else: outs = eff_sw(q)
            for q2 in outs:
                if wins(q2): return g + 1
                succ.append((q2, frozenset(), sp + 2))
        for q2, m2, sp2 in succ:
            if eligible(q2): q2 = q2[:4] + (False,); sp2 = max(0, sp2 - 10)
            if sp2 > B: continue
            n += 1; heapq.heappush(pq, (g + 1, n, (q2, m2, sp2)))
    return None
for B in (16, 17, 18, 19):
    print('superset completion, B', B, '->', best(B), flush=True)
