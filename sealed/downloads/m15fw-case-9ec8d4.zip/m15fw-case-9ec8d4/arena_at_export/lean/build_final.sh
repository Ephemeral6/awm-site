#!/bin/bash
# Build lean/FinalProof.lean from scratch (toolchain pinned per METHOD.md).
set -e
LEAN=~/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lean.exe
cd "$(dirname "$0")"
"$LEAN" --version
rm -f FinalTables.olean FinalModel.olean FinalCert.olean
LEAN_PATH=. "$LEAN" -o FinalTables.olean FinalTables.lean
LEAN_PATH=. "$LEAN" -o FinalModel.olean FinalModel.lean
LEAN_PATH=. "$LEAN" -o FinalCert.olean FinalCert.lean
LEAN_PATH=. "$LEAN" FinalProof.lean
