# Final proof: m15fw level 4 cannot be won within its budget

## Build

```bash
bash lean/build_final.sh        # toolchain pinned: leanprover--lean4---v4.34.1 (METHOD.md)
```

The script compiles, in order, `FinalTables.lean`, `FinalModel.lean`, `FinalCert.lean` and `FinalProof.lean`.
Measured on this machine from scratch:
- total time about 100 s;
- peak memory 735 MB (in `FinalCert.lean`; 328 MB for `FinalProof.lean`).

None of these files uses `sorry`, `native_decide` or an `axiom` declaration. Every heavy check is `decide +kernel`, which is checked by the kernel.

`FinalProof.lean` ends with:

```
'Final.double_wins_18' does not depend on any axioms
'Final.witness_wins_19' does not depend on any axioms
'Final.l4_least_budget' depends on axioms: [propext, Classical.choice, Quot.sound]
'Final.l4_no_win' depends on axioms: [propext, Classical.choice, Quot.sound]
```

## Main theorem: `Final.l4_no_win`

```lean
theorem l4_no_win (u : U) (hF : HFire u) (hG : HGrow u) (hR : HRefund u) (hD : HNoDouble u)
    (as : List Act) : run u 18 init as = false
```

In plain words: for every way of filling in the rules I could not pin down that satisfies the four hypotheses, and for every finite list of actions (moves, panel clicks, off-panel clicks), playing that list from the level-4 start position does not win within the measured budget of 18 units.

**The model** is `FinalModel.lean`. It has the same rules as `M15fwModel.lean`, specialised to level 4.

**The unknowns** are the fields of `U`:
- `fires`: does completing the switch pattern open the barrier here?
- `res`: where the cursor ends up after completing the shrink pattern.
- `refill`: whether an eligible refill triggers, and when.
- `refundTo`: units spent after a refill.
- `sup`: does a pattern complete when the marks contain the recipe plus extra cells?
- `both`, `order`, `pick`: what happens when the marks contain both recipes.

**Built-in rules.** These were read off or verified against recorded steps, and are definitions rather than hypotheses:

| Rule | Evidence |
|---|---|
| **Moves** slide by the cursor's side length, stopping short of impassable cells | Many steps in attempts 1–8 |
| **Costs:** 1 per action, 2 per completing click, 0 per off-panel click; budget 18 | `work/fit_budget.py`: one surviving parameter combination over every bar reading of all 8 attempts |
| **Panel clicks** toggle one cell | Attempt 6 |
| **A completion** clears the panel | Every completion recorded |
| **Board:** room, corridor, barrier, goal, stalk, switch frame | Read off the frames; stalk passability seen in attempt 3 |
| **Refill eligibility:** only a 2×2 overlapping the item | Attempt 1: a 4×4 covering the item got nothing; attempts 4, 6, 8: a 2×2 did |
| **Win** = cursor overlaps the goal | Levels 1–3 |

**Permissive choices.** Where the order of events was never observed, the model takes the reading that allows more wins:
- a winning action counts even if it overdraws the budget;
- a completed pattern that leaves the cursor on the goal wins;
- the refill is applied before the budget check;
- facing is not tracked at all.

## Hypotheses and their evidence

All four are explicit arguments of the main theorem.

**`HFire u`: the switch can only open the barrier when the cursor's left column is 31 or 32.**
- **Evidence:** 13 recorded switch completions, `M15fwModel.casts`.
  - Fired at the stalk column every time I tried it with the cursor facing up. On level 4 that was a 2×2 at column 31 in attempts 3–6 and a 4×4 at column 31 in attempts 7–8.
  - Never fired at columns 29, 33, 37, 41 or 43.
- **Stated more weakly than the evidence:** it leaves facing and size free. The observation that facing left at column 31 does not fire (attempt 5) is not used.

**`HGrow u`: completing the shrink pattern ends in one of `growOpts`.**
- **4×4 → 2×2** at the same top-left corner. Observed on level 1 and in attempts 2–8.
- **2×2 → 4×4 at (r−2, c−2)** when that footprint is free. Observed in attempts 4, 7 and 8.
- **Next to walls** (never observed): any free placement of the 4×4 containing the old 2×2, or no growth at all.

**`HRefund u`: a refill refunds at most 10 units.**
- **Evidence:** exactly 10 every time it was measured.
  - Attempt 4: 10 spent, +1 for the move, then 1.
  - Attempt 6: 18 spent, +1, then 9.
  - Attempt 8: 11 spent, +1, then 2.
- **Left free:** whether and when an eligible refill triggers (`u.refill`).

**`HNoDouble u`: no single click fires both recipes.**
- **Evidence: none either way.** Marks containing both recipes were never made.
- **Load-bearing.** `double_wins_18` shows that a reading satisfying the other three hypotheses, but firing both effects on one click (grow, then the switch), wins at budget 18.
- **Left free:** whether marks that contain a recipe plus extra cells complete it (`u.sup`), and which recipe fires when the marks contain both but only one fires (`u.pick`).

## Bound and witness: `Final.l4_least_budget`

```lean
theorem l4_least_budget :
    (∀ B, B ≤ 18 → ∀ (u : U), HFire u → HGrow u → HRefund u → HNoDouble u →
        ∀ as, run u B init as = false) ∧
    (∃ u : U, HFire u ∧ HGrow u ∧ HRefund u ∧ HNoDouble u ∧ ∃ as, run u 19 init as = true)
```

In this model the least budget at which a win exists is **19**.

`witness_wins_19` exhibits the winning list: 27 actions, 30 gross units, the last one overdrawing to 20.
- **Reading used:** `uW`. The switch fires at column 31/32 in any facing, grow uses the observed anchor, the refill always triggers, and the refund is exactly 10.
- **The list:** down ×2, left ×3; shrink; left onto the item (refill); up; right; grow; right ×2; switch; right ×6.

This route fires the switch with the 4×4 facing right. The evidence says that doesn't fire, and in the game itself the cheapest route I found costs 21 (attempts 7 and 8 died exactly on schedule). The model's least budget is lower only because `HFire` was weakened.

## How the proof works

Two lower bounds:
- `NN st`: units still needed to win, ignoring the refund.
- `MM st`: units still needed to win by a route that still takes the refill.

Each is a table entry for the cursor/board part `q` (size, row, column, barrier opened, item present) plus, for each pattern, the number of its recipe cells still unmarked.

**The tables** are 2,826 positions. They were computed by value iteration (`work/final/gen.py`) and stored as a binary search tree (`FinalTables.lean`). Nothing about them is trusted: `FinalCert.lean` checks every local inequality they must satisfy, at every position of the domain, with `decide +kernel` (320 row chunks, `chunk_ok`).

**The invariant** is `Inv B st`:
- `B + 2 ≤ NN st + spent`;
- if the item is still present, also `B + 12 ≤ MM st + spent`.

**Why it holds throughout:**
- every action preserves `Inv`: `pre_inv` for the action, `post_inv` for a refill;
- no action can win from a state where `Inv` holds and spent ≤ B;
- the start position satisfies it for every B ≤ 18, since `NN init = 23` and `MM init = 30` (`init_inv`);
- `run_false` is the induction over the action list.

## What I could not close

- **`HNoDouble` is genuinely open.** It is the one hypothesis with no evidence, and dropping it breaks the bound (`double_wins_18`). The experiment that would settle it: mark cells 1, 3, 4, 5 and 7 so the marks contain both recipes, and see what the last click does.
- **The model's least budget (19) is below the cheapest route under the full evidence (21).** I chose weaker hypotheses so that the theorem covers more readings. I did not prove 21 in Lean.
- **Off-panel clicks** are modelled as free no-ops. Seven different targets were tested (attempts 7–8), not every cell.
- **The connection to `M15fwModel.lean` is by construction.** It is the same rules restated, with the stalk and the opened switch frame made passable. It is not a proved refinement between the two Lean models.

## Update after the self-audit repair round (2026-10-22)

**Changed rules**, all now in `FinalModel.lean`:
- **Grow refill (R12.4):** a grow that leaves a 4×4 over the item may refill (−10). Observed in the round's att.2: bar 30 → 44 at the grow, (35,25) → (33,23).
- **Strict order (R6):** the budget is checked BEFORE the win. Observed in att.2: the move onto the goal at spent 19 gave GAME_OVER. `run` now uses this order.
- **Blocked move turns the cursor (R17), att.3:** facing is not part of the Lean state (the switch hypothesis ignores facing), so no Lean change is needed.

**Certificate:** N(init) = 23, M(init) = 29. The invariant is B+1 ≤ NN+spent, plus B+11 ≤ MM+spent while the item is present.

**Main theorem:** `Final.l4_no_win` (budget 18) is closed.
**Relaxed-model theorem:** `Final.l4_least_budget` shows no win for any B ≤ 18, and a witness `witness_wins_19` at 19. In the weak model the witness fires the switch facing right.
**Removed:** `double_wins_18` no longer holds under the strict order.

**Replay:** the full-evidence Python model (`work/selfaudit/engine.py`) reproduces 256/256 recorded level-4 transitions, with a strict facing check.

**Still untested:** the grow anchor of a 2×2 facing LEFT (R9.2). With it relaxed, the least budget would be 18 = C.
