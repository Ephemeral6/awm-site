# L4 / Claude Opus 5.5 + AWM / 9ec8d4

- **实验类别**：外部反馈后：AWM修复
- **关卡/受试**：L4 / Claude Opus 5.5 + AWM
- **论文位置**：主表修复后阶段；与原始阶段分开
- **预算/轮次**：4次
- **结果**：20 → 19（第2次正确）
- **最终声明**：impossible
- **注意**：L4采用最新严格v7，L5采用较早v3；不是同一字节协议的独立重复。

## 从哪里检查

1. [受试逐轮/汇总答复](answers.md)。这是阅读入口。
2. [原始JSON / 会话提取](run.json)。摘录与索引有歧义时以原始记录为准。
3. [既有独立重编报告](rebuild/rebuild.json)。

## 同一case的其他阶段

- [主表：AWM原始实验](../../../02_awm_main/m15fw-case-9ec8d4/README.md)

## 采集来源

`D:\THU\2026 Summer\ARC-AGI\ours\sc25-repair-8plus4\runs-v7\m15fw-case-9ec8d4.json`

这是采集时的来源路径；当前arena可能已经经过后续修复，不能代替本目录保存的阶段快照。

[返回本类实验](../../README.md) · [返回实验总表](../../../EXPERIMENTS.md)
