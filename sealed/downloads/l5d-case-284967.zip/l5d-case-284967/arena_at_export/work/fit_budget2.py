import json,math,itertools,sys
sys.path.insert(0,'concepts');sys.path.insert(0,'.')
L=[json.loads(l) for l in open('transitions.jsonl')]
from _lib import cursor
segs=json.load(open('work/l5_segs.json'))
# classify fires by pattern: need prev selection + clicked cell -> rebuild from transitions
def sel(g): return frozenset((r,c) for r in range(3) for c in range(3) if g[50+5*r][25+5*c]==14)
SP={frozenset({(0,1),(1,0),(1,2),(2,1)}):'f',frozenset({(0,1),(1,1),(2,1)}):'6',frozenset({(0,0),(0,1),(1,1)}):'b'}
kinds=[]
from _lib import bar
idx=0;cur=None;out=[]
for r in L:
    if r['ctx']['level_prev']!=5: continue
    st=(cursor(r['prev']) or (0,0))[:3]
    if bar(r['prev'])==128 and st==(29,17,4) and (cur is None or len(cur)>3): cur=[];out.append(cur)
    a=r['action'];k=None
    if a.startswith('ACTION6'):
        x,y=map(int,a.split(':')[1].split(','))
        cell=[(rr,c) for rr in range(3) for c in range(3) if abs(x-(25+5*c))<=1 and abs(y-(50+5*rr))<=1]
        if cell:
            s=set(sel(r['prev']))^{cell[0]}
            k=SP.get(frozenset(s))
            if k=='f': k='grow' if (cursor(r['prev']) or (0,0,4))[2]==2 else 'shrink'
    cur.append(k)
for s,ks in zip(segs,out):
    for t,k in zip(s,ks):
        if t['kind']=='fire': t['sp']=k
from collections import Counter
print(Counter(t.get('sp') for s in segs for t in s if t['kind']=='fire'))
def disp(rem,N): return 4*max(0,min(32,math.ceil(32*rem/N-1e-9)))
res=[]
for N in range(32,40):
  for ex in itertools.product((0,1,2),repeat=4):
    E=dict(zip(['shrink','grow','6','b'],ex))
    for pg in range(6,14):
      ok=0
      for s in segs:
        rem=N;good=True
        for t in s:
          c={'mv':1,'click':1,'hint':0,'noop':0}.get(t['kind'],None)
          if t['kind']=='fire': c=1+E[t['sp']]
          rem-=c
          if t['pad']: rem+=pg
          if t['dead']:
            good = rem<0; break
          if rem<0 or disp(rem,N)!=t['b1']: good=False;break
        ok+=good
      if ok==len(segs): res.append((N,E,pg))
print(len(res)); [print(x) for x in res[:20]]
