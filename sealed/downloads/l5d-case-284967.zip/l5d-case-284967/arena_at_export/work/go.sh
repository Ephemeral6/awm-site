#!/bin/sh
# usage: work/go.sh "bet text" ACTION...
cd D:/arc-arena/l5d-case-284967
python play.py bet "$1" >/dev/null || exit 1
shift
python play.py act "$@"
python play.py settle | tail -4
python work/diff.py
