## play_first 1

I reached **level 5** and beat levels 1–4 (4 levels completed), but I did not beat the game. Level 5 ended in **GAME_OVER**: the budget bar on the right edge ran out. I did not call `/reset`.

**How the game works:**
- **Movement:** you steer a 4×4 block (later 2×2) with actions 1–4 (up, down, left, right). A level is won when the block overlaps the inside of the goal box.
- **Spells:** you cast one by clicking cells in the 3×3 grid at the bottom so the selected set exactly matches one of the patterns shown on the left; a partial or extra selection does nothing. There are three:
  - **Shrink** (f pattern): turns the block into a 2×2 so it fits through 2-wide passages.
  - **Teleport** (b pattern): moves the block to the spot marked with b corner marks.
  - **Key** (6 pattern): sends a probe in the direction the block faces. If it travels up a narrow passage into a 6-coloured box, that box disappears and the barrier of the matching colour opens. A badly aligned probe bounces back.
- **Budget bar:** every action drains it; on level 5 it cost about 4 cells per action out of 128. Stepping on a small pad of the bar's colour refills it by 32, and the pad is then used up. The action after the bar hit zero returned GAME_OVER.

**What went wrong on level 5:** I shrank the block and opened the first barrier, then found I had only about 21 actions left against a route of roughly 40. I detoured to the refill pad, but the remaining route still needed about 26 actions with only 11 left. The bar ran out while I was still climbing toward the second key box. The real mistake was not counting the route against the bar before spending actions.

**Method work:**
- **Concepts:** I registered six concepts and checked them against 137 recorded moves. All six currently hold with no contradictions, though two rest on only 3 and 1 samples.
- **Revisions:** two concepts were revised after contradicting moves. One was hit by the very first action, which the game ignored; the other by the bar refill.
- **Bets:** I wrote a prediction before every action, but only as free text.
- **Frame predictions:** I wrote no frame-predicting rules, so predicted-versus-actual frames were never compared. That METHOD requirement is not met.
- **Formalization:** the second step (the Lean formalization) has not been done yet.

**Harness change:** I added one line to `play.py` that saves the full last server response to `work/last_resp.json`. I needed it to see the spell animations; it doesn't change the gates.

The rules table, the audit of mechanisms I saw but didn't write as rules, and the notes are in `work/REPORT.md`. I also saved a memory note for the next attempt: plan the route against the bar before acting.

## play 1

I reached **level 5** and beat levels 1–4 (4 levels completed), but I did not beat the game. Level 5 ended in **GAME_OVER**: the budget bar on the right edge ran out. I did not call `/reset`.

**How the game works:**
- **Movement:** you steer a 4×4 block (later 2×2) with actions 1–4 (up, down, left, right). A level is won when the block overlaps the inside of the goal box.
- **Spells:** you cast one by clicking cells in the 3×3 grid at the bottom so the selected set exactly matches one of the patterns shown on the left; a partial or extra selection does nothing. There are three:
  - **Shrink** (f pattern): turns the block into a 2×2 so it fits through 2-wide passages.
  - **Teleport** (b pattern): moves the block to the spot marked with b corner marks.
  - **Key** (6 pattern): sends a probe in the direction the block faces. If it travels up a narrow passage into a 6-coloured box, that box disappears and the barrier of the matching colour opens. A badly aligned probe bounces back.
- **Budget bar:** every action drains it; on level 5 it cost about 4 cells per action out of 128. Stepping on a small pad of the bar's colour refills it by 32, and the pad is then used up. The action after the bar hit zero returned GAME_OVER.

**What went wrong on level 5:** I shrank the block and opened the first barrier, then found I had only about 21 actions left against a route of roughly 40. I detoured to the refill pad, but the remaining route still needed about 26 actions with only 11 left. The bar ran out while I was still climbing toward the second key box. The real mistake was not counting the route against the bar before spending actions.

**Method work:**
- **Concepts:** I registered six concepts and checked them against 137 recorded moves. All six currently hold with no contradictions, though two rest on only 3 and 1 samples.
- **Revisions:** two concepts were revised after contradicting moves. One was hit by the very first action, which the game ignored; the other by the bar refill.
- **Bets:** I wrote a prediction before every action, but only as free text.
- **Frame predictions:** I wrote no frame-predicting rules, so predicted-versus-actual frames were never compared. That METHOD requirement is not met.
- **Formalization:** the second step (the Lean formalization) has not been done yet.

**Harness change:** I added one line to `play.py` that saves the full last server response to `work/last_resp.json`. I needed it to see the spell animations; it doesn't change the gates.

The rules table, the audit of mechanisms I saw but didn't write as rules, and the notes are in `work/REPORT.md`. I also saved a memory note for the next attempt: plan the route against the bar before acting.

## probe 1

**1. What happened.** Level 5 has three spells, each cast by clicking a pattern on the panel:
- **Shrink:** turns the 4×4 cursor into a 2×2.
- **6-probe:** dashes in the direction the cursor faces and opens a barrier when it reaches the 6-box of the matching colour.
- **Teleport:** jumps the cursor to the spot marked with b corners.

The goal sits above a corridor that you can only enter by teleporting, and that corridor is blocked by the dd barrier. The dd box can only be hit from a 2-cell-high strip at the top right. Getting there means crossing the cc barrier and climbing a 2-wide stem.

I shrank first, opened cc, and only then counted the cost. The bar costs about 4 cells per action here, which is roughly 35 actions in total, and my route needed about 40. I detoured to the refill pad (+8 actions), but ran dry while climbing the stem. The bar hit 0, and the next action returned GAME_OVER.

The cause was not planning against the budget. I also travelled as a 2×2 (2 cells per step) where I could have moved as a 4×4 (4 cells per step) and shrunk later.

**2. Yes, I still see a way.** In my model the level is winnable with one unit to spare. A search over the model found a route costing 42 units, and the pad gives +8, so it needs a start budget of 34. I measured 35: 43 actions, including the pad, before the GAME_OVER on the 44th. The route:
- R, U (4×4 under the left stem, facing up), then cast 6 to open cc.
- D, D, R×4, D, R×3: cross the opened cc and land on the pad as a 4×4.
- U×3, L, shrink: the 2×2 is now under the right stem.
- U×5, R: up to the strip, facing right.
- Cast 6 to open dd, teleport, then U×7 to the goal.

What I still need to check:
- **The 4×4 cast.** The 6-probe from a 4×4 has to work when the stem lines up with its left half. Level 3 says yes, level 4 says no when the stem is on the right half, and I have never tested it in level 5. This is what the model's "probe uses the top-left 2×2" rule rests on.
- **The probe's range.** It has to travel the 10 strip columns to the dd box.
- **The 2×2 teleport landing** at rows 18–19, cols 34–35, which I read off the corner marks.
- **Bar cost, which matters most.** Some firing clicks drained 8 or 12 cells instead of 4: level 2's teleport, level 4's 6-casts, level 5's shrink. My model charges 1 unit per click. If those extras are real, the route needs about 44–46 units against roughly 43 available, and fails.

**3. Next attempt.**
- Play the route above.
- Read the bar after every action and compare it with the planned spend. The checkpoints are the first cast, the pad, and the shrink.
- If the 4×4 cc cast bounces, fall back to the 2×2 cast I already know works. That costs about 5 more units, and I'd test the ff pad before committing to it.
- Before any cast, compute the cost of the remaining route.

**4. Formal system** (`lean/L5Model.lean`, new this attempt; there was no earlier one to amend).
- **Objects.** Each one is kept because dropping it merges positions that behave differently:
  - Cursor (row, col, size, facing): facing decides where the probe goes, and size decides which stems you fit.
  - Flags `cc`, `dd`, `pad`: a barrier open versus shut, and a pad used versus unused, each lead to different outcomes.
  - Budget and `won`.
  - A static floor mask taken from the level 5 start frame, plus rectangles for the barriers, boxes, goal interior and pad.
  - Panel state was dropped: clicks are bundled into atomic casts.
- **Rules.**
  - R-move: slide by the largest k up to the cursor size whose swept cells are all floor; facing becomes the pressed direction.
  - R-win: overlapping the goal interior wins.
  - R-pad: stepping on the unused pad adds 8 units.
  - R-shrink: costs 4 and keeps the top-left corner.
  - R-cast6: costs 3; the probe is the top-left 2×2 and it opens the barrier whose box it touches.
  - R-tele: costs 3.
  - R-budget: an action is refused unless the budget covers its cost.
  - Explicitly not in the model: growing back to 4×4, the ff pad, the extra cost of firing clicks, the free actions, and the panel.
- **Check against observations.** On all 37 observed level 5 moves, the model put the cursor where the frame showed it (37 of 37). The casts, pad and level-change transitions were not replayed.

**5. Proof.** File: `lean/L5Model.lean`.

MAIN-THEOREM: lean/L5Model.lean : L5.l5_winnable_in_model

The statement is `wins 34 route2 = true`: one witness action sequence, checked by kernel evaluation (`decide +kernel`). It assumes no hypotheses, and start budget 34 is below the measured 35.

The model-level search that found the route ran in Python; Lean only re-checks the witness. Three side theorems show the result isn't empty:
- `route2_fails_33`: the same route is refused with budget 33.
- `route2_needs_dd`: without the second cast it does not win, even with budget 60.
- `route_wins_36` / `route_fails_35`: my hand-found 44-unit route wins at 36 and fails at 35.

`#print axioms` output, verbatim:
```
'L5.route_wins_36' depends on axioms: [propext]
'L5.route_fails_35' depends on axioms: [propext]
'L5.route_cost' does not depend on any axioms
'L5.l5_winnable_in_model' depends on axioms: [propext]
'L5.route2_fails_33' depends on axioms: [propext]
'L5.route2_needs_dd' depends on axioms: [propext]
```

The proof leans on R-move, R-cast6, R-pad, R-tele, R-shrink, R-budget and R-win. The model is looser than the game in two places, and both are exactly where "winnable in the model" might not carry over:
- Casts cost a fixed number of clicks, ignoring the extra cost seen on some firing clicks.
- Probe range is unlimited, and the probe collides as its top-left 2×2, a rule fitted to two observations.

The step from "1 unit" to "about 3.7 bar cells" is also an assumption I measured on level 5 only, not one I established.

**6.** The formal system was created this attempt, so there is nothing unchanged to report.

VERDICT: winnable
CONFIDENCE: 50