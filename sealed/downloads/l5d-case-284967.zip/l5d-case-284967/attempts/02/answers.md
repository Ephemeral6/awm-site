## play_first 1

This attempt restarted on **level 5** and I did not beat it, so the game is not won: 4 of the levels are completed overall. The game is still `NOT_FINISHED` with about one action of bar left. I stopped there because the goal was out of reach, and I did not call reset.

**What worked (the route planned after attempt 1):**
- **First barrier:** casting the 6-spell as a 4×4 from below the left stem opened it. That confirms the probe rule I had only inferred from level 3.
- **Refill pad:** I stepped onto it as a 4×4 and got the +32 refill.
- **Second barrier:** I shrank under the right stem, climbed to the strip, and cast facing right. The probe opened the barrier blocking the goal corridor. The bar stayed exactly on plan up to here.

**What broke:** casting the teleport while the cursor was 2×2 did not send it into the goal corridor. It landed on the ff pad at the bottom left (rows 37-38, cols 15-16), inside the f corner marks that appear after shrinking. A second teleport from there didn't move the cursor and cost 16 cells. That left no bar for the 7 moves up to the goal.

**Model correction:** the teleport destination depends on the cursor's size. The teleport rule in `lean/L5Model.lean` is wrong for a 2×2 cursor, so its "winnable" theorem doesn't hold for the real game. I've written this up in `work/REPORT.md`.

**For a next attempt:** be 4×4 when teleporting. That means finding out how to grow back after the strip cast; my guess is casting the f-spell again while small, possibly landing at the ff pad. From the corridor target a 4×4 reaches the goal in 4 moves. I've saved this to memory.

## play 1

The game has now ended: GAME_OVER on **level 5**, with 4 levels beaten. I did not beat the game.

I spent the last cells of the bar trying the shrink pattern again while the cursor was 2×2, to see whether it grows back to 4×4. The first click took the bar to 0. The game then ended on the second click, before the pattern was complete, so growing back is still untested.

What I learned this attempt is in `work/REPORT.md`:
- **What worked:** both barriers can be opened on budget, using a 4×4 cast for the first one and the refill pad on the way.
- **What failed:** casting the teleport while the cursor is 2×2 sends it to the ff pad at the bottom left, not into the goal corridor, so it has to be 4×4 when teleporting.
- **Next attempt:** first test how to grow back from 2×2 to 4×4, and what that costs in bar.

## probe 1

**1. What happened.** Level 5 started over and I followed my planned route.
- **First barrier:** casting the opening spell as a 4×4 from below the left stem opened it.
- **Refill pad:** I stepped onto it as a 4×4 and got the refill.
- **Second barrier:** I shrank to 2×2, climbed to the narrow strip and cast facing right, which opened the barrier in front of the goal. The budget bar matched the plan to within one action.
- **Teleport:** I then cast the teleport while still 2×2. It did not go into the goal corridor; it dropped me on the small "ff" pad at the bottom left. That pad is the one framed by the corner marks that appear when you shrink.
- **Retry:** a second teleport from there did not move the cursor and cost 16 cells.

That left no budget for the climb, and the game ended on a click once the bar was empty. It failed because my teleport rule ignored size: the destination depends on whether the cursor is small or big. Only a 4×4 lands in the corridor, which the level 2 analogy suggests but I never saw in level 5. Opening the second barrier requires being 2×2, and I don't know how to get back to 4×4.

**2. Can it be beaten?** I can't tell either way.

- **Proved in my model:** without a way to grow back, the level cannot be won. The argument has three steps:
  1. The goal can only be reached through the corridor.
  2. The corridor can only be entered by teleporting as a 4×4.
  3. The second barrier only opens from a 2×2. With no grow, once you are 2×2 you stay 2×2, so you can never be both.

  This rests on two things:
  - **Established:** the floor map, checked in Lean: the corridor is walled off from every other floor cell, and the barrier rows really are closed.
  - **Assumed, not proved:** that the slide rule can't cross those walls. That step is argued in prose only; the Lean proof is over the abstract zone model.

- **The step to the real game is the problem:** growing back is simply missing from my model, and leaving it out makes the model stricter than the game. The corner marks suggest a grow exists, probably casting the shrink pattern again while small, landing on the ff pad.
- **A route that might work:** do everything as in attempt 2 up to the second barrier, then grow (4 clicks), teleport as a 4×4 (3 clicks), and climb 4 moves.
- **What would settle it:**
  - whether the shrink pattern grows a 2×2 cursor, and where it lands;
  - whether a 4×4 teleport really lands in the corridor;
  - the budget. After the second barrier I had 40 cells (about 10 actions) left, and this tail needs about 11 plus any extra charge on spell clicks. That is about one action short, so I'd also have to save an action earlier.

**3. Next attempt.** First, test growing while small on the left board, early, while the budget can still recover: shrink, then cast the plus pattern again and watch where the cursor lands. If growing works and costs about 4 actions, re-plan the full route with growing included against the measured budget, and only commit if it fits. Otherwise, use the run to measure the 4×4 teleport destination for the record.

**4. Formal system** (amended `lean/L5Model.lean`; not rewritten):
- **Objects:** unchanged. The cursor (row, column, size, facing), the two barrier flags, the pad-used flag, the budget and the won flag.
- **R-tele revised:**
  - A 2×2 now lands on the ff pad at (37,15). That comes from the one observation this attempt.
  - A 4×4 lands at (17,33) in the corridor; that is still an assumption.
  - The old version is kept in the file's comment as refuted.
- **Theorems that changed:** last attempt's main theorem (`wins 34 route2 = true`) is now false under the corrected rule. It became `route2_fails_after_tele_fix`, and likewise `route_fails_36_after_tele_fix`.
- **Zone abstraction added:** main board / corridor / above the barrier. Its actions are deliberately looser than the concrete ones, and the budget is dropped.
- **Map checks added:** `corr_isolated` and `dd_rows_closed`.
- **Grow:** explicitly marked "not in the model", and added only in a relaxed step function `stepG`.

**5. Proof.** MAIN-THEOREM: lean/L5Model.lean : L5Zone.l5_impossible_without_grow

- **What it says:** for every action list of any length, the zone model started at the level 5 start never reaches "won". It is proved by an invariant that every action preserves.
- **Rules it leans on:** R-move (as stay / up / down / win in zone form), R-shrink, R-cast6 (loosened: it may open the barrier any time the cursor is small on the main board), R-tele as revised, and R-win.
- **Where it is stricter than the game:** there is no grow rule. This is exactly why the result may not carry over.
- **Unproved assumption A1:** that slides never cross a wall the map check shows is closed. This is argued in prose, not in Lean.
- **Non-vacuity checks:** `l5_wins_with_grow` shows that adding grow makes a win possible, and `inv_fails_with_grow` shows that grow breaks the invariant.

`#print axioms` output, verbatim:
```
'L5.route_fails_36_after_tele_fix' depends on axioms: [propext]
'L5.route_fails_35' depends on axioms: [propext]
'L5.route_cost' does not depend on any axioms
'L5.route2_fails_after_tele_fix' depends on axioms: [propext]
'L5.corr_isolated' depends on axioms: [propext]
'L5.dd_rows_closed' depends on axioms: [propext]
'L5Zone.l5_impossible_without_grow' depends on axioms: [propext]
'L5Zone.l5_wins_with_grow' depends on axioms: [propext]
'L5Zone.inv_fails_with_grow' depends on axioms: [propext]
```

**6.** The formal system did change this attempt: R-tele was revised, so there is nothing unchanged to report.

VERDICT: undecided
CONFIDENCE: 50

## pushes 1

The game has now ended: GAME_OVER on **level 5**, with 4 levels beaten. I did not beat the game.

I spent the last cells of the bar trying the shrink pattern again while the cursor was 2×2, to see whether it grows back to 4×4. The first click took the bar to 0. The game then ended on the second click, before the pattern was complete, so growing back is still untested.

What I learned this attempt is in `work/REPORT.md`:
- **What worked:** both barriers can be opened on budget, using a 4×4 cast for the first one and the refill pad on the way.
- **What failed:** casting the teleport while the cursor is 2×2 sends it to the ff pad at the bottom left, not into the goal corridor, so it has to be 4×4 when teleporting.
- **Next attempt:** first test how to grow back from 2×2 to 4×4, and what that costs in bar.