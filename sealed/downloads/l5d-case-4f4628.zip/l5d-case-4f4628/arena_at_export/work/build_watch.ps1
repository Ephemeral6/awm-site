param([string]$file)
$lean = "$env:USERPROFILE\.elan\toolchains\leanprover--lean4---v4.34.1\bin\lean.exe"
$env:LEAN_PATH = "."
$base = [IO.Path]::GetFileNameWithoutExtension($file)
$p = Start-Process -FilePath $lean -ArgumentList "-o", "$base.olean", $file -NoNewWindow -PassThru -RedirectStandardOutput "..\work\$base.out" -RedirectStandardError "..\work\$base.err"
$peak = 0
while (-not $p.HasExited) {
  try { $p.Refresh(); $m = [int]($p.WorkingSet64/1MB); if ($m -gt $peak) { $peak = $m } } catch {}
  if ($peak -gt 1900) { Stop-Process -Id $p.Id -Force; "KILLED at $peak MB"; break }
  Start-Sleep -Milliseconds 500
}
"$file exit=$($p.ExitCode) peakMB=$peak"
