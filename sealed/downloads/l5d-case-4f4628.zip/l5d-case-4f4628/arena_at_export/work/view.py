import json,sys
sys.path.insert(0,'.')
from geo import hist, blobs
g=json.load(open('.last_frame.json'))['frame']
H='0123456789abcdef'
print('    '+''.join(str(i%10) for i in range(64)))
for i,r in enumerate(g): print('%3d '%i+''.join(H[v] for v in r))
print(hist(g))
