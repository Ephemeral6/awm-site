#!/bin/bash
# usage: step.sh "bet text" ACTION...
cd /d/arc-arena/l5d-case-4f4628
python play.py bet "$1" >/dev/null && shift && python play.py act "$@" && python play.py settle | grep -E "反例|闸|错|FALSE" ; python work/diff.py
