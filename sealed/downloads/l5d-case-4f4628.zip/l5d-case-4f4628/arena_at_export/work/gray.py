"""Gray-code walk over panel patterns; one click per new pattern; report any change outside panel/bar."""
import json, subprocess, sys
CELLS=[(26,50),(31,50),(36,50),(26,55),(31,55),(36,55),(26,60),(31,60),(36,60)]
ORDER=[0,5,1,6,2,7,3,8,4]  # attempt 8: interleave low/high cells
ICONS=[{1,3,5,7},{0,1,4},{1,4,7}]
n=int(sys.argv[1]); start=int(sys.argv[2]) if len(sys.argv)>2 else 1
state=set()
# replay state up to start
for i in range(1,start):
    b=ORDER[(i & -i).bit_length()-1]; state ^= {b}
for i in range(start,start+n):
    b=ORDER[(i & -i).bit_length()-1]
    new=state ^ {b}
    if new in ICONS: print('skip-icon',sorted(new)); 
    x,y=CELLS[b]
    prev=json.load(open('.last_frame.json'))['frame']
    subprocess.run(['python','play.py','bet','gray %d: pattern %s; bet no world change outside panel/bar'%(i,sorted(new))],capture_output=True)
    out=subprocess.run(['python','play.py','act','ACTION6:%d,%d'%(x,y)],capture_output=True,text=True,encoding='utf-8').stdout
    s=subprocess.run(['python','play.py','settle'],capture_output=True,text=True,encoding='utf-8').stdout
    if '反例' in s or '跑不起来' in s: print('GATE',s[-400:]); break
    g=json.load(open('.last_frame.json'))['frame']
    ch=[(r,c) for r in range(64) for c in range(62) if prev[r][c]!=g[r][c] and not (47<=r<=63 and 22<=c<=38)]
    E=sum(1 for r in range(64) if g[r][62]==14)//2
    print(i,sorted(new),'E',E,'world-changes',len(ch), out.strip().splitlines()[0][-30:])
    state=new
    if 'GAME_OVER' in out or ch: break
