#!/bin/bash
cd /d/arc-arena/l5d-case-4f4628
for a in "$@"; do
  python play.py bet "attempt3 $a: ${BET:-predict per lean/L5Model.lean pstep}" >/dev/null
  out=$(python play.py act $a); echo "$out" | grep -E "关|闸|拒绝"; echo "$out" | grep -q "关" || exit 1
  s=$(python play.py settle | grep -E "反例|跑不起来" ); [ -n "$s" ] && { echo "$s"; exit 1; }
  echo "$out" | grep -qE "GAME_OVER|WIN" && exit 0
  python -c "
import json,sys;sys.path.insert(0,'concepts');sys.path.insert(0,'.')
from _lib import piece
g=json.load(open('.last_frame.json'))['frame'];print('  E',sum(1 for i in range(64) if g[i][62]==14)//2, piece(g), piece(g,(2,)))"
done
