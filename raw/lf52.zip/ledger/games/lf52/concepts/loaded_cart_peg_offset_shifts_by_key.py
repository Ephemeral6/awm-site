# -*- coding: utf-8 -*-
"""方向键按下、载子车自己走得动时，载子车与每一颗盘上子的**相对位移**恰好朝键的反方向变一个 STRIDE——镜头钉住车还是车自己在屏幕上挪，两档算出来完全一样。"""
LEVEL = "L6"
SCOPE = (
    "只看 ACTION1/2/3/4。prev 与 nxt 里都必须恰好一辆载子车（装子卸子那一步载子身份会变，"
    "不归这条管），否则 NA。prev 盘上没子（pegs 减 carts 为空）时 NA——没有可量的东西。"
    "载子车自己走不动时 NA：借 cart_moves_iff_rail_ahead._free，prev 帧上这辆车朝键的方向 "
    "_free 不是 True 就闭嘴，那一档归 cart_moves_iff_rail_ahead 管。"
    "载子车自己的位移不是 (0,0) 也不是 delta 时 NA：那一帧哪一档都不是，这条本来就没在说它。"
    "落到视口外的子允许消失，不算反例——pegs() 读的是窗口不是盘。"
)
NOTE = (
    "第 4877 步写。由来是第 2364~2380 步那条走通的路：车与盘上子的相对位移从 (-18,30) "
    "一路缩到 (6,6)，靠的就是这件事。册子里没有一条单独说过它——pegs_scroll_with_the_board 说的是"
    "子在屏幕坐标里跟着盘滚，camera_pins_loaded_cart / loaded_cart_column_pinned 说的是镜头钉不钉车，"
    "cart_slides_one_stride 说车动就动一格；相对位移这一层是它们的交集，谁都没说出来。"
    "它值钱的地方正在于**不需要知道是哪一档**：哪一档由什么决定册子答不出"
    "（camera_pins_loaded_cart 对位移 (0,0) 返回 NA，等于没人管），而相对位移两档相同。\n"
    "写之前量了两遍，第一遍的原话留在这儿不删：第一版（probe_rel_offset.txt）在全去重语料上"
    "382 TRUE / 3 FALSE / 1885 NA。三条 FALSE 都是第 2242 / 2656 / 4648 步的同一个局面"
    "（关 2，载子车 (12,32)→(12,30)）。我当时猜「是因为车不在 STRIDE 格点上」，"
    "**这个猜想被我自己的探针判据否掉了**（probe_offgrid.txt 判据二：不对齐那一堆里 TRUE 有 295 条，"
    "不对齐照样成立，按它缩 scope 就是给自己的反例圈地）。猜错了，记在这儿。\n"
    "真正漏写的前提是：那三条里载子车在 ACTION4（delta (0,+6)）下挪了 (0,-2)，"
    "既不是 (0,0) 也不是 (0,+6)，哪一档都不是。第二版把「载子车位移 ∈ {(0,0), delta}」"
    "写成开口条件，并当场查了圈地（probe_rel_offset2.txt 判据二）：新条件挡掉了 18 条原本判 TRUE 的、"
    "3 条原本判 FALSE 的，被挡掉的位移全是 ±2 这种半格档，是一整类局面不是三条定制。"
    "第二版 364 TRUE / 0 FALSE / 1906 NA，覆盖第 1~9 关、两档、四个方向键都有。\n"
    "它不说车该往哪开——那是规划器的事；它只说按了之后相对位移怎么变。"
)
EVIDENCE = [
    # 乙档（车自己挪）：四个方向各一条，跨关
    "c04df16417c9b5ff",  # 第 2184 步 关1 ACTION4 位移 (0,6)
    "15a19f0b1bc9bc88",  # 第 2188 步 关1 ACTION3 位移 (0,-6)
    "a9b8e08715725592",  # 第 2185 步 关1 ACTION2 位移 (6,0)
    "d7652e05f25e00b8",  # 第 2264 步 关2 ACTION1 位移 (-6,0)
    "d301630b011fa843",  # 第 2372 步 关4 ACTION1 位移 (-6,0)
    "71bf69a04a75ff2b",  # 第 4500 步 关9 ACTION1 位移 (-6,0)
    # 甲档（镜头钉车、盘滚）：位移 (0,0)，跨关
    "81159804c5e0612b",  # 第 2368 步 关4 ACTION4 位移 (0,0)
    "ed7cd904312eeb28",  # 第 2381 步 关4 ACTION3 位移 (0,0)
    "b06834d03f121828",  # 第 2291 步 关3 ACTION4 位移 (0,0)
    "8d6318dd0001130e",  # 第 4359 步 关7 ACTION1 位移 (0,0)
    "24abccd42752baf0",  # 第 4392 步 关8 ACTION4 位移 (0,0)
    # 塑造了 scope 的那三条：第一版判 FALSE，第二版按「哪一档都不是」判 NA。
    # 照硬要求抄进来，不藏；它们判 NA，不是判 TRUE。
    "45a2ec3629e32866",  # 第 2242 步 关2 ACTION4 载子位移 (0,-2)
    "1ba2ae46e38e70eb",  # 第 2656 步 同一局面
    "49b3eee9f19335ed",  # 第 4648 步 同一局面
]

from _lib import carts, pegs, DELTA, rail_free as _free

KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _lone_loaded(g):
    ps = set(pegs(g))
    ld = [c for c in carts(g) if c in ps]
    return ld[0] if len(ld) == 1 else None


def _board_pegs(g):
    return set(pegs(g)) - set(carts(g))


def _inside(g, cell):
    r, c = cell
    return 0 <= r < len(g) and 0 <= c < len(g[0])


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith(KEYS):
        return "NA"
    a = _lone_loaded(prev)
    b = _lone_loaded(nxt)
    if a is None or b is None:
        return "NA"
    ra = _board_pegs(prev)
    if not ra:
        return "NA"
    key = next(k for k in KEYS if action.startswith(k))
    dr, dc = DELTA[key]
    if _free(prev, set(carts(prev)), a, dr, dc) is not True:
        return "NA"
    if (b[0] - a[0], b[1] - a[1]) not in ((0, 0), (dr, dc)):
        return "NA"          # 哪一档都不是，这条不说话
    rb = _board_pegs(nxt)
    for p in ra:                                     # prev 的子该落到哪
        r = (p[0] - a[0] - dr, p[1] - a[1] - dc)
        t = (b[0] + r[0], b[1] + r[1])
        if _inside(nxt, t) and t not in rb:
            return "FALSE"
    for p in rb:                                     # nxt 的子该从哪来
        r = (p[0] - b[0] + dr, p[1] - b[1] + dc)
        t = (a[0] + r[0], a[1] + r[1])
        if _inside(prev, t) and t not in ra:
            return "FALSE"
    return "TRUE"
