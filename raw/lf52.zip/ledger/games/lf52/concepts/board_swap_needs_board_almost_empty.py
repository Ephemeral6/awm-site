"""一次**点击**若换掉了整块盘（盘面孔的网格相位变了），那么点之前盘上最多只剩 2 个子。

换句话说：盘上还有 3 个及以上的子时，任何点击都换不走这块盘——想换盘，先把子吃到只剩两个。
"""
LEVEL = "L5"
SCOPE = (
    "只看 ACTION6 点击。**方向键不在这条的管辖内，而且已知它能改相位**："
    "关 2 有 21 条 ACTION3/ACTION4 把相位在 (0,0)→(0,4)→(0,2)→(0,0) 上循环推，"
    "那是 4 像素的次格平移（同时盘面孔从 24 涨到 31、子从 4 涨到 9，是视口把大盘滚进来），"
    "不是换盘；其中 15 条点之前有 3 个以上的子，若这条概念管方向键，它当场就是假的。"
    "（读数见 runs/lf52-0915-2239/probe_phase_diff2.txt 判据五。）"
    "盘面（孔减去车腔）为空时返回 NA——相位算不出来。相位没变返回 NA：这条只管换盘那一步。"
    "换关不返回 NA：27 条里有 11 条正是换关，它们是这条的主要证据。"
)
NOTE = (
    "第4856 步立的。由来：先前我以为「换盘 = 换关」，"
    "ask_levelup.txt 与 probe_board_phase.txt 一对就被推翻了——"
    "16 条换关点击里只有 11 条改相位，16 条改相位的点击不换关。"
    "于是改问「换盘那一步盘上还剩什么」，27 条点击的 prev 子数是 1 或 2，一条例外都没有。"
    "**这条写的是必要条件，不是充分条件**：剩 2 个子的时候绝大多数点击什么也不换，"
    "所以它只能告诉策略「还有 3 个子就别指望换盘」，不能告诉策略「点哪里」。"
)
EVIDENCE = [
    "864b046089ed7d4c",   # 第2308 步 关3 ACTION6:25,49  子 2→1  不换关
    "6ed9dd90d72a30b4",   # 第2338 步 关4 ACTION6:28,43  子 2→2  换关 3→4
    "55d7935d6311dc38",   # 第2426 步 关4 ACTION6:43,25  子 2→4  不换关（第 4 关唯一一条）
    "e66b508ae9690dd3",   # 第2482 步 关5 ACTION6:22,55  子 2→3  换关 4→5
    "cd67afd72a2d4793",   # 第2938 步 关5 ACTION6:49,43  子 1→1
    "4912f81ba51d0a58",   # 第4476 步 关9 ACTION6:35,37  子 2→2  换关 8→9
    "bbe996586e7277bb",   # 第4772 步 关4 ACTION6:28,43  子 2→2  换关 3→4（本 run 当前这一次进关）
]

from _lib import STRIDE, carts, holes, pegs


def _phase(g):
    """盘面孔（孔减去车腔）落在 STRIDE 网格上的相位集合。"""
    board = set(holes(g)) - set(carts(g))
    if not board:
        return None
    return frozenset((r % STRIDE, c % STRIDE) for (r, c) in board)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    a, b = _phase(prev), _phase(nxt)
    if a is None or b is None:
        return "NA"
    if a == b:
        return "NA"
    return "TRUE" if len(pegs(prev)) <= 2 else "FALSE"
