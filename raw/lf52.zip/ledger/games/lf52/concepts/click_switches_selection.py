"""已经选中一个可跳物时再点另一个有合法跳的可跳物，世界把选中**整个搬过去**：旧的选中框与它的全部落点环一起清掉，新的选中框与新的落点环一起画上；棋子、石子、灰团一个不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点中某个孔、prev 里已经有一个**别的**可跳物被选中、被点的孔里是棋子/石子/灰团、"
         "且它在 prev 里至少有一个合法跳的转移；其余 NA。"
         "点的就是已选中的那一个（click_selected_peg_noop 管）、被点的物件没有合法跳"
         "（click_stuck_peg_deselects 管）、prev 里没有选中（click_selects_peg 管），一律 NA。"
         "孔位集合变了（换关/换盘）返回 NA。")
NOTE = """
由来是一次**自己的沉默**，不是一条反例：第 4654 步策略要换一颗子起跳，
`bet --policy` 打出来「预测 0 格 ← 没有概念开口」，而世界实际动了 57 格。
翻册子才发现这一档在三条点击概念之间漏了：
click_selects_peg 的 scope 明写「它在 prev 里还没被选中」，而它的 apply 第一句就是
`if selected(prev) is not None: return None  # 已有选中，别的概念管`——
那个「别的概念」一直不存在。click_stuck_peg_deselects 只管被点的子**没有**跳的情形，
click_selected_peg_noop 只管点中已选中的那一个。于是「选着 A 去点 B」全册没人说话。

**这不是小事，因为它在预测链上**：策略每次换起跳点都要先点新的子，
这一步不开口，喂给下一步的模型帧里选中框还留在旧位置，
click_ring_jumps 从旧的选中算落点，后面每一格预测都跟着歪（click_selects_peg v5 的 NOTE
把这个病叫「链上最贵的一种沉默」，这是同一个病的第三次发作）。

主张本身是从 click_selects_peg 抄过来的，只多一件事：**旧的那一份要清干净**。
清的形状照 click_stuck_peg_deselects 说的那一套（它只写了 assert_，没有 apply，
所以「清掉长什么样」这件事以前从没被逐格对过答案）。
第 4654 步实测 57 格 = 1 计数条 + 旧的（16 描边 + 4 角 + 8 环）+ 新的（16 描边 + 4 角 + 8 环），
两边各只有一个落点。多落点的情形这条一样敢生成：环按 jumps_from 全画，
画少一个就是 8 格的整数倍的错，settle 逐格对得出来。

代价与可判错性：它断言的是「搬」，所以两头都能打死它——
旧的清不干净（比如环留着）是反例，新的没选上或环画错也是反例。
顺序上先清后画：两个物件的描边有可能重叠（相邻两孔），重叠处该是新的那一份。
"""
EVIDENCE = [
    "fdd3c0359b1d42fb",  # 步4654 第2关：选着 (18,48) 去点 (30,54)，帧差 57 —— 全册零预测的那一步
]

from _lib import (CORNERS, EDGE8, OUTLINE16, C_EMPTY, C_RING, C_SEL, C_STONE, C_GREY, PEG12,
                  click_target, count_in, holes, jumps_from, pegs, rings, selected)


def _is_stone(g, h):
    """h 这个孔里坐着一颗石子吗。只读这一个孔的 16 格，代价是常数（办法与 click_selects_peg 同源）。"""
    return count_in(g, h[0], h[1], C_STONE) >= len(PEG12)


def _is_grey(g, h):
    """h 这个孔里坐着一个灰团吗。"""
    return count_in(g, h[0], h[1], C_GREY) >= len(PEG12)


def _in_scope(prev, action):
    """返回 (被点的孔, 旧选中) —— 不在这一档就返回 (None, None)。

    免责条款按单价排，最贵的 jumps_from（每次 11.3ms，读数见 click_selects_peg 的 NOTE）放最后。
    """
    sel = selected(prev)
    if sel is None:
        return None, None                      # 没有选中：click_selects_peg 管
    tgt = click_target(prev, action)
    if tgt is None or tgt == sel:
        return None, None                      # 点中已选中的那一个：click_selected_peg_noop 管
    if tgt not in pegs(prev) and not _is_stone(prev, tgt) and not _is_grey(prev, tgt):
        return None, None
    if not jumps_from(prev, tgt):
        return None, None                      # 没跳可走：click_stuck_peg_deselects 管
    return tgt, sel


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6:"):
        return "NA"
    tgt, sel = _in_scope(prev, action)
    if tgt is None:
        return "NA"
    if holes(prev) != holes(nxt):
        return "NA"
    ps = pegs(prev)
    stone = tgt not in ps and _is_stone(prev, tgt)
    grey = tgt not in ps and not stone and _is_grey(prev, tgt)
    if selected(nxt) != tgt:
        return "FALSE"                          # 选中没搬过去
    if rings(nxt) != jumps_from(prev, tgt):
        return "FALSE"                          # 环不等于新起跳点的全部落点（旧的环没清干净也在这里现形）
    if pegs(nxt) != ps:
        return "FALSE"                          # 子一颗都不该动
    if stone and not _is_stone(nxt, tgt):
        return "FALSE"
    if grey and not _is_grey(nxt, tgt):
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """先把旧的选中与它的环擦掉（描边 3→0、四角 3→1、环 2→1），再把新的画上（同一套形状）。"""
    if not action.startswith("ACTION6:"):
        return None
    tgt, sel = _in_scope(prev, action)
    if tgt is None:
        return None
    H, W = len(prev), len(prev[0])
    out = {}

    def paint(cell, corner, outline):
        R, C = cell
        for dr, dc in CORNERS:
            out[(R + dr, C + dc)] = corner
        for dr, dc in OUTLINE16:
            r, c = R + dr, C + dc
            if 0 <= r < H and 0 <= c < W:
                out[(r, c)] = outline

    # 1) 擦旧的：四角回空孔色，描边回背景
    paint(sel, C_EMPTY, 0)
    for dst in rings(prev):                     # 旧的落点环回空孔色
        for dr, dc in EDGE8:
            r, c = dst[0] + dr, dst[1] + dc
            if 0 <= r < H and 0 <= c < W:
                out[(r, c)] = C_EMPTY
    # 2) 画新的：重叠处新的说了算，所以它必须排在后面
    paint(tgt, C_SEL, C_SEL)
    for dst in jumps_from(prev, tgt):
        for dr, dc in EDGE8:
            r, c = dst[0] + dr, dst[1] + dc
            if 0 <= r < H and 0 <= c < W:
                out[(r, c)] = C_RING
    # 计数条不预测具体哪格（counter_advance 管）
    return out
