"""过关那一步，prev 的视口里**恰好剩 2 颗子**，而被点中的那个环正好是「其中一颗跨过另一颗」的落点——过关只由把最后两颗子吃成一颗触发。"""
LEVEL = "L5"
SCOPE = ("只看 ctx 里 level_next == level_prev + 1 的转移；同关、RESET 降级（level 变小）、ctx 缺失一律返回 NA。"
         "它只说过关那一步**长什么样**，不说什么时候会过关：视口外还有子的时候，"
         "把视口里的 2 颗吃成 1 颗并不过关。")
NOTE = """
levelup_needs_capture_jump 说的是「过关 ⇒ 是一次跳吃且换盘」，它的 NA 率 100%——
换句话说它对全部 1200 多条转移一句话没说，只在 11 条过关转移上开口，而那 11 条它全判 TRUE。
这条把它欠的那一半补上：**那一跳吃的是谁**。

出处：把 11 条过关转移的 prev 逐条读了一遍（runs/…/probe_boards.py），子数全是 2，一条不差；
而且两颗子在同一行或同一列、相距一个 STRIDE，被点的环落在第三格上。五个不同的盘面、五种不同的几何，
同一个形状。

**这条概念真正的用处是给规划器一个终点判据**，而且它是个**否定式**的判据：
第 3014 步（fbb41448c905ef05）视口里正好 2 颗子、正好做了这一跳、吃成了 1 颗，
`level` 纹丝不动，接着左下角冒出圆盘——那是死局，不是过关。
所以「2 颗吃成 1 颗」是过关的**必要形状**而不是充分条件：视口只是世界的一扇窗，
窗外还有子的时候，这一跳只是把自己走死。规划器不能拿视口里的子数当终局判据，
这一条就是用来提醒它的：把 assert_ 写成「过关 ⇒ 这个形状」，反过来的方向故意不写，
因为它已经被第 3014 步证伪了。

还不知道的：世界总共有多少颗子。`pegs()` 只读视口，而第 5 关的镜头东西向能滚 80 列，
一屏看不全。要把「剩 1 颗就过关」写成能走闸的话，得先有一条概念能说出视口外的子数，
现在没有，所以不写。
"""
EVIDENCE = [
    "f21860f7196c8b1a",  # 步2124 关0->1 子[(30,41),(36,41)] 点 (42,41)
    "c4b7f7adeed9ecf6",  # 步2203 关1->2 子[(51,37),(51,43)] 点 (51,49)
    "6b86f2fbbc519fa9",  # 步2277 关2->3 子[(48,12),(48,18)] 点 (48,24)
    "6ed9dd90d72a30b4",  # 步2338 关3->4 子[(42,15),(42,21)] 点 (42,27)
    "e66b508ae9690dd3",  # 步2482 关4->5 子[(54,27),(54,33)] 点 (54,21)
    "9be171041dc23e3a",  # 步2512 关0->1（换卡后重走同一条路）
    "2920cafbe879b902",  # 步2544 关0->1
    "9c6bcd1799d36584",  # 步2591 关0->1
    "9b5d59b582f7d57e",  # 步2640 关1->2
    "5322f79d1b183980",  # 步2690 关2->3
    "62a2ae2d463a0366",  # 步2744 关3->4
]

from _lib import click_target, pegs, rings, selected


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    if ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if ctx["level_next"] != ctx["level_prev"] + 1:
        return "NA"
    ps = set(pegs(prev))
    if len(ps) != 2:
        return "FALSE"
    src, tgt = selected(prev), click_target(prev, action)
    if src is None or tgt is None:
        return "FALSE"
    if src not in ps or tgt not in rings(prev):
        return "FALSE"
    mid = ((src[0] + tgt[0]) // 2, (src[1] + tgt[1]) // 2)
    return "TRUE" if ps - {src} == {mid} else "FALSE"
