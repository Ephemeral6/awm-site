"""方向键引起的镜头平移只会沿**这个键自己那根轴**滚，方向与键**相反**：
按右键画面往左滚、按下键画面往上滚，另一根轴的平移分量恒为 0；不滚也算数（平移 0 永远合法）。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1 / ACTION2 / ACTION3 / ACTION4 这四个方向键；ACTION6、RESET、"
         "以及方向不固定的 ACTION7（见 NOTE 的 v2）一律返回 NA。"
         "换关（level_prev != level_next）返回 NA——换关整幅重画，谈不上对齐。"
         "候选平移只取行、列各属于 {0, ±6, ±8} 的那 25 个（6 是同盘相邻孔的像素间距，8 是第 2 关实测到的幅度）；"
         "断言的是「这 25 个候选里最齐的那一个落在允许的方向上」，不是「世界只会按这些幅度滚」。"
         "重叠区不足 800 格的候选不参评；最齐的候选并列时返回 NA。")
NOTE = """
前身 camera_never_pans_vertically v1 生于第 2377 步、死于同一次结算：
它断言镜头只横着滚，而第 3 关第 2313、2314 两步按下键时整幅画面刚性**上移** 6 像素。
死因不是守卫写漏，是 claim 本身取错了——我拿第 4 关那几步的横向平移当了全部，
把一个关卡的特例写成了世界的法则。

改法不是缩 scope，是回头把全语料的平移量做成一张表（`runs/…/pans.py`）。
25 条非零平移，一条不落地满足同一件事：轴 = 键的轴，方向 = 键的反方向。
    第 2 关 按右键 dc=-8（5 条）、按左键 dc=+8（5 条）
    第 3 关 按右键 dc=-6（4 条）、按左键 dc=+6（4 条）、按下键 dr=-6（2 条）
    第 4 关 按右键 dc=-6（5 条）
其余 2100 多条方向键转移最齐的平移都是 (0,0)。**幅度按关卡不同（8 和 6），方向从不含糊**，
所以这条只断言方向与轴，不断言幅度——断言幅度的那条概念等我弄清 8 和 6 分别由什么决定再写。

**为什么值得单独立一条**：镜头把「屏幕坐标」和「世界坐标」拆成了两件事，
而我此前所有的路线规划都是在屏幕坐标上做的。平移一旦发生而我没算进去，
帧差会大出一个数量级（第 2362 步实测 807 格对我押的 140 格），
更要命的是下一步的点击坐标会整个错位。这条概念至少把「往哪错」钉死了一半。

还欠着的：镜头到底跟着谁滚、什么时候夹住不滚，仍然没有可核的读法。
第 3 关第 2313 步那次，装着子的滑车屏幕位置纹丝不动、其余全动，像是镜头钉住了载子的车；
可第 2372、2373 步载子车沿竖轨向上爬了两格，镜头一格没跟。
我现在的猜想是「钉住载子车，但夹在世界边界内」，而「世界边界在帧上怎么读」我还答不出来，
所以那句话一个字都不写进断言——写出来就是拿一个我看不见的事实当前提。

v1→v2：死在 137ec6148af07723（第 5 关步 3060 ACTION7，帧差 870）。
ALLOWED 里 ACTION7 抄的是「实测与左键同义」，于是断言镜头该往右滚；实测往左滚。
死因和 cart_slides_one_stride v9 是同一个：**ACTION7 根本不是一个固定方向的键**。
第 3058-3060 步的实验把两种说法分开了：
    ACTION2（下，帧差 126）→ ACTION7（帧差 126，逐格是上一下的逆变换，车往上）
    ACTION3（左，帧差 870）→ ACTION7（帧差 870，逐格是上一下的逆变换，车往右、镜头往左）
同一关里 ACTION7 一次往上、一次往右，「按关卡固定方向」当场出局；
剩下的读法是「**ACTION7 = 上一个方向键的反向**」，它和第 2 关那条老证据（ACTION4 之后 7 往左）、
以及第 2968 步（前一下是 ACTION2 而上键本来就堵着，于是 7 帧差 1）全都对得上。

**但这条读法写不成这个台架上的概念**，这是一处装置边界，值得写明：
`assert_` 只拿得到 (prev, action, nxt)，`ctx` 里只有 step / level_prev / level_next / state_prev / state_next，
**没有上一个动作**；而「上一个方向键是什么」在帧上也没有任何地方画出来（车身没有朝向标记，
我逐格比过 ACTION2 与 ACTION3 之后那两帧，除了物件位置没有别的差异）。
所以 ACTION7 的真正规律在这里只能落在 journal 里，落不进断言。
v2 的做法是把 ACTION7 整个交出去判 NA——闭嘴比留着一个我知道是错的映射强。
"""
EVIDENCE = [
    "d30b9a7e5f664a84",  # 步2313 第3关 ACTION2：整幅上移 6 像素（dr=-6）——打死前身的两条之一
    "dc6510d564664f85",  # 步2314 第3关 ACTION2：同上
    "b5922c919746207a",  # 步2362 第4关 ACTION4 帧差807：整幅左移 6 像素
    "e81a1f91723dd022",  # 步2363 第4关 ACTION4 帧差823：同上
    "81159804c5e0612b",  # 步2368 第4关 ACTION4 帧差695：同上
    "12badc7634cce815",  # 步2376 第4关 ACTION4 帧差836：同上
    "1f31056df7e68efa",  # 步2377 第4关 ACTION4 帧差1011：同上
    "d301630b011fa843",  # 步2372 第4关 ACTION1 帧差124：载子车纵向爬一格，镜头不跟，平移 (0,0)
    "c5a5427e8d4d6cbb",  # 步2371 第4关 ACTION4 帧差1：两辆车都推不动，平移 (0,0)
    "137ec6148af07723",  # 步3060 第5关 ACTION7 帧差870：打掉 v1 的那条——7 不是固定方向键
]

SHIFTS = (-8, -6, 0, 6, 8)
MIN_OVERLAP = 800

# 键 -> 它允许的平移方向（行符号, 列符号）；0 表示这根轴上只许不动
ALLOWED = {
    "ACTION1": (+1, 0),    # 上键：世界往下滚
    "ACTION2": (-1, 0),    # 下键：世界往上滚
    "ACTION3": (0, +1),    # 左键：世界往右滚
    "ACTION4": (0, -1),    # 右键：世界往左滚
}


def _key(action):
    """把动作串归一成键名；整数记号（'1'、'4'）也认。"""
    head = action.split(":", 1)[0]
    if head.isdigit():
        head = "ACTION" + head
    return head


def _mismatch(a, b, dr, dc):
    H, W = len(a), len(a[0])
    bad = tot = 0
    for r in range(1, H):
        rr = r - dr
        if not (1 <= rr < H):
            continue
        arow, brow = a[rr], b[r]
        for c in range(W):
            cc = c - dc
            if not (0 <= cc < W):
                continue
            tot += 1
            if arow[cc] != brow[c]:
                bad += 1
    return bad, tot


def assert_(prev, action, nxt, ctx=None):
    key = _key(action)
    if key not in ALLOWED:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    best = None
    tied = False
    for dr in SHIFTS:
        for dc in SHIFTS:
            bad, tot = _mismatch(prev, nxt, dr, dc)
            if tot < MIN_OVERLAP:
                continue
            rate = bad / tot
            if best is None or rate < best[0] - 1e-12:
                best, tied = (rate, dr, dc), False
            elif abs(rate - best[0]) <= 1e-12 and (dr, dc) != (best[1], best[2]):
                tied = True
    if best is None or tied:
        return "NA"
    _, dr, dc = best
    sr, sc = ALLOWED[key]
    if (dr, dc) == (0, 0):
        return "TRUE"
    if sr == 0 and dr != 0:
        return "FALSE"                      # 横向键滚出了行分量
    if sc == 0 and dc != 0:
        return "FALSE"                      # 纵向键滚出了列分量
    if sr and dr * sr <= 0:
        return "FALSE"                      # 行分量方向不对
    if sc and dc * sc <= 0:
        return "FALSE"                      # 列分量方向不对
    return "TRUE"
