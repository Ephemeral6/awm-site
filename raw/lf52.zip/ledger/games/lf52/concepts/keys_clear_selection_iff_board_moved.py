"""盘上没有石子时：方向键和撤销键一旦真的推动了盘面（选中标记与落点环自己占的那几个方框之外还有任何一格变了），就必定把选中物连同它的环一起清空；什么都没推动的那一下，选中物和环原样留着。"""
LEVEL = "L1"
SCOPE = ("只看不是 ACTION6、不是 RESET 的动作（1/2/3/4/7）；计数条没有正常推进一格（重开、清条、整批截断）时返回 NA；"
         "prev 里没有选中物时返回 NA——没东西可清，这条不表态；"
         "**prev 或 nxt 盘上有石子时返回 NA**——见 NOTE，石子在场那一下不守这条，我不知道为什么，这片地不归这条管。"
         "「推动了盘面」是**扣掉选中标记与环自己占的那几个 6x6 方框之后**量的，"
         "所以它和「选中被清掉」不是同一句话的两种说法：车动了而选中还在，是这条的反例。")
NOTE = """
出处：第 7 关开局，手上选着子按了一下方向键，车走了一格、选中当场没了
（7a522f0760d124cf，帧差 110）；紧接着同样一下、车走同样一格、手上没选中物，帧差 82。
110-82=28，正好是选上去那 29 格减掉计数条那一格——清选中付的是选上去那一笔的退款。

**先查语料才写的这条，查完主张就换了一句。** 我原本要写的是「方向键会清掉选中」：
全语料「按方向键时手上有选中物」只有 21 条，其中 **16 条选中好好活着**，
这句话写出去当场被 16 条打死。真正把两拨分开的是**这一下有没有推动东西**——
「推动了却还选着」全语料 0 条（1804 条去重转移）。

**v2 改动：v1 在自己的 EVIDENCE 上判 FALSE 关了闸，因为 v1 的 NOTE 写错了一句话。**
v1 说「e6c3d38954b30194 是车一辆没动、整幅画面平移了」——**平移是我推的，没量过，是错的**。
按扣掉选中与环之后的帧差实测：那一下**盘面一格都没变**，选中却照样被清。
它是 1804 条里唯一一条「什么都没推动却把选中清掉」的转移，反向那半句就这样被打掉了。
局面：第 5 关，选中子(24,18)、环(12,18)、石子(18,18) 正压在它头顶，两辆车(42,48)(42,54) 头上无轨走不了。
这 21 条里**有石子的就它一条**，所以 v2 把有石子的局面整片划出去判 NA。
**这是按一条反例裁的 scope，不是我看懂了**：疑似与「石子只在没选中子时才被推」同源——
那一下大概是拿这次按键去换「把选中放掉」，好让下一次按键能推石子——但这只是猜测，
要它算数就得单独写一条概念去撞，撞出来之前这片地没人管。

关于判据为什么写成帧差而不是 carts(prev) != carts(nxt)：**在这条概念自己的地盘上，两种写法 21/21 完全一致，
所以这条概念区分不了它们，我不能拿它当证据。** 只在更大的范围上（所有非点击键、不管有没有选中）
两者才在 126/1804 条上分岔——石子走位、画面平移、车走出视口都是帧差看得见而 carts() 看不见的。
帧差是按更宽的那个意思写的，但这条概念没检验过这个选择。
"""
EVIDENCE = [
    "7a522f0760d124cf",  # 步4288 第7关 ACTION3：车(60,18)->(60,12)，选中(24,12)被清，帧差 110
    "e6c3d38954b30194",  # 步2918 第5关 ACTION1：一格没动却清了选中，盘上有石子——v2 判 NA，见 NOTE
    "bc8de0174fad21ee",  # 步2098 第0关：盘上没车，这一下什么都没推动，选中活着
    "04c1bef688530473",  # 步2099 同上
    "a8b8f6e1ae1e83b9",  # 步2100 同上
]

from _lib import selected, rings, stones, SIZE

BOX = SIZE + 2


def _bar(g):
    return tuple(g[0])


def _box_cells(anchors):
    """选中标记与环画在以 (r, c) 为左上角的 4x4 内腔上，外框还多占一圈，按 6x6 扣干净。"""
    out = set()
    for r, c in anchors:
        for dr in range(-1, BOX - 1):
            for dc in range(-1, BOX - 1):
                out.add((r + dr, c + dc))
    return out


def assert_(prev, action, nxt, ctx=None):
    if action.startswith("ACTION6") or action.startswith("RESET"):
        return "NA"
    a, b = _bar(prev), _bar(nxt)
    if sum(1 for x, y in zip(a, b) if x != y) != 1:
        return "NA"          # 重开 / 清条 / 整批截断，不在本条管辖内
    src = selected(prev)
    if src is None:
        return "NA"
    if stones(prev) or stones(nxt):
        return "NA"          # 石子在场那一下不守这条，见 NOTE
    # 量「推动了没有」时把选中与环自己那几块扣掉，否则清选中会把自己算成推动。
    masked = _box_cells({src} | rings(prev) | rings(nxt))
    H, W = len(prev), len(prev[0])
    moved = any(prev[r][c] != nxt[r][c]
                for r in range(1, H) for c in range(W)
                if (r, c) not in masked)
    if moved:
        return "TRUE" if (selected(nxt) is None and not rings(nxt)) else "FALSE"
    return "TRUE" if (selected(nxt) == src and rings(nxt) == rings(prev)) else "FALSE"
