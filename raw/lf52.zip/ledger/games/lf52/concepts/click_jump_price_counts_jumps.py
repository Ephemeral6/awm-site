"""已经有选中物时点它的一个环把它跳过去，这一帧改动的格子数恰好是 45 + 8×(起跳前那颗子的合法跳数 − 1)，被跨过去的若是一颗子再加 12——擦掉的环每个 8 格，多吃掉一颗子多擦 12 格。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6；prev 里没有选中物时返回 NA（那是选中，归 click_select_price_counts_jumps）；"
         "点中的不是 prev 里的一个环时返回 NA（点别处是取消选中或无事发生，另有概念管）；"
         "孔位集合 prev 与 nxt 不同（换盘、换关、镜头滚）返回 NA；"
         "**圆盘的有无/位置在这一帧变了**（disc(prev) != disc(nxt)）返回 NA——那一帧额外画了一个圆盘，"
         "它多花多少格本条不知道，见 NOTE。"
         "环数从 **prev** 用 jumps_from(prev, 选中物) 算，不是去数 nxt 上剩几个环。")
NOTE = """
和 click_select_price_counts_jumps 同一张价目表的另一半，同一支探针 `runs/…/probe_click_price.py` 量的：
**183 条正例、7 条反例**，残差分布 [(0,183), (114,3), (126,2), (150,2)]。

那 7 条不是噪声，它们的 tid 是——
ceb6602cf5bc6190 / 1c605901d2500623 / b8be27f69a5d233d / 38914a5db218341e /
20e6e0a48ab01bca / fbb41448c905ef05 / 18fd43d3deaf46d6
——**一条不多一条不少，正是 disc_only_at_the_killing_move 的 EVIDENCE 全集**：本局圆盘只在「这一跳之后再没有合法跳」
那一刻冒出来，语料里所有的圆盘现身帧都是起跳帧，也都在这 7 条里。所以这不是价目表错了，是那一帧比别的帧
多画了一个圆盘。scope 把它们排掉之后是 183 对 0 错。

**排掉不等于解释掉，这里留一个明摆着的窟窿**：我原以为圆盘固定值 ±122 格（那是从别处量的），
可这 7 条的残差是 114、126、150 三个不同的值，122 一个也对不上。圆盘的画价还没有任何概念管，
残差里那三根小柱子就是账。等写「圆盘画价」那条概念时，从这 7 条起手。

吃子加 12 的口径：被跨的那一格在 prev 里是一颗**子**才加（石子和踏板被跨过去什么也不掉，
见 jump_over_step_captures_nothing）；起跳的若是石子，跨什么都不加。
语料里 9beb444a0eee5e57 一类 1 环吃子跳全是 57 = 45+8×0+12，和不吃子的 45 只差这 12 格。

没写 apply：只知道变几格，不知道哪几格，生成不出像素。
"""
EVIDENCE = [
    "beb95bc162de8524",  # 步4132 石子从盘上跳进车腔，1 环，不吃，45
    "0d5f8595ed030f60",  # 步4121 子跳进车腔，1 环，不吃，45
    "9beb444a0eee5e57",  # 步2116 子跨子，1 环，吃，57 = 45+12
    "2e1ceef4dce96bee",  # 步2120 同上，57
    "d5bce195f2626121",  # 步2122 竖着跨、吃，1 环，57
    "94787c4e206a6862",  # 步2126 另一行，吃，1 环，57
    "ceb6602cf5bc6190",  # 步2130 圆盘现身那一跳：本条判 NA，残差 126 记在 NOTE 的窟窿里
    "20e6e0a48ab01bca",  # 步2951 同类，2 环，残差 114——三个残差互不相同，正是还没解释的地方
]

from _lib import click_target, holes, pegs, rings, selected, jumps_from, disc


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6:"):
        return "NA"
    if holes(prev) != holes(nxt):
        return "NA"                       # 换盘、换关、镜头滚：整屏重画，不归这条
    if disc(prev) != disc(nxt):
        return "NA"                       # 这一帧多画/擦了一个圆盘，它的价钱本条不知道
    src = selected(prev)
    if src is None:
        return "NA"                       # 没有选中物：那是选中
    tgt = click_target(prev, action)
    if tgt is None or tgt not in rings(prev):
        return "NA"                       # 点的不是环
    k = len(jumps_from(prev, src))
    if k == 0:
        return "NA"                       # 一个环都没有却点出了环，读法自相矛盾，不硬判
    over = ((src[0] + tgt[0]) // 2, (src[1] + tgt[1]) // 2)
    cap = 12 if (src in pegs(prev) and over in pegs(prev)) else 0
    d = sum(1 for r in range(len(prev)) for c in range(len(prev[0]))
            if prev[r][c] != nxt[r][c])
    return "TRUE" if d == 45 + 8 * (k - 1) + cap else "FALSE"
