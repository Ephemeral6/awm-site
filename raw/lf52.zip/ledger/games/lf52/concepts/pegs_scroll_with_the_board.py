"""盘上的子跟着盘一起滚：方向键把盘整体平移一个 STRIDE 时，视口里的子也整体平移同一个量——滚出视口的从画面上消失，视口外的从边缘滚进来。

所以「视口里只剩一颗子」是**镜头**的事实，不是**盘**的事实：盘比视口大，看不见的地方还有子。
"""
LEVEL = "L7"
SCOPE = (
    "只看 ACTION1/2/3/4。位移 d 不是拿子解的，是拿**盘面孔**（孔减去车腔）解的——"
    "两种读法互相核对才算检验，拿子解 d 再核对子等于自己证自己。"
    "候选 d 只取 {(0,0),(0,±STRIDE),(±STRIDE,0)}；孔筛不出唯一的 d 返回 NA（实测 16 条，全是解不出，没有不唯一的）。"
    "**相位变了返回 NA，而且这不是给它开后门**：关 2 有 21 条 ACTION3/ACTION4 把盘面孔的相位在 "
    "(0,0)→(0,4)→(0,2)→(0,0) 上循环推，那是 4 像素的次格平移，幅度根本不是 STRIDE，"
    "候选集合里没有它，硬算下去它会判 FALSE。这条概念只管整格平移那一类，次格平移该由另一条概念去说，"
    "现在还没有人写。（读数见 runs/lf52-0915-2239/probe_peg_window.txt 判据五、"
    "probe_phase_diff2.txt 判据五。）"
    "盘面为空、相位算不出来时返回 NA。"
)
NOTE = """第4872 步立的。由来是一次**误读被语料打脸**：

第4857 步我看见「视口里只剩 1 颗子、它在车腔里、一个环都没有」，写下了「这块盘被吃死了」，
还据此用掉了一次 act RESET。probe_level4_path.txt 证明那是错的——走通的那条路
（第2338 步进关 → 第2482 步出关）在**第2356 步就是同一个局面**：子 1、装载 [(24,30)]、环 0。
它没死。第2363 步往东开了一格，右边缘滚进来一颗子 (24,60)，跳法跟着回来了。
本 run 其实也做到过：第4798 步滚进来，第4801 步往回开又滚没了。
原话留在上一条 note 里，不删。

这条概念要说的就是那一下：**pegs() 读的是一扇窗，不是整块盘**。
册子里此前没有任何一条说过这件事——pan_opposes_key_axis 只说镜头往哪滚，
pan_is_one_stride_rigid 只管第 7 关的像素怎么搬，levelup_is_two_peg_capture 的 NOTE
把「世界总共有多少颗子」明写成「还不知道」。

先量后写（`runs/lf52-0915-2239/probe_peg_window.py`，跑的就是下面这段 assert_，一个字不差）：
全去重语料 2268 条，**TRUE 1246、FALSE 0、NA 1022**，NA 里 985 条是非方向键、21 条是关 2 的次格平移、
16 条是孔筛不出唯一位移。中途死掉的两个猜测也留着：
  - 「新冒出来的子一定贴视口边缘」——probe_offscreen_pegs.txt 判据二当场证伪，162 颗里 112 颗离边超过一个 STRIDE。
  - 「装着子的车才会把子滚进来」——probe_loaded_pan.txt 判据五证伪，没装子的 300 条对照同样整体平移。

**它管不到的事**：它不说盘上一共有几颗子，也不说往哪个方向开能遇到子。
规划器只能从它拿到一句话：视口里没跳法不等于这一关走不动了，把镜头挪开再看。
"""
EVIDENCE = [
    "e81a1f91723dd022",   # 第2363 步 关4 ACTION4 子 1→2 右边缘滚进 (24,60)——走通那条路的救命一步
    "017a30df386173bd",   # 第2389 步 关4 ACTION3 子 2→1 往回开，同一颗又滚出去
    "93b536ab161a2082",   # 第2415 步 关4 ACTION4 子 1→2 再滚进来一次
    "f2f82b9b36d34ec9",   # 第4798 步 关4 ACTION4 子 1→2 本 run 也滚进来过
    "789406dad51c5962",   # 第4801 步 关4 ACTION3 子 2→1 本 run 又把它开没了
]

from _lib import STRIDE, carts, holes, pegs

KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")
DS = [(0, 0), (0, -STRIDE), (0, STRIDE), (-STRIDE, 0), (STRIDE, 0)]


def _inside(g, cell):
    r, c = cell
    return 0 <= r < len(g) and 0 <= c < len(g[0])


def _board_holes(g):
    return set(holes(g)) - set(carts(g))


def _board_pegs(g):
    return set(pegs(g)) - set(carts(g))


def _phase(g):
    board = _board_holes(g)
    if not board:
        return None
    return frozenset((r % STRIDE, c % STRIDE) for (r, c) in board)


def _fits(prev, nxt, a, b, d):
    """a 在 prev 里、b 在 nxt 里：整体平移 d，落到视口外的允许消失。"""
    for (r, c) in a:
        t = (r + d[0], c + d[1])
        if _inside(nxt, t) and t not in b:
            return False
    for (r, c) in b:
        t = (r - d[0], c - d[1])
        if _inside(prev, t) and t not in a:
            return False
    return True


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith(KEYS):
        return "NA"
    pa, pb = _phase(prev), _phase(nxt)
    if pa is None or pb is None:
        return "NA"
    if pa != pb:
        return "NA"
    ok = [d for d in DS if _fits(prev, nxt, _board_holes(prev), _board_holes(nxt), d)]
    if len(ok) != 1:
        return "NA"
    d = ok[0]
    return "TRUE" if _fits(prev, nxt, _board_pegs(prev), _board_pegs(nxt), d) else "FALSE"
