"""ACTION7 是撤销键：它要么让行1 以下一格不动，要么把盘面退回一步——整幅横向平移、若干辆车沿同一方向各退一格、或一颗子/石子沿直线退 12 格（吃过的子回到中点）；它自己从不产生新的局面。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7；换关、RESET 返回 NA；计数条没有正常推进一格返回 NA。"
         "「退回一步」按三种形状判，命中任一即 TRUE："
         "(a) 存在非零列位移 dc 使行1 以下整体平移后失配率低于 5%%，且比 dc=0 更齐——镜头跟着被撤的那一步平回去；"
         "(b) 车不变数，存在方向 (±6,0)/(0,±6) 与一组车，把这组各挪一格后与 nxt 的车集合相等（车队里前车让位给后车，集合差算不出来，所以枚举子集）；"
         "(c) 车不动，恰好一枚子或石子沿行或列挪了 12 格，石子数不变，子数不变或恰多一颗且多出来的那颗在中点；"
         "圆盘在这一步出现或消失时，(c) 只在两帧共有的孔上比子——圆盘盖住的孔另一边读不到，读不到的孔说不了动没动。"
         "三种都不是就判 FALSE。")
NOTE = """
出处：全语料 60 条 ACTION7（第0关50、第1关2、第2关1、第5关7）。第5关的 7 条：
步2913、2968 帧差 1（没东西可撤）；3056 帧差126；3060 帧差870；3158 帧差477；3595 帧差861；3596 帧差107。
后三条各和它们**前一步**的帧差一模一样、方向相反（3055 ACTION2 / 3059 ACTION3 / 3157 ACTION4），这是「撤销」的由来。

写之前先押了两下（步3595、3596）：第一下押「撤销上一步 ACTION4」兑现（861 格，C 车 88 回 82，镜头 60 回 54）；
第二下我押「撤销栈只有一层，帧差 1」——**落空**，107 格，石车从 (30,88) 退回 (36,88)，
正是再上一步 ACTION1 的逆。所以撤销栈至少两层。

v1 写完先自己在全语料上跑了一遍（runs/…/probe_undo.py），60 条里 58 条 TRUE、2 条 FALSE，两条都是我写错了断言不是世界变了：
- 步3056（第5关）：空车 (36,28) 与载子车 (42,28) 一起上移一格，成 (30,28)/(36,28)。
  v1 用集合差找位移，(36,28) 在前后两个集合里都在，差集算出 {(42,28)}→{(30,28)}，看着像一辆车跳了 12 格。
  **车队让位**这件事集合差看不见，改成枚举「哪几辆动了」。
- 步2237（第2关）：帧差 1773，整幅横向平移 **dc=+8**（失配 121/3528），不是 ±6。子从 7 枚变 5 枚是两枚滚出视口，不是被吃。
  v1 只试了 ±6 就判 FALSE。平移量不等于格距，说明镜头的步长和棋盘格距是两码事——这一条比断言本身值钱。
  为了不让「任意 dc 的平移」把普通一步车动（帧差百来格、占全帧 3%）也蒙混成 TRUE，加了一条：平移后的失配必须**比不平移还少**。

**这条概念只断言形状，不断言历史**：assert_ 只看得见 (prev, action, nxt)，验不了「退回的正是前一步」，
所以它管的是「ACTION7 之后的盘面与 prev 只差一步合法动作的逆」。哪天 ACTION7 让盘面跳出这三种形状，它当场死。
它值多少：撤销让吃子也能试错——这一关的东半边是不是死路，可以走进去看了再退出来。

**v1→v2（第 4653 步）：第一次真的挨打，死因不在断言，在读帧。**
第 2 关走死了（左下角冒圆盘），我按这条概念撤了一步。撤销本身干得漂亮，正是形状 (c)：
子 (18,60) 沿行退 12 格回到 (18,48)，被吃的那颗回到中点 (18,54)。v1 却判 FALSE，
因为 `pegs()` 在 prev 里数出 6 颗、在 nxt 里数出 8 颗：多出来的第三颗是 **(48,0)**。
那颗子一直在那儿——prev 的圆盘（心在 (55,6)）把它连同它的孔一起盖住了，
`holes()` 在 prev 里只认出 32 个孔，nxt 里 33 个，差的正好是 (48,0)。
v1 的 `_piece_stepped_back` 要求「恰好多一颗且在中点」，凭空冒出来的第三颗直接判死。

**这是同一个机制第二次打人**：board_replaced_iff_last_peg v10→v11 死于同一件事
（圆盘画上来盖掉孔 (48,0)，孔位集合 33→32，被读成「换盘」）。凡是把两帧的像素派生集合
做差的概念，都会在圆盘来去的那一步读到并不存在的位移。

改法与那条一致——**不去描圆盘的形状，而是承认读不到**：圆盘在这一步出现或消失时，
(c) 只在 `holes(prev) & holes(nxt)` 上比子。没描形状是故意的：那个 52 格的色15 大环
只量过一次，换一种画法的圆盘会把描好的矩形整个作废，而「一边读不到的孔不比」对任何形状都成立。

**代价量过了**（`runs/…/probe_undo_holes.py`，全语料 201 条 ACTION7）：
孔位集合在 ACTION7 前后不一致的只有 10 条，而其中**圆盘来去的只有第 4653 步这一条**——
其余 9 条圆盘前后都是 None，走的全是形状 (a) 镜头平移或 (b) 车队让位，
一条都进不到 (c) 的这段新代码。所以这次改动**只碰这一条转移**，200 条 TRUE 一条不动。
守卫窄成这样是有意的：`disc` 一有一无是可判的事实，不是「反正读数不好看就放过」。
它照样能被打死：哪天圆盘来去的那一步撤销出了三种形状之外的结果，它当场是反例。
"""
EVIDENCE = [
    "4d6cbb7caacb7960",  # 步2913 第5关 帧差1：没东西可撤
    "86571256483a0b30",  # 步2166 第2关 帧差122：一辆车退一格
    "8e2c4452a69dfe1f",  # 步2237 第2关 帧差1773：整幅平移 dc=+8——v1 的反例（只试 ±6）
    "540dc7b732a6eb9d",  # 步3056 第5关 帧差126：两辆车队列上移——v1 的反例（集合差看不见让位）
    "137ec6148af07723",  # 步3060 第5关 帧差870：整幅平移 dc=-6
    "5f729a926ddc5ade",  # 步3595 第5关 帧差861：撤销 ACTION4，C 车 88 回 82
    "d552e6063f0d74d0",  # 步3596 第5关 帧差107：再撤一步，石车 (30,88) 退回 (36,88)——撤销栈多层
    "96197d46644e7227",  # 步4653 第2关 帧差241：撤掉走死那一跳——v1 的反例（圆盘盖住孔 (48,0)，子读少一颗）
]

from itertools import combinations

from _lib import STRIDE, carts, disc, holes, pegs, stones

_DIRS = ((STRIDE, 0), (-STRIDE, 0), (0, STRIDE), (0, -STRIDE))
_MAX_PAN = 4 * STRIDE


def _mismatch(a, b, dc):
    """把 a 横移 dc 列后与 b 比，只看行1 以下，返回 (失配数, 重叠数)。"""
    bad = tot = 0
    W = len(a[0])
    for r in range(1, len(a)):
        arow, brow = a[r], b[r]
        for c in range(W):
            src = c - dc
            if 0 <= src < W:
                tot += 1
                if arow[src] != brow[c]:
                    bad += 1
    return bad, tot


def _is_pan(prev, nxt):
    base, tot = _mismatch(prev, nxt, 0)
    if not tot:
        return False
    for dc in range(-_MAX_PAN, _MAX_PAN + 1):
        if dc == 0:
            continue
        bad, t = _mismatch(prev, nxt, dc)
        if t and bad < 0.05 * t and bad < base:
            return True
    return False


def _carts_stepped(prev, nxt):
    a, b = carts(prev), carts(nxt)
    if len(a) != len(b) or a == b or len(a) > 8:
        return False
    if len(pegs(prev)) != len(pegs(nxt)) or len(stones(prev)) != len(stones(nxt)):
        return False
    lst = sorted(a)
    for d in _DIRS:
        for k in range(1, len(lst) + 1):
            for moved in combinations(lst, k):
                mv = set(moved)
                if {(r + d[0], c + d[1]) for (r, c) in mv} | (a - mv) == b:
                    return True
    return False


def _jump_apart(p, q):
    dr, dc = q[0] - p[0], q[1] - p[1]
    return (dr == 0 and abs(dc) == 2 * STRIDE) or (dc == 0 and abs(dr) == 2 * STRIDE)


def _piece_stepped_back(prev, nxt):
    if carts(prev) != carts(nxt):
        return False
    sp, sn = stones(prev), stones(nxt)
    pp, pn = pegs(prev), pegs(nxt)
    if (disc(prev) is None) != (disc(nxt) is None):
        # 圆盘这一步来了或走了：它画在盘面上，盖住压在它下面的孔，那些孔上的子在一边读得到、另一边读不到。
        # 只在两帧都读得到的孔上比子——读不到的孔说不了「动没动」。只在圆盘来去的那一步这么做（v2）。
        common = frozenset(holes(prev)) & frozenset(holes(nxt))
        pp, pn = pp & common, pn & common
    if len(sp) != len(sn):
        return False
    if sp != sn:                       # 石子挪了：子必须原样
        if pp != pn or len(sp - sn) != 1 or len(sn - sp) != 1:
            return False
        (p,), (q,) = tuple(sp - sn), tuple(sn - sp)
        return _jump_apart(p, q)
    gone, came = pp - pn, pn - pp
    if len(gone) != 1 or len(came) not in (1, 2):
        return False
    p = next(iter(gone))
    for q in came:
        if _jump_apart(p, q):
            mid = ((p[0] + q[0]) // 2, (p[1] + q[1]) // 2)
            rest = came - {q}
            if not rest or rest == {mid}:
                return True
    return False


def assert_(prev, action, nxt, ctx=None):
    if action != "ACTION7":
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if sum(1 for x, y in zip(prev[0], nxt[0]) if x != y) != 1:
        return "NA"
    if prev[1:] == nxt[1:]:
        return "TRUE"
    if _is_pan(prev, nxt):
        return "TRUE"
    if _carts_stepped(prev, nxt):
        return "TRUE"
    if _piece_stepped_back(prev, nxt):
        return "TRUE"
    return "FALSE"
