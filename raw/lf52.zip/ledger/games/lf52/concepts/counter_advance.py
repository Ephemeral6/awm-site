"""行0作为计数器/答题条，每次动作（非RESET）点亮或改色下一格。"""
LEVEL = "L4"
SCOPE = "只看非RESET动作；列号按(列,行)格式读帧差（上游输出列在前）"
NOTE = "第1-64步：行0列0-63顺序从色0变色1（计数器填充）；第65步动作2让列0变色2（改色）"
EVIDENCE = ["80584e29a350fd1c"]  # 第1步：动作1 → (0,0) 0→1

def assert_(prev, action, nxt, ctx=None):
    """检查：非RESET动作改变行0的某一格（点亮或改色），RESET清空整条。"""
    if action == "RESET":
        # RESET应清空行0的所有非0格
        return "NA"

    # 非RESET动作：行0应该有恰好1格变化（或整帧不动）
    if prev == nxt:
        return "TRUE"

    # 读帧差（注意上游格式是(列,行)）
    changes = []
    for c in range(64):
        if prev[0][c] != nxt[0][c]:
            changes.append((c, prev[0][c], nxt[0][c]))

    # 行0恰好1格变化
    if len(changes) == 1:
        return "TRUE"

    # 行0多格变化或别的行变化 → 概念不管的情况
    return "NA"
