"""lf52 的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测出来的世界：这是一局**孔明棋（peg solitaire）**。

帧里散布着若干 4x4 像素的「孔」，相邻孔的像素间距是 6（4 格孔 + 2 格缝）。
一关可以有好几块盘，块与块之间用色5 的管道连着。

**盘边不挡跳**（推翻了本文件早先写的「块内的孔才谈得上相邻」）：实测第 4 关第 2425/2426 步，
起跳孔与落点分属两块各有色5 外框的盘、中间隔着两层框，世界照样画出了落点环并执行了这一跳。
所以相邻只由格点坐标决定：坐标差恰好 (±6, 0) 或 (0, ±6) 就是相邻，跟它们画在哪块盘的框里无关。

孔里的颜色读法（假设，全部可被帧推翻）：
    含色14  -> 这个孔里有棋子
    含色2   -> 这个孔是当前选中棋子的一个合法落点（画成 8 格环）
    含色3   -> 这个孔里的棋子处于选中态（四角变色3，孔外还会描一圈色3）
    只有色1 -> 空孔

行0 是一条 64 格的计数条，每个动作推进一格，与盘面无关。

**视口不是世界**：64x64 只是一扇窗。方向键会把整幅画面刚性横移 8 像素（注意不是 STRIDE=6），
窗外还有盘。所以这里所有的坐标都是**当前这一帧里的像素坐标**，跨帧不稳定——
比较两帧的孔位之前，先想清楚中间有没有平移。

**孔一律用它左上角的像素坐标 (R, C) 称呼**，不用关卡相关的行列号——每关盘面形状都不一样，
像素坐标是唯一跨关稳定的说法。相邻 = 坐标差恰好 (±6, 0) 或 (0, ±6)。
"""
from __future__ import annotations

SIZE = 4               # 一个孔的像素边长
STRIDE = 6             # 同一块盘内相邻孔的像素间距

C_EMPTY = 1            # 空孔底色
C_RING = 2             # 落点提示环
C_SEL = 3              # 选中标记
C_PEG = 14             # 棋子

C_CART_EDGE = 11       # 管道上那个方盒子的外框（6x6 空心方框）
C_CART_FILL = 12       # 方盒子的内腔（4x4，和孔同尺寸，且落在同一套格点上）

C_STEP_EDGE = 15       # 「踏板」的外框（4x4 空心方框，和孔同尺寸）
C_STEP_FILL = 7        # 踏板腔里那几格

C_STONE = 8            # 「石子」：12 格实心，画得和棋子一模一样，只是颜色不同

C_GREY = 9             # 「灰团」：也是 12 格实心，第 7 关才出现。**这个颜色同时是阴影色**

HOLE_COLORS = frozenset((C_EMPTY, C_RING, C_PEG, C_CART_FILL, C_STONE, C_GREY))
# 色8 收进孔色是第 3125 步之后加的：石子和子共用格点，石子坐着的孔以前扫不出来，
# 于是石子一动 holes() 就变、被选中的石子 selected() 也读不到。全语料 949 帧量过：
# 收进来后 holes 变化的 155 帧里，多出来的孔恰好都等于 stones()，一帧不差。
#
# 色9 收进来是第 4310 步之后加的，病和石子那次一模一样：第 7 关列30 上那两个灰团
# 扫不出孔，于是 jumps_from 算不出跨它们的跳。世界在第 4310 步给那颗子画了 **2** 个环，
# 册子只算得出 1 条跳，click_select_price_counts_jumps 与 click_selects_peg 双双判 FALSE 关闸。
# 色9 同时是墙脚阴影的颜色，所以放宽它有假阳性的风险，量过才敢动
# （runs/*/holes_cost.py，全语料 8620 帧逐帧对拍）：
#   少认出来的孔 **0 个**——阴影连成片，过不了「四周一圈都不是孔色」那道边界判据；
#   多认出来的孔只有 51 帧里的 5 个坐标，全在第 7 关列30，正是那两个灰团爬梯子走过的格点；
#   第 0..6 关**一格没动**。
DIRS = ((-STRIDE, 0), (STRIDE, 0), (0, -STRIDE), (0, STRIDE))

# 一个孔那 4x4 里三组格子的偏移。实测帧差拆出来的（见 apply 的概念）：
#   选中一颗子 = 四角 1→3 加孔外描边 16 格 0→3，一个环 = EDGE8 8 格 1→2，
#   一颗子 = EDGE8 + INNER4 共 12 格色14，四角留底色。29 = 4 + 16 + 8 + 1 格计数条。
CORNERS = ((0, 0), (0, SIZE - 1), (SIZE - 1, 0), (SIZE - 1, SIZE - 1))
EDGE8 = tuple((dr, dc) for dr in range(SIZE) for dc in range(SIZE)
              if (dr in (0, SIZE - 1)) != (dc in (0, SIZE - 1)))
INNER4 = tuple((dr, dc) for dr in range(1, SIZE - 1) for dc in range(1, SIZE - 1))
PEG12 = EDGE8 + INNER4
OUTLINE16 = (tuple((-1, dc) for dc in range(SIZE))
             + tuple((SIZE, dc) for dc in range(SIZE))
             + tuple((dr, -1) for dr in range(SIZE))
             + tuple((dr, SIZE) for dr in range(SIZE)))

# 车框上允许看见的颜色：色11 是框本身，色3 是车里的子被选中时改画的，
# 色15/色7 是车载着的踏板压过来的。见 carts() 的 docstring。
_CART_EDGE_OCCLUDERS = frozenset((C_CART_EDGE, C_SEL, C_STEP_EDGE, C_STEP_FILL))


def _blocks(g, colors):
    """扫出所有「4x4 对齐块」：块内 16 格颜色都落在 colors 里，且四周一圈都不在 colors 里。

    孔之间隔着 2 格色0，所以这个判据不会把两个孔并成一个。

    **第 4952 步改过一次，只动速度**：原先对 3721 个位置各拼一次 16 格的 `all(...)` 生成器，
    cProfile 里 748 次调用占 17.6s（`runs/…/probe_concept_cost.txt`）。
    现在先按行算一张「从这一格往右连续几格是 colors」的游程表（一趟 H*W），
    再要求连着四行的游程都 ≥ 4——两者是同一个条件，只是不再为每个位置重建生成器。
    边界那一圈的检查一字未动。对拍见 `runs/…/probe_lib_speed.txt`。
    """
    n = len(g)
    out = []
    run = []
    for r in range(n):
        row = g[r]
        w = len(row)
        rr = [0] * (w + 1)
        k = 0
        for c in range(w - 1, -1, -1):
            k = k + 1 if row[c] in colors else 0
            rr[c] = k
        run.append(rr)
    for r in range(n - SIZE + 1):
        for c in range(len(g[r]) - SIZE + 1):
            if not (run[r][c] >= SIZE and run[r + 1][c] >= SIZE
                    and run[r + 2][c] >= SIZE and run[r + 3][c] >= SIZE):
                continue
            ok = True
            for dr in range(-1, SIZE + 1):
                for dc in range(-1, SIZE + 1):
                    if 0 <= dr < SIZE and 0 <= dc < SIZE:
                        continue
                    rr, cc = r + dr, c + dc
                    if 0 <= rr < n and 0 <= cc < len(g[rr]) and g[rr][cc] in colors:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                out.append((r, c))
    return out


_HOLE_OR_SEL = HOLE_COLORS | {C_SEL}       # 只为省掉每次调用现算一次并集，内容一字不差


def _is_hole_block(g, R, C):
    """(R, C) 起的 4x4 块，16 格颜色是否都落在孔色（含选中色3）里。"""
    if R < 0 or C < 0 or R + SIZE > len(g) or C + SIZE > len(g[0]):
        return False
    return all(g[R + dr][C + dc] in _HOLE_OR_SEL
               for dr in range(SIZE) for dc in range(SIZE))


def _sel_outline_ok(g, R, C):
    """(R, C) 块外那一圈色3 描边齐不齐——「这个孔被选中了」的独立签名。

    描边是 16 格：上下各 SIZE 格、左右各 SIZE 格，四个斜角不描（实测就是这个形状，
    帧差 29 = 20 格选中标记（16 描边 + 4 个孔角）+ 8 格一个环 + 1 格计数条，一格不多）。
    出界的格子不参与，但看得见的至少要有 8 格，免得在视口角上认花眼。
    """
    H, W = len(g), len(g[0])
    seen = 0
    for d in range(SIZE):
        for rr, cc in ((R - 1, C + d), (R + SIZE, C + d),
                       (R + d, C - 1), (R + d, C + SIZE)):
            if 0 <= rr < H and 0 <= cc < W:
                if g[rr][cc] != C_SEL:
                    return False
                seen += 1
    return seen >= 8


def holes(g):
    """盘上所有孔，用左上角像素坐标 (R, C) 表示。

    选中态的孔四角是色3，孔外还描一圈色3——那圈色3 会破坏「四周一圈都不是孔色」
    这条边界判据，于是选中的孔严格扫扫不出来。所以三步走：
    先用 {1,2,14} 严格扫出干净的孔；
    再把「块内 16 格都是孔色或色3、且块外色3 描边齐全」的块也收作种子；
    最后沿 ±STRIDE 的格点向外闭包，把颜色合法但边界被色3 破坏的孔补回来。

    第二步是后加的，因为只靠闭包会漏掉**四面无邻居的选中孔**：第 4 关第 2479 步，
    一颗子停在一个孤零零的孔里（上边是载着踏板的车腔、下边是踏板、左右什么都没有，
    这几样都不是孔），一选中它，这个孔连同里头的子一起从读数里消失，
    害得一条根本不谈选中的概念（board_replaced_iff_last_peg）连判两条 FALSE。
    代价已量：全部 5058 帧里 5054 帧逐帧相同，只有出问题的那 2 条转移的 4 帧各多认出 1 个孔。

    **这个函数是全册最贵的一步**（cProfile：一次搜索 92.9s 里它占 48.8s，4844 次调用，
    其中 1805 万次落在 `_is_hole_block` 上）。第 4528 步之后底下换了两处，两处都只动速度：
      · 记了张按帧的备忘录（帧不可 hash 就折成元组当键），同一帧第二次问不再重扫；
      · 第二步那趟 3600 格的全盘扫，改成只扫**色3 描边可能落在哪儿**推出来的候选位置——
        `_sel_outline_ok` 要求看得见的描边格里至少 8 格是色3，所以它认下的块必定有一格色3 落在自己的描边上，
        反过来由每一格色3 推出 16 个候选位置就一个不漏。帧上没有色3 时候选为空，整趟扫不跑。
    **读数一格不许变**：`runs/…/probe_holes_cmp.py` 拿 `history/_lib.v21.py`（改之前那一本）
    在去重语料全部 4084 帧上三路对拍（老本子 / 新本子喂元组 / 新本子喂列表），**一帧不差**。
    """
    try:
        return _holes_cached(g)
    except TypeError:                                # 帧里有不可 hash 的东西：照旧现算
        return _holes_raw(g)


_HOLES_MEMO = {}
_HOLES_MEMO_CAP = 2048                   # 一帧折成元组约 36KB，封顶是为了别把内存吃光


def _holes_cached(g):
    key = g if isinstance(g, tuple) else tuple(map(tuple, g))
    hit = _HOLES_MEMO.get(key)
    if hit is None:
        if len(_HOLES_MEMO) >= _HOLES_MEMO_CAP:
            _HOLES_MEMO.clear()
        hit = _HOLES_MEMO[key] = _holes_raw(g)
    return hit


def _sel_candidates(g):
    """所有可能通过 `_sel_outline_ok` 的块左上角：由每一格色3 反推它能当谁的描边。"""
    H, W = len(g), len(g[0])
    out = set()
    for pr in range(H):
        row = g[pr]
        for pc in range(W):
            if row[pc] != C_SEL:
                continue
            for d in range(SIZE):
                out.add((pr + 1, pc - d))        # 色3 落在上边 (R-1, C+d)
                out.add((pr - SIZE, pc - d))     # 落在下边 (R+SIZE, C+d)
                out.add((pr - d, pc + 1))        # 落在左边 (R+d, C-1)
                out.add((pr - d, pc - SIZE))     # 落在右边 (R+d, C+SIZE)
    return [(R, C) for (R, C) in out
            if 0 <= R <= H - SIZE and 0 <= C <= W - SIZE]


def _holes_raw(g):
    found = set(_blocks(g, HOLE_COLORS))
    for R, C in _sel_candidates(g):
        # 两条都是纯判据，先考便宜的那条（描边一格不对就早退）；先后不改结果
        if (R, C) not in found and _sel_outline_ok(g, R, C) and _is_hole_block(g, R, C):
            found.add((R, C))
    frontier = list(found)
    while frontier:
        R, C = frontier.pop()
        for dr, dc in DIRS:
            nb = (R + dr, C + dc)
            if nb in found or not _is_hole_block(g, *nb):
                continue
            found.add(nb)
            frontier.append(nb)
    return frozenset(found)


def colors_in(g, R, C):
    """孔 (R, C) 那 4x4 像素里出现过的颜色集合。"""
    return {g[R + dr][C + dc] for dr in range(SIZE) for dc in range(SIZE)}


def count_in(g, R, C, color):
    """孔 (R, C) 那 4x4 像素里有几格是这个颜色。"""
    return sum(1 for dr in range(SIZE) for dc in range(SIZE)
               if g[R + dr][C + dc] == color)


def pegs(g, hs=None):
    """盘上所有有棋子的孔。

    `hs` 是已经算好的 holes(g)，只为省一次全盘扫描；不给就自己算，行为一字不差。

    棋子画成 12 格实心（四角留底色），环画成 8 格空心。两者都可能用色2：
    实测第 2 关走到无路可走时，剩下的子整体由色14 变成色2，孔里仍是 12 格实心——
    所以「是不是子」按格数认，不按颜色认。色2 的子是什么意思还不知道，
    这里只断言它仍然占着这个孔。
    """
    return frozenset(h for h in (holes(g) if hs is None else hs)
                     if count_in(g, *h, C_PEG) >= 12 or count_in(g, *h, C_RING) >= 12)


def rings(g):
    """盘上所有画着落点环的孔：色2 恰好 8 格的空心环。"""
    return frozenset(h for h in holes(g) if count_in(g, *h, C_RING) == 8)


def selected(g):
    """处于选中态的那个孔；没有或不唯一就返回 None。"""
    hit = [h for h in holes(g) if C_SEL in colors_in(g, *h)]
    return hit[0] if len(hit) == 1 else None


def steps(g):
    """盘上所有「踏板」占的**格点**坐标 (R, C)。

    第 4 关出现的新物件：一个 4x4 空心方框，框是色15，腔里三格色7、一格色0，
    脚下垫一条 4 格宽的色5。它画在格点**上方 1 像素**处——框在行 r..r+3，
    它占的格点是 (r+1, C)。这条「上移 1 像素」是假设，错了跳法就算错，概念会挨打。

    它不是孔（腔里不是孔色，落不进去），但它在跳跃规则里扮演**被跨者**：
    实测第 4 关点 (24,12) 那颗子，世界画出的唯一一个环在 (24,24)，
    中间隔着的正是 (24,18) 这块踏板——所以跨它是合法的。
    「跨过之后它会不会消失」还没测，这里不表态。
    """
    n = len(g)
    out = set()
    for r in range(n - SIZE + 1):
        row = g[r]
        for c in range(len(row) - SIZE + 1):
            if row[c] != C_STEP_EDGE:
                continue          # 左上角就不是框色，整块必不是踏板：不必再拼那两张表
            border = [(r + dr, c + dc) for dr in range(SIZE) for dc in range(SIZE)
                      if dr in (0, SIZE - 1) or dc in (0, SIZE - 1)]
            inner = [(r + dr, c + dc) for dr in range(1, SIZE - 1)
                     for dc in range(1, SIZE - 1)]
            if all(g[rr][cc] == C_STEP_EDGE for rr, cc in border) and \
               not any(g[rr][cc] == C_STEP_EDGE for rr, cc in inner):
                out.add((r + 1, c))
    return frozenset(out)


def stones(g):
    """盘上所有「石子」占的格点坐标 (R, C)：12 格实心的色8，四角留底色。

    第 5 关开局出现的第三种物件。它和棋子画法完全一样（4x4 去掉四角的 12 格实心，
    四角留色1），只是颜色是色8 而不是色14，并且和孔共用同一套格点——
    这一点跟踏板不同，踏板画在格点上方 1 像素处。

    它在跳跃规则里和踏板同一个角色：**跨得过去，但跨过之后它不动也不消失**。
    实测第 2483 步点它下方的子 (24,18)，世界画出的唯一一个环在 (12,18)（帧差 29），
    中间隔的正是石子 (18,18)；第 2484 步执行这一跳，帧差 45——
    和跨踏板一模一样的价钱，比跨子的 57 少掉被吃那颗子的 12 格，石子一格没变。

    它坐着的格点**是孔**（第 3125 步起色8 收进 HOLE_COLORS）：它和子一样占孔，
    holes() 能扫到它，jumps_from 的落点排除它，selected() 能读到它被选中。
    """
    out = set()
    H, W = len(g), len(g[0])
    for r in range(H - SIZE + 1):
        row = g[r]
        for c in range(W - SIZE + 1):
            if row[c + 1] != C_STONE:
                continue          # (r, c+1) 是非角格，不是石色就必不是石子：不必再拼那两张表
            corners = {(r, c), (r, c + SIZE - 1), (r + SIZE - 1, c), (r + SIZE - 1, c + SIZE - 1)}
            cells = [(r + dr, c + dc) for dr in range(SIZE) for dc in range(SIZE)]
            if any(g[rr][cc] == C_STONE for rr, cc in corners):
                continue
            if all(g[rr][cc] == C_STONE for rr, cc in cells if (rr, cc) not in corners):
                out.add((r, c))
    return frozenset(out)


def greys(g, hs=None):
    """盘上所有「灰团」占的格点坐标 (R, C)：孔里 12 格实心的色9。

    第 7 关开局出现的第四种物件，画法和棋子、石子一模一样（12 格实心、四角留底色），
    只是颜色是色9。它和孔共用同一套格点。

    **它是棋子，不是布景**——这一点我认错过 18 步：第 4286 步点它一下帧差只有 1，
    我读成「点不动的布景」就绕开了。其实那一下点的是**没有合法跳的**那个灰团，
    而 click_stuck_peg_deselects 早就说过，点一颗动不了的子就是这个签名——
    「点了没反应」分不出「不是棋子」和「是棋子但走不动」。
    第 4304 步改点另一个有跳的灰团 (48,30)，帧差 29、环画在 (36,30)，当场认下它是棋子。

    在跳跃规则里它扮演两个角色，各有量过的读数：
      * **被跨者**：第 4310 步那颗子有两条跳，其中一条的中点正是灰团 (24,30)，
        帧差 37 = 21 + 8×2，世界自己把「两条跳」报了出来。
      * **跳者**：第 4305 步它自己跨过另一个灰团走了一格，帧差 45。

    **跨过灰团不吃掉它**：第 4305 步帧差 45 而不是 57，少掉的正是被吃那颗的 12 格。
    我押的是 57（理由「灰团处处像子」），押错了——灰团在别处都像子，偏偏在能不能被吃上不像。
    「子跨灰团吃不吃」「灰团跨子吃不吃」两条**都还没量过**，这里不表态。

    读法走 holes() 而不是自己扫像素，是有意的：色9 同时是阴影色，
    自由扫描会在墙脚的阴影带上认出假灰团；holes() 那道「四周一圈都不是孔色」的边界判据
    把连成片的阴影整片挡在外面。代价量过（见 HOLE_COLORS 处的注释）：
    全语料 8620 帧，少认 0 个孔，多认的 5 个坐标全是这两个灰团走过的格点。
    """
    return frozenset(h for h in (holes(g) if hs is None else hs)
                     if count_in(g, *h, C_GREY) >= 12)


def jumpable(g):
    """所有「可以被跨过去」的格点：有子的孔，加上踏板，加上石子，加上灰团。"""
    return pegs(g) | steps(g) | stones(g) | greys(g)


def jumps_from(g, src):
    """从 src 出发的合法跳：跨过一个相邻的可跨者，落在空孔上。返回落点集合。

    跳的可以是子、石子，也可以是灰团（第 2920、3105、3125 步实测石子按同一套规则跳；
    第 4304/4305 步实测灰团按同一套规则跳）；落点不能是有子、有石子、有灰团的孔。"""
    hs = holes(g)
    ps, st, gr = pegs(g, hs), stones(g), greys(g, hs)
    over_ok = jumpable(g)
    if src not in ps and src not in st and src not in gr:
        return frozenset()
    out = set()
    for dr, dc in DIRS:
        over = (src[0] + dr, src[1] + dc)
        dst = (src[0] + 2 * dr, src[1] + 2 * dc)
        if over in over_ok and dst in hs and dst not in ps and dst not in st and dst not in gr:
            out.add(dst)
    return frozenset(out)


def all_jumps(g):
    """全盘**子**的合法跳，返回 {(起点, 被跨, 落点)}。石子的跳不在这里，用 stone_jumps。"""
    out = set()
    for src in pegs(g):
        for dst in jumps_from(g, src):
            over = ((src[0] + dst[0]) // 2, (src[1] + dst[1]) // 2)
            out.add((src, over, dst))
    return out


def stone_jumps(g):
    """全盘石子的合法跳，返回 {(起点, 被跨, 落点)}。"""
    out = set()
    for src in stones(g):
        for dst in jumps_from(g, src):
            over = ((src[0] + dst[0]) // 2, (src[1] + dst[1]) // 2)
            out.add((src, over, dst))
    return out


def grey_jumps(g):
    """全盘灰团的合法跳，返回 {(起点, 被跨, 落点)}。"""
    out = set()
    for src in greys(g):
        for dst in jumps_from(g, src):
            over = ((src[0] + dst[0]) // 2, (src[1] + dst[1]) // 2)
            out.add((src, over, dst))
    return out


def any_jump(g):
    """这一帧还有没有**任何**合法跳（子跳、石跳或灰跳）。

    等价于 `bool(all_jumps(g) or stone_jumps(g) or grey_jumps(g))`。

    为什么要单写一个：那两个函数只适合「已经知道要看哪几帧」的用法。
    jumps_from 每次调用都要 holes + pegs + stones + jumpable，而 jumpable = pegs | steps | stones，
    pegs/stones 又各自回头再调一次 holes——**一个起点**就是五六遍全盘扫描；
    all_jumps 再对每颗子各调一次。子多的关卡里一帧上百遍扫描，
    拿它去问全语料「这一帧死了没有」必然跑不完（实测外推 129s，结算预算 20s）。
    这里整帧只扫一遍：holes/pegs/stones 各算一次，落点与被跨者都查这三张表。

    踏板推迟到第二轮才算：第一轮只拿子和石子当被跨者，找到跳就已经证明「还活着」，
    steps() 那一遍扫描就不必付。只有第一轮空手（包括所有死局）才去算踏板。
    这是纯粹的省钱，不是缩口径——第一轮的被跨者集合是真集合的子集，
    它判「活」必真活；判不出来才进第二轮拿全集合重判。

    **它不是一条新主张，是同一句话的另一种算法**，所以必须和慢版本逐帧同判，
    这一点是量过的，不是想当然：全语料 1730 帧里，等距抽样帧加上**全部**判死帧
    （概念只在判死时开口，判死这一半错了才会真的改判词）逐帧对拍，
    见 runs/ 里的 probe_dead_speed.py / probe_dead_speed3.py。
    """
    hs = holes(g)
    ps = pegs(g, hs)
    st = stones(g)
    occupied = ps | st | greys(g, hs)
    if not occupied:
        return False
    for over_ok in (occupied, occupied | steps(g)):
        for src in occupied:
            for dr, dc in DIRS:
                over = (src[0] + dr, src[1] + dc)
                dst = (src[0] + 2 * dr, src[1] + 2 * dc)
                if over in over_ok and dst in hs and dst not in occupied:
                    return True
    return False


def click(R, C):
    """点这个孔要发的动作串。ACTION6 的坐标是 x=列 y=行，取 4x4 块里的第二格。"""
    return f"ACTION6:{C + 1},{R + 1}"


def carts(g):
    """盘上所有滑车的内腔左上角 (R, C)；没有就返回空集。

    **底下记了张按帧的备忘录，只动速度，读数一格不许变**（第 4952 步加的，与 holes() 同一套写法）：
    全册第二贵的一步——1360 帧单跑 8.94s（`runs/…/probe_assert_cost.txt`），
    而 vacated_cart_cell_holds_nothing 一条 assert_ 要问两次（prev 与 nxt），
    改版冲掉缓存后整条在去重语料上跑 20.74s，超了 settle 的 20s 预算，闸当场关了一次。
    对拍见 `runs/…/probe_carts_cmp.txt`（老本子 / 新本子喂元组 / 新本子喂列表，逐帧比）。

    实测第 2 关：滑车是一圈 6x6 的色11 空心方框，框里 4x4 就是它的内腔。
    内腔的底色不是色1 而是色12——空车时 16 格全是色12，装了子就是 12 格色14 加 4 角色12，
    画环时是 8 格色2 加 8 格色12。所以色12 在这辆车里扮演的正是色1 在孔里的角色，
    HOLE_COLORS 把它收进去，孔的扫描规则一字不改就能把内腔当成一个孔扫出来。
    第 3 关一次出现两辆，所以这里返回集合。

    **车框不一定全是色11**：车里那颗子被选中时，框上除四角以外全部由色11 改画成色3
    （和普通孔被选中时孔外描一圈色3 是同一套画法，只是这里那圈正好落在车框上）。
    实测第 1 关第 2202 步：框在行50..55 列36..41，选中后只剩四角还是色11，其余十六格变色3，
    内腔也不再见得到色12（四角由色12 变成了色3）。
    所以判据是：框上看得见的格子颜色都落在 {色11, 色3} 里，**且至少有一格仍是色11**。
    那一格色11 正是「这是车不是普通孔」的凭据——普通孔被选中时描的那圈是纯色3。

    **车载着踏板时，踏板会盖住车框的一条边**：实测第 4 关第 2427..2436 步，
    那辆车的内腔里放着一块踏板，踏板的 4x4 色15 外框比内腔高出一行，正压在车框的顶边上，
    于是顶边那六格里有四格是色15 而不是色11。旧判据把这种车整辆漏掉——
    漏掉的后果不是少读一个物件，而是 non_click_keys_inert 的免责条款
    「prev 里 cart() 找得到滑车就返回 NA」失效，十条方向键转移全被判 FALSE。
    所以 {色15, 色7}（踏板的框与腔）也算作合法遮挡。
    代价测过：第 0/1/2/3 关合计 4767 帧，候选读法与旧读法**辆数逐帧相同**，
    只有第 4 关多认出 181 帧里的那辆载板车——不是放宽到谁都算车。

    **上一条放宽会在两辆车的接缝上造出一个不存在的第三辆**：实测第 6 关第 4248 步之后，
    两辆载板车上下紧挨，车框分别占行 23..28 与行 29..34（列 53..58）。
    行 26..31 这个 6x6 窗口的上边是 `11 15 15 15 15 11`、下边是 `11 15 7 7 15 11`——
    两条边的非角格全是踏板色，被「踏板算合法遮挡」整条放行；两侧的色11 则是两辆真车自己的侧框。
    于是 carts() 在接缝上多认出一个腔 (27,54)，cart_slides_one_stride 的
    「这批车的辆数不变」被这个读数假象打翻，闸关了一次。

    补的判据是：**围出来的 4x4 内腔里一个色11 都不许有**。
    内腔能装的东西只有五种——空（色12）、子（色14/2）、被选中的子（色3）、石（色8）、踏板（色15/7/0）——
    没有一种用车框色；内腔里出现色11，说明这个窗口跨在两个框上，不是一个腔。
    接缝那个窗口的内腔里整整一行都是色11（下面那辆车的顶边），当场出局。
    这条判据不认方向，左右紧挨的两辆车会在列上造出同样的接缝，同样被它挡掉。
    代价测过（`runs/*/probe_cart_seam.py`）：全语料去重 1764 条、对拍 3528 帧，
    **3523 帧辆数完全相同**；变的 5 帧全是上面那个接缝，每帧只少 (27,54) 这一个腔，别的一个没动。
    注意「行列不是 6 的倍数」不是判据：车停在轨上本来就常常不在格点上，全语料有 2547 个这样的腔。

    车开到屏幕边上时框会被裁掉一部分，所以判据只查**看得见的那些框格**；
    内腔仍要求整块 4x4 都看得见，看不全的内腔当不了孔。
    """
    try:
        return _carts_cached(g)
    except TypeError:                                # 帧里有不可 hash 的东西：照旧现算
        return _carts_raw(g)


_CARTS_MEMO = {}
_CARTS_MEMO_CAP = 2048                   # 与 _HOLES_MEMO 同一个理由、同一个封顶


def _carts_cached(g):
    key = g if isinstance(g, tuple) else tuple(map(tuple, g))
    hit = _CARTS_MEMO.get(key)
    if hit is None:
        if len(_CARTS_MEMO) >= _CARTS_MEMO_CAP:
            _CARTS_MEMO.clear()
        hit = _CARTS_MEMO[key] = _carts_raw(g)
    return hit


def _carts_raw(g):
    """**第 4952 步改过一次，只动速度**：候选窗口不再是整幅帧上的 70x70 个位置，
    而是由每一格色11 反推出来的那几十个。

    能这么改是因为判据自己要求 `edge >= 1`——被认下的窗口，边框上**必有**一格是色11，
    所以由每一格色11 反推「它能当谁的边框」就一个都不漏（和 `_sel_candidates` 同一个套路）。
    帧上没有色11 时候选为空，整趟扫不跑。判据本身一字未动。
    改之前 1290 次调用 17.4s（13ms/帧），是当时最贵的一步；对拍见 `runs/…/probe_lib_speed.txt`。
    """
    H = len(g)
    W = len(g[0]) if H else 0
    box = SIZE + 2                       # 车框是 6x6
    cand = set()
    for r in range(H):
        row = g[r]
        for c in range(W):
            if row[c] != C_CART_EDGE:
                continue
            for fr in range(r - box + 1, r + 1):
                for fc in range(c - box + 1, c + 1):
                    if r in (fr, fr + box - 1) or c in (fc, fc + box - 1):
                        cand.add((fr, fc))
    out = set()
    for fr, fc in cand:
        lr, lc = fr + box - 1, fc + box - 1
        ir, ic = fr + 1, fc + 1
        if ir < 0 or ic < 0 or ir + SIZE > H or ic + SIZE > W:
            continue
        ok, edge = True, 0
        for r in range(fr, lr + 1):
            for c in range(fc, lc + 1):
                if not (r in (fr, lr) or c in (fc, lc)):
                    continue
                if not (0 <= r < H and 0 <= c < W):
                    continue
                if g[r][c] == C_CART_EDGE:
                    edge += 1
                elif g[r][c] not in _CART_EDGE_OCCLUDERS:
                    ok = False
                    break
            if not ok:
                break
        if ok and edge:
            # 内腔里出现车框色 = 这个窗口跨在两个框上，不是一个腔。
            # 这一查放在框判据**之后**：候选窗口有几千个，通过框判据的只有几个，
            # 放前面会让 carts() 慢到把三条概念的结算拖爆预算（试过，闸关了一次）。
            if any(g[r][c] == C_CART_EDGE
                   for r in range(ir, ir + SIZE)
                   for c in range(ic, ic + SIZE)):
                continue
            out.add((ir, ic))
    return frozenset(out)


def cart(g):
    """盘上恰好一辆滑车时返回它的内腔左上角，否则 None。"""
    cs = carts(g)
    return next(iter(cs)) if len(cs) == 1 else None


def click_target(g, action):
    """把 ACTION6:x,y 还原成它点中的孔；点在孔外或不是 ACTION6 就返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    for (R, C) in holes(g):
        if R <= y < R + SIZE and C <= x < C + SIZE:
            return (R, C)
    return None


def click_xy(action):
    """ACTION6:x,y 里的 (y, x)——行在前列在后，和帧的下标一致；解析不了返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return (y, x)


def disc(g):
    """左下那个圆盘的黑心（2x2 全黑、外框一圈全是色5、再外一圈里有色15）；找不到返回 None。

    判据是照着实测的那一个圆盘描的——第二个圆盘长得不一样它就会瞎。
    这是明知故犯，理由写在 click_outside_board 的 NOTE 里。
    """
    H, W = len(g), len(g[0])
    for r in range(2, H - 3):
        for c in range(2, W - 3):
            if any(g[r + dy][c + dx] != 0 for dy in (0, 1) for dx in (0, 1)):
                continue
            ring = [(y, x) for y in range(r - 1, r + 3) for x in range(c - 1, c + 3)
                    if not (r <= y < r + 2 and c <= x < c + 2)]
            if any(g[y][x] != 5 for (y, x) in ring):
                continue
            if any(g[y][x] == 15 for y in range(r - 2, r + 4) for x in range(c - 2, c + 4)):
                return (r, c)
    return None


def background(g):
    """行1 以下出现次数最多的那一种颜色。"""
    freq = {}
    for row in g[1:]:
        for v in row:
            freq[v] = freq.get(v, 0) + 1
    return max(freq, key=freq.get)


def world_open(g):
    """视口边缘上还有非背景内容 —— 世界很可能在视口外接着长，视口里的子数不等于世界里的子数。

    边缘取行1、末行、首列、末列（行0 是计数条，与盘面无关）；色0 当作「什么都没画」。
    这段读法原先长在 board_replaced_iff_last_peg v6 里（它靠这一条把「剩 1 子就该换盘」
    那半边在视口装不下世界时闭嘴），第 4652 步 disc_only_on_dead_position 也要同一个判断，
    所以搬进词汇表，两处一个读法。**搬家不改一个字**：原处的 `_world_open` 与这里逐行相同。
    """
    bg = background(g)
    H, W = len(g), len(g[0])
    edge = [(1, c) for c in range(W)] + [(H - 1, c) for c in range(W)] \
        + [(r, 0) for r in range(1, H)] + [(r, W - 1) for r in range(1, H)]
    return any(g[r][c] not in (bg, 0) for r, c in edge)


# ---- 方向键的位移，和「这辆车前方通不通」 ----------------------------------
# 这两样原先长在 cart_moves_iff_rail_ahead 里。第 4877 步
# loaded_cart_peg_offset_shifts_by_key 要用同一个判断（它得知道载子车这一下
# 自己走不走得动，走不动的那一档归 cart_moves_iff_rail_ahead 管、它闭嘴），
# 两条概念共用就该进词汇表，否则两处各留一份迟早分家。
# **搬家不改一个字**：DELTA / C_RAIL / CART_COLORS / _ahead / rail_free
# 与原处逐行相同，只把 `_free` 改名成 `rail_free`（词汇表里不用下划线开头）。
# 它是假设不是定论：改 _lib 不算改版，所以依赖它的两条概念每批一起重审。

DELTA = {
    "ACTION1": (-STRIDE, 0),
    "ACTION2": (STRIDE, 0),
    "ACTION3": (0, -STRIDE),
    "ACTION4": (0, STRIDE),
}
C_RAIL = 5
CART_COLORS = HOLE_COLORS | _CART_EDGE_OCCLUDERS


def _ahead(r, c, dr, dc):
    """去处内腔正中那 2x2 格——轨道线（横轨两行 / 立柱两列）穿过内腔中心的地方。
    第一版查的是新车框压在轨道线上的整整 12 格，被「从立柱下到横轨」当场打掉：
    立柱到横轨为止，横轨下面两行是空的，可车照样下得去。"""
    return [(r + dr + k, c + dc + j) for k in (1, 2) for j in (1, 2)]


def rail_free(g, A, a, dr, dc, seen=()):
    """a 这辆车沿 (dr, dc) 前方通不通：True / False / None（看不全）。"""
    H, W = len(g), len(g[0])
    cells = _ahead(a[0], a[1], dr, dc)
    if any(not (0 <= r < H and 0 <= c < W) for r, c in cells):
        return None
    cols = {g[r][c] for r, c in cells}
    if cols == {C_RAIL}:
        return True
    if cols <= CART_COLORS:
        b = (a[0] + dr, a[1] + dc)
        if b in A and b not in seen:
            return rail_free(g, A, b, dr, dc, seen + (a,))
    return False
