"""点在一块踏板上：没有选中时行1 以下整帧一格不动；有选中时只是清掉选中框和环，子、踏板、别的一格不动——踏板自己不能被选中、不出环。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点中的 4x4 格点在 prev 里是 steps() 之一的转移；计数条没有正常推进一格（重开/换关）返回 NA；其余 NA。"
         "有选中时，「清掉」的判法：nxt 里 selected() 为 None、rings() 为空，且把 prev 里选中框与环的格子都按 nxt 的读数改掉之后两帧行1 以下完全相同。")
NOTE = """踏板是家具：它在跳跃规则里扮演被跨者（jump_over_step_captures_nothing），但自己不是可操作物。
第 3077 步在镜头 62 下点世界 (24,90) 那块踏板（屏幕 (24,28)），帧差 1。
同一批前两步点的是空地（坐标按旧帧算的，见 journal 事故），不算这条的证据。

v2：v1 从入册起 N=0，连自己的 EVIDENCE 3077 都判 NA——它用 `click_target` 找点中的格点，
而 `click_target` 只在 `holes()` 里找，踏板（色 15/7）根本不是洞，所以 v1 的 SCOPE 永远够不到。
一条永远 NA 的概念在册子里挂了几百步没人发现，settle 每批都报 N=0，我当成「还没遇到踏板」，
其实是「遇到了也认不出」。改成直接拿 `click_xy` 对 `steps()` 的 4x4 找。
步 3562/3563 在镜头 54 下点世界 (24,70) 与 (24,88) 两块踏板，帧差各 1，是 v2 头两条真证据。

v3：v2 一上场就被 d69c7116b12abfb5（第 3 关步 2283）打死——子 (24,12) 选中、环在 (24,24)，
点踏板 (24,18)，帧差 29：选中框和环都没了，别的没动。v1 里「也不清掉已有的选中」那半句是我没证据写上去的，
全语料里带选中点踏板的只有这一条，它说的正好相反。所以主张分成两半：无选中 = 死物；有选中 = 和点空地一样清选中。
"""
EVIDENCE = [
    "e6709089ced1ebe2",  # 步3077 ACTION6:29,25 点踏板 (24,28)，无选中，帧差 1
    "55216bb28dad5a82",  # 步3562 ACTION6:17,25 点踏板 屏幕(24,16)，无选中，帧差 1
    "adb4703efa116734",  # 步3563 ACTION6:35,25 点踏板 屏幕(24,34)，无选中，帧差 1
    "d69c7116b12abfb5",  # 步2283 ACTION6:20,25 有选中点踏板 (24,18)：反例→v3，只清掉选中与环，帧差 29
]

from _lib import SIZE, C_RING, C_SEL, click_xy, steps, selected, rings


def _step_hit(g, action):
    """点在哪块踏板的 4x4 里；没点中返回 None。"""
    xy = click_xy(action)
    if xy is None:
        return None
    y, x = xy
    for (R, C) in steps(g):
        if R <= y < R + SIZE and C <= x < C + SIZE:
            return (R, C)
    return None


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    if sum(1 for x, y in zip(prev[0], nxt[0]) if x != y) != 1:
        return "NA"
    if _step_hit(prev, action) is None:
        return "NA"
    if selected(prev) is None:
        return "TRUE" if prev[1:] == nxt[1:] else "FALSE"
    # 有选中：nxt 里选中与环都没了，其余格子一格不动
    if selected(nxt) is not None or rings(nxt):
        return "FALSE"
    for r in range(1, len(prev)):
        for c in range(len(prev[0])):
            a, b = prev[r][c], nxt[r][c]
            if a == b:
                continue
            if a in (C_RING, C_SEL):
                continue                    # 选中框 / 环被擦掉，允许
            return "FALSE"
    return "TRUE"
