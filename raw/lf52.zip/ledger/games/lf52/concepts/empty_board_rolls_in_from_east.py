"""第 4 关，视口里一颗**盘上的**子都没有时，把子滚进视口的方向键只有 ACTION4（往东）——ACTION1/ACTION2/ACTION3 一次都没做到过。"""
LEVEL = "L7"
SCOPE = (
    "只看第 4 关（ctx 的 level_prev 与 level_next 都是 4，换关返回 NA）。"
    "只看 ACTION1/2/3/4——ACTION7（撤销）和 RESET 也把子换回视口里过（第 4848/4850/4852/4854/4856 步、"
    "第 4820/4857 步），那是**把局面退回去**，不是把镜头开过去，不归这条管，返回 NA。"
    "prev 里必须**恰好一辆载子车**、且视口内盘上子（pegs 减 carts）为 0；否则返回 NA。"
    "它只说「哪个键做到过」，**不说 ACTION4 一按就一定滚出子来**——实测 18 次 ACTION4 里只有 3 次滚出来，"
    "所以 ACTION4 那一档一律判 TRUE，不去断言它的效果。"
)
NOTE = """第4875 步立的。由来是连着 6 批零新 tid 之后，押注 v179 预注册的分支逼出来的一次重量。

先说被重量推翻的和被重量坐实的：
  · **被证伪的**（我自己的话）：押注 v178 的分支主张「轨网把车锁在一条纵向走廊里」。
    probe_rail_corridor.txt 判据一当场打脸——当前帧从载子车做车队 BFS 可达 26 个车位、
    跨 9 列 9 行。轨网没锁死，是我编的。原话留在 note 里，不删。
  · **被坐实的**：第 4758 步我判过「腔里那颗子没有落在盘上的合法跳」，此后规划器每一批都在引用它，
    却一次都没重量过。probe_click_branch.txt 判据三重量了：第 4 关「一辆载子车 + 视口内 0 颗盘上子」
    的去重帧共 82 帧，有盘上落点的 **0 帧**。那条判断没过期——点击那一支在这一类局面里真的没有路。

这条概念说的是判据四：那 82 帧里，走完之后视口内盘上子从 0 变成非 0 的只有 10 条，
其中方向键 **3 条，全是 ACTION4**（第 2363 步 tid e81a1f91723dd022、第 2415 步 93b536ab161a2082、
第 4798 步 f2f82b9b36d34ec9）；其余 7 条是 ACTION7 与 RESET，那是退回去不是开过去。
同一批 82 帧里下一步的动作分桶是 ACTION4 18 / ACTION2 18 / ACTION3 16 / ACTION1 16 / ACTION7 12 / RESET 2，
也就是说 ACTION1/2/3 一共走了 50 次，**一次都没把子滚进来**。

**样本有多薄，照实说**：正面例子只有 3 条，而且第 2363/2415 步那两条车在屏幕 (42,30)、
第 4798 步那条车在别处。三条都指东，可它们也可能只是「这几次车恰好停在盘的西缘」的巧合，
而不是这一关的盘只在东边。所以这条概念写成**只认方向、不认位置**的形状，
好让它最容易被打死：将来只要有一次 ACTION1/2/3 在这一类局面里滚出一颗盘上的子，它当场就是反例。

它靠着的两条已入册的概念：pan_opposes_key_axis（盘朝键的反方向滚）说明往东开露出来的是盘的东侧；
pegs_scroll_with_the_board（第 4872 步入册，S=1.000 C=0.548 N=1241）说明视口外确实还有子。
这一条补的是它们都不说的那一句：**这一关该往哪边开**。

规划器只从它拿一句话：盘空了要找盘，先往东。EAST 这个名字导出来给驱动层用（和
cart_moves_iff_rail_ahead 把 _free 借出去是同一个办法），驱动层一格也不预测，算错最坏是多走冤枉路。
"""
EVIDENCE = [
    "e81a1f91723dd022",   # 第2363 步 关4 ACTION4 盘上子 0→1，走通那条路的救命一步
    "93b536ab161a2082",   # 第2415 步 关4 ACTION4 盘上子 0→1，同一条路上第二次
    "f2f82b9b36d34ec9",   # 第4798 步 关4 ACTION4 盘上子 0→1，本 run 也做到过
    "017a30df386173bd",   # 第2389 步 关4 ACTION3 往西开，盘上子没有 0→非 0（反面一档，判 TRUE）
    "789406dad51c5962",   # 第4801 步 关4 ACTION3 往西开，同样没滚出子来
]

from _lib import carts, pegs

EAST = "ACTION4"
KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _board_pegs(g):
    return set(pegs(g)) - set(carts(g))


def _lone_loaded(g):
    """恰好一辆载子车时返回它，否则 None。"""
    ps = set(pegs(g))
    ld = [c for c in carts(g) if c in ps]
    return ld[0] if len(ld) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and (ctx.get("level_prev") != 4 or ctx.get("level_next") != 4):
        return "NA"
    if not action.startswith(KEYS):
        return "NA"
    if _lone_loaded(prev) is None:
        return "NA"
    if _board_pegs(prev):
        return "NA"
    if action.startswith(EAST):
        return "TRUE"
    return "FALSE" if _board_pegs(nxt) else "TRUE"
