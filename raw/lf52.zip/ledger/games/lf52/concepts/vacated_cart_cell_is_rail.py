"""方向键让一辆车离开某一格之后，那一格露出来的是轨（内腔正中 2x2 全是色5），不是空孔。"""
LEVEL = "L6"
SCOPE = ("只看方向键 ACTION1..4，且 prev 里有车、在镜头位移修正之后 nxt 里那格不再是车的转移；"
         "点击、换关、没有任何车腾出格子（含帧差 1 的全堵死）一律 NA。"
         "镜头位移由踏板定，且**只用不在车腔里的那些踏板**：两轴各取 -8/-6/0/6/8 共 25 个候选，"
         "要求 prev 的这批踏板平移后凡整块还在画面里的（至少 3 块）都落在 nxt 的踏板上，"
         "命中数最高且唯一的那个位移才作数；对不上或并列第一一律 NA；踏板空集 NA。"
         "腾出的格子的内腔 2x2 越出画面边界返回 NA。"
         "只断言**腾出来那一格**的内腔 2x2 的颜色，不断言车框外圈、不断言车去了哪。")
NOTE = """v2 → v3：换参照物的挑法。断言正文仍然一字未动。

v2 拿**全部**踏板反解镜头位移。可是这个世界里有踏板是**装在车腔里**的
（world 行 78 那三辆车，其中两辆各驮着一块），车一动它们就跟着走——
拿一个会动的东西定位镜头，等于在错的坐标系里宣布地形对或不对。
v3 的锚点改成 `steps(g) - carts(g)`：只认不在车腔里的那些踏板。
这件事在 v2 入册时还没有机会犯错（第 7 关至今按过的方向键都没同时动过驮踏板的车），
但路线的第 5 步就是 ACTION3，那一下底下三辆车一起西移、两块车上的踏板跟着走。
**这是在反例发生之前补的洞，不是被打出来的**——所以 EVIDENCE 没有新增，
它也因此没有任何一条转移能证明这个改动是必要的。若将来有一条转移能分辨 v2 与 v3，记在这里。

另外两处一并抄自 stitch7.py 里已经跑通 87 帧、零地形冲突的那版 `pan()`：
(1) 去掉反向包含。镜头一滚就有新踏板从画面外进来，反向必然不成立——
    v2 的写法会让这条概念在**每一次真的滚了镜头的转移上闭嘴**，而那正是要它说话的那些步。
(2) 加边距过滤 `1 <= r+dr <= h-SIZE-1`：贴着视口上下边的踏板被裁掉一半，`steps()` 认不出来，
    平移后落在那里的锚点会凭空"消失"，害得正确位移的命中集不被包含。
唯一性从"只有一个候选"放宽成"命中数最高且唯一"——并列第一仍然 NA。

v1 → v2：把「镜头不许滚」换成「把镜头的位移算出来再比」。

v1 的 scope 里写着「要求 prev 与 nxt 的踏板集合相同」，当时我借的是 steps_pinned_in_level7 的参照物，
而那条概念在第 4325 步被打死了（37a105c0c3144154：第 7 关第一次按 ACTION2，镜头跟着车往南滚一格，
踏板整体上移 6 行）。镜头会滚，所以 v1 的 scope 从「镜头没滚的凭据」退化成「这一步碰巧没滚」——
往后第 7 关每一次南北向推车它都会闭嘴，而那正是我要拿它排路线的那几步。
v2 不再要求不滚，改成**先用踏板把位移解出来，再在同一套坐标里比车位**。
踏板在这里仍然只当参照物用，但这次是量位移，不是赌位移为零。

**留了唯一性这道闸**：25 个候选里对上不止一个（比如踏板少、平移后大半出画）就返回 NA。
宁可闭嘴也不要挑一个凑得上的位移——那等于让判据自己去找一个能让结论成立的坐标系。

**这条在补一个我早就在用、却一直没量过的地形前提。** 排第 7 关路线的时候，
我把车腔当成「可以落子的空位」，于是顺手假定车开走以后那一格还是个空孔、还能当落点。
第 4324 步把它量了：载子车从 (36,12) 西行一格，(36,12) 那一格在 nxt 里是**色5 的轨**。
所以车一走，那格就不是落点了——这直接改掉了搜索的可达集。
solve7b.py 已经按这条事实在跑（RAIL 里放进了当前车占的格），
**所以它必须是一条概念，不能只是脚本里的一行**。物证 f12506f00e2d9023。

**它和 cart_moves_iff_rail_ahead 是一对**：那条说「前方内腔 2x2 是轨才走得动」，
这条说「走完身后内腔 2x2 也是轨」。两条合起来才是「车只在轨上跑」。
判据里的「内腔正中 2x2」刻意抄的是那条概念里的同一块坐标（(r+k, c+j), k,j ∈ {1,2}），
**排路线用的尺子和走闸的尺子必须是同一把**，否则我在规划里信的东西没人检验过。

**借了别人的腿，写在这里**：镜头的位移这条自己不判，是从踏板反解出来的——
前提是「踏板不会自己动」。那个前提**不在这条断言里**，也还没有任何一条概念管它
（keys_dont_push_free_stones 管的是石子）。踏板哪天自己挪了一块，这条会算出一个假位移，
然后在错的坐标系里宣布地形对或不对。这笔账记在这，别拿这条概念替那条说话。

**欠**：没写 apply。腾出来那一格的 16 格里，我只量准了正中 2x2；
车框外圈（色11 的边）退场之后剩什么颜色，得再看一帧才知道，不许拿 2x2 的读数外推到 6x6。
"""
EVIDENCE = ["f12506f00e2d9023", "e513e60e1ce86dee", "537f5cfafba9d288",
            "37a105c0c3144154"]

from _lib import steps, carts, SIZE

C_RAIL = 5
SHIFTS = (-8, -6, 0, 6, 8)
MIN_MATCH = 3


def _pan(prev, nxt):
    """用踏板反解镜头位移；解不出或不唯一返回 None。

    **只拿不在车腔里的踏板当锚**：世界里有踏板是装在车腔里的，车一动它就跟着走，
    拿它定位镜头等于拿一个会动的东西当参照物。
    只查正向包含（镜头一滚就有新踏板从画面外进来，反向必然不成立），
    并且只数平移后仍整块在画面里的那些（贴边的踏板会被视口裁掉、认不出来）。
    """
    sa = set(steps(prev)) - set(carts(prev))
    sb = set(steps(nxt)) - set(carts(nxt))
    if not sa or not sb:
        return None
    h, w = len(nxt), len(nxt[0])
    best = []
    for dr in SHIFTS:
        for dc in SHIFTS:
            inside = [(r + dr, c + dc) for r, c in sa
                      if 1 <= r + dr <= h - SIZE - 1 and 1 <= c + dc <= w - SIZE - 1]
            if len(inside) < MIN_MATCH or not set(inside) <= sb:
                continue
            best.append((len(inside), (dr, dc)))
    if not best:
        return None
    best.sort(reverse=True)
    if len(best) > 1 and best[0][0] == best[1][0]:
        return None
    return best[0][1]


def assert_(prev, action, nxt, ctx=None):
    if not any(action.startswith(f"ACTION{k}") for k in (1, 2, 3, 4)):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    pan = _pan(prev, nxt)
    if pan is None:
        return "NA"
    dr, dc = pan
    moved_frame = {(r + dr, c + dc) for r, c in carts(prev)}
    vacated = moved_frame - set(carts(nxt))
    if not vacated:
        return "NA"
    h, w = len(nxt), len(nxt[0])
    for r, c in vacated:
        if not (0 <= r and r + 2 < h and 0 <= c and c + 2 < w):
            return "NA"
        for k in (1, 2):
            for j in (1, 2):
                if nxt[r + k][c + j] != C_RAIL:
                    return "FALSE"
    return "TRUE"
