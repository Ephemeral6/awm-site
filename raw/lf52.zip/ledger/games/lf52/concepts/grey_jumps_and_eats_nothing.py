"""选中的是灰团时点它的某个环，灰团就照子的跳法跳过去：起点清空、落点长出一个灰团、选中与环清掉，而**盘上一个东西都不被吃**——子数、灰团数、石子数、踏板数全不变。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点中的孔正好是 prev 里的一个环、且 prev 唯一的选中物是一个**灰团**的转移；"
         "选中的是子或石子返回 NA（各归 click_ring_jumps 与 stone_moves_when_no_peg_selected）；"
         "孔位集合变了（换盘、换关、镜头滚）返回 NA。")
NOTE = """
第 7 关的开局摆着两个色9 的团，它们是这一关唯一的机关，而册子里**一条概念都没开在它们身上**。
这条是补上那个洞。

**我把它们当布景当了 18 步。** 第 4286 步点了其中一个，帧差只有 1（只动了计数条），
我读成「点不动的死物」就绕开了，还据此推出「第 7 关无解」——那个推论后来整条作废。
错在哪：`click_stuck_peg_deselects` 早就说过，点一颗**没有合法跳的子**就是这同一个签名。
帧差 1 分不出「它不是棋子」和「它是棋子但此刻走不动」，而我当时只想着前一种。
第 4304 步改点另一个（那个有合法跳），帧差 29、环画在唯一落点上，当场翻案。

它在跳跃规则里的两个角色各有读数：
  **当被跨者**：第 4310 步子 A 有两条跳，其中一条的中点就是灰团，帧差 37 = 21+8×2；
  **当跳者**：第 4307、4309 两步它自己各跨过另一个灰团走了一格，帧差都是 45。

**「跨过它/它跨过去，吃不吃」是三个独立的二选一，目前量到两个：**
  子跨灰团 —— 不吃（第 4311 步，帧差 53 而不是 65，先押后测）；
  灰团跨灰团 —— 不吃（第 4307/4309 步，帧差 45 而不是 57）；
  **灰团跨子 —— 没量过。** 这条概念**不替它留免责**：断言写的是「一个东西都不被吃」，
  所以哪天灰团真吃了一颗子，它当场判 FALSE 把我叫回来。这是有意把话说满——
  说满才有人来打脸，留个 NA 就等于这件事永远不会有答案。

价钱与子的跳完全同构（45 + 8×(环数−1)），这一点归 click_jump_price_counts_jumps 管，这里不重复断言。
"""
EVIDENCE = [
    "d17aba0fed0670d2",  # 步4307 灰团 (42,30) 跨灰团 (36,30) 落 (30,30)，帧差 45，被跨的那个一格没变
    "e6c27519c76c1aa4",  # 步4309 灰团 (36,30) 跨灰团 (30,30) 落 (24,30)，帧差 45
]

from _lib import (click_target, holes, pegs, rings, selected, steps, stones, greys, carts,
                  PEG12, CORNERS, OUTLINE16, STRIDE,
                  C_EMPTY, C_GREY, C_CART_EDGE, C_CART_FILL)


def assert_(prev, action, nxt, ctx=None):
    # 免责条款按单价排：便宜的前缀判断在前，全帧扫描在后（同一套排法的由来见 click_ring_jumps 的 NOTE）。
    if not action.startswith("ACTION6:"):
        return "NA"
    tgt = click_target(prev, action)
    if tgt is None:
        return "NA"
    src = selected(prev)
    if src is None or tgt not in rings(prev):
        return "NA"
    hs = holes(prev)
    gs = set(greys(prev, hs))
    if src not in gs:
        return "NA"   # 选中的是子或石子：各有各的概念
    if hs != holes(nxt):
        return "NA"
    # 灰团挪了两格，别的灰团一个不动
    if set(greys(nxt)) != (gs - {src}) | {tgt}:
        return "FALSE"
    # 一个东西都没被吃：子、石子、踏板全守恒
    if pegs(nxt) != pegs(prev) or stones(nxt) != stones(prev) or steps(nxt) != steps(prev):
        return "FALSE"
    if selected(nxt) is not None:
        return "FALSE"
    return "TRUE" if not rings(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    """灰团跳：起点清空、描边退回它盖住的那层、所有环清掉、落点长出 12 格色9。

    照 click_ring_jumps v10 的骨架写，两处不同：落点画的是色9 不是色14；
    被跨的那个孔一格不碰（灰团不吃东西）。
    """
    if not action.startswith("ACTION6:"):
        return None
    tgt = click_target(prev, action)
    if tgt is None:
        return None
    src = selected(prev)
    rs = rings(prev)
    if src is None or tgt not in rs or src not in greys(prev):
        return None
    dr, dc = (tgt[0] - src[0]) // 2, (tgt[1] - src[1]) // 2
    if (dr, dc) not in ((0, STRIDE), (0, -STRIDE), (STRIDE, 0), (-STRIDE, 0)):
        return None

    cavities = carts(prev)

    def floor(h):
        """这个孔被清空之后露出来的底色。车腔的底色是腔色，不是空孔底色。"""
        return C_CART_FILL if h in cavities else C_EMPTY

    out = {}
    # 起点清空：四角与 12 格实心一起退回这个孔自己的底色
    for dr2, dc2 in CORNERS:
        out[(src[0] + dr2, src[1] + dc2)] = floor(src)
    for dr2, dc2 in PEG12:
        out[(src[0] + dr2, src[1] + dc2)] = floor(src)
    # 描边退回它盖住的那层
    under = C_CART_EDGE if src in cavities else 0
    for dr2, dc2 in OUTLINE16:
        r, c = src[0] + dr2, src[1] + dc2
        if 0 <= r < len(prev) and 0 <= c < len(prev[0]):
            out[(r, c)] = under
    # 所有环清掉——必须写在落点长灰之前：落点自己就是一个环，
    # 先画后擦会把刚长出来的那 8 格擦回底色（click_ring_jumps v5 踩过这个坑）
    for ring in rs:
        for dr2, dc2 in ((0, 1), (0, 2), (1, 0), (1, 3), (2, 0), (2, 3), (3, 1), (3, 2)):
            out[(ring[0] + dr2, ring[1] + dc2)] = floor(ring)
    # 落点长出灰团（12 格 →9）
    for dr2, dc2 in PEG12:
        out[(tgt[0] + dr2, tgt[1] + dc2)] = C_GREY
    # 计数条不预测（counter_advance 管）
    return out
