"""第 4、5 关，两帧都看不见载子滑车、且这一步的点击落点**离视口东缘还有两格以上**时，整幅画面一格都不滚——最齐的整体平移恒是 (0,0)。没有载子车时方向键推得动空车、点击点得动子，画面就是不滚；但子被送到视口东缘那一下不算，那一片镜头会滚，规矩还没量出来。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1 / ACTION2 / ACTION3 / ACTION4 / ACTION6；RESET 返回 NA。"
         "**ACTION7 返回 NA**（v4 缩掉的，理由见 NOTE：撤销要滚不滚取决于上一步是什么，"
         "而这条概念只拿得到 prev，看不出上一步）。"
         "换关（level_prev != level_next）返回 NA——换关整幅重画，谈不上对齐。"
         "只在第 4、5 关表态；别的关返回 NA（第 1/2/3 关镜头另有规矩，见 loaded_cart_column_pinned 的 NOTE）。"
         "**prev 或 nxt 任何一帧里 carts() 看得见一辆腔里含色14 的滑车，就返回 NA**——那一片归 "
         "loaded_cart_column_pinned 管，这条只管「一辆载子车都看不见」的那一片。"
         "**圆盘被吃掉的那一步返回 NA**（disc(prev) 有、disc(nxt) 没有）——那是整片盘区被换掉，"
         "和换关一样谈不上对齐，归 disc_click_consumes 管。"
         "**ACTION6 的点击落在屏幕列 ≥ EDGE_COL(=52) 时返回 NA**（v4 缩掉的那一片：实测镜头在那里会滚）。"
         "候选平移取行、列各属于 {0, ±6, ±8} 的 25 个，重叠不足 800 格的候选不参评；最齐的候选并列时返回 NA。")
NOTE = """
出处：这条是 loaded_cart_column_pinned 欠着的另一半。那条说「有载子车时，腔钉在屏幕第 28 列（第5关）」，
于是「没有载子车时镜头怎么办」一直没人管，而整个第 5 关能不能通关就压在这句话上：
镜头 = 载子车腔列 − 28，腔列的最大值是轨道东端，镜头因此有个上限；
如果没有载子车时镜头还能自己往东滚，这个上限就不存在，东边那片盘区就够得着。

**动手写之前先量**（`runs/…/probe_freeze.py`，全语料 1395 条去重转移）：
第 4/5 关、方向键、prev 与 nxt 两帧都找不到载子滑车的转移共 **97 条，平移 (0,0) 的 97 条，滚了的 0 条**。
帧差最大的几条（步2339 帧差244、步2352 帧差209、步2353 帧差204）都是空车在轨道上挪、
车身进出视口造成的大片变动，镜头一格没跟。

**它最可能怎么死，我先写在这里**：`carts()` 只看得见 64x64 视口里的车，而这个世界比视口大。
真有一辆载子车停在视口外、镜头跟着它滚，这条概念会把那一帧误判成「没有载子车」，当场判 FALSE。
这正是它值得写的理由——「视口不是世界」已经在这一局咬过两次
（board_replaced_iff_last_peg v5→v6、pegs() 数不到视口外的子），
与其把它当成一句我私下记着的注意事项，不如写成断言让世界去撞。
撞死了，我就知道镜头能在没有可见载子车时滚，第 5 关往东那条路重新打开；
撞不死，第 5 关「镜头上限 = 轨道东端腔列 − 28」这句话就有了两条腿。

**v2（扩到点击与 ACTION7）**：v1 只管方向键，于是「点一下会不会推镜头」还悬着——而整条
「东边那片盘区够不着」的推理要求镜头**只**由载子车决定，少一个动作没查就是少一条腿。
先量（`runs/…/probe_click_pan.py`）：帧差落在 60..1500 的 ACTION6 共 **13 条**（关1:5、关3:4、关5:2），
最佳整体平移**全是 (0,0)**，且 13 条的两帧都没有载子车。
其中第 5 关那两条 `ACTION6:41,19`（步2951、步3014）帧差 178，一度像是没人解释的镜头动作，
摊开看是「跳子 + 左下圆盘出现」（行51..63 列2..12 正是 `disc()` 描的那个圆盘），归 disc_only_on_dead_position 管。
帧差小于 60 的点击（选中 29、跳 45/57）没单独量——这条现在也替它们表态，判 TRUE 是廉价的，
但它们照样是能被推翻的断言：任何一条点击把画面推走，这条当场死。
扩的是动作轴，没扩关卡轴（第 1/2/3 关镜头另有规矩），一次只动一根轴，死了才知道是谁杀的。

**v2 当场被打死两次，v3 是补丁**：反例 450f37b2dcbfccc0（步2961 ACTION6:7,56 帧差2168）与
6cb9ee98a6fcf2be（步3015 ACTION6:6,54 帧差2155），两条都是**圆盘被吃掉**那一步。
它们的帧差都在 2150 格以上——整片盘区换掉，剩下的那点相同格子是噪声，
25 个候选里恰好有一个比 (0,0) 更"齐"，于是判 FALSE。这不是镜头滚了，是根本没有可对齐的东西，
和 SCOPE 里早就写着的「换关整幅重画，谈不上对齐」是同一件事，v2 漏掉了它的孪生兄弟。
补丁按已有原则收口：`disc(prev)` 有而 `disc(nxt)` 没有 → NA，交给 disc_click_consumes。
**v3 这次缩 scope 缩掉了什么，说清楚**：圆盘那一下画面到底滚没滚，这条概念从此不表态；
「第 5 关镜头上限」的论证因此不能拿圆盘当反证也不能当正证——圆盘那条路要单独查。

**v3 被打死，v4 是缩口——而且它死在自己写好的那句预言上，只是死因不是我猜的那个**：
反例 ee9cc1e9f655cdac（步4005 ACTION6:53,19 帧差1626）。当时盘上一辆载子车都没有（视口内视口外都没有），
镜头却从 106−44=62 一口气滚到 106。三个互相独立的锚一致：这一跳的落子 W 在世界(18,114) 现身于屏幕列 8；
早先在别的镜头下定位过的两颗子 P2 世界(48,126)、P3 世界(36,138) 分别现身于列 20、列 32。
114−8 = 126−20 = 138−32 = 106。石子(18,108)、踏板(24,108)、空车腔(30,108) 也都落在列 2。

**所以「镜头只跟载子车」是错的**：没有载子车时，镜头会跟自由子。上面 v1 那段
「镜头 = 载子车腔列 − 28，腔列有上限，所以第 5 关东边那片盘区够不着」的推理，**前提没了，结论作废**。
镜头一滚，这一关东边第一次露出来：行18 世界120..162 都是孔、世界(18,156) 还有一个车腔，
世界(24,162) 站着一颗**从没见过的子**。往东那条路是通的。

**新法则还量不出来，所以这一版只缩口不改主张。** 只有一个滚动样本，它同时符合至少两种读法：
(a) 镜头跟着动了的子走，把它摆到屏幕列 8；(b) 镜头想跟子走，但撞上了世界东端被钳住——
若世界宽 170，则镜头上限恰是 170−64=106。两种读法都解释得了这一条，要分开得再滚一次。
位移 +44 不是 STRIDE(6) 的倍数，这本身就说明镜头不是一格一格挪的，(b) 那种「钳住」更像。

**v4 缩掉了什么，说清楚**：
1. ACTION6 点击落在屏幕列 ≥ 52（离东缘不足两格）的那一片，这条从此不表态。
   门槛就取在实测那一条上（点击 x=53 → 列52），不多缩一格：列 46 那里若也滚，它该是下一条反例。
2. ACTION7 整个不表态。v2 特地把它扩进来过，理由是「谁也推不动镜头」；这个理由现在没了。
   撤销会不会滚镜头，取决于被撤销的那一步滚没滚，而这条概念只看得到 prev，看不出上一步是什么——
   看不出就别表态。这不是躲，是它真的缺输入。
3. 因此「第 5 关镜头有上限」这句话现在**一条腿都没有**了，不许再拿这条概念背书。
"""
EVIDENCE = [
    "442455249e983e76",  # 步2339 第4关 ACTION3 帧差244：空车挪动、车身进出视口，镜头一格不动
    "ebef2198b5672f22",  # 步2352 第4关 ACTION2 帧差209：同上，纵向
    "4d9dc7ce119b4cbf",  # 步2353 第4关 ACTION2 帧差204：同上
    "6d7c7527a413fdce",  # 步2351 第4关 ACTION2 帧差200：同上
    "7f91f83fe78d9960",  # 步2427 第4关 ACTION1 帧差149：同上
    "2ae807a0485757bc",  # 步3207 第5关 ACTION4 帧差135：第5关的空车东行，镜头不跟
    "faa6a2d293aecebd",  # 步3206 第5关 ACTION4 帧差131：同上
    "7615ae15de004ddd",  # 步2958 第5关 ACTION3 帧差121：同上，反方向
    "3000dbdd6e6a084a",  # 步2960 第5关 ACTION3 帧差121：同上
    "20e6e0a48ab01bca",  # 步2951 第5关 ACTION6:41,19 帧差178：跳子+左下圆盘出现，镜头不动（v2）
    "fbb41448c905ef05",  # 步3014 第5关 ACTION6:41,19 帧差178：同上（v2）
    "450f37b2dcbfccc0",  # 步2961 第5关 ACTION6:7,56 帧差2168：反例，点圆盘整片换盘，v3 缩成 NA
    "6cb9ee98a6fcf2be",  # 步3015 第5关 ACTION6:6,54 帧差2155：反例，圆盘复位整片换盘，v3 缩成 NA
    "ee9cc1e9f655cdac",  # 步4005 第5关 ACTION6:53,19 帧差1626：反例，无载子车而镜头 62→106，v4 缩成 NA
]

from _lib import SIZE, C_PEG, carts, disc

SHIFTS = (-8, -6, 0, 6, 8)
MIN_OVERLAP = 800
KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION6")
LEVELS = (4, 5)
EDGE_COL = 52          # 点击落在这一列或更东，这条不表态（v4）


def _key(action):
    head = action.split(":", 1)[0]
    if head.isdigit():
        head = "ACTION" + head
    return head


def _has_loaded(g):
    """视口里有没有一辆内腔含色14 的滑车。"""
    for (r, c) in carts(g):
        if any(g[r + dr][c + dc] == C_PEG
               for dr in range(SIZE) for dc in range(SIZE)):
            return True
    return False


def _mismatch(a, b, dr, dc):
    H, W = len(a), len(a[0])
    bad = tot = 0
    for r in range(1, H):
        rr = r - dr
        if not (1 <= rr < H):
            continue
        arow, brow = a[rr], b[r]
        for c in range(W):
            cc = c - dc
            if 0 <= cc < W:
                tot += 1
                if arow[cc] != brow[c]:
                    bad += 1
    return bad, tot


def _click_col(action):
    """ACTION6:x,y 的落点屏幕列（x-1）；不是点击返回 None，拆不出来也返回 None。"""
    if _key(action) != "ACTION6":
        return None
    if ":" not in action:
        return None
    body = action.split(":", 1)[1]
    parts = body.split(",")
    if len(parts) != 2:
        return None
    try:
        return int(parts[0]) - 1
    except ValueError:
        return None


def assert_(prev, action, nxt, ctx=None):
    if _key(action) not in KEYS:
        return "NA"
    if not ctx:
        return "NA"
    lp, ln = ctx.get("level_prev"), ctx.get("level_next")
    if lp != ln or lp not in LEVELS:
        return "NA"
    col = _click_col(action)
    if col is not None and col >= EDGE_COL:
        return "NA"                         # 视口东缘那一片镜头会滚，规矩未知（v4）
    if _has_loaded(prev) or _has_loaded(nxt):
        return "NA"                         # 有载子车，那一片不归这条管
    if disc(prev) is not None and disc(nxt) is None:
        return "NA"                         # 圆盘被吃掉：整片换盘，没有可对齐的东西
    best = None
    tied = False
    for dr in SHIFTS:
        for dc in SHIFTS:
            bad, tot = _mismatch(prev, nxt, dr, dc)
            if tot < MIN_OVERLAP:
                continue
            rate = bad / tot
            if best is None or rate < best[0] - 1e-12:
                best, tied = (rate, dr, dc), False
            elif abs(rate - best[0]) <= 1e-12 and (dr, dc) != (best[1], best[2]):
                tied = True
    if best is None or tied:
        return "NA"
    return "TRUE" if (best[1], best[2]) == (0, 0) else "FALSE"
