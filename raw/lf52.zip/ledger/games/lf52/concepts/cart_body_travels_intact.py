"""方向键让一辆滑车走一格时，它那 6x6 的车体**原样平移**：新位置框内每一格的颜色，等于 prev 里旧位置对应格的颜色——车框、内腔、腔里装的子或石子或踏板，一格不改地整体搬过去。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1/2/3/4；计数条没有正常推进一格时 NA；"
         "prev 或 nxt 里 carts() 找不到车时 NA；"
         "**镜头滚过就不表态**——去掉车腔之后的孔集合 prev 与 nxt 必须逐格相同，否则 NA（滚镜头时新旧坐标不可比）；"
         "这一步没有任何一辆车走动（没有 a 使得 a 在 prev 里、a+一格 在 nxt 里、a 不在 nxt 里）时 NA；"
         "**腔里那颗子被选中的车不表态**：prev 的 6x6 框里出现色3 就跳过这辆，全部被跳过就返回 NA。"
         "框被视口裁掉的那些格不比，只比 prev 与 nxt 两边都看得见的格。"
         "（**生成器比检查器窄一档**，是故意的、量过的：prev 里有**装着子的车这一步走得动**时 apply 整步不画，"
         "因为镜头会不会滚只在这一档里发生，而单帧读不出来。读数与理由见 NOTE v4。）")
NOTE = """
按方法册「想写的那条概念，先用探针在全语料上量一遍再写」办的：
`runs/…/probe_cart_body.py` 在去重 1602 条转移里挑出 365 条「没有镜头平移的挪车」转移、共 391 车次，
逐格比新旧两个 6x6 框：**对 390 次，错 1 次**。

错的那一次是第 3970 步（tid 569fc0f6d0516070，ACTION2，内腔在(30,28)），错的 20 格全是同一种错法：
色3 变色11 十六格、色3 变色12 四格——也就是那一步之前车里那颗子是**被选中**的，
框上本该是色11 的十六格被改画成了色3、四角的色12 也被改成色3（画法见 _lib.carts 的注）；
车一动，选中态就掉了，框和腔一起画回本色。所以这不是「车体没整体搬」，是「搬之前那身高亮被卸了」。
把它缩进 scope（prev 框里有色3 的车不表态）之后，同一批语料 390 比 0。
**这条负结果不许被读成「概念全对」**：它明说了自己管不着「带着选中态的车走一格」那一类，
而那一类恰恰是唯一一次它会说错的地方。反例 tid 569fc0f6d0516070 记进了 EVIDENCE，本条在它上面判 NA。

**它值多少**：这是本册第一条敢把挪车画出来的概念。探针同时量了它能解释多少帧差——
那 391 车次的新位置框内落在帧差里的格子共 13360 格，它说对 13340 格。
入册前全册 E = 10838/261070 = 0.042，挪车是帧差里最大的一块无人区（一次挪车一百二十格，语料里有几百次），
所以这一条应当把 E 推到大约 0.09。E 是全册唯一「写得越多越涨」的数，而在此之前三条 apply 全都只画点击。

写法上和 cart_moves_iff_rail_ahead 的分工：那条只说「什么时候动」，cart_slides_one_stride 只说「动就动一格」，
这条只说「动的时候画面上那块像素长什么样」。三条都不碰对方的断言。
apply 里要判断车会不会动，用的是和 cart_moves_iff_rail_ahead 同一套「去处内腔正中 2x2 是不是纯色5」的读法——
那段 _free/_ahead 是抄过来的，不是 import 的（概念文件各自独立）；抄的代价是它改了这里不会跟着改，
所以两处的读法哪天分了岔，settle 的冲突格会先报出来。

**入册当天量出来的一个自家缺陷，写在这里不删**：这个 apply 只画车到了新位置的 6x6 框，**不擦旧位置**。
单步预测无所谓（旧位置那些格子它不认领，算残差不算说错）；但 `bet --predict` 是**链式**的，
下一步的 prev 就是上一步的预测帧，旧位置那团车像素还留在里面，`carts()` 于是多认出一辆幽灵车。
第 4093 步起连发七个方向键，预测格数被实测打成 36, 36, 72, 108, 144, 180 —— 每多走一步多一辆幽灵。
所以那一批我把 --predict 撤了，改用文字押帧差：明知道要错的预测不产生信息。
补这个洞需要回答「车走了以后原地露出来的是什么」，那是另一条概念的事（猜是「前方那一格原先露着的东西」，
直轨上成立、岔口上多半不成立），没量过就不写进 apply —— 按方法册「先用探针在全语料上量一遍再写」。

**（第 4332 步后补）上面括号里那个猜想量了，死了：`runs/…/probe_uncover.py`，全语料 438 对
「A 走到 B」，A 在 nxt 里露出的 6x6 与 B 在 prev 里的 6x6 **一致 0 对、不一致 438 对**
（第3关96、第4关128、第6关205、第7关9）。连直轨上都不成立，所以不是「岔口的例外」，是整条错。
差的格数从 3 到 36 都有，众数是 5 和 16。**这条负结果留着，别再去试第二遍。**

死因看得见：轨不是按格点画的，它按 6 像素的节拍画，而车**不一定停在格点上**
（`_lib.carts` 的注记着全语料有 2547 个不在格点的腔）。于是我截的 6x6 跨在两个地形格中间，
A 的框和 B 的框相位不同，比的根本不是同一种东西的两份拷贝。
轨格本身也不是一种画法：`runs/…/probe_vacated.py` 在第 7 关数出 19 个纯轨格有 **12 种** 4x4 图案，
取决于四邻接不接轨。**拓扑 × 相位**，两个自由度都得知道才画得出来——
而 apply 只拿得到 prev 的像素，拓扑要靠推、相位要靠对齐，成本远超它能救回来的 9674 格。

所以「擦旧」这件事在本局**暂时放弃**，代价明写在这：
(a) 全册说错里 9674 格是它的，占 88%；(b) 连发方向键的 `--predict` 链式预测不可用，
那种批次一律撤掉逐格预测、改文字押帧差，且**不加 --strict**（明知要错的预测不产生信息）。
同一批里量到的一条正面读数倒是坐实了另一件事：腾出格的内腔 4x4 与纯轨格的 4x4 **4 种图案全部对得上**，
vacated_cart_cell_is_rail 的 NOTE 里那句「不许拿 2x2 外推到整格」的欠账，就此还清（还清的是读数，不是断言）。

**（第 4413 步后补）「给 apply 加一道滚镜头闸」这个念头量过了，死了，别再试第二遍。**
起因：第 4392 步和第 4413 步两次 `--strict` 都停在这条概念上，都是推载子车、镜头滚了、它画的车体整个错位。
`assert_` 早有滚镜头闸（去掉车腔的孔集合逐格比），`apply` 没有也不可能照抄——它只看得见 prev，
而「这一步会不会滚」是 nxt 才知道的事。prev 里读得出来的代理只有一个：**有没有装着子的车**
（camera_frozen_without_loaded_cart）。`runs/…/probe_pan_guard.py` 在去重语料 1121 条方向键转移上把它量成 2x2：

    prev无载子车 · 没滚   597 条   说对 10968   说错     0
    prev有载子车 · 没滚   307 条   说对 11862   说错     0
    prev有载子车 · 滚了   217 条   说对  2272   说错 10346

两头都读得很干净：**没有载子车就一次都不滚**（0/597，camera_frozen_without_loaded_cart 在这把尺下也站住了）；
而且**只要没滚，这个 apply 一格都没说错**（10968+11862 全对）——它的全部 10346 格错误集中在滚镜头那 217 条里。
但代理不准：有载子车时只有 **41.4%**（217/524）真的滚。于是「有载子车就整条不画」这道闸
**省下说错 10346 格，要赔掉说对 14134 格**——净亏 3788 格，还白丢一大块 E。所以不加。

留下的是一个更精确的问题，没答案：同样是「载着子的车走一格」，那 307 条为什么不滚、那 217 条为什么滚？
猜是世界比视口大不大（大才需要滚），但那是关卡属性，还没找到从单帧读出来的判据；
在找到之前，**带方向键的批次不加 --strict、也不发 --predict**（链式预测还会叠幽灵车，见上一段），
改成按 plan8.py 那张坐标表逐步用文字押帧差、结算后人工核对。

**（第 4528 步后补，v3：只改 apply，assert_ 一字未动）幽灵车那半句已经作废，另有一道闸补上。**
上一段说的「链式预测还会叠幽灵车」——因为这个 apply 只画车到了哪、不画原地变回什么——
由新入册的 vacated_cart_cell_holds_nothing 补掉了：它把腾出格行进轴上那条轨画成色5，
carts() 就认不出幽灵了。合起来在 1168 条方向键转移上，STEP 的八项读数 514 条全对；
262 条读错里 **228 条是滚镜头**（还是上面那个没答案的问题），镜头没滚的只剩 34 条。

那 34 条又拆出一道该加的闸，这次是加得起的。`runs/…/probe_step6.py`：其中 10 条是「多画了车」——
贴着视口边、去处落在视野外的那辆车，我把它留在了原地，可 nxt 里它没了。
根子在这里：`_free` 对它返回的是 **None（看不全，不知道）**，而 v2 的 `is not True: continue`
把「不知道」当成了「不动」。`runs/…/probe_edgecart.py` 在镜头没滚的转移上把这一格问清楚了：

    去处出界的车，nxt 里  不见了 11 条 · 还在原地 8 条

**11 比 8，它根本不是一条规律**——视口外有没有轨，单帧就是读不出来。
所以 v3 把三值当三值用：只要这一步里**有任何一辆车的 _free 返回 None**，整个动作返回 None 不画。
代价是这 19 条转移上规划器不再提议那个方向（宁可少提议一步，不可凭空提议一步），
换来的是它不再在这 11 条上给出一个假的下一帧。和上面那道滚镜头闸不同，这道闸赔得起：
它只在贴边且朝边走时闭合，不碰那 1100 多条正常转移。

**（第 4570 步后补，v4：又只改 apply，assert_ 一字未动）「有载子车就不画」那道闸的**收紧版**装上了。**
上面第 71 行写着「有载子车时只有 41.4% 真的滚，所以不加」——那道闸掐的是**有载子车**，
新这道掐的是**载子车这一步真的走得动**（`_free(...) is True`），窄一档。依据是
`runs/…/probe_panrule.py`：去重语料里 569 条「prev 有载子车」的方向键转移，按 (关, 走得动, 边缘)
分桶之后，**滚镜头一次都没出现在「载子车走不动」那些桶里**（约 100 条，pan 全是 (0,0)）。
所以这道闸不像老闸那样把不滚的那一大片一起赔掉。

`runs/…/probe_pan_guard2.py` 在全部 1194 条方向键转移上逐格对答案（1194 条里 469 条闸会闭合）：

    掐掉的那一档   说对 13990   说错 10694
    留下的那一档   说对 16236   说错     0

**净亏 3296 格 E，换来留下的那一档一格不错。**老闸净亏 3788 格且留下的那档本来就没错，
所以老闸买不到任何东西；这道买到的是「方向键上的预测再也不会打脸」——
终局卡上一格说错就是退出码 5 停批，而 E 只是个统计量。这是拿 E 换终局卡上的可发言性，明写在这儿。

**为什么不去把「滚不滚」读出来，而是闭嘴**：试过两个单帧判据，都在语料上垮了。
(1)「行进方向那一侧视口边缘三列/三行全是背景 ⇒ 夹住了不滚」——第 2 关 15 滚 / 12 不滚分得干干净净，
但第 3 关 ACTION2、第 4 关 ACTION3、第 7 关 ACTION2、第 8 关 ACTION4 都有「边缘全背景照样滚」的反例。
(2) 把它细化成「边缘往里数多少列是纯背景」（`probe_panmargin.txt`）：第 2 关西行 滚的 margin=0、
不滚的 margin=4；第 3 关西行 滚 0 / 不滚 7——看着像；可第 4 关西行 margin 0、4、10、16 **全都滚**，
第 8 关东行 margin 0、5、11、17 **全都滚**，边缘那几列只是「世界在这一侧画得稀」，不是「世界到头了」。
真正的变量是镜头位置相对世界宽度，而世界有多宽恰恰是视口里看不见的东西
（camera_pins_loaded_cart 的 NOTE 里已经把同一堵墙记过一次）。**看不见就不猜**，与上面那道 `_free is None` 闸同一个理由。
"""
EVIDENCE = [
    "13908aaa5be46fc3",  # 步4048 第6关 ACTION3：空车西移一格，帧差 122
    "7a1c6dff4834f9ae",  # 步4050 第6关 ACTION1：空车沿立柱上一格
    "2609ddd4fd876945",  # 步4038 第5关 ACTION2：载石车下一格，帧差 91
    "0557b7657c30bfdd",  # 步4039 第5关 ACTION2：同一辆再下一格，帧差 101
    "b03b82b293c83f47",  # 步4058 第6关 ACTION4：**载子**车东移一格，帧差 117
    "f0d420073f9fc08b",  # 步4086 第6关 ACTION2：载石车沿立柱下一格，帧差 107
    "dc31e0c63e41dd6e",  # 步3598 第5关 ACTION1：两辆车一起走一格，帧差 126
    "569fc0f6d0516070",  # 步3970 唯一的反例：腔里那颗子被选中，车一动高亮就掉了；本条在它上面判 NA
]

from _lib import SIZE, STRIDE, C_PEG, C_SEL, carts, holes, HOLE_COLORS, _CART_EDGE_OCCLUDERS

DELTA = {
    "ACTION1": (-STRIDE, 0),
    "ACTION2": (STRIDE, 0),
    "ACTION3": (0, -STRIDE),
    "ACTION4": (0, STRIDE),
}
BOX = SIZE + 2                       # 车框是 6x6
C_RAIL = 5
CART_COLORS = HOLE_COLORS | _CART_EDGE_OCCLUDERS


def _box(g, ir, ic):
    """内腔左上角 (ir,ic) 那辆车的 6x6 框：{(dr,dc): 颜色}，越界的格不收。"""
    H, W = len(g), len(g[0])
    out = {}
    for dr in range(BOX):
        for dc in range(BOX):
            r, c = ir - 1 + dr, ic - 1 + dc
            if 0 <= r < H and 0 <= c < W:
                out[(dr, dc)] = g[r][c]
    return out


def _selected_box(g, ir, ic):
    """这辆车身上有没有选中的高亮（色3）。"""
    return C_SEL in _box(g, ir, ic).values()


def _ahead(r, c, dr, dc):
    """去处内腔正中那 2x2 格；读法抄自 cart_moves_iff_rail_ahead。"""
    return [(r + dr + k, c + dc + j) for k in (1, 2) for j in (1, 2)]


def _free(g, A, a, dr, dc, seen=()):
    """a 这辆车沿 (dr,dc) 前方通不通：True / False / None（看不全）。"""
    H, W = len(g), len(g[0])
    cells = _ahead(a[0], a[1], dr, dc)
    if any(not (0 <= r < H and 0 <= c < W) for r, c in cells):
        return None
    cols = {g[r][c] for r, c in cells}
    if cols == {C_RAIL}:
        return True
    if cols <= CART_COLORS:
        b = (a[0] + dr, a[1] + dc)
        if b in A and b not in seen:
            return _free(g, A, b, dr, dc, seen + (a,))
    return False


def assert_(prev, action, nxt, ctx=None):
    key = action.split(":", 1)[0]
    if key not in DELTA:
        return "NA"
    if sum(1 for x, y in zip(prev[0], nxt[0]) if x != y) != 1:
        return "NA"
    A, B = carts(prev), carts(nxt)
    if not A or not B:
        return "NA"
    if set(holes(prev)) - A != set(holes(nxt)) - B:
        return "NA"                      # 镜头滚了或换了盘，新旧坐标不可比
    dr, dc = DELTA[key]
    said = False
    for a in A:
        b = (a[0] + dr, a[1] + dc)
        if b not in B or a in B:
            continue                     # 这辆没走动
        if _selected_box(prev, *a):
            continue                     # 带着选中态的车不表态
        said = True
        src, dst = _box(prev, *a), _box(nxt, *b)
        for k in set(src) & set(dst):
            if src[k] != dst[k]:
                return "FALSE"
    return "TRUE" if said else "NA"


def _loaded(g, ir, ic):
    """这辆车的内腔 4x4 里有没有子（色14）。读法与 camera_pins_loaded_cart._loaded 相同。"""
    H, W = len(g), len(g[0])
    return any(g[ir + i][ic + j] == C_PEG
               for i in range(SIZE) for j in range(SIZE)
               if 0 <= ir + i < H and 0 <= ic + j < W)


def apply(prev, action, ctx=None):
    key = action.split(":", 1)[0]
    if key not in DELTA:
        return None
    A = carts(prev)
    if not A:
        return None
    dr, dc = DELTA[key]
    H, W = len(prev), len(prev[0])
    out = {}
    for a in A:
        if _free(prev, A, a, dr, dc) is None:
            return None                  # 有车的去处在视口外：走不走单帧读不出（11 走 8 留），整步不画
    for a in A:
        if _loaded(prev, *a) and _free(prev, A, a, dr, dc) is True:
            return None                  # 载子车这一步真要走：镜头可能整幅滚，单帧读不出（NOTE v4），整步不画
    for a in A:
        if _selected_box(prev, *a):
            continue
        if _free(prev, A, a, dr, dc) is not True:
            continue                     # 前方不通就不动，这条不画
        b = (a[0] + dr, a[1] + dc)
        for (kr, kc), col in _box(prev, *a).items():
            r, c = b[0] - 1 + kr, b[1] - 1 + kc
            if 0 <= r < H and 0 <= c < W:
                out[(r, c)] = col
    return out or None
