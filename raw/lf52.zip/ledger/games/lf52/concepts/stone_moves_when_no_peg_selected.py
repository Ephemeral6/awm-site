"""选中的是一颗石子时点它的一个环，动的是石子：它跨过相邻的可跨者落到那个环上，棋子一颗不少、一颗不挪，被跨的东西原样留着。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 点中 prev 里的一个环、且 prev 里 selected() 落在 stones() 上的转移；"
         "孔集合变了（换盘/过关/镜头平移）返回 NA；其余 NA")
NOTE = ("v1 用「selected() 为 None 且恰有一颗石子隔着一个可跨者」来认石子跳，结果在自己的四条 EVIDENCE 上全判 NA："
        "石子块是色8，当时不在 HOLE_COLORS 里，石子一动 holes() 就变、第一道 NA 出口就关上了。"
        "第 3125 步把色8 收进孔色（全语料 155 帧量过，多出来的孔恰好等于 stones()），"
        "selected() 从此能读到被选中的石子，v2 直接按选中物是石子来认。"
        "石子和子一样能被点、能跳（点它出 20 格高亮 + 环），跨过子不吃子（第 2920、3125 步），"
        "还能跨过载子车跳进空车腔（第 3105 步）。第5关开局全册 all_jumps 只有一条，石子自己走才是这一关的引擎。"
        "\nv2→v3 只加了一个 apply，断言一字未动。由来：第 3151 步链式预测 28 格只对 20 格，8 格全错在环上——"
        "不是断言错，是第 3150 步的石子跳**没有任何概念敢生成**，"
        "喂给下一步的模型帧里石子还停在 (42,18)，click_selects_peg 于是把落点环画到了 (42,12) 而不是真的 (42,36)。"
        "一条概念闭嘴，会把它后面每一步的预测一起带歪，这是 --predict 链上最贵的一种沉默。")
EVIDENCE = [
    "7eeb2911708af605",  # 步2920 石子 (18,18) 跨子 (24,18) 落 (30,18)，子未少
    "6f2319b34f97e855",  # 步2924 (30,18)→(42,18)
    "e52d6fb272409e34",  # 步2932 (42,18)→(42,30)
    "926e3a0ea24cfda8",  # 步2936 (42,30)→(42,42)
    "6e64e8dc62c6a0e5",  # 步3105 石子 (42,22) 跨载子车 (42,28) 跳进空车腔 (42,34)
    "ee0d030f7cd56a98",  # 步3125 石子 (18,10) 跨子 (18,16) 落 (18,22)，另一个环 (30,10) 一并清掉
    "62c4e3314698e1e2",  # 步3150 石子 (42,18) 跨子 (42,24) 落 (42,30)，帧差 45 —— v3 的 apply 照着它拆的
    "c1ffe038e775efd0",  # 步3154 石子 (42,30) 跨子 (42,36) 落 (42,42)，同上
]

from _lib import (holes, pegs, rings, selected, stones, steps, click_target, carts,
                  CORNERS, EDGE8, OUTLINE16, PEG12, C_EMPTY, C_SEL, C_STONE)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    if holes(prev) != holes(nxt):
        return "NA"
    tgt = click_target(prev, action)
    if tgt is None or tgt not in rings(prev):
        return "NA"
    s = selected(prev)
    if s is None or s not in stones(prev):
        return "NA"
    if set(stones(nxt)) != (set(stones(prev)) - {s}) | {tgt}:
        return "FALSE"
    if set(pegs(nxt)) != set(pegs(prev)) or steps(nxt) != steps(prev):
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """石子跳：起点 12 格 8→1、四角与描边收回选中色，落点 12 格画成色8，其余的环清掉。

    45 格 = 16 描边 + 4 角 + 起点 12 + 落点 12 + 1 计数条（计数条归 counter_advance）。
    只在起点是**普通孔**（不是车腔）时生成——车腔的底色是色12 不是色1，
    「收回选中色」该收成什么，这条概念答不上来，答不上来就闭嘴。
    """
    if not action.startswith("ACTION6:"):
        return None
    tgt = click_target(prev, action)
    if tgt is None or tgt not in rings(prev):
        return None
    s = selected(prev)
    if s is None or s not in stones(prev):
        return None
    cs = carts(prev)
    if s in cs:
        return None
    H, W = len(prev), len(prev[0])
    out = {}
    # 起点：石子那 12 格退回空孔底色
    for dr, dc in PEG12:
        out[(s[0] + dr, s[1] + dc)] = C_EMPTY
    # 选中标记退场：只改那些**现在确实是色3** 的格子，别的不碰
    for dr, dc in CORNERS:
        r, c = s[0] + dr, s[1] + dc
        if prev[r][c] == C_SEL:
            out[(r, c)] = C_EMPTY
    for dr, dc in OUTLINE16:
        r, c = s[0] + dr, s[1] + dc
        if 0 <= r < H and 0 <= c < W and prev[r][c] == C_SEL:
            out[(r, c)] = 0
    # 落点：12 格画成石子（车腔里也是这 12 格，四角留车腔底色，所以不碰四角）
    for dr, dc in PEG12:
        out[(tgt[0] + dr, tgt[1] + dc)] = C_STONE
    # 没被选中的那些环清回空孔；车腔里的环底色不是色1，不表态
    for ring in rings(prev):
        if ring == tgt or ring in cs:
            continue
        for dr, dc in EDGE8:
            out[(ring[0] + dr, ring[1] + dc)] = C_EMPTY
    return out
