"""第 7 关按方向键的那一步，镜头要么一格不滚，要么整幅画面原样平移一个 STRIDE：只有「纵向键（ACTION1/ACTION2）+ 画面里恰好一辆载子车 + 那辆车正前方一格是轨」时镜头才滚，方向与键相反；横向键、以及车动不了的时候，一格不滚。滚的时候是逐格的原样搬运——车框外扩两像素之外，**世界那一层**里 nxt 每一格的颜色等于 prev 里往回一个 STRIDE 的那一格；第 0 行是计数条、第 0 列同样不算世界，它们既不当终点也不当源点。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1/2/3/4，且 prev 与 nxt 都在第 7 关（换关返回 NA）。"
         "prev 里有两辆或更多载子车时返回 NA——镜头跟谁走没有定义。"
         "载子车正前方那 2x2 被视口裁掉、看不全时返回 NA。"
         "实测位移解不出唯一值时返回 NA（用不在车腔里的踏板与灰团反解，少于 3 块锚或候选打平都算解不出）。"
         "断言分两半，都在 assert_ 里查：**滚多少**（预测位移必须等于实测位移）与"
         "**怎么搬**（位移非零时逐格比对，跳过第 0 行、第 0 列**以及源点落在第 0 行、第 0 列的格**，"
         "跳过任一车框外扩 2 像素的邻域，跳过平移后源点落在画面外的格）。"
         "两半说的是同一件事——这一步镜头把画面搬到哪，所以算一条。")
NOTE = """**先量后写**（方法册「想写的那条概念，先用探针在全语料上量一遍再写」）。
三支探针，结论逐条列出来，包括不利的那条：

`runs/…/probe_pan.py`，全去重语料 1855 条，方向键逐条反解镜头位移：
    镜头滚过 **22** 次，位移取值只有 (0,-6)、(0,6)、(-6,0) 三种 —— **幅度恒等于一个 STRIDE，一次例外都没有**。
    (+6,0) 一次都没出现过：ACTION1 带着载子车至今没按过（第 7 关、第 3 关都没有）。
    没有载子车的方向键 **155 次全部不滚**（这半句 camera_frozen_without_loaded_cart v4 已经在说了，这里不重复断言）。
    有载子车时滚不滚**按关卡分家**：第 6 关 55 次带载全不滚；第 7 关纵向键带载会滚、横向键带载 5 次全不滚；
    第 3 关三个键都滚过一部分（ACTION2 4/5、ACTION3 8/20、ACTION4 6/12）。

`runs/…/probe_pan2.py`，滚了的那 22 条，车框以外差了 1377 格：
    543 格在第 0 行或第 0 列（HUD 与那根逐步推进的计数条，它们不跟着世界滚）；
    834 格颜色对全是 5↔10、9↔10、5↔9 —— 轨/墙、背景、以及**轨的花纹里那个色9**（色9 既是灰团也是轨纹，
    这是本局词汇的一个陷阱，greys() 认灰团靠的是别的判据，但肉眼看帧差时极易看错）。
    「选中态」那一类数出来是 0 格。

`runs/…/probe_pan3.py`，把那 834 格量到最近车框的切比雪夫距离：
    **距离 1 有 582 格，距离 2 有 252 格，距离 3 及以上一格都没有。**
    所以轨怎么画只跟「车压在它旁边没有」有关，影响半径恰好 2 像素。
    车框再向外让 2 像素之后：**说错 0 格**，仍然认领得下一万七千多个帧差格。
    （探针只试了 R=0,3,6,…；R=3 已经是 0 说错，R=2 是量出来的边界，取 2 是取那个边界本身。）

**它凭什么值一条概念**：pan_opposes_key_axis 是全册覆盖第二高的概念（C=0.592 N=1091），
但它只说镜头往哪个方向滚，**不说幅度、也没有 apply**。镜头一滚就是整屏两三千格帧差，
那是规则图 E 上最大的一块无人区——入册前全册 E = 38528/304416 = 0.127，
光第 7 关这 4 条滚镜头的转移就有 4744 个帧差格是这条能解释的。

**apply 比 assert_ 窄，窄在哪、为什么，明写在这**：
(a) apply 看不见 nxt，所以它只在**能从 prev 算出位移**的时候画，也就是上面那条「纵向键 + 一辆载子车 + 前方是轨」；
    算出来是不滚就干脆不画（不滚的帧本来也没有帧差格可赚）。
(b) apply 在**新内容进来的那条边**额外让出 STRIDE + 6 像素不认领。理由是探针的排除集里含 carts(nxt)，
    而 assert_ 看得见 nxt、apply 看不见：镜头往南滚的时候会有整辆车从视口下方升进画面
    （第 4291 步就发生过），那辆车在 prev 里根本不存在，探针把它算进排除集因而没数到它，
    apply 要是照搬就会拿旧内容去画一辆新出现的车。**这是探针的排除集替 apply 掩盖过的一个洞，
    写在这里免得以后有人把那条边加回来。**

**下一块更大的肉，连同该跑的探针一起记在这**：第 3 关滚了 18 次、能解释 15960 个帧差格，
是第 7 关这块的三倍多，但这条概念够不着——它按「纵向键 + 车前方是轨」预测滚不滚，
而第 3 关**横向键也滚**，且同一个键有时滚有时不滚。
一个还没量过的猜想：镜头把载子车居中、撞到世界边界就夹住，于是**载子车停在「居中位」上时按键才滚，
被夹住的时候是车在屏幕上自己走**。probe_row.py 的读数和它对得上——第 3 关载子车的屏幕行只取 {18,24,30}，
而 30 正是 64 宽视口里 4 格宽物件的居中位；第 7 关行恒 36 则是另一个常数。
该跑的探针：第 3 关每条带载方向键转移，列「载子车屏幕行/列 × 键 × 滚没滚」，看有没有干净的阈值。
**没量之前不写进任何断言**，和 loaded_cart_row_pinned 里那个同源猜想一样的处理。

**预注册两条死法**（写在前面，死的时候该被读成量到了一个参数，不是又押错了）：
1. 通关路线第 4 步是 ACTION2，载子车从世界行 60 走到 66，镜头偏移要从 24 走到 30。
   如果镜头在世界底边夹住、这一步不滚，这条判 FALSE —— 和 loaded_cart_row_pinned 预注册的那条是**同一个事件**，
   两条会同时倒。夹点在哪是我目前缺的参数，只有撞上去才知道。
   **（第 4342 步结果）没倒。** 镜头照滚 (-6,0)，偏移 24→30，载子车屏幕行仍是 36。
   押注预测 2729 格、对 2693 格，错的 36 格全在 `cart_body_travels_intact` 画的车框上（它看不见镜头，
   把车身画在屏幕 (42,24)，而车留在 (36,24)）——押注原文里已经预告了这一块，本条自己**一格没说错**。
   同一批结算里这条第一次拿到分数：**P=1.000，认领 2693 格，说对 2693，说错 0**，全册 E 0.127 → 0.130。
   顺带量到一个参数：视口此刻显示世界行 30..93，而世界行 84 起已经是背景——**镜头会越过世界底边继续滚，底边不夹**。
   这条 tid **不进 EVIDENCE**：它是押注先于事实做出的预测，进了 EVIDENCE 就不再是 held-out，这场考试就白考了。
2. 路线第 16 步是 ACTION1 带载 —— 全语料里 (+6,0) 这个位移**一次都没出现过**。
   这条概念在那一步预测镜头往北滚一格，纯属由对称性外推。外推错了就该倒。

---
**v2（入册后第一次改，没有反例，改的是锚集与记账）**

(1) `_measure` 加了一级备胎锚：踏板解不出位移时，把灰团也收进锚集再解一次。
    起因：`runs/…/probe_anchor.py` 在按第 4 步之前先算了一遍，
    末帧（第 4341 步后）不在车腔里的踏板只剩 3 块 `(6,48) (12,18) (12,42)`，
    镜头一往北搬 6 行，`(6,48)` 被推到第 0 行、出了边距，只剩 2 块 < MIN_MATCH=3 —— 位移解不出来。
    也就是说这条概念会在**它自己预注册的那场考试上判 NA**，白考一场；stitch7 同样接不上地图。
    第一版改法是无条件把灰团当锚，**当场回归失败**：灰团会跳，拼图脚本在第 4305 步
    （一次灰团跳跃）正向包含不成立，从 113 帧退回 40 帧。所以灰团只当备胎——
    踏板不够用的那一步按的是方向键，那时灰团不动。改成两级之后拼图仍是 113 帧、地形 165 格。
    收进灰团后第 4 步那个位移有 5 块锚，而 (0,0) 仍被排除（`(6,48)` 在 nxt 里不存在）。
    「方向键下灰团不动」和「踏板不动」一样是**读法上的假设**，不是本概念的断言。
    方法册条目：**「锚集要在按键之前算一遍，别等镜头搬完才发现参照物被推出画面」**，
    以及**「补锚要挑不会动的：拿会动的当参照物，是同一个错误的第三次」**。

(2) settle_66 那行 `P= -  认领 0 格` 不是 bug。`runs/…/probe_apply_dbg.py` 手工喂 ctx 跑出来
    `apply(ctx={'level_prev':7,'level_next':7}) -) 2923 格`、`assert_ -) TRUE`，生成器是好的。
    认领 0 格的原因是**全语料里那 4 条滚镜头的第 7 关转移，被我自己一条不剩地写进了 EVIDENCE**，
    held-out 里一条会开火的转移都不剩。台架在如实说：这条概念还没在没见过的转移上被考过。
    **不为了刷 P 去删 EVIDENCE**——那 4 条确实是它的依据。分数要等路线第 4 步那条新转移。

---
**v4（第 4359 步，预注册死法 #2 到期：(+6,0) 第一次出现，这条当场判 FALSE 关闸）**

死法 #2 原文写的是「路线第 16 步是 ACTION1 带载 —— 全语料里 (+6,0) 这个位移一次都没出现过，
这条概念在那一步预测镜头往北滚一格，纯属由对称性外推。外推错了就该倒。」
第 4359 步就是那一步。**外推没错，垮的是另一半**，而这正是把两半分开写在 SCOPE 里的好处：

    实测位移 _measure = (6, 0)      ← 全语料第一次出现这个方向
    概念预测 _expect  = (6, 0)      ← 「滚多少」那一半一格不差，对称性外推成立
    assert_ = FALSE                 ← 垮在「怎么搬」那一半

`runs/…/probe_pan4359.py` 把逐格比对的失配打了出来：**37 格，全部落在同一行——屏幕第 6 行**。
原因一句话讲得完：位移是 +6，屏幕第 6 行的源点是 prev 的**第 0 行**，而第 0 行是计数条（HUD），
它钉在屏幕上、不跟着世界滚。旧代码在 nxt 那一侧跳过了第 0 行，却没在 prev 那一侧跳过它——
**一侧坐标用了一把尺子，另一侧用了另一把**（方法册「可比性判据要在一侧坐标里做一次」说的就是这个）。
此前 22 次平移全是 (-6,0) 或 (0,±6)：源点行 = R+6，永远碰不到第 0 行，所以这个洞一直藏着。
**只有 (+6,0) 这个方向能把它照出来**，而这个方向正是死法 #2 预注册的那个。

改法：逐格比对里加一句「源点落在第 0 行或第 0 列就跳过」。这是把已有的排除条款做成对称，
不是按反例裁 scope——第 0 行本来就不是世界内容，断言从来没打算管它。
**这次改版的代价**：滚进来的那条边上，世界第一行的 37 格不再被这条概念核对（它们的源点在画面外或在 HUD 上）。
`apply` 早就不认领这一片（它有 `edge = STRIDE + BOX` 的让边，所以这一步生成器 2452 格一格没说错，
是检查器比生成器更宽——方法册「检查器与生成器 scope 必须一样宽」的反向那一种，这次修的就是它）。

附带量到的世界事实（这一步顺手确认，不写进断言）：
    镜头确实会往北滚，方向仍与键相反；本关偏移从 30 回到 24。
    帧差 1673 格，比南行时的两千多小，因为露出来的世界上沿多半是背景色10。
    计数条走到屏幕第 0 行的末尾会**回卷重画**：第 4352 步之后从 (63,0) 绕回 (0,0)，颜色由 1 变 2。

**（第 4361 步）v4 的修补在 held-out 的同一个方向上受了考，没倒。**
那一步又是 ACTION1 带载（载子车世界行 60→54，偏移 24→18），全语料第二次出现 (+6,0)——
也是 v4 改完之后第一条它没见过的、能照出那个洞的转移。押注里写明了「修对了就判 TRUE、apply 说错 0；
还判 FALSE 就说明洞不止一处，得再 probe 而不是接着改」。结果：**assert_ = TRUE，
apply 认领从 2693 涨到 5151 格、说对 5151、说错 0。** 这条 tid 不进 EVIDENCE（held-out 才有考试的意义）。
同一步落空的那 24 格是 `cart_body_travels_intact` 画的车框（它看不见镜头，把车画在没滚过的屏幕行 29..34），
押注里预告过，本条自己一格没说错——和第 4342 步同一个形状，第三次了。
**这也是「一个洞被一个方向照出来之后，该等它第二次出现再宣布修好」的一次实例**：
修补当批的那条转移已经进了 EVIDENCE，在它上面判 TRUE 是自证；真正的证据是这一条。

---
**v5（第 4528 步，只改 NOTE，不动一行代码）——把上面那个猜想标记成已经死了的**

NOTE 里「下一块更大的肉」那一段挂着一个猜想，原文是：
「镜头把载子车居中、撞到世界边界就夹住，于是**载子车停在『居中位』上时按键才滚，
被夹住的时候是车在屏幕上自己走**」，还附了它的支持读数（第 3 关屏幕行只取 {18,24,30}，
30 是 64 宽视口里 4 格宽物件的居中位）。那一段末尾写着「该跑的探针：第 3 关每条带载方向键转移，
列『载子车屏幕行/列 × 键 × 滚没滚』，看有没有干净的阈值」。**那个探针跑了，猜想的前半句垮了。**

`runs/…/probe_pancenter.py` 跑出来的不是阈值，是**定值**：同一关同一个键，镜头一滚，
载子车在那个轴上的屏幕坐标就恒等于一个数——第 3 关 ACTION3 恒 39、ACTION4 恒 18、
第 5 关恒 28、第 8 关恒 22、第 7 关恒 36。**没有一个是居中位 30**，而且同一关两个键是两个数，
「居中」解释不了这件事。`runs/…/probe_rollwhen.py` 又把「车在居中位」当判据正面打了一次分：
**真阳 15、假阳 26、漏报 130**。前半句到此为止。

后半句（撞到世界边界就夹住）**活着，而且是目前唯一像话的那条**：同一支探针里
「前进方向最外 6 条不全是背景 → 会滚」得 137/129/8，那 129 个假阳几乎全在「这一轴从不滚」的关里；
而在唯一一个真正混着的（关,键）上——第 3 关 ACTION3——它零交叉地分开了 8 条滚和 12 条不滚。

「定值」这件事本身已经有了一个不需要表的解释，写成了新概念 `camera_pins_loaded_cart`
（**镜头跟着载子车走，所以车在屏幕上一格不动**；141/145，4 条反例全在第 2 关，那里位移是 8 不是 6）。
车没动，坐标当然每次都一样——各关那些不同的常数于是全变成推论，不再是规则。

**对本概念的影响：一行代码都不用改，但要知道自己窄在哪。**
`_expect` 现在这个写法（「纵向键 + 一辆载子车 + 前方是轨 → 滚 (-dr,0)」）在第 7 关是对的，
而它的「滚多少」那一半其实**和关卡无关**——`camera_pins_loaded_cart` 在六个关上量出同一句话。
真正只在第 7 关成立的是「**横向键不滚、纵向键滚**」这半句：第 4、5、8 关正好相反（横向滚、纵向不滚），
第 3 关两个轴都滚，第 1、6、9 关四个键全不滚。所以 `ctx["level_prev"] != 7 → NA` 这道闸
**不是保守，是必需**：照搬到别的关会把滚不滚判反。
放开它要等「滚不滚」有一条只读 prev 的判据，那是 `camera_pins_loaded_cart` 的 NOTE 里点名欠的账。
在那之前，规划器靠 `runs/…/plan.py` 的外层驱动绕过去（发一个键、吃一步落空、从真帧重新规划），
代价明写在那里。
"""
EVIDENCE = [
    "37a105c0c3144154",  # 步4325 ACTION2 载子车南行，镜头位移 (-6,0)，整帧原样搬
    "43925a36ec926c50",  # 步4326 同上
    "6f430176af2e76c2",  # 步4327 同上
    "de9faa063f473a5e",  # 步4328 同上
    "7ee7f5c276ea06ee",  # 步4338 ACTION2 但载子车南边是背景、它动不了 —— 镜头也不滚，这是"不滚"那一支
    "6800ba1262922b73",  # 步4337 ACTION3 横向键带载：不滚
    "484a53ef060d4d28",  # 步4339 ACTION4 横向键带载、车确实走了一格：仍不滚
    "6cc6e9a990f8ef34",  # 步4340 同上
    "eec46eabab664964",  # 步4341 同上
    "8d6318dd0001130e",  # 步4359 ACTION1 载子车北行，位移 (+6,0) —— **打死 v3 的那一条**；
                         #   「滚多少」这一半在它上面是对的，垮的是拿 prev 第 0 行（计数条）当源点去比
]

from _lib import (SIZE, STRIDE, C_PEG, carts, steps, greys,
                  HOLE_COLORS, _CART_EDGE_OCCLUDERS)

C_RAIL = 5
BOX = SIZE + 2            # 车框 6x6
PAD = 2                   # 车框外再让 2 像素：轨的花纹受车影响的半径（probe_pan3 量的）
MIN_MATCH = 3
SHIFTS = (-12, -8, -6, 0, 6, 8, 12)
DELTA = {"ACTION1": (-STRIDE, 0), "ACTION2": (STRIDE, 0),
         "ACTION3": (0, -STRIDE), "ACTION4": (0, STRIDE)}
CART_COLORS = HOLE_COLORS | _CART_EDGE_OCCLUDERS


def _loaded(g):
    """腔里含色14 的滑车的内腔左上角集合。读法与 loaded_cart_row_pinned 相同（抄的，不是 import 的）。"""
    out = set()
    for (r, c) in carts(g):
        if any(g[r + dr][c + dc] == C_PEG
               for dr in range(SIZE) for dc in range(SIZE)):
            out.add((r, c))
    return out


def _ahead(r, c, dr, dc):
    return [(r + dr + k, c + dc + j) for k in (1, 2) for j in (1, 2)]


def _free(g, A, a, dr, dc, seen=()):
    """a 这辆车沿 (dr,dc) 走不走得动：True / False / None（前方被视口裁掉）。
    读法抄自 cart_moves_iff_rail_ahead v3，抄的代价是那边改了这里不会跟着改。"""
    H, W = len(g), len(g[0])
    cells = _ahead(a[0], a[1], dr, dc)
    if any(not (0 <= r < H and 0 <= c < W) for r, c in cells):
        return None
    cols = {g[r][c] for r, c in cells}
    if cols == {C_RAIL}:
        return True
    if cols <= CART_COLORS:
        b = (a[0] + dr, a[1] + dc)
        if b in A and b not in seen:
            return _free(g, A, b, dr, dc, seen + (a,))
    return False


def _measure(prev, nxt):
    """用**不在车腔里**的踏板反解实测位移；踏板不够用时把灰团也收进锚集。解不出或不唯一返回 None。
    车上的踏板会跟着车走，拿它当锚等于拿会动的东西当参照物（第 4337 步就是这么栽的）。

    v2 加了灰团这一级备胎。只用踏板的话第 4341 步之后只剩三块固定踏板，
    镜头再往北搬一个 STRIDE 就有一块被推出边距，锚不足 3 块、位移解不出来——
    这条概念会在它自己预注册的那场考试（路线第 4 步）上判 NA，白考一场。
    但**灰团会跳**，所以不能无条件当锚（拼图脚本上试过，一次灰团跳跃当场解不出位移）；
    只在踏板解不出来时才用，而那种时候按的是方向键、灰团不动。
    「方向键下灰团不动」是读法上的假设，和「踏板不动」同等地位，不是这条概念的断言。"""
    for extra in (False, True):
        out = _solve(prev, nxt, extra)
        if out is not None:
            return out
    return None


def _solve(prev, nxt, extra):
    A, B = set(carts(prev)), set(carts(nxt))
    sa = set(steps(prev)) - A
    sb = set(steps(nxt)) - B
    if extra:
        sa |= set(greys(prev)) - A
        sb |= set(greys(nxt)) - B
    if not sa or not sb:
        return None
    h, w = len(nxt), len(nxt[0])
    best = []
    for dr in SHIFTS:
        for dc in SHIFTS:
            inside = [(r + dr, c + dc) for r, c in sa
                      if 1 <= r + dr <= h - SIZE - 1 and 1 <= c + dc <= w - SIZE - 1]
            if len(inside) < MIN_MATCH or not set(inside) <= sb:
                continue
            best.append((len(inside), (dr, dc)))
    if not best:
        return None
    best.sort(reverse=True)
    if len(best) > 1 and best[0][0] == best[1][0]:
        return None
    return best[0][1]


def _expect(prev, key):
    """只看 prev 就算得出来的那一半：这一步镜头该滚多少。None = 说不好。"""
    dr, dc = DELTA[key]
    ld = _loaded(prev)
    if len(ld) > 1:
        return None                      # 两辆载子车时镜头跟谁没有定义
    if dc != 0 or not ld:
        return (0, 0)                    # 横向键不滚；没有载子车不滚
    f = _free(prev, carts(prev), ld.pop(), dr, dc)
    if f is None:
        return None
    return (-dr, 0) if f else (0, 0)


def _anchors(prev, key, shift):
    """哪些位置上可能有车框：原地、按键走一格、被镜头搬一格、两者都。"""
    kr, kc = DELTA[key]
    sr, sc = shift
    out = set()
    for (r, c) in carts(prev):
        out |= {(r, c), (r + kr, c + kc), (r + sr, c + sc),
                (r + kr + sr, c + kc + sc)}
    return out


def _near(anchors, R, C):
    """(R,C) 是否落在某个车框外扩 PAD 像素的邻域里。车框 = [r-1, r+4] x [c-1, c+4]。"""
    for (ar, ac) in anchors:
        dv = max(0, (ar - 1) - R, R - (ar + SIZE))
        dh = max(0, (ac - 1) - C, C - (ac + SIZE))
        if max(dv, dh) <= PAD:
            return True
    return False


def assert_(prev, action, nxt, ctx=None):
    key = action.split(":", 1)[0]
    if key not in DELTA:
        return "NA"
    if not ctx or ctx.get("level_prev") != 7 or ctx.get("level_next") != 7:
        return "NA"
    exp = _expect(prev, key)
    if exp is None:
        return "NA"
    got = _measure(prev, nxt)
    if got is None:
        return "NA"
    if got != exp:
        return "FALSE"
    if exp == (0, 0):
        return "TRUE"
    dr, dc = exp
    h, w = len(nxt), len(nxt[0])
    anch = _anchors(prev, key, exp) | set(carts(nxt))
    for R in range(1, h):
        for C in range(1, w):
            sr, sc = R - dr, C - dc
            if not (0 <= sr < h and 0 <= sc < w):
                continue
            if sr == 0 or sc == 0:
                continue                 # 源点落在计数条那一行/列上——HUD 不是世界内容，见 v4
            if _near(anch, R, C):
                continue
            if nxt[R][C] != prev[sr][sc]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    key = action.split(":", 1)[0]
    if key not in DELTA:
        return None
    if not ctx or ctx.get("level_prev") != 7:
        return None
    exp = _expect(prev, key)
    if exp is None or exp == (0, 0):
        return None
    dr, dc = exp
    h, w = len(prev), len(prev[0])
    anch = _anchors(prev, key, exp)
    edge = STRIDE + BOX                  # 新内容进来的那条边，多让一个车身
    out = {}
    for R in range(1, h):
        if (dr < 0 and R >= h - edge) or (dr > 0 and R < edge):
            continue
        for C in range(1, w):
            if (dc < 0 and C >= w - edge) or (dc > 0 and C < edge):
                continue
            sr, sc = R - dr, C - dc
            if not (0 <= sr < h and 0 <= sc < w):
                continue
            if _near(anch, R, C):
                continue
            out[(R, C)] = prev[sr][sc]
    return out or None
