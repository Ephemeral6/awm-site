"""再点一次已经选中的那个子，什么也不会发生——行1 以下整帧不动，选中不会被取消。"""
LEVEL = "L2"
SCOPE = "只看 ACTION6 点中的孔正好是 prev 里那个唯一的选中孔的转移；其余 NA。计数条没有正常推进一格（重开/换关）返回 NA。"
NOTE = "选中不是开关：点第二次不会取消。要取消得去点一个跳不动的子（见 click_stuck_peg_deselects）。"
EVIDENCE = [
    "c440e53af9128cf0",  # 步2103：(18,17) 已选中，再点一次，只推进行0
    "75b5a379f46f58ea",  # 步2104：再点第三次，仍然只推进行0
]

from _lib import click_target, selected


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    if sum(1 for x, y in zip(prev[0], nxt[0]) if x != y) != 1:
        return "NA"
    sel = selected(prev)
    if sel is None or click_target(prev, action) != sel:
        return "NA"
    return "TRUE" if prev[1:] == nxt[1:] else "FALSE"
