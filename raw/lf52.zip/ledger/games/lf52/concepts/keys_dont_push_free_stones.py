"""方向键不推自由石子：不在车腔里的石子，整幅画面怎么滚它就怎么跟着滚，在世界里一格不动。

「怎么滚」用踏板量：踏板本局从不移动，所以两帧里踏板集合的整体位移就是镜头平移。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1/2/3/4；换关返回 NA；"
         "两帧踏板个数不等、或踏板不是整体平移（量不出镜头）返回 NA；"
         "没有一颗自由石子在平移后仍整格落在画面内（核不了）返回 NA。"
         "在车腔里的石子不算——它跟车走，那是 cart_slides_one_stride 管的事。")
NOTE = ("由来：本 run 第 3972 步之前，我按『方向键推石子』这条**从没量过的**假设排了一整条路线，"
        "以为把车往西开会把石子一路推到墙角。全语料核对推翻了它："
        "用踏板扣掉镜头平移后，30 条能核的方向键转移里自由石子逐条与平移相等，0 条例外。"
        "先前看起来像『石子被推』的 53 条命中，全是镜头平移或石子坐在车里跟车走造成的屏幕坐标变化。"
        "这条概念存在的意义就是：让『方向键推不推石子』不再是脑子里的印象，而是每条新转移都要复核的对象。")
EVIDENCE = [
    "24b421b26ff36d7e",  # 步3214 ACTION1 平移(0,0)  自由石子(18,46) 未动
    "65a71f637a4d88b4",  # 步3221 ACTION1 平移(0,0)  自由石子(18,34) 未动
    "4ed070eff87dc7e2",  # 步3225 ACTION2 平移(0,0)  自由石子(18,34) 未动
    "b04088b8a1d47575",  # 步3226 ACTION2 平移(0,0)  自由石子(18,34) 未动
    "82924d2a6ed407ab",  # 步3219 ACTION3 平移(0,0)  自由石子(18,34) 未动
    "628e3791ce680162",  # 步3101 ACTION3 平移(0,6)  自由石子(42,4) 随镜头滚，世界里未动
    "c882d71dfc30fcef",  # 步3186 ACTION3 平移(0,6)  同上
    "8e53785a8003d49e",  # 步3229 ACTION4 平移(0,0)  自由石子(18,22) 未动
    "cfa29876f8568557",  # 步2941 ACTION4 平移(0,-6) 自由石子(42,10) 随镜头滚，世界里未动
    "c063b7fffebbd879",  # 步2992 ACTION4 平移(0,-6) 同上
]

from _lib import stones, steps, carts, SIZE

DIRS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _pan(a, b):
    """踏板集合从 a 到 b 的整体位移；个数不等或不是整体平移则 None。"""
    pa, pb = sorted(steps(a)), sorted(steps(b))
    if not pa or len(pa) != len(pb):
        return None
    d = (pb[0][0] - pa[0][0], pb[0][1] - pa[0][1])
    for (ra, ca), (rb, cb) in zip(pa, pb):
        if (rb - ra, cb - ca) != d:
            return None
    return d


def _inside(r, c, H, W):
    return 0 <= r and r + SIZE <= H and 0 <= c and c + SIZE <= W


def _checkable(prev, nxt):
    """返回 (平移, [平移后仍整格在画面内的自由石子起点])，量不出就 (None, [])。"""
    d = _pan(prev, nxt)
    if d is None:
        return None, []
    H, W = len(prev), len(prev[0])
    free = set(stones(prev)) - set(carts(prev))
    keep = [(r, c) for (r, c) in sorted(free) if _inside(r + d[0], c + d[1], H, W)]
    return d, keep


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith(DIRS):
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d, keep = _checkable(prev, nxt)
    if d is None or not keep:
        return "NA"
    free_q = set(stones(nxt)) - set(carts(nxt))
    for r, c in keep:
        if (r + d[0], c + d[1]) not in free_q:
            return "FALSE"
    return "TRUE"


# 不写 apply：这条概念主张的是「什么都没发生」。
# 唯一生成得出的是石子原地那 12 格的颜色，而那些格子根本不在帧差里——
# 认领它们只会让「认领格数」虚涨，E 一格不动。不变量式的概念生成不了就闭嘴。
