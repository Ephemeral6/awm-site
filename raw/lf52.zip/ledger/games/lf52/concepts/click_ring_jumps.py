"""有子被选中时点在它的某个环上，世界就执行这一跳：起点清空，落点长出棋子，选中与环一并清掉；被跨的若是子就连它一起清掉，若是踏板/石子/灰团则原封不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION6 点中的孔正好是 prev 里的一个环、且 prev 有唯一选中**子**的转移；选中的是石子返回 NA（归 stone_moves_when_no_peg_selected）；其余 NA。孔位集合变了（跳完就换关）返回 NA。"
NOTE = """
v6 只缩 scope：第 3125 步之后色8 收进了 HOLE_COLORS，selected() 从此能读到被选中的石子，
于是石子跳的那几条转移（2920、3105、3125）落进了这条的 scope，而它按「跨过的孔被吃掉」算落点子集合，判 FALSE。
这条从头到尾说的都是子的跳，石子的跳另有概念管，所以选中物不是子就闭嘴。断言和 apply 的正文一字未动。

孔明棋的「跳吃」动作。被吃的那一子由起点与落点的中点决定——落点必须恰好隔一个孔，这一点由 rings 的产生规则保证。
v1 在 ceb6602cf5bc6190 上判过一次 FALSE，查下来不是主张错而是**词汇读错帧**：
那一跳之后盘上剩下的子由色14 整体变成了色2，而当时的 _lib.pegs 只认色14，于是读成「盘上零子」。
把 pegs 改成按「孔里 12 格实心」认（色14 或色2 都算子），这条转移就判 TRUE 了。

v5 只改 apply，断言一个字没动（所以 S 不受影响，受影响的是 P）。
v4 的 apply 一直把「孔清空」写成退回空孔底色 C_EMPTY、把选中描边写成退回盘面黑 0。
这两条在普通孔上对，在**车腔**上全错：腔的底色是 C_CART_FILL，腔外面那一圈是车框 C_CART_EDGE 而不是黑。
第 2687/2688 两步是现成的物证——点中车腔里的子时 (30,47) 走的是 11→3，跳出去之后又 3→11，
而 v4 的 apply 在那一格填的是 0。凡是子跳进车、跳出车、或环画在腔里的转移，
每条要错 16（描边）+12（腔底）格上下，而 assert_ 照样判 TRUE，因为检查器只比对孔位与子集合，
看不见生成器往像素上画了什么——settle 说的「说错却判 TRUE」就是这个。
v5 结算后 P 只从 0.639 涨到 0.677，逐条查残差才看见第二个错：**每一跳固定错 8 格**，全在落点上——
落点本身就是一个环，apply 先画子再擦环，把刚长出来的子擦回了底色。把擦环挪到画子之前。
还剩一类没管：2130/2168/2524/2599 四跳之后视口里只剩最后一颗子，它整颗（12 格）画成色 2 而不是 14；
但 2355 同样视口里只剩一颗，却还是 14。区别在哪还没弄清，先不猜，这 4×12 格留作残差。
v7 到 v8：**只改账单，不改主张**。改 _lib.carts 让这条的结算缓存失效，第一次真的跑满全语料，
当场超 20s 预算被中止（`kind=error`，闸关）。在那之前它从没跑满过——缓存替它付了账。
量下来（runs/*/probe_slow_click.out）：第一行 `holes(prev)!=holes(nxt)` 每条转移 5.7ms、
全语料 10.1s，而 1764 条里 1138 条根本不是点击、只有 129 条真是点环——
**最贵的免责条款写在了最前面**。把它按单价重排（ACTION6 前缀 → click_target → selected → rings →
pegs → 孔集合比较），并把算了两遍的 pegs(prev) 提成局部变量。
这几条免责全都返回 NA，谁先谁后不改任何一条转移的判决；S/C/N 应当逐位不变，变了就是我排错了。
**上面那句自检写错了层，而且当场就落空**：结算回来 N 从 129 涨到 159。
不是排错了——同一次结算里 _lib.carts 也改了，而这条概念 import carts，N 本来就该动。
真去核过（runs/*/probe_reorder_check.out）：拿**同一本现在的 _lib**，新旧两种顺序在全语料 1764 条上
逐条对拍，判决 0 处不同（两边都是 NA 1599 / TRUE 165）。
留着这段是因为教训在自检本身：S/C/N 是**这一批所有改动的合成读数**，
而「重排免责条款」只保证**判决**不变；用合成读数去核单处改动，对不上也说明不了是谁的错。

**v9→v10：只改 apply（和一句说过头的主张），断言正文一字未动。**
`assert_` 从 v1 起就把非子的被跨者算对了——`want = (ps - {src, over}) | {tgt}`，
`over` 不是子时 `ps - {src, over}` 自然等于 `ps - {src}`，跨踏板的跳它一直判 TRUE。
**而 `apply` 里有一行 `if over not in pegs(prev): return None`，跨踏板/石子/灰团的跳它一格都不画。**
于是出现了最难看的一种不一致：同一条概念，检查器敢判、生成器不敢画。

代价是按批暴露出来的：第 4312 批十个动作，`--predict` 只有第一步说得出话，
后九步全是「没有概念开口」——因为链式预测要拿上一步的模型帧喂下一步，
中间只要有一跳没人生成，后面每一步就都在读一张不存在的帧。
`--strict` 只护得住有预测的那些步，等于这一批十步里九步裸奔。
这正是本文件 v5 那段说过的病（「一条概念闭嘴，会把它后面每一步的预测一起带歪」），
只不过这次闭嘴的是它自己。

改法：被跨者不是子时，除了「不清空被跨的那个孔」，其余一切照旧。
底气是 jump_over_step_captures_nothing v4 刚刚在全语料上重新结算过的那条主张
（跨踏板/石子/灰团都不吃），它和这条读的是同一批转移的两个侧面。
主张里那句「起点与被跨过的孔各清空」同时改掉——它本来就说过了头，
只是因为检查器没照着它写，这个过头一直没被罚到。

**v10→v11：只改 apply，断言正文一字未动（所以 S/C/N 该逐位不变，变了就是我改错了）。**
终局卡第一批第 8 步（第 4536 步，9be171041dc23e3a）吃了一次意外：预测 56 格全错，
实际帧差 1679 格——那一跳是**收关的一跳**，整盘换掉，我押的是旧盘上一次普通的跳。

这不是主张错。`assert_` 从 v1 起第一行免责就写着 `holes(prev) != holes(nxt) → NA`，
SCOPE 原文也写着「孔位集合变了（跳完就换关）返回 NA」——**检查器早就不管这一类了**。
错的是 `apply` 看不见 `nxt`，没法照着同一句话闭嘴，于是每一关的最后一跳都要错这么一次。
又是 v5 那段说过的病的另一面：v5/v10 是生成器比检查器窄，这次是**生成器比检查器宽**。

改法：只读 prev 算出「这一跳之后还剩几颗子」，剩 1 颗且视口装得下整个世界时返回 None。
这两个判据不是我现编的，是 `board_replaced_iff_last_peg` v9 的断言本身
（`last = len((pegs(prev) - {src, over}) | {tgt}) == 1`，以及 `_world_open` 那道边缘守卫）。
**它只是抄过来的，不是 import 的**：settle 的缓存指纹只含本文件源码，import 别的概念会让那边改了这边不重算。
抄的代价照例是那边改了这里不会跟着改，写在这里。

**一处明说的走样**：`board_replaced_iff_last_peg` 查的是 `_world_open(nxt)`，这里只能查 `_world_open(prev)`。
一次跳吃只在盘内挪一颗子，视口边缘那一圈两帧之间该是一样的，但这句话我没量过，
它是这次改版里唯一一个没有读数背书的地方。真要是两帧不同，表现会是「该闭嘴时没闭嘴」——
和这次的意外同一个形状，会再被罚一次。

**v11→v12：又被罚了一次，死法和 v11 预注册的那句话形状一样，死因却更简单。**
终局卡第 2 关收关的一跳（第 4688 步，71c2f361bec6d5cf）：预测 56 格全错，实际帧差 1940 格，整盘换掉、过关 3/10。
`runs/…/probe_lastjump.py` 把那道闸拆成两半量了一遍：「跳完剩 1 颗」那一半是 True，
`not _world_open(prev)` 那一半是 False——**顶开闸的不是两帧不同，而是 `_world_open(prev)` 自己就是 True**。
第 2 关的世界确实比视口宽（第 4679 步镜头滚过之后，左边缘滚进来一颗我从没见过的子），
可世界照样在只剩 1 颗**可见**子时换了盘。

`runs/…/probe_lastjump_scan.py` 在全语料 401 条点环的跳上把两类数清楚了：

    A 跳完剩 1 颗且孔位集合变了（真换盘，生成器必须闭嘴）  49 条，其中 _world_open(prev)=True **34 条**
    B 跳完剩 1 颗但孔位集合没变（视口外还有子，可以照画）  46 条，其中 _world_open(prev)=True **46 条（全部）**

**这道否决在 True 那一侧一条都分不开**：34 条该闭嘴的和 46 条该开口的挤在同一个值上。
它唯一干成的事是把 A 里 15 条 False 的挑出来闭嘴。留着它，每过一关就要说一次 56 格的谎并挨一次批停（终局卡上还剩 7 关）；
砍掉它，B 那 46 条正确预测变成沉默。**沉默是洞，说谎是伪证**，所以砍。
砍掉的代价写在明处：P 会掉一点，E 会掉一点，凡是「跳完只剩 1 颗可见子而世界还没完」的那一步从此没人预测。

真正该有的那条判据（只读 prev 就能分开「世界到此为止」和「视口外还有子」）我还没有。
`_world_open` 的读法太粗：它问的是「边缘上有没有非背景」，而轨、车、踏板都算非背景。
该问的大概是「盘面的孔网有没有被视口切断」，但那要先量，量之前不许写进任何闸——
这正是 v11 那道否决当初该走而没走的手续。

**v12→v13：只改 apply，断言正文一字未动。落进空车腔的那一跳从此闭嘴。**
终局卡第 3 关第 4695 步（71c2… 之后那一批的最后一步，tid 7c6ab6d4bbeb0e68）：
预测 64 格错 52 格，实际帧差 1662。手工核过（`probe_jump1662.txt`）：这不是换盘，是**镜头滚了
5 个 STRIDE**——子跳进 (24,48) 那辆空车的腔，那辆车当场变成载子车，镜头随即把它钉到 (24,18)，
整幅视口向左滚 30 像素，右边缘滚进来一颗我从没见过的子。子、车、踏板三组坐标在位移 (0,-30) 下逐一对得上，
被跨的 (24,42) 确实被吃了（世界里 3 子变 2 子，屏幕上看着还是 3 颗是因为滚进来一颗）。

先量后改（`probe_jump_into_cart.txt` / `probe_jump_into_cart2.txt`，全语料 404 条点环的跳）：

    落点是车腔的  38 个不同 tid
      其中镜头滚了/整幅重画（_shift 解不出唯一位移）  10 个，prev 里**全都没有载子车**
      其中一格没滚（_shift = (0,0)）              28 个，其中 4 个 prev 里**已经有一辆载子车**
                                                （子从一辆车的腔跳进另一辆车的腔，镜头早钉好了，不重新钉）

所以这道闸写成「落点是车腔 **且** prev 里一辆载子车都没有 → 闭嘴」：10 条该闭嘴的全在里面，
4 条「换车」的照旧开口。代价数清楚了：**24 条不滚的也被一起闭嘴**，其中 18 条原先是逐格说对的
（另外 6 条本来就被别的闸挡着，一格没说）。换来的是 2 个 tid 上每次 52 格的谎不再说
（另外 8 条滚的本来就被「剩 1 颗」那道闸挡住了，所以这次真正堵掉的是 2 个）。
18 条沉默换 2 条谎，比 v12 那笔（46 换 49）难看得多，但方向一样：**在终局卡上，一次 52 格的谎
等于一次批停、一次意外；一次沉默只是那一步没人预测**。而且这两个 tid 正是摆渡要反复走的那一步。

我不知道的那件事写在明处：**镜头重新钉在哪，这条概念一个字都答不出**。
只读 prev 分不开「钉位就在这辆车脚下（不滚）」和「钉位在别处（滚）」——
`loaded_cart_column_pinned` 的钉位是按关写死的常数，而 prev 里没有载子车时那个常数读不出来。
真正该有的是一条「这一关镜头把载子车钉在哪」的概念；有了它，这道闸可以收窄回「钉位不在落点」。
"""
EVIDENCE = [
    "9beb444a0eee5e57",  # 步2116 (18,17) 跨 (18,23) 落 (18,29)
    "2e1ceef4dce96bee",  # 步2120 (18,29) 跨 (18,35) 落 (18,41)
    "d5bce195f2626121",  # 步2122 (18,41) 跨 (24,41) 落 (30,41)
    "ceb6602cf5bc6190",  # 步2130 (15,43) 跨 (15,37) 落 (15,31)：打掉 v1 词汇的那一条
    "ca5264581e8425fc",  # 步2677 (48,48) 跨 (48,42) 进车腔 (48,36)：子跳进车，落点是腔——v5 改 apply 的物证之一
    "6a7da7cce35454e0",  # 步2688 车腔 (48,30) 跨 (48,24) 落 (48,18)：子跳出车，起点是腔，描边退回车框 11 而不是 0
    "c380aa0b78f93941",  # 步2285 跨踏板 (24,18)：被跨者不是子、一格没变 —— v10 让 apply 敢画的那一类
    "fd1e236e94b7235f",  # 步4311 跨灰团 (24,30)：同上，帧差 53
    "9be171041dc23e3a",  # 步4536 终局卡第 0 关最后一跳，帧差 1679：换盘。assert_ 在它上面判 NA
                         #   （孔位集合变了），是 apply 押了 56 格全错 —— v11 让生成器闭嘴的那一条
    "71c2f361bec6d5cf",  # 步4688 终局卡第 2 关收关的一跳，帧差 1940：换盘、过关 3/10。
                         #   v11 那道 `not _world_open(prev)` 否决在这里顶开了闸，56 格全错 —— v12 砍掉它的那一条
    "7c6ab6d4bbeb0e68",  # 步4695 终局卡第 3 关，子跳进空车腔 (24,48)，帧差 1662：不是换盘，是镜头
                         #   把刚装上子的那辆车钉到 (24,18)，整幅滚 5 个 STRIDE。apply 押 64 格错 52 —— v13 让它闭嘴的那一条
]

from _lib import (click_target, holes, pegs, rings, selected, carts,
                  PEG12, CORNERS, OUTLINE16, DIRS, STRIDE,
                  C_EMPTY, C_PEG, C_RING, C_CART_EDGE, C_CART_FILL)


def _world_open(g):
    """视口边缘上还有非背景内容 —— 世界很可能在视口外接着长，视口里的子数不等于世界里的子数。

    **v12 起 apply 不再用它**（留着是因为 NOTE 里那段账要指得到这段代码）。
    整段抄自 board_replaced_iff_last_peg v6（连同「行0 是计数条不算边缘」「背景色取行1 起的众数」
    这两条读法）。抄而不 import 的理由写在 NOTE v11 里：settle 的缓存指纹只含本文件源码。
    """
    freq = {}
    for row in g[1:]:
        for v in row:
            freq[v] = freq.get(v, 0) + 1
    bg = max(freq, key=freq.get)
    H, W = len(g), len(g[0])
    edge = [(1, c) for c in range(W)] + [(H - 1, c) for c in range(W)] \
        + [(r, 0) for r in range(1, H)] + [(r, W - 1) for r in range(1, H)]
    return any(g[r][c] not in (bg, 0) for r, c in edge)


def assert_(prev, action, nxt, ctx=None):
    # 这一串免责条款按「单价从低到高」排，不是按想到的顺序排：每一条都返回 NA，
    # 谁先谁后不改判决，只改账单。holes(prev)!=holes(nxt) 原先写在第一行，
    # 于是 1764 条转移每条都先付 5.7ms 去算两帧的孔（合计 10.1s），
    # 而其中 1138 条根本不是点击、129 条才真是点环。量出来见 runs/*/probe_slow_click.out。
    if not action.startswith("ACTION6:"):
        return "NA"
    tgt = click_target(prev, action)
    if tgt is None:
        return "NA"
    src = selected(prev)
    if src is None or tgt not in rings(prev):
        return "NA"
    ps = pegs(prev)
    if src not in ps:
        return "NA"   # 选中的是石子：那是 stone_moves_when_no_peg_selected 的地盘
    if holes(prev) != holes(nxt):
        return "NA"
    over = ((src[0] + tgt[0]) // 2, (src[1] + tgt[1]) // 2)
    want = (ps - {src, over}) | {tgt}
    if pegs(nxt) != want:
        return "FALSE"
    if selected(nxt) is not None:
        return "FALSE"
    return "TRUE" if not rings(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    """跳吃：起点清空（角3→1、子14→1、描边3→0），落点长子（→14），选中与环清掉，计数条+1。
    被跨的是子就一并清空（12格）；是踏板/石子/灰团就一格不碰（v10）。
    两类跳不画：收关的那一跳（v11/v12），和落进空车腔、会让镜头重新钉住的那一跳（v13）。"""
    if not action.startswith("ACTION6:"):
        return None
    tgt = click_target(prev, action)
    if tgt is None:
        return None
    src = selected(prev)
    rs = rings(prev)
    if src is None or tgt not in rs or src not in pegs(prev):
        return None
    # 计算被吃位置
    dr, dc = (tgt[0] - src[0]) // 2, (tgt[1] - src[1]) // 2
    if (dr, dc) not in ((0, STRIDE), (0, -STRIDE), (STRIDE, 0), (-STRIDE, 0)):
        return None
    over = (src[0] + dr, src[1] + dc)
    # v10 之前这里是 `if over not in pegs(prev): return None`——跨踏板/石子/灰团的跳
    # 整条不画。现在只把「要不要清空被跨的那个孔」这一个判断挂在它身上。
    eats = over in pegs(prev)

    # v11：收关的那一跳不画——换成什么样这条概念一个字都答不出，所以闭嘴。
    # assert_ 早就用 `holes(prev) != holes(nxt)` 把这一类挡在门外了，这里只是让生成器跟上检查器。
    # v12 砍掉了原先挂在后面的 `and not _world_open(prev)` 那道否决（量出来的三个数见 NOTE）：
    # 它在 True 那一侧分不开「真换盘」和「视口外还有子」，而分不开的代价是每关一次 56 格全错。
    if len((pegs(prev) - {src, over}) | {tgt}) == 1:
        return None

    cavities = carts(prev)

    # v13：落进一辆**空车**的腔——这一跳会把那辆车变成载子车，而镜头可能当场把它重新钉到别处
    # （第 4695 步整幅滚了 5 个 STRIDE，1662 格）。钉在哪这条概念答不出，所以闭嘴。
    # prev 里已经有载子车时不闭嘴：那是「子从一辆车的腔跳进另一辆车的腔」，镜头早钉好了，
    # 全语料 4 条这样的转移一格没滚（读数与代价见 NOTE v12→v13）。
    if tgt in cavities and not any(prev[c[0] + dr][c[1] + dc] == C_PEG
                                   for c in cavities for dr, dc in PEG12):
        return None

    def floor(h):
        """这个孔被清空之后露出来的底色。车腔的底色是腔色，不是空孔底色。"""
        return C_CART_FILL if h in cavities else C_EMPTY

    out = {}
    # 起点清空：四角与 12 格棋子一起退回这个孔自己的底色
    for dr2, dc2 in CORNERS:
        out[(src[0] + dr2, src[1] + dc2)] = floor(src)
    for dr2, dc2 in PEG12:
        out[(src[0] + dr2, src[1] + dc2)] = floor(src)
    # 描边退回它盖住的那层：普通孔外面是盘面黑，车腔外面是车框
    under = C_CART_EDGE if src in cavities else 0
    for dr2, dc2 in OUTLINE16:
        r, c = src[0] + dr2, src[1] + dc2
        if 0 <= r < len(prev) and 0 <= c < len(prev[0]):
            out[(r, c)] = under
    # 被吃清空（12格）——只在被跨者真是子的时候。踏板/石子/灰团原封不动，
    # 一格都不往 out 里写：不写等于不表态，而这里的「不变」正是 jump_over_step_captures_nothing 管的。
    if eats:
        for dr2, dc2 in PEG12:
            out[(over[0] + dr2, over[1] + dc2)] = floor(over)
    # 所有环清掉（8格每个环）——要写在落点长子**之前**：落点自己就是一个环，
    # 先画子再擦环会把刚长出来的子擦掉 8 格（v5 之前每一跳都固定错这 8 格）
    for ring in rs:
        for dr2, dc2 in ((0,1),(0,2),(1,0),(1,3),(2,0),(2,3),(3,1),(3,2)):
            out[(ring[0] + dr2, ring[1] + dc2)] = floor(ring)
    # 落点长子（12格 →14）
    for dr2, dc2 in PEG12:
        out[(tgt[0] + dr2, tgt[1] + dc2)] = C_PEG
    # 计数条不预测（counter_advance 管）
    return out
