"""方向键按下时，每一辆两个去处都看得全的滑车**走一格当且仅当前方那一格轨道是通的**：把内腔沿键方向平移一个 STRIDE，去处内腔正中那 2x2 格在 prev 里要么全是色5（横轨或立柱正穿过去处的中心），要么全落在紧挨着的另一辆车腔里而那辆车自己走得动。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1/2/3/4；计数条没有正常推进一格时 NA；prev 或 nxt 里 carts() 找不到车、或去掉车腔后一个孔都对不上任何列平移时 NA。前方 12 格有一格在视口外、或两个去处（不动 / 走一格）有一个在视口外的车不表态；两个去处都停着车的也不表态。"
NOTE = """
第 5 关东段量出来的：横轨在内腔下面两行（r+1、r+2）、立柱在内腔中间两列（c+1、c+2），
车能不能走，看的就是这条线上前面一格有没有轨。四条读数：
  空车在东立柱脚下，ACTION1 走了两格（帧差 117、107），第三下顶到屋子地板帧差 1——
    前方 12 格从「全是色5」变成踏板的色15/色7 和底座；
  载子车头顶没柱，同一下 ACTION1 一格不动；
  两车相邻同向走，后车前方 12 格压在前车身上，前车走它就走、前车顶死它也顶死（第 3168 步帧差 1）；
  横轨西端：载子车在世界列 48 推不动，空车从 66 继续走到 54 贴上它（第 3189、3190 步帧差 122、112）。
它比 cart_slides_one_stride 多说的一半是「什么时候动」；那条只说「动就动一格」。
「前方 2x2」用的是 prev 帧，所以镜头滚不滚不影响判定；判「动没动」时借 cart_slides 那把尺子找列平移 d。
v2→v3 只补证据：「后车跟着前车走」这半句原先只有一条反面的 tid（两辆都顶死），正面的没有。
第 3598 步补上了——石车从行36 升到行30、载子车从行42 跟上到行36，两辆一起走一格。
顺带纠正我自己的估法：我押这一步帧差 200 到 260（按两辆车算），实测 **126**，和一辆车单独走同价；
车队中间那条共用边缘一格不变，贵的只是车队对外的两条边界。步 3056 那条撤销也是 126，
当时我把它读成「一辆车跳了两格」，还为此给 action7_undoes_one_move 写错过一版断言。
第 3599 步再按一次 ACTION1：石车正对着行24 那块踏板，帧差 1，两辆都不动——和步 3171 同一个死法，
也就是说这一批我把已经做过的实验又做了一遍。教训写在 METHOD.proposals：开跑前先读相关概念的 NOTE，它就是实验记录。

v1→v2 只改首行：v1 入册时首行还写着影子册第一版的「新车框压在轨道线上的 12 格」，代码早已改成去处内腔正中 2x2
（12 格那版在影子册上 S=0.829、78 条反例，全是「从立柱下到横轨」「顺着管道拐弯」这类轨道线不铺满整个车框的局面；
改成 2x2 之后同一语料 463 条 TRUE、0 条 FALSE）。主张要和代码说同一句话。
"""
EVIDENCE = [
    "e2916e071b342fbb",  # 步3169 ACTION1：空车沿东立柱上一格，载子车不动
    "125c2d0124667a5d",  # 步3170 ACTION1：空车再上一格
    "ddac66c8a948419a",  # 步3171 ACTION1：空车顶到屋子地板，帧差 1
    "c83f155cb4c848b9",  # 步3168 ACTION4：前车顶到车库东墙，两车都不动
    "fdf112d8a2d1eee7",  # 步3189 ACTION3：载子车顶在轨西端不动，空车独走
    "59f55d9a127c0094",  # 步3190 ACTION3：空车贴上载子车
    "5ddbf601f4b46f6b",  # 步3174 ACTION1：载子车沿西立柱上一格，空车（在东柱顶端）不动
    "dc31e0c63e41dd6e",  # 步3598 ACTION1：石车上一格、载子车跟着上一格，两车一起走，帧差 126
    "c33e9038076a461a",  # 步3599 ACTION1：石车顶在踏板下不动，后面的载子车也跟着顶死，帧差 1
]

from _lib import SIZE, STRIDE, carts, holes, DELTA, rail_free

# DELTA / C_RAIL / CART_COLORS / _ahead / rail_free 第 4877 步搬进了 _lib——
# loaded_cart_peg_offset_shifts_by_key 要用同一个「前方通不通」，两条共用就该进词汇表。
# 搬家一个字没改，断言与判据一律照旧；本地名 _free 留作别名，下面的代码原样不动。
PAN = 16
_free = rail_free


def _shift(S, d, W):
    return {(r, c + d) for (r, c) in S if 0 <= c + d and c + d + SIZE <= W}


def _keep(S, d, W):
    return {(r, c) for (r, c) in S if 0 <= c - d and c - d + SIZE <= W}


def _vis(r, c, H, W):
    return 0 <= r and r + SIZE <= H and 0 <= c and c + SIZE <= W


def assert_(prev, action, nxt, ctx=None):
    key = action.split(":", 1)[0]
    if key not in DELTA:
        return "NA"
    if sum(1 for x, y in zip(prev[0], nxt[0]) if x != y) != 1:
        return "NA"
    A, B = carts(prev), carts(nxt)
    if not A or not B:
        return "NA"
    H, W = len(prev), len(prev[0])
    hA, hB = set(holes(prev)) - A, set(holes(nxt)) - B
    dr, dc = DELTA[key]
    usable = False
    for d in range(-PAN, PAN + 1):
        if not _shift(hA, d, W) or _shift(hA, d, W) != _keep(hB, d, W):
            continue
        usable = True
        ok = True
        for a in A:
            p = (a[0], a[1] + d)
            s = (a[0] + dr, a[1] + dc + d)
            if not (_vis(p[0], p[1], H, W) and _vis(s[0], s[1], H, W)):
                continue
            in_p, in_s = p in B, s in B
            if in_p and in_s:
                continue
            if not (in_p or in_s):
                ok = False
                break
            fr = _free(prev, A, a, dr, dc)
            if fr is None:
                continue
            if fr != in_s:
                ok = False
                break
        if ok:
            return "TRUE"
    return "FALSE" if usable else "NA"
