"""点一个有合法跳的**可跳物**（棋子、石子或灰团），世界就把它设为选中，并把环恰好画在它的全部合法落点上；棋子、石子与灰团一个不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点中某个孔、该孔里是一颗棋子、一颗石子或一个灰团、该物件至少有一个合法跳、"
         "且它在 prev 里还没被选中的转移；其余 NA。孔位集合变了（换关/换盘）返回 NA。")
NOTE = """孔明棋的「选子」动作。环不是装饰，是落点提示——这条概念断言环等于合法落点集合，读错一个环就是反例。

它顺带是「盘边挡不挡跳」这个问题的判官：jumps_from 只认格点相邻（坐标差 ±6），不认盘的色5 外框，
所以只要有一次跳跨过盘边而世界没画那个环，这条概念立刻判 FALSE。第 2425 步实测跨过去了
（起跳孔与落点分属两块各有外框的盘，中间隔着两层框），环照画，这条概念判 TRUE。
于是 _lib 早先那句「块内的孔才谈得上相邻」是错的，已从 _lib 的 docstring 里撤掉。

**v4→v5：从「点子」放宽到「点可跳物」，把石子收进来。**（文件名还叫 click_selects_peg 是历史包袱，主张以首行为准。）
第 5 关的引擎是石子自己走（stone_moves_when_no_peg_selected），可选石子这一半一直没人写，
于是每一次「点石子」的转移全册没人开口、预测 0 格。实测选石子和选子的帧差一模一样：
第 3149 步点石子 (42,18)、第 3153 步点石子 (42,30)，都是 29 格 = 16 描边 + 4 角 + 8 环 + 1 计数条，
和第 3151 步点子 (42,24) 逐格同构。石子早就和子共用 holes()/selected()/jumps_from()，
断言里唯一要加的是「石子集合也不变」。

**为什么急着补它：链式预测**。第 3151 步 apply 预测 28 格只对了 20 格，8 格全错在那个环上。
查下来不是断言错，是**链断了**：第 3150 步的石子跳没有任何 apply 敢生成，
于是喂给第 3151 步的那张「模型帧」里石子还停在 (42,18)，
jumps_from 从 (42,24) 算出的落点就成了 (42,12) 而不是真的 (42,36)，环画到了空处。
一条概念闭嘴，会把它后面每一步的预测一起带歪——这是 `--predict` 链上最贵的一种沉默。

**v5 的第一版把闸关了**：断言里直接用 `_lib.stones()` 认石子，那是一次 61x61x16 的全帧扫描，
每条 ACTION6 转移都要跑一次，整条概念超过 20s 预算被中止（`kind=error`，不是判错，是没跑完）。
改成只读被点那一个孔的 16 格（`_is_stone`），判据与 stones() 同源而代价是常数。
教训归档：**放宽 scope 的代价不只是多说错的风险，还有每条转移多花的时间**——
一条跑不完的概念和一条被推翻的概念在闸前是一回事。
v6 到 v7：同一个病第二次发作，**只改账单，不改主张**。改 _lib.carts 让缓存失效，
这条第一次跑满全语料，又超 20s（`kind=error`，闸关）。量下来（runs/*/probe_slow_click.out）：
jumps_from 每次 11.3ms、在 626 条点击上合计 7.1s，是全场最贵的一步；
而「已经选中它了」「盘面换了」这两条免责都比它便宜一半以上，却排在它后面——
于是那些注定返回 NA 的转移照样把最贵的一步付掉了。按单价重排，把它俩挪到 jumps_from 前面；
另外 pegs(prev) 原先算了三遍，提成局部变量算一遍。
被挪动的全是返回 NA 的免责条款，判决不变；S/C/N 应当逐位不变（v6 是 S=1.000 C=0.130 N=228），变了就是我排错了。
**那句自检写错了层，而且当场落空**：结算回来 N 从 228 涨到 243。
不是排错了——同一次结算里 _lib.carts 也改了，这条 import carts，N 本来就该动。
真去核过（runs/*/probe_reorder_check.out）：同一本现在的 _lib、新旧两种顺序、全语料 1764 条逐条对拍，
判决 0 处不同（两边都是 NA 1515 / TRUE 249）。
教训留在这里：单处改动的自检量必须是它**单独负责**的那个量（这里是判决），不是总账里的 S/C/N。

**v8→v9：第三种可跳物「灰团」（色9）收进来，由一条反例逼出来。**
第 4310 步 `ACTION6:25,25` 点子 (24,24)，世界画了 **2** 个环，这条概念算出 1 个，判 FALSE 关闸。
不是主张错了，是词汇瞎了：`_lib.HOLE_COLORS` 里没有色9，列30 上那两个灰团扫不出孔，
`jumps_from` 就看不见「跨过灰团」那条跳。**这是词汇表的假阴性伪装成概念的反例**——
断言一个字没改，把色9 收进孔色，这条转移当场判 TRUE（算出 2 条跳，恰好等于帧上 2 个环）。
色9 同时是阴影色，收它之前在全语料 8620 帧上量过代价（见 _lib 的 HOLE_COLORS 注释）：少认 0 个孔。

顺手把「点灰团」也收进 scope，理由和 v5 收石子那次逐字相同：不收就是每一次点灰团全册没人开口。
这不是白担风险——第 4306 步点灰团 (42,30) 帧差 29、环落在唯一落点 (30,30)，
与点子、点石子逐格同构。`_is_grey` 照 `_is_stone` 的办法只读那一个孔的 16 格，代价是常数，
不碰 v5/v7 两次踩过的全帧扫描。
"""
EVIDENCE = [
    "5ca53ff2aa1c1cf1",  # 步2119 点 (18,29)：选中它，环恰好落在唯一合法落点 (18,41)
    "974425ea452aeb93",  # 步2114 点 (18,17)：选中它，环落在 (18,29)
    "a6bea85e82a41ce5",  # 步2121 点 (18,41)：选中它，环落在 (30,41)
    "f49fbe138f83d2d1",  # 步2425 第一次跨盘边选子：源 (24,30) 与落点 (24,42) 分属两块盘，环照画（帧差 29）
    "3d29e02c36c69aa5",  # 步3149 点石子 (42,18)：帧差 29，与点子逐格同构 —— v5 放宽的由来
    "330cd196ae84db97",  # 步3153 点石子 (42,30)：同上
    "1a89d68cc2b90ee7",  # 步4310 点子 (24,24)：**反例**，世界画 2 环册子只算 1 条跳；词汇收进色9 后判 TRUE
    "ec4f5982a4577ef5",  # 步4306 点灰团 (42,30)：帧差 29，环落在唯一落点 (30,30) —— v9 放宽的由来
]

from _lib import (click_target, holes, pegs, rings, selected, count_in, jumps_from, carts,
                  CORNERS, EDGE8, OUTLINE16, C_EMPTY, C_RING, C_SEL, C_STONE, C_GREY, PEG12)


def _is_stone(g, h):
    """(h 这个孔里坐着一颗石子吗。)

    不用 _lib.stones()：那是一次全帧扫描（61x61x16），在这条概念里每条 ACTION6 转移都要跑一次，
    v5 第一版就是这么把自己跑成「断言太慢，超过 20s 预算」、把闸关掉的。
    这里只读这一个孔的 16 格——判据和 stones() 同源（12 格实心色8、四角留底色），代价是常数。
    """
    return count_in(g, h[0], h[1], C_STONE) >= len(PEG12)


def _is_grey(g, h):
    """h 这个孔里坐着一个灰团吗。照 _is_stone 的办法：只读这一个孔的 16 格，代价是常数。"""
    return count_in(g, h[0], h[1], C_GREY) >= len(PEG12)


def assert_(prev, action, nxt, ctx=None):
    # 免责条款按单价排序，不按想到的顺序排（都返回 NA，顺序不改判决只改账单）：
    # jumps_from 每次 11.3ms，是这里最贵的一步，所以把「已经选中它了」和「盘面换了」
    # 两条便宜的免责挪到它前面；pegs(prev) 原先算了三遍，提成局部变量算一遍。
    # 读数见 runs/*/probe_slow_click.out。
    tgt = click_target(prev, action)
    if tgt is None:
        return "NA"
    ps = pegs(prev)
    stone = tgt not in ps and _is_stone(prev, tgt)
    grey = tgt not in ps and not stone and _is_grey(prev, tgt)
    if tgt not in ps and not stone and not grey:
        return "NA"
    if selected(prev) == tgt:
        return "NA"
    if holes(prev) != holes(nxt):
        return "NA"
    js = jumps_from(prev, tgt)
    if not js:
        return "NA"
    if selected(nxt) != tgt:
        return "FALSE"
    if rings(nxt) != js:
        return "FALSE"
    if pegs(nxt) != ps:
        return "FALSE"
    # 被点的那个物件自己没动：石子/灰团还坐在原孔里（子的不动已由上一行的集合相等管住）。
    # 选中只把四角改成色3，那 12 格实心一格不动，所以选中态下这两个判据照样成立。
    if stone and not _is_stone(nxt, tgt):
        return "FALSE"
    if grey and not _is_grey(nxt, tgt):
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """选中一个可跳物：四角 1→3、外圈 16 格 0→3、**每一个**落点环 8 格 1→2、计数条 +1。"""
    if not action.startswith("ACTION6:"):
        return None
    tgt = click_target(prev, action)
    if tgt is None:
        return None
    if tgt not in pegs(prev) and not _is_stone(prev, tgt) and not _is_grey(prev, tgt):
        return None
    if selected(prev) is not None:
        return None  # 已有选中，别的概念管
    js = jumps_from(prev, tgt)
    if not js:
        return None  # 卡住的子，别的概念管

    out = {}
    R, C = tgt
    # 四角 1→3
    for dr, dc in CORNERS:
        out[(R + dr, C + dc)] = C_SEL
    # 外圈 0→3
    for dr, dc in OUTLINE16:
        r, c = R + dr, C + dc
        if 0 <= r < len(prev) and 0 <= c < len(prev[0]):
            out[(r, c)] = C_SEL
    # 每一个落点都画环 1→2（v4 只画 next(iter(js)) 那一个，多环时必错 8 格的整数倍）
    for dst in js:
        for dr, dc in EDGE8:
            out[(dst[0] + dr, dst[1] + dc)] = C_RING
    # 计数条不预测具体哪格（counter_advance 管）
    return out
