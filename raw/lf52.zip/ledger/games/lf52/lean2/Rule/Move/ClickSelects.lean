/-
# Rule/Move/ClickSelects —— 点一颗能跳的东西：选中它（对应 `rule/move/click_selects.py`）

**身份：定义。** 「选中」这件事本来就是这样定义的，不是一条待证的定理。

跳法（选中之后环画在哪）也住在这里：`targets` 就是环。
-/
import Obj.World
import Obj.Marks.Ring

namespace Game

/-- 从 `p` 朝 `d` 跳：隔壁那一格站着东西、再隔一格是空着的落脚处 ⇒ 落点；否则 `none`。 -/
def jumpTo (b : Board) (c : Core) (p : Nat) (d : Dir) : Option Nat :=
  match b.nbr p d with
  | none => none
  | some m =>
    match b.nbr m d with
    | none => none
    | some t =>
      if has c.pieces m && has (floorOf b c) t && !has c.pieces t then some t else none

/-- `p` 上的东西此刻的全部落点（= 选中它之后环画在哪）。 -/
def targets (b : Board) (c : Core) (p : Nat) : Rings :=
  [Dir.up, Dir.down, Dir.left, Dir.right].foldl
    (fun acc d => match jumpTo b c p d with
      | some t => acc ||| bit t
      | none => acc) 0

/-- 能被选中的三种：子、灰团、暗块（石子语料里从没被选中过，不收）。 -/
def selectable (c : Core) (p : Nat) : Bool := has c.pegs p || has c.greys p || has c.darks p

/-- 这一下点中的是「此刻有落点、能被选中」的东西吗。 -/
def canSelect (b : Board) (c : Core) (p : Nat) : Bool := selectable c p && targets b c p != 0

/-- 选中它。盘上别的一概不动。 -/
def select (c : Core) (p : Nat) : Core := { c with sel := some p }

/-- 环：有选中就是它的全部落点，没有就空。 -/
def ringsOf (b : Board) (c : Core) : Rings :=
  match c.sel with
  | some p => targets b c p
  | none => 0

end Game
