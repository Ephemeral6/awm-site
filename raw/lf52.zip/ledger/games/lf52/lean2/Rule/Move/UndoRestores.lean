/-
# Rule/Move/UndoRestores —— 撤销键（对应 `rule/move/undo_restores.py`）

**身份：定义。**

把「上一步之前」的盘面放回来；计数条照加（那一半在 `Rule/Response/HudCountsSteps`）。
这一关还没有上一步时按撤销：语料里 0 次，模型说不出话（`none`）。
-/
import Obj.World

namespace Game

/-- 撤销之后的盘面；没有可撤的返回 `none`。 -/
def undoCore (s : St) : Option Core := s.hist

end Game
