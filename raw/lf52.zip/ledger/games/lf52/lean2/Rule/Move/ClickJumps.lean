/-
# Rule/Move/ClickJumps —— 有选中时点它的环：跳（对应 `rule/move/click_jumps.py`）

**身份：定义。**

选中的那一样从 `p` 挪到 `t`，种类不变；被跨的那一格（`(p + t) / 2`，横跳竖跳都对）
上若是子、而跳的也是子，那颗子被吃掉；别的一律不吃。选中清空。
-/
import Obj.World
import Rule.Move.ClickSelects

namespace Game

/-- 起点 `p` 与落点 `t` 之间被跨的那一格。横跳差 2、竖跳差 `2w`，中点都是 `(p + t) / 2`。 -/
def middle (p t : Nat) : Nat := (p + t) / 2

/-- 把 `p` 上的东西挪到 `t`（`x` 是某一种棋子的集合）。 -/
def moveOne (p t : Nat) (x : Mask) : Mask := if has x p then diff x (bit p) ||| bit t else x

/-- 跳：从选中的那一格跳到 `t`。 -/
def jump (c : Core) (t : Nat) : Core :=
  match c.sel with
  | none => c
  | some p =>
    { c with
      pegs := if has c.pegs p && has c.pegs (middle p t)
              then diff (moveOne p t c.pegs) (bit (middle p t))
              else moveOne p t c.pegs
      greys := moveOne p t c.greys
      darks := moveOne p t c.darks
      stones := moveOne p t c.stones
      sel := none }

/-- 这一下点中的是选中那一样的一个环吗（= 真的会跳）。 -/
def isJump (b : Board) (c : Core) (q : Nat) : Bool :=
  match c.sel with
  | some p => has (targets b c p) q
  | none => false

end Game
