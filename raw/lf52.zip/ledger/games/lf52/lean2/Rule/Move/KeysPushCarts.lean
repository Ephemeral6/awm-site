/-
# Rule/Move/KeysPushCarts —— 方向键推车（对应 `rule/move/keys_push_carts.py`）

**身份：定义。**

每辆车前面那一格是轨就走一格——除非那一格上停着一辆**不走**的车；
「不走的车挡住后面的车」可以一路传下去，所以要反复剔到不再变（`prune`，
`fuel` 只是给内核看的上界：一列车最长 5 辆）。车里装的东西跟着车走。
有车动了就清掉选中。

**和 Python 那一边的分别**：这一边算的是**整关**的车（窗外的也推），
Python 那一边只能说视口里判得了的那几辆（窗外的是「判不了」）。
-/
import Obj.World

namespace Game

/-- 候选里前面那一格是「一辆不走的车」的，剔掉；剔到不再变为止。 -/
def prune (w : Nat) (carts : Mask) (d : Dir) : Nat → Mask → Mask
  | 0, cand => cand
  | f + 1, cand =>
    let blocked := cand &&& shiftD w (diff carts cand) d.opp
    if blocked == 0 then cand else prune w carts d f (diff cand blocked)

/-- 这一下走得动的车。第一轮：前面那一格是轨（车只停在轨上，所以车格也算轨）。 -/
def movers (b : Board) (c : Core) (d : Dir) : Mask :=
  prune b.w c.carts d 32 (c.carts &&& shiftD b.w b.rails d.opp)

/-- 把 `x` 里落在走动的车上的那些，跟着挪一格。 -/
def ride (w : Nat) (mv : Mask) (d : Dir) (x : Mask) : Mask :=
  diff x (x &&& mv) ||| shiftD w (x &&& mv) d

/-- 推车。镜头不在这里挪（`Rule/Camera/CameraFollowsPegCart`）。 -/
def pushCarts (b : Board) (c : Core) (d : Dir) : Core :=
  let mv := movers b c d
  { c with
    carts := ride b.w mv d c.carts
    pegs := ride b.w mv d c.pegs
    greys := ride b.w mv d c.greys
    darks := ride b.w mv d c.darks
    stones := ride b.w mv d c.stones
    sel := if mv == 0 then c.sel else none }

end Game
