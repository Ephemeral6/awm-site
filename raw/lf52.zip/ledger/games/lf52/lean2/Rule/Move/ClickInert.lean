/-
# Rule/Move/ClickInert —— 没有选中时点在不能跳的地方：什么都不变（对应 `rule/move/click_inert.py`）

**身份：定义。**

有选中时点在环外会怎样，语料里一次都没有——模型在那一支**说不出话**（`Step` 返回 `na`），
不替世界编一个结果。
-/
import Obj.World

namespace Game

/-- 什么都不变。 -/
def inert (c : Core) : Core := c

end Game
