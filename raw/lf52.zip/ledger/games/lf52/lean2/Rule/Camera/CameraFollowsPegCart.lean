/-
# Rule/Camera/CameraFollowsPegCart —— 镜头只跟装子的车（对应 `rule/camera/camera_follows_peg_cart.py`）

**身份：定义。**

这一下有装着子的车走动 ⇒ 镜头沿键那根轴、朝键的方向挪「这一关这根轴的步长」，
顶到这一关镜头的边就停在边上；没有装子的车走动 ⇒ 镜头不挪。

步长与边来自版图（`Board.pan` / `lo*` / `hi*`，出处见 `lean2/levelmap.py`）。
**边只写了语料里真撞到过的**（第 2、3 关各一条下界）；没撞到过的边按「没有边」算——
这是一条明写的口径：换一批语料撞到别的边，这里要跟着补。
-/
import Obj.World

namespace Game

/-- 夹到 `[lo, hi]` 里（缺的那一侧不夹）。 -/
def clampTo (lo hi : Option Int) (x : Int) : Int :=
  let x := match hi with | some h => min h x | none => x
  match lo with | some l => max l x | none => x

/-- 镜头跟车：`pegMoved` = 这一下有装着子的车走了一格。 -/
def follow (b : Board) (cam : Int × Int) (d : Dir) (pegMoved : Bool) : Int × Int :=
  if pegMoved then
    match d with
    | .up => (clampTo b.loR b.hiR (cam.1 - b.pan.1), cam.2)
    | .down => (clampTo b.loR b.hiR (cam.1 + b.pan.1), cam.2)
    | .left => (cam.1, clampTo b.loC b.hiC (cam.2 - b.pan.2))
    | .right => (cam.1, clampTo b.loC b.hiC (cam.2 + b.pan.2))
  else cam

end Game
