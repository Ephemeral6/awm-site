/-
# Rule/Response/HudCountsSteps —— 计数条每一步加一（对应 `rule/response/hud_counts_steps.py`）

**身份：定义。** 任何动作（包括撤销、什么都没推动的键）都让它加一。
换进下一关清零那一半不在这里：模型不描述下一关（那是另一张版图）。
-/
import Obj.World

namespace Game

/-- 走了一步。 -/
def tick (h : Hud) : Hud := h + 1

end Game
