/-
# Rule/Win/LevelupOnLastCapture —— 全盘剩一颗子就过关（对应 `rule/win/levelup_on_last_capture.py`）

**身份：定义。** 「过关」就是这样定义的。

Python 那一边只能说视口里判得了的那一半（「跳前视口里恰好两颗」）；
这一边带着整关的状态，直接数全盘的子。`isGoal` 是**状态**的性质，不是一个转移事件——
于是「这个局面赢不赢得了」这句话才问得出来（`Proof/Reachable.lean`）。
-/
import Obj.World

namespace Game

/-- 目标：全盘恰好剩一颗子。 -/
def isGoal (c : Core) : Bool := popc 64 c.pegs == 1

end Game
