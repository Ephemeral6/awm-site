import Obs.Replay
open Game Game.Replay

theorem t6 : traceOk board6 start6 (stepsOf 6) = true := by decide +kernel
#print axioms t6
theorem c6 : corpusScan board6 start6 seen0_6 (stepsOf 6) = (237, 0, 1) := by decide +kernel
#print axioms c6
