/-
# Obs/Project —— 模型那一侧「这一帧应该看到什么」（对应 Python 的 `parse` 读出的那一份）

`Seen` 只装**帧上看得见的**东西，和 Python `World` 的字段一一对上（坐标都是视口格 `i * 11 + j`）：

    cam     镜头（观测那一侧由相邻两帧地形对齐累加出来，开局 = (0,0)；Python `derive/camera`）
    vis     这一帧整格可见的格（死局圆盘压住的那几格观测那一侧算看不见）
    holes rails carts pegs greys darks stones rings    各一个位集合
    sel     选中框在哪一格
    hud     计数条

**不在 `Seen` 里的**：死局标记（不进模型，见 `Obj/Marks/Dead.lean`）。

模型怎么算出一个 `Seen`（`seenOf`）：按镜头把版图上的一个窗口平移到视口格上。
轨只报「上面没有车」的那几格——车盖住的轨帧上读不到，这一侧也不报。
-/
import Obj.World
import Step

namespace Game

structure Seen where
  cam : Int × Int
  vis : Mask
  holes : Mask
  rails : Mask
  carts : Mask
  pegs : Mask
  greys : Mask
  darks : Mask
  stones : Mask
  rings : Mask
  sel : Option Nat
  hud : Nat
deriving DecidableEq, Repr

/-- 视口格 (i, j) 对应版图的第 `(ra + i)` 行、第 `(ca + j)` 列。 -/
def offs (b : Board) (cam : Int × Int) : Int × Int :=
  let ph := phase b.wp cam
  (((ph.1 : Int) + cam.1 - b.wp.1) / 6 - b.i0, ((ph.2 : Int) + cam.2 - b.wp.2) / 6 - b.j0)

/-- 版图第 `r` 行、从第 `ca` 列起的 `n` 格，排成一个 `n` 位的数。版图外补 0。 -/
def rowBits (b : Board) (m : Mask) (r ca : Int) (n : Nat) : Mask :=
  if r < 0 || b.h ≤ r then 0
  else
    let row := (m >>> (r.toNat * b.w)) % 2 ^ b.w
    if 0 ≤ ca then (row >>> ca.toNat) % 2 ^ n else (row <<< (-ca).toNat) % 2 ^ n

/-- 版图上的一组格 → 这一帧视口里的那几格。 -/
def proj (b : Board) (cam : Int × Int) (m : Mask) : Mask :=
  let ph := phase b.wp cam
  let o := offs b cam
  let n := colsVisible ph.2
  (List.range VW).foldl
    (fun acc i => if rowVisible ph.1 i then acc ||| (rowBits b m (o.1 + i) o.2 n <<< (VW * i)) else acc) 0

/-- 版图上的一格 → 视口格编号；不在视口里返回 `none`。 -/
def projCell (b : Board) (cam : Int × Int) (p : Nat) : Option Nat :=
  let ph := phase b.wp cam
  let o := offs b cam
  let i : Int := (p / b.w : Nat) - o.1
  let j : Int := (p % b.w : Nat) - o.2
  if 0 ≤ i && i < VW && rowVisible ph.1 i.toNat && 0 ≤ j && j < colsVisible ph.2
  then some (VW * i.toNat + j.toNat) else none

/-- 模型说这一帧应该看到什么。 -/
def seenOf (b : Board) (s : St) : Seen :=
  let c := s.core
  let ph := phase b.wp c.cam
  { cam := c.cam
    vis := visMask ph.1 ph.2
    holes := proj b c.cam b.holes
    rails := proj b c.cam (diff b.rails c.carts)
    carts := proj b c.cam c.carts
    pegs := proj b c.cam c.pegs
    greys := proj b c.cam c.greys
    darks := proj b c.cam c.darks
    stones := proj b c.cam c.stones
    rings := proj b c.cam (ringsOf b c)
    sel := match c.sel with | some p => projCell b c.cam p | none => none
    hud := s.hud }

end Game
