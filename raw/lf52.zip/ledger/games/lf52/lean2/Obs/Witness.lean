/-
# Obs/Witness —— 「走得通」的见证：真人走过的那条路，点击坐标按模型自己的镜头改写

`_winnable` 要的是**模型里**的一串动作。真人那条路是按**真的镜头**点的；
镜头跳开的那 8 次，模型的镜头没跟着跳（它说不出跳到哪），于是之后的点击要改写：
同一格在模型的视口里挪了多少像素，点击坐标就挪多少。**点的还是同一个世界格。**

代价写在明处：改写后的坐标可能落在 64×64 的视口外（真游戏点不到那里，模型允许）。
落在视口外的有几下，`offView` 数出来，进读数、上页面。
-/
import Obj.World
import Obs.Check

namespace Game

/-- 按「观测镜头 − 模型镜头」挪点击坐标。 -/
def retarget (s : St) (camObs : Int × Int) : Act → Act
  | .click x y => .click ((x : Int) + camObs.2 - s.core.cam.2).toNat ((y : Int) + camObs.1 - s.core.cam.1).toNat
  | a => a

/-- 沿轨迹改写出一串动作（**不注入镜头**：这是模型自己走的路）。 -/
def witness (b : Board) : St → (Int × Int) → List RStep → List Act
  | _, _, [] => []
  | s, cam, r :: rest =>
    let a := retarget s cam r.act
    match step b s a with
    | .ok s' => a :: witness b s' r.next.cam rest
    | _ => [a]

/-- 这一串里有几下点击落在 64×64 视口外。读数，不是定理。 -/
def offView : List Act → Nat
  | [] => 0
  | .click x y :: rest => (if x < 64 && y < 64 then 0 else 1) + offView rest
  | _ :: rest => offView rest

/-- 这一串里有几下点击被改写过（坐标和真人点的不一样）。读数。 -/
def retargeted : List Act → List RStep → Nat
  | a :: as, r :: rs => (if a == r.act then 0 else 1) + retargeted as rs
  | _, _ => 0

end Game
