/-
# Obs/Corpus —— 逐条：模型面对全部真实转移（`lean2/export_levels.py` 生成，**不要手改**）

每一步都先把视口里的那部分**拉回观测**（`resync`：窗外的部分与撤销用的历史仍用模型的），
再走一步，和下一帧比。三个数：（对上, 对不上, 模型不说话）。

「模型不说话」只有一种：过关那一步——下一帧是下一关的盘，模型不描述它。
那一步不是没人核：`Proof/Levels.lean` 的 `_trace` 要求模型**在那一步**说「过关」。

每关一条定理把三个数钉死（走内核，不是 `#eval`）。
-/
import Obj.World
import Obs.Replay

namespace Game
namespace Corpus
open Replay

theorem C0 : corpusScan board0 start0 seen0_0 (stepsOf 0) = (7, 0, 1) := by decide +kernel
#print axioms C0

theorem C1 : corpusScan board1 start1 seen0_1 (stepsOf 1) = (33, 0, 1) := by decide +kernel
#print axioms C1

theorem C2 : corpusScan board2 start2 seen0_2 (stepsOf 2) = (49, 0, 1) := by decide +kernel
#print axioms C2

theorem C3 : corpusScan board3 start3 seen0_3 (stepsOf 3) = (51, 0, 1) := by decide +kernel
#print axioms C3

theorem C4 : corpusScan board4 start4 seen0_4 (stepsOf 4) = (143, 0, 1) := by decide +kernel
#print axioms C4

theorem C5 : corpusScan board5 start5 seen0_5 (stepsOf 5) = (135, 0, 1) := by decide +kernel
#print axioms C5

theorem C6 : corpusScan board6 start6 seen0_6 (stepsOf 6) = (237, 0, 1) := by decide +kernel
#print axioms C6

theorem C7 : corpusScan board7 start7 seen0_7 (stepsOf 7) = (77, 0, 1) := by decide +kernel
#print axioms C7

theorem C8 : corpusScan board8 start8 seen0_8 (stepsOf 8) = (112, 0, 1) := by decide +kernel
#print axioms C8

theorem C9 : corpusScan board9 start9 seen0_9 (stepsOf 9) = (52, 0, 0) := by decide +kernel
#print axioms C9

-- 两份现役之间的逐条对账用：沿轨迹每一步模型走的是哪一支（行号, 支名）。`lean2/verify.py` 读这一行。
#eval "BRANCHES " ++ toString ([(board0, start0, 0), (board1, start1, 1), (board2, start2, 2), (board3, start3, 3), (board4, start4, 4), (board5, start5, 5), (board6, start6, 6), (board7, start7, 7), (board8, start8, 8), (board9, start9, 9)].map (fun (bs : Board × St × Nat) => branches bs.1 bs.2.1 (stepsOf bs.2.2)))

end Corpus
end Game
