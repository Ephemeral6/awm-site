/-
# Obs/Check —— 判据层：**两把尺子，0 条定理**（照 `ledger/templates/lean/Check.lean`）

    agrees      一帧：模型说的 `Seen` 和看到的 `Seen` 对不对得上
    traceOk     一整关：只有开局是观测给的，**后面全是模型自己算的**，逐帧比
    corpusScan  逐条：**每一步都先把视口里的那部分拉回观测**（窗外的部分仍用模型的），再走一步比

## 比什么、不比什么（写在明处）

* 只在**观测那一帧看得见的格**上比（`o.vis`）；模型的视口必须**盖得住**这些格。
* **不比死局标记**：它不进模型（`Obj/Marks/Dead.lean`）。
* 选中框：模型的选中那一格若在观测可见的格里，就必须和观测的一样；不在就必须观测也没有。

## 一条明写的注入：镜头跳开

「跳」的那一下镜头有时会一下子跳开（语料 8 次），跳到哪模型说不出来。
那几步的 `RStep.inj` 带着观测到的镜头，走完这一步之后把模型的镜头**换成它**（`inject`）。
**这是拿观测续命，只续镜头这一个量、只续这 8 次**；次数进读数、上页面。
它不碰盘面：跳完之后车在哪、子在哪、选中在哪，照样全是模型自己算的。
-/
import Obj.World
import Obs.Project

namespace Game

/-- 轨迹上的一步（`Obs/Replay.lean` 里存的就是它）。 -/
structure RStep where
  /-- 语料里的第几行（0 起）。只用来对账，切片不按它。 -/
  row : Nat
  /-- **步号**：这一步自己的身份，唯一（导出器数过一遍重号，有就停）。 -/
  step : Nat
  lvl : Nat
  act : Act
  /-- 这一步之后那一帧看到的。 -/
  next : Seen
  /-- 这一步之后镜头跳开到哪（观测给的，见文件头）；`none` = 没跳开。 -/
  inj : Option (Int × Int)
  /-- 这一步是这一关的最后一步（过关 / 通关）。 -/
  ends : Bool
  /-- 这一步之后那一帧还是这一关的盘吗（换进下一关的那一帧是另一张版图，不比）。 -/
  cmp : Bool
deriving Repr

/-- 一帧对不对得上。 -/
def agrees (m o : Seen) : Bool :=
  m.cam == o.cam
  && (m.vis &&& o.vis) == o.vis
  && (m.holes &&& o.vis) == o.holes
  && (m.rails &&& o.vis) == o.rails
  && (m.carts &&& o.vis) == o.carts
  && (m.pegs &&& o.vis) == o.pegs
  && (m.greys &&& o.vis) == o.greys
  && (m.darks &&& o.vis) == o.darks
  && (m.stones &&& o.vis) == o.stones
  && (m.rings &&& o.vis) == o.rings
  && (match m.sel with | some q => if has o.vis q then some q else none | none => none) == o.sel
  && m.hud == o.hud

/-- 注入镜头（见文件头）。 -/
def inject (s : St) : Option (Int × Int) → St
  | none => s
  | some c => { s with core := { s.core with cam := c } }

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算的状态。**
    最后一步必须是模型说的「过关」，而且只许是最后一步。 -/
def traceOk (b : Board) : St → List RStep → Bool
  | _, [] => true
  | s, r :: rest =>
    match step b s r.act with
    | .ok s' => !r.ends && agrees (seenOf b (inject s' r.inj)) r.next && traceOk b (inject s' r.inj) rest
    | .won s' => r.ends && rest.isEmpty && (!r.cmp || agrees (seenOf b s') r.next)
    | .na => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (b : Board) : St → List RStep → Nat → Option Nat
  | _, [], _ => none
  | s, r :: rest, i =>
    match step b s r.act with
    | .ok s' => if !r.ends && agrees (seenOf b (inject s' r.inj)) r.next
                then firstSplit b (inject s' r.inj) rest (i + 1) else some i
    | .won s' => if r.ends && rest.isEmpty && (!r.cmp || agrees (seenOf b s') r.next) then none else some i
    | .na => some i

/-! ## 逐条那一层：每一步先把视口拉回观测 -/

/-- 视口格的一组 → 版图上的那几格（`proj` 的反方向）。 -/
def unproj (b : Board) (cam : Int × Int) (m : Mask) : Mask :=
  let ph := phase b.wp cam
  let o := offs b cam
  let n := colsVisible ph.2
  (List.range VW).foldl
    (fun (acc : Mask) (i : Nat) =>
      let r : Int := o.1 + (i : Int)
      if rowVisible ph.1 i && 0 ≤ r && r < b.h then
        let bits := (m >>> (VW * i)) % 2 ^ n
        let row := if 0 ≤ o.2 then (bits <<< o.2.toNat) % 2 ^ b.w else (bits >>> (-o.2).toNat) % 2 ^ b.w
        acc ||| (row <<< (r.toNat * b.w))
      else acc) 0

/-- 视口格编号 → 版图位编号。 -/
def unprojCell (b : Board) (cam : Int × Int) (q : Nat) : Nat :=
  let o := offs b cam
  ((o.1 + (q / VW : Nat)) * b.w + (o.2 + (q % VW : Nat))).toNat

/-- 把模型状态里**观测看得见的那一块**换成观测；窗外的部分、撤销用的历史照旧。 -/
def resync (b : Board) (s : St) (o : Seen) : St :=
  let win := unproj b o.cam o.vis
  let fix := fun (x ox : Mask) => diff x win ||| unproj b o.cam ox
  let c := s.core
  { core := { carts := fix c.carts o.carts
              pegs := fix c.pegs o.pegs
              greys := fix c.greys o.greys
              darks := fix c.darks o.darks
              stones := fix c.stones o.stones
              sel := match o.sel with
                | some q => some (unprojCell b o.cam q)
                | none => match c.sel with
                  | some p => if has win p then none else some p
                  | none => none
              cam := o.cam }
    hud := o.hud
    hist := s.hist }

/-- 逐条：（对上, 对不上, 模型不说话）。 -/
def corpusScan (b : Board) : St → Seen → List RStep → Nat × Nat × Nat
  | _, _, [] => (0, 0, 0)
  | s, o, r :: rest =>
    let s0 := resync b s o
    match step b s0 r.act with
    | .ok s' =>
      let good := !r.ends && agrees (seenOf b (inject s' r.inj)) r.next
      let t := corpusScan b (inject s' r.inj) r.next rest
      if good then (t.1 + 1, t.2.1, t.2.2) else (t.1, t.2.1 + 1, t.2.2)
    | .won s' =>
      let t := corpusScan b s' r.next rest
      if !r.cmp then (t.1, t.2.1, t.2.2 + 1)
      else if r.ends && agrees (seenOf b s') r.next then (t.1 + 1, t.2.1, t.2.2)
      else (t.1, t.2.1 + 1, t.2.2)
    | .na =>
      let t := corpusScan b s0 r.next rest
      (t.1, t.2.1, t.2.2 + 1)

/-- 这一步模型走的是哪一支（给两份现役之间的逐条对账用：Python 规则的论域 vs 这里的分支）。 -/
def branchOf (b : Board) (s : St) : Act → String
  | .key _ => "keys_push_carts"
  | .undo => "undo_restores"
  | .click x y =>
    match cellAt b s.core.cam x y with
    | none => if s.core.sel.isSome then "na" else "click_inert"
    | some q =>
      if isJump b s.core q then "click_jumps"
      else if s.core.sel.isSome then "na"
      else if canSelect b s.core q then "click_selects"
      else "click_inert"

/-- 沿轨迹（带注入）列出每一步的分支。读数，不是定理。 -/
def branches (b : Board) : St → List RStep → List (Nat × String)
  | _, [] => []
  | s, r :: rest =>
    let br := branchOf b s r.act
    match step b s r.act with
    | .ok s' => (r.row, br) :: branches b (inject s' r.inj) rest
    | .won _ => [(r.row, br)]
    | .na => [(r.row, br)]

end Game
