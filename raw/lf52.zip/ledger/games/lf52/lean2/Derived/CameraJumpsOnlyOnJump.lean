/-
# Derived/CameraJumpsOnlyOnJump —— 不跳就不挪镜头（对应 `rule/camera/camera_jumps_only_on_jump.py`）

**身份：推论。** Python 那一边它是一条要逐帧判的规则；这一边它**不是一条独立的规则**：
点击那一支（`Step.clickStep`）除了「跳」之外，只会调 `select` 或 `inert`，
而这两个都不碰镜头——于是「没有真的跳，镜头就不挪」是**分发的形状**推出来的。

它不空：把 `Rule/Move/ClickSelects.select` 改成顺手挪一下镜头，这一条当场证不出来。
-/
import Obj.World
import Step

namespace Game

theorem camera_still_unless_jump (b : Board) (s s' : St) (x y : Nat)
    (h : step b s (.click x y) = .ok s')
    (hj : ∀ q, cellAt b s.core.cam x y = some q → isJump b s.core q = false) :
    s'.core.cam = s.core.cam := by
  simp only [step, clickStep] at h
  split at h
  · split at h
    · simp at h
    · simp only [Res.ok.injEq] at h; subst h; rfl
  · rename_i q hq
    rw [hj q hq] at h
    simp only [Bool.false_eq_true, ite_false] at h
    split at h
    · simp at h
    · split at h
      · simp only [Res.ok.injEq] at h; subst h; rfl
      · simp only [Res.ok.injEq] at h; subst h; rfl

#print axioms camera_still_unless_jump

end Game
