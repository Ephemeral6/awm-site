/-
# Derived/TerrainIsStatic —— 地形不动（对应 `rule/response/terrain_is_static.py`）

**身份：推论**——而且是最便宜的那一种：**表示不出来**。

孔和轨住在 `Board` 里，`Board` 不是状态的字段，`step` 返回的状态里没有它。
所以「走一步地形变了」这件事**说都说不出来**。能说出来、还值得写成一条定理的只剩一句：
**视口里看到的地形只取决于镜头**——两个状态镜头一样，看到的孔和轨就一样，不管盘上别的怎么变。

这条定理几乎是空的，它空得有道理：把地形搬出状态，本来就是为了让它空。
Python 那一边这条规则每一步都要对齐一次两帧（`derive/camera`），这一边一句话。
-/
import Obj.World
import Obs.Project

namespace Game

/-- 视口里看到的孔和轨（轨只报没被车盖住的那几格，所以带上车）。 -/
def seenTerrain (b : Board) (s : St) : Mask × Mask :=
  ((seenOf b s).holes, proj b s.core.cam b.rails)

theorem terrain_view_depends_on_camera_only (b : Board) (s s' : World)
    (h : s.core.cam = s'.core.cam) : seenTerrain b s = seenTerrain b s' := by
  simp only [seenTerrain, seenOf, h]

#print axioms terrain_view_depends_on_camera_only

/-- 一步之后镜头没挪，看到的地形就一格不变（任何动作）。 -/
theorem terrain_still_when_camera_still (b : Board) (s s' : St) (a : Act)
    (_h : step b s a = .ok s') (hc : s'.core.cam = s.core.cam) :
    seenTerrain b s' = seenTerrain b s :=
  terrain_view_depends_on_camera_only b s' s hc

#print axioms terrain_still_when_camera_still

end Game
