/-
# Step —— 一步怎么走：**只做分发，0 条定理**

动作分三支；点击再按「真跳 / 有选中却没点中环 / 能选中 / 别的」分四支。
每一支调哪条规则写在右边。规则的内容全在 `Rule/` 下，这里一行判断都不加。

    key d        → Rule/Move/KeysPushCarts.pushCarts + Rule/Camera/CameraFollowsPegCart.follow
    click x y    → 点中的格是环         → Rule/Move/ClickJumps.jump（+ Rule/Win.isGoal 判过关）
                   有选中却没点中环     → na（语料 0 次，模型不说话）
                   点中能选中的东西     → Rule/Move/ClickSelects.select
                   别的                 → Rule/Move/ClickInert.inert
    undo         → Rule/Move/UndoRestores.undoCore
    每一支都     → Rule/Response/HudCountsSteps.tick

**镜头跳开不在这里。** 跳的那一下镜头有时会一下子跳开，跳到哪模型说不出来——
那 8 次在逐帧比对里是**明写的注入**（`Obs/Check.lean` 的 `inject`），不是这里的一支。
-/
import Rule.Move.ClickSelects
import Rule.Move.ClickJumps
import Rule.Move.ClickInert
import Rule.Move.KeysPushCarts
import Rule.Move.UndoRestores
import Rule.Camera.CameraFollowsPegCart
import Rule.Win.LevelupOnLastCapture
import Rule.Response.HudCountsSteps

namespace Game

/-- 视口像素 (x, y) 点中了哪一格（世界格的位编号）；点在缝里或版图外返回 `none`。 -/
def cellAt (b : Board) (cam : Int × Int) (x y : Nat) : Option Nat :=
  let ry := (y : Int) + cam.1 - b.wp.1
  let rx := (x : Int) + cam.2 - b.wp.2
  if ry % 6 < 4 && rx % 6 < 4 then
    let r := ry / 6 - b.i0
    let c := rx / 6 - b.j0
    if 0 ≤ r && r < b.h && 0 ≤ c && c < b.w then some (r.toNat * b.w + c.toNat) else none
  else none

/-- 记下「这一步之前」的盘面（撤销键要用），计数条加一。 -/
def remember (s : St) (c : Core) : St := { core := c, hud := tick s.hud, hist := some s.core }

def clickStep (b : Board) (s : St) (x y : Nat) : Res :=
  match cellAt b s.core.cam x y with
  | none => if s.core.sel.isSome then .na else .ok (remember s (inert s.core))
  | some q =>
    if isJump b s.core q then
      if isGoal (jump s.core q) then .won (remember s (jump s.core q))
      else .ok (remember s (jump s.core q))
    else if s.core.sel.isSome then .na
    else if canSelect b s.core q then .ok (remember s (select s.core q))
    else .ok (remember s (inert s.core))

def keyStep (b : Board) (s : St) (d : Dir) : Res :=
  .ok (remember s { pushCarts b s.core d with
    cam := follow b s.core.cam d ((s.core.pegs &&& movers b s.core d) != 0) })

def undoStep (s : St) : Res :=
  match undoCore s with
  | some c => .ok { core := c, hud := tick s.hud, hist := none }
  | none => .na

/-- 一步。 -/
def step (b : Board) (s : St) : Act → Res
  | .key d => keyStep b s d
  | .click x y => clickStep b s x y
  | .undo => undoStep s

end Game
