/-
# Proof/Scenes —— 手造的教学盘：给「走不通」那把钥匙配三条防线

一把「对谁都说走不通」的钥匙也能满绿——它从不说能赢，永远不会被反例打死。
所以钥匙 `NoPegs`（`Proof/Reachable.lean`）配一张**只差一处**的盘：

    scene_winnable          有两颗子的那张盘确实走得通（两下点击，内核算）
    scene_closed_at_start   而且不是因为它一开始就已经过关
    scene_not_key           而且钥匙的前提在它身上真的不满足（有子）
    scene_empty_unsolvable  把两颗子拿掉（只差这一处），钥匙套上去：怎么走都过不了关

盘：宽 7 高 5（四周各留两格），中间一行三个孔，镜头 (0,0)，世界格 (0,0) 的格芯在像素 (0,0)。
-/
import Obj.World
import Proof.Reachable

namespace Game
namespace Scenes

def sceneB : Board :=
  { w := 7, h := 5, i0 := 0, j0 := 0, wp := (0, 0)
    holes := bit (2 * 7 + 2) ||| bit (2 * 7 + 3) ||| bit (2 * 7 + 4)
    rails := 0, pan := (0, 0), loR := none, hiR := none, loC := none, hiC := none }

/-- 左边两个孔上各一颗子。 -/
def sceneWin : St :=
  { core := { carts := 0, pegs := bit (2 * 7 + 2) ||| bit (2 * 7 + 3), greys := 0, darks := 0,
              stones := 0, sel := none, cam := (0, 0) }, hud := 0, hist := none }

/-- 同一张盘，把两颗子拿掉——只差这一处。 -/
def sceneEmpty : St := { sceneWin with core := { sceneWin.core with pegs := 0 } }

/-- 点 (13,13) 选中左边那颗（格 (2,2) 的格芯在像素 12..15），点 (25,13) 跳到右边的孔（格 (2,4)）。 -/
def winPlay : List Act := [.click 13 13, .click 25 13]

theorem scene_winnable : Winnable sceneB (sceneWin : World) := ⟨winPlay, by decide +kernel⟩
#print axioms scene_winnable

theorem scene_closed_at_start : isGoal sceneWin.core = false := by decide
#print axioms scene_closed_at_start

theorem scene_not_key : ¬ NoPegs (sceneWin : World) := by
  intro h
  exact absurd h.1 (by decide)
#print axioms scene_not_key

theorem scene_empty_unsolvable : Unsolvable sceneB (sceneEmpty : World) :=
  unsolvable_nopegs sceneB sceneEmpty ⟨rfl, by intro h hh; simp [sceneEmpty, sceneWin] at hh⟩
#print axioms scene_empty_unsolvable

end Scenes
end Game
