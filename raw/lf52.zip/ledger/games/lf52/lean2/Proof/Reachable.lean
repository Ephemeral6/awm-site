/-
# Proof/Reachable —— 这个**局面**做不做得了（骨架照 `ledger/templates/lean/Reachable.lean`）

    Winnable   b s  :=  ∃ as, 照着走中途过关
    Unsolvable b s  :=  ∀ as, 照着走从没过关

## 一处削弱，写在明处

`everWon` 碰到模型**说不出话**的那一支（`Res.na`：有选中却没点中环、没有可撤的撤销）返回 `false`。
所以 `Unsolvable` 准确的意思是：**不经过「模型说不出话」的那几步，就过不了关**。
这一半句不许含糊过去——它同样写在 `Proof/Levels.lean` 与页面上。

**这一局十关都走得通**（每关的 `_winnable` 在 `Proof/Levels.lean`），所以没有一关用得上下面的骨架。
骨架与一把钥匙照样写出来、证出来，并配上三条防线——为的是「走不通」这句话在这套形式化里
**有一条真能说出口的路**，而不是一个空着的接口。
-/
import Obj.World
import Step

namespace Game

/-- 从 `s` 出发照 `as` 走，中途有没有哪一步过关。模型说不出话（`na`）就算没过。 -/
def everWon (b : Board) : St → List Act → Bool
  | _, [] => false
  | s, a :: rest =>
    match step b s a with
    | .won _ => true
    | .ok s' => everWon b s' rest
    | .na => false

def Winnable (b : Board) (s : World) : Prop := ∃ as : List Act, everWon b s as = true
def Unsolvable (b : Board) (s : World) : Prop := ∀ as : List Act, everWon b s as = false

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (s : World) (hw : Winnable b s) (hu : Unsolvable b s) : False := by
  obtain ⟨as, h⟩ := hw
  rw [hu as] at h
  exact Bool.false_ne_true h

#print axioms not_both

/-! ## 骨架：不变量 ⇒ 不可做（全文唯一做归纳的地方，与盘多大、走多少步都无关） -/

theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ s s' a, P s → step b s a = .ok s' → P s')
    (hwin : ∀ s a s', P s → step b s a ≠ .won s') :
    ∀ s : World, P s → Unsolvable b s := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hs : step b s a with
    | won s' => exact absurd hs (hwin s a s' hp)
    | ok s' => exact ih s' (hkeep s s' a hp hs)
    | na => rfl

#print axioms unsolvable_of_invariant

/-! ## 一把钥匙：盘上（连同撤销能找回的那一步）一颗子都没有

    理由不是「挡住了」：盘上什么障碍都没有也一样——**子不会凭空生出来**，
    而过关要的是恰好一颗子。跳只挪子、吃子；推车只让子跟着车走；撤销只能找回上一步的盘，
    而上一步的盘也一颗子都没有。 -/

/-- 钥匙：现在和「上一步之前」都一颗子都没有。 -/
def NoPegs (s : St) : Prop := s.core.pegs = 0 ∧ ∀ h, s.hist = some h → h.pegs = 0

theorem nopegs_keep (b : Board) : ∀ s s' a, NoPegs s → step b s a = .ok s' → NoPegs s' := by
  have ride_zero : ∀ (w : Nat) (mv : Mask) (d : Dir), ride w mv d 0 = 0 := by
    intro w mv d; cases d <;> simp [ride, diff, shiftD]
  have moveOne_zero : ∀ (p t : Nat), moveOne p t 0 = 0 := by
    intro p t; simp [moveOne, has]
  intro s s' a ⟨h0, hh⟩ hs
  cases a with
  | key d =>
    simp only [step, keyStep, Res.ok.injEq] at hs
    subst hs
    refine ⟨?_, ?_⟩
    · simp [remember, pushCarts, h0, ride_zero]
    · intro h hh'; simp [remember] at hh'; subst hh'; exact h0
  | undo =>
    simp only [step, undoStep, undoCore] at hs
    split at hs
    · rename_i c hc
      simp only [Res.ok.injEq] at hs; subst hs
      exact ⟨hh c hc, by intro h hh'; simp at hh'⟩
    · simp at hs
  | click x y =>
    simp only [step, clickStep] at hs
    split at hs
    · split at hs
      · simp at hs
      · simp only [Res.ok.injEq] at hs; subst hs
        exact ⟨by simp [remember, inert, h0], by intro h hh'; simp [remember] at hh'; subst hh'; exact h0⟩
    · split at hs
      · split at hs
        · simp at hs
        · simp only [Res.ok.injEq] at hs; subst hs
          refine ⟨?_, by intro h hh'; simp [remember] at hh'; subst hh'; exact h0⟩
          simp only [remember, jump]
          split
          · exact h0
          · simp [h0, moveOne_zero, has]
      · split at hs
        · simp at hs
        · split at hs
          · simp only [Res.ok.injEq] at hs; subst hs
            exact ⟨by simp [remember, select, h0], by intro h hh'; simp [remember] at hh'; subst hh'; exact h0⟩
          · simp only [Res.ok.injEq] at hs; subst hs
            exact ⟨by simp [remember, inert, h0], by intro h hh'; simp [remember] at hh'; subst hh'; exact h0⟩

#print axioms nopegs_keep

theorem nopegs_no_win (b : Board) : ∀ s a s', NoPegs s → step b s a ≠ .won s' := by
  have moveOne_zero : ∀ (p t : Nat), moveOne p t 0 = 0 := by
    intro p t; simp [moveOne, has]
  intro s a s' ⟨h0, _⟩ hs
  cases a with
  | key d => simp [step, keyStep] at hs
  | undo =>
    simp only [step, undoStep, undoCore] at hs
    split at hs <;> simp at hs
  | click x y =>
    simp only [step, clickStep] at hs
    split at hs
    · split at hs <;> simp at hs
    · split at hs
      · rename_i q _ hj
        split at hs
        · rename_i hg
          simp only [isGoal, jump] at hg
          split at hg
          · simp [h0, popc] at hg
          · simp [h0, moveOne_zero, has, popc] at hg
        · simp at hs
      · split at hs
        · simp at hs
        · split at hs <;> simp at hs

#print axioms nopegs_no_win

/-- 钥匙挂上骨架：一颗子都没有的盘，怎么走都过不了关（不经过「模型说不出话」的那几步）。 -/
theorem unsolvable_nopegs (b : Board) (s : World) (h : NoPegs s) : Unsolvable b s :=
  unsolvable_of_invariant b NoPegs (nopegs_keep b) (nopegs_no_win b) s h

#print axioms unsolvable_nopegs

end Game
