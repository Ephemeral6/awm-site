/-
# Proof/Levels —— 每一关一条定理（`lean2/export_levels.py` 生成，**不要手改**）

    L<k>_len        这一段有几步
    L<k>_start      模型的开局投到视口上，和这一关第一帧对得上
    L<k>_trace      沿真人那条路一步不差（只有开局是观测给的，后面全是模型自己算的）
    L<k>_winnable   这一关走得通 —— 见证是真人那条路（点击按模型的镜头改写）

`_winnable` 与 `_unsolvable` 不能同时有（`Proof/Reachable.lean` 的 `not_both`）。
这一局十关都是 `_winnable`。

**两条明写的口径**（页面照抄，不许升格）：
* `_trace` 里「镜头跳开」那几步的镜头是注入的（见 `Obs/Check.lean`），别的每一样都是模型算的；
* 开局比第一帧多知道窗外的东西（整关取并集 + 搜出来的窗外的车，见 `lean2/levelmap.py`）。
-/
import Obj.World
import Obs.Replay
import Obs.Witness
import Proof.Reachable

-- 这一条是**独立的一条命令**：夹在文档注释和定理之间会变成语法错误。
-- 实测：`_len` 用不带 `+kernel` 的 `decide` 撞 maxRecDepth，Lean 报一行错然后照常往下编，
-- 那条定理的公理表里悄悄多出 `sorryAx`——而同一份文件里别的定理照样干净。
set_option maxRecDepth 20000

namespace Game
namespace Levels
open Replay

/-! ## 第 0 关：8 步，逐帧核过 7 步，镜头注入 0 次 -/

theorem L0_len : (stepsOf 0).length = 8 := by decide +kernel
#print axioms L0_len

theorem L0_start : agrees (seenOf board0 (start0 : World)) seen0_0 = true := by decide +kernel
#print axioms L0_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L0_trace : traceOk board0 start0 (stepsOf 0) = true := by decide +kernel
#print axioms L0_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L0_winnable : Winnable board0 (start0 : World) :=
  ⟨witness board0 start0 (0, 0) (stepsOf 0), by decide +kernel⟩
#print axioms L0_winnable

#eval "LEVEL 0 steps=" ++ toString (stepsOf 0).length
  ++ " witness=" ++ toString (witness board0 start0 (0, 0) (stepsOf 0)).length
  ++ " retargeted=" ++ toString (retargeted (witness board0 start0 (0, 0) (stepsOf 0)) (stepsOf 0))
  ++ " offview=" ++ toString (offView (witness board0 start0 (0, 0) (stepsOf 0)))

/-! ## 第 1 关：34 步，逐帧核过 33 步，镜头注入 0 次 -/

theorem L1_len : (stepsOf 1).length = 34 := by decide +kernel
#print axioms L1_len

theorem L1_start : agrees (seenOf board1 (start1 : World)) seen0_1 = true := by decide +kernel
#print axioms L1_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L1_trace : traceOk board1 start1 (stepsOf 1) = true := by decide +kernel
#print axioms L1_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L1_winnable : Winnable board1 (start1 : World) :=
  ⟨witness board1 start1 (0, 0) (stepsOf 1), by decide +kernel⟩
#print axioms L1_winnable

#eval "LEVEL 1 steps=" ++ toString (stepsOf 1).length
  ++ " witness=" ++ toString (witness board1 start1 (0, 0) (stepsOf 1)).length
  ++ " retargeted=" ++ toString (retargeted (witness board1 start1 (0, 0) (stepsOf 1)) (stepsOf 1))
  ++ " offview=" ++ toString (offView (witness board1 start1 (0, 0) (stepsOf 1)))

/-! ## 第 2 关：50 步，逐帧核过 49 步，镜头注入 0 次 -/

theorem L2_len : (stepsOf 2).length = 50 := by decide +kernel
#print axioms L2_len

theorem L2_start : agrees (seenOf board2 (start2 : World)) seen0_2 = true := by decide +kernel
#print axioms L2_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L2_trace : traceOk board2 start2 (stepsOf 2) = true := by decide +kernel
#print axioms L2_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L2_winnable : Winnable board2 (start2 : World) :=
  ⟨witness board2 start2 (0, 0) (stepsOf 2), by decide +kernel⟩
#print axioms L2_winnable

#eval "LEVEL 2 steps=" ++ toString (stepsOf 2).length
  ++ " witness=" ++ toString (witness board2 start2 (0, 0) (stepsOf 2)).length
  ++ " retargeted=" ++ toString (retargeted (witness board2 start2 (0, 0) (stepsOf 2)) (stepsOf 2))
  ++ " offview=" ++ toString (offView (witness board2 start2 (0, 0) (stepsOf 2)))

/-! ## 第 3 关：52 步，逐帧核过 51 步，镜头注入 2 次 -/

theorem L3_len : (stepsOf 3).length = 52 := by decide +kernel
#print axioms L3_len

theorem L3_start : agrees (seenOf board3 (start3 : World)) seen0_3 = true := by decide +kernel
#print axioms L3_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L3_trace : traceOk board3 start3 (stepsOf 3) = true := by decide +kernel
#print axioms L3_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L3_winnable : Winnable board3 (start3 : World) :=
  ⟨witness board3 start3 (0, 0) (stepsOf 3), by decide +kernel⟩
#print axioms L3_winnable

#eval "LEVEL 3 steps=" ++ toString (stepsOf 3).length
  ++ " witness=" ++ toString (witness board3 start3 (0, 0) (stepsOf 3)).length
  ++ " retargeted=" ++ toString (retargeted (witness board3 start3 (0, 0) (stepsOf 3)) (stepsOf 3))
  ++ " offview=" ++ toString (offView (witness board3 start3 (0, 0) (stepsOf 3)))

/-! ## 第 4 关：144 步，逐帧核过 143 步，镜头注入 1 次 -/

theorem L4_len : (stepsOf 4).length = 144 := by decide +kernel
#print axioms L4_len

theorem L4_start : agrees (seenOf board4 (start4 : World)) seen0_4 = true := by decide +kernel
#print axioms L4_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L4_trace : traceOk board4 start4 (stepsOf 4) = true := by decide +kernel
#print axioms L4_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L4_winnable : Winnable board4 (start4 : World) :=
  ⟨witness board4 start4 (0, 0) (stepsOf 4), by decide +kernel⟩
#print axioms L4_winnable

#eval "LEVEL 4 steps=" ++ toString (stepsOf 4).length
  ++ " witness=" ++ toString (witness board4 start4 (0, 0) (stepsOf 4)).length
  ++ " retargeted=" ++ toString (retargeted (witness board4 start4 (0, 0) (stepsOf 4)) (stepsOf 4))
  ++ " offview=" ++ toString (offView (witness board4 start4 (0, 0) (stepsOf 4)))

/-! ## 第 5 关：136 步，逐帧核过 135 步，镜头注入 2 次 -/

theorem L5_len : (stepsOf 5).length = 136 := by decide +kernel
#print axioms L5_len

theorem L5_start : agrees (seenOf board5 (start5 : World)) seen0_5 = true := by decide +kernel
#print axioms L5_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L5_trace : traceOk board5 start5 (stepsOf 5) = true := by decide +kernel
#print axioms L5_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L5_winnable : Winnable board5 (start5 : World) :=
  ⟨witness board5 start5 (0, 0) (stepsOf 5), by decide +kernel⟩
#print axioms L5_winnable

#eval "LEVEL 5 steps=" ++ toString (stepsOf 5).length
  ++ " witness=" ++ toString (witness board5 start5 (0, 0) (stepsOf 5)).length
  ++ " retargeted=" ++ toString (retargeted (witness board5 start5 (0, 0) (stepsOf 5)) (stepsOf 5))
  ++ " offview=" ++ toString (offView (witness board5 start5 (0, 0) (stepsOf 5)))

/-! ## 第 6 关：238 步，逐帧核过 237 步，镜头注入 2 次 -/

theorem L6_len : (stepsOf 6).length = 238 := by decide +kernel
#print axioms L6_len

theorem L6_start : agrees (seenOf board6 (start6 : World)) seen0_6 = true := by decide +kernel
#print axioms L6_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L6_trace : traceOk board6 start6 (stepsOf 6) = true := by decide +kernel
#print axioms L6_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L6_winnable : Winnable board6 (start6 : World) :=
  ⟨witness board6 start6 (0, 0) (stepsOf 6), by decide +kernel⟩
#print axioms L6_winnable

#eval "LEVEL 6 steps=" ++ toString (stepsOf 6).length
  ++ " witness=" ++ toString (witness board6 start6 (0, 0) (stepsOf 6)).length
  ++ " retargeted=" ++ toString (retargeted (witness board6 start6 (0, 0) (stepsOf 6)) (stepsOf 6))
  ++ " offview=" ++ toString (offView (witness board6 start6 (0, 0) (stepsOf 6)))

/-! ## 第 7 关：78 步，逐帧核过 77 步，镜头注入 0 次 -/

theorem L7_len : (stepsOf 7).length = 78 := by decide +kernel
#print axioms L7_len

theorem L7_start : agrees (seenOf board7 (start7 : World)) seen0_7 = true := by decide +kernel
#print axioms L7_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L7_trace : traceOk board7 start7 (stepsOf 7) = true := by decide +kernel
#print axioms L7_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L7_winnable : Winnable board7 (start7 : World) :=
  ⟨witness board7 start7 (0, 0) (stepsOf 7), by decide +kernel⟩
#print axioms L7_winnable

#eval "LEVEL 7 steps=" ++ toString (stepsOf 7).length
  ++ " witness=" ++ toString (witness board7 start7 (0, 0) (stepsOf 7)).length
  ++ " retargeted=" ++ toString (retargeted (witness board7 start7 (0, 0) (stepsOf 7)) (stepsOf 7))
  ++ " offview=" ++ toString (offView (witness board7 start7 (0, 0) (stepsOf 7)))

/-! ## 第 8 关：113 步，逐帧核过 112 步，镜头注入 1 次 -/

theorem L8_len : (stepsOf 8).length = 113 := by decide +kernel
#print axioms L8_len

theorem L8_start : agrees (seenOf board8 (start8 : World)) seen0_8 = true := by decide +kernel
#print axioms L8_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L8_trace : traceOk board8 start8 (stepsOf 8) = true := by decide +kernel
#print axioms L8_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L8_winnable : Winnable board8 (start8 : World) :=
  ⟨witness board8 start8 (0, 0) (stepsOf 8), by decide +kernel⟩
#print axioms L8_winnable

#eval "LEVEL 8 steps=" ++ toString (stepsOf 8).length
  ++ " witness=" ++ toString (witness board8 start8 (0, 0) (stepsOf 8)).length
  ++ " retargeted=" ++ toString (retargeted (witness board8 start8 (0, 0) (stepsOf 8)) (stepsOf 8))
  ++ " offview=" ++ toString (offView (witness board8 start8 (0, 0) (stepsOf 8)))

/-! ## 第 9 关：52 步，逐帧核过 52 步，镜头注入 0 次 -/

theorem L9_len : (stepsOf 9).length = 52 := by decide +kernel
#print axioms L9_len

theorem L9_start : agrees (seenOf board9 (start9 : World)) seen0_9 = true := by decide +kernel
#print axioms L9_start

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L9_trace : traceOk board9 start9 (stepsOf 9) = true := by decide +kernel
#print axioms L9_trace

/-- **这一关走得通。** 见证是真人那条路（点击坐标按模型自己的镜头改写，见 `Obs/Witness.lean`）。 -/
theorem L9_winnable : Winnable board9 (start9 : World) :=
  ⟨witness board9 start9 (0, 0) (stepsOf 9), by decide +kernel⟩
#print axioms L9_winnable

#eval "LEVEL 9 steps=" ++ toString (stepsOf 9).length
  ++ " witness=" ++ toString (witness board9 start9 (0, 0) (stepsOf 9)).length
  ++ " retargeted=" ++ toString (retargeted (witness board9 start9 (0, 0) (stepsOf 9)) (stepsOf 9))
  ++ " offview=" ++ toString (offView (witness board9 start9 (0, 0) (stepsOf 9)))

end Levels
end Game
