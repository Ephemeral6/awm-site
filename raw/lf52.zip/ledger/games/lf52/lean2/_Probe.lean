import Obs.Replay
open Game Game.Replay

#eval (agrees (seenOf board0 start0) seen0_0, firstSplit board0 start0 (stepsOf 0) 0)
#eval (agrees (seenOf board1 start1) seen0_1, firstSplit board1 start1 (stepsOf 1) 0)
#eval (agrees (seenOf board2 start2) seen0_2, firstSplit board2 start2 (stepsOf 2) 0)
#eval (agrees (seenOf board3 start3) seen0_3, firstSplit board3 start3 (stepsOf 3) 0)
#eval (agrees (seenOf board4 start4) seen0_4, firstSplit board4 start4 (stepsOf 4) 0)
#eval (agrees (seenOf board5 start5) seen0_5, firstSplit board5 start5 (stepsOf 5) 0)
#eval (agrees (seenOf board6 start6) seen0_6, firstSplit board6 start6 (stepsOf 6) 0)
#eval (agrees (seenOf board7 start7) seen0_7, firstSplit board7 start7 (stepsOf 7) 0)
#eval (agrees (seenOf board8 start8) seen0_8, firstSplit board8 start8 (stepsOf 8) 0)
#eval (agrees (seenOf board9 start9) seen0_9, firstSplit board9 start9 (stepsOf 9) 0)
