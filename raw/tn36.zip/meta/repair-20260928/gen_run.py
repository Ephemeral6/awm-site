"""带全机并发上限的数据段生成：同一时间最多 2 个 formalize.py build（每个要把一局全部帧读进内存，
2026-09-29 六个同时跑把本机内存与页面文件耗尽）。

    python meta/repair-20260928/gen_run.py <局> --full-route --lib <lib> --out <目录>

参数原样转给 `world/formalize.py build`。退出码就是生成器的退出码。check.py 的 K3 复算也经由这里取槽。
"""
from __future__ import annotations

import subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(HERE))
import lean_run  # noqa: E402

GENLOCKS = HERE / "_work" / "_genlocks"


def run(args: list[str]) -> subprocess.CompletedProcess:
    slot = lean_run.acquire(GENLOCKS)
    try:
        return subprocess.run([sys.executable, str(ROOT / "world" / "formalize.py"), "build", *args],
                              cwd=ROOT, capture_output=True)
    finally:
        try:
            slot.unlink()
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    p = run(sys.argv[1:])
    sys.stdout.buffer.write(p.stdout); sys.stderr.buffer.write(p.stderr)
    sys.exit(p.returncode)
