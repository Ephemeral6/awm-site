"""底栏恰好四个方向框、右面板槽数是偶数的关卡里，件所在格「行+列」的奇偶性，任何一个动作都改不了。"""
LEVEL = "L2"
SCOPE = ("只看底栏恰好四个框且每个框里都有偏离框心的图标（four_dir_boxes）、"
         "右面板读得出来且槽数是**偶数**、前后两帧都读得出件所在格的那些转移；"
         "五框关卡（带放大/缩小/旋转的那一套）返回 NA——那里件的倍数会变，「占哪一格」这个说法本身就要重写；"
         "槽数为奇数的四框关卡返回 NA（那里这一条该说的是「奇偶必翻」，但一道作废的程序件不动、奇偶不翻，"
         "两种情形要分开量，没量过就不说）；换关返回 NA")
NOTE = ("v2（同一批，装置的口径审计当场点的）：「换关返回 NA」这句话只有结算时判得出来——"
        "预测口径下 level_next 就等于 level_prev，这一条照样开口，抽查里 1/200 条这么变脸。"
        "换关是整屏重画，重画之后的「件在第几格」跟重画之前根本不是同一块盘上的事。"
        "改成从帧上认同一块盘：**前后两帧的棋盘框、墙、空腔三者都一样**，才算同一块盘，才说话。"
        "这不绕圈——这一条断言的是件的位置，不是墙的位置。"
        "（第 513 步 disc_runs_program、第 561 步 counter_pays_every_other 吃的都是同一个病："
        "拿 ctx 的事后字段划的边界，在预测口径下是虚的。）\n"
        "由来是第 597 步（d7999f1510d4fae9，终局卡第 6 关）：把 [N,N,N,N,N,NOP] 交上去，除顶栏外整帧一格不动。"
        "四框关卡里 NOP 不是那四个平移码之一，整道程序作废（allblank_voids_program 当场兑现），"
        "于是**这一关的程序只能由六条平移组成**，而六条单格平移的净位移奇偶必然是偶——"
        "件所在格的「行+列」交完卷还是原来的奇偶。\n"
        "这一条把 level6_blocked 的论证从「我把 262144 道穷举了一遍、六道能填满的都交过了」"
        "换成一句不用穷举的话：件在 (6,2) 行列和为偶，空腔在 (1,2) 行列和为奇，"
        "**两者的奇偶永远合不上**，所以「算出来恰好填满空腔」这件事在这一关根本不可能发生。"
        "穷举只覆盖「从当前位置一道程序直接入位」；奇偶还多管住了**接力**："
        "第 5 关那种「先交一道合法但不入位的程序把件挪到中途、再交第二道」的两段路，"
        "在这一关也是死的——每交一次卷奇偶都不变，件走到哪儿都跟空腔差一个奇偶。\n"
        "**它顺带解释了一件我原本只能照实记着的事**：整局唯一一次「交了卷没过关而件真的挪了」是"
        "第 5 关第 350 步（[E,E,E,E,N,N]，件从 (6,0) 到 (4,4)），那一步奇偶从偶到偶，**没有打破这一条**。"
        "也就是说这一条不靠「第 6 关的盘是冻住的」那个我至今解释不了的差别（odd_board_freezes_disc 只给它起了名字）——"
        "件动不动都不影响结论，这是它比 level6_blocked 原来那套论证硬的地方。\n"
        "**它怎么被推翻**：四框偶数槽的关卡里，任何一个动作之后件所在格的行列和奇偶变了，当场判 FALSE。"
        "最可能的打法有两种：某个我还没认出来的码其实是「不动」或「走两格」（那会让净位移的奇偶不再等于槽数的奇偶）、"
        "或者作废的程序其实把件挪了半步。两种都会当场现形。\n"
        "**故意没说的一半**：为什么四框关卡里非平移码会让整串作废，这一条不管，那是 allblank_voids_program 的主张；"
        "这一条只在它成立的那些关卡上说话，所以它是**架在另一条概念上的**，那一条倒了这一条也要重审。")
EVIDENCE = ["d7999f1510d4fae9",                    # 597：[N,N,N,N,N,NOP] 作废，件不动
            "671cca9e90739858", "b0e0d6d5e6cb2384"]  # 383 / 392：NOP 在首槽、末槽，同样不动

from _lib import (RPANEL_COLS, board_geom, board_walls, four_dir_boxes,
                  panel_layout, piece_cell, socket_cavity)


def _in_scope(prev, nxt, ctx):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return False
    if (board_geom(prev) != board_geom(nxt) or board_walls(prev) != board_walls(nxt)
            or socket_cavity(prev) != socket_cavity(nxt)):
        return False                       # 不是同一块盘（换关整屏重画）：这一条说的话在那儿没有意思
    if not four_dir_boxes(prev):
        return False
    lay = panel_layout(prev, RPANEL_COLS)
    if lay is None or len(lay["cols"]) % 2:
        return False
    return piece_cell(prev) is not None and piece_cell(nxt) is not None


def assert_(prev, action, nxt, ctx=None):
    if not _in_scope(prev, nxt, ctx):
        return "NA"
    a, b = piece_cell(prev), piece_cell(nxt)
    return "TRUE" if (a[0] + a[1]) % 2 == (b[0] + b[1]) % 2 else "FALSE"
