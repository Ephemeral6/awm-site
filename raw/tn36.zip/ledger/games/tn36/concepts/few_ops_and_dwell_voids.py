"""带色 14 记号的盘上，一道六槽全平移、最长连段不到四的程序，如果整串用到的不同指令少于三种、且路径在记号行上落了两步以上，按大圆交卷整串作废：除顶栏外整帧一格不动、件一格不挪。"""
LEVEL = "L2"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且右面板六槽全满、每一槽都是平移码、棋盘上存在带色 14 的格、"
         "件是 1×1（更大的件在这块盘上一次都没出现过）；"
         "`marked_prog_class` 判不出 'void' 的一律返回 NA——"
         "连四以上归 four_in_a_row_voids，两个条件只中一个的那一片（'unsure'）册子闭嘴；"
         "棋盘、件、路径算不出返回 NA；换关（ctx.level_prev != ctx.level_next）返回 NA。"
         "**不核终点**：终点是普通格的程序本来就不动（offpad_end_voids），两条理由指向同一个结果，不算越界")
NOTE = ("v1：这是**两条读法的交集**，不是我相信的那一条——两条更宽的读法在现有语料上一模一样，分不开：\n"
        "  （甲）码太少：整串用到的不同指令少于三种就作废（已兑现的四道 98/149/166/263 恰好都是三种）；\n"
        "  （乙）久留记号行：路径在记号行（有色 14 那两格所在的行）上落到第二步就作废"
        "（四道兑现的里，三道一步都不落在记号行，一道只落一步）。\n"
        "甲与乙在本关全部十六道全平移交卷上给出完全相同的判决，一条分辨用的交卷都没有。"
        "所以这一条只声称**两个条件同时成立**的那一片——甲乙都认的那块交集；"
        "只中一个的那一片（`marked_prog_class` 返回 'unsure'）册子不预测，规划器也不许走那种边。\n"
        "**分辨实验**：要把甲乙分开，得有一道最长连段不到四、终点落在花格或空腔上的程序，"
        "或者「码只有两种、但记号行只落一步」（甲判作废、乙判照走），"
        "或者「码有三种、但记号行落两步」（甲判照走、乙判作废）。本关的花格与墙摆在那里，"
        "这两种程序都做得出来，只是终局卡上不能为了做实验乱发动作——留给下一张卡。\n"
        "**由来是终局卡上两次意外**：\n"
        "  · 第 253 步 97b78eb54bc328c6：件在 (6,2) 交 N N N W N W（码两种，记号行落两步 (3,2)(3,1)），"
        "终点 (2,0) 是花格，册子押挪窝，世界整帧不动。\n"
        "  · 第 273 步 3f93d5643e9b4f83：件在 (5,5) 交 N N N S N N（码两种，记号行落两步，都是 (3,5)），"
        "终点 (1,5) 是花格，册子又押挪窝，世界又整帧不动。\n"
        "第 273 步同时**打死了 mark_on_path_voids**（「路径踩到记号格就作废」，只活了一步）："
        "它的路径一格记号都没踩，照样作废。那一条是拿第 253 步一条证据立的，"
        "而 253 同时满足这里的甲和乙——**一条只有一条证据、而那条证据被三种读法同样解释的概念，从立起来就没被检验过**。"
        "它已 retire，源码在 history/。\n"
        "**它怎么被推翻**：带记号的盘上，一道码少于三种、记号行落两步以上、连段不到四、终点是花格的程序让件挪了窝。")
EVIDENCE = ["97b78eb54bc328c6",                  # 253：N N N W N W，终点花格，不动
            "3f93d5643e9b4f83"]                  # 273：N N N S N N，终点花格，不动

from _lib import (DELTA, board_geom, board_piece, click_rc, frozen_frame, marked_prog_class,
                  on_disc, panel_ops, piece_cell, piece_shape)


def _in_scope(prev, action, ctx):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return False
    ops = panel_ops(prev)
    if not ops or any(op not in DELTA for op in ops):
        return False
    if board_geom(prev) is None or board_piece(prev) is None or piece_cell(prev) is None:
        return False
    shape = piece_shape(board_piece(prev))
    if shape is None or shape[0] != 1:
        return False                              # 只声称 1×1 的件那一侧，见 SCOPE
    return marked_prog_class(prev, ops) == "void"


def apply(prev, action, ctx=None):
    if not _in_scope(prev, action, ctx):
        return None
    return frozen_frame(prev)                     # 「整帧不动」要说出每一格，才拦得住「其实动了」


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    if any(nxt[r][c] != v for (r, c), v in want.items()):
        return "FALSE"
    return "TRUE" if piece_cell(nxt) == piece_cell(prev) else "FALSE"
