"""棋盘上有带色 14 记号的格时，一道六槽全平移的程序里同一条指令**连续**出现四次及以上，按大圆交卷整串作废：除顶栏外整帧一格不动、件一格不挪。"""
LEVEL = "L2"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且右面板六槽全满、每一槽都是平移码、棋盘上存在带色 14 的格；"
         "最长连段不到四个时返回 NA——那一片归 disc_runs_program / offpad_end_voids；"
         "棋盘、件读不出返回 NA；换关（ctx.level_prev != ctx.level_next）返回 NA。"
         "**不核墙、不核边界、不核终点**：撞墙出界、终点不是花格的程序照样归我判「不动」，几条理由指向同一个结果，不算越界")
NOTE = ("v2：**自审一遍「每条依据是不是都能被别的规则同样解释」**（起因：第 253 步 97b78eb54bc328c6 逼出 "
        "mark_on_path_voids，把本关十四道全平移交卷排成一张表重算）。五条依据里只有两条是这一条独撑的：\n"
        "  · 458 a475ae72f4944590 N N N N W W：连段 4，终点 (2,0) 是花格、路径不踩记号 → 别的规则都判「该挪窝」\n"
        "  · 430 19dcd4e0757041b1 N N N N N N：连段 6，落点恰好等于空腔（该过关）、路径不踩记号 → 只有这一条判不动\n"
        "另外三条（402、406、124）终点是普通格或路径踩了记号，off-pad 与 mark_on_path_voids 同样解释得通，"
        "它们是混杂证据。**留着不动**：混杂不等于错，但要标出来，免得下次又拿 S=1.000 当检验过。\n"
        "458 同时把门槛钉在 4：它连段正好 4 就作废，而活下来的三道（98、149、166）连段都是 3。\n"
        "**「它解释不了那两格记号是什么」这句话作废了**（原文见下）：记号是路径上的禁区，"
        "踩上就作废，归 mark_on_path_voids。所以「3 宽的纹」和「最多连三」仍然只是数字上的巧合——"
        "没有任何一道交卷把连段门槛和记号那两格的形状联系起来。\n"
        "v1：接替死掉的 marked_row_seals（「记号所在的行封死」）。那一条列的五道落空里，路径都踩了行 3，"
        "但第 149 步（4d27759dc40d4cf1）N N N E W N 从普通格 (3,5) 竖穿行 3 落到花格 (1,5)，件照走——行 3 没封。"
        "把本关全部「六槽全平移、终点花格」的交卷排开，动了的两道和落空的两道只差一件事：\n"
        "  · 第 98 步  N N E E E S → (5,5)  动了   最长连段 3（E E E）\n"
        "  · 第 149 步 N N N E W N → (1,5)  动了   最长连段 3（N N N），N 一共四个但不连着\n"
        "  · 第 458 步 N N N N W W → (2,0)  不动   最长连段 4\n"
        "  · 第 115 步 E N N N N W → (1,5)  不动   最长连段 4\n"
        "另外三道落空（402 N×5、406 N×4、124 W×4）也全是连四以上，只是它们终点不是花格，两条理由重叠。"
        "149 同时打掉了「同一条指令不许出现四次」这个写法（它有四个 N），所以这一条写的是**连续**。\n"
        "**这一条只在带记号的盘上说话**：第 5 关第 350 步 E E E E N N（连四个 E）件从 (6,0) 照走到 (4,4)，"
        "所以这不是全局规则，是这块盘带来的。**它解释不了那两格记号是什么**——(3,1)、(3,6) 各一根色 14 竖条贴外侧边，"
        "中间一条 3 宽 2 高的色 12/13 棋盘纹。「3」和「最多连三」是同一个数，这是巧合还是标尺，没有第二条读法对过。\n"
        "**它顺手把 NOP 的三条证据（383/392/597）全变成了混杂证据**：那三道程序都是 N×5，在这一条下本来就作废，"
        "allblank_voids_program 在本关其实一次都没被干净地考过。下一道 S W W W N NOP 就是去考它。\n"
        "**它怎么被推翻**：带记号的盘上，一道连四的全平移程序让件挪了窝，当场 FALSE。")
EVIDENCE = ["a475ae72f4944590",              # 458：N N N N W W，终点花格，不动
            "a5760ed2821cbf7e",              # 115：E N N N N W，终点花格，不动
            "53a66ef1f81a80a9",              # 402：N N N N N S，不动
            "b63f83e55509ade1",              # 406：E N N N N S，不动
            "9ead44468eae9118"]              # 124：N W W W W N，不动

from _lib import (DELTA, board_geom, board_piece, click_rc, frozen_frame,
                  marked_cells, max_run, on_disc, panel_ops, piece_cell)

RUN_LIMIT = 4                                 # 连到这个数就作废


def _in_scope(prev, action, ctx):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return False
    ops = panel_ops(prev)
    if not ops or any(op not in DELTA for op in ops):
        return False
    if board_geom(prev) is None or board_piece(prev) is None or piece_cell(prev) is None:
        return False
    if not marked_cells(prev):
        return False
    return max_run(ops) >= RUN_LIMIT


def apply(prev, action, ctx=None):
    if not _in_scope(prev, action, ctx):
        return None
    return frozen_frame(prev)                 # 「整帧不动」要说出每一格，才拦得住「其实动了」


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    if any(nxt[r][c] != v for (r, c), v in want.items()):
        return "FALSE"
    return "TRUE" if piece_cell(nxt) == piece_cell(prev) else "FALSE"
