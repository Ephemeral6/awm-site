"""第 5 关起顶栏每两个动作才扣一格：进关（或本关 RESET 重开）之后的第 1、3、5… 个动作顶栏 61 格一格不动，第 2、4、6… 个动作恰好把最右端那个色 9 变成色 3。"""
LEVEL = "L4"
SCOPE = ("只看 LEVEL_ANCHORS 里登记了起点的那几关之内（ctx.level_prev == ctx.level_next 且该关在表里）；"
         "**RESET 这个动作本身返回 NA**——它填顶栏不是花顶栏，归 reset_refills；"
         "**按大圆且算出来正好入位（这一下要过关）返回 NA**——过关顶栏被重填，归 clear_refills_counter；"
         "换关返回 NA；没有 ctx 或没有 step 返回 NA；表里没有的关返回 NA；"
         "顶栏已耗尽（counter_head 是 None）返回 NA；只断言第 1 行列 1..61 这 61 格")
NOTE = ("v4 同批还补了一处口径不齐：「换关返回 NA」这句话只有结算时判得出来，"
        "预测时 level_next 是 None，于是过关那一下这一条照样开口、押顶栏照抄或扣一格，"
        "而过关顶栏是被**重填**的——第 513 步 disc_runs_program 吃的是同一个病。"
        "改成从帧上认：按大圆且 run_program 算出来正好等于空腔，就是要过关，这一条闭嘴。\n"
        "v4：**换了终局卡，这张表整张都错位了**——第 561 步（f1f4726950271cde）是新卡第 5 关的第一个动作，"
        "表里最大的、不超过它的锚还是旧卡的 322，于是 k = 239 是奇数、押扣一格，实测顶栏一格没动。"
        "主张本身没挨打，反而又兑现了一次：**新关的第一个动作免费**，这正是 v2 立下的读法。"
        "挨打的是这张表的性质——它不是世界规律，是**一张卡一份的语料事实**，"
        "换一张卡、每进一个新关，都要靠那一关的第一次实测补一行进来，补之前整关判错。"
        "这已经是 NOTE 里预告过的代价（「表里每多一行就是多一条可被打错的主张」），"
        "现在把话说得更死一点：**这条概念在一张没见过的卡上必然先错一次**，"
        "因为「本关走到第几个动作」在帧上读不出来，而顶栏只看得见花掉的格数 s，本关动作数是 2s 还是 2s+1 "
        "差的那一位是世界的隐藏状态。要去掉这张表，得先找到一个能从帧上读出那一位的东西——还没找到。\n"
        "v3：第 416 步在第 6 关按了 RESET，v2 当场吃了反例——**这正是 v2 的 NOTE 末尾预告的那一条**，"
        "预告里说它「是反例，不是可以顺手改的参数」，所以这里不是调参，是把两件事分开："
        "RESET 把顶栏从 35 填回 61（帧差 161 格，右面板六槽同时清空、工具栏选回框 0），"
        "那是 reset_refills 的主张，这一条对它闭嘴；而 RESET **不推进步号**（前后都是「累计 416 步」），"
        "所以「本关第几个动作」这个数在 RESET 之后没法再用 step - 起始步 算出来——"
        "起点表因此从「一关一个起始步」改成「一关一串分段起点」，取不大于当前步的那个最大起点。"
        "新起点 417 是**押上去的**，不是量出来的：它断言重开之后本关的免费/扣钱重新从「免费」起数，"
        "第 417 步免费、418 扣。要是实测反过来，这一条当场又是反例，那就说明奇偶跟着的不是「本关动作数」"
        "而是别的什么（比如整局动作数），得重问。"
        "v2：**v1 的形式被第 6 关证伪了**，只是因为它当时缩在第 5 关里，才没有吃到自动反例——照实记在这里。"
        "v1 说的是「步号为偶数的动作免费」，锚是第 5 关第一个动作恰好落在偶数步 322 上。"
        "第 6 关第一个动作落在**奇数**步 363，实测 363 免费 / 364 扣 / 365 免费 / 366 扣，"
        "整关的奇偶和 v1 反过来。所以真正的规律不是步号的奇偶，而是**本关内已发生的动作数**的奇偶："
        "每关重新从「免费」起数，第 1、3、5… 个动作免费，第 2、4、6… 个扣一格。"
        "第 5 关（首动作 322）与第 6 关（首动作 363）在这个读法下同时成立，不再需要两套奇偶。"
        "**这一条同时是一条观测机制的坏消息（本该记 L7）**：「本关走到第几个动作」在帧上读不出来。"
        "顶栏只看得见已花掉的格数 s，而本关已发生的动作数是 2s 或 2s+1，两者的下一步一个免费一个扣钱——"
        "差的那一位是世界的隐藏状态。所以这里只能靠 ctx.step 减去本关起始步来数，"
        "而本关起始步是语料事实，写成了下面这张表：表里每多一行就是多一条可被打错的主张，"
        "新关第一次动作之后必须实测填进来，填错就整关判错。"
        "第 0~4 关是另一档：每个动作都扣一格（335/335），归 counter_spends 管，不在这一条的表里。"
        "落空的方式照旧留着：本关里 RESET 会让 step 撞号（settle 自己也这么记着），撞号之后计数就会错位，"
        "那是反例，不是可以顺手改的参数。")
EVIDENCE = ["90e1f8050e87138b", "da641b461f04d341", "d008631d8d5b3030", "c7a22846c8f40d53",
            "407e11fb344b0d01", "fcabb9a8215bbcc4", "f9233007ff0579d4",
            "f1f4726950271cde"]                   # v4 那条：终局卡第 5 关的第一个动作，表里缺锚

from _lib import (COUNTER_COLS, COUNTER_FULL, COUNTER_ROW, COUNTER_SPENT,
                  board_piece, click_rc, counter_head, on_disc, panel_ops,
                  run_program, socket_cavity)

# 每关「从这一步起重新数动作」的分段起点。**一张卡一份**，出处全是实测的第一批：
#   探索卡 第 5 关：第 322 步（第 321 步交卷过关，322 是进关后的第一个动作）
#   探索卡 第 6 关：第 363 步（第 362 步交卷过关）；第 417 步（第 416 步 RESET 重开本关，RESET 不推进步号）
#   终局卡 第 5 关：第 561 步（第 560 步交卷过关）——第 561 步实测免费，与「新关第一个动作免费」一致
LEVEL_ANCHORS = {5: [322, 561], 6: [363, 417]}


def _clears(prev, action):
    """这一下是不是「按大圆交卷、而且算出来正好入位」——也就是要过关整屏重画。

    为什么不靠 ctx.level_next：那是**事后**才有的字段，apply 在动作之前就要开口，
    那时它是 None，「换关返回 NA」这句话在预测口径下形同虚设（第 513 步吃过一次）。
    入位与否是这一帧上算得出来的，所以边界按它划。
    """
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return False
    ops = panel_ops(prev)
    piece, cav = board_piece(prev), socket_cavity(prev)
    if not ops or not piece or cav is None:
        return False
    got = run_program(piece, ops)
    return got is not None and set(got) == set(cav)


def _index(prev, action, ctx):
    """本关这一段里这是第几个动作（从 0 数）；不归我管返回 None。"""
    if action == "RESET":                     # 填顶栏不是花顶栏
        return None
    if not ctx or ctx.get("step") is None:
        return None
    lv = ctx.get("level_prev")
    if lv != ctx.get("level_next") or lv not in LEVEL_ANCHORS:
        return None
    if _clears(prev, action):                 # 这一下要过关：顶栏被重填，归 clear_refills_counter
        return None
    if counter_head(prev) is None:
        return None
    starts = [s for s in LEVEL_ANCHORS[lv] if s <= ctx["step"]]
    if not starts:
        return None
    return ctx["step"] - max(starts)


def apply(prev, action, ctx=None):
    """整条顶栏都押：本段内第偶数个（0,2,4…）动作照抄，第奇数个把头那一格翻成已耗尽。"""
    k = _index(prev, action, ctx)
    if k is None:
        return None
    out = {(COUNTER_ROW, c): prev[COUNTER_ROW][c] for c in COUNTER_COLS}
    if k % 2 == 1:
        out[(COUNTER_ROW, counter_head(prev))] = COUNTER_SPENT
    return out


def assert_(prev, action, nxt, ctx=None):
    k = _index(prev, action, ctx)
    if k is None:
        return "NA"
    want = apply(prev, action, ctx)
    if any(nxt[r][c] != v for (r, c), v in want.items()):
        return "FALSE"
    # 再核一遍「扣掉的正好是最右端那个满格」这半句：该扣的那一步头必须恰好前移一格
    h0, h1 = counter_head(prev), counter_head(nxt)
    if k % 2 == 1:
        return "TRUE" if h1 is not None and h1 == h0 - 1 else "FALSE"
    return "TRUE" if h1 == h0 and prev[COUNTER_ROW][h0] == COUNTER_FULL else "FALSE"
