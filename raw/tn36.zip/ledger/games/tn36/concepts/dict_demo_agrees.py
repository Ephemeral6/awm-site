"""点框之后那一帧，左上画布里的示范图形与左下对照面板的码说的是同一件事：方向码 -> 图形是最小号、从画布正中格沿那个方向整格移开；放大码 -> 图形落在画布左上角格且倍数大于 1；缩小码 -> 图形落在画布左上角格且倍数是 1；旋转码 -> 图形留在正中格、最小号，而缺口是标准图那个朝向转一步之后的朝向。"""
LEVEL = "L0"
SCOPE = ("只看关卡不变、落点在底栏某个框里的 ACTION6，看点完之后那一帧；"
         "画布读不出图形、面板读不出码、或码不在密码本里时 NA")
NOTE = ("v3。旋转那一条收紧了：从「缺口不是标准的那个南」改成「缺口 = ROT_NOTCH[南] = 东」，"
        "于是这条概念现在真的在给 ROT_NOTCH 这张表上闸，而不只是说「它变了」。"
        "收紧的依据不是新的像素，是新的约束：第 4 关的件缺口朝东、空腔缺口朝南，"
        "在缩放锚=左上（三次通关唯一钉死）下穷举 1..6 条指令，只有「东一步到南」的映射有解；"
        "合上这张示范图给的「南一步到东」，映射只能是对合。原先那个四循环 南->东->北->西 被这条推翻。"
        "v2 的话仍然成立：这是密码本的第二道闸，和已撤的 l2_dict_shown 分工——"
        "那条只管「码在表里」（已被第 1 关证伪），这条管「码和帧上另一种读法对得上」。"
        "画布是完全独立的一块像素，两边同时错成一样的概率很低，所以它才算真的检验了 OP_CODE。"
        "位移量故意只主张「沿那个方向、至少一格」而不主张几格：第 2 关的示范图挪 2 格，"
        "第 3 关挪 1 格，写死哪个数都会在另一关变成假反例。"
        "放大 / 缩小那两条里「落在左上角格」是故意伸出去的舌头——它同时是 run_program 里"
        "「缩放锚在左上角」那个假设的来源，而那个假设已经在第 3 关的通关上兑现了一次。")
EVIDENCE = ["684d74a6341403e5", "af27da5a917c91af",
            "49f7a0e930a7fb3c", "6ed4562d07a6e4f5",
            "d9422b1b54dbc0e6", "4cd32570de76b45f",
            "ef2b79ebe20fe623", "582f7a3cfbabb33c",
            "c1dfeb85360ac212", "d893afd23e7ffed0",
            "4b414ef1eeb07a2a", "8fc5abdd776bca77"]

from _lib import (BY_CODE, DELTA, LPANEL_COLS, ROT_NOTCH, box_at, canvas_geom,
                  canvas_piece, click_rc, panel_off_rows, tool_boxes)

STD_NOTCH = "S"        # 别的码那几张示范图一律画成缺口朝南，这是「标准图」的朝向


def _mine(prev, action, nxt, ctx):
    if not ctx or ctx.get("level_prev") != ctx.get("level_next"):
        return None
    rc = click_rc(action)
    if rc is None or not tool_boxes(prev) or box_at(prev, *rc) is None:
        return None
    off = panel_off_rows(nxt, LPANEL_COLS)
    op = BY_CODE.get(off) if off is not None else None
    demo = canvas_piece(nxt)
    geom = canvas_geom(nxt)
    if op is None or demo is None or geom is None:
        return None
    return (op, demo, geom[2])


def assert_(prev, action, nxt, ctx=None):
    m = _mine(prev, action, nxt, ctx)
    if m is None:
        return "NA"
    op, (i, j, s, notch), n = m
    ci = (n - 1) // 2                           # 7×7 的正中格
    if op in DELTA:
        if s != 1:
            return "FALSE"
        dr, dc = DELTA[op]
        di, dj = i - ci, j - ci
        k = di * dr + dj * dc                   # 沿这个方向走了几格
        return "TRUE" if k >= 1 and (di, dj) == (dr * k, dc * k) else "FALSE"
    if op == "GROW":
        return "TRUE" if (i, j) == (0, 0) and s > 1 else "FALSE"
    if op == "SHRINK":
        return "TRUE" if (i, j) == (0, 0) and s == 1 else "FALSE"
    if op == "ROT":
        return "TRUE" if (i, j) == (ci, ci) and s == 1 and notch == ROT_NOTCH[STD_NOTCH] else "FALSE"
    return "NA"
