"""按大圆交卷那一下，右面板的码按槽序解成一串平移指令、件从当前格逐格走：走不通的那一条（撞墙或出界）跳过、其余照走；终点落在花格上时件只挪到终点格，起点格露出底色或一格花格，别处一格不动。"""
LEVEL = "L1"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且右面板六槽全满、每一槽的码都认得、且**每一条指令都是平移**"
         "（出现放大/缩小/旋转/六排全暗的程序一律返回 NA——它们的语义不归这一条）；"
         "**按跳过读法算出来的终点格不是花格（board_pads）时返回 NA**——那一片归 offpad_end_voids（v12）；"
         "**带色 14 记号的盘上、程序里同一条指令连续四次及以上时返回 NA**——那一片归 four_in_a_row_voids（v11）；"
         "**带色 14 记号的盘上、`marked_prog_class` 判不出 'ok' 时一律返回 NA**（v14）——"
         "'void' 归 few_ops_and_dwell_voids，'unsure'（两条读法只中一个）那一片册子里谁都不声称；"
         "**算出来的落点恰好等于空腔（= 这一道要入位过关）时返回 NA**——过关整屏重画归 disc_fit_clears_level；"
         "换关（ctx.level_prev != ctx.level_next）返回 NA；棋盘、件、件所在格读不出返回 NA")
NOTE = ("v14：终局卡第 6 关第 273 步（3f93d5643e9b4f83）又是同一个位置，错 8 格：件在 (5,5) 交 N N N S N N，"
        "不碰墙、不出界、最长连段 3、终点 (1,5) 是花格，这一条押件挪到 (1,5)，世界整帧一格不动。"
        "**而这一道路径一格记号都没踩**（六步全在第 5 列，记号在 (3,1)、(3,6)）——v13 让出去的那道边界"
        "（「路径踩记号格」）当场死，mark_on_path_voids 只活了一步，已撤册。\n"
        "这是同一个位置上的**第四次**划错边界（v6 按盘的颜色、v9 按路径踩的行、v13 按路径踩的格、"
        "现在按 `marked_prog_class`）。这一次不再声称自己知道边界在哪：253 与 273 两道落空的共同点有两条读法"
        "（码少于三种 / 路径在记号行落两步以上），本关十六道全平移交卷上它们判决完全相同，一道都分不开。"
        "所以让出去的是**两条读法的并集**——交集归 few_ops_and_dwell_voids 声称，只中一个的那一片谁都不声称，"
        "这一条对整个并集闭嘴。让出去的比以前多，是因为**以前每次都是把边界划在自己看得见的那个量上**，"
        "而三次都划错了；这一次把没分开的两个量一起让出去，等分辨实验做完再要回来。\n"
        "v13：终局卡第 6 关第 253 步（97b78eb54bc328c6）这一条又挨了一次打，错 8 格：件在 (6,2) 交 N N N W N W，"
        "不碰墙、不出界、最长连段 3、终点 (2,0) 是花格，这一条押件挪到 (2,0)，世界整帧一格不动。"
        "与它兑现过的三道（98、149、166）唯一的差别是路径第四步踩上了记号格 (3,1)。"
        "那一片从此归 mark_on_path_voids——记号是路径上的禁区。"
        "这是同一个位置上的第三次划错边界（v6 按盘的颜色、v9 按路径踩的「行」、现在按路径踩的「格」）；"
        "v9 那次之所以把「行」划错，是因为打死它的第 149 步竖穿行 3 时走的是 (3,5)，不是记号格本身——"
        "「记号所在的行」和「记号那一格」这两种读法，要一道**只差这一点**的程序才分得开，而它直到现在才出现。\n"
        "v12：**「撞墙就整串作废」被打死了**。第 166 步（194f3bd8748f5ac1）第 7 关（原第 6 关）交 S W W W N N，"
        "第六条 N 从空腔那一格往北撞进墙里——按 v4 起一直写着的「整串作废」，这一下该除顶栏外一格不动；"
        "世界给的是件挪进空腔、当场通关。所以撞墙的那一条指令不是让整串作废，是**它自己被跳过、后面照走**。\n"
        "这一条本来两版之前就该分开的：撑着「整串作废」的四道证据（第 333、430、110、134 步）没有一道是干净的——"
        "按跳过读法重算，333 终点 (6,1)、110 终点 (1,6)、134 终点 (2,5) 全是普通格（归 offpad_end_voids），"
        "430 是记号盘上连六（归 four_in_a_row_voids），四道在两种读法下都该不动。"
        "一条规则的每一条依据都能被另一条规则同样解释，这条规则就一次都没被检验过；"
        "S=1.000 照样拿满分——这正是「S 高只等于没被推翻」那句话的样子。\n"
        "另一种活着的读法「件进了空腔就停、后面的指令不执行」也死了，死在第 402 步："
        "N N N N N S 第五步进空腔、第六步退出来，若是入腔即停那一步就该通关，实测一格没动。"
        "所以跳过读法是目前唯一一种能同时对上全部 28 道全平移交卷的读法（`runs/<run>/skipsem.py` 逐道排开）。\n"
        "v11：v9 让出去的「路径踩记号行」那一片又要回来了——第 149 步（4d27759dc40d4cf1）N N N E W N 从 (3,5) 竖穿行 3 "
        "落到花格 (1,5)，件照走，这一条算出来的落点和世界给的一样。让出去的边界改成 four_in_a_row_voids 划的那条：带记号的盘上、"
        "同一条指令连四以上的程序作废。两次划错边界（v6 按盘的颜色、v9 按路径踩的行）教的是同一件事：**分辨实验要一次只变一个量**——"
        "v9 那五道落空既踩了行 3 又都连四，我只看见了前者。\n"
        "v9：**把色 14 那块盘要回来了**。v6 整块让给 odd_board_freezes_disc（「这块盘不接程序」），"
        "第 98 步（4809c023e1f57f55）把那条打死：件在 (6,2) 交 N N E E E S，六步全在行 4-6，"
        "件照走到花格 (5,5)。所以这块盘和别的盘一样接程序，让出去的边界划错了——划在「盘的颜色」上，"
        "而真正的边界在**路径踩不踩记号行**。现在让出去的只剩那一条，归 marked_row_seals。"
        "教训与 v7 同源：边界要按帧上读得到的**因果**划，不按最好认的那个标记划。\n"
        "同一步还咬掉了 v4 起故意伸着的那根舌头「起点格恢复成底色」：件离开 (6,2) 后那一格露出的是花格，"
        "不是底色——花格是画在盘上的、件压在上面时看不见，第 5 关件走后 (6,0) 没长出花格也说明它不是件留下的。"
        "所以起点格那 16 个像素这一条不再押（apply 里抠掉），assert_ 只核它露出的是整格底色或一格花格。\n"
        "v8：第 5 关一道分辨实验（7043f3c132d3bbfd）：件在 (6,0)，交 E E E E N S，六步不碰墙不出界、终点 (6,4) 是普通底色格，"
        "这一条押件挪到 (6,4)，世界除顶栏外一格不动（错 28 格）。它与兑现过的 E E E E N N（终点 (4,4) 花格）只差最后一槽。"
        "所以「走得通就走」少了一个前提：**终点得是花格**（或空腔）。这一条从此只管终点落在花格上的程序；"
        "终点是普通格的归 offpad_end_voids。第 6 关那五道落空里的四道（402/406/409/462）终点都是普通格，也归它；"
        "第 458 步终点 (2,0) 是花格却没动，这一条靠色 14 那句 scope 仍对它闭嘴——那是还没解释的一块，不是解释了。"
        "（v9 补：那一块现在解释了，是路径踩了记号行。）\n"
        "v7：**scope 只在结算口径成立，预测口径下漏了**——第 513 步（cce22a3fc610da1d）在终局卡第 1 关交卷，"
        "[N,N,N,N] 把件从 (5,3) 送到 (1,3) 正好入位、过关整屏重画，这一条却押了整帧四千格，错 591 格。"
        "原因不在主张，在 scope 的写法：`ctx.level_prev != ctx.level_next` 这句话只有**事后**才判得出来，"
        "预测时 `level_next` 这个键根本不存在，两边 get 出来都是 None、相等，于是「换关返回 NA」形同虚设。"
        "改成从帧上认：算出来的落点像素恰好等于 socket_cavity，就是要入位、要过关，这一条闭嘴——"
        "**入位之后世界画什么，归 disc_fit_clears_level 管，不归我**。"
        "教训写在这儿：拿 ctx 的事后字段划的边界，在 apply 里是虚的；边界要按帧上读得到的东西划。"
        "（原来那句 ctx 判断留着，它在结算口径下仍然多一层保险。）\n"
        "v6：把整块「带色 14 的棋盘」让出去，交给 odd_board_freezes_disc。"
        "v5 让出的是「路径压过空腔那一格」，只撑了一步：第 406 步（b63f83e55509ade1）交的 [E,N,N,N,N,S] "
        "件在 (6,2)，走 (6,3)(5,3)(4,3)(3,3)(2,3)(3,3)，**不碰空腔、不入位、不碰墙、不出界**，"
        "这一条据此押件停在 (3,3)，世界还是除顶栏外整帧一格不动（错 28 格）。"
        "所以 v5 NOTE 里留的两种读法，（甲）「空腔那一格中途进不得」被这一步打掉，（乙）活下来："
        "拦住程序的不是路径，是这块盘。第 6 关是整局唯一盘上带色 12/13/14 的棋盘，"
        "这一条从此对这类盘闭嘴，不是解释它——解释归 odd_board_freezes_disc，那是一条会被下一次挪动打掉的舌头。"
        "这已经是它第四次在第 6 关挨打（383、392、402、406），四次的共同点只有「关卡」这一个，"
        "所以让出去的边界按帧上读得到的东西划（色 14），不按关卡号。"
        "v5：把「路径压过空腔那一格」这一片让出去。第 402 步（53a66ef1f81a80a9）是第 6 关**第一次**"
        "交出六槽全平移的程序 [N,N,N,N,N,S]：件在 (6,2)，五个 N 到 (5,2)(4,2)(3,2)(2,2)(1,2)、第六步 S 退回 (2,2)，"
        "沿途一格墙都不碰、一步都不出界，这一条据此押件停在 (2,2)、押了整帧四千格，"
        "世界给的是**除顶栏外整帧一格不动**（错 28 格，全在 (2,2) 那一格的十六个像素与件原位上）。"
        "第五步落在插槽空腔 (1,2) 上、第六步又离开，是这道程序与已兑现的两条（第 333、350 步）唯一的差别。"
        "它同时打掉了「件走进空腔就算到位、后面的指令不再执行」那个读法——真那样的话这一步该当场过关。"
        "剩下两种读法还没分开：（甲）空腔那一格中途进不得，整串作废；"
        "（乙）第 6 关任何不以入位收尾的程序都作废。分开它们要一道既不碰空腔、也不入位的程序。"
        "在分开之前这一条对那一片闭嘴，不是解释它。"
        "v4：缩回只管平移。v2 与 v3 各拿「六排全暗」这个码赌了一次，两次都被打掉——"
        "v2 读成零位移，第 383 步把它放进**第一槽**（[全暗,N,N,N,N,N]），该走五格通关，世界给帧不变；"
        "v3 改读成终止符，第 392 步把它放进**最后一槽**（[N,N,N,N,N,全暗]），前五个 N 该照走通关，"
        "世界还是帧不变（只掉了顶栏一格）。那一片现归 allblank_voids_program（v2 已把空槽一并收进去）。"
        "两条正面依据照旧：第 333 步的 E N N N N N 第二步要走进整格色 6 的 (5,1)，整串作废、除顶栏外一格没动；"
        "第 350 步六步一格墙都没碰，件就从 (6,0) 照走到 (4,4)（帧差 22 格）。"
        "**结构性盲区**：赢的那一步换了关，这一条对它判 NA——它只能在「交了卷没赢」的转移上被检验。"
        "**故意伸出去的舌头**：起点格恢复成棋盘底色 bg_color——点画格若会长回来，这里当场判错，"
        "那就说明点画格是个有状态的东西，不是画上去的记号。"
        "（v1 的舌头「码 {A横条} 读成西移」已由第 362 步通关证实，第 366 步在第 6 关重新量到同一个码。）")
EVIDENCE = ["6975a93f19d9016b", "8a0eee4b22fee3bb", "671cca9e90739858", "b0e0d6d5e6cb2384",
            "53a66ef1f81a80a9", "b63f83e55509ade1",
            "cce22a3fc610da1d",                  # v7 那次意外：算出来入位、过关重画，预测口径没缩住
            "7043f3c132d3bbfd",                  # v8 那次意外：终点普通格，件不走
            "4809c023e1f57f55",                  # v9 的由来：记号盘上件照走，色 14 那道边界划错了
            "4d27759dc40d4cf1",                  # v11 的由来：竖穿记号行件照走，「封行」那道边界也划错了
            "194f3bd8748f5ac1",                  # v12 的由来：撞了墙的那一串照走、还入位通关，「整串作废」当场死
            "97b78eb54bc328c6",                  # v13 的由来：路径踩了记号格，终点是花格也不动
            "3f93d5643e9b4f83"]                  # v14 的由来：一格记号都没踩，终点是花格也不动

from _lib import (BLOCK, CELL, DELTA, bg_color, board_geom, board_pads, board_piece,
                  cell_px, click_rc, frozen_frame, marked_cells, marked_prog_class, on_disc,
                  panel_ops, piece_cell, socket_cavity, walk_program_skip)


def _marked_trouble(g, ops):
    """带记号的盘上让出去的地方：连四以上（four_in_a_row_voids）、
    码少于三种且久留记号行（few_ops_and_dwell_voids），
    以及两条读法只中一个的 'unsure'——那一片册子里谁都不声称，这一条也不冒充知道。"""
    if not marked_cells(g):
        return False
    return marked_prog_class(g, ops) != "ok"    # 算不出（None）也当让出去：不知道就闭嘴


def _setup(prev, action, ctx):
    """这一步归不归我管：管的话返回 (指令串, 起点格)。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return None
    ops = panel_ops(prev)
    if not ops or any(op not in DELTA for op in ops):
        return None
    if board_geom(prev) is None or board_piece(prev) is None or piece_cell(prev) is None:
        return None
    if _marked_trouble(prev, ops):            # 带记号的盘上没判成 'ok' 的那一片，见 _marked_trouble
        return None
    return (ops, piece_cell(prev))


def apply(prev, action, ctx=None):
    got = _setup(prev, action, ctx)
    if got is None:
        return None
    ops, start = got
    out = frozen_frame(prev)                 # 「别处一格不动」要说出每一格，才拦得住事
    walked = walk_program_skip(prev, ops)
    if walked is None:
        return None                          # 算不出（读不出盘/件）：这一条闭嘴
    (di, dj), new_px = walked
    cav = socket_cavity(prev)
    if cav is not None and set(new_px) == set(cav):
        return None                          # 算出来正好入位 = 要过关整屏重画，那一片归 disc_fit_clears_level
    pads = board_pads(prev)
    if pads is None or (di, dj) not in pads:
        return None                          # 终点不是花格：件不走，那一片归 offpad_end_voids（v8）
    for i, j in (start, (di, dj)):
        px = cell_px(prev, i, j)
        if px is None:
            return None
        for p in px:
            if (i, j) == start:
                out.pop(p, None)             # 起点格露出来是什么（底色还是花格）这一条不押，见 v9 NOTE
            else:
                out[p] = BLOCK if p in new_px else bg_color(i, j)
    return out


def _start_ok(prev, nxt, start):
    """件离开后起点格只许露出两样东西之一：整格底色，或一格花格。"""
    px = cell_px(prev, *start)
    if px is None:
        return False
    i, j = start
    if all(nxt[r][c] == bg_color(i, j) for r, c in px):
        return True
    pads = board_pads(nxt)
    return pads is not None and start in pads


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    if any(nxt[r][c] != v for (r, c), v in want.items()):
        return "FALSE"
    # 再拿一种独立的读法核一遍终点：件在新帧上应当读成同一个形状，且左上角落在算出来那一格
    walked = walk_program_skip(prev, panel_ops(prev))
    if walked is None:
        return "TRUE"
    if piece_cell(nxt) != walked[0]:
        return "FALSE"
    if not _start_ok(prev, nxt, piece_cell(prev)):
        return "FALSE"
    return "TRUE"
