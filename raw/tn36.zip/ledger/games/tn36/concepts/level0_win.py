"""第 0 关：点在大圆的包围盒里，面板 10 个件全暗时这一步整屏重画且顶栏刷回满 61 格（过关）；不全暗时只掉顶栏一格。"""
LEVEL = "L5"
SCOPE = "只看第 0 关（ctx.level_prev == 0）里落点在大圆包围盒内的 ACTION6；顶栏已耗尽时返回 NA；别的动作、别的落点、别的关返回 NA"
NOTE = "第 0 关的「什么算赢」。它只看帧不看 ctx.level_next，所以结算口径和预测口径下是同一条——终局卡上也管用。"
EVIDENCE = ["057ab87c5d1b982d", "89da7ba9203580e5"]

from _lib import (COUNTER_COLS, COUNTER_FULL, COUNTER_ROW, click_rc,
                  counter_head, on_circle, panel_all_off)

BIG_REDRAW = 1000                          # 「整屏重画」的下界：过关那一帧改了两千多格


def _diff(prev, nxt):
    n = 0
    for r in range(len(prev)):
        if prev[r] == nxt[r]:
            continue
        for c in range(len(prev[r])):
            if prev[r][c] != nxt[r][c]:
                n += 1
    return n


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") != 0:
        return "NA"
    rc = click_rc(action)
    if rc is None or not on_circle(*rc):
        return "NA"
    if counter_head(prev) is None:
        return "NA"
    n = _diff(prev, nxt)
    if panel_all_off(prev):
        full = all(nxt[COUNTER_ROW][c] == COUNTER_FULL for c in COUNTER_COLS)
        return "TRUE" if (n >= BIG_REDRAW and full) else "FALSE"
    return "TRUE" if n == 1 else "FALSE"
