"""同一关之内每发一次 ACTION6，顶栏（第 1 行）那 61 格里**最多只有最右端那个色 9 格会变**，而且只会从色 9 变成色 3；已经是色 3 的格子一律留在色 3，别的色 9 格一格不动。"""
LEVEL = "L4"
SCOPE = "只看第 1 行列 1..61 这 61 格，且只看 ACTION6；别的动作（RESET）返回 NA；换关返回 NA；顶栏已耗尽（没有色 9）时返回 NA；**凡是按在大圆上的一律返回 NA**"
NOTE = ("v8：不再用 submit_fits 分流按大圆那一下，改成**凡是按在大圆上一律 NA**。"
        "第 333 步（6975a93f19d9016b）交上去一道算得恰好填满空腔的程序，世界没过关、顶栏照常扣一格，"
        "说明「填满 = 会过关 = 顶栏刷回满格」这个前提是错的（见 disc_fit_clears_level v5）。"
        "从像素既然预测不出这一下会不会过关，就预测不出顶栏是扣一格还是刷回满格——那就一格都不押。"
        "v6 的由来是第 322 步的反例（f1f4726950271cde）：第 5 关的第一次点灯，顶栏一格没动。"
        "v1-v5 主张「每发一次必扣恰好一格」，这一步把「必」字打掉了——327/328 次动作扣一格，"
        "独独第 5 关的头一下没扣，而前五关的头一下都是从满格扣走一格的。"
        "所以顶栏不是「一格 = 一次动作」的计数器，它是一根**量表**：61 是显示宽度，本关的预算另说。"
        "第 322-325 步四步的读数把量表的两支分开了：满格数依次 61 → 61 → 60 → 60 → 59，"
        "即**每两步掉一格**，掉格的间隔均匀铺开——这是等比那一支（乙），夹住那一支（甲，"
        "「先连停好几步、之后每步都掉」）当场出局。第 5 关的预算因此是 122 步，前五关是 61 步；"
        "预算怎么随关卡变，册子还答不出来，这是一块明写着的空地。"
        "v7 改的只有 apply，断言一个字没动，原因是押注是**链式模拟**："
        "v6 的 apply 不押最右端那一格，于是模拟帧里那一格永远停在色 9，模拟的「最右端」比真实的偏右；"
        "下一步它按偏右的那个头去押「别的 60 格不动」，就把真实里刚刚被扣掉的那一格押成了没变"
        "（第 325 步 (1,60) 押 9 实 3，--strict 拦下）。结算口径下它判 TRUE——**断言对、生成器仍然不能用**。"
        "所以 v7 只认领「已经是色 3 的格子留在色 3」：模拟帧比真实帧陈旧时，模拟里算作已耗尽的格子"
        "必然在真实里也已耗尽，这个集合对陈旧单调稳健，链上多少步都不会押错。"
        "v5：交卷成功那一下顶栏是刷回满格（归 clear_refills_counter），这里 NA；改成从像素判（submit_fits），"
        "预测口径下也闭得上嘴。v4：「全暗时点大圆」那一类归 level0_win。v3：换关归 NA。"
        "v2：v1 顺带断言了「非 ACTION6 时顶栏不变」，被 RESET 打脸。")
EVIDENCE = ["057ab87c5d1b982d", "f08a8d938b86f8e1", "b7cf75bfdf08999a", "89da7ba9203580e5",
            "f1f4726950271cde", "1447335087ad4b4f"]

from _lib import (COUNTER_COLS, COUNTER_FULL, COUNTER_ROW, COUNTER_SPENT,
                  click_rc, counter_head, is_circle_click_all_off, on_disc)


def _mine(prev, action, ctx):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return False
    if not action.startswith("ACTION6"):
        return False
    rc = click_rc(action)
    if rc is not None and on_disc(prev, *rc):
        return False                     # 按大圆那一下会不会过关，从像素预测不出 —— 一律闭嘴
    return not is_circle_click_all_off(prev, action, ctx)


def assert_(prev, action, nxt, ctx=None):
    if not _mine(prev, action, ctx):
        return "NA"
    head = counter_head(prev)
    if head is None:
        return "NA"
    for c in COUNTER_COLS:
        if c != head and prev[COUNTER_ROW][c] != nxt[COUNTER_ROW][c]:
            return "FALSE"
    return "TRUE" if nxt[COUNTER_ROW][head] in (COUNTER_FULL, COUNTER_SPENT) else "FALSE"


def apply(prev, action, ctx=None):
    """只押「已耗尽的留在已耗尽」——这个集合对「模拟帧比真实帧陈旧」单调稳健。"""
    if not _mine(prev, action, ctx):
        return None
    if counter_head(prev) is None:
        return None
    return {(COUNTER_ROW, c): COUNTER_SPENT
            for c in COUNTER_COLS if prev[COUNTER_ROW][c] == COUNTER_SPENT}
