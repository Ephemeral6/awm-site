"""点在面板第 k 个槽的下半格命中盒（_lib.slot_of 判 stem）里，这个槽的竖杆 3 格在色 1 与色 5 之间整体翻转，别的槽件不动。"""
LEVEL = "L1"
SCOPE = "只看第 0 关（ctx.level_prev == 0）里落点判 stem 的 ACTION6；换关返回 NA；只断言 5 根竖杆共 15 格与 5 个横条共 15 格"
NOTE = "v3：第 1 关布局整个换了，面板不在原处，圈到第 0 关。v2：命中盒随 _lib.slot_of 放宽（下半格 = 行 44-47、中心列 ±2）。行 47 与 ±2 还没打过，是这一版故意伸出去的。"
EVIDENCE = ["b9a328f39e765142"]

from _lib import (OFF, ON, PANEL_SLOT_COLS, PANEL_STEM_ROWS, PANEL_TOP_ROW,
                  click_rc, in_level, slot_of)


def _pieces(g):
    out = {}
    for k, col in enumerate(PANEL_SLOT_COLS):
        for r in PANEL_STEM_ROWS:
            out[(r, col)] = g[r][col]
        for c in range(col - 1, col + 2):
            out[(PANEL_TOP_ROW, c)] = g[PANEL_TOP_ROW][c]
    return out


def _want(prev, k):
    out = _pieces(prev)
    col = PANEL_SLOT_COLS[k]
    flip = {ON: OFF, OFF: ON}
    for r in PANEL_STEM_ROWS:
        out[(r, col)] = flip.get(prev[r][col], prev[r][col])
    return out


def assert_(prev, action, nxt, ctx=None):
    if not in_level(ctx, 0):
        return "NA"
    rc = click_rc(action)
    if rc is None:
        return "NA"
    hit = slot_of(*rc)
    if hit is None or hit[0] != "stem":
        return "NA"
    return "TRUE" if _want(prev, hit[1]) == _pieces(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if not in_level(ctx, 0):
        return None
    rc = click_rc(action)
    if rc is None:
        return None
    hit = slot_of(*rc)
    if hit is None or hit[0] != "stem":
        return None
    return _want(prev, hit[1])
