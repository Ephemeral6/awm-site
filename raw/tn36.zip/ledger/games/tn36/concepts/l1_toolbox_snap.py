"""第 1 关：点底栏两个 9×9 框之一，整个左半边（示范图形、左下对照面板、两个框的边框）被换成这个框固定对应的那一套；右半边一格不动。"""
LEVEL = "L6"
SCOPE = "只看第 1 关内的 ACTION6，且落点在 l1_box_of 认出的框里；别的一律 NA"
NOTE = ("v1。两个框不是「按一下动一下」而是「按一下切到那一套」：按已经选中的那个框，"
        "左半边已经是那一套时就一格不动（第 202/204-206/208-209 步），不是那一套时会被扳过去（第 199 步）。")
EVIDENCE = ["bf380bc0f3dd9534", "777d1b3a5969bff1", "c18f3c857bb1cea7",
            "b5c19b369eb8ea55", "a83e70bf2003012a", "5becafda680a8c33"]

from _lib import click_rc, diff_cells, in_level, l1_box_of, l1_config_changes


def _target(prev, action, ctx):
    if not in_level(ctx, 1):
        return None
    rc = click_rc(action)
    if rc is None:
        return None
    name = l1_box_of(*rc)
    if name is None:
        return None
    return l1_config_changes(prev, name)


def assert_(prev, action, nxt, ctx=None):
    want = _target(prev, action, ctx)
    if want is None:
        return "NA"
    return "TRUE" if diff_cells(prev, nxt) == want else "FALSE"


def apply(prev, action, ctx=None):
    return _target(prev, action, ctx)
