"""带放大/缩小/旋转的程序按大圆交卷时，中间只要有一步让件盖住的格（倍数 s 就是 s×s 格）压上墙或走出棋盘，整串就作废：除顶栏外整帧一格不动。"""
LEVEL = "L2"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且右面板的码整串认得出、棋盘与件读得出、"
         "整串指令逐条都做得了（program_trace 走满 len(ops) 步）；"
         "**且这一串里确实有一步让件盖住的格越界或压墙**——全程合法的那些不归这一条"
         "（归 disc_runs_program 与 disc_fit_clears_level）；"
         "**六槽全是平移的程序返回 NA**（v3）——那一族撞墙不作废，是跳过那一条照走；换关返回 NA")
NOTE = ("v3：主张缩到「带放大/缩小/旋转的程序」这一族。v2 说的是任何程序，"
        "第 166 步（194f3bd8748f5ac1）把那句话的平移一半打死了：S W W W N N 第六条 N 撞墙，"
        "件照样挪进空腔、当场通关。那一步这一条没被判 FALSE，只因为它换了关、scope 里换关返回 NA——"
        "**这正是「结构性盲区」的样子：一条概念可以靠盲区活着，而不是靠对**。所以这一版自己缩回去，"
        "不等下一次侥幸。依据（第 535 步）是一道带 SHRINK 的程序，缩了之后它照旧解释得了；"
        "平移那一族的新读法见 disc_runs_program v12（撞墙那一条跳过、其余照走）。"
        "为什么不把跳过读法也扩到带缩放的程序上：一次都没量过。2 倍件撞墙是不是也只跳过那一条，"
        "要一道「带缩放且中途撞墙」的交卷才分得开，这一局没交过第二道。\n"
        "由来是第 535 步（3c170b2c6c282299，终局卡第 3 关）：件在格 (1,3) 是 **2 倍**、盖住 2×2 格，"
        "码 [S,S,W,S,S,SHRINK] 用 run_program 算出来的落点**恰好等于空腔**，"
        "按 disc_fit_clears_level 本该当场过关。世界给的是除顶栏外整帧一格不动。\n"
        "差别就在「件不只占一格」：第二个 S 把件挪到左上角 (3,3)，它盖住的四格里 (4,3)(4,4) 都是墙——"
        "这一关第 4 行整排只有 (4,2) 一个缺口，而 2 格宽的件根本穿不过 1 格宽的缺口。"
        "换成按盖住的格核路径，本关唯一的解是 [S,W,SHRINK,S,S,S]：先挪到缺口正上方、缩成 1 倍、再穿下去。\n"
        "**这一条和 disc_runs_program 是同一条规则的两半**：那一条说「路走不通就整帧不动」，"
        "但它当时用的 walk_program 只核件左上角那一格——对 1 倍件没差别，对 2 倍件是错的。"
        "walk_program 已按这条一并改成核 piece_footprint；这一条负责把这件事说成一句能挨判的话，"
        "并且把它扩到**带缩放/旋转的程序**上，那是 disc_runs_program 明说不管的一片。\n"
        "**它怎么被推翻**：只要有一次「中间某步件压墙/出界」的交卷让帧上除顶栏外有任何一格变了"
        "（件挪了、过关了、画面重画了），这一条当场判 FALSE。\n"
        "**故意留在里面的一件事**：SHRINK 的锚点（左上角不动）来自 run_program，它在本关这一道解上"
        "第一次被正面用来定路线。锚点若不在左上角，[S,W,SHRINK,S,S,S] 会落到别处，这一条判不出来，"
        "但下一次交卷会当场打脸——那正是它该被打的地方。")
EVIDENCE = ["3c170b2c6c282299",
            "194f3bd8748f5ac1"]                  # v3 的由来：平移那一族撞墙不作废（这一条现在对它 NA）

from _lib import (DELTA, board_geom, board_piece, board_walls, click_rc, frozen_frame,
                  on_disc, panel_ops, piece_cell, piece_footprint, program_trace)


def _bad(prev, action, ctx):
    """这一步归不归我管：管的话返回 True（= 这一串中间有一步件压墙或出界）。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return False
    ops = panel_ops(prev)
    if not ops:
        return False
    if all(op in DELTA for op in ops):           # 全平移：撞墙只跳过那一条（v3）
        return False
    geom, walls = board_geom(prev), board_walls(prev)
    if geom is None or walls is None or board_piece(prev) is None or piece_cell(prev) is None:
        return False
    tr = program_trace(prev, ops)
    if tr is None or len(tr) != len(ops):        # 有一条指令根本做不了：那归别的概念，不归这一条
        return False
    _, _, nr, nc = geom
    for i, j, s, _ in tr:
        for a, b in piece_footprint(i, j, s):
            if not (0 <= a < nr and 0 <= b < nc) or (a, b) in walls:
                return True
    return False


def apply(prev, action, ctx=None):
    if not _bad(prev, action, ctx):
        return None
    return frozen_frame(prev)                    # 「一格不动」要把每一格都说出来，才拦得住事


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    return "FALSE" if any(nxt[r][c] != v for (r, c), v in want.items()) else "TRUE"
