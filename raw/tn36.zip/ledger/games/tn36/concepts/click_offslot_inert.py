"""第 0 关里 ACTION6 的落点不在面板 5 个槽的命中盒（_lib.slot_of）里时，除顶栏那一行外整帧不变。"""
LEVEL = "L2"
SCOPE = "只看第 0 关（ctx.level_prev == 0）里带坐标的 ACTION6；落点在槽命中盒里返回 NA；「全暗时点大圆」那一类归 level0_win，返回 NA；换关返回 NA；只断言第 1 行以外的格子"
NOTE = "v3：第 1 关布局整个换了，面板不在原处，所以圈到第 0 关。v2：v1 把「槽件」等同于画出来的那几格，被 (行43,列31) 打脸——那格是横条与竖杆之间的色 0 空隙，点它翻了横条。"
EVIDENCE = ["f08a8d938b86f8e1", "acced8203c51bd4b", "b8bc5b41235a9c74",
            "cce231e53ce8ebc9", "71db93dd51e0276f", "e6e1c963397abb2a"]

from _lib import COUNTER_ROW, click_rc, in_level, is_circle_click_all_off, slot_of


def _mine(prev, action, ctx):
    if not in_level(ctx, 0) or is_circle_click_all_off(prev, action, ctx):
        return False
    rc = click_rc(action)
    return rc is not None and slot_of(*rc) is None


def assert_(prev, action, nxt, ctx=None):
    if not _mine(prev, action, ctx):
        return "NA"
    for r in range(len(prev)):
        if r == COUNTER_ROW:
            continue
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _mine(prev, action, ctx):
        return None
    return {(r, c): v for r, row in enumerate(prev) if r != COUNTER_ROW
            for c, v in enumerate(row)}
