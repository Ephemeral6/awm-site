"""按下大圆而右面板那道程序算出来的件**填不满**插槽的空腔，就一定不过关；填满了未必过关。"""
LEVEL = "L5"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且棋盘上既找得到带缺口的件、也找得到插槽、空腔也读得出来；"
         "算出来**恰好填满**空腔的那一下返回 NA —— 那一侧已经被第 333 步推翻，这一条不再声称管它。"
         "**六槽全是平移时，「算出来」按「走不通的那一条跳过」读**（v6）；"
         "其余情形（含 GROW/SHRINK/ROT/空槽）仍按 submit_fits 那副不核墙的读法，算不出来时算作「填不满」，照样主张不过关")
NOTE = ("v6 的由来是第 166 步（194f3bd8748f5ac1）：第 7 关（原第 6 关）交上去 S W W W N N 当场过关，"
        "而 submit_fits 背后的 run_program 不核墙，把最后那一条撞进墙里的 N 也当成真挪了一格，"
        "算出来的终点不是空腔，于是这一条判「填不满 → 不过关」，被过关本身打成反例。"
        "错的不是主张那一半，是「算出来」这四个字背后的读法：撞墙那一条指令是被跳过的，"
        "跳过之后这道程序正好把件送进空腔（见 disc_runs_program v12：「撞墙整串作废」同一步被打死）。"
        "所以 v6 只换算法不换主张——平移程序改用 walk_program_skip 算落点，"
        "于是第 166 步落在「恰好填满」那一侧，这一条对它闭嘴，不再声称管它。\n"
        "v5 的由来是第 333 步（6975a93f19d9016b）：第 5 关交上去 E N N N N N，"
        "按 run_program 算出来的 14 格与空腔逐格相等，按下去**一格没动**（除了顶栏扣掉一格），关卡没变。"
        "v1-v4 主张的是双向的「填满 <-> 过关」，这一步把「填满 -> 过关」那一半打掉了。"
        "剩下这一半（过关 -> 填满）仍然站得住：五次过关的程序算出来都与空腔逐格相等。"
        "**所以「什么算赢」这一槽现在是空的**：填满只是必要条件，还缺一条。已知的约束："
        "第 5 关件在格 (6,0)、空腔在格 (1,1)、六个槽、工具只有 S/N/E/W，所以解必然是 5 个 N 加 1 个 E 的某个排列——"
        "六种排列的末位置完全相同，差别只在**次序**。而这个盘面上第 5 行只有第 4、6 两列不是色 6，"
        "任何一种排列都要从第 6 行穿到第 4 行、必经色 6，所以「路径不能压过色 6」这个读法会让本关六槽无解；"
        "除非本关真的无解，否则拦住第 333 步的不是色 6 的墙。下一步先量密码本：本关的 N 与 E 到底是哪一组灯。"
        "v4 的由来是第 304-321 步那一批（判读表在押注里预注册）：先交六槽全填的 S S S S ROT GROW，一格没动；"
        "再交 S S S ROT GROW 框4，当场过关——放大的锚和缩小一样在左上，空槽确实作废，框 4 是无操作。"
        "提醒：押注口径下 level_next 被置成 level_prev，所以这一条在预测时对「过关」那一侧永远闭嘴。")
EVIDENCE = ["e9bc2118232833e6", "f6c89ede48f5fdb2", "f05f90280fbe3b20",
            "af2856ec23fd84ce", "a104ec10d06cca18", "6975a93f19d9016b",
            "194f3bd8748f5ac1"]                          # 第 166 步：撞墙的那一串过了关

from _lib import DELTA, panel_ops, socket_cavity, submit_fits, walk_program_skip


def _fits(prev, action):
    """这一下算不算「恰好填满空腔」；不是按大圆或读不出返回 None。

    六槽全是平移时按跳过读法自己算（v6）；其余情形交给 submit_fits。
    """
    base = submit_fits(prev, action)
    if base is None:
        return None
    ops = panel_ops(prev)
    if not ops or any(op not in DELTA for op in ops):
        return base
    walked = walk_program_skip(prev, ops)
    cav = socket_cavity(prev)
    if walked is None or cav is None:
        return base
    return set(walked[1]) == set(cav)


def assert_(prev, action, nxt, ctx=None):
    fit = _fits(prev, action)
    if fit is None or fit or not ctx:
        return "NA"                                  # 填满那一侧已被推翻，不再声称
    cleared = ctx.get("level_next") != ctx.get("level_prev")
    return "FALSE" if cleared else "TRUE"
