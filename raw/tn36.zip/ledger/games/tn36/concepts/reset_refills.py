"""第 0 关里 RESET 把顶栏 61 格全部刷回色 9，并把面板 10 个开关全部还原成开局态（上排与竖杆都是 暗亮暗亮亮）。"""
LEVEL = "L5"
SCOPE = "只看第 0 关（ctx.level_prev == 0）的 RESET；只断言第 1 行列 1..61 这 61 格与面板 10 个开关共 30 格"
NOTE = "v2：第 1 关布局整个换了，面板不在原处，圈到第 0 关；别的关的 RESET 还没打过。"
EVIDENCE = ["b7cf75bfdf08999a"]

from _lib import (COUNTER_COLS, COUNTER_FULL, COUNTER_ROW, OFF, ON,
                  PANEL_SLOT_COLS, PANEL_STEM_ROWS, PANEL_TOP_ROW, in_level)

OPEN_PANEL = (OFF, ON, OFF, ON, ON)      # 开局态：1 号槽暗、2 号亮、3 号暗、4 号亮、5 号亮


def _want(prev):
    out = {(COUNTER_ROW, c): COUNTER_FULL for c in COUNTER_COLS}
    for k, col in enumerate(PANEL_SLOT_COLS):
        for r in PANEL_STEM_ROWS:
            out[(r, col)] = OPEN_PANEL[k]
        for c in range(col - 1, col + 2):
            out[(PANEL_TOP_ROW, c)] = OPEN_PANEL[k]
    return out


def assert_(prev, action, nxt, ctx=None):
    if not in_level(ctx, 0):
        return "NA"
    if action.split(":")[0] != "RESET":
        return "NA"
    return "TRUE" if all(nxt[r][c] == v for (r, c), v in _want(prev).items()) else "FALSE"


def apply(prev, action, ctx=None):
    if not in_level(ctx, 0):
        return None
    if action.split(":")[0] != "RESET":
        return None
    return _want(prev)
