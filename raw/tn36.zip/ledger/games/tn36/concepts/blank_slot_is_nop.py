"""工具栏不是四个方向框的那套关卡里，六排全暗的那一槽是无操作：把它整槽去掉之后算出来的件恰好填满空腔，这一下就过关。"""
LEVEL = "L1"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且底栏**不是**四方向框那一套（four_dir_boxes 为假——四框关卡里"
         "全暗槽让整串作废，那一片归 allblank_voids_program）；要求右面板读得出、整串码都认得、"
         "且这一串里**至少有一槽是六排全暗**；棋盘、件、空腔读不出返回 NA；"
         "把全暗槽去掉之后算出来的落点**不等于**空腔时返回 NA——这一条只声称「填满就过关」那一侧，"
         "别的落点它不预测（那要连带回答全暗槽在别处会不会也无操作，没量过）")
NOTE = ("由来是三次通关：第 321 步（a104ec10d06cca18）交 S S S ROT GROW NOP 过关，"
        "第 63 步与第 560 步（同一条 tid 67b8e1d774cf1d48，两个 run 各走到一次）交 S S S NOP ROT GROW 也过关——"
        "全暗槽在**末位**和**中间**各验过一次，结果一样：整串照常执行。\n"
        "为什么要单写一条：同一个码（六排全暗）在四框关卡里是让整串作废的"
        "（allblank_voids_program，第 383/392 步两次、后来第 470-497 步四次复现），在这套关卡里却什么都不做。"
        "一个码在两种关卡里意思相反，这件事必须自己走一次闸，不能藏在规划器的字母表里当默认。"
        "**它怎么被推翻**：五框关卡里再来一道去掉全暗槽后算出来正好填满空腔的程序，交上去没过关，这一条当场判 FALSE。\n"
        "**没声称的一半**：全暗槽在「不入位」的程序里是不是也无操作（件照走到落点），一次都没量过——"
        "五框关卡的交卷全是冲着入位去的。所以 scope 把那一侧整个留白，不靠沉默占地方。")
EVIDENCE = ["a104ec10d06cca18",                  # 第 321 步：S S S ROT GROW NOP 过关
            "67b8e1d774cf1d48"]                  # 第 63 / 560 步：S S S NOP ROT GROW 过关

from _lib import (board_piece, click_rc, four_dir_boxes, on_disc, panel_ops,
                  run_program, socket_cavity)


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return "NA"
    if four_dir_boxes(prev):
        return "NA"                              # 四框关卡：全暗槽作废，归 allblank_voids_program
    ops = panel_ops(prev)
    if not ops or "NOP" not in ops:
        return "NA"
    piece, cav = board_piece(prev), socket_cavity(prev)
    if not piece or cav is None:
        return "NA"
    got = run_program(piece, [o for o in ops if o != "NOP"])
    if got is None or set(got) != set(cav):
        return "NA"                              # 只声称「去掉全暗槽后正好填满」那一侧
    return "TRUE" if ctx.get("level_next") != ctx.get("level_prev") else "FALSE"
