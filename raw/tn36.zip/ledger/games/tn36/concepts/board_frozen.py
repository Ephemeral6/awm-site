"""第 0 关之内，棋盘区（行 9..40 × 列 14..49）在任何转移下一格都不变；换关那一帧整屏重画，不算。"""
LEVEL = "L2"
SCOPE = "只看第 0 关（ctx.level_prev == 0）；换关（level 变）返回 NA；「全暗时点大圆」那一类归 level0_win，返回 NA；只看棋盘边框以内的 32×36 格"
NOTE = "v3：第 1 关的屏幕布局整个换了，行 9..40 × 列 14..49 在那里不再是棋盘，所以圈到第 0 关。v2：v1 说的是「任何转移」，被换关那一帧打脸——第 0 关正是靠整屏重画才过的。"
EVIDENCE = ["a00717fa21e07a69", "24a7ff9c8bfa024c", "f509484bc9c53c3a",
            "b7cf75bfdf08999a", "89da7ba9203580e5"]

from _lib import (BOARD_COLS, BOARD_LEFT, BOARD_ROWS, BOARD_TOP, CELL,
                  in_level, is_circle_click_all_off)

ROWS = range(BOARD_TOP, BOARD_TOP + CELL * BOARD_ROWS)
COLS = range(BOARD_LEFT, BOARD_LEFT + CELL * BOARD_COLS)


def _mine(prev, action, ctx):
    return in_level(ctx, 0) and not is_circle_click_all_off(prev, action, ctx)


def assert_(prev, action, nxt, ctx=None):
    if not _mine(prev, action, ctx):
        return "NA"
    for r in ROWS:
        for c in COLS:
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _mine(prev, action, ctx):
        return None
    return {(r, c): prev[r][c] for r in ROWS for c in COLS}
