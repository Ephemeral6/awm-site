"""ACTION6 的落点既不在右半边面板的件上、也不在底栏那排框里、也不在大圆的包围盒里时，除顶栏那一格外整帧不动——棋盘、左上画布、左下对照面板都点不动。"""
LEVEL = "L2"
SCOPE = "只看关卡不变、面板与底栏量得出布局的 ACTION6；落点在面板命中盒 / 底栏任一框 / 大圆包围盒里的一律 NA（那三处各有主张）"
NOTE = ("v2。v1 接替 l1_inert_elsewhere：同一条主张，读法从写死的 4 槽 / 2 框改成每帧现量——"
        "第 2 关是 6 槽 / 4 框，大圆也跟着往右挪，写死的版本在那里会把「点空了」和「点在框上」判反。"
        "v2 只改 apply：原来返回 {} 等于一格都没认领，--strict 因此拦不住任何事，"
        "而这条概念的全部价值就是当全屏报警器。现在整帧照认。")
EVIDENCE = ["6fa42bec3fb10ed7", "af3fa9b79575ee1d", "d5cfdadb1a7b4362",
            "a5129922adb35855", "14460a34cc4bd88e"]

from _lib import (RPANEL_COLS, box_at, click_rc, diff_cells, frozen_frame,
                  on_disc, panel_layout, panel_slot_at, tool_boxes)


def _mine(prev, action, ctx):
    if not ctx or ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None:
        return False
    lay = panel_layout(prev, RPANEL_COLS)
    if lay is None or not tool_boxes(prev):
        return False
    r, c = rc
    return (panel_slot_at(lay, r, c) is None and box_at(prev, r, c) is None
            and not on_disc(prev, r, c))


def assert_(prev, action, nxt, ctx=None):
    if not _mine(prev, action, ctx):
        return "NA"
    return "TRUE" if not diff_cells(prev, nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if not _mine(prev, action, ctx):
        return None
    return frozen_frame(prev)
