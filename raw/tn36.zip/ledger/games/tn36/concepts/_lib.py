"""tn36 的词汇表 —— 每个定义都是假设，不是装置给的事实。

已实测的读法（来源：第 0-7 步）：
  ACTION6:x,y 里 x = 列，y = 行（第 7 步点 x=36,y=45，变的是 (行44..46, 列36)）。
  顶栏：第 1 行、列 1..61 共 61 格，开局全是色 9；每发一次 ACTION6 最右端的色 9 变成色 3。
  棋盘：色 0 边框 bbox (8,41,13,50)，内部行 9..40 × 列 14..49，按 4×4 分成 8 行 × 9 列的棋盘格。
  面板：色 0 边框 bbox (41,47,13,50)；上排 5 个 1×3 横条（第 42 行，列 20..22 / 25..27 / …，中心列 21,26,31,36,41）；
        下排 5 个 3×1 竖杆（行 44..46，列 21,26,31,36,41）。色 1 = 亮，色 5 = 与底色同（暗）。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

# ---- 顶栏 ----
COUNTER_ROW = 1
COUNTER_COLS = tuple(range(1, 62))          # 61 格
COUNTER_FULL = 9                            # 未消耗
COUNTER_SPENT = 3                           # 已消耗

# ---- 棋盘 ----
BOARD_TOP, BOARD_LEFT = 9, 14               # 内部左上角
CELL = 4                                    # 一格 4×4
BOARD_ROWS, BOARD_COLS = 8, 9

# ---- 面板 ----
PANEL_TOP_ROW = 42                          # 上排横条所在行
PANEL_STEM_ROWS = (44, 45, 46)              # 下排竖杆所在行
PANEL_SLOT_COLS = (21, 26, 31, 36, 41)      # 5 个槽的中心列
ON, OFF = 1, 5


def click_rc(action):
    """把 "ACTION6:x,y" 解成 (行, 列)；不带坐标或不是 ACTION6 返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except Exception:
        return None
    return (y, x)


def counter_left(g):
    """顶栏还剩几格色 9。"""
    return sum(1 for c in COUNTER_COLS if g[COUNTER_ROW][c] == COUNTER_FULL)


def counter_head(g):
    """顶栏最右端那个还没被消耗的格子的列号；没有返回 None。"""
    for c in reversed(COUNTER_COLS):
        if g[COUNTER_ROW][c] == COUNTER_FULL:
            return c
    return None


def cell_rect(i, j):
    """棋盘第 i 行第 j 列格子的 (行范围, 列范围)。"""
    r0 = BOARD_TOP + CELL * i
    c0 = BOARD_LEFT + CELL * j
    return range(r0, r0 + CELL), range(c0, c0 + CELL)


def cell_of(r, c):
    """帧坐标落在棋盘哪个格子；不在棋盘内部返回 None。"""
    i = (r - BOARD_TOP) // CELL
    j = (c - BOARD_LEFT) // CELL
    if 0 <= i < BOARD_ROWS and 0 <= j < BOARD_COLS and r >= BOARD_TOP and c >= BOARD_LEFT:
        return (i, j)
    return None


SLOT_HALFWIDTH = 2                          # 命中盒比画出来的件宽：假设，待打
TOP_BOX_ROWS = (41, 42, 43)                 # 上半格：命中算横条
STEM_BOX_ROWS = (44, 45, 46, 47)            # 下半格：命中算竖杆


def slot_of(r, c):
    """帧坐标落在面板第几个槽的哪一部分：("top", k) / ("stem", k) / None。

    命中盒不等于精灵：第 184 步点 (行 43, 列 31) —— 那是横条与竖杆之间的色 0 空隙 ——
    翻的是横条。所以这里按「面板上半格 / 下半格 × 槽中心列 ±2」划盒，而不是按画出来的格子。
    ±2 与行 41/47 都还没打过，它们是这一版故意伸出去的舌头：错了就当场是反例。
    """
    for k, col in enumerate(PANEL_SLOT_COLS):
        if abs(c - col) > SLOT_HALFWIDTH:
            continue
        if r in TOP_BOX_ROWS:
            return ("top", k)
        if r in STEM_BOX_ROWS:
            return ("stem", k)
    return None


def stem_color(g, k):
    return g[PANEL_STEM_ROWS[0]][PANEL_SLOT_COLS[k]]


def top_color(g, k):
    return g[PANEL_TOP_ROW][PANEL_SLOT_COLS[k]]


# ---- 第 0 关下方那个色 9 的大圆 ----
CIRCLE_ROWS = tuple(range(51, 60))          # 包围盒，不是圆本身
CIRCLE_COLS = tuple(range(32, 41))


def in_level(ctx, n):
    """这条转移是不是整个发生在第 n 关内（进关那一步、出关那一步都算不是）。"""
    if not ctx:
        return False
    return ctx.get("level_prev") == n and ctx.get("level_next") == n


def on_circle(r, c):
    """落点在第 0 关大圆的包围盒里。"""
    return r in CIRCLE_ROWS and c in CIRCLE_COLS


def panel_pieces(g):
    """面板 10 个件各自的颜色：{("top", k): 色, ("stem", k): 色}。"""
    out = {}
    for k, col in enumerate(PANEL_SLOT_COLS):
        out[("top", k)] = g[PANEL_TOP_ROW][col]
        out[("stem", k)] = g[PANEL_STEM_ROWS[0]][col]
    return out


def panel_all_off(g):
    """面板 10 个件是不是全暗（全是色 5）。"""
    return all(v == OFF for v in panel_pieces(g).values())


def is_circle_click_all_off(prev, action, ctx=None):
    """这一步是不是「第 0 关、面板全暗、点在大圆盒里」这一类——只是读法，这一类会发生什么由 level0_win 主张。"""
    if not ctx or ctx.get("level_prev") != 0:
        return False
    rc = click_rc(action)
    if rc is None or not on_circle(*rc):
        return False
    return panel_all_off(prev)


# ==================== 第 1 关 ====================
# 画面分四象限 + 一条底栏（读自第 191 步换关后那一帧）：
#   左上 行4..31 列2..29   底色 3 的画布，7×7 格，上面一个色 4 的 4×4 图形（带 2 格缺口）
#   右上 行4..31 列34..61  7×7 棋盘格（色 5 / 色 4 相间），上面色 11 的「件」与「插槽」
#   左下 行32..49 列7..24  对照面板：3 组 ×（4 横条 + 4 竖杆），点不动
#   右下 行32..49 列37..56 可点面板：同样 3 组 × 4 槽，色 1 = 亮 / 色 5 = 暗
#   底栏 行54..62          两个 9×9 的框（列7..15 / 列17..25，边框色 9 = 选中、色 2 = 没选中）+ 右边色 9 的大圆
# 画在框与左下面板之间、以及右下面板与大圆之间的那两条色 0 / 色 2 细线，是「谁喂谁」的提示。
L1_CANVAS_TOP, L1_CANVAS_LEFT = 4, 2
L1_BOARD_TOP, L1_BOARD_LEFT = 4, 34
L1_GRID = 7
L1_CANVAS_BG, L1_SHAPE = 3, 4

L1_BAR_ROWS = (33, 39, 45)                      # 三组横条各自所在的行（左右两块面板同行）
L1_STEM_ROWS = ((35, 36, 37), (41, 42, 43), (47, 48, 49))
L1_LEFT_COLS = (8, 13, 18, 23)                  # 左下对照面板 4 个槽的中心列
L1_RIGHT_COLS = (39, 44, 49, 54)                # 右下可点面板 4 个槽的中心列

L1_BOX = {"left": (54, 62, 7, 15), "mid": (54, 62, 17, 25)}   # (行0, 行1, 列0, 列1)
L1_SEL, L1_UNSEL = 9, 2

L1_DISC_ROWS = tuple(range(54, 63))             # 右下大圆的包围盒
L1_DISC_COLS = tuple(range(42, 51))

# 两个框各自对应的一套左半边定装：图形落在 7×7 的哪一格、缺口朝哪、对照面板哪几排是暗的。
# "init" 不是框，是 RESET 之后左半边回到的那一套（图形停在既不是 left 也不是 mid 的第三个位置，
# 而高亮却在 left —— 所以「按左框」在开局那一下是会动的）。
L1_CONFIG = {
    "left": {"cell": (3, 1), "notch": "W", "off": (("bar", 0),)},
    "mid": {"cell": (1, 3), "notch": "N", "off": (("bar", 0), ("stem", 2))},
    "init": {"cell": (3, 5), "notch": "W", "off": (("bar", 0),), "sel": "left"},
}

_NOTCH_CUT = {"N": ((0, 1), (0, 2)), "S": ((3, 1), (3, 2)),
              "W": ((1, 0), (2, 0)), "E": ((1, 3), (2, 3))}


def l1_shape_cells(cell, notch):
    """左上画布第 (i,j) 格上、缺口朝 notch 的那个图形占哪 14 格。"""
    i, j = cell
    r0 = L1_CANVAS_TOP + CELL * i
    c0 = L1_CANVAS_LEFT + CELL * j
    out = {(r0 + dr, c0 + dc) for dr in range(CELL) for dc in range(CELL)}
    for dr, dc in _NOTCH_CUT[notch]:
        out.discard((r0 + dr, c0 + dc))
    return out


def l1_canvas_shape(g):
    """左上画布上现在哪些格是色 4。"""
    return {(r, c)
            for r in range(L1_CANVAS_TOP, L1_CANVAS_TOP + CELL * L1_GRID)
            for c in range(L1_CANVAS_LEFT, L1_CANVAS_LEFT + CELL * L1_GRID)
            if g[r][c] == L1_SHAPE}


def l1_piece_cells(kind, gi, k, cols):
    """面板上第 gi 组第 k 槽的横条 / 竖杆画出来占哪 3 格。"""
    col = cols[k]
    if kind == "bar":
        return {(L1_BAR_ROWS[gi], col + d) for d in (-1, 0, 1)}
    return {(r, col) for r in L1_STEM_ROWS[gi]}


def l1_right_slot(r, c):
    """右下面板的命中盒 -> ("bar"|"stem", 组号 0..2, 槽号 0..3)；不在返回 None。

    仍按「每组 6 行、上半 3 行算横条、下半 3 行算竖杆、槽中心列 ±2」划盒——
    第 0 关的教训是命中盒比画出来的精灵大，这里照搬那个划法，划错了当场是反例。
    """
    if not (32 <= r <= 49):
        return None
    gi = (r - 32) // 6
    kind = "bar" if (r - 32) % 6 < 3 else "stem"
    for k, col in enumerate(L1_RIGHT_COLS):
        if abs(c - col) <= 2:
            return (kind, gi, k)
    return None


def l1_box_of(r, c):
    """落点在底栏哪个 9×9 框里；都不在返回 None。"""
    for name, (r0, r1, c0, c1) in L1_BOX.items():
        if r0 <= r <= r1 and c0 <= c <= c1:
            return name
    return None


def l1_on_disc(r, c):
    return r in L1_DISC_ROWS and c in L1_DISC_COLS


def l1_box_border(name):
    r0, r1, c0, c1 = L1_BOX[name]
    return {(r, c)
            for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
            if r in (r0, r1) or c in (c0, c1)}


def l1_config_changes(prev, name):
    """点了 name 那个框之后左半边该变成什么：{(行,列): 色}，只列与 prev 不同的格。"""
    cfg = L1_CONFIG[name]
    want = {}
    old = l1_canvas_shape(prev)
    new = l1_shape_cells(cfg["cell"], cfg["notch"])
    for rc in old - new:
        want[rc] = L1_CANVAS_BG
    for rc in new:
        want[rc] = L1_SHAPE
    off = set(cfg["off"])
    for gi in range(3):
        for kind in ("bar", "stem"):
            color = OFF if (kind, gi) in off else ON
            for k in range(len(L1_LEFT_COLS)):
                for rc in l1_piece_cells(kind, gi, k, L1_LEFT_COLS):
                    want[rc] = color
    for other in L1_BOX:
        color = L1_SEL if other == cfg.get("sel", name) else L1_UNSEL
        for rc in l1_box_border(other):
            want[rc] = color
    return {rc: v for rc, v in want.items() if prev[rc[0]][rc[1]] != v}


def diff_cells(a, b, skip_row=COUNTER_ROW):
    """两帧差在哪：{(行,列): 新色}，默认跳过顶栏那一行（顶栏归 counter_spends 管）。"""
    return {(r, c): b[r][c]
            for r in range(len(a)) for c in range(len(a[r]))
            if r != skip_row and a[r][c] != b[r][c]}


# ==================== 从帧上量布局（第 1 关起的那套画面） ====================
# 第 1 关与第 2 关是同一种画面、不同的尺码：面板槽数从 4 变 6，底栏的框从 2 个变 4 个，
# 大圆也跟着往右挪。所以这些数不能写死——写死一次就只对一关。下面这些函数一律从帧上量。
SEL, UNSEL = 9, 2                               # 框边框：高亮 / 没高亮
BLOCK = 11                                      # 棋盘上的「件」与「插槽」
CANVAS_ROWS, CANVAS_COLS = (3, 31), (1, 30)
BOARD_ROWS_REGION, BOARD_COLS_REGION = (3, 32), (32, 61)
PANEL_BAND = (32, 50)
LPANEL_COLS, RPANEL_COLS = (1, 30), (32, 61)
STRIP_ROWS = (51, 63)
BOX_SIZE = 9


def _runs(seq):
    """把一串递增的整数切成连续段。"""
    out = []
    for v in seq:
        if out and v == out[-1][-1] + 1:
            out[-1].append(v)
        else:
            out.append([v])
    return out


def panel_layout(g, cols):
    """量一块面板：{"bars": [横条行…], "stems": [(竖杆三行)…], "cols": (槽中心列…)}。

    量不出成对的横条/竖杆就返回 None——读法不适用，用它的概念该 NA。
    """
    c0, c1 = cols
    rows = [r for r in range(PANEL_BAND[0], PANEL_BAND[1] + 1)
            if any(g[r][c] in (ON, OFF) for c in range(c0, c1 + 1))]
    runs = _runs(rows)
    bars = [rr[0] for rr in runs if len(rr) == 1]
    stems = [tuple(rr) for rr in runs if len(rr) == 3]
    if not bars or len(bars) != len(stems) or len(runs) != len(bars) + len(stems):
        return None
    r = stems[0][0]
    centers = tuple(c for c in range(c0, c1 + 1) if g[r][c] in (ON, OFF))
    if not centers:
        return None
    return {"bars": bars, "stems": stems, "cols": centers}


def piece_cells(lay, kind, gi, k):
    """面板上第 gi 组第 k 槽的横条 / 竖杆画出来占哪 3 格。"""
    col = lay["cols"][k]
    if kind == "bar":
        return {(lay["bars"][gi], col + d) for d in (-1, 0, 1)}
    return {(r, col) for r in lay["stems"][gi]}


def panel_code(g, lay):
    """一块面板现在的样子：{("bar"|"stem", 组号, 槽号): 色}。"""
    out = {}
    for gi in range(len(lay["bars"])):
        for kind in ("bar", "stem"):
            for k in range(len(lay["cols"])):
                rc = next(iter(piece_cells(lay, kind, gi, k)))
                out[(kind, gi, k)] = g[rc[0]][rc[1]]
    return out


def panel_slot_at(lay, r, c):
    """落点落在这块面板的哪个件上：(kind, 组号, 槽号)；不在返回 None。

    命中盒按「横条行 ±1 算横条、竖杆那三行算竖杆、槽中心列 ±2」划——比画出来的件大一圈，
    这是第 0 关那次打脸（点在两件之间的空隙上翻的是上面那件）留下的划法。
    """
    kind = gi = None
    for i, br in enumerate(lay["bars"]):
        if abs(r - br) <= 1:
            kind, gi = "bar", i
        if r in lay["stems"][i]:
            kind, gi = "stem", i
    if kind is None:
        return None
    for k, col in enumerate(lay["cols"]):
        if abs(c - col) <= 2:
            return (kind, gi, k)
    return None


def tool_boxes(g):
    """底栏那一排 9×9 的框：[(行0, 行1, 列0, 列1, 边框色)]，按列从左到右；没有返回 []。

    框是**空心的方框**，所以上下两条边都要在——只认上边那一行会把圆认成框：
    一个色 9 的圆最宽的那一行恰好是 9 像素，函数从那儿往下扩满 9 行，扩出去的最后两行
    其实是背景色。审计实测：只认上边的版本在某一关的 143/143 帧上都报出一个不存在的框，
    而依赖它的概念照样判 TRUE（那些点击本来就什么都不改），一格分都不掉。
    """
    def runs9(r):
        found, row, c = [], g[r], 0
        while c < len(row):
            if row[c] in (SEL, UNSEL):
                c2 = c
                while c2 + 1 < len(row) and row[c2 + 1] == row[c]:
                    c2 += 1
                if c2 - c + 1 == BOX_SIZE:
                    found.append((c, c2, row[c]))
                c = c2 + 1
            else:
                c += 1
        return found

    best = None
    for r in range(STRIP_ROWS[0], min(STRIP_ROWS[1] + 1, len(g))):
        rb = r + BOX_SIZE - 1
        if rb >= len(g):
            break
        bottom = runs9(rb)
        found = [b for b in runs9(r) if b in bottom]      # 上下两条边对齐、同色，才算一个框
        if found and (best is None or len(found) > len(best[1])):
            best = (r, found)
    if best is None:
        return []
    r, found = best
    return [(r, r + BOX_SIZE - 1, c0, c1, v) for c0, c1, v in found]


def box_at(g, r, c):
    """落点落在第几个框里（从 0 数）；都不在返回 None。"""
    for i, (r0, r1, c0, c1, _v) in enumerate(tool_boxes(g)):
        if r0 <= r <= r1 and c0 <= c <= c1:
            return i
    return None


def four_dir_boxes(g):
    """底栏是不是「恰好四个框、每个框里都有一块偏离框心的图标」。

    两条概念拿它划同一条界：框里的图标偏出框心 = 那个框指一个方向；
    出现「框里没有块」或「图标居中」的框，就不是这一套四方向的关卡。
    """
    boxes = tool_boxes(g)
    if len(boxes) != 4:
        return False
    for b in boxes:
        cells = [(r, c) for r in range(b[0] + 1, b[1]) for c in range(b[2] + 1, b[3])
                 if g[r][c] == BLOCK]
        if not cells:
            return False
        dr = sum(r for r, _ in cells) / len(cells) - (b[0] + b[1]) / 2
        dc = sum(c for _, c in cells) / len(cells) - (b[2] + b[3]) / 2
        if abs(dr) < 1 and abs(dc) < 1:
            return False
    return True


def disc_box(g):
    """底栏最右边那团色 9（扳机）的包围盒 (行0, 行1, 列0, 列1)；没有返回 None。"""
    boxes = tool_boxes(g)
    right = max((b[3] for b in boxes), default=-1)
    cells = [(r, c)
             for r in range(STRIP_ROWS[0], min(STRIP_ROWS[1] + 1, len(g)))
             for c in range(right + 1, len(g[r])) if g[r][c] == SEL]
    if not cells:
        return None
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    return (min(rs), max(rs), min(cs), max(cs))


def on_disc(g, r, c):
    box = disc_box(g)
    if box is None:
        return False
    r0, r1, c0, c1 = box
    return r0 <= r <= r1 and c0 <= c <= c1


def board_geom(g):
    """右上棋盘：(左上行, 左上列, 行格数, 列格数)；量不出返回 None。"""
    cells = [(r, c)
             for r in range(BOARD_ROWS_REGION[0], BOARD_ROWS_REGION[1] + 1)
             for c in range(BOARD_COLS_REGION[0], BOARD_COLS_REGION[1] + 1)
             if g[r][c] != 0]
    if not cells:
        return None
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    h = max(rs) - min(rs) + 1
    w = max(cs) - min(cs) + 1
    if h % CELL or w % CELL:
        return None
    return (min(rs), min(cs), h // CELL, w // CELL)


def blobs(g, rows, cols, color):
    """指定矩形里某个颜色的四连通块，按左上角排序返回 [set((行,列))]。"""
    todo = {(r, c) for r in rows for c in cols if g[r][c] == color}
    out = []
    while todo:
        seed = min(todo)
        comp, stack = set(), [seed]
        while stack:
            rc = stack.pop()
            if rc in comp or rc not in todo:
                continue
            comp.add(rc)
            r, c = rc
            stack += [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
        todo -= comp
        out.append(comp)
    return sorted(out, key=lambda s: min(s))


def notch_cuts(s):
    """倍数为 s 的件，四个方向的缺口各自缺掉哪些相对格（相对左上角）。"""
    return {
        "N": {(r, c) for r in range(0, s) for c in range(s, 3 * s)},
        "S": {(r, c) for r in range(3 * s, 4 * s) for c in range(s, 3 * s)},
        "W": {(r, c) for r in range(s, 3 * s) for c in range(0, s)},
        "E": {(r, c) for r in range(s, 3 * s) for c in range(3 * s, 4 * s)},
    }


def piece_shape(cells):
    """一块「件」的形状：(倍数 s, 缺口方向)；不是这种形状返回 None。

    件 = 4s × 4s 的方块，在某一条边的正中缺掉 2s × s 一块（s=1 就是最早那种 4×4 缺 2 格）。
    第 3 关的棋盘上出现了 s=2 的件——8×8、缺口 4 宽 2 深——所以「件」这个词不能再写死成 4×4。
    """
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    r0, c0, r1, c1 = min(rs), min(cs), max(rs), max(cs)
    h, w = r1 - r0 + 1, c1 - c0 + 1
    if h != w or h == 0 or h % CELL:
        return None
    s = h // CELL
    missing = ({(r, c) for r in range(h) for c in range(w)}
               - {(r - r0, c - c0) for r, c in cells})
    if len(missing) != 2 * s * s:
        return None
    for d, cut in notch_cuts(s).items():
        if missing == cut:
            return (s, d)
    return None


def piece_at(top, left, s, notch):
    """左上角落在像素 (top, left)、倍数 s、缺口朝 notch 的那块件占哪些格。"""
    n = CELL * s
    cut = notch_cuts(s)[notch]
    return {(top + dr, left + dc)
            for dr in range(n) for dc in range(n) if (dr, dc) not in cut}


def notch_of(cells):
    """一个件的缺口朝哪：'N'/'S'/'W'/'E'；不是件的形状返回 None。"""
    shape = piece_shape(cells)
    return shape[1] if shape else None



def board_piece(g):
    """棋盘上那个能动的「件」占哪些格（色 11 里带缺口的那一块）；找不到返回 None。
    插槽是个 16 格的括号形，notch_of 认不出来，正好用来区分。"""
    geom = board_geom(g)
    if geom is None:
        return None
    t, l, nr, nc = geom
    for s in blobs(g, range(t, t + CELL * nr), range(l, l + CELL * nc), BLOCK):
        if notch_of(s):
            return s
    return None


def panel_off_rows(g, cols):
    """一块面板里「整排都暗」的是哪几排：frozenset((kind, 组号))；有半暗的排返回 None。"""
    lay = panel_layout(g, cols)
    if lay is None:
        return None
    code = panel_code(g, lay)
    n = len(lay["cols"])
    out = set()
    for gi in range(len(lay["bars"])):
        for kind in ("bar", "stem"):
            vals = {code[(kind, gi, k)] for k in range(n)}
            if vals == {OFF}:
                out.add((kind, gi))
            elif vals != {ON}:
                return None
    return frozenset(out)


def panel_off_shape(g, cols):
    """面板暗着的件是不是「某几排的前 k 个槽」：返回 (frozenset((kind,组号)), k)；不是这形状返回 None。"""
    lay = panel_layout(g, cols)
    if lay is None:
        return None
    code = panel_code(g, lay)
    rows_off = {}
    for (kind, gi, k), v in code.items():
        if v == OFF:
            rows_off.setdefault((kind, gi), set()).add(k)
    if not rows_off:
        return None
    shapes = {frozenset(s) for s in rows_off.values()}
    if len(shapes) != 1:
        return None
    s = next(iter(shapes))
    if s != set(range(len(s))):
        return None
    return (frozenset(rows_off), len(s))


# 密码本：一条指令 -> 对照面板上「哪几排是暗的」。
# 出处：第 243-246 步（第 2 关四个框）与第 257-260 步（第 3 关四个框）逐个点框、读左下对照面板。
# 换关换的是**框的排序**，不是码：第 2 关的框 0..3 是 南北西东，第 3 关是 西·放大·南·缩小，
# 而「西 = A竖杆+C竖杆」「南 = A横条+A竖杆」两关一模一样。所以这张表是全局的，一关只是取它的一个子集。
DELTA = {"N": (-1, 0), "S": (1, 0), "W": (0, -1), "E": (0, 1)}   # 一格的行列增量
OP_CODE = {
    "S": frozenset({("bar", 0), ("stem", 0)}),
    "N": frozenset({("bar", 0), ("stem", 2)}),
    "W": frozenset({("stem", 0), ("stem", 2)}),
    "E": frozenset({("stem", 0)}),
    "GROW": frozenset({("stem", 1)}),
    "SHRINK": frozenset({("bar", 0), ("stem", 1)}),
    "ROT": frozenset({("bar", 0), ("bar", 1)}),
    # 「六排全暗」= 无操作。出处：第 4 关工具栏第五个框（框 4）的码就是这个，
    # 而第 321 步交上去的 S S S ROT GROW 框4 当场过关——那道程序在「空槽作废 + 缩放锚左上」下
    # 只有把框 4 读成无操作才恰好填满空腔。这一条同时把「六槽必须全填」钉住了：
    # 同一道程序把第 6 槽留空（第 303 步）一格没动，换成框 4 就过关，两次只差这一槽。
    # 故意伸出去的舌头：如果框 4 其实是**终止符**（读到它就停，后面的不执行），
    # 那么把它放在程序中间的一道正解会一格不动——那一步当场就是 disc_fit_clears_level 的反例。
    # 目前只见过它排在最后一槽，没有任何证据分开「无操作」与「终止符」。
    "NOP": frozenset({("bar", 0), ("bar", 1), ("bar", 2),
                      ("stem", 0), ("stem", 1), ("stem", 2)}),
}
BY_CODE = {code: op for op, code in OP_CODE.items()}

# 第五个码，和上面那段注释打架：{A横条} 单独一排暗。
# 出处：第 334-336 步在第 5 关逐个点底栏的框、读左面板——框 3 的图标是「色 11 的块贴着框的西边」
# （和第 2 关框 2、第 3 关框 0 那两个**被通关证实为西移**的图标逐像素同形），点下去左面板读出的
# 暗排却是 {("bar",0)}，而不是上表里的西 {("stem",0),("stem",2)}。
# 同一关的另外三个框（南/北/东）读出来的码和上表一字不差，所以不是「换关整张表重排」，
# 是**只有西边这一个符号有两套码**——要么这张表不是全局的，要么这是个没认出来的第五种指令。
# 先按「图标说什么就是什么」读成西移一格；这不是结论，是一根故意伸出去的舌头：
# 第 5 关件在 (4,4)、插座在 (1,1)，只有 W W N N N W 走得通，交上去赢了它就是西移，
# 整帧不动或件挪到别处，它就不是——disc_runs_program 会当场吃反例。
CODE_ALIAS = {frozenset({("bar", 0)}): "W"}
BY_CODE.update(CODE_ALIAS)

# 「旋转」一步把缺口朝向怎么换：**对合**，南<->东、北<->西（沿主对角线翻，不是转 90°）。
# 两条互不相干的依据把它夹死了：
#   （甲）示范图：第 4 关框 3 的图形停在画布正中格、没挪窝、没改大小，缺口从别的框那张标准图的南变成了东
#        —— 所以这一步把 南 送到 东。框 3 的图标本身也是个菱形（1-3-5-3-1），对角线对称。
#   （乙）关卡设计：第 4 关的件缺口朝东、要填的空腔缺口朝南，而在「缩放锚=左上」下（锚由三次通关唯一钉死）
#        穷举 1..6 条指令，只有「东一步到南」的映射才有解；转 90° 的两个环里，南->东 那个环
#        （东->北）整个第 4 关无解，另一个环（东->南）与（甲）的 南->东 冲突。
# 对合同时满足（甲）（乙）：它是唯一两边都对得上的读法。原先写的是 南->东->北->西->南 那个四循环，
# 被（乙）推翻——当时它只有（甲）一条依据，而（甲）不区分「对合」和「四循环」。
# 后来把锚放开重算了一遍（放大锚四种 × 旋转四张表）：转 90° 的那两个环在**任何**一个锚下、
# 1..6 条指令内都让第 4 关无解；只有两张对合有解，而其中「南<->西」与（甲）的示范图冲突。
# 所以这张表现在由两条独立的依据各自单独钉死，不再只靠合取。
ROT_NOTCH = {"S": "E", "E": "S", "N": "W", "W": "N"}


def run_program(piece, ops):
    """把一串指令依次作用在件上，返回最后占哪些格；有一条做不了返回 None。

    移动 = 整体平移一格（CELL 像素）；放大 = 倍数 ×2、缩小 = ÷2，两者都**左上角不动**
    （依据：示范图形里放大与缩小那两张都画在画布左上角格；缩小的锚由第 3 关通关钉死，
    放大的锚由第 321 步通关钉死——那一步是六槽全填的 S S S ROT GROW NOP，
    换成「锚在左下」的六槽解 S S S S ROT GROW 同一批里先交过，一格没动）。
    旋转 = 只换缺口朝向，左上角与倍数都不动（依据：示范图停在正中格、只有缺口变了）。
    无操作 = 什么都不做。件已是最小还要缩，这里没定义。
    """
    shape = piece_shape(piece)
    if shape is None:
        return None
    s, notch = shape
    top = min(r for r, _ in piece)
    left = min(c for _, c in piece)
    for op in ops:
        if op == "NOP":
            continue
        if op in DELTA:
            dr, dc = DELTA[op]
            top += dr * CELL
            left += dc * CELL
        elif op == "GROW":
            s *= 2
        elif op == "SHRINK":
            if s % 2:
                return None
            s //= 2
        elif op == "ROT":
            notch = ROT_NOTCH[notch]
        else:
            return None
    return piece_at(top, left, s, notch)


def canvas_geom(g):
    """左上示范画布：(网格左上行, 网格左上列, 边长格数)；量不出返回 None。

    画布是那块底色 3 的矩形，网格从它的包围盒左上角往里挪一像素起算。
    """
    cells = [(r, c)
             for r in range(CANVAS_ROWS[0], CANVAS_ROWS[1] + 1)
             for c in range(CANVAS_COLS[0], CANVAS_COLS[1] + 1)
             if g[r][c] in (L1_CANVAS_BG, L1_SHAPE)]
    if not cells:
        return None
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    n = min(max(rs) - min(rs), max(cs) - min(cs)) // CELL
    if n < 1:
        return None
    return (min(rs) + 1, min(cs) + 1, n)


def canvas_piece(g):
    """左上画布里那个示范图形：(格行, 格列, 倍数, 缺口)；读不出返回 None。"""
    geom = canvas_geom(g)
    if geom is None:
        return None
    top, left, n = geom
    cells = {(r, c)
             for r in range(top, top + CELL * n) for c in range(left, left + CELL * n)
             if g[r][c] == L1_SHAPE}
    if not cells:
        return None
    shape = piece_shape(cells)
    if shape is None:
        return None
    r0 = min(r for r, _ in cells)
    c0 = min(c for _, c in cells)
    if (r0 - top) % CELL or (c0 - left) % CELL:
        return None
    return ((r0 - top) // CELL, (c0 - left) // CELL, shape[0], shape[1])


def panel_program(g, cols):
    """把一块面板从左到右读成一串码：第 k 个槽那一竖列里暗着的灯 -> frozenset((kind, 组号))。

    量不出布局返回 None。空 frozenset 表示这一槽整列都亮着（没写码）。
    """
    lay = panel_layout(g, cols)
    if lay is None:
        return None
    code = panel_code(g, lay)
    ngroup = len(lay["bars"])
    return [frozenset((kind, gi)
                      for gi in range(ngroup) for kind in ("bar", "stem")
                      if code[(kind, gi, k)] == OFF)
            for k in range(len(lay["cols"]))]


def frozen_frame(g, skip_row=COUNTER_ROW):
    """整帧照抄（跳过顶栏那一行，顶栏归计数器那条概念管）——给「除顶栏外一格不动」这类概念当 apply。

    返回 {} 等于什么都没认领，--strict 也就拦不住任何事；要让「别处不动」真的当报警器用，
    它得把每一格都说出来。
    """
    return {(r, c): g[r][c]
            for r in range(len(g)) for c in range(len(g[r])) if r != skip_row}


# ==================== 插槽与「程序算出来的件」 ====================
SOCKET_COLORS = (BLOCK, 15)                 # 插槽画出来用的颜色：第 1-3 关是色 11，第 4 关是色 15


def board_socket(g):
    """棋盘上那个「插槽」占哪些格；找不到返回 None。

    判据是形状：件是 4s×4s 缺一口的方块（piece_shape 认得），插槽是个括号形（认不出来）。
    颜色两种都扫——色 11 与色 15 —— 因为换关会换插槽的颜色，写死一个只对一关。
    """
    geom = board_geom(g)
    if geom is None:
        return None
    cand = []
    t, l, nr, nc = geom
    for color in SOCKET_COLORS:
        cand += blobs(g, range(t, t + CELL * nr), range(l, l + CELL * nc), color)
    cand = [b for b in cand if notch_of(b) is None]
    return max(cand, key=len) if cand else None


def socket_cavity(g):
    """插槽的空腔 = 插槽的包围盒减去插槽自己；读不出返回 None。

    为什么是「包围盒减自己」：插槽画成一个三面围起来、开口朝外的括号，围出来的那块空地
    正好是一个件的形状（第 1/2 关量出来是 (1,'N')，第 3 关 (1,'S')，第 4 关 (2,'S')）。
    这个读法**不依赖任何操作语义**，是一块独立的像素证据，用来给 OP_CODE 与 run_program 上闸。
    """
    s = board_socket(g)
    if s is None:
        return None
    rs = [r for r, _ in s]
    cs = [c for _, c in s]
    box = {(r, c) for r in range(min(rs), max(rs) + 1) for c in range(min(cs), max(cs) + 1)}
    return box - s


def program_result(g, cols=RPANEL_COLS):
    """把右面板那串码当成一道程序、作用在棋盘上那个件上，返回它该占哪些格；算不出返回 None。

    算不出的情形：面板布局读不出、棋盘上找不到件、有一槽的码不在密码本里、程序里有做不了的
    一步（最小号还要缩）、**或者有一槽是空的**。
    **整列都亮的空槽让整串作废。** 出处是第 303 步那次实测：在「缩放锚=左上」下，
    「S S S ROT GROW + 一个空槽」算出来的件与空腔逐格相等，按下去却一格没动。
    上一版把空槽当无操作（理由是这个锚下恰好 6 条指令的解是 0 个、最短解 5 条，所以第 6 槽必须能空着），
    那一版把它写成了故意伸出去的舌头——舌头被咬了，所以现在改成作废。

    诚实标注：这次打脸只否掉了「空槽是无操作」与「放大锚在左上」的**合取**，没说清是哪一个错。
    全部 8 次按大圆上，「空槽作废 + 放大锚左上」与「空槽无操作 + 放大锚左下/右上」都是 8/8，
    分不开——因为四次通关里没有一次用到放大，放大的锚一次都没被检验过。
    这里先按「空槽作废 + 锚统一在左上」写（缩小的锚是左上，那一条是三次通关唯一钉死的，
    假设两种缩放共用一个锚最省），另一支由下一批的甲相（六槽全填的 S S S S ROT GROW）当场分开。
    """
    prog = panel_program(g, cols)
    piece = board_piece(g)
    if prog is None or piece is None:
        return None
    ops = []
    for slot in prog:
        if not slot:
            return None                     # 空槽 = 整串作废
        op = BY_CODE.get(slot)
        if op is None:
            return None
        ops.append(op)
    return run_program(piece, ops)


def submit_fits(g, action):
    """这一下是不是「按大圆交卷、而且算出来的件恰好填满插槽的空腔」；不是按大圆或读不出返回 None。

    抽出来给三条概念共用：答错那一侧（整帧不动）、换关那一侧（关卡前进）、以及顶栏
    （交卷成功那一下顶栏是刷回满格，不是扣一格，所以 counter_spends 在这里必须闭嘴）。
    """
    rc = click_rc(action)
    if rc is None or not on_disc(g, *rc):
        return None
    if board_piece(g) is None or board_socket(g) is None:
        return None
    cav = socket_cavity(g)
    if cav is None:
        return None
    return program_result(g) == cav


# ==================== 墙、底色、逐格走 ====================
# 出处：第 341-350 步。第 333 步交的 E N N N N N 在「不看墙」下算出来恰好填满空腔，世界一格没动；
# 第 350 步交的 E E E E N N 在「不看墙」下**填不满**，世界却把件从 (6,0) 挪到了 (4,4)（帧差 22 格）。
# 两次只差一件事：前者第二步要走进整格色 6 的 (5,1)，后者六步一格墙都没碰。
# 所以「填不满就整帧不动」是错的（disc_noop_unless_fit 因此撤册），真正的判据是**走得通/走不通**。
WALL = 6                                    # 棋盘上挡路的颜色
BG_EVEN, BG_ODD = 5, 4                      # 棋盘底色：(格行+格列) 偶数是色 5，奇数是色 4


def bg_color(i, j):
    """棋盘第 i 行第 j 列那一格的底色。

    出处：第 5 关那一帧逐像素读全部 49 格——不是墙、不是件、不是插座、不是点画格的格子，
    16 个像素同色，且 (i+j) 偶数一律色 5、奇数一律色 4，49 格无例外。
    """
    return BG_EVEN if (i + j) % 2 == 0 else BG_ODD


def cell_px(g, i, j):
    """棋盘第 i 行第 j 列那一格占哪些像素格；棋盘量不出或越界返回 None。"""
    geom = board_geom(g)
    if geom is None:
        return None
    t, l, nr, nc = geom
    if not (0 <= i < nr and 0 <= j < nc):
        return None
    return {(t + i * CELL + dr, l + j * CELL + dc) for dr in range(CELL) for dc in range(CELL)}


def board_walls(g):
    """棋盘上哪些格挡路：一格里色 6 的像素占到一半以上就算墙。返回 set((格行, 格列))。

    为什么是「过半」而不是「全格」：插座的括号压在两格墙的边上（那两格 16 个像素里有 4 个是
    插座的色 11），全格判据会把它们漏成通路。
    """
    geom = board_geom(g)
    if geom is None:
        return None
    t, l, nr, nc = geom
    out = set()
    for i in range(nr):
        for j in range(nc):
            n = sum(1 for dr in range(CELL) for dc in range(CELL)
                    if g[t + i * CELL + dr][l + j * CELL + dc] == WALL)
            if n * 2 > CELL * CELL:
                out.add((i, j))
    return out


def board_pads(g):
    """棋盘上的「花格」：一格 16 个像素是色 11 与该格底色的棋盘格交错（左上角那一像素是色 11）。
    返回 set((格行, 格列))；棋盘量不出返回 None。

    它们是件可以停下来的地方：一道全走得通的程序，终点不落在花格也不落在插座空腔上，整帧就不动
    （第 5 关一道终点落在普通格上的程序当场证实）；终点落在花格上件才照走（第 5 关 E E E E N N 到 (4,4)）。
    """
    geom = board_geom(g)
    if geom is None:
        return None
    t, l, nr, nc = geom
    out = set()
    for i in range(nr):
        for j in range(nc):
            bg = bg_color(i, j)
            if all(g[t + i * CELL + dr][l + j * CELL + dc] == (BLOCK if (dr + dc) % 2 == 0 else bg)
                   for dr in range(CELL) for dc in range(CELL)):
                out.add((i, j))
    return out


MARK = 14                                   # 记号格那根竖条的颜色


def marked_cells(g):
    """棋盘上带色 14 的格：返回 set((格行, 格列))；棋盘量不出返回 None。

    这类格整局只在一块盘上出现过，一行两格、左右对称（一格的竖条贴西边缘、另一格贴东边缘），
    竖条之外那两排是色 12/13 的棋盘纹，两格的纹路互为反相。
    """
    geom = board_geom(g)
    if geom is None:
        return None
    t, l, nr, nc = geom
    return {(i, j) for i in range(nr) for j in range(nc)
            if any(g[t + i * CELL + dr][l + j * CELL + dc] == MARK
                   for dr in range(CELL) for dc in range(CELL))}


def marked_rows(g):
    """带色 14 记号的格占了棋盘的哪几行（格行号）；棋盘量不出返回 None。"""
    cells = marked_cells(g)
    return None if cells is None else {i for i, _ in cells}


MARK_RUN_LIMIT = 4                          # 带记号的盘上，同一条指令连到这个数就作废
MARK_MIN_OPS = 3                            # 同上，整串用到的不同指令少于这个数是「码太少」那一侧
MARK_MAX_DWELL = 1                          # 同上，路径落在记号行的步数超过这个数是「久留」那一侧


def marked_prog_class(g, ops):
    """带记号的盘上，一道全平移程序按册子现有读法落在哪一类（**不看终点**）：

    'runs'   同一条指令连四以上 —— 归 four_in_a_row_voids
    'void'   码少于三种 **且** 路径在记号行上落了两步以上 —— 归 few_ops_and_dwell_voids
    'unsure' 上面两个条件只中一个 —— 两种更宽的读法在这里分岔，册子闭嘴（见 few_ops_and_dwell_voids NOTE）
    'ok'     两个条件都不中，按普通盘读
    不是带记号的盘、或路径算不出，返回 None。
    """
    marks = marked_cells(g)
    if not marks:
        return None
    if any(op not in DELTA for op in ops):
        return None
    if max_run(list(ops)) >= MARK_RUN_LIMIT:
        return "runs"
    path = walk_path_skip(g, ops)
    if path is None:
        return None
    rows = {i for i, _ in marks}
    dwell = sum(1 for i, _ in path[1:] if i in rows)
    few = len(set(ops)) < MARK_MIN_OPS
    if few and dwell > MARK_MAX_DWELL:
        return "void"
    return "unsure" if (few or dwell > MARK_MAX_DWELL) else "ok"


def max_run(ops):
    """一串指令里同一条指令最长连了几个（空串返回 0）。"""
    best = cur = 0
    prev = None
    for op in ops:
        cur = cur + 1 if op == prev else 1
        prev = op
        best = max(best, cur)
    return best


def piece_cell(g):
    """件左上角落在棋盘的第几行第几列格；读不出返回 None。"""
    geom, piece = board_geom(g), board_piece(g)
    if geom is None or piece is None:
        return None
    t, l = geom[0], geom[1]
    top = min(r for r, _ in piece) - t
    left = min(c for _, c in piece) - l
    if top % CELL or left % CELL:
        return None
    return (top // CELL, left // CELL)


def piece_footprint(i, j, s):
    """左上角在格 (i, j)、倍数 s 的件盖住哪些格：s×s 个。

    s=1 时就是 {(i, j)} 本身——所以「件只占一格」的旧读法是这个的特例，不是它的反例。
    """
    return {(i + di, j + dj) for di in range(s) for dj in range(s)}


def program_trace(g, ops):
    """件按 ops 逐条走，返回每一步之后的形态 [(格行, 格列, 倍数, 缺口), ...]。

    语义与 run_program 逐字对齐，但**不核墙、不核边界**——那是概念该判的事，
    词汇替概念判了，判据就跑到闸外去了。
    读不出件或棋盘返回 None；某一条指令做不了（奇数倍还要缩、认不出的码）就停在那里，
    返回的列表短于 ops，调用方据此知道整串没走完。
    """
    shape = piece_shape(board_piece(g) or set())
    start, geom = piece_cell(g), board_geom(g)
    if shape is None or start is None or geom is None:
        return None
    s, notch = shape
    i, j = start
    out = []
    for op in ops:
        if op == "NOP":
            pass
        elif op in DELTA:
            di, dj = DELTA[op]
            i, j = i + di, j + dj
        elif op == "GROW":
            s *= 2
        elif op == "SHRINK":
            if s % 2:
                return out
            s //= 2
        elif op == "ROT":
            notch = ROT_NOTCH[notch]
        else:
            return out
        out.append((i, j, s, notch))
    return out


# 「六排全暗」这个码**不是零位移**——第 383 步把这个读法打掉了。
# 那一步在第 6 关交上去 [全暗, N, N, N, N, N]：件在格 (6,2)、空腔在格 (1,2)、同一列一路无墙，
# 读成零位移则五个 N 照走、当场通关；世界给出的是**帧不变**（顶栏都没动，那一步本来就免费）。
# 所以它要么是终止符（读到它就停，它自己和后面的槽都不执行），要么在第 6 关根本不是个合法码。
# 这里只留四个平移；截断的事归 disc_runs_program 自己声明，因为那是它的解码主张，要挨判。
def translate_cells(g, ops):
    """一串**全是平移**的指令，件左上角依次落在哪些格：[起点, 第一步后, …, 终点]。

    不核墙、不核边界、不核棋盘大小——判这些是概念的事。
    ops 里有一条不是平移，或件/棋盘读不出，返回 None。
    """
    start = piece_cell(g)
    if start is None or board_geom(g) is None:
        return None
    out = [start]
    i, j = start
    for op in ops:
        if op not in DELTA:
            return None
        di, dj = DELTA[op]
        i, j = i + di, j + dj
        out.append((i, j))
    return out


def walk_program(g, ops):
    """件按 ops 逐条在棋盘上走：返回 (终点格, 终点像素格集合)；有一步撞墙或出界就返回 None。

    只管 DELTA 里那四个平移。碰上 GROW/SHRINK/ROT/NOP 这里不定义，返回 None。
    ops 为空时返回起点本身——「一步都不走」和「走不通」是两回事。

    **「撞墙」按件盖住的每一格算，不是只按左上角那一格。** 原先只核左上角：对 1 倍件没差别，
    对 2 倍件是错的，而第 3 关的件正是 2 倍。改这里的由来见 piece_footprint_blocks。
    """
    start, shape = piece_cell(g), piece_shape(board_piece(g) or set())
    walls = board_walls(g)
    geom = board_geom(g)
    if start is None or shape is None or walls is None or geom is None:
        return None
    t, l, nr, nc = geom
    s, notch = shape
    i, j = start
    for op in ops:
        if op not in DELTA:
            return None
        di, dj = DELTA[op]
        i, j = i + di, j + dj
        for a, b in piece_footprint(i, j, s):
            if not (0 <= a < nr and 0 <= b < nc) or (a, b) in walls:
                return None
    return ((i, j), piece_at(t + i * CELL, l + j * CELL, s, notch))


def walk_program_skip(g, ops):
    """同 walk_program，但**走不通的那一条指令跳过、后面的照走**：返回 (终点格, 终点像素格集合)。

    读不出棋盘/件、或碰上 GROW/SHRINK/ROT/NOP 时仍返回 None——那是「算不出」，不是「走不通」。
    ops 为空返回起点本身。

    两种读法（撞墙整串作废 / 撞墙那一步跳过）的由来见 disc_runs_program v12：
    「整串作废」被一道撞了墙却当场通关的程序判死，剩下这一种。
    """
    start, shape = piece_cell(g), piece_shape(board_piece(g) or set())
    walls = board_walls(g)
    geom = board_geom(g)
    if start is None or shape is None or walls is None or geom is None:
        return None
    t, l, nr, nc = geom
    s, notch = shape
    path = walk_path_skip(g, ops)
    if path is None:
        return None
    i, j = path[-1]
    return ((i, j), piece_at(t + i * CELL, l + j * CELL, s, notch))


def walk_path_skip(g, ops):
    """跳过读法**走过的格**：[起点, 第一步真走到的格, …]；走不通的那一条不进这张表。

    读不出棋盘/件、或碰上 GROW/SHRINK/ROT/NOP 时返回 None（算不出）。ops 为空返回 [起点]。
    路径和终点分开取，是因为「中途踩到什么」和「停在哪」是两件事（见 mark_on_path_voids）。
    """
    start, shape = piece_cell(g), piece_shape(board_piece(g) or set())
    walls = board_walls(g)
    geom = board_geom(g)
    if start is None or shape is None or walls is None or geom is None:
        return None
    _, _, nr, nc = geom
    s = shape[0]
    i, j = start
    path = [start]
    for op in ops:
        if op not in DELTA:
            return None
        di, dj = DELTA[op]
        ni, nj = i + di, j + dj
        if all(0 <= a < nr and 0 <= b < nc and (a, b) not in walls
               for a, b in piece_footprint(ni, nj, s)):
            i, j = ni, nj                       # 走得通才挪；走不通就跳过这一条
            path.append((i, j))
    return path


def panel_ops(g, cols=RPANEL_COLS):
    """右面板那串码解成指令名；有空槽或有认不出的码返回 None。"""
    prog = panel_program(g, cols)
    if prog is None:
        return None
    ops = []
    for slot in prog:
        if not slot:
            return None
        op = BY_CODE.get(slot)
        if op is None:
            return None
        ops.append(op)
    return ops




