"""第 1 关发 RESET：顶栏补回满 61 格，右下面板 24 个件全部点亮，左半边退回开局那一套（图形在第三个位置、高亮在左框），别处一格不动。"""
LEVEL = "L5"
SCOPE = "只看第 1 关内的 RESET（level_prev == level_next == 1）；ACTION6 与别的关一律 NA"
NOTE = "v1。第 191 步之后那次 RESET 一共动了 217 格：顶栏 41 + 右面板 24×3 + 图形 28 + 对照面板 12 + 两个框边框 64。"
EVIDENCE = ["3eaa5a0d549a0285"]

from _lib import (COUNTER_COLS, COUNTER_FULL, COUNTER_ROW, L1_RIGHT_COLS, ON,
                  diff_cells, in_level, l1_config_changes, l1_piece_cells)


def _target(prev, action, ctx):
    if not in_level(ctx, 1) or action != "RESET":
        return None
    want = l1_config_changes(prev, "init")
    for gi in range(3):
        for kind in ("bar", "stem"):
            for k in range(len(L1_RIGHT_COLS)):
                for rc in l1_piece_cells(kind, gi, k, L1_RIGHT_COLS):
                    if prev[rc[0]][rc[1]] != ON:
                        want[rc] = ON
    return want


def assert_(prev, action, nxt, ctx=None):
    want = _target(prev, action, ctx)
    if want is None:
        return "NA"
    if diff_cells(prev, nxt) != want:
        return "FALSE"
    row = [nxt[COUNTER_ROW][c] for c in COUNTER_COLS]
    return "TRUE" if all(v == COUNTER_FULL for v in row) else "FALSE"


def apply(prev, action, ctx=None):
    want = _target(prev, action, ctx)
    if want is None:
        return None
    out = dict(want)
    for c in COUNTER_COLS:
        out[(COUNTER_ROW, c)] = COUNTER_FULL
    return out
