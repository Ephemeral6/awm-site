"""一次真的让关卡前进的按键，把顶栏那 61 格全部刷回未消耗色。"""
LEVEL = "L4"
SCOPE = ("只断言第 1 行列 1..61 这 61 格；只看上游报的关卡真的变了的那一步（ctx.level_next != level_prev）；"
         "**那一步同时把整局打完时（ctx.state_next 不是 NOT_FINISHED）返回 NA**——没有下一关可画；"
         "别的一律 NA。押注与终局卡的 ctx 里 level_next 被置成 level_prev，所以那副口径下它永远 NA，也不出预测")
NOTE = ("v3 的由来是第 166 步（194f3bd8748f5ac1）：最后一关过掉那一下，关卡确实前进了（7/7），"
        "顶栏却没有刷回满格——它照常扣掉一格（(23,1) 9→3），整帧只动了 55 格，没有整屏重画。"
        "所以 v2 那句「一次真的让关卡前进的按键」漏了一种：**通关和换关不是一回事**。"
        "换关要画新一关，所以刷满；通关之后没有新一关，世界只把这一下的代价记完就停。"
        "v3 把终局那一下缩出去（state_next != NOT_FINISHED 返回 NA），不再声称管它。"
        "教训：凡是按「关卡变了」取的口径，都要单独想一遍最后一关——它是唯一一次关卡变了而后面没有关卡的。\n"
        "v2 的由来是第 333 步（6975a93f19d9016b）：v1 的前提是「submit_fits 为真 = 这一下会过关」，"
        "而那一步 submit_fits 为真、关卡却没动，顶栏不但没刷回满格，还照常扣掉一格——v1 逐格押错 6 格。"
        "根子在 disc_fit_clears_level v5 那条：填满空腔只是过关的必要条件，从像素**预测不出**会不会过关。"
        "所以 v2 退回到只用 ctx 判、并且**不再出 apply**：预测口径下闭嘴，不押就不会押错。"
        "代价是换关那一帧顶栏这 61 格重新变成没人管的残差（E 掉 183 格）——这是诚实的代价："
        "上一版那 183 格是靠一个错的前提押中的。"
        "什么时候能拿回来：等「什么算赢」那一槽被重新填上，能从像素判定「这一下会过关」，"
        "再把前提换成那条概念，apply 才有资格回来。")
EVIDENCE = ["a104ec10d06cca18", "89da7ba9203580e5", "6975a93f19d9016b",
            "194f3bd8748f5ac1"]                  # 第 166 步：通关那一下关卡变了却不刷满

from _lib import COUNTER_COLS, COUNTER_FULL, COUNTER_ROW


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_next") == ctx.get("level_prev"):
        return "NA"
    if ctx.get("state_next") not in (None, "NOT_FINISHED"):
        return "NA"                              # 通关那一下：没有下一关可画（v3）
    return "TRUE" if all(nxt[COUNTER_ROW][c] == COUNTER_FULL for c in COUNTER_COLS) else "FALSE"
