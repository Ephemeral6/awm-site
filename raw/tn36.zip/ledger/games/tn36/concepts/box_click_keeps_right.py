"""点底栏任何一个框，右半边的上部——棋盘与右侧那块可点面板，行 3..50 × 列 32..61——一格不变；框只管左半边。"""
LEVEL = "L2"
SCOPE = "只看关卡不变、底栏量得出框、落点落在某个框里的 ACTION6；别的一律 NA。底栏那几行（框自己的边框会变）不在主张范围内"
NOTE = ("v1。第 1 关那条 l1_toolbox_snap 里「右半边一格不动」是和「左半边换成这一套定装」捆在一起说的，"
        "而左半边那张定装表是第 1 关专属的，到第 2、3 关就作废，于是右半边这一半也跟着哑了。"
        "把它单拆出来：这一半不依赖任何一关的配置表，只依赖「框是左半边的开关」这一条，"
        "第 1、2 关的 6 次点框全都成立。它认领 1440 格，是第 3 关棋盘上目前唯一的报警器。")
EVIDENCE = ["777d1b3a5969bff1", "59d0e89a738f8214", "684d74a6341403e5",
            "af27da5a917c91af", "49f7a0e930a7fb3c", "6ed4562d07a6e4f5"]

from _lib import box_at, click_rc, tool_boxes

ROWS = range(3, 51)
COLS = range(32, 62)


def _mine(prev, action, ctx):
    if not ctx or ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None or not tool_boxes(prev):
        return False
    return box_at(prev, *rc) is not None


def assert_(prev, action, nxt, ctx=None):
    if not _mine(prev, action, ctx):
        return "NA"
    for r in ROWS:
        for c in COLS:
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _mine(prev, action, ctx):
        return None
    return {(r, c): prev[r][c] for r in ROWS for c in COLS}
