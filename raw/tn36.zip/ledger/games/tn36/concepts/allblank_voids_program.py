"""工具栏只有四个框、四个图标各指一个方向的关卡里，右面板只要有一槽不是那四个平移码之一（整列全暗、或整列全亮的空槽），按大圆交卷整道程序作废：除顶栏外整帧一格不动。"""
LEVEL = "L1"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6；要求底栏恰好四个框且每个框里都有一块偏离框心的色 11 图标"
         "（出现「框里没有块」的框——即带放大/缩小/旋转那类图标的关卡——返回 NA，那种关卡里这些码另有说法）；"
         "要求右面板读得出来、且至少有一槽不是认得出的平移码；"
         "面板/底栏读不出、换关（ctx.level_prev != ctx.level_next）返回 NA")
NOTE = ("v3：**主张一个字没改**，只把「底栏是不是四个方向框」那段读法搬进本局词汇 `_lib.four_dir_boxes`，"
        "因为 even_slots_keep_parity 要划同一条界。两条概念各抄一份同样的十行，等于同一个可能读错的判据"
        "在册子里有两个不受审的副本；搬进词汇表之后，每批结算的词汇表审计会点名它。\n"
        "v2：把主张从「整列全暗」放宽到「任何一槽不是平移码」，因为第 399 步（06cf60a7afdbc035）把空槽也收进来了——"
        "[N,N,N,N,N,空槽] 交上去**整帧逐格相同**，连顶栏都没掉（那一步恰好是本关的免费步）。"
        "于是四框关卡里已知的两种非平移槽（全暗、全亮）给出同一个结果，合成一条。"
        "v1 的两条依据照旧：第 383 步 [全暗,N,N,N,N,N]、第 392 步 [N,N,N,N,N,全暗]，两次都帧不变（只掉顶栏一格）。"
        "把全暗读成零位移、读成终止符，都被这两个位置的对照打掉了。三次的点灯共 30 下逐格预测全中，"
        "所以面板上确实是那些码，不是点错了。"
        "**故意划出去的边界**：不管第 4 关。那一关底栏有五个框，第五个框里没有块，而它的码正是整列全暗；"
        "第 321 步把它排在最后一槽交上去当场过关——那一关里这个码显然不作废程序。"
        "两关的差别写进 scope 用底栏量（四个框 vs 五个框、有没有「没有块」的框），不用关卡号，"
        "这样终局卡上换了关号也照样判得动。"
        "**这一条能被什么打掉**：在四框关卡里交一道带非平移槽的程序而件动了、或关卡过了。"
        "**它顺带说死了一件事**：四框关卡的程序长度就是槽数，六个槽必须凑出六条平移——"
        "第 6 关件在 (6,2)、空腔在 (1,2)，曼哈顿距离 5 是奇数，六次单格平移的净位移必然是偶数，"
        "所以在这条概念成立的前提下，第 6 关**用这四个框的码无解**。这是下一步要撞的地方。")
EVIDENCE = ["671cca9e90739858", "b0e0d6d5e6cb2384", "06cf60a7afdbc035"]

from _lib import (DELTA, RPANEL_COLS, BY_CODE, click_rc,
                  four_dir_boxes, frozen_frame, on_disc, panel_program)


def _in_scope(prev, action, ctx):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return False
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return False
    if not four_dir_boxes(prev):
        return False
    prog = panel_program(prev, RPANEL_COLS)
    if not prog:
        return False
    if all(slot and BY_CODE.get(slot) in DELTA for slot in prog):
        return False                          # 六槽全是平移码：那一片归 disc_runs_program
    return True


def apply(prev, action, ctx=None):
    if not _in_scope(prev, action, ctx):
        return None
    return frozen_frame(prev)                 # 除顶栏外，每一格都照抄——才拦得住「其实动了」


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    return "FALSE" if any(nxt[r][c] != v for (r, c), v in want.items()) else "TRUE"
