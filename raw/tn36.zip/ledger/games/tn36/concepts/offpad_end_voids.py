"""按大圆交卷、六槽全是平移的程序，只要按「走不通的那一条跳过」算出来的终点格既不是花格也不是插座空腔，件就一格不挪、除顶栏外整帧不动。"""
LEVEL = "L2"
SCOPE = ("只看落点在大圆包围盒里的 ACTION6，且右面板六槽全满、每一槽都是平移、棋盘与件读得出；"
         "终点是花格（board_pads）或恰好是空腔（socket_cavity）返回 NA——那两片分别归 disc_runs_program 与 disc_fit_clears_level；"
         "带色 14 记号的盘上、程序里同一条指令连续四次及以上时返回 NA——那一片归 four_in_a_row_voids（v3）；棋盘、件读不出返回 NA；"
         "换关（ctx.level_prev != ctx.level_next）返回 NA")
NOTE = ("v4：撞墙 / 出界的那一族收进来了。v1-v3 把它们让给 disc_runs_program 的「整串作废」，"
        "而那条主张在第 166 步（194f3bd8748f5ac1）被打死（撞了墙的程序照走、还入位通关），"
        "剩下的唯一读法是「走不通的那一条跳过、其余照走」。按这个读法重算，"
        "第 333 步终点 (6,1)、第 110 步终点 (1,6)、第 134 步终点 (2,5) 都是普通格——"
        "它们不动的理由和第 5 关那道分辨实验是同一条，本来就该归这里。"
        "所以这一版把 walk_program 换成 walk_program_skip，并且不再把撞墙的程序缩出去。"
        "代价要说明白：这三道现在成了这一条的解释对象，而它们**也是**当初撑「整串作废」的依据——"
        "两条规则抢同一批证据时，留下的该是能同时对上全部 28 道全平移交卷的那一条。\n"
        "v3：让出去的那一片改按 four_in_a_row_voids 划界（marked_row_seals 被第 149 步打死，见那一条的撤册理由）。"
        "第 6 关 402/406 两道又能收回来了吗？不能——它们连四以上，仍归那一条；依据不变。\n"
        "v2：把「路径踩记号行」那一片让给 marked_row_seals，与 disc_runs_program v9 划同一条界。"
        "v1 顺手把第 6 关 402/406/409/462 都收进来解释，其实那四道里 402/406/462 路径全踩了行 3，"
        "两条理由同时成立，分不出是哪条在起作用；只有 409（E E N N S S，终点 (5,3)，全程行 4-6）"
        "是干净的「终点普通格」证据。所以依据只留 5 关那道分辨实验和 409，另三道让出去。"
        "这不是被打了改的，是主动把两条概念的边界划开，免得同一步两条都开口、S 各拿一分却谁也没被单独检验过。\n"
        "v1：从一道分辨实验逼出来的。第 5 关件在 (6,0)，交 E E E E N S：六步一格墙不碰、不出界，终点 (6,4) 是块普通底色格，"
        "disc_runs_program 押件挪到 (6,4)，世界给的是除顶栏外整帧一格不动（错 28 格 = 起点 14 + 终点 14）。"
        "同一关、同一起点、只差最后一槽的 E E E E N N（终点 (4,4) 是花格）件照走。两道程序只差终点落不落在花格上。"
        "回头看第 6 关五道「走得通却一格不动」的程序：402→(2,2)、406→(3,3)、409→(5,3)、462→(5,1) 终点全是普通格，"
        "这一条一并解释；**458→(2,0) 是花格却也没动**，这一条对它返回 NA，不解释——它是留给 disc_runs_program 的反例，"
        "也是花格之外还差一块的证据（花格有没有先后次序？行 3 那对括号是不是必经？）。"
        "所以「第 6 关的盘冻住了」（odd_board_freezes_disc）多半是错把「没交过合格的程序」读成了「盘不接程序」；"
        "它现在还没被打，要等第 6 关一道终点落在花格上的程序挪动了件。")
EVIDENCE = ["7043f3c132d3bbfd",                  # 第 5 关 E E E E N S 终点普通格，整帧不动
            "799a37ea3ce717f7",                  # 第 6 关 409：E E N N S S 终点 (5,3) 普通格、不踩记号行，整帧不动
            "6975a93f19d9016b",                  # v4 收进来的撞墙族：跳过读法终点 (6,1) 普通格
            "de6d4ee86a1f8b8e",                  # 同上：跳过读法终点 (1,6) 普通格
            "f08fec6a1da05637"]                  # 同上：跳过读法终点 (2,5) 普通格

from _lib import (DELTA, board_geom, board_pads, board_piece, click_rc, frozen_frame,
                  marked_cells, max_run, on_disc, panel_ops, piece_cell, socket_cavity,
                  walk_program_skip)

RUN_LIMIT = 4                                 # 与 four_in_a_row_voids 同一个数


def _setup(prev, action, ctx):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    rc = click_rc(action)
    if rc is None or not on_disc(prev, *rc):
        return None
    ops = panel_ops(prev)
    if not ops or any(op not in DELTA for op in ops):
        return None
    if board_geom(prev) is None or board_piece(prev) is None or piece_cell(prev) is None:
        return None
    if marked_cells(prev) and max_run(ops) >= RUN_LIMIT:
        return None                          # 带记号的盘上连四：归 four_in_a_row_voids（v3）
    walked = walk_program_skip(prev, ops)
    if walked is None:
        return None
    (di, dj), new_px = walked
    pads = board_pads(prev)
    if pads is None or (di, dj) in pads:
        return None
    cav = socket_cavity(prev)
    if cav is not None and set(new_px) == set(cav):
        return None
    return (di, dj)


def apply(prev, action, ctx=None):
    if _setup(prev, action, ctx) is None:
        return None
    return frozen_frame(prev)


def assert_(prev, action, nxt, ctx=None):
    want = apply(prev, action, ctx)
    if want is None:
        return "NA"
    if any(nxt[r][c] != v for (r, c), v in want.items()):
        return "FALSE"
    return "TRUE" if piece_cell(nxt) == piece_cell(prev) else "FALSE"
