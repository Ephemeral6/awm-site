"""点在右半边可点面板某个件的命中盒里，只有那个件的 3 格在色 1 与色 5 之间翻一下，别处（除顶栏）一格不动。"""
LEVEL = "L1"
SCOPE = "只看关卡不变、面板量得出布局、落点在 panel_slot_at 命中盒里的 ACTION6；别的一律 NA"
NOTE = ("v1，接替 l1_panel_toggles。改的不是主张而是读法：第 2 关面板从 3 组 × 4 槽变成 3 组 × 6 槽，"
        "写死的槽位表当场失效，所以槽位改成每帧从帧上现量（panel_layout）。命中盒仍按「横条行 ±1、"
        "竖杆那三行、槽中心列 ±2」划，比画出来的件大一圈。")
EVIDENCE = ["e8729f58c23c6158", "13cae5cab3f70e3e", "2f6ef2022f59271f",
            "ae70e6692f461245", "ea46ffae932091f0", "0dd4ccd683e1ce83"]

from _lib import (OFF, ON, RPANEL_COLS, click_rc, diff_cells, panel_layout,
                  panel_slot_at, piece_cells)


def _target(prev, action, ctx):
    if not ctx or ctx.get("level_prev") != ctx.get("level_next"):
        return None
    rc = click_rc(action)
    if rc is None:
        return None
    lay = panel_layout(prev, RPANEL_COLS)
    if lay is None:
        return None
    hit = panel_slot_at(lay, *rc)
    if hit is None:
        return None
    cells = piece_cells(lay, *hit)
    now = {prev[r][c] for r, c in cells}
    if now == {ON}:
        return {rc2: OFF for rc2 in cells}
    if now == {OFF}:
        return {rc2: ON for rc2 in cells}
    return None                      # 这个件不是整齐的一种颜色：读法不适用，闭嘴


def assert_(prev, action, nxt, ctx=None):
    want = _target(prev, action, ctx)
    if want is None:
        return "NA"
    return "TRUE" if diff_cells(prev, nxt) == want else "FALSE"


def apply(prev, action, ctx=None):
    return _target(prev, action, ctx)
