/-
# 推论：过关的只有「点中大圆且 isGoal」这一种

`fit_clears_level` 在 Python 那边是一个等价（填满 ⇒ 过关，过关 ⇒ 填满）。在模型里正方向是 `isGoal` 的**定义**
加 `step` 的分发；反方向不用再写一遍——它从 `step` 的定义**推得出来**，这里就是那条推论。
它不是「每条规则一条定理」那种同义反复：`step` 里还有 RESET、见底、点面板三支，这条定理说它们没有一支会给出赢。
-/
import Obj.Frame.World
import Step

-- 定理用全名写在命名空间外：装置的公理表探针（ledger/lean_check）按定理的短名打 `#print axioms`，
-- 写在 namespace 里面它会找不到（见 UNIFY-REPORT「装置事故」）。

theorem Game.won_only_by_goal (L : Layout) (w : World) (a : Act) (h : step L w a = Res.won) :
    isGoal L w = true := by
  cases a with
  | reset => simp [step] at h
  | click x y =>
    simp only [step] at h
    split at h
    · cases h
    · split at h
      · split at h
        · assumption
        · cases h
      · cases h

#print axioms Game.won_only_by_goal
