/-
# 推论：一关之内顶栏只减不增

从 `counter_pays` 的定义（`upkeep`）加 `step` 的分发推出来：`step` 给出的每一个新 World，顶栏都不比原来多。
`Proof/Levels.lean` 的导出器对现实那一侧做同一件事的交叉检查（一关之内顶栏一涨就停下）；
这一条是模型那一侧的同一句话——两边各说一遍，一边是观测、一边是定理。
-/
import Obj.Frame.World
import Step

-- 定理用全名写在命名空间外（装置的公理表探针按定理名原样打 `#print axioms`）。

theorem Game.counter_never_rises (L : Layout) (w w' : World) (a : Act) (h : step L w a = Res.ok w') :
    w'.counter ≤ w.counter := by
  cases a with
  | reset => simp [step] at h
  | click x y =>
    simp only [step] at h
    split at h
    · cases h
    · split at h
      · split at h
        · cases h
        · cases h
          exact Nat.sub_le _ _
      · cases h
        exact Nat.sub_le _ _

#print axioms Game.counter_never_rises
