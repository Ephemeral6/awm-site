/-
# Step —— 一步怎么走：**只做分发，0 条定理。**

    RESET                 说不出话（na）——见 Rule/Unmodeled/ResetRestarts.lean
    顶栏已见底            说不出话（na）——本批语料从没见底（最少还剩 23 格）
    点中大圆且 isGoal     赢了（won）
    其余点击              顶栏按节奏掉格（upkeep），面板按 panelAfter、件按 pieceAfter

**「不经过 na 那两支」这半句**：`Winnable` / `Unsolvable` 都只对不经过 RESET、顶栏没见底的走法成立。
-/
import Rule.Move.PanelFollowsClicks
import Rule.Move.PieceFollowsProgram
import Rule.Response.CounterPays
import Rule.Win.FitClearsLevel
import Obj.Compose.Click

namespace Game

inductive Act
  | click (x y : Nat)
  | reset
deriving DecidableEq, Repr

inductive Res
  | ok (w : World)
  | won
  | na
deriving DecidableEq, Repr

def step (L : Layout) (w : World) : Act → Res
  | .reset       => .na
  | .click x y   =>
      if w.counter = 0 then .na
      else
        match target L x y with
        | some .disc =>
            if isGoal L w then .won
            else .ok { upkeep L w with piece := pieceAfter L w (some .disc) }
        | t => .ok { upkeep L w with panel := panelAfter w t, piece := pieceAfter L w t }

end Game
