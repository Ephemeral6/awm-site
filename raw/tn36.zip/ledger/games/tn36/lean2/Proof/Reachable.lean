/-
# Reachable —— 这个**局面**做不做得了。

    Winnable   L w  :=  ∃ as, 沿 step 走 as，中途赢过
    Unsolvable L w  :=  ∀ as, 沿 step 走 as，从没赢过

**「不经过 na 那两支」这半句写在明处**：`everWon` 碰上 na（RESET、顶栏见底）就停，所以
`Unsolvable` 的准确意思是「**不经过 RESET、顶栏不见底**的走法都赢不了」；`Winnable` 的见证也是这样一条走法。

这一局 7 关在语料里全部走通了（`Proof/Levels.lean` 每关一条 `_winnable`），所以这一份里**没有要证的「走不通」**。
骨架照样证一次放在这里：它和盘面多大无关、不枚举任何状态；要宣告哪一关走不通，得在这里挂一把钥匙
（一个每步保持、又和赢矛盾的不变量）——没挂钥匙就不许写「走不通」。
-/
import Obj.Frame.World
import Obs.Check

namespace Game

def Winnable (L : Layout) (w : World) : Prop := ∃ as : List Act, everWon (step L) w as = true

def Unsolvable (L : Layout) (w : World) : Prop := ∀ as : List Act, everWon (step L) w as = false

end Game

-- 定理用全名写在命名空间外（装置的公理表探针按定理名原样打 `#print axioms`）。

/-- 两句话不能同时成立。 -/
theorem Game.not_both (L : Layout) (w : World) :
    (∃ as : List Act, everWon (step L) w as = true) →
    (∀ as : List Act, everWon (step L) w as = false) → False := by
  intro ⟨as, h⟩ h2
  rw [h2 as] at h
  exact Bool.false_ne_true h

/-- **骨架：不变量 ⇒ 不可做。** 全文唯一做归纳的地方；与盘面大小、动作串长短无关，不枚举任何状态。 -/
theorem Game.unsolvable_of_invariant (L : Layout) (P : World → Prop)
    (hkeep : ∀ w w' a, P w → step L w a = Res.ok w' → P w')
    (hwin : ∀ w a, P w → step L w a ≠ Res.won) :
    ∀ w, P w → ∀ as : List Act, everWon (step L) w as = false := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hs : step L w a with
    | won => exact absurd hs (hwin w a hp)
    | na => rfl
    | ok w' => exact ih w' (hkeep w w' a hp hs)

#print axioms Game.not_both
#print axioms Game.unsolvable_of_invariant
