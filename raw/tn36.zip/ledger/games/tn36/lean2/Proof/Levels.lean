/-
# Levels —— 每一关一条定理（**自动生成：lean2/export_levels.py，不要手改**）

    L<n>_trace      两半：那一段到底有几步（空表会让 traceOk 平凡为真，前一半钉住它）
                    + 沿着认证那一段真实走法，模型**每一帧**都和观测对上（只有开局那一帧是观测给的）
    L<n>_winnable   这一关走得通：见证就是认证那一段的全部动作（最后一下是过关的交卷）
    S0_L<n>_trace   同一件事，换成**不被成绩单认证**的那一段（seq 1..166）——只多核一遍，不当见证

**一条明写的假设**：每一关开局 `phase = false`（本关第一下免费）。它帧上读不出来；
节奏 2 的第 5、6 关里，要是它错了，第二步的顶栏就对不上——这是它在这批语料上唯一一次被驳倒的机会。
**没红不构成证明。**

版面用**整关取并集**那一口径（`Replay.levelLayout`）。
-/
import Obj.Frame.World
import Obs.Replay
import Proof.Reachable

set_option maxRecDepth 100000

namespace Game
namespace Levels

/-- 第 0 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 1 那一行的前一帧；路 6 步（seq 1..6）。 -/
def S0_L0_start : World := Replay.startAt 1
def S0_L0_play : List (Act × Seen) := Replay.playFrom 1 6

#eval match firstSplit (step (Replay.levelLayout 0)) S0_L0_start S0_L0_play 0 with
  | none   => "S0_L0  一处都没分家（共 " ++ toString S0_L0_play.length ++ " 步）"
  | some i => "S0_L0  第 " ++ toString i ++ " 步分家"

/-- 第 1 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 8 那一行的前一帧；路 8 步（seq 8..15）。 -/
def S0_L1_start : World := Replay.startAt 8
def S0_L1_play : List (Act × Seen) := Replay.playFrom 8 8

#eval match firstSplit (step (Replay.levelLayout 1)) S0_L1_start S0_L1_play 0 with
  | none   => "S0_L1  一处都没分家（共 " ++ toString S0_L1_play.length ++ " 步）"
  | some i => "S0_L1  第 " ++ toString i ++ " 步分家"

/-- 第 2 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 17 那一行的前一帧；路 8 步（seq 17..24）。 -/
def S0_L2_start : World := Replay.startAt 17
def S0_L2_play : List (Act × Seen) := Replay.playFrom 17 8

#eval match firstSplit (step (Replay.levelLayout 2)) S0_L2_start S0_L2_play 0 with
  | none   => "S0_L2  一处都没分家（共 " ++ toString S0_L2_play.length ++ " 步）"
  | some i => "S0_L2  第 " ++ toString i ++ " 步分家"

/-- 第 3 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 26 那一行的前一帧；路 21 步（seq 26..46）。 -/
def S0_L3_start : World := Replay.startAt 26
def S0_L3_play : List (Act × Seen) := Replay.playFrom 26 21

#eval match firstSplit (step (Replay.levelLayout 3)) S0_L3_start S0_L3_play 0 with
  | none   => "S0_L3  一处都没分家（共 " ++ toString S0_L3_play.length ++ " 步）"
  | some i => "S0_L3  第 " ++ toString i ++ " 步分家"

/-- 第 4 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 48 那一行的前一帧；路 15 步（seq 48..62）。 -/
def S0_L4_start : World := Replay.startAt 48
def S0_L4_play : List (Act × Seen) := Replay.playFrom 48 15

#eval match firstSplit (step (Replay.levelLayout 4)) S0_L4_start S0_L4_play 0 with
  | none   => "S0_L4  一处都没分家（共 " ++ toString S0_L4_play.length ++ " 步）"
  | some i => "S0_L4  第 " ++ toString i ++ " 步分家"

/-- 第 5 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 64 那一行的前一帧；路 24 步（seq 64..87）。 -/
def S0_L5_start : World := Replay.startAt 64
def S0_L5_play : List (Act × Seen) := Replay.playFrom 64 24

#eval match firstSplit (step (Replay.levelLayout 5)) S0_L5_start S0_L5_play 0 with
  | none   => "S0_L5  一处都没分家（共 " ++ toString S0_L5_play.length ++ " 步）"
  | some i => "S0_L5  第 " ++ toString i ++ " 步分家"

/-- 第 6 关（成绩单不认证的那一段，只多核一遍）：开局取 seq 89 那一行的前一帧；路 77 步（seq 89..165）。 -/
def S0_L6_start : World := Replay.startAt 89
def S0_L6_play : List (Act × Seen) := Replay.playFrom 89 77

#eval match firstSplit (step (Replay.levelLayout 6)) S0_L6_start S0_L6_play 0 with
  | none   => "S0_L6  一处都没分家（共 " ++ toString S0_L6_play.length ++ " 步）"
  | some i => "S0_L6  第 " ++ toString i ++ " 步分家"

/-- 第 0 关（成绩单认证的那一段）：开局取 seq 168 那一行的前一帧；路 6 步（seq 168..173）。 -/
def L0_start : World := Replay.startAt 168
def L0_play : List (Act × Seen) := Replay.playFrom 168 6

#eval match firstSplit (step (Replay.levelLayout 0)) L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- 第 0 关的动作串：路上那 6 步，再加过关那一下（seq 174）。 -/
def L0_acts : List Act := Replay.actsFrom 168 7

/-- 第 1 关（成绩单认证的那一段）：开局取 seq 175 那一行的前一帧；路 8 步（seq 175..182）。 -/
def L1_start : World := Replay.startAt 175
def L1_play : List (Act × Seen) := Replay.playFrom 175 8

#eval match firstSplit (step (Replay.levelLayout 1)) L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- 第 1 关的动作串：路上那 8 步，再加过关那一下（seq 183）。 -/
def L1_acts : List Act := Replay.actsFrom 175 9

/-- 第 2 关（成绩单认证的那一段）：开局取 seq 184 那一行的前一帧；路 8 步（seq 184..191）。 -/
def L2_start : World := Replay.startAt 184
def L2_play : List (Act × Seen) := Replay.playFrom 184 8

#eval match firstSplit (step (Replay.levelLayout 2)) L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- 第 2 关的动作串：路上那 8 步，再加过关那一下（seq 192）。 -/
def L2_acts : List Act := Replay.actsFrom 184 9

/-- 第 3 关（成绩单认证的那一段）：开局取 seq 193 那一行的前一帧；路 12 步（seq 193..204）。 -/
def L3_start : World := Replay.startAt 193
def L3_play : List (Act × Seen) := Replay.playFrom 193 12

#eval match firstSplit (step (Replay.levelLayout 3)) L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- 第 3 关的动作串：路上那 12 步，再加过关那一下（seq 205）。 -/
def L3_acts : List Act := Replay.actsFrom 193 13

/-- 第 4 关（成绩单认证的那一段）：开局取 seq 206 那一行的前一帧；路 15 步（seq 206..220）。 -/
def L4_start : World := Replay.startAt 206
def L4_play : List (Act × Seen) := Replay.playFrom 206 15

#eval match firstSplit (step (Replay.levelLayout 4)) L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- 第 4 关的动作串：路上那 15 步，再加过关那一下（seq 221）。 -/
def L4_acts : List Act := Replay.actsFrom 206 16

/-- 第 5 关（成绩单认证的那一段）：开局取 seq 222 那一行的前一帧；路 19 步（seq 222..240）。 -/
def L5_start : World := Replay.startAt 222
def L5_play : List (Act × Seen) := Replay.playFrom 222 19

#eval match firstSplit (step (Replay.levelLayout 5)) L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- 第 5 关的动作串：路上那 19 步，再加过关那一下（seq 241）。 -/
def L5_acts : List Act := Replay.actsFrom 222 20

/-- 第 6 关（成绩单认证的那一段）：开局取 seq 242 那一行的前一帧；路 50 步（seq 242..291）。 -/
def L6_start : World := Replay.startAt 242
def L6_play : List (Act × Seen) := Replay.playFrom 242 50

#eval match firstSplit (step (Replay.levelLayout 6)) L6_start L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- 第 6 关的动作串：路上那 50 步，再加过关那一下（seq 292）。 -/
def L6_acts : List Act := Replay.actsFrom 242 51

end Levels
end Game

/-- 第 0 关（成绩单不认证的那一段，只多核一遍）：这条路一共 6 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L0_trace :
    S0_L0_play.length = 6 ∧
    traceOk (step (Replay.levelLayout 0)) S0_L0_start S0_L0_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L0_trace

/-- 第 1 关（成绩单不认证的那一段，只多核一遍）：这条路一共 8 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L1_trace :
    S0_L1_play.length = 8 ∧
    traceOk (step (Replay.levelLayout 1)) S0_L1_start S0_L1_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L1_trace

/-- 第 2 关（成绩单不认证的那一段，只多核一遍）：这条路一共 8 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L2_trace :
    S0_L2_play.length = 8 ∧
    traceOk (step (Replay.levelLayout 2)) S0_L2_start S0_L2_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L2_trace

/-- 第 3 关（成绩单不认证的那一段，只多核一遍）：这条路一共 21 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L3_trace :
    S0_L3_play.length = 21 ∧
    traceOk (step (Replay.levelLayout 3)) S0_L3_start S0_L3_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L3_trace

/-- 第 4 关（成绩单不认证的那一段，只多核一遍）：这条路一共 15 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L4_trace :
    S0_L4_play.length = 15 ∧
    traceOk (step (Replay.levelLayout 4)) S0_L4_start S0_L4_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L4_trace

/-- 第 5 关（成绩单不认证的那一段，只多核一遍）：这条路一共 24 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L5_trace :
    S0_L5_play.length = 24 ∧
    traceOk (step (Replay.levelLayout 5)) S0_L5_start S0_L5_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L5_trace

/-- 第 6 关（成绩单不认证的那一段，只多核一遍）：这条路一共 77 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.S0_L6_trace :
    S0_L6_play.length = 77 ∧
    traceOk (step (Replay.levelLayout 6)) S0_L6_start S0_L6_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.S0_L6_trace

/-- 第 0 关（成绩单认证的那一段）：这条路一共 6 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L0_trace :
    L0_play.length = 6 ∧
    traceOk (step (Replay.levelLayout 0)) L0_start L0_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L0_trace

/-- **第 0 关走得通。** 见证是成绩单认证那一段的真实走法（7 下，最后一下 seq 174 过关）；不经过 RESET。 -/
theorem Game.Levels.L0_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 0)) L0_start as = true :=
  ⟨L0_acts, by decide⟩

#print axioms Game.Levels.L0_winnable

/-- 第 1 关（成绩单认证的那一段）：这条路一共 8 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L1_trace :
    L1_play.length = 8 ∧
    traceOk (step (Replay.levelLayout 1)) L1_start L1_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L1_trace

/-- **第 1 关走得通。** 见证是成绩单认证那一段的真实走法（9 下，最后一下 seq 183 过关）；不经过 RESET。 -/
theorem Game.Levels.L1_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 1)) L1_start as = true :=
  ⟨L1_acts, by decide⟩

#print axioms Game.Levels.L1_winnable

/-- 第 2 关（成绩单认证的那一段）：这条路一共 8 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L2_trace :
    L2_play.length = 8 ∧
    traceOk (step (Replay.levelLayout 2)) L2_start L2_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L2_trace

/-- **第 2 关走得通。** 见证是成绩单认证那一段的真实走法（9 下，最后一下 seq 192 过关）；不经过 RESET。 -/
theorem Game.Levels.L2_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 2)) L2_start as = true :=
  ⟨L2_acts, by decide⟩

#print axioms Game.Levels.L2_winnable

/-- 第 3 关（成绩单认证的那一段）：这条路一共 12 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L3_trace :
    L3_play.length = 12 ∧
    traceOk (step (Replay.levelLayout 3)) L3_start L3_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L3_trace

/-- **第 3 关走得通。** 见证是成绩单认证那一段的真实走法（13 下，最后一下 seq 205 过关）；不经过 RESET。 -/
theorem Game.Levels.L3_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 3)) L3_start as = true :=
  ⟨L3_acts, by decide⟩

#print axioms Game.Levels.L3_winnable

/-- 第 4 关（成绩单认证的那一段）：这条路一共 15 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L4_trace :
    L4_play.length = 15 ∧
    traceOk (step (Replay.levelLayout 4)) L4_start L4_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L4_trace

/-- **第 4 关走得通。** 见证是成绩单认证那一段的真实走法（16 下，最后一下 seq 221 过关）；不经过 RESET。 -/
theorem Game.Levels.L4_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 4)) L4_start as = true :=
  ⟨L4_acts, by decide⟩

#print axioms Game.Levels.L4_winnable

/-- 第 5 关（成绩单认证的那一段）：这条路一共 19 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L5_trace :
    L5_play.length = 19 ∧
    traceOk (step (Replay.levelLayout 5)) L5_start L5_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L5_trace

/-- **第 5 关走得通。** 见证是成绩单认证那一段的真实走法（20 下，最后一下 seq 241 过关）；不经过 RESET。 -/
theorem Game.Levels.L5_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 5)) L5_start as = true :=
  ⟨L5_acts, by decide⟩

#print axioms Game.Levels.L5_winnable

/-- 第 6 关（成绩单认证的那一段）：这条路一共 50 步——**空表撑不起来**；模型沿着它一步不差。
    只有开局那一帧是观测给的，后面全是 step 自己算的。 -/
theorem Game.Levels.L6_trace :
    L6_play.length = 50 ∧
    traceOk (step (Replay.levelLayout 6)) L6_start L6_play = true :=
  ⟨by decide, by decide⟩

#print axioms Game.Levels.L6_trace

/-- **第 6 关走得通。** 见证是成绩单认证那一段的真实走法（51 下，最后一下 seq 292 过关）；不经过 RESET。 -/
theorem Game.Levels.L6_winnable :
    ∃ as : List Act, everWon (step (Replay.levelLayout 6)) L6_start as = true :=
  ⟨L6_acts, by decide⟩

#print axioms Game.Levels.L6_winnable
