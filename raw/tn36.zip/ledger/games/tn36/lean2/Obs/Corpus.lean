/-
# Corpus —— 模型面对全部真实转移，**逐条**（三条腿的第三条的 ①）。

每一行都从**观测到的那一帧**起算一步，和看到的下一帧比（`agrees`）。
过关那一行只核「模型也说赢了」；RESET 那一行只核「模型也说不出话」——
**「不进路里」和「没人核」是两件事**：它们不进每关那一层的路，但在这里各是一条用例。

读数（`#eval`）只是读数，走求值器；结论是下面那条走内核的定理。
-/
import Obs.Replay

set_option maxRecDepth 100000

namespace Game
namespace Corpus

/-- 一行对不对得上（逐条口径：用这一帧自己读到的版面）。 -/
def rowOk (r : Replay.Row) : Bool :=
  agrees (step (Replay.layoutAt r.lay) (r.prev.getD Replay.dummyWorld) r.act) r.obs

/-- 读数（给 verify.py 和 Python 那一份逐条对账用）：每一行点中了什么、交卷的结果是什么。 -/
def outcomeTag (r : Replay.Row) : String :=
  match r.prev, r.act with
  | some w, .click x y =>
      match target (Replay.layoutAt r.lay) x y with
      | some .disc =>
          match outcome (Replay.layoutAt r.lay) w with
          | .win    => "win"
          | .move _ => "move"
          | .void   => "void"
      | some (.piece _ _ _) => "panel"
      | none => "none"
  | _, _ => "-"

#eval "OUTCOMES " ++ String.intercalate ";" (Replay.rows.map fun r => toString r.seq ++ ":" ++ outcomeTag r)

/-- 读数：对不上的 seq。 -/
def mismatches : List Nat := (Replay.rows.filter (fun r => !rowOk r)).map (·.seq)

#eval "CORPUS rows=" ++ toString Replay.rows.length ++ " mismatches=" ++ toString mismatches.length
  ++ " " ++ toString mismatches

end Corpus
end Game

-- 定理用全名写在命名空间外（装置的公理表探针按定理名原样打 `#print axioms`）。

/-- **模型没被这批语料驳倒**：一共 292 行（不是空表撑起来的），每一行模型从那一帧算一步，都和看到的对上。 -/
theorem Game.Corpus.corpus_agrees :
    Replay.rows.length = 292 ∧
    Replay.rows.all (fun r =>
      agrees (step (Replay.layoutAt r.lay) (r.prev.getD Replay.dummyWorld) r.act) r.obs) = true :=
  ⟨by decide, by decide⟩

/-- 尺子的地板：拿模型自己算出来的那一帧去问它，必判「对上」。 -/
theorem Game.Corpus.judge_self (w : World) : agrees (Res.ok w) (Obs.seen w.seen) = true := by
  simp [agrees]

/-- 尺子**不是恒真**：seq 230（第 5 关交卷、件从 (6,0) 挪到 (4,4)）那一步，要是观测说「件没动」，判据判不对上。 -/
theorem Game.Corpus.judge_can_fail :
    agrees (step (Replay.layoutAt (Replay.rowAt 230).lay) (Replay.startAt 230) (Replay.rowAt 230).act)
      (Obs.seen ⟨(Replay.startAt 230).counter - 1, (Replay.startAt 230).panel, (Replay.startAt 230).piece⟩)
      = false := by
  decide

#print axioms Game.Corpus.corpus_agrees
#print axioms Game.Corpus.judge_self
#print axioms Game.Corpus.judge_can_fail
