/-
# Check —— 判据层：两把尺子，**0 条定理**（尺子不自证，它只是被用）。

    agrees    **一条转移**：从观测到的那一帧算一步，和看到的下一帧比
    traceOk   **一整条路**：只有开局那一帧是观测给的，后面带着模型自己算出来的 World 往下走

`Seen` 只装帧上看得见的东西：顶栏、面板、件。`phase` 不在里面——它帧上读不出来，判据不许依赖它；
版面不在里面——它不是 World 的字段。
-/
import Step

namespace Game

structure Seen where
  counter : Nat
  panel   : Panel
  piece   : Form
deriving DecidableEq, Repr

def World.seen (w : World) : Seen := ⟨w.counter, w.panel, w.piece⟩

/-- 现实那一侧看到了什么。 -/
inductive Obs
  | seen (s : Seen)     -- 下一帧还是同一关、读得成世界
  | won                 -- 上游说关卡前进 / 整局打完
  | reset               -- 这一下是 RESET（下一帧模型不描述）
deriving DecidableEq, Repr

/-- 三值里的「对上」：每一支都要对上一种观测，不许有一支写成「算不出来就算它对」。 -/
def agrees : Res → Obs → Bool
  | .ok w, .seen s => decide (w.seen = s)
  | .won,  .won    => true
  | .na,   .reset  => true
  | _,     _       => false

/-- 从 w 出发沿 play 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算出来的 w'**。 -/
def traceOk (f : World → Act → Res) : World → List (Act × Seen) → Bool
  | _, []             => true
  | w, (a, o) :: rest =>
      match f w a with
      | .ok w' => decide (w'.seen = o) && traceOk f w' rest
      | _      => false

/-- 沿一串动作走，中途有没有赢过。碰上 na（RESET、顶栏见底）就停：**不经过那两支**。 -/
def everWon (f : World → Act → Res) : World → List Act → Bool
  | _, []        => false
  | w, a :: as =>
      match f w a with
      | .won   => true
      | .ok w' => everWon f w' as
      | .na    => false

/-- 只给读数用：第一处分家在第几步（`none` = 一处都没分家）。**读数不是定理**，`#eval` 走的是求值器。 -/
def firstSplit (f : World → Act → Res) : World → List (Act × Seen) → Nat → Option Nat
  | _, [],             _ => none
  | w, (a, o) :: rest, i =>
      match f w a with
      | .ok w' => if w'.seen = o then firstSplit f w' rest (i + 1) else some i
      | _      => some i

end Game
