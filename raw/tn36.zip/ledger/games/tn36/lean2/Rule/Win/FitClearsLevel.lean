/-
# fit_clears_level —— 对应 `rule/什么算赢/fit_clears_level.py`

-- IDENTITY: definition

**这是「赢」的定义**，不是一条要证的定理：`isGoal` 是一个**状态**性质——
面板上写着的这道程序，一交上去算出来的终点就和插槽空腔一模一样。`step` 在点中大圆且 `isGoal` 时给出 `won`。

反方向「过关的只有这一种」是 `Derived/WonOnlyByGoal.lean` 里的一条推论。
-/
import Obj.Compose.Outcome

namespace Game

def isGoal (L : Layout) (w : World) : Bool :=
  match outcome L w with
  | .win => true
  | _    => false

end Game
