/-
# counter_pays —— 对应 `rule/世界怎么回应/counter_pays.py`

-- IDENTITY: definition

**定义**：关内每一下点击，顶栏掉 `pay` 格；`phase` 翻一下。
节奏表 `rateOf` 按关号查（第 5、6 关节奏 2，其余节奏 1）——**语料事实表，帧上读不出**；
这一份是独立写的一张表，和 Python 那张由逐条对账核。
-/
import Obj.Frame.Layout
import Obj.Frame.World

namespace Game

def rateOf : Nat → Nat
  | 5 => 2
  | 6 => 2
  | _ => 1

/-- 这一下掉几格。节奏 1：每下 1 格；节奏 2：本关第奇数个动作（`phase = true`）掉 1 格，偶数个免费。 -/
def pay (lvl : Nat) (phase : Bool) : Nat :=
  if rateOf lvl = 1 then 1 else if phase then 1 else 0

def upkeep (L : Layout) (w : World) : World :=
  { w with counter := w.counter - pay L.level w.phase, phase := !w.phase }

end Game
