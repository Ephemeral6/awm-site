/-
# layout_stays —— 对应 `rule/世界怎么回应/layout_stays.py`

-- IDENTITY: not-in-model
-- WHY: 版面（盘、花格、底栏、命中盒、其余画面）住在 Layout 里，不是 World 的字段；step 的类型是 Layout → World → Act → Res，它拿得到版面却交不出新的版面。「一关之内版面不变」在模型里表示不出来——不用证，也没法作为一条规则写进去。Python 那一侧照常面对语料（论域与被驳倒次数由 verify.py 从 analysis/readings.json 读出来打在明处）。

这一份只有说明，没有定义：它说的那件事在模型里是**类型**保证的，不是某个 `def` 保证的。
-/
import Obj.Frame.Layout

namespace Game
end Game
