/-
# clear_starts_fresh —— 对应 `rule/说了但不进模型/clear_starts_fresh.py`

-- IDENTITY: not-in-model
-- WHY: 它说的是「下一关开局」那一帧（顶栏满、面板全亮）。模型的 step 在过关那一下给出 won、不给下一帧：下一关的版面与件是关卡设计，不是当前 World 的函数，World 表示不出「下一关」。所以不进模型，只在 Python 一侧面对语料。

这一份只有说明。
-/
import Obj.Frame.World

namespace Game
end Game
