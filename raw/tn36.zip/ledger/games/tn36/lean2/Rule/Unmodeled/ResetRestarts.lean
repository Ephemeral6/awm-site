/-
# reset_restarts —— 对应 `rule/说了但不进模型/reset_restarts.py`

-- IDENTITY: not-in-model
-- WHY: 「重来之后是哪一帧」不是当前状态的函数，是历史；本批唯一一次 RESET 的前一帧还是终局画面（读不成世界）。给 World 硬塞一个「开局」字段，就是加一位帧上读不出来的信息。所以 step 对 RESET 给出 na（说不出话），这一条只在 Python 一侧面对语料。

**这一支让「赢不了」的意思变弱**：`Winnable` / `Unsolvable` 说的都是「不经过 RESET」的走法。写在 `Proof/Reachable.lean` 与页面上。
-/
import Obj.Frame.World

namespace Game
end Game
