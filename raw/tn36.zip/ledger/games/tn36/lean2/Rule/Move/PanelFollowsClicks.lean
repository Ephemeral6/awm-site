/-
# panel_follows_clicks —— 对应 `rule/一步怎么走/panel_follows_clicks.py`

-- IDENTITY: definition

**这是一个定义，不是定理**：它就是「点一下之后面板变成什么样」的定义。
点中面板的某个件 → 那一个件翻亮暗；点中大圆或什么都没点中 → 面板不动。
-/
import Obj.Frame.World
import Obj.Screen.Controls

namespace Game

def panelAfter (w : World) : Option Target → Panel
  | some (.piece kd g k) => w.panel.toggle kd g k
  | _                    => w.panel

end Game
