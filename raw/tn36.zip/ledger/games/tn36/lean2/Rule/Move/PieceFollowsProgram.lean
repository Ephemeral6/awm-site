/-
# piece_follows_program —— 对应 `rule/一步怎么走/piece_follows_program.py`

-- IDENTITY: definition

**定义**：点中大圆 → 件照程序走（`outcome` 给出 `move` 时挪过去，否则一格不挪）；没点中大圆 → 件不动。
过关那一下（`outcome = win`）不在这里：那是 `Rule/Win/FitClearsLevel.lean` 的 `isGoal`，由 `step` 分发。
-/
import Obj.Compose.Outcome

namespace Game

def pieceAfter (L : Layout) (w : World) : Option Target → Form
  | some .disc =>
      match outcome L w with
      | .move f => f
      | _       => w.piece
  | _ => w.piece

end Game
