"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源：第 1–103 步，第 0–4 关。
盘面 64x64 分两部分：**盘面**是左上 21x21 个 3x3 的块（块坐标 (br,bc) = (row//CELL, col//CELL)，各取 0..20）；
最后一行是一条静止的装饰带，最后一列是**计数带**（64 格，自顶向下被填掉，空格是色11，填充色随关卡变）。

盘上的角色（颜色是这一局的偶然事实，读法是假设）：
  色5  **真物件**，空心（边框色5）。可以有好几片；被推的就是它们之一。
  色10 **分隔带**，空心，占满一条块行或一条块列 —— 它是镜像轴，而且它自己也能被推。
       **轴可以不止一条**：第4 关是一横一竖两条，交叉却不合并成一件东西，各推各的。
  色4  **镜像**，实心。它不是独立的东西：它是全部色5 在**这组轴生成的反射群**下的像，**只画落在盘内的那部分**
       （第2关轴在下方，镜像落到盘外，所以整关没有色4）。一条轴给一个镜像；一行加一列还多给一个绕交点的点对称。
  色11 实心的**目标**（也是计数带的空格色）。
块的**中心格是色0** 标记「这一组是当前被推的那一组」；ACTION6:x,y 换标记（见 act6_select），不花计数。
"""
from __future__ import annotations

CELL = 3
NB = 21                  # 盘面 21x21 块
BG = 9                   # 底色
MARK = 0                 # 「这一组正被选中」的标记色：块的中心格是它
PIECE = 5                # 真物件
BAND = 10                # 分隔带 = 镜像轴
GHOST = 4                # 镜像
TARGET = 11              # 目标

# **被选中那件东西**的位移，单位是块。
DELTA = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def block(g, br, bc):
    return tuple(tuple(g[br * CELL + i][bc * CELL + j] for j in range(CELL)) for i in range(CELL))


def shape(g, color):
    """颜色 color 占的块集合（只看盘面 21x21 块；最后一行、最后一列不算盘面）。"""
    out = set()
    for br in range(NB):
        for bc in range(NB):
            b = block(g, br, bc)
            if any(v == color for row in b for v in row):
                out.add((br, bc))
    return frozenset(out)


def movers(g):
    """中心格是 MARK 的那些块 —— 当前被 ACTION1-4 推动的那一组。"""
    return frozenset((br, bc) for br in range(NB) for bc in range(NB)
                     if g[br * CELL + CELL // 2][bc * CELL + CELL // 2] == MARK)


def comp(g, color, br, bc):
    """从块 (br,bc) 出发的「一个物件」：同色块**八邻连通**，并且允许跨过目标块。
    由来：分隔带被线上的目标块切成几段，点其中一段，整条带一起被选中一起走——
    目标是画在地板上的记号，东西从它上面过，不算断开。
    **八邻而非四邻**：第 5 关四片散落的色5 对角相连，世界点其中一片把四片一起选中一起推——
    四邻切成 4 件，八邻切成 1 件，只有后者和标记一致（全语料 145 帧验证：四邻 4 帧失败，八邻 0 帧失败；
    不算 2 帧零标记的帧）。
    注意：八邻对分隔带仍不够用——两条交叉的轴对角块也相连，世界却把它们当两件东西。
    所以带按「线」读，不按连通片读，见 band_lines。"""
    s = shape(g, color)
    if (br, bc) not in s:
        return frozenset()
    nodes = s | shape(g, TARGET)
    seen, stack = {(br, bc)}, [(br, bc)]
    while stack:
        r, c = stack.pop()
        for dr, dc in ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)):
            p = (r + dr, c + dc)
            if p in nodes and p not in seen:
                seen.add(p)
                stack.append(p)
    return frozenset(seen & s)


def pieces(g):
    """色5 的各个连通片（每片一个块集合）。"""
    left, out = set(shape(g, PIECE)), []
    while left:
        br, bc = next(iter(left))
        s = comp(g, PIECE, br, bc)
        out.append(s)
        left -= s
    return out


def line_cells(line):
    """一条线占的 21 块（不减目标）。"""
    kind, k = line
    return frozenset((k, bc) for bc in range(NB)) if kind == "row" else frozenset((br, k) for br in range(NB))


def band_lines(g):
    """盘上有哪几条分隔带轴：("row",br) / ("col",bc) 的元组。一条轴 = 一整块行或一整块列，
    线上每一块要么是带，要么被目标让位、被物件或镜像盖住；带块少于 2 的行列不算。
    有色10 不落在任何一条轴上就返回 None（说不准）。
    由来：第4 关同时有一条横轴和一条竖轴，交叉于一点，而点击只选中其中一条。"""
    b = shape(g, BAND)
    if not b:
        return ()
    ok = b | shape(g, TARGET) | shape(g, PIECE) | shape(g, GHOST)
    out = []
    for k in range(NB):
        if all((k, bc) in ok for bc in range(NB)) and sum((k, bc) in b for bc in range(NB)) >= 2:
            out.append(("row", k))
    for k in range(NB):
        if all((br, k) in ok for br in range(NB)) and sum((br, k) in b for br in range(NB)) >= 2:
            out.append(("col", k))
    cov = frozenset().union(*[line_cells(l) for l in out]) if out else frozenset()
    return tuple(out) if b <= cov else None


def band_cells(g, line):
    """分隔带在某条线上占的块 = 那条线上的全部 21 块，减去线上的目标块。
    由来：带从一条行走到另一条行，块数跟着新行上有几个目标变（20 → 18）——它不是个形状固定的物件，
    它是一条线，目标处让位。"""
    return frozenset(line_cells(line) - shape(g, TARGET))


IDENT = (1, 0, 1, 0)


def _compose(a, b):
    """先做 a 再做 b。变换写成 (sr, ar, sc, ac)：row' = sr*row + ar，col' = sc*col + ac。"""
    sr1, ar1, sc1, ac1 = a
    sr2, ar2, sc2, ac2 = b
    return (sr1 * sr2, sr2 * ar1 + ar2, sc1 * sc2, sc2 * ac1 + ac2)


def transforms(lines):
    """这组轴生成的全部镜像变换，不含恒等。一条轴给一个镜像；一行加一列还多给一个绕交点的点对称。
    两条平行轴会生成无穷多个平移，数不完就返回 None（说不准，还没见过这种局面）。"""
    gens = [(-1, 2 * k, 1, 0) if kind == "row" else (1, 0, -1, 2 * k) for kind, k in lines]
    grp, front = {IDENT}, [IDENT]
    while front:
        t = front.pop()
        for gm in gens:
            n = _compose(t, gm)
            if n not in grp:
                if len(grp) >= 8:
                    return None
                grp.add(n)
                front.append(n)
    return frozenset(grp - {IDENT})


def apply_t(t, p):
    sr, ar, sc, ac = t
    return (sr * p[0] + ar, sc * p[1] + ac)


def ghosts(cells, lines):
    """cells 在这组轴下的全部镜像落点（含落在盘外的，裁不裁由调用方决定）；算不出来返回 None。"""
    ts = transforms(lines)
    if ts is None:
        return None
    return frozenset(apply_t(t, p) for t in ts for p in cells)


def shift(s, d):
    return frozenset((br + d[0], bc + d[1]) for br, bc in s)


def shift_line(line, d):
    """线跟着走：横线只能上下走，竖线只能左右走；另一向返回 None（那等于把带推出盘外）。"""
    kind, k = line
    if kind == "row":
        return ("row", k + d[0]) if d[1] == 0 else None
    return ("col", k + d[1]) if d[0] == 0 else None


def inside(s):
    return all(0 <= br < NB and 0 <= bc < NB for br, bc in s)


def counter(g):
    """计数带（最后一列，64 格）已用掉的格数 = 顶部连续「不是色11」的格数。
    填充色随关卡变（见过色5 和色12），空格一直是色11 —— 所以数的是「不是11」，不是「是某个色」。"""
    w, n = len(g[0]) - 1, 0
    for r in range(len(g)):
        if g[r][w] == TARGET:
            break
        n += 1
    return n


def fill_color(g):
    """计数带当前的填充色；一格都没用掉就读不出来（返回 None）。"""
    return g[0][len(g[0]) - 1] if counter(g) else None


def me(g):
    """镜像（色4）外接框的左上角像素；没有色4 就 None。给 lens.py map 用。"""
    s = shape(g, GHOST)
    return (min(br for br, _ in s) * CELL, min(bc for _, bc in s) * CELL) if s else None


def solid(color):
    return tuple(tuple(color for _ in range(CELL)) for _ in range(CELL))


def ring(color, center):
    """边框 color、中心格 center 的一块。"""
    b = [[color] * CELL for _ in range(CELL)]
    b[CELL // 2][CELL // 2] = center
    return tuple(tuple(r) for r in b)


def paint(br, bc, b):
    return {(br * CELL + i, bc * CELL + j): b[i][j] for i in range(CELL) for j in range(CELL)}


def obj_mode(g, s, color):
    """一件东西**看得见的那些块**的中心格读法 —— 它说的是「这件东西现在能不能被推」：
    底色 = 能推但没被选中；自身颜色（实心）= 推不动；
    "hidden" = 没有一块露得出自己的中心格（压在目标上、或被标记盖住），帧上读不出它是哪一种。
    由来：第0关的分隔带是实心的（推不动，那一关推的是物件），第1、2 关的带是空心的（能推）。
    **「正被选中」不在这里判**：标记穿透所有层（见 render），所以它是 read 按 movers 统一判的。
    读之前排掉两类格：中心格是标记色的（那说的是「这一块参与移动」，不是这件东西的可推状态），
    和压在目标上的（中心格露的是目标色）。"""
    h = CELL // 2
    rest = s - movers(g) - shape(g, TARGET)
    if not rest:
        return "hidden"
    cs = {g[br * CELL + h][bc * CELL + h] for br, bc in rest}
    if cs == {BG}:
        return "free"
    if cs == {color}:
        return "fixed"
    return None


def selected(g):
    """当前被推的那件东西占的块；读不出来返回 None。
    不能直接拿 movers 当它：压在目标上的块中心格露的是目标色，不算进 movers，可那几块照样跟着走。"""
    st = read(g)
    if st is None:
        return None
    for o in st["objs"]:
        if o["mode"] == "sel":
            return o["cells"]
    return None


def read(g):
    """把一帧读成状态：各件东西（每条带轴一件 + 色5 的各片，带各自的可推状态）、轴有哪几条、目标块集合。
    读不出轴（有色10 不在任何一条线上）返回 None。
    带的 cells 取**逻辑占位**（band_cells：整条线减去线上的目标），不是帧上看得见的那些——
    被物件盖住的带块在帧上看不见，却照样跟着带走。它的可推状态则只看这条轴上看得见的那些块。
    **谁被选中按标记判**：标记（中心格色0）穿透所有层，一件东西被选中时，它除目标块以外的每一块都带标记。
    标记比一整件东西少时是**粘连**：两个对象在帧上挨上了（八邻连成一片），帧分不出边界——
    对象身份在世界里跨移动保持，帧上挨着不等于同一件——按标记把连通片切成「被选中的那件 = 标记块」
    和「剩下的部分」。切法只保证可预测性（世界推的就是标记那些块），不保证 rest 是世界里的一件东西。
    一个标记都没有：恰有一件东西整片压在目标上时它就是被选中的那件（one_selected 检验这句话）。"""
    lines = band_lines(g)
    if lines is None:
        return None
    vis = shape(g, BAND)
    tg = shape(g, TARGET)
    objs = []
    for l in lines:
        cells = band_cells(g, l)
        objs.append({"cells": cells, "color": BAND, "line": l,
                     "mode": obj_mode(g, cells & vis, BAND)})
    for p in pieces(g):
        objs.append({"cells": p, "color": PIECE, "line": None, "mode": obj_mode(g, p, PIECE)})
    m = movers(g)
    hits = [o for o in objs if m and m == (o["cells"] - tg)]
    if len(hits) > 1:
        return None
    if len(hits) == 1:
        hits[0]["mode"] = "sel"
    elif m:
        hosts = [o for o in objs if o["color"] == PIECE and m < o["cells"]]
        if len(hosts) != 1:
            return None
        h = hosts[0]
        rest = h["cells"] - m
        h["cells"] = frozenset(m)
        h["mode"] = "sel"
        objs.append({"cells": rest, "color": PIECE, "line": None,
                     "mode": obj_mode(g, rest, PIECE)})
    else:
        hid = [o for o in objs if o["mode"] == "hidden"]
        if len(hid) != 1:
            return None
        hid[0]["mode"] = "sel"
    for o in objs:
        if o["mode"] == "hidden":
            o["mode"] = "free"
    return {"objs": objs, "lines": lines, "targets": tg}


def render(st):
    """从状态画回整个盘面（21x21 块），返回 {(row,col): 色}；说不准就返回 None。

    叠起来怎么画（实测）：两件事各有一条优先级，而且是**同一条**——物件(色5) > 镜像(色4) > 目标(色11) > 分隔带(色10) > 底色。
    **边框色**取最上面那一层的颜色。**中心格**取最上面那一层的「中心写法」，各层的中心写法是：
    目标 → 目标色（它画在地板上，压住它的东西不会让它消失，它从中心透出来，所以它在中心这条优先级里反而在最上面）；
    物件与分隔带 → 正被选中画标记色、能推画底色、推不动画自己的颜色；镜像 → 它是实心的，没有状态可写，就画自己的色4；
    都没有 → 跟边框同色。**「正被选中」这个标记穿透所有层**：一块上只要压着的东西里有一件是被选中的那件，
    中心格就是标记色，不管它在第几层（实测：物件压在被选中的带上、带钻到被选中的物件底下、两条带交叉，四种叠法一律标记色）。
    其余情形由最上面那一层写：底色 = 能推没被选中，自身颜色 = 推不动。
    唯一还说不准的叠法：两片物件叠在一起（边框都是色5，分不出来）——返回 None。"""
    if st is None:
        return None
    lines, objs, tg = st["lines"], st["objs"], st["targets"]
    if not lines or any(o["mode"] is None for o in objs):
        return None
    ps = [o["cells"] for o in objs if o["color"] == PIECE]
    allp = frozenset().union(*ps) if ps else frozenset()
    if sum(len(p) for p in ps) != len(allp):
        return None
    gh = ghosts(allp, lines)
    if gh is None:
        return None
    refl = frozenset(p for p in gh if inside({p})) - allp
    owner, marked = {}, set()
    for o in objs:
        for p in o["cells"]:
            if o["mode"] == "sel":
                marked.add(p)
            cur = owner.get(p)
            if cur is None:
                owner[p] = o
            elif cur["color"] != PIECE and o["color"] == PIECE:
                owner[p] = o
    out = {}
    for br in range(NB):
        for bc in range(NB):
            p, on_t = (br, bc), (br, bc) in tg
            o = owner.get(p)
            if p in allp:
                edge = PIECE
            elif p in refl:
                edge = GHOST
            elif o is not None:
                edge = o["color"]
            elif on_t:
                edge = TARGET
            else:
                edge = BG
            if on_t:
                center = TARGET
            elif p in marked:
                center = MARK
            elif p in refl:
                center = GHOST
            elif o is not None:
                center = MARK if o["mode"] == "sel" else (BG if o["mode"] == "free" else o["color"])
            else:
                center = edge
            out.update(paint(br, bc, ring(edge, center)))
    return out


def _sel(g):
    """(状态, 被选中那件东西)；读不出来返回 (None, None)。"""
    st = read(g)
    if st is None:
        return None, None
    sels = [o for o in st["objs"] if o["mode"] == "sel"]
    return (st, sels[0]) if len(sels) == 1 else (None, None)


def sel_move(g, d):
    """被选中那件东西走一步之后**该占的块集合**；说不准返回 None。
    带走：先把它那条线挪一格，再按新线重算占位；别的东西走：整体平移。"""
    st, sel = _sel(g)
    if sel is None:
        return None
    if sel["color"] == BAND:
        nl = shift_line(sel["line"], d)
        return None if nl is None else band_cells(g, nl)
    return shift(sel["cells"], d)


def post(g, d):
    """推一下（被选中那件东西走 d）之后的**状态**（objs / lines / targets）；说不准返回 None。
    盘面长什么样由 render 从它算，「这一关过没过」由 covers_all 从它算。"""
    st, sel = _sel(g)
    if sel is None:
        return None
    ncells = sel_move(g, d)
    if not ncells or not inside(ncells):
        return None                               # 推到盘外会怎样（卡住？无效？）还没试过
    if sel["color"] == BAND:
        nl = shift_line(sel["line"], d)
        objs = [{**o, "cells": ncells, "line": nl} if o is sel else o for o in st["objs"]]
        lines = tuple(nl if l == sel["line"] else l for l in st["lines"])
    else:
        objs = [{**o, "cells": ncells} if o is sel else o for o in st["objs"]]
        lines = st["lines"]
    return {**st, "objs": objs, "lines": lines}


def covers_all(st):
    """这个状态里，每一块目标是不是都被物件或它的某个镜像盖住了 —— 这一局「赢」的判据。"""
    if st is None:
        return False
    ps = [o["cells"] for o in st["objs"] if o["color"] == PIECE]
    allp = frozenset().union(*ps) if ps else frozenset()
    if not allp or not st["lines"]:
        return False
    gh = ghosts(allp, st["lines"])
    if gh is None:
        return False
    refl = frozenset(p for p in gh if inside({p}))
    return bool(st["targets"]) and st["targets"] <= (allp | refl)


def step_pred(g, d):
    """推一下之后的整个盘面；说不准就 None。
    这一步会盖满全部目标时**故意不预测**：那一帧是换关的整屏重画，新关长什么样算不出来。"""
    st = post(g, d)
    if st is None or covers_all(st):
        return None
    return render(st)


# ============================================================================================
# 修复（meta/repair-20260928，2026-09-29）补的读数。以上原函数一字未改。
# 全部只读**这一帧**的像素，输出感知原语（哪些块是什么颜色、轴在哪条线、谁带标记），
# 不输出任何「做某个动作会怎样」的量——推动、镜像、换关都由 Lean 规则从这些原语算。
# ============================================================================================

def tg(g):
    """目标层：盘面上含色11 的块（被物件或镜像压住时中心仍露色11，照样算）。"""
    return shape(g, TARGET)


def pc(g):
    """物件层：盘面上含色5 的块（所有物件的并集，不分片）。"""
    return shape(g, PIECE)


def gh(g):
    """镜像层：盘面上含色4 的块。"""
    return shape(g, GHOST)


def bv(g):
    """带的可见块：盘面上含色10 的块。"""
    return shape(g, BAND)


def _line_code(line):
    """一条轴编成一个整数：横轴 ("row",k) -> k，竖轴 ("col",k) -> 32+k。"""
    kind, k = line
    return k if kind == "row" else 32 + k


def axes(g):
    """这一帧读出的分隔带轴（band_lines 的结果），编成定长 2 元组，按编码升序，空位 -1。
    读不出轴（band_lines 为 None）或超过两条返回 None。"""
    lines = band_lines(g)
    if lines is None or len(lines) > 2:
        return None
    cs = sorted(_line_code(l) for l in lines)
    return tuple(cs + [-1] * (2 - len(cs)))


def sel_line(g):
    """带标记的那件东西是哪一种：是某条带轴就给那条轴的编码（同 axes），是物件给 -1；read 读不出被选中的那件给 None。"""
    st, sel = _sel(g)
    if sel is None:
        return None
    return _line_code(sel["line"]) if sel["color"] == BAND else -1


# 每关一组常数（修订 R1.1）：计数带的填充色。计数为 0 的帧上看不见，换关后第一次有效推动才露出来。
# 反推自全部 run 的帧（probe4.py，全部 1051 条转移的 prev/next 各读一次 fill_color）：
#   第 0 关 148 帧、第 1 关 88 帧读到色5，没有别的值；第 2–7 关（388/168/216/314/290/416 帧）读到色12，没有别的值；
#   第 8 关（WIN 帧）4 帧读到色12。每关恰好一个值。
#
# sizes：这一关各件物件的块数，编成位集（块数 n 占第 n 位）。物件整体平移，块数不变，所以它是关卡内容，和换关后的布局同类。
# 反推自每关开局帧（换关后第一帧、RESET 后第一帧、run 第一帧）里色5 块的八邻连通片（不跨目标）大小（probe6.py）：
#   第 0 关 {5}（4 帧）、第 1 关 {8}（4 帧）、第 2 关 {6,7}（5 帧）、第 3 关 {6,7}（4 帧）、第 4 关 {11}（4 帧）、
#   第 5 关 {5,8}（4 帧）、第 6 关 {9,14}（4 帧）、第 7 关 {7,8}（5 帧）、第 8 关（WIN 帧）{7,8}（3 帧）。同一关各帧一致。
# 用处：帧上两件物件八邻相接（或一件整片压在目标上、被 reader 经目标连成一片）时，单帧分不清被选中那件的边界；
#   Lean 的规则只在「标记所在的那片块数等于本关某件物件的块数」时才认为读得清，否则不预测。
LEVEL_CONST = {0: {"fill": 5, "sizes": 32}, 1: {"fill": 5, "sizes": 256}, 2: {"fill": 12, "sizes": 192},
               3: {"fill": 12, "sizes": 192}, 4: {"fill": 12, "sizes": 2048}, 5: {"fill": 12, "sizes": 288},
               6: {"fill": 12, "sizes": 16896}, 7: {"fill": 12, "sizes": 384}, 8: {"fill": 12, "sizes": 384}}
