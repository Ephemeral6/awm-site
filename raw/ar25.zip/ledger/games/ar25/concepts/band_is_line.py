"""分隔带在帧上看得见的块，恰好等于「它那几条轴上的全部块，减去轴上的目标块，再减去被物件(色5)或镜像(色4)盖住的块」。"""
LEVEL = "L6"
SCOPE = "看每一帧的 nxt（含换关后的第一帧）；盘上没有色10、或色10 读不出轴（band_lines 为 None）返回 NA。"
NOTE = "v4：v3 说「只有物件盖得住带」，被 tid 7d4edd5a0aaec426 之后那条 7d02fb53a57a0f1e 推翻——镜像落到轴上的非目标块时，那一块画成实心色4，带在那里也看不见了。所以镜像和物件一样会遮带；真正压不住带的只有目标（目标根本不占带的位）。v3：轴可以不止一条（第4 关一横一竖，交叉于一点却是两件东西），右边改成各轴占位的并集。v2：v1 只减目标，被 tid 80035af93303fa8d 推翻——带推到物件所在那一行，物件那两块画的是物件的边框。目标和物件/镜像盖带的方式不一样：目标让带真的让位（那格不进可动组），后两者只是盖住（那格照样跟着带走）。写它是为了让 _lib.band_cells 自己走一次闸：左边直接读色10 占了哪些块，右边从「轴在哪」「目标在哪」「谁压在上面」算出来。"
EVIDENCE = ["f2d20cbfe45f4a8a", "0291bbd2c4b9cc3d", "80035af93303fa8d", "7d02fb53a57a0f1e"]

from _lib import BAND, GHOST, PIECE, band_cells, band_lines, shape


def assert_(prev, action, nxt, ctx=None):
    s = shape(nxt, BAND)
    if not s:
        return "NA"
    lines = band_lines(nxt)
    if not lines:
        return "NA"
    want = frozenset().union(*[band_cells(nxt, l) for l in lines])
    want -= shape(nxt, PIECE) | shape(nxt, GHOST)
    return "TRUE" if s == want else "FALSE"
