"""带坐标的 ACTION6 只改「谁能被推」：可动组变成被点中的那件东西——点中块上画的是物件就是那片物件，画的是分隔带就是**那一条轴**（不是同色连通片），盘上三件东西（色4/色5/色11）的块集合一格不动。"""
LEVEL = "L7"
SCOPE = "只看 ACTION6:x,y（x=列 y=行 的像素坐标）；换关返回 NA；点在底色块上、块里除底色与标记色外不止一种颜色、块上画的既不是物件也不是分隔带、或点中的块同时属于两条轴（交叉点，分不清点的是哪条）返回 NA。它只断言标记的去向与「别的没动」，不断言标记被画成什么样——那由 apply 生成、由帧差判。"
NOTE = "v4：轴不止一条时，「点中块所在的同色连通片」给出的是两条轴的并集，而世界只选中其中一条（第4 关一横一竖交叉于一点，点横轴只有横轴变可动组）。所以点中的东西改从 _lib.read 的物件表认：块上画在最上面的是哪种颜色，就在那种颜色的东西里找包含这一块的那一件；交叉点属于两条轴，返回 NA。v3：被选中那件东西改用 _lib.selected 认（物件压在目标上时那几块中心露的是目标色，数不进 movers）；apply 也跟着不再往目标块上画标记。v2 时挨过一记（tid ccdc61f5500f7a16）：点带的左段，被选中的是整条带 20 块，不是我算的 11 块——带被线上一个目标块切成两段，而世界不认这个切口。v1 由第 26 步问出来：第 1 关的可动组是整条分隔带，推带只给得出色4 的横向位移，竖向一步都给不出来——所以「谁能被推」必须是可改的，而唯一没试过的动作就是带坐标的 ACTION6。"
EVIDENCE = ["b05ff54ae4f4d76c", "ccdc61f5500f7a16"]

from _lib import BAND, BG, CELL, MARK, NB, PIECE, TARGET, block, read, selected, shape


def _clicked(prev, action):
    """点中的那件东西（块集合）；说不准就 None。"""
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except (IndexError, ValueError):
        return None
    br, bc = y // CELL, x // CELL
    if not (0 <= br < NB and 0 <= bc < NB):
        return None
    cols = {v for row in block(prev, br, bc) for v in row} - {BG, MARK}
    if len(cols) != 1:
        return None
    c = cols.pop()
    st = read(prev)
    if st is None or c not in (PIECE, BAND):
        return None
    hits = [o["cells"] for o in st["objs"] if o["color"] == c and (br, bc) in o["cells"]]
    return hits[0] if len(hits) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith("ACTION6"):
        return "NA"
    tgt = _clicked(prev, action)
    if tgt is None:
        return "NA"
    for c in (4, 5, 11):
        if shape(prev, c) != shape(nxt, c):
            return "FALSE"
    s = selected(nxt)
    if s is None:
        return "NA"
    return "TRUE" if s == tgt else "FALSE"


def apply(prev, action, ctx=None):
    if not action.upper().startswith("ACTION6"):
        return None
    tgt = _clicked(prev, action)
    if tgt is None:
        return None
    h, tg = CELL // 2, shape(prev, TARGET)
    old = selected(prev)
    if old is None:
        return None
    out = {(br * CELL + h, bc * CELL + h): BG for br, bc in old
           if (br, bc) not in tgt and (br, bc) not in tg}
    out.update({(br * CELL + h, bc * CELL + h): MARK for br, bc in tgt if (br, bc) not in tg})
    return out
