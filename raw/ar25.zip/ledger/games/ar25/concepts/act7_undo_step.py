"""ACTION7 要么让被选中那件东西回退一步（上下左右之一，落点跟一次推动能到的地方一样），要么它不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION7；换关返回 NA；读不出被选中的是哪一件（selected/sel_move 说不准）返回 NA。它走哪个方向由历史决定（看着像撤销栈），单帧看不出来，所以这里只断言「四个方向里的某一个，且落点按推动的算法算」。"
NOTE = "v3：主角从 movers（数中心标记色）换成 _lib.selected（先认东西再取块）——物件压在目标上时那几块中心露的是目标色；落点从「整体平移一块」换成 sel_move，跟四个方向动作用同一套（带回退时占位要按新线重算，不是平移）。v2 时主角从色4 换成可动组——撤销撤掉的是一次推动，色4 只是跟着动的那个。"
EVIDENCE = ["365aadcfb0925931"]

from _lib import sel_move, selected


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith("ACTION7"):
        return "NA"
    s0, s1 = selected(prev), selected(nxt)
    if s0 is None or s1 is None:
        return "NA"
    if s1 == s0:
        return "TRUE"
    for d in ((-1, 0), (1, 0), (0, 1), (0, -1)):
        if s1 == sel_move(prev, d):
            return "TRUE"
    return "FALSE"
