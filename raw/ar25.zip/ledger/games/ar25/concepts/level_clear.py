"""这一关什么时候算赢：一次推动之后，每一块目标都被物件(色5)或它关于分隔带的镜像盖住——当且仅当这一步换关。"""
LEVEL = "L5"
SCOPE = "只看 ACTION1-4（会推动的那四个）；从 prev 算不出推完之后的状态（post 说不准）返回 NA；ctx 缺 level_prev/level_next 返回 NA。它是双向的：盖满就该换关，没盖满就不该换关。"
NOTE = "写它是为了让册子知道自己什么时候不知道：换关那一帧是整屏重画，新关长什么样算不出来（换关帧上的规则图完成度只有 0.073），所以 _lib.step_pred 现在在「这一步会盖满」时故意返回 None，不预测。不这么做的话，每次过关都会记成一次意外，而那不是世界让我意外，是我明知道算不出还硬猜。goal_cover 是它的否定式弱版（没重合就不换关），这条是正反都说的强版，也是策略里「什么算赢」那个必填槽的正文。**它在两副口径下会变脸**：结算时 ctx 的 level_next 是真的，预测时 level_next 被填成 level_prev，于是真正换关的那一步在预测口径下判 FALSE——分数量的是结算那一条。"
EVIDENCE = ["26948eaad88e320e", "d31f0e0e4339d8de"]

from _lib import DELTA, covers_all, post


def assert_(prev, action, nxt, ctx=None):
    base = action.upper().split(":")[0]
    if base not in DELTA:
        return "NA"
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    st = post(prev, DELTA[base])
    if st is None:
        return "NA"
    return "TRUE" if covers_all(st) == (ctx["level_prev"] != ctx["level_next"]) else "FALSE"
