"""ACTION5 不改变盘面上任何形状：色4、色5、色11 的块集合一格不变。"""
LEVEL = "L1"
SCOPE = "只看 ACTION5；换关返回 NA。只管盘面 21x21 块，列63 的计数带由 counter_tick 管。"
NOTE = ""
EVIDENCE = ["481887edd62a1b6b"]

from _lib import shape


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith("ACTION5"):
        return "NA"
    for color in (4, 5, 11):
        if shape(prev, color) != shape(nxt, color):
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.upper().startswith("ACTION5"):
        return None
    out = {}
    for color in (4, 5, 11):
        for br, bc in shape(prev, color):
            for i in range(3):
                for j in range(3):
                    out[(br * 3 + i, bc * 3 + j)] = prev[br * 3 + i][bc * 3 + j]
    return out
