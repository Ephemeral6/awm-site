"""ACTION1 要么让被选中那件东西上移一行——物件整体平移、分隔带则改占上面那条线（线上目标处让位）——要么它原地不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1；换关返回 NA；读不出被选中的是哪一件（selected/sel_move 说不准）返回 NA。只断言被选中那件东西的落点，跟着动的色4 由 mirror 管、由 apply 生成。粘连（两件东西 8 邻相接导致 selected 变大或分裂）时，若预测落点全在色5 里则仍判 TRUE，否则返回 NA。"
NOTE = "v6：被 b06fd8a7 / d006e5b1 推翻——物件上移后与另一片对角相邻，selected(nxt) 返回合并后的 15 块，但 sel_move 只预测了原先 8 块。改法：s1 != want 时，若 want ⊆ shape(nxt, PIECE) 仍判 TRUE（块都在对的位置，只是被合并了），否则 NA（粘连导致 sel_move 失准）。v5：改用 selected。"
EVIDENCE = ["72135a5e9e70310c", "f2d20cbfe45f4a8a",
            "b06fd8a718d69426", "d006e5b1f122cd5b"]

from _lib import DELTA, PIECE, sel_move, selected, shape, step_pred

A = "ACTION1"


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith(A):
        return "NA"
    s0, s1 = selected(prev), selected(nxt)
    if s0 is None:
        return "NA"
    if s1 is not None and s1 == s0:
        return "TRUE"
    want = sel_move(prev, DELTA[A])
    if want is None:
        return "NA"
    if s1 is not None and s1 == want:
        return "TRUE"
    if want <= shape(nxt, PIECE):
        return "TRUE"
    return "NA"


def apply(prev, action, ctx=None):
    if not action.upper().startswith(A):
        return None
    return step_pred(prev, DELTA[A])
