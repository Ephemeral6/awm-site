"""任何一帧里，色4 占的块集合恰好等于「全部色5 在这组分隔带轴生成的反射群下的像」里落在盘内、又没有被物件(色5)本体压住的那一部分。"""
LEVEL = "L6"
SCOPE = "看每一帧的 nxt（含换关后的第一帧）；读不出轴（band_lines 为 None 或空）、轴的组合生成不出有限多个变换（ghosts 为 None）、或盘面上没有色5 返回 NA。它同时断言了三件可判错的事：镜像落在盘外就不画（第2 关一开始没有色4 是它的预测）；镜像和物件本体落在同一块时画的是物件；**轴不止一条时，像是它们生成的整个群**，不是各画各的。"
NOTE = "v5：轴可以不止一条（一横一竖），此时除了两个镜像还多一个绕交点的点对称——「群」这个词是可判错的：若世界只画两条轴各自的镜像、不画点对称的那一份，这条当场判 FALSE。v4：v3 被 tid 80035af93303fa8d 推翻——轴推到某片物件身上时，那片贴着轴的两块的镜像就是它自己，而那两块画的是物件的边框，不是色4。所以要减掉物件占的块。减的只是物件：镜像压在分隔带上仍画色4（优先级 物件 > 镜像 > 目标 > 带）。v3 之前还错过一次因果：说色5 是色4 的镜像，反了，也说不出色4 缺席。"
EVIDENCE = ["16913da84badc924", "0291bbd2c4b9cc3d", "80035af93303fa8d"]

from _lib import GHOST, PIECE, band_lines, ghosts, inside, shape


def assert_(prev, action, nxt, ctx=None):
    lines = band_lines(nxt)
    if not lines:
        return "NA"
    s5 = shape(nxt, PIECE)
    if not s5:
        return "NA"
    gh = ghosts(s5, lines)
    if gh is None:
        return "NA"
    want = frozenset(p for p in gh if inside({p})) - s5
    return "TRUE" if shape(nxt, GHOST) == want else "FALSE"
