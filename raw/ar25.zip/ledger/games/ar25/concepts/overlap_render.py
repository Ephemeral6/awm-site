"""镜像和目标叠在一起那一块，恰好是「边框色4、中心格色11」——两层都还看得见；只有镜像是实心色4，只有目标是实心色11。"""
LEVEL = "L6"
SCOPE = "看每一帧的 nxt；换关返回 NA（那一帧整屏重画）；盘面上没有色4 或没有色11 返回 NA。**只管颜色成分不出 {色4, 色11} 的块**——块里还有物件或分隔带时，画的是那两层，由 frame_is_render 管。中心格是可动标记的块（movers 里的）中心不算。"
NOTE = "v2：v1 说「只含色11 的块是实心色11」，被 tid a3d4eea3431fa704 推翻——物件推到目标上，那一块边框是物件的色5、中心露出目标色11，既不是实心色11 也不在 v1 的例外里。缩 scope：这条只讲镜像与目标这两层怎么叠。它顺带钉住了一件事——**目标被盖住不会消失，它从中心格透出来**，物件那一层同理（那条由 frame_is_render 管）。v1 原本问的是「棋子压在目标上那一格画成什么」，答案已经拿到，而拿到的答案不属于这条概念。"
EVIDENCE = ["4259e73e695d86ca", "769528f2403ae67e", "a3d4eea3431fa704"]

from _lib import CELL, block, movers, ring, shape, solid


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    s4, s11 = shape(nxt, 4), shape(nxt, 11)
    if not s4 or not s11:
        return "NA"
    mk, h = movers(nxt), CELL // 2
    for br, bc in s4 | s11:
        b = block(nxt, br, bc)
        if {v for row in b for v in row} - {4, 11}:
            continue                              # 还叠着别的层，不由这条概念管
        if (br, bc) in s4 and (br, bc) in s11:
            want = ring(4, 11)
        elif (br, bc) in s4:
            want = solid(4)
        else:
            want = solid(11)
        for i in range(CELL):
            for j in range(CELL):
                if (i, j) == (h, h) and (br, bc) in mk:
                    continue                      # 这一格被标记占了，不由这条概念管
                if b[i][j] != want[i][j]:
                    return "FALSE"
    return "TRUE"
