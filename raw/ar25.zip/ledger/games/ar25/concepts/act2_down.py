"""ACTION2 要么让被选中那件东西下移一行——物件整体平移、分隔带则改占下面那条线（线上目标处让位）——要么它原地不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION2；换关返回 NA；读不出被选中的是哪一件（selected/sel_move 说不准）返回 NA。只断言被选中那件东西的落点，跟着动的色4 由 mirror 管、由 apply 生成。粘连时若预测落点全在色5 里则仍判 TRUE，否则返回 NA。"
NOTE = "v6：与 act1_up v6 同一批——粘连（8 邻合并）导致 selected(nxt) 比预期大或 None；改法同。v5：改用 selected。"
EVIDENCE = ["e20fe61cf7a3a726", "a3d4eea3431fa704"]

from _lib import DELTA, PIECE, sel_move, selected, shape, step_pred

A = "ACTION2"


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith(A):
        return "NA"
    s0, s1 = selected(prev), selected(nxt)
    if s0 is None:
        return "NA"
    if s1 is not None and s1 == s0:
        return "TRUE"
    want = sel_move(prev, DELTA[A])
    if want is None:
        return "NA"
    if s1 is not None and s1 == want:
        return "TRUE"
    if want <= shape(nxt, PIECE):
        return "TRUE"
    return "NA"


def apply(prev, action, ctx=None):
    if not action.upper().startswith(A):
        return None
    return step_pred(prev, DELTA[A])
