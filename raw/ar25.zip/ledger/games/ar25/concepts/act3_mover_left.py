"""ACTION3 要么让被选中那件东西左移一列——物件整体平移、分隔带则改占左边那条线（线上目标处让位）——要么它原地不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION3；换关返回 NA；读不出被选中的是哪一件（selected/sel_move 说不准）返回 NA。横着的带被要求左右走时 sel_move 说不准（那等于把线推出它自己的方向），返回 NA。粘连/脱粘时，若预测落点全在色5 里则仍判 TRUE，否则返回 NA。"
NOTE = "v4：被 ff0bbb7f / 58cecefb / 86097eb9 推翻——粘连后 selected 合并了两件东西。selected(nxt) 比预期大（粘连持续）或小（脱粘）。改法：s1 != want 时，若 want ⊆ shape(nxt, PIECE) 仍判 TRUE。v3：改用 _lib.selected。"
EVIDENCE = ["16913da84badc924", "c6f11fc6bbb8d7de",
            "ff0bbb7f3cf67a7e", "58cecefb95fe100d", "86097eb9fc53a37b"]

from _lib import DELTA, PIECE, sel_move, selected, shape, step_pred

A = "ACTION3"


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith(A):
        return "NA"
    s0, s1 = selected(prev), selected(nxt)
    if s0 is None:
        return "NA"
    if s1 is not None and s1 == s0:
        return "TRUE"
    want = sel_move(prev, DELTA[A])
    if want is None:
        return "NA"
    if s1 is not None and s1 == want:
        return "TRUE"
    if want <= shape(nxt, PIECE):
        return "TRUE"
    return "NA"


def apply(prev, action, ctx=None):
    if not action.upper().startswith(A):
        return None
    return step_pred(prev, DELTA[A])
