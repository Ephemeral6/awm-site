"""每一帧的标记都指认恰好一件被选中的东西：标记块要么恰好等于某一件东西露在目标外的全部块，要么是某个八邻连通片的真子集（两个对象在帧上挨上时帧分不出边界，标记指认被选中那件的可见部分），要么一块都没有——后者只发生在恰有一件东西整片压在目标上的时候（WIN 帧所有物件都压在目标上，此时返回 NA）。"""
LEVEL = "L7"
SCOPE = "看每一帧的 nxt（含换关后的第一帧）；盘上读不出分隔带的轴（band_lines 为 None）返回 NA。「东西」= 每条带轴一件（按 band_cells 算的逻辑占位）加色5 的各个**八邻**连通片。WIN 帧（所有物件都在目标上）返回 NA；零标记且无物件在目标上（粘连导致标记丢失）返回 NA。"
NOTE = "v6：被 5f206fbd 推翻——粘连后标记丢失，m=0 且无物件在目标上，判 FALSE。改法：零标记且 hidden_on_tg=0 时返回 NA。v5：被 79417f72 推翻——WIN 帧两件物件全压在目标上，零标记却有两件「整片压在目标上」，判 FALSE。改法：零标记且压在目标上的不止一件时返回 NA（WIN 帧）。v4：粘连切割（m < piece）。v3：四邻改八邻。"
EVIDENCE = ["b05ff54ae4f4d76c", "29deaeb5d032b656", "c11d7f52f7316a3e", "2ce17e1a296976fa",
            "4ac7c48725730b78", "5444b30bbe57ecf0", "64560d14e6c3d3e6", "bab4df59811cc0e9", "e9c9f75cb2fbfd9b",
            "79417f72814f8fd9", "5f206fbd7a29ae45"]

from _lib import TARGET, band_cells, band_lines, movers, pieces, shape


def _objs(g):
    lines = band_lines(g)
    if lines is None:
        return None
    return [band_cells(g, l) for l in lines] + pieces(g)


def assert_(prev, action, nxt, ctx=None):
    objs = _objs(nxt)
    if objs is None:
        return "NA"
    m, tg = movers(nxt), shape(nxt, TARGET)
    if not m:
        hidden_on_tg = [s for s in objs if s <= tg]
        if len(hidden_on_tg) == 1:
            return "TRUE"
        return "NA"                                   # WIN 帧 / 粘连标记丢失：说不准
    if len([s for s in objs if m == s - tg]) == 1:
        return "TRUE"
    hosts = [s for s in objs if m < s]
    return "TRUE" if len(hosts) == 1 else "FALSE"
