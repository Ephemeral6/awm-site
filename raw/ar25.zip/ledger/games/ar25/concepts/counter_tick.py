"""计数带（最后一列 64 格，空格是色11）已用掉的格数：ACTION1..ACTION5 在盘面发生变化时恰好 +1，盘面不变（被阻挡的推）时 +0；ACTION6、ACTION7 之后不变。"""
LEVEL = "L4"
SCOPE = "只看 ACTION1-7；换关返回 NA。只管最后一列这一条带，不管盘面。数的是「顶部连续不是色11 的格数」，不是某个具体填充色。"
NOTE = "v6：被 f22b3e9d / 9a90ac88 / 302bc15b / bc260bb8 推翻——阻挡/无效的推送不消耗计数器。改法：ACTION1-5 在 prev==nxt 时期望 +0。v5：apply 现在在「这一步会盖满全部目标」时闭嘴——换关计数带清零，照常 +1 就错（tid c5a0921712afb8e7 上押色12 实际是色11 的空格）。v4：填充色不是固定的——第0、1 关填色5，第2 关填色12，而空格一直是色11。v3 把填充色写死成色5，第2 关第一步就判 FALSE（tid 0291bbd2c4b9cc3d）。"
EVIDENCE = ["72135a5e9e70310c", "365aadcfb0925931", "b05ff54ae4f4d76c", "0291bbd2c4b9cc3d",
            "f22b3e9debcfbe6e", "9a90ac88075f271e", "302bc15bd6ca8db3", "bc260bb8a703cc46"]

from _lib import DELTA, counter, fill_color


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = action.upper()
    d = counter(nxt) - counter(prev)
    if a.startswith("ACTION7") or a.startswith("ACTION6"):
        return "TRUE" if d == 0 else "FALSE"
    if any(a.startswith(f"ACTION{k}") for k in (1, 2, 3, 4, 5)):
        if prev == nxt:                                # 被阻挡的推：盘面不变，计数器也不变
            return "TRUE" if d == 0 else "FALSE"
        return "TRUE" if d == 1 else "FALSE"
    return "NA"


def apply(prev, action, ctx=None):
    a = action.upper()
    if not any(a.startswith(f"ACTION{k}") for k in (1, 2, 3, 4, 5)):
        return None
    base = a.split(":")[0]
    if base in DELTA:
        # 快速检查：step_pred → None 意味着这一步会换关或说不准，不预测
        from _lib import step_pred
        sp = step_pred(prev, DELTA[base])
        if sp is None:
            return None
    n, f = counter(prev), fill_color(prev)
    if f is None or n >= len(prev):
        return None
    return {(n, len(prev[0]) - 1): f}
