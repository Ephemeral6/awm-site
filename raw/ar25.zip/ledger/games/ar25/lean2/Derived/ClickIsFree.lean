/-
# ClickIsFree —— 点一下不花钱、盘面不动（**推论**，对应 `rule/budget/click_is_free.py`）

在规则层它是一句要对着语料判的话；在这里它**不是独立的规则**：
点的定义（`Rule/Move/ClickSelects.lean`）只改 `sel` 一个字段，于是

    计数带不变、带不变、物件不变

都是从定义推出来的。一条规则重排之后掉进这里，说明它本来就不是一条独立的规则。

它会失败吗：把 `click` 改成顺手动一下 `used`（点一下也花钱），这一条当场编不过。
-/
import Step
import Obj.World

/- 定理一律写**全名**（`Game.…`），不包在 `namespace` 里：装置的公理表探针（`ledger/lean_check.py`）
   按源码里的名字逐条 `#print axioms`，不带 `open`，短名它找不到——那时读数是「跑不起来」，不是「干净」。 -/

theorem Game.click_is_free (b : Board) (w w' : World) (x y : Nat)
    (h : step b w (.click x y) = .ok w') :
    w'.used = w.used ∧ w'.bands = w.bands ∧ w'.pieces = w.pieces := by
  simp only [step] at h
  cases hc : click b w x y with
  | none => simp [hc] at h
  | some w'' =>
    simp only [hc, Res.ok.injEq] at h
    subst h
    simp only [click] at hc
    cases hi : clickedIx b w x y with
    | none => simp [hi] at hc
    | some i =>
      simp only [hi, Option.some.injEq] at hc
      subst hc
      exact ⟨rfl, rfl, rfl⟩

#print axioms Game.click_is_free
