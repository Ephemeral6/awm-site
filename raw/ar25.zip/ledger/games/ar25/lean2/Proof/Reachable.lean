/-
# Reachable —— 这个**局面**做不做得了

整套形式化里真正要证的只有两句话：

    Winnable   b w  :=  ∃ as, 每一下合法 ∧ 照着走中途赢过
    Unsolvable b w  :=  ∀ as, 每一下合法 → 照着走从没赢过

## 一条必须写在明处的削弱

`step` 有一支 `unknown`（模型说不出话：推出盘外、点在空白处、计数带用满……），
`everWon` 碰到它返回 `false`。所以 `Unsolvable` 准确的意思是
**「不经过模型说不出话的那几支，就赢不了」**——`∀ as` 这个形状一个字都看不出来，所以写在这里。
这一局的八关全部是 `Winnable`（见 `Proof/Levels.lean`），这一局没有用到 `Unsolvable`；
骨架留着，是给「宣告某个局面不可做」的那一天用的。
-/
import Step
import Obj.World

namespace Game

/-- 一下动作合法：点击要点在 64×64 的帧里。 -/
def Act.legal : Act → Bool
  | .push _ => true
  | .click x y => x < 64 && y < 64

/-- 从 `w` 起照着 `as` 走，中途有没有哪一步赢过。`unknown` 当「没赢」（见文件头那条削弱）。 -/
def everWon (b : Board) : World → List Act → Bool
  | _, [] => false
  | w, a :: rest =>
    match step b w a with
    | .won => true
    | .ok w' => everWon b w' rest
    | .unknown => false

def Winnable (b : Board) (w : World) : Prop :=
  ∃ as : List Act, as.all Act.legal = true ∧ everWon b w as = true

def Unsolvable (b : Board) (w : World) : Prop :=
  ∀ as : List Act, as.all Act.legal = true → everWon b w as = false

end Game

/- 定理一律写**全名**：装置的公理表探针按源码里的名字 `#print axioms`，不带 `open`。 -/

theorem Game.not_both (b : Board) (w : World) : Winnable b w → Unsolvable b w → False := by
  intro ⟨as, hl, hw⟩ hu
  have := hu as hl
  simp [this] at hw

/-- **骨架：不变量 ⇒ 不可做。** 全文唯一做归纳的地方，不枚举任何状态、与盘面大小无关。 -/
theorem Game.unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w w' a, Act.legal a = true → P w → step b w a = .ok w' → P w')
    (hwin : ∀ w a, P w → step b w a ≠ .won) :
    ∀ (w : World), P w → Unsolvable b w := by
  intro w hp as
  induction as generalizing w with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [List.all_cons, Bool.and_eq_true] at hall
    simp only [everWon]
    cases hstep : step b w a with
    | won => exact absurd hstep (hwin w a hp)
    | unknown => rfl
    | ok w' => exact ih w' (hkeep w w' a hall.1 hp hstep) hall.2

#print axioms Game.not_both
#print axioms Game.unsolvable_of_invariant
