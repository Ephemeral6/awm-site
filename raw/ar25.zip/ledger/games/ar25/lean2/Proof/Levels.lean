/-
# Levels —— 每一关一条定理（自动生成：`python lean2/export_levels.py`，不要手改）

    L<n>_len        那一段路切出来恰好这么多步（空表会让下一条平凡为真）
    L<n>_trace      沿着真人走过的那条路，模型**每一帧都和观测对上**
                    —— 只有开局那一帧是观测给的，后面全是模型自己算的
    L<n>_winnable   这一关走得通 —— 见证就是那条路再加上过关那一脚

开局**从语料的帧里读出来**（`Replay.frameAt`），盘用**整关取并集**的那张（`Replay.levelBoard`）。
每关核过的步数：14 / 10 / 39 / 21 / 27 / 52 / 36 / 46（共 245 步；另有 8 步过关的脚不在路里，由 `_winnable` 与逐条层核）。

这一局 0 次 RESET、每关一段：没有尾段、也没有「重来放回开局」那条假设（见 `export_levels.py`）。
-/
import Obs.Replay
import Proof.Reachable
import Obj.World

set_option maxRecDepth 20000

-- 定理一律写全名（`Game.Levels.…`）：装置的公理表探针按源码里的名字 `#print axioms`，不带 `open`。

namespace Game.Levels
open Game.Replay

/-- 第 0 关的真实开局（步号 1 那一步之前的那一帧）。 -/
def L0_start : World := (frameAt (byStep 1).prev).world
def L0_board : Board := levelBoard 0

/-- 开局之后、过关那一脚之前的 14 步：（动作, 动作之后看到的那一帧）。 -/
def L0_play : List (Act × SeenWorld) := playFrom 1 14

/-- 路 + 过关那一脚（步号 15，.push .left）。 -/
def L0_acts : List Act := L0_play.map Prod.fst ++ [.push .left]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L0_len : (L0_play : List (Act × SeenWorld)).length = 14 := by decide +kernel

/-- **模型沿着真人的路一步不差**：14 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L0_trace : traceOk step L0_board (L0_start : World) L0_play = true := by
  decide +kernel

/-- **第 0 关走得通。** 见证：那 14 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L0_winnable : Winnable L0_board (L0_start : World) :=
  ⟨L0_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L0_len
#print axioms Game.Levels.L0_trace
#print axioms Game.Levels.L0_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L0_board L0_start L0_play 0, L0_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 1 关的真实开局（步号 16 那一步之前的那一帧）。 -/
def L1_start : World := (frameAt (byStep 16).prev).world
def L1_board : Board := levelBoard 1

/-- 开局之后、过关那一脚之前的 10 步：（动作, 动作之后看到的那一帧）。 -/
def L1_play : List (Act × SeenWorld) := playFrom 16 10

/-- 路 + 过关那一脚（步号 26，.push .down）。 -/
def L1_acts : List Act := L1_play.map Prod.fst ++ [.push .down]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L1_len : (L1_play : List (Act × SeenWorld)).length = 10 := by decide +kernel

/-- **模型沿着真人的路一步不差**：10 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L1_trace : traceOk step L1_board (L1_start : World) L1_play = true := by
  decide +kernel

/-- **第 1 关走得通。** 见证：那 10 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L1_winnable : Winnable L1_board (L1_start : World) :=
  ⟨L1_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L1_len
#print axioms Game.Levels.L1_trace
#print axioms Game.Levels.L1_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L1_board L1_start L1_play 0, L1_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 2 关的真实开局（步号 27 那一步之前的那一帧）。 -/
def L2_start : World := (frameAt (byStep 27).prev).world
def L2_board : Board := levelBoard 2

/-- 开局之后、过关那一脚之前的 39 步：（动作, 动作之后看到的那一帧）。 -/
def L2_play : List (Act × SeenWorld) := playFrom 27 39

/-- 路 + 过关那一脚（步号 66，.push .down）。 -/
def L2_acts : List Act := L2_play.map Prod.fst ++ [.push .down]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L2_len : (L2_play : List (Act × SeenWorld)).length = 39 := by decide +kernel

/-- **模型沿着真人的路一步不差**：39 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L2_trace : traceOk step L2_board (L2_start : World) L2_play = true := by
  decide +kernel

/-- **第 2 关走得通。** 见证：那 39 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L2_winnable : Winnable L2_board (L2_start : World) :=
  ⟨L2_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L2_len
#print axioms Game.Levels.L2_trace
#print axioms Game.Levels.L2_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L2_board L2_start L2_play 0, L2_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 3 关的真实开局（步号 67 那一步之前的那一帧）。 -/
def L3_start : World := (frameAt (byStep 67).prev).world
def L3_board : Board := levelBoard 3

/-- 开局之后、过关那一脚之前的 21 步：（动作, 动作之后看到的那一帧）。 -/
def L3_play : List (Act × SeenWorld) := playFrom 67 21

/-- 路 + 过关那一脚（步号 88，.push .right）。 -/
def L3_acts : List Act := L3_play.map Prod.fst ++ [.push .right]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L3_len : (L3_play : List (Act × SeenWorld)).length = 21 := by decide +kernel

/-- **模型沿着真人的路一步不差**：21 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L3_trace : traceOk step L3_board (L3_start : World) L3_play = true := by
  decide +kernel

/-- **第 3 关走得通。** 见证：那 21 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L3_winnable : Winnable L3_board (L3_start : World) :=
  ⟨L3_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L3_len
#print axioms Game.Levels.L3_trace
#print axioms Game.Levels.L3_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L3_board L3_start L3_play 0, L3_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 4 关的真实开局（步号 89 那一步之前的那一帧）。 -/
def L4_start : World := (frameAt (byStep 89).prev).world
def L4_board : Board := levelBoard 4

/-- 开局之后、过关那一脚之前的 27 步：（动作, 动作之后看到的那一帧）。 -/
def L4_play : List (Act × SeenWorld) := playFrom 89 27

/-- 路 + 过关那一脚（步号 116，.push .left）。 -/
def L4_acts : List Act := L4_play.map Prod.fst ++ [.push .left]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L4_len : (L4_play : List (Act × SeenWorld)).length = 27 := by decide +kernel

/-- **模型沿着真人的路一步不差**：27 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L4_trace : traceOk step L4_board (L4_start : World) L4_play = true := by
  decide +kernel

/-- **第 4 关走得通。** 见证：那 27 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L4_winnable : Winnable L4_board (L4_start : World) :=
  ⟨L4_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L4_len
#print axioms Game.Levels.L4_trace
#print axioms Game.Levels.L4_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L4_board L4_start L4_play 0, L4_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 5 关的真实开局（步号 117 那一步之前的那一帧）。 -/
def L5_start : World := (frameAt (byStep 117).prev).world
def L5_board : Board := levelBoard 5

/-- 开局之后、过关那一脚之前的 52 步：（动作, 动作之后看到的那一帧）。 -/
def L5_play : List (Act × SeenWorld) := playFrom 117 52

/-- 路 + 过关那一脚（步号 169，.push .left）。 -/
def L5_acts : List Act := L5_play.map Prod.fst ++ [.push .left]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L5_len : (L5_play : List (Act × SeenWorld)).length = 52 := by decide +kernel

/-- **模型沿着真人的路一步不差**：52 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L5_trace : traceOk step L5_board (L5_start : World) L5_play = true := by
  decide +kernel

/-- **第 5 关走得通。** 见证：那 52 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L5_winnable : Winnable L5_board (L5_start : World) :=
  ⟨L5_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L5_len
#print axioms Game.Levels.L5_trace
#print axioms Game.Levels.L5_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L5_board L5_start L5_play 0, L5_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 6 关的真实开局（步号 170 那一步之前的那一帧）。 -/
def L6_start : World := (frameAt (byStep 170).prev).world
def L6_board : Board := levelBoard 6

/-- 开局之后、过关那一脚之前的 36 步：（动作, 动作之后看到的那一帧）。 -/
def L6_play : List (Act × SeenWorld) := playFrom 170 36

/-- 路 + 过关那一脚（步号 206，.push .right）。 -/
def L6_acts : List Act := L6_play.map Prod.fst ++ [.push .right]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L6_len : (L6_play : List (Act × SeenWorld)).length = 36 := by decide +kernel

/-- **模型沿着真人的路一步不差**：36 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L6_trace : traceOk step L6_board (L6_start : World) L6_play = true := by
  decide +kernel

/-- **第 6 关走得通。** 见证：那 36 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L6_winnable : Winnable L6_board (L6_start : World) :=
  ⟨L6_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L6_len
#print axioms Game.Levels.L6_trace
#print axioms Game.Levels.L6_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L6_board L6_start L6_play 0, L6_play.length)

namespace Game.Levels
open Game.Replay

/-- 第 7 关的真实开局（步号 207 那一步之前的那一帧）。 -/
def L7_start : World := (frameAt (byStep 207).prev).world
def L7_board : Board := levelBoard 7

/-- 开局之后、过关那一脚之前的 46 步：（动作, 动作之后看到的那一帧）。 -/
def L7_play : List (Act × SeenWorld) := playFrom 207 46

/-- 路 + 过关那一脚（步号 253，.push .up）。 -/
def L7_acts : List Act := L7_play.map Prod.fst ++ [.push .up]

end Game.Levels

open Game Game.Levels

theorem Game.Levels.L7_len : (L7_play : List (Act × SeenWorld)).length = 46 := by decide +kernel

/-- **模型沿着真人的路一步不差**：46 步，只有开局那一帧是观测给的。 -/
theorem Game.Levels.L7_trace : traceOk step L7_board (L7_start : World) L7_play = true := by
  decide +kernel

/-- **第 7 关走得通。** 见证：那 46 步再加过关那一脚，从开局算下去中途赢了。 -/
theorem Game.Levels.L7_winnable : Winnable L7_board (L7_start : World) :=
  ⟨L7_acts, by decide +kernel, by decide +kernel⟩

#print axioms Game.Levels.L7_len
#print axioms Game.Levels.L7_trace
#print axioms Game.Levels.L7_winnable

-- 读数（求值器，不是证明）：第一处分家在第几步（none = 一处都没分家）
#eval (firstSplit step L7_board L7_start L7_play 0, L7_play.length)

