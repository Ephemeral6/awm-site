/-
# PushCostsOne —— 推一下用掉一格（对应 `rule/budget/push_costs_one.py`）

**这是定义。** 计数带 64 格；推得动的一推用掉一格。用满之后再推会怎样，语料里没有（最多用到 53 格）
——模型在那一支上**不说话**。

「点一下不花钱」**不在这里**：它不是一条独立的规则，是点的定义只改 `sel` 的推论
（`Derived/ClickIsFree.lean`）。
-/
import Obj.World

namespace Game

/-- 计数带的格数。 -/
def BUDGET : Nat := 64

/-- 还推得动吗（计数带没用满）。 -/
def canSpend (w : World) : Bool := w.used < BUDGET

/-- 推一下：用掉一格。 -/
def spend (w : World) : World := { w with used := w.used + 1 }

end Game
