/-
# PushMovesSelected —— 推：被选中的那一件走一格（对应 `rule/move/push_moves_selected.py`）

**这是定义，不是定理。** 「推一下被选中的那件走一格」就是「推」的意思。

    物件   整体平移一格（任何一块出盘 ⇒ 说不准；撞上另一片 ⇒ 说不准）
    带     换到相邻那条线：横带只能上下、竖带只能左右（推向自己的方向 ⇒ 说不准）；
           新线出盘、新线上已有一条带、这条带画成推不动 ⇒ 说不准

「说不准」一律是 `none`：模型在这几支上**不说话**，而不是说「不动」。
这一批语料里这几支各 0 次（`analysis/record.txt` 第 4 轮「这批语料说不了的」）。

计数带不在这里（`Rule/Budget/PushCostsOne.lean`），赢不赢不在这里（`Rule/Win/LevelClear.lean`）。
-/
import Obj.World

namespace Game

inductive Dir
  | up | down | left | right
deriving DecidableEq, BEq, Repr

/-- 一块朝某个方向走一格；出盘 ⇒ `none`。 -/
def stepCell : Dir → Cell → Option Cell
  | .up, x    => if rowOf x ≥ 1 then some (x - STRIDE) else none
  | .down, x  => if rowOf x + 1 < NB then some (x + STRIDE) else none
  | .left, x  => if colOf x ≥ 1 then some (x - 1) else none
  | .right, x => if colOf x + 1 < NB then some (x + 1) else none

/-- 一串块整体走一格；有一块出盘 ⇒ `none`。 -/
def stepCells (d : Dir) : List Cell → Option (List Cell)
  | [] => some []
  | x :: xs => match stepCell d x, stepCells d xs with
    | some y, some ys => some (y :: ys)
    | _, _ => none

/-- 一条线朝某个方向挪一格；方向不对或出盘 ⇒ `none`。 -/
def stepLine : Dir → Line → Option Line
  | .up, l    => if l.horiz ∧ l.k ≥ 1 then some { l with k := l.k - 1 } else none
  | .down, l  => if l.horiz ∧ l.k + 1 < NB then some { l with k := l.k + 1 } else none
  | .left, l  => if !l.horiz ∧ l.k ≥ 1 then some { l with k := l.k - 1 } else none
  | .right, l => if !l.horiz ∧ l.k + 1 < NB then some { l with k := l.k + 1 } else none

/-- 推被选中的那条带（它是 `bands` 里第 `i` 条）。 -/
def pushBand (b : Board) (w : World) (i : Nat) (d : Dir) : Option World :=
  match w.bands[i]? with
  | none => none
  | some x =>
    if b.frozen.contains x.line then none else
    match stepLine d x.line with
    | none => none
    | some l' =>
      if w.bands.any (fun y => y.line == l') then none
      else some { w with bands := w.bands.set i { line := l' } }

/-- 推被选中的那片物件（它是 `pieces` 里第 `j` 片）。 -/
def pushPiece (w : World) (j : Nat) (d : Dir) : Option World :=
  match w.pieces[j]? with
  | none => none
  | some p =>
    match stepCells d p.cells with
    | none => none
    | some cs =>
      let others := minusMask w.body p.mask
      if maskOf cs &&& others != 0 then none
      else some { w with pieces := w.pieces.set j { cells := cs } }

/-- **推**：被选中的那一件走一格，别的一概不动，选中的还是它（下标不变）。 -/
def push (b : Board) (w : World) (d : Dir) : Option World :=
  if w.sel < w.bands.length then pushBand b w w.sel d
  else pushPiece w (w.sel - w.bands.length) d

end Game
