/-
# ClickSelects —— 点：选中换成点中的那一件（对应 `rule/move/click_selects.py`）

**这是定义。** 点中块上**画在最上面**的是物件就是那片物件，是带就是**那一条带**。

    像素 (x, y) → 块 (y / 3, x / 3)            折算只在这一处（动作坐标是像素）
    最上层：物件 > 镜像 > 带 > 目标 > 底色      和 `derive/render.py` 的边框优先级同一条
    点在盘外 / 镜像 / 目标 / 底色 / 两条带的交点   说不准（`none`）

别的一格不动——这不是一句要另证的话，是这个定义只改 `sel` 一个字段
（它的推论在 `Derived/ClickIsFree.lean`）。
-/
import Obj.Derive.BandCells
import Obj.Derive.Ghosts

namespace Game

/-- 一块像素几格。**折算**：动作坐标是像素，世界是块。 -/
def PX : Nat := 3

/-- 第一个满足条件的下标。 -/
def firstIx {α} (p : α → Bool) : List α → Nat → Option Nat
  | [], _ => none
  | a :: as, i => if p a then some i else firstIx p as (i + 1)

/-- 点中那一件在 `bands ++ pieces` 里的下标；说不准返回 `none`。 -/
def clickedIx (b : Board) (w : World) (x y : Nat) : Option Nat :=
  if y / PX ≥ NB ∨ x / PX ≥ NB then none else
  match firstIx (fun p => memMask p.mask (cellAt (y / PX) (x / PX))) w.pieces 0 with
  | some j => some (w.bands.length + j)
  | none =>
    match ghostMask w with
    | none => none
    | some g =>
      if memMask g (cellAt (y / PX) (x / PX)) then none else
      match w.bands.filter (fun z => memMask (bandMask b z) (cellAt (y / PX) (x / PX))) with
      | [z] => firstIx (fun u => u == z) w.bands 0
      | _ => none

/-- **点**：选中换成点中的那一件，别的字段原样。 -/
def click (b : Board) (w : World) (x y : Nat) : Option World :=
  match clickedIx b w x y with
  | some i => some { w with sel := i }
  | none => none

end Game
