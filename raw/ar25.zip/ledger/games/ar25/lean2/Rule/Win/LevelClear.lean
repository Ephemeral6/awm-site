/-
# LevelClear —— 什么算赢（对应 `rule/win/level_clear.py` 与 `derive/cover.py`）

**这是赢的定义，不是一条要证的话。** 而且是**状态**的性质：

    isGoal b w  ⇔  目标非空，且每一块目标都被物件本体或它的镜像盖住

写成状态性质（而不是「换关」那个转移事件），「这个局面赢不赢得了」才问得出来。
镜像说不准（平行轴）时 `isGoal = false`——那是「说不准」被折成了「没赢」，
这一局的语料里一次都没发生（每一关的轴都是一条，或一横一竖）。
-/
import Obj.Derive.Ghosts

namespace Game

def isGoal (b : Board) (w : World) : Bool :=
  match ghostMask w with
  | some g => b.targets != 0 && subMask b.targets (w.body ||| g)
  | none => false

end Game
