/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    推  (ACTION1–4)   计数带没满 → 被选中的那一件走一格（Rule/Move/PushMovesSelected）
                      → 用掉一格（Rule/Budget/PushCostsOne）→ 盖满了就是赢（Rule/Win/LevelClear）
    点  (ACTION6)     选中换成点中的那一件（Rule/Move/ClickSelects）

结果三种：`ok`（走到了某个状态）、`won`（这一步盖满了：下一帧是另一关，模型不描述它）、
`unknown`（**模型说不出话**：推出盘外、点在空白处……这一批语料里没有的那些）。

ACTION5 / ACTION7 / RESET **不在 `Act` 里**：这批语料一次都没有，它们是 `offmodel/` 的话，不进模型。
-/
import Rule.Move.PushMovesSelected
import Rule.Move.ClickSelects
import Rule.Budget.PushCostsOne
import Rule.Win.LevelClear

namespace Game

inductive Act
  | push (d : Dir)
  | click (x y : Nat)
deriving DecidableEq, BEq, Repr

inductive Res
  | ok (w : World)
  | won
  | unknown
deriving DecidableEq, BEq, Repr

/-- 推完之后：盖满了就是赢，否则走到这个状态。 -/
def settle (b : Board) (w : World) : Res := if isGoal b w then .won else .ok w

def step (b : Board) (w : World) : Act → Res
  | .push d => if canSpend w then (match push b w d with
      | some w' => settle b (spend w')
      | none => .unknown) else .unknown
  | .click x y => match click b w x y with
      | some w' => .ok w'
      | none => .unknown

end Game
