/-
# Check —— 判据层：两把尺子（**0 条定理**，尺子不自证）

    agrees      **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比
    traceOk     **一整条路**对不对：从开局起带着**自己算出来的状态**往下走，逐帧比

两把尺子的分量差得很远：`agrees` 每一步都被观测拉回正轨；`traceOk` 只有开局那一帧是观测给的。
一个「每步单独看都对、走两步就和现实分家」的模型，在前者满分，在后者过不了。

尺子吃的是一个 `stepFn` 参数，不直接写死 `step`：**判据不依赖被判的那一份**，
同一把尺子可以量模型、也可以量破坏测试里改坏的那一份。

## `SeenWorld`：一帧**看得见**的世界

    bands / pieces / sel / used      解析（`objects/parse.py`）从帧上读出来的状态
    ghosts                           帧上色 4 的块（掩码）——**模型算出来的镜像要和它逐块相等**

比的时候：带和物件**按集合比**（观测那边按左上角排、模型自己保持原来的先后，先后不是帧上的信息）；
选中**比那一件是谁**（哪条线 / 哪一片），不比下标。
-/
import Step

namespace Game

/-- 一帧看得见的世界。`sel` 是观测那一边 `bands ++ pieces` 的下标。 -/
structure SeenWorld where
  bands  : List Band
  pieces : List Piece
  sel    : Nat
  used   : Nat
  ghosts : Nat
deriving DecidableEq, BEq, Repr

/-- 从观测起算的那个世界（逐条判用它当 `prev`，每关判用它当开局）。 -/
def SeenWorld.world (o : SeenWorld) : World :=
  { bands := o.bands, pieces := o.pieces, sel := o.sel, used := o.used }

/-- 被选中的是谁：一条线，或一片物件的掩码。 -/
inductive Who
  | band (l : Line)
  | piece (m : Nat)
  | nobody
deriving DecidableEq, BEq, Repr

def whoOf (bands : List Band) (pieces : List Piece) (sel : Nat) : Who :=
  if sel < bands.length then
    match bands[sel]? with
    | some x => .band x.line
    | none => .nobody
  else
    match pieces[sel - bands.length]? with
    | some p => .piece p.mask
    | none => .nobody

/-- 两串掩码作为集合相等（每片物件互不重叠，所以「一样长 + 互相包含」就够）。 -/
def sameMasks (a b : List Nat) : Bool :=
  a.length == b.length && a.all (fun m => b.contains m) && b.all (fun m => a.contains m)

def sameLines (a b : List Line) : Bool :=
  a.length == b.length && a.all (fun l => b.contains l) && b.all (fun l => a.contains l)

/-- 模型算出来的世界 `w`，和看到的这一帧 `o` 对不对得上。 -/
def seenAs (w : World) (o : SeenWorld) : Bool :=
  sameLines w.lines (o.bands.map (·.line))
  && sameMasks (w.pieces.map (·.mask)) (o.pieces.map (·.mask))
  && whoOf w.bands w.pieces w.sel == whoOf o.bands o.pieces o.sel
  && w.used == o.used
  && ghostMask w == some o.ghosts

/-- 语料里的一条转移。`up` = 这一步换关了（下一帧是另一关的盘，模型说的该是 `won`）。 -/
structure Case where
  seq   : Nat
  board : Board
  prev  : SeenWorld
  act   : Act
  next  : SeenWorld
  up    : Bool

/-- 一条转移对不对。**每一支都要对上一种观测**，没有「算不出来就算它对」的那一支：
    模型说 `unknown` 就是没对上。 -/
def agrees (stepFn : Board → World → Act → Res) (c : Case) : Bool :=
  match stepFn c.board c.prev.world c.act with
  | .ok w  => !c.up && seenAs w c.next
  | .won   => c.up
  | .unknown => false

/-- 从 `w` 出发沿 `play` 走，每一步都和当时看到的那一帧比。全对才是 `true`。
    **下一轮喂进去的是模型自己算出来的 `w'`**，不是观测到的那一帧。 -/
def traceOk (stepFn : Board → World → Act → Res) (b : Board) : World → List (Act × SeenWorld) → Bool
  | _, [] => true
  | w, (a, o) :: rest =>
    match stepFn b w a with
    | .ok w' => seenAs w' o && traceOk stepFn b w' rest
    | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，不是证明。 -/
def firstSplit (stepFn : Board → World → Act → Res) (b : Board) :
    World → List (Act × SeenWorld) → Nat → Option Nat
  | _, [], _ => none
  | w, (a, o) :: rest, i =>
    match stepFn b w a with
    | .ok w' => if seenAs w' o then firstSplit stepFn b w' rest (i + 1) else some i
    | _ => some i

end Game
