/-
# Corpus —— 逐条：每一条真实转移，模型都对（自动生成：`python lean2/export_corpus.py`，不要手改）

    C<n>_agrees     第 n 关的每一条转移 `agrees step` 为真（253 条分到 8 关）

每一条都从**观测到的那一帧**起算（被观测拉回正轨），所以它比 `Proof/Levels.lean` 的 `_trace` 弱；
它多核的一件事是**换关那一步**：模型要在那一步说 `won`（每关那一层不走那一步）。
另一件：语料里没有的动作（ACTION5 / ACTION7 / RESET）这里一条都没有——`Act` 里本来就没有它们。
-/
import Obs.Replay
import Obj.World

namespace Game
namespace Corpus

open Replay

set_option maxRecDepth 20000

/-- 第 n 关的全部用例（按步号，含换关那一步）。 -/
def casesOf (n : Nat) : List Case := (steps.filter (fun s => s.lvl == n)).map caseOf

end Corpus
end Game

open Game Game.Replay Game.Corpus

-- 定理一律写全名：装置的公理表探针按源码里的名字 `#print axioms`，不带 `open`。

/-- 第 0 关：15 条转移（步号 1–15，最后一条是换关）。 -/
theorem Game.Corpus.C0_agrees : (casesOf 0).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C0_count :
    (casesOf 0 : List Case).length = 15 ∧ (casesOf 0).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C0_agrees⟩

#print axioms Game.Corpus.C0_agrees
#print axioms Game.Corpus.C0_count

/-- 第 1 关：11 条转移（步号 16–26，最后一条是换关）。 -/
theorem Game.Corpus.C1_agrees : (casesOf 1).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C1_count :
    (casesOf 1 : List Case).length = 11 ∧ (casesOf 1).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C1_agrees⟩

#print axioms Game.Corpus.C1_agrees
#print axioms Game.Corpus.C1_count

/-- 第 2 关：40 条转移（步号 27–66，最后一条是换关）。 -/
theorem Game.Corpus.C2_agrees : (casesOf 2).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C2_count :
    (casesOf 2 : List Case).length = 40 ∧ (casesOf 2).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C2_agrees⟩

#print axioms Game.Corpus.C2_agrees
#print axioms Game.Corpus.C2_count

/-- 第 3 关：22 条转移（步号 67–88，最后一条是换关）。 -/
theorem Game.Corpus.C3_agrees : (casesOf 3).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C3_count :
    (casesOf 3 : List Case).length = 22 ∧ (casesOf 3).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C3_agrees⟩

#print axioms Game.Corpus.C3_agrees
#print axioms Game.Corpus.C3_count

/-- 第 4 关：28 条转移（步号 89–116，最后一条是换关）。 -/
theorem Game.Corpus.C4_agrees : (casesOf 4).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C4_count :
    (casesOf 4 : List Case).length = 28 ∧ (casesOf 4).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C4_agrees⟩

#print axioms Game.Corpus.C4_agrees
#print axioms Game.Corpus.C4_count

/-- 第 5 关：53 条转移（步号 117–169，最后一条是换关）。 -/
theorem Game.Corpus.C5_agrees : (casesOf 5).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C5_count :
    (casesOf 5 : List Case).length = 53 ∧ (casesOf 5).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C5_agrees⟩

#print axioms Game.Corpus.C5_agrees
#print axioms Game.Corpus.C5_count

/-- 第 6 关：37 条转移（步号 170–206，最后一条是换关）。 -/
theorem Game.Corpus.C6_agrees : (casesOf 6).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C6_count :
    (casesOf 6 : List Case).length = 37 ∧ (casesOf 6).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C6_agrees⟩

#print axioms Game.Corpus.C6_agrees
#print axioms Game.Corpus.C6_count

/-- 第 7 关：47 条转移（步号 207–253，最后一条是换关）。 -/
theorem Game.Corpus.C7_agrees : (casesOf 7).all (agrees step) = true := by decide +kernel

theorem Game.Corpus.C7_count :
    (casesOf 7 : List Case).length = 47 ∧ (casesOf 7).all (agrees step) = true :=
  ⟨by decide +kernel, Game.Corpus.C7_agrees⟩

#print axioms Game.Corpus.C7_agrees
#print axioms Game.Corpus.C7_count

-- 读数：每一关（关号, 对上几条, 共几条, 第一条没对上的步号）。求值器算的，**不是证明**；证明是上面的 `C<n>_agrees`。
#eval (List.range 8).map (fun n =>
  (n, ((casesOf n).filter (agrees step)).length, (casesOf n).length,
   ((casesOf n).find? (fun c => !agrees step c)).map (·.seq)))
