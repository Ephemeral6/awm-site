"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源（第 1-8 步）：
    玩家 = 色9 的 8 格 + 色4 的 1 格，合起来是一个 3x3 实心块；色4 占该块的一条边的中点。
    第 4 步 ACTION4：整块 Δ(0,+6)，原位变色0。
    第 7 步 ACTION2：整块 Δ(+6,0)，原位变色0，色4 从右中位移到下中位。
    ACTION1 / ACTION3 至今没生效过（第 1、3、6、8 步都只扣 HUD），所以它们的 DELTA 是**猜的**，
    按「上 / 左」填，等世界来打。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 6               # 一次生效移动的格数（第 4、7 步实测 |Δ| = 6）
BLOCK = 3              # 玩家块 / 地砖块的边长（实测 3x3）

PLAYER = 9             # 玩家块主体色
MARK = 4               # 玩家块上的单格记号，占块内某条边的中点
TARGET = 14            # 全图唯一的另一个 3x3 实心块（开局在 (45,45)）
FOE = 8                # 第 1 关起出现的第二个 3x3 块：会动，撞上就 GAME_OVER
FOE_MARK = 15          # 敌人块上的单格记号，和玩家的色4 同构：指它下一步要走的方向
GAME_OVER_STATE = "GAME_OVER"
HUD_ROW = 63           # 行 63 整行：开局 64 格色6，每步从右端起变色0
HUD_COLOR = 6

# 猜的部分：只有 ACTION2 / ACTION4 有实测支撑
DELTA = {
    "ACTION1": (-CELL, 0),
    "ACTION2": (CELL, 0),
    "ACTION3": (0, -CELL),
    "ACTION4": (0, CELL),
}

# 记号相对块左上角的偏移 -> 方向名。实测：右中位 (1,2)、下中位 (2,1)。
# 上中位 (0,1)、左中位 (1,0) 是按对称补的，没见过。
MARK_OFFSET = {
    (0, 1): (-CELL, 0),
    (2, 1): (CELL, 0),
    (1, 0): (0, -CELL),
    (1, 2): (0, CELL),
}


GRID0 = 15             # 第 0 关的阵列原点。**别直接用**——第 1 关的阵列不在这里。
PITCH = 3              # 块间距 = 块边长
BRIDGE = 2             # 桥色（节点之间的连接块）
NODE = 0               # 节点色（可站的落点）


def grid_origin(g):
    """阵列的相位原点：用玩家块自己的位置反推，而不是抄上一关的常数。

    玩家永远站在一个块角上（19 步实测都是），所以 (me % PITCH) 就是这一关的相位。
    方法册「不继承上一关的常数」：GRID0 是第 0 关量出来的，第 1 关的阵列不在那里。
    """
    a = me(g)
    if a is None:
        return None
    return (a[0] % PITCH, a[1] % PITCH)


def on_grid(top, left, g=None):
    """(top,left) 是不是块阵列上的一个块角。

    给了 g 就用这一帧自己的相位（grid_origin）；没给才退回 GRID0——
    退回那一支只对第 0 关成立，是已知的债。
    """
    if g is not None:
        o = grid_origin(g)
        if o is None:
            return False
        return top % PITCH == o[0] and left % PITCH == o[1]
    return (top - GRID0) % PITCH == 0 and (left - GRID0) % PITCH == 0


def block_color(g, top, left):
    """(top,left) 起的 PITCH×PITCH 块若是纯色就返回该色，越界或不纯返回 None。"""
    if top < 0 or left < 0 or top + PITCH > len(g) or left + PITCH > len(g[0]):
        return None
    vals = {g[top + dr][left + dc] for dr in range(PITCH) for dc in range(PITCH)}
    return vals.pop() if len(vals) == 1 else None


def mark_cell_for(top, left, action):
    """块 (top,left) 上，动作 action 对应的那条边的中点绝对坐标；动作不在表里返回 None。

    共享词：mark_faces 用它做主张，move_shift 用它把这一格让出去（免得两条概念在同一格打架）。
    概念之间不能互相 import——predict 路径下 sys.path 里只有 _lib。
    """
    d = DELTA.get(action)
    if d is None:
        return None
    for off, dd in MARK_OFFSET.items():
        if dd == d:
            return (top + off[0], left + off[1])
    return None


def _block_of(g, color):
    """色 color 的所有格子的 bbox 左上角；没有该色返回 None。"""
    cs = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == color]
    if not cs:
        return None
    return (min(r for r, _ in cs), min(c for _, c in cs))


def me(g):
    """玩家块的 (top_row, left_col)：色9 与色4 合起来的 bbox 左上角。

    只在两者合起来恰好铺满一个 3x3（9 格）时给答案，否则 None——
    「色4 一定嵌在玩家块里」本身是假设，不满足时宁可闭嘴。
    """
    cs = [(r, c) for r, row in enumerate(g)
          for c, v in enumerate(row) if v in (PLAYER, MARK)]
    if len(cs) != BLOCK * BLOCK:
        return None
    top, left = min(r for r, _ in cs), min(c for _, c in cs)
    if set(cs) != {(top + dr, left + dc)
                   for dr in range(BLOCK) for dc in range(BLOCK)}:
        return None
    return (top, left)


def facing(g):
    """色4 记号指的方向，返回 DELTA 里的那种 (dr, dc)；读不出来返回 None。"""
    a = me(g)
    if a is None:
        return None
    m = _block_of(g, MARK)
    if m is None:
        return None
    return MARK_OFFSET.get((m[0] - a[0], m[1] - a[1]))


def target(g):
    """目标块 (top_row, left_col)；不存在返回 None。"""
    return _block_of(g, TARGET)


def foe(g):
    """敌人块（色8 + 色15）的 (top_row, left_col)。

    和 me() 同构：只在两色合起来恰好铺满一个 BLOCK×BLOCK 时给答案。
    第 0 关没有敌人，返回 None——那是对的，不是失败。
    """
    cs = [(r, c) for r, row in enumerate(g)
          for c, v in enumerate(row) if v in (FOE, FOE_MARK)]
    if len(cs) != BLOCK * BLOCK:
        return None
    top, left = min(r for r, _ in cs), min(c for _, c in cs)
    if set(cs) != {(top + dr, left + dc)
                   for dr in range(BLOCK) for dc in range(BLOCK)}:
        return None
    return (top, left)


def foe_mark_offset(g):
    """色15 记号相对敌人块左上角的偏移；读不出来返回 None。"""
    f = foe(g)
    m = _block_of(g, FOE_MARK)
    if f is None or m is None:
        return None
    return (m[0] - f[0], m[1] - f[1])


def foe_facing(g):
    """敌人记号指的方向，返回 DELTA 里的那种 (dr, dc)；读不出来返回 None。

    和玩家的 facing() 共用同一张 MARK_OFFSET 表——这是个**假设**：
    两种记号的读法相同。它没被单独检验过，foe_walks 就是在赌它。
    """
    off = foe_mark_offset(g)
    return None if off is None else MARK_OFFSET.get(off)


PATROL = 12            # 第 3 关起出现的第三种 3x3 块：和色8 同构（8格 + 1格色15）


def _entities(g, body):
    """把「色 body 的格子 + 色15 记号」切成一个个 BLOCK×BLOCK 块。

    色8 和色12 可能同屏（第 3 关），色15 记号也就有多个；
    记号按「落在哪个块的范围里」归属，不靠 _block_of 的唯一性。
    返回 [(top, left), ...]，按 (top, left) 排序。
    """
    body_cs = [(r, c) for r, row in enumerate(g)
               for c, v in enumerate(row) if v == body]
    marks = [(r, c) for r, row in enumerate(g)
             for c, v in enumerate(row) if v == FOE_MARK]
    out = []
    seen = set()
    for r0, c0 in body_cs:
        for top in range(r0 - BLOCK + 1, r0 + 1):
            for left in range(c0 - BLOCK + 1, c0 + 1):
                if (top, left) in seen:
                    continue
                cells = {(top + dr, left + dc)
                         for dr in range(BLOCK) for dc in range(BLOCK)}
                if not all(0 <= r < len(g) and 0 <= c < len(g[0])
                           for r, c in cells):
                    continue
                got = {(r, c) for r, c in cells
                       if g[r][c] == body or (r, c) in marks}
                if got == cells and any((r, c) in marks for r, c in cells):
                    seen.add((top, left))
                    out.append((top, left))
    return sorted(out)


def patrols(g):
    """所有色12 巡逻兵块的 (top, left)，按位置排序；没有就是空表。"""
    return _entities(g, PATROL)


def foes(g):
    """所有色8 敌人块的 (top, left)，按位置排序；没有就是空表。

    和 foe() 的区别：foe() 只在全帧的色8+色15 恰好铺满**一个**块时才给答案，
    多只敌人同屏、或别的带色15 记号的块同屏时，它一律读不出来（返回 None）。
    """
    return _entities(g, FOE)


CHASER = 13            # 第 6 关起出现的第四种块：8格 + 1格记号
CHASER_ASLEEP = 15     # 记号是这个色 = 它休眠，不动
CHASER_AWAKE = 11      # 记号是这个色 = 它已唤醒，每步都动


def chasers(g):
    """所有色13 块的 (top, left)，按位置排序；没有就是空表。

    **不能用 _entities**：那个只认色15 记号，而这种块唤醒后记号会变成色11，
    于是它从块开始动的那一刻起就读不出来了——概念会在最该说话的每一步上返回 NA。
    """
    out = []
    for r in range(len(g) - BLOCK + 1):
        for c in range(len(g[0]) - BLOCK + 1):
            v = [g[r + dr][c + dc] for dr in range(BLOCK) for dc in range(BLOCK)]
            if v.count(CHASER) != BLOCK * BLOCK - 1:
                continue
            if CHASER_ASLEEP not in v and CHASER_AWAKE not in v:
                continue
            if any(abs(r - a) < BLOCK and abs(c - b) < BLOCK for a, b in out):
                continue
            out.append((r, c))
    return sorted(out)


def chaser_mark(g, top, left):
    """那只色13 块的记号 (色, 块内偏移)；读不出返回 (None, None)。"""
    for dr in range(BLOCK):
        for dc in range(BLOCK):
            v = g[top + dr][left + dc]
            if v in (CHASER_AWAKE, CHASER_ASLEEP):
                return v, (dr, dc)
    return None, None


def chaser_awake(g, top, left):
    """那只色13 块醒了没；读不出返回 None。"""
    col, _ = chaser_mark(g, top, left)
    return None if col is None else col == CHASER_AWAKE


def chaser_facing(g, top, left):
    """那只色13 块记号指的方向；读不出返回 None。"""
    _, off = chaser_mark(g, top, left)
    return None if off is None else MARK_OFFSET.get(off)


def cell_dist(p, q):
    """两个块左上角之间的曼哈顿距离，按格（CELL）计。"""
    return (abs(p[0] - q[0]) + abs(p[1] - q[1])) // CELL


BG = 5                 # 底色：占地最多、没人站的那一色


def majority_color(g, top, left):
    """块的多数色。block_color 遇到带记号的块返回 None，这个不会。"""
    if top < 0 or left < 0 or top + PITCH > len(g) or left + PITCH > len(g[0]):
        return None
    v = [g[top + dr][left + dc] for dr in range(PITCH) for dc in range(PITCH)]
    return max(set(v), key=v.count)


def bridge_graph(g):
    """这一帧的落点图：{块角: [相邻块角, ...]}，边 = 中点块的多数色是桥色。

    节点 = 阵列上多数色不是底色的块。和 bridge_gate 赌的是同一张图，
    只是那条概念每次只问一条边，这里把整张图铺开——**是同一个假设的两种用法**。
    """
    o = grid_origin(g)
    if o is None:
        return {}
    ns = set()
    for t in range(o[0], len(g) - PITCH + 1, PITCH):
        for l in range(o[1], len(g[0]) - PITCH + 1, PITCH):
            if majority_color(g, t, l) != BG:
                ns.add((t, l))
    adj = {}
    for n in ns:
        for d in DELTA.values():
            dst = (n[0] + d[0], n[1] + d[1])
            if dst not in ns:
                continue
            if majority_color(g, n[0] + d[0] // 2, n[1] + d[1] // 2) == BRIDGE:
                adj.setdefault(n, []).append(dst)
    return adj


def first_steps(adj, src, dst):
    """adj 上 src 走向 dst 的所有最短路第一步；不连通返回 None，同格返回空集。"""
    from collections import deque
    if src == dst:
        return set()
    dist = {dst: 0}
    q = deque([dst])
    while q:
        u = q.popleft()
        for v in adj.get(u, []):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    if src not in dist:
        return None
    return {v for v in adj.get(src, []) if dist.get(v, 1 << 30) == dist[src] - 1}


def patrol_facing(g, top, left):
    """(top,left) 那只巡逻兵的朝向；读不出来返回 None。

    记号读法沿用 MARK_OFFSET —— 和 foe_facing 赌的是同一个假设。
    """
    for dr in range(BLOCK):
        for dc in range(BLOCK):
            if g[top + dr][left + dc] == FOE_MARK:
                return MARK_OFFSET.get((dr, dc))
    return None


def patrol_next(g, top, left):
    """那只巡逻兵下一步落在哪：朝向上有桥就直行，没桥就反向走一格。

    走法沿用 patrol_turns 的主张（那条概念在这张图上判过 71 次），
    这里只是把「下一步在哪」抽成一个词，好让别的概念拿来当危险格用。
    朝向读不出返回 None。
    """
    f = patrol_facing(g, top, left)
    if f is None:
        return None
    dst = (top + f[0], left + f[1])
    if dst in bridge_graph(g).get((top, left), []):
        return dst
    return (top - f[0], left - f[1])


def hud_left(g):
    """HUD 带上还剩几格色6。行 63 之外的东西一概不看。"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_COLOR)


def walls(g):
    """阻挡格集合。待实测：ACTION1/ACTION3 至今零生效，分不清是出界还是墙。"""
    return None


# ======================================================================
# 修复（meta/repair-20260928）补的读数、隐藏状态与每关常数。
# 上面的原读数一个没删、一个没改义；下面只加。
# ======================================================================

def bridges(g):
    """桥块集合：帧上整块（3x3）都是桥色 2 的块的左上角 (r, c)。

    只看像素：3x3 全是色 2 的窗口只可能是一段桥（桥块两头都是落点、落点不是色 2，
    两段桥最多角对角相邻，拼不出错位的全 2 窗口）。玩家 / 守卫只站在落点上，不压桥，
    所以一关之内它不变；换关随新帧读出。
    """
    H = min(len(g), HUD_ROW)
    out = set()
    for r in range(H - PITCH + 1):
        row0, row1, row2 = g[r], g[r + 1], g[r + 2]
        for c in range(len(row0) - PITCH + 1):
            if (row0[c] == BRIDGE and row0[c + 1] == BRIDGE and row0[c + 2] == BRIDGE
                    and row1[c] == BRIDGE and row1[c + 1] == BRIDGE and row1[c + 2] == BRIDGE
                    and row2[c] == BRIDGE and row2[c + 1] == BRIDGE and row2[c + 2] == BRIDGE):
                out.add((r, c))
    return out


def chasers_awake(g):
    """帧上看得见的追兵（色13 块）里，记号是唤醒色 11 的有几只。只看像素。

    原读数 chasers() 只给位置，醒没醒（chaser_alarm / chaser_wakes 的话题）帧上看得见却没进状态，这里补上。"""
    return sum(1 for r, c in chasers(g) if chaser_awake(g, r, c))


# ---------- 守卫的完整读法（带朝向；下划线开头 = 不是读数，只给 hidden_step 用）----------
# 朝向编号：0 上、1 下、2 左、3 右（记号在块内 (0,1)/(2,1)/(1,0)/(1,2)）。
_DIR_AT = {(0, 1): 0, (2, 1): 1, (1, 0): 2, (1, 2): 3}
_DIR_D = {0: (-CELL, 0), 1: (CELL, 0), 2: (0, -CELL), 3: (0, CELL)}
_ACT_DIR = {"ACTION1": 0, "ACTION2": 1, "ACTION3": 2, "ACTION4": 3}
_BODY = {FOE: "s", PATROL: "p", CHASER: "c"}
_NS, _NP, _NC = 6, 4, 1     # 槽位数：哨兵（色8）6、巡逻（色12）4、追兵（色13）1——全语料各自同屏最多的只数


def _code(r, c, d, alert):
    """一只守卫编成一个整数：((r*64 + c)*4 + 朝向)*2 + 醒没醒。空槽 = -1。"""
    return ((r * 64 + c) * 4 + d) * 2 + (1 if alert else 0)


def _decode(x):
    a = x % 2
    d = (x // 2) % 4
    p = x // 8
    return p // 64, p % 64, d, a


def _guards(g):
    """帧上看得见的守卫：{'s': [...], 'p': [...], 'c': [...]}，每只 (r, c, 朝向, 醒没醒)，按位置排序。
    8 格主体色 + 1 格记号（15 静 / 11 动）且记号在边中点的 3x3 窗口。"""
    out = {"s": [], "p": [], "c": []}
    H = min(len(g), HUD_ROW)
    for r in range(H - BLOCK + 1):
        for c in range(len(g[0]) - BLOCK + 1):
            v = [g[r + dr][c + dc] for dr in range(BLOCK) for dc in range(BLOCK)]
            body = v[0] if v[0] == v[2] else v[6]
            if body not in _BODY or v.count(body) != BLOCK * BLOCK - 1:
                continue
            k = next(i for i, x in enumerate(v) if x != body)
            if v[k] not in (CHASER_ASLEEP, CHASER_AWAKE) or (k // 3, k % 3) not in _DIR_AT:
                continue
            out[_BODY[body]].append((r, c, _DIR_AT[(k // 3, k % 3)], v[k] == CHASER_AWAKE))
    for k in out:
        out[k].sort()
    return out


def _linked(br, r, c, d):
    """(r,c) 往朝向 d 那一格之间有没有桥（中间块是桥块）。"""
    dr, dc = _DIR_D[d]
    return (r + dr // 2, c + dc // 2) in br


def _first_step(br, frm, to):
    """桥图上 frm 走到 to 的最短路第一步的朝向；并列按 上、下、左、右 取第一个；到不了或同格返回 None。"""
    from collections import deque
    if frm == to:
        return None
    dist = {to: 0}
    q = deque([to])
    while q:
        u = q.popleft()
        for d in range(4):
            if _linked(br, u[0], u[1], d):
                v = (u[0] + _DIR_D[d][0], u[1] + _DIR_D[d][1])
                if v not in dist:
                    dist[v] = dist[u] + 1
                    q.append(v)
    if frm not in dist:
        return None
    for d in range(4):
        if _linked(br, frm[0], frm[1], d):
            v = (frm[0] + _DIR_D[d][0], frm[1] + _DIR_D[d][1])
            if dist.get(v) == dist[frm] - 1:
                return d
    return None


# ---------- 隐藏状态（判据修订 R1.1）----------
# 为什么要：守卫会互相压住（第 4 关四只巡逻在一个十字路口穿行，一帧常只看得见两三只；
# 巡逻压住目标、压住哨兵、压住追兵）。被压住的那只在帧上一个像素都没有，但它还在、还按规矩走，
# 下一帧可能又露出来——单帧读数说不出它在哪、朝哪。它由真实历史机械决定：
# 关开局那一帧所有守卫都看得见，之后每一步按下面的走法推。
# 键：ready（这一关推过没有）+ 每个槽位一只守卫的编码（_code；死了 / 空槽 = -1）。
HIDDEN_INIT = {"ready": 0, **{f"s{i}": -1 for i in range(_NS)}, **{f"p{i}": -1 for i in range(_NP)},
               **{f"c{i}": -1 for i in range(_NC)}}


def hidden_step(h, prev, action, nxt):
    """上一步的隐藏量 + 前帧 + 动作 → 这一步之后的隐藏量。只用这四样（nxt 不读）。

    ready == 0（关开局、reset 之后、run 开头）：先从前帧读出全部守卫填槽（按位置排序）。
    然后按一步的次序推（和规则段 stepRules 同一套走法）：
      1. 玩家（前帧读）往动作方向有桥 ⇒ 走；没桥 ⇒ 整个世界不动（守卫全不动）。
      2. 落点上的哨兵 / 巡逻，若进入方向与它的朝向垂直 ⇒ 被踩掉（槽位置 -1）。
      3. 巡逻：沿朝向有桥就走一格；到了之后前方没桥就掉头。
      4. 追兵：醒着 ⇒ 沿朝向有桥就走一格，然后朝向改指「到玩家动作之前那一格」的最短路第一步；
               睡着 ⇒ 玩家落点离它不超过 2 格（曼哈顿、按格计）就醒，朝向改指那条最短路的第一步；否则不动。
      5. 哨兵不动。
    槽位不重排：同一只守卫一直待在同一个槽里。
    """
    h = dict(h)
    if h["ready"] == 0:
        gs = _guards(prev)
        for key, n in (("s", _NS), ("p", _NP), ("c", _NC)):
            lst = gs[key]
            if len(lst) > n:
                raise ValueError(f"{key} 槽位不够：{len(lst)} > {n}")
            for i in range(n):
                h[f"{key}{i}"] = _code(*lst[i]) if i < len(lst) else -1
        h["ready"] = 1
    d = _ACT_DIR.get(action.split(":")[0].upper())
    pl = me(prev)
    if d is None or pl is None:
        return h
    br = bridges(prev)
    if not _linked(br, pl[0], pl[1], d):
        return h
    q = (pl[0] + _DIR_D[d][0], pl[1] + _DIR_D[d][1])
    # 2. 踩掉
    for key, n in (("s", _NS), ("p", _NP)):
        for i in range(n):
            x = h[f"{key}{i}"]
            if x < 0:
                continue
            r, c, gd, a = _decode(x)
            if (r, c) == q and (gd < 2) != (d < 2):
                h[f"{key}{i}"] = -1
    # 3. 巡逻
    for i in range(_NP):
        x = h[f"p{i}"]
        if x < 0:
            continue
        r, c, gd, a = _decode(x)
        if _linked(br, r, c, gd):
            r, c = r + _DIR_D[gd][0], c + _DIR_D[gd][1]
        if not _linked(br, r, c, gd):
            gd = gd ^ 1
        h[f"p{i}"] = _code(r, c, gd, a)
    # 4. 追兵
    for i in range(_NC):
        x = h[f"c{i}"]
        if x < 0:
            continue
        r, c, gd, a = _decode(x)
        if a:
            if _linked(br, r, c, gd):
                r, c = r + _DIR_D[gd][0], c + _DIR_D[gd][1]
            f = _first_step(br, (r, c), pl)
            gd = gd if f is None else f
        elif (abs(r - q[0]) + abs(c - q[1])) // CELL <= 2:
            a = 1
            f = _first_step(br, (r, c), pl)
            gd = gd if f is None else f
        h[f"c{i}"] = _code(r, c, gd, a)
    return h


# ---------- 每关常数（判据修订 R1.1，游戏内容：和换关后的布局同类）----------
# B    预算步数：本关第 k 步之后预算带剩 64 - round(64k/B)（.5 进位，= 64 - (128k + B) // (2B)）。
#      反推：run tu93-0909-1819 每关每次尝试（run 开头 / reset / 换关起算）的逐步 hud_left，
#      1..200 里能让全部尝试每一步都对上的 B 只有一个（探针 _scratch/tu93-20260910/probe2.py）：
#      第 0 关 seq 1/175/380 起 3 次；第 1 关 seq 25/30/199/398 起 4 次；第 2 关 seq 44/213/408 起 3 次；
#      第 3 关 seq 65/69/90/234/427 起 5 次；第 4 关 seq 107/251/444 起 3 次；第 5 关 seq 136/144/280/473 起 4 次；
#      第 6 关 seq 310/503 起 2 次；第 7 关 seq 328/517 起 2 次；第 8 关 seq 349/538 起 2 次。
# tr, tc  目标块左上角：本关开局帧的 target()（同一关每次开局都相同，出处同上那些 seq 的前帧）。
#      目标会被巡逻压住（帧上读不出），所以它的位置要从开局记下。
# s0..s5 / p0..p3 / c0  本关开局帧上的哨兵 / 巡逻 / 追兵（_code 编码，按位置排序，空槽 -1）；
#      出处同上那些 seq 的前帧，同一关每次开局读出的都相同。关内第一步 stepRules 用它们填隐藏槽位
#      （hidden_step 那一侧是直接读开局帧，两者相同）。
LEVEL_CONST = {
    0: {"B": 50, "tr": 45, "tc": 45, "s0": -1, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": -1, "p1": -1, "p2": -1, "p3": -1, "c0": -1},
    1: {"B": 50, "tr": 21, "tc": 48, "s0": 14116, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": -1, "p1": -1, "p2": -1, "p3": -1, "c0": -1},
    2: {"B": 35, "tr": 42, "tc": 24, "s0": 12486, "s1": 12530, "s2": 18534, "s3": -1, "s4": -1, "s5": -1,
        "p0": -1, "p1": -1, "p2": -1, "p3": -1, "c0": -1},
    3: {"B": 20, "tr": 22, "tc": 21, "s0": 8410, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": 11578, "p1": -1, "p2": -1, "p3": -1, "c0": -1},
    4: {"B": 50, "tr": 32, "tc": 27, "s0": -1, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": 13530, "p1": 16462, "p2": 16554, "p3": 19672, "c0": -1},
    5: {"B": 60, "tr": 18, "tc": 12, "s0": 15554, "s1": 15698, "s2": 21696, "s3": 21748, "s4": 24768, "s5": 24816,
        "p0": 12528, "p1": 21892, "p2": -1, "p3": -1, "c0": -1},
    6: {"B": 30, "tr": 30, "tc": 48, "s0": 12628, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": -1, "p1": -1, "p2": -1, "p3": -1, "c0": 9410},
    7: {"B": 50, "tr": 14, "tc": 26, "s0": 16546, "s1": -1, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": -1, "p1": -1, "p2": -1, "p3": -1, "c0": 10546},
    8: {"B": 50, "tr": 40, "tc": 33, "s0": 20702, "s1": 23768, "s2": -1, "s3": -1, "s4": -1, "s5": -1,
        "p0": 8412, "p1": 8556, "p2": 11626, "p3": -1, "c0": 11482},
}

# sover  画的先后：哨兵槽位的位掩码，第 i 位 = 1 表示第 i 只哨兵画在巡逻**上面**（两者同格时帧上看得见哨兵、看不见巡逻），
#      0 表示巡逻画在它上面。语料里哨兵与巡逻同格只发生在第 5 关、只涉及两只哨兵，全都是同一只巡逻（开局在 (42,48)）
#      走过去（探针 _scratch/tu93-20260910/sim.py --debug）：
#        · s3（(42,30)、朝左）：seq 138、146、152、158、164、282、288、294、300、475、481、487、493，帧上全是哨兵在上 ⇒ 第 3 位 = 1；
#        · s2（(42,24)、朝上）：seq 139、147、151、159、163、283、287、295、299、476、480、488、492，帧上全是巡逻在上 ⇒ 第 2 位 = 0。
#      其余各关没有哨兵与巡逻同格的观测，取 0（这一位在那些关不起作用，是选的不是量的）。
_SOVER = {5: 0b1000}
for _lv in LEVEL_CONST:
    LEVEL_CONST[_lv]["sover"] = _SOVER.get(_lv, 0)
