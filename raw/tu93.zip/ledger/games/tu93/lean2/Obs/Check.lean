/-
# Check —— 判据层：模型面对**一帧**站不站得住。**0 条定理**，尺子不自证。

两把尺子：

    agrees    一条转移：从**观测到的那一帧**读出一个状态，算一步，和下一帧比
    traceOk   一整条路：只有开局那一帧是观测给的，**后面全是模型自己算的**

## 一帧对应的是**一组**世界（纤维）

一格只画得下一只棋子：叠在一起的守卫帧上只看得见最上面那只，目标被巡逻压住就读不出来。
所以「模型算出来的状态」和「看到的那一帧」按下面这个口径比（`seenOk`）：

    · 帧上看得见的每只守卫，模型里都有一只一模一样的（同一种、同一格、同朝向、同醒没醒）；
    · 模型里的每只守卫，要么帧上看得见，要么它那一格被帧上某只棋子压住了；
    · 目标：帧上看得见就得是这一关的目标；看不见，就得有一只守卫压着那一格；
    · 玩家、玩家的记号、预算带、桥：逐字相等。

`traceOk` 带着模型自己算出来的完整状态走，这个口径就够了。
**逐条那一层多一个麻烦**：前一帧本身就可能藏着一只守卫，从它读出来的状态少一只，
下一帧那只露出来时模型说不出它从哪来。那时再问一句（`lenient`）：它是不是
「前一帧某只守卫底下可能藏着的那一只」走了一步？是 ⇒ 判 `fiber`（纤维里有一个世界对得上），
不是 ⇒ `bad`。玩家底下不许藏：守卫落到玩家身上是 GAME_OVER，不是压住。
前一帧目标被压住（这一帧的版面 `target = none`）而下一帧目标露出来，同样是 `fiber`：
前一帧的纤维里有目标在那一格的那个世界。
-/

import Step
import Obj.Derive.Budget

namespace Game

/-- 一帧看得见的东西。`fb` 指向 `Replay.boards`：这一帧**真正读到的**桥与目标。 -/
structure Obs where
  fb       : Nat
  player   : Cell
  facing   : Dir
  sentries : List Guard
  patrols  : List Guard
  chasers  : List Guard
  hud      : Nat
  deriving DecidableEq, Repr

def Obs.guardCells (o : Obs) : List Cell := (o.sentries ++ o.patrols ++ o.chasers).map (·.cell)

def Obs.occupied (o : Obs) : List Cell := o.player :: o.guardCells

def kindOk (occ : List Cell) (vis mdl : List Guard) : Bool :=
  vis.all (mdl.contains ·) && mdl.all (fun g => vis.contains g || occ.contains g.cell)

def targetOk (b fbd : Board) (o : Obs) : Bool :=
  match fbd.target with
  | some t => b.target == some t
  | none => match b.target with
    | none => true
    | some t => o.guardCells.contains t

/-- 模型算出来的状态 `s`（这一关的版面 `b`）对得上帧 `o`（它读到的版面 `fbd`）吗。 -/
def seenOk (b fbd : Board) (s : St) (o : Obs) : Bool :=
  fbd.bridges == b.bridges && o.player == s.player && o.facing == s.facing
  && o.hud == hudAt b.budget s.used && targetOk b fbd o
  && kindOk o.occupied o.sentries s.sentries && kindOk o.occupied o.patrols s.patrols
  && kindOk o.occupied o.chasers s.chasers

/-- 从一帧读出一个状态：看得见的守卫全算上，看不见的不知道；走了几步由预算带反推。 -/
def stateOf (b : Board) (o : Obs) : Option St :=
  (stepsUsed b.budget o.hud).map fun k =>
    { player := o.player, facing := o.facing, sentries := o.sentries, patrols := o.patrols,
      chasers := o.chasers, used := k }

/-! ## 逐条那一层的纤维：前一帧某只守卫底下可能藏着的那一只 -/

/-- 只假设**走得到的**状态：巡逻与醒着的追兵，记号永远指着一段桥；哨兵与巡逻的记号从不翻色；
    哨兵只可能藏在**会动的**守卫（巡逻 / 追兵）底下（两只哨兵叠一格只能是开局就叠着，而开局帧没有）。
    后一条不加的话，「一只哨兵原地转了个向」会被「它底下还藏着一只朝那边的」顶罪。 -/
def hiddenCands (b : Board) (s : St) (kind : Nat) : List Guard :=
  let cells := if kind == 0 then (s.patrols ++ s.chasers).map (·.cell)
    else (s.sentries ++ s.patrols ++ s.chasers).map (·.cell)
  cells.flatMap fun c => Dir.order.flatMap fun f => [false, true].filterMap fun a =>
    if kind == 0 then (if a then none else some ⟨c, f, a⟩)
    else if kind == 1 then (if a || !linked b.bridges c f then none else some ⟨c, f, a⟩)
    else (if a && !linked b.bridges c f then none else some ⟨c, f, a⟩)

def hiddenSucc (b : Board) (s : St) (d : Dir) (kind : Nat) : List Guard :=
  let q := landing b s d
  let gs := hiddenCands b s kind
  if kind == 0 then sentriesNext q d gs
  else if kind == 1 then patrolsNext b q d gs
  else chasersNext b s q gs

def kindLenient (occ : List Cell) (vis mdl alt : List Guard) : Bool :=
  vis.all (fun g => mdl.contains g || alt.contains g) && mdl.all (fun g => vis.contains g || occ.contains g.cell)

def lenient (b fbd : Board) (s : St) (d : Dir) (s' : St) (o : Obs) : Bool :=
  fbd.bridges == b.bridges && o.player == s'.player && o.facing == s'.facing
  && o.hud == hudAt b.budget s'.used && (targetOk b fbd o || b.target.isNone)
  && kindLenient o.occupied o.sentries s'.sentries (hiddenSucc b s d 0)
  && kindLenient o.occupied o.patrols s'.patrols (hiddenSucc b s d 1)
  && kindLenient o.occupied o.chasers s'.chasers (hiddenSucc b s d 2)

/-! ## 逐条 -/

inductive Verdict where
  | exact      -- 模型算出来的，和下一帧对上了
  | fiber      -- 对不上，但前一帧藏着的东西（被压住的守卫 / 目标）解释得了
  | bad        -- 模型被这一帧证伪
  | skip       -- 模型不描述这一步（RESET），**有名字、有条数**，不是「对」
  deriving DecidableEq, Repr

/-- 语料里的一条转移。`prev` / `next` 指向 `Replay.frames`，读不成的帧是 `none`。 -/
structure Case where
  seq  : Nat
  lvl  : Nat
  act  : Option Dir
  prev : Option Nat
  next : Option Nat
  won  : Bool
  over : Bool
  deriving DecidableEq, Repr

/-- 判一条转移。`frameOf` / `boardOf` / `budgetOf` 由 `Replay` 给（观测只存那一份）。 -/
def agrees (frameOf : Nat → Obs) (boardOf : Nat → Board) (budgetOf : Nat → Nat) (c : Case) : Verdict :=
  match c.act, c.prev with
  | none, _ => .skip
  | _, none => .skip
  | some d, some pi =>
    let p := frameOf pi
    let b : Board := { boardOf p.fb with budget := budgetOf c.lvl }
    match stateOf b p with
    | none => .bad
    | some s =>
      match step b s d with
      | .won => if c.won then .exact else .bad
      | .over => if c.over then .exact else .bad
      | .ok s' =>
        if c.won then (if b.target.isNone then .fiber else .bad)
        else if c.over then .bad
        else match c.next with
          | none => .bad
          | some ni =>
            let o := frameOf ni
            if seenOk b (boardOf o.fb) s' o then .exact
            else if lenient b (boardOf o.fb) s d s' o then .fiber else .bad

/-! ## 每关 -/

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算出来的状态。** -/
def traceOk (b : Board) (boardOf : Nat → Board) : St → List (Dir × Obs) → Bool
  | _, [] => true
  | s, (d, o) :: rest =>
    match step b s d with
    | .ok s' => seenOk b (boardOf o.fb) s' o && traceOk b boardOf s' rest
    | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，不是定理。 -/
def firstSplit (b : Board) (boardOf : Nat → Board) : St → List (Dir × Obs) → Nat → Option Nat
  | _, [], _ => none
  | s, (d, o) :: rest, i =>
    match step b s d with
    | .ok s' => if seenOk b (boardOf o.fb) s' o then firstSplit b boardOf s' rest (i + 1) else some i
    | _ => some i

end Game
