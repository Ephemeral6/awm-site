/-
# Corpus —— 模型面对**每一条**真实转移（`lean2/export_corpus.py` 生成，不要手改）

    exact   从观测到的前一帧读出状态，算一步，和下一帧对上
    fiber   对不上，但前一帧藏着的东西（被压住的守卫 / 目标）解释得了
    bad     模型被这一帧证伪
    skip    模型不描述这一步：RESET（有名字、有条数，不是「对」）

**逐条这一层每一步都从观测到的那一帧重新起算——模型每步都被拉回正轨。**
「走两步就和现实分家」的毛病这里看不见，要看 `Proof/Levels.lean`。

`#eval` 那几行是**读数**（求值器），结论是下面那几条走内核的 `theorem`。
-/

import Obs.Replay

namespace Game
namespace Corpus
open Replay

set_option maxRecDepth 100000

def noBad (lv : Nat) : Bool := (steps.filter (fun c => c.lvl == lv)).all (fun c => verdict c != .bad)

/-- 第 0 关（语料里 66 行）：没有一行判 `bad`。 -/
theorem corpus_L0 : noBad 0 = true := by decide +kernel

#print axioms corpus_L0

/-- 第 1 关（语料里 43 行）：没有一行判 `bad`。 -/
theorem corpus_L1 : noBad 1 = true := by decide +kernel

#print axioms corpus_L1

/-- 第 2 关（语料里 61 行）：没有一行判 `bad`。 -/
theorem corpus_L2 : noBad 2 = true := by decide +kernel

#print axioms corpus_L2

/-- 第 3 关（语料里 76 行）：没有一行判 `bad`。 -/
theorem corpus_L3 : noBad 3 = true := by decide +kernel

#print axioms corpus_L3

/-- 第 4 关（语料里 87 行）：没有一行判 `bad`。 -/
theorem corpus_L4 : noBad 4 = true := by decide +kernel

#print axioms corpus_L4

/-- 第 5 关（语料里 98 行）：没有一行判 `bad`。 -/
theorem corpus_L5 : noBad 5 = true := by decide +kernel

#print axioms corpus_L5

/-- 第 6 关（语料里 33 行）：没有一行判 `bad`。 -/
theorem corpus_L6 : noBad 6 = true := by decide +kernel

#print axioms corpus_L6

/-- 第 7 关（语料里 42 行）：没有一行判 `bad`。 -/
theorem corpus_L7 : noBad 7 = true := by decide +kernel

#print axioms corpus_L7

/-- 第 8 关（语料里 59 行）：没有一行判 `bad`。 -/
theorem corpus_L8 : noBad 8 = true := by decide +kernel

#print axioms corpus_L8

/-- 第 9 关（语料里 1 行）：没有一行判 `bad`。 -/
theorem corpus_L9 : noBad 9 = true := by decide +kernel

#print axioms corpus_L9

/-- 一共 566 行，一行不漏（切片没切丢东西）。 -/
theorem corpus_len : steps.length = 566 := by decide +kernel

#print axioms corpus_len

/-- **非恒真**：seq 1 那一行，把下一帧换成前一帧（「什么都没发生」），判决必须是 `bad`。 -/
theorem agrees_can_fail : verdict { bySeq 1 with next := (bySeq 1).prev } = .bad := by decide +kernel

#print axioms agrees_can_fail

/-- 同一行原样判：`exact`。上一条红的是被换掉的那一帧，不是这一行本身。 -/
theorem agrees_real_row : verdict (bySeq 1) = .exact := by decide +kernel

#print axioms agrees_real_row

#eval (steps.map verdict).foldl (fun (acc : Nat × Nat × Nat × Nat) v =>
  match v with
  | .exact => (acc.1 + 1, acc.2.1, acc.2.2.1, acc.2.2.2)
  | .fiber => (acc.1, acc.2.1 + 1, acc.2.2.1, acc.2.2.2)
  | .bad => (acc.1, acc.2.1, acc.2.2.1 + 1, acc.2.2.2)
  | .skip => (acc.1, acc.2.1, acc.2.2.1, acc.2.2.2 + 1)) (0, 0, 0, 0)

/- 逐行的判决，给 `verify.py` 和 Python 规则层对账用（读数，不是定理）。 -/
#eval "VERDICTS " ++ String.intercalate "," (steps.map fun c =>
  toString c.seq ++ ":" ++ match verdict c with
    | .exact => "E" | .fiber => "F" | .bad => "B" | .skip => "S")

end Corpus
end Game
