/-
# 规则 budget/hud_drains —— **定义**

每按一下方向键（被挡也算）走了的步数 +1；帧上预算带显示 `hudAt B used`
（`Obj/Derive/Budget.lean`）。走满 B 步预算带归零——那一步是死法之一（`GameOverIff`）。
-/

import Obj.World

namespace Game

def usedNext (s : St) : Nat := s.used + 1

/-- 这一步之后预算带归零。 -/
def runsOut (b : Board) (s : St) : Bool := b.budget ≤ usedNext s

end Game
