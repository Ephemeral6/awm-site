/-
# 规则 move/player_moves —— **定义**

往 d 有桥 ⇒ 落在 player+d、记号朝 d；没桥 ⇒ 位置与记号都不变（整个世界冻住，只有预算照扣）。
-/

import Obj.World
import Obj.Derive.Graph.Linked

namespace Game

/-- 玩家往 d 走，落在哪；没桥返回 `none`（这一步被挡）。 -/
def landing (b : Board) (s : St) (d : Dir) : Option Cell :=
  if linked b.bridges s.player d then some (s.player.move d) else none

/-- 走了之后玩家的位置与记号。 -/
def playerNext (s : St) (d : Dir) : Option Cell → Cell × Dir
  | some q => (q, d)
  | none   => (s.player, s.facing)

end Game
