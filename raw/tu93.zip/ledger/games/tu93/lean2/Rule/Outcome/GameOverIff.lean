/-
# 规则 outcome/game_over_iff —— **定义**（这就是「死」的定义）

五种里占一种就死（都只看动作之前的局面 + 动作）：

    front   玩家落在一只没被这一步踩掉的哨兵正前方
    patrol  某只巡逻这一步落到玩家的落点上
    swap    玩家踩进一只巡逻那一格、那只巡逻正要走到玩家原来那一格
    chaser  某只追兵这一步落到玩家的落点上
    budget  预算带这一步归零（被挡住的那一步也算）

swap 与 chaser 两支语料里一次都没发生过，是照 patrol 那一支补的。
-/

import Rule.Move.PlayerMoves
import Rule.Guards.PatrolWalks
import Rule.Guards.ChaserSteps
import Rule.Budget.HudDrains

namespace Game

def dies (b : Board) (s : St) (d : Dir) : Bool :=
  let q := landing b s d
  let byGuard := match q with
    | none => false
    | some c =>
      (s.sentries.any fun g => !stomped q d g && g.cell.move g.facing == c)
      || (s.patrols.any fun g => !stomped q d g && (patrolNext b true g).cell == c)
      || (s.patrols.any fun g => !stomped q d g && g.cell == c && g.cell.move g.facing == s.player)
      || (s.chasers.any fun g => (chaserNext b s.player c true g).cell == c)
  byGuard || runsOut b s

end Game
