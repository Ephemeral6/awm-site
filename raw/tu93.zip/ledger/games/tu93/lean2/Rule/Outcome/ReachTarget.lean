/-
# 规则 outcome/reach_target —— **定义**（这就是「赢」的定义）

落点就是目标 ⇒ 这一步过关。落在目标上的同时被扑中：过关优先（语料里 0 次，是选的；
Python 那边 `game_over_iff` 在换关那一步不开口，与这一选择一致）。
-/

import Obj.World

namespace Game

def reaches (b : Board) (q : Option Cell) : Bool :=
  match q, b.target with
  | some c, some t => c == t
  | _, _ => false

end Game
