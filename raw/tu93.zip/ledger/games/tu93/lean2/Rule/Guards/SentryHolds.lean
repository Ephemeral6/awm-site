/-
# 规则 guards/sentry_holds —— **定义**

哨兵原地不动、朝向不变；玩家落在它身上、且进入方向与它的朝向垂直，它就被踩掉。

`stomped` 也被巡逻那一条和死法那一条用（同一个谓词，只写这一处）。
**平行地踩进去**（顺着它的朝向从背后踩）：这里判「不算踩掉」——语料里 0 次，是选的。
-/

import Obj.World

namespace Game

def stomped (q : Option Cell) (d : Dir) (g : Guard) : Bool :=
  match q with
  | some c => g.cell == c && d.perp g.facing
  | none => false

def sentriesNext (q : Option Cell) (d : Dir) (gs : List Guard) : List Guard :=
  gs.filter (fun g => !stomped q d g)

end Game
