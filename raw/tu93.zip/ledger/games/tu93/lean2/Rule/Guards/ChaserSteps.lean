/-
# 规则 guards/chaser_steps —— **定义**

玩家被挡住的那一步，追兵一概不动。否则：

    睡着   原地不动；玩家落点离它 ≤ 2 格（曼哈顿）就当场醒，记号改指下面那条最短路的第一步
    醒着   沿记号走一格，然后记号改指「到玩家**动作之前**那一格」的最短路第一步

两处是选的（语料上两种读数一样）：醒的距离按曼哈顿；刚醒那一步记号改。
-/

import Obj.World
import Obj.Derive.Graph.Route

namespace Game

def wakeDist : Nat := 2

def chaserNext (b : Board) (before after : Cell) (moved : Bool) (g : Guard) : Guard :=
  if moved then
    if g.alert then
      let c := if linked b.bridges g.cell g.facing then g.cell.move g.facing else g.cell
      { g with cell := c, facing := (firstStep b.bridges c before).getD g.facing }
    else if g.cell.dist after ≤ wakeDist then
      { g with alert := true, facing := (firstStep b.bridges g.cell before).getD g.facing }
    else g
  else g

def chasersNext (b : Board) (s : St) (q : Option Cell) (gs : List Guard) : List Guard :=
  gs.map (chaserNext b s.player (q.getD s.player) q.isSome)

end Game
