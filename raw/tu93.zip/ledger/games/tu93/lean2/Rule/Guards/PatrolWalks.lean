/-
# 规则 guards/patrol_walks —— **定义**

玩家真走了一步 ⇒ 每只巡逻沿朝向走一格，到了之后前方没桥就当场掉头；玩家被挡 ⇒ 不动。
被踩掉的那只不算。**巡逻开局就朝着死路**（语料里 0 次）：原地不动——是选的。
-/

import Rule.Guards.SentryHolds
import Obj.Derive.Graph.Linked

namespace Game

def patrolNext (b : Board) (moved : Bool) (g : Guard) : Guard :=
  if moved then
    let c := if linked b.bridges g.cell g.facing then g.cell.move g.facing else g.cell
    { g with cell := c, facing := if linked b.bridges c g.facing then g.facing else g.facing.rev }
  else g

def patrolsNext (b : Board) (q : Option Cell) (d : Dir) (gs : List Guard) : List Guard :=
  (gs.filter (fun g => !stomped q d g)).map (patrolNext b q.isSome)

end Game
