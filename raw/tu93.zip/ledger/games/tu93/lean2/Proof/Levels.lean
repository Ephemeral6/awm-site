/-
# Levels —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L<n>_trace      沿着真人走过的那条路，模型**每一帧**都和观测对上（只有开局那一帧是观测给的）
    L<n>_winnable   这一关走得通——见证就是那条路（最后一脚过关）

见证只取**成绩单认证的那一段**（guid f61f9313-9b63-4593-988d-c12f4ceff1d7，逐关步数与成绩单的 level_actions 对过账）。
这一局九关都过了，所以没有 `_unsolvable`；「不可做」那一半的骨架与一把钥匙在 `Proof/Reachable.lean`
与 `Proof/Scenes.lean`。`Winnable` 里的动作串不含 RESET——**模型不描述重来**。

## 一条明写的假设：每一关的开局 `used = 0`（预算带满格）

过关那一步模型只说 `won`，不带下一帧；下一关的开局从语料那一帧读出来。
`L<n>_trace` 第一帧就拿 `hudAt B 0` 去对观测到的格数——假设错了当场红。
**没红不构成证明**：那只是这条假设在这批语料上唯一一次被驳倒的机会，它没被驳倒。
-/

import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels
open Replay

set_option maxRecDepth 100000

/-! ## 第 0 关：认证段 seq 380–397，18 步（成绩单 level_actions = 18） -/

/-- 第 0 关的真实开局：seq 380 那一行动作之前的那一帧，按整关版面读出来。 -/
def L0_start : St := startAt 0 380

/-- 开局到过关前一步为止，17 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 1 关的盘。 -/
def L0_play : List (Dir × Obs) := playFrom 380 17

/-- 全部 18 个动作，最后一个是过关那一脚。 -/
def L0_acts : List Dir := actsFrom 380 18

theorem L0_play_len : L0_play.length = 17 := by decide +kernel
theorem L0_acts_len : L0_acts.length = 18 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L0_start_fresh : St.used L0_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 0) boardOf L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L0_trace : traceOk (levelBoard 0) boardOf L0_start L0_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 18 步。 -/
theorem L0_winnable : Winnable (levelBoard 0) L0_start := ⟨L0_acts, by decide +kernel⟩

#print axioms L0_play_len
#print axioms L0_acts_len
#print axioms L0_start_fresh
#print axioms L0_trace
#print axioms L0_winnable

/-! ## 第 1 关：认证段 seq 398–407，10 步（成绩单 level_actions = 10） -/

/-- 第 1 关的真实开局：seq 398 那一行动作之前的那一帧，按整关版面读出来。 -/
def L1_start : St := startAt 1 398

/-- 开局到过关前一步为止，9 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 2 关的盘。 -/
def L1_play : List (Dir × Obs) := playFrom 398 9

/-- 全部 10 个动作，最后一个是过关那一脚。 -/
def L1_acts : List Dir := actsFrom 398 10

theorem L1_play_len : L1_play.length = 9 := by decide +kernel
theorem L1_acts_len : L1_acts.length = 10 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L1_start_fresh : St.used L1_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 1) boardOf L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L1_trace : traceOk (levelBoard 1) boardOf L1_start L1_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 10 步。 -/
theorem L1_winnable : Winnable (levelBoard 1) L1_start := ⟨L1_acts, by decide +kernel⟩

#print axioms L1_play_len
#print axioms L1_acts_len
#print axioms L1_start_fresh
#print axioms L1_trace
#print axioms L1_winnable

/-! ## 第 2 关：认证段 seq 408–426，19 步（成绩单 level_actions = 19） -/

/-- 第 2 关的真实开局：seq 408 那一行动作之前的那一帧，按整关版面读出来。 -/
def L2_start : St := startAt 2 408

/-- 开局到过关前一步为止，18 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 3 关的盘。 -/
def L2_play : List (Dir × Obs) := playFrom 408 18

/-- 全部 19 个动作，最后一个是过关那一脚。 -/
def L2_acts : List Dir := actsFrom 408 19

theorem L2_play_len : L2_play.length = 18 := by decide +kernel
theorem L2_acts_len : L2_acts.length = 19 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L2_start_fresh : St.used L2_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 2) boardOf L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L2_trace : traceOk (levelBoard 2) boardOf L2_start L2_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 19 步。 -/
theorem L2_winnable : Winnable (levelBoard 2) L2_start := ⟨L2_acts, by decide +kernel⟩

#print axioms L2_play_len
#print axioms L2_acts_len
#print axioms L2_start_fresh
#print axioms L2_trace
#print axioms L2_winnable

/-! ## 第 3 关：认证段 seq 427–443，17 步（成绩单 level_actions = 17） -/

/-- 第 3 关的真实开局：seq 427 那一行动作之前的那一帧，按整关版面读出来。 -/
def L3_start : St := startAt 3 427

/-- 开局到过关前一步为止，16 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 4 关的盘。 -/
def L3_play : List (Dir × Obs) := playFrom 427 16

/-- 全部 17 个动作，最后一个是过关那一脚。 -/
def L3_acts : List Dir := actsFrom 427 17

theorem L3_play_len : L3_play.length = 16 := by decide +kernel
theorem L3_acts_len : L3_acts.length = 17 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L3_start_fresh : St.used L3_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 3) boardOf L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L3_trace : traceOk (levelBoard 3) boardOf L3_start L3_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 17 步。 -/
theorem L3_winnable : Winnable (levelBoard 3) L3_start := ⟨L3_acts, by decide +kernel⟩

#print axioms L3_play_len
#print axioms L3_acts_len
#print axioms L3_start_fresh
#print axioms L3_trace
#print axioms L3_winnable

/-! ## 第 4 关：认证段 seq 444–472，29 步（成绩单 level_actions = 29） -/

/-- 第 4 关的真实开局：seq 444 那一行动作之前的那一帧，按整关版面读出来。 -/
def L4_start : St := startAt 4 444

/-- 开局到过关前一步为止，28 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 5 关的盘。 -/
def L4_play : List (Dir × Obs) := playFrom 444 28

/-- 全部 29 个动作，最后一个是过关那一脚。 -/
def L4_acts : List Dir := actsFrom 444 29

theorem L4_play_len : L4_play.length = 28 := by decide +kernel
theorem L4_acts_len : L4_acts.length = 29 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L4_start_fresh : St.used L4_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 4) boardOf L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L4_trace : traceOk (levelBoard 4) boardOf L4_start L4_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 29 步。 -/
theorem L4_winnable : Winnable (levelBoard 4) L4_start := ⟨L4_acts, by decide +kernel⟩

#print axioms L4_play_len
#print axioms L4_acts_len
#print axioms L4_start_fresh
#print axioms L4_trace
#print axioms L4_winnable

/-! ## 第 5 关：认证段 seq 473–502，30 步（成绩单 level_actions = 30） -/

/-- 第 5 关的真实开局：seq 473 那一行动作之前的那一帧，按整关版面读出来。 -/
def L5_start : St := startAt 5 473

/-- 开局到过关前一步为止，29 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 6 关的盘。 -/
def L5_play : List (Dir × Obs) := playFrom 473 29

/-- 全部 30 个动作，最后一个是过关那一脚。 -/
def L5_acts : List Dir := actsFrom 473 30

theorem L5_play_len : L5_play.length = 29 := by decide +kernel
theorem L5_acts_len : L5_acts.length = 30 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L5_start_fresh : St.used L5_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 5) boardOf L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L5_trace : traceOk (levelBoard 5) boardOf L5_start L5_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 30 步。 -/
theorem L5_winnable : Winnable (levelBoard 5) L5_start := ⟨L5_acts, by decide +kernel⟩

#print axioms L5_play_len
#print axioms L5_acts_len
#print axioms L5_start_fresh
#print axioms L5_trace
#print axioms L5_winnable

/-! ## 第 6 关：认证段 seq 503–516，14 步（成绩单 level_actions = 14） -/

/-- 第 6 关的真实开局：seq 503 那一行动作之前的那一帧，按整关版面读出来。 -/
def L6_start : St := startAt 6 503

/-- 开局到过关前一步为止，13 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 7 关的盘。 -/
def L6_play : List (Dir × Obs) := playFrom 503 13

/-- 全部 14 个动作，最后一个是过关那一脚。 -/
def L6_acts : List Dir := actsFrom 503 14

theorem L6_play_len : L6_play.length = 13 := by decide +kernel
theorem L6_acts_len : L6_acts.length = 14 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L6_start_fresh : St.used L6_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 6) boardOf L6_start L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L6_trace : traceOk (levelBoard 6) boardOf L6_start L6_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 14 步。 -/
theorem L6_winnable : Winnable (levelBoard 6) L6_start := ⟨L6_acts, by decide +kernel⟩

#print axioms L6_play_len
#print axioms L6_acts_len
#print axioms L6_start_fresh
#print axioms L6_trace
#print axioms L6_winnable

/-! ## 第 7 关：认证段 seq 517–537，21 步（成绩单 level_actions = 21） -/

/-- 第 7 关的真实开局：seq 517 那一行动作之前的那一帧，按整关版面读出来。 -/
def L7_start : St := startAt 7 517

/-- 开局到过关前一步为止，20 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 8 关的盘。 -/
def L7_play : List (Dir × Obs) := playFrom 517 20

/-- 全部 21 个动作，最后一个是过关那一脚。 -/
def L7_acts : List Dir := actsFrom 517 21

theorem L7_play_len : L7_play.length = 20 := by decide +kernel
theorem L7_acts_len : L7_acts.length = 21 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L7_start_fresh : St.used L7_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 7) boardOf L7_start L7_play 0 with
  | none   => "L7  一处都没分家（共 " ++ toString L7_play.length ++ " 步）"
  | some i => "L7  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L7_trace : traceOk (levelBoard 7) boardOf L7_start L7_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 21 步。 -/
theorem L7_winnable : Winnable (levelBoard 7) L7_start := ⟨L7_acts, by decide +kernel⟩

#print axioms L7_play_len
#print axioms L7_acts_len
#print axioms L7_start_fresh
#print axioms L7_trace
#print axioms L7_winnable

/-! ## 第 8 关：认证段 seq 538–566，29 步（成绩单 level_actions = 29） -/

/-- 第 8 关的真实开局：seq 538 那一行动作之前的那一帧，按整关版面读出来。 -/
def L8_start : St := startAt 8 538

/-- 开局到过关前一步为止，28 步（动作, 下一帧）。过关那一脚不在这里：它的下一帧是第 9 关的盘。 -/
def L8_play : List (Dir × Obs) := playFrom 538 28

/-- 全部 29 个动作，最后一个是过关那一脚。 -/
def L8_acts : List Dir := actsFrom 538 29

theorem L8_play_len : L8_play.length = 28 := by decide +kernel
theorem L8_acts_len : L8_acts.length = 29 := by decide +kernel

/-- 开局读出来的是「一步都没走」（预算带满格）——明写的那条假设在这一关的落点。
    （写成 `St.used L_start` 而不写 `L_start.used`：装置的「长在世界上」按名字认，
    `L_start.used` 这个带点的名字它拆不出 `L_start`，会误判成「跟这一局无关」。） -/
theorem L8_start_fresh : St.used L8_start = 0 := by decide +kernel

#eval match firstSplit (levelBoard 8) boardOf L8_start L8_play 0 with
  | none   => "L8  一处都没分家（共 " ++ toString L8_play.length ++ " 步）"
  | some i => "L8  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L8_trace : traceOk (levelBoard 8) boardOf L8_start L8_play = true := by decide +kernel

/-- **这一关走得通。** 见证是认证段里真人走的那 29 步。 -/
theorem L8_winnable : Winnable (levelBoard 8) L8_start := ⟨L8_acts, by decide +kernel⟩

#print axioms L8_play_len
#print axioms L8_acts_len
#print axioms L8_start_fresh
#print axioms L8_trace
#print axioms L8_winnable

end Levels
end Game
