/-
# Reachable —— 这个局面做不做得了

    Winnable   b s  :=  ∃ as, 照着走中途赢过
    Unsolvable b s  :=  ∀ as, 照着走从没赢过

**`∀ as` 里没有 RESET**：动作只有四个方向（`Dir`），模型不描述重来。
所以 `Unsolvable` 的准确意思是 **「不经过重置就赢不了」**——这半句写在这里、写在
`Proof/Levels.lean`、写在页面上，三处都写。

这一局九关在语料里全过了，所以九关都是 `Winnable`（`Proof/Levels.lean`）。
不可做的那一半这里只给**骨架**和**一把钥匙**（`Proof/Scenes.lean` 里用在一张手造的盘上）。
-/

import Step

namespace Game

def everWon (b : Board) : St → List Dir → Bool
  | _, [] => false
  | s, d :: ds =>
    match step b s d with
    | .won => true
    | .over => false
    | .ok s' => everWon b s' ds

def Winnable (b : Board) (s : St) : Prop := ∃ as : List Dir, everWon b s as = true

/-- **不经过重置**，任何动作串都赢不了。 -/
def Unsolvable (b : Board) (s : St) : Prop := ∀ as : List Dir, everWon b s as = false

theorem not_both (b : Board) (s : St) (hw : Winnable b s) (hu : Unsolvable b s) : False := by
  obtain ⟨as, h⟩ := hw
  rw [hu as] at h
  exact Bool.false_ne_true h

/-- **全文唯一的一条归纳。** 找一个每走一步都还成立、而且和「这一步赢」矛盾的性质 `P`，
    从满足 `P` 的局面出发，任何动作串都赢不了。与盘面多大、动作串多长都无关，不枚举任何状态。 -/
theorem unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' d, P s → step b s d = .ok s' → P s')
    (hwin : ∀ s d, P s → step b s d ≠ .won) :
    ∀ s, P s → Unsolvable b s := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons d t ih =>
    simp only [everWon]
    cases h : step b s d with
    | won => exact absurd h (hwin s d hp)
    | over => rfl
    | ok s' => exact ih s' (hkeep s s' d hp h)

end Game
