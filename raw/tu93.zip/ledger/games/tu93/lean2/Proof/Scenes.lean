/-
# Scenes —— 手造的盘：一把「不可做」的钥匙，和它的三条防线

这一局九关都走通了，语料里没有一关要证「走不通」。但「不可做」那一半的零件要**能用**，
而且要能**失败**——所以在一张手造的小盘上用一次。

## 钥匙：玩家被关在一块对桥封闭的区域里，而目标不在里面

    closedIn bs C   C 里每一格往任何方向，要么没桥，要么桥那头还在 C 里
    P s             玩家在 C 里

`P` 每走一步都还成立（落点要么是原地、要么是桥那头），而且和「这一步过关」矛盾
（过关要求落点就是目标，目标不在 C 里）。挂上 `unsolvable_of_invariant`，
**任何**不经重置的动作串都赢不了。**不枚举状态**：`closedIn` 是对 C 这张有限表的一次检查。

这把钥匙**不看守卫**——守卫只会让事情更难，不会搭出一段新桥。

## 三条防线

    cut_winnable          把断开的那一段桥补上（只差一处），这张盘三步就赢
    cut_closed_at_start   断开的那张盘不是「开局就已经在目标上」
    bridged_not_key       补上之后钥匙的前提**真的不满足**（不是「没找到证明」）
-/

import Proof.Reachable

namespace Game
namespace Scenes

def closedIn (bs : List Bridge) (C : List Cell) : Bool :=
  C.all fun c => Dir.order.all fun d => !linked bs c d || C.contains (c.move d)

theorem mem_order (d : Dir) : d ∈ Dir.order := by cases d <;> simp [Dir.order]

theorem landing_stays (b : Board) (s : St) (d : Dir) (C : List Cell)
    (hc : closedIn b.bridges C = true) (hp : C.contains s.player = true) :
    ∀ q, landing b s d = some q → C.contains q = true := by
  intro q hq
  unfold landing at hq
  by_cases hl : linked b.bridges s.player d = true
  · simp [hl] at hq
    subst hq
    have h1 := List.all_eq_true.mp hc s.player (by simpa using hp)
    have h2 := List.all_eq_true.mp h1 d (mem_order d)
    simp [hl] at h2
    simpa using h2
  · simp [hl] at hq

theorem key_keep (b : Board) (C : List Cell) (hc : closedIn b.bridges C = true) :
    ∀ s s' d, C.contains s.player = true → step b s d = .ok s' → C.contains s'.player = true := by
  intro s s' d hp h
  unfold step at h
  by_cases h1 : reaches b (landing b s d) = true
  · simp [h1] at h
  · by_cases h2 : dies b s d = true
    · simp [h1, h2] at h
    · simp [h1, h2] at h
      subst h
      cases hq : landing b s d with
      | none => simpa [advance, playerNext, hq] using hp
      | some q => simpa [advance, playerNext, hq] using landing_stays b s d C hc hp q hq

theorem key_no_win (b : Board) (C : List Cell) (t : Cell) (hc : closedIn b.bridges C = true)
    (ht : b.target = some t) (hout : C.contains t = false) :
    ∀ s d, C.contains s.player = true → step b s d ≠ .won := by
  intro s d hp h
  unfold step at h
  by_cases h1 : reaches b (landing b s d) = true
  · cases hq : landing b s d with
    | none => simp [reaches, hq] at h1
    | some q =>
      have hin := landing_stays b s d C hc hp q hq
      simp [reaches, hq, ht] at h1
      subst h1
      rw [hin] at hout
      exact Bool.noConfusion hout
  · by_cases h2 : dies b s d = true
    · simp [h1, h2] at h
    · simp [h1, h2] at h

/-- 钥匙本身：玩家关在一块封闭的区域里、目标在外面 ⇒ **不经过重置**，任何动作串都赢不了。 -/
theorem unsolvable_by_cut (b : Board) (C : List Cell) (t : Cell) (hc : closedIn b.bridges C = true)
    (ht : b.target = some t) (hout : C.contains t = false) (s : St) (hp : C.contains s.player = true) :
    Unsolvable b s :=
  unsolvable_of_invariant b (fun s => C.contains s.player = true)
    (key_keep b C hc) (key_no_win b C t hc ht hout) s hp

/-! ## 一张手造的盘：一行四格，中间那段桥断了 -/

def cutBoard : Board :=
  { bridges := [⟨⟨0, 0⟩, ⟨0, 1⟩⟩, ⟨⟨0, 2⟩, ⟨0, 3⟩⟩], target := some ⟨0, 3⟩, budget := 50 }

/-- 只差一处：补上 (0,1)–(0,2) 那段桥。 -/
def bridgedBoard : Board :=
  { cutBoard with bridges := ⟨⟨0, 1⟩, ⟨0, 2⟩⟩ :: cutBoard.bridges }

def start0 : St :=
  { player := ⟨0, 0⟩, facing := .right, sentries := [], patrols := [], chasers := [], used := 0 }

def island : List Cell := [⟨0, 0⟩, ⟨0, 1⟩]

theorem cut_unsolvable : Unsolvable cutBoard start0 :=
  unsolvable_by_cut cutBoard island ⟨0, 3⟩ (by decide) rfl (by decide) start0 (by decide)

/-- 防线一：补上那一段桥，三步就赢。 -/
theorem bridged_winnable : Winnable bridgedBoard start0 := ⟨[.right, .right, .right], by decide⟩

/-- 防线二：断开的那张盘不是「开局就已经在目标上」。 -/
theorem cut_closed_at_start : start0.player ≠ ⟨0, 3⟩ ∧ everWon cutBoard start0 [] = false := by
  exact ⟨by decide, rfl⟩

/-- 防线三：补上之后钥匙的前提**真的不满足**——那块区域对桥不再封闭。 -/
theorem bridged_not_key : closedIn bridgedBoard.bridges island = false := by decide

#print axioms mem_order
#print axioms landing_stays
#print axioms key_keep
#print axioms key_no_win
#print axioms unsolvable_by_cut
#print axioms cut_unsolvable
#print axioms bridged_winnable
#print axioms cut_closed_at_start
#print axioms bridged_not_key

end Scenes
end Game
