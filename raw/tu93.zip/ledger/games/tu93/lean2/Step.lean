/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    过关   落点是目标                       → `won`（不带下一帧：下一关是另一张盘）
    死     `dies`                           → `over`（不带下一帧：玩家已经被吃掉）
    否则   各条规则各算自己那一份，拼成下一个 `St`

「重来一次（RESET）」**不在这里**：模型不描述它，写成明处的假设（见 `Proof/Levels.lean`）。
（`step` 的体里不写 `let`：写了 `let`，证明里 `split` 就进不去。）
-/

import Rule.Outcome.ReachTarget
import Rule.Outcome.GameOverIff

namespace Game

inductive Res where
  | ok (s : St)
  | won
  | over
  deriving DecidableEq, Repr

def advance (b : Board) (s : St) (d : Dir) (q : Option Cell) : St :=
  { player := (playerNext s d q).1, facing := (playerNext s d q).2,
    sentries := sentriesNext q d s.sentries,
    patrols := patrolsNext b q d s.patrols,
    chasers := chasersNext b s q s.chasers,
    used := usedNext s }

def step (b : Board) (s : St) (d : Dir) : Res :=
  if reaches b (landing b s d) then .won
  else if dies b s d then .over
  else .ok (advance b s d (landing b s d))

end Game
