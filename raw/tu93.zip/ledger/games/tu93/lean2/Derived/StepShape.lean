/-
# 分发的形状 —— 推论（从 `Step.lean` 的定义直接推出来，不是新说法）

`step` 没死没过关时，下一个状态就是 `advance` 拼出来的那一个。后面几条推论都从这一条起步。
-/

import Step

namespace Game

theorem step_ok (b : Board) (s s' : St) (d : Dir) (h : step b s d = .ok s') :
    s' = advance b s d (landing b s d) := by
  unfold step at h
  by_cases h1 : reaches b (landing b s d) = true
  · simp [h1] at h
  · by_cases h2 : dies b s d = true
    · simp [h1, h2] at h
    · simp [h1, h2] at h
      exact h.symm

#print axioms step_ok

end Game
