/-
# 规则 observe/nothing_appears —— **推论**

Python 那边这是一条每帧都要判的规则：「下一帧的每只守卫都有来处」。
在模型里它**不是一条独立的规则**：`advance` 对三种守卫只做 `filter`（踩掉）和 `map`（走一步），
从不凭空造一只——所以「下一个状态里的每只守卫，都是这一个状态里某只守卫走了一步」是定义的推论。
**被踩掉的不会回来**也在里面：下一个状态里的哨兵，一定是这一步**没被**踩掉的那些。

它在 Python 那边还多管一件事：帧上**被压住**的那只露出来时认得出来路——那是观测的口径，
在这边住在判据里（`Obs/Check.lean` 的 `lenient` / `hiddenSucc`），不在模型里。
-/

import Derived.StepShape

namespace Game

theorem sentries_come_from (b : Board) (s s' : St) (d : Dir) (h : step b s d = .ok s') :
    ∀ g ∈ s'.sentries, g ∈ s.sentries ∧ stomped (landing b s d) d g = false := by
  rw [step_ok b s s' d h]
  intro g hg
  simp only [advance, sentriesNext, List.mem_filter, Bool.not_eq_true'] at hg
  exact hg

theorem patrols_come_from (b : Board) (s s' : St) (d : Dir) (h : step b s d = .ok s') :
    ∀ g ∈ s'.patrols, ∃ g0 ∈ s.patrols, stomped (landing b s d) d g0 = false ∧
      g = patrolNext b (landing b s d).isSome g0 := by
  rw [step_ok b s s' d h]
  intro g hg
  simp only [advance, patrolsNext, List.mem_map, List.mem_filter, Bool.not_eq_true'] at hg
  obtain ⟨g0, ⟨hm, hs⟩, rfl⟩ := hg
  exact ⟨g0, hm, hs, rfl⟩

theorem chasers_come_from (b : Board) (s s' : St) (d : Dir) (h : step b s d = .ok s') :
    ∀ g ∈ s'.chasers, ∃ g0 ∈ s.chasers,
      g = chaserNext b s.player ((landing b s d).getD s.player) (landing b s d).isSome g0 := by
  rw [step_ok b s s' d h]
  intro g hg
  simp only [advance, chasersNext, List.mem_map] at hg
  obtain ⟨g0, hm, rfl⟩ := hg
  exact ⟨g0, hm, rfl⟩

#print axioms sentries_come_from
#print axioms patrols_come_from
#print axioms chasers_come_from

end Game
