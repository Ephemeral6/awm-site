/-
# 方向的代数 —— 推论（`objects/geometry/dir.py` 那两条性质）

对称（判据 3）提成对象之后要证它的代数性质，**证不出来说明提错了**：
`rev` 是对合；`perp` 对称，且一个方向和自己、和自己的反向都不垂直
（「垂直踩进」「迎面 / 背后」这两种情况因此互斥）。
-/

import Obj.Geometry.Dir

namespace Game

theorem rev_rev (d : Dir) : d.rev.rev = d := by cases d <;> rfl

theorem perp_symm (a b : Dir) : a.perp b = b.perp a := by cases a <;> cases b <;> rfl

theorem not_perp_self (d : Dir) : d.perp d = false ∧ d.perp d.rev = false := by
  cases d <;> exact ⟨rfl, rfl⟩

#print axioms rev_rev
#print axioms perp_symm
#print axioms not_perp_self

end Game
