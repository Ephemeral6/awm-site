"""色13 追踪者一步之后从帧上整块读不出来，当且仅当它这一步落进的那格上同时有一只色12——它被画在巡逻兵**底下**。

这不是死亡，是遮挡：它的 8 个像素连同记号一格不剩地被色12 盖掉，
下一步两者分开时它原样出现在该在的位置上。第 8 关连着发生了两次，
第一次我把它当成「追踪者没了」，差点照着一张错的地图规划。

**读不出来 ≠ 不存在。** 词汇 chasers() 在这两帧上返回空表，
而 chaser_hunts / chaser_steps / game_over 全都靠它取值——
于是最危险的那两步恰好是全册集体失明的两步（方法册「词汇也会瞎」）。
写下这条是为了让「它到底在不在」有一个能判错的答案：
它在的位置由 chaser_steps 的记号预告接着算，遮挡期间照常推进。

只管消失那个方向。反过来（从空表里冒出来）prev 就已经读不出它，这条概念说不了，留 NA。
"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1..4；换关返回 NA；ctx 缺失返回 NA；"
         "prev 里色13 块不是恰好 1 只、或它的记号读不出，返回 NA；"
         "me 这一步没真的动（被挡，世界冻结）返回 NA")
NOTE = ""
EVIDENCE = [
    "b24889df4538c311",     # 第 357 步：色13 落进 (16,27)，那格上有巡逻兵，帧上色13 归零
    "2e27f988f1c1db38",     # 第 363 步：同样的事再来一次，这次发生在我身边两格
]

from _lib import me, chasers, chaser_facing, patrols, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return "NA"
    cs = chasers(prev)
    if len(cs) != 1:
        return "NA"
    f = chaser_facing(prev, *cs[0])
    if f is None:
        return "NA"
    dst = (cs[0][0] + f[0], cs[0][1] + f[1])
    return "TRUE" if (not chasers(nxt)) == (dst in patrols(nxt)) else "FALSE"
