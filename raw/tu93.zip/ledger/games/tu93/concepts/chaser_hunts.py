"""唤醒后的色13 块，每一步都走在桥图上通往玩家的最短路上——目标是玩家动作**之前**的位置。

这条比 chaser_steps 深一层：那条只说「它照记号走」，这条说**记号是怎么定出来的**。
两条合起来，看一眼当前帧就能算出它此后每一步落在哪，不必观察不必回忆。

它也解释了另一个更显眼、但更浅的规律：追踪者锁上玩家的轨迹之后，
看起来像是「踩着玩家两步前站过的格」。那只是最短路在走廊里的样子——
第 8 关的开局它离玩家两步的轨迹很远，滞后 2 那条读法当场失效，最短路这条照样成立。

并列没检验过：语料 26 步里每一步的最短路第一步都**唯一**。
真出现两条一样短的岔路时它挑哪条，这条概念不知道；规划时把两条都当危险格。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；换关那一步返回 NA（整屏重画）；"
         "prev 或 nxt 里色13 块不是恰好一个返回 NA；prev 里它没醒返回 NA；"
         "me 读不出返回 NA；它在图上到不了玩家、或已与玩家同格返回 NA")
NOTE = "v1：从 chaser_steps 的「照记号走」再往下问一层——记号本身指哪，由最短路定。"
EVIDENCE = [
    "c58260689f785e64",     # 步311 唤醒后第一步，此时它还没踩上我的轨迹
    "aa7f30c686eb019b",     # 步333 走廊里，最短路与滞后2 恰好重合
]
# 语料里另有 24 步没抄进来，留在 held-out 里。

from _lib import me, chasers, chaser_awake, bridge_graph, first_steps, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    p, q = chasers(prev), chasers(nxt)
    if len(p) != 1 or len(q) != 1:
        return "NA"
    if chaser_awake(prev, *p[0]) is not True:
        return "NA"
    a = me(prev)
    if a is None:
        return "NA"
    cands = first_steps(bridge_graph(prev), p[0], a)
    if not cands:
        return "NA"
    return "TRUE" if q[0] in cands else "FALSE"
