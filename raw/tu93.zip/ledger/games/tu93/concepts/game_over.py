"""一步之后局面变 GAME_OVER，当且仅当落点是别人的落点/正前方，或 HUD 归零。

L5 这一格上一直只有 reach_goal 说「怎么赢」，没有一条说「怎么死」——
规划器里那张危险格表因此是我自己发明的世界事实，一次都没走过闸。这条把它交出去。

四类危险格，三类有实证、一类是补的对称支：
  · 活着的色8 敌人**正对着**的那一格 —— 第 28 步、第 139 步两次死在这里；
    注意这和 foe_kills 不冲突：踩进它**所在**的格且方向垂直是杀它，踩进它**面前**的格是死。
  · 巡逻兵这一步的落点，或与巡逻兵对穿换位 —— 第 66 步死在这里。
  · 醒着的追踪者这一步的落点 —— **没见过**，是照前两类补的；
    真踩上去而没死，这条概念当场变反例，那正是它该做的事。
  · HUD 归零 —— 第 86 步 hud 3→0，人没撞任何东西，局面照样结束。

它是「当且仅当」，所以两个方向都能被打：漏了一种死法会判 FALSE，
多编了一种危险格（比如世界其实允许走进敌人正前方）也会判 FALSE。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..4；ctx 缺失、或 ctx 里没有 state_next 返回 NA；"
         "换关那一步返回 NA；me(prev) 读不出返回 NA；"
         "prev 里有巡逻兵而它的朝向读不出返回 NA（危险格算不出来就闭嘴）；"
         "**动作被挡（落点不在桥图上）返回 NA**——那一支世界冻结，谁都不动，"
         "只有 HUD 在掉，归 hud_drain 与 bridge_gate 管")
NOTE = "v1：把规划器里那张自造的危险格表交出来走闸。"
EVIDENCE = [
    "e3ef86bef23a18b2",     # 步86  HUD 3->0，没撞任何东西
    "bbdf2ba5a0ba9a71",     # 步139 踏进两只色8 共同正对的格
]
# 语料里另有两条死亡转移（步28 撞正对格、步66 撞巡逻兵落点）没抄进来，
# 连同几百条「没死」的转移一起留在 held-out 里——「当且仅当」的两个方向都在被考。

from _lib import (me, foes, patrols, patrol_facing, patrol_next, chasers,
                  chaser_awake, bridge_graph, first_steps, hud_left, DELTA)

GAME_OVER = "GAME_OVER"


def _danger(prev, dst):
    """dst 这一格，在 prev 这一帧上是不是危险格。"""
    for f in foes(prev):
        d = patrol_facing(prev, *f)
        if d is not None and dst == (f[0] + d[0], f[1] + d[1]):
            return True
    for p in patrols(prev):
        if patrol_next(prev, *p) == dst:
            return True
    for c in chasers(prev):
        if chaser_awake(prev, *c) is not True:
            continue
        a = me(prev)
        s = first_steps(bridge_graph(prev), c, a) if a else None
        if s and dst in s:
            return True
    return False


def _swap(prev, a, dst):
    """我和某只巡逻兵对穿换位。"""
    for p in patrols(prev):
        if p == dst and patrol_next(prev, *p) == a:
            return True
    return False


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    dead = ctx.get("state_next")
    if dead is None:
        return "NA"
    a = me(prev)
    if a is None:
        return "NA"
    d = DELTA[action]
    dst = (a[0] + d[0], a[1] + d[1])
    if dst not in bridge_graph(prev).get(a, []):
        return "NA"                      # 被挡：世界冻结，另有概念管
    for p in patrols(prev):
        if patrol_facing(prev, *p) is None:
            return "NA"
    want = (_danger(prev, dst) or _swap(prev, a, dst)
            or hud_left(nxt) == 0)
    return "TRUE" if want == (dead == GAME_OVER) else "FALSE"
