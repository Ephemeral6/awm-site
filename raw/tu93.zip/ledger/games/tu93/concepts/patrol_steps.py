"""巡逻兵只在玩家动作生效时走：me 动了，色12 块才沿自己朝向平移一格；me 被挡，世界冻结，它也不动。

v2 死于 490fdcfeb52f7354：me 在 (40,33) 发被墙挡的 A1（(37,33) 无桥），帧上只有 HUD 三格变化，
巡逻兵留在 (34,39) 没走——「每步都走」错了，走棋以玩家的有效动作为节拍。
这也是第 3 关相位墙的一半：被挡动作不能用来调巡逻兵的相位。

LEVEL: L6
SCOPE: 只看帧上有色12 块的动作（ACTION1..4）；色12 块数量变化（生/灭）返回 NA；
       me() 定位不到返回 NA
NOTE: 只管「走没走、走多远、跟不跟着世界节拍」，掉头方向见 patrol_turns。
      「me 动了」用位置平移判定（move_shift 的读法）；被挡 = me 原地 = 冻结。
EVIDENCE: 32ec594bb2809c0d 5e6f831eaaca66dc ad3d4f4ccd3c8e45 490fdcfeb52f7354
"""
import _lib

LEVEL = "L6"
EVIDENCE = ["32ec594bb2809c0d", "5e6f831eaaca66dc", "ad3d4f4ccd3c8e45",
            "490fdcfeb52f7354"]


def assert_(prev, action, nxt, ctx=None):
    if action not in _lib.DELTA:
        return "NA"
    ps = _lib.patrols(prev)
    if not ps:
        return "NA"
    ns = _lib.patrols(nxt)
    if len(ns) != len(ps):
        return "NA"          # 有生有灭就不是「平移」这件事，交给别的概念
    a, b = _lib.me(prev), _lib.me(nxt)
    if a is None or b is None:
        return "NA"
    moved = (a != b)
    for top, left in ps:
        face = _lib.patrol_facing(prev, top, left)
        if face is None:
            return "NA"
        want = (top + face[0], left + face[1])
        back = (top - face[0], left - face[1])
        if moved:
            # 玩家走了棋：巡逻兵必须走一格（直行或掉头后走，两种都算走）
            if want not in ns and back not in ns:
                return "FALSE"
        else:
            # 玩家被挡：世界冻结，巡逻兵必须原地
            if (top, left) not in ns:
                return "FALSE"
    return "TRUE"
