"""色13 块的记号从休眠色15 翻成唤醒色11，就发生在玩家走进它 2 格以内的那一步；翻过就不再翻回。

这是扳机本身。实测第 6 关：玩家在 3~5 格外来回走了 6 步，记号一直是15；
走到 2 格的那一步记号变 11，此后 11 步一直是 11，一次也没变回 15。

对规划的意思：**2 格是安全线**。路线只要不进它 2 格以内，它就是一块布景，
可以当墙绕过去；一旦碰线，它就永久跟着走，只能靠不回头甩开（它每步一格，和我同速）。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；换关那一步返回 NA；"
         "prev 或 nxt 里色13 块不是恰好一个返回 NA；"
         "记号色读不出返回 NA；**prev 里它已经是唤醒色就返回 NA**（那一支是「不再翻回」，"
         "由 chaser_wakes 的每步复核间接管着）")
NOTE = "v1：把 chaser_wakes v1 的距离规则从「动不动」挪到「记号翻不翻」，各归各位。"
EVIDENCE = [
    "79acaaa6c82be897",     # 步309 格距4 → 记号仍是 15
    "c6d89096f585f7e3",     # 步310 格距3→走完变2 → 记号翻成 11
]
# 另有 4 条休眠期的转移没抄进来，留在 held-out 里。

from _lib import me, chasers, chaser_awake, cell_dist, DELTA

WAKE = 2


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    p, q = chasers(prev), chasers(nxt)
    if len(p) != 1 or len(q) != 1:
        return "NA"
    if chaser_awake(prev, *p[0]) is not False:
        return "NA"
    after = chaser_awake(nxt, *q[0])
    b = me(nxt)
    if after is None or b is None:
        return "NA"
    return "TRUE" if after == (cell_dist(q[0], b) <= WAKE) else "FALSE"
