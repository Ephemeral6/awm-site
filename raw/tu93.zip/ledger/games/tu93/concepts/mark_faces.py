"""生效移动后，色4 记号落在玩家块内**朝该动作方向**的那条边的中点——记号是朝向，不跟着块平移。

第 10 步 ACTION4 打脸了「记号随块平移」：块从 (21,27) 移到 (27,27)（ACTION4 竟是向下），
落点上的记号不在平移该到的位置。这条只管记号那一格，块本身归 move_shift。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4 且玩家块确实挪了（me(prev) != me(nxt)）；换关返回 NA；"
         "me() 读不出来返回 NA；nxt 里读不出记号返回 NA")
NOTE = ("v4：apply 在「落点就是目标块」那一步照旧生成同关内的记号，而那一步整屏重画。"
        "结算口径下它本来就 NA（换关返回 NA），所以它从没变成反例——"
        "漏只在**事前口径**里，终局卡第 391 步预测 18 格对 0 格才把它逼出来。"
        "改用帧上的读法（落点是不是目标块，reach_goal 的同一个判据），事前事后都闭嘴。")
EVIDENCE = ["100a66356f23e1f3", "123802eb1d08dd2b", "650dff6793dda42b"]

from _lib import me, DELTA, MARK, MARK_OFFSET, _block_of, mark_cell_for


def _mark_cell_for(top, left, action):
    """共享词 _lib.mark_cell_for 的别名，保留本地名字。"""
    return mark_cell_for(top, left, action)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return "NA"
    m = _block_of(nxt, MARK)
    if m is None:
        return "NA"
    want = _mark_cell_for(b[0], b[1], action)
    if want is None:
        return "NA"
    return "TRUE" if m == want else "FALSE"


def apply(prev, action, ctx=None):
    """只画记号那一格，以及它在块内让位给主体色的那一格——都不画。

    记号的落点由 move_shift 之外的这条概念单独负责：这里只声明记号格。
    """
    from _lib import on_grid, block_color, BRIDGE
    d = DELTA.get(action)
    if d is None:
        return None
    a = me(prev)
    if a is None or not on_grid(*a, prev):
        return None
    if block_color(prev, a[0] + d[0] // 2, a[1] + d[1] // 2) != BRIDGE:
        return None
    b = (a[0] + d[0], a[1] + d[1])
    from _lib import target
    if b == target(prev):
        return None                    # reach_goal：这一步过关，整屏重画，本条不生成
    want = _mark_cell_for(b[0], b[1], action)
    return None if want is None else {want: MARK}
