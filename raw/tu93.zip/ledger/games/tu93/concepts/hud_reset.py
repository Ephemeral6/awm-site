"""过关那一步，HUD 带子回到满格 64——不管进关前还剩多少。

实测 6 次换关，进关前的余额是 35 / 47 / 27 / 13 / 28 / 33，六次之后全是 64。
和 hud_drain 合起来，L4 这个槽才算有东西：预算是**每关一份**，不是全局一份，
所以规划器该按关做预算，上一关省下来的不带过来（也不用心疼）。

v3 死于 a6a2162b82f9d686：最后一关通关那一步，HUD 停在 26 没有回满。
v2 把「过关」当成了「新的一关开始」，可通掉最后一关之后没有下一关——
帧上目标块直接消失，带子就地留在余额上。所以补满的不是「过关」这个事件，
是**新一关被摆出来**这件事；判据也从上游的 level 号改成帧上的读法：
下一帧有没有目标块。这一改还让它在预测口径下也说得出话（那时 state 全是 None）。
"""
LEVEL = "L4"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；"
         "**只管换关那一步**（level_prev != level_next），其余一律 NA；"
         "换关后帧上没有目标块（= 没有下一关了，整局通关）返回 NA")
NOTE = ("v3：v2 在最后一关通关那一步判 FALSE。「过关」不等于「新一关开始」，"
        "末关之后没有新预算可发。")
EVIDENCE = [
    "f78cbb893b781c08",     # 第 24 步 第 0→1 关：35 → 64
    "c22e35c4523c11c9",     # 第 103 步 第 3→4 关：13 → 64（进关前最紧的一次）
    "a6a2162b82f9d686",     # 第 373 步 第 9 关通关：26 没回满，也没有下一关——v2 死在这里
]
# 另外 4 次换关没抄进来，留在 held-out 里当考题。

from _lib import hud_left, target, DELTA

FULL = 64


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") == ctx.get("level_next"):
        return "NA"
    if target(nxt) is None:
        return "NA"
    return "TRUE" if hud_left(nxt) == FULL else "FALSE"
