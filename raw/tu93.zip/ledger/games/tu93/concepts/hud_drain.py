"""同一关内，玩家每发一个 ACTION1..4，HUD 带上的色6 格数就少 1~4 格，绝不变多。

这是本局唯一的资源，也是规划器的预算槽：它给出「一关最多能走多少步」的上界。
实测 159 条关内动作，扣减量的直方图是 1:84  2:38  3:30  4:7，一次都没变多过，
也没有一步是零扣减——**连玩家被挡住原地不动的那些步也照扣**（第 0 关 6 条、第 3 关 1 条）。
所以「白走一步」不是免费的，探索本身要花钱。

单价随关卡变（第 3 关中位 3，第 0/1/4/5 关中位 1，第 2 关中位 2），
但这条不说单价是几，只说它落在 1..4 且方向朝下——多说一个字就得先量出单价由什么定。
查过一个猜法并**否掉**了：单价不是墙钟时间。单价与上游往返时间的相关系数只有 0.104，
第 4、5 关的 rtt 中位（1638 / 1773 ms）和第 3 关（1652 ms）一样，单价却是 1 对 3。
"""
LEVEL = "L4"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；"
         "**换关那一步返回 NA**（那一步 HUD 会回满，归 hud_reset 管）；"
         "state 变了的那一步返回 NA（GAME_OVER 整屏重画，读不出带子）")
NOTE = "v1：L4 计数器一直是空槽，规划器没有预算来源，路线长短全靠手估。"
EVIDENCE = [
    "4e0d440e6017b707", "3c1fd26d11ae6568",
    "fe4e4a78353eab06", "d5b40bf6e1cb4d6a",
    "32ec594bb2809c0d", "5e6f831eaaca66dc",
    "3a868dec317bc1d9", "44dac0b1764895f0",
]

from _lib import hud_left, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx.get("state_prev") != ctx.get("state_next"):
        return "NA"
    return "TRUE" if 1 <= hud_left(prev) - hud_left(nxt) <= 4 else "FALSE"
