"""玩家一步踩进某只色12 巡逻兵所在的格、且移动方向与它朝向垂直时，那只巡逻兵当步消失，且不 GAME_OVER。

和 foe_kills 是同一条击杀规则，只是作用在会动的那一族身上。
在此之前册子里只有「巡逻兵的**落点**踩不得」（game_over 的一支），
从没说过「巡逻兵**当前所在的格**踩进去会怎样」——那一块是空的，
而我第 8 关有一步就是在这块空白上误打误撞过去的：当时以为它凭空消失了，
查像素才知道是被我杀的（色12 从 24 像素掉到 16，记号色15 从 5 掉到 4）。

只此一条证据，N 会很低。写下来是为了让规划器里那句「踩进色12 的格不会死」
指得到一条概念，而不是我脑子里的类比（方法册「危险格表是世界事实」）。
非垂直进入那一支不敢说，语料里 0 条，留 NA。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..4；ctx 缺失、me(prev) 读不出、prev 里没有色12 块，返回 NA；"
         "**落点不是某只色12 块当前所在的格位**返回 NA（绝大多数步都落在这里）；"
         "那只巡逻兵的朝向读不出、或移动方向与它朝向不垂直，返回 NA")
NOTE = ""
EVIDENCE = ["ebf9dd329ff7cfd6"]     # 第 360 步 第 8 关：我向下踩进一只横着走的巡逻兵

from _lib import me, patrols, patrol_facing, DELTA, GAME_OVER_STATE


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    a = me(prev)
    if a is None:
        return "NA"
    ps = patrols(prev)
    if not ps:
        return "NA"
    d = DELTA[action]
    dst = (a[0] + d[0], a[1] + d[1])
    if dst not in ps:
        return "NA"
    f = patrol_facing(prev, dst[0], dst[1])
    if f is None or f[0] * d[0] + f[1] * d[1] != 0:
        return "NA"
    if ctx.get("state_next") == GAME_OVER_STATE:
        return "FALSE"
    return "TRUE" if dst not in patrols(nxt) else "FALSE"
