"""生效的移动一定是整块平移 CELL 格：玩家块整体挪 DELTA[动作]，原位置全变色0，仍是 3x3 实心块。

块**在哪**归这条管；块内那一格色4 记号**指哪**归 mark_faces 管——
第 10 步 ACTION4 的 2 格意外就是这条边界：位置全对，记号错了。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1..4；换关返回 NA；me() 在 prev 或 nxt 读不出来返回 NA；"
         "玩家块没挪（me(prev) == me(nxt)）返回 NA，那一支归 bridge_gate 管；"
         "只主张块的位置与腾出的旧格，不主张块内哪一格是记号")
NOTE = ("v6：apply 在「落点就是目标块」那一步照旧生成同关内的平移，而那一步整屏重画。"
        "结算口径下这条本来就 NA（换关返回 NA），漏只在事前口径里——"
        "终局卡第 391 步预测 18 格对 0 格才把它逼出来。改用帧上的读法（落点是不是目标块）。"
        "v3：v2 的 apply 把整块连同记号一起平移，第 10 步 ACTION4 上错 2 格——"
        "记号不随块平移，它转向。apply 改成只画主体色，记号交给 mark_faces。"
        "v2：v1 拿「prev == nxt」当没生效，但 HUD 带每一步都扣格，整帧永远在变，"
        "于是每条没生效的转移都被当成「生效了却没挪」判 FALSE。")
EVIDENCE = ["123802eb1d08dd2b", "650dff6793dda42b",
            "4e0d440e6017b707", "fe4e4a78353eab06", "3c1fd26d11ae6568",
            "18294bff9809c4a2", "d5b40bf6e1cb4d6a", "ab4e3a81ba768e7f",
            "431ce56dfadcee7f", "100a66356f23e1f3"]

from _lib import me, DELTA, BLOCK, NODE, on_grid, block_color, BRIDGE, PLAYER, MARK


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    if a == b:
        return "NA"
    dr, dc = DELTA[action]
    if (b[0] - a[0], b[1] - a[1]) != (dr, dc):
        return "FALSE"
    # 落点必须仍是 3x3 实心玩家块（主体色 + 恰好一格记号）
    new = {(b[0] + i, b[1] + j) for i in range(BLOCK) for j in range(BLOCK)}
    if sum(1 for (r, c) in new if nxt[r][c] == MARK) != 1:
        return "FALSE"
    if any(nxt[r][c] not in (PLAYER, MARK) for (r, c) in new):
        return "FALSE"
    # 原位置腾出来的那部分必须变成 NODE 色
    old = {(a[0] + i, a[1] + j) for i in range(BLOCK) for j in range(BLOCK)}
    for (r, c) in old - new:
        if nxt[r][c] != NODE:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只在 bridge_gate 说走得动时生成，且**只画主体色**——
    块内哪一格是记号由 mark_faces 单独主张，这条不碰，免得两条概念在同一格上打架。"""
    if action not in DELTA:
        return None
    a = me(prev)
    if a is None or not on_grid(*a, prev):
        return None
    dr, dc = DELTA[action]
    if block_color(prev, a[0] + dr // 2, a[1] + dc // 2) != BRIDGE:
        return None
    from _lib import mark_cell_for, target
    b = (a[0] + dr, a[1] + dc)
    if b == target(prev):
        return None                    # reach_goal：这一步过关，整屏重画，本条不生成
    skip = mark_cell_for(b[0], b[1], action)
    out = {}
    old = {(a[0] + i, a[1] + j) for i in range(BLOCK) for j in range(BLOCK)}
    new = {(b[0] + i, b[1] + j) for i in range(BLOCK) for j in range(BLOCK)}
    for cell in new:
        if cell != skip:
            out[cell] = PLAYER
    for (r, c) in old - new:
        out[(r, c)] = NODE
    return out
