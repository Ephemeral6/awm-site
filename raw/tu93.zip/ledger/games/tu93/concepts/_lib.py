"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源（第 1-8 步）：
    玩家 = 色9 的 8 格 + 色4 的 1 格，合起来是一个 3x3 实心块；色4 占该块的一条边的中点。
    第 4 步 ACTION4：整块 Δ(0,+6)，原位变色0。
    第 7 步 ACTION2：整块 Δ(+6,0)，原位变色0，色4 从右中位移到下中位。
    ACTION1 / ACTION3 至今没生效过（第 1、3、6、8 步都只扣 HUD），所以它们的 DELTA 是**猜的**，
    按「上 / 左」填，等世界来打。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 6               # 一次生效移动的格数（第 4、7 步实测 |Δ| = 6）
BLOCK = 3              # 玩家块 / 地砖块的边长（实测 3x3）

PLAYER = 9             # 玩家块主体色
MARK = 4               # 玩家块上的单格记号，占块内某条边的中点
TARGET = 14            # 全图唯一的另一个 3x3 实心块（开局在 (45,45)）
FOE = 8                # 第 1 关起出现的第二个 3x3 块：会动，撞上就 GAME_OVER
FOE_MARK = 15          # 敌人块上的单格记号，和玩家的色4 同构：指它下一步要走的方向
GAME_OVER_STATE = "GAME_OVER"
HUD_ROW = 63           # 行 63 整行：开局 64 格色6，每步从右端起变色0
HUD_COLOR = 6

# 猜的部分：只有 ACTION2 / ACTION4 有实测支撑
DELTA = {
    "ACTION1": (-CELL, 0),
    "ACTION2": (CELL, 0),
    "ACTION3": (0, -CELL),
    "ACTION4": (0, CELL),
}

# 记号相对块左上角的偏移 -> 方向名。实测：右中位 (1,2)、下中位 (2,1)。
# 上中位 (0,1)、左中位 (1,0) 是按对称补的，没见过。
MARK_OFFSET = {
    (0, 1): (-CELL, 0),
    (2, 1): (CELL, 0),
    (1, 0): (0, -CELL),
    (1, 2): (0, CELL),
}


GRID0 = 15             # 第 0 关的阵列原点。**别直接用**——第 1 关的阵列不在这里。
PITCH = 3              # 块间距 = 块边长
BRIDGE = 2             # 桥色（节点之间的连接块）
NODE = 0               # 节点色（可站的落点）


def grid_origin(g):
    """阵列的相位原点：用玩家块自己的位置反推，而不是抄上一关的常数。

    玩家永远站在一个块角上（19 步实测都是），所以 (me % PITCH) 就是这一关的相位。
    方法册「不继承上一关的常数」：GRID0 是第 0 关量出来的，第 1 关的阵列不在那里。
    """
    a = me(g)
    if a is None:
        return None
    return (a[0] % PITCH, a[1] % PITCH)


def on_grid(top, left, g=None):
    """(top,left) 是不是块阵列上的一个块角。

    给了 g 就用这一帧自己的相位（grid_origin）；没给才退回 GRID0——
    退回那一支只对第 0 关成立，是已知的债。
    """
    if g is not None:
        o = grid_origin(g)
        if o is None:
            return False
        return top % PITCH == o[0] and left % PITCH == o[1]
    return (top - GRID0) % PITCH == 0 and (left - GRID0) % PITCH == 0


def block_color(g, top, left):
    """(top,left) 起的 PITCH×PITCH 块若是纯色就返回该色，越界或不纯返回 None。"""
    if top < 0 or left < 0 or top + PITCH > len(g) or left + PITCH > len(g[0]):
        return None
    vals = {g[top + dr][left + dc] for dr in range(PITCH) for dc in range(PITCH)}
    return vals.pop() if len(vals) == 1 else None


def mark_cell_for(top, left, action):
    """块 (top,left) 上，动作 action 对应的那条边的中点绝对坐标；动作不在表里返回 None。

    共享词：mark_faces 用它做主张，move_shift 用它把这一格让出去（免得两条概念在同一格打架）。
    概念之间不能互相 import——predict 路径下 sys.path 里只有 _lib。
    """
    d = DELTA.get(action)
    if d is None:
        return None
    for off, dd in MARK_OFFSET.items():
        if dd == d:
            return (top + off[0], left + off[1])
    return None


def _block_of(g, color):
    """色 color 的所有格子的 bbox 左上角；没有该色返回 None。"""
    cs = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == color]
    if not cs:
        return None
    return (min(r for r, _ in cs), min(c for _, c in cs))


def me(g):
    """玩家块的 (top_row, left_col)：色9 与色4 合起来的 bbox 左上角。

    只在两者合起来恰好铺满一个 3x3（9 格）时给答案，否则 None——
    「色4 一定嵌在玩家块里」本身是假设，不满足时宁可闭嘴。
    """
    cs = [(r, c) for r, row in enumerate(g)
          for c, v in enumerate(row) if v in (PLAYER, MARK)]
    if len(cs) != BLOCK * BLOCK:
        return None
    top, left = min(r for r, _ in cs), min(c for _, c in cs)
    if set(cs) != {(top + dr, left + dc)
                   for dr in range(BLOCK) for dc in range(BLOCK)}:
        return None
    return (top, left)


def facing(g):
    """色4 记号指的方向，返回 DELTA 里的那种 (dr, dc)；读不出来返回 None。"""
    a = me(g)
    if a is None:
        return None
    m = _block_of(g, MARK)
    if m is None:
        return None
    return MARK_OFFSET.get((m[0] - a[0], m[1] - a[1]))


def target(g):
    """目标块 (top_row, left_col)；不存在返回 None。"""
    return _block_of(g, TARGET)


def foe(g):
    """敌人块（色8 + 色15）的 (top_row, left_col)。

    和 me() 同构：只在两色合起来恰好铺满一个 BLOCK×BLOCK 时给答案。
    第 0 关没有敌人，返回 None——那是对的，不是失败。
    """
    cs = [(r, c) for r, row in enumerate(g)
          for c, v in enumerate(row) if v in (FOE, FOE_MARK)]
    if len(cs) != BLOCK * BLOCK:
        return None
    top, left = min(r for r, _ in cs), min(c for _, c in cs)
    if set(cs) != {(top + dr, left + dc)
                   for dr in range(BLOCK) for dc in range(BLOCK)}:
        return None
    return (top, left)


def foe_mark_offset(g):
    """色15 记号相对敌人块左上角的偏移；读不出来返回 None。"""
    f = foe(g)
    m = _block_of(g, FOE_MARK)
    if f is None or m is None:
        return None
    return (m[0] - f[0], m[1] - f[1])


def foe_facing(g):
    """敌人记号指的方向，返回 DELTA 里的那种 (dr, dc)；读不出来返回 None。

    和玩家的 facing() 共用同一张 MARK_OFFSET 表——这是个**假设**：
    两种记号的读法相同。它没被单独检验过，foe_walks 就是在赌它。
    """
    off = foe_mark_offset(g)
    return None if off is None else MARK_OFFSET.get(off)


PATROL = 12            # 第 3 关起出现的第三种 3x3 块：和色8 同构（8格 + 1格色15）


def _entities(g, body):
    """把「色 body 的格子 + 色15 记号」切成一个个 BLOCK×BLOCK 块。

    色8 和色12 可能同屏（第 3 关），色15 记号也就有多个；
    记号按「落在哪个块的范围里」归属，不靠 _block_of 的唯一性。
    返回 [(top, left), ...]，按 (top, left) 排序。
    """
    body_cs = [(r, c) for r, row in enumerate(g)
               for c, v in enumerate(row) if v == body]
    marks = [(r, c) for r, row in enumerate(g)
             for c, v in enumerate(row) if v == FOE_MARK]
    out = []
    seen = set()
    for r0, c0 in body_cs:
        for top in range(r0 - BLOCK + 1, r0 + 1):
            for left in range(c0 - BLOCK + 1, c0 + 1):
                if (top, left) in seen:
                    continue
                cells = {(top + dr, left + dc)
                         for dr in range(BLOCK) for dc in range(BLOCK)}
                if not all(0 <= r < len(g) and 0 <= c < len(g[0])
                           for r, c in cells):
                    continue
                got = {(r, c) for r, c in cells
                       if g[r][c] == body or (r, c) in marks}
                if got == cells and any((r, c) in marks for r, c in cells):
                    seen.add((top, left))
                    out.append((top, left))
    return sorted(out)


def patrols(g):
    """所有色12 巡逻兵块的 (top, left)，按位置排序；没有就是空表。"""
    return _entities(g, PATROL)


def foes(g):
    """所有色8 敌人块的 (top, left)，按位置排序；没有就是空表。

    和 foe() 的区别：foe() 只在全帧的色8+色15 恰好铺满**一个**块时才给答案，
    多只敌人同屏、或别的带色15 记号的块同屏时，它一律读不出来（返回 None）。
    """
    return _entities(g, FOE)


CHASER = 13            # 第 6 关起出现的第四种块：8格 + 1格记号
CHASER_ASLEEP = 15     # 记号是这个色 = 它休眠，不动
CHASER_AWAKE = 11      # 记号是这个色 = 它已唤醒，每步都动


def chasers(g):
    """所有色13 块的 (top, left)，按位置排序；没有就是空表。

    **不能用 _entities**：那个只认色15 记号，而这种块唤醒后记号会变成色11，
    于是它从块开始动的那一刻起就读不出来了——概念会在最该说话的每一步上返回 NA。
    """
    out = []
    for r in range(len(g) - BLOCK + 1):
        for c in range(len(g[0]) - BLOCK + 1):
            v = [g[r + dr][c + dc] for dr in range(BLOCK) for dc in range(BLOCK)]
            if v.count(CHASER) != BLOCK * BLOCK - 1:
                continue
            if CHASER_ASLEEP not in v and CHASER_AWAKE not in v:
                continue
            if any(abs(r - a) < BLOCK and abs(c - b) < BLOCK for a, b in out):
                continue
            out.append((r, c))
    return sorted(out)


def chaser_mark(g, top, left):
    """那只色13 块的记号 (色, 块内偏移)；读不出返回 (None, None)。"""
    for dr in range(BLOCK):
        for dc in range(BLOCK):
            v = g[top + dr][left + dc]
            if v in (CHASER_AWAKE, CHASER_ASLEEP):
                return v, (dr, dc)
    return None, None


def chaser_awake(g, top, left):
    """那只色13 块醒了没；读不出返回 None。"""
    col, _ = chaser_mark(g, top, left)
    return None if col is None else col == CHASER_AWAKE


def chaser_facing(g, top, left):
    """那只色13 块记号指的方向；读不出返回 None。"""
    _, off = chaser_mark(g, top, left)
    return None if off is None else MARK_OFFSET.get(off)


def cell_dist(p, q):
    """两个块左上角之间的曼哈顿距离，按格（CELL）计。"""
    return (abs(p[0] - q[0]) + abs(p[1] - q[1])) // CELL


BG = 5                 # 底色：占地最多、没人站的那一色


def majority_color(g, top, left):
    """块的多数色。block_color 遇到带记号的块返回 None，这个不会。"""
    if top < 0 or left < 0 or top + PITCH > len(g) or left + PITCH > len(g[0]):
        return None
    v = [g[top + dr][left + dc] for dr in range(PITCH) for dc in range(PITCH)]
    return max(set(v), key=v.count)


def bridge_graph(g):
    """这一帧的落点图：{块角: [相邻块角, ...]}，边 = 中点块的多数色是桥色。

    节点 = 阵列上多数色不是底色的块。和 bridge_gate 赌的是同一张图，
    只是那条概念每次只问一条边，这里把整张图铺开——**是同一个假设的两种用法**。
    """
    o = grid_origin(g)
    if o is None:
        return {}
    ns = set()
    for t in range(o[0], len(g) - PITCH + 1, PITCH):
        for l in range(o[1], len(g[0]) - PITCH + 1, PITCH):
            if majority_color(g, t, l) != BG:
                ns.add((t, l))
    adj = {}
    for n in ns:
        for d in DELTA.values():
            dst = (n[0] + d[0], n[1] + d[1])
            if dst not in ns:
                continue
            if majority_color(g, n[0] + d[0] // 2, n[1] + d[1] // 2) == BRIDGE:
                adj.setdefault(n, []).append(dst)
    return adj


def first_steps(adj, src, dst):
    """adj 上 src 走向 dst 的所有最短路第一步；不连通返回 None，同格返回空集。"""
    from collections import deque
    if src == dst:
        return set()
    dist = {dst: 0}
    q = deque([dst])
    while q:
        u = q.popleft()
        for v in adj.get(u, []):
            if v not in dist:
                dist[v] = dist[u] + 1
                q.append(v)
    if src not in dist:
        return None
    return {v for v in adj.get(src, []) if dist.get(v, 1 << 30) == dist[src] - 1}


def patrol_facing(g, top, left):
    """(top,left) 那只巡逻兵的朝向；读不出来返回 None。

    记号读法沿用 MARK_OFFSET —— 和 foe_facing 赌的是同一个假设。
    """
    for dr in range(BLOCK):
        for dc in range(BLOCK):
            if g[top + dr][left + dc] == FOE_MARK:
                return MARK_OFFSET.get((dr, dc))
    return None


def patrol_next(g, top, left):
    """那只巡逻兵下一步落在哪：朝向上有桥就直行，没桥就反向走一格。

    走法沿用 patrol_turns 的主张（那条概念在这张图上判过 71 次），
    这里只是把「下一步在哪」抽成一个词，好让别的概念拿来当危险格用。
    朝向读不出返回 None。
    """
    f = patrol_facing(g, top, left)
    if f is None:
        return None
    dst = (top + f[0], left + f[1])
    if dst in bridge_graph(g).get((top, left), []):
        return dst
    return (top - f[0], left - f[1])


def hud_left(g):
    """HUD 带上还剩几格色6。行 63 之外的东西一概不看。"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_COLOR)


def walls(g):
    """阻挡格集合。待实测：ACTION1/ACTION3 至今零生效，分不清是出界还是墙。"""
    return None
