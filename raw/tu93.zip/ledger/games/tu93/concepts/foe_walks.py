"""色8 敌人块**不是每步都动**：至少三步连续不动过，而它面前一直有桥。

v1 断言「有桥就走」，被自己的三条依据当场打死（第 25、26、27 步敌人面前是桥却没动）。
现在只保留站得住的那一半：**敌人不动是常态**，它动的时机由别的东西决定，还没量出来。
所以这条只断言否定式：玩家走了不到 3 步（本关内）时，敌人一定不动。
这是能被打的——只要哪一步敌人提前动了，它当场变反例。

样本只有 4 步（第 25-28），「每 4 步动一次」是从单次事件外推的，不写进主张。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；换关返回 NA；prev 或 nxt 里读不出色8 块返回 NA；"
         "GAME_OVER 那一步 nxt 已重画，返回 NA；"
         "只在敌人还停在本关出生点（还一步没走过）时开口——那是唯一实测过的区间")
NOTE = ("v3：v2 想用 ctx['level_step'] 判本关步数，但 ctx 里只有全局 step，没有本关步数——"
        "那是我发明的字段。改成从帧上读：敌人还在出生点时才开口。"
        "v2：v1 说「面前有桥就走」，被第 25/26/27 步三条自己的依据打死——"
        "那三步敌人面前都是桥（色2）却纹丝不动。")
EVIDENCE = ["785a9502477782ff", "e3f0bf006bc8d9b7", "f123c13c36d8bd85",
            "168811c66e944b85"]

from _lib import DELTA, foe, GAME_OVER_STATE

SPAWN = (27, 36)       # 第 1 关敌人的出生点，第 25 步实测。换关要重量。


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if ctx.get("state_next") == GAME_OVER_STATE:
        return "NA"
    if action not in DELTA:
        return "NA"
    f, g2 = foe(prev), foe(nxt)
    if f is None or g2 is None:
        return "NA"
    if f != SPAWN:
        return "NA"                    # 超出实测范围，闭嘴
    return "TRUE" if g2 == f else "FALSE"
