"""巡逻兵沿桥走直路，尽头才掉头：走直（朝向不变）或有桥才走；无桥直行则这一步反向走。

证据：两次掉头都在桥的断头处——(40,39) 向下 (43,39) 无桥 → 反向朝上；
(16,39) 向上 (13,39) 无桥 → 反向朝下。巡逻兵走的每一步（含掉头步）中点都是桥，
和玩家走 bridge_gate 是同一张图。

LEVEL: L6
SCOPE: 帧上有色12 块且玩家动作生效（me 平移了）；动作不是 ACTION1..4 返回 NA
NOTE: 「走没走」归 patrol_steps；这里只管方向——直行还是掉头、掉头的条件。
      桥的读法沿用 _lib.block_color（bridge_gate 赌的同一个词）。
EVIDENCE: ad3d4f4ccd3c8e45 44dac0b1764895f0
"""
import _lib

LEVEL = "L6"
EVIDENCE = ["ad3d4f4ccd3c8e45", "44dac0b1764895f0"]


def _block_color_at(g, top, left):
    return _lib.block_color(g, top, left)


def assert_(prev, action, nxt, ctx=None):
    if action not in _lib.DELTA:
        return "NA"
    ps = _lib.patrols(prev)
    if not ps:
        return "NA"
    ns = _lib.patrols(nxt)
    if len(ns) != len(ps):
        return "NA"
    a, b = _lib.me(prev), _lib.me(nxt)
    if a is None or b is None or a == b:
        return "NA"          # 被挡的世界不归这条管（见 patrol_steps）
    for top, left in ps:
        face = _lib.patrol_facing(prev, top, left)
        if face is None:
            return "NA"
        want = (top + face[0], left + face[1])
        back = (top - face[0], left - face[1])
        if want in ns:
            mid = (top + face[0] // 2, left + face[1] // 2)
            # 直行必须真有桥；没有桥还能直行，说明桥的读法或掉头条件错了
            if _block_color_at(prev, mid[0], mid[1]) != _lib.BRIDGE:
                return "FALSE"
        elif back in ns:
            mid = (top + face[0] // 2, left + face[1] // 2)
            # 掉头只准发生在直行无桥的尽头；有桥还掉头就是反例
            if _block_color_at(prev, mid[0], mid[1]) == _lib.BRIDGE:
                return "FALSE"
        else:
            return "FALSE"   # 既没直行也没反向——斜走/跳格，不在主张内
    return "TRUE"
