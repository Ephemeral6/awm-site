"""色13 块移动时，走的正是它上一帧记号所指的那个方向、恰好 CELL 格。

记号不是装饰，是**预告**：和玩家块的色4 记号、哨兵的色15 记号读同一张 MARK_OFFSET 表，
指向它下一步要去的格。所以看一眼当前帧就知道它下一步落在哪——
不必知道它用什么算法追人，也不必回忆自己走过哪条路。

v1 只敢说「位移是 CELL 格、四个正方向之一」，那时 chasers() 读不出唤醒态的块，
这条概念在全部 11 次移动上都没开过口（N=0）。词汇修好之后方向那一半也能一起说了。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；换关那一步返回 NA；"
         "prev 或 nxt 里色13 块不是恰好一个返回 NA；"
         "**它这一步没动就返回 NA**（那一支归 chaser_wakes）；记号方向读不出返回 NA")
NOTE = "v2：v1 因 chasers() 读不出唤醒态而恒 NA；修词汇后把方向也纳入主张。"
EVIDENCE = [
    "c58260689f785e64",     # 步311 (18,24)->(24,24)  记号指下
    "8653f9fe490ecbcd",     # 步317 (42,36)->(36,36)  记号指上
]
# 另有 9 条移动没抄进来，留在 held-out 里。

from _lib import chasers, chaser_facing, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    p, q = chasers(prev), chasers(nxt)
    if len(p) != 1 or len(q) != 1 or p[0] == q[0]:
        return "NA"
    f = chaser_facing(prev, *p[0])
    if f is None:
        return "NA"
    got = (q[0][0] - p[0][0], q[0][1] - p[0][1])
    return "TRUE" if got == f else "FALSE"
