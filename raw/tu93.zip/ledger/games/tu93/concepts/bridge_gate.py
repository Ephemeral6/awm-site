"""移动生效 iff 玩家与落点之间的那个中间块是桥（色2）；不是桥就整帧活动区不动。

玩家块 3x3 站在阵列的一个块角上，一次移动跨 PITCH*2 = CELL 格，正好越过一个中间块。
主张：中间块是纯色2 才走得动。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..4；换关返回 NA；me() 读不出来返回 NA；"
         "me() 不在阵列块角上返回 NA")
NOTE = ""
EVIDENCE = ["123802eb1d08dd2b", "650dff6793dda42b", "18294bff9809c4a2"]

from _lib import me, DELTA, block_color, on_grid, BRIDGE, PITCH


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    a = me(prev)
    if a is None or not on_grid(*a, prev):
        return "NA"
    dr, dc = DELTA[action]
    mid = block_color(prev, a[0] + dr // 2, a[1] + dc // 2)
    moved = me(nxt) != a
    return "TRUE" if (mid == BRIDGE) == moved else "FALSE"
