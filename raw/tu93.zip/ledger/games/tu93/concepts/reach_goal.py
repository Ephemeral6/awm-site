"""踩上目标块（色14）当步换关；没踩上绝不换关——**只用 prev 判**。

v1 死于 f78cbb893b781c08：换关那一帧整屏重画，我却拿 nxt 里的玩家块去和 **prev** 的目标块比。
换关后 me(nxt) 读出来的是新关的玩家位置，跟旧关的目标块毫无关系，于是判 FALSE。
判据必须只用「动作之前的局面 + 这个动作」算，不能读换关后的帧——那一帧已经是另一个世界了。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；me(prev) 读不出来返回 NA；"
         "prev 里读不出目标块返回 NA；me(prev) 不在阵列块角上返回 NA。"
         "只用 prev 与 action 推落点，一格都不读 nxt")
NOTE = ("v2：v1 拿 me(nxt) 和 target(prev) 比，换关重画那一帧 nxt 是新关的世界，比出来必错。"
        "改成从 prev 算落点：走得动就落在 me(prev)+DELTA，走不动就还在原地。")
EVIDENCE = ["28d9c01f282a2422", "2ad77e018e642ab7", "794190918c9b25b7",
            "f78cbb893b781c08"]

from _lib import me, DELTA, target, on_grid, block_color, BRIDGE


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    d = DELTA.get(action)
    if d is None:
        return "NA"
    t = target(prev)
    a = me(prev)
    if t is None or a is None or not on_grid(*a, prev):
        return "NA"
    # 落点：中间块是桥才走得动（bridge_gate 的判据），否则原地不动
    if block_color(prev, a[0] + d[0] // 2, a[1] + d[1] // 2) == BRIDGE:
        landing = (a[0] + d[0], a[1] + d[1])
    else:
        landing = a
    leveled = ctx["level_prev"] != ctx["level_next"]
    return "TRUE" if (landing == t) == leveled else "FALSE"

