"""色13 块这一步动不动，等于它上一帧的记号是不是唤醒色 11。

v1 说的是「离玩家 ≤2 格就动」，那条在语料上也全中，但它错过了真正的读法：
块上的记号会变色。休眠时记号是色15（和哨兵、巡逻兵的记号同色），
被唤醒的那一帧变成色11，从下一步起每步都动，再没变回去过。

这比距离规则更基本，也更好用：**一帧就能看出它醒没醒**，不必回忆玩家走过哪。
距离只是把记号从15 翻成11 的那个扳机，归 chaser_alarm 管。

v1 还带着一个词汇上的内伤：chasers() 当时套用共用的 _entities，而那个只认色15 记号，
于是块一开始动、记号一变色，它就读不出来——概念在最该说话的 11 步上全部返回 NA，
N=0 却挂着满分。这次连词一起修了。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；换关那一步返回 NA（整屏重画）；"
         "prev 或 nxt 里色13 块不是恰好一个返回 NA；记号色读不出返回 NA")
NOTE = ("v2：改用记号色判醒没醒（v1 用的是与玩家的格距）；"
        "同时修 chasers() —— 它此前读不出唤醒态的块，让 v1 的分数是从沉默里换来的。")
EVIDENCE = [
    "79acaaa6c82be897",     # 步309 记号15 → 不动
    "c58260689f785e64",     # 步311 记号11 → 动（唤醒后第一步）
]
# 语料里另有 4 条休眠、10 条唤醒没抄进来，留在 held-out 里。

from _lib import chasers, chaser_awake, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    p, q = chasers(prev), chasers(nxt)
    if len(p) != 1 or len(q) != 1:
        return "NA"
    awake = chaser_awake(prev, *p[0])
    if awake is None:
        return "NA"
    return "TRUE" if (p[0] != q[0]) == awake else "FALSE"
