"""玩家一步踩进某只色8 敌人所在的格、且移动方向与它朝向垂直时，那只敌人当步消失，且不 GAME_OVER。

我三关的路线都靠这条走通，可它到今天一句口都没开过（N=0、NA 率 100%）——
因为 v2 用的 foe() 是单数读法：全帧色8+色15 恰好铺满一个块才给答案。
第 3 关起多只敌人同屏，巡逻兵也带色15 记号，它就永远读不出来，
于是这条概念在它最该说话的每一步上都返回 NA。**没被检验，不等于没被推翻。**

v3 换成 foes()（多只），并把「踩进去会怎样」正面说出来：
垂直进入 ⇒ 下一帧那个格位上不再有色8 块，且 state 不是 GAME_OVER。
非垂直进入那一支仍不敢说（语料里 0 条），留 NA。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..4；ctx 缺失返回 NA；me(prev) 读不出返回 NA；"
         "prev 里没有色8 块返回 NA；"
         "**落点不是某只色8 块所在的格位**返回 NA（绝大多数步都落在这里）；"
         "那只敌人的朝向读不出、或移动方向与它朝向不垂直，返回 NA")
NOTE = ("v3：v2 的 foe() 在多只敌人同屏时恒为 None，这条概念因此在 162 条 held-out 上"
        "全部 NA——满分的 S 是从没开过口换来的。改用 foes() 并把击杀那一半正面断言。")
EVIDENCE = [
    "551f0807fcbb198c",     # 第 39 步 第 2 关：敌人朝左，我从下往上踩进去
    "33d11ec0c3b6e12f",     # 第 55 步 第 3 关：敌人朝下，我从左往右踩进去
    "9c086ca8055d95ce",     # 第 159 步 第 5 关：敌人朝上，我从右往左踩进去
]
# 语料里另有 8 条同型转移**没抄进来**：它们留在 held-out 里当这条概念的考题。
# 把依据抄全了，N 就是 0——那样的 S=1 只是「它在自己挑的题上没错」。

from _lib import me, foes, patrol_facing, DELTA, GAME_OVER_STATE


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action not in DELTA:
        return "NA"
    a = me(prev)
    if a is None:
        return "NA"
    fs = foes(prev)
    if not fs:
        return "NA"
    d = DELTA[action]
    dst = (a[0] + d[0], a[1] + d[1])
    if dst not in fs:
        return "NA"
    f = patrol_facing(prev, dst[0], dst[1])
    if f is None or f[0] * d[0] + f[1] * d[1] != 0:
        return "NA"
    if ctx.get("state_next") == GAME_OVER_STATE:
        return "FALSE"
    return "TRUE" if dst not in foes(nxt) else "FALSE"
