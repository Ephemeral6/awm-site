/-
# Rule/Move/Drift —— 规则 `drift`（对应 `rule/一步怎么走/drift.py`）

**漂：顺着重力一格一格穿过能进的格，停在第一个不能进的格前面。**
漂进十字那一格就是过关；前面是模型不知道的格（`unk`）就说不出话。

`fuel` 只是为了让递归停得下来：一关总共那么多行，漂的格数不会超过它。
燃料用完还没停 = 漂出了地图 = `unknown`（不是编一个落点出来）。
-/

import Obj.Level.State

namespace Game

inductive Drift where
  | stop (r : Int)
  | goal
  | unknown
  deriving DecidableEq, Repr

/-- 从第 `r` 行往 `d` 方向漂（第 `c` 列）。 -/
def driftFrom (m : Map) (c d : Int) : Nat → Int → Drift
  | 0, _ => .unknown
  | n + 1, r =>
    match m.get (r + d) c with
    | .goal => .goal
    | .unk => .unknown
    | t => if t.passable = true then driftFrom m c d n (r + d) else .stop r

/-- **规则 drift**：从 (r, c) 顺着重力 `g` 漂到挡住为止。 -/
def drift (m : Map) (r c : Int) (g : Grav) : Drift :=
  driftFrom m c g.dir (m.length + 1) r

end Game
