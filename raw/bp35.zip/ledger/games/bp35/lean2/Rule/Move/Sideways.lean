/-
# Rule/Move/Sideways —— 规则 `sideways`（对应 `rule/一步怎么走/sideways.py`）

**横着只有左右走会挪。** 左右走时，玩家那一行里左 / 右那一格能进（液体或空槽），
就挪过去一列，否则原地；鼻子转过去，走不动也转。点击不挪、不转。

这是一条**定义**，不是定理：「左右走挪一列」就是左右走的意思。
-/

import Obj.Level.State
import Obj.Action.Act

namespace Game

/-- 横着挪几列：左 -1、右 +1、别的 0。 -/
def Act.dc : Act → Int
  | .left => -1
  | .right => 1
  | _ => 0

/-- **规则 sideways（列）**：挪完之后在第几列。 -/
def sideways (m : Map) (r c : Int) (a : Act) : Int :=
  if a.dc ≠ 0 ∧ (m.get r (c + a.dc)).passable = true then c + a.dc else c

/-- **规则 sideways（朝向）**：按左朝左、按右朝右；别的动作不转。 -/
def turn (f : Facing) : Act → Facing
  | .left => .l
  | .right => .r
  | _ => f

end Game
