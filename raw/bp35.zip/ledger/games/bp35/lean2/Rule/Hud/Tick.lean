/-
# Rule/Hud/Tick —— 规则 `hud_tick`（对应 `rule/计数/hud_tick.py`）

**每发一个动作计步条加一格**（走不走得动、点没点中、撤销，都算）。
过关清零那一半不在这里：过关之后是另一关的开局，模型不描述「下一关长什么样」。
它改的是 `State.hud`（对象层那一份），所以 import 对象层。
-/

import Obj.Level.State

namespace Game

/-- **规则 hud_tick**。 -/
def tick (h : Nat) : Nat := h + 1

end Game
