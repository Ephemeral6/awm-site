/-
# Rule/Win/GoalWins —— 规则 `goal_wins`（对应 `rule/什么算赢/goal_wins.py`）

**过关 ⇔ 玩家走进或漂进十字那一格。** 横着那一半在这里（`walksIntoGoal`），
竖着那一半在 `drift` 的 `.goal` 那一支；两半在 `Step.lean` 里接成 `Res.won`。

`isGoal` 是**状态**的性质（玩家站在十字上）——「赢」不能只是一个转移事件，
否则「这个局面可不可做」无从问起。
-/

import Obj.Level.State
import Rule.Move.Sideways

namespace Game

/-- 玩家站在十字上。 -/
def isGoal (s : State) : Bool := s.map.get s.r s.c == .goal

/-- **规则 goal_wins（横着那一半）**：这一下左右走，目标格就是十字。 -/
def walksIntoGoal (m : Map) (r c : Int) (a : Act) : Bool :=
  a.dc != 0 && m.get r (c + a.dc) == .goal

end Game
