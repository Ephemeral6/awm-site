/-
# Rule/Click/Opens —— 规则 `opens`（对应 `rule/点击怎么回应/opens.py`）

**一次性的门：SHELL / SWITCH / FOAM 被点，那一格变成液体，变不回去。**
三种的差别不在「那一格变成什么」，在副作用：开关还翻重力（`gravity`），泡沫还长一圈（`foam_spreads`）。
-/

import Obj.Board.Tile

namespace Game

/-- **规则 opens**：被点的那一格变成什么；不是这三种就 `none`。 -/
def opens : Tile → Option Tile
  | .shell => some .liquid
  | .switch => some .liquid
  | .foam => some .liquid
  | _ => none

end Game
