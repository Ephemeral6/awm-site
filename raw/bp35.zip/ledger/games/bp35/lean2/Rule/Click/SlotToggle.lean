/-
# Rule/Click/SlotToggle —— 规则 `slot_toggle`（对应 `rule/点击怎么回应/slot_toggle.py`）

**槽：点空槽放进一块，点块取走变回空槽。** 一来一回，点两次回到原样
（那一句是推论，见 `Derived/SlotToggle.lean`）。
-/

import Obj.Board.Tile

namespace Game

/-- **规则 slot_toggle**：空槽 ⇄ 块；别的 `none`。 -/
def toggle : Tile → Option Tile
  | .slot => some .block
  | .block => some .slot
  | _ => none

end Game
