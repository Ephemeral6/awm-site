/-
# Rule/Click/Gravity —— 规则 `gravity`（对应 `rule/点击怎么回应/gravity.py`）

**重力只被开关翻：点中开关，上浮 ⇄ 下沉；别的动作一概不翻。**
-/

import Obj.Board.Tile
import Obj.Player.Gravity

namespace Game

/-- **规则 gravity**：点中的那一格是 `t` 时，重力变成什么。 -/
def gravAfter (g : Grav) (t : Tile) : Grav :=
  if t = .switch then g.flip else g

end Game
