/-
# Rule/Click/FoamSpreads —— 规则 `foam_spreads`（对应 `rule/点击怎么回应/foam_spreads.py`）

**点泡沫时，被点那一格上下左右四格里原来是液体的，变成泡沫；玩家那一格不长。**
-/

import Obj.Level.State

namespace Game

/-- 一格：是液体、又不是玩家那一格，就变成泡沫。`(pr, pc)` 是玩家。 -/
def spreadOne (m : Map) (pr pc r c : Int) : Map :=
  if r = pr ∧ c = pc then m
  else if m.get r c = .liquid then m.set r c .foam else m

/-- **规则 foam_spreads**：以 (r, c) 为中心的四邻。 -/
def spread (m : Map) (pr pc r c : Int) : Map :=
  spreadOne (spreadOne (spreadOne (spreadOne m pr pc (r - 1) c) pr pc (r + 1) c) pr pc r (c - 1)) pr pc r (c + 1)

end Game
