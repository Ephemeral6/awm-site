/-
# Derived/BoardPersists —— 规则 `board_persists` 的身份：**推论**

Python 那边 `board_persists` 是一条每步都要对语料判的规则（「没被点到的格对齐之后一格不变」）。
在模型里它**不是一条独立的规则**：地图只在点击那一支被 `Map.set` 改，
而 `Map.set` 只动它改的那一格——所以「其余的格原样」是架构推出来的，这里把它证出来。

  persists_walk    左右走、点在缝上：地图一格不变
  persists_click   点在 (r+dr, c)：被点那一格和它上下左右四格之外，一格不变

「这条推论会不会失败」：把 `clickAt` 改成顺手多改一格（比如点一下把正下方也改成液体），
`persists_click` 就证不出来——那正是 Python 那条规则当初要挡的事。

证明里用到的列表事实（改第 n 个不动第 k 个）写在证明体里，不另立定理：
另立的话它们的语句里没有 `step` / `World`，那是关于列表的事，不是关于这一局的事。
-/

import Obj.Level.State
import Step

open Game

/-- **推论 board_persists（左右走 / 点缝）**：地图一格不变。 -/
theorem persists_walk (s s' : State) (a : Act) (ha : a = .left ∨ a = .right ∨ a = .gap)
    (h : step s a = .ok s') : s'.map = s.map := by
  rcases ha with rfl | rfl | rfl <;>
  · simp only [step] at h
    split at h
    · cases h
    · split at h
      · cases h
      · cases h
      · cases h; rfl

/-- **推论 board_persists（点击）**：点在 (s.r+dr, c)，那一格和它四邻之外，地图一格不变。 -/
theorem persists_click (s s' : State) (dr c : Int) (h : step s (.click dr c) = .ok s')
    (r' c' : Int)
    (h0 : ¬ (r' = s.r + dr ∧ c' = c)) (h1 : ¬ (r' = s.r + dr - 1 ∧ c' = c))
    (h2 : ¬ (r' = s.r + dr + 1 ∧ c' = c)) (h3 : ¬ (r' = s.r + dr ∧ c' = c - 1))
    (h4 : ¬ (r' = s.r + dr ∧ c' = c + 1)) :
    s'.map.get r' c' = s.map.get r' c' := by
  -- 列表事实：改第 n 个不动第 k 个
  have setAt_ne : ∀ (l : List Tile) (n k : Nat) (v d : Tile), k ≠ n →
      (setAt l n v).getD k d = l.getD k d := by
    intro l
    induction l with
    | nil => intro n k v d _; simp [setAt]
    | cons x xs ih =>
      intro n k v d hk
      cases n with
      | zero => cases k with
        | zero => exact absurd rfl hk
        | succ k => simp [setAt]
      | succ n => cases k with
        | zero => simp [setAt]
        | succ k => simp only [setAt, List.getD_cons_succ]; exact ih n k v d (by omega)
  have modAt_ne : ∀ (l : List (List Tile)) (n k : Nat) (f : List Tile → List Tile) (d : List Tile),
      k ≠ n → (modAt l n f).getD k d = l.getD k d := by
    intro l
    induction l with
    | nil => intro n k f d _; simp [modAt]
    | cons x xs ih =>
      intro n k f d hk
      cases n with
      | zero => cases k with
        | zero => exact absurd rfl hk
        | succ k => simp [modAt]
      | succ n => cases k with
        | zero => simp [modAt]
        | succ k => simp only [modAt, List.getD_cons_succ]; exact ih n k f d (by omega)
  have modAt_same : ∀ (l : List (List Tile)) (n : Nat) (f : List Tile → List Tile), f [] = [] →
      (modAt l n f).getD n [] = f (l.getD n []) := by
    intro l
    induction l with
    | nil => intro n f hf; simp [modAt, hf]
    | cons x xs ih =>
      intro n f hf
      cases n with
      | zero => simp [modAt]
      | succ n => simp only [modAt, List.getD_cons_succ]; exact ih n f hf
  -- 地图上：改 (r, c) 不动别的格
  have setKeep : ∀ (m : Map) (r c r' c' : Int) (t : Tile), ¬ (r' = r ∧ c' = c) →
      (m.set r c t).get r' c' = m.get r' c' := by
    intro m r c r' c' t hne
    unfold Map.set
    by_cases hneg : r < 0 ∨ c < 0
    · simp [hneg]
    · simp only [hneg, ite_false]
      unfold Map.get
      by_cases hneg' : r' < 0 ∨ c' < 0
      · simp [hneg']
      · simp only [hneg', ite_false]
        by_cases hr : r'.toNat = r.toNat
        · rw [hr, modAt_same _ _ _ (by simp [setAt])]
          have hc : c'.toNat ≠ c.toNat := by
            intro hc; apply hne; constructor <;> omega
          exact setAt_ne _ _ _ _ _ hc
        · rw [modAt_ne _ _ _ _ _ hr]
  -- 一次「长泡沫」只可能动那一格
  have spreadKeep : ∀ (m : Map) (pr pc r c r' c' : Int), ¬ (r' = r ∧ c' = c) →
      (spreadOne m pr pc r c).get r' c' = m.get r' c' := by
    intro m pr pc r c r' c' hne
    unfold spreadOne
    split
    · rfl
    · split
      · exact setKeep m r c r' c' _ hne
      · rfl
  -- 从 step 读出新地图 = clickAt …
  have hm : s'.map = clickAt s.map s.r s.c (s.r + dr) c := by
    simp only [step] at h
    split at h
    · cases h
    · split at h
      · cases h
      · cases h
      · cases h; rfl
  rw [hm]
  unfold clickAt
  split
  · rfl
  · split
    · split
      · unfold spread
        rw [spreadKeep _ _ _ _ _ _ _ h4, spreadKeep _ _ _ _ _ _ _ h3,
            spreadKeep _ _ _ _ _ _ _ h2, spreadKeep _ _ _ _ _ _ _ h1, setKeep _ _ _ _ _ _ h0]
      · exact setKeep _ _ _ _ _ _ h0
    · split
      · exact setKeep _ _ _ _ _ _ h0
      · rfl

#print axioms persists_walk
#print axioms persists_click

