/-
# Derived/BlockedNoSwitch —— 规则 `blocked_no_switch` 的身份：**推论**

起点册子里它是一条「第 5 关做不了」的阻断主张。在这一套模型里它是一条**关于一步**的推论：

> 玩家在上浮、这一步没点开关、而整关里玩家这一行及以上一个十字都没有 ⇒ 这一步不过关。

它由 sideways（横着只挪一列、只在玩家那一行）、gravity（不点开关不翻）、drift（上浮只往上漂）、
goal_wins（过关 = 走进 / 漂进十字）、以及「点击不会造出十字」推出来——所以它不该是一条独立的规则。

**它说的是「这一步」，不是「这一关」**：下一步点个开关、翻成下沉，十字照样够得着。
册子当年把这句话读成了「这一关做不了」，而那一关在这批语料里是过了的。
-/

import Obj.Level.State
import Step

open Game

/-- **推论 blocked_no_switch**。 -/
theorem up_goal_below_no_win (s : State) (a : Act)
    (hg : s.g = .up)
    (hsw : ∀ dr c, a = .click dr c → s.map.get (s.r + dr) c ≠ .switch)
    (hgoal : ∀ r' c', r' ≤ s.r → s.map.get r' c' ≠ .goal) :
    step s a ≠ .won := by
  -- 列表事实：改第 n 个，第 k 个要么是新值、要么原样
  have setAt_mem : ∀ (l : List Tile) (n k : Nat) (v d : Tile),
      (setAt l n v).getD k d = v ∨ (setAt l n v).getD k d = l.getD k d := by
    intro l
    induction l with
    | nil => intro n k v d; right; simp [setAt]
    | cons x xs ih =>
      intro n k v d
      cases n with
      | zero => cases k with
        | zero => left; simp [setAt]
        | succ k => right; simp [setAt]
      | succ n => cases k with
        | zero => right; simp [setAt]
        | succ k => simp only [setAt, List.getD_cons_succ]; exact ih n k v d
  have modAt_mem : ∀ (l : List (List Tile)) (n k : Nat) (f : List Tile → List Tile),
      (modAt l n f).getD k [] = f (l.getD k []) ∨ (modAt l n f).getD k [] = l.getD k [] := by
    intro l
    induction l with
    | nil => intro n k f; right; simp [modAt]
    | cons x xs ih =>
      intro n k f
      cases n with
      | zero => cases k with
        | zero => left; simp [modAt]
        | succ k => right; simp [modAt]
      | succ n => cases k with
        | zero => right; simp [modAt]
        | succ k => simp only [modAt, List.getD_cons_succ]; exact ih n k f
  -- 改一格造不出十字（除非改成的就是十字）
  have setNoGoal : ∀ (m : Map) (r c r' c' : Int) (t : Tile), t ≠ .goal →
      (m.set r c t).get r' c' = .goal → m.get r' c' = .goal := by
    intro m r c r' c' t ht h
    unfold Map.set at h
    by_cases hneg : r < 0 ∨ c < 0
    · simpa [hneg] using h
    · simp only [hneg, ite_false] at h
      unfold Map.get at h ⊢
      by_cases hneg' : r' < 0 ∨ c' < 0
      · simp [hneg'] at h
      · simp only [hneg', ite_false] at h ⊢
        rcases modAt_mem m r.toNat r'.toNat (fun row => setAt row c.toNat t) with h1 | h1
        · rw [h1] at h
          rcases setAt_mem (m.getD r'.toNat []) c.toNat c'.toNat t .unk with h2 | h2
          · rw [h2] at h; exact absurd h ht
          · rw [h2] at h; exact h
        · rw [h1] at h; exact h
  -- 点击造不出十字
  have spreadOneNoGoal : ∀ (m : Map) (pr pc r c r' c' : Int),
      (spreadOne m pr pc r c).get r' c' = .goal → m.get r' c' = .goal := by
    intro m pr pc r c r' c' h
    unfold spreadOne at h
    split at h
    · exact h
    · split at h
      · exact setNoGoal m r c r' c' .foam (by decide) h
      · exact h
  have clickNoGoal : ∀ (m : Map) (pr pc r c r' c' : Int),
      (clickAt m pr pc r c).get r' c' = .goal → m.get r' c' = .goal := by
    intro m pr pc r c r' c' h
    unfold clickAt at h
    split at h
    · exact h
    · split at h
      · rename_i t ht
        have htg : t ≠ .goal := by
          intro e; subst e
          revert ht; cases m.get r c <;> simp [opens]
        split at h
        · unfold spread at h
          exact setNoGoal _ _ _ _ _ _ htg (spreadOneNoGoal _ _ _ _ _ _ _
            (spreadOneNoGoal _ _ _ _ _ _ _ (spreadOneNoGoal _ _ _ _ _ _ _ (spreadOneNoGoal _ _ _ _ _ _ _ h))))
        · exact setNoGoal _ _ _ _ _ _ htg h
      · split at h
        · rename_i t ht
          have htg : t ≠ .goal := by
            intro e; subst e
            revert ht; cases m.get r c <;> simp [toggle]
          exact setNoGoal _ _ _ _ _ _ htg h
        · exact h
  have preNoGoal : ∀ r' c', r' ≤ s.r → (preMap s a).get r' c' ≠ .goal := by
    intro r' c' hr hgl
    cases a with
    | click dr c => exact hgoal r' c' hr (clickNoGoal _ _ _ _ _ _ _ hgl)
    | left => exact hgoal r' c' hr hgl
    | right => exact hgoal r' c' hr hgl
    | undo => exact hgoal r' c' hr hgl
    | gap => exact hgoal r' c' hr hgl
  have preUp : preGrav s a = .up := by
    cases a with
    | click dr c =>
      simp only [preGrav]
      split
      · exact hg
      · unfold gravAfter
        have := hsw dr c rfl
        simp [this, hg]
    | _ => simp [preGrav, hg]
  -- 上浮只往上漂：一路上的格都在玩家这一行及以上，没有十字
  have driftNoGoal : ∀ (m : Map) (c : Int) (fuel : Nat) (r : Int),
      (∀ r' c', r' ≤ s.r → m.get r' c' ≠ .goal) → r ≤ s.r → driftFrom m c (-1) fuel r ≠ .goal := by
    intro m c fuel
    induction fuel with
    | zero => intro r _ _; simp [driftFrom]
    | succ n ih =>
      intro r hm hr
      simp only [driftFrom]
      have hng := hm (r + -1) c (by omega)
      split
      · rename_i heq; exact absurd heq hng
      · simp
      · split
        · exact ih (r + -1) hm (by omega)
        · simp
  -- 横着那一半：走进的那一格就在玩家这一行
  have noWalk : walksIntoGoal s.map s.r s.c a = false := by
    unfold walksIntoGoal
    have := hgoal s.r (s.c + a.dc) (Int.le_refl _)
    simp [this]
  cases a with
  | undo => simp [step]
  | _ =>
    simp only [step, noWalk, Bool.false_eq_true, ↓reduceIte]
    intro h
    split at h
    · rename_i hd
      rw [preUp] at hd
      exact driftNoGoal _ _ _ _ preNoGoal (Int.le_refl _) hd
    · cases h
    · cases h

#print axioms up_goal_below_no_win

