/-
# Proof/Levels —— 每一关一条定理（**自动生成，不要手改**；讲解在 `export_levels.py`）

    L<n>_start_seen  开局状态拍下来 = 这一关第一帧
    L<n>_len         逐帧核的步数
    L<n>_trace       沿真实走法逐帧对上（模型自己算状态），最后一步过关
    L<n>_winnable    这一关走得通

**明写的假设（撤销 = 弹栈）**：撤销不进模型；`traceEnd` 按弹栈处理它，撤销之后那一帧必须对上。
没红不构成证明，但那是这条假设在这批语料上唯一一次有机会被驳倒。

**明写的口径（整关地图）**：开局状态的地图是整关取并集的那一张，比玩家开局那一帧知道得多。

**明写的削弱（预算）**：模型里没有步数预算，`Winnable` 是「不管预算，走得通」。
-/

import Obj.Level.State
import Obs.Replay
import Proof.Reachable

set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- 定理放在根上、不进命名空间：装置的 `lean_check` 按定理名逐条 `#print axioms`，
-- 不认命名空间（带前缀的名字它会报「找不到」）。
open Game Game.Replay


/-! ## 第 0 关：seq 1..32（真人 32 步，其中撤销 5 步；过关在 seq 32） -/

def L0_start : State := levelStarts.getD 0 default
def L0_play : List (Act × World) := (between 1 31).map (fun r => (r.act, r.next))
def L0_last : Act := .left
def L0_route : List Act := [.right, .click (-1) (7), .left, .click (0) (4), .click (-4) (5), .right, .right, .right, .right, .left, .left, .left, .click (-1) (5), .click (0) (2), .click (-1) (4), .click (0) (4), .left, .click (-1) (4), .click (-1) (5), .right, .left, .left]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L0_start_seen : view (L0_start : State) = (((between 1 1).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 31 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L0_len : (L0_play : List (Act × World)).length = 31 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L0_trace : traceEnd [] (L0_start : State) (L0_play : List (Act × World)) L0_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L0_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 22 步。 -/
theorem L0_winnable : ∃ as : List Act, stepWins (L0_start : State) as = true :=
  ⟨L0_route, by decide +kernel⟩

#print axioms L0_start_seen
#print axioms L0_len
#print axioms L0_trace
#print axioms L0_winnable
#eval "L0 firstSplit=" ++ toString (firstSplit [] L0_start L0_play 0) ++ " checked=" ++ toString L0_play.length


/-! ## 第 1 关：seq 33..75（真人 43 步，其中撤销 0 步；过关在 seq 75） -/

def L1_start : State := levelStarts.getD 1 default
def L1_play : List (Act × World) := (between 33 74).map (fun r => (r.act, r.next))
def L1_last : Act := .right
def L1_route : List Act := [.right, .right, .right, .click (-1) (6), .click (-1) (6), .click (0) (5), .left, .click (0) (4), .left, .click (0) (3), .left, .click (0) (2), .left, .click (-1) (2), .right, .right, .right, .click (-1) (5), .click (-1) (5), .click (0) (8), .left, .left, .click (-1) (3), .click (-1) (3), .click (-1) (3), .click (0) (4), .right, .click (0) (5), .right, .click (0) (6), .right, .click (0) (7), .right, .click (0) (8), .right, .click (-1) (8), .click (-1) (8), .left, .left, .left, .left, .click (-1) (4), .right]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L1_start_seen : view (L1_start : State) = (((between 33 33).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 42 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L1_len : (L1_play : List (Act × World)).length = 42 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L1_trace : traceEnd [] (L1_start : State) (L1_play : List (Act × World)) L1_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L1_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 43 步。 -/
theorem L1_winnable : ∃ as : List Act, stepWins (L1_start : State) as = true :=
  ⟨L1_route, by decide +kernel⟩

#print axioms L1_start_seen
#print axioms L1_len
#print axioms L1_trace
#print axioms L1_winnable
#eval "L1 firstSplit=" ++ toString (firstSplit [] L1_start L1_play 0) ++ " checked=" ++ toString L1_play.length


/-! ## 第 2 关：seq 76..109（真人 34 步，其中撤销 0 步；过关在 seq 109） -/

def L2_start : State := levelStarts.getD 2 default
def L2_play : List (Act × World) := (between 76 108).map (fun r => (r.act, r.next))
def L2_last : Act := .right
def L2_route : List Act := [.right, .click (0) (5), .right, .right, .click (-1) (6), .click (-1) (5), .click (-1) (4), .click (-1) (3), .left, .left, .left, .left, .right, .click (0) (5), .click (-1) (5), .click (0) (6), .click (-1) (6), .right, .right, .right, .right, .click (-1) (6), .click (-1) (5), .click (-1) (4), .left, .left, .left, .click (-1) (3), .left, .right, .click (0) (5), .right, .right, .right]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L2_start_seen : view (L2_start : State) = (((between 76 76).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 33 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L2_len : (L2_play : List (Act × World)).length = 33 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L2_trace : traceEnd [] (L2_start : State) (L2_play : List (Act × World)) L2_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L2_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 34 步。 -/
theorem L2_winnable : ∃ as : List Act, stepWins (L2_start : State) as = true :=
  ⟨L2_route, by decide +kernel⟩

#print axioms L2_start_seen
#print axioms L2_len
#print axioms L2_trace
#print axioms L2_winnable
#eval "L2 firstSplit=" ++ toString (firstSplit [] L2_start L2_play 0) ++ " checked=" ++ toString L2_play.length


/-! ## 第 3 关：seq 110..134（真人 25 步，其中撤销 0 步；过关在 seq 134） -/

def L3_start : State := levelStarts.getD 3 default
def L3_play : List (Act × World) := (between 110 133).map (fun r => (r.act, r.next))
def L3_last : Act := .click (2) (4)
def L3_route : List Act := [.right, .right, .right, .click (-5) (5), .left, .left, .left, .left, .left, .click (1) (2), .right, .right, .right, .click (2) (5), .right, .right, .right, .click (3) (3), .click (1) (8), .click (1) (8), .left, .left, .left, .left, .click (2) (4)]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L3_start_seen : view (L3_start : State) = (((between 110 110).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 24 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L3_len : (L3_play : List (Act × World)).length = 24 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L3_trace : traceEnd [] (L3_start : State) (L3_play : List (Act × World)) L3_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L3_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 25 步。 -/
theorem L3_winnable : ∃ as : List Act, stepWins (L3_start : State) as = true :=
  ⟨L3_route, by decide +kernel⟩

#print axioms L3_start_seen
#print axioms L3_len
#print axioms L3_trace
#print axioms L3_winnable
#eval "L3 firstSplit=" ++ toString (firstSplit [] L3_start L3_play 0) ++ " checked=" ++ toString L3_play.length


/-! ## 第 4 关：seq 135..164（真人 30 步，其中撤销 0 步；过关在 seq 164） -/

def L4_start : State := levelStarts.getD 4 default
def L4_play : List (Act × World) := (between 135 163).map (fun r => (r.act, r.next))
def L4_last : Act := .left
def L4_route : List Act := [.right, .right, .right, .right, .click (0) (8), .click (1) (7), .right, .click (1) (8), .left, .left, .left, .left, .left, .click (-4) (3), .click (4) (8), .left, .right, .right, .right, .right, .right, .right, .right, .click (-1) (9), .click (0) (8), .left, .click (0) (7), .left, .left, .left]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L4_start_seen : view (L4_start : State) = (((between 135 135).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 29 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L4_len : (L4_play : List (Act × World)).length = 29 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L4_trace : traceEnd [] (L4_start : State) (L4_play : List (Act × World)) L4_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L4_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 30 步。 -/
theorem L4_winnable : ∃ as : List Act, stepWins (L4_start : State) as = true :=
  ⟨L4_route, by decide +kernel⟩

#print axioms L4_start_seen
#print axioms L4_len
#print axioms L4_trace
#print axioms L4_winnable
#eval "L4 firstSplit=" ++ toString (firstSplit [] L4_start L4_play 0) ++ " checked=" ++ toString L4_play.length


/-! ## 第 5 关：seq 165..205（真人 41 步，其中撤销 0 步；过关在 seq 205） -/

def L5_start : State := levelStarts.getD 5 default
def L5_play : List (Act × World) := (between 165 204).map (fun r => (r.act, r.next))
def L5_last : Act := .left
def L5_route : List Act := [.right, .right, .right, .right, .right, .click (-1) (6), .click (0) (4), .left, .left, .right, .right, .left, .left, .click (-1) (5), .left, .left, .right, .right, .right, .click (-6) (8), .left, .left, .click (5) (4), .left, .right, .right, .click (1) (6), .left, .left, .right, .click (4) (6), .right, .click (1) (7), .right, .right, .left, .left, .left, .left, .left, .left]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L5_start_seen : view (L5_start : State) = (((between 165 165).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 40 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L5_len : (L5_play : List (Act × World)).length = 40 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L5_trace : traceEnd [] (L5_start : State) (L5_play : List (Act × World)) L5_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L5_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 41 步。 -/
theorem L5_winnable : ∃ as : List Act, stepWins (L5_start : State) as = true :=
  ⟨L5_route, by decide +kernel⟩

#print axioms L5_start_seen
#print axioms L5_len
#print axioms L5_trace
#print axioms L5_winnable
#eval "L5 firstSplit=" ++ toString (firstSplit [] L5_start L5_play 0) ++ " checked=" ++ toString L5_play.length


/-! ## 第 6 关：seq 206..250（真人 45 步，其中撤销 0 步；过关在 seq 250） -/

def L6_start : State := levelStarts.getD 6 default
def L6_play : List (Act × World) := (between 206 249).map (fun r => (r.act, r.next))
def L6_last : Act := .click (-6) (0)
def L6_route : List Act := [.right, .right, .right, .click (2) (6), .click (-6) (0), .right, .click (-4) (0), .right, .left, .left, .left, .left, .click (3) (4), .click (1) (0), .click (-1) (4), .click (0) (0), .left, .left, .right, .click (2) (3), .click (1) (0), .right, .click (-2) (4), .click (-1) (0), .click (0) (5), .right, .click (2) (5), .click (3) (0), .click (0) (6), .right, .click (-2) (6), .click (1) (0), .click (-4) (7), .right, .right, .click (-1) (0), .right, .left, .left, .click (-4) (0), .left, .left, .left, .left, .click (-6) (0)]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L6_start_seen : view (L6_start : State) = (((between 206 206).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 44 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L6_len : (L6_play : List (Act × World)).length = 44 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L6_trace : traceEnd [] (L6_start : State) (L6_play : List (Act × World)) L6_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L6_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 45 步。 -/
theorem L6_winnable : ∃ as : List Act, stepWins (L6_start : State) as = true :=
  ⟨L6_route, by decide +kernel⟩

#print axioms L6_start_seen
#print axioms L6_len
#print axioms L6_trace
#print axioms L6_winnable
#eval "L6 firstSplit=" ++ toString (firstSplit [] L6_start L6_play 0) ++ " checked=" ++ toString L6_play.length


/-! ## 第 7 关：seq 251..301（真人 51 步，其中撤销 3 步；过关在 seq 301） -/

def L7_start : State := levelStarts.getD 7 default
def L7_play : List (Act × World) := (between 251 300).map (fun r => (r.act, r.next))
def L7_last : Act := .right
def L7_route : List Act := [.click (1) (4), .click (-3) (2), .click (-3) (3), .click (-3) (4), .click (-3) (5), .right, .right, .click (-2) (6), .right, .right, .right, .click (0) (7), .left, .left, .left, .left, .left, .click (-1) (3), .click (-1) (3), .click (-1) (3), .click (-1) (3), .click (-1) (3), .click (-1) (3), .click (0) (4), .right, .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-6) (5), .click (0) (5), .right, .click (0) (6), .right, .click (0) (7), .right, .click (0) (8), .right, .click (1) (8), .click (1) (8), .click (1) (8), .click (1) (8), .right]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L7_start_seen : view (L7_start : State) = (((between 251 251).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 50 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L7_len : (L7_play : List (Act × World)).length = 50 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L7_trace : traceEnd [] (L7_start : State) (L7_play : List (Act × World)) L7_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L7_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 45 步。 -/
theorem L7_winnable : ∃ as : List Act, stepWins (L7_start : State) as = true :=
  ⟨L7_route, by decide +kernel⟩

#print axioms L7_start_seen
#print axioms L7_len
#print axioms L7_trace
#print axioms L7_winnable
#eval "L7 firstSplit=" ++ toString (firstSplit [] L7_start L7_play 0) ++ " checked=" ++ toString L7_play.length


/-! ## 第 8 关：seq 302..374（真人 73 步，其中撤销 0 步；过关在 seq 374） -/

def L8_start : State := levelStarts.getD 8 default
def L8_play : List (Act × World) := (between 302 373).map (fun r => (r.act, r.next))
def L8_last : Act := .right
def L8_route : List Act := [.click (0) (0), .click (-4) (0), .click (-4) (6), .right, .right, .click (-1) (5), .click (-1) (5), .click (-1) (5), .click (0) (4), .left, .click (-1) (4), .click (-1) (4), .click (-1) (3), .click (0) (3), .click (-1) (3), .click (-2) (3), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (-1) (4), .click (0) (5), .right, .click (0) (6), .right, .click (0) (7), .right, .click (0) (0), .click (1) (7), .click (1) (7), .click (0) (8), .right, .click (-4) (0), .click (0) (9), .right, .click (-1) (9), .click (-1) (9), .click (-1) (9), .click (-1) (9), .click (-1) (9), .click (-1) (9), .click (-1) (9), .click (0) (8), .left, .click (0) (7), .left, .click (0) (6), .left, .click (0) (5), .left, .click (0) (4), .left, .click (-1) (4), .click (-6) (7), .click (-6) (6), .click (-6) (5), .click (-1) (4), .click (-1) (4), .click (0) (3), .left, .click (0) (2), .left, .click (0) (1), .left, .left, .click (-6) (2), .click (1) (0), .click (-6) (3), .click (1) (0), .click (-6) (4), .right, .right]

/-- 开局从帧里读：开局状态拍下来就是这一关第一帧。 -/
theorem L8_start_seen : view (L8_start : State) = (((between 302 302).headD default).prev : World) := by
  decide +kernel

/-- 这一关逐帧核 72 步（钉死，免得切歪成空表而平凡为真）。 -/
theorem L8_len : (L8_play : List (Act × World)).length = 72 := by
  decide +kernel

/-- **沿真实走法，模型每一帧都对上，最后一步过关。** 只有开局是观测给的，后面全是模型自己算的。 -/
theorem L8_trace : traceEnd [] (L8_start : State) (L8_play : List (Act × World)) L8_last = true := by
  decide +kernel

/-- **这一关走得通**（= `Winnable L8_start` 摊开）。见证 = 真实走法去掉撤销与被撤销的那几步，共 73 步。 -/
theorem L8_winnable : ∃ as : List Act, stepWins (L8_start : State) as = true :=
  ⟨L8_route, by decide +kernel⟩

#print axioms L8_start_seen
#print axioms L8_len
#print axioms L8_trace
#print axioms L8_winnable
#eval "L8 firstSplit=" ++ toString (firstSplit [] L8_start L8_play 0) ++ " checked=" ++ toString L8_play.length


