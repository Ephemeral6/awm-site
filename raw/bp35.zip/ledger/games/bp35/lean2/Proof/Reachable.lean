/-
# Proof/Reachable —— 这个局面做不做得了

    Winnable   s := ∃ as, 照着 as 一步一步走（`stepWins`），中途赢过
    Unsolvable s := ∀ as, 照着 as 走，从没赢过

## 两处削弱，写在明处

1. **`step` 对撤销说不出话（`na`）**，而 `stepWins` 碰到 `na` 就当「没赢」。
   所以 `Unsolvable` 准确的意思是「**不经过撤销**就赢不了」。这一局九关全都有 `Winnable`，
   一条 `Unsolvable` 都没用上——但这半句仍然写在这里，免得哪天有人拿它去宣告不可做。
2. **模型里没有步数预算**（计步条只数不罚：语料里前六关一次都没走满过，后三关走满一圈之后
   换色接着走，没有一次进 GAME_OVER）。所以 `Winnable` 是「不管预算，走得通」。
   每关的见证路线都**不长于**真人那一关用掉的步数（撤掉的那几步不走），而真人没被罚——
   这一句只是旁证，不是定理。
-/

import Obj.Level.State
import Step

open Game

/-- 照着 `as` 一步一步走（每一步都是 `step`），中途赢过没有。说不出话（`na`）当没赢。 -/
def stepWins : State → List Act → Bool
  | _, [] => false
  | s, a :: as =>
    match step s a with
    | .won => true
    | .ok s' => stepWins s' as
    | .na => false

def Winnable (s : State) : Prop := ∃ as : List Act, stepWins s as = true

def Unsolvable (s : State) : Prop := ∀ as : List Act, stepWins s as = false

/-- **骨架**：一个每步都保持、而且和「这一步赢」矛盾的性质 Φ ⇒ 从满足 Φ 的局面出发怎么走都赢不了。
    全文唯一做归纳的地方；不枚举状态，与盘面大小无关。这一局没有一关用得上它（九关都走得通），
    留着是给「宣告不可做」的那一天——那时候钥匙挂在它上面。 -/
theorem unsolvable_of_invariant (P : State → Prop)
    (hkeep : ∀ s s' a, P s → step s a = .ok s' → P s')
    (hwin : ∀ s a, P s → step s a ≠ .won) :
    ∀ s, P s → ∀ as : List Act, stepWins s as = false := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    simp only [stepWins]
    cases hstep : step s a with
    | won => exact absurd hstep (hwin s a hp)
    | na => rfl
    | ok s' => exact ih s' (hkeep s s' a hp hstep)

#print axioms unsolvable_of_invariant

