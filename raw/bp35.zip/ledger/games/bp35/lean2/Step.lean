/-
# Step —— 一步怎么走：**只做分发，0 条定理**

把几条规则（全是 `def`）按顺序拼成一步：

    撤销           → na（要历史，模型不描述；见身份表 undo_pops）
    左右走进十字   → won                          （goal_wins 横着那一半）
    否则           漂之前：地图按点击改（opens / slot_toggle / foam_spreads），
                          重力按点击翻（gravity），列与朝向按左右走变（sideways）
                   然后漂（drift）：漂进十字 → won；漂进不知道的格 → na；停住 → ok
                   计步条 +1（hud_tick）

## 身份表（`verify.py` 逐条核；和 `rule/` 目录对账，多一条少一条都红）

每条规则**恰好**一种身份：定义（`Rule/` 下的 def）/ 推论（`Derived/` 下的 theorem）/ 不进模型（带理由）。

IDENTITY sideways        定义     Rule/Move/Sideways.lean      sideways,turn
IDENTITY drift           定义     Rule/Move/Drift.lean         drift
IDENTITY opens           定义     Rule/Click/Opens.lean        opens
IDENTITY slot_toggle     定义     Rule/Click/SlotToggle.lean   toggle
IDENTITY foam_spreads    定义     Rule/Click/FoamSpreads.lean  spread
IDENTITY gravity         定义     Rule/Click/Gravity.lean      gravAfter
IDENTITY goal_wins       定义     Rule/Win/GoalWins.lean       walksIntoGoal,isGoal
IDENTITY hud_tick        定义     Rule/Hud/Tick.lean           tick
IDENTITY board_persists  推论     Derived/BoardPersists.lean   persists_walk,persists_click
IDENTITY blocked_no_switch 推论   Derived/BlockedNoSwitch.lean up_goal_below_no_win
IDENTITY undo_pops       不进模型 撤销要看历史（最近一个还没被撤掉的动作之前是什么样），一帧上读不出来；硬塞进状态就是给模型加一位帧上没有的信息。它写成 Obs/Check.lean 里 traceEnd 的一条明处假设，每次撤销都给它一次被驳倒的机会。

## 点玩家自己那一格

没反应（地图、重力都不变）。Python 那边这一格读成 `HIDDEN`，点它归「其余不变」；
语料里点中玩家那一格的次数由读数脚本报出来——**这一条不是被语料撑住的，是和观测口径对齐**。
-/

import Rule.Move.Sideways
import Rule.Move.Drift
import Rule.Click.Opens
import Rule.Click.SlotToggle
import Rule.Click.FoamSpreads
import Rule.Click.Gravity
import Rule.Win.GoalWins
import Rule.Hud.Tick

namespace Game

/-- 点在 (r, c)：一次性的门变液体、槽翻一下、泡沫再长一圈；点玩家自己那一格没反应。 -/
def clickAt (m : Map) (pr pc r c : Int) : Map :=
  if r = pr ∧ c = pc then m
  else match opens (m.get r c) with
    | some t => if m.get r c = .foam then spread (m.set r c t) pr pc r c else m.set r c t
    | none =>
      match toggle (m.get r c) with
      | some t => m.set r c t
      | none => m

/-- 漂之前的地图。 -/
def preMap (s : State) : Act → Map
  | .click dr c => clickAt s.map s.r s.c (s.r + dr) c
  | _ => s.map

/-- 漂之前的重力。 -/
def preGrav (s : State) : Act → Grav
  | .click dr c => if dr = 0 ∧ c = s.c then s.g else gravAfter s.g (s.map.get (s.r + dr) c)
  | _ => s.g

/-- 漂完之后的状态（地图、列、重力、朝向、计步条都已经定了，只差停在哪一行）。 -/
def settle (s : State) (a : Act) (r' : Int) : State :=
  { map := preMap s a, r := r', c := sideways s.map s.r s.c a, g := preGrav s a,
    f := turn s.f a, hud := tick s.hud }

def step (s : State) : Act → Res
  | .undo => .na
  | a =>
    if walksIntoGoal s.map s.r s.c a then .won
    else match drift (preMap s a) s.r (sideways s.map s.r s.c a) (preGrav s a) with
      | .goal => .won
      | .unknown => .na
      | .stop r' => .ok (settle s a r')

end Game
