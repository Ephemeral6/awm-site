/-
# Obs/Corpus —— 模型面对**每一条**真实转移（逐条那一层）

每一条转移：从**看到的那一帧**搭一个状态（`ofWorld`：窗口外、玩家脚下都是 `unk`），走一步，和下一帧比。
三值：`some true` 应验 / `some false` 被证伪 / `none` 模型说不出话（撤销；漂出了窗口）。

**读数不是定理**：`#eval` 走求值器，不进可信基。结论另写一条走内核的定理（`corpus_no_false`）。

最后那一段 `#eval` 把模型对每一条转移的**判决**（过关 / 说不出话 / 停在哪）打出来，
`verify.py` 拿它和 Python 那一份（`rule/_step.py` + `drift.run`）逐条对账——
两份都是现役，**不许只靠「它们应该一样」**。
-/

import Obj.Frame.World
import Obs.Replay

set_option maxRecDepth 100000
set_option maxHeartbeats 0

open Game Game.Replay

def verdict (r : Rec) : Option Bool := agrees r.prev r.act r.next r.won

def nTrue : Nat := (recs.filter (fun r => verdict r == some true)).length
def nFalse : Nat := (recs.filter (fun r => verdict r == some false)).length
def nNa : Nat := (recs.filter (fun r => verdict r == none)).length

#eval "CORPUS true=" ++ toString nTrue ++ " false=" ++ toString nFalse ++ " na=" ++ toString nNa ++ " total=" ++ toString recs.length

/-- **模型没被任何一条真实转移驳倒**（走内核，不是读数）。 -/
theorem corpus_no_false :
    (recs.filter (fun r => agrees (r.prev : World) r.act (r.next : World) r.won == some false)).length = 0 := by
  decide +kernel

#print axioms corpus_no_false

/-- 模型对一条转移的判决，打成一行给对账用：`seq:won` / `seq:na` / `seq:ok:行差:列:重力:朝向`。 -/
def judge (r : Rec) : String :=
  match step (ofWorld r.prev) r.act with
  | .won => toString r.seq ++ ":won"
  | .na => toString r.seq ++ ":na"
  | .ok s' => toString r.seq ++ ":ok:" ++ toString (s'.r - (ofWorld r.prev).r) ++ ":" ++ toString s'.c ++ ":" ++
      (match s'.g with | .up => "up" | .down => "down") ++ ":" ++ (match s'.f with | .l => "L" | .r => "R")

#eval "JUDGE " ++ String.intercalate " " (recs.map judge)
