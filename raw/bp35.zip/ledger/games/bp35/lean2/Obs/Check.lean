/-
# Obs/Check —— **判据层**：两把尺子，只在这里定义一次

    agrees     **一条转移**：从**看到的那一帧**搭一个状态（窗口外不知道），走一步，和下一帧比。三值。
    traceEnd   **一整关**：从开局起**带着模型自己算出来的状态**往下走，逐帧比；最后一步必须过关。

两把尺子分量差得很远：`agrees` 每步都被观测拉回正轨，`traceEnd` 只有开局是观测给的。
一个「每步单独看都对、走两步就和现实分家」的模型，在前者满分，在后者过不了。

**这一份里没有一条定理。** 尺子不自证。

## 一条明写的假设：撤销 = 弹栈（规则 undo_pops，身份「不进模型」）

`step` 对撤销说不出话（要历史）。`traceEnd` 自己记一个栈：每走一步把走之前的状态压进去，
撤销就弹出来，计步条照走（+1）。**这是假设，不是模型的一部分**；
它在语料上唯一的检验就是：撤销之后那一帧要和弹出来的状态拍下来的那一帧一格不差。
没红不构成证明，**但那是这条假设在这批语料上唯一一次有机会被驳倒**。
-/

import Step
import Obs.Camera

namespace Game

/-- 一格：模型说 `unk`（不知道）就不比；否则要相等。 -/
def cellOk (model seen : Tile) : Bool := model == .unk || model == seen

def rowOk : List Tile → List Tile → Bool
  | [], [] => true
  | a :: as, b :: bs => cellOk a b && rowOk as bs
  | _, _ => false

def rowsOk : List (List Tile) → List (List Tile) → Bool
  | [], [] => true
  | a :: as, b :: bs => rowOk a b && rowsOk as bs
  | _, _ => false

/-- 模型拍下来的那一帧对上看到的那一帧（模型不知道的格不比）。 -/
def seenOk (model seen : World) : Bool :=
  rowsOk model.cells seen.cells && model.facing == seen.facing && model.hud == seen.hud

/-- **逐条（三值）**：`some true` 应验、`some false` 被证伪、`none` 模型说不出话。
    `won` 是现实那一侧的读数（上游关卡号加了一），不是模型算的。 -/
def agrees (prev : World) (a : Act) (next : World) (won : Bool) : Option Bool :=
  match step (ofWorld prev) a with
  | .won => some won
  | .na => none
  | .ok s => some (!won && seenOk (view s) next)

/-- 撤销之后的状态：弹出来的那一个，计步条照走。 -/
def undone (h s : State) : State := { h with hud := tick s.hud }

/-- **每关**：从 `s` 起沿 `play` 走，逐帧和观测比（这一层地图是整关的，比的是整帧，不跳格）；
    `play` 走完之后，`last` 那一下必须过关。`hist` 是撤销用的栈。 -/
def traceEnd : List State → State → List (Act × World) → Act → Bool
  | _, s, [], last => step s last == .won
  | hist, s, (a, o) :: rest, last =>
    match a with
    | .undo =>
      match hist with
      | h :: hs => view (undone h s) == o && traceEnd hs (undone h s) rest last
      | [] => false
    | _ =>
      match step s a with
      | .ok s' => view s' == o && traceEnd (s :: hist) s' rest last
      | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，不是定理。 -/
def firstSplit : List State → State → List (Act × World) → Nat → Option Nat
  | _, _, [], _ => none
  | hist, s, (a, o) :: rest, i =>
    match a with
    | .undo =>
      match hist with
      | h :: hs => if view (undone h s) == o then firstSplit hs (undone h s) rest (i + 1) else some i
      | [] => some i
    | _ =>
      match step s a with
      | .ok s' => if view s' == o then firstSplit (s :: hist) s' rest (i + 1) else some i
      | _ => some i

end Game
