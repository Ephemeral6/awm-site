/-
# Obs/Camera —— 模型的状态在一帧上长什么样（观测函数），以及从一帧反过来搭一个状态

**镜头跟着玩家走**：窗口 11 行 x 11 列；上浮时玩家在窗口第 6 行，下沉时在第 5 行
（`Grav.prow`）。窗口里玩家那一格画成 `hidden`——观测读不出它底下是液体还是空槽。

这一份是观测，不是规则：它不说世界怎么变，只说「这个状态拍下来是哪一帧」。
Python 那边对应的是 `parse` 的良构检查（镜头 = 重力）和 `derive/window.py`。
-/

import Obj.Level.State
import Obj.Frame.World

namespace Game

/-- 窗口第 `i` 行、第 `j` 列在整关的哪一格：行 = r - prow + i。 -/
def cellSeen (s : State) (i j : Nat) : Tile :=
  if s.r - s.g.prow + i = s.r ∧ (j : Int) = s.c then .hidden
  else s.map.get (s.r - s.g.prow + i) j

/-- **观测函数**：这个状态拍下来的那一帧。 -/
def view (s : State) : World :=
  { cells := (List.range 11).map (fun i => (List.range 11).map (fun j => cellSeen s i j)),
    facing := s.f, hud := s.hud }

/-- 从一帧读重力：`hidden` 在第 6 行是上浮，在第 5 行是下沉（和 Python `derive/window.grav` 各写一份，逐条对账）。 -/
def gravOf (w : World) : Grav :=
  if (w.cells.getD 6 []).contains .hidden then .up else .down

/-- 从一帧读玩家在第几列。 -/
def colOf (w : World) : Int :=
  ((w.cells.getD (gravOf w).prow.toNat []).idxOf .hidden : Nat)

/-- **逐条那一层用的状态**：只知道这一帧窗口里的格，窗口外全是 `unk`；
    玩家脚下那一格读不出来，也是 `unk`。 -/
def ofWorld (w : World) : State :=
  { map := w.cells.map (fun row => row.map (fun t => if t = .hidden then .unk else t)),
    r := (gravOf w).prow, c := colOf w, g := gravOf w, f := w.facing, hud := w.hud }

end Game
