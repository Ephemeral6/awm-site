"""ACTION6 点在主色为 14 的格上，那一格在下一帧的主色变成 10。"""
LEVEL = "L1"
SCOPE = ("只看形如 ACTION6:列,行 的动作，且点中的格在 prev 里主色是 14；点在缝隙上（cell_at 取不到格）返回 NA；"
         "换关返回 NA。只断言被点中的那一格自己变成 10，不管周围缝隙怎么补、也不管别处。"
         "**点中的格正是玩家在被拉方向上紧贴着的那一格时返回 NA**：那一下会当场把玩家带走并整屏滚动，"
         "同一个格坐标在 nxt 里已经不是同一个世界位置了。")
NOTE = "v2 被 001a3e2f08289aab 打掉：点开玩家脚底下那块色14，玩家当场下沉、画面滚了一格，于是那格在 nxt 里读出来的不是它自己。"
EVIDENCE = ["001a3e2f08289aab", "da145af05522b1cc", "92b5600476bed61a"]

from _lib import click_cell, kind, me, pull, ahead, TILE, FLOOR


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cell = click_cell(action, prev)
    if cell is None or kind(prev, *cell) != TILE:
        return "NA"
    m, p = me(prev), pull(prev)
    if m is not None and p is not None and cell == ahead(m, p):
        return "NA"
    return "TRUE" if kind(nxt, *cell) == FLOOR else "FALSE"
