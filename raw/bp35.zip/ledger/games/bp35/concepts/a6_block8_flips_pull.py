"""点色8 的块会把玩家被拉的方向翻到反面：prev 里读出来是 up，nxt 里就是 down，反之亦然。"""
LEVEL = "L6"
SCOPE = ("只看形如 ACTION6:列,行 的动作，且点中的格在 prev 里主色是 8；别的情况返回 NA；换关返回 NA。"
         "方向用 _lib.pull 读（玩家贴着的那一侧）；prev 或 nxt 里读不出来就返回 NA。"
         "只断言方向翻了，不断言玩家被带到哪去——落点由当时那一列决定，另说。")
NOTE = ""
EVIDENCE = ["91e0cd2e1f5924b4", "4eb491820db0294b"]

from _lib import click_cell, kind, pull, BLOCK8


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cell = click_cell(action, prev)
    if cell is None or kind(prev, *cell) != BLOCK8:
        return "NA"
    a, b = pull(prev), pull(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if a != b else "FALSE"
