"""ACTION6 点在主色既不是 14 / 12 / 8、也不是「带色12 记号的液体」的地方，除 HUD 行外整帧一格不变。"""
LEVEL = "L1"
SCOPE = ("只看形如 ACTION6:列,行 的动作；点中的格在 prev 里主色是 14 或 12、或者是带色12 记号的液体时返回 NA（分别由 a6_opens_tile / a6_opens_block12 / a6_places_block 管）；"
         "点在缝隙上（cell_at 取不到格）也归这条管——它同样应当什么都不改。换关返回 NA。")
NOTE = ("v1 只把色14 排除在外，被 94ab7d5e6ce26367 打掉：色12 的圆角块点一下也会变成液体。"
        "v2 又被 1aa57c83360798ea / 40905d286691f0ac / e070cb59a35d35de 三条打掉："
        "主色是 10、但格里嵌着色12 记号的那种液体，点一下会**变成色12 的块**——这一局第一次出现「放」而不是「开」。"
        "v3 又被 91e0cd2e1f5924b4 打掉：第 3 关的色8 圆角块点一下会整屏重画、玩家往下掉。")
EVIDENCE = ["91e0cd2e1f5924b4", "7da5d5abd4ddc298", "2c38a6fb128686a7", "a0c6611b3ab17dbb", "94ab7d5e6ce26367",
            "1aa57c83360798ea", "40905d286691f0ac", "e070cb59a35d35de"]

from _lib import click_cell, kind, marked, OPENABLE, BLOCK8, HUD_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.upper().startswith("ACTION6:"):
        return "NA"
    cell = click_cell(action, prev)
    if cell is not None and (kind(prev, *cell) in OPENABLE or kind(prev, *cell) == BLOCK8 or marked(prev, *cell)):
        return "NA"
    for r in range(len(prev)):
        if r != HUD_ROW and prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.upper().startswith("ACTION6:"):
        return None
    cell = click_cell(action, prev)
    if cell is not None and (kind(prev, *cell) in OPENABLE or kind(prev, *cell) == BLOCK8 or marked(prev, *cell)):
        return None
    return {(r, c): v for r, row in enumerate(prev) if r != HUD_ROW
            for c, v in enumerate(row)}
