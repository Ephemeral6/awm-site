"""ACTION6 点在主色为 12 的圆角块上，那一格在下一帧的主色变成 10——和色14 一个样。"""
LEVEL = "L1"
SCOPE = ("只看形如 ACTION6:列,行 的动作，且点中的格在 prev 里主色是 12；点在缝隙上返回 NA；换关返回 NA。"
         "只断言被点中的那一格自己变成 10，不管周围缝隙怎么补、也不管液体总量怎么算——"
         "色12 与色14 在**代价**上可能不同（第 95 步点开色12 之后走了一步，窗口内液体没少），那另说。")
NOTE = "点中的格正是玩家在被拉方向上紧贴着的那一格时返回 NA：那一下会当场把玩家带走并整屏滚动，格坐标在 nxt 里已经不是同一个世界位置了（001a3e2f08289aab）。"
EVIDENCE = ["94ab7d5e6ce26367"]

from _lib import click_cell, kind, me, pull, ahead, BLOCK12, FLOOR


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cell = click_cell(action, prev)
    if cell is None or kind(prev, *cell) != BLOCK12:
        return "NA"
    m, p = me(prev), pull(prev)
    if m is not None and p is not None and cell == ahead(m, p):
        return "NA"
    return "TRUE" if kind(nxt, *cell) == FLOOR else "FALSE"
