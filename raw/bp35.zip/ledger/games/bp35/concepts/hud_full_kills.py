"""HUD 那一行 64 格全填成色15 的那一步，state 变成 GAME_OVER——它是每关的步数预算，不是计数器。"""
LEVEL = "L5"
SCOPE = ("只看非 RESET 动作，且 prev 里 HUD 行恰好还剩 1 格是色 0（也就是这一步会把它填满）；"
         "别的情况返回 NA。ctx 缺席、或 ctx 里没有 state_next 返回 NA。"
         "**不加「换关返回 NA」的护栏**——万一填满反而是过关，这条要能判错。")
NOTE = ""
EVIDENCE = ["427fd2f576336df8"]

from _lib import HUD_ROW, HUD_EMPTY


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or action.upper().startswith("RESET"):
        return "NA"
    if sum(1 for v in prev[HUD_ROW] if v == HUD_EMPTY) != 1:
        return "NA"
    st = ctx.get("state_next")
    if st is None:
        return "NA"
    return "TRUE" if st == "GAME_OVER" else "FALSE"
