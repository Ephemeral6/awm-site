"""朝色7 十字所在的那一格走一步，就过关：上游给的 level 会加一。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION3 / ACTION4，且 prev 里色7 十字所在的格恰好是玩家这一步的目标格（同一格行、列差 1）；"
         "别的情况返回 NA。十字不在窗口里、me() 定位不到、ctx 缺席也返回 NA。"
         "**这条不加「换关返回 NA」的护栏**——换关正是它要断言的事。"
         "它不声称目标格能不能走进去（那格主色是 5，move_needs_floor 会说挡住），只声称「朝它走 = 过关」。")
NOTE = ""
EVIDENCE = ["f00070472d183608"]

from _lib import me, goal


def assert_(prev, action, nxt, ctx=None):
    act = action.upper()
    if act.startswith("ACTION3"):
        dj = -1
    elif act.startswith("ACTION4"):
        dj = 1
    else:
        return "NA"
    m, g = me(prev), goal(prev)
    if m is None or g is None or ctx is None:
        return "NA"
    if g != (m[0], m[1] + dj):
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
