"""被液体带到头时，如果顶住玩家的那一格是色15（空），玩家就没了——这一步进 GAME_OVER；顶住的是墙或块则不会。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION3 / ACTION4，且 prev 里落脚格在 _lib.pull(prev) 那一侧是液体（这一步会被带走）；否则返回 NA。"
         "沿落脚列往那个方向数连续的液体，第一个不是液体的格就是「顶住玩家的那一格」；"
         "如果一直数到窗口边缘还全是液体（顶住的东西在窗口外），返回 NA——窗口外的看不见。"
         "**方向逐帧读**：第 3 关点色8 之后玩家是往下沉的，这条也跟着翻。"
         "ctx 缺席、或 ctx 里没有 state_next（预测口径下它是 None）返回 NA。")
NOTE = "v1 写成 ctx['state']，settle 给的键叫 state_next，于是在自己的 EVIDENCE 上判 FALSE。键名写错，不是主张错。"
EVIDENCE = ["a096d65c539c023c", "ee4d258e78331df6", "3c39b2504a11a1d8"]

from _lib import me, dest, pull, ahead, kind, NR, FLOOR, HUD_FILL


def assert_(prev, action, nxt, ctx=None):
    act = action.upper()
    if not (act.startswith("ACTION3") or act.startswith("ACTION4")):
        return "NA"
    if ctx is None or me(prev) is None:
        return "NA"
    d = dest(prev, action)
    if d is None:
        return "NA"
    p = pull(prev)
    if p is None:
        return "NA"
    step = -1 if p == 'up' else 1
    i, j = d
    if not (0 <= i + step < NR) or kind(prev, i + step, j) != FLOOR:
        return "NA"
    r = i + step
    while 0 <= r + step < NR and kind(prev, r + step, j) == FLOOR:
        r += step
    if not (0 <= r + step < NR):
        return "NA"
    stopper = kind(prev, r + step, j)
    if stopper is None:
        return "NA"
    st = ctx.get("state_next")
    if st is None:
        return "NA"
    dead = (st == "GAME_OVER")
    return "TRUE" if dead == (stopper == HUD_FILL) else "FALSE"
