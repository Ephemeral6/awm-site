"""ACTION6 点在主色为 8 的圆角块上，会整屏重画：玩家格行以上至少变掉 200 格。"""
LEVEL = "L6"
SCOPE = ("只看形如 ACTION6:列,行 的动作，且点中的格在 prev 里主色是 8；别的情况返回 NA；换关返回 NA。"
         "只断言「会整屏重画」，**不**断言玩家掉到哪去——第 152 步那一次玩家从世界的第 1 行掉到第 8 行、"
         "而且落点还偏离格点 2 个像素，落点规律只有一条样本，不敢写。")
NOTE = ""
EVIDENCE = ["91e0cd2e1f5924b4"]

from _lib import click_cell, kind, BLOCK8, HUD_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cell = click_cell(action, prev)
    if cell is None or kind(prev, *cell) != BLOCK8:
        return "NA"
    n = sum(1 for r in range(len(prev)) if r != HUD_ROW
            for x, y in zip(prev[r], nxt[r]) if x != y)
    return "TRUE" if n >= 200 else "FALSE"
