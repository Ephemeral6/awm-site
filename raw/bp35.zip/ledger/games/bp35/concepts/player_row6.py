"""一步之内，玩家的格行要么不变，要么变成 6——上浮会滚屏，滚完把玩家重新对中到第 6 格行。"""
LEVEL = "L0"
SCOPE = ("看每一条非 RESET 转移；换关返回 NA（新关开局会把玩家摆在别的行，第 45 步实测在格行 1）；"
         "me() 在 prev 或 nxt 里定位不到返回 NA。只管行号，不管列。")
NOTE = ("v3：scope 缩到只看左右走——点色8 的块会让玩家整个掉下去，格行既不留在原处也不是 6（91e0cd2e1f5924b4）。"
        "v1 写成「玩家永远在格行 6」，那是只看了第 0 关的窗口；第 45 步进第 1 关时玩家出现在格行 1。"
        "v2 改成「要么不变、要么变成 6」，把「滚屏之后重新对中」这件事单独说清楚。")
EVIDENCE = ["91e0cd2e1f5924b4", "cc69bce608399792", "7bd1d48711f966ca"]

from _lib import me, PLAYER_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    act = action.upper()
    if not (act.startswith("ACTION3") or act.startswith("ACTION4")):
        return "NA"
    if action.upper().startswith("RESET"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if b[0] in (a[0], PLAYER_ROW) else "FALSE"
