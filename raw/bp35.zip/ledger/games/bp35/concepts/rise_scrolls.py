"""左右走时，落脚格在「被拉的那一侧」若是液体，玩家就被带走：整屏重画，玩家格行那一片至少变掉 100 格。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION3 / ACTION4；换关返回 NA。"
         "被拉的方向由 _lib.pull(prev) 逐帧读出来（玩家贴着的那一侧），读不出来返回 NA——"
         "**不再写死「往上」**：第 3 关点色8 之后玩家改成往下沉。"
         "落脚格 = 目标格主色是 10 就走过去、否则原地；落脚格在该方向上已经出窗口，返回 NA。"
         "只说「会重画」，不说走了几格——走的距离可能超出窗口。")
NOTE = ("v1/v2 写的是「正上方是液体就上浮」，被 a096d65c539c023c 打掉：那一步玩家正上方是液体，"
        "却只是平移了一格，因为它已经变成往下沉的了。")
EVIDENCE = ["a096d65c539c023c", "cc69bce608399792", "7bd1d48711f966ca"]

from _lib import me, dest, pull, ahead, kind, origin, SIDE, HUD_ROW, FLOOR, NR


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    act = action.upper()
    if not (act.startswith("ACTION3") or act.startswith("ACTION4")):
        return "NA"
    d = dest(prev, action)
    p = pull(prev)
    if d is None or p is None:
        return "NA"
    nb = ahead(d, p)
    if not (0 <= nb[0] < NR):
        return "NA"
    if kind(prev, *nb) != FLOOR:
        return "NA"
    r0 = origin(*d, g=prev)[0]
    lo, hi = (0, r0 + SIDE - 1) if p == 'up' else (r0, len(prev) - 1)
    n = 0
    for r in range(max(0, lo), min(hi + 1, len(prev))):
        if r == HUD_ROW:
            continue
        n += sum(1 for x, y in zip(prev[r], nxt[r]) if x != y)
    return "TRUE" if n >= 100 else "FALSE"
