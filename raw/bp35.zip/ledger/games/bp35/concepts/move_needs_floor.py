"""左右走生效（玩家格真的变了）当且仅当目标格在 prev 里的主色是 10。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION3 / ACTION4；换关返回 NA；me() 定位不到返回 NA；"
         "目标格越出 0..10 的格点范围时按「主色不是 10」处理（即断言它挡住）。"
         "主色 = 该格 5x5 里出现最多的色号（_lib.kind），玩家自己那一格会读成 5，但目标格不是玩家那一格。")
NOTE = ""
EVIDENCE = ["3d1be259a9f752ae", "dcee3c620d74b86d"]

from _lib import me, kind, FLOOR, NC


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    act = action.upper()
    if act.startswith("ACTION3"):
        dj = -1
    elif act.startswith("ACTION4"):
        dj = 1
    else:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    tj = a[1] + dj
    walkable = 0 <= tj < NC and kind(prev, a[0], tj) == FLOOR
    moved = (b != a)
    return "TRUE" if moved == walkable else "FALSE"
