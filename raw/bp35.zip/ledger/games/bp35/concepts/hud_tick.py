"""每发一个动作，HUD（行 63）最左边那个还是色 0 的格变成色 15，别的格不变——受理就扣，生效与否无关。"""
LEVEL = "L4"
SCOPE = ("只看非 RESET 动作；换关返回 NA；HUD 行已经被填满（64 格全是色 15）时返回 NA（没见过，别瞎断）。"
         "「最左边那个还是色 0 的格」= prev 里行 63 从左数第一个不是色 15 的位置。")
NOTE = ""
EVIDENCE = ["6c2874a8285dd12c", "3d1be259a9f752ae"]

from _lib import HUD_ROW, HUD_EMPTY, HUD_FILL


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.upper().startswith("RESET"):
        return "NA"
    p, n = prev[HUD_ROW], nxt[HUD_ROW]
    k = next((x for x, v in enumerate(p) if v != HUD_FILL), None)
    if k is None:
        return "NA"
    if p[k] != HUD_EMPTY:
        return "NA"
    want = list(p)
    want[k] = HUD_FILL
    return "TRUE" if list(n) == want else "FALSE"


def apply(prev, action, ctx=None):
    if action.upper().startswith("RESET"):
        return None
    p = prev[HUD_ROW]
    k = next((x for x, v in enumerate(p) if v != HUD_FILL), None)
    if k is None or p[k] != HUD_EMPTY:
        return None
    return {(HUD_ROW, x): (HUD_FILL if x == k else p[x]) for x in range(len(p))}
