"""bp35 的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源：开局帧 + 第 1~6 步。
  · 帧 64x64。行 63 整行是 HUD（开局全色 0），不属于棋盘。
  · 棋盘是 6 格距的点阵：格 (i, j) 占 行 1+6i..5+6i、列 1+6j..5+6j，i、j 各 0..10
    （i=10 只剩 行61..62，j=10 只剩 列61..63，都被裁）。格与格之间有一行/一列缝隙（行 6i、列 6j）。
    依据：色 3 的装饰点只出现在 行 1+6i / 4+6i / 5+6i 与 列 2+6j / 1+6j / 4+6j 上；
    色 14 的 7 个圆角块、以及玩家所在的那个洞，边界都正好落在这套格点上。
  · 玩家 = 色 9（6 格核心）+ 色 11（2 格鼻子），鼻子贴在核心的行进侧，整体落在**一个**格子里。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 6                 # 格距（格边长 5 + 1 格缝）
PHASE = (1, 1)           # 格 (0,0) 的左上角在 (行1, 列1)
SIDE = 5                 # 一个格子里画得下的边长
NR = NC = 11             # 格点行数 / 列数（末行末列被帧边裁掉）

BODY, NOSE = 9, 11       # 玩家核心 / 朝向鼻子
GOAL = 7                 # 第 39 步窗口上滚之后露出来的十字标记（5 格：中心加上下左右），全图唯一
BG, FLOOR, TILE, DOT = 5, 10, 14, 3
BLOCK12 = 12             # 第 2 关出现的另一种圆角块，画法与色14 相同；点开一样变液体（第 95 步实测）
BLOCK8 = 8               # 第 3 关出现的第三种圆角块；点它会让玩家**往下掉**并整屏重画（第 152 步实测）
OPENABLE = (TILE, BLOCK12)   # 命名是**猜**：色 5 带色 3 点阵，色 10 是大片，色 14 是 7 个圆角块
HUD_ROW = 63
HUD_EMPTY, HUD_FILL = 0, 15

DELTA = {"ACTION3": (0, -1), "ACTION4": (0, +1)}   # 以**格**为单位；ACTION7 未定，不填


_PH_CACHE: dict = {}


def phase_of(g) -> tuple[int, int]:
    """这一帧的格点相位 (行相位, 列相位)。**格点会动**——第 3 关点色8 翻转重力之后，
    整块棋盘相对帧往下挪了 2 行，行相位从 1 变成 3；写死 PHASE 会让此后所有读数系统性偏两行。

    判法：色 3 的点阵在每个墙格里固定长在局部 (0,1)、(3,0)、(4,3) 上，
    所以行相位 p 满足「点的行号 mod 6 ∈ {p, p+3, p+4}」、列相位 q 满足「列号 mod 6 ∈ {q, q+1, q+3}」。
    取让命中数最大的那个 p / q（块的四角也是色 3，会给别的相位加一点噪声，用 argmax 而不是集合相等）。
    """
    key = id(g)
    hit = _PH_CACHE.get(key)
    if hit is not None and hit[0] is g:
        return hit[1]
    rows = [0] * 6
    cols = [0] * 6
    for r in range(HUD_ROW):
        row = g[r]
        rr = r % 6
        for c, v in enumerate(row):
            if v == DOT:
                rows[rr] += 1
                cols[c % 6] += 1
    if not any(rows):
        return PHASE
    pr = max(range(6), key=lambda p: rows[p] + rows[(p + 3) % 6] + rows[(p + 4) % 6])
    pc = max(range(6), key=lambda q: cols[q] + cols[(q + 1) % 6] + cols[(q + 3) % 6])
    if len(_PH_CACHE) > 512:
        _PH_CACHE.clear()
    _PH_CACHE[key] = (g, (pr, pc))
    return (pr, pc)


def origin(i: int, j: int, g=None) -> tuple[int, int]:
    """格 (i, j) 左上角的像素坐标。给了帧就按这一帧实测的相位算，不给就用开局那套 (1, 1)。"""
    ph = phase_of(g) if g is not None else PHASE
    return (ph[0] + CELL * i, ph[1] + CELL * j)


def cell_at(r: int, c: int, g=None):
    """像素 (r, c) 落在哪个格子里；落在缝隙上或越界返回 None。"""
    ph = phase_of(g) if g is not None else PHASE
    i, j = (r - ph[0]) // CELL, (c - ph[1]) // CELL
    if not (0 <= i < NR and 0 <= j < NC):
        return None
    r0, c0 = origin(i, j, g)
    if not (r0 <= r < r0 + SIDE and c0 <= c < c0 + SIDE):
        return None
    return (i, j)


def me(g):
    """玩家所在格 (i, j)。定位方式：**只用色 9**（核心）的最小行/最小列落回格点。

    注意这是**格点吸附**，不是「最小列减一」——两种读法对不上就该有反例。
    第 46 步之前这里连色 11 一起用，第 1 关出现了另一个带色 11 的三格宽物件，把 me 读歪到 (1,2)；
    色 11 只在**鼻子**这个角色上可信，定位一律用色 9。
    """
    cs = cells_of(g, (BODY,))
    if not cs:
        return None
    return cell_at(min(r for r, _ in cs), min(c for _, c in cs), g)


def facing(g):
    """鼻子相对核心在哪边：'L'/'R'/'U'/'D'；读不出来返回 None。"""
    body = cells_of(g, (BODY,))
    nose = cells_of(g, (NOSE,))
    if not body or not nose:
        return None
    br = sum(r for r, _ in body) / len(body)
    bc = sum(c for _, c in body) / len(body)
    nr = sum(r for r, _ in nose) / len(nose)
    nc = sum(c for _, c in nose) / len(nose)
    if abs(nc - bc) >= abs(nr - br):
        return 'R' if nc > bc else 'L'
    return 'D' if nr > br else 'U'


def patch(g, i: int, j: int):
    """格 (i, j) 的 5x5 内容（越界的格位置补 None）。"""
    r0, c0 = origin(i, j, g)
    return [[g[r][c] if 0 <= r < 63 and 0 <= c < 64 else None
             for c in range(c0, c0 + SIDE)] for r in range(r0, r0 + SIDE)]


def kind(g, i: int, j: int):
    """格 (i, j) 的主色（25 格里出现最多的那个色号）；越界返回 None。

    玩家所在的格会读成 BG（玩家把自己那格画成色 5 的圆角块），不是地形本色。
    """
    if not (0 <= i < NR and 0 <= j < NC):
        return None
    cnt: dict[int, int] = {}
    for row in patch(g, i, j):
        for v in row:
            if v is not None:
                cnt[v] = cnt.get(v, 0) + 1
    return max(cnt, key=lambda k: cnt[k]) if cnt else None


SPRITE = {
    'L': ((BG, BG, BODY, BG, BG),
          (BG, NOSE, BODY, BODY, BG),
          (BG, NOSE, BODY, BODY, BG),
          (BG, BG, BODY, BG, BG),
          (None, BG, BG, BG, None)),
    'R': ((BG, BG, BODY, BG, BG),
          (BG, BODY, BODY, NOSE, BG),
          (BG, BODY, BODY, NOSE, BG),
          (BG, BG, BODY, BG, BG),
          (None, BG, BG, BG, None)),
}
"""玩家那一格的 5x5 画法（实测自第 1~9 步）：只有左下/右下两角是透明的（None，露出地形本色），
   左上/右下角照样画成 BG。朝向 U / D 没见过，所以没有条目——取不到就别生成。"""


def hud_fill(g) -> int:
    """HUD 条里已填色 15 的格数。"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_FILL)


def click_cell(action: str, g=None):
    """'ACTION6:39,15' -> 点中的格 (i, j)。第一个数是**列**、第二个是**行**（第 12~15 步实测：
    ACTION6:39,15 改的是 行13-17 列37-41 那一块）。不是带坐标的 ACTION6、或点在缝隙上，返回 None。"""
    a = action.upper()
    if not a.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in a.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return cell_at(y, x, g)


PLAYER_ROW = 6
"""玩家永远画在第 6 格行（第 1~39 步实测）：上浮之后画面整体滚动，把玩家重新摆回这一行。
所以屏幕是一个 11 格行的**窗口**，不是整个世界；窗口外的行读不到。"""


def dest(g, action):
    """左右走这一步会落到哪个格：目标格主色是 10 才走得动，否则原地。不是左右走返回 None。"""
    a = action.upper()
    dj = -1 if a.startswith("ACTION3") else (1 if a.startswith("ACTION4") else None)
    if dj is None:
        return None
    m = me(g)
    if m is None:
        return None
    i, j = m
    t = (i, j + dj)
    if 0 <= t[1] < NC and kind(g, *t) == FLOOR:
        return t
    return m


def above(g, cell):
    """某格正上方那一格的主色；已经在窗口第 0 行返回 None（窗口外读不到）。"""
    i, j = cell
    return kind(g, i - 1, j) if i - 1 >= 0 else None


def goal(g):
    """色 7 十字标记所在的格 (i, j)；窗口里看不到就返回 None。

    它的格子被 kind 读成 5（标记只占 5 格，其余是 BG 与液体），所以不能拿 kind 找它。
    """
    cs = cells_of(g, (GOAL,))
    if not cs:
        return None
    return cell_at(min(r for r, _ in cs), min(c for _, c in cs) + 1, g)


def marked(g, i: int, j: int) -> bool:
    """这一格是不是「带记号的液体」：主色是 10，格里却嵌着色 12 的点（实测是 5 点的 X）。

    第 2 关首次出现（S1 行的 j=3,4,5）。kind 读它是 10，所以光看 kind 的地图会把它当普通液体。
    """
    if kind(g, i, j) != FLOOR:
        return False
    return any(v == BLOCK12 for row in patch(g, i, j) for v in row if v is not None)


def pull(g):
    """玩家被液体拉向哪边：'up'（浮）/ 'down'（沉）/ None（这一帧读不出来）。

    读法**不是**「它是不是气泡」，而是「它此刻靠在哪一侧」：玩家总是贴着某个非液体停住，
    贴住的那一侧就是被拉的方向。上方非液体、下方液体 = 被往上拉；反过来就是往下。
    两侧都非液体（卡在缝里）或都液体时返回 None。
    第 3 关点了那块色8 之后，同一个玩家从 'up' 变成了 'down'——这一局的重力对玩家是可翻转的。
    """
    m = me(g)
    if m is None:
        return None
    i, j = m
    up = kind(g, i - 1, j) if i - 1 >= 0 else None
    dn = kind(g, i + 1, j) if i + 1 < NR else None
    if up == FLOOR and dn is not None and dn != FLOOR:
        return 'down'
    if dn == FLOOR and up is not None and up != FLOOR:
        return 'up'
    return None


def ahead(cell, p):
    """格 cell 在被拉方向 p 上的相邻格。"""
    i, j = cell
    return (i - 1, j) if p == 'up' else (i + 1, j)
