"""ACTION6 点在「带色12 记号的液体」格上，那一格变成主色 12 的块——这是往世界里**放**东西，不是开。"""
LEVEL = "L1"
SCOPE = ("只看形如 ACTION6:列,行 的动作，且点中的格在 prev 里是带记号的液体（主色 10、格内嵌着色 12 的点）；"
         "别的情况返回 NA；换关返回 NA。只断言那一格自己变成主色 12。")
NOTE = "点中的格正是玩家在被拉方向上紧贴着的那一格时返回 NA：那一下会当场把玩家带走并整屏滚动，格坐标在 nxt 里已经不是同一个世界位置了（001a3e2f08289aab）。"
EVIDENCE = ["1aa57c83360798ea", "40905d286691f0ac", "e070cb59a35d35de"]

from _lib import click_cell, kind, marked, me, pull, ahead, BLOCK12


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cell = click_cell(action, prev)
    if cell is None or not marked(prev, *cell):
        return "NA"
    m, p = me(prev), pull(prev)
    if m is not None and p is not None and cell == ahead(m, p):
        return "NA"
    return "TRUE" if kind(nxt, *cell) == BLOCK12 else "FALSE"
