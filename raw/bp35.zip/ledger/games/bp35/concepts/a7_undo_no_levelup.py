"""ACTION7（撤销）这一步不可能过关：它把棋盘放回上一个动作之前的样子，只有 HUD 照常往前走。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION7；别的动作返回 NA。ctx 取不到（没有 level_prev / level_next）也返回 NA。"
         "只断言「这一步 level 不加一」这一件事——「棋盘被精确回退」那一半断言不了，"
         "因为 assert_ 只看得见一条转移，看不见上上一帧。")
NOTE = ("立这一条是为了给第 5 关的阻断主张补一个窟窿：做穷举搜索时我把 ACTION7 整个排除在外，"
        "当时的理由「整帧回退、深度 1，净效果为零」是一句没走过闸的假设。"
        "回头把语料里全部 5 次 ACTION7 摊开看（runs/bp35-0915-2032/a7audit3.py），5 次全部一致："
        "撤销之后棋盘（行 0..62）与「上一个动作之前那一帧」**一格不差**——"
        "包括第 252 步那次把重力从 down 翻成 up、重画了 1754 格的色 8 点击，也被完整回退；"
        "唯一的差别是 HUD 第 63 行多出 2 格色 15：被撤销的那一步扣的预算、撤销自己扣的预算，都不退还。"
        "所以撤销在可达性上只会更差（花两格预算把棋盘放回原处），排除它是保守的，不是偷懒。"
        "第 4 步那次是「撤销的撤销」（重做），说明它只有深度 1——不能靠连点往回翻更多步。"
        "棋盘被精确回退这件事写不成概念：assert_ 只收一条 (prev, action, nxt)，"
        "要判它得看上上一帧。这是装置的边界，不是我懒得写——所以这里只把可判错的那一半立成主张。")
EVIDENCE = ["a83d67e9998a489a", "58fe41a7eaebf7dc", "9f3627e087550d3d",
            "e85c26eaed9c08ff", "e53d556fa3010899"]


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION7"):
        return "NA"
    if not ctx:
        return "NA"
    a, b = ctx.get("level_prev"), ctx.get("level_next")
    if a is None or b is None:
        return "NA"
    return "TRUE" if b == a else "FALSE"
