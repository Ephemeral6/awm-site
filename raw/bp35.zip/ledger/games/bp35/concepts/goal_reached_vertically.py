"""被液体带着走的那一列上，如果连续液体之后紧接着的那一格是色7 十字，这一步就过关。"""
LEVEL = "L5"
SCOPE = ("只看点色8（翻重力）那一步；方向取 nxt 里的 pull（翻完之后的方向），起点取 prev 里玩家所在的格。"
         "沿那一列往那个方向数连续液体，第一个非液体的格若正是色7 十字所在的格，就断言 level 加一；"
         "数到窗口边缘还没遇到非液体、十字不在窗口里、pull 读不出来，都返回 NA。"
         "**这条不加「换关返回 NA」的护栏**——换关正是它要断言的事。"
         "它补的是 goal_cross_wins 管不到的那一半：第 3 关是竖着撞进十字赢的，不是横着走进去的。")
NOTE = ""
EVIDENCE = ["85b9695644dcfa39"]

from _lib import me, goal, pull, click_cell, kind, BLOCK8, NR, FLOOR


def assert_(prev, action, nxt, ctx=None):
    cell = click_cell(action, prev)
    if cell is None or kind(prev, *cell) != BLOCK8 or ctx is None:
        return "NA"
    m, gl, p = me(prev), goal(prev), pull(nxt)
    if m is None or gl is None or p is None:
        return "NA"
    step = -1 if p == 'up' else 1
    i, j = m
    r = i
    while 0 <= r + step < NR and kind(prev, r + step, j) == FLOOR:
        r += step
    if not (0 <= r + step < NR):
        return "NA"
    if (r + step, j) != gl:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
