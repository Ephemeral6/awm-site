"""左右走时，只要落脚格的正上方不是液体（浮不起来），玩家格行及其以上的像素除玩家那两格外一格不变。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION3 / ACTION4，且 prev 里落脚格（目标格主色是 10 就走过去，否则原地）的正上方不是液体；"
         "落脚格正上方是液体时返回 NA（那一步会上浮加滚屏，由 rise_scrolls 管）；"
         "落脚格已经在窗口第 0 格行（上方读不到）也返回 NA；换关、me() 定位不到返回 NA。"
         "只断言行号 ≤ 玩家格底行的那一片：底下会被排空，这条不声称管。"
         "它借了 move_needs_floor 的主张来算落脚格，那条另有概念走闸。")
NOTE = "board_static 的正身：那条没写「浮不起来」这个前提，被第 28 步的滚屏打掉了。"
EVIDENCE = ["76f4a053cf393504", "66e485cefc1a06a2", "7bd1d48711f966ca"]

from _lib import me, dest, above, origin, SIDE, HUD_ROW, FLOOR


def _blocked(g, action):
    d = dest(g, action)
    if d is None:
        return None
    a = above(g, d)
    return None if a is None else (a != FLOOR)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    act = action.upper()
    if not (act.startswith("ACTION3") or act.startswith("ACTION4")):
        return "NA"
    if _blocked(prev, action) is not True:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    free = set()
    for cell in (a, b):
        r0, c0 = origin(*cell, g=prev)
        for dr in range(SIDE):
            for dc in range(SIDE):
                free.add((r0 + dr, c0 + dc))
    lim = max(origin(*a, g=prev)[0], origin(*b, g=nxt)[0]) + SIDE - 1
    for r in range(min(lim + 1, len(prev))):
        if r == HUD_ROW or prev[r] == nxt[r]:
            continue
        for c, (x, y) in enumerate(zip(prev[r], nxt[r])):
            if x != y and (r, c) not in free:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if _blocked(prev, action) is not True:
        return None
    a = me(prev)
    if a is None:
        return None
    skip = set()
    for j in (a[1] - 1, a[1], a[1] + 1):
        r0, c0 = origin(a[0], j, g=prev)
        for dr in range(SIDE):
            for dc in range(SIDE):
                skip.add((r0 + dr, c0 + dc))
    lim = origin(*a, g=prev)[0] + SIDE - 1
    return {(r, c): v for r in range(min(lim + 1, len(prev))) if r != HUD_ROW
            for c, v in enumerate(prev[r]) if (r, c) not in skip}
