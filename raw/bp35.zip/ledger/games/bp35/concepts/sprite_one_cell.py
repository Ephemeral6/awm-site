"""玩家永远是「色9 恰 6 格」，全落在同一个 5x5 的格子里，且那一格里恰有 2 格色11（鼻子）。"""
LEVEL = "L0"
SCOPE = ("看每一条转移的 nxt 帧；换关返回 NA。只管玩家自己的形状与整格对齐，不管它在哪。"
         "**不再声称全图只有 2 格色11**：色 11 也用来画液面的装饰边（第 1 关 (1,2)(1,3)(1,4) 三格各有 2 格）。"
         "nxt 是 GAME_OVER 那一帧时返回 NA：玩家被顶到液面就整个消失，这条不声称管它死了以后长什么样。")
NOTE = ("v4：scope 缩到只看左右走——点色8 那一帧玩家整个偏离格点 2 个像素（91e0cd2e1f5924b4）。"
        "v1 把「全图色11 恰 2 格」和玩家形状捆在一起，被 57bd2b25f3e428c2 打掉——"
        "第 1 关的液面装饰边也是色 11，全图共 8 格。v2 只数玩家那一格里的色 11。")
EVIDENCE = ["a096d65c539c023c", "91e0cd2e1f5924b4", "6c2874a8285dd12c", "57bd2b25f3e428c2", "ee4d258e78331df6"]

from _lib import BODY, NOSE, cell_at

from geo import cells_of


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    act = action.upper()
    if not (act.startswith("ACTION3") or act.startswith("ACTION4")):
        return "NA"
    if ctx and ctx.get("state_next") == "GAME_OVER":
        return "NA"
    body = cells_of(nxt, (BODY,))
    if len(body) != 6:
        return "FALSE"
    cells = {cell_at(r, c, nxt) for r, c in body}
    if len(cells) != 1 or None in cells:
        return "FALSE"
    home = next(iter(cells))
    nose = [(r, c) for r, c in cells_of(nxt, (NOSE,)) if cell_at(r, c, nxt) == home]
    return "TRUE" if len(nose) == 2 else "FALSE"
