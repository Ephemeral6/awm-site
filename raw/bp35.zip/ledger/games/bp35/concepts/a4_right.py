"""ACTION4 要么让玩家格右移一格（行不变、列 +1），要么玩家格原地不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION4；换关返回 NA；me() 在 prev 或 nxt 里定位不到返回 NA。"
         "apply 额外借用了另外两条主张（右移生效的条件是目标格主色为 10、走完之后鼻子朝右），"
         "它们各自另有概念走闸；assert_ 本身只断言「格坐标要么右移一格要么不动」。")
NOTE = ""
EVIDENCE = ["f295fbff611939e4", "dcee3c620d74b86d"]

from _lib import me, kind, origin, SIDE, SPRITE, FLOOR, NC


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.upper().startswith("ACTION4"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) in ((0, 1), (0, 0)) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.upper().startswith("ACTION4"):
        return None
    a = me(prev)
    if a is None:
        return None
    tgt = (a[0], a[1] + 1)
    if tgt[1] >= NC or kind(prev, *tgt) != FLOOR:
        return None
    out = {}
    r0, c0 = origin(*a, g=prev)
    for dr in range(SIDE):
        for dc in range(SIDE):
            out[(r0 + dr, c0 + dc)] = FLOOR
    r1, c1 = origin(*tgt, g=prev)
    for dr in range(SIDE):
        for dc in range(SIDE):
            v = SPRITE['R'][dr][dc]
            if v is not None:
                out[(r1 + dr, c1 + dc)] = v
    return out
