"""格点相位跟着重力走：玩家被往上拉时行相位是 1，被往下拉时是 3；列相位一直是 1。"""
LEVEL = "L7"
SCOPE = ("看每一条转移的 nxt 帧；_lib.pull(nxt) 读不出来返回 NA；帧里一个色 3 的点都没有（相位无从测）也返回 NA。"
         "行相位由色 3 点阵实测（phase_of），被拉方向由玩家贴着哪一侧实测（pull）——两种互不相干的读法，"
         "所以这条不是循环论证。它把一件本来藏在词汇表里的世界事实拿出来走闸："
         "第 152 步点色8 翻重力之后，整块棋盘相对帧下移了 2 行，而 kind/patch/me 当时全按相位 1 读，"
         "地图静默地错了一整批——把它写成概念，以后再变就会当场响。")
NOTE = ""
EVIDENCE = ["91e0cd2e1f5924b4", "a096d65c539c023c"]

from _lib import pull, phase_of, DOT, HUD_ROW


def assert_(prev, action, nxt, ctx=None):
    p = pull(nxt)
    if p is None:
        return "NA"
    if not any(v == DOT for r in range(HUD_ROW) for v in nxt[r]):
        return "NA"
    pr, pc = phase_of(nxt)
    want = 1 if p == 'up' else 3
    return "TRUE" if (pr, pc) == (want, 1) else "FALSE"
