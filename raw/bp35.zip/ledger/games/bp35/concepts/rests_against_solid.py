"""每个动作之后，玩家的正上方和正下方至少有一个不是液体——它总是贴着什么停住，不会悬在液体中间。"""
LEVEL = "L6"
SCOPE = ("看每一条非 RESET 转移的 nxt 帧；换关返回 NA；me() 定位不到返回 NA；"
         "玩家在窗口最上或最下一格行（有一侧读不到）也返回 NA。"
         "这条比 ceiling_above_player 弱一档，但它**不挑方向**：第 3 关点色8 把玩家从浮的变成沉的之后，"
         "「头顶不是液体」不再成立，而「总贴着点什么」还成立。")
NOTE = "接替 ceiling_above_player：那条写死了「浮」这一个方向，被 a096d65c539c023c 打掉。"
EVIDENCE = ["a096d65c539c023c", "cc69bce608399792", "7bd1d48711f966ca"]

from _lib import me, kind, NR, FLOOR


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.upper().startswith("RESET"):
        return "NA"
    m = me(nxt)
    if m is None:
        return "NA"
    i, j = m
    if i - 1 < 0 or i + 1 >= NR:
        return "NA"
    up, dn = kind(nxt, i - 1, j), kind(nxt, i + 1, j)
    if up is None or dn is None:
        return "NA"
    return "TRUE" if (up != FLOOR or dn != FLOOR) else "FALSE"
