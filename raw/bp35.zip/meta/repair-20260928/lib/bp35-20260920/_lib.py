"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测（第 1–27 步）：
    画面是 6 步距的瓦片格：瓦片内腔 5×5，瓦片之间 1 格线。内腔左上角 (top, left) 满足
    top ≡ 1 (mod 6)、left ≡ 1 (mod 6)，可玩区是屏幕列 7..59（9 列瓦片），竖向随玩家滚动。
    ——「7 列 / 列 13..53」是第 1–27 步的读数，第 4、5 关把两头都推翻了：
      右边界：第 8 列 left=55 确实可站可走（反例 991ba49c2c418786：玩家从 left=49 右移到 left=55，
              而 COL1=54 让 tile_kind 返回 None，move_right 于是把一次合法右移判成「被挡」）。
      左边界：第 5 关下半场的目标口袋里，屏幕列 7..11 是色 10 空格（出界是渲染成色 5 实心的），
              所以 left=7 也是一列真瓦片。
              ——「left=1 那列至今只见过实心，没有证据说它在界内，故 COL0 只放宽到 7」这句话
              被第 8 关推翻了：反例 d9335d7f96368978（第 3706 步 ACTION3），玩家从 left=7 左移**站进了
              left=1**，而 COL0=7 让 tile_kind 返回 None，move_left 把一次合法左移判成「被挡」。
              第 8 关的 left=1 整列是一条竖井（空格夹着六枚重力开关），是这一关的主通道。
              故 COL0 放宽到 1：可玩区是 10 列瓦片。右边界仍是 60（屏幕列 61..63 是边框实心）。
    玩家：一块 5×5 内腔里的 色 9（6 格）+ 色 11（2 格）图样，屏幕行永远 37..41（镜头竖向跟随）。
    色 11 在内腔第 1 列 = 朝左，在第 3 列 = 朝右。
    色 10 = 空；色 5（带 3 的点纹）= 实心；色 14 的 5×5（四角 3）= 可点掉的块；色 7 = 目标图样（暂只见过一次）。
    ACTION3 左移一格瓦片、ACTION4 右移一格瓦片，随后**向上升**到被挡住为止（升 k 格瓦片 ⇒ 画面整体下滚 6k）。
    ACTION7 = 撤销上一步。ACTION6:x,y 点在 14 块上 ⇒ 该块变 10，与相邻空瓦片之间的线也变 10。
    底行 (63, k) 每步点亮一格色 15（k = 已走步数），像计数器。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 6                       # 瓦片步距（内腔 5 + 线 1）
PHASE = (1, 1)                 # 内腔左上角的相位：top % 6 == 1, left % 6 == 1
DELTA = {"ACTION3": (0, -6), "ACTION4": (0, 6)}   # 横向；竖向由 rise() 决定
ME_ROW = 37                    # 玩家内腔的屏幕顶行（镜头竖向跟随）
COL0, COL1 = 1, 60             # 可玩区屏幕列 [1, 60)：10 列瓦片，left = 1,7,13,19,25,31,37,43,49,55
BOTTOM = 63                    # 计数器所在行

EMPTY, SOLID, BLOCK, PLAYER_INK, PLAYER_FACE, GOAL, DOT, TICK, SPIKE = 10, 5, 14, 9, 11, 7, 3, 15, 15
CYAN = 12                      # 第2关起出现的青色块（5×5，形状同块），行为待测

# 玩家 5×5 内腔图样（相对内腔左上角），朝左；朝右把第 1 列与第 3 列的 11/9 对调
PLAYER_L = ("55955", "5B995", "5B995", "55955", "A555A")
PLAYER_R = ("55955", "599B5", "599B5", "55955", "A555A")
BLOCK_PAT = ("3EEE3", "EEEEE", "EEEEE", "EEEEE", "3EEE3")
GOAL_PAT = ("55755", "57775", "55755", "A555A", "AAAAA")
_H = "0123456789ABCDEF"


def _pat_cells(pat, top, left):
    return {(top + r, left + c): _H.index(ch) for r, row in enumerate(pat) for c, ch in enumerate(row)}


def tile_top(r):
    """r 所在瓦片内腔的顶行（线格归到它上面的瓦片，规划时不该问线格）。"""
    return r - ((r - 1) % 6)


def tile_left(c):
    return c - ((c - 1) % 6)


def me(g):
    """玩家内腔的 (top_row, left_col)：色 9 的格所在瓦片。定位不到返回 None。"""
    cells = [(r, c) for r in range(64) for c in range(64) if g[r][c] == PLAYER_INK]
    if len(cells) != 6:
        return None
    r0 = min(r for r, _ in cells)
    tops = [c for r, c in cells if r == r0]
    if len(tops) != 1:
        return None
    return (r0, tops[0] - 2)          # 顶端那一格 9 在内腔第 2 列（两种朝向都是）


def facing(g):
    """'L' / 'R' / None：色 11 在内腔第 1 列还是第 3 列。"""
    m = me(g)
    if m is None:
        return None
    r, c = m
    if g[r + 1][c + 1] == PLAYER_FACE:
        return "L"
    if g[r + 1][c + 3] == PLAYER_FACE:
        return "R"
    return None


def tile_kind(g, top, left):
    """瓦片内腔是什么：'empty' / 'solid' / 'block' / 'spikeblock' / 'player' / 'goal' / 'spike' / None(出界)。
    spike：内腔含色 15 的「尖刺」（第 34 步：升到它正下方玩家消失、GAME_OVER）。
    spikeblock：第 7 关出现的 {色3:4, 色15:21}——图样逐像素等于 BLOCK_PAT 把色14 换成色15，
    是「块」不是尖刺。第 2676 步 b76efbda14320a57 点它：它消失、四个正交邻格各生一块同样的。
    它碰到会不会死**没测过**，deadly() 仍只认尖刺精灵，规划时按「未知危险」对待。"""
    if not (0 <= top and top + 4 < BOTTOM and COL0 <= left and left + 4 < COL1):
        return None
    inner_list = [g[top + r][left + c] for r in range(5) for c in range(5)]
    inner = set(inner_list)
    if inner == {EMPTY}:
        return "empty"
    if PLAYER_INK in inner:
        return "player"
    if BLOCK in inner:
        return "block"
    if GOAL in inner:
        return "goal"
    if inner == {DOT, SPIKE} and inner_list.count(SPIKE) == 21:
        return "spikeblock"
    if SPIKE in inner:
        return "spike"
    if CYAN in inner:
        # 青块点一次缩成 CAC 种子（约 5 个色12，可通行）；满块（约 21 个色12）挡路
        return "cyanseed" if inner_list.count(CYAN) <= 8 else "cyan"
    if inner <= {SOLID, DOT}:
        return "solid"
    return None


def phase(g):
    """这一帧屏幕上瓦片内腔顶行的相位（mod 6）。

    世界瓦顶恒 ≡1 (mod 6)，但镜头 off = 玩家世界行 −(27 重力向下 / 37 重力向上)，
    所以屏幕上瓦顶 ≡3（向下）、≡1（向上）。玩家自己就是标尺：me(g)[0] % 6。
    玩家不在帧上时退回按 gravity_down 猜。

    反例（逼出这个函数的那一条）：b13f9b9adeeedd3d 的 prev 帧重力向下、真相位 3，
    而 tiles() 原先写死 ≡1，窗口横跨两块瓦，把 (51,19) 的目标图样记成 (49,19) 的一块 goal。
    像素是真的（第 6 关屏上确有目标，世界 W73/L19），错的只是窗口位置。"""
    m = me(g)
    if m is not None:
        return m[0] % 6
    return 3 if gravity_down(g) else 1


# 【修复副本改动 1/2】tiles / blocks / goals / spikes / walls 五个读数加下划线前缀，退出抽象状态（只改了名字和它们互相调用时的名字，逻辑一字未改）。
# 它们原来各是一张 64×64 像素步长的位掩码（每个 4096 位），五张加起来让数据段膨胀到装不下；
# 它们的值全都是新读数 grid（每格瓦片码）与 phase 的函数——证明脚本见
# meta/repair-20260928/_scratch/bp35-20260920/derive_proof.py，结果写在交回里。
def _tiles(g):
    """屏幕上所有瓦片：{(top, left): kind}。顶行相位按本帧现算，不写死。"""
    ph = phase(g)
    out = {}
    for top in range(ph, BOTTOM - 4, 6):
        for left in range(COL0, COL1 - 4, 6):
            out[(top, left)] = tile_kind(g, top, left)
    return out


def _blocks(g):
    return frozenset(k for k, v in _tiles(g).items() if v == "block")


def _goals(g):
    return frozenset(k for k, v in _tiles(g).items() if v == "goal")


def _spikes(g):
    return frozenset(k for k, v in _tiles(g).items() if v == "spike")


def deadly(g, top, left):
    """停在内腔 (top, left) 会不会被尖刺杀死：看**重力上游方向**的那一格是不是尖刺。

    旧版写死「正上方是尖刺」，那是重力向上的读法（第 1 关第 34 步：升到尖刺正下方玩家消失）。
    第 6 关第 2620 步 eb4fee0a16342a91 给了反方向的一条：重力向下，玩家沿 L49 竖井坠到 W61/L49
    停住，其**正下方** W67/L49 是尖刺，next 帧玩家消失、state=GAME_OVER。
    尖刺图样本身是尖头朝上、底座压在下边框上——两次致死的几何朝向相反，
    所以致死判据不是尖头朝哪边，是「玩家被重力压进了它」。"""
    d = 6 if gravity_down(g) else -6
    return tile_kind(g, top + d, left) == "spike"


def slide_to(g, top, left):
    """从内腔 (top, left) 沿当前重力方向滑到被挡住为止，返回停住的内腔顶行。
    出界时 tile_kind 返回 None、passable(None) 为假，循环自然停下。"""
    d = 6 if gravity_down(g) else -6
    while passable(tile_kind(g, top + d, left)):
        top += d
    return top


def slide_known(g, top, left):
    """slide_to 的停点是否在屏幕内可判：挡住它的那一格必须真在屏幕上，
    而不是「滑出屏幕所以看起来被挡住了」。"""
    d = 6 if gravity_down(g) else -6
    return tile_kind(g, slide_to(g, top, left) + d, left) is not None


def passable(kind):
    return kind in ("empty", "goal", "player", "cyanseed")


def rise_to(g, top, left):
    """从内腔 (top, left) 出发一直向上，返回停住的内腔顶行（上方是空/目标就继续升）。
    升到屏幕最上一排瓦片（top == 相位）还没被挡时，真正的停点在屏幕外——用 rise_known 判断。"""
    while top - 6 >= 0 and passable(tile_kind(g, top - 6, left)):
        top -= 6
    return top


def rise_known(g, top, left):
    """rise_to 的停点是否在屏幕内可判：停点不是屏幕最上一排瓦片（顶行 == 相位）。
    原先写死「stop > 1」，重力向下时相位是 3，最上一排的 top=3 会被误判成「可判」。"""
    stop = rise_to(g, top, left)
    return stop > stop % 6


def step_count(g):
    """底行点亮的格数。**不认颜色**：第 4 关点亮用色 15，第 6 关换成了色 7（和目标同色），
    所以只数「不是色 0」的格。反例：c0e76cce7eec1550 起的第 6 关十条转移，底行一路 0→7。"""
    return sum(1 for c in range(64) if g[BOTTOM][c] != 0)


def tick_color(g):
    """底行点亮用的是哪个颜色；还没点亮过（本关第 0 步）返回 None。"""
    seen = {g[BOTTOM][c] for c in range(64)} - {0}
    return next(iter(seen)) if len(seen) == 1 else None


def gravity_down(g):
    """重力是否朝下。读玩家自己的内腔顶行：相机律把玩家钉在屏幕行 27（向下）或 37（向上）。

    原来读左 HUD 的单个像素 g[1][4] == 色3。第 6 关最左那列瓦片整列是重力开关，
    (1,4) 正落在开关内腔里恒为色 8，于是永远读成「向上」——
    反例 c0e76cce7eec1550（ACTION6:3,39）：next 帧 me()=(27,19)，重力明明已经向下。
    玩家不在帧上（死了/换关重画）时退回旧读法。"""
    m = me(g)
    if m is not None and m[0] in (27, 37):
        return m[0] == 27
    return g[1][4] == DOT


def click_tile(action, g=None):
    """'ACTION6:x,y' -> 点中的瓦片 (top, left)；不是点击返回 None。

    给了帧 g 就按该帧的重力定屏幕相位：世界瓦顶恒 ≡1 (mod 6)，而镜头
    off = 玩家世界行 −(27 重力向下 / 37 重力向上)，所以屏幕上瓦顶 ≡3（向下）、≡1（向上）。
    不给 g 沿用旧读法（恒 ≡1），重力向下时会整整错开 2 行、取到横跨两块瓦的窗口。
    佐证：第 2579 步 ACTION6:27,59（重力向下）帧差 (24,56) 10→5 …… (25,57) 10→3，
    被点的世界瓦顶 −23 落在屏幕行 57，相位确为 3。"""
    if not action.startswith("ACTION6:"):
        return None
    xs, ys = action.split(":")[1].split(",")
    x, y = int(xs), int(ys)
    if g is None:
        return (tile_top(y), tile_left(x))
    ph = 3 if gravity_down(g) else 1
    return ((y - ph) // 6 * 6 + ph, (x - 1) // 6 * 6 + 1)


def _walls(g):
    """阻挡：实心与块瓦片的集合（内腔左上角）。"""
    return frozenset(k for k, v in _tiles(g).items() if v in ("solid", "block"))


# =====================================================================================
# 【修复副本改动 2/2】以下全部是新增（2026-09-29，形式化修复）。
#
# 为什么要加：这一局镜头竖向跟随玩家，一关的地图远比一屏高（最高约 40 行瓦片），
# 横移/坠落/翻重力后新滚进屏幕的那几行，单凭这一帧的像素说不出来。于是：
#   · grid（新读数，感知原语）：这一帧 10×10 屏幕瓦片各是什么（码表见 _CODE 注释）。
#   · tick_wrap（新读数，感知原语）：底行计数器第二轮已经重涂了几格。
#   · 隐藏量 h_pw / h_mem / h_stk（按真实历史累加，只用 h、前帧、动作串、后帧四样）：
#       h_pw  玩家所在的世界瓦片行（本关开局 = 0，向下为正），由前后两帧的画面配准量出来；
#       h_mem 本关看见过的世界瓦片（每格 4 位：0 = 没见过；1..10 = 最后一次看见时的码 + 1；
#             11..15 = 「这一格被点过、点完之后还没再看见」，点它时它分别是 块/青块/青种/开关/spikeblock；
#             点完没再看见、但点它时是别的码（点了不起作用的格），照常记「码 + 1」）；
#       h_stk 撤销栈：最近 4 步各记一条「这一步之前的样子」（玩家行列、重力、朝向、这一步里看见变了的格的旧码）。
#     三者都只记录看见过的东西；「点了之后会怎样、落到哪」一律不在这里算，交给 Lean 的 stepRules。
#   · LEVEL_CONST[关].map：每关开局时的世界地图（游戏内容，和换关后的布局同类），
#     每格 = 本局路线那个 run（bp35-0920-0507）里这一格**第一次被看见**时的码，坐标系同 h_pw；
#     推导脚本 meta/repair-20260928/_scratch/bp35-20260920/derive_k.py，文本表见 _MAPS。
#     LEVEL_CONST[关].tick：本关计数器第一轮的颜色（第 0–5 关色 15，第 6–8 关色 7；
#     两个 run 里每一关第一格点亮的颜色，probe7.py 全语料 3700+ 次无例外）。
# =====================================================================================

# 瓦片码（grid / 世界地图 / h_mem 共用）。先按原 tile_kind 分类，再细分：
#   0 empty  1 solid  2 block  3 尖刺（尖头朝上图样） 4 尖刺（倒置图样）  5 cyan  6 cyanseed
#   7 开关（色 8 图样）  8 spikeblock  9 goal  10 玩家朝左  11 玩家朝右
#   12 tile_kind 说是 spike 但图样不标准（潮水盖住的格等）  13 tile_kind 说是 player 但读不出朝向
#   15 其余（tile_kind 为 None 且不是开关图样：画面过渡帧、潮水等）
_SPIKE_UP = ("5FFF5", "5FFF5", "5FFF5", "5FFF5", "5B0B5")
_SPIKE_DN = ("5B0B5", "5FFF5", "5FFF5", "5FFF5", "5FFF5")
_SWITCH = ("38883", "88888", "88888", "88888", "38883")
_KIND_CODE = {"empty": 0, "solid": 1, "block": 2, "cyan": 5, "cyanseed": 6, "spikeblock": 8, "goal": 9}
_NOSTORE = (10, 11, 12, 13, 14, 15)      # 不是地形的码：不记进世界记忆（14 没有用到）
_ANCH = {27: 4, 37: 6}                   # 玩家锚点屏幕行 -> 玩家所在的屏幕瓦片行号
_OFF = 40                                # 世界行 W 在记忆/地图里的行下标 = W + _OFF
# 撤销栈深度 _KMAX：游戏真实的栈上限**未知**。语料里最长连按 ACTION7 是 5 次（0916 run seq 2805–2809，
# 第 5 次画面仍在变），第一版取 4 被审计抓出（seq 2809 栈已弹空却还能撤）。现取 8，只担保「≥ 语料最深 5」。
_KMAX, _REC, _SL = 8, 128, 4             # 撤销栈深度、每条记录位宽、记忆每格位宽
_FLAG = {2: 11, 5: 12, 6: 13, 7: 14, 8: 15}   # 「点过、没再看见」的记法（见上）


def _rows_hex(g, top, left):
    return tuple("".join(_H[g[top + r][left + c]] for c in range(5)) for r in range(5))


def _code_at(g, top, left):
    k = tile_kind(g, top, left)
    if k in _KIND_CODE:
        return _KIND_CODE[k]
    rows = _rows_hex(g, top, left)
    if k == "spike":
        return 3 if rows == _SPIKE_UP else 4 if rows == _SPIKE_DN else 12
    if k == "player":
        if g[top + 1][left + 1] == PLAYER_FACE:
            return 10
        if g[top + 1][left + 3] == PLAYER_FACE:
            return 11
        return 13
    return 7 if rows == _SWITCH else 15


def _grid_rows(g):
    ph = phase(g)
    return [[_code_at(g, ph + 6 * i, 1 + 6 * j) for j in range(10)] for i in range(10)]


def grid(g):
    """新读数：这一帧 10×10 屏幕瓦片的码，打包成一个整数（第 i 行第 j 列占第 4*(10i+j) 起的 4 位）。
    行按本帧相位（phase）取，列是可玩区 10 列（left = 1,7,…,55）。"""
    v = 0
    for i, row in enumerate(_grid_rows(g)):
        for j, c in enumerate(row):
            v |= c << (4 * (10 * i + j))
    return v


def tick_wrap(g):
    """新读数：底行 64 格点满之后，第二轮从左起已重涂了几格（与最右一格不同色的前缀长度）；没点满为 0。"""
    if step_count(g) < 64:
        return 0
    base = g[BOTTOM][63]
    k = 0
    while k < 64 and g[BOTTOM][k] != base:
        k += 1
    return k


def tide_top(g):
    """新读数：潮顶屏幕行（照搬概念 tide_rises_and_kills 的 tide_top）：从行 62 起向上连续、
    每行至少 30 格色 15 的那一整块的顶行；行 62 不满足就是没有潮，返回 None。
    比概念原文多一道门槛：行 62 的 11 个格线列（0,6,…,60）至少 6 个是色 15——潮是整屏的带子，
    盖过格线；一排 spikeblock（色 15 画的块）也能凑够 30 格，但格线列是色 5（路线 run 第 7 关 seq 261–263 实测）。"""
    def lit(y):
        return sum(1 for x in range(64) if g[y][x] == 15) >= 30
    if not lit(62) or sum(1 for x in range(0, 61, 6) if g[62][x] == 15) < 6:
        return None
    y = 62
    while y - 1 >= 0 and lit(y - 1):
        y -= 1
    return y


# ---------------- 隐藏量：世界记忆的读写 ----------------
def _midx(W, C):
    return _SL * (10 * (W + _OFF) + C)


def _mem_get(mem, W, C):
    if W + _OFF < 0 or not 0 <= C < 10:
        return 0
    return (mem >> _midx(W, C)) & 15


def _mem_put(mem, W, C, v):
    if W + _OFF < 0:
        return mem
    i = _midx(W, C)
    return (mem & ~(15 << i)) | (v << i)


def _write_screen(mem, gr, pw, ip):
    """把这一屏看得见的地形记进记忆（玩家、潮水、读不出的格不记）。"""
    for i in range(10):
        for j in range(10):
            c = gr[i][j]
            if c in _NOSTORE:
                continue
            mem = _mem_put(mem, pw + i - ip, j, c + 1)
    return mem


def _usable(g):
    m = me(g)
    return m is not None and m[0] in _ANCH


def _pixel_scores(g, h, mp, mn):
    """前后两帧逐像素配准：后帧行 r 对应前帧行 r+d。返回 {玩家世界行增量: 分数}。
    只比两帧里都不是玩家图样、不是底行计数器的像素；分数 = 吻合数 − 11 × 不吻合数。
    d 必须 ≡ 锚点差 (mod 6)：世界瓦片是 6 行一格，镜头只随玩家整格走，翻重力时锚点 37↔27 差 10。"""
    ap, an = mp[0], mn[0]
    res = (ap - an) % 6
    out = {}
    for d in range(-62, 63):
        if d % 6 != res:
            continue
        mis = cnt = rows = 0
        for r in range(BOTTOM):
            r2 = r + d
            if not 0 <= r2 < BOTTOM:
                continue
            rows += 1
            hr, gr = h[r], g[r2]
            for c in range(64):
                if mn[0] - 1 <= r <= mn[0] + 5 and mn[1] - 1 <= c <= mn[1] + 5:
                    continue
                if mp[0] - 1 <= r2 <= mp[0] + 5 and mp[1] - 1 <= c <= mp[1] + 5:
                    continue
                cnt += 1
                mis += hr[c] != gr[c]
        if rows >= 2:
            out[(d + an - ap) // 6] = (cnt - mis) - 10 * mis
    return out


def _localize(mem, pw, g, h):
    """后帧里玩家在哪一世界行：把后帧的瓦片和本关的世界记忆比（非实心格吻合记 5 分、实心格 1 分、
    不吻合扣 50 分），再加上前后两帧的像素配准分，取最高。只用看见过的东西，不用任何移动规则。"""
    mp, mn = me(g), me(h)
    gn = _grid_rows(h)
    ipn = _ANCH[mn[0]]
    px = _pixel_scores(g, h, mp, mn)
    best = None
    for dW in range(-40, 41):
        a = x = 0
        for i in range(10):
            W = pw + dW + i - ipn
            for j in range(10):
                c = gn[i][j]
                if c in _NOSTORE:
                    continue
                m = _mem_get(mem, W, j)
                if m == 0 or m >= 11:
                    continue
                if m - 1 == c:
                    a += 5 if c != 1 else 1
                else:
                    x += 1
        sc = 6 * (a - 50 * x) + px.get(dW, 0)
        if best is None or sc > best[0]:
            best = (sc, dW)
    return pw + best[1]


def _rec_pack(pw, col, gd, face, changes):
    v = 1 | ((pw + 64) << 1) | (col << 8) | (gd << 12) | (face << 13) | (len(changes) << 14)
    for k, (W, C, code) in enumerate(changes):
        v |= ((10 * (W + _OFF) + C) | (code << 12)) << (17 + 16 * k)
    return v


def _rec_unpack(v):
    pw = ((v >> 1) & 127) - 64
    col, gd, face, n = (v >> 8) & 15, (v >> 12) & 1, (v >> 13) & 1, (v >> 14) & 7
    ch = []
    for k in range(n):
        e = (v >> (17 + 16 * k)) & 0xFFFF
        ch.append(((e & 0xFFF) // 10 - _OFF, (e & 0xFFF) % 10, e >> 12))
    return pw, col, gd, face, ch


def _click_cell(action, ph):
    """点击落在哪个屏幕瓦片 (i, j)；不是点击、或落在 10×10 瓦片网格外返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    x, y = map(int, action.split(":")[1].split(","))
    if y < ph:
        return None
    i, j = (y - ph) // 6, (x - 1) // 6
    if not (0 <= i < 10 and 0 <= j < 10):
        return None
    return i, j


HIDDEN_INIT = {"pw": 0, "mem": 0, "stk": 0}


def hidden_step(h, prev, action, nxt):
    """只用四样：上一步的隐藏量、前帧、动作串、后帧。
    · 记忆：把前帧、后帧看得见的地形写进去；被点的那格若点完没再看见，记下「点它时的样子」并打标。
    · pw：ACTION7 取撤销栈顶记下的行；否则由画面配准量出来（_localize）。
    · 撤销栈：ACTION7 弹栈并把记录里的旧码写回记忆；其余动作压一条「这一步之前」的记录
      （含前后两帧都看得见、码变了的格的旧码，以及被点那格的旧码）。每一步都压，不管画面动没动。"""
    pw, mem, stk = h["pw"], h["mem"], h["stk"]
    if not _usable(prev):
        return dict(h)
    mp = me(prev)
    gp = _grid_rows(prev)
    ipp = _ANCH[mp[0]]
    colp = (mp[1] - 1) // 6
    mem = _write_screen(mem, gp, pw, ipp)
    act = action.split("|")[0]
    if act == "ACTION7":
        top = stk & ((1 << _REC) - 1)
        pw2 = pw
        if top:
            opw, _c, _g, _f, ch = _rec_unpack(top)
            for W, C, code in ch:
                mem = _mem_put(mem, W, C, code + 1)
            stk >>= _REC
            pw2 = opw
        if _usable(nxt):
            mem = _write_screen(mem, _grid_rows(nxt), pw2, _ANCH[me(nxt)[0]])
        return {"pw": pw2, "mem": mem, "stk": stk}
    if not _usable(nxt):
        return {"pw": pw, "mem": mem, "stk": stk}
    pw2 = _localize(mem, pw, prev, nxt)
    mn = me(nxt)
    gn = _grid_rows(nxt)
    ipn = _ANCH[mn[0]]
    changes = {}
    for i in range(10):
        W = pw + i - ipp
        k = W - pw2 + ipn
        if not 0 <= k < 10:
            continue
        for j in range(10):
            a, b = gp[i][j], gn[k][j]
            if a in _NOSTORE or b in _NOSTORE:
                continue
            if a != b:
                changes[(W, j)] = a
    mem = _write_screen(mem, gn, pw2, ipn)
    cc = _click_cell(act, phase(prev))
    if cc is not None and gp[cc[0]][cc[1]] not in _NOSTORE:
        W, j = pw + cc[0] - ipp, cc[1]
        k = W - pw2 + ipn
        if not (0 <= k < 10 and gn[k][j] not in _NOSTORE):
            c0 = gp[cc[0]][cc[1]]
            mem = _mem_put(mem, W, j, _FLAG.get(c0, c0 + 1))
            changes.setdefault((W, j), gp[cc[0]][cc[1]])
    ch = sorted((W, C, c) for (W, C), c in changes.items())
    face = 1 if gp[ipp][colp] == 11 else 0
    rec = _rec_pack(pw, colp, 1 if mp[0] == 27 else 0, face, ch[:6])
    stk = ((stk << _REC) | rec) & ((1 << (_REC * _KMAX)) - 1)
    return {"pw": pw2, "mem": mem, "stk": stk}


# ---------------- 每关常数 ----------------
# _MAPS[关] = (最上一行的世界行号, [每行 10 个字符])：字符是瓦片码的十六进制，'.' = 本 run 从没看见过（按实心处理）。
# 由 derive_k.py 在 bp35-0920-0507（本局路线那个 run）上用上面的 hidden_step 累出 h_pw，
# 取每个世界格第一次被看见时的码。另一 run（bp35-0916-0958）同一关同一格第一次看见的码与此对照：10 关 3129 格 0 处不一致。
# 注意：第 8 关 W=-28 那一行（下面第 8 关的第 7 行 "0100088800"）的 C=5,6,7 三个 spikeblock，
# 两个 run 里第一次看见都在玩家点了相邻 spikeblock 之后——「首见即点击后，不担保是开局布局」，可能是点击的产物。
# 这张图在关内是承重的：路线 365 个关内步里，滚进屏幕的新行由它提供 88 步，落点/列/重力因未见格而变 5 步，
# 玩家身下从没露出过的格 19 步；拿它预测另一 run 3705 步对 3666 步（审计 2026-09-29 复算）。
_MAPS = {
    0: (-22, [
        "1111111111", "1111111111", "1111111111", "1111111111", "1111111111", "1111111111",
        "1109000001", "1100000001", "1111122211", "1100000001", "1100000001", "1100222001",
        "1100000001", "1100000001", "1122211111", "1122200001", "1122200001", "1111100001",
        "1111122221", "1100000001", "1100000001", "1111111011", "1100000001", "1100000001",
        "1100000001", "1100000001",
    ]),
    1: (-36, [
        "1111111111", "1111111111", "1111111111", "1111111111", "1111111111", "1111111111",
        "1100093331", "1100000001", "1122222221", "1100000221", "1111100001", "1133300001",
        "1100000001", "1112111121", "1112111121", "1112222221", "1112111111", "1130333331",
        "1100000001", "1122211111", "1100000031", "1100000001", "1111121111", "1111121111",
        "1100003331", "1100000001", "1100000001", "1121112221", "1122220001", "1122220001",
        "1111110001", "1133310001", "1100010001", "1100010001", "1122222221", "1122222221",
        "1100000001", "1100000001", "1100000001", "1100000001",
    ]),
    2: (-27, [
        "1111111111", "1111111111", "1111111111", "1133333331", "1100000001", "1155555551",
        "1100050901", "1100050001", "1100111111", "1100333111", "1100000111", "1155666111",
        "1100000001", "1100000001", "1111111001", "1111133001", "1111166001", "1110055001",
        "1100000001", "1101111001", "1103333001", "1100000001", "1106661111", "1100000001",
        "1100000001", "1100000001", "1111112221", "1100050001", "1100050001", "1100000001",
        "1100000001",
    ]),
    3: (-8, [
        "1111111111", "1111171111", "1111111111", "1100000001", "1100000001", "1111111101",
        "1111111001", "1111110001", "1133000001", "1100000001", "1100000001", "1122111111",
        "1100000001", "1100022221", "1100000001", "1100001001", "1111111001", "1117171221",
        "1111111221", "1133033001", "1100000001", "1100900001", "1100000001", "1100000001",
        "1111111111", "1111711111", "1111111111", "1111111111", "1111111111",
    ]),
    4: (-11, [
        "1111111111", "1111111111", "1111111111", "1111111111", "1111111111", "1111111111",
        "1111090333", "1111000222", "1111000222", "1111111110", "1111111110", "1100000070",
        "1100000011", "1144440011", "1111110011", "1111112211", "1100000011", "1101110033",
        "1101110000", "1103312200", "1106611122", "1100000000", "1100000000", "1110000011",
        "1110011111", "1112211111", "1110011111", "1114411111", "1111111171", "1111111111",
    ]),
    5: (-22, [
        "1111111171", "1111111111", "1111111111", "1111111111", "1111111111", "1111111111",
        "1111111001", "1111000001", "1111011111", "1111033331", "1100000001", "1100000001",
        "1166665661", "1100000001", "1144440001", "1111110111", "1111110111", "1133300001",
        "1100000101", "1166611101", "1100000001", "1111117111", "1100000001", "1100000001",
        "1100006601", "1144444401", "1111111101", "1111111101", "1111111101", "1000100001",
        "1090700001", "1111111111", "1111111111", "1111111111", "1111111111", "1111111111",
    ]),
    6: (-19, [
        "1111111111", "1111111111", "1111111111", "1111111111", "1111111613", "7111111610",
        "7111111600", "7111111600", "7106303610", "7106605610", "7106050610", "7106040410",
        "7101111110", "7101666010", "7101666010", "7100666000", "7100666000", "7104666400",
        "7111111100", "7100006100", "7100000000", "7100006100", "7111111100", "7100000000",
        "7100000040", "7109011010", "7100011000", "7100011111", "1111111111", "1111111111",
        "1111111111", "1111111111",
    ]),
    7: (-30, [
        "1111171111", "1111111111", "1111111111", "1111111111", "1111333111", "1111000111",
        "1113000311", "1130000031", "1300000003", "1000000000", "1000000000", "1000000000",
        "1000000000", "1000000000", "1000000000", "1000000000", "1008000151", "1000000109",
        "1000000111", "1000000000", "1555555555", "1000000000", "1000000111", "1000000500",
        "1111111100", "1333333300", "1000000000", "1080000000", "1000000000", "1111100011",
        "1000000000", "1000000000", "1000000000", "1111111111",
    ]),
    8: (-34, [
        "1777777777", "1111111111", "1111111111", "1111111111", "1111111111", "1133333333",
        "0100088800", "0200000800", "0100000000", "0100000000", "0100000000", "0100000000",
        "0100200000", "0100000000", "7155555555", "0100000000", "0144444440", "0111111110",
        "7133333310", "0100000010", "7100000010", "0100010010", "0100010000", "0100010000",
        "7100014444", "0122211111", "0100033333", "0100000000", "0100000000", "0100000000",
        "0100008000", "0100000000", "7100000000", "0111100011", "7100000000", "0100000000",
        "0100000000", "0111111111", "0000111111", "0090111111", "1111111111", "1111111111",
        "1111111111", "1111111111", "1111111111",
    ]),
    9: (-4, [
        "0100000000", "0100000000", "0111111111", "0000111111", "00.0111111", "1111111111",
        "1111111111", "1111111111", "1111111111", "1111111111",
    ]),
}


def _map_int(top, rows):
    v = 0
    for r, s in enumerate(rows):
        for c, ch in enumerate(s):
            if ch != ".":
                v |= (int(ch, 16) + 1) << (4 * (10 * (top + r + _OFF) + c))
    return v


LEVEL_CONST = {lv: {"map": _map_int(*_MAPS[lv]), "tick": (15 if lv <= 5 else 7)} for lv in _MAPS}
