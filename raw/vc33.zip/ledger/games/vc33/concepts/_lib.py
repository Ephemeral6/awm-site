"""这一局的词汇表 —— 每个定义都是假设，不是装置给的事实。

这一局只有 ACTION6（点坐标），写成 "ACTION6:x,y"，x 是列、y 是行；帧是 g[row][col]。

**世界的样子**：
  行 0 是顶栏（HUD），随点击从最右一格起往左染色。
  行 1 以下是 playfield。规范视图 view() 把它摆成「lane × 深度」，深度 0 = 填充起点那一侧。
  playfield 被**隔条**（C_BAND 色）切成若干个**槽**。隔条有两种，它们做的事不一样：
    · **横隔条**：占满若干整道 lane（从深度 0 起画），把 lane 方向切开。按钮贴着它，跨它搬运。
    · **前墙**：占满一段深度、横跨一整片 lane 区，把那一片 lane 沿**深度**方向切成两个槽——
      近侧那个被封顶，墙外那个从更深处起算。
  每个槽是一块矩形 (lane0, lane1, 深度0, 深度1)：从深度0 起，前若干格是「已填」（C_BG0），其余是 C_BG3。
  **槽的值 = 填充前沿的绝对深度**（= 深度0 + 已填格数），不是格数——这样它和标记的深度可以直接比。
  每条横隔条的两侧各有 C_BTN 方块，属于它所在的槽；点它把 STEP 格从隔条另一侧的槽拉进自己这个槽。
  STEP = 横隔条的厚度。
  标记色（既不是背景也不是隔条/按钮/顶栏的颜色）成对出现：一份嵌在某条横隔条里（= 目标深度），
  一份紧贴某个槽的填充前沿（= 光标，深度恒等于该槽的值），两份同色配对。
  过关条件：所有配了对的光标都停在自己那份标记的深度上，且所在的槽贴着嵌那份标记的隔条。

没量出来的留 None。
"""
from __future__ import annotations

N = 64
HUD_ROW = 0
BUDGET = 50                  # 每关点击预算（顶栏取整定律反推）

C_BG0 = 0                    # 槽里「已填」
C_BG3 = 3                    # 槽里「未填」
C_ARROW = 4                  # 箭头 / 顶栏已消耗 / 边框，同一个色号
C_USED = 4
C_BAND = 5                   # 隔条
C_HUD = 7                    # 顶栏未消耗
C_BTN = 9                    # 按钮
STRUCT = (C_BG0, C_BG3, C_ARROW, C_BAND, C_HUD, C_BTN)
FILL = (C_BG0, C_BTN)

CELL = None                  # 这一局的步长按关变，见 step()
PHASE = None
DELTA = {}


def is_mark(v):
    """标记色 = 不在结构色里的任何颜色。"""
    return v not in STRUCT


# ---------- 顶栏 ----------

def hud_used(g):
    n = 0
    for v in g[HUD_ROW]:
        if v == C_USED:
            n += 1
        elif v != C_HUD:
            return None
    return n


def hud_k(g):
    u = hud_used(g)
    if u is None:
        return None
    for k in range(BUDGET + 1):
        if round(N * k / BUDGET) == u:
            return k
    return None


# ---------- 规范视图：把 playfield 摆成「横向、填充从左长」 ----------

def crop(g):
    """playfield 的外接矩形 (r0, r1, c0, c1)：所有 C_BG0/C_BG3 格的 bbox（不含行 0）。"""
    rs, cs = [], []
    for r in range(1, N):
        row = g[r]
        for c in range(N):
            if row[c] == C_BG0 or row[c] == C_BG3:
                rs.append(r)
                cs.append(c)
    if not rs:
        return None
    return (min(rs), max(rs), min(cs), max(cs))


def origin(g):
    """按钮贴着 playfield 的哪条边：'L' / 'R' / 'T' / 'B'；不唯一返回 None。"""
    cr = crop(g)
    if cr is None:
        return None
    r0, r1, c0, c1 = cr
    cells = [(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if g[r][c] == C_BTN]
    if not cells:
        return None
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    hits = []
    if min(cs) == c0:
        hits.append("L")
    if max(cs) == c1:
        hits.append("R")
    if min(rs) == r0:
        hits.append("T")
    if max(rs) == r1:
        hits.append("B")
    return hits[0] if len(hits) == 1 else None


def view(g):
    """返回 (V, put)。V[lane][i]：lane 沿隔条排列的方向，i=0 是填充起点。
    put(lane, i) -> (row, col) 原坐标。读不出来返回 (None, None)。"""
    cr = crop(g)
    o = origin(g)
    if cr is None or o is None:
        return (None, None)
    r0, r1, c0, c1 = cr
    if o in ("L", "R"):
        nlane, ndeep = r1 - r0 + 1, c1 - c0 + 1
        if o == "L":
            def put(l, i):
                return (r0 + l, c0 + i)
        else:
            def put(l, i):
                return (r0 + l, c1 - i)
    else:
        nlane, ndeep = c1 - c0 + 1, r1 - r0 + 1
        if o == "T":
            def put(l, i):
                return (r0 + i, c0 + l)
        else:
            def put(l, i):
                return (r1 - i, c0 + l)
    V = [[g[put(l, i)[0]][put(l, i)[1]] for i in range(ndeep)] for l in range(nlane)]
    return (V, put)


# ---------- 视图上的结构 ----------

def _runs(xs):
    out, cur = [], []
    for x in xs:
        if cur and x == cur[-1] + 1:
            cur.append(x)
        else:
            if cur:
                out.append((cur[0], cur[-1]))
            cur = [x]
    if cur:
        out.append((cur[0], cur[-1]))
    return out


def _is_band_lane(V, l):
    """这一道 lane 整条是横隔条吗——判据只看**填充起点那一格**。

    旧判据是「这道 lane 里出现过隔条色」，那把一堵前墙（占一段深度、横跨一整片 lane）
    误判成「这一片 lane 全是隔条」，于是整片槽被吞掉，而读出来的是一个**看起来正常**的结构：
    槽数变少、上限变小，没有任何东西返回 None。
    横隔条从深度 0 起画，前墙不从深度 0 起画 —— 这是把两者分开的那一格。
    """
    if V[l][0] == C_BAND:
        return True
    return is_mark(V[l][0]) and len(V[l]) > 1 and V[l][1] == C_BAND


def bands(V):
    """横隔条：[(lane0, lane1, 0, 最大深度), …]。前 2 项是 lane 区间，和旧写法同义。"""
    deep = len(V[0]) - 1
    return [(a, b, 0, deep) for a, b in _runs([l for l in range(len(V)) if _is_band_lane(V, l)])]


def _lane_runs(V):
    """不是横隔条的那些 lane 的连续区间。"""
    return _runs([l for l in range(len(V)) if not _is_band_lane(V, l)])


def frontwalls(V, run):
    """这一片 lane 里的前墙：[(深度0, 深度1), …] —— 这一段深度上**每一道** lane 都是隔条色。"""
    l0, l1 = run
    deep = len(V[0])
    hit = [d for d in range(deep) if all(V[l][d] == C_BAND for l in range(l0, l1 + 1))]
    return _runs(hit)


def zones(V):
    """槽：[(lane0, lane1, 深度0, 深度1), …]。前 2 项是 lane 区间，和旧写法同义。

    每一片非隔条 lane 被它自己的前墙沿深度切成若干段，每段是一个独立的槽。
    """
    out = []
    deep = len(V[0])
    for run in _lane_runs(V):
        l0, l1 = run
        walls = frontwalls(V, run)
        cut, d = [], 0
        for w0, w1 in walls:
            if w0 > d:
                cut.append((d, w0 - 1))
            d = w1 + 1
        if d <= deep - 1:
            cut.append((d, deep - 1))
        for d0, d1 in cut:
            out.append((l0, l1, d0, d1))
    return out


def zdepths(z):
    """槽的深度区间（老式两元组默认整条）。"""
    return (z[2], z[3]) if len(z) > 3 else (0, None)


def step(V):
    """STEP = 横隔条的厚度；各条厚度不一致返回 None。"""
    bs = bands(V)
    if not bs:
        return None
    th = {b[1] - b[0] + 1 for b in bs}
    return th.pop() if len(th) == 1 else None


def prefix_len(V, l, colors, d0=0, d1=None):
    """从深度 d0 起连续属于 colors 的格数。"""
    if d1 is None:
        d1 = len(V[l]) - 1
    n = 0
    for d in range(d0, d1 + 1):
        if V[l][d] in colors:
            n += 1
        else:
            break
    return n


def zone_val(V, z):
    """槽 z 的**填充前沿的绝对深度** = 深度0 + 已填格数。

    按钮压在填充上，前沿浅于按钮时那几道 lane 会读高，所以优先只看没有按钮的 lane。
    """
    l0, l1, d0, d1 = z
    lanes = [l for l in range(l0, l1 + 1)
             if all(V[l][d] != C_BTN for d in range(d0, d1 + 1))]
    if not lanes:
        lanes = list(range(l0, l1 + 1))
    vals = {d0 + prefix_len(V, l, FILL, d0, d1) for l in lanes}
    return vals.pop() if len(vals) == 1 else None


def zone_fill(V, z):
    """槽 z 里实际有多少格液体（= 前沿深度 - 起算深度）。读不出来返回 None。"""
    v = zone_val(V, z)
    return None if v is None else v - z[2]


def zone_vals(V):
    out = []
    for z in zones(V):
        v = zone_val(V, z)
        if v is None:
            return None
        out.append((z, v))
    return out


# ---------- 帧 → 定长读数（给形式化的抽象态用；本身不是主张，是读数） ----------

MAX_ZONES = 6                # 定长补位用的上界：语料里槽最多这么多
MAX_PAIRS = 4                # 同上，配对最多这么多


def zone_fronts(g):
    """各槽的填充前沿绝对深度，按槽序排成定长 MAX_ZONES 元组，不足补 -1；读不出来返回 None。

    **这一局的状态变量就是它**。写成「帧 → 定长整数元组」是因为抽象态只收得下定长读数：
    原来抽象态里跟槽有关的只有 `zone_vals_n`（有几个槽），一个液面读数都没有，
    于是液面完全不同的两个局面塌成同一个抽象态——全语料 369 条转移只剩 288 个不同的
    (状态, 动作)，其中 38 组「同一个 (状态, 动作) 却有不同的下一状态」。
    那看着像世界藏了状态，其实是这一份读数里没有液面。补上它之后 369 条各有各的 key，冲突 0 组。
    """
    V, _ = view(g)
    if V is None:
        return None
    zv = zone_vals(V)
    if zv is None or len(zv) > MAX_ZONES:
        return None
    vals = [v for _z, v in sorted(zv)]
    return tuple(vals + [-1] * (MAX_ZONES - len(vals)))


def target_depths(g):
    """配对目标的深度，按标记色排成定长 MAX_PAIRS 元组，不足补 -1；读不出来返回 None。"""
    V, _ = view(g)
    if V is None:
        return None
    tg = targets(V)
    if len(tg) > MAX_PAIRS:
        return None
    return tuple([tg[c] for c in sorted(tg)] + [-1] * (MAX_PAIRS - len(tg)))


def cursor_depths(g):
    """光标的深度，按标记色排成定长 MAX_PAIRS 元组，不足补 -1；读不出来返回 None。"""
    V, _ = view(g)
    if V is None:
        return None
    cu = cursors(V)
    if len(cu) > MAX_PAIRS:
        return None
    return tuple([d for _c, (_z, d) in sorted(cu.items())] + [-1] * (MAX_PAIRS - len(cu)))


def _first_mark(V, lanes, d0=0, d1=None):
    """这几道 lane 上离深度 d0 最近的标记格：返回 (绝对深度, 颜色) 或 None。"""
    best = None
    for l in lanes:
        hi = len(V[l]) - 1 if d1 is None else d1
        for d in range(d0, hi + 1):
            v = V[l][d]
            if is_mark(v):
                if best is None or d < best[0]:
                    best = (d, v)
                break
    return best


def targets(V):
    """{标记色: 目标深度}：嵌在横隔条里、**颜色配得到某个槽里的光标**的那些标记段的起始深度。

    分类判据和 gauges() 是同一条、方向相反：配得到光标的是配对目标，配不到的是量规。
    两个函数都必须看一条隔条里的**每一段**标记，不能只看离原点最近的那一段——
    某一关的隔条里浅处是量规、深处才是目标，只取最近的一段会把目标整段挡住，
    读出来是「这一关没有配对目标」。那不是读不出来，是读出了一个假的。

    同一种标记色出现在两条隔条里时**整种颜色都丢掉**（见 targets_ambiguous）。
    """
    cur = set(cursors(V))
    seen = {}
    for b in bands(V):
        for col, d0, _d1 in band_marks(V, b):
            if col in cur:
                seen.setdefault(col, []).append(d0)
    return {col: offs[0] for col, offs in seen.items() if len(offs) == 1}


def band_targets(V):
    """[(隔条, 标记色, 目标深度), …]：每条隔条里最靠近填充起点的那个标记，一条不漏。"""
    out = []
    for b in bands(V):
        m = _first_mark(V, range(b[0], b[1] + 1))
        if m is not None:
            out.append((b, m[1], m[0]))
    return out


def band_marks(V, b):
    """这条横隔条里嵌的所有标记段：[(色, 起始深度, 结束深度), …]，由浅到深。"""
    lane = V[b[0]]
    out = []
    d = 0
    n = len(lane)
    while d < n:
        if is_mark(lane[d]):
            e = d
            while e + 1 < n and lane[e + 1] == lane[d]:
                e += 1
            out.append((lane[d], d, e))
            d = e + 1
        else:
            d += 1
    return out


def gauges(V):
    """[(隔条, 色, 起始深度, 结束深度), …]：**颜色在任何槽里都配不到光标**的那些标记段。

    隔条里的标记有两类，靠「这个颜色在槽里有没有一个同色光标」分开，不靠厚度：
      · 配得到光标的 —— 那是**配对目标**（见 targets / pairs）；
      · 配不到的 —— 那是**量规**，不属于任何槽的目标。
    """
    cur = set(cursors(V))
    out = []
    for b in bands(V):
        for col, d0, d1 in band_marks(V, b):
            if col not in cur:
                out.append((b, col, d0, d1))
    return out


def bar_zones(V, b, d0=None, d1=None):
    """这条横隔条两侧的槽，按 lane 递增。

    给了深度区间就只留深度上盖得住它的那些槽 —— 一条隔条可以同时贴着好几个槽
    （前墙把一侧切成了两段），而一段量规只跟盖住它那一段深度的槽有关系。
    """
    out = []
    for z in zones(V):
        if not (z[1] + 1 == b[0] or z[0] - 1 == b[1]):
            continue
        if d0 is not None and not (z[2] <= d0 and d1 <= z[3]):
            continue
        out.append(z)
    return out


def gauge_aligned(V, b, d0, d1=None):
    """这条隔条两侧盖住该量规段的槽，液面是不是都正好等于该量规段的起始深度 d0。
    读不出来返回 None。两侧只有一侧有槽（隔条在盘边上）时，只看那一侧。
    """
    adj = bar_zones(V, b, d0, d0 if d1 is None else d1)
    if not adj:
        return None
    for z in adj:
        v = zone_val(V, z)
        if v is None:
            return None
        if v != d0:
            return False
    return True


PIPE_LANE_OUT = 2                # 通道离隔条边缘几道


def pipe_inset(b):
    """通道的深度区间比量规两端各缩几格 = **这条隔条的厚度减一**。

    原来这里写死成 2，那是在只见过一种厚度的隔条时量出来的。见到厚度 2 的隔条之后
    实测两侧各缩 1，全语料 122 次点亮里 106 次缩 2（厚 3）、16 次缩 1（厚 2），没有例外。
    语料里量规段的长度恒等于 4×厚度，所以「厚度减一」和「段长除以四再减一」在这里分不开；
    取厚度是因为厚度是这个世界里本来就有的量（它同时是 STEP），段长不是。
    """
    return b[1] - b[0]


def gauge_pipe_cells(V):
    """量规点亮时会被改写的那些 (lane, 深度)：隔条两侧各距 PIPE_LANE_OUT 道的那一道 lane 上、
    深度区间比量规两端各缩 pipe_inset(b) 格的那一段。

    只给**位置**，不给颜色——颜色是 gauge_lit 的主张，写在那条概念里受计分。
    放这里的唯一理由是**归属**：btn_pull 和 cursor_follows 要靠它把这些格子让出去。
    """
    out = set()
    for b, _col, d0, d1 in gauges(V):
        ins = pipe_inset(b)
        for lane in (b[0] - PIPE_LANE_OUT, b[1] + PIPE_LANE_OUT):
            if not (0 <= lane < len(V)):
                continue
            if not any(z[0] <= lane <= z[1] and z[2] <= d0 and d1 <= z[3] for z in zones(V)):
                continue
            for d in range(d0 + ins, d1 - ins + 1):
                if 0 <= d < len(V[lane]):
                    out.add((lane, d))
    return out


def gauge_hit(g, action):
    """这次点击落在哪个量规段里：返回 (隔条, 色, 起始深度, 结束深度) 或 None。

    只给**位置**（点没点在量规段里），不给「点了会怎样」——那是 gauge_teleport / gauge_swap 的主张。
    """
    p = clicked(action)
    if p is None:
        return None
    V, _ = view(g)
    if V is None:
        return None
    q = to_view(g, *p)
    if q is None:
        return None
    lane, d = q
    for b, col, d0, d1 in gauges(V):
        if b[0] <= lane <= b[1] and d0 <= d <= d1:
            return (b, col, d0, d1)
    return None


def rig_cells(V, z):
    """槽 z 里属于「光标那一套」的格子：{(lane, 深度): 色}。

    一套 = 标记色的那几格（光标本体）+ 紧跟在它后面的 C_ARROW 那几格（把手）。
    判据只用颜色：槽里除了已填/未填/按钮，剩下的就是这一套。
    """
    l0, l1, d0, d1 = z
    out = {}
    for l in range(l0, l1 + 1):
        for d in range(d0, d1 + 1):
            v = V[l][d]
            if is_mark(v) or v == C_ARROW:
                out[(l, d)] = v
    return out


def land_lane(dst, w):
    """一套宽 w 的东西落进槽 dst 时，它最小的那个道号：**两边的中位下标对齐**。

    槽的中位 = 宽 // 2，这一套的中位 = w // 2，落点让这两个中位落在同一道。
    宽是偶数时「中位」取靠后的那一格，两边都这么取——所以它既不是一律向下取整
    也不是一律向上取整，取整方向由 w 的奇偶决定。
    只有一处写这个偏移量（搬运和对调共用），三处各写一份等于没人管它。
    """
    return dst[0] + (dst[1] - dst[0] + 1) // 2 - w // 2


def wall_height(V, b):
    """这条横隔条画到多深：从深 0 往下数，第一个空槽色 C_BG3 之前有多少格。

    隔条不是通到底的。深度超过这个高度之后，那几道 lane 就是空槽色，
    跟两边的槽连成一片 —— 所以它是一堵**有限高的墙**，不是一条分割线。
    """
    l = b[0]
    h = 0
    while h < len(V[l]) and V[l][h] != C_BG3:
        h += 1
    return h


def caps(V):
    """{槽: 容量上限（绝对深度）} = 它自己的深度上界与两侧隔条里最矮那条的高度，取小。"""
    bs = bands(V)
    out = {}
    for z in zones(V):
        lim = [z[3] + 1]
        for b in bs:
            if b[1] + 1 == z[0] or b[0] - 1 == z[1]:
                lim.append(wall_height(V, b))
        out[z] = min(lim)
    return out


def would_cap(g, action):
    """这次点击会不会把得到方顶出上限（顶出去 = 整次点击作废）。读不出来返回 None。"""
    bh = button_hit(g, action)
    if bh is None:
        return None
    gain, _lose = bh
    V, _ = view(g)
    if V is None:
        return None
    st = step(V)
    gv = zone_val(V, gain)
    if st is None or gv is None:
        return None
    return gv + st > caps(V)[gain]


def cursors(V):
    """{标记色: (槽, 光标的绝对深度)}：贴在某个槽填充前沿上的那些标记。

    同一种标记色出现在两个槽里时**整种颜色都丢掉**（后写的会把先写的静默盖掉）。
    """
    seen = {}
    for z in zones(V):
        m = _first_mark(V, range(z[0], z[1] + 1), z[2], z[3])
        if m is not None:
            seen.setdefault(m[1], []).append((z, m[0]))
    return {col: hits[0] for col, hits in seen.items() if len(hits) == 1}


def cursors_ambiguous(V):
    """光标读不干净吗——有没有哪种颜色在两个槽里各贴一份，被 cursors() 整种丢掉。

    **隔条那一侧的重名不算在内**：同一个色在好几条隔条里各嵌一段量规是常态，
    它只影响 targets()（见 targets_ambiguous），不影响「谁是量规」。
    """
    seen = {}
    for z in zones(V):
        m = _first_mark(V, range(z[0], z[1] + 1), z[2], z[3])
        if m is not None:
            seen.setdefault(m[1], 0)
            seen[m[1]] += 1
    return any(n > 1 for n in seen.values())


def targets_ambiguous(V):
    """配对目标读不干净吗——某个光标色在两条隔条里各嵌一段，targets() 会把它整种丢掉。"""
    cur = set(cursors(V))
    seen = {}
    for b in bands(V):
        for col, _d0, _d1 in band_marks(V, b):
            if col in cur:
                seen.setdefault(col, 0)
                seen[col] += 1
    return any(n > 1 for n in seen.values())


def pairs(V):
    """[(槽, 现在的前沿深度, 目标深度), …]：按标记色把光标和目标配起来；配不上的丢掉。"""
    tg, cu = targets(V), cursors(V)
    out = []
    for col, (z, _off) in sorted(cu.items()):
        if col in tg:
            v = zone_val(V, z)
            if v is None:
                return None
            out.append((z, v, tg[col]))
    return out


def solved(V):
    """所有配了对的槽都到位了吗？配不出对返回 None。"""
    ps = pairs(V)
    if not ps:
        return None
    return all(v == t for _, v, t in ps)


# ---------- 按钮 ----------

def _blocks(cells):
    cells = set(cells)
    out = []
    while cells:
        seed = cells.pop()
        comp, stack = {seed}, [seed]
        while stack:
            a, b = stack.pop()
            for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                p = (a + d[0], b + d[1])
                if p in cells:
                    cells.discard(p)
                    comp.add(p)
                    stack.append(p)
        out.append(comp)
    return out


def buttons(V):
    """[(槽, 隔条, 按钮的格子集合), …]。槽按 lane **和深度**双向认领。"""
    cells = {(l, i) for l in range(len(V)) for i in range(len(V[l])) if V[l][i] == C_BTN}
    out = []
    zs, bs = zones(V), bands(V)
    for blk in _blocks(cells):
        ls = sorted({l for l, _ in blk})
        ds = sorted({d for _, d in blk})
        z = next((w for w in zs
                  if w[0] <= ls[0] and ls[-1] <= w[1] and w[2] <= ds[0] and ds[-1] <= w[3]), None)
        if z is None:
            continue
        cands = [b for b in bs if b[1] + 1 == z[0] or b[0] - 1 == z[1]]
        if not cands:
            out.append((z, None, blk))
            continue

        def _gap(b, ls=ls):
            return b[0] - ls[-1] if b[0] > ls[-1] else ls[0] - b[1]
        out.append((z, min(cands, key=_gap), blk))
    return out


def clicked(action):
    """"ACTION6:x,y" -> (x, y) = (列, 行)；不是 ACTION6 返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except Exception:                                        # noqa: BLE001
        return None
    return (x, y)


def to_view(g, x, y):
    """原坐标 (列 x, 行 y) -> 视图坐标 (lane, i)；不在 playfield 里返回 None。"""
    cr, o = crop(g), origin(g)
    if cr is None or o is None:
        return None
    r0, r1, c0, c1 = cr
    if not (r0 <= y <= r1 and c0 <= x <= c1):
        return None
    if o == "L":
        return (y - r0, x - c0)
    if o == "R":
        return (y - r0, c1 - x)
    if o == "T":
        return (x - c0, y - r0)
    return (x - c0, r1 - y)


def button_hit(g, action):
    """这次点击落在哪个按钮上：返回 (得到 STEP 格的槽, 失去 STEP 格的槽) 或 None。

    对岸那个槽要**深度上盖得住这个按钮**：一条隔条的另一侧可能被前墙切成好几个槽，
    只有和按钮同一段深度的那个才是它的对家。
    """
    p = clicked(action)
    if p is None:
        return None
    x, y = p
    if not (0 <= y < N and 0 <= x < N) or g[y][x] != C_BTN:
        return None
    V, _ = view(g)
    if V is None:
        return None
    q = to_view(g, x, y)
    if q is None:
        return None
    for z, bd, blk in buttons(V):
        if q in blk:
            if bd is None:
                return None
            ds = sorted({d for _, d in blk})
            other = [w for w in zones(V)
                     if w != z and (w[1] + 1 == bd[0] or w[0] - 1 == bd[1])
                     and w[2] <= ds[0] and ds[-1] <= w[3]]
            if len(other) != 1:
                return None
            return (z, other[0])
    return None


def next_zone_vals(g, action):
    """按 btn_pull 的定律，这一次点击之后各槽的前沿深度。读不出来返回 None。"""
    V, _ = view(g)
    if V is None:
        return None
    zv = zone_vals(V)
    st = step(V)
    if zv is None or st is None:
        return None
    out = dict(zv)
    bh = button_hit(g, action)
    if bh is None:
        return out
    gain, lose = bh
    if out.get(lose) is None or out[lose] - lose[2] < st or gain not in out:
        return None
    out[gain] += st
    out[lose] -= st
    return out


def target_bar(V, col):
    """嵌着色 col 那份配对标记的隔条；不唯一就是 None（读不出来）。"""
    hits = [b for b in bands(V) for c, _d0, _d1 in band_marks(V, b) if c == col]
    return hits[0] if len(hits) == 1 else None


def will_win(g, action):
    """按 win_align 的定律：这一次点击之后，每个配了对的光标是不是既到了自己那份标记的深度、
    又待在贴着嵌那份标记的隔条的槽里（= 该换关）。读不出来返回 None。
    各条概念的 apply 用它来对换关那一帧闭嘴。

    **只留一份实现**：win_align 的 assert_ 和 apply 那一侧的「事前闭嘴」共用这一段。
    分开写过一次，代价是 win_align 已经改掉的旧判据（只比槽值、不问贴不贴着）
    继续留在这里，而这里不受计分——于是有一步明明只是普通的按钮搬运，
    apply 全体误以为「这一步要过关」而集体闭嘴，整册只说出 156 格，
    链式预测从那一步起偏掉 104 格。断言那一侧早就修好了，生成那一侧没人告诉它。
    """
    V, _ = view(g)
    if V is None or targets_ambiguous(V):
        return None
    czone = {c: z for c, (z, _off) in cursors(V).items()}
    tgt = targets(V)
    nv = next_zone_vals(g, action)
    if nv is None:
        return None
    ps = [(c, czone[c], t) for c, t in tgt.items() if c in czone]
    if not ps:
        return None
    for c, z, t in ps:
        b = target_bar(V, c)
        if b is None:
            return None
        if nv.get(z) != t or z not in bar_zones(V, b):
            return False
    return True


def me(g):
    """这一局没有会自己走的玩家。"""
    return None


def walls(g):
    return None
