"""顶栏永远是「从最右一格起连续 u 格 C_USED、其余全 C_HUD」这个形状；每次 ACTION6 让 u 增加 0、1 或 2 格，绝不减少；**开出新一关**时整行复位为 u=0，而通关（state=WIN）那一步不复位、就地接着涨。"""
LEVEL = "L4"
SCOPE = ("只看 ACTION6；顶栏行出现 C_HUD/C_USED 之外的颜色、或不是「右起一段」这个形状时返回 NA。"
         "换关那一步只断言「复位为 u=0」，**但通关那一步除外**（那一步按普通增量断言）。"
         "**不断言 u 与本关点击数的换算尺度**——那个尺度按关而变，单帧上读不出来（见 NOTE）。"
         "apply 因此只填单调必然的那一半：右起 0..u-1 必是 C_USED；u 及其左边一概不主张。")
NOTE = ("v7：「换关就复位」在**最后一关通关**那一步被打掉。装置在那一步照样报 level_prev != level_next"
        "（关号从 6 变成 7 = 已过关数），但盘面没换、顶栏也没复位，u 从 15 涨到 16。"
        "教训：**「关号变了」和「开出了新一关」是两件事**，只有前者写在 ctx 里，"
        "而复位是后者的性质。整整六关里这两件事一直重合，所以这个混淆一次都没露馅——"
        "它只能死在最后一关的最后一步，也就是这条概念本来最该说对的地方。"
        "同类的判据都要问一句：我用的这个信号，是不是只是我真正想说的那件事的一个相关物？"
        "v5：v3/v4 断言「u = round(64*k/50)，k 是本关已点次数」，在前两关 20 条转移上一条没错，"
        "第 3 关上被 378b76f0a7ff582e、a2a2f5b9420b2912 打掉——那一关的 u 序列是 1,2,3,3,4,5，"
        "拟合出的分母在 74~76 之间，不是 50。所以预算是**按关给的**，而单帧上没有任何东西说得出它是几："
        "u 一个读数反推不出 k（增量可以是 0），k 也没写在盘上。"
        "留下来的是形状（右起连续段）、单调（只增不减）、复位（换关归零）和增量上界 2。"
        "增量上界 2 是从两关的实测里量的：分母 50 时 round(1.28k) 的增量在 1 和 2 之间跳，"
        "分母 75 时在 0 和 1 之间跳；哪天出现一次 +3，这条就该再改。")
EVIDENCE = ["c5836c5219fa264c", "c17cfa06708643f6", "378b76f0a7ff582e", "a2a2f5b9420b2912",
            "17936d317a552171"]      # 通关那一步：关号变了但顶栏没复位（v6 死在这里）

from _lib import C_HUD, C_USED, HUD_ROW, N, clicked, hud_used, will_win

MAX_JUMP = 2


def _shape_ok(g):
    """顶栏是不是「右起连续 u 格 C_USED」这个形状；是就返回 u，不是返回 None。"""
    u = hud_used(g)
    if u is None:
        return None
    for i in range(N):
        if g[HUD_ROW][N - 1 - i] != (C_USED if i < u else C_HUD):
            return None
    return u


def assert_(prev, action, nxt, ctx=None):
    if clicked(action) is None:
        return "NA"
    a = _shape_ok(prev)
    if a is None:
        return "NA"
    b = _shape_ok(nxt)
    if b is None:
        return "FALSE"                                # 形状本身就是主张的一部分
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        if ctx.get("state_next") == "WIN":
            # 通关那一步装置照样报「换了一关」，但**没有下一关可以复位**：
            # 顶栏就地接着涨，和普通一步一样。复位是「新一关开张」的事，不是「关号变了」的事。
            return "TRUE" if a <= b <= a + MAX_JUMP else "FALSE"
        return "TRUE" if b == 0 else "FALSE"
    return "TRUE" if a <= b <= a + MAX_JUMP else "FALSE"


def apply(prev, action, ctx=None):
    if clicked(action) is None:
        return None
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None                                   # 换关时复位，不逐格主张
    if will_win(prev, action):
        return None                                   # 册子自己预言这一步换关 —— 事前也闭嘴
    u = _shape_ok(prev)
    if u is None:
        return None
    # 只填单调必然的那一半：右起 0..u-1 已经染过，u 只增不减，所以它们此后永远是 C_USED。
    # 右起 u 以外的格子一概不主张 —— 逐格预测会把模型自己生成的帧再喂回来（一批多步时），
    # 那份帧里的 u 只会滞后于真实的 u，据它断言「这些还是 C_HUD」就会一步错一格地累积。
    # 这半边本来也不涨 E：顶栏每步只变 0~2 格，剩下六十来格是不变格。
    return {(HUD_ROW, N - 1 - i): C_USED for i in range(u)} or None
