"""点在色9 按钮上、而隔条另一侧那个槽的值 < STEP 时：这次点击搬不动任何东西，除了行 0 的顶栏整帧一格不动。"""
LEVEL = "L2"
SCOPE = ("只看落在 C_BTN 格上的 ACTION6；换关那一步返回 NA；朝向/槽值/STEP 读不出来返回 NA；"
         "**失去方那个槽的值 >= STEP 时返回 NA**（那归 btn_pull）。"
         "这条概念管的正好是 btn_pull 明写在 scope 里的那个洞。")
NOTE = ("v1：btn_pull 从 v1 起就把「不够搬」写成 scope 外的洞（「另立概念」），而规划器一直主动绕开它，"
        "所以这个洞在前 61 步一次都没被走进去过——不是没主张，是连数据都没有。"
        "第 62~64 步是专门走进去取证的：局面 [18,0,33,0,0]，点槽1 的按钮（隔条对面的槽2 是空的），"
        "赌的是「拉穿」——按钮改从这个方向上最近的非空槽（槽3，33 格）拉，那样就能过唯一一条两侧都没按钮的隔条2。"
        "三步的实际帧差都是 1~2 格，全在顶栏：**源槽空了，点击就是白费一次预算**，拉穿被证伪。"
        "这条概念的价值不在它多聪明，在于它把「白费」变成了可判错的东西："
        "哪天有一次点击在源槽为空时改动了 playfield，它当场关闸。"
        "v2：「源槽的值」现在是**绝对深度**（槽被一堵与填充方向垂直的墙切开之后，有的槽从更深处起算），"
        "能搬走的是 值 − 起算深度。不改这一处，一个刚好空掉、但起算深度大于 STEP 的槽会被读成「搬得动」，"
        "这条概念在它最该开口的地方闭嘴，而 btn_pull 会替它说错。")
EVIDENCE = ["b83db3728dbbed59", "25b3851d7df61ea8", "d72b339e4fdae5b7"]

from _lib import N, button_hit, step, view, zone_val


def _starved(prev, action):
    """这次点击是不是「点在按钮上但源槽不够搬」：是就返回 True，不是返回 False，读不出来返回 None。"""
    bh = button_hit(prev, action)
    if bh is None:
        return None
    _gain, lose = bh
    V, _ = view(prev)
    if V is None:
        return None
    st = step(V)
    lv = zone_val(V, lose)
    if st is None or lv is None:
        return None
    return lv - lose[2] < st


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    s = _starved(prev, action)
    if s is not True:
        return "NA"
    for r in range(1, N):
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if _starved(prev, action) is not True:
        return None
    return {(r, c): prev[r][c] for r in range(1, N) for c in range(N)}
