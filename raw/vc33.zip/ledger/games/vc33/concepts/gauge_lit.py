"""量规段整段是「亮色」当且仅当它两侧槽的液面都等于该段起始深度；亮着的时候，隔条两侧各距 2 道的那一道 lane 上、深度比量规两端各缩（隔条厚度−1）的那一段是填充色，哪怕液面根本没到那么深。"""
LEVEL = "L7"
SCOPE = ("看的是 nxt 这一帧本身，跟动作无关（不变量）。换关那一步返回 NA；"
         "朝向/槽/槽值读不出来返回 NA；这一关没有量规段时返回 NA（前三关都是这样）。"
         "那两道 lane 落在槽外（隔条太靠盘边）时返回 NA。"
         "**apply 只对 ACTION6 开口**：RESET 一类动作没有前向定律，apply 返回 None（assert_ 照旧管它，"
         "因为 assert_ 只看 nxt 那一帧）。"
         "**apply 还有一道事前闸**：这一次点击之后该换关（`_lib.will_win` 判 True）时返回 None——"
         "换关那一帧整盘重画，本概念的定律说的是同一关内部的事。"
         "不亮的时候那 8 格按普通填充规则走（深度 < 槽值就是填充色），**本概念不主张它们一定是空的**——"
         "液面高过那一段时它们本来就该是填充色。")
NOTE = ("v5：apply 补上「这一步之后该换关就闭嘴」的**事前**闸。原来只有事后那道"
        "（`ctx.level_prev != ctx.level_next`），而事后信息在逐格预测和终局卡上根本拿不到——"
        "那两处的 ctx 一律按「不换关」给。于是过关那一帧本概念照旧逐格开口，"
        "语料里 5 条带量规的换关转移上分别说错 90/104、130/156、84/104 格。"
        "**两套检验都看不见它**：结算的「说错格数」按真实 ctx 走，换关那几步被事后闸挡在计分外；"
        "链式自我推演按关切段，换关那一步从来不进段。要专门拿换关转移 + 预测用的 ctx 跑一遍才现形。"
        "教训：一条概念有「事后闸」不等于有「事前闸」，而生成器只吃得到事前的信息。"
        "v1：把 gauge_signal 只敢说的「变没变」升级成「是什么」。之所以能升级，是因为已经见过亮色本身："
        "色1 熄、色12 亮，八条转移（点亮 4 次、熄灭 4 次）互相印证。"
        "两个**色号**写在本概念里而不是写进 _lib：改 _lib 不算改版、不重新计分，"
        "写进去等于把两个从帧上量不出来的常数永久藏在计分之外。写在这里它们每一步都被检验。"
        "通道的两个**偏移量**是例外，它们在 _lib.gauge_pipe_cells 里——因为 btn_pull 和 cursor_follows "
        "要靠同一个函数把这 16 格让出去（谁都画就是谁都不负责，会在终局卡上打成冲突）；"
        "偏移量错了，本概念在点亮的转移上照样判 FALSE，所以它是间接受检不是没受检。"
        "**这条概念存在的直接理由是终局卡**：点亮这件事没有任何概念**生成**得出来，"
        "于是模型自己往前推演的帧从点亮那一步开始就少 36 格量规 + 16 格通道 = 52 格，"
        "一直错到熄灭那一步才自愈——结算里表现为连续六步「预测 4032 格、对 3980 格」，"
        "而这六步的 assert_ 全判 TRUE、帧差只有 1 格。**判 TRUE 不等于画得出来**，"
        "终局卡上差一格就停批，所以会判不会画的地方必须补上生成器。"
        "保留 gauge_signal 不撤：它是更弱的那条（只说变没变），本概念垮了它还站得住，"
        "两条对同一格给不同颜色时结算会报冲突。"
        "**入册当批就说错 19 格，全在 RESET 那一步**：apply 用 next_zone_vals 算「这一步之后的槽值」，"
        "而那个函数在认不出按钮时**原样返回当前槽值**——对空点是对的，对 RESET 是彻底错的"
        "（整盘重排，五个槽的值全变）。于是我拿 RESET 前的液面去判对齐，把量规和通道画在了旧位置上。"
        "教训：一个「读不出来就返回原样」的前向函数，对**换掉整张盘**的动作会静默给出错答案，"
        "而它的返回值类型完全正常。所以 apply 先问「这个动作我认不认识」，再问「算不算得出来」。"
        "v3：五条反例，全在同一关——那一关的一片 lane 被一堵**与填充方向垂直**的墙沿深度切成了两个槽，"
        "于是「这道 lane 属于哪个槽」这句话不再有唯一答案。本概念原来用 `z[0] <= lane <= z[1]` 取槽，"
        "取到的是深度上根本盖不住那段通道的那一个，拿它的液面去判通道该是什么色，判出来的是别人的答案。"
        "隔条两侧的 adj 也一样：不按深度筛，一条隔条会同时贴上三个槽，「两侧都对齐」就永远凑不齐。"
        "教训：**槽从一维区间变成二维矩形的那一刻，所有「按 lane 找槽」的写法一起失效，而它们不会报错**——"
        "它们照旧返回一个合法的槽。凡是拿位置去索引结构的地方，位置有几维就得筛几维。"
        "v4：通道的深度缩进原来写死成 2，那是在只见过一种厚度的隔条时量出来的；"
        "遇到厚度 2 的隔条实测是缩 1，改成 `_lib.pipe_inset(b) = 隔条厚度 − 1`。"
        "**这个错三次都躲过了 assert_**：缩多了只是**少看**两格，本概念判 TRUE，"
        "而 btn_pull / cursor_follows 把这少看的两格当成普通液体去画，"
        "于是错的是它们的 apply，报出来的是它们的「说错格数」，本概念一身干净。"
        "教训：一个「我管哪几格」的常数写小了，惩罚不落在写它的人头上，落在把剩下那几格接过去的人头上。")
EVIDENCE = ["ddcefdf942239947", "6d51ae3ccff9eda6",
            "cc9dd4c697620908", "fe6cd777d3f20895", "f84d752057ac4737",
            "81c6f59474730132", "127f1b34fe87af05", "b86b5e9e9f6eb3a5",
            "97cc4cc35c67ff88", "4f7560ca8b880f73",
            "8c26eedbdf957496", "5d4f7ada8b7280df"]   # v3 在这两条上少认领了通道两端各一格

from _lib import (C_BG0, C_BG3, PIPE_LANE_OUT, bar_zones, clicked,
                  gauge_aligned, gauges, pipe_inset, view, will_win, zone_val, zones)

C_GAUGE_OFF = 1                  # 量规不亮时的色号
C_GAUGE_ON = 12                  # 量规亮时的色号


def _pipes(V, b, d0, d1):
    """点亮时该画通道的那些 (lane, 深度)；lane 落在槽外返回 None。

    取槽要**同时**按 lane 和深度筛：一片 lane 可能被前墙沿深度切成好几个槽。
    """
    zs = zones(V)
    ins = pipe_inset(b)
    out = []
    for lane in (b[0] - PIPE_LANE_OUT, b[1] + PIPE_LANE_OUT):
        if not (0 <= lane < len(V)):
            return None
        z = next((z for z in zs
                  if z[0] <= lane <= z[1] and z[2] <= d0 and d1 <= z[3]), None)
        if z is None:
            return None
        for d in range(d0 + ins, d1 - ins + 1):
            if not (0 <= d < len(V[lane])):
                return None
            out.append((lane, d, z))
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    V, _ = view(nxt)
    if V is None:
        return "NA"
    gs = gauges(V)
    if not gs:
        return "NA"
    for b, col, d0, d1 in gs:
        a = gauge_aligned(V, b, d0, d1)
        if a is None:
            return "NA"
        want = C_GAUGE_ON if a else C_GAUGE_OFF
        for l in range(b[0], b[1] + 1):
            for d in range(d0, d1 + 1):
                if V[l][d] != want:
                    return "FALSE"
        ps = _pipes(V, b, d0, d1)
        if ps is None:
            return "NA"
        for lane, d, z in ps:
            v = zone_val(V, z)
            if v is None:
                return "NA"
            expect = C_BG0 if (a or d < v) else C_BG3
            if V[lane][d] != expect:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """事前生成：拿这一步之后的槽值算对齐，再把量规段和通道画出来。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if clicked(action) is None:
        return None                  # RESET 一类动作：next_zone_vals 没有定律可依，见 NOTE
    if will_win(prev, action) is True:
        return None                  # 事前闸：这一步之后整盘换掉，本概念不主张那一帧
    from _lib import next_zone_vals
    V, put = view(prev)
    if V is None:
        return None
    gs = gauges(V)
    if not gs:
        return None
    nv = next_zone_vals(prev, action)
    if nv is None:
        return None
    out = {}
    for b, _col, d0, d1 in gs:
        adj = bar_zones(V, b, d0, d1)
        if not adj or any(nv.get(z) is None for z in adj):
            return None
        a = all(nv[z] == d0 for z in adj)
        want = C_GAUGE_ON if a else C_GAUGE_OFF
        for l in range(b[0], b[1] + 1):
            for d in range(d0, d1 + 1):
                out[put(l, d)] = want
        ps = _pipes(V, b, d0, d1)
        if ps is None:
            return None
        for lane, d, z in ps:
            v = nv.get(z)
            if v is None:
                return None
            out[put(lane, d)] = C_BG0 if (a or d < v) else C_BG3
    return out or None
