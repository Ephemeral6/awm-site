"""每个槽的填充值都不超过它两侧隔条里最矮那条的高度：槽装不过它旁边最矮的那堵墙。"""
LEVEL = "L2"
SCOPE = ("看的是 nxt 这一帧本身，跟动作无关（不变量）。换关那一步返回 NA；"
         "朝向/槽/槽值读不出来返回 NA；**只有一个槽时返回 NA**——没有「两侧的隔条」，"
         "唯一的槽值可以超过隔条墙高（第 5 关 18 > 3），那不是液面被墙拦住，另一种机制。"
         "两侧都没隔条的槽（盘子边上那种）按整个深度算，等于不设限。"
         "不写 apply：这是不变量，逐格生成归 btn_pull / btn_capped。")
NOTE = ("v1→v2：加「单槽关卡返回 NA」闸。第 5 关只有一个槽，值 18 超过容量 3，"
        "而它不是在「装液体的槽」，值是另一套机制的读数，v1 在那一条转移上挨打。"
        "v1：隔条色不是通到底的——每条隔条画到某个深度就换成空槽色，再往下那几道 lane 跟两边连成一片。"
        "前三关从没有哪个槽装到那么高，所以隔条一直被当成一条通到底的分割线；"
        "第 3 关把 33 格往一个上限 30 的槽里倒，第 11 下空转，才把「墙有高度」逼出来。"
        "量出来的墙高：第 0 关 44；第 1 关 56/44；第 2 关 20/6/22/28；第 3 关 33/42/39/30。"
        "第 2 关那条高 6 的墙把两个槽的上限都压到 6，而那一关是通了的——说明上限是真参与设计的量，"
        "不是我从一条转移上凑出来的。全部 150 帧次零违例。")
EVIDENCE = ["2c891272c598af11", "81c6f59474730132"]

from _lib import caps, view, zone_vals


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    V, _ = view(nxt)
    if V is None:
        return "NA"
    vs = zone_vals(V)
    if vs is None:
        return "NA"
    if len(vs) < 2:
        return "NA"
    cp = caps(V)
    for z, v in vs:
        if v > cp[z]:
            return "FALSE"
    return "TRUE"
