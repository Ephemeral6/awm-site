"""同一关之内，所有槽的填充值之和恒定不变：一次点击只在槽之间搬运，不凭空生成也不销毁。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6；换关那一步返回 NA（整盘换掉，两边的槽不是同一批）；"
         "前后两帧的朝向/槽结构读不出来、或槽的条数变了、或只有一个槽，返回 NA。"
         "单槽时「槽之间搬运」没有意义——总和变化 = 凭空生成，"
         "而单槽关卡（第 5 关）观察到点击确实增加了唯一那个槽的值。"
         "不写 apply：这是不变量，逐格生成由 btn_pull / cursor_follows 负责。")
NOTE = ("v1→v2：加「单槽返回 NA」闸。第 5 关只有一个槽、没有光标、不存在「槽之间搬运」，"
        "点击一次槽值 +3，守恒律不适用。v1 在那一条转移上挨打。"
        "v1：立它是因为规划器在用它——「没配对的那些槽该到几」是靠「总量 - 已配对目标之和」定死的。"
        "这条守恒律本来只活在规划器代码里，等于一条从没走过闸的世界事实；写成概念才会被每一条转移复核。")
EVIDENCE = ["929fb8538dfac04c", "dd47bbf667b158ad",
            "81c6f59474730132"]        # 单槽关卡，点击让唯一那个槽值增加 3（v1 FALSE）

from _lib import clicked, view, zone_vals


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if clicked(action) is None:
        return "NA"
    Vp, _ = view(prev)
    Vn, _ = view(nxt)
    if Vp is None or Vn is None:
        return "NA"
    a, b = zone_vals(Vp), zone_vals(Vn)
    if a is None or b is None or len(a) != len(b):
        return "NA"
    if len(a) < 2:
        return "NA"
    return "TRUE" if sum(v for _z, v in a) == sum(v for _z, v in b) else "FALSE"
