"""隔条的形状、隔条里那些配对目标标记、以及 playfield 外面那一圈边框，任何一次点击后都一格不动——会动的只有行 0 的顶栏、各个槽的内部、和隔条里的量规段。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6；换关那一步返回 NA；朝向/playfield 读不出来返回 NA；"
         "**只有一个槽的关卡返回 NA**——那类关卡没有「槽之间」的搬运与配对，"
         "隔条不是分割槽的分界线（整盘只有一条隔条、一条边），它的形状会随点击生长，"
         "本概念断言的「隔条形状不动」在那种关卡上不成立。"
         "「槽的内部」= 规范视图里每个槽**那一块矩形**（lane 区间 × 深度区间），其余"
         "（隔条 lane、槽与槽之间那堵与填充方向垂直的墙、playfield 之外的行 1 以下）归本概念，"
         "**但隔条里的量规段（gauges，配不到同色光标的那些标记段）除外**——它会变色，归 gauge_signal。")
NOTE = ("v5：「槽的内部」从「这些 lane 的整条深度」收成「这一块矩形」。槽变成矩形之后，"
        "一片 lane 上可能有两个槽，中间夹着一堵与填充方向垂直的墙；按 lane 整条让出去，"
        "等于把那堵墙也让了出去，而它谁都不归——本概念不认领，btn_pull 的画笔也停在自己那块矩形里，"
        "那几十格成了纯残差。**让出去的那一片没人接，就不是分工，是漏**。"
        "v2→v3：加「单槽关卡返回 NA」闸。当时读出来只有一个槽（zones 长度 1），"
        "隔条形状点击后就变了（墙长高、标记图案上移），本概念在那一条转移上挨打。"
        "**后来发现那个「单槽」是词汇读错的产物**：把整条含隔条色的 lane 判成隔条，"
        "一堵横在中间的墙就把一大片槽吞了。闸留着，但它当初挡的不是一种关卡，是一次误读。"
        "v1：写它是为了把帧上没人认领的那一大片（边框与隔条）收进模型，让规则图完成度 E 有机会接近 1。"
        "v2：把量规段让出去。原来的主张是「隔条里嵌的那份标记一格不动」，在 75 条转移上判 TRUE，"
        "第 78 / 79 / 86 / 87 四步一起打脸：两侧槽液面同时落到量规段起始深度时那一整段换色。"
        "**「一直没变」和「不会变」差着一个反例**——这一片之所以几十步都没露馅，是因为那个局面很难做出来："
        "两侧液面同时等于一个特定深度，在守恒量不配合的关卡里根本凑不出。"
        "让出去而不是缩成「除了色号以外不动」：变色本身是一条有内容的规律，该有自己的文件，"
        "塞进本概念的 scope 里等于把一条主张藏成一个例外。")
EVIDENCE = ["dd47bbf667b158ad", "929fb8538dfac04c",
            "ddcefdf942239947", "a5eed45206fad5eb",
            "6d51ae3ccff9eda6", "542589050be2b131",
            "81c6f59474730132"]        # 单槽关卡，隔条形状随点击生长（v2 FALSE）

from _lib import N, bands, clicked, gauges, view, will_win, zones


def _static_cells(prev):
    """返回本概念主张「不动」的那些原坐标。"""
    V, put = view(prev)
    if V is None:
        return None
    if len(zones(V)) < 2:
        return None                       # 单槽关卡：隔条不是分割槽的分界线，形状会随点击生长
    deep = len(V[0])                       # noqa: F841  （留着当读数：这一关有多深）
    inside = set()
    for z in zones(V):
        for l in range(z[0], z[1] + 1):
            for i in range(z[2], z[3] + 1):    # 只让出这一块矩形；矩形之间的墙归本概念
                inside.add(put(l, i))
    for b, _col, d0, d1 in gauges(V):
        for l in range(b[0], b[1] + 1):
            for d in range(d0, d1 + 1):
                inside.add(put(l, d))          # 量规段让给 gauge_signal
    out = [(r, c) for r in range(1, N) for c in range(N) if (r, c) not in inside]
    # 顺手确认隔条确实被算进来了；一条隔条都没有说明这一关不长这样
    if not bands(V):
        return None
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if clicked(action) is None:
        return "NA"
    cells = _static_cells(prev)
    if cells is None:
        return "NA"
    for r, c in cells:
        if prev[r][c] != nxt[r][c]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if clicked(action) is None or will_win(prev, action):
        return None
    cells = _static_cells(prev)
    if cells is None:
        return None
    return {(r, c): prev[r][c] for r, c in cells} or None
