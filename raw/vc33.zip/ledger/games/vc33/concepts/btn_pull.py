"""点在色9 按钮上：按钮所在那个槽的填充值加 STEP，隔条另一侧那个槽减 STEP，其余槽一格不变；STEP = 隔条的厚度。"""
LEVEL = "L1"
SCOPE = ("只看落在 C_BTN 格上的 ACTION6；换关那一步返回 NA；朝向/槽值/STEP 读不出来返回 NA；"
         "失去方那个槽的值 < STEP 时返回 NA（不够搬的情形归 btn_starved）；"
         "**得到方那个槽加了 STEP 之后会超过它的容量上限时返回 NA**（顶出上限的情形归 btn_capped）。"
         "apply 不碰**被这次点击改动、且带光标**的那些槽——它们交给 cursor_follows；"
         "apply 也不碰隔条与 playfield 外面那一圈——交给 frame_static。")
NOTE = ("v3：第 2 关同一套规则换成竖直朝向，步长也从 4 变成 2。词汇改成规范视图 view()，"
        "常数 CELL 换成从帧上量出来的 step()＝隔条厚度；apply 改成「填充前沿以上整体平移 d 格」，"
        "不再假定光标只有一个、也不再假定槽上方只有背景。"
        "v5：2c891272c598af11 打掉了 v4——那一步点了按钮、源槽也够搬（3 格，STEP 也是 3），"
        "实际却整帧只有顶栏变。原因是得到方已经到顶：隔条色不是通到底的，"
        "隔条4 只画到深 29，而得到方那个槽当时正好 30。**槽装不过它两侧最矮那条墙**，"
        "顶出去的那次点击整个作废（预算照扣）。这条上限律在全部 150 帧次上零违例、"
        "在全部 4 次「点了按钮却只动顶栏」上和 btn_starved 二选一地解释干净，另立 tank_cap / btn_capped。"
        "教训：一直把隔条当成通到底的分割线，是因为槽从来没装到那么高过；"
        "「墙有高度」这件事写在每一帧上，只是没人去量。"
        "v6：apply 把通道那 16 格让给 gauge_lit —— 既不认领它们，也不把它们当成平移的源。"
        "起因是量规点亮的四步上本概念说错 96 格，全落在通道的 lane 上：它把一张**装置贴图**"
        "当成了槽里随前沿刚性平移的图案。两边都要改：认领了会和 gauge_lit 打成冲突，"
        "读它当源会把填充色搬到不该填的深度。归属靠 _lib.gauge_pipe_cells 一个函数定，"
        "三处各写一份偏移量才是真的没人管。"
        "v7：槽从「一片 lane」变成「一块矩形」之后改两处。一是「够不够搬」：槽的值现在是**绝对深度**，"
        "而能搬走的只有 值 − 起算深度，拿绝对值去比 STEP，会把一个空槽说成搬得动。"
        "二是 apply 的画笔：原来按 lane 画满整条深度，于是它越过前墙，把墙外那个槽连同墙本身一起重画了"
        "——2560 格说错，而 assert_ 全程判 TRUE，因为断言只看槽值。"
        "又一次「检查器看不见生成器画了什么」，这次的由来不是抄漏了闸，是**词汇的语义在脚底下换了**："
        "同一行 `for i in range(deep)` 在旧词汇下正好是这个槽，在新词汇下是三个槽。")
EVIDENCE = ["929fb8538dfac04c", "dd47bbf667b158ad", "2c891272c598af11"]

from _lib import (C_BG0, C_BG3, C_BTN, button_hit, cursors, gauge_pipe_cells,
                  step, view, will_win, would_cap, zone_val, zone_vals, zones)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    bh = button_hit(prev, action)
    if bh is None:
        return "NA"
    gain, lose = bh
    Vp, _ = view(prev)
    Vn, _ = view(nxt)
    if Vp is None or Vn is None:
        return "NA"
    st = step(Vp)
    a, b = zone_vals(Vp), zone_vals(Vn)
    if st is None or a is None or b is None:
        return "NA"
    pa, pb = dict(a), dict(b)
    if set(pa) != set(pb):
        return "NA"
    if pa.get(lose) is None or pa[lose] - lose[2] < st:
        return "NA"
    if would_cap(prev, action) is not False:
        return "NA"                                   # 得到方会顶出上限（或读不出来）—— 归 btn_capped
    for z, v in pa.items():
        want = v + st if z == gain else (v - st if z == lose else v)
        if pb.get(z) != want:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None                                   # 换关那一帧整张换掉，本概念不主张
    if will_win(prev, action):
        return None                                   # 册子自己预言这一步换关 —— 事前也闭嘴，不只事后
    bh = button_hit(prev, action)
    if bh is None:
        return None
    gain, lose = bh
    V, put = view(prev)
    if V is None:
        return None
    st = step(V)
    if st is None:
        return None
    lv0 = zone_val(V, lose)
    if lv0 is None or lv0 - lose[2] < st:
        return None                                   # 源槽不够搬 —— 交给 btn_starved
    if would_cap(prev, action) is not False:
        return None                                   # 得到方顶出上限 —— 交给 btn_capped
    marked = {z for z, _ in cursors(V).values()}
    pipe = gauge_pipe_cells(V)
    out = {}
    for z in zones(V):
        d = st if z == gain else (-st if z == lose else 0)
        if d and z in marked:
            continue                                  # 带光标又被改动的槽交给 cursor_follows
        v = zone_val(V, z)
        if v is None or not (z[2] <= v + d <= z[3] + 1):
            return None
        for l in range(z[0], z[1] + 1):
            for i in range(z[2], z[3] + 1):           # 只画这一块矩形：越过前墙就是画别人的槽
                if (l, i) in pipe:
                    continue                          # 通道这几格归 gauge_lit，本概念不认领
                r, c = put(l, i)
                if V[l][i] == C_BTN:
                    out[(r, c)] = C_BTN               # 按钮压在填充上，不随前沿走
                elif i < v + d:
                    out[(r, c)] = C_BG0
                else:
                    j = i - d                         # 前沿以上整体平移 d 格
                    src = V[l][j] if z[2] <= j <= z[3] else C_BG3
                    if (l, j) in pipe:
                        src = C_BG3                   # 通道是画在空槽色上的贴图，不跟着前沿走
                    out[(r, c)] = C_BG3 if src == C_BTN else src
    return out or None
