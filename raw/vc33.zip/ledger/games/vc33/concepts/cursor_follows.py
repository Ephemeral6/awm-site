"""每个带标记的槽里，那个标记（光标）永远紧贴该槽填充前沿的外侧：标记的偏移恒等于该槽的值。"""
LEVEL = "L6"
SCOPE = ("看的是 nxt 这一帧本身，跟动作无关（不变量）。换关那一步返回 NA；"
         "朝向/槽读不出来、或没有任何槽带标记时返回 NA。"
         "apply 只填**被这次点击改动、且带光标**的那些槽，做法是把该槽填充前沿以上的图案整体平移 STEP 格；"
         "**失去方那个槽的值 < STEP 时这次点击搬不动任何东西**（见 btn_starved），apply 一格不主张。")
NOTE = ("v2：改用规范视图，允许一关里同时有多个带光标的槽（第 2 关有三个）；"
        "光标图案不再假定形状，只假定它随前沿刚性平移。"
        "v4：apply 补上「源槽不够搬」这道闸。b83db3728dbbed59 / 25b3851d7df61ea8 / d72b339e4fdae5b7 三步"
        "点的是槽1 的按钮而隔条对面的槽2 是空的，实际整帧只有顶栏变，本概念的 apply 却照旧把槽1 整体推了 3 格，"
        "三步共说错 186 格——而它的 assert_ 判 TRUE，因为那是一条只看 nxt 的不变量，"
        "光标没动、值没变，不变量当然成立。**检查器看不见生成器画了什么**，这是同一条概念里两半各说各话，"
        "只有 settle 的「说错格数」抓得到；断言没错，是 apply 越界了。"
        "btn_pull 早就把这一情形写在 scope 里当洞（「不够搬的情形另立概念」），本概念抄它的 apply 时漏抄了这道闸。"
        "v5：和 btn_pull v6 同一处改动——通道那几格让给 gauge_lit，既不认领也不当平移的源。"
        "两条概念在同一批里犯的是同一个错，因为一条的 apply 是抄另一条的："
        "**抄来的生成器会把洞一起抄走**，两次都是这样。"
        "v6→v7：又是和 btn_pull 同一处（第三次了）。槽变成矩形之后，"
        "「够不够搬」要拿 值 − 起算深度 去比 STEP，画笔要停在这块矩形的深度区间里。"
        "这一条比前两次难发现：它的 assert_ 是只看 nxt 的不变量，光标贴着前沿这件事在越界重画之后照样成立。")
EVIDENCE = ["929fb8538dfac04c", "dd47bbf667b158ad",
            "b83db3728dbbed59", "25b3851d7df61ea8", "d72b339e4fdae5b7"]

from _lib import (C_BG0, C_BG3, C_BTN, button_hit, cursors, gauge_pipe_cells,
                  step, view, will_win, would_cap, zone_val, zones)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    V, _ = view(nxt)
    if V is None:
        return "NA"
    cu = cursors(V)
    if not cu:
        return "NA"
    for _col, (z, off) in cu.items():
        v = zone_val(V, z)
        if v is None:
            return "NA"
        if off != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if will_win(prev, action):
        return None                                   # 册子自己预言这一步换关 —— 事前也闭嘴，不只事后
    bh = button_hit(prev, action)
    if bh is None:
        return None
    gain, lose = bh
    V, put = view(prev)
    if V is None:
        return None
    st = step(V)
    if st is None:
        return None
    lv = zone_val(V, lose)
    if lv is None or lv - lose[2] < st:
        return None                                   # 源槽不够搬 —— 这次点击什么都不动，交给 btn_starved
    if would_cap(prev, action) is not False:
        return None                                   # 得到方顶出上限 —— 同样什么都不动，交给 btn_capped
    marked = {z for z, _ in cursors(V).values()}
    pipe = gauge_pipe_cells(V)
    out = {}
    for z in zones(V):
        if z not in marked:
            continue
        d = st if z == gain else (-st if z == lose else 0)
        if d == 0:
            continue                                  # 没被改动的槽不归本概念说
        v = zone_val(V, z)
        if v is None or not (z[2] <= v + d <= z[3] + 1):
            return None
        for l in range(z[0], z[1] + 1):
            for i in range(z[2], z[3] + 1):           # 只画这一块矩形
                if (l, i) in pipe:
                    continue                          # 通道这几格归 gauge_lit
                r, c = put(l, i)
                if V[l][i] == C_BTN:
                    out[(r, c)] = C_BTN
                elif i < v + d:
                    out[(r, c)] = C_BG0
                else:
                    j = i - d
                    src = V[l][j] if z[2] <= j <= z[3] else C_BG3
                    if (l, j) in pipe:
                        src = C_BG3                   # 通道是贴图，不跟着前沿走
                    out[(r, c)] = C_BG3 if src == C_BTN else src
    return out or None
