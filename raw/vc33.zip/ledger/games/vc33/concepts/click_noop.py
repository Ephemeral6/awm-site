"""点在不是色9 按钮的格子上：除了行 0 的顶栏，整帧一格不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6；坐标越界返回 NA；点在 C_BTN 格上返回 NA（那归 btn_pull）；"
         "点在量规段里返回 NA（那归 gauge_teleport）；换关那一步返回 NA。")
NOTE = ("v3：让出「点在量规段里」这一整类。"
        "它在 128 步里判 TRUE 判了 128 次，第 129 步挨了第一记打——"
        "点在亮着的量规段上，光标连把手 56 格整套搬去了对岸的槽，槽值一格没动。"
        "让出的是**整类**（亮的暗的一起让），比反例要求的宽：暗着的量规点下去确实是空转，"
        "语料里 3 条都是，这条概念本来判得对。宽让的理由是不想在两处各写一份"
        "「什么时候算亮、光标挨不挨着」——那是 gauge_teleport 的主张，抄过来就是同一句世界事实走两遍闸、"
        "改一处漏一处。让位只用 _lib.gauge_hit 的**位置**判据，不碰条件。"
        "v2：只是改了导入，判据没变——这条本来就跟朝向无关。")
EVIDENCE = ["35aa5098824dc6dd", "47e6fd70ee9839d7"]

from _lib import C_BTN, N, clicked, gauge_hit


def _out_of_scope(prev, action):
    p = clicked(action)
    if p is None:
        return True
    x, y = p
    if not (0 <= y < N and 0 <= x < N):
        return True
    if prev[y][x] == C_BTN:
        return True
    return gauge_hit(prev, action) is not None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if _out_of_scope(prev, action):
        return "NA"
    for r in range(1, N):
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if _out_of_scope(prev, action):
        return None
    return {(r, c): prev[r][c] for r in range(1, N) for c in range(N)}

