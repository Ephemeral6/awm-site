"""隔条里那段量规标记的颜色，只在「它两侧槽的液面是否都正好等于该段起始深度」这件事翻转的那一步改变；这件事不翻转，它整段一格不变。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION6；换关那一步返回 NA；朝向/槽值读不出来返回 NA；"
         "这一关没有量规段（隔条里的标记都配得到同色光标）时返回 NA——前三关都是这样。"
         "**光标读不干净时返回 NA**（cursors_ambiguous）：谁是量规全靠「这个色在槽里配不到光标」，"
         "而某个光标因同色重名被丢掉时，它的配对目标就会被归成量规，判据静默给出错答案。"
         "**只断言「变没变」，不断言「变成什么色」**：点亮用的是哪个色号，光看一帧读不出来，"
         "得先见过它亮一次。apply 因此只认领**不翻转**的那些步（照抄原色），翻转的那一步一格不主张，是明写的洞。"
         "**apply 还有一道事前闸**：这一次点击之后该换关（`_lib.will_win` 判 True）时返回 None——"
         "换关那一帧整盘重画，照抄原色是错的。")
NOTE = ("v5：apply 补上「这一步之后该换关就闭嘴」的事前闸，跟 gauge_lit v5 同一处漏洞。"
        "本概念的 apply 在换关那一帧照抄量规段的原色，而整盘已经重画——语料里 5 条带量规的换关转移上"
        "说的每一格都是错的（72、108、72 格全错）。事后闸（ctx 的关卡号）挡不住它，"
        "因为逐格预测和终局卡上的 ctx 一律按「不换关」给。"
        "v3：把 v2 声称有、其实没接上的那道闸真接上，并从 marks_ambiguous 换成 cursors_ambiguous。"
        "**v2 是一次空改版**：SCOPE 里写了「标记读不干净时返回 NA」，import 也加了，"
        "assert_ 和 apply 里一次都没调用——结算照样记「改版、代码变了」，因为源码确实变了（变的是 import）。"
        "教训：闸写在 SCOPE 里不算写；settle 记的「改版」不核对 SCOPE 和代码是否一致，没有任何东西会替我发现这件事。"
        "换判据的理由：原来那个把两种重名混成一个信号——同一个色在好几条隔条里各嵌一段量规是常态，"
        "它只影响读不读得出配对目标，跟「谁是量规」无关；混着用会让这条概念在一整关里无故闭嘴。"
        "v2：只改了 SCOPE、NOTE 和 import，闸没接上（见上）。"
        "v1：前 77 步里隔条上的标记从没变过色，frame_static 因此一直把它算进「一格不动」的那片，"
        "在 75 条转移上判 TRUE。第 78 步和第 86 步各出一次反例，形状完全一样："
        "两侧槽的液面同时落到该量规段的起始深度，那一整段就换一个色号；下一步液面一错开，又换回来。"
        "这一关有两段量规，起始深度分别是 9 和 18，各点亮过一次，各熄灭过一次，四条转移互相印证。"
        "**它是装置在说话**：这一关唯一没有按钮的那条隔条上也嵌着一段量规——"
        "盘面自己在标注「什么样的液面算对齐」，而对齐这件事在前三关根本不需要，因为前三关每条隔条都有按钮。"
        "写成 L7 不是 L2：变的不是世界的物件，是**观测量**——同一堵墙换了个颜色说自己的状态。"
        "v4：跟 gauge_lit v3 同一处改动——一片 lane 被前墙沿深度切成两个槽之后，"
        "「贴着这条隔条的槽」不按深度筛就会一次贴上三个，「两侧都对齐」永远凑不齐，"
        "于是 apply 在真的点亮那一步照抄了旧色。这条没挨打只是因为它比 gauge_lit 弱（只说变没变），"
        "**弱到判不出错，不等于说对了**。")
EVIDENCE = ["ddcefdf942239947", "a5eed45206fad5eb",
            "6d51ae3ccff9eda6", "542589050be2b131"]

from _lib import (bar_zones, clicked, cursors_ambiguous, gauge_aligned, gauges,
                  next_zone_vals, view, will_win)


def _seg_color(V, b, d0, d1):
    """量规段在这一帧里的颜色；整段不同色返回 None（本概念主张它整段同色）。"""
    cols = {V[l][d] for l in range(b[0], b[1] + 1) for d in range(d0, d1 + 1)}
    return cols.pop() if len(cols) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if clicked(action) is None:
        return "NA"
    V0, _ = view(prev)
    V1, _ = view(nxt)
    if V0 is None or V1 is None:
        return "NA"
    if cursors_ambiguous(V0) or cursors_ambiguous(V1):
        return "NA"
    gs = gauges(V0)
    if not gs:
        return "NA"
    for b, col, d0, d1 in gs:
        a0 = gauge_aligned(V0, b, d0, d1)
        a1 = gauge_aligned(V1, b, d0, d1)
        if a0 is None or a1 is None:
            return "NA"
        now = _seg_color(V1, b, d0, d1)
        if now is None:
            return "FALSE"                    # 整段不同色 —— 主张里说它整段一起翻
        if (now != col) != (a0 != a1):
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if clicked(action) is None:
        return None
    if will_win(prev, action) is True:
        return None                           # 事前闸：这一步之后整盘换掉，照抄原色是错的
    V0, put = view(prev)
    if V0 is None:
        return None
    if cursors_ambiguous(V0):
        return None
    gs = gauges(V0)
    if not gs:
        return None
    out = {}
    nv = next_zone_vals(prev, action)
    if nv is None:
        return None
    for b, col, d0, d1 in gs:
        a0 = gauge_aligned(V0, b, d0, d1)
        if a0 is None:
            return None
        adj = bar_zones(V0, b, d0, d1)
        if not adj:
            return None
        a1 = all(nv.get(z) == d0 for z in adj)
        if a0 != a1:
            continue                          # 这一步翻转 —— 本概念不认领，明写的洞
        for l in range(b[0], b[1] + 1):
            for d in range(d0, d1 + 1):
                out[put(l, d)] = col
    return out or None
