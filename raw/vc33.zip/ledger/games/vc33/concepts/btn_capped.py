"""点在色9 按钮上、而得到方那个槽加了 STEP 之后会超过它的容量上限时：这次点击整个作废，除了行 0 的顶栏整帧一格不动。"""
LEVEL = "L2"
SCOPE = ("只看落在 C_BTN 格上的 ACTION6；换关那一步返回 NA；朝向/槽值/STEP 读不出来返回 NA；"
         "得到方加 STEP 之后不超过上限时返回 NA（那归 btn_pull）。"
         "**不管源槽够不够搬**——源槽不够搬同时又会顶出上限的情形，两条概念都会开口，"
         "它们对帧的主张是同一句「除顶栏外一格不动」，不会打架。")
NOTE = ("v1：和 btn_starved 是一对，管的是同一件事的另一半——点击白费。"
        "区别在白费的原因：btn_starved 是源头没货，这条是接收方装不下。"
        "第 75 步 ACTION6:45,63 是唯一一例：源槽有 3 格、STEP 也是 3，够搬，"
        "但得到方已经 30 而它的上限就是 30（隔条4 只画到深 29）。"
        "**顶出上限不会溢流到隔壁槽，也不会只搬一部分，而是整次作废，预算照扣。**"
        "这一条是花了一次预算买来的，值：它把「墙有高度」从一句描述变成了会改变动作后果的规律。")
EVIDENCE = ["2c891272c598af11"]

from _lib import N, would_cap


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if would_cap(prev, action) is not True:
        return "NA"
    for r in range(1, N):
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if would_cap(prev, action) is not True:
        return None
    return {(r, c): prev[r][c] for r in range(1, N) for c in range(N)}
