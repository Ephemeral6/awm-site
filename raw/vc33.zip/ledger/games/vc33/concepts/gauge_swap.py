"""点在亮着的量规段上、而这条隔条两侧的槽里各站着一个光标：两个光标连同把手**对调**，各自在对面那个槽里居中、深度不变、各槽的值一格不动；量规段不亮时，除了行 0 整帧不动。

这是 gauge_teleport 明写的那个洞——它在「两侧各一个光标」上返回 NA（不知道该搬哪个、会不会对调）。
对调是唯一能让两个光标**互换左右**的途径：单光标搬运永远换不了位，两个光标谁也过不去谁。
落点算法和单光标搬运是同一条（在目标槽里居中），不是另立一条。
"""
LEVEL = "L1"
SCOPE = ("只看点在量规段里的 ACTION6（gauge_hit 非 None）；不是 ACTION6、坐标越界、"
         "没点在量规段里、换关那一步、视图或槽值读不出来、光标读不干净（cursors_ambiguous）一律 NA；"
         "这条隔条两侧不是恰好两个槽时 NA。"
         "**两侧不是恰好各站一个光标时 NA** —— 那是 gauge_teleport 管的一片（0 个或 1 个）。"
         "任一套按居中算出来的落点超出目标槽的道号范围时 NA：塞不进去会怎样，语料里没有，不猜。")
NOTE = ("v3：落点的取整方向跟着 gauge_teleport v6 一起改（现在两条共用词汇里的 land_lane，"
        "判据是两边的中位下标对齐）。这条概念只被检验过两次，两次都在同一批里挨打——"
        "它和搬运是同一个落点算法，所以**同一个错必然同时出现在两条概念上**，"
        "这正是把公式抽进词汇的理由：分开写的时候，改对一条不会让另一条跟着对。"
        "反过来也成立：中间那版猜错的取整方向也是一改就同时打两条，"
        "**共用一个词的两条概念，反例数会翻倍，但它们数的是同一件事**——报数时别当成两条独立的证据。"
        "v1：由第 4 关那一记打生出来——不是反例，是一次**走进无人区**的押注。"
        "那一关两个配对互相要求对方的位置（各自的目标槽被容量上限钉死在盘子的两头），"
        "而册子里当时唯一的搬运手段是单光标搬运，它换不了位：BFS 在整个状态空间里穷举完也到不了目标。"
        "**「规划器说到不了」不等于「世界做不到」**——它等于「册子说不出来」。"
        "分辨这两件事的办法只有一个：找到册子返回 NA 的那一步，走进去。"
        "所以这一批的押注押的不是「会发生什么」而是「这一步全册无话可说」，"
        "再把我猜的那件事（对调）写成能落空的话。它兑现了。"
        "教训：搜索穷举失败是**地图空白的信号**，不是阻断的证据；"
        "把它当阻断写进主张，会把一条没问过的问题伪装成一个已知的否定。"
        "v2：「隔条两侧的槽」改成按深度一起筛（同 gauge_teleport v5）——"
        "有前墙的关卡里一条隔条会贴上三个槽，不筛深度这条概念在整关一句话都不说。")
EVIDENCE = ["3831ee5dc044372c",          # 两个光标分居亮着的隔条两侧 → 对调，槽值不动
            "b636b3115874a6d0",          # 同一局面的第二次对调：宽 15 装宽 6，取整向下
            "a325c55faf708a04"]          # 宽 16 / 宽 14 各装宽 3：同一条公式，取整向上（v2 死在这里）

from _lib import (C_BG3, N, bar_zones, cursors, cursors_ambiguous, gauge_hit,
                  land_lane, rig_cells, view, zone_vals)

C_GAUGE_ON = 12                  # 量规亮着时的色号（和 gauge_lit / gauge_teleport 各写一份）


def _plan(prev, action):
    """("NA", None) / ("stay", (V, put)) / ("swap", (V, put, {原坐标: 色}))。"""
    hit = gauge_hit(prev, action)
    if hit is None:
        return ("NA", None)
    b, col, gd0, gd1 = hit
    V, put = view(prev)
    if V is None or cursors_ambiguous(V) or zone_vals(V) is None:
        return ("NA", None)
    adj = bar_zones(V, b, gd0, gd1)
    if len(adj) != 2:
        return ("NA", None)
    near = [(c, z) for c, (z, _off) in cursors(V).items() if z in adj]
    if len(near) != 2 or near[0][1] == near[1][1]:
        return ("NA", None)                  # 不是两侧各一个 —— 归 gauge_teleport
    if col != C_GAUGE_ON:
        return ("stay", (V, put))
    want = {}
    moves = []
    for _c, src in near:
        dst = adj[0] if src == adj[1] else adj[1]
        rig = rig_cells(V, src)
        if not rig:
            return ("NA", None)
        lanes = {lane for lane, _d in rig}
        w = max(lanes) - min(lanes) + 1
        if w > dst[1] - dst[0] + 1:
            return ("NA", None)
        shift = land_lane(dst, w) - min(lanes)
        moves.append((rig, shift))
    for rig, _shift in moves:                # 先把两套原地的格子腾空
        for cell in rig:
            want[cell] = C_BG3
    for rig, shift in moves:                 # 再落到对面（落点覆盖腾空）
        for (lane, d), c in rig.items():
            want[(lane + shift, d)] = c
    return ("swap", (V, put, want))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    kind, data = _plan(prev, action)
    if kind == "NA":
        return "NA"
    if kind == "stay":
        for r in range(1, N):
            if prev[r] != nxt[r]:
                return "FALSE"
        return "TRUE"
    V, put, want = data
    V1, _ = view(nxt)
    if V1 is None:
        return "FALSE"
    if zone_vals(V) != zone_vals(V1):
        return "FALSE"                       # 对调光标不搬液体
    for (lane, d), c in want.items():
        if not (0 <= lane < len(V1) and 0 <= d < len(V1[lane])):
            return "FALSE"
        if V1[lane][d] != c:
            return "FALSE"
    changed = set()
    for r in range(1, N):
        for c in range(N):
            if prev[r][c] != nxt[r][c]:
                changed.add((r, c))
    if changed != {put(lane, d) for lane, d in want if prev[put(lane, d)[0]][put(lane, d)[1]] != want[(lane, d)]}:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    kind, data = _plan(prev, action)
    if kind == "NA":
        return None
    if kind == "stay":
        return {(r, c): prev[r][c] for r in range(1, N) for c in range(N)}
    V, put, want = data
    out = {}
    for (lane, d), c in want.items():
        out[put(lane, d)] = c
    for r in range(1, N):
        for c in range(N):
            out.setdefault((r, c), prev[r][c])
    return out
