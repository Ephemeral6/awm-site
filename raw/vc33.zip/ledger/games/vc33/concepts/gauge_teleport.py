"""点在量规段上：那段亮着、且光标就在这条隔条一侧的槽里时，光标连着把手整套搬到隔条对岸那个槽，**在目标槽里居中**、深度不变、各槽的值一格不动；两个条件缺任何一个，除了行 0 整帧不动。

这是配对要求会**换槽**的唯一途径：搬完之后，要求某个深度的不再是原来那个槽。
两侧的槽宽度不同也照这条算——落点由目标槽的宽度和这一套的宽度算出来，和它原来在源槽里偏左偏右无关。
"""
LEVEL = "L1"
SCOPE = (
    "只看点在量规段里的 ACTION6（gauge_hit 非 None）；不是 ACTION6、坐标越界、"
    "没点在量规段里、换关那一步、视图或槽值读不出来、光标读不干净（cursors_ambiguous）一律 NA；"
    "两侧不是恰好两个槽时 NA。"
    "**两侧各有一个光标时 NA** —— 不知道该搬哪个、或者会不会两个对调，语料里没见过。"
    "落点算出来超出目标槽的道号范围时 NA：那种局面语料里没有，"
    "而「挤不进去会怎样」是另一条主张（会不会不搬、会不会截断），这里不猜。"
)
NOTE = (
    "v6：居中的**取整方向**错了半格。v4 写「向下取整」，一直判 TRUE，"
    "因为在此之前每一次搬运的「目标槽宽 − 这一套宽」都是偶数——偶数时向上向下取整同一个答案，"
    "两种算法在语料里一直是同一条概念。第一次遇到差为奇数就差了整整一道。"
    "改法：把落点抽进词汇 land_lane 一处算（搬运和对调共用），"
    "判据是**两边的中位下标对齐**：槽的中位 = 宽//2，这一套的中位 = 宽//2，让它们落在同一道。"
    "**中间还死过一版猜测**：先改成一律向上取整，它修好了新关卡那两条，"
    "却把旧关卡上四条本来判 TRUE 的转移打成反例——一律向下和一律向上都不对，"
    "取整方向由这一套的宽的奇偶决定。分辨它靠的不是再猜一次，"
    "是把语料里全部 21 次落点连同源槽、目标槽、宽度列成一张表，从表上读出来。"
    "教训：一个公式里每有一次整数除法，就藏着一个语料没分开的二选一；"
    "而当第一个修法在旧语料上引出新反例时，**那说明两个分支都不是真的判据**，"
    "该去列表，不该在两个分支之间来回挑。"
    "还有一笔看得见的代价：猜错的那一版打出来的反例，装置照样要求登记进 EVIDENCE，"
    "而进了 EVIDENCE 就退出计分——**乱猜一版会把这条概念的可测语料一次性削掉一大块**，"
    "这一次是 6 条搬运里的 5 条。列表再改，不只是更快，也更省证据。"
    "v5：「隔条两侧的槽」改成按**深度**一起筛。一片 lane 被一堵与填充方向垂直的墙切成两个槽之后，"
    "一条隔条会同时贴上三个槽，len(adj) != 2 让这条概念在整关静音——"
    "而那一关的过关手段正是搬光标。这是 v3 那条教训的第二次上演："
    "**闸掉一片语料，等于闸掉那片语料能做的判别**，只是这一次闸不是我写的，是词汇改基之后自己冒出来的。"
    "所以词汇一改基，先去数每条概念的 NA 率有没有在新关卡上跳到 100%——静音不报错。"
    "v4：落点从「相对低道号那一侧的偏移不变」改成「在目标槽里居中」。"
    "v3 放宽宽度闸之后第一次被检验就挨打，只差 1 道：源槽宽 12、这一套宽 6、贴着两边各留 3，"
    "目标槽宽 14，左对齐算出 lane 37，实测 38 = 34 + (14-6)//2。"
    "**v2 那道「两侧必须一样宽」的闸恰好掩盖了这件事**：同宽时左对齐和居中给同一个答案，"
    "所以那道闸不只是让概念哑火，它还让哑火看起来无害——被它挡住的转移，"
    "正是唯一能把两种落点算法分开的那些。闸掉一片语料，等于闸掉那片语料能做的判别。"
    "v3：删掉「两侧两个槽必须一样宽」那道闸，把落点明写出来。"
    "v2 那道闸的理由是「语料里两侧一样宽，别猜」，听着像谨慎，实际是把这条概念在整关里静音："
    "这一关四个槽宽度各不相同（没有任何一对相等），于是每一次量规点击都判 NA，"
    "而本关唯一的过关手段就是搬光标——三枪搬运下去，一条主张都不会被检验。"
    "**「语料没分开的两种可能」有两种处理，代价不对称**：闸掉它，这条概念在需要它的地方哑火，"
    "而哑火不报错；写下来，猜错就是一条反例，当场看见。所以只要落点是可判错的，就该写下来。"
    "v2：把「整盘只有一个光标」改成「这条隔条两侧恰有一个光标」。v1 写死了前者，"
    "而下一关盘上就有两个光标——照 v1 这条概念会在整关返回 NA，一次都不被检验，"
    "而它是上一关唯一的过关手段。**「语料里只有一个」不该写成「只能有一个」**："
    "前者是读数，后者是判据，抄成判据就是把这一关的答案钉进概念。"
    "同时把重名闸从 marks_ambiguous 换成 cursors_ambiguous（同一个色在几条隔条里各嵌一段量规是常态）。"
    "v1：由第 3 关那一记打生出来。click_noop 在 128 步里活了 128 步，第 129 步挨打，"
    "打它的正是点在**亮着**的量规段上那一枪；同一条隔条暗着的时候点它、"
    "以及另一条隔条亮着但光标不在它两侧的时候点它，都确实是空转。"
    "亮/暗 × 挨着/不挨着 四种组合语料里各有一条，条件是分开的，不是猜的。"
    "把「亮」和「光标挨着」写成两个独立的门，是因为语料恰好把它们分开了；"
    "如果只见过步 125 那一条，我会写成「点亮着的量规就搬」，那是把两个条件当成一个。"
)
EVIDENCE = [
    "47e6fd70ee9839d7",          # 亮 + 光标挨着 → 搬了（槽1→槽2，56 格）
    "2d61d83a5d9a02bc",          # 亮 + 光标不挨着 → 没搬
    "88fe14095c56b1fb",          # 暗 + 光标挨着 → 没搬
    "f2b53f63ac10e2c2",          # 暗 + 光标不挨着 → 没搬
    "8a7a6f30cf0fc592",          # 暗 + 光标不挨着 → 没搬
    "05c1f4554e79b345",          # 宽 12 的槽搬到宽 14 的槽：居中，不是左对齐（v3 死在这里）
    "85df44246c594e82",          # 宽 16 的槽装宽 3 的一套：中位对齐，一律向下取整在这里差一道（v5 死在这里）
    "2a3ebdd27390ef4b",          # 宽 15 装宽 6：同样是奇数差，取整方向却相反（一律向上的 v6 死在这里）
    "1c50f14386896f47",          # 同上，另一次
    "0edfd4ff0e21edb1",          # 宽 31 装宽 6
    "87fb8e054725a854",          # 宽 29 装宽 6
]

from _lib import (C_BG3, N, bar_zones, cursors, cursors_ambiguous, gauge_hit,
                  land_lane, rig_cells, view, zone_vals)

C_GAUGE_ON = 12                  # 量规亮着时的色号（和 gauge_lit 各写一份：那条概念的主张是「什么时候亮」）


def _plan(prev, action):
    """这一次点击按本主张该发生什么：
    ("NA", None) 读不出来 / 语料没覆盖；("stay", (V, put)) 该空转；
    ("move", (V, put, 源槽, 目标槽, 套)) 该整套搬过去。"""
    hit = gauge_hit(prev, action)
    if hit is None:
        return ("NA", None)
    b, col, gd0, gd1 = hit
    V, put = view(prev)
    if V is None or cursors_ambiguous(V) or zone_vals(V) is None:
        return ("NA", None)
    adj = bar_zones(V, b, gd0, gd1)
    if len(adj) != 2:
        return ("NA", None)
    near = [(c, z) for c, (z, _off) in cursors(V).items() if z in adj]
    if len(near) > 1:
        return ("NA", None)          # 两侧各一个光标：搬哪个、会不会对调，语料里没见过
    if col != C_GAUGE_ON or len(near) != 1:
        return ("stay", (V, put))    # 暗着，或者没有光标挨着这条隔条
    _ccol, src = near[0]
    dst = adj[0] if src == adj[1] else adj[1]
    rig = rig_cells(V, src)
    if not rig:
        return ("NA", None)
    lanes = {lane for lane, _d in rig}
    w = max(lanes) - min(lanes) + 1
    if w > dst[1] - dst[0] + 1:
        return ("NA", None)      # 这一套比目标槽还宽：塞不进去会怎样，语料里没有，不猜
    # 落点：在目标槽里居中。取整方向由 _lib.land_lane 一处定，搬运和对调共用。
    shift = land_lane(dst, w) - min(lanes)
    return ("move", (V, put, shift, rig))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    kind, data = _plan(prev, action)
    if kind == "NA":
        return "NA"
    if kind == "stay":
        for r in range(1, N):
            if prev[r] != nxt[r]:
                return "FALSE"
        return "TRUE"
    V, put, shift, rig = data
    V1, _ = view(nxt)
    if V1 is None:
        return "FALSE"
    if zone_vals(V) != zone_vals(V1):
        return "FALSE"                       # 搬光标不搬液体
    want = {}
    for (lane, d), _c in rig.items():
        want[(lane, d)] = C_BG3
    for (lane, d), c in rig.items():
        want[(lane + shift, d)] = c
    for (lane, d), c in want.items():
        if not (0 <= lane < len(V1) and 0 <= d < len(V1[lane])):
            return "FALSE"
        if V1[lane][d] != c:
            return "FALSE"
    # 整帧只许这些格子变（行 0 归 hud_cost）
    changed = set()
    for r in range(1, N):
        for c in range(N):
            if prev[r][c] != nxt[r][c]:
                changed.add((r, c))
    if changed != {put(lane, d) for lane, d in want}:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    kind, data = _plan(prev, action)
    if kind == "NA":
        return None
    if kind == "stay":
        return {(r, c): prev[r][c] for r in range(1, N) for c in range(N)}
    V, put, shift, rig = data
    out = {}
    for (lane, d), _c in rig.items():
        out[put(lane, d)] = C_BG3
    for (lane, d), c in rig.items():
        out[put(lane + shift, d)] = c
    for r in range(1, N):
        for c in range(N):
            out.setdefault((r, c), prev[r][c])
    return out

