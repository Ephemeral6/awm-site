/-
# Proof/Scenes —— 两把钥匙各一张「赢不了」的盘，外加三条防线

一个把什么都判成「不可做」的判据也能通过全部检查——它从不说「能赢」，永远不会被反例打死。
所以每张「赢不了」的盘都配一张**只差一处**的盘，配三条：

    _ctrl_winnable        对照盘确实赢得了（给一条真路线，让内核算）
    _ctrl_closed_at_start 而且不是因为它一开始就通
    _ctrl_not_key         而且那把钥匙在对照盘上**前提真的不满足**（不是「没找到证明」）

两张盘都从**第 0 关的真实开局**改一处：只挪那一段目标的深度。对照盘就是第 0 关本身
（它赢得了——那是 `Proof/Levels/L0.lean` 的 `L0_winnable`，真人走过的那条路）。

    钥匙一（余数）  目标深度 24 → 26：两侧的槽液面 32、12，模 4 都是 0；26 模 4 是 2。盘上什么都没挡着。
    钥匙二（墙高）  目标深度 24 → 48：两侧的槽容量都是 44（墙只画到 44 深）。48 模 4 是 0，余数那把套不上。

每张盘还证一条「**另一把钥匙在这里套不上**」：两把钥匙的理由真的不同，不会在同一处一起失效。

**「赢不了」的准确意思**：不经过模型说不出话的那一支（`Res.na`）、也不经过 RESET（它不是 `Act`），就赢不了。
-/

import Obj.World
import Step
import Proof.Reachable
import Proof.Keys.Residue
import Proof.Keys.Capacity
import Proof.Levels.L0

namespace Game
namespace Scenes

open Levels

/-- 把版面上每一段目标的深度往深处挪 `k`。**两张盘都只改这一处。** -/
def shiftTargets (b : Board) (k : Nat) : Board :=
  { b with targets := b.targets.map (fun t => { t with depths := ⟨t.depths.lo + k, t.depths.hi + k⟩ }) }

def residueBoard : Board := shiftTargets L0_board 2
def capacityBoard : Board := shiftTargets L0_board 24

-- ---------------------------------------------------------------- 钥匙一：余数

/-- 目标深度挪到 26：**赢不了**。 -/
theorem residue_scene_unsolvable : Unsolvable (World.mk residueBoard L0_start) :=
  unsolvable_by_residue residueBoard 4 L0_start (by decide +kernel)

/-- 这张盘上墙高那把钥匙**套不上**（26 没超过容量 44）——赢不了的理由确实是余数。 -/
theorem residue_scene_not_capacity : capKeyOf (World.mk residueBoard L0_start) = false := by decide +kernel

/-- 对照盘（第 0 关本身）赢得了。 -/
theorem residue_ctrl_winnable : Winnable (World.mk L0_board L0_start) := L0_winnable

/-- 对照盘不是一开局就到位。 -/
theorem residue_ctrl_closed_at_start : isGoal L0_board L0_start = false := by decide +kernel

/-- 对照盘上余数那把钥匙的**前提不满足**（24 模 4 = 0 = 两侧液面模 4）。 -/
theorem residue_ctrl_not_key : resKeyOf (World.mk L0_board L0_start) 4 = false := by decide +kernel

-- ---------------------------------------------------------------- 钥匙二：墙高

/-- 目标深度挪到 48：**赢不了**。 -/
theorem capacity_scene_unsolvable : Unsolvable (World.mk capacityBoard L0_start) :=
  unsolvable_by_capacity capacityBoard L0_start (by decide +kernel)

/-- 这张盘上余数那把钥匙**套不上**（48 模 4 = 0 = 两侧液面模 4）——赢不了的理由确实是墙高。 -/
theorem capacity_scene_not_residue : resKeyOf (World.mk capacityBoard L0_start) 4 = false := by decide +kernel

theorem capacity_ctrl_winnable : Winnable (World.mk L0_board L0_start) := L0_winnable

theorem capacity_ctrl_closed_at_start : isGoal L0_board L0_start = false := by decide +kernel

/-- 对照盘上墙高那把钥匙的**前提不满足**（24 < 44）。 -/
theorem capacity_ctrl_not_key : capKeyOf (World.mk L0_board L0_start) = false := by decide +kernel

#print axioms residue_scene_unsolvable
#print axioms residue_scene_not_capacity
#print axioms residue_ctrl_winnable
#print axioms residue_ctrl_closed_at_start
#print axioms residue_ctrl_not_key
#print axioms capacity_scene_unsolvable
#print axioms capacity_scene_not_residue
#print axioms capacity_ctrl_winnable
#print axioms capacity_ctrl_closed_at_start
#print axioms capacity_ctrl_not_key

#eval "SCENE residue target=" ++ toString (residueBoard.targets.map (fun t => t.depths.lo)) ++
  " levels=" ++ toString L0_start.levels
#eval "SCENE capacity target=" ++ toString (capacityBoard.targets.map (fun t => t.depths.lo)) ++
  " caps=" ++ toString ((upto L0_start.levels.length).map (capacity capacityBoard))

end Scenes
end Game
