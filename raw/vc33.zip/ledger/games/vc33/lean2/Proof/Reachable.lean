/-
# Reachable —— 这个**局面**做不做得了

整套形式化里只有两句话是要证的：

    Winnable   w  :=  ∃ as, 每一下合法 ∧ 照着走中途赢过
    Unsolvable w  :=  ∀ as, 每一下合法 → 照着走从没赢过

**「赢不了」的准确意思永远带半句**：`everWon` 碰到模型说不出话的那一支（`Res.na`）返回 `false`，
所以 `Unsolvable` 说的是「**不经过模型说不出话的那一支**、也不经过 RESET（它不是 `Act`），就赢不了」。
`∀ as` 这个形状一个字都看不出这半句，所以写在这里、写在每关那一层、写在页面上。

## 可做那一半容易，不可做那一半没有捷径

可做：给一条真路线，内核算一遍（每关那一层用的就是真人走过的那条路）。
不可做：要对**所有**动作串说话，不许枚举、不许搜索——只有一个办法：
找一个每走一步都还成立、而且和「赢」矛盾的量 Φ（下面的骨架，只证一次，与盘面大小无关）。
-/

import Obj.World
import Step

namespace Game

def Winnable (w : World) : Prop :=
  ∃ as : List Act, as.all (Act.legal w.board) = true ∧ everWon w.board w.st as = true

def Unsolvable (w : World) : Prop :=
  ∀ as : List Act, as.all (Act.legal w.board) = true → everWon w.board w.st as = false

/-- 两句话不能同时成立。 -/
theorem not_both (w : World) (h1 : Winnable w) (h2 : Unsolvable w) : False := by
  obtain ⟨as, hl, hw⟩ := h1
  rw [h2 as hl] at hw
  exact Bool.false_ne_true hw

#print axioms not_both

/-- **骨架：不变量 ⇒ 不可做。** 全文唯一做归纳的地方，不枚举任何状态。

    `hkeep`：Φ 每走一步都还成立（只对合法的一下）。
    `hwin` ：满足 Φ 的局面，这一步不可能赢。 -/
theorem unsolvable_of_invariant (b : Board) (P : State → Prop)
    (hkeep : ∀ s s' a, Act.legal b a = true → P s → step b s a = Res.ok s' → P s')
    (hwin : ∀ s a, P s → step b s a ≠ Res.won) :
    ∀ (s : State), P s → ∀ (as : List Act), as.all (Act.legal b) = true → everWon b s as = false := by
  intro s hp as
  induction as generalizing s with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [List.all_cons, Bool.and_eq_true] at hall
    simp only [everWon]
    cases hstep : step b s a with
    | won => exact absurd hstep (hwin s a hp)
    | na => rfl
    | ok s' => exact ih s' (hkeep s s' a hall.1 hp hstep) hall.2

#print axioms unsolvable_of_invariant

end Game
