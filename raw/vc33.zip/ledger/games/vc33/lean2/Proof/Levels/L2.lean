/-
# 第 2 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L2_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L2_walked     那一段模型一步不差地走了 22 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L2_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L2_start` 是**从语料帧里读出来的**（seq 382 动作之前那一帧），不是手写的盘。
过关那一脚（seq 404）的下一帧已经是下一关的盘，所以它不在 `L2_play` 里；它在 `L2_acts` 的最后。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L2_board : Board := Replay.boardOf 382
def L2_start : State := Replay.preOf 382
def L2_play : List (Act × State) := Replay.playFrom 382 22
def L2_acts : List Act := L2_play.map Prod.fst ++ [Replay.actOf 404]

#eval match firstSplit step L2_board L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L2_trace : traceOk step L2_board L2_start L2_play = true := by decide +kernel

/-- 这一关核过的步数：22。 -/
theorem L2_walked : walked step L2_board L2_start L2_play = 22 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 23 下，每一下都合法）。 -/
theorem L2_winnable : Winnable (World.mk L2_board L2_start) :=
  ⟨L2_acts, by decide +kernel, by decide +kernel⟩

#print axioms L2_trace
#print axioms L2_walked
#print axioms L2_winnable

end Levels
end Game
