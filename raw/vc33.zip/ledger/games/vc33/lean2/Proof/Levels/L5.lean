/-
# 第 5 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L5_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L5_walked     那一段模型一步不差地走了 19 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L5_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L5_start` 是**从语料帧里读出来的**（seq 470 动作之前那一帧），不是手写的盘。
过关那一脚（seq 489）的下一帧已经是下一关的盘，所以它不在 `L5_play` 里；它在 `L5_acts` 的最后。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L5_board : Board := Replay.boardOf 470
def L5_start : State := Replay.preOf 470
def L5_play : List (Act × State) := Replay.playFrom 470 19
def L5_acts : List Act := L5_play.map Prod.fst ++ [Replay.actOf 489]

#eval match firstSplit step L5_board L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L5_trace : traceOk step L5_board L5_start L5_play = true := by decide +kernel

/-- 这一关核过的步数：19。 -/
theorem L5_walked : walked step L5_board L5_start L5_play = 19 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 20 下，每一下都合法）。 -/
theorem L5_winnable : Winnable (World.mk L5_board L5_start) :=
  ⟨L5_acts, by decide +kernel, by decide +kernel⟩

#print axioms L5_trace
#print axioms L5_walked
#print axioms L5_winnable

end Levels
end Game
