/-
# 第 1 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L1_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L1_walked     那一段模型一步不差地走了 6 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L1_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L1_start` 是**从语料帧里读出来的**（seq 375 动作之前那一帧），不是手写的盘。
过关那一脚（seq 381）的下一帧已经是下一关的盘，所以它不在 `L1_play` 里；它在 `L1_acts` 的最后。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L1_board : Board := Replay.boardOf 375
def L1_start : State := Replay.preOf 375
def L1_play : List (Act × State) := Replay.playFrom 375 6
def L1_acts : List Act := L1_play.map Prod.fst ++ [Replay.actOf 381]

#eval match firstSplit step L1_board L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L1_trace : traceOk step L1_board L1_start L1_play = true := by decide +kernel

/-- 这一关核过的步数：6。 -/
theorem L1_walked : walked step L1_board L1_start L1_play = 6 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 7 下，每一下都合法）。 -/
theorem L1_winnable : Winnable (World.mk L1_board L1_start) :=
  ⟨L1_acts, by decide +kernel, by decide +kernel⟩

#print axioms L1_trace
#print axioms L1_walked
#print axioms L1_winnable

end Levels
end Game
