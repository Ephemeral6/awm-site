/-
# 第 3 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L3_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L3_walked     那一段模型一步不差地走了 20 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L3_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L3_start` 是**从语料帧里读出来的**（seq 405 动作之前那一帧），不是手写的盘。
过关那一脚（seq 425）的下一帧已经是下一关的盘，所以它不在 `L3_play` 里；它在 `L3_acts` 的最后。

这一关还带一段「重来之后」的核对（非认证段）：seq 92 RESET 之后 48 步。它们**不是见证**，只给「重来回到开局」那条假设一次被驳倒的机会。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L3_board : Board := Replay.boardOf 405
def L3_start : State := Replay.preOf 405
def L3_play : List (Act × State) := Replay.playFrom 405 20
def L3_acts : List Act := L3_play.map Prod.fst ++ [Replay.actOf 425]

#eval match firstSplit step L3_board L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L3_trace : traceOk step L3_board L3_start L3_play = true := by decide +kernel

/-- 这一关核过的步数：20。 -/
theorem L3_walked : walked step L3_board L3_start L3_play = 20 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 21 下，每一下都合法）。 -/
theorem L3_winnable : Winnable (World.mk L3_board L3_start) :=
  ⟨L3_acts, by decide +kernel, by decide +kernel⟩

#print axioms L3_trace
#print axioms L3_walked
#print axioms L3_winnable

/-- **假设：重来一次把局面放回这一关的开局。** 它不进模型（开局是历史，帧上读不出来）。

    这一段是非认证段里 seq 92 那次 RESET 之后的 48 步（seq 93 起），**从认证段的第 3 关开局起算**逐帧核。
    假设要是错的（重来其实没把液面 / 光标放回去），第一帧就对不上。
    **没红不构成证明**——但这是这条假设在这批语料上的一次被驳倒的机会，而它没被驳倒。 -/
def L3_after_reset_92 : List (Act × State) := Replay.playFrom 93 48

theorem L3_after_reset_92_trace : traceOk step L3_board L3_start L3_after_reset_92 = true := by
  decide +kernel

theorem L3_after_reset_92_walked : walked step L3_board L3_start L3_after_reset_92 = 48 := by
  decide +kernel

#print axioms L3_after_reset_92_trace
#print axioms L3_after_reset_92_walked

end Levels
end Game
