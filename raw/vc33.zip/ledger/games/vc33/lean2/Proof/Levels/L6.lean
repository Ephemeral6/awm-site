/-
# 第 6 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L6_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L6_walked     那一段模型一步不差地走了 48 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L6_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L6_start` 是**从语料帧里读出来的**（seq 490 动作之前那一帧），不是手写的盘。
过关那一脚（seq 538）的下一帧已经是下一关的盘，所以它不在 `L6_play` 里；它在 `L6_acts` 的最后。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L6_board : Board := Replay.boardOf 490
def L6_start : State := Replay.preOf 490
def L6_play : List (Act × State) := Replay.playFrom 490 48
def L6_acts : List Act := L6_play.map Prod.fst ++ [Replay.actOf 538]

#eval match firstSplit step L6_board L6_start L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L6_trace : traceOk step L6_board L6_start L6_play = true := by decide +kernel

/-- 这一关核过的步数：48。 -/
theorem L6_walked : walked step L6_board L6_start L6_play = 48 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 49 下，每一下都合法）。 -/
theorem L6_winnable : Winnable (World.mk L6_board L6_start) :=
  ⟨L6_acts, by decide +kernel, by decide +kernel⟩

#print axioms L6_trace
#print axioms L6_walked
#print axioms L6_winnable

end Levels
end Game
