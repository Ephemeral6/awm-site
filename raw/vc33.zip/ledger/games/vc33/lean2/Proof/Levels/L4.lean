/-
# 第 4 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L4_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L4_walked     那一段模型一步不差地走了 43 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L4_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L4_start` 是**从语料帧里读出来的**（seq 426 动作之前那一帧），不是手写的盘。
过关那一脚（seq 469）的下一帧已经是下一关的盘，所以它不在 `L4_play` 里；它在 `L4_acts` 的最后。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L4_board : Board := Replay.boardOf 426
def L4_start : State := Replay.preOf 426
def L4_play : List (Act × State) := Replay.playFrom 426 43
def L4_acts : List Act := L4_play.map Prod.fst ++ [Replay.actOf 469]

#eval match firstSplit step L4_board L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L4_trace : traceOk step L4_board L4_start L4_play = true := by decide +kernel

/-- 这一关核过的步数：43。 -/
theorem L4_walked : walked step L4_board L4_start L4_play = 43 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 44 下，每一下都合法）。 -/
theorem L4_winnable : Winnable (World.mk L4_board L4_start) :=
  ⟨L4_acts, by decide +kernel, by decide +kernel⟩

#print axioms L4_trace
#print axioms L4_walked
#print axioms L4_winnable

end Levels
end Game
