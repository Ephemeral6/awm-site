/-
# 第 0 关 —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

    L0_trace      沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（局面 + 版面由逐条那层另核）
    L0_walked     那一段模型一步不差地走了 2 步（切片切歪成空表时这个数是 0，`_trace` 却会平凡为真）
    L0_winnable   这一关走得通 —— 见证就是那一段走法再加上过关那一脚

开局 `L0_start` 是**从语料帧里读出来的**（seq 372 动作之前那一帧），不是手写的盘。
过关那一脚（seq 374）的下一帧已经是下一关的盘，所以它不在 `L0_play` 里；它在 `L0_acts` 的最后。

这一关还带一段「重来之后」的核对（非认证段）：seq 203 RESET 之后 2 步。它们**不是见证**，只给「重来回到开局」那条假设一次被驳倒的机会。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000

def L0_board : Board := Replay.boardOf 372
def L0_start : State := Replay.preOf 372
def L0_play : List (Act × State) := Replay.playFrom 372 2
def L0_acts : List Act := L0_play.map Prod.fst ++ [Replay.actOf 374]

#eval match firstSplit step L0_board L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L0_trace : traceOk step L0_board L0_start L0_play = true := by decide +kernel

/-- 这一关核过的步数：2。 -/
theorem L0_walked : walked step L0_board L0_start L0_play = 2 := by decide +kernel

/-- **这一关走得通。** 见证：认证那一段的走法 + 过关那一脚（共 3 下，每一下都合法）。 -/
theorem L0_winnable : Winnable (World.mk L0_board L0_start) :=
  ⟨L0_acts, by decide +kernel, by decide +kernel⟩

#print axioms L0_trace
#print axioms L0_walked
#print axioms L0_winnable

/-- **假设：重来一次把局面放回这一关的开局。** 它不进模型（开局是历史，帧上读不出来）。

    这一段是非认证段里 seq 203 那次 RESET 之后的 2 步（seq 204 起），**从认证段的第 0 关开局起算**逐帧核。
    假设要是错的（重来其实没把液面 / 光标放回去），第一帧就对不上。
    **没红不构成证明**——但这是这条假设在这批语料上的一次被驳倒的机会，而它没被驳倒。 -/
def L0_after_reset_203 : List (Act × State) := Replay.playFrom 204 2

theorem L0_after_reset_203_trace : traceOk step L0_board L0_start L0_after_reset_203 = true := by
  decide +kernel

theorem L0_after_reset_203_walked : walked step L0_board L0_start L0_after_reset_203 = 2 := by
  decide +kernel

#print axioms L0_after_reset_203_trace
#print axioms L0_after_reset_203_walked

end Levels
end Game
