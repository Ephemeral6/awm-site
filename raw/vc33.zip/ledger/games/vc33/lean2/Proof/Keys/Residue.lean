/-
# Proof/Keys/Residue —— 钥匙一：**余数守恒**（不是「挡住了」）

每一次搬运都是一个隔条厚度；这一局每条隔条厚度都是 `T` 的倍数时，
**每个槽的液面模 `T` 永远不变**——点量规、点空地不动液面，点按钮 ±厚度。
所以要是嵌目标的那条隔条两侧的每一个槽，液面模 `T` 都和目标深度模 `T` 不同，
那一对永远到不了位：盘上一堵墙都不需要，照样赢不了。

    ResP T s0 s    ∀ 槽 k，s 里的液面 ≡ s0 里的液面 (mod T)       ← 不变量 Φ
    resKey b T s0  厚度都是 T 的倍数 ∧ 每段目标两侧的槽，开局液面 ≢ 目标深度 (mod T)   ← 钥匙的前提（可当场算）

挂上骨架 `unsolvable_of_invariant`：**不枚举任何状态，和盘面多大无关。**
「赢不了」的准确意思带半句：**不经过模型说不出话的那一支、也不经过 RESET**（它不是 `Act`）。
-/

import Obj.World
import Step
import Derived.Idx
import Derived.StepFacts
import Derived.FlowConserved
import Proof.Reachable
import Proof.Keys.Goal

namespace Game

def ResP (T : Nat) (s0 s : State) : Prop := ∀ k, getN s.levels k % T = getN s0.levels k % T

def resKey (b : Board) (T : Nat) (s0 : State) : Bool :=
  b.bands.all (fun x => x.thickness % T == 0) &&
  b.targets.all (fun t => (sides b t.band none).all (fun k => getN s0.levels k % T != t.depths.lo % T))

/-- 钥匙的前提是**这个局面**的性质（版面 + 开局）。 -/
def resKeyOf (w : World) (T : Nat) : Bool := resKey w.board T w.st

theorem thick_res (l : List Band) (T bi : Nat) (h : l.all (fun x => x.thickness % T == 0) = true) :
    (match nth l bi with
     | none => 0
     | some band => band.thickness) % T = 0 := by
  induction l generalizing bi with
  | nil => simp [nth]
  | cons x xs ih =>
    simp only [List.all_cons, Bool.and_eq_true] at h
    cases bi with
    | zero => simp only [nth]; simpa using h.1
    | succ n => simp only [nth]; exact ih n h.2

theorem pressWith_res (b : Board) (T : Nat) (s0 s s' : State) (gain lose st : Nat)
    (hst : st % T = 0) (hr : ResP T s0 s) (h : pressWith b s gain lose st = some s') : ResP T s0 s' := by
  unfold pressWith at h
  split at h
  · cases h
  rename_i h1
  split at h
  · cases h
  rename_i h2
  split at h
  · cases h
  rename_i h3
  split at h
  · cases h; exact hr
  rename_i h4
  split at h
  · cases h; exact hr
  rename_i h5
  cases h
  intro k
  show getN (bump (bump s.levels gain (· + st)) lose (· - st)) k % T = getN s0.levels k % T
  have len1 : (bump s.levels gain (· + st)).length = s.levels.length := bump_length _ _ _
  by_cases hkl : k = lose
  · subst hkl
    rw [getN_bump_eq _ _ _ (by rw [len1]; omega),
        getN_bump_ne s.levels gain k (· + st) (fun e => h1 e.symm)]
    try simp only
    rw [sub_res _ _ _ hst (by omega)]
    exact hr k
  · rw [getN_bump_ne _ lose k _ hkl]
    by_cases hkg : k = gain
    · subst hkg
      rw [getN_bump_eq _ _ _ (by omega)]
      try simp only
      rw [add_res _ _ _ hst]
      exact hr k
    · rw [getN_bump_ne _ gain k _ hkg]
      exact hr k

theorem pre_res (b : Board) (T : Nat) (s0 s s' : State) (a : Act)
    (hb : b.bands.all (fun x => x.thickness % T == 0) = true)
    (hr : ResP T s0 s) (h : pre b s a = some s') : ResP T s0 s' := by
  rcases pre_cases b s s' a h with e | ⟨i, hp⟩ | ⟨i, hg⟩
  · rw [e]; exact hr
  · unfold pressButton at hp
    split at hp
    · cases hp
    · exact pressWith_res b T s0 s s' _ _ _ (by unfold thick; exact thick_res b.bands T _ hb) hr hp
  · intro k
    rw [clickGauge_levels b s s' i hg]
    exact hr k

/-- 走不坏：`step` 走成一个局面，余数一格不变。 -/
theorem res_keep (b : Board) (T : Nat) (s0 : State) (hk : resKey b T s0 = true) :
    ∀ s s' a, Act.legal b a = true → ResP T s0 s → step b s a = Res.ok s' → ResP T s0 s' := by
  intro s s' a _ hr h
  simp only [resKey, Bool.and_eq_true] at hk
  exact pre_res b T s0 s s' a hk.1 hr (step_ok_pre b s s' a h)

/-- 与目标矛盾：余数没变的局面，这一步不可能赢。 -/
theorem res_no_win (b : Board) (T : Nat) (s0 : State) (hk : resKey b T s0 = true) :
    ∀ s a, ResP T s0 s → step b s a ≠ Res.won := by
  intro s a hr hw
  obtain ⟨s', hp, hg⟩ := step_won_pre b s a hw
  simp only [resKey, Bool.and_eq_true, List.all_eq_true] at hk
  have hr' := pre_res b T s0 s s' a (List.all_eq_true.mpr hk.1) hr hp
  obtain ⟨c, t, ht, hm, he⟩ := goal_witness b s' hg
  have hne := hk.2 t ht c.zone (memN_mem _ _ hm)
  have e := hr' c.zone
  rw [he] at e
  simp only [bne_iff_ne, ne_eq] at hne
  exact hne e.symm

/-- **钥匙一挂上骨架**：钥匙的前提成立，这个局面就赢不了（不经过「说不出话」那一支、不经过 RESET）。 -/
theorem unsolvable_by_residue (b : Board) (T : Nat) (s0 : State) (hk : resKey b T s0 = true) :
    Unsolvable (World.mk b s0) := fun as hl =>
  unsolvable_of_invariant b (ResP T s0) (res_keep b T s0 hk) (res_no_win b T s0 hk) s0 (fun _ => rfl) as hl

#print axioms thick_res
#print axioms pressWith_res
#print axioms pre_res
#print axioms res_keep
#print axioms res_no_win
#print axioms unsolvable_by_residue

end Game
