/-
# Proof/Keys/Capacity —— 钥匙二：**墙太矮**（这一把是「挡住了」那一类）

槽装不过它旁边最矮的那堵墙（推论 `Derived/TankCap.lean`：液面从没超过容量的局面，走一步还是没超过）。
所以要是嵌目标的那条隔条两侧的每一个槽，容量都比目标深度浅，光标就永远到不了那个深度。

    CapOK b s     每个槽的液面 ≤ 它的容量                   ← 不变量 Φ（就是那条推论）
    capKey b s0   开局 CapOK ∧ 每段目标两侧的槽，容量 < 目标深度   ← 钥匙的前提（可当场算）

和钥匙一的理由**真的不同**：钥匙一盘上一堵墙都不需要（余数守恒），这一把靠的正是墙高。
两把各配一张对照盘（`Proof/Scenes.lean`），并且各自在对方的盘上**套不上**——同一处失效不会同时带走两把。
-/

import Obj.World
import Step
import Derived.Idx
import Derived.StepFacts
import Derived.TankCap
import Proof.Reachable
import Proof.Keys.Goal

namespace Game

def capKey (b : Board) (s0 : State) : Bool :=
  (upto s0.levels.length).all (fun k => Nat.ble (getN s0.levels k) (capacity b k)) &&
  b.targets.all (fun t => (sides b t.band none).all (fun k => Nat.blt (capacity b k) t.depths.lo))

/-- 钥匙的前提是**这个局面**的性质（版面 + 开局）。 -/
def capKeyOf (w : World) : Bool := capKey w.board w.st

theorem cap_start (b : Board) (s0 : State) (hk : capKey b s0 = true) : CapOK b s0 := by
  simp only [capKey, Bool.and_eq_true, List.all_eq_true] at hk
  intro k hlt
  have := hk.1 k (mem_upto _ _ hlt)
  exact Nat.le_of_ble_eq_true this

theorem cap_keep (b : Board) :
    ∀ s s' a, Act.legal b a = true → CapOK b s → step b s a = Res.ok s' → CapOK b s' := by
  intro s s' a _ hc h
  exact tank_cap b s s' a hc h

theorem cap_no_win (b : Board) (s0 : State) (hk : capKey b s0 = true) :
    ∀ s a, CapOK b s → step b s a ≠ Res.won := by
  intro s a hc hw
  obtain ⟨s', hp, hg⟩ := step_won_pre b s a hw
  have hc' := pre_cap b s s' a hc hp
  obtain ⟨c, t, ht, hm, he⟩ := goal_witness b s' hg
  simp only [capKey, Bool.and_eq_true, List.all_eq_true] at hk
  have hlt : capacity b c.zone < t.depths.lo := by
    have := hk.2 t ht c.zone (memN_mem _ _ hm)
    simpa [Nat.blt_eq] using this
  by_cases hin : c.zone < s'.levels.length
  · have := hc' c.zone hin
    omega
  · rw [getN_ge _ _ (by omega)] at he
    omega

/-- **钥匙二挂上骨架**：钥匙的前提成立，这个局面就赢不了（不经过「说不出话」那一支、不经过 RESET）。 -/
theorem unsolvable_by_capacity (b : Board) (s0 : State) (hk : capKey b s0 = true) :
    Unsolvable (World.mk b s0) := fun as hl =>
  unsolvable_of_invariant b (CapOK b) (cap_keep b) (cap_no_win b s0 hk) s0 (cap_start b s0 hk) as hl

#print axioms cap_start
#print axioms cap_keep
#print axioms cap_no_win
#print axioms unsolvable_by_capacity

end Game
