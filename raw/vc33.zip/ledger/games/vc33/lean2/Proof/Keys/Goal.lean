/-
# Proof/Keys/Goal —— 「赢了」拆开是什么（两把钥匙都从这里撞上目标）

`isGoal` 是 true，就一定找得到一对（光标 c, 目标 t）：t 是版面上的一段目标，
c 所在的槽贴着 t 那条隔条，而且那个槽的液面正好等于 t 的深度。
钥匙要证「赢不了」，就是证「这样的一对永远凑不出来」。
-/

import Obj.World
import Step
import Derived.Idx

namespace Game

theorem pairs_mem (b : Board) (cs : List Cursor) (c : Cursor) (t : Target) (h : (c, t) ∈ pairs b cs) :
    t ∈ b.targets := by
  induction cs with
  | nil => simp [pairs] at h
  | cons x xs ih =>
    simp only [pairs, List.mem_append, List.mem_map] at h
    rcases h with ⟨t', ht', e⟩ | h
    · simp only [Prod.mk.injEq] at e
      rw [← e.2]
      simp only [targetsOf, List.mem_filter] at ht'
      exact ht'.1
    · exact ih h

theorem goal_witness (b : Board) (s : State) (h : isGoal b s = true) :
    ∃ (c : Cursor) (t : Target), t ∈ b.targets ∧ memN c.zone (sides b t.band none) = true ∧
      getN s.levels c.zone = t.depths.lo := by
  unfold isGoal at h
  cases hp : pairs b s.cursors with
  | nil => rw [hp] at h; simp at h
  | cons p rest =>
    rw [hp] at h
    have hmem : p ∈ pairs b s.cursors := by rw [hp]; simp
    obtain ⟨c, t⟩ := p
    simp only [List.isEmpty_cons, Bool.not_false, Bool.true_and, List.all_cons, Bool.and_eq_true] at h
    unfold pairOK at h
    simp only [Bool.and_eq_true] at h
    exact ⟨c, t, pairs_mem b s.cursors c t hmem, h.1.2, Nat.eq_of_beq_eq_true h.1.1⟩

#print axioms pairs_mem
#print axioms goal_witness

end Game
