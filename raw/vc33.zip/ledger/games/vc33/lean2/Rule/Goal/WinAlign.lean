/-
# Rule/Goal/WinAlign —— 规则 win_align（对应 `rule/什么算赢什么算砸/win_align.py`）

**定义：「赢」是一个局面的性质，不是一个事件。**

    isGoal  ⟺  至少有一对（同色的光标与目标），而且每一对都到位：
               光标所在的槽液面 = 目标深度，并且那个槽贴着嵌目标的那条隔条

「碰到一起就赢」不是一件要去证的事，它就是赢的定义。
-/

import Obj.World
import Obj.Derive.Layout
import Obj.Derive.Goal

namespace Game

def pairOK (b : Board) (s : State) (p : Cursor × Target) : Bool :=
  Nat.beq (getN s.levels p.1.zone) p.2.depths.lo && memN p.1.zone (sides b p.2.band none)

def isGoal (b : Board) (s : State) : Bool :=
  !(pairs b s.cursors).isEmpty && (pairs b s.cursors).all (pairOK b s)

end Game
