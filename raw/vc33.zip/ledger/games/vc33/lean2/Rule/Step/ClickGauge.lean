/-
# Rule/Step/ClickGauge —— 规则 click_gauge（对应 `rule/一步怎么走/click_gauge.py`）

**定义。** 点在一段量规上：

    它亮着 ⇒ 隔条两侧（盖得住它的那两个槽）里的**每一个**光标整套搬进对岸那个槽，在那里居中；液面不动
    暗着   ⇒ 原样

一个光标时这就是「搬运」，两个时恰好是「对调」——册子里是两条，这里是一句。
`none` = 说不出话：两侧不是恰好两个槽，或者某一套比对岸的槽还宽（语料里 0 次，不猜）。
-/

import Obj.World
import Obj.Derive.Layout
import Obj.Derive.Gauge
import Obj.Derive.Move

namespace Game

/-- 一个光标：住在 `z0` 就送到 `z1`，住在 `z1` 就送到 `z0`，别处不动。塞不下给 `none`。 -/
def sendOver (b : Board) (z0 z1 : Nat) (c : Cursor) : Option Cursor :=
  if Nat.beq c.zone z0 || Nat.beq c.zone z1 then
    let dst := if Nat.beq c.zone z0 then z1 else z0
    match nth b.zones dst with
    | none => none
    | some z =>
      if Nat.blt z.lanes.size c.width then none
      else some { c with zone := dst, lane := landLane b dst c.width }
  else some c

def sendAll (b : Board) (z0 z1 : Nat) : List Cursor → Option (List Cursor)
  | [] => some []
  | c :: cs =>
    match sendOver b z0 z1 c, sendAll b z0 z1 cs with
    | some c', some cs' => some (c' :: cs')
    | _, _ => none

def clickGauge (b : Board) (s : State) (i : Nat) : Option State :=
  match nth b.gauges i with
  | none => none
  | some g =>
    match sides b g.band (some g.depths) with
    | [z0, z1] =>
      if aligned b s i then
        match sendAll b z0 z1 s.cursors with
        | none => none
        | some cs => some { s with cursors := sortC cs }
      else some s
    | _ => none

end Game
