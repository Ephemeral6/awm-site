/-
# Rule/Step/ClickNoop —— 规则 click_noop（对应 `rule/一步怎么走/click_noop.py`）

**定义。** 点在既不是按钮、也不是量规的地方（包括盘面外的边框）：局面原样。
（顶栏会涨，但顶栏不进模型。）

它短，但它是一句会被驳倒的话：Python 那边它在 21 行上开口；
这里 `step` 在那些行上算出「原样」，逐条核对要看到下一帧真的原样。
-/

import Obj.World

namespace Game

def clickNoop (s : State) : State := s

end Game
