/-
# Rule/Step/PressButton —— 规则 press_button（对应 `rule/一步怎么走/press_button.py`）

**这是一条定义，不是一条定理。** 「点按钮会怎样」就是这样定义的；
证它等于用它自己证它自己。

    得到方 = 按钮所在的槽，失去方 = 隔着按钮贴的那条隔条、深度盖得住按钮的对岸那个槽，
    搬运量 = 那条隔条的厚度。
    失去方能搬走的（液面 − 起算深度）不够一个厚度  ⇒ 整次作废（原样）
    得到方加上一个厚度会超过容量                    ⇒ 整次作废（原样）
    否则                                            ⇒ 得到方 + 厚度、失去方 − 厚度

`none` = 模型说不出话（按钮对家读不出唯一答案）。

头三道是**形状守卫**：得到方和失去方不是同一个槽、两者都在液面表的范围里。
在读得出来的盘上它们恒真（液面表和槽表一样长、对家从不是自己）；写进来是为了让
推论那两条（`Derived/FlowConserved.lean`、`Derived/TankCap.lean`）的证明不必另证这件事。
-/

import Obj.World
import Obj.Derive.Layout

namespace Game

def pressWith (b : Board) (s : State) (gain lose st : Nat) : Option State :=
  if gain = lose then none
  else if s.levels.length ≤ gain then none
  else if s.levels.length ≤ lose then none
  else if getN s.levels lose - zoneLo b lose < st then some s
  else if capacity b gain < getN s.levels gain + st then some s
  else some { s with levels := bump (bump s.levels gain (· + st)) lose (· - st) }

def pressButton (b : Board) (s : State) (i : Nat) : Option State :=
  match buttonPair b i with
  | none => none
  | some (gain, lose, bi) => pressWith b s gain lose (thick b bi)

end Game
