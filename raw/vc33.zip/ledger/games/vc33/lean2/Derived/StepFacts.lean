/-
# Derived/StepFacts —— 拆开 `step` 的三句话（推论那几条与钥匙都从这里起手）

    step_ok_pre     step 走成一个局面 ⇒ 分发给出的就是那个局面
    step_won_pre    step 说赢了      ⇒ 分发给出的那个局面是到位的
    pre_cases       分发给出的局面，要么原样（点空 / 盘外），要么是按钮那一下的结果，要么是量规那一下的结果

它们只是把 `Step.lean` 的三行分发拆开说，不带任何新主张。
-/

import Obj.World
import Step

namespace Game

theorem step_ok_pre (b : Board) (s s' : State) (a : Act) (h : step b s a = .ok s') : pre b s a = some s' := by
  unfold step at h
  cases hx : pre b s a with
  | none => rw [hx] at h; simp [finish] at h
  | some y =>
    rw [hx] at h
    by_cases hg : isGoal b y = true
    · simp [finish, hg] at h
    · simp [finish, hg] at h
      rw [h]

theorem step_won_pre (b : Board) (s : State) (a : Act) (h : step b s a = .won) :
    ∃ s', pre b s a = some s' ∧ isGoal b s' = true := by
  unfold step at h
  cases hx : pre b s a with
  | none => rw [hx] at h; simp [finish] at h
  | some y =>
    rw [hx] at h
    by_cases hg : isGoal b y = true
    · exact ⟨y, rfl, hg⟩
    · simp [finish, hg] at h

theorem pre_cases (b : Board) (s s' : State) (a : Act) (h : pre b s a = some s') :
    s' = s ∨ (∃ i, pressButton b s i = some s') ∨ (∃ i, clickGauge b s i = some s') := by
  cases a with
  | off => simp [pre, clickNoop] at h; exact Or.inl h.symm
  | click l d =>
    simp only [pre] at h
    split at h
    · exact Or.inr (Or.inl ⟨_, h⟩)
    · exact Or.inr (Or.inr ⟨_, h⟩)
    · simp [clickNoop] at h; exact Or.inl h.symm

#print axioms step_ok_pre
#print axioms step_won_pre
#print axioms pre_cases

end Game
