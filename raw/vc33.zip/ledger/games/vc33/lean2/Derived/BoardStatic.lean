/-
# Derived/BoardStatic —— 规则 board_static 在这一层的样子：**表示不出来**

Python 那边 board_static 是一条每步都判的规则（538 行里开口 517 次、全部判对）：同一关里版面一样都不变。
在这里它**不是一条要证的定理**，是 `step` 的类型：

    step : Board → State → Act → Res        Res 里只有 State，没有 Board 的位置

「走一步版面变了」这句话写不出来。所以它的身份是**推论（由架构推出）**，理由就是上面那一行类型。

下面这条定理是那句话的**全部内容**：照着一串动作走，每一步用的都是同一个 `b`。
它是 `rfl`，**它不可能失败**——除非有人改了 `step` 的签名、让它能返回一张新版面，那时它当场编不过。
**这一条不算「会失败的形式化」**，它是一处架构的见证；真正核「版面没变」的是观测那一侧：
`Obs/Check.agrees` 在同一关的每一步上连版面一起比，`Obs/Corpus.lean` 的 `corpus_reconciled` 把 516 行都核了。
-/

import Obj.World
import Step

namespace Game

theorem board_static (b : Board) (s : State) (a : Act) (as : List Act) :
    everWon b s (a :: as) =
      (match step b s a with
       | .won => true
       | .ok s' => everWon b s' as
       | .na => false) := rfl

#print axioms board_static

end Game
