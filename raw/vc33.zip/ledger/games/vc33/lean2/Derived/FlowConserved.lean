/-
# Derived/FlowConserved —— 推论：点一下，所有槽的液面之和不变

册子里这是一条每步都判的概念（flow_conserved，撤册前的读数：538 行里开口 516 次、全部判对、判错 0）。
卡 05 把它撤了：它**不是一条独立的规则**——按钮那一下的定义（`Rule/Step/PressButton.lean`）里
「得到方 + 厚度、失去方 − 厚度」已经把它说完了，点量规和点空地不动液面。
能证出来的，就不该每帧去测。下面就是那个证明：对**所有**版面、**所有**局面、**所有**动作成立，没有枚举。

这条定理**会失败**：把按钮那一下改成「得到方 + 厚度 + 1」，`pressWith_sum` 当场证不出来。
-/

import Obj.World
import Step
import Derived.Idx
import Derived.StepFacts

namespace Game

theorem pressWith_sum (b : Board) (s s' : State) (gain lose st : Nat)
    (h : pressWith b s gain lose st = some s') : sumL s'.levels = sumL s.levels := by
  unfold pressWith at h
  split at h
  · cases h
  rename_i h1
  split at h
  · cases h
  rename_i h2
  split at h
  · cases h
  rename_i h3
  split at h
  · cases h; rfl
  rename_i h4
  split at h
  · cases h; rfl
  rename_i h5
  cases h
  show sumL (bump (bump s.levels gain (· + st)) lose (· - st)) = sumL s.levels
  have hl1 : lose < (bump s.levels gain (· + st)).length := by rw [bump_length]; omega
  have e2 := sumL_bump (bump s.levels gain (· + st)) lose (· - st) hl1
  have e1 := sumL_bump s.levels gain (· + st) (by omega)
  have g2 : getN (bump s.levels gain (· + st)) lose = getN s.levels lose :=
    getN_bump_ne s.levels gain lose (· + st) (fun e => h1 e.symm)
  rw [g2] at e2
  try simp only at e1 e2
  omega

theorem pressButton_sum (b : Board) (s s' : State) (i : Nat)
    (h : pressButton b s i = some s') : sumL s'.levels = sumL s.levels := by
  unfold pressButton at h
  split at h
  · cases h
  · exact pressWith_sum b s s' _ _ _ h

theorem clickGauge_levels (b : Board) (s s' : State) (i : Nat)
    (h : clickGauge b s i = some s') : s'.levels = s.levels := by
  unfold clickGauge at h
  split at h
  · cases h
  · split at h
    · split at h
      · split at h
        · cases h
        · cases h; rfl
      · cases h; rfl
    · cases h

/-- 分发给出的局面，液面之和不变。 -/
theorem pre_sum (b : Board) (s s' : State) (a : Act) (h : pre b s a = some s') :
    sumL s'.levels = sumL s.levels := by
  rcases pre_cases b s s' a h with e | ⟨i, hp⟩ | ⟨i, hg⟩
  · rw [e]
  · exact pressButton_sum b s s' i hp
  · rw [clickGauge_levels b s s' i hg]

/-- **推论：点一下（`step` 走成一个局面），所有槽的液面之和不变。** -/
theorem flow_conserved (b : Board) (s s' : State) (a : Act) (h : step b s a = .ok s') :
    sumL s'.levels = sumL s.levels :=
  pre_sum b s s' a (step_ok_pre b s s' a h)

#print axioms pressWith_sum
#print axioms pressButton_sum
#print axioms clickGauge_levels
#print axioms pre_sum
#print axioms flow_conserved

end Game
