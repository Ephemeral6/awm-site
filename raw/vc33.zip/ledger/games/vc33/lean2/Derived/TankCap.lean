/-
# Derived/TankCap —— 推论：液面从没超过容量的局面，点一下之后还是没超过

册子里这是一条每步都判的概念（tank_cap，撤册前的读数：538 行里开口 517 次、全部判对、判错 0）。
卡 05 把它撤了：按钮那一下的定义里「得到方加上一个厚度会超过容量 ⇒ 整次作废」已经把它说完了。

    CapOK b s  :=  每个槽的液面 ≤ 它的容量

「每一帧都没超」在语料上是 517 次观察；这里是**对所有局面**的一句话：从 CapOK 的局面出发，
`step` 走出来的局面还是 CapOK。它**会失败**：把按钮那一下的容量闸拿掉（Python 那边的源码变异
「容量不看墙高」就是这一刀），得到方那一格证不出来。
-/

import Obj.World
import Step
import Derived.Idx
import Derived.StepFacts
import Derived.FlowConserved

namespace Game

def CapOK (b : Board) (s : State) : Prop := ∀ k, k < s.levels.length → getN s.levels k ≤ capacity b k

theorem pressWith_cap (b : Board) (s s' : State) (gain lose st : Nat)
    (hc : CapOK b s) (h : pressWith b s gain lose st = some s') : CapOK b s' := by
  unfold pressWith at h
  split at h
  · cases h
  rename_i h1
  split at h
  · cases h
  rename_i h2
  split at h
  · cases h
  rename_i h3
  split at h
  · cases h; exact hc
  rename_i h4
  split at h
  · cases h; exact hc
  rename_i h5
  cases h
  intro k hk
  show getN (bump (bump s.levels gain (· + st)) lose (· - st)) k ≤ capacity b k
  have len1 : (bump s.levels gain (· + st)).length = s.levels.length := bump_length _ _ _
  have hk' : k < s.levels.length := by
    have : (bump (bump s.levels gain (· + st)) lose (· - st)).length = s.levels.length := by
      rw [bump_length, len1]
    simp only at hk
    omega
  by_cases hkl : k = lose
  · subst hkl
    rw [getN_bump_eq _ _ _ (by rw [len1]; omega),
        getN_bump_ne s.levels gain k (· + st) (fun e => h1 e.symm)]
    have := hc k hk'
    try simp only
    omega
  · rw [getN_bump_ne _ lose k _ hkl]
    by_cases hkg : k = gain
    · subst hkg
      rw [getN_bump_eq _ _ _ hk']
      try simp only
      omega
    · rw [getN_bump_ne _ gain k _ hkg]
      exact hc k hk'

theorem pressButton_cap (b : Board) (s s' : State) (i : Nat)
    (hc : CapOK b s) (h : pressButton b s i = some s') : CapOK b s' := by
  unfold pressButton at h
  split at h
  · cases h
  · exact pressWith_cap b s s' _ _ _ hc h

theorem pre_cap (b : Board) (s s' : State) (a : Act) (hc : CapOK b s) (h : pre b s a = some s') :
    CapOK b s' := by
  rcases pre_cases b s s' a h with e | ⟨i, hp⟩ | ⟨i, hg⟩
  · rw [e]; exact hc
  · exact pressButton_cap b s s' i hc hp
  · have e := clickGauge_levels b s s' i hg
    intro k hk
    rw [e] at hk ⊢
    exact hc k hk

/-- **推论：液面从没超过容量的局面，`step` 走一步之后还是没超过。** -/
theorem tank_cap (b : Board) (s s' : State) (a : Act) (hc : CapOK b s) (h : step b s a = .ok s') :
    CapOK b s' :=
  pre_cap b s s' a hc (step_ok_pre b s s' a h)

#print axioms pressWith_cap
#print axioms pressButton_cap
#print axioms pre_cap
#print axioms tank_cap

end Game
