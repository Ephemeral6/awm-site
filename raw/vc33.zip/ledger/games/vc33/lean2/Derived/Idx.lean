/-
# Derived/Idx —— 关于「按下标改一格」的四条引理

推论那两条（液面之和不变、液面不超容量）都要从「按钮那一下 = 改两格」推出来，
而「改两格之后和是多少、别的格变没变」是这里这四句话。它们只讲列表，不讲这一局——
所以语句里没有 `World` / `step`；它们不是这一局的主张，是推论要用的算术。
（`ledger/lean_check.py` 会因此报「语句里一个对象层的名字都没出现」——这一份在 verify.py 的豁免表里，理由即此。）
-/

import Obj.World

namespace Game

theorem bump_length (l : List Nat) (n : Nat) (f : Nat → Nat) : (bump l n f).length = l.length := by
  induction l generalizing n with
  | nil => rfl
  | cons x xs ih => cases n <;> simp [bump, ih]

theorem getN_bump_ne (l : List Nat) (n m : Nat) (f : Nat → Nat) (h : m ≠ n) :
    getN (bump l n f) m = getN l m := by
  induction l generalizing n m with
  | nil => rfl
  | cons x xs ih =>
    cases n with
    | zero => cases m with
      | zero => exact absurd rfl h
      | succ m => rfl
    | succ n => cases m with
      | zero => rfl
      | succ m => exact ih n m (by omega)

theorem getN_bump_eq (l : List Nat) (n : Nat) (f : Nat → Nat) (h : n < l.length) :
    getN (bump l n f) n = f (getN l n) := by
  induction l generalizing n with
  | nil => simp at h
  | cons x xs ih =>
    cases n with
    | zero => rfl
    | succ n => exact ih n (by simp at h; omega)

theorem sumL_bump (l : List Nat) (n : Nat) (f : Nat → Nat) (h : n < l.length) :
    sumL (bump l n f) + getN l n = sumL l + f (getN l n) := by
  induction l generalizing n with
  | nil => simp at h
  | cons x xs ih =>
    cases n with
    | zero => simp [bump, sumL, getN]; omega
    | succ n =>
      have := ih n (by simp at h; omega)
      simp [bump, sumL, getN]; omega

theorem memN_mem (n : Nat) (l : List Nat) (h : memN n l = true) : n ∈ l := by
  induction l with
  | nil => simp [memN] at h
  | cons x xs ih =>
    simp only [memN, Bool.or_eq_true] at h
    rcases h with h | h
    · have := Nat.eq_of_beq_eq_true h
      subst this
      exact List.mem_cons_self
    · exact List.mem_cons_of_mem _ (ih h)

/-- 加上一个 `T` 的倍数，模 `T` 不变。 -/
theorem add_res (x st T : Nat) (h : st % T = 0) : (x + st) % T = x % T := by
  rw [Nat.add_mod, h, Nat.add_zero, Nat.mod_mod]

/-- 减掉一个（不比它大的）`T` 的倍数，模 `T` 不变。 -/
theorem sub_res (x st T : Nat) (h : st % T = 0) (hx : st ≤ x) : (x - st) % T = x % T := by
  have e := add_res (x - st) st T h
  rw [Nat.sub_add_cancel hx] at e
  exact e.symm

theorem getN_ge (l : List Nat) (k : Nat) (h : l.length ≤ k) : getN l k = 0 := by
  induction l generalizing k with
  | nil => rfl
  | cons x xs ih =>
    cases k with
    | zero => simp at h
    | succ k => exact ih k (by simp at h; omega)

theorem mem_upto (n k : Nat) (h : k < n) : k ∈ upto n := by
  induction n with
  | zero => omega
  | succ n ih =>
    simp only [upto, List.mem_append, List.mem_singleton]
    by_cases hk : k = n
    · exact Or.inr hk
    · exact Or.inl (ih (by omega))

#print axioms getN_ge
#print axioms mem_upto
#print axioms bump_length
#print axioms getN_bump_ne
#print axioms getN_bump_eq
#print axioms sumL_bump
#print axioms memN_mem
#print axioms add_res
#print axioms sub_res

end Game
