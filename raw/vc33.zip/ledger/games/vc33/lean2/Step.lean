/-
# Step —— 一步怎么走：**只做分发，0 条定理**

点中了什么（`hit`），就交给哪一条规则；规则给出点完的局面（`pre`），到位了就是 `won`（`finish`）。

    按钮     → press_button
    量规     → click_gauge
    别处     → click_noop
    盘面外   → click_noop

`na`（模型说不出话）**不是** `ok`：一条永远闭嘴的规则不许显得永远正确。
RESET 不是 `Act`：「重来之后是哪一帧」是历史，模型不描述（明写的假设见 `Proof/Levels/`）。
-/

import Obj.World
import Obj.Derive.Hit
import Rule.Step.PressButton
import Rule.Step.ClickGauge
import Rule.Step.ClickNoop
import Rule.Goal.WinAlign

namespace Game

/-- 分发：点完之后的局面（`none` = 说不出话）。 -/
def pre (b : Board) (s : State) : Act → Option State
  | .off => some (clickNoop s)
  | .click l d =>
    match hit b ⟨l, d⟩ with
    | .button i => pressButton b s i
    | .gauge i => clickGauge b s i
    | .elsewhere => some (clickNoop s)

/-- 到位了就是 `won`（规则 win_align 的定义 `isGoal`）。 -/
def finish (b : Board) : Option State → Res
  | none => .na
  | some s => if isGoal b s then .won else .ok s

def step (b : Board) (s : State) (a : Act) : Res := finish b (pre b s a)

/-- 从 `s` 起照着 `as` 走，中途赢过没有。`na` 那一支返回 `false`——
    所以「赢不了」这句话的准确意思永远是「**不经过模型说不出话的那一支**就赢不了」。 -/
def everWon (b : Board) : State → List Act → Bool
  | _, [] => false
  | s, a :: as =>
    match step b s a with
    | .won => true
    | .ok s' => everWon b s' as
    | .na => false

end Game
