/-
# Check —— **判据层**：两把尺子，0 条定理（尺子不自证）

    agrees      **一条转移**对不对：拿观测到的那一帧起算一步，和看到的下一帧比
    traceOk     **一整条路**对不对：只有开局是观测给的，后面全拿模型**自己算出来的**状态往下走

两把尺子的分量差得很远：`agrees` 每一步都被观测拉回正轨，`traceOk` 错一步后面全错。
一个「每步单独看都对、走两步就和现实分家」的模型，在前者满分，在后者过不了。

尺子都把 `step` 当参数收进来：语句里写的是 `traceOk step …`——量的是**这一个** `step`。

## 三值，不是两值

    yes  模型说的就是这样
    no   模型说的不是这样     ← 只有这一种是反例
    na   模型这一步说不出话（对家读不出，或这一步本来就不进模型：RESET）

`na` 不是 `yes`：两者混在一起，一条永远闭嘴的规则就会显得永远正确。
-/

import Obj.World
import Step

namespace Game

inductive Verdict where
  | yes
  | no
  | na
deriving Repr, DecidableEq

/-- 观测到的下一帧是什么：同一关里的一个局面（连同那一帧读到的版面）/ 换关了（下一帧是另一张盘）/
    这一步模型不描述（RESET）。 -/
inductive Seen where
  | same (ob : Board) (o : State)
  | leveled
  | skip
deriving Repr, DecidableEq

/-- 版面也在比：模型的 `step` 碰不到版面（它的结果里没有 `Board` 的位置），
    所以观测到版面变了，就是模型被驳倒了——规则 board_static 在逐条这一层就是这一个合取项。 -/
def agrees (f : Board → State → Act → Res) (b : Board) (s : State) (a : Act) : Seen → Verdict
  | .skip => .na
  | .leveled =>
    match f b s a with
    | .won => .yes
    | .na => .na
    | .ok _ => .no
  | .same ob o =>
    match f b s a with
    | .ok s' => if s' = o ∧ ob = b then .yes else .no
    | .won => .no
    | .na => .na

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。全对才是 `true`。
    **要害在那个 `s'`**：下一轮喂进去的是模型自己算出来的状态，不是观测到的那一帧。 -/
def traceOk (f : Board → State → Act → Res) (b : Board) : State → List (Act × State) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match f b s a with
    | .ok s' => decide (s' = o) && traceOk f b s' rest
    | _ => false

/-- 沿 `play` 一步不差地走了几步（遇到第一处分家就停）。**它是 `_len` 那条定理的主语**：
    切片切歪成空表时 `traceOk` 平凡为真，而这个数会是 0。 -/
def walked (f : Board → State → Act → Res) (b : Board) : State → List (Act × State) → Nat
  | _, [] => 0
  | s, (a, o) :: rest =>
    match f b s a with
    | .ok s' => if s' = o then walked f b s' rest + 1 else 0
    | _ => 0

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (f : Board → State → Act → Res) (b : Board) : State → List (Act × State) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match f b s a with
    | .ok s' => if s' = o then firstSplit f b s' rest (i + 1) else some i
    | _ => some i

end Game
