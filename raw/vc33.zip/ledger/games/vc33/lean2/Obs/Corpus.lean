/-
# Corpus —— 逐条那一层 + 与规则那一份的逐条对账（`lean2/export_corpus.py` 生成，不要手改）

每一行都从**观测到的那一帧**起算一步（`agrees step …`），和看到的下一帧比（局面 + 版面）。
这一层每一步都被观测拉回正轨，所以它比每关那一层（`Proof/Levels/`）弱；它强在**每一行都核到**。

`expected` 是规则那一份（Python）对每一行的判决翻译成的三值（翻译表见生成器文件头）。
`corpus_reconciled` 说「内核自己算出来的 538 个判决，和规则那一份逐行相等」——
**一行对不上这一份就编不过**。下面三条计数是同一件事的读数版，也走内核。

`#eval` 那几行是读数（走求值器，不进可信基）；结论只认定理。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay

namespace Game
namespace Corpus

open Replay

def verdictOf (f : Board → State → Act → Res) (r : Row) : Verdict :=
  agrees f (boardAt r.board) (stateAt r.pre) r.act (seenOf r)

def countV (f : Board → State → Act → Res) (v : Verdict) : List Row → Nat
  | [] => 0
  | r :: rs => (if verdictOf f r = v then 1 else 0) + countV f v rs


/-- 规则那一份对每一行的判决（翻译成三值），538 行，按 Replay.rows 的顺序。 -/
def expected : List Verdict := [.yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .na, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .na, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .na, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes, .yes]

set_option maxRecDepth 200000

/-- **两份现役逐条对账**：内核自己算的每一行判决 = 规则那一份的判决。 -/
theorem corpus_reconciled : Replay.rows.map (verdictOf step) = expected := by decide +kernel

#print axioms corpus_reconciled

/-- 模型被这批语料驳倒的行数：0。 -/
theorem corpus_no : countV step .no Replay.rows = 0 := by decide +kernel

#print axioms corpus_no

/-- 模型说对了的行数。 -/
theorem corpus_yes : countV step .yes Replay.rows = 535 := by decide +kernel

#print axioms corpus_yes

/-- 模型说不出话（或这一行本来不进模型：RESET）的行数。 -/
theorem corpus_na : countV step .na Replay.rows = 3 := by decide +kernel

#print axioms corpus_na

#eval "CORPUS yes=" ++ toString (countV step .yes Replay.rows) ++ " no=" ++ toString (countV step .no Replay.rows) ++ " na=" ++ toString (countV step .na Replay.rows)


end Corpus
end Game
