"""点面板上那张 36 像素的色2 卡（第3关）：地图上两条 16 像素宽的横带（行20-21 列8-23、行40-41 列16-31）各沿
「全开(纯色5) → 边框2 → 边框4 → 边框6 → 全闭(纯色12)」这条五档轨道**恰好走一档**，两条永远反向、档位之和恒等于 4；
中间档朝哪边走从单帧读不出，但「只走一档、反向、和守恒、边框对称、闭合是整条跳成色12」在中间档照样可判——
下一帧必须与两种候选画面之一逐像素相符（玩家 2×2 盖住的像素除外），否则 FALSE；在尽头只有一种候选。"""

LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色2、落在面板区（列>=42）、所在同色块恰好 36 像素（_lib.clicked_card + glyph_size）；"
         "ctx.level_prev 必须是 3 且不换关（level_prev == level_next），否则 NA——第4关那条单带、第5关那块 132 像素的色2 图形都不归这里管。"
         "两条带各按「与可见像素相容的唯一档位」读：`_lib.unreadable` 的像素（玩家色14、调用方标的负数哨兵）当未知，两行合并，"
         "五种档位画面（纯5 / 边框2 / 边框4 / 边框6 / 纯12，边框色1、缺口色5、左右对称）里恰好一种与可见像素相容才算读出；"
         "任一条读不出、或两条档位之和不是 4（不在轨道上互补）就 NA——这条概念只主张「从互补态点一下」之后的事。"
         "断言：把 prev 玩家 2×2 之外的两带 64 像素与两种候选（A 进一档 B 退一档 / A 退一档 B 进一档，越界的候选去掉）逐像素比，"
         "有一种全对就 TRUE，都不对就 FALSE。apply 只交两种候选一致的像素：尽头处是整条带（此时候选只有一种），"
         "中间档只有那些两种走向都不会碰的像素（它们与 prev 相同）——中间档里会变的像素，本概念一格都不押。")
NOTE = ("从两份语料合起来 1675 条去重转移里挑出第3关点这张卡的 16 条（两个 run 各 8 条），逐条把两带 prev/nxt 摆开看：\n"
        "两个 run 各自都是 4 次点击把 A 从全开推到全闭（B 反向）、再 4 次推回来，档位序列 A：0,1,2,3,4,3,2,1,0，B 恒等于 4-A。\n"
        "试过让中间档的走向变成可读的，全部失败：\n"
        "(1) 带子自身像素——同一档位的两帧逐像素完全相同（da7ffa846ab8294f 与 879555cb47f97d91 的 prev 都是 A=B=边框4，"
        "一个之后 A 收到 6、一个之后 A 松到 2）；\n"
        "(2) 帧上其他像素——把这对帧全帧相减，排掉玩家后只剩：色11 卡管的两条横条（行28-29/38-39）、两块垫子的花色相位"
        "（行24-25 列4-5、行32-33 列18-19）、HUD 行63 的色3 计数。它们各由别的动作驱动，跨 run 对照（a28abadd6c60b59b 与 da7ffa846ab8294f "
        "同为「A 正在收」，横条却在列12/8 与列10/6、垫子相位也相反）说明拿它们当方向标是巧合；HUD 计数按奇偶分也不成"
        "（正在收的两帧计数 2 与 9，正在松的 16 与 42）；\n"
        "(3) 面板上卡面自身——点击前后 12 行全同，八次点击一个像素都没变。\n"
        "settle 递的 ctx 只有 step/level/state，没有上一步，所以方向只能算隐藏状态。于是本概念把主张缩到方向之外仍然可判的那部分。\n"
        "EVIDENCE 只登记 run dc22-0916-1543 的 8 条；run dc22-0915-2238 的 8 条（d62bf04d4bd374c3 起）故意留在 held-out 里给 settle 考。"
        "第4关 gate_bounce 记的那条单带这里不管——本概念要求两条带互补，第4关只有一条。\n\n"
        "入册（原在 proposals/，settle 打 S=1.000 C=0.005 N=8 P=1.000/252格 之后挪进来）时加了一个 `apply_branches`：\n"
        "它把两种候选画面**都**交出去，给离场规划器当两条不同的边用。理由：`apply` 按册子的规矩只敢交两种候选一致的那些像素，"
        "而中间档两种候选一致的部分恰好等于 prev，于是规划器看到「点了等于没点」，第3关整条路当场断掉。\n"
        "诚实地写清代价：规划器沿哪一条分支走是**猜**的，世界走哪边这一帧读不出来；"
        "`apply_branches` 不进任何断言，只喂规划器。\n\n"
        "v2（只改 NOTE 与 EVIDENCE，断言与 apply 一个字没动）：入册时这里还写着"
        "「猜错了 `--strict` 也不会响（本概念在那些像素上正是弃权的），只会在下一批重新规划时被真帧纠正」。"
        "**这句话被终局卡第 779 步（a6b7d39f13392758）推翻了，退出码 5。**\n"
        "推翻的方式不是这条概念说错了话——恰恰相反，拿**真帧**喂它，那一步它押 32 格、32 格全对、`assert_` 判 TRUE。"
        "错的是「弃权是安全的」这个推论：弃权不只是让模型这一步少说几格，"
        "而是让模型手里那张**链式推演的帧就地冻住**——带子真的走了一档，模型的帧还停在原处。"
        "下一次点同一张卡，本概念从那张过期的帧上读出过期的档位（A=1 而不是真的 A=2），"
        "于是理直气壮地押出 16 格，错 8 格（行20-21 列12,13,18,19 押色5、实际色1）。\n"
        "所以「读不出方向」的代价比原先记的大一档：它不止让**这一步**不可预测，"
        "还让**这一步之后同一条链上的每一步**都不可预测，直到有人拿真帧把链接回去。"
        "修在离场的规划器里（`UNDETERMINED` 槽：把一批截在分叉那一步，下一批从真帧起手），不在这条概念里——"
        "这条概念该说的话没有变，变的是谁有资格把它的输出往下串。")
EVIDENCE = [
    "1c0403bc6ee54e3e", "364ab9b616a29384", "da7ffa846ab8294f", "d12a86fe6f5f294e",
    "f70878d63ea80d02", "86743600f08e549a", "879555cb47f97d91", "0db168e2300c04bc",
    "a6b7d39f13392758",   # 第 779 步：拿真帧押 32 格全对，推翻的是 NOTE 里「弃权就安全」那句话
]

from _lib import me, CELL, clicked_card, glyph_size, unreadable  # noqa: E402  本局词汇

BANDS = ((20, 8, 24), (40, 16, 32))     # (首行, 起始列, 结束列)，各两行、16 像素宽
NPOS = 5                                # 0=全开 .. 4=全闭
OPEN, EDGE, GAP, CLOSED = 5, 1, 5, 12


def _paint_row(pos, n):
    if pos == 0:
        return [OPEN] * n
    if pos == NPOS - 1:
        return [CLOSED] * n
    e = pos * 2
    return [EDGE] * e + [GAP] * (n - 2 * e) + [EDGE] * e


def _read_pos(g, r, c0, c1):
    """与可见像素相容的唯一档位；读不出的像素（`unreadable`）当未知；两行冲突、或相容档位不唯一都返回 None。"""
    n = c1 - c0
    merged = []
    for c in range(c0, c1):
        a, b = g[r][c], g[r + 1][c]
        a = None if unreadable(a) else a
        b = None if unreadable(b) else b
        if a is None:
            merged.append(b)
        elif b is None or a == b:
            merged.append(a)
        else:
            return None
    fits = [p for p in range(NPOS)
            if all(v is None or v == w for v, w in zip(merged, _paint_row(p, n)))]
    return fits[0] if len(fits) == 1 else None


def _clicked(g, action):
    if not clicked_card(g, action, 2):
        return False
    c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    return glyph_size(g, r, c) == 36


def _player_px(g):
    a = me(g)
    return {(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)} if a else set()


def _candidates(g):
    """两种候选画面的列表；读不出、不互补返回 None。每个候选是 {(r,c): 色}，已去掉玩家像素。"""
    pos = [_read_pos(g, r, c0, c1) for (r, c0, c1) in BANDS]
    if any(p is None for p in pos) or pos[0] + pos[1] != NPOS - 1:
        return None
    px = _player_px(g)
    out = []
    for d in (+1, -1):
        pa, pb = pos[0] + d, pos[1] - d
        if not (0 <= pa < NPOS and 0 <= pb < NPOS):
            continue
        cand = {}
        for (r, c0, c1), p in zip(BANDS, (pa, pb)):
            row = _paint_row(p, c1 - c0)
            for rr in (r, r + 1):
                for i, c in enumerate(range(c0, c1)):
                    if (rr, c) not in px:
                        cand[(rr, c)] = row[i]
        out.append(cand)
    return out or None


def _in_scope(prev, action, ctx):
    if not _clicked(prev, action):
        return False
    if not ctx or ctx.get("level_prev") != 3:
        return False
    if "level_next" in ctx and ctx.get("level_next") not in (None, 3):
        return False
    return True


def assert_(prev, action, nxt, ctx=None):
    if not _in_scope(prev, action, ctx):
        return "NA"
    cands = _candidates(prev)
    if cands is None:
        return "NA"
    for cand in cands:
        if all(nxt[r][c] == v for (r, c), v in cand.items()):
            return "TRUE"
    return "FALSE"


def apply(prev, action, ctx=None):
    if not _in_scope(prev, action, ctx):
        return None
    cands = _candidates(prev)
    if cands is None:
        return None
    first = cands[0]
    agreed = {k: v for k, v in first.items() if all(c.get(k) == v for c in cands[1:])}
    return agreed or None


def apply_branches(prev, action, ctx=None):
    """**给离场规划器用，不进任何断言**：下一帧不唯一时，把全部候选画面列出来。

    返回 [{(行,列): 色}, ...]，每一项是一整张候选的带子画面；本概念说不出世界会走哪一条，
    只说得出「一定是其中之一」。规划器把每一条当成一条独立的边展开，猜错由下一批从真帧重新规划纠正。
    不在 scope、读不出档位时返回 None。
    """
    if not _in_scope(prev, action, ctx):
        return None
    return _candidates(prev)
