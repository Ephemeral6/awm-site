"""点面板上那张色8 的卡：地图上那只 8×8 的色8 空心方框，若它正中央那 2×2 咬着色12（件）**且它里圈那一周 4×4 正好落在件身上那 12 个色8 像素上**，整圈就朝里收 1 像素——里面那 6×6 除正中 2×2 外全变成色8、正中 2×2 仍是色12（这就是「合了口的夹子」），方框原来那 8×8 一圈让开、露出底下的东西；正中 2×2 不是色12 时，地图区一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色8、落在面板区（列>=42）、所在同色块至少 8 像素"
         "（面板上那张色8 卡；四色图标里 2×2 的色8 象限被这一条筛掉）；换关返回 NA；"
         "全帧里找不到唯一一只「一周边框全是色8」的 8×8 方框（`_lib.box_ring`）返回 NA"
         "（合口之后场上只剩那块 6×6 的夹子，围不出 8×8 的一周，这条概念对它无话可说，归 clamped_piece_slides 管）；"
         "**正中 2×2 咬着色12、但里圈那一周 4×4 不全是色8 时返回 NA**——见 NOTE，那种局面语料里一次都没有，"
         "「咬住就合口」和「套准了才合口」拿现有证据分不开，这里选后者（不外推）；"
         "**让开的那一圈（方框原来那 28 个像素）露出什么不管**，底下是什么这一帧上看不见；"
         "断言范围是地图区（行<62、列<42）；prev 或 nxt 里是玩家色14 的像素跳过（玩家站得上件）。")
NOTE = ("v2: 两处改动。\n"
        "(1) 认方框改用 `_lib.box_ring`（一周边框全是色8 的 8×8），不再按「28 像素的连通块」认——"
        "方框推到件跟前的路上有一格会和件身上那一小圈色8 贴成一块（zmerge.out），旧读法在那儿返回 None。\n"
        "(2) 收窄合口的条件。v1 只要求「正中 2×2 是色12」就宣布合口，那是外推——\n"
        "两次合口时方框都停在同一处（行30-37 列6-13），而那一处的特别之处不止「正中咬着色12」：\n"
        "件身上本来就有一圈 12 像素的色8（行32-35 列8-11 的 4×4 周边，芯是色12），方框恰好套在它外面一圈。\n"
        "合口之后那块 32 像素（行31-36 列7-12 去掉正中 2×2）正是「旧的 12 像素 + 新变的 20 像素」，\n"
        "也就是方框和件身上那圈**并成了一块**。换句话说，两种读法在语料上分不开：\n"
        "(a) 正中咬着色12 就合口；(b) 里圈套准了件身上那圈色8 才合口。选 (b)，因为它一个坐标都不含，\n"
        "而且 clamped_piece_slides 自己就要求「地图区只剩一块色8」——套不准就会剩两块，那条概念当场认不出夹子，\n"
        "两条读法在册子里本来就该一致。以后哪天方框没套准也合了口，这条当场被打掉，那时换成 (a)。\n"
        "实测（zclamp.out）方框推到行30 列14 时正中 2×2 也是色12（压在件的一条胳膊上），\n"
        "v1 会在那儿宣布合口——规划器于是按一只根本不存在的夹子往下推，和 l4_card8_closes_clamp v1 犯的是同一个错。\n\n"
        "v1: 第 594 步（61b7a270d923829e）与第 1016 步（de4922528e0a9249）各有一次，两次一模一样："
        "方框在行30-37 列6-13，正中 2×2（行33-34 列9-10）是件的色12，点色8 卡之后帧差 48 格——"
        "行31-36 列7-12 除正中 2×2 外全成了色8（新变的 20 格），方框原来那 28 个像素让开，"
        "露出件的色12（行30 与行37 的列7-12、行32-35 的列6 与列13）与色4 的墙。"
        "另外五次点同一张卡地图区一格没动（a76a1eee5c3989a4、c452db2d17ba5a95、5e748ddd051a0c96、"
        "e68204410f94f0ce、6e5f320cefcc9c75），那几次方框的正中 2×2 都不是色12。"
        "为什么现在才写：规划器在第 6 关的真解是「把方框推到件上 → 点色8 卡合口 → 点亮着的菱形搬着件走」，"
        "中间这一下册子从来没说过，于是搜索里「合口」这件事压根不会发生——clamped_piece_slides 要等合了口才开口，"
        "lit_diamond_moves_box 只会推方框，两条概念中间断了一环。")
EVIDENCE = ["61b7a270d923829e", "de4922528e0a9249",
            "a76a1eee5c3989a4", "c452db2d17ba5a95", "5e748ddd051a0c96",
            "e68204410f94f0ce", "6e5f320cefcc9c75"]

from _lib import MAP_ROWS, PANEL_COL0, clicked_card, box_ring

BOX_PX = 28           # 8×8 空心方框的边框像素数
SIDE = 8              # 方框外接框边长
BITE = 12             # 口里咬着的那一色（件）
JAW = 8               # 夹子/方框的颜色
PLAYER = 14


def _box(g):
    """那只 8×8 的色8 空心方框的一周边框像素；认不出返回 None。
    和 `lit_diamond_moves_box._box` 同一眼（`_lib.box_ring`）：按形状认不按连通块大小认，
    因为方框贴上件身上那一小圈色8 时两者会并成一块（zmerge.out）。"""
    return box_ring(g)


def _inner_ring(b):
    """方框里圈那一周 4×4（相对左上角 +2..+5 的边）：合口那两次，件身上那 12 个色8 正好在这里。"""
    r0, c0 = min(r for r, _ in b), min(c for _, c in b)
    return {(r0 + 2 + i, c0 + 2 + j) for i in range(4) for j in range(4)
            if i in (0, 3) or j in (0, 3)}


def _centre(b):
    r0, c0 = min(r for r, _ in b), min(c for _, c in b)
    return {(r0 + 3 + i, c0 + 3 + j) for i in range(2) for j in range(2)}


def _jaws(b):
    """收拢之后那块夹子占的像素：方框里面那 6×6 去掉正中 2×2。"""
    r0, c0 = min(r for r, _ in b), min(c for _, c in b)
    inner = {(r0 + 1 + i, c0 + 1 + j) for i in range(SIDE - 2) for j in range(SIDE - 2)}
    return inner - _centre(b)


def _bites(g, b):
    """正中 2×2 咬着件的色12。"""
    return all(g[r][c] == BITE for r, c in _centre(b))


def _seated(g, b):
    """套准了：里圈那一周 4×4 全是色8（件身上那一小圈正好嵌在方框里面一圈）。"""
    return all(g[r][c] == JAW for r, c in _inner_ring(b))


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, JAW):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    b = _box(prev)
    if b is None:
        return "NA"
    n, m = min(MAP_ROWS, len(prev)), min(PANEL_COL0, len(prev[0]))
    if not _bites(prev, b):
        for r in range(n):                       # 没咬住：地图区一格不动
            for c in range(m):
                if prev[r][c] == PLAYER or nxt[r][c] == PLAYER:
                    continue
                if prev[r][c] != nxt[r][c]:
                    return "FALSE"
        return "TRUE"
    if not _seated(prev, b):
        return "NA"                              # 咬住了但没套准：没见过，不外推（见 NOTE）
    jaws, centre = _jaws(b), _centre(b)
    for r, c in jaws:
        if prev[r][c] == PLAYER or nxt[r][c] == PLAYER:
            continue
        if nxt[r][c] != JAW:
            return "FALSE"
    for r, c in centre:
        if prev[r][c] == PLAYER or nxt[r][c] == PLAYER:
            continue
        if nxt[r][c] != BITE:
            return "FALSE"
    for r in range(n):                           # 让开的那 28 个像素之外，地图区一格不动
        for c in range(m):
            if (r, c) in b or (r, c) in jaws or (r, c) in centre:
                continue
            if prev[r][c] == PLAYER or nxt[r][c] == PLAYER:
                continue
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """押收拢后那块夹子：6×6 去掉正中 2×2 全是色8，正中 2×2 仍是色12。
    让开的那 28 个像素露出什么不押——底下是什么这一帧上看不见（SCOPE 里写着）。"""
    if not clicked_card(prev, action, JAW):
        return None
    b = _box(prev)
    if b is None:
        return None
    if not _bites(prev, b):
        return {}                                # 没咬住：我押整帧不动
    if not _seated(prev, b):
        return None                              # 咬住了但没套准：闭嘴
    out = {p: JAW for p in _jaws(b)}
    out.update({p: BITE for p in _centre(b)})
    return out


def apply_mover(prev, action, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：这一下点击里，那只会挪窝的方框收拢前/后各占哪些像素
    （只报坐标，不报让开那圈露出什么——那才是主张，而这一帧上看不见）。

    和 `clamped_piece_slides.apply_mover`、`lit_diamond_moves_box.apply_mover` 是同一个接口。
    没有它，规划器把「合口」这一下算成「方框原地留了个影子」：老那 28 个像素仍是色8，
    下一帧地图区就有两块色8，`clamped_piece_slides` 认不出夹子，整条链断在合口这一步上。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if not clicked_card(prev, action, JAW):
        return None
    b = _box(prev)
    if b is None or not _bites(prev, b) or not _seated(prev, b):
        return None
    return set(b), _jaws(b) | _centre(b)


def apply_cover(prev, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：方框此刻盖着哪些像素（只报坐标）。
    与 `lit_diamond_moves_box.apply_cover` 报的是同一只方框，写在这里是为了合口那一下之后
    规划器还回得去——让开的那 28 个像素的底色，它上一帧记过。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    return _box(prev)
