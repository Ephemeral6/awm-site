"""地图区只露着一块抖动垫时，玩家正踩着它的同伴：玩家走开一格（不是传送），原格露出来的是同一对色、相位相反的垫子（[a,b/b,a] 露着，脚下就是 [b,a/a,b]）。"""
LEVEL = "L7"
SCOPE = ("只看玩家在 prev 和 nxt 里都定位得到、且恰好挪了一格（一轴差 CELL、另一轴不变）的转移；换关返回 NA；"
         "prev 的地图区（列<42、行<62）里露着的垫子（_lib.pads）不是恰好一块返回 NA；"
         "地图区帧差超过 12 像素（传送、换关、件在动）返回 NA——传送那一步两块垫子都翻，归 card6_teleport / card6_flips_pad_phase 管。"
         "只断言原格四像素。")
NOTE = ("v1: 第 410 步（bb84faeb3b4b0b5e）玩家从传送落点 (17,5) 走开，原格露出 [6,7/7,6]，而露着的那块 (3,12) 是 [7,6/6,7]；"
        "floor_under 按四邻猜成色2，白挨一次预测错。回头扫全语料（runs 里 probe_padpartner.py）：prev 只露一块垫子而玩家走开的 13 次里，"
        "走一格的（468、534、652 与本步）原格全是相反相位的垫子；同相位的那几次全是传送本身（467、532、645），那一步两块都翻，另有概念管。"
        "露着 3 块的第 6 关另有一块从不翻的垫子，这条不管它。")
EVIDENCE = ["bb84faeb3b4b0b5e", "eb8999d9269a4199", "89d5b9ac301782ee", "69bddf9432a63912"]

from _lib import CELL, PANEL_COL0, MAP_ROWS, me, pads


def _walk(prev, nxt):
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return None
    dr, dc = b[0] - a[0], b[1] - a[1]
    if (abs(dr), abs(dc)) not in ((CELL, 0), (0, CELL)):
        return None
    return a


def _map_diff(prev, nxt):
    return sum(1 for r in range(MAP_ROWS) for c in range(PANEL_COL0) if prev[r][c] != nxt[r][c])


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = _walk(prev, nxt)
    if a is None:
        return "NA"
    p = pads(prev)
    if len(p) != 1:
        return "NA"
    if _map_diff(prev, nxt) > 12:
        return "NA"
    x, y, _, _ = next(iter(p.values()))
    r, c = a
    got = (nxt[r][c], nxt[r][c + 1], nxt[r + 1][c], nxt[r + 1][c + 1])
    return "TRUE" if got == (y, x, x, y) else "FALSE"
