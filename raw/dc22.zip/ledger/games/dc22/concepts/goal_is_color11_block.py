"""方向键走向一格四像素全是色11 的块，这一步就过关（上游给的关卡数 +1）；走向别的格，关卡数不变。"""
LEVEL = "L5"
SCOPE = "只看 ACTION1-4 四个方向键；me() 定位不到返回 NA；目标格越出帧返回 NA。只断言关卡数变没变，不管像素怎么重画。"
NOTE = "v2: 「地图区」那道边界（列<40、行<62）是我自己画的，第 6 关的色11 块在**列46-47**——正文在自己要管的那一格上返回 NA，这条概念本来说不出这一局怎么赢。" + \
    "本关右上那间屋的地板一路铺到列49，面板从列42 起只是右下半边的事，拿一个列号当地图右界在这一局根本不成立（lit_diamond_moves_box v2 栽过同一个跟头）。" + \
    "改成只拿帧边界兜底：目标格出帧才 NA。这一改不会放进新的判错风险——目标格是 me()+DELTA 算出来的，只可能落在玩家够得着的地方；" + \
    "够不着的那些格 goal_cell 返回 False，主张就是「关卡数不变」，与原来一致。\n" + \
    "v1:五次换关全是走进纯色11 的格（0ece4a389344cee2 关0→1、e97c85245dfa0681 关1→2、9405743c6a4429b9 关2→3、ba39c5a91b1720f7 关3→4、1e6c107f8106f76d 关4→5），没有一次是点卡或别的动作换的。反过来，其余几百步方向键都没换关。第 6 关的色11 块在行6-7 列46-47 那间封死的屋里——这条概念就是这一局「什么算赢」的正文。"
EVIDENCE = ["0ece4a389344cee2", "e97c85245dfa0681", "9405743c6a4429b9", "ba39c5a91b1720f7", "1e6c107f8106f76d"]

from _lib import me, CELL, DELTA

MAP_COLS = 40        # v2 起不再用它当地图右界，留着只为记住这道自画的线错在哪
MAP_ROWS = 62
GOAL = 11


def goal_cell(g, r, c):
    """(r,c) 这一格是不是四像素全色11。"""
    if r < 0 or c < 0 or r + CELL > len(g) or c + CELL > len(g[0]):
        return False
    return all(g[r + i][c + j] == GOAL for i in range(CELL) for j in range(CELL))


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    a = me(prev)
    if a is None:
        return "NA"
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    if tr < 0 or tc < 0 or tr + CELL > len(prev) or tc + CELL > len(prev[0]):
        return "NA"
    up = ctx["level_next"] - ctx["level_prev"]
    return "TRUE" if up == (1 if goal_cell(prev, tr, tc) else 0) else "FALSE"
