"""card_l4_claw_slides 判不出「这一下按钮点击走没走」的那些转移（目标腰格 16 个像素里有的被爪子
自身现在的身子盖住，单帧看不见底下），只要被盖住的不超过 4 个、其余可见像素读得出来且颜色一致、
玩家又没有挨着这个件，这些可见像素是不是清一色轨道色0，就能预判「走了」还是「没走」，从而把件的
落点、腰格让开处的色0 一并当 apply 的主张交出去——但这条判据只在这个窄窗口里立得住：被盖住 12
个（只剩 4 个可见）的那一类、以及玩家挨着件的那一类，这条概念对它们保持沉默，`apply` 返回 None、
不猜。"""

LEVEL = "L6"
SCOPE = (
    "只在 `card_l4_claw_slides._plan(prev, action)` 返回 None（认得出爪子/件/方向，"
    "但目标腰格底下的颜色单帧读不出来）时才可能开口；`_plan` 自己判得出来的（含目标腰格出地图、"
    "件会被推出地图区那些局面）一概交还给它，这条不重复表态，返回 NA/None。\n"
    "先过玩家关：跟 `card_l4_claw_slides._plan` 同一条判据——玩家色14 的像素只要有一个落在件的"
    "外接框（矩形 hull，不是四连通形状）、当前腰格、或目标腰格里，一律 NA/None。这条不是照抄，"
    "是补丁：v1 曾经以为「玩家不落在目标腰格（tgt）里」就够了，被 `e9800c19bf9dabb6` 推翻，见 NOTE。\n"
    "目标腰格是 4×4=16 个像素。把它按「此刻是不是落在件（爪子±咬住的杆）自身占的像素集合里」"
    "分成 hidden（盖住，读不出来）和 visible（没盖住，帧上直接读得到）两半："
    "hidden 为 0 或 >4，或 visible 为空，或 visible 里出现 `_lib.unreadable`（玩家色14/离场规划器"
    "的负数哨兵）、或 visible 颜色不清一色，一律 NA/None——这条只吃「被盖住不超过 4 个、"
    "剩下的看得清楚且一个色、玩家不挨着件」这个窄窗口。\n"
    "窗口之内：visible 清一色轨道色0 → 判「走了」，apply 交出件的落点（跟 `card_l4_claw_slides._plan`"
    "走成时同一套坐标）与腰格让开处的色0；visible 不是轨道色0（比如色4 的墙）→ 判「没走」，"
    "apply 交出空字典 `{}`。\n"
    "换关（`ctx.level_prev != ctx.level_next`）返回 NA/None，与 `card_l4_claw_slides` 一致。"
)
NOTE = (
    "起因：`card_l4_claw_slides.apply` 只要目标腰格 16 个像素里有**一个**被爪子自身现在的身子盖住，"
    "整条就弃权（返回 None）——那是诚实的（底下确实读不出来），但链式预测因此在这几颗按钮"
    "（面板上那排四颗、地图区里爪子挨到杆之后点某个方向）上连续吃 0 格，实际帧差却有 36～126 格。\n"
    "这条概念不推翻 `card_l4_claw_slides` 的判据（它的 NOTE 第 6 条已经证明「目标腰格底下整格是"
    "色0 轨道」单帧读不出来是真的读不出来，不是没找对判据），只是把它让出来的那部分信息拿回来用："
    "16 个像素里如果只有一小片被盖住、其余大半可见，那可见的大半往往足够把「底下是不是整格轨道」"
    "问出答案——但\"往往\"两个字要拿反例钉住，不能靠感觉，而且钉了两次才钉牢：\n"
    "1) hidden∈[1,4] 这个窗口——对应地图区里点按钮排的六个位置/方向组合（`ACTION6:43,28`/`48,28`/"
    "`58,28`/`49,29`/`59,29`/`44,29`，含开口爪子单独走、也含合口爪子带着杆一起走，`_piece` 大小"
    "30 或 82 都有）——单个 run 的 `transitions.jsonl`（2081 条去重转移）上 `_plan` 返回 None 的"
    "一共 47 条去重 tid，hidden 都恰好是 2 或 3（从没见过 1 或 4），visible 清一色的判据用在"
    "这 47 条上，逐格核对完整 apply（件落点 + 腰格让开处）与真实 next 帧：claimed=2758 right=2758"
    " wrong=0，包含「走了」与「没走」两种判词（例：`d4b254512fda5c77`/`4f40e58f9f03ad82`/"
    "`ea9b02ec00b4257f`/`98a2554bc01c4f07`/`800895abca00b6ec`/`a6472811c1597ada` 判「走了」；"
    "`328ff296ca56db50`/`dda9589ed9e780fa` 判「没走」，两种都对）。\n"
    "2) hidden=12（只剩 4 个可见）这一类——只在 `ACTION6:53,28` 这个位置/方向组合上见过，"
    "对应合口爪子带着杆朝右走、目标腰格恰好有 3/4 落在爪子自己身子底下——单个 run 上找到 8 条去重 "
    "tid，visible 清一色都是轨道色0，其中 7 条真的走了，唯独 `82b8b5332f6ff4a4`（第 903 步）没走："
    "这条转移与它的近邻 `90ab41271a39463a`（第 902 步，同一个按钮、同一个爪子/杆姿态、可见的那 4"
    "个像素同样清一色色0）在「hidden 计数、visible 颜色」这两个能从单帧读出来的量上完全相同，"
    "却一条走了一条没走——跟 `card_l4_claw_slides` 自己 NOTE 第 6 条记的反例是同一件事"
    "（目标腰格另外那 12 个读不出来的像素里，有一半底下其实是色4 的墙，帧上却只看得见件）。"
    "在只有 4 个可见像素的这一档，可见的那一角不足以代表整个 16 像素格子，`visible 全色0 ⇒ 走了`"
    "这条判据在本局语料里已经被证伪，不能再往 hidden=12 那一档延伸——这是负结果，不是没试过，"
    "是试了、错了，所以这条概念把 SCOPE 卡在 `hidden<=4`，`hidden=12` 那一档 apply 返回 None、不猜。\n"
    "3) **v2 更正，玩家关（本版）**：入册后装置在**本局全部 run 去重并集**（两个 run 合起来 2209"
    "条去重转移，不是只看一个 run）上核出 72 格说错，全部落在 `e9800c19bf9dabb6`"
    "（另一个 run `dc22-0915-2238` 第 611 步，`ACTION6:44,29`，hidden=2、visible 14 个像素清一色"
    "轨道色0）这一条转移上——这条转移正是 `card_l4_claw_slides` 自己 EVIDENCE 里记的「玩家压在件上"
    "→ 整帧不动」那一条（`card_l4_claw_slides._plan` 因为玩家色14 落在件的矩形外接框里而返回 None，"
    "不是因为目标腰格读不出来）。v1 的 `_window` 只检查了「目标腰格 `tgt` 里有没有玩家」，没检查"
    "「件本身的外接框、当前腰格 `cur` 里有没有玩家」——这一条转移里玩家正站在件的身子上、不在目标"
    "腰格里，可见的 14 个像素照样清一色色0，v1 因此误判「走了」，逐格给了 72 格，世界一格没动。"
    "教训（与 `card_l4_claw_slides` 自己 NOTE 第 4 条同源）：**「目标格干净」不等于「这一下能走」**——"
    "挡着的可以是任何一个跟件相关的格子，不只是目标格；借别的概念的几何（`_plan`）时，"
    "「它判不出来」和「它判不出来的具体原因」是两件事，后者也得原样借过来，不能只挑一半。\n"
    "本版把 `card_l4_claw_slides._plan` 那句「玩家挨着件的矩形外接框/当前腰格/目标腰格，"
    "一律不开口」原样搬进 `_window`（`_player_blocks`），不再只看目标腰格。修完在同一份"
    "全局并集语料（2209 条去重转移）上重核：`e9800c19bf9dabb6` 现在落进玩家关、`_window` 直接"
    "返回 None、apply 对它整条闭嘴（0 格），其余 46 条 hidden∈[1,4] 的转移不受影响。"
    "结果：claimed=2758 right=2758 wrong=0（改之前是 claimed=4248 right=4176 wrong=72——"
    "分母的差额来自这条转移原本认领的 76 格，砍掉之后总 claimed 也跟着减，其余转移一格没变）。\n"
    "4) `assert_` 不自建判据，直接转发 `card_l4_claw_slides.assert_` 的结果——那条函数在 `_plan` 返回"
    "None 时会退到 `_assert_moved_half`（「要是动了就必须整体平移 4 像素」那一半，已经在基础概念"
    "自己的语料上验过 0 反例），这条概念只是把它在窗口内更窄的范围内重新报一遍，"
    "不发明新的真值判据，避免两条概念在同一件事上给出互相矛盾的 TRUE/FALSE。\n"
    "5) `card_phase_swap_by_color` 的覆盖范围：题面给的另一个例子 `ACTION6:49,12`（帧差 36）"
    "在这局语料里已经被 `card_phase_swap_by_color` 完整覆盖（apply 36 格，逐格对得上"
    "real next），不落在 `card_l4_claw_slides._plan` 返回 None 的范围里——`level_prev==4` 下这个坐标"
    "查到的转移 `_plan` 都不是 None。「0 预测格」更像是链式预测（`predict_chain`）在别的步骘上"
    "漂移出的假象，不是这一步单帧真的没概念覆盖，这条概念不为它添任何东西。\n"
    "6) 装载纪律：探针与这条概念本体都只借 `_lib.sibling(\"card_l4_claw_slides\")` 拿"
    "`_dir/_claw/_piece/_cell/_plan/_waist_free/TRACK/MAP_ROWS/MAP_COLS/ME`，不重复实现那套几何；"
    "装置进程里 `import card_l4_claw_slides` 本身会失败（`settle.load_concepts` 不注册概念模块名），"
    "`sibling()` 是唯一走得通的借用路径。核验也要照装置的口径：装置的语料是**本局全部 run 的去重"
    "并集**（`settle.load_game_corpus`），只在单个 run 上核过就报「wrong=0」是不够的——这条本身"
    "也是这一版吃的教训。"
)
EVIDENCE = [
    "d4b254512fda5c77",   # ACTION6:43,28，hidden=2，可见清一色色0，走了——张口爪子紧贴杆左移
    "4f40e58f9f03ad82",   # ACTION6:48,28，hidden=2或3，走了
    "ea9b02ec00b4257f",   # ACTION6:58,28，合口爪子(piece=82)，hidden 仍是小窗口，走了
    "98a2554bc01c4f07",   # ACTION6:49,29，走了
    "328ff296ca56db50",   # ACTION6:49,29，可见清一色非轨道色，判「没走」，对
    "800895abca00b6ec",   # ACTION6:59,29，走了
    "dda9589ed9e780fa",   # ACTION6:59,29，判「没走」，对
    "a6472811c1597ada",   # ACTION6:44,29，合口爪子带杆，走了
    "90ab41271a39463a",   # ACTION6:53,28 第902步，hidden=12，可见清一色色0，真走了
    "82b8b5332f6ff4a4",   # ACTION6:53,28 第903步，hidden=12，可见跟上面那条一模一样，却没走——
                            # 这条概念因此把 hidden=12 整档划出 apply 的 SCOPE，不猜
    "e9800c19bf9dabb6",   # 另一个 run 第611步，ACTION6:44,29，hidden=2、可见清一色色0，
                            # 但玩家压在件的外接框上，世界整帧不动——v1 在这条上押「走了」逐格错72格，
                            # v2 补上玩家关，这条概念现在对它整条闭嘴（apply 返回 None）
]

from _lib import sibling, unreadable

_claw = sibling("card_l4_claw_slides")

TRACK = _claw.TRACK
MAP_ROWS = _claw.MAP_ROWS
MAP_COLS = _claw.MAP_COLS
ME = _claw.ME
HIDDEN_MAX = 4


def _player_blocks(prev, pc, cur, tgt):
    """跟 `card_l4_claw_slides._plan` 同一条玩家判据（原样搬过来，不是自己另猜一条）：
    玩家色14 的像素只要有一个落在件的矩形外接框（不是四连通形状本身，是包住它的矩形）、
    当前腰格、或目标腰格里，就说明这一下「玩家挨着件」，世界会不会动跟目标腰格底下是什么色无关
    ——这种局面 `card_l4_claw_slides._plan` 自己也不开口，这条判据只是把它一并借过来用，
    不然「可见像素清一色轨道色」会被误读成「走了」（`e9800c19bf9dabb6` 那种情形）。"""
    if not pc:
        return False
    rs = [p[0] for p in pc]
    cs = [p[1] for p in pc]
    n, m = len(prev), len(prev[0]) if prev else 0
    hull = {(r, c) for r in range(min(rs), max(rs) + 1) for c in range(min(cs), max(cs) + 1)}
    for r, c in hull | cur | tgt:
        if 0 <= r < n and 0 <= c < m and prev[r][c] == ME:
            return True
    return False


def _window(prev, action):
    """算目标腰格 16 个像素的 hidden/visible 两个子集，并判定是否落在这条概念敢开口的窄窗口里。
    返回 (moved: bool, bb, pc, d) 或 None（不在窗口内，交还给 `card_l4_claw_slides` 或整条闭嘴）。"""
    if _claw._plan(prev, action) is not None:
        return None    # 基础概念自己判得出来，这条不重复表态
    d = _claw._dir(prev, action)
    if d is None:
        return None
    bb = _claw._claw(prev)
    if bb is None:
        return None
    pc = _claw._piece(prev, bb)
    cur = _claw._cell(bb)
    dr, dc = d
    tgt = {(r + dr, c + dc) for r, c in cur}
    n, m = min(MAP_ROWS, len(prev)), min(MAP_COLS, len(prev[0]))
    if any(not (0 <= r < n and 0 <= c < m) for r, c in tgt):
        return None    # 出地图：`_plan` 自己判得出来，走不到这儿
    if _player_blocks(prev, pc, cur, tgt):
        return None    # 玩家挨着件：跟基础概念一样不开口
    hidden = [p for p in tgt if p in pc]
    if not (1 <= len(hidden) <= HIDDEN_MAX):
        return None
    visible_colors = []
    for p in tgt:
        if p in pc:
            continue
        col = prev[p[0]][p[1]]
        if unreadable(col):
            return None
        visible_colors.append(col)
    if not visible_colors:
        return None
    if any(v != visible_colors[0] for v in visible_colors):
        return None
    moved = all(v == TRACK for v in visible_colors)
    return moved, bb, pc, d


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    got = _window(prev, action)
    if got is None:
        return "NA"
    return _claw.assert_(prev, action, nxt, ctx)


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    got = _window(prev, action)
    if got is None:
        return None
    moved, bb, pc, d = got
    if not moved:
        return {}
    dr, dc = d
    want = {(r + dr, c + dc): prev[r][c] for r, c in pc}
    out = {k: v for k, v in want.items() if prev[k[0]][k[1]] != v}
    for r, c in _claw._waist_free(prev, bb, action):
        if prev[r][c] != TRACK:
            out[(r, c)] = TRACK
    return out
