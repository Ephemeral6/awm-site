"""RESET 总把 HUD 那一行（行63）里的色3 清光；至于玩家回不回固定起点 (40,10)，只有**把整局打回第 0 关**的那种 RESET 才算数，重开本关的那种这条概念不表态。"""
LEVEL = "L6"
SCOPE = ("只看 RESET 动作；非 RESET 返回 NA。HUD 那半句对所有 RESET 都断言。"
         "玩家落点那半句只在 ctx 说这一下把关号带回第 0 关（level_next == 0）时才断言；"
         "关号没回 0 的 RESET（会话还活着，只重开本关）不表态——玩家去的是本关自己的起点，"
         "本关起点在哪这条概念读不出来，读不出来就别说。ctx 缺失或 me() 定位不到也不表态。")
NOTE = ("v3：被 9a49e58059532401 打脸——第 5 关上带着活会话发的 RESET 只重开本关，"
        "HUD 照常清空，可玩家落在 (52,28) 而不是 (40,10)，v2 于是判 FALSE。"
        "教训：v2 的三条依据全是**整局归零**那种 RESET（会话已被上游回收，退回第 0 关），"
        "「RESET 把玩家送回起点」里的『起点』当时只见过第 0 关那一个，就被写成了一个常数。"
        "同一个动作在两种会话状态下是两件事，判据得把这个岔口写进来，而不是把见过的那一支当全部。"
        "apply 同步收口：关号没回 0 时只画 HUD 那一行，不再替玩家瞎画落点。")
EVIDENCE = ["5df520175dc0539c", "f94dbfd8b940e549", "e6ffb3ecb89fb6cb", "9a49e58059532401"]

from _lib import me


def _back_to_zero(ctx):
    """这一下 RESET 是不是把关号带回了第 0 关（整局归零那一种）。读不出来就 None。"""
    if not ctx:
        return None
    lv = ctx.get("level_next")
    if lv is None:
        return None
    return int(lv) == 0


def assert_(prev, action, nxt, ctx=None):
    if action != "RESET":
        return "NA"

    if any(c == 3 for c in nxt[63]):
        return "FALSE"

    zero = _back_to_zero(ctx)
    if not zero:                      # None（读不出关号）或 False（只重开本关）都不表态落点
        return "TRUE"

    pos_next = me(nxt)
    if pos_next is None:
        return "NA"
    return "TRUE" if pos_next == (40, 10) else "FALSE"


def apply(prev, action, ctx=None):
    if action != "RESET":
        return None

    result = {(63, c): 0 for c in range(64)}

    if not _back_to_zero(ctx):
        return result                 # 只重开本关：本关起点读不出来，就只画敢担保的那一行

    old_pos = me(prev)
    if old_pos:
        r, c = old_pos
        for dr in range(2):
            for dc in range(2):
                result[(r + dr, c + dc)] = 2

    for dr in range(2):
        for dc in range(2):
            result[(40 + dr, 10 + dc)] = 14

    return result
