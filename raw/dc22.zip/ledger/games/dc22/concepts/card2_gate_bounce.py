"""点面板上那张色2 的卡：把它管的一条 16 像素宽的双色横带（色1 边框 + 色5 缺口，边框对称）朝当前尽头以外推一档——
带子处在两个极端（缺口全开 16 像素，或整条实心色12）时，下一档朝哪边走是唯一确定的：全开必然收窄到边框2，
全闭必然松开到边框6；带子处在中间任何一种边框宽度（2/4/6）时，光看这一帧读不出它正往哪个方向走，
本概念对这些转移只交 NA（证据见 NOTE，同一种边框宽度在语料里两个方向都走过）。"""

LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色2、落在面板区（列>=42）、且所在同色块恰好 36 像素——"
         "面板上还有一块 132 像素的色2 图形，点它整帧零像素变化（唯一样本 7fc11a454c3ecbd5），"
         "尺寸不对就不是这张卡，返回 NA。"
         "换关（ctx.level_prev != level_next）返回 NA。"
         "只认得两组带子坐标：第3关两条（行20-21、行40-41，各16 像素宽）和第4关一条（行44-45，16 像素宽）；"
         "别的关、或两行读出来颜色对不上（残缺/花格）都按“这一条带子读不出”处理。"
         "带子的两行内容必须一致（允许其中一行被玩家色14 遮住，取另一行；两行都给出确切值但不一致就判读不出）。"
         "读出来的形状必须是“对称边框 + 纯色缺口”（边框宽度左右相等，且是 0/2/4/6，缺口纯色5）或整条纯色5（开）"
         "或纯色12（闭）；不满足就是“读不出”，不是这条卡的转移或帧本身有杂色。"
         "一条转移里可能同时看到两条带子（第3关）：哪条带子当前处在极端就检验哪条，两条都不在极端就返回 NA；"
         "两条带子的边框宽度经验上总是互补（宽度/2 相加=4，即一条全开时另一条必然全闭），"
         "但本概念不断言这一点——它只用两条带子里凑巧在极端的那条来判，不要求两条同时极端。")
NOTE = ("从 13 条“被点像素是色2 且列>=42”的转移里挑出来：12 条落在同一 36 像素的色2 图形上（第3关8条、第4关4条），"
        "1 条落在另一块 132 像素的色2 图形上（第5关，7fc11a454c3ecbd5，ndiff=0，点了什么都没变，样本太少不敢断言，"
        "干脆用尺寸把它隔开）。"
        "第4关连续4条点击（9b0fa8db9ae8d712/3fff11c69820a9e3/d9e76b6db36810e9/a2c9fe22c694aef9）把同一条带子从"
        "全开（缺口16）一路点到全闭（整条变色12）：每档边框从0→2→4→6，最后一档不是边框8缺口0，而是整条直接变色12——"
        "闭合是一次跳变，不是缺口收尽。"
        "第3关8条点击（d62bf04d4bd374c3 起）里有两条带子在同一批帧里，边框宽度一直互补（宽度/2 相加恒等于4）；"
        "其中 d62bf04d4bd374c3 和 704a9b76559ed24e 这两步，两条带子同时处在极端（一条全开一条全闭），"
        "其余6条（019f9e2e12f6f35e/a28abadd6c60b59b/4345ad31f0139f99/f615c918dc61cb82/1dbb7321152b019d/"
        "c9e16c41d2ad5e3d）两条带子都在中间档，本概念对它们只交 NA——但正是这6条暴露了方向的不可判：把8条按"
        "时间顺序摆开，带子A 的边框宽度走的是 0,2,4,6,(闭),6,4,2,(开) 这样一个来回，"
        "边框宽度=4（比如 a28abadd6c60b59b 的 prev）在序列里出现两次，一次之后走向6（更闭），一次之后走向2"
        "（更开，见 1dbb7321152b019d 的 prev）——同一种像素完全看不出下一步该往哪边走，这不是没读全，"
        "是这一档的视觉本身就不带方向信息（除非另有一个没入册的计数器记着朝向，本概念没找到）。"
        "HUD 行63 上那一长条从左往右增长的色3 计数在这批点击之间也在走（有的点击前进1格、有的不动、"
        "两条记录之间还跳过10多格），核对下来它和别的动作（非本卡点击）也会动，不是这张卡专属的读数，"
        "本概念不管它。")
EVIDENCE = [
    "d62bf04d4bd374c3", "019f9e2e12f6f35e", "a28abadd6c60b59b", "4345ad31f0139f99",
    "704a9b76559ed24e", "f615c918dc61cb82", "1dbb7321152b019d", "c9e16c41d2ad5e3d",
    "9b0fa8db9ae8d712", "3fff11c69820a9e3", "d9e76b6db36810e9", "a2c9fe22c694aef9",
    "7fc11a454c3ecbd5",
]

from _lib import glyph_size  # noqa: F401  本局词汇

PANEL_COL0 = 42

LEVEL_BANDS = {
    3: [(20, 8, 24), (40, 16, 32)],
    4: [(44, 14, 30)],
}


def _clicked(g, action):
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == 2 and glyph_size(g, r, c) == 36


def _run_from_left(vals):
    cnt = 0
    for v in vals:
        if v == 1 or v is None:
            cnt += 1
        else:
            break
    return cnt


def band_pos(g, r, c0, c1):
    """带子当前的档位：0=全开(缺口16) .. 4=全闭(整条色12)，中间 1/2/3 对应边框宽度 2/4/6。
    读不出（两行不一致、花色、边框不对称、宽度不是0/2/4/6）返回 None。玩家色14 当作未知，靠另一行或对称补全。"""
    n = c1 - c0

    def row_vals(rr):
        raw = [g[rr][c] for c in range(c0, c1)]
        return [None if v == 14 else v for v in raw]

    a, b = row_vals(r), row_vals(r + 1)
    merged = []
    for va, vb in zip(a, b):
        if va is None:
            merged.append(vb)
        elif vb is None:
            merged.append(va)
        elif va == vb:
            merged.append(va)
        else:
            return None
    non_none = [v for v in merged if v is not None]
    if not non_none:
        return None
    if all(v == 12 for v in non_none):
        return 4
    if all(v == 5 for v in non_none):
        return 0
    left = _run_from_left(merged)
    right = _run_from_left(list(reversed(merged)))
    if left != right or left not in (2, 4, 6):
        return None
    mid = merged[left:n - left]
    if any(v is not None and v != 5 for v in mid):
        return None
    return left // 2


def _extremal_target(pos):
    """只在两个尽头是唯一确定的：全开(0)必然收到边框2(位1)，全闭(4)必然松到边框6(位3)。中间返回 None。"""
    if pos == 0:
        return 1
    if pos == 4:
        return 3
    return None


def _paint(r, c0, c1, target_pos):
    n = c1 - c0
    if target_pos == 4:
        vals = [12] * n
    elif target_pos == 0:
        vals = [5] * n
    else:
        e = target_pos * 2
        vals = [1] * e + [5] * (n - 2 * e) + [1] * e
    return {(rr, c0 + i): vals[i] for rr in (r, r + 1) for i in range(n)}


def assert_(prev, action, nxt, ctx=None):
    if not _clicked(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    lvl = ctx.get("level_prev") if ctx else None
    bands = LEVEL_BANDS.get(lvl)
    if not bands:
        return "NA"
    checked = False
    for (r, c0, c1) in bands:
        pos = band_pos(prev, r, c0, c1)
        if pos is None:
            continue
        target = _extremal_target(pos)
        if target is None:
            continue
        checked = True
        pred = _paint(r, c0, c1, target)
        for (rr, cc), v in pred.items():
            if nxt[rr][cc] != v:
                return "FALSE"
    return "TRUE" if checked else "NA"


def apply(prev, action, ctx=None):
    if not _clicked(prev, action):
        return None
    lvl = ctx.get("level_prev") if ctx else None
    bands = LEVEL_BANDS.get(lvl)
    if not bands:
        return None
    out = {}
    for (r, c0, c1) in bands:
        pos = band_pos(prev, r, c0, c1)
        if pos is None:
            continue
        target = _extremal_target(pos)
        if target is None:
            continue
        out.update(_paint(r, c0, c1, target))
    return out or None
