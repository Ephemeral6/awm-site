"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

量出来的：
    CELL=2   玩家是 2×2 像素的块，所有物件都按 2×2 对齐
    PHASE=(0,0)  格位从 (0,0) 起
    DELTA    ACTION1=上 ACTION2=下 ACTION3=左 ACTION4=右（文件名里的「right/left」是开局的错名，没改）
    me(g)    全帧唯一那只恰好 2×2 的色14 连通块的左上角（**不是**「第一个 2×2 的色14」——亮着的菱形也是色14）
    cell_color/enterable/walls  见各自 docstring
    floor_under/move_cells  只给 apply 用：玩家走开后原格露出什么，帧上多半看不到，按四邻猜；
                            standing_on 是那少数看得到的情形（面板有菱形全亮 ⇒ 玩家踩在同色标记格上）
    unreadable    这个像素读不出来（玩家盖着，或调用方标了负数哨兵）——读装置时当未知，不当颜色
    clicked_card  面板上的卡按被点像素的颜色认
    TRACK_*/track_band/track_after_shift  第 6 关左下角横条轨道的读法与转一档的画法

几何工具从 geo 拿（`from geo import components, diff_sum, fold, moved`），那里没有世界断言。
"""
from __future__ import annotations

from geo import cells_of, components  # noqa: F401  —— 常用；不用可删

CELL = 2               # 玩家是 2×2 的块
PHASE = (0, 0)         # 格位相位
DELTA = {              # 实测：四个方向各移 CELL 像素
    "ACTION1": (-CELL, 0),  # 上
    "ACTION2": (CELL, 0),   # 下
    "ACTION3": (0, -CELL),  # 左
    "ACTION4": (0, CELL),   # 右
}

BLOCK_COLORS = (0, 3, 4, 5)  # 色4=地图墙，色5=右侧卡面板底色，色3=第2关里那种挡路块，色0=第6关中间那片黑区

# 垫子：两色相间的 2×2 格，四种花色循环（点色4 图标推进一档：6/7 → 13/8 → 12/11 → 9/10 → 6/7）。
# 四种都站得上去——不分花色。这一条是第 860 步拿反例换来的（6bcce9fed69e28f5）。
PAD_PAIRS = (frozenset({6, 7}), frozenset({13, 8}), frozenset({12, 11}), frozenset({9, 10}))


BIG14 = 6              # 色14 连通块超过这么多像素就不是玩家（亮着的菱形是 16）


def unreadable(v):
    """这个像素的**原本颜色读不出来**。两种情形：

    1. 色14 —— 玩家自己的方块盖在上面。玩家会挡住地图上的装置（横条、带子），
       被挡的那几个像素不能当成「这里是色14」来读，也不能当成「装置没画到这儿」。
    2. 负值 —— 调用方（离场规划器）在帧上标的哨兵，意思是「这一格谁也说不出原本是什么」。
       真实帧上的颜色都是 0 起的小整数，负数不会和任何一种颜色撞车，所以这个约定是安全的。

    读装置的概念应当把这种像素当**未知**而不是当某种颜色：未知像素只是少一条约束，
    剩下的可见像素往往仍然把状态定死。把它当颜色读，概念会在玩家一走上去就整条闭嘴。
    """
    return v == 14 or (isinstance(v, int) and v < 0)


def me(g):
    """玩家块：排掉大块色14（亮菱形）之后，按格位数色14 像素最多的那一格；并列或一个都没有返回 None。

    第一版是「从上往下扫，第一个 2×2 全是色14 的位置」。第 879 步它认错了人：第 6 关面板上那颗「右」菱形
    一亮就是 16 像素的色14（行35-38 列53-56），排在玩家（行58-59）前面，于是 me 指到了菱形身上，
    一条转移同时打掉 action4_down 与 cell_enterable（37e1f7195bbc3458）。
    第二版改成按连通块认：「恰好四像素且方方正正」的色14 连通块。它在第 621 步塌了——
    围死的图例屋里「右」标记格 [1,0 / 0,14] 的那一个色14 像素（行59 列37）和站在它正下方的玩家
    （行60-61 列36-37）四连通，两者并成 5 像素的一块，me 返回 None，玩家一走进那个角落整册概念全体闭嘴。
    第三版要求「格位上四像素全是色14」，它在第 644 步塌了：玩家走进色12 十字件中心那圈色8 环
    （格(4,9)=像素行8-9 列18-19）时，环画在玩家**上面**，玩家只剩左半边两个像素露着（和 box 的
    「画在别的东西上面」是同一回事），四像素全色14 一格都找不到，第 647 步同样。
    现版不要求「全」也不要求「恰好」：先把大于 BIG14 像素的色14 连通块整块扔掉（那只能是亮着的菱形，
    16 像素；玩家最多 4 像素，再贴上图例屋那一两个色14 标记像素也到不了 7），
    剩下的色14 像素按 CELL 格位归堆，谁最多谁是玩家——标记格和灭着的菱形各只有 1 个色14 像素，
    半遮的玩家还有 2 个，分得开；真并列时（玩家被遮到只剩 1 像素）宁可返回 None。
    仍不拿列号划界，因为地图右边界在这一关本来就不是 PANEL_COL0。
    """
    px = {(r, c) for r in range(len(g)) for c in range(len(g[0])) if g[r][c] == 14}
    keep = set()
    for comp in components(px):
        if len(comp) <= BIG14:
            keep |= set(comp)
    if not keep:
        return None
    cnt = {}
    for r, c in keep:
        k = (r - (r - PHASE[0]) % CELL, c - (c - PHASE[1]) % CELL)
        cnt[k] = cnt.get(k, 0) + 1
    top = max(cnt.values())
    hit = [k for k, n in cnt.items() if n == top]
    return hit[0] if len(hit) == 1 else None


def cell_color(g, r, c):
    """以 (r,c) 为左上角的一格的颜色；四个像素不同色（花格）返回 None，越界也返回 None。"""
    if r < 0 or c < 0 or r + CELL > len(g) or c + CELL > len(g[0]):
        return None
    v = g[r][c]
    for dr in range(CELL):
        for dc in range(CELL):
            if g[r + dr][c + dc] != v:
                return None
    return v


def is_marker(px):
    """图例标记格：四像素是一个色1、两个色0、外加一个别的色X（X 就是这块标记代表的方向）。
    第 6 关围死的图例屋里，垫子的上下左右各贴一块；踩上去会点亮面板上带同色X 标记的那颗菱形。"""
    if len(px) != CELL * CELL:
        return False
    rest = [v for v in px if v not in (0, 1)]
    return px.count(1) == 1 and px.count(0) == 2 and len(rest) == 1 and rest[0] not in (0, 1)


def marker_color(px):
    """标记格代表的那个色X；不是标记格返回 None。"""
    if not is_marker(px):
        return None
    return [v for v in px if v not in (0, 1)][0]


def enterable(g, r, c):
    """玩家能不能站进 (r,c) 这一格：
    四个像素里**一个都不是** 色3/4/5；含色0 的格一律是墙，只有图例标记格（is_marker：一个色1、两个色0、一个色X）例外；
    其余要么四像素同色，要么是「花格里带色2 地板」，要么是四种花色的垫子（PAD_PAIRS，两色相间的 2×2），
    要么是色8 占了至少两个像素的花格（第 6 关色12 十字件中心那圈色8 环，[8,12,8,8] 之类，玩家走得进去）。

    半开的桥（色9 与色4 相间）、半开的柱（色15 与色4 相间）因为混着色4 自动算进不去；
    垫子（6/7、13/8、12/11、9/10 四种花色）、地上的小道具（色2 里嵌一点色8/色15）进得去；
    第 5 关色12 条的「插头」角格 [12,12,12,8]（夹子的爪尖盖在原来的色4 角上）进不去——它只有一个色8 像素，
    没有色2，也不是垫子。
    第 6 关地图中间那一大片色0（看着像通道，从来没人走进去过）是墙：全语料 803 条里玩家一次都没进过纯色0 的格，
    而第 828 步起连撞五次（3f68ccbfdf7b1b01、dbd9cdb3fdb940f7）；但图例屋那四块含色0 的标记格踩得上去
    （73ee06ae28c73c86、94d19429542fa05a）——它们是开关不是墙。
    「色8 数量」「色0 是墙、标记格除外」「垫子不分花色」这几条界线都是拿反例拼出来的，不是从机制推出来的，随时可能再挨打。
    负数像素（离场规划器标的「这一格谁也说不出原本是什么」）一律算进不去：真实帧上没有负数，
    所以这一条只在离场规划里生效，而在那里「说不出来」当成能走会让规划器走进一堵它没看见的墙。
    """
    if r < 0 or c < 0 or r + CELL > len(g) or c + CELL > len(g[0]):
        return False
    px = [g[r + dr][c + dc] for dr in range(CELL) for dc in range(CELL)]
    if any(isinstance(v, int) and v < 0 for v in px):
        return False                    # 离场规划器标的「说不出这是什么色」：说不出就当走不进去
    if any(v in (3, 4, 5) for v in px):
        return False
    if 0 in px:
        return is_marker(px)
    if len(set(px)) == 1 or 2 in px or frozenset(px) in PAD_PAIRS or px.count(8) >= 2:
        return True
    return False


def box(g):
    """第 6 关地图上那只 8×8 的色8 空心方框（边框 1 像素、28 个像素）的像素集合；没有返回 None。

    它画在别的东西**上面**：十字件转到它身上时，重叠的像素显的是方框的色8 不是件的色12（f56dd4c5c8a0504f）。
    只在列 0-39 里找，按「纯色8 的四连通块、恰好 28 像素、外接框 8×8」认，面板上的卡和件中心那圈 12 像素的环都对不上号。
    """
    px = {(r, c) for r in range(len(g)) for c in range(min(40, len(g[0]))) if g[r][c] == 8}
    for comp in components(px):
        if len(comp) != 28:
            continue
        rs = [p[0] for p in comp]
        cs = [p[1] for p in comp]
        if max(rs) - min(rs) == 7 and max(cs) - min(cs) == 7:
            return frozenset(comp)
    return None


GOAL_COLOR = 11


def is_goal(g, r, c):
    """(r,c) 这一格是不是四像素全色11——按 goal_is_color11_block，走进它就换关，整帧重画。
    只给 apply 用：方向概念在这一步该闭嘴，它们说的是「谁挪到哪一格」，而换关那一帧和上一帧没有逐格对应关系。"""
    if r < 0 or c < 0 or r + CELL > len(g) or c + CELL > len(g[0]):
        return False
    return all(g[r + i][c + j] == GOAL_COLOR for i in range(CELL) for j in range(CELL))


def floor_under(g, r, c):
    """猜玩家脚下那格的颜色：四邻格像素里最常见的可走色（不算阻挡色和玩家色）。

    只给 apply 用——玩家走开后原格要露出脚下的东西，帧上看不到，只能猜；
    猜错就是预测错格，由 settle 记 P。实测 435 次走开里猜中 420 次（传送格、桥边上会猜错）。

    **票数打平就返回 None**（猜不出来），由 move_cells 决定不押那一格。
    第 264 步是这么换来的（68f13d794feb6ad5）：玩家在格(22,6) 上，北邻是整格实心色9 的桥（4 票），
    东邻是色2 地板（4 票），南邻是块 6/7 垫子（各 2 票）——4 比 4 平手，旧写法靠 max() 的字典序
    把它读成色9，实际是色2，白挨一次预测错。平手时哪一边赢是 Python 的遍历顺序说了算，不是世界说了算；
    与其发明一条「平手时偏向地板色」的世界事实（它一次都没走过闸），不如在这一格上闭嘴。
    四邻一个可走色都没有时同样返回 None：那是零证据，不是「答案是色2」。
    """
    cnt = {}
    for dr, dc in DELTA.values():
        tr, tc = r + dr, c + dc
        if tr < 0 or tc < 0 or tr + CELL > len(g) or tc + CELL > len(g[0]):
            continue
        for i in range(CELL):
            for j in range(CELL):
                v = g[tr + i][tc + j]
                if v not in BLOCK_COLORS and v != 14:
                    cnt[v] = cnt.get(v, 0) + 1
    if not cnt:
        return None
    top = max(cnt.values())
    winners = [v for v, n in cnt.items() if n == top]
    return winners[0] if len(winners) == 1 else None


def _unlit_diamond(g):
    """面板上随便一颗**灭着**的菱形的色X；一颗都没有返回 None。

    灭着的菱形是 4×4 里十五个色4 加右下角一个别的色。它只用来当「这一帧的面板上确实有图例那套菱形」的旁证：
    四颗菱形一次只可能亮一颗，所以只要有一颗亮着，就一定还有别的颜色的菱形灭着。
    只在已经找到一块孤立纯色 4×4 之后才调用（本身要扫 4×4 窗口，全帧每帧都跑会撑爆 settle 的预算）。
    """
    n, m = len(g), len(g[0])
    for r in range(n - 3):
        for c in range(PANEL_COL0, m - 3):
            if g[r][c] != 4:
                continue
            x = g[r + 3][c + 3]
            if x in (4, 5):
                continue
            if sum(1 for i in range(4) for j in range(4) if g[r + i][c + j] == 4) == 15:
                return x
    return None


def lit_diamond(g):
    """面板上那颗**亮着**的菱形：(色X, 它的 16 个像素)；没有亮着的返回 (None, None)。

    亮着的菱形就是面板上一块**孤立的 4×4 纯色块**——十六格同色X、外面一圈一个色X 都没有，
    **并且**同一张面板上还另有一颗灭着的菱形作旁证。面板上那几张卡是更大的连通图形，外圈一查就排掉了。
    不走 panel_diamond 的 flood：那个一帧要 flood 十几次，settle 会超时（第 890 步实测五条概念一起被 20s 预算掐断）。

    「另有一颗灭着的」这一条是拿误认换来的：只查「孤立的纯色 4×4」时，第 5 关面板上一张色10 的卡
    （行28-31 列43-46）正好也是孤立的纯色 4×4，全语料 863 条里有 137 条被它骗过去，
    而那一关根本没有图例屋、没有菱形。被骗的不是判据（这个函数一条断言都没进），是 apply：
    standing_on 顺着假菱形把玩家脚下读成标记格，四条动作概念加 cell_enterable 每走一步错四格。
    **孤立、尺寸对、颜色对，加起来仍然只是「长得像」**；要认出一套装置，得找它成套的证据。
    """
    n, m = len(g), len(g[0])
    for r in range(n - 3):
        for c in range(PANEL_COL0, m - 3):
            x = g[r][c]
            if x in (4, 5):
                continue
            if any(g[r + i][c + j] != x for i in range(4) for j in range(4)):
                continue
            ring = [(r + i, c + j) for i in range(-1, 5) for j in range(-1, 5)
                    if not (0 <= i <= 3 and 0 <= j <= 3)]
            if any(g[y][z] == x for y, z in ring if 0 <= y < n and 0 <= z < m):
                continue
            if _unlit_diamond(g) is None:
                continue
            return x, {(r + i, c + j) for i in range(4) for j in range(4)}
    return None, None



def pads(g):
    """地图区（列 < PANEL_COL0、行 < MAP_ROWS）里露着的抖动垫：{(r,c): (左上,右上,左下,右下)}。

    垫子 = 一格 2×2，四像素恰好是 PAD_PAIRS 里某一对、对角同色（[a,b / b,a]）。只按 CELL 对齐扫。
    """
    out = {}
    for r in range(0, MAP_ROWS - CELL + 1, CELL):
        for c in range(0, PANEL_COL0 - CELL + 1, CELL):
            px = (g[r][c], g[r][c + 1], g[r + 1][c], g[r + 1][c + 1])
            if px[0] != px[1] and px[0] == px[3] and px[1] == px[2] and frozenset(px) in PAD_PAIRS:
                out[(r, c)] = px
    return out


def standing_on(g):
    """玩家脚下那格的四像素 {(dr,dc): 色}——只在帧上真读得出来的时候给，否则 None。

    两种情形读得出来：
    1. 面板上有一颗菱形 16 像素全亮成色X，按 legend_marker_lights_diamond
       这说明玩家正踩在那块色X 的标记格上，而标记格的排法四块一律是 [1,0 / 0,X]（左上色1、右下色X）。
       这不是新事实，是把已经走过闸的那条概念反过来用：它断言「踩上去 ⇒ 菱形全亮」，
       这里用的是它的逆否在语料上成立（全语料里菱形全亮的帧，玩家都在标记格上）——所以它只进 apply，不进任何断言。
    2. 地图区只露着**一块**垫子：垫子成对出现，另一块正被玩家踩着，而且相位与露着的那块相反
       （pad_partner_under_player 管这条断言；这里只是把它反过来给 apply 用）。
       露着 0 块或 2 块以上都不猜——第 6 关有四块、还有一块从不翻的，那边的规矩不一样。
    3. 玩家的方块整个压在第 3 关的一条横条轨道上：按 card11_l3_bars_shift 的读法（玩家像素当未知）
       从可见像素里把横条的档位唯一读出来，玩家那一格落在档内就是踩在横条上，脚下是横条色（最右档色12，其余色1）。
       这也不是新事实：那条概念断言的就是「横条 6 像素宽、整条同色、玩家压着的部分照样在」，
       这里只是把它读出来的档位反过来用在脚下那一格。
       由来（第 841 步，退出码 5）：玩家从横条上走开，四邻猜法按上下两格的地板色猜成色2，实际露出的是横条的色1；
       猜法本来就写明「桥边上会猜错」，而这一关过桥就得在横条上走好几步，每一步都是一次押错。
    """
    x, _ = lit_diamond(g)
    if x is not None:
        return {(0, 0): 1, (0, 1): 0, (1, 0): 0, (1, 1): x}
    p = pads(g)
    if len(p) == 1:
        a, b, _, _ = next(iter(p.values()))
        return {(0, 0): b, (0, 1): a, (1, 0): a, (1, 1): b}
    u = bar_under_player(g)
    if u is not None:
        return {(i, j): u for i in range(CELL) for j in range(CELL)}
    return None


_SIBLING = {}


def sibling(name):
    """按文件路径装一条**同目录的概念**，给「一条读法借另一条概念」用；装不上返回 None。

    为什么不能直接 `import <名字>`（第 1804 步换来的，退出码 5 之前逮住）：
    装置装册子时并不把概念目录放进 sys.path，也不把概念放进 sys.modules
    （它把每份源码执行成自己的模块对象，只有 `_lib` 和 `geo` 被注册成可 import 的名字）。
    所以概念之间的 `import` 在**装置进程里永远抛 ModuleNotFoundError**，而在我自己写探针的进程里
    （我习惯先把概念目录插进 sys.path）永远成功——同一份源码、同一张帧，两边给不同的预测。
    旧写法 `except ImportError: return None` 把这件事咽了下去：借读法的那一条静默交白卷，
    调用方转头去四邻猜，猜错就是一次预测错，而账记在「册子说错了」头上。
    装不上要么是文件真没了、要么是它自己崩了——两种都该看得见，所以这里只在**文件不存在**时安静返回 None。
    """
    if name not in _SIBLING:
        import importlib.util                                       # noqa: PLC0415
        from pathlib import Path as _Path                           # noqa: PLC0415
        p = _Path(__file__).resolve().parent / f"{name}.py"
        if not p.exists():
            _SIBLING[name] = None
        else:
            spec = importlib.util.spec_from_file_location(name, p)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)                              # 崩了就让它崩：静默的读法比读不出来更贵
            _SIBLING[name] = m
    return _SIBLING[name]


def bar_under_player(g):
    """玩家踩在第 3 关的某条横条上时脚下的颜色（1 或 12）；不在轨道上、或档位读不唯一，返回 None。
    读法全部借 card11_l3_bars_shift（按文件路径装，见 sibling：概念之间 import 不到彼此）。"""
    a = me(g)
    if a is None:
        return None
    m = sibling("card11_l3_bars_shift")
    if m is None:
        return None
    BAND_R28, BAND_R38 = m.BAND_R28, m.BAND_R38
    BAR_WIDTH = m.BAR_WIDTH
    SLOTS_R28, SLOTS_R38 = m.SLOTS_R28, m.SLOTS_R38
    _read_bar_on_band = m._read_bar_on_band
    for rows, slots in ((BAND_R28, SLOTS_R28), (BAND_R38, SLOTS_R38)):
        if a[0] != rows[0] or not (slots[0] <= a[1] and a[1] + CELL <= slots[-1] + BAR_WIDTH):
            continue
        s = _read_bar_on_band(g, rows, slots)
        if s is None:
            return None
        if s <= a[1] and a[1] + CELL <= s + BAR_WIDTH:
            return 12 if s == slots[-1] else 1
        return None
    return None


def maybe_on_pad(g):
    """玩家脚下**可能**压着一块抖动垫：帧上有哪一对花色只露着一块。

    垫子成对出现（pad_partner_under_player），缺的那一块只可能被谁盖着；
    一对两块都露着，就说明这一对不缺人。四对里只要有一对缺一块，就没法排除「缺的那块在他脚底下」。
    （第 6 关四块垫子四种花色各一块，四对都「缺一块」——那一关这条一律算「可能」，宁可少说一格。）
    读不出玩家位置时也算「可能」。

    由来（第 1002 步 6d7a23705f1d802d，退出码 5）：玩家刚被色6 卡换位到一块垫子上，
    下一步走开，floor_under 按四邻把原格猜成地板色2，实际露出来的是那块 6/7 垫子，四格全错。
    猜法本来就写明「传送格会猜错」，而这一关的路线正要从垫子上起步。
    """
    a = me(g)
    if a is None:
        return True
    cnt = {}
    for px in pads(g).values():
        cnt[frozenset(px)] = cnt.get(frozenset(px), 0) + 1
    return any(n == 1 for n in cnt.values())


def move_cells(g, r, c, tr, tc):
    """apply 共用：玩家从 (r,c) 走到 (tr,tc) 时该预测的格——目的格涂 14，原格涂脚下的东西
    （能从帧上读出来就照读 standing_on，读不出来才按四邻猜 floor_under；连猜都猜不出来就不押原格）。
    目的格半步踏上十字件中心那圈色8 环的外沿时，框内那几个像素留原色（见 `ring_straddle_keep`）。"""
    out = {(tr + i, tc + j): 14 for i in range(CELL) for j in range(CELL)}
    for k, v in ring_straddle_keep(g, tr, tc).items():
        out[k] = v
    if (tr, tc) != (r, c):
        px = standing_on(g)
        if px is None:
            if maybe_on_pad(g):
                return out         # 脚下可能是块垫子：四邻猜法在垫子上必错，宁可不押原格
            u = floor_under(g, r, c)
            if u is None:          # 四邻票数打平：宁可少说一格，不说错一格
                return out
            px = {(i, j): u for i in range(CELL) for j in range(CELL)}
        for (i, j), v in px.items():
            out[(r + i, c + j)] = v
    return out


def walls(g):
    """阻挡像素集合：所有进不去的格的像素（给 lens.py map 画图用）。"""
    blocked = set()
    for r in range(0, len(g) - CELL + 1, CELL):
        for c in range(0, len(g[0]) - CELL + 1, CELL):
            if not enterable(g, r, c):
                for dr in range(CELL):
                    for dc in range(CELL):
                        blocked.add((r + dr, c + dc))
    return frozenset(blocked)


# ---- 面板上的卡 ------------------------------------------------------------
PANEL_COL0 = 42        # 列42 起是右侧卡面板，地图只算它左边（列40-41 是虚线分隔，偶有地图内容）
# 注意：第 6 关右上那间屋子的地板一直铺到列49（行4-11），也就是说「地图只到列40」在这一关是错的；
# 目前没有概念因此判错（那一片没有卡、也没走过），但拿 PANEL_COL0 当「地图右边界」用之前先量一遍。


def panel_diamond(g, x):
    """面板里带色X 标记的那颗菱形的像素集合：从面板的色X 像素起沿 {色4, 色X} 四连通铺开，取恰好 16 像素的那块；
    没有就返回 None。按颜色认不按坐标认——面板别处也可能有色X（那块四色小图标就有），所以用大小 16 筛。
    灭着的菱形是 15 个色4 + 右下角一个色X，亮着的是 16 个色X。

    读法一字未改，只是不再把同一块铺第二遍：铺出来不是 16 像素的那一块，它里面每一个色X 像素
    原来都会各自重铺一次（一次结算里这个函数被调了两万多次，占掉全册结算的大半时间，
    最后把一条概念顶出 20s 预算、以「跑不起来」关了闸）。一块铺不成，从它里面任何一点起铺都铺不成。
    """
    n, m = len(g), len(g[0])
    bad = set()
    for r in range(n):
        row = g[r]
        for c in range(PANEL_COL0, m):
            if row[c] != x or (r, c) in bad:
                continue
            seen = {(r, c)}
            st = [(r, c)]
            while st and len(seen) <= 16:
                y, z = st.pop()
                for dy, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p = (y + dy, z + dz)
                    if (0 <= p[0] < n and PANEL_COL0 <= p[1] < m
                            and p not in seen and g[p[0]][p[1]] in (4, x)):
                        seen.add(p)
                        st.append(p)
            if len(seen) == 16:
                return seen
            bad |= seen
    return None


def panel_diamonds(g):
    """面板上四颗菱形：{色X: 像素集合}。X 取自面板里出现过、且能围出 16 像素菱形的颜色。
    围不出菱形的颜色记进 miss，不再为它的每一个像素重问一遍（理由同 panel_diamond）。"""
    out = {}
    seen_px = set()
    miss = set()
    for r in range(len(g)):
        for c in range(PANEL_COL0, len(g[0])):
            x = g[r][c]
            if x in (4, 5) or x in out or x in miss or (r, c) in seen_px:
                continue
            d = panel_diamond(g, x)
            if d:
                out[x] = d
                seen_px |= d
            else:
                miss.add(x)
    return out


def diamond_dir(g, x):
    """这颗菱形管哪个方向：四颗摆成一个十字，最靠上那颗管上、最靠下管下、最靠左管左、最靠右管右。
    围死的图例屋里那四块标记格摆得一模一样（垫子上方那块的色X 正是这颗菱形的色），两处读法互为旁证。
    认不出（不是四颗、或分不出唯一的最上/最下/最左/最右）返回 None。"""
    ds = panel_diamonds(g)
    if len(ds) != 4 or x not in ds:
        return None
    ctr = {k: (sum(p[0] for p in v) / 16.0, sum(p[1] for p in v) / 16.0) for k, v in ds.items()}
    rs = sorted(ctr.values())
    top = min(ctr.values(), key=lambda t: t[0])
    bot = max(ctr.values(), key=lambda t: t[0])
    left = min(ctr.values(), key=lambda t: t[1])
    right = max(ctr.values(), key=lambda t: t[1])
    if len({top, bot, left, right}) != 4 or len(rs) != 4:
        return None
    me_ = ctr[x]
    return {top: "ACTION1", bot: "ACTION2", left: "ACTION3", right: "ACTION4"}.get(me_)


def glyph_size(g, r, c):
    """(r,c) 所在的同色四连通块有多少像素（面板上的卡是大块图形，小图标只有几个像素）。"""
    v = g[r][c]
    seen = {(r, c)}
    st = [(r, c)]
    while st:
        y, x = st.pop()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (y + dy, x + dx)
            if 0 <= p[0] < len(g) and 0 <= p[1] < len(g[0]) and p not in seen and g[p[0]][p[1]] == v:
                seen.add(p)
                st.append(p)
    return len(seen)


def clicked_card(g, action, color, min_glyph=8):
    """ACTION6 点的像素在 prev 里是这个颜色、落在面板区、且所在同色块至少 min_glyph 像素——
    卡按被点像素的颜色认，不按坐标；面板上 2×2 的小图标象限（拾到道具后出现的那种）不算卡。"""
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == color and glyph_size(g, r, c) >= min_glyph


PANEL_BG = 5           # 面板底色
MAP_ROWS = 62          # 行 62-63 是 HUD
GLYPH_MAX = 24         # 一块面板图形的外接框边长上限（地图整块是几十行几十列，卡面最大十几）


BOX_SIDE = 8           # 第 6 关那只空心方框的外接框边长
BOX_COLOR = 8


def box_ring(g, colour=BOX_COLOR, side=BOX_SIDE):
    """那只 side×side 空心方框的一周边框像素（side=8 时 28 个）：全帧找「一周边框整整齐齐
    全是这个颜色」的左上角，唯一才认，找不到或不止一个返回 None。

    为什么不按「恰好 28 像素的连通块」认（原来两条概念各自那么写的）：方框是**画在别的东西
    上面**的，它推到件跟前时，件身上那一小圈同色的像素会和方框的边框贴在一起，两者并成一个
    38 像素的连通块——于是「恰好 28 像素」当场认不出人。后果不是判错，是**闭嘴**：
    mover_px / apply_mover / 合口那条概念全部返回 None，而那个位置恰好是通往终点的必经之处
    （实测 zmerge.out：沿途四个落点里只有它并了块）。规划器因此在离终点两步的地方看不见路，
    搜索报「搜了几千个局面没到终点」，册子零反例——两边都不报警。

    换成按形状认之后，连通块怎么并都不影响：边框那一周是不是全这个颜色，一格一格看得出来。
    代价是它比「28 像素」松——一块实心的 side×side 也会被认成方框；本关没有那种东西
    （合了口的夹子是 6×6 实心去掉正中 2×2，边长不对），真出现了会被 assert_ 打脸。

    实现上先按行、按列各扫一遍「往右/往下连着 side 个同色」（H、V 两张表），再拿四条边拼；
    第一版逐个候选左上角现搭那一周 28 个像素，在色8 满地都是的关里慢到结算超时（20s 预算）。
    """
    n, m = len(g), len(g[0])
    if n < side or m < side:
        return None
    H = [[False] * m for _ in range(n)]          # (r,c) 起往右 side 个全是 colour
    V = [[False] * m for _ in range(n)]          # (r,c) 起往下 side 个全是 colour
    for r in range(n):
        run = 0
        for c in range(m - 1, -1, -1):
            run = run + 1 if g[r][c] == colour else 0
            H[r][c] = run >= side
    for c in range(m):
        run = 0
        for r in range(n - 1, -1, -1):
            run = run + 1 if g[r][c] == colour else 0
            V[r][c] = run >= side
    hit = []
    for r0 in range(n - side + 1):
        for c0 in range(m - side + 1):
            if (H[r0][c0] and H[r0 + side - 1][c0]
                    and V[r0][c0] and V[r0][c0 + side - 1]):
                hit.append({(r0 + i, c0 + j) for i in range(side) for j in range(side)
                            if i in (0, side - 1) or j in (0, side - 1)})
                if len(hit) > 1:
                    return None
    return hit[0] if hit else None


def panel_glyphs(g):
    """面板上一块块画出来的图形：行 0-61 里**非色5** 像素的八连通块，整块外 4 邻域只有色5（或帧边），
    且外接框两边都不超过 GLYPH_MAX。返回 [像素集合]，每块可以多色——开局时卡面外面套着一圈色0 边框、
    菱形是 15 个色4 加一个色X 的心，按单色取块会把它们拆散或漏掉。不拿列号划界：地图能铺到列 49。"""
    n, m = min(MAP_ROWS, len(g)), len(g[0])
    px = {(y, z) for y in range(n) for z in range(m) if g[y][z] != PANEL_BG}
    out = []
    for comp in components(px, diag=True):
        s = set(comp)
        rs = [p[0] for p in s]
        cs = [p[1] for p in s]
        if max(rs) - min(rs) >= GLYPH_MAX or max(cs) - min(cs) >= GLYPH_MAX:
            continue
        nb = {(y + dy, z + dz) for y, z in s for dy, dz in ((1, 0), (-1, 0), (0, 1), (0, -1))} - s
        if all(not (0 <= y < n and 0 <= z < m) or g[y][z] == PANEL_BG for y, z in nb):
            out.append(s)
    return out


# ---- 左下角横条轨道（第 6 关；点色11 卡转一档）----------------------------
from itertools import combinations  # noqa: E402

TRACK_BANDS = (54, 56, 58)          # 三条带，各两像素行
TRACK_SLOTS = (6, 8, 10, 12, 14, 16)  # 六个档位（横条左端列）
BAR_W = 6                           # 横条宽 6 像素
BAR_COLORS = (1, 12)                # 停在最右档显色12，其余色1
TRACK_LAST = TRACK_SLOTS[-1]


def _bar_cover(slots):
    out = set()
    for p in slots:
        out |= set(range(p, p + BAR_W))
    return out


def track_band(g, r0):
    """这条带上被横条盖住的列，还原成唯一的最小一组档位；还原不出来返回 None。
    横条会互相压住（同一带上两条只差两档时重叠两像素），所以不能直接数横段。"""
    track = range(TRACK_SLOTS[0], TRACK_LAST + BAR_W)
    mask = {c for c in track if g[r0][c] in BAR_COLORS}
    if mask != {c for c in track if g[r0 + 1][c] in BAR_COLORS}:
        return None
    if not mask:
        return None
    for k in range(1, len(TRACK_SLOTS) + 1):
        hit = [s for s in combinations(TRACK_SLOTS, k) if _bar_cover(s) == mask]
        if len(hit) == 1:
            return hit[0]
        if hit:
            return None
    return None


MAP_COLS = 40          # 地图只算列 0-39（列40-41 是虚线分隔，见 PANEL_COL0）
PIECE_COLORS = (12, 8)  # 第 6 关那件大十字件的两种色：件身色12、嵌在中心那圈环色8


def cross_piece(g):
    """地图区里色12/8 的最大四连通块（方框的像素不算）；不像那件十字件就返回 None。
    返回 (像素表 {(r,c): 色}, 环心 (半整数, 半整数))。

    **这是读法，不是主张**：件长什么样、转不转、怎么转，全归 `card6_rotates_piece`（它的 SCOPE 把这里的每一道
    筛子逐条写成了自己主张的一部分）。挪进词汇表只因为三条概念要共用它
    （card6_rotates_piece / card6_flips_pad_phase / card6_refused_if_player_stranded），
    而 settle 把概念模块登记成 `concept_<名>`、且不进 sys.modules，概念之间根本 import 不到彼此
    ——第 1618 步那一回就是这么绕空的：新筛子在探针里生效，在 settle 里恒为 None，判词一个字没变。

    挖掉方框那 28 个像素会**把件拦腰切断**：方框横跨件身上时，剩下的是芯加四条断臂，
    而其中的芯（正好是件中心那一圈色8 环加它围着的色12）自己也能过完这里的每一道筛子。
    所以挖完要数一句：碰着方框的残块不止一块，就说明方框切开了什么，这一帧认不出件，返回 None。
    只碰着一块时照旧（方框只啃掉件的一角）。
    """
    seen = set(box(g) or ())
    bx = frozenset(box(g) or ())
    best = {}
    blobs = []
    for r0 in range(MAP_ROWS):
        for c0 in range(MAP_COLS):
            if g[r0][c0] not in PIECE_COLORS or (r0, c0) in seen:
                continue
            cur = {}
            st = [(r0, c0)]
            seen.add((r0, c0))
            while st:
                r, c = st.pop()
                cur[(r, c)] = g[r][c]
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p = (r + dr, c + dc)
                    if (0 <= p[0] < MAP_ROWS and 0 <= p[1] < MAP_COLS and p not in seen
                            and g[p[0]][p[1]] in PIECE_COLORS):
                        seen.add(p)
                        st.append(p)
            blobs.append(cur)
            if len(cur) > len(best):
                best = cur
    if bx:
        touch = sum(1 for cur in blobs
                    if any((r + dr, c + dc) in bx
                           for (r, c) in cur
                           for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))))
        if touch > 1:
            return None        # 方框把某个东西切成了几块，这一帧说不出件有多大
    ring = [k for k, v in best.items() if v == 8]
    if len(ring) < 8 or sum(1 for v in best.values() if v == 12) < 20:
        return None
    r0, r1 = min(r for r, _ in ring), max(r for r, _ in ring)
    c0, c1 = min(c for _, c in ring), max(c for _, c in ring)
    if r1 - r0 != c1 - c0 or (r1 - r0) % 2 == 0:
        return None            # 外接框要是边长偶数的正方形（中心落在半整数上）
    border = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
              if r in (r0, r1) or c in (c0, c1)}
    if not set(ring) >= border:
        return None            # 色8 至少得把那个框的边圈满，缺口的不算环
    pr = [r for r, _ in best]
    pc = [c for _, c in best]
    if ((min(pr) + max(pr)) / 2, (min(pc) + max(pc)) / 2) != ((r0 + r1) / 2, (c0 + c1) / 2):
        return None            # 件得以环为心；偏心的那件绕环心转出来根本不成形
    return best, ((r0 + r1) / 2, (c0 + c1) / 2)


def cross_piece_with_player(g):
    """玩家正踩在那件大十字件上时，把他四像素**当件色补回去**再认出来的那件件；否则 None。

    补色这一手和 `card11_refused_if_player_stranded._shifted` 是同一招——玩家挡住的那几格按
    「他压着的是这东西」补上去，认得出整件（`cross_piece` 的每一道筛子照过）、且他那四格确实落在件里，
    才算他踩在件上。返回 (件的像素表, 环心)。
    """
    a = me(g)
    if a is None:
        return None
    h = [list(r) for r in g]
    for i in range(CELL):
        for j in range(CELL):
            h[a[0] + i][a[1] + j] = PIECE_COLORS[0]
    got = cross_piece(h)
    if got is None:
        return None
    cells = got[0]
    if not all((a[0] + i, a[1] + j) in cells for i in range(CELL) for j in range(CELL)):
        return None                 # 他站在件旁边，不是站在件上
    return got


def ring_straddle_keep(g, tr, tc):
    """走进 (tr,tc) 这一格时，目的格里**不该被涂成色14** 的那几个像素及其原色（没有就空表）。

    由来：十字件中心那圈色8 环，玩家半步踏上它的外沿时，环画在玩家上面——`me()` 四版前就为这件事
    补过**读**侧（不再要求格位四像素全是色14，靠色14 像素最多认人），可 `move_cells` 这个**写**侧
    一直无条件把目的格整格涂 14，预测帧在被环占着的那半格上说假话；`assert_` 只量位移，从来量不到它。
    判据是「目的格四像素**跨过环自身外接框的边界**」：整格落在框内是环内部的普通挪动，照常盖成 14。
    这句话本身写成概念 `move_into_piece_ring_keeps_ring_pixels` 走闸（它拿真帧的 nxt 逐像素核这里的读法），
    放进词汇只因为五条方向键概念的 apply 共用 `move_cells` 这一个落子口。
    """
    got = cross_piece(g)
    if got is None:
        return {}
    ring = {k for k, v in got[0].items() if v == 8}
    if not ring:
        return {}
    target = {(tr + i, tc + j) for i in range(CELL) for j in range(CELL)}
    overlap = target & ring
    if not overlap:
        return {}
    r0 = min(r for r, _ in ring)
    r1 = max(r for r, _ in ring)
    c0 = min(c for _, c in ring)
    c1 = max(c for _, c in ring)
    if all(r0 <= r <= r1 and c0 <= c <= c1 for (r, c) in target):
        return {}                   # 整格都在环的外接框里：正常覆盖，不是这个例外
    return {(r, c): g[r][c] for (r, c) in overlap}


def track_after_shift(g):
    """三条带各转一档之后，轨道区（三带 × 列6-21）每个像素的颜色；任一带读不出返回 None。
    最右档的横条显色12，被别的横条压住的部分仍显色1。"""
    pred = {}
    for r0 in TRACK_BANDS:
        slots = track_band(g, r0)
        if slots is None:
            return None
        moved = [TRACK_SLOTS[0] + (p - TRACK_SLOTS[0] + 2) % (len(TRACK_SLOTS) * 2) for p in slots]
        paint = {}
        for p in sorted(moved, reverse=True):          # 色1 的横条压在色12 那条上
            for c in range(p, p + BAR_W):
                paint[c] = 12 if p == TRACK_LAST else 1
        for r in (r0, r0 + 1):
            for c in range(TRACK_SLOTS[0], TRACK_LAST + BAR_W):
                pred[(r, c)] = paint.get(c, 4)
    return pred
