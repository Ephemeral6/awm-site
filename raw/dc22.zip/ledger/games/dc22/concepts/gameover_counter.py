"""HUD 计数器触发 GAME_OVER：连续失败动作达到阈值后游戏结束。"""
LEVEL = "L5"
SCOPE = "所有动作；只看 state 转换为 GAME_OVER 的那一步"
NOTE = "HUD(63,62)和(63,63)计数失败动作（被阻挡的移动），各自达到3后触发 GAME_OVER"
EVIDENCE = ["c2466cdf9b27fd8b"]
BLOCKING = False

def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    # 只检查 GAME_OVER 触发那一步
    if ctx.get("state") != "GAME_OVER":
        return "NA"
    # GAME_OVER 由上游给出，这里只确认它发生了
    return "TRUE"
