"""点面板上那张色6 的卡：地图上那件色12 的大十字件（连同嵌在它中心的那圈色8）绕色8 环的中心转 90°——转后每一个像素的颜色，等于转前它对应位置的颜色；只有被那只 8×8 色8 空心方框压住的像素例外，它们显方框的色8。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色6、落在面板区（列>=42）；换关返回 NA；地图区（列<40、行<62）里色12 与色8 的四连通块"
         "（先把 _lib.box 那 28 个像素挖掉）中最大的那块，下列任一条不成立就返回 NA："
         "色8 至少 8 像素、色12 至少 20 像素、色8 的外接框是边长为偶数的正方形、"
         "**色8 把那个外接框的边圈满了**（缺一个角的不算环）、"
         "**整块件的外接框中心与色8 环的中心重合**、"
         "**挖掉方框之后碰着方框的残块只有一块**（不止一块说明方框把什么切开了，这一帧认不出件有多大）。"
         "**玩家此刻正踩在件上（`_lib.cross_piece_with_player` 认得出）、而转完之后件不再盖着他脚下那四格的，返回 NA**"
         "——那一下点击整个被拒，归 card6_refused_if_player_stranded 管。"
         "他踩在件上而转完仍盖着他的，照转，**但他那四像素不断言**（他不跟着件走，那四格仍是玩家色）。"
         "（别的关里色12 是别的东西：夹子、轨道上停在最右档的横条、爪子吊着的那根杆。）件转走之后空出来的格露出什么，这条概念不管。")
NOTE = ("v7: 把 v6 那道筛子从「踩在件上就闭嘴」缩成「踩在件上**且转完不再盖着他**才闭嘴」，"
        "并补上「照转的那一档，玩家那四像素不断言」。"
        "由来：v6 与 card6_refused_if_player_stranded 两条概念各自把「踩在件上而转完仍盖着他」那一档写成 NA，"
        "理由都是「语料里一个样本都没有」——两条加起来，册子在这一档上整体闭嘴。"
        "代价到终局卡第 5 关才现形：玩家被围在件和它两头那两小片地里（67 格），"
        "册子说得出话的点击没有一下开得出新地面，规划器退出码 1 报「这一步开不出任何新东西」。"
        "而这一档恰好是唯一的出路——他站在件上转完仍被盖住的那 8 格里任一格点色6，"
        "件由竖转横（行32-35 列0-19 加行30-37 列8-13），脚下这一关从没走到过的 11 格当场露出来（zpark5.out）。"
        "**这不是新规矩，是本局已经走过闸的那一条的另一面**：card11_refused_if_player_stranded 断言"
        "「转完一档后玩家脚下仍是横条 ⇒ 横条照转、玩家原地不动；脚下会露出背景 ⇒ 整个点击被拒」，"
        "S=1 活到现在。件和横条是同一类东西：踩得上去的、会动的地板。这里把同一句话搬到件上，"
        "**它是预测不是观察**——真走到那一步若是被拒，就是退出码 5 打在这条上，那时再缩回去。\n"
        "v6: 判据的主张一字未动，又多一道筛子：**玩家踩在件上就返回 NA**（apply 同步闭嘴）。"
        "由来：终局卡第 1618 步（fa5c215846869cb6）退出码 5——玩家站在竖着的件上（件只剩 96 像素）点色6 卡，"
        "这条押了一整套 90° 旋转、错 48 格，而真帧上地图区一格没动。"
        "这一档不是「件怎么转」的问题，是「这一下点击成不成立」的问题："
        "件转完之后不再盖着他脚下那一格，整个点击被拒（card6_refused_if_player_stranded，"
        "与 card11_refused_if_player_stranded 同型）。缩到这里，就别再声称管那一片。\n"
        "同一版里认件那段代码（原 `_piece`）原样挪进词汇表 `_lib.cross_piece`，主张与筛子一个字没改。"
        "只因三条概念要共用它，而 settle 把概念执行成 `concept_<名>` 且不放进 sys.modules，概念之间 import 不到彼此："
        "第一稿把新筛子写成「从 card6_rotates_piece 延迟导入」，在探针里生效、在 settle 里恒为 None，"
        "判词一个字没变、闸照样关着。**代价要认**：挪进词汇表的东西不再单独打分（`_lib` 不评版本、不算存活率），"
        "这几道筛子从此只由本条概念的 S 兜着。\n"
        "v5: 判据的主张一字未动，只多一道筛子：挖掉方框之后**碰着方框的残块不止一块就返回 NA**。"
        "为什么（第 1109-1111 步）：方框推到件的正中央时，挖掉它那 28 个像素等于把件拦腰切断，"
        "剩下芯（行31-36 列7-12）加四条断臂；而那个芯自己就是「色8 环围着色12、同心、边长偶数」，"
        "v4 的每一道筛子它都过，于是 `_piece` 把件的**芯**当成了整件件，`apply_cover` 跟着只报 32 格。"
        "断言那边没被打脸纯属侥幸：那三步里没人点色6 卡。规划器那边当场付了账——"
        "件另外 72 个像素被当成没人盖着，它们那一身色12 被记进了规划器的底色表，"
        "件一挪窝就在原地留下半件影子（104→120 像素），认件的概念再也读不出唯一一块，"
        "搬运那一整段没有终点可言（zmacro12.out、zmacro15.out、zmacro16.out）。"
        "教训：**一个物件的碎片常常和这个物件长得一模一样**，凡是靠「挖掉挡在上面的东西再认连通块」的读法，"
        "都要回头问一句「我挖的那一刀是不是把它切开了」。\n"
        "v4: 判据、apply、SCOPE 一字未动；补两个**只供规划器**的接口 apply_cover（件此刻占哪些像素）与 apply_mover（这一下转前/转后各占哪些像素）。"
        "为什么补（第 1094 步）：规划器沿 STEP 算出的下一帧比真帧多 52 个色12——件转走空出来的像素没人擦，"
        "本条概念按 SCOPE 对它们不开口，规划器又不知道件是个会挪窝的物件；帧对不上，计划册每批脱线重算，重算的路线又以同一下点击开头，于是在两块垫子之间来回传送。\n"
        "v3: 只缩 scope，主张一字未动，全语料 1882 条上判词一条没变（zdiffver.py 逐条对过 v2）。"
        "第 870 步爪子吊着杆停在行10-21 列14-25 时，色12/8 的最大连通块 84 像素"
        "（色8 30 像素、色12 54 像素，色8 外接框行12-19 列14-21 正好是 8×8 的偶数边长正方形）把 v2 的三道筛子全过了，"
        "这条概念于是对着爪子押了一个 84 像素的 90° 旋转；而语料里这一关点过四次色6 卡"
        "（78a807f6afbc0234、61b82fb7e62b0482、6f63b2040471f6df、2047fd895b5b37ec），帧差只有 8~9 像素，全是垫子翻色，"
        "爪子一个像素都没动过。**它当时返回 NA 不是因为筛子说对了，是因为爪子恰好停在别处**——"
        "筛子拦住的是位置，不是身份。\n"
        "起判别作用的是「同心」那一条：十件转过的转移里，件的外接框心与环心都分毫不差"
        "（一件是 100px/环 12px 4×4，另一件是 104px/环 32px 6×6，两件都同心）；爪子那边件心 (15.5, 19.5)、"
        "环心 (15.5, 17.5)，差两列。这也正是「绕环心转 90° 还是同一件东西」的前提：件不以环为心时，转出来的像素落点根本不成形。"
        "**第一稿把这一条写成了「色8 恰好是空心边框」，当场误伤六条**（e554eb99a042dda5、c82bd57507567b1e、"
        "005de826f51a67c0、9f0ddb2d05ed07ce、bc2ba7f40e64b0ba、e6cf973b4196ed33 由 TRUE 变 NA）——"
        "那件 104px 的环是 6×6 里塞了 32 个色8，比边框厚，「空心」是我照着另一件想当然写的。改成「圈满即可」。\n"
        "v1: 第 6 关三次点色6 卡（66dd5ee813d3552a、68493cf78d4e17f9、308c7e1468ec1b80），色12/8 的最大连通块 100 像素在「竖着：行24-43 列6-13」和「横着：行30-37 列0-19」之间来回；穷举半整数中心与两个转向，唯一解都是绕 (33.5, 9.5) 转 90°，也就是色8 环（行32-35 列8-11）的正中。件本身 180° 对称，所以左转右转分不出来。\n"
        "v2: 第 978 步（f56dd4c5c8a0504f）方框停在行34-41 列18-25，件转成横的之后右端（行34-35 列18-19）压进方框的边框，那 3 个像素显 8 不显 12——方框画在件上面。"
        "两处改：认件时先把方框的 28 个像素挖掉（不然横着的件和方框连成一块 128 像素的色12/8 连通块，环的外接框不再是正方形，整条概念哑掉）；"
        "断言里凡落在方框边框上的像素改押 8。")
EVIDENCE = ["66dd5ee813d3552a", "68493cf78d4e17f9", "308c7e1468ec1b80", "f56dd4c5c8a0504f",
            "78a807f6afbc0234", "61b82fb7e62b0482", "6f63b2040471f6df", "2047fd895b5b37ec",
            "fa5c215846869cb6"]

from _lib import CELL, MAP_COLS, MAP_ROWS, PANEL_COL0, PIECE_COLORS, box, me  # noqa: E402,F401
from _lib import cross_piece as _piece  # noqa: E402
from _lib import cross_piece_with_player  # noqa: E402


def _clicked_six(g, action):
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == 6


def _player_cells(g):
    a = me(g)
    if a is None:
        return None
    return {(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)}


def _rot(g):
    """返回 (转后像素表, 玩家那四格) —— 玩家没踩在件上时第二项是空集；认不出或被拒返回 None。"""
    got = cross_piece_with_player(g)
    mine = frozenset()
    if got is not None:
        mine = _player_cells(g)
        if mine is None:
            return None
    else:
        got = _piece(g)
    if got is None:
        return None
    cells, (k, h) = got
    b = box(g) or frozenset()
    out = {}
    for (r, c), v in cells.items():
        rr, cc = k + (c - h), h - (r - k)
        if not (float(rr).is_integer() and float(cc).is_integer()):
            return None
        p = (int(rr), int(cc))
        out[p] = 8 if p in b else v
    if mine:
        if not all(p in out for p in mine):
            return None        # 转完之后件不再盖着他：整下点击被拒，归 card6_refused_if_player_stranded
        for p in mine:
            out.pop(p, None)   # 他不跟着件转，那四格仍是玩家色——这条概念不断言
    return out, frozenset(mine)


def _rotated(g):
    got = _rot(g)
    return None if got is None else got[0]


def assert_(prev, action, nxt, ctx=None):
    if not _clicked_six(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    img = _rotated(prev)
    if img is None:
        return "NA"
    for (r, c), v in img.items():
        if not (0 <= r < MAP_ROWS and 0 <= c < MAP_COLS) or nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _clicked_six(prev, action):
        return None
    img = _rotated(prev)
    if img is None:
        return None
    return {k: v for k, v in img.items() if 0 <= k[0] < MAP_ROWS and 0 <= k[1] < MAP_COLS}


def apply_cover(prev, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：那件十字件此刻占了哪些像素（只报坐标，不报颜色）。

    和 `card_l4_claw_slides.apply_cover` 是同一个接口：规划器要在每一张真帧上知道「哪些地面此刻被件盖着」，
    才记得住件底下的底色——盖着的时候看见的是件，不是地面。这条概念本来就写明「件转走之后空出来的格露出什么，
    这条概念不管」；规划器管，靠的是它自己见过件在另一个朝向时露出来的那一眼。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    got = _piece(prev)
    return set(got[0]) if got else None


def apply_mover(prev, action, ctx=None, ground=None):
    """**只供规划器，永不参与断言、不进结算**：这一下点击里件转之前/转之后各占哪些像素；认不出返回 None。

    主张一字没动：转后像素集就是 `_rotated` 的键。规划器拿它做记账——转走空出来的像素还原成记性里的底色，
    新盖住的记进记性。没有它，规划器的帧在每一次点色6 卡之后都多出几十个空出来却没擦掉的色12，
    帧和真帧对不上，计划册每一批都「脱线」重算，而重算出的路线又总以同一下点击开头。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if not _clicked_six(prev, action):
        return None
    got = cross_piece_with_player(prev) or _piece(prev)
    rot = _rot(prev)
    if got is None or rot is None:
        return None
    img, mine = rot
    return set(got[0]) - set(mine), set(img)
