"""点面板上那张色11 的卡时，玩家不跟横条走：若转完一档后玩家脚下那一格仍是横条（四像素全色1 或全色12），横条照转、玩家原地不动；若转完后脚下会露出背景，整个点击被拒——地图区（行0-61、列0-39）一格不变。"""
LEVEL = "L2"
SCOPE = "只看 ACTION6 且被点像素在 prev 里是色11、且落在面板区（列>=42）；换关返回 NA；me() 定位不到、玩家不在轨道三条带（行54-59 列6-21）上、或轨道读不出档位（_lib.track_band）的返回 NA。只断言玩家位置与地图区变没变，横条画到哪归 card11_bars_shift。"
NOTE = "v1: 玩家站在行54 档16 的横条上点卡（69e10350306ba851），横条该绕回档6、玩家脚下会变成背景，整帧只有 HUD 涨了一格；玩家站在行56 档14 的横条上点卡（90671ef12ba173cd），转完档16 仍盖着玩家，横条照转、玩家没动。两条合起来：不是载具，也不是一律拒——拒不拒看转完之后脚下有没有横条。第 5 关滑块的先例同型。"
EVIDENCE = ["69e10350306ba851", "90671ef12ba173cd"]

from _lib import me, CELL, clicked_card, track_after_shift, TRACK_BANDS, TRACK_SLOTS, TRACK_LAST, BAR_W

MAP_COLS = 40
MAP_ROWS = 62


def _on_track(a):
    return a is not None and a[0] in TRACK_BANDS and TRACK_SLOTS[0] <= a[1] < TRACK_LAST + BAR_W


def _player_cells(a):
    return [(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)]


def _shifted(prev, a):
    """把玩家四像素当横条色1 读档位，转一档后的轨道像素；读不出返回 None。"""
    h = [list(r) for r in prev]
    for r, c in _player_cells(a):
        h[r][c] = 1
    return track_after_shift(h)


def _bar_stays_under(pred, a):
    px = {pred.get(k) for k in _player_cells(a)}
    return px <= {1} or px <= {12}


def _map_same(prev, nxt):
    return all(prev[r][:MAP_COLS] == nxt[r][:MAP_COLS] for r in range(MAP_ROWS))


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, 11):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = me(prev)
    if not _on_track(a):
        return "NA"
    pred = _shifted(prev, a)
    if pred is None:
        return "NA"
    if _bar_stays_under(pred, a):
        return "TRUE" if me(nxt) == a and not _map_same(prev, nxt) else "FALSE"
    return "TRUE" if _map_same(prev, nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, 11):
        return None
    a = me(prev)
    if not _on_track(a):
        return None
    pred = _shifted(prev, a)
    if pred is None:
        return None
    if not _bar_stays_under(pred, a):
        return {}                                    # 被拒：地图区一格不变
    return {k: 14 for k in _player_cells(a)}         # 玩家原地；横条怎么画归 card11_bars_shift
