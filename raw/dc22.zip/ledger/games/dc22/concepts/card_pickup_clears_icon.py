"""玩家走进地上那块卡图标（底色 F 上一个 `.XX.` 压 `XXXX` 的图形，六个像素没有一个是 F，图形压着的两格都走得进去）所占的、含图形像素的格：那 6 个图形像素全变成底色 F（被玩家 2×2 盖住的除外）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1/2/3/4；换关返回 NA；me() 在 prev 或 nxt 里定位不到返回 NA；"
         "prev 的地图区（行<62、列<38）里，某行读作 `F ? ? F`（中间两格都不是 F）、紧接着一行四格都不是 F、"
         "这四列的左端按 CELL 对齐、且这两格（左端格与它右边那一格）都 enterable 的那 6 个像素叫卡图标；"
         "玩家这一步的落点格不在某块卡图标里、或落点格一个图形像素都不含时返回 NA；"
         "只断言那 6 个图形像素在 nxt 里的颜色，别的一格都不管——面板上多出来的那张卡落在哪一行，"
         "这条概念说不出来（全语料只有两次捡单色卡：第 1 关色8 落在面板行29、第 4 关色15 落在行12，"
         "两次的面板布局对不上同一个槽位规则），所以它压根不断言面板。")
NOTE = ("v3: 图形的六个像素不必同色。第 6 关行18-19 列6-9 躺着一块**四色**卡图标（底色2 上 11/10 压 8,8,7,7），"
        "形状和单色卡一模一样，走进去同样清空、面板上同样多出那块四色小图标（87e8322fdd265a8c、58ab7d171373c1cf，"
        "两次都是从 (20,8) 走到 (18,8)，六格里没被玩家盖住的三格全变成底色2）。"
        "旧认法要求六格同色，于是这一块在册子眼里根本不是卡：规划器的「够得到的卡图标」集合是空的，"
        "而这一关唯一能改垫子花色的东西就是那块四色图标——**够不到它就通不了关**，"
        "而这个缺口不会报错，只表现为「搜不到路」。\n"
        "放宽颜色之后要有别的东西顶住：全语料上只放宽颜色会多认出 11 处（都在第 3 关那片色8 背景的花纹里，"
        "底色8、图形色 0/12/4），它们一处都不是物件。补的那一条是「图形压着的两格都 enterable」——"
        "地上的卡是走进去捡的，走不进去的就不是卡。补上之后全语料认出的正好是 5 处：旧的 4 处一处不少，"
        "加上第 6 关这块四色的（runs 里 zicon6.py，2022 条语料逐帧数过）。\n"
        "v1: 第 210 步（2fb7fe51）和第 417 步（dfb2365b）。第 1 关行52-55 列16-19 是一块底色2 上的色8 图标，"
        "玩家从 (50,16) 走到 (52,16) 那一步，图标的 6 个色8 像素里 5 个变成色2、剩下 1 个 (53,17) 被玩家盖住，"
        "同时面板行29-33 冒出一张色8 的卡；第 4 关行18-21 列10-13 是同样形状的色15 图标，走进 (18,10) 之后"
        "同样清空、面板行12-16 冒出色15 卡。**这是第 1 关能不能通的关键**：不捡这张色8 卡，"
        "离场规划器把整个可点局面空间（80 个）搜完都到不了目标；捡了之后 24 步就到。\n"
        "为什么不连面板一起断言：两次捡卡落的行（29 与 12）在各自关的面板布局里既不是等距槽位、"
        "也不是「最大空隙居中」——两个样本推不出规则，硬写一条就是编。规划器改成把「捡卡」当成一段路线的终点，"
        "下一批从真帧重新规划，那时面板上已经有那张卡了。\n"
        "v2: 认图标的条件从「外面那个 CELL 对齐的 4×4 框整块只有两色」放宽成「只看图形自己那两行 + 左端列对齐」。"
        "起因是第 2 关的图标（行42-43 列16-19 色15、底色2）下面紧挨着色4 的墙，4×4 框里三色，被旧条件挡掉，"
        "离场规划器在第 2 关起手那一局面上报「也没有一块够得到的卡图标」。列对齐这条留着："
        "全语料这个图案只出现在 5 处，4 处列号偶数（第1/2/4/5 关各一，都是真图标），"
        "第 5 处第 4 关行53-54 列23-26（色4 压在色15 上）列号是奇数，是相位花纹里凑出来的，不是物件。")
EVIDENCE = ["2fb7fe5122ee4500", "dfb2365b376e1f1b", "87e8322fdd265a8c", "58ab7d171373c1cf"]
# 语料里另外两次捡卡（758756a8、77e2414a，上一个 run 的同两处）留在闸里考它。

from _lib import CELL, DELTA, MAP_ROWS, enterable, me

MAP_COLS = 38


def icons(g):
    """地图区里所有卡图标：{(图形左上行, 图形左上列): (底色F, 那 6 个图形像素)}。

    认法只看图形本身的两行：行r 读作 `F ? ? F`（中间两格都不是 F）、行r+1 四格都不是 F，左上列按 CELL 对齐，
    并且图形压着的那两格（左端格、它右边那一格）都 enterable。
    v1 还要求外面那个 4×4 框整块只有两色——第 2 关那块图标（行42-43 列16-19）下面紧挨着色4 的墙，
    框里三色，被这条多余的条件挡掉了。
    v2 要求六个像素同色——第 6 关那块四色图标（行18-19 列6-9）因此不算卡，而它是那一关唯一能改垫子花色的东西。
    列对齐这一条留着：这一局的物件没有一件不按格对齐（第 4 关行53-54 列23-26 那处色4 压色15 的花样列号是奇数，
    它是棋盘格相位区里凑出来的，不是物件）。
    「两格都走得进去」是放宽颜色之后顶住花纹的那一条：地上的卡是走进去捡的，走不进去的就不是卡。
    """
    out = {}
    n = min(MAP_ROWS, len(g))
    for r in range(n - 1):
        for c in range(0, MAP_COLS - 3, CELL):
            f = g[r][c]
            if g[r][c + 3] != f or g[r][c + 1] == f or g[r][c + 2] == f:
                continue
            if any(g[r + 1][c + j] == f for j in range(4)):
                continue
            rr = r - r % CELL
            if not enterable(g, rr, c) or not enterable(g, rr, c + CELL):
                continue
            px = frozenset({(r, c + 1), (r, c + 2)} | {(r + 1, c + j) for j in range(4)})
            out[(r, c)] = (f, px)
    return out


def _hit(g, cell):
    """玩家落点格压在哪块卡图标上（这一格里确实有图形像素）；没有返回 None。"""
    own = {(cell[0] + i, cell[1] + j) for i in range(CELL) for j in range(CELL)}
    for (f, px) in icons(g).values():
        if own & px:
            return f, px
    return None


def pickup_cells(g):
    """这一帧上「走进去就会捡到卡」的格：含图形像素的那些格。规划器拿它当路线终点。"""
    out = set()
    for (f, px) in icons(g).values():
        for (r, c) in px:
            out.add((r - r % CELL, c - c % CELL))
    return out


def _target(prev, action):
    if action not in DELTA:
        return None
    a = me(prev)
    if a is None:
        return None
    dr, dc = DELTA[action]
    return (a[0] + dr, a[1] + dc)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    t = _target(prev, action)
    if t is None:
        return "NA"
    b = me(nxt)
    if b is None or b != t:
        return "NA"                      # 没走成（撞墙、或落点和预期不同）就不是这条概念的事
    h = _hit(prev, t)
    if h is None:
        return "NA"
    f, px = h
    cover = {(b[0] + i, b[1] + j) for i in range(CELL) for j in range(CELL)}
    for (r, c) in px:
        if (r, c) in cover:
            continue
        if nxt[r][c] != f:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    t = _target(prev, action)
    if t is None:
        return None
    h = _hit(prev, t)
    if h is None:
        return None
    f, px = h
    cover = {(t[0] + i, t[1] + j) for i in range(CELL) for j in range(CELL)}
    return {(r, c): f for (r, c) in px if (r, c) not in cover}
