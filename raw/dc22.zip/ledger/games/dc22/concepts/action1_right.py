"""ACTION1 让 me 上移 2 像素行，或整帧不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA；prev == nxt 只改 HUD 的转移返回 NA"
NOTE = "v10: 判据一个字没动，改的是 apply——目标格是色11 块（_lib.is_goal）时不再开口。走进它就换关，换关那一帧整屏重画，" + \
    "「玩家从这格挪到那格」这句话在那一步根本没有逐格对应的意思；照押就是每次过关都白挨一次预测错。v9: apply 把腾出的原格也押上——颜色按 _lib.floor_under 由四邻猜（435 次走开猜中 420 次）；不押原格时链式预测的模拟帧里会留下两个色14 块，me() 认错人，第 617 步整批因此停掉。v8: apply 改成先查目标格进不进得去（_lib.enterable：四像素同色且色不是4/5）——进不去就押原地不动。v7: 换关那一帧整屏重画返回 NA；apply 不再把腾出的格子押成色2（玩家站在桥/臂上时腾出的格子回到那件东西的颜色，prev 看不见脚下），只押新位置。v6: 第 23 步遇阻挡：只改了 HUD (63,9)，me 未移动，prev == nxt 除 row 63 外。HUD 不算帧变化。"
EVIDENCE = ["89db1714b36607f3", "f81f81a1f3c1165e"]

from _lib import me, CELL, enterable, move_cells, is_goal

def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION1"):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    # 只改 HUD (row 63) 的转移不算帧变化
    if a == b:
        return "NA"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (-CELL, 0) else "FALSE"

def apply(prev, action, ctx=None):
    if not action.startswith("ACTION1"):
        return None
    pos = me(prev)
    if pos is None:
        return None
    r, c = pos
    tr, tc = r - CELL, c
    # 走进色11 块就换关，整帧重画，这条概念说不出那一帧——闭嘴
    if is_goal(prev, tr, tc):
        return None
    # 目标格进不去就押「原地不动」；进得去就押新位置变色14
    if not enterable(prev, tr, tc):
        return move_cells(prev, r, c, r, c)
    return move_cells(prev, r, c, tr, tc)
