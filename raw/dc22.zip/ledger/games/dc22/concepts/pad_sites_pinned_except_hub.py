"""第6关（装置显示「过关 5/6」）的四块抖动垫里，只有 (48,18) 那一块会换花色：
(4,4) 恒是 {11,12}、(52,32) 恒是 {6,7}、(58,34) 恒是 {9,10}，没有任何动作改得了它们；
点面板那块 2×2 小图标时，换色的永远是 (48,18) 那一块，按 (6,7)→(13,8)→(12,11)→(9,10)→(6,7) 走一档，
主色位置仍放主色；那一块被玩家压着时，四个像素照样是玩家色，地图区一格不动。
"""
LEVEL = "L6"

SCOPE = (
    "只看第6关（格位 (4,4)/(48,18)/(52,32)/(58,34) 这一套抖动垫布局）：prev 或 nxt 的地图区里"
    "出现了这四个格位之外的抖动垫，返回 NA —— 别的关卡不是这张图。换关（ctx.level_prev != ctx.level_next）"
    "返回 NA。两帧的地图区里一块垫子都露不出来时返回 NA。"
    "断言只管这四个格位上的四像素，别处怎么变一概不管（件在挪、方框在挪、玩家在走，都不是这条的事）。"
    "玩家压着的那个格位（四像素读不出原色）在断言里跳过。\n"
    "apply 只在「点那块 2×2 小图标」时开口（ACTION6、被点像素在面板区、颜色是八种垫子色之一、"
    "所在同色四连通块恰好 4 像素）：押三块钉死的垫子一像素不动，外加 (48,18) 那一格——"
    "露着就押它走一档，被玩家压着就押它仍是玩家色。(48,18) 既不是垫子又不是玩家色时整条闭嘴（返回 None）。"
)

NOTE = (
    "由来：终局卡第 5 关（level_prev==5）的语料里，会换花色的垫子**一次都没有**出现在 (48,18) 之外。"
    "z9r_probe.out：23 条点小图标的转移（去重后）里有 13 条有垫子换色，换的那块 13/13 都是 (48,18)；"
    "另外 10 条地图区零像素变化，那 10 条玩家都正站在 (48,18) 上。"
    "z9s_probe.out 的分母更硬：第5关去重后 862 条转移的 prev+nxt 共 1724 个帧里，"
    "(4,4) 露着 1714 次全是 11/12，(52,32) 露着 1705 次全是 6/7，(58,34) 露着 1600 次全是 9/10，零反例；"
    "同一批帧里 (48,18) 露着 1620 次，四种花色都出现过（6/7 730、13/8 130、12/11 114、9/10 646）。\n"
    "为什么值得单写一条：册子里已有的 icon_recolors_pad 是按**相位**认「哪一块会换色」的，"
    "而相位是全场一起翻的，于是两块露着的垫子撞上同一种花色时它认不出唯一一块、整条返回 NA。"
    "第 2216 步的真帧就是这种局面（(48,18) 与 (52,32) 同为 6/7），"
    "z9w_chain.out 里那 6 下点图标全是「预测 0 格 ← 没有概念开口」。"
    "按坐标认就没有这个洞：哪一块会换色是**关卡布局的一部分**，不是能从相位反推的东西。\n"
    "**这一条没有说、也说不出的那一半**：玩家站在 (48,18) 上时，脚下的花色单帧读不出来。"
    "z9p_probe.out 做过穷举——把 34 条色6卡传送的 prev 当样本、次帧露出的花色当真值，"
    "全帧 4096 个像素里能唯一决定花色的有 **0 个**；语料里还有 **3 组逐像素完全相同的 prev 帧落点却不同**"
    "（53a28a883e17faf6→(58,34) vs 351ae79aa98c6ae6→(4,4)；99c84d8f6fc60170→(52,32) vs 90ba82a81fcb7c68→(4,4)；"
    "53a28a883e17faf6→(58,34) vs f3c7e18589bb5254→(52,32)）。落点不是单帧的函数，任何 apply 都押不中，"
    "只能靠「走开一格量一下」或者自己记账。这条概念把可判的那一半（哪一块会变、变成什么）钉死，"
    "剩下的那一半明说留给玩家。\n"
    "全语料实测（runs/dc22-0916-1543/z9z_validate.py → z9z_validate.out，"
    "口径：dc22-0915-2238 去重前 1109 行 + dc22-0916-1543 去重前 2224 行，去重后 2331 条，"
    "签名 game:dc22-0915-2238,dc22-0916-1543）："
    "**TRUE 860 / FALSE 0 / NA 1471**，860 条 TRUE 全部落在 level_prev==5。"
    "apply：开口 23 条，押中像素 364、押错 0；同样这 23 条上册子现有概念合计只给 52 格（其中 10 条给 0 格）。"
    "这些数字由上面那个脚本跑出，**未经 ledger/settle.py 结算**；语料是活的，行数会随主会话继续打而增长。"
)

EVIDENCE = [
    # 点小图标、换色的是 (48,18)，且沿循环走一档（垫子露着，看得见）
    "9d04b095e842a0f0",   # 6/7 -> 13/8
    "b1fd828e9f4e6679",   # 13/8 -> 12/11
    "00aca1d39bafc948",   # 12/11 -> 9/10
    "3fb82811541b8bd1",   # 9/10 -> 6/7
    "d31c7e2f5d50bc5b",   # 玩家在 (58,34)、(48,18) 与 (52,32) 同为 6/7：册子哑掉，这条仍判得动
    # 点小图标、玩家正压着 (48,18)：地图区一格不动
    "a3814481c922d5f2",
    "29cf701c4e1fd634",
    "51c50215a0324432",
    # 三块钉死的垫子在传送里露出来，花色照旧
    "68493cf78d4e17f9",   # (52,32) 露出 6/7
    "ef38229b63361124",   # (58,34) 露出 9/10
    "a01a118254921f34",   # (4,4)  露出 11/12
    "c82bd57507567b1e",   # 通关前那一下：(48,18) 露出 12/11，玩家落到 (4,4)
]

from _lib import PAD_PAIRS, PANEL_COL0, MAP_ROWS, CELL, pads, glyph_size, unreadable

HUB = (48, 18)
PINNED = {(4, 4): frozenset({11, 12}),
          (52, 32): frozenset({6, 7}),
          (58, 34): frozenset({9, 10})}
SITES = (HUB,) + tuple(PINNED)
PLAYER = 14

# (6,7) -> (13,8) -> (12,11) -> (9,10) -> (6,7)，主色跟主色走
_CYCLE = ((6, 7), (13, 8), (12, 11), (9, 10))
NEXT_COLOR = {}
for _i, _p in enumerate(_CYCLE):
    _q = _CYCLE[(_i + 1) % len(_CYCLE)]
    NEXT_COLOR[_p[0]] = _q[0]
    NEXT_COLOR[_p[1]] = _q[1]
PAD_COLORS = frozenset(NEXT_COLOR)
assert all(frozenset(p) in PAD_PAIRS for p in _CYCLE), "循环里的花色必须是 _lib 认的那四对"


def _cell(g, rc):
    r, c = rc
    return (g[r][c], g[r][c + 1], g[r + 1][c], g[r + 1][c + 1])


def _this_level(g):
    """这张图上露着的抖动垫，格位必须全在那四个里——否则不是第6关这张图。"""
    return all(site in SITES for site in pads(g))


def _is_player_cell(px):
    return all(v == PLAYER for v in px)


def _icon_click(g, action):
    """点的是面板上那块 2×2 的小图标象限（不是卡：卡的同色块大得多）。"""
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] in PAD_COLORS and glyph_size(g, r, c) == 4


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not (_this_level(prev) and _this_level(nxt)):
        return "NA"
    p_prev, p_nxt = pads(prev), pads(nxt)
    if not p_prev and not p_nxt:
        return "NA"

    spoke = False
    for site, suit in PINNED.items():
        for g, table in ((prev, p_prev), (nxt, p_nxt)):
            px = _cell(g, site)
            if any(unreadable(v) for v in px):
                continue                      # 玩家压着，读不出原色，跳过
            if site not in table:
                continue                      # 此刻这一格不是垫子（件盖上来之类），不表态
            spoke = True
            if frozenset(table[site]) != suit:
                return "FALSE"                # 钉死的花色出现了别的值
        if site in p_prev and site in p_nxt:   # 两帧都露着：这一步之内不许换花色
            if frozenset(p_prev[site]) != frozenset(p_nxt[site]):
                return "FALSE"
    if not spoke:
        return "NA"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if not _this_level(prev):
        return None
    if not _icon_click(prev, action):
        return None

    out = {}
    table = pads(prev)
    for site, suit in PINNED.items():          # 三块钉死的：一像素不动（读得出来的才押）
        px = _cell(prev, site)
        if any(unreadable(v) for v in px):
            continue
        if site not in table or frozenset(table[site]) != suit:
            return None                        # 和主张对不上，这一帧我认不出，闭嘴
        r, c = site
        for dr in range(CELL):
            for dc in range(CELL):
                out[(r + dr, c + dc)] = prev[r + dr][c + dc]

    r, c = HUB                                 # (48,18)：露着就走一档，被压着就仍是玩家色
    if r + CELL > MAP_ROWS or c + CELL > PANEL_COL0:
        return None
    px = _cell(prev, HUB)
    if HUB in table:
        for dr in range(CELL):
            for dc in range(CELL):
                v = prev[r + dr][c + dc]
                if v not in NEXT_COLOR:
                    return None
                out[(r + dr, c + dc)] = NEXT_COLOR[v]
    elif _is_player_cell(px):
        for dr in range(CELL):
            for dc in range(CELL):
                out[(r + dr, c + dc)] = PLAYER
    else:
        return None                            # 既不是垫子又不是玩家，没见过，不外推
    return out
