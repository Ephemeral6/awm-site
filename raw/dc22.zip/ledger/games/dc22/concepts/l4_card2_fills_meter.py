"""点面板上那张色2 的卡：地图行44-45、列14-29 那条由 8 个 2×2 格排成的计量条，每点一次就把**最左边的一个空格**（整格色5）和**最右边的一个空格**各填成色1；若这一下填完后条上一个空格都不剩，整条 8 格一起变成色12。地图别处一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色2、落在面板区（列>=42）、所在同色四连通块至少 8 像素"
         "（_lib.clicked_card）；换关（ctx 的 level_prev != level_next）返回 NA。"
         "再要求这条计量条在 prev 上读得出来：行44 与行45 在列14-29 上逐像素相同、这 16 列按 2 像素切成的 8 个格"
         "每格四像素同色、每格的颜色只能是 5（空）/1（填）/12（满），且至少还有一个色5 的格——"
         "任何一条不成立返回 NA。"
         "「一个色5 的格都没有」（整条已经是色12）也返回 NA：语料里填满之后再点一次的事一次都没发生过，"
         "那不是「我断言它不变」，是「没见过」。"
         "断言范围是地图区行0-61、列0-39；HUD 两行（行62-63）与面板（列>=40）不管——"
         "点这张卡有时会顺带改一个 HUD 像素，那是别的概念的事。")
NOTE = ("v1。第一读法是「每点一次多两格色1」——它数得对，却说不出填在哪一格，任何一次预测都落不到具体像素上。"
        "把全语料 1675 条转移里出现过的这条计量条的样子逐帧列出来，只有五种："
        "(5,5,5,5,5,5,5,5) → (1,5,5,5,5,5,5,1) → (1,1,5,5,5,5,1,1) → (1,1,1,5,5,1,1,1) → (12,12,12,12,12,12,12,12)，"
        "没有第六种，也没有任何「从左往右填」「隔一格填」的样子。所以改成现在这条：**从两端往中间对称地填**。\n"
        "分不开的两种读法（选了前者，理由是它只用帧上读得到的东西）："
        "色12 出现的那一下，既是「填满了」也是「第 4 次点击」；语料里两次走到色12 都同时满足这两句，"
        "拿它们分不开。如果以后出现一条先被填过几格、再从中途接着点的记录，两种读法会分家。\n"
        "只按「同色四连通块 >= 8 像素的色2 面板像素」认卡，不认坐标：别的关也有色2 的卡（它们点下去改的是别处），"
        "那些转移在这里全被计量条的读法挡成 NA——不是因为坐标对不上，是因为那两行读不出 8 个 5/1/12 的格。")
EVIDENCE = ["be64b3a65dfa2465", "ba1474b10aec2a79"]

from _lib import clicked_card, MAP_ROWS

MAP_COLS = 40          # 列40-41 是虚线分隔，列>=42 是面板
BAR_ROWS = (44, 45)    # 计量条占的两个像素行
BAR_C0 = 14            # 最左一格的左端列
NCELL = 8              # 8 个 2×2 的格
EMPTY, FILL, DONE = 5, 1, 12
CARD_COLOR = 2


def _meter(g):
    """计量条的 8 个格各是什么颜色；读不出来返回 None。"""
    cells = []
    for k in range(NCELL):
        c = BAR_C0 + 2 * k
        px = {g[r][c + j] for r in BAR_ROWS for j in (0, 1)}
        if len(px) != 1:
            return None
        v = px.pop()
        if v not in (EMPTY, FILL, DONE):
            return None
        cells.append(v)
    return cells


def _after(cells):
    """点一次之后这 8 格该是什么；一个空格都没有返回 None（SCOPE 里说的那种闭嘴）。"""
    empt = [k for k, v in enumerate(cells) if v == EMPTY]
    if not empt:
        return None
    new = list(cells)
    new[empt[0]] = FILL
    new[empt[-1]] = FILL
    if EMPTY not in new:
        new = [DONE] * NCELL
    return new


def _pred(g):
    """计量条那 32 个像素点完之后的颜色；读不出来返回 None。"""
    cells = _meter(g)
    if cells is None:
        return None
    new = _after(cells)
    if new is None:
        return None
    return {(r, BAR_C0 + 2 * k + j): new[k]
            for k in range(NCELL) for r in BAR_ROWS for j in (0, 1)}


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    pred = _pred(prev)
    if pred is None:
        return "NA"
    for r in range(min(MAP_ROWS, len(prev))):
        row_p, row_n = prev[r], nxt[r]
        for c in range(MAP_COLS):
            if row_n[c] != pred.get((r, c), row_p[c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return None
    return _pred(prev)
