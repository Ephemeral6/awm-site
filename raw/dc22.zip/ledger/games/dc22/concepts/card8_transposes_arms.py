"""点面板上那张色8 的卡：地图上每个 4×4 实心色13 枢纽周围与它相连的色8 臂，按过枢纽的主对角线转置——左臂变上臂、上臂变左臂、右臂变下臂、下臂变右臂，臂长不变；原臂位置露出色4，其余地图像素不动；但玩家正踩在某条臂上时整张地图一格不动（踩在枢纽上不算，那样照转）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6，被点像素在 prev 里是色8、落在面板区、所在同色四连通块至少 8 像素（面板上那颗 4 像素的色8 小图标"
         "推进的是垫子花色，不是这张卡）。地图上找不到任何 4×4 实心色13 枢纽时返回 NA（第 4、5 关这张卡做的是别的事，"
         "那里没有枢纽，归别的概念）。me() 定位不到返回 NA。换关返回 NA。只断言行 0-61 里 prev 与 next 都不是色0/色5 的像素——"
         "第一次点卡时面板上会闪出一块 0↔5 的选中高亮，那是面板的事。")
NOTE = ("v1: 帧差实测。第 0 关枢纽在 (30-33,18-21)，左臂 (30-33,12-17) 6 像素长；点一次左臂消失、上臂 (24-29,18-21) 出现，"
        "再点一次换回来（2529fc5f8db19fea / e43cef636d3ab523 / 8214ada18a06e9f5）。第 1、2 关枢纽在 (24-27,20-23)，"
        "左右两臂各 8 长；点一次变成上下两臂，再点换回（a7613c326baabc00、bff59523e97ce9b6、79386bf252e4edf8、ee26f9ff1db4c54a）。"
        "「左↔上、右↔下」正是绕主对角线的转置，两种臂形都对得上，所以不写成「转 90°」——转 90° 会把第 0 关第二次点击"
        "送去右臂，实测回到了左臂。臂的像素 = 从枢纽出发沿色8 四连通铺开的像素（不含枢纽）；"
        "转置公式：枢纽左上角 (r0,c0)，像素 (r,c) → (r0 + (c - c0), c0 + (r - r0))。"
        "影子册 card8_gate_toggle 只断言「4→8 与 8→4 数量相等」，这条把位置也押上。"
        "玩家站在枢纽上时（第 372 步 8214ada18a06e9f5、第 452 步 79386bf252e4edf8）臂照样转置——"
        "第一稿的枢纽识别要求 16 个像素全是色13，这两条被判成 NA；改成玩家格里的像素也算枢纽的一部分。"
        "没解释的：玩家正站在臂上时点卡会怎样，语料里没有；第 4、5 关那张卡做的事（合拢爪子、48 格混色变化）这里不管。\n"
        "v2: v1 留的那个「没解释的」被终局卡第 672 步补上了（e0791471f6204ecc）：玩家站在 (32-33,16-17)，"
        "正是左臂的一段，点色8 卡**整张地图一格没动**（帧差只有 HUD 那 10 格），v1 押 40 格转置，全错，退出码 5。"
        "和色9/色15 那张卡「玩家站在桥上就不翻」是同一条规矩：**卡不搬玩家脚下的地**。"
        "从帧上怎么读「踩在臂上」：玩家那 2×2 是色14，臂在那儿断成两截，所以把玩家格当成臂色再从枢纽铺一遍，"
        "铺得到玩家格就算踩在臂上。踩在枢纽上不会被误判——枢纽那 4×4 本来就不算臂，"
        "而第 372、452 步正是踩在枢纽上照转，它们仍判 TRUE。"
        "对照读数：同一座枢纽，第 372 步臂 24 像素（玩家在枢纽里，臂完整），第 672 步臂 20 像素（玩家吃掉了 4 格）。")
EVIDENCE = ["2529fc5f8db19fea", "e43cef636d3ab523", "8214ada18a06e9f5", "a7613c326baabc00",
            "bff59523e97ce9b6", "79386bf252e4edf8", "ee26f9ff1db4c54a", "e0791471f6204ecc"]

from _lib import CELL, clicked_card, me

HUB, ARM, WALL = 13, 8, 4
HUB_SIZE = 4
MAP_ROWS = 62
SKIP = (0, 5)


def hubs(g):
    """地图上的 4×4 实心色13 枢纽的左上角列表：外面一圈一个色13 都没有（排掉更大的色13 块）。
    玩家正站在枢纽上时它少一格露不出来（第 372、452 步），所以玩家那 2×2 里的像素也当色13 算。"""
    n, m = len(g), len(g[0])
    p = me(g)
    mine = set() if p is None else {(p[0] + i, p[1] + j) for i in range(CELL) for j in range(CELL)}
    out = []
    for r in range(0, min(MAP_ROWS, n) - HUB_SIZE + 1):
        for c in range(0, m - HUB_SIZE + 1):
            if any(g[r + i][c + j] != HUB and (r + i, c + j) not in mine
                   for i in range(HUB_SIZE) for j in range(HUB_SIZE)):
                continue
            ring = [(r + i, c + j) for i in range(-1, HUB_SIZE + 1) for j in range(-1, HUB_SIZE + 1)
                    if not (0 <= i < HUB_SIZE and 0 <= j < HUB_SIZE)]
            if any(0 <= y < n and 0 <= z < m and g[y][z] == HUB for y, z in ring):
                continue
            out.append((r, c))
    return out


def arm_pixels(g, r0, c0, extra=()):
    """从枢纽出发沿色8 四连通铺开的像素（不含枢纽）。`extra` 里的像素也当色8 算。"""
    n, m = len(g), len(g[0])
    seen = set()
    st = [(r0 + i, c0 + j) for i in range(HUB_SIZE) for j in range(HUB_SIZE)]
    hub = set(st)
    while st:
        y, z = st.pop()
        for dy, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (y + dy, z + dz)
            if (0 <= p[0] < min(MAP_ROWS, n) and 0 <= p[1] < m and p not in seen and p not in hub
                    and (g[p[0]][p[1]] == ARM or p in extra)):
                seen.add(p)
                st.append(p)
    return seen


def on_arm(g):
    """玩家是不是正踩在某座枢纽的臂上；me 定位不到返回 None。

    玩家那 2×2 在帧上是色14，臂在那儿断成两截，所以把玩家格**当成臂色**再从枢纽铺一遍：
    铺得到玩家格就是踩在臂上。踩在枢纽上不算——枢纽那 4×4 从一开始就被排除在臂之外，
    实测那种情况臂照样转置（第 372、452 步）。
    """
    p = me(g)
    if p is None:
        return None
    mine = {(p[0] + i, p[1] + j) for i in range(CELL) for j in range(CELL)}
    return any(mine & arm_pixels(g, r0, c0, mine) for r0, c0 in hubs(g))


def transposed(g):
    """转置后该变的像素：{(row, col): 色}。玩家踩在臂上时整张地图不动，返回空。"""
    if on_arm(g):
        return {}
    pred = {}
    for r0, c0 in hubs(g):
        arms = arm_pixels(g, r0, c0)
        for y, z in arms:
            pred[(y, z)] = WALL
        for y, z in arms:
            q = (r0 + (z - c0), c0 + (y - r0))
            if 0 <= q[0] < len(g) and 0 <= q[1] < len(g[0]):
                pred[q] = ARM
    return {k: v for k, v in pred.items() if g[k[0]][k[1]] != v}


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, ARM):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not hubs(prev) or on_arm(prev) is None:
        return "NA"
    pred = transposed(prev)
    for r in range(min(MAP_ROWS, len(prev))):
        for c in range(len(prev[0])):
            if prev[r][c] in SKIP and nxt[r][c] in SKIP:
                continue
            if nxt[r][c] != pred.get((r, c), prev[r][c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, ARM) or not hubs(prev) or on_arm(prev) is None:
        return None
    return transposed(prev)
