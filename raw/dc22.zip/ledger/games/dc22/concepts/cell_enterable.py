"""方向键走一步：目标格四像素没有色3/4/5、含色0 的只有图例标记格例外、且（同色 / 带色2 地板 / 四种花色的垫子 / 色8 至少占两像素）就走进去，否则玩家原地不动。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1-4 四个方向键；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA"
NOTE = "v10: 判据一个字没动，改的是 apply——目标格是色11 块（_lib.is_goal）时不再开口：走进它就换关，换关那一帧整屏重画，逐格预测必错。v9: 判据一个字没动，挨打的是词汇 me()——第 879 步玩家走进「右」标记格，面板那颗菱形亮成 16 像素的色14，旧 me() 从上往下扫第一个 2×2 色14 就指到了它（37e1f7195bbc3458，同一条转移把 action4_down 也打了）。_lib.me 改成认「全帧唯一一只恰好 2×2 的色14 连通块」。v8: 色0 是墙这条要挖个洞——图例屋里贴在垫子四周的标记格 [1,0/0,X] 踩得上去。" + \
    "第 866 步玩家从垫子 (58,34) 往上走进 (56,34)（73ee06ae28c73c86），第 868 步又走进去一次（94d19429542fa05a），v7 认它含色0 就是墙，判两次 FALSE。词汇加 is_marker/marker_color：一个色1、两个色0、一个色X 的花格是标记不是墙；纯色0 的黑区照旧是墙（那五次撞墙不变）。踩上去还会点亮面板上带同色X 的菱形，那是另一条概念 legend_marker_lights_diamond 的事。v7: 垫子不分花色都站得上去。" + \
    "第 860 步玩家从 (50,18) 按上键走进 9/10 垫子 (48,18)（6bcce9fed69e28f5），v6 的 enterable 只认 6/7 那一种花色，判它进不去，吃了一条反例。词汇改成 PAD_PAIRS = {6/7, 13/8, 12/11, 9/10} 四对。这条反例是押注时就点名想要的：垫子能站，才有可能站在 9/10 垫子上点色6 卡传送。v6: 第 6 关地图中间那一大片色0 不是墙外的通道，是墙。" + \
    "玩家站在色12 十字件的右臂 (32,12) 上连按五次右键，目标格 (32,14) 四像素全色0，一次都没进去（3f68ccbfdf7b1b01、dbd9cdb3fdb940f7），v5 的 enterable 认「四像素同色且不在阻挡表」，把它当通道，判五次 FALSE。语料复核：803 条转移里玩家一次都没进过含色0 的格（lens ask 命中 0），所以色0 直接进 _lib.BLOCK_COLORS。这条改的代价要记着：本关正中那片黑区（列20-31、行8-39）连同里面那只色8 空盒子，从此在册子里是不可达区；要是哪天玩家真的进去了，反过来就是这条的反例。v5: 第 6 关竖着的色12 十字件中心有一圈色8 环，环格 [8,12,8,8] 玩家走得进去（029a5a9e25aca7e4），v4 判进不去。而第 5 关插头角格 [12,12,12,8] 仍是进不去的——两边只差色8 像素的个数，词汇 enterable 就按「色8 至少两像素」划线；这是拼反例拼出来的界线，不是机制。全语料 741 条复核零反例。v4: 花格再收紧——花格只有带色2 地板（[2,2,2,8]、[15,2,15,15]）或纯 6/7 传送格才进得去；第 5 关色12 条的插头角格 [12,12,12,8] 被拒六次（9afacf5cb62ed31e、fe0db6941f4e4ff9、676a7e82dc5e0806），它没有阻挡色却进不去，v3 判错。全语料 607 条复核零反例。v3: apply 把腾出的原格也押上（_lib.move_cells，颜色按四邻猜）；不押原格时链式预测的模拟帧里留着两个色14 块，me() 认错人，第 617 步整批因此停掉。v2: 判据从「四像素同色且色不在阻挡表」改成「四像素一个都不在阻挡表」，阻挡表 = {3,4,5}。改版原因：五条反例都是花格——传送格 [6,7,7,6]、地上小道具 [2,2,2,8] 与 [15,2,15,15] 玩家都进得去（758756a82a656848、bb0eccd5b3e0cbae、af16e931526dc55e、90d087db3493a5a7），而纯色的 [3,3,3,3] 进不去（53156ca2afa7e637）。新写法顺带把半开的桥（色9 与色4 相间）、半开的柱（色15 与色4 相间）算成进不去，因为它们混着色4。v1: 只认纯色格。"
EVIDENCE = ["758756a82a656848", "53156ca2afa7e637", "bb0eccd5b3e0cbae", "af16e931526dc55e",
            "90d087db3493a5a7", "e80fc7e2732386ed", "168007841e45f3ea", "69b4f69b0d36cba7",
            "9afacf5cb62ed31e", "fe0db6941f4e4ff9", "676a7e82dc5e0806", "029a5a9e25aca7e4",
            "3f68ccbfdf7b1b01", "dbd9cdb3fdb940f7", "6bcce9fed69e28f5",
            "73ee06ae28c73c86", "94d19429542fa05a", "37e1f7195bbc3458"]

from _lib import me, CELL, DELTA, enterable, move_cells, is_goal


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    if enterable(prev, tr, tc):
        return "TRUE" if b == (tr, tc) else "FALSE"
    return "TRUE" if b == a else "FALSE"


def apply(prev, action, ctx=None):
    if action not in DELTA:
        return None
    a = me(prev)
    if a is None:
        return None
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    # 走进色11 块就换关，整帧重画，这条概念说不出那一帧——闭嘴
    if is_goal(prev, tr, tc):
        return None
    if not enterable(prev, tr, tc):
        return move_cells(prev, a[0], a[1], a[0], a[1])
    return move_cells(prev, a[0], a[1], tr, tc)
