"""面板上那张色2 的卡：点它一下，地图上下两条横带就交换一档——上带的填充从两端各长 1 格、下带各退 1 格（或反过来），两带填充像素之和恒为 16；除了这一击，任何动作都不动这两条带。

读法（全部写在本文件里，不动 _lib）：
  上带 = 行20-21 × 列8..23，下带 = 行40-41 × 列16..31，各 16 像素宽、2 像素高。
  一条带的状态只有一个数 f（填充像素数）：从**两端**对称往里填，左右各 f/2 像素；
  填充色是色1，**填满 16 像素时整条显色12**，没填的部分是色5。
  色14（玩家站在带上）与负数（离场规划器的哨兵）当**未知**，不当颜色——玩家会从上带身上走过去。
  f 读不唯一、或两条带里有一条读不出来，这条概念就闭嘴（返回 NA）：那正好是「这一关没有这套带子」的情形。
"""
LEVEL = "L4"
SCOPE = ("只在**两条带都能被上面那套读法唯一读出、且填充像素之和 = 16** 的帧上开口；别的帧（别的关、换关那一步、"
         "玩家把带子遮到读不唯一）一律 NA。"
         "『哪一击算数』按被点像素的颜色认：ACTION6:<列>,<行> 点到的那个像素在 prev 里是色2、且落在面板区（列 >= 42）、"
         "且它所在的同色四连通块 >= 8 像素。"
         "**方向不在主张里**：档位停在中间（f=4/8/12）时，下一击是继续涨还是回落，全帧找不出任何像素能区分"
         "（语料里 f=4/8/12 三档各有 7 次涨、7 次落，逐格求差为 0 个稳定差异像素），那是一个帧上看不见的潜状态；"
         "所以断言只到『恰好挪一档、两带反向、总和守恒』，外加两个端点上方向被逼死：f=0 必涨、f=16 必落。"
         "RESET 在这一关的语料里一次都没出现过，本概念对 RESET 返回 NA（不是『它不动带子』，是没见过）。")
NOTE = ""
EVIDENCE = [
    "1c0403bc6ee54e3e",   # f=0 -> 4（下带 16 -> 12）
    "364ab9b616a29384",   # f=4 -> 8
    "d12a86fe6f5f294e",   # f=12 -> 16，上带整条变色12
    "f70878d63ea80d02",   # f=16 -> 12，端点上方向反过来
    "0db168e2300c04bc",   # f=4 -> 0，上带整条变色5
    "7ccbed8b45b447f7",   # 另一处点法（卡的另一个像素），同样 f=0 -> 4
    "73c600809ee8e608",   # f=16 -> 12
    "a31e30a08785866b",   # 非点击：玩家在上带上走，带子读数不变
    "33671af46fc1059d",   # 非点击：玩家沿上带走
    "1130efa78fe3725a",   # 点的是另一张卡（色11），带子不动
]

TOP = (20, 8)          # (起始行, 起始列)，两行高
BOT = (40, 16)
BAND_W = 16            # 一条带 16 像素宽
BAND_H = 2
NOTCH = 4              # 一击挪 4 个填充像素（两端各 2 像素 = 各 1 格）
FULL_COLOR = 12        # 填满时整条的颜色
FILL_COLOR = 1         # 没填满时，填着的那部分的颜色
EMPTY_COLOR = 5        # 空着的部分
CARD_COLOR = 2
PANEL_COL0 = 42
MIN_GLYPH = 8


def _unknown(v):
    """这个像素说不出原本是什么：玩家（色14）压在上面，或调用方标的负数哨兵。"""
    return v == 14 or (isinstance(v, int) and v < 0)


def _paint(f):
    """填充 f 像素时，一条带的一行长什么样（16 个颜色）。"""
    if f >= BAND_W:
        return [FULL_COLOR] * BAND_W
    half = f // 2
    return [FILL_COLOR if (i < half or i >= BAND_W - half) else EMPTY_COLOR
            for i in range(BAND_W)]


def _read(g, band):
    """把一条带读成填充像素数 f；读不出或读不唯一返回 None。"""
    r0, c0 = band
    if r0 + BAND_H > len(g) or c0 + BAND_W > len(g[0]):
        return None
    hit = []
    for f in range(0, BAND_W + 1, 2):
        want = _paint(f)
        ok = True
        for i in range(BAND_W):
            for dr in range(BAND_H):
                v = g[r0 + dr][c0 + i]
                if _unknown(v):
                    continue
                if v != want[i]:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            hit.append(f)
    return hit[0] if len(hit) == 1 else None


def _glyph_size(g, r, c, cap=MIN_GLYPH):
    """(r,c) 所在的同色四连通块至少有 cap 个像素？（数到 cap 就收手，不铺完整块。）"""
    v = g[r][c]
    seen = {(r, c)}
    st = [(r, c)]
    while st and len(seen) < cap:
        y, x = st.pop()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (y + dy, x + dx)
            if 0 <= p[0] < len(g) and 0 <= p[1] < len(g[0]) and p not in seen and g[p[0]][p[1]] == v:
                seen.add(p)
                st.append(p)
    return len(seen) >= cap


def _is_meter_click(g, action):
    """这一击点在面板上那张色2 的卡上。动作记号是 ACTION6:<列>,<行>（先列后行——
    按被点像素的颜色反查出来的：转置读法下动带的两次点击落在色2 的卡上，不转置则落在色4 的背景上）。"""
    if not isinstance(action, str) or not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == CARD_COLOR and _glyph_size(g, r, c)


def assert_(prev, action, nxt, ctx=None):
    if ctx:
        lp, ln = ctx.get("level_prev"), ctx.get("level_next")
        if lp is not None and ln is not None and lp != ln:
            return "NA"                      # 换关整帧重画，这两条带和上一帧没有对应关系
    if isinstance(action, str) and action.upper().startswith("RESET"):
        return "NA"                          # 这一关的语料里没有 RESET，没证据就不开口
    pa, pb = _read(prev, TOP), _read(prev, BOT)
    if pa is None or pb is None or pa + pb != BAND_W:
        return "NA"                          # 这一帧没有这套带子（或玩家遮到读不唯一）
    na, nb = _read(nxt, TOP), _read(nxt, BOT)
    if na is None or nb is None:
        return "NA"
    if not _is_meter_click(prev, action):
        return "TRUE" if (na, nb) == (pa, pb) else "FALSE"
    if na + nb != BAND_W:
        return "FALSE"                       # 守恒破了
    d = na - pa
    if pa == 0:
        return "TRUE" if d == NOTCH else "FALSE"
    if pa == BAND_W:
        return "TRUE" if d == -NOTCH else "FALSE"
    return "TRUE" if abs(d) == NOTCH else "FALSE"


def apply(prev, action, ctx=None):
    """只在这一击上开口，而且只押「两个方向都同意」的那些像素：
    端点（f=0 或 f=16）上方向被逼死，两条带 64 个像素全押；中间档只有两种走法都不变的像素敢押。
    玩家（色14）或哨兵压着的像素一律不押——那底下是谁，这条概念说了不算。"""
    if ctx:
        lp, ln = ctx.get("level_prev"), ctx.get("level_next")
        if lp is not None and ln is not None and lp != ln:
            return None
    if not _is_meter_click(prev, action):
        return None
    pa, pb = _read(prev, TOP), _read(prev, BOT)
    if pa is None or pb is None or pa + pb != BAND_W:
        return None
    cand = [f for f in (pa + NOTCH, pa - NOTCH) if 0 <= f <= BAND_W]
    if not cand:
        return None
    out = {}
    for band, vals in ((TOP, cand), (BOT, [BAND_W - f for f in cand])):
        r0, c0 = band
        rows = [_paint(f) for f in vals]
        for i in range(BAND_W):
            col = {row[i] for row in rows}
            if len(col) != 1:
                continue                     # 两种走法给的颜色不同：不押
            v = col.pop()
            for dr in range(BAND_H):
                if _unknown(prev[r0 + dr][c0 + i]):
                    continue                 # 玩家压在带子上，底下露不露得出来不归这条概念说
                out[(r0 + dr, c0 + i)] = v
    return out
