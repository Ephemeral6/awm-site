"""点面板上那张色6 的卡：地图上那块 4×4 实心色6 枢纽周围与它相连的色7 臂，按过枢纽的主对角线转置——左臂变上臂、右臂变下臂，臂长不变；原臂位置露出色4，地图区其余像素不动；但玩家正踩在某条臂上时整张地图一格不动（踩在枢纽上不算，那样照转）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色6、落在面板区、所在同色块至少 8 像素（clicked_card）；换关返回 NA；"
         "地图区（行<62、列<38）里 4×4 实心色6 枢纽（外圈一个色6 都没有）不是**恰好一块**时返回 NA——"
         "别的关的色6 卡做的是别的事（第 5 关传送与垫子相位、第 6 关转那件色12 十字件），那里没有这样的枢纽，归别的概念；"
         "玩家那 2×2 的像素 prev/nxt 两边都跳过：他站得上色7 的臂也站得上色6 的枢纽，色14 盖住了下面的东西。"
         "me() 定位不到返回 NA（判不了玩家踩没踩在臂上）。"
         "列 38-39 是虚线分隔（每帧在 0/5 之间抖），列 40 起是面板，都不在断言范围内。")
NOTE = ("v1: 第 185 步（d5b643d361b0f33a）逐像素量出来的。枢纽在行40-43 列16-19，点卡前左臂行40-43 列8-15、"
        "右臂行40-43 列20-27（各 8 长），点卡后两臂变成上臂行32-39 列16-19、下臂行44-51 列16-19，原来两臂的位置全露色4。"
        "左臂像素 (40,8) 落到 (32,16)、右臂端点 (40,27) 落到 (51,16)，正是绕枢纽左上角的主对角线转置："
        "(r,c) → (r0 + (c - c0), c0 + (r - r0))。\n"
        "本关两臂等长，所以「转置」和「转 90°」在这一关分不出来——写成转置是因为册子里那张色8 卡"
        "（card8_transposes_arms）在臂不等长的局面上实测是转置不是旋转，同一套臂-枢纽装置按同一条规矩读。"
        "这条概念和 card6_rotates_piece 说的是同一张卡在不同关的效果：那边的枢纽是色8 的环、臂是色12，"
        "两边靠枢纽的颜色与形状分开，不会同时开口。\n"
        "没解释的：为什么这一关的枢纽是色6（和卡同色）而第 6 关的枢纽是色8（和卡不同色）。\n"
        "v2: v1 留的「玩家正站在臂上时点卡，臂转走了他脚下露出什么」被终局卡第 694 步补上了"
        "（5f49b29a3e218c9e）：玩家站在 (40-41,14-15)，正是左臂的一段，点色6 卡**整张地图一格没动**，"
        "v1 押 120 格转置，全错，退出码 5。答案是「什么都不露出来，因为臂根本不转」。\n"
        "这已经是同一条世界规矩在这局里第三次露面：色9/色15 卡「玩家站在桥上就不翻」、"
        "色8 卡「玩家踩在臂上就不转」（card8_transposes_arms v2）、这里第三次。"
        "**卡不搬玩家脚下的地**——前两次是各自挨了一次打才补上的，这一次是照着 card8 的补法搬过来的。\n"
        "从帧上怎么读「踩在臂上」：玩家那 2×2 是色14，臂在那儿断成两截，所以把玩家格当成臂色再从枢纽铺一遍，"
        "铺得到玩家格就算踩在臂上。踩在枢纽上不会被误判——枢纽那 4×4 本来就不算臂。"
        "对照读数：同一座枢纽，第 185 步臂 64 像素（玩家在别处，两臂完整）、转置 128 格；"
        "第 694 步臂 60 像素（玩家吃掉了 4 格）、地图 0 格。")
EVIDENCE = ["d5b643d361b0f33a", "5f49b29a3e218c9e"]
# 第一条只抄这一条：全语料里「第 1 关点色6 卡」一共 6 条，六条全抄进 EVIDENCE 会让 held-out 变空、
# S 直接 UNMEASURABLE（v1 第一次结算就是这样）。留另外五条（f16b3d944ff0573d、1fd0ee438611d43e、
# 06bbd7240a77d740、5e65c143243d5838、0683de6704185e93）在闸里考它。
# 第二条是 v2 的反例（终局卡第 694 步，玩家踩在臂上）。

from _lib import CELL, clicked_card, me

HUB, ARM, WALL = 6, 7, 4
HUB_SIZE = 4
MAP_ROWS, MAP_COLS = 62, 38


def hubs(g):
    """地图区里 4×4 实心色6 枢纽的左上角列表：外面一圈一个色6 都没有（排掉更大的色6 块）。
    玩家正站在枢纽上时它少一格露不出来，所以玩家那 2×2 里的像素也当色6 算（和 card8_transposes_arms 同一处理）。"""
    n = min(MAP_ROWS, len(g))
    p = me(g)
    mine = set() if p is None else {(p[0] + i, p[1] + j) for i in range(CELL) for j in range(CELL)}
    out = []
    for r in range(n - HUB_SIZE + 1):
        for c in range(MAP_COLS - HUB_SIZE + 1):
            if any(g[r + i][c + j] != HUB and (r + i, c + j) not in mine
                   for i in range(HUB_SIZE) for j in range(HUB_SIZE)):
                continue
            ring = [(r + i, c + j) for i in range(-1, HUB_SIZE + 1) for j in range(-1, HUB_SIZE + 1)
                    if not (0 <= i < HUB_SIZE and 0 <= j < HUB_SIZE)]
            if any(0 <= y < n and 0 <= z < MAP_COLS and g[y][z] == HUB for y, z in ring):
                continue
            out.append((r, c))
    return out


def arm_pixels(g, r0, c0, extra=()):
    """从枢纽出发沿色7 四连通铺开的像素（不含枢纽）。`extra` 里的像素也当色7 算。"""
    n = min(MAP_ROWS, len(g))
    seen = set()
    hub = {(r0 + i, c0 + j) for i in range(HUB_SIZE) for j in range(HUB_SIZE)}
    st = list(hub)
    while st:
        y, z = st.pop()
        for dy, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (y + dy, z + dz)
            if (0 <= p[0] < n and 0 <= p[1] < MAP_COLS and p not in seen and p not in hub
                    and (g[p[0]][p[1]] == ARM or p in extra)):
                seen.add(p)
                st.append(p)
    return seen


def on_arm(g):
    """玩家是不是正踩在某条色7 的臂上；me 定位不到返回 None。

    玩家那 2×2 在帧上是色14，臂在那儿断成两截，所以把玩家格**当成臂色**再从枢纽铺一遍：
    铺得到玩家格就是踩在臂上。踩在枢纽上不算——枢纽那 4×4 从一开始就被排除在臂之外。
    """
    p = me(g)
    if p is None:
        return None
    mine = {(p[0] + i, p[1] + j) for i in range(CELL) for j in range(CELL)}
    return any(mine & arm_pixels(g, r0, c0, mine) for r0, c0 in hubs(g))


def transposed(g):
    """转置后该变的像素：{(行,列): 色}。先把原臂涂回色4，再把转置后的位置涂色7（重叠处以色7 为准）。
    玩家踩在臂上时整张地图不动，返回空。"""
    if on_arm(g):
        return {}
    pred = {}
    for r0, c0 in hubs(g):
        arms = arm_pixels(g, r0, c0)
        for y, z in arms:
            pred[(y, z)] = WALL
        for y, z in arms:
            q = (r0 + (z - c0), c0 + (y - r0))
            if 0 <= q[0] < min(MAP_ROWS, len(g)) and 0 <= q[1] < MAP_COLS:
                pred[q] = ARM
    return {k: v for k, v in pred.items() if g[k[0]][k[1]] != v}


def _player_px(g):
    p = me(g)
    return set() if p is None else {(p[0] + i, p[1] + j) for i in range(CELL) for j in range(CELL)}


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, HUB):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if len(hubs(prev)) != 1:
        return "NA"
    if on_arm(prev) is None:
        return "NA"
    pred = transposed(prev)
    skip = _player_px(prev) | _player_px(nxt)
    for r in range(min(MAP_ROWS, len(prev))):
        for c in range(MAP_COLS):
            if (r, c) in skip:
                continue
            if nxt[r][c] != pred.get((r, c), prev[r][c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, HUB) or len(hubs(prev)) != 1 or on_arm(prev) is None:
        return None
    return {k: v for k, v in transposed(prev).items() if k not in _player_px(prev)}
