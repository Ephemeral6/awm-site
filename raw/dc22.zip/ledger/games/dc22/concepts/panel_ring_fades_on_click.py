"""面板图形外面那圈色0 边框：点某块图形**芯部**（被点像素不是色0）的任一像素，整圈边框变成面板底色5；按方向键、点地图、或点在边框本身那圈色0 像素上，边框一像素不动。"""
LEVEL = "L6"
SCOPE = ("只在 prev 的面板图形（_lib.panel_glyphs）里含有色0 像素时开口，没有边框返回 NA；换关返回 NA。"
         "ACTION6 且被点像素落在某块面板图形里、**且那个像素不是色0** → 断言 next 里这些色0 像素全部变成色5；"
         "其余一切（方向键、点地图、点面板空白、点在色0 边框像素上）→ 断言这些像素在 next 里仍是色0。"
         "只断言边框像素本身。")
NOTE = ("v2: 终局卡第 660 步点第 0 关右边那块图形的边框像素（行33 列44，prev 里是色0）——"
        "ce4524333495284b：两圈边框 80 像素一格没动，真实帧差只有 HUD 的 (63,0) 0→3 一格。"
        "v1 说的是「点任一块图形」，于是它把点在边框上也算成点卡，押 80 格褪色，全错。"
        "分界是**被点的那个像素本身是不是边框**：点芯部才褪，点边框等于没点。"
        "v1 立这条时语料里只有一次褪框，那一次点的正是色8 卡芯，边框被点过没有当时无从分辨。\n"
        "v1: 第 0 关开局两张卡各套着 40 像素的色0 边框，从第 1 步到第 357 步一直在（89db1714b36607f3、"
        "df8f94b57f2fc806 点地图也没动它），第 358 步第一次点卡（2529fc5f8db19fea，点的是色8 卡芯）两圈一起褪成色5，"
        "此后本局再没出现过。第 1-5 关开局都没有边框。语料里只有这一次褪框，「点任一块图形都褪」是从这一条推的，"
        "点色9 卡先褪没试过。")
EVIDENCE = ["89db1714b36607f3", "df8f94b57f2fc806", "2529fc5f8db19fea", "ce4524333495284b"]

from _lib import panel_glyphs

RING = 0
PANEL_BG = 5


def ring_pixels(g):
    """面板图形里的色0 像素。"""
    return {p for s in panel_glyphs(g) for p in s if g[p[0]][p[1]] == RING}


def _clicked_color(g, action):
    """被点的那个像素在哪块面板图形里、是什么色；没点到任何图形返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    if not (0 <= r < len(g) and 0 <= c < len(g[0])):
        return None
    for s in panel_glyphs(g):
        if (r, c) in s:
            return g[r][c]
    return None


def _want(g, action):
    """这一下之后边框像素该是什么色。点到芯部才褪；点在边框自己身上等于没点。"""
    x = _clicked_color(g, action)
    return PANEL_BG if (x is not None and x != RING) else RING


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    ring = ring_pixels(prev)
    if not ring:
        return "NA"
    want = _want(prev, action)
    return "TRUE" if all(nxt[r][c] == want for r, c in ring) else "FALSE"


def apply(prev, action, ctx=None):
    ring = ring_pixels(prev)
    if not ring:
        return None
    return {p: _want(prev, action) for p in ring}
