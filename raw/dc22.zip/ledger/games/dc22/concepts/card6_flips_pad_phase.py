"""点面板上那张色6 的卡：地图上每一块抖动垫（四像素是 (6,7)、(13,8)、(12,11)、(9,10) 里某一对、两两相间的格）的两色对调——原来放这色的像素改放那色，位置一格不动；面板上有那块四色图标时放宽一档：每一块垫子要么照样对调、要么原样不动，而**原样不动的至多一块**（= 图标管的那块，帧上认不出是哪一块）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色6、落在面板区（列>=42）；换关返回 NA；"
         "只看在 prev 和 nxt 里同一位置都是抖动垫的那些格（玩家换位时踩住的那块、腾出的那块两帧里不都是垫子，自动不算）；"
         "一块都不剩时返回 NA。面板上有四色图标（四个 2×2 象限四种垫子色）时，主张只到「每块要么翻要么不动、不动的至多一块」这一档，"
         "而 `apply` 在这种帧上对垫子**一概不表态**（说不出是哪一块不翻，就说不出任何一块翻成什么）。"
         "**玩家此刻正踩在那件色12 大十字件上时整条返回 NA**——那一下点击可能被整个拒掉（连垫子一起），"
         "归 card6_refused_if_player_stranded 管。")
NOTE = ("v10: 主张一字未动，多一道筛子：**玩家踩在那件大十字件上时整条 NA**，`apply` 同步闭嘴。"
        "由来：终局卡第 1618 步（fa5c215846869cb6）退出码 5——玩家站在件上点色6 卡，"
        "地图区一格没动：件没转、四块垫子也一块没翻，只有 HUD 涨了。"
        "这条概念一直默认「点了色6 卡，垫子就翻」，而那一步整个点击根本没成立"
        "（转完之后件不再盖着他脚下那一格，被拒；同型的先例是 card11_refused_if_player_stranded）。"
        "筛子故意比「被拒」的条件宽一档：踩在件上但转完仍盖着他的那一档语料里一次都没有过，说不出翻不翻，那就别说。\n"
        "v9: 补一个**只供规划器**的接口 `pad_cells`（此刻哪些像素属于抖动垫、各属于哪一对花色），"
        "主张、SCOPE、assert_、apply、apply_with_ground、apply_under 一个字没动。"
        "为什么补：v8 起有图标的帧上 `apply` 对垫子整片闭嘴（那是对的，说不出就别说），"
        "可规划器的离场推演因此在这几块上**停住不动**——它手里的帧留着旧相位，真帧已经翻过了。"
        "帧一对不上，计划册按状态键就认不出自己走到第几格，整条路线每批作废重搜，"
        "而重搜出来的路线在两个朝向之间来回（第 1131~1133 步：转一下、转回去、再转一下）。"
        "相位翻没翻不改任何结果——换位的落点按**花色对**认（card6_teleport），一对花色对调之后还是同一对——"
        "所以规划器只要能把相位**折掉**再比，这条路线就接得上。这里报的不是「翻成什么色」（那才是主张，"
        "有图标时说不出），只是「这四个像素是同一块垫子、属于哪一对」。\n"
        "v8: 图标在场时的那条豁免不再点名，改成数数：「每块要么翻要么不动，不动的至多一块」；"
        "`apply` 在有图标的帧上对垫子整片闭嘴。由来：第 1115 步（756b63d66498b600）终局卡上退出码 5——"
        "四块垫子全是主色在左上，v7 的认法（主色在左上且**唯一**）当场认不出人，于是它押四块全翻，"
        "(48,18) 那块没翻，押错 4 格。这是 v2 自己预告过的死法（「点过偶数次之后四块全是主色在左上，认不出，"
        "那时这条概念押四块全翻，(48,18) 若仍不翻就是下一条反例」）。\n"
        "为什么不换个认法：认不出是**帧里没有**这件事，不是读法不够巧。三块露着的垫子邻域逐像素相同"
        "（zpad3.out：(4,4)、(48,18)、(52,32) 周围 8×8 一模一样），图标的四个象限全程 (8,11,10,7) 不变，"
        "而「主色在左上」本身会被这条概念自己的翻相位改掉——第 1044 步图标管的那块正是副色在左上"
        "（zpad2.out）。所以 v7 的认法一直是猜，只是猜中过。\n"
        "为什么主张只弱化到「至多一块」而不是整条闭嘴：本局两个 run 里有图标的每一次点色6 卡，"
        "露着的垫子要么全翻、要么恰好一块没翻（zpad2.out），两块同时不翻一次都没出现过——"
        "这一档仍然判得错，只是不再假装知道是哪一块。`apply` 那边没有对应的写法（生成器要说出每一格的颜色），"
        "所以它闭嘴：**免责声明写在 assert_ 里等于没写**（v5 的老账），这次两边一起改。\n"
        "v7: 那条豁免从「它从来不翻」改成「这条概念不管它」——主张因此变弱，assert_ 只会从 FALSE 变 TRUE/NA，"
        "apply 在那四格上闭嘴。由来：第 1043 步（95bdad633f7d695b）面板上有图标、(48,18) 是唯一一块主色在左上的垫子，"
        "v6 押它不变，它却翻了——终局卡上一次意外。回头把本局两个 run 的全部转移对过一遍（runs 里 zflip.py / zflip2.py）："
        "点色6 卡的 53 次里可见垫子翻了 82 次、不翻 1 次，而别的动作 3643 次可见垫子一次都没翻——"
        "「垫子只在点色6 卡时翻」这条因果是稳的，垮掉的只是 v2 那条豁免。"
        "豁免的两个样本是第 1004 步（不翻）和第 1043 步（翻）：两帧的垫子花色格局、四色图标的四个象限（都是 (8,11,10,7)）、"
        "认出来的那块（都是 (48,18)）全都一样，prev 侧找不出任何读得出来的差别——"
        "翻不翻挂在帧上看不见的东西上。v2 的「从来不翻」是从 n=1 长出来的，现在退回 n=2 撑得住的那句：说不准。\n"
        "v6: 再加一个**只供规划器**的读口 `apply_under`（主张、SCOPE、assert_、apply 一字未动）。"
        "SCOPE 里「玩家换位时踩住的那块、腾出的那块两帧里不都是垫子，自动不算」一直被读成「它们不翻」——"
        "本 run 第 1000-1002 步的真帧说它们照翻：踩着的那块翻了，落点那块也翻了。"
        "帧上看不见的东西 `apply` 不该说，但规划器的记性必须记；不记，下一次换位就按错的花色算落点。\n"
        "v5: 又是同一个病，这次治在 apply 上（主张与 assert_ 仍是一字未动）。v3 的「只露一块才闭嘴」"
        "只堵住了最窄的一种局面：最后一关同时露着三块垫子，其中一块仍会在这一步变成玩家——"
        "settle 把这件事报了很多批了（认领 240 格说错 52 格，错的全是换位的落点那 4 格），"
        "而 assert_ 一直判 TRUE，因为它看得见 nxt、把那块滤掉了。**免责声明只写在 assert_ 里等于没写**："
        "检查器看得见 nxt，生成器看不见，装置的链式预测和规划器的合并预测拿的都是生成器那一份。"
        "prev 侧读得出来的判据是：落点必定和玩家脚下那块同花色对，所以**同花色对只露着一块**的垫子"
        "都可能正缺着一块被踩在脚下——这些一律不押。剩下的残余风险照写：同一对露着两块、而玩家踩着第三块时，"
        "这条仍会押错落点；这一局的地图上没出现过那种排法。\n"
        "v4: 加一个**只供规划器**的 `apply_with_ground`（不进结算、不算存活率，主张与 assert_ 又是一字未动）。"
        "v3 的「只露一块就整条闭嘴」是个粗糙的近似：最后一关同时露着三块垫子，其中一块是这次传送的落点，"
        "apply 照押它四像素翻相位，而 card6_teleport 在同四格押玩家色14——规划器的合并预测判两条打架，"
        "把「站上垫子点色6 卡」这条边整条删掉，最后一关通往图例屋那半张地图因此在规划器眼里永远够不到。"
        "落点是谁，单帧看不出（玩家自己盖着脚下那块的花色），但规划器手里有他踩上去之前那一帧；"
        "把脚下四像素递进来，同花色的那一块就是落点，这里精确地只对它弃权（它在 nxt 里是玩家不是垫子，assert_ 本来就滤掉），"
        "别的垫子照押翻。弃权不会多说错一格。\n"
        "v3: 只改 apply，主张与 assert_ 一字未动。地图上**只露着一块**垫子时 apply 改为闭嘴——"
        "那一块必定是这次传送的落点（card6_teleport：露一块时玩家和它换位），它在 nxt 里是色14 不是垫子，"
        "assert_ 早就把它滤掉了（「只看在 prev 和 nxt 里同一位置都是垫子的那些格」），apply 却照押不误，"
        "于是第 2、3 关每次传送都和 card6_teleport 在同四个像素上给出不同颜色：settle 记 P 错、规划器的合并预测"
        "当场判两条概念打架、把这条边整条删掉（第 2 关离场先算 8318 个状态搜不到路，就是这么来的）。"
        "apply 说的话必须是 assert_ 敢担的那一部分，不然「预测」和「主张」就不是同一条概念了。\n"
        "v2: 第 1004 步（d995f6553676c39a）玩家站在图例屋的标记格上点色6 卡，(4,4)、(52,32)、(58,34) 三块都翻了，(48,18) 那块 9/10 一格没动。"
        "回头把本关六次点色6 卡的四块垫子逐次对表（runs 里 padflip.py）：(48,18) 露着的时候从来都是 [9,10/10,9]，玩家换位腾出它时也是 [9,10/10,9]"
        "（card6_teleport v3 早在第 861 步就记过「腾出的那块没翻」，当时读成「被玩家压着的那块不参与」）；第 993-995 步它在玩家脚下被图标推成 13/8、再经一次色6 卡，第 996 步露出来是 [13,8/8,13]——主色仍在左上。"
        "所以它不是「被压着才不翻」，是**图标管的那块垫子从来不翻**，别的三块每点一次翻一次。"
        "帧上认它的办法借 icon_recolors_pad 的：主色在左上角、且是唯一一块——别的三块开局都是主色在左上，点过奇数次之后全成了副色在左上，这时它唯一；点过偶数次之后四块全是主色在左上，认不出，那时这条概念押四块全翻，(48,18) 若仍不翻就是下一条反例，那时得换认法。"
        "第一稿没加「面板上有图标」这一条，第 2-5 关两块垫子本来就一块主色在左上、一块副色在左上，点一下两块都翻（4beedc3fb0928585、2e4ff9252b82ed0c、6f63b2040471f6df 三条当场判 FALSE）——豁免只在有图标的关里成立。\n"
        "v1: 第 6 关三次点色6 卡，四块垫子（行4-5 列4-5、行48-49 列18-19、行52-53 列32-33、行58-59 列34-35）每次都整齐对调两色（308c7e1468ec1b80 的帧差里 4 块各 4 像素）。这条和 card6_teleport 分开写：那条只管玩家与垫子的位置，这条只管花纹。")
EVIDENCE = ["66dd5ee813d3552a", "68493cf78d4e17f9", "308c7e1468ec1b80", "d995f6553676c39a",
            "4beedc3fb0928585", "2e4ff9252b82ed0c", "6f63b2040471f6df", "95bdad633f7d695b",
            "756b63d66498b600", "fa5c215846869cb6"]

from _lib import CELL, cross_piece_with_player, me

PAIRS = ((6, 7), (13, 8), (12, 11), (9, 10))
MAP_COLS = 40
MAP_ROWS = 62
PANEL_COL0 = 42


def _clicked_six(g, action):
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == 6


def _pads(g):
    out = {}
    for r in range(0, MAP_ROWS - CELL + 1, CELL):
        for c in range(0, MAP_COLS - CELL + 1, CELL):
            px = tuple(g[r + i][c + j] for i in range(CELL) for j in range(CELL))
            s = set(px)
            if len(s) == 2 and any(s == set(p) for p in PAIRS):
                out[(r, c)] = px
    return out


def _flip(px):
    a, b = set(px)
    return tuple(b if v == a else a for v in px)


def pad_cells(g):
    """**只供规划器，永不参与断言、不进结算**：此刻帧上哪些像素属于抖动垫，各属于哪一对花色
    （{位置: 这一对里小的那个色}）。不问点了什么、不问翻不翻，只报归属。

    和 `mover_px` / `waypoint_cells` 是同一类接口：报的是坐标与归属，不构成任何一条可判错的主张，
    所以它既不该进结算，也不该被当成「这条概念还说得出别的」。理由见 NOTE v9。
    """
    out = {}
    for (r, c), px in _pads(g).items():
        lo = min(set(px))
        for i in range(CELL):
            for j in range(CELL):
                out[(r + i, c + j)] = lo
    return out


MAIN = {p[0] for p in PAIRS}      # 每一对的主色：6、13、12、9
PAD_COLORS = {v for p in PAIRS for v in p}


def _has_icon(g):
    """面板上有没有那块 4×4 四色图标：四个 2×2 象限各一色、四色都是垫子色、四色互不相同。
    只有它在，地图上才有一块图标管的垫子。"""
    n, m = len(g), len(g[0])
    for r in range(n - 3):
        for c in range(PANEL_COL0, m - 3):
            q = [g[r][c], g[r][c + 2], g[r + 2][c], g[r + 2][c + 2]]
            if len(set(q)) != 4 or any(v not in PAD_COLORS for v in q):
                continue
            if all(g[r + i][c + j] == q[(i // 2) * 2 + j // 2] for i in range(4) for j in range(4)):
                return True
    return False


def _exempt(g, pads):
    """图标管的那块垫子：面板上有四色图标、且 prev 里主色在左上角的垫子恰好一块时返回它的位置，否则 None。

    v8 起**只有 `apply_under` 还用它**（那是只供规划器的猜测，不进结算）：认法本身是猜的——
    主色在左上会被这条概念自己的翻相位改掉，第 1044 步图标管的那块就是副色在左上。
    判据那一侧改用「不翻的至多一块」，不再点名。
    """
    if not _has_icon(g):
        return None
    hit = [k for k, px in pads.items() if px[0] in MAIN]
    return hit[0] if len(hit) == 1 else None


def _pred(prev, nxt_pads):
    """两帧里同一位置都是垫子的那些块，翻完该是什么色（不作任何豁免）。"""
    out = {}
    for k, px in _pads(prev).items():
        if k not in nxt_pads:
            continue
        f = _flip(px)
        for i in range(CELL):
            for j in range(CELL):
                out[(k[0] + i, k[1] + j)] = f[i * CELL + j]
    return out


def _refusable(g):
    """玩家踩在那件大十字件上：这一下点击可能被整个拒掉，这条概念一概不开口（NOTE v10）。"""
    return cross_piece_with_player(g) is not None


def assert_(prev, action, nxt, ctx=None):
    if not _clicked_six(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if _refusable(prev):
        return "NA"
    p, q = _pads(prev), _pads(nxt)
    both = [k for k in p if k in q]
    if not both:
        return "NA"
    still = 0
    for k in both:
        if q[k] == _flip(p[k]):
            continue
        if q[k] == p[k]:
            still += 1          # 原样不动：有图标时至多允许一块（图标管的那块）
            continue
        return "FALSE"          # 既没翻也没不动：主张当场垮
    if still == 0:
        return "TRUE"
    return "TRUE" if (still == 1 and _has_icon(prev)) else "FALSE"


def _maybe_gone(pads):
    """哪些垫子可能在这一步**不再是垫子**（玩家换位换到它头上去了）——只读 prev。

    传送的落点是「和玩家脚下那块同花色对」的那一块（card6_teleport）。玩家脚下是什么色单帧读不出来，
    所以凡是**同花色对只露着一块**的垫子，都可能正缺着一块被玩家踩在脚下、这一下就被换上去。
    这些格 assert_ 本来就滤掉了（「只看在 prev 和 nxt 里同一位置都是垫子的那些格」），apply 也必须闭嘴。
    """
    cnt = {}
    for px in pads.values():
        cnt[frozenset(px)] = cnt.get(frozenset(px), 0) + 1
    return {k for k, px in pads.items() if cnt[frozenset(px)] == 1}


def apply(prev, action, ctx=None):
    if not _clicked_six(prev, action):
        return None
    if _refusable(prev):
        return None                     # 玩家踩在件上：这一下可能整个被拒（见 NOTE v10）
    if _has_icon(prev):
        return None                     # 有图标：说不出哪一块不翻，就一块都不押（见 NOTE v8）
    pads = _pads(prev)
    keep = {k: v for k, v in pads.items() if k not in _maybe_gone(pads)}
    pred = _pred(prev, keep)            # 事前不知道 nxt：可能被换掉的那些不押，其余都押
    return pred or None


def apply_with_ground(prev, action, ctx=None, ground=None):
    """只供规划器（不进结算）：知道玩家脚下那一格是哪一对花色时，把落点那一块也让出去。

    这是一条**弃权**，不是新主张：SCOPE 本来就写着「只看在 prev 和 nxt 里同一位置都是抖动垫的那些格」，
    而玩家脚下那块的同花色伙伴就是这一下传送的落点（card6_teleport），它在 nxt 里是玩家色14、不是垫子，
    assert_ 一直把它滤掉。apply 事前看不出谁是落点，所以 v3 只能在「只露一块」时整条闭嘴；
    规划器手里有玩家踩上去之前那一帧，把脚下四像素递进来，这里就能精确地只让出那一块，别的照押。
    脚下读不出、或同花色的垫子不止一块，退回 apply。
    """
    if not _clicked_six(prev, action):
        return None
    if _refusable(prev):
        return None                     # v10：踩在件上就整条闭嘴
    if _has_icon(prev):
        return None                     # v8：有图标就整片闭嘴，`apply` 同款
    a = me(prev)
    pads = _pads(prev)
    px = None
    if a is not None and ground:
        px = tuple(ground.get((a[0] + i, a[1] + j)) for i in range(CELL) for j in range(CELL))
        if any(v is None for v in px):
            px = None
    if px is None or not any(set(px) == set(p) for p in PAIRS):
        return apply(prev, action, ctx)
    hit = [k for k, v in pads.items() if set(v) == set(px)]
    if len(hit) != 1:
        return apply(prev, action, ctx)
    pred = _pred(prev, {k: v for k, v in pads.items() if k != hit[0]})
    return pred or None


def apply_under(prev, action, ctx=None, ground=None):
    """**只供规划器**（不进结算、不算存活率）：这一下点击之后，帧上**看不见**的那几格底下是什么色。

    主张一个字没改：每一块垫子两色对调（图标管的那块除外）。改的只是「说给谁听」——
    `apply` 报的是帧上的颜色，而两块垫子在这一步会从帧上消失或本来就不在帧上：
    玩家换位踩上去的那块落点，和他这会儿正压着的那块。两块都照样翻，只是没人看得见翻。
    规划器要的正是这个：它的 `und`（玩家脚下四像素）是它自己的记性，翻没翻它必须跟着记，
    不然下一次换位就按错的花色算落点。

    由来（第 1000-1002 步，本 run 落盘的真帧）：第 1000 步玩家踩上 (48,18) 那块，当时露着的是 [6,7/7,6]；
    第 1001 步点色6 卡换位走开，那一格露出来是 [7,6/6,7]——**被压着的那块照样翻**；
    同一步的落点 (52,32) 点前露着 [7,6/6,7]，第 1002 步玩家走开时露出来是 [6,7/7,6]——**落点也照样翻**。

    v8 起这是全册唯一还在用 `_exempt` 的地方，而且是**明知道在猜**：玩家脚下那块若恰好就是图标管的那块，
    这里会多翻一次。留着猜是因为规划器手上没有别的来源（那块垫子帧上看不见），而猜错的代价只到相位那一层——
    换位的落点按**花色对**认（card6_teleport），相位翻没翻不改花色对。
    """
    if not _clicked_six(prev, action):
        return None
    if _refusable(prev):
        return None                                # v10：踩在件上就整条闭嘴，底下那几格也不记
    pads = _pads(prev)
    keep = _exempt(prev, pads)
    out = {}
    for k, px in pads.items():                 # 露着的每一块（含这一步的落点）翻完是什么色
        if k == keep:
            continue
        f = _flip(px)
        for i in range(CELL):
            for j in range(CELL):
                out[(k[0] + i, k[1] + j)] = f[i * CELL + j]
    a = me(prev)
    if a is not None and ground and a != keep:
        px = tuple(ground.get((a[0] + i, a[1] + j)) for i in range(CELL) for j in range(CELL))
        if all(v is not None for v in px) and any(set(px) == set(p) for p in PAIRS):
            f = _flip(px)                      # 他这会儿正压着的那块
            for i in range(CELL):
                for j in range(CELL):
                    out[(a[0] + i, a[1] + j)] = f[i * CELL + j]
    return out or None
