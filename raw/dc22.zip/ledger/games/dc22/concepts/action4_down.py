"""ACTION4 让 me 右移 2 像素列（0, +CELL），或整帧不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION4；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA；HUD 格（行63）返回 NA"
NOTE = "v15: 判据一个字没动，改的是 apply——目标格是色11 块（_lib.is_goal）时不再开口：走进它就换关，换关那一帧整屏重画，逐格预测必错。v14: 判据一个字没动，挨打的是词汇——第 879 步玩家往右走进图例屋的「右」标记格，面板上那颗菱形整块亮成色14（行35-38 列53-56），旧的 me() 从上往下扫第一个 2×2 的色14，指到了菱形身上，这条和 cell_enterable 一起判 FALSE（37e1f7195bbc3458）。_lib.me 改成按连通块形状认玩家（恰好 4 像素、方方正正）。教训记在词汇上：一个词的读法能撑八百条转移，不等于它撑得住下一条新出现的同色物件。v13: apply 把腾出的原格也押上——颜色按 _lib.floor_under 由四邻猜（435 次走开猜中 420 次）；不押原格时链式预测的模拟帧里会留下两个色14 块，me() 认错人。v12: apply 先查目标格进不进得去（_lib.enterable），进不去押原地不动。v11: apply 不再把腾出的格子押成色2——玩家站在桥/臂上时腾出的格子回到那件东西的颜色，prev 帧看不见脚下，只押新位置。v10: 换关那一帧整屏重画，玩家被放到新关起点，不是位移——返回 NA（0ece4a389344cee2 踩目标过关）。v9: 排除 HUD 更新（行63只有计数器，与玩家移动无关）；ce1cfb34bd152dc6 是 GAME_OVER 触发，只改 HUD"
EVIDENCE = ["6a560f0f6b6b8888", "e0e88e1e8b19e5e5", "74dd45b5e6bccf33", "9ce62bbf61b1bb5d", "0f5d3bbb11ca3e7b", "1e9d1a82fcf1de1e", "d7d6f58a12aefe46", "62c61e3ad865cdb5", "ddbb45a2986a072a", "8648be9d7f0c4aca", "a297d30bf2f476d7", "3875fef59267bbee", "1ef1e7f8b75d33fa", "20815ba89d204474", "1f14671286f3f3f1", "27e91e9c3126a7f3", "5f560f214d10e635", "794bdb7fb7bfd52d", "8c612ba9ac14c6ed", "9ff0203c44851be5", "c9c9e5681f76bc53", "d8d27b7bd42fa9df", "ce1cfb34bd152dc6", "0ece4a389344cee2", "37e1f7195bbc3458"]

from _lib import me, CELL, enterable, move_cells, is_goal

def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION4"):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    # 如果唯一帧差在行63（HUD），这不是玩家移动，返回 NA
    diffs = [(i,j) for i in range(64) for j in range(64) if prev[i][j] != nxt[i][j]]
    if diffs and all(i == 63 for i,j in diffs):
        return "NA"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (0, CELL) else "FALSE"

def apply(prev, action, ctx=None):
    if not action.startswith("ACTION4"):
        return None
    pos = me(prev)
    if pos is None:
        return None
    r, c = pos
    tr, tc = r, c + CELL
    # 走进色11 块就换关，整帧重画，这条概念说不出那一帧——闭嘴
    if is_goal(prev, tr, tc):
        return None
    # 目标格进不去就押「原地不动」；进得去就押新位置变色14
    if not enterable(prev, tr, tc):
        return move_cells(prev, r, c, r, c)
    return move_cells(prev, r, c, tr, tc)
