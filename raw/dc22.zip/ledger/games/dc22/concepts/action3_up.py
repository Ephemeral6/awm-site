"""ACTION3 让 me 左移 2 像素列，或整帧不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION3；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA"
NOTE = "v11: 判据一个字没动，改的是 apply——目标格是色11 块（_lib.is_goal）时不再开口：走进它就换关，换关那一帧整屏重画，逐格预测必错。v10: apply 把腾出的原格也押上——颜色按 _lib.floor_under 由四邻猜（435 次走开猜中 420 次）；不押原格时链式预测的模拟帧里会留下两个色14 块，me() 认错人。v9: apply 先查目标格进不进得去（_lib.enterable），进不去押原地不动。v8: 换关那一帧整屏重画返回 NA；apply 不再把腾出的格子押成色2（玩家站在桥/臂上时腾出的格子回到那件东西的颜色，prev 看不见脚下），只押新位置。v7: me() 返回像素坐标"
EVIDENCE = ["2e927afafb219ae9", "7889f20471db2c44", "142f36ce7cc22067", "eb8331147948bd4d", "a16b2dcafc0dc10f", "d31103ef94f81ec4", "b35b5fcdd94021c6", "73bf79284e3af9ea"]

from _lib import me, CELL, enterable, move_cells, is_goal

def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION3"):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    # 阻挡情况：me 不动，可能只改 HUD
    if a == b:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (0, -CELL) else "FALSE"

def apply(prev, action, ctx=None):
    if not action.startswith("ACTION3"):
        return None
    pos = me(prev)
    if pos is None:
        return None
    r, c = pos
    tr, tc = r, c - CELL
    # 走进色11 块就换关，整帧重画，这条概念说不出那一帧——闭嘴
    if is_goal(prev, tr, tc):
        return None
    # 目标格进不去就押「原地不动」；进得去就押新位置变色14
    if not enterable(prev, tr, tc):
        return move_cells(prev, r, c, r, c)
    return move_cells(prev, r, c, tr, tc)
