"""方向键走一步之后，若挪走前那一格既读不出「面板菱形/垫子搭档/横条」的脚下信息（_lib.standing_on
为 None）、地图上也没有任何一对花色的垫子只剩一块可见（_lib.maybe_on_pad 为假），玩家原来那一格露出来
的颜色就是 _lib.floor_under 按四邻多数投票猜出的那个色。"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION1-4 且真的挪动了一格：me(prev) 定位得到、目标格 enterable 且不是通关格"
    "（goal_is_color11_block 管的那格）、真实 nxt 里 me() 落在这个目标格上；换关"
    "（ctx.level_prev != level_next）返回 NA。域内再筛：standing_on(prev) 不是 None"
    "（面板菱形亮着/垫子只剩一块且相位可判/横条上）——那种情形另有概念"
    "（legend_marker_lights_diamond 的逆用、pad_partner_under_player、card11_l3_bars_shift）管，"
    "这里退让，返回 NA。maybe_on_pad(prev) 为真（花色分对后有恰好一对只剩一块可见，"
    "可能玩家正踩在它的搭档上）——这里明确拒绝猜，返回 NA，不是这条概念的地盘。"
    "floor_under(prev, r, c) 打平（四邻票数相等）返回 NA。"
    "只断言原格四像素是否等于 floor_under 猜出的那个单一颜色。"
)
NOTE = (
    "跑法：把 dc22 两个 run（dc22-0915-2238 + dc22-0916-1543）按 tid 去重合并（跑这条概念时是"
    "2274 条不同转移，语料是活的，仍在长），在全语料上筛出「方向键走一步、目标格进得去、真的挪过去了」"
    "的转移共 1464 条。standing_on(prev) 读得出来的只有 85 条（5.8%）；读不出来的 1379 条里，"
    "_lib.maybe_on_pad(prev) 为真（花色分对后有一对只剩一块）挡掉 499 条（36.2%）——这部分独立核过"
    "floor_under 的猜法：猜对 380 条（76.2%）、猜错 99 条（19.8%，其中 55 条是真的踩在垫子搭档上、"
    "39 条是脚下其实是十字件中心那圈色8/12 环、5 条是猜错了但真相其实是平地色2）、打平猜不出 20 条。"
    "也就是说 maybe_on_pad 挡的这 499 条里，四分之三其实是错杀——但从单帧分不出这三成会踩雷的和"
    "七成能猜对的，所以这条概念不进这一段，都判 NA，留给以后找到能分辨的判据再收。"
    "没被挡的 880 条（占 standing_none 的 63.8%）里，floor_under 打平 37 条（NA），剩下 843 条"
    "全部猜对，一条反例都没有——这条概念断言的就是这 843 条（外加语料以后再长出的同类转移）。"
    "EVIDENCE 按 (level, floor_under 猜出的颜色) 去重各取一条，横跨 5 个关卡（level 0-4）、"
    "9 种不同的落地颜色（1/2/6/7/8/9/12/13/15），不是只在某一种平地色上验证过。"
    "另查过一件事：pad_partner_under_player 用的口径（地图区总共只露一块垫子，len(pads)==1）和"
    "maybe_on_pad 用的口径（按花色分对、某一对只剩一块）理论上可能不一致——总数不是1但某一对恰好"
    "缺一块的情形。语料上实测：花色分对后恰好只有一对缺一块的转移共 12 条，这 12 条无一例外"
    "len(pads(prev))==1，也无一例外玩家脚下真的是那一对的搭档（12/12）。两个口径在这批语料上"
    "没有分岔（gap=0）——不是没有分岔的可能，是这批语料还没走到那种局面（多数情形是 545 条转移"
    "同时有不止一对垫子恰好缺一块，这时两个口径都不敢下判断，一起弃权）。这条不是本概念断言的内容，"
    "只在这里留个底：以后如果要收窄 maybe_on_pad 挡的那 499 条，先查这条线索。"
)
EVIDENCE = [
    "89db1714b36607f3", "2dd275093e8684a2", "cc018457c5a661f0", "4dcd7f304ebf3d7c",
    "954239274b7a5a5e", "453c252708a986dc", "2996ca30e8bab9d1", "602473a346f21631",
    "b01be044c6c33515", "7f73427bc172e244", "b26235d9a32a3a91", "bfa50ee1693b7b60",
    "824697e80c1d4d2b", "c5de822bb7c33a53", "35fde72b16880809", "fff33d45ea82dfc8",
    "1c7deea0ee54e82e", "13fbfc18787e4ae0", "69b4f69b0d36cba7", "13554c48ef507cd6",
    "56611efabb5abf3d", "4fcc90332e0f25a6",
]

from _lib import me, DELTA, enterable, is_goal, standing_on, maybe_on_pad, floor_under


def _target(prev, action):
    """方向键这一步预备走到哪：(r, c, tr, tc)；不是方向键、定位不到玩家、目标格是通关格或进不去，返回 None。"""
    if action not in DELTA:
        return None
    a = me(prev)
    if a is None:
        return None
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    if is_goal(prev, tr, tc) or not enterable(prev, tr, tc):
        return None
    return (a[0], a[1], tr, tc)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    t = _target(prev, action)
    if t is None:
        return "NA"
    r, c, tr, tc = t
    b = me(nxt)
    if b != (tr, tc):
        return "NA"                       # 没真的走过去（撞了别的东西/帧不对应）
    if standing_on(prev) is not None:
        return "NA"                       # 脚下读得出来，归另一条概念管
    if maybe_on_pad(prev):
        return "NA"                       # 花色分对后有一对只剩一块，可能正踩着——不猜
    fg = floor_under(prev, r, c)
    if fg is None:
        return "NA"                       # 四邻票数打平，猜不出
    got = (nxt[r][c], nxt[r][c + 1], nxt[r + 1][c], nxt[r + 1][c + 1])
    return "TRUE" if all(v == fg for v in got) else "FALSE"


def apply(prev, action, ctx=None):
    t = _target(prev, action)
    if t is None:
        return None
    r, c, _, _ = t
    if standing_on(prev) is not None or maybe_on_pad(prev):
        return None
    fg = floor_under(prev, r, c)
    if fg is None:
        return None
    return {(r, c): fg, (r, c + 1): fg, (r + 1, c): fg, (r + 1, c + 1): fg}
