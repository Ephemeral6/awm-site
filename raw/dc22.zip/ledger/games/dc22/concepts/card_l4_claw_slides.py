"""点面板上那排四颗 4×4 实心按钮（按列从左到右是色10/色9/色10/色9）中的一颗：地图区里唯一那只色8 爪子、连同它**合口咬住**的色12 件（口张着时杆不跟着走，爪子自己走），整体朝这颗按钮管的方向（左起第 1/2/3/4 颗 = 左/上/右/下）平移 4 像素，别的像素一格不动，只有件让开的那些格里、爪子腰上那个 4×4 轨道格所占的像素露出来的是轨道色0；而爪子腰上那个 4×4 轨道格平移之后只要有一个像素出了地图、或者**底下**（不是面上）不是轨道色0，这一下就整帧一格不动——底下被件自己盖着、单帧读不出来的那些格，这一条不说走不走，只说「要是动了就得整体平移 4 像素」。"""
LEVEL = "L6"
SCOPE = (
    "只看 ACTION6:<列>,<行>，且被点像素在 prev 里是色9 或色10、落在面板区（列 >= PANEL_COL0）。"
    "面板上必须恰好有四块「16 像素、外接框 4×4、整块同色」的色9/色10 实心块，四块顶边同一行，"
    "按列排序颜色恰好是 (10, 9, 10, 9)，且被点的像素落在其中一块里——否则返回 NA。"
    "（这一条把别处那些长得像的东西挡在外面：面板上 16 像素全亮的菱形也是实心 4×4，但一次只亮一颗，凑不出四块同行的；"
    "47 像素的相变卡、4 像素的小图标象限尺寸对不上。）\n"
    "地图区（行 < MAP_ROWS、列 < PANEL_COL0）里的色8 四连通块必须**恰好一块**，且外接框宽恰好 8 列、"
    "高 6 行或 8 行（张口的爪子 8 行 30 像素，合口的 6 行 28 像素）；不是这个样子返回 NA。"
    "件 = 从这块色8 出发、在地图区内铺开的四连通像素：**合口时（6 行）沿 {色8, 色12} 铺，张口时（8 行）只沿色8 铺**；"
    "件平移后会有像素落到地图区之外时返回 NA（没见过）。\n"
    "玩家色14 的像素只要有一个落在件的外接框里、或落在爪子腰上那个 4×4 轨道格、或落在它平移后的目标格里，"
    "一律返回 NA（玩家压在件上时世界不动，但这种局面全语料只有一条，不够立断言）。换关返回 NA。"
    "只断言行 0-61；HUD 两行（行 62-63）不管。件让开的那些格里只断言腰格那 16 个像素（在 next 里不再被件盖住的那些是色0），"    "其余让开的格不断言——底下是什么读不出来。"
    "目标腰格里只要有一个像素**底下**是什么色读不出来，「走不走」这一问返回 NA——"
    "读不出来有三种：玩家盖着 / 离场规划器标的负数哨兵（`_lib.unreadable`）、被件自己盖着（帧上只看得见件）。"
    "这时不整条闭嘴，只退到还能判错的那一半：**要是这一帧真动了，就必须是整体平移 4 像素那个样子**"
    "（件的落点、腰格让开处的色0、其余像素一格不动，任一条不符仍判 FALSE）；这一帧没动则返回 NA。"
)
NOTE = (
    "读法是从帧差逆出来的，派给我的猜测「这是一组方向键，推着某个大件走，推不动时 0 格」只对了前半句，"
    "四条被推翻的读法各附反例：\n"
    "1) 「按钮颜色决定方向」不成立：色10 两颗确实都是横向、色9 两颗都是纵向，"
    "但同色的两颗方向相反（左起第 1 颗色10 往左、第 3 颗色10 往右）。方向只能按**列序**认。"
    "反例形状：cf9aab0584c3bc2e（第 3 颗色10）与 8848517cbb5f8bc8（第 1 颗色10）在同一个爪子位置上，"
    "一个的目标格出了地图、一个的目标格不在轨道上，按颜色认会把这两颗混为一谈。\n"
    "2) 「件就是那只色8 爪子」不够：爪子合口咬住色12 的杆之后，杆整根跟着走"
    "（3063f91327b699e5：48 个色12 让位、24 个色4 变色12）；合口之前杆一动不动（343d6da45a3e43b5）。"
    "所以件按 {色8, 色12} 四连通取，不按颜色单取。"
    "**v5 更正：这一条只对了一半。**「合口之前杆一动不动」当年是靠「张口的爪子当时还没挨上杆、"
    "四连通自然取不到它」蒙对的，不是靠判据。第 871 步（d4b254512fda5c77）规划器把张口的爪子一路开到"
    "紧贴着杆（爪子行12-19 列14-21，杆在它右边，两者四连通成一块 84 像素的件），再点左键："
    "实际只有那 30 个色8 像素左移了 4 像素，54 个色12 一格没动，这条概念押的 80 格错了 48 格，退出码 5。"
    "改法：口张着（外接框 8 行）时件只沿色8 铺，口合着（6 行）时才连色12 一起铺。"
    "全语料 1883 条上只有这一条判词变了（FALSE→TRUE），别的一条没动。"
    "教训写进方法册：**「我的读法在语料上从没出错」和「我的读法说的是对的道理」是两件事**——"
    "靠位置蒙对的那一半，会被规划器专程走到它蒙不对的位置上去。\n"
    "3) 「撞到色4 的墙就推不动」是错的，而且错得很干净：允许走的那一次，件的落点上有 48 个色4"
    "（f76e7b402400efb8）；被拦的那一次，件的落点上只有 41 个色4（dda9589ed9e780fa）——件压不压墙"
    "跟走不走得动无关，爪子是画在墙上面的。真正决定走不走的是**爪子腰上那一格**：爪子外接框正中的 4 行、"
    "左边起第 2 到第 5 列，正好是一个 4×4 的格，它落在一条 4 像素宽的色0 轨道里（轨道是条拐两道弯的长条）。"
    "这一格平移 4 像素之后整格仍在轨道上（每个像素非色0 即件自身）才走，否则整帧不动。"
    "列的相位是拿反例钉死的：取成「左边起第 1 到第 4 列」，会把沿轨道横臂往左走的那一次误判成不动"
    "（爪子左邻那一列是色4）；取成「第 3 到第 6 列」，会把沿轨道底臂一路向右走到头那一次（f76e7b402400efb8，实测走了）"
    "误判成不动。行同理：取正中 4 行才能同时容下轨道竖臂的两端，偏一行就会把竖臂两端的合法位置判死。\n"
    "4) 「玩家挡不住」被一对转移推翻：同一个件位置、同一个方向，玩家站在件上那一次整帧不动"
    "（e9800c19bf9dabb6），玩家挪开之后照走不误（e415d5ab6f92ec5f）。只有这一个正例，不够断言"
    "「玩家压着就不动」，所以把玩家挨着件的局面整个划出 scope。\n"
    "apply 只填件的落点，**不填让开的那些格**：爪子底下的背景是读不出来的隐藏状态。量过三种猜法，"
    "最好的一种（与爪子同相位的 4×4 格里整格「色0 或被件盖住」就算轨道，让开处在轨道上猜色0、否则猜色4）"
    "在 2818 个让开像素上只对 2651 个（94.1%）；错的集中在被爪子整个盖住的那件色2/色15 道具（111 个像素）"
    "和轨道边上多出来的一列。躲开可见色2/色15 附近再猜反而更差（半径 2 时 92.6%、半径 4 时 91.8%），"
    "因为道具会被爪子整个盖住、附近一个色2/色15 都看不见。"
    "代价说清楚：链式预测里件会留下一个影子，下一步「地图里恰好一块色8」认不出来，这条概念会闭嘴。\n"
    "开口范围实测：两个 run 合起来 1675 条去重转移，这条概念开口 73 条，全部落在同一关（level_prev 全相等），"
    "其中 65 条判「走了」、7 条判「不动」、1 条因玩家压在件上返回 NA；0 条反例。\n"
    "5) 让开的格从「一格不断言」改成「腰格那 16 个像素，件走了之后没被件盖住的都是色0」（本版）。"
    "理由是上一版留的那个代价真的咬人了："
    "规划器离场搜索时，件走开处一律记成「不知道」，爪子折回去踩自己走过的路时，"
    "目标腰格里全是「不知道」，`_plan` 只好闭嘴，搜索在半路上死掉。"
    "而腰格本身是可以断言的：件真的走了的那 32 条转移里，腰格在 next 里露出来的像素共 353 个，"
    "353 个全是色0，一个例外都没有（对照：全部 1396 个让开像素里色0 只有 591 个，还有 752 个色4、31 个色2、22 个色15，"
    "所以宽到整片让开区就不行；再对照：沿行进方向把腰格那条 4 宽带拉到爪子全长，584 个像素里有 90 个色4，也不行）。"
    "物理上说得通：腰格是按「整格落在色0 轨道上」定义的，爪子只沿轨道走。\n"
    "6) 「目标腰格里属于件自身的像素算通行」（第 3 条留下的那句豁免）被第 903 步推翻，而且**修不成单帧规则**（本版）。"
    "反例 82b8b5332f6ff4a4：合口的件（82 像素）在行13-18 列14-21，点右键，目标腰格是行14-17 列19-22，"
    "里面 12 个像素被件自己盖着、4 个是可见的色0，按豁免整格放行，这条概念押「走」、逐格给了 86 格，世界一格没动。"
    "真正的规矩是**底下**那片地：拿本关 301 条转移把这 16 个像素的历史颜色翻出来——"
    "列19 是色0（293 次）、列20 是色0（199 次），而列21 一次色0 都没有（色4 257 次）、列22 也没有（色4 207 次）："
    "目标腰格有一半压在色4 的墙上。对照真走了的 f76e7b402400efb8（同样合口、同样点右键、目标腰格行26-29 列15-18），"
    "那 16 个像素的底色全是色0（258 次）。所以判据是「目标腰格底下整格是色0 轨道」，豁免那句是错的。\n"
    "但**这一条单帧读不出来**：`zglyph` 把两条转移的爪子图形连同右边 8 列一起打出来，两幅图逐像素相同——"
    "件把自己要去的那一片地盖住了，帧上看见的是件，不是地。量过另外三种只用帧的读法，全不行："
    "「落点压着色2 就不动」被证伪（走了的那几条里杆也压着 8 个色2）；「色0 或色8 才通行」在 97 条能判的转移上错 18 条；"
    "「只放行帧上看见的色0」错 80 条，而且全是**说不动而世界动了**——也就是说，把豁免直接删掉会把 80 条对的判成错的。"
    "既然帧上答不出，这一版就不在那儿硬答：走不走返回 NA，只保留还能判错的那一半"
    "（`_assert_moved_half`：要是动了，就必须是整体平移 4 像素那个样子）。"
    "规划器另走一条路——它一路上把每一格「没被件盖着时是什么色」记下来，从 `apply_with_ground` 递进来，"
    "那是看见过的读数不是猜的；没人见过的格子照旧弃权。\n"
    "教训（与第 2 条同源，写进方法册）：**在语料上从没出错，可能只是底下那片地恰好是路**。"
    "两条局面像素级相同而世界给出相反答案时，任何单帧规则都必须闭嘴——那不是判据没调好，是这一帧里信息不够。"
)
EVIDENCE = [
    "98a2554bc01c4f07",   # 张口的爪子朝上走一格
    "343d6da45a3e43b5",   # 张口的爪子朝右走，色12 的杆不动
    "3063f91327b699e5",   # 合口之后整根杆跟着走
    "a6472811c1597ada",   # 合口的件朝左走
    "8848517cbb5f8bc8",   # 目标格出地图 -> 不动
    "92b051a23f8d7fe1",   # 同上，另一个 run
    "cf9aab0584c3bc2e",   # 目标格不在轨道上 -> 不动
    "8d723a25edd846d1",   # 同上
    "328ff296ca56db50",   # 同上（朝上）
    "a0c18931b3830e06",   # 同上（朝下）
    "dda9589ed9e780fa",   # 合口的件朝下：落点只有 41 个色4 也照样不动
    "f76e7b402400efb8",   # 落点 48 个色4 却走了——「撞墙就不动」的反例
    "e9800c19bf9dabb6",   # 玩家压在件上 -> 整帧不动（划出 scope，返回 NA）
    "e415d5ab6f92ec5f",   # 玩家挪开，同一位置同一方向照走
    "0239a2cdbffd035d",   # 腰格让开处露出色0（本版新增的那半句）
    "fc370c3acaf48d4d",   # 同上，另一个方向
    "16e58cb9766c0605",   # 同上
    "d4b254512fda5c77",   # 张口的爪子紧贴着杆往左走：只有爪子走，杆不动（v5 的由来）
    "82b8b5332f6ff4a4",   # 目标腰格底下一半是色4 的墙：世界不动，而帧上只看得见件（v6 的由来）
]

from _lib import MAP_ROWS, PANEL_COL0, unreadable
from geo import components

MAP_COLS = PANEL_COL0          # 地图区只取列 < PANEL_COL0
BTN_COLORS = (9, 10)           # 按钮只有这两种颜色
BTN_ORDER = (10, 9, 10, 9)     # 四颗按钮按列从左到右的颜色
BTN_DIRS = ((0, -4), (-4, 0), (0, 4), (4, 0))   # 对应：左、上、右、下
BTN_SIDE = 4                   # 按钮是 4×4 实心块
PIECE = (8, 12)                # 爪子 + 它咬住的件
CLAW = 8
TRACK = 0                      # 轨道底色
ME = 14
CELL4 = 4                      # 轨道格边长，也是一下走的像素数


def _click(action):
    """ACTION6 点的 (行, 列)；不是 ACTION6 或记号不合法返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return r, c


def _buttons(g):
    """面板上那排 4×4 实心按钮 [(行, 列, 色)]，按列排序；按「16 像素、外接框 4×4」认，不认坐标。"""
    out = []
    for k in BTN_COLORS:
        px = {(r, c) for r in range(min(MAP_ROWS, len(g)))
              for c in range(PANEL_COL0, len(g[0])) if g[r][c] == k}
        for comp in components(px):
            if len(comp) != BTN_SIDE * BTN_SIDE:
                continue
            rs = [p[0] for p in comp]
            cs = [p[1] for p in comp]
            if max(rs) - min(rs) == BTN_SIDE - 1 and max(cs) - min(cs) == BTN_SIDE - 1:
                out.append((min(rs), min(cs), k))
    return sorted(out, key=lambda b: b[1])


def _dir(g, action):
    """这一下点的是哪颗按钮、它管哪个方向；不是点这排按钮返回 None。"""
    rc = _click(action)
    if rc is None:
        return None
    r, c = rc
    if not (0 <= r < min(MAP_ROWS, len(g)) and PANEL_COL0 <= c < len(g[0])):
        return None
    if g[r][c] not in BTN_COLORS:
        return None
    bs = _buttons(g)
    if len(bs) != len(BTN_ORDER):
        return None
    if any(b[0] != bs[0][0] for b in bs):
        return None
    if tuple(b[2] for b in bs) != BTN_ORDER:
        return None
    for i, (br, bc, _k) in enumerate(bs):
        if br <= r < br + BTN_SIDE and bc <= c < bc + BTN_SIDE:
            return BTN_DIRS[i]
    return None


def _claw(g):
    """地图区里唯一那块色8 四连通块的外接框 (r0, r1, c0, c1)；不是「宽 8 列、高 6 或 8 行」返回 None。"""
    px = {(r, c) for r in range(min(MAP_ROWS, len(g)))
          for c in range(min(MAP_COLS, len(g[0]))) if g[r][c] == CLAW}
    comps = components(px)
    if len(comps) != 1:
        return None
    rs = [p[0] for p in comps[0]]
    cs = [p[1] for p in comps[0]]
    r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
    if c1 - c0 != 7 or (r1 - r0) not in (5, 7):
        return None
    return r0, r1, c0, c1


def _open_mouth(bb):
    """爪子张着口还是合着口：外接框 8 行是张口（30 像素），6 行是合口（28 像素）。"""
    r0, r1, _c0, _c1 = bb
    return r1 - r0 == 7


def _piece(g, bb):
    """件：**合口**的爪子连同它咬住的色12 杆，沿 {色8, 色12} 四连通铺开；
    **张口**的爪子只算它自己那块色8——口开着的时候，挨着不等于咬住。"""
    r0, r1, c0, c1 = bb
    n, m = min(MAP_ROWS, len(g)), min(MAP_COLS, len(g[0]))
    flow = (CLAW,) if _open_mouth(bb) else PIECE
    seen = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if g[r][c] == CLAW}
    st = list(seen)
    while st:
        r, c = st.pop()
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (r + dr, c + dc)
            if p in seen or not (0 <= p[0] < n and 0 <= p[1] < m):
                continue
            if g[p[0]][p[1]] in flow:
                seen.add(p)
                st.append(p)
    return seen


def _cell(bb):
    """爪子腰上那个 4×4 轨道格：外接框正中的 4 行 × 左边起第 2 到第 5 列。"""
    r0, r1, c0, _c1 = bb
    top = r0 + (r1 - r0 + 1 - CELL4) // 2
    return {(top + i, c0 + 1 + j) for i in range(CELL4) for j in range(CELL4)}


def _ground(g, p, pc, ground):
    """这一格**底下**是什么色：没被件盖住时就是帧上看见的那个色；被件盖住时单帧读不出来，
    只认调用方递进来的底色表 `ground`（规划器从真帧记下来的，见 apply_with_ground），
    表里也没有就返回 None ——「说不出」，不是「不是轨道」。"""
    if p not in pc:
        return g[p[0]][p[1]]
    if ground is None:
        return None
    return ground.get(p)


def _plan(g, action, ground=None):
    """这一下点击的结果：(件的落点 {位置: 色}, 走没走成)；认不出局面、或目标腰格底下读不出来返回 None。"""
    d = _dir(g, action)
    if d is None:
        return None
    bb = _claw(g)
    if bb is None:
        return None
    pc = _piece(g, bb)
    cur = _cell(bb)
    dr, dc = d
    tgt = {(r + dr, c + dc) for r, c in cur}
    n, m = min(MAP_ROWS, len(g)), min(MAP_COLS, len(g[0]))
    rs = [p[0] for p in pc]
    cs = [p[1] for p in pc]
    hull = {(r, c) for r in range(min(rs), max(rs) + 1) for c in range(min(cs), max(cs) + 1)}
    for r in range(n):
        for c in range(m):
            if g[r][c] == ME and ((r, c) in hull or (r, c) in cur or (r, c) in tgt):
                return None                      # 玩家挨着件：这种局面不开口
    if any(not (0 <= r < n and 0 <= c < m) for r, c in tgt):
        return {}, False                         # 目标腰格出了地图：不动
    under = []
    for p in tgt:
        col = _ground(g, p, pc, ground)
        if col is None or unreadable(col):
            return None                          # 目标腰格底下读不出来：说不出走不走，闭嘴
        under.append(col)
    if not all(col == TRACK for col in under):
        return {}, False
    if any(not (0 <= r + dr < n and 0 <= c + dc < m) for r, c in pc):
        return None                              # 件会被推出地图区：没见过，不开口
    return {(r + dr, c + dc): g[r][c] for r, c in pc}, True


def apply_mover(prev, action, ctx=None, ground=None):
    """**只供规划器，永不参与断言、不进结算**：这一下点击里会挪窝的那个物件占了哪些像素——
    返回 (挪之前, 挪之后) 两个像素集合；这一下走不动、或认不出局面就返回 None。
    `ground` 同 `apply_with_ground`：件盖住的那些像素底下是什么色，由规划器从真帧记下来递进来。

    为什么要有它：`apply` 按设计**不填件让开的那些格**（底下是什么是隐藏状态，最好的猜法也只有 94.1%）。
    可离场规划里「不填」= 上一帧的样子原样留着，于是件走一步就在原地留下一个影子，
    下一步「地图区里恰好一块色8」认不出来，这条概念整条闭嘴——实测第 4 关的搜索因此在每条分支上
    只推得动件一次，450 个局面就把空间搜完了，报「目标不可达」。
    这里报的不是「让开那格是什么色」（那才是主张），只是**坐标**：哪些像素被盖住了、哪些露出来了。
    规划器拿它自己记账——件盖上去之前那一格是什么色，规划器上一帧见过，还回去就是了。
    件一开始就盖着的那一片没人见过，规划器会记成「不知道」，这条概念照旧读不了它、照旧闭嘴，那是对的。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    d = _dir(prev, action)
    if d is None:
        return None
    bb = _claw(prev)
    if bb is None:
        return None
    got = _plan(prev, action, ground)
    if not got or not got[1]:
        return None
    pc = _piece(prev, bb)
    dr, dc = d
    return pc, {(r + dr, c + dc) for r, c in pc}


def apply_cover(prev, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：那个会挪窝的物件此刻占了哪些像素（只报坐标，不报颜色）。

    和 `apply_mover` 的区别是它不问「这一下走不走得动」：规划器要在**每一张真帧**上知道
    「哪些地面此刻被物件盖着」才记得住底色（盖着的时候看见的不是地面），
    而那时候还没有哪一下点击、更谈不上走不走得动。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    bb = _claw(prev)
    if bb is None:
        return None
    return _piece(prev, bb)


def apply_with_ground(prev, action, ctx=None, ground=None):
    """**只供规划器，永不参与断言、不进结算**：和 `apply` 一句话不差，只是多收一张底色表
    `ground = {(行,列): 色}`——件此刻盖着的那些像素，在件盖上去**之前**的真帧上是什么色。

    为什么非要它不可（第 903 步的由来，见 NOTE 第 6 条）：走不走取决于目标腰格**底下**是不是轨道，
    而件盖着的地方单帧看不见底下。`apply` 于是在那种局面一律弃权——这是诚实的，但规划器就推不动件了。
    规划器手里恰好有这张表：它从本关的真帧上一格一格记下来「这一格没被物件盖着的时候是什么色」，
    那是**看见过的读数**，不是猜的。表里没有的格子（开局就盖着、谁都没见过）照旧读不出来，照旧弃权。

    这里藏着一条**明说的假设**：这一关的地是静的——件盖过去又走开，底下还是原来那块地。
    它走不了闸（单帧判不了：要跨帧才看得见同一格「盖住前」和「露出后」），所以它不是概念，是假设。
    它错了会怎样：规划器按它算出来的那一步预测落空，`act --from-bet` 退出码 5 当场停批——
    这就是它唯一的兑现方式，不假装它是被检验过的。
    """
    return _apply(prev, action, ctx, ground)


def apply_hidden(prev, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：件现在盖着的那些像素里，册子说得出底下是什么色的——
    腰格那 16 个像素中被件盖住的，底下是轨道色0；返回 {(行,列): 色}，认不出局面返回 None。

    这不是一条新主张，是主张的另一半：`assert_` 每次件走开都在腰格露出来的像素上核它
    （全语料 353 个露出来的腰格像素，353 个是色0）。区别只在于**还没露出来**的那些——
    规划器要靠它们才推得动件，否则件一走开就在自己的起手位置上留一片「不知道」，
    折回去时腰格读不出来，这条概念只好闭嘴（实测第 4 关的离场搜索因此死在半路）。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    bb = _claw(prev)
    if bb is None:
        return None
    pc = _piece(prev, bb)
    return {p: TRACK for p in _cell(bb) if p in pc}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    got = _plan(prev, action)
    if got is None:
        return _assert_moved_half(prev, action, nxt)
    want, moved = got
    rows = min(MAP_ROWS, len(prev))
    if not moved:
        for r in range(rows):
            if prev[r] != nxt[r]:
                return "FALSE"
        return "TRUE"
    for (r, c), v in want.items():
        if nxt[r][c] != v:
            return "FALSE"
    bb0 = _claw(prev)
    src = _piece(prev, bb0)
    for r, c in _waist_free(prev, bb0, action):
        if nxt[r][c] != TRACK:
            return "FALSE"                        # 腰格让开处露出来的必须是轨道色0
    for r in range(rows):
        for c in range(len(prev[0])):
            if (r, c) in src or (r, c) in want:
                continue                          # 件让开的其余格不断言：底下是什么读不出来
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def _assert_moved_half(prev, action, nxt):
    """目标腰格底下读不出来（件自己盖着）时还能核的那一半：**要是它真动了，就必须动成这个样子**。

    走不走得动这一问，单帧答不出来（NOTE 第 6 条）；但「动了的话怎么动」答得出来，而且照旧可判错：
    件整体朝这颗按钮管的方向平移恰好 4 像素、别的像素一格不动、腰格让开处露出轨道色0。
    这一帧没动 → 返回 NA（这一版不声称「它本该动」）。
    """
    d = _dir(prev, action)
    bb = _claw(prev)
    if d is None or bb is None:
        return "NA"
    rows = min(MAP_ROWS, len(prev))
    if all(prev[r] == nxt[r] for r in range(rows)):
        return "NA"                               # 世界没动：这一版说不出它本该动不动
    pc = _piece(prev, bb)
    dr, dc = d
    want = {(r + dr, c + dc): prev[r][c] for r, c in pc}
    if any(not (0 <= r < rows and 0 <= c < min(MAP_COLS, len(prev[0]))) for r, c in want):
        return "NA"                               # 件被推出地图区：没见过
    for (r, c), v in want.items():
        if nxt[r][c] != v:
            return "FALSE"
    for r, c in _waist_free(prev, bb, action):
        if nxt[r][c] != TRACK:
            return "FALSE"
    for r in range(rows):
        for c in range(len(prev[0])):
            if (r, c) in pc or (r, c) in want:
                continue
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def _waist_free(g, bb, action):
    """件走了之后，腰格那 16 个像素里**不再被件盖住**的那些——这一版断言它们在 next 里是轨道色0。"""
    d = _dir(g, action)
    if d is None or bb is None:
        return set()
    pc = _piece(g, bb)
    new = {(r + d[0], c + d[1]) for r, c in pc}
    return set(_cell(bb)) - new


def apply(prev, action, ctx=None):
    """装置认的那个签名：三个参数，没有底色表 —— 件盖着的地方一律弃权（返回 None）。"""
    return _apply(prev, action, ctx, None)


def _apply(prev, action, ctx=None, ground=None):
    got = _plan(prev, action, ground)
    if got is None:
        return None
    want, moved = got
    if not moved:
        return {}
    out = {k: v for k, v in want.items() if prev[k[0]][k[1]] != v}
    for r, c in _waist_free(prev, _claw(prev), action):
        if prev[r][c] != TRACK:
            out[(r, c)] = TRACK
    return out
