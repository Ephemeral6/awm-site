"""玩家踩上一块图例标记格（四像素是 1、0、0、X），面板上带色X 标记的那颗 4×4 菱形整块亮成色X；玩家走开，它灭回色4、只剩右下角那一像素还是色X。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1-4 且玩家真换了格；进的那格（读 prev）或让出的那格（读 nxt）至少有一个是标记格，否则 NA；面板里找不到带色X 的 16 像素菱形也 NA；换关 NA；me() 定位不到 NA"
NOTE = "v4: 补一个**只供规划器**的接口 waypoint_cells（报图例标记格在哪），判据与 apply 一个字没动。为什么补：规划器的路标槽此前只有垫子报得出来，于是「先走到标记格再点对应那颗菱形」这种边在搜索里根本不存在——而这一关会挪窝的那个件，每挪 4 像素都要先换一块标记格。路标的定义（站上去不改地图、改的是有哪些边）说的正是这条概念断言的事。v3: apply 补上「走开那一半」——判据从 v1 起就同时断言进和出，apply 却只画进，于是链式预测里菱形一亮就再也不灭，下一步 _lib.standing_on 顺着那颗假亮的菱形把玩家脚下读成标记格，第 892、895 步各错 4 格。现在走离标记格也画：那颗亮着的菱形灭回色4、只留右下角。走开的是哪一块不用去猜——它正亮着，lit_diamond 在面板上直接认得出。撞墙没挪窝则不画（人还站在原地，灯照旧亮）。判据一个字没动。v2: 找菱形那段（按颜色沿 {色4,色X} 四连通铺开、取 16 像素的那块）挪进 _lib 叫 panel_diamond，另一条概念 lit_diamond_moves_box 也要用它；判据一个字没动。v1: 第 862 步踩着垫子点「上」菱形一格没动（diamonds_inert 第 16 次 TRUE），第 866 步玩家从垫子往上走进标记格 (56,34)，面板上那颗带色15 的菱形（行31-34 列49-52）整块 4→15（73ee06ae28c73c86）；第 867 步走开，它 15→4 只留右下角 (34,52) 那点色15（aa16fb964c677511）；第 868、869 步又亮又灭（94d19429542fa05a、95dc3f1e53aec8eb）。这解释了围死的图例屋是干什么用的：它不是通路，是开关房——四块标记格分别对应面板四颗菱形，标记格里那个色X 就是认领哪一颗（上15 左12 右14 下10，和菱形自带的标记像素一一对上）。菱形按位置认会写死坐标，所以这里按颜色认：从面板里的色X 像素沿 {色4, 色X} 四连通铺开，取那块恰好 16 像素的。"
EVIDENCE = ["73ee06ae28c73c86", "aa16fb964c677511", "94d19429542fa05a", "95dc3f1e53aec8eb"]

from _lib import me, CELL, DELTA, marker_color, panel_diamond, lit_diamond, enterable


def _cellpx(g, r, c):
    if r < 0 or c < 0 or r + CELL > len(g) or c + CELL > len(g[0]):
        return None
    return [g[r + i][c + j] for i in range(CELL) for j in range(CELL)]


def _ok(g, x, lit):
    d = panel_diamond(g, x)
    if d is None:
        return None
    vals = [g[r][c] for r, c in d]
    if lit:
        return all(v == x for v in vals)
    corner = (max(r for r, _ in d), max(c for _, c in d))
    return all((g[r][c] == x) == ((r, c) == corner) or g[r][c] == 4 for r, c in d) and \
        vals.count(x) == 1 and g[corner[0]][corner[1]] == x


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return "NA"
    px_in, px_out = _cellpx(prev, *b), _cellpx(nxt, *a)
    entered = marker_color(px_in) if px_in else None
    left = marker_color(px_out) if px_out else None
    if entered is None and left is None:
        return "NA"
    verdicts = []
    for x, lit in ((entered, True), (left, False)):
        if x is None:
            continue
        v = _ok(nxt, x, lit)
        if v is None:
            return "NA"
        verdicts.append(v)
    return "TRUE" if all(verdicts) else "FALSE"


def waypoint_cells(g):
    """**只供规划器，永不参与断言、不进结算**：图例标记格（四像素 1、0、0、X 的那些格）。

    路标的定义就是「站上去本身不改地图，改的是**有哪些边**」——这正是这条概念说的事：
    踩上标记格，面板上对应那颗菱形才亮，而只有亮着的菱形点下去才管用。
    玩家正站着的那一格读出来是色14，认不出来也不该认（他已经在上面了）。
    """
    out = set()
    for r in range(0, len(g) - CELL + 1, CELL):
        for c in range(0, len(g[0]) - CELL + 1, CELL):
            px = _cellpx(g, r, c)
            if px and marker_color(px) is not None:
                out.add((r, c))
    return out


def apply(prev, action, ctx=None):
    """走进标记格：那颗菱形 16 像素全涂成色X；走离标记格：原先亮着的那颗灭回色4、只留右下角。
    两件事同一步里可能一起发生（从一块标记格直接走进另一块）。"""
    if action not in DELTA:
        return None
    a = me(prev)
    if a is None:
        return None
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    if not enterable(prev, tr, tc):
        return None                       # 撞墙没挪窝，脚下那块标记格照旧亮着
    out = {}
    x, d = lit_diamond(prev)              # 走开的那一块：它正亮着，所以在帧上认得出
    if x is not None:
        corner = (max(r for r, _ in d), max(c for _, c in d))
        for p in d:
            out[p] = x if p == corner else 4
    px = _cellpx(prev, tr, tc)
    y = marker_color(px) if px else None
    if y is not None:
        e = panel_diamond(prev, y)
        if e is None:
            return out or None
        for p in e:
            out[p] = y
    return out or None
