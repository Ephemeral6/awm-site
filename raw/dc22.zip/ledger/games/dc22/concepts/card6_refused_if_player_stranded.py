"""点面板上那张色6 的卡时，玩家不跟那件色12 大十字件走：若他此刻正踩在件上（他四像素补成件色才认得出整件），而件绕环心转 90° 之后不再盖着他脚下那一格，整个点击被拒——地图区（行0-61、列0-39）一格不变。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 且点的是面板上那张色6 的卡（_lib.clicked_card）；换关返回 NA；"
         "me() 定位不到、或 `_lib.cross_piece_with_player` 认不出「他踩在件上」的，返回 NA（他没站在件上，这条不管）；"
         "**转完之后件仍盖着他脚下那四格的，也返回 NA**——那一档语料里一次都没出现过，说不出被拒还是照转。"
         "只断言「被拒的那一档里地图区一格不变」；件转到哪归 card6_rotates_piece，垫子翻不翻归 card6_flips_pad_phase，"
         "行62-63 的 HUD 不在断言范围内（那两行每一步都在涨）。")
NOTE = ("v1: 终局卡第 1618 步（fa5c215846869cb6）退出码 5。玩家站在竖着的件上（行38-39 列10-11，"
        "件因此只剩 96 像素）点色6 卡，card6_rotates_piece 押了一整套 90° 旋转、错 48 格，"
        "card6_flips_pad_phase 押四块垫子对调、也错——**整帧只有行63 那条 HUD 涨了 2 像素，地图区一格没动**。"
        "件转完之后占行32-35 列0-19 加行30-37 列8-11，(38,10) 的原像是 (33,14)、那不是件的像素，"
        "所以他脚下会露出背景（件横过来那一版里，行38-39 列8-11 是色4 的墙）。\n"
        "这不是新规矩，是本局已经走过闸的那一条在另一张卡上的同一面："
        "card11_refused_if_player_stranded 断言「转完一档后玩家脚下仍是横条 ⇒ 横条照转、玩家不动；"
        "脚下会露出背景 ⇒ 整个点击被拒、地图区一格不变」。这里的件和那里的横条是同一类东西：踩得上去的会动的地板。\n"
        "为什么「仍盖着」那一档写 NA 不写 TRUE：全语料 2731 条里，起帧上玩家踩在件上的有 136 条，"
        "而其中动作是点色6 卡的只有这一条（zrot4.out）。那一档一个样本都没有，照 card11 的先例猜「照转、玩家不动」"
        "是把别处的结论搬过来当观察，所以留空。真走到那一步会是退出码 5，那时再补。\n"
        "认件的读法在词汇表 `_lib.cross_piece` / `cross_piece_with_player`（原是 card6_rotates_piece 的私有函数，"
        "为三条概念共用挪过去的）：settle 把概念执行成 `concept_<名>` 且不放进 sys.modules，概念之间 import 不到彼此。")
EVIDENCE = ["fa5c215846869cb6"]

from _lib import CELL, clicked_card, cross_piece_with_player, me

MAP_COLS = 40
MAP_ROWS = 62


def _player_cells(a):
    return [(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)]


def _stranded(g):
    """玩家踩在件上、且件转完之后不再盖着他脚下那四格 → True；
    踩在件上但转完仍盖着 → False；他根本没踩在件上（或认不出） → None。"""
    a = me(g)
    if a is None:
        return None
    got = cross_piece_with_player(g)
    if got is None:
        return None
    cells, (k, h) = got
    img = {(k + (c - h), h - (r - k)) for (r, c) in cells}    # 绕环心转 90° 之后件占哪些格
    return not all(p in img for p in _player_cells(a))


def _map_same(prev, nxt):
    return all(prev[r][:MAP_COLS] == nxt[r][:MAP_COLS] for r in range(MAP_ROWS))


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, 6):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    s = _stranded(prev)
    if s is not True:
        return "NA"                     # 没踩在件上、或转完仍盖着：这条不管
    return "TRUE" if _map_same(prev, nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, 6):
        return None
    if _stranded(prev) is not True:
        return None
    return {}                           # 被拒：地图区一格不变，所以一格都不用改（同 card11 那条）
