"""点面板上那张色8 的卡：地图上那只 30 像素、外接框 8×8 的色8 夹子，只要它口里（外接框最右那一列的中间四行）有色12 的像素，上下两爪就各向内收 1 像素、变成 28 像素的「合口」样子（口宽 4 像素收到 2 像素）；口里那四个像素全是色4 或色0 时整只夹子一格不动。两种情形下地图别处都一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色8、落在面板区（列>=42）、所在同色四连通块至少 8 像素"
         "（_lib.clicked_card）；换关（ctx 的 level_prev != level_next）返回 NA。"
         "再要求在地图区（行0-61、列0-39）的色8 像素里，四连通块恰好有**一块**与下面写死的「张口」模板"
         "逐像素相同（30 像素、外接框正好 8×8），而且没有第二块与「张口」或「合口」模板相同——否则 NA。"
         "夹子已经是「合口」那 28 像素的样子时也返回 NA：语料里合口之后再点这张卡的事一次都没发生过，"
         "那不是「我断言它不变」，是「没见过」。"
         "口里那四个像素既不含色12、又不全是色0/色4 时（包括离场规划里那些读不出来的哨兵像素）同样返回 NA："
         "语料里这种口一次都没出现过，不该拿「非空即合口」去外推。"
         "别的关也有色8 的卡（点下去改的是别处），那些关里一块合模板的色8 块都找不到，自动落回 NA。"
         "断言范围是地图区行0-61、列0-39；HUD 两行与面板不管——点这张卡有时会顺带改一个 HUD 像素。")
NOTE = ("v2。把「口里非空就合口」收成「口里含色12 才合口」，两头之外（既没有色12、又不全是色0/色4）改判 NA。\n"
        "为什么收：v1 的「非空」在离场规划里是致命的——规划器把物件让开、谁也说不出底下是什么的像素标成负数哨兵，"
        "那种像素当然「既不是色4 也不是色0」，于是 v1 在夹子根本没咬到东西的位置上照样宣布合口，"
        "规划器从此按一只合了口的空夹子往下推，整条支线全错。收窄之后这种帧上它闭嘴，"
        "规划器改用别的概念或者认输，而不是被喂一个编出来的状态。\n"
        "收窄不丢证据：全语料 17 帧有唯一一只张口夹子，口里的颜色集合只出现过三种——全色0（9 帧）、全色4（7 帧）、"
        "{色4, 色12}（1 帧）；真点了色8 卡的两帧一个是全色4（没动）、一个是 {色4, 色12}（合口）。"
        "两条 EVIDENCE 在新读法下判的和旧读法一样。\n"
        "两张模板（张口 30 像素、合口 28 像素，都写成相对外接框左上角的像素表）是从两次合口的帧差上"
        "逐像素抄下来的，不是从机制推出来的；抄完回头核对，两次合口改的像素完全一样（18 个）。\n"
        "被打掉的第一读法：「点色8 卡 = 夹子合口」，不带任何条件。它在同一关里当场有三条零变化的反例"
        "（15195398ee10ba3a：夹子张着口停在别处，点下去整幅帧一个像素都没动；9bca743eef6d0995、6de3bd5bf312d12f 同理）。"
        "把这五次「点了没反应」和两次「合口」摆在一起对表，唯一分得开的帧上差别是夹子口里有没有东西："
        "两次合口时口里那四个像素含色12（口外还顶着一大片色12），五次没反应时口里四个像素全是色4 或色0。\n"
        "**在语料上分不开的两种读法**：两次合口时夹子恰好都停在同一个位置（外接框左上角同一格），"
        "所以「口里非空才合」和「夹子停在那个位置才合」拿现有证据分不开。这里选了前者，因为它一个坐标都不含；"
        "如果以后夹子在别处口里含着东西却不合口，这条当场被打掉，那时该换成后者。\n"
        "**还没验过的那半**：合口时消失的那 10 个色8 像素一律押成色4。这只在那一个位置验过，"
        "那里夹子底下本来就是色4；夹子压在别的东西上时合口该露出什么，语料里没有。\n"
        "夹子本身会动——面板上另外几张卡每点一次把它整只挪 4 像素（外接框跟着走），那是别的概念的事，"
        "这一条只管张口/合口。语料里两次进这一关都是同一副样子：进来时 30 像素张着口，合一次口之后直到离关一直是 28 像素，"
        "从没再张开过。所以「合口之后再点一次会怎样」和「怎样才能重新张口」两件事都没有证据，SCOPE 里对合口状态闭嘴。")
EVIDENCE = ["88663be4d99ea88a", "15195398ee10ba3a"]

from _lib import clicked_card, MAP_ROWS
from geo import components

MAP_COLS = 40
CLAMP_COLOR = 8
CARD_COLOR = 8
BOX = 8                # 外接框边长

# 相对外接框左上角的像素表，(行, 列)
OPEN = frozenset(((0, 3), (0, 4), (0, 5), (0, 6), (0, 7),
                  (1, 3), (1, 7),
                  (2, 1), (2, 2), (2, 3), (2, 4),
                  (3, 0), (3, 1), (3, 2), (3, 3),
                  (4, 0), (4, 1), (4, 2), (4, 3),
                  (5, 1), (5, 2), (5, 3), (5, 4),
                  (6, 3), (6, 7),
                  (7, 3), (7, 4), (7, 5), (7, 6), (7, 7)))
CLOSED = frozenset(((1, 3), (1, 4), (1, 5), (1, 6), (1, 7),
                    (2, 1), (2, 2), (2, 3), (2, 4), (2, 7),
                    (3, 0), (3, 1), (3, 2), (3, 3),
                    (4, 0), (4, 1), (4, 2), (4, 3),
                    (5, 1), (5, 2), (5, 3), (5, 4), (5, 7),
                    (6, 3), (6, 4), (6, 5), (6, 6), (6, 7)))
MOUTH_ROWS = (2, 3, 4, 5)   # 口：外接框最右一列（相对列7）的中间四行
MOUTH_COL = 7
NOTHING = (0, 4)            # 口里算「空」的两种颜色
GRIP = 12                   # 口里算「咬住了」的那一种颜色


def _clamps(g):
    """地图区里合模板的色8 四连通块：{"open": [(r0,c0)...], "closed": [...]}。"""
    px = [(r, c) for r in range(min(MAP_ROWS, len(g)))
          for c in range(min(MAP_COLS, len(g[0]))) if g[r][c] == CLAMP_COLOR]
    out = {"open": [], "closed": []}
    for comp in components(px):
        if len(comp) not in (len(OPEN), len(CLOSED)):
            continue
        r0 = min(p[0] for p in comp)
        c0 = min(p[1] for p in comp)
        if max(p[0] for p in comp) - r0 != BOX - 1 or max(p[1] for p in comp) - c0 != BOX - 1:
            continue
        rel = frozenset((p[0] - r0, p[1] - c0) for p in comp)
        if rel == OPEN:
            out["open"].append((r0, c0))
        elif rel == CLOSED:
            out["closed"].append((r0, c0))
    return out


def _pred(g):
    """夹子那 8×8 外接框里 64 个像素点完之后的颜色；读不出唯一一只张着口的夹子返回 None。"""
    cl = _clamps(g)
    if len(cl["open"]) != 1 or cl["closed"]:
        return None
    r0, c0 = cl["open"][0]
    box = {(r0 + i, c0 + j): g[r0 + i][c0 + j] for i in range(BOX) for j in range(BOX)}
    mouth = [g[r0 + i][c0 + MOUTH_COL] for i in MOUTH_ROWS]
    if all(v in NOTHING for v in mouth):
        return box                       # 口里空着：一格不动
    if GRIP not in mouth:
        return None                      # 既没咬住色12、又不是空口：没见过这种口，闭嘴
    for i, j in OPEN:
        box[(r0 + i, c0 + j)] = 4
    for i, j in CLOSED:
        box[(r0 + i, c0 + j)] = CLAMP_COLOR
    return box


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    pred = _pred(prev)
    if pred is None:
        return "NA"
    for r in range(min(MAP_ROWS, len(prev))):
        row_p, row_n = prev[r], nxt[r]
        for c in range(MAP_COLS):
            if row_n[c] != pred.get((r, c), row_p[c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return None
    return _pred(prev)
