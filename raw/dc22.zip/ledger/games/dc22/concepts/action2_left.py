"""ACTION2 让 me 下移 2 像素行（+CELL），或整帧不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION2；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA；帧差只有 HUD（row 63）时也算整帧不动"
NOTE = "v11: 判据一个字没动，改的是 apply——目标格是色11 块（_lib.is_goal）时不再开口：走进它就换关，换关那一帧整屏重画，逐格预测必错。v10: apply 把腾出的原格也押上——颜色按 _lib.floor_under 由四邻猜（435 次走开猜中 420 次）；不押原格时链式预测的模拟帧里会留下两个色14 块，me() 认错人。v9: apply 先查目标格进不进得去（_lib.enterable），进不去押原地不动。v8: 换关那一帧整屏重画，玩家被放到新关起点，不是位移——返回 NA（9405743c6a4429b9 踩目标过关）。apply 不再把腾出的格子押成色2：玩家站在桥/臂上时腾出的格子回到那件东西的颜色（9/8/13/7/6/15），prev 帧看不见脚下是什么，所以只押新位置。v7: me() 返回像素坐标；row 63 是 HUD 不算玩家移动"
EVIDENCE = ["9405743c6a4429b9", "a9058ad9dcc0fcde", "c30a65d27eebcb0e"]

from _lib import me, CELL, enterable, move_cells, is_goal

def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION2"):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    # 找出 me 范围外的帧差
    r, c = a
    diff_cells = []
    for row in range(len(prev)):
        for col in range(len(prev[0])):
            if prev[row][col] != nxt[row][col]:
                # 不在 me 旧位置，也不在 me 新位置
                if not (r <= row < r + CELL and c <= col < c + CELL):
                    new_r = r + CELL
                    if not (new_r <= row < new_r + CELL and c <= col < c + CELL):
                        diff_cells.append((row, col))
    # HUD 在 row 63，只有 HUD 变化时算整帧不动
    non_hud_diff = [cell for cell in diff_cells if cell[0] != 63]
    if len(non_hud_diff) == 0 and a == b:
        return "TRUE"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (CELL, 0) else "FALSE"

def apply(prev, action, ctx=None):
    if not action.startswith("ACTION2"):
        return None
    pos = me(prev)
    if pos is None:
        return None
    r, c = pos
    tr, tc = r + CELL, c
    # 走进色11 块就换关，整帧重画，这条概念说不出那一帧——闭嘴
    if is_goal(prev, tr, tc):
        return None
    # 目标格进不去就押「原地不动」；进得去就押新位置变色14
    if not enterable(prev, tr, tc):
        return move_cells(prev, r, c, r, c)
    return move_cells(prev, r, c, tr, tc)
