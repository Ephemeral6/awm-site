"""方向键走一步：目的格**半步踏上**十字件中心那圈色8 环的外沿时（目的格四像素有的落在环自身外接框内、
有的已经出了框），框内那几个环像素在 nxt 里保持原色8 不变，不被走进来的玩家压成色14；框外那几格照常变色14。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1-4 四个方向键；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA；"
         "目的格越界或进不去（_lib.enterable 为 False）返回 NA——那一下压根没挪动；"
         "prev 里 _lib.cross_piece 认不出十字件、或件上没有色8 环时返回 NA；"
         "目的格四像素和环一个都不重叠时返回 NA——那是 action1_right 等基础走格概念管的普通格；"
         "目的格四像素**全部**落在环外接框（环像素的 min/max 行列围出的矩形）之内时也返回 NA"
         "——那是环内部的挪动，压成色14 是正常覆盖，不属于这条主张。"
         "只有目的格跨过外接框边界的那一步才判定。")
NOTE = ("v1（影子册）：判据是「目的格和环有任意重叠就保色8」，全语料 15 条反例——同一局面里另有一处更小的"
        "十字件（环外接框 4×4、边框 1 像素宽），整格挪进它的环范围内部时环像素照常被压成色14。\n"
        "v2（影子册）：把判据换成「目的格是不是跨过环自身外接框的边界」。19 条「目的格与环有重叠」的转移上"
        "4 条跨界全部保色8、15 条不跨界全部被压成14，零反例零遗漏。\n"
        "v3（本版，入册）：判据实现挪进 `_lib.ring_straddle_keep`，因为同一句话得同时修**写**侧——"
        "五条方向键概念的 apply 共用 `_lib.move_cells`，它一直无条件把目的格整格涂色14。\n"
        "这条为什么是 `assert_` 抓不到的：方向键概念的 assert_ 只量 `me(nxt)` 有没有挪到该去的格，"
        "而 `me()` 四版前就为「环画在玩家上面」补过读侧，位移算得对、照判 TRUE；"
        "假话只在把 apply() 的输出和真实 nxt 逐像素对过一遍时才现形，而 apply() 正是规划器唯一能拿到的"
        "「这一步之后世界长什么样」。读侧补了、写侧没补，四版里没人发现——**补丁要成对**。\n"
        "外推交代：4 条跨界正例全部来自同一处大环（6×6 外接框）、同一个 ACTION4；小环跨界、以及"
        "ACTION1/2/3 跨界，语料里一次都没出现过。判据里看不出方向或环大小的痕迹，所以 SCOPE 没往那边缩，"
        "但这是外推不是实测——真撞上了判 FALSE，就该在这里分叉。")
EVIDENCE = ["66589c0fb64800d5", "44360b68485f8fd6", "2c8918d101825def", "8b62083ded4e549c",
            "029a5a9e25aca7e4", "bcf23688f1697c91", "bcd85be9bac88f50", "b419172c01902d98",
            "3aa553f6198cde0c", "a70fb55227f902cd", "bc3e8099a4907ac9", "921d6250f2531d56",
            "0be6a93af81fcc02", "3cba9aa2d3db84d6", "942f7965d301d101", "635765185b50e819",
            "701015dc5ac10cb0", "e923f0bf19bc5fa0", "a46c55a89e47b331"]

from _lib import me, CELL, DELTA, enterable, ring_straddle_keep


def _case(prev, action):
    """(该保原色的像素表, 目的格四像素) 或 (None, None)——不归这条概念管就是后者。"""
    a = me(prev)
    if a is None:
        return None, None
    dr, dc = DELTA[action]
    tr, tc = a[0] + dr, a[1] + dc
    if not (0 <= tr and tr + CELL <= len(prev) and 0 <= tc and tc + CELL <= len(prev[0])):
        return None, None
    if not enterable(prev, tr, tc):
        return None, None
    keep = ring_straddle_keep(prev, tr, tc)
    if not keep:
        return None, None
    return keep, {(tr + i, tc + j) for i in range(CELL) for j in range(CELL)}


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    keep, target = _case(prev, action)
    if keep is None:
        return "NA"
    for (r, c), v in keep.items():
        if nxt[r][c] != v:
            return "FALSE"
    for (r, c) in target - set(keep):
        if nxt[r][c] != 14:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if action not in DELTA:
        return None
    keep, target = _case(prev, action)
    if keep is None:
        return None
    out = {(r, c): 14 for (r, c) in target}
    out.update(keep)
    return out
