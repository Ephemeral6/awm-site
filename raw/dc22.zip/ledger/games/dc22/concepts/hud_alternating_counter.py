"""HUD栏（行63）按动作序号奇偶隔次增加1格色3；本关内第1/3/5/7...次动作增加HUD，第2/4/6/8...次动作HUD不变；达到64时触发自动RESET；RESET后动作序号归零。"""
LEVEL = "L4"
SCOPE = "只看非RESET动作；RESET动作返回NA；换关（ctx.level_prev != level_next）返回NA；ACTION6 点卡而地图区（行0-62）一格没变的返回NA"
NOTE = "v5: 玩家站在滑块上点它的卡，滑块没动，HUD 一次涨了 7 格（8bcf2620f22a1508）——像是「无效点卡」的惩罚，规则未摸清，先缩 scope：点卡而地图区无变化的转移不管。v4: 换关那一帧 HUD 整行重画归零（0ece4a389344cee2），不是计数——返回 NA。HUD是动作序号的隔次计数器，与玩家是否成功移动无关。改版原因：初版假设「每次移动都增加」79反例，二版假设「隔次移动增加」32反例（步23玩家未动但HUD增加），实测发现HUD只看动作序号奇偶。"
EVIDENCE = ["8bcf2620f22a1508", "0ece4a389344cee2", "89db1714b36607f3", "2e927afafb219ae9", "c0a3027b1a6e14df", "f81f81a1f3c1165e", "07a51c4a22bbd04a", "b35b5fcdd94021c6", "c30a65d27eebcb0e", "ddbb45a2986a072a", "73bf79284e3af9ea", "c84b5ef8d8d44884", "5e284ef6385f7c5d", "b32f5f1fe2d001c8", "dee2d1f6a868d8c7", "6a6c1e4de7b1c17a", "33e5954d47e14cb8", "ab8d4aef4f2ffec6", "24a30b99f98c6fa9", "f1c64edfed72c1ce", "5c29784f4821e7aa", "af98ff7c88d3b5e6", "39adac3c9d7b9d97", "8cd0c46ec8ca4f42", "5af9aca65b76ffb3", "e18a11f4f6ecf088", "8f58da0d850b6c8f", "9c42d6a6a86a4ba6", "9b7f08c51bbf29e5", "8b2fa08a4b34d3f5", "d4dfa22b3dd2b31d", "86c4f5c7aa60ed3c", "55ac19e825fdb33c", "a30b3f34f0ac5adb", "ab72d6f1e6d3cb64", "1ce4ffa2a0189a25", "2059cb5137a0ba27", "339e5c209432be96", "3b5ba10711cf9e71", "3b84b8dcc7c2486c", "460e703350d38bda", "57bfc5b67b009e13", "6da7c0b68f8146c1", "8f8d7dc7143cc969", "99937819fb956ab6", "a6b9da394d356db2", "cde7cfdb25a083ee", "ce1cfb34bd152dc6", "dd047a64f7205e58", "e9a21fd2a0377a13", "e9e53e916e4789f4", "eada5fdf5d4745d7", "f18ebb3a43aee662", "f8e05c57306e2ea8", "f9288a4f0680bc75"]

from _lib import me

def assert_(prev, action, nxt, ctx=None):
    if action == "RESET":
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.startswith("ACTION6") and all(prev[i] == nxt[i] for i in range(63)):
        return "NA"

    hud_prev = sum(1 for c in prev[63] if c == 3)
    hud_next = sum(1 for c in nxt[63] if c == 3)
    delta = hud_next - hud_prev

    # HUD value tells us how many actions have incremented it
    # If HUD=N, then N odd-numbered actions have happened
    # Next action is the (2*N + 1)th or (2*N + 2)th action
    # Based on delta, we can infer which one this is:
    # - If delta=1: this is action number (2*hud_prev + 1), which is odd ✓
    # - If delta=0: this is action number (2*hud_prev + 2), which is even ✓

    # Actually simpler: HUD increments iff this is an odd-numbered action
    # Action number = 2*hud_prev + 1 (if delta=1) or 2*hud_prev + 2 (if delta=0)
    # Check: (2*hud_prev + 1) % 2 == 1 (odd) and (2*hud_prev + 2) % 2 == 0 (even)

    if delta == 1:
        # This should be odd action: (2*hud_prev + 1) must be odd
        action_num = 2 * hud_prev + 1
        return "TRUE" if action_num % 2 == 1 else "FALSE"
    elif delta == 0:
        # This should be even action: (2*hud_prev + 2) must be even
        action_num = 2 * hud_prev + 2
        return "TRUE" if action_num % 2 == 0 else "FALSE"
    else:
        # Delta not 0 or 1
        return "FALSE"

def apply(prev, action, ctx=None):
    if action == "RESET":
        return None

    # Can't predict whether this action is odd or even without tracking state across transitions
    return None
