"""dc22 的对象层（R9 口径）：一帧 → {玩家格, 露着的垫子表}，外加一个帧上看不见的隐藏量 hp。

读法的由来全部是实测（探针在 runs/_maint/dc22-r9/）：

* `me`      玩家所在格（2×2 像素为一格，格坐标取左上像素）。全语料每一帧都读得出，没有 None。
* `pads`    地面上**露着**的垫子：位置 + 色对编号（0..3）。玩家站上去会把脚下那块盖住，
            于是它从帧上消失——这就是隐藏量的来源。
* `hp`      玩家脚下那块垫子的色对编号；9 = 没站在垫子上。帧上看不见（被玩家盖住），
            只能由 step 从历史推进；逐条核对时由 seed 从「后一帧里那格露出来的色」反解。

`consts` 给的每关常数里，`floor` / `goal` 两项是从该关全部观测帧算出来的（不是手写），
其余是实测钉死的小表，条数与由来见 formal/RULES.md 的坦白清单。
"""

import _lib as L

# ---- 色对 → 编号。_lib.pads 返回 {(r,c): (lt,rt,lb,rb)}，对角两色构成一个色对 ----
PAIRID = {frozenset({6, 7}): 0, frozenset({13, 8}): 1, frozenset({12, 11}): 2, frozenset({9, 10}): 3}

# ---- 实测钉死的每关小表（来源：全语料逐帧统计，见 RULES.md 坦白清单）----
# 每关玩家的落脚点：RESET 后 / 从上一关进来时站的那一格
SPAWN = {0: (40, 10), 1: (30, 6), 2: (18, 30), 3: (18, 4), 4: (34, 32), 5: (52, 28), 6: (6, 46)}
# 第 5 关的出口落在地图区之外（列 ≥ 面板起列），is_goal 扫不到，补一条
GOAL_EXTRA = {5: (6, 46)}
# 每关垫子的「常驻色」：换关 / RESET 重建垫子表时用
PADHOME = {2: {(16, 6): 0, (46, 12): 0},
           3: {(24, 4): 0, (32, 18): 0},
           4: {(6, 24): 0, (34, 10): 0},
           5: {(4, 4): 2, (48, 18): 0, (52, 32): 0, (58, 34): 3}}
# 面板上两张卡的像素矩形 [r0, r1, c0, c1]（-1 = 这一关没有这张卡）
SWAPCARD = {2: [34, 36, 48, 52], 3: [17, 19, 49, 53], 4: [46, 48, 49, 52], 5: [23, 25, 48, 52]}
CYCCARD = {5: [46, 49, 49, 51]}
CYCPAD = {5: (48, 18)}
# 实测会在关内开关的落点（这 6 格的通不通不在本抽象里，落到它们头上的观测计入 skipObs 公示）
GATE = {0: [(22, 20), (28, 20), (36, 8), (36, 10)], 3: [(20, 10)], 4: [(34, 28)]}
NOBOX = [-1, -1, -1, -1]
NOPOS = (-1, -1)

MAP_ROWS, MAP_COLS, CELL = 62, 40, 2

HIDDEN = {"hp": 9}
NAMES = {"pads": "Pad"}
TYPES = {
    "me": "Pos",
    "*.pos": "Pos",
    "consts.floor": "List Pos",
    "consts.goal": "List Pos",
    "consts.padPos": "List Pos",
    "consts.gates": "List Pos",
    "consts.spawn": "Pos",
    "consts.nextSpawn": "Pos",
    "consts.cycPad": "Pos",
    "consts.swapCard": "Box",
    "consts.cycCard": "Box",
}


def parse(g):
    """一帧 → 对象。只许用帧，不许用关号（关号由装置从 meta 注入 State.level）。"""
    m = L.me(g)
    pads = [{"pos": [r, c], "col": PAIRID[frozenset(px)]}
            for (r, c), px in sorted(L.pads(g).items())]
    return {"me": list(m) if m else None, "pads": pads}


def consts(frames_by_level):
    """每关常数。frames = {关号: [该关全部观测帧]}。"""
    out = {}
    for lv, gs in frames_by_level.items():
        if lv is None:
            continue
        floor, goal, padpos = set(), set(), set()
        for g in gs:
            m = L.me(g)
            if m:
                floor.add(m)                       # 玩家在这一关站到过的格 = 可走地面
            padpos |= set(L.pads(g))
        for g in gs:
            for r in range(0, MAP_ROWS, CELL):
                for c in range(0, MAP_COLS, CELL):
                    if L.is_goal(g, r, c):
                        goal.add((r, c))
        if lv in GOAL_EXTRA:
            goal.add(GOAL_EXTRA[lv])
        floor -= goal                              # 出口格单独算，不混进地面
        pp = sorted(padpos)
        out[lv] = {
            "floor": [list(p) for p in sorted(floor)],
            "goal": [list(p) for p in sorted(goal)],
            "spawn": list(SPAWN[lv]),
            "nextSpawn": list(SPAWN.get(lv + 1, SPAWN[0])),
            "padPos": [list(p) for p in pp],
            "padHome": [PADHOME.get(lv, {}).get(p, 0) for p in pp],
            "swapCard": SWAPCARD.get(lv, NOBOX),
            "cycCard": CYCCARD.get(lv, NOBOX),
            "cycPad": list(CYCPAD.get(lv, NOPOS)),
            "keepPads": lv == 5,
            "gates": [list(p) for p in GATE.get(lv, [])],
        }
    return out
