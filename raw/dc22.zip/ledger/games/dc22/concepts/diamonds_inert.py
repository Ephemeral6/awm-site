"""点面板上那四颗孤零零的菱形心（周围一圈都是色4、自己只占一个像素的色15/12/14/10），地图区一格不变。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且被点像素落在面板区（列>=42）、颜色是 15/12/14/10 之一、且所在同色四连通块只有它一个像素；换关返回 NA。只断言地图区（列<40、行<62）不变，行63 的计数器和面板本身怎么变不管。"
NOTE = "v1: 第 6 关面板上有四颗菱形（心分别是色15 在上、色12 在左、色14 在右、色10 在下），地图里那间围死的图例屋（行56-61 列32-37）画的正是同一个图案：一块 9/10 抖动垫，四周四个 [1,0/0,X] 记号，X 依次是 15、12、14、10。第 5 关面板上有一排四个 4×4 的色10/色9 按钮，点下去会把地图里一件色8 的物件整体平移四像素（b8494b6af83f921a 等六条），所以本关这四颗看起来就是同一类「方向钮」。可是八次点击（含 28c199390ddb6903 那次点色15 的心，以及本批点四颗心各一次、四颗身各一次）地图一格没动——垫子是 6/7 时不动，换成 13/8 也不动，玩家不在垫子上。这条概念就是把「它们现在是死的」写成一句会被打破的话：等哪天它动了，反例会告诉我先决条件是什么。"
EVIDENCE = ["28c199390ddb6903", "73a91c3ad251b3e6", "97268a70718dee32", "7f9b31c1322591cc",
            "1283a393ab8218e2", "ca1ba4785d27da3e", "57e3c2e8abf12820", "21f830217fdabad4"]

from _lib import PANEL_COL0, glyph_size

DIAMOND_COLORS = (15, 12, 14, 10)
MAP_COLS = 40
MAP_ROWS = 62


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6:"):
        return "NA"
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return "NA"
    if not (0 <= r < len(prev) and PANEL_COL0 <= c < len(prev[0])):
        return "NA"
    if prev[r][c] not in DIAMOND_COLORS or glyph_size(prev, r, c) != 1:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    for y in range(MAP_ROWS):
        if prev[y][:MAP_COLS] != nxt[y][:MAP_COLS]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6:"):
        return None
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    if not (0 <= r < len(prev) and PANEL_COL0 <= c < len(prev[0])):
        return None
    if prev[r][c] not in DIAMOND_COLORS or glyph_size(prev, r, c) != 1:
        return None
    return {(y, x): prev[y][x] for y in range(MAP_ROWS) for x in range(MAP_COLS)}
