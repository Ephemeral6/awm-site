"""点面板上那张色6 的卡：玩家和一块同花色的抖动垫互换位置——玩家落到那块垫子那一格，原来站的那一格露出一块同一对花色的垫子（相位不保）；玩家没换位时，所有垫子的位置一格不变。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6:<列>,<行> 且被点像素在 prev 里是色6、且落在面板区（列>=42）；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA。只断言玩家与垫子的位置和花色对，同一步里别的东西怎么变、相位怎么翻都不管。"
NOTE = "v5: 再加一个**只供规划器**的读口 `waypoint_cells`（主张、SCOPE、assert_、apply 一字未动）：" \
    "「露着的垫子」这一组格是规划器的路标——换位只在玩家站在垫子上时发生，而最后一关的真解是" \
    "「走到垫子上 → 点两下四色图标把它推成目标那一对花色 → 点色6 卡换过去」，" \
    "外层搜索按「走一段 + 点一下」分层，这条路线有三层点击、第一层要先走几十步，任何墙钟都搜不到；" \
    "把「走到垫子上」变成和「走进卡图标」一样的路线终点，它就成了三批各自搜得动的三段。\n" \
    "v4: 加一个**只供规划器**的 `apply_with_ground`（不进结算、不算存活率，判据一字未动）。" \
    "apply 只在「帧上恰好露着一块垫子」时敢开口，因为玩家自己盖着脚下那一块，单帧读不出它是什么花色；" \
    "最后一关四块垫子（两块 6/7 是一对，另两块各自成单）就卡在这里：玩家站到 6/7 垫子上点色6 卡会换位到另一块 6/7 垫子" \
    "（66dd5ee813d3552a 与 68493cf78d4e17f9 两条实测，两次腾出的那一格都原样露出玩家脚下那块的四像素），" \
    "而 apply 那时看得见三块垫子，闭嘴，规划器于是整条边都不存在——" \
    "最后一关从平台到图例屋那半张地图因此在规划器眼里永远够不到。规划器手里有玩家踩上去之前那一帧，" \
    "把脚下四像素递进来，同一条规矩（同花色对的那一块是目的地）就算得出来：目的地变成玩家，腾出的那一格露出脚下那块（相位不变）。" \
    "脚下读不出、或同花色的垫子不止一块／一块都没有时，退回 apply 原来的答案。\n" \
    "v3: 腾出的那一格只保证花色对相同，不保证相位。第 861 步玩家踩着 (48,18) 那块 (9,10,10,9) 垫子点色6 卡，被换到图例屋 (58,34)（它在 prev 里是 (10,9,9,10)），腾出的 (48,18) 露出来仍是 (9,10,10,9)——v2 要求「和目的垫子在 prev 里一模一样」，判 FALSE（53a28a883e17faf6）。同一步里露着的另两块垫子 (4,4)、(52,32) 都翻了相位，只有玩家压着的那块没翻：看来翻相位只落在露着的垫子上，而被玩家压住的那块这一步不参与。v1 的四次换位之所以「一模一样」全中，是因为那几关两块垫子本来就同相位，区分不出这两种读法。v2: 垫子不止 6/7 一种花色——第 6 关点面板那块四色图标会把一块垫子在 (6,7)→(13,8)→(12,11)→(9,10) 里循环（icon_recolors_pad v2）。_pads 因此改成认全部四对。这一改顺带堵住一个必错的预测：v1 的 apply 只要「帧上恰好露着一块 6/7 垫子」就押换位，它默认「垫子总是成对、少的那块被玩家踩着」；第 6 关四块垫子四种花色各一块，这个默认已经不成立，而玩家站在色12 件的色8 环上、根本不在垫子上。认全四对之后 len(p)=4，apply 自己就闭嘴了。判据本身没动，四条换位证据照旧判 TRUE。v1: 第2、3、4、5 关各见一次换位（f8707f5215cd3f3d、3cdbc69893fa5983、2047fd895b5b37ec、66dd5ee813d3552a），第4 关还见过一次玩家不在垫子上、谁也不动只换花纹相位（6f63b2040471f6df）。地图上的垫子永远是 6 与 7 相间的花格，面板上那张卡的色6 是实心的——判据因此要求「既有6 又有7」，否则会把卡面本身当垫子。换位时腾出的那一格的四像素，实测等于目的垫子在 prev 里的四像素（四次全中），所以 apply 敢连原格一起押。"
EVIDENCE = ["f8707f5215cd3f3d", "3cdbc69893fa5983", "2047fd895b5b37ec", "66dd5ee813d3552a", "6f63b2040471f6df",
            "53a28a883e17faf6"]

from _lib import me, CELL

PANEL_COL0 = 42    # 列42 起是右侧卡面板，地图只算它左边
PAIRS = ((6, 7), (13, 8), (12, 11), (9, 10))


def _pads(g):
    """地图区里所有抖动垫（四像素是四对花色之一、两两相间）：位置 -> 四像素。"""
    out = {}
    for r in range(0, len(g) - CELL + 1, CELL):
        for c in range(0, PANEL_COL0 - CELL + 1, CELL):
            px = tuple(g[r + i][c + j] for i in range(CELL) for j in range(CELL))
            if any(set(px) == set(p) for p in PAIRS):
                out[(r, c)] = px
    return out


def _clicked_six(g, action):
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == 6


def assert_(prev, action, nxt, ctx=None):
    if not _clicked_six(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    p, q = _pads(prev), _pads(nxt)
    if b == a:
        return "TRUE" if set(p) == set(q) else "FALSE"
    if b not in p or a not in q or set(q[a]) != set(p[b]):
        return "FALSE"
    return "TRUE" if set(p) - {b} == set(q) - {a} else "FALSE"


def apply(prev, action, ctx=None):
    if not _clicked_six(prev, action):
        return None
    a = me(prev)
    if a is None:
        return None
    p = _pads(prev)
    if len(p) != 1:        # 露着两块（玩家没站在垫子上）或一块都没有：不敢生成
        return None
    (tr, tc), px = next(iter(p.items()))
    out = {(tr + i, tc + j): 14 for i in range(CELL) for j in range(CELL)}
    for i in range(CELL):
        for j in range(CELL):
            out[(a[0] + i, a[1] + j)] = px[i * CELL + j]
    return out


def _under(g, ground):
    """玩家脚下那一格的四像素（规划器递进来的底色表里查得到才算）；查不到返回 None。"""
    a = me(g)
    if a is None or not ground:
        return None
    px = tuple(ground.get((a[0] + i, a[1] + j)) for i in range(CELL) for j in range(CELL))
    return None if any(v is None for v in px) else px


def apply_with_ground(prev, action, ctx=None, ground=None):
    """只供规划器（不进结算）：告诉我玩家脚下那一格是什么色，我就答得出这一下换位去哪。

    规矩和 assert_ 是同一条——和**同花色对**的那一块垫子互换：目的地那一格变成玩家色14，
    玩家腾出的那一格露出他脚下那块（相位不变，见 v3）。脚下读不出、或同花色的垫子不是恰好一块时，
    退回 apply 原来的答案（帧上只露着一块时那条照旧成立）。
    """
    if not _clicked_six(prev, action):
        return None
    a = me(prev)
    px = _under(prev, ground)
    if a is None or px is None:
        return apply(prev, action, ctx)
    s = set(px)
    if not any(s == set(p) for p in PAIRS):
        return apply(prev, action, ctx)          # 脚下不是垫子：这一下不换位，本条无话可说
    hit = [k for k, v in _pads(prev).items() if set(v) == s]
    if len(hit) != 1:
        return apply(prev, action, ctx)
    tr, tc = hit[0]
    out = {(tr + i, tc + j): 14 for i in range(CELL) for j in range(CELL)}
    for i in range(CELL):
        for j in range(CELL):
            out[(a[0] + i, a[1] + j)] = px[i * CELL + j]
    return out


def waypoint_cells(g):
    """**只供规划器**（不进结算、不算存活率）：站上去之后「点色6 卡」这条边才可能把玩家送到别处的格，
    也就是地图上露着的每一块抖动垫。

    这不是新主张，是把首行那句话的**前提**说给规划器听：换位只发生在玩家站在垫子上的时候
    （`assert_` 里 b != a 那一支要求 b 在 prev 的垫子表里）。规划器的搜索是按「走一段 + 点一下」分层的，
    而一条真解可能要先走几十步到某块垫子上、再点两下图标改花色、最后点色6 卡换位过去——
    这种路线在任何墙钟下都搜不出来，除非「走到垫子上」本身先成为一个可以走过去的路标。
    和「走进卡图标」同理：到了那儿就停下，下一批从真帧重新规划。
    """
    return set(_pads(g))
