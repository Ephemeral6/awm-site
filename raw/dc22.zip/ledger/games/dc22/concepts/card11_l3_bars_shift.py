"""点面板上那张色11的卡：第3关地图上两条横带（行28-29与行38-39）各有一条6像素宽的横条同时右移2像素；行28-29的横条走6档（列8/10/12/14/16/18），行38-39的横条走6档（列4/6/8/10/12/14）；走到各自轨道最右一档（行28-29在列18、行38-39在列14）时横条变色12，再点一次跳回最左一档并变回色1。玩家站在轨道上时不跟横条走：转完一档后脚下那一格仍整格压在横条上，横条照转、玩家原地不动（只断言玩家以外的像素）；转完后脚下会露出背景，整个点击被拒——地图区一格不变。"""
LEVEL = "L3"
SCOPE = "只看ACTION6且被点像素在prev里是色11、落在面板区（列>=42）、且所在同色块至少8像素（_lib.clicked_card；拾到道具后面板上那块4×4四色图标的色11象限只有4像素，不算这张卡）；换关返回NA；只读行28-29（列8-19）与行38-39（列4-15）这两条横带，逐档与可见像素比对（档内该是色1或色12、档外该是色4，`_lib.unreadable` 的像素跳过不比），恰好一个档位相容才开口，零个或多个相容都返回NA（别的关也有色11的卡，那边的装置不是这个）。玩家站在轨道上（左上角行=28或38、列在轨道区间内）时，先判「转完之后脚下还有没有横条」：没有就断言地图区（行0-61、列0-39）一格不变，有就照常断言两条带的像素（玩家自己那四个像素除外）。"
NOTE = "档位起点（最左一档在哪一列）是隐藏状态，帧上读不出来——两条横带的起点不同（行28-29从列8起、行38-39从列4起），但没有任何帧上可见的标记能区分它们。试过的读法：(1)从横条颜色推——色12只在最右一档出现，但玩家可能盖住横条，且横条可能全是色1；(2)从两条带的相对相位推——它们独立移动，没有固定相位关系；(3)从地图别处的标记推——行28-29与行38-39周围没有找到任何与档位相关的标记。结论：找不到帧上的读法。因此SCOPE缩到「只在能从像素唯一确定档位时开口」。\n\nv2（离场规划时发现它在整段第3关静默）：v1 把「玩家盖住横条」当成读不出来。它先数出轨道上属于色1/色12的列，要求两行一致且恰好6个连续——玩家的2×2压在横条上时被盖的那2个像素既不是色1也不是色12，于是数出4个，`len(mask0) != BAR_WIDTH` 直接返回None。第3关里玩家本来就要站到横条上去过桥，所以这条概念在最需要它的那几步全体闭嘴（步330/332/334/336 都是这样）。v2 改成逐档相容检查：可见的4个像素加上档外该是色4的那一段，仍然只对得上一种6像素横条——把玩家盖住的像素**当未知读**而不是当颜色读，档位照样唯一。这是主张变强（开口的局面变多），不是缩scope；相应地它现在会在更多转移上被检验。\n\nv3（v2 之后 settle 报 P=0.913、说错56格，而 assert_ 全是TRUE/NA）：v1/v2 的 assert_ 用「地图区一格没变」这个**看了nxt才知道**的条件把被拒的转移判成NA，apply 看不见nxt，于是在那几条上照常画了一遍横条，56个像素全说错。v3 把被拒的判据搬到prev上：抄第6关那条同型概念（card11_refused_if_player_stranded）的读法——把玩家四像素当横条色读出档位、算出转完一档后的轨道，若玩家脚下四像素在新轨道上不是整格色1或整格色12，就断言整个地图区不变。这同时把NA变成了可判错的TRUE/FALSE，主张再次变强。"
EVIDENCE = ["f4eeafb9e4db0fd5", "be30a88f43e10ba5", "21a95670e77b0078", "4822cc3f2c4f0c83", "bddae675e79e88d0"]

from _lib import me, CELL, clicked_card, MAP_ROWS, unreadable

BAND_R28 = (28, 29)
BAND_R38 = (38, 39)
BAR_WIDTH = 6
BAR_COLORS = (1, 12)
TRACK_BG = 4                 # 轨道上没被横条盖住的那一段是色4
MAP_COLS = 40

# Slot positions (left edge of bar)
SLOTS_R28 = (8, 10, 12, 14, 16, 18)
SLOTS_R38 = (4, 6, 8, 10, 12, 14)

def _read_bar_on_band(g, rows, slots):
    """读这条带上横条的档位；读不出来返回None。

    读法（v2）：**逐档试相容**。对每个候选档位 s，把轨道两行每个像素和「s 那一档该长的样子」比——
    档内该是色1 或色12，档外该是色4；`unreadable` 的像素（玩家盖着的、调用方标的哨兵）跳过不比。
    恰好一个档位相容才算读出，零个或两个以上都返回 None。
    """
    r0, r1 = rows
    track_cols = range(slots[0], slots[-1] + BAR_WIDTH)
    fits = []
    for s in slots:
        ok = True
        seen_any = False
        for c in track_cols:
            for r in (r0, r1):
                v = g[r][c]
                if unreadable(v):
                    continue
                seen_any = True
                if s <= c < s + BAR_WIDTH:
                    if v not in BAR_COLORS:
                        ok = False
                        break
                elif v != TRACK_BG:
                    ok = False
                    break
            if not ok:
                break
        if ok and seen_any:
            fits.append(s)
    return fits[0] if len(fits) == 1 else None

def _bar_after_shift(g, rows, slots):
    """这条带上的横条右移2像素后，轨道区每个像素的颜色；读不出档位返回None。"""
    pos = _read_bar_on_band(g, rows, slots)
    if pos is None:
        return None

    # Find new position (shift right by 2, wrap around)
    idx = slots.index(pos)
    new_idx = (idx + 1) % len(slots)
    new_pos = slots[new_idx]

    # Determine color (color 12 if at last slot, else color 1)
    new_color = 12 if new_pos == slots[-1] else 1

    pred = {}
    r0, r1 = rows
    track_cols = range(slots[0], slots[-1] + BAR_WIDTH)
    for c in track_cols:
        if new_pos <= c < new_pos + BAR_WIDTH:
            pred[(r0, c)] = new_color
            pred[(r1, c)] = new_color
        else:
            pred[(r0, c)] = 4
            pred[(r1, c)] = 4

    return pred

def _player_cells(a):
    return {(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)} if a else set()

def _on_band(a):
    """玩家（2×2、按格对齐）是不是正站在某条带的轨道上。"""
    if a is None:
        return False
    for rows, slots in ((BAND_R28, SLOTS_R28), (BAND_R38, SLOTS_R38)):
        if a[0] == rows[0] and slots[0] <= a[1] < slots[-1] + BAR_WIDTH:
            return True
    return False

def _raw_pred(g):
    """两条带各右移一档后、轨道区每个像素该是什么色（**不去掉玩家像素**）；任一带读不出返回None。"""
    pred1 = _bar_after_shift(g, BAND_R28, SLOTS_R28)
    pred2 = _bar_after_shift(g, BAND_R38, SLOTS_R38)
    if pred1 is None or pred2 is None:
        return None
    return {**pred1, **pred2}

def _bar_stays_under(raw, a):
    """转完一档之后，玩家脚下那一格是不是仍整格压在横条上（四像素全色1 或全色12）。
    玩家有像素落在轨道之外时 raw 取不到值，算「脚下没横条」。"""
    px = {raw.get(k) for k in _player_cells(a)}
    return px <= {1} or px <= {12}

def _pred_both_bands(g):
    """两条带各右移一档后的预测（已去掉玩家像素）；任一带读不出返回None。"""
    raw = _raw_pred(g)
    if raw is None:
        return None
    return {k: v for k, v in raw.items() if k not in _player_cells(me(g))}

def _refused(g):
    """这一下点击会不会被整个拒掉（地图区一格不变）：玩家站在轨道上、且转完之后脚下会露出背景。
    读不出档位时返回 None（不知道）。"""
    raw = _raw_pred(g)
    if raw is None:
        return None
    a = me(g)
    if not _on_band(a):
        return False
    return not _bar_stays_under(raw, a)

def _map_same(prev, nxt):
    return all(prev[r][:MAP_COLS] == nxt[r][:MAP_COLS] for r in range(MAP_ROWS))

def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, 11):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"

    ref = _refused(prev)
    if ref is None:
        return "NA"
    if ref:
        return "TRUE" if _map_same(prev, nxt) else "FALSE"

    pred = _pred_both_bands(prev)
    if pred is None:
        return "NA"

    for (r, c), v in pred.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"

def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, 11):
        return None

    ref = _refused(prev)
    if ref is None:
        return None
    if ref:
        return {}                       # 被拒：地图区一格不变（空 dict 就是「我认领了，但没有一格变」）

    pred = _pred_both_bands(prev)
    if pred is None:
        return None

    return {k: v for k, v in pred.items() if v != prev[k[0]][k[1]]}
