"""点色6卡时，多块垫子露着：玩家和同花色的那块垫子互换位置——落点是 prev 里与脚下垫子同一对颜色的那块"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且被点像素在 prev 里是色6、且落在面板区（列>=42）；换关返回 NA；me() 定位不到返回 NA；地图区露着的垫子不是 2-4 块返回 NA；玩家换位了、但脚下露出的垫子花色和落点的垫子花色不配对返回 FALSE。只断言玩家位置与两块垫子（原位、落点）的花色对，别的垫子怎么翻相位、别的物件怎么动都不管。"
NOTE = "card6_teleport 只在露着恰好一块垫子时开口，第 5 关有 4 块垫子、第 6 关也有 4 块，它在这两关全程闭嘴。实测 16 次多块垫子时的传送：玩家脚下露出的垫子花色集合，与落点在 prev 里的垫子花色集合，100% 匹配（例如脚下露出 {9,10}，落点也是 {9,10}）。这说明世界按花色配对选落点。相位不保：脚下露出 (9,10,10,9)、落点是 (10,9,9,10) 照样配对成功。露 2-4 块都见过传送（2 块时每块都可能是落点、3 块时三选一、4 块时四选一），0 块或 5 块以上没见过，SCOPE 里只开 2-4。"
EVIDENCE = ["66dd5ee813d3552a", "68493cf7603ba3da", "53a28a883e17faf6", "ef38229b39c09d26",
            "f56dd4c5c8a0504f", "578bfbd43c7ba7cf", "6ff6592e18e91c67", "e554eb996a5bb83e",
            "c82bd5750c43f9e6"]

from _lib import me, CELL, PANEL_COL0

PANEL_COL0 = 42
PAIRS = (frozenset({6, 7}), frozenset({13, 8}), frozenset({12, 11}), frozenset({9, 10}))
MAP_COLS = 40
MAP_ROWS = 62


def _pads(g):
    """地图区里所有抖动垫：位置 -> 四像素的颜色集合。"""
    out = {}
    for r in range(0, MAP_ROWS - CELL + 1, CELL):
        for c in range(0, MAP_COLS - CELL + 1, CELL):
            px = tuple(g[r + i][c + j] for i in range(CELL) for j in range(CELL))
            if frozenset(px) in PAIRS:
                out[(r, c)] = frozenset(px)
    return out


def _clicked_six(g, action):
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] == 6


def assert_(prev, action, nxt, ctx=None):
    if not _clicked_six(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    p, q = _pads(prev), _pads(nxt)
    if not (2 <= len(p) <= 4) or b == a:
        return "NA"
    # 玩家换位了：检查花色配对
    if b not in p:
        return "FALSE"
    if a not in q:
        return "FALSE"
    # 脚下露出的花色集合应该等于落点在 prev 里的花色集合
    if q[a] != p[b]:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _clicked_six(prev, action):
        return None
    a = me(prev)
    if a is None:
        return None
    p = _pads(prev)
    if not (2 <= len(p) <= 4):
        return None
    # 找脚下的垫子：从玩家位置往 next 看需要 next，这里只能假设玩家站在某块垫子上
    # 但多块垫子时玩家可能不在垫子上，所以 apply 保守：只在恰好一块时敢押
    # （这和 card6_teleport 的 apply 逻辑一样）
    if len(p) != 1:
        return None
    (tr, tc), colors = next(iter(p.items()))
    out = {(tr + i, tc + j): 14 for i in range(CELL) for j in range(CELL)}
    # 脚下露出的花色：假设和落点在 prev 里一样（按花色配对）
    for i in range(CELL):
        for j in range(CELL):
            # 这里没法预测具体哪个像素是哪个色（相位不保），apply 就不押原格了
            pass
    return out
