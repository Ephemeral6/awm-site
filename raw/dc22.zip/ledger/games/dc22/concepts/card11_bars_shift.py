"""点面板上那张色11 的卡：左下角轨道的三条带各是一个 6 档的环，带上每条 6 像素宽的横条同时前进一档（右移 2 像素），走过最右一档（列16-21）就绕回最左一档（列6-11）；停在最右一档的横条显示成色12，被别的横条压住的部分仍显色1。玩家站在轨道上时，只断言玩家以外的像素。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且被点像素在 prev 里是色11、落在面板区（列>=42）、且所在同色块至少 8 像素（_lib.clicked_card；拾到道具后面板上那块 4×4 四色图标的色11 象限只有 4 像素，不算这张卡）；换关返回 NA；只读行54-59 列6-21 这一段轨道（列32-37 那块围起来的图例不算），要求每条带都至少有一条横条、且带上色1/色12 的像素能被唯一一组最少的横条解释——否则返回 NA（别的关也有色11 的卡，那边的滑块不是这个装置）。玩家站在轨道上、点击被拒（地图区一格没变）的转移归 card11_refused_if_player_stranded 管，这里返回 NA。"
NOTE = "v5: 被拒的判据从 nxt 搬到 prev。v4 的 assert_ 用「地图区一格没变」把被拒的点击判成 NA——那是看了 nxt 才知道的条件，apply 看不见 nxt，于是在那些转移上照常画了一遍横条（settle 一直在报「认领 972 说错 52」）。终局卡第 995 步就是这么落空的：玩家站在行54 档14 的横条上（be89538d4cc65110），转完脚下露背景、整帧只涨了 HUD，而合并预测拿的是这条概念押的 44 格。v5 改成和 card11_l3_bars_shift v3 同一个读法：把玩家四像素当横条色读出档位、算转完一档后的轨道，脚下不是整格色1/色12 就是被拒，assert_ 与 apply 用同一个只读 prev 的闸——被拒的那一片仍归 card11_refused_if_player_stranded 断言，这里两边一致地闭嘴。v4: 点四色图标的色11 象限（b1fd828e9f4e6679）改的是左屋垫子的花纹，轨道没动——「卡按颜色认」还得加一条「得是大块图形」，clicked_card 加了同色块至少 8 像素的门槛。v3: 读法搬进 _lib（track_band / track_after_shift），和 card11_refused_if_player_stranded 共用；玩家站在轨道上时把玩家四像素当横条读档位，并把玩家那四格排除在断言之外。v2: v1 把「横条互相压住」漏了，判错七条。行56 那条带上有两条横条，它们在第 733 步重叠了两像素（列16-17），渲染时色1 压在色12 上，从像素直接数横条会数错。改成：先把覆盖到的像素还原成最少的一组档位（64 种子集里挑唯一的最小解，不唯一就 NA），再整组转一档。v1: 以为每条带只有一条横条、颜色由档位定。"
EVIDENCE = ["2067bfaee9c8a802", "b77c8a20cccf8175", "504a45e3c237ff8a", "cb414b71a810c3f3", "bf9283cc3d81b896", "a88ad4af1875dc1d", "90671ef12ba173cd", "b1fd828e9f4e6679", "be89538d4cc65110"]

from _lib import me, CELL, clicked_card, track_after_shift, TRACK_BANDS, TRACK_SLOTS, TRACK_LAST, BAR_W

MAP_COLS = 40
MAP_ROWS = 62


def _on_track(a):
    return a is not None and a[0] in TRACK_BANDS and TRACK_SLOTS[0] <= a[1] < TRACK_LAST + BAR_W


def _player_cells(a):
    return {(a[0] + i, a[1] + j) for i in range(CELL) for j in range(CELL)} if a else set()


def _masked(g, a):
    """玩家盖住的那一段本来就是横条：把玩家四像素当色1 再读档位。"""
    if not _on_track(a):
        return g
    h = [list(r) for r in g]
    for r, c in _player_cells(a):
        h[r][c] = 1
    return h


def _pred(prev):
    a = me(prev)
    pred = track_after_shift(_masked(prev, a))
    if pred is None:
        return None
    for k in _player_cells(a):
        pred.pop(k, None)
    return pred


def _bar_stays_under(raw, a):
    """转完一档之后玩家脚下那一格是不是仍整格压在横条上（四像素全色1 或全色12）。"""
    px = {raw.get(k) for k in _player_cells(a)}
    return px <= {1} or px <= {12}


def _refused(prev):
    """这一下点击会不会被整个拒掉（玩家站在轨道上、转完之后脚下会露出背景）。
    只读 prev，assert_ 与 apply 共用；读不出档位返回 None（不知道）。"""
    a = me(prev)
    if not _on_track(a):
        return False
    raw = track_after_shift(_masked(prev, a))
    if raw is None:
        return None
    return not _bar_stays_under(raw, a)


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, 11):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    ref = _refused(prev)
    if ref is None or ref:
        return "NA"                                   # 被拒的点击归 card11_refused_if_player_stranded
    pred = _pred(prev)
    if pred is None:
        return "NA"
    for (r, c), v in pred.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, 11):
        return None
    ref = _refused(prev)
    if ref is None or ref:
        return None
    pred = _pred(prev)
    if pred is None:
        return None
    return {k: v for k, v in pred.items() if v != prev[k[0]][k[1]]}
