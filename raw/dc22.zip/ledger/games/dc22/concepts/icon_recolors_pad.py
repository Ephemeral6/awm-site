"""点面板上那块 4×4 四色小图标（四个 2×2 象限，各一色）的任意一个象限：地图区里**固定那一块**抖动垫（格位行48 列18）的花纹换成循环里的下一对——(6,7)→(13,8)→(12,11)→(9,10)→(6,7)——主色的位置仍放主色，地图区其余像素一格不动；那一块此刻被玩家压着时，地图区一个像素都不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素落在面板区（列>=42）、颜色是八色之一、所在同色四连通块恰好是一个 2×2 方块"
         "（不必按格位对齐——图标落在奇数列上）；换关返回 NA；地图区里找不到抖动垫、或垫子集合在两帧之间位置变了返回 NA；"
         "**格位 (48,18) 既不是露着的抖动垫、又不是玩家此刻所在的格，返回 NA** —— 这一关之外它一句话都不说。")
NOTE = ("v6: 认「哪一块会换色」的判据整条换掉：不再看相位，改成**位置**——永远是格位 (48,18) 那一块。"
        "由来：v5 在终局卡第 2216 步（d31c7e2f5d50bc5b）判 FALSE。当时玩家站在 (58,34)，露着的三块垫子"
        "(4,4)/(48,18)/(52,32) 相位**全是 True**，v5 走「全同相位 ⇒ 地图区一格不动」那一档，"
        "而 (48,18) 明明从 (9,10,10,9) 换成了 (6,7,7,6)。"
        "把语料里全部 23 次点图标摊开逐条看（z10_pads.py / z10.out），结论只有一条："
        "**换色的永远是 (48,18) 这一块**——15 次它露着，它换色、别的垫子一格不动；8 次玩家正踩在它上面，"
        "整个地图区一格不动。相位判据在前 15 次里碰巧成立，是因为那段时间只有它一块的相位与众不同；"
        "第 2216 步之前 (4,4) 和 (52,32) 各自翻过相位，这个巧合就散了。"
        "（顺带一条读数：它被玩家压着的那一千多步里没跟着别的垫子一起翻相位——第 811 步它露着是 True，"
        "第 2216 步再露出来还是 True，而同期 (4,4) 从 False 翻成了 True。这条这里不主张，留给 card6_flips_pad_phase。）"
        "代价要说清楚：位置是这一关地图上的一个常数，这条概念因此只在这一关的这张地图上开口——"
        "换关、换图它返回 NA。它换来的是可判错性：任何**别的**垫子换色，或这一块该换没换，当场就是反例。\n"
        "v5: 认「哪一块会换色」的判据从「唯一一块**主色在左上角**」换成「唯一一块**相位和其余都不一样**」，"
        "并补一档：露着的垫子相位全一样时，断言地图区一格不动。"
        "由来：v1 的 NOTE 自己留了话——「点色6 的卡会把所有垫子的两色对调（card6_flips_pad_phase），"
        "对调之后这条认法必然认错——留着等它挨打」。它没等到反例，等到的是**整条哑掉**："
        "终局卡第 1622 步转完件之后，四块垫子里有三块主色在左上角，`_target` 认不出唯一一块，"
        "这四张图标卡（面板上那块 4×4 的四个象限）在 24 个停车位上全部「没有一条概念开口」——"
        "288 格的「停车位 × 点卡」表里 124 格是哑区，其中 96 格是它一条概念的份（zpark6.out、zpark7.out）。"
        "**没人开口和这条边不存在，在搜索里长得一模一样**，于是规划器报「这一步开不出任何新东西」。\n"
        "v4: 又加一个**只供规划器**的读口 `apply_with_ground`（主张、SCOPE、assert_、apply 一字未改）："
        "要换色的那块被玩家压着时，帧上一个像素都不动，`apply` 却返回 None，"
        "于是这条边在规划器眼里不是「整帧不动」而是「算不出来」——没有边。"
        "实测这一条把最后一关真解的第一段整段抹掉了，细节写在该函数里。\n"
        "v3: 主张、SCOPE、assert_、apply 一个字没改，只加了一个**只供规划器**的读口 apply_under——"
        "玩家压着的那块垫子在帧上看不见，`apply` 对它无话可说，可规划器手里有底色表，同一条循环用得上。"
        "它不进结算、不算存活率。\n"
        "v2: v1 说「换成含被点颜色的那一对」，第 806 步点色10 那格（b7c0d4bbd894b843）垫子却从 6/7 变成 13/8，判 FALSE。"
        "回头看：781-784 四次点的恰好是左上、右上、左下、右下，而结果 13/8、12/11、9/10、6/7 正好是一个固定循环的四步——"
        "「按被点颜色」是这个巧合骗出来的。真的规律是点哪一格都一样，垫子往下走一格。面板上那块图标本身四次都没变色。\n"
        "v1: 以为象限颜色定花纹。哪一块垫子会变仍然认不准：靠「主色在左上角」认，四块垫子里此刻唯一；"
        "但点色6 的卡会把所有垫子的两色对调（card6_flips_pad_phase），对调之后这条认法必然认错——留着等它挨打。")
EVIDENCE = ["9d04b095e842a0f0", "b1fd828e9f4e6679", "00aca1d39bafc948", "3fb82811541b8bd1",
            "b7c0d4bbd894b843", "534e524f7ec65658", "6ffd2f599acd6594", "540090da803a489c",
            "05d66bf9506c5f21",
            # 「被玩家压着 ⇒ 地图区一格不动」那一档
            "a3814481c922d5f2", "bd15f3996d182216", "c5d69edae9161f88", "18d375467338aa2e",
            "a216b439d91670e2", "290a2b89d5b85c37", "4672468892a019fb",
            # v5 在这一条上判 FALSE：玩家不在 (48,18) 上，露着的三块相位全同，它却认了「一格不动」
            "d31c7e2f5d50bc5b"]


from _lib import CELL, PANEL_COL0, me

CYCLE = ((6, 7), (13, 8), (12, 11), (9, 10))       # (主色, 副色)：主色占循环里固定的那个角
PAIR_OF = {v: p for p in CYCLE for v in p}
NEXT = {p: CYCLE[(i + 1) % len(CYCLE)] for i, p in enumerate(CYCLE)}
MAP_COLS = 40
MAP_ROWS = 62

ICON_PAD = (48, 18)    # 图标管着的那一块垫子的格位（行,列）——这一关地图上的位置常数


def _square4(g, r, c):
    """(r,c) 所在的同色四连通块恰好是一个 2×2 方块就返回 True。"""
    v = g[r][c]
    seen = {(r, c)}
    st = [(r, c)]
    while st and len(seen) <= 4:
        y, x = st.pop()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (y + dy, x + dx)
            if 0 <= p[0] < len(g) and 0 <= p[1] < len(g[0]) and p not in seen and g[p[0]][p[1]] == v:
                seen.add(p)
                st.append(p)
    if len(seen) != 4:
        return False
    rs = {p[0] for p in seen}
    cs = {p[1] for p in seen}
    return len(rs) == 2 and len(cs) == 2 and max(rs) - min(rs) == 1 and max(cs) - min(cs) == 1


def clicked_icon(g, action):
    """被点的是四色图标的某个象限就返回 True。"""
    if not action.startswith("ACTION6:"):
        return False
    try:
        c, r = (int(x) for x in action.split(":", 1)[1].split(","))
    except ValueError:
        return False
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return False
    return g[r][c] in PAIR_OF and _square4(g, r, c)


def _pads(g):
    out = {}
    for r in range(0, MAP_ROWS - CELL + 1, CELL):
        for c in range(0, MAP_COLS - CELL + 1, CELL):
            px = tuple(g[r + i][c + j] for i in range(CELL) for j in range(CELL))
            s = set(px)
            if len(s) == 2 and any(s == set(p) for p in CYCLE):
                out[(r, c)] = px
    return out


def _cell_of(a):
    return (a[0] - a[0] % CELL, a[1] - a[1] % CELL)


def _on_icon_pad(g):
    """玩家此刻正压着图标管的那一块。"""
    a = me(g)
    return a is not None and _cell_of(a) == ICON_PAD


def _advance(px):
    old = PAIR_OF[px[0]]
    new = NEXT[old]
    return tuple(new[0] if q == old[0] else new[1] for q in px)


def assert_(prev, action, nxt, ctx=None):
    if not clicked_icon(prev, action):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    p, q = _pads(prev), _pads(nxt)
    if not p or set(p) != set(q):
        return "NA"
    if ICON_PAD not in p:
        if not _on_icon_pad(prev):
            return "NA"                    # 这张地图上没有这一块，也没人压着它：不是这条概念的地界
        for r in range(MAP_ROWS):          # 被压着：帧上一个像素都不该动
            for c in range(MAP_COLS):
                if prev[r][c] != nxt[r][c]:
                    return "FALSE"
        return "TRUE"
    if q[ICON_PAD] != _advance(p[ICON_PAD]):
        return "FALSE"
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            if prev[r][c] != nxt[r][c] and not (
                    ICON_PAD[0] <= r < ICON_PAD[0] + CELL and ICON_PAD[1] <= c < ICON_PAD[1] + CELL):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_icon(prev, action):
        return None
    pads = _pads(prev)
    if not pads:
        return None
    if ICON_PAD not in pads:
        if not _on_icon_pad(prev):
            return None
        return {}                          # 会换色的那块被玩家压着：地图区一格不动
    new = _advance(pads[ICON_PAD])
    return {(ICON_PAD[0] + i, ICON_PAD[1] + j): new[i * CELL + j]
            for i in range(CELL) for j in range(CELL)}


def apply_with_ground(prev, action, ctx=None, ground=None):
    """**只供规划器**（不进结算、不算存活率）：同一条主张的另一半——这一下点击之后**帧上**是什么样。

    v6 起 `apply` 自己就能答这一档（认哪块靠位置，不靠相位，玩家压着时直接返回 {}），
    这个读口留着只为不改规划器的调用签名。`ground` 用不上了。

    历史（v4 写下的代价，留着当教训）：v4 之前玩家压着那块垫子时 `apply` 返回 None，
    于是这条边在规划器眼里**整条不存在**——不是「预测整帧不动」，是「算不出下一帧」，
    两者在搜索里天差地别：前者是一条边，后者是没有边。实测（zmacro4.out）这把最后一关
    「连点几下图标把脚下那块推成目标垫子的花色、再点色6 卡换过去」这条真解的第一段整段抹掉了。
    """
    return apply(prev, action, ctx)


def apply_under(prev, action, ctx=None, ground=None):
    """**只供规划器**（不进结算、不算存活率）：这一下点击把玩家脚下那一格的**底色**改成什么。

    为什么不能写进 `apply`：玩家压着的那一格在帧上是色14，底色换没换一个像素都看不出来，
    `apply` 报的是帧上的颜色，它对这一格无话可说——这正是它该闭嘴的地方。
    可规划器手里有底色表（它见过玩家踩上去之前那一帧），同一条循环用得上。

    落在玩家脚下时帧上一格不变，所以这条不会和任何概念在任何一格上打架；
    它错了也不会当场报错，而是下一次换位落到错的垫子上——退出码 5 会把它抓出来。
    """
    if not clicked_icon(prev, action):
        return None
    if not ground or not _on_icon_pad(prev):
        return None
    px = tuple(ground.get((ICON_PAD[0] + i, ICON_PAD[1] + j))
               for i in range(CELL) for j in range(CELL))
    if any(v is None for v in px) or not any(set(px) == set(p) for p in CYCLE):
        return None
    new = _advance(px)
    return {(ICON_PAD[0] + i, ICON_PAD[1] + j): new[i * CELL + j]
            for i in range(CELL) for j in range(CELL)}
