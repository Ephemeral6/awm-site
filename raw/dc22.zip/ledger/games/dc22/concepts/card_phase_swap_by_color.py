"""点面板上一张色K 的卡（K 是 9 或 15，按被点像素的颜色认，不认坐标）：地图上每一格「实心色K」与「4/K 棋盘格」互换相位——实心变棋盘、棋盘变实心，其余像素不动；但玩家正站在一座色K 的桥上时整张地图一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6，且被点像素在 prev 里是色9 或色15、落在面板区、所在同色四连通块至少 20 像素"
         "（真卡 47 像素；第 4 关面板上那对 16 像素的色9 箭头、第 6 关 16 像素的亮菱形和 1 像素的死菱形心都挡在线下，"
         "那些归别的概念管）。换关返回 NA；只断言行 0-61，HUD 两行不管；"
         "**panel_glyphs 认出的那些面板图形像素一概不断言**（它们变不变归画它们的概念管，"
         "同一下点击里褪框就发生在那儿）。"
         "「地图上的相变格」= 2×2 对齐格、四像素都在 {4, K} 里且含 K、且它的色K 像素所在的八连通色K 块"
         "不是「四周一圈只挨着面板底色 5」的那种纯装饰块"
         "（卡面自己就是画在色5 上的实心色K，箭头也是；这条用「挨不挨色5」而不是列号把它们排掉——列号是自画的边界，"
         "第 6 关已经证明地图能铺到列 49）。")
NOTE = ("v1: 这一条把 card15_phase_swap（锁死 ACTION6:52,14）和影子册里 card15_phase_swap_by_color / "
        "card9_only_swaps_9_4 三条合成一条：色9 卡与色15 卡是同一种装置，卡的颜色就是它管的那种桥/柱的颜色。"
        "第一稿用「格子外圈一圈没有色5」排面板，结算当场 10 条自证反例（9b255c49f56e7813 等）：卡面 47 像素里"
        "有整格实心色K 的内芯，外圈全是色K，排不掉；改成按整块（八连通）挨不挨色5 来排，dc3ee130dbb4a5d2 同理。"
        "帧差实测：第 0 关点色9 卡，(20-23,18-21) 实心 9 掉 8 像素变棋盘、(34-37,8-11) 棋盘补 8 像素变实心，再点一次原样换回"
        "（9b255c49f56e7813 / f7cb149efc7d73b9）；第 1、2、4 关同理（ba9190d07a8fc765、e660fbf9238bf5b5、dacb8926c15f557b）；"
        "色15 三条（42f2328068b6d913、bc82204362547936、e35aadcdcbb6d77e）完全一样的读法。"
        "「玩家站在桥上时不动」是第 584 步（d7298e57f3a2a624）换来的：真卡、47 像素、地图一格没变，那一刻玩家正踩在"
        "(34-37,26-29) 那座实心色9 桥的一格上——桥翻成棋盘等于把脚下抽掉，世界就干脆不翻。"
        "「站在桥上」从帧上这样读：把相变格按格与格四邻接分成一座座桥，哪座桥的外接框盖住玩家格就算站在桥里"
        "（玩家挡住的那格看不见，桥上少了一格，框还在；站在桥旁边地板上时框到桥边为止，盖不到玩家）。"
        "第一稿按像素八连通取块，第 1 关一座实心桥和一座棋盘桥斜角相碰被并成一块，把站在旁边的玩家也罩进去了"
        "（ba9190d07a8fc765 判成不动，实际翻了）；面板排除也从「挨到一个色5 像素」改成「整块四周只有色5」，"
        "因为第 4 关地图里行44-45 就有一片色5，一根棋盘柱挨着它被整根吃掉（bc82204362547936）。"
        "一格宽的桥的两端这样读会漏，语料里没有这种桥，先这么写。"
        "棋盘格的相位：像素为色K 当且仅当行列和为奇，四关全部一致。"
        "apply 押整张地图的相变格；玩家脚下那格看不见，走开后 floor_under 若猜成色2，链式预测里那格就再也不参与相变——"
        "这是 apply 的已知短板，判据不受影响。"
        " v2: 面板排除改走 _lib.panel_glyphs（非色5 像素的八连通块、整块四周只有色5）。第 0 关开局两张卡各套着一圈"
        "40 像素的色0 边框，本关第一次点卡才整块褪成色5（2529fc5f8db19fea）；边框在时按色K 取块的邻居是色0，"
        "卡面 47 像素被当成地图上三格实心色9——探索卡上第一次点色9 卡恰好在褪框之后，这条漏洞没被考到，"
        "终局卡从开局起手就会撞上。判据与 EVIDENCE 不变。"
        " v3: 终局卡第 1076 步（450c68a41338a621）点色9 卡时面板区有 72 个色0 像素（边框），panel_glyphs 返空，"
        "卡面被当成地图实心格，而实际只褪框（97 格 0→5）、地图不变——判 FALSE。缩 scope：面板区有色0 就返回 NA。"
        " v4（总账记作 v6）: **v3 的两条依据实测都是假的，整条撤掉。** 把同一个 tid 重新跑一遍："
        "(a) panel_glyphs 在那一帧返的是 2 块 87 像素的图形（边框 40 + 卡面 47），**不是空**——它本来就按"
        "「非色5 的八连通块」取块，边框在不在都一样罩得住；(b) 那一步地图**也变了**：96 格帧差 = 80 格褪框 + 16 格相变，"
        "而这 16 格正是这条概念押的那 16 格，一格不差。v3 把褪框的 80 格读成了「地图不变」。"
        "真正的病在断言的**范围**：这条概念把行 0-61 **整行**（含面板列）都要求「除我押的以外一格不许动」，"
        "于是同一下点击里褪框的 80 个面板像素全算它头上。褪框归 panel_ring_fades_on_click 管，不是它的主张。"
        "改法：不变量那一圈跳过 panel_glyphs(prev) 认出的图形像素——它本来就已经用同一个读法把面板排除在**预测**之外了，"
        "只是忘了同样排除在**不变量**之外。不用列号划界（第 6 关地图铺到列 49，列号靠不住）。"
        "反例：终局卡第 661 步 f5377a11a1f0387b（边框在，褪框 + 相变同时发生，v3 返 NA 于是链式预测拿了张过期的帧，"
        "下一步 90ae767265b5dce4 押 4 实 9 错 16 格，退出码 5）。")
EVIDENCE = ["9b255c49f56e7813", "f7cb149efc7d73b9", "ba9190d07a8fc765", "e660fbf9238bf5b5",
            "0f144597e8a58044", "1bba4b02543003ea", "dacb8926c15f557b", "d7298e57f3a2a624",
            "42f2328068b6d913", "bc82204362547936", "e35aadcdcbb6d77e", "dc3ee130dbb4a5d2",
            "450c68a41338a621", "f5377a11a1f0387b", "90ae767265b5dce4"]

from _lib import CELL, clicked_card, me, panel_glyphs
from geo import components

CARD_COLORS = (9, 15)
CARD_MIN_GLYPH = 20
MAP_ROWS = 62          # 行 62-63 是 HUD
PANEL_BG = 5
PANEL_COL0 = 42        # 面板区列起始
PANEL_COL1 = 64        # 面板区列终止（不含）


def _has_ring(g):
    """面板区是否有色0（边框）；有则 panel_glyphs 会失效。"""
    return any(g[r][c] == 0 for r in range(min(MAP_ROWS, len(g))) for c in range(PANEL_COL0, min(PANEL_COL1, len(g[0]))))


def card_color(g, action):
    """这一下点的是哪张相变卡的颜色；不是就返回 None。"""
    for k in CARD_COLORS:
        if clicked_card(g, action, k, min_glyph=CARD_MIN_GLYPH):
            return k
    return None


def panel_pixels(g, k):
    """面板画上去的色K 像素：落在 `_lib.panel_glyphs` 认出的面板图形里的那些。

    图形 = 非色5 像素的八连通块、整块**四周一圈只挨着面板底色 5**（或帧边）。卡面、箭头都是画在一片纯色5 上的图案；
    地图上的桥/柱嵌在色4 的墙里，和整张地图连成一大块。不拿列号划界——列号是自画的边界，第 6 关地图铺到列 49，
    而第 4 关地图里（行44-45 列22-27）就有一片色5，所以「挨到 5」单像素地看也不可靠，只能整块看。
    按「非色5」而不是「色K」取块，是因为开局时卡面外面套着一圈色0 边框：按色K 取块，块的邻居是色0 不是色5，
    卡面就会被当成地图上的实心格。
    """
    return {(y, z) for s in panel_glyphs(g) for y, z in s if g[y][z] == k}


def phase_cells(g, k):
    """地图上的相变格：[(r, c, 是不是实心)]。"""
    n, m = len(g), len(g[0])
    skip = panel_pixels(g, k)
    out = []
    for r in range(0, min(MAP_ROWS, n) - CELL + 1, CELL):
        for c in range(0, m - CELL + 1, CELL):
            px = [g[r + i][c + j] for i in range(CELL) for j in range(CELL)]
            if k not in px or not set(px) <= {4, k}:
                continue
            if any((r + i, c + j) in skip for i in range(CELL) for j in range(CELL)):
                continue
            out.append((r, c, len(set(px)) == 1))
    return out


def on_bridge(g, k):
    """玩家是不是站在一座色K 的桥里；me 定位不到返回 None。

    读法：把相变格按**格与格四邻接**分成一座座桥（不用像素八连通——第 1 关一座实心桥和一座棋盘桥斜角相碰，
    按像素八连通会并成一块，外接框把站在旁边地板上的玩家也罩进去，ba9190d07a8fc765 就是这么误判的）；
    某座桥的外接框盖住玩家格，就算站在桥里（玩家挡住的那格看不见，桥上少了一格，但框还在）。
    """
    p = me(g)
    if p is None:
        return None
    cells = {(r, c) for r, c, _ in phase_cells(g, k)}
    idx = {(r // CELL, c // CELL) for r, c in cells}   # 折成格号，components 才按格四邻接分块
    pr, pc = p[0] // CELL, p[1] // CELL
    for comp in components(idx):
        rs = [q[0] for q in comp]
        cs = [q[1] for q in comp]
        if min(rs) <= pr <= max(rs) and min(cs) <= pc <= max(cs):
            return True
    return False


def swapped(g, k):
    """相变后该变成什么：{(row, col): 色}，只含会变的像素。"""
    pred = {}
    for r, c, solid in phase_cells(g, k):
        for i in range(CELL):
            for j in range(CELL):
                v = (k if (r + i + c + j) % 2 else 4) if solid else k
                if v != g[r + i][c + j]:
                    pred[(r + i, c + j)] = v
    return pred


def assert_(prev, action, nxt, ctx=None):
    k = card_color(prev, action)
    if k is None:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    ob = on_bridge(prev, k)
    if ob is None:
        return "NA"
    pred = {} if ob else swapped(prev, k)
    skip = {p for s in panel_glyphs(prev) for p in s}   # 面板画的图形不归这条概念管，变不变都不是它的主张
    for r in range(min(MAP_ROWS, len(prev))):
        for c in range(len(prev[0])):
            if (r, c) in skip:
                continue
            if nxt[r][c] != pred.get((r, c), prev[r][c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    k = card_color(prev, action)
    if k is None:
        return None
    ob = on_bridge(prev, k)
    if ob is None:
        return None
    return {} if ob else swapped(prev, k)
