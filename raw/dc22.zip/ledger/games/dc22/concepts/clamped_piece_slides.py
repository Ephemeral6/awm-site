"""夹子合口之后（地图区里那只色8 的方块正中央咬着 2×2 的色12），点面板上一颗**亮着的**菱形：只会有两种结果——夹子连同整件色12 的件一起朝这颗菱形管的方向平移恰好 4 像素，或者整帧一格不动；平移后夹子正中央那 2×2 落在色4 的墙上、件有像素会被推出帧外、或件新占的那一圈里有色2 的地板时，一定是后者。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6:<列>,<行>，被点像素在 prev 里是某颗菱形的色X 且那颗菱形 16 像素全亮；diamond_dir 认不出方位返回 NA。"
         "地图区（列<42）里的色8 四连通块要**只有一块**，而且是「边长偶数且不小于 6 的实心正方形挖掉正中 2×2」的样子，"
         "prev 里那 2×2 还得是色12，否则返回 NA——没合口的时候地图上是两块色8（那只 28 像素的空心方框 + 件自带的 4×4 环），归 lit_diamond_moves_box 管。"
         "件 = 含夹子在内的色8/色12 四连通块（地图区内）。断言只管件落点上的像素颜色，让开的那一圈露出什么不管；"
         "落点在 prev 或 nxt 里是玩家色14 的像素跳过（玩家可以站在件上）。换关返回 NA。"
         "三条否决条件（判「不动」）：夹子正中 2×2 的落点压色4 的墙、件有像素出帧、"
         "件新占的那一圈（落点扣掉件此刻自己占的像素）里有色2 的地板。"
         "三条都不成立时这条概念只说「要么按平移落点长、要么整帧不动」——整帧不动一律判 TRUE，见 NOTE v4。")
NOTE = ("v6: 再补一个**只供规划器**的接口 centre_field（把同样那三条否决条件拿去逐个中心位置问一遍，"
        "算出「件还差几下点击才到落点」的距离场），判据与 apply、apply_mover、mover_px 一个字没动。"
        "为什么补：规划器原来拿「中心离落点多少像素」排序，件正上方有墙时那把尺会把唯一走得通的绕路"
        "判成退步——实测件离落点只剩 5 下点击，搜了两万个局面没到终点。\n"
        "v5: 补回**第三条否决条件**——件新占的那一圈像素（落点扣掉件此刻自己占的）里只要有一个是色2 的地板，"
        "这一下就不动。由来：终局卡第 2219 步 fa178cf072953f3c，件在行28-47 列26-33（竖着），点亮着的下菱形，"
        "夹心落点全是色12、没有像素出帧，两条老否决条件都不成立，apply 于是照旧押「整体下移 4 像素」104 格，"
        "世界整帧一格没动——终局卡上这就是一次意外（预测错 56 格）。"
        "拿全语料 55 条「合口后点亮菱形」重新对照（z14_refuse.py / z14.out）："
        "**动了的 46 条，新占那一圈里的色2 像素个数全是 0；不动的 9 条里有一条是 8**，就是这一条。"
        "色0 与色4 都拦不住它（动了的落点上色4 最多压过 72 个像素），色2 是目前唯一一个两组分得开的读数。"
        "老实说清这条的分量：它只有**一个**正面例子撑着，另外 8 条不动仍然解释不了（v4 那段话照旧算数）；"
        "它换来的是 apply 在这一类局面上闭嘴而不是押错——押错要在终局卡上当场记一次意外。"
        "件是踩得上去的地板，色2 也是地板，「地板不许叠地板」是个能说得通的读法，但这只是读法，不是证据。\n"
        "v4: **「两条否决条件就是全部」被推翻**——第 1126 步 f487dfb3cc779235：件在行20-39 列18-25，"
        "点的是亮着的那颗上菱形，落点上夹子正中那 2×2 落在件自己的色12 上（没压墙）、也没有像素会出帧，"
        "世界却整帧一格不动，连着五下都不动。离场查过：这一帧和上一帧（7410cfc641f7539b，同一颗菱形、动了 88 格）"
        "之间除了件挪窝，**帧上一格都没变**（zrefuse6），所以不是别处的开关；"
        "落点上的色4 也不是拦路的——那一下动了的落点上同样压着 10 个色4 像素，件照样把它们盖掉了（zrefuse5）。"
        "拿全语料 18 条「合口后点亮菱形」逐条比过（zrefuse2），动了的 17 条和这一条在"
        "「落点压了几个色4 / 压的是夹子还是件身 / 压的是哪一块色4」上都分不开。"
        "**第三条否决条件我找不出来，所以这条概念不再声称自己知道什么时候不动**：主张缩成「只有两种结果」，"
        "整帧不动一律判 TRUE。原来那两条否决条件是**充分**的（19 条证据撑着），留在断言里照旧关着。"
        "apply 仍按「会动」生成——那是这条概念敢生成的部分，押错了就该在终局卡上当场响，不拿闭嘴换太平。\n"
        "v3: 补一个**只供规划器**的接口 mover_px（此刻件在哪，不问点哪一颗菱形），判据与 apply、apply_mover 一个字没动。"
        "为什么补：规划器要先知道「场上会挪窝的是谁、现在在哪」，才算得出「把它挪到哪儿才搭得上桥」；"
        "apply_mover 要先答出「这一下走不走得动」才报坐标，答不了「它现在在哪」。\n"
        "v2: 认夹子那段太松，12 条反例全是**合口之前**的点菱形（a6f75481ba8a3461 等）：件自带的那圈 4×4 色8 环"
        "（行32-35 列8-11，正中 2×2 是件的色12）也符合「边长偶数的正方形挖掉正中 2×2」，于是这条概念在整关都开口，"
        "押「件整体平移」而实际上动的是那只 28 像素的空心方框。合口前后真正的差别是**地图上剩几块色8**："
        "合口前两块（方框 + 件自带的环），合口后只剩一块（8 卡把方框收拢到环外，两者并成一块 6×6）。"
        "改成「只有一块、且边长≥6」，12 条反例全部退回 NA。\n"
        "v1: 第 1016 步 8 卡把方框在件上合了口（de4922528e0a9249），之后三次点亮着的菱形都是整帧不动"
        "（第 1017 步左菱形 1bf514f62abdbebf、第 1020-1021 步上菱形 341d6e18defb332d），像是「夹住了就再也推不动」。"
        "第 1024 步点右菱形（9e166ab41d11d3e9）推翻了这个读法：89 格帧差，夹子从列7-12 走到列11-16、件从列0-19 走到列4-23，整体右移 4 像素——"
        "**夹住即搬运，只是方向受限**。三次不动各有各的理由：上菱形那两次新中心 (29-30,9-10) 有一半压在色4 的墙上；"
        "左菱形那次件的左端已经贴着列0，再左移 4 像素整条左臂就出帧了。两条否决条件都是 (prev, action) 上算得出来的，不是隐藏状态。"
        "「出帧」这一条只有左边这一个例子撑着：往右推到列39 之外会不会被拦（那边是 HUD 与面板）、还是照样走，没试过。")
EVIDENCE = ["9e166ab41d11d3e9", "1bf514f62abdbebf", "341d6e18defb332d", "f487dfb3cc779235",
            "15324eaf396808f6", "17a7aa6863818ffa", "23d23c4145768ab1", "962e643a167a736b",
            "9805ddbd1e7b89fd", "9bea735d277392ee", "a6f75481ba8a3461", "aad0a49e8c0521da",
            "bd799f587b910aa9", "c7421ff01609984b", "daf7c0128e401216", "e44e5509988da126",
            "0cf1953682f66a60", "596536b9353fb32c", "846d5d9fa055ebfb", "8903032e8e4eb223",
            "bd91bc7e3bd0716e", "bf26c8488d66de52", "c5b7230c1d53c3e5", "ef8207d85616014a",
            "fca8aed6f2130cac", "fa178cf072953f3c"]

from _lib import PANEL_COL0, panel_diamond, diamond_dir, DELTA
from geo import components

MAP_ROWS = 62
PIECE = (8, 12)
HOLE = 12            # 夹子正中 2×2 咬住的就是件
WALL = 4
ME = 14


def _clicked(g, action):
    """点的是哪颗菱形的色X、它亮没亮；不是点菱形返回 (None, None)。"""
    if not action.startswith("ACTION6:"):
        return None, None
    try:
        c, r = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None, None
    if not (0 <= r < len(g) and PANEL_COL0 <= c < len(g[0])):
        return None, None
    x = g[r][c]
    d = panel_diamond(g, x)
    if d is None or (r, c) not in d:
        return None, None
    return x, all(g[i][j] == x for i, j in d)


def _clamp(g):
    """合了口的夹子：地图区里**唯一**一块色8 连通块，而且是「边长偶数且≥6 的实心正方形挖掉正中 2×2」。
    返回 (像素集, 正中 2×2 的四个位置)；不是这个样子返回 None。
    没合口时地图上有两块色8（28 像素的空心方框 + 件自带的 4×4 环），这里直接返回 None。"""
    px = {(r, c) for r in range(min(MAP_ROWS, len(g)))
          for c in range(min(PANEL_COL0, len(g[0]))) if g[r][c] == 8}
    comps = components(px)
    if len(comps) != 1:
        return None
    comp = set(comps[0])
    rs = [r for r, _ in comp]
    cs = [c for _, c in comp]
    r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
    side = r1 - r0 + 1
    if side != c1 - c0 + 1 or side < 6 or side % 2:
        return None
    k = side // 2
    hole = {(r0 + k - 1 + i, c0 + k - 1 + j) for i in range(2) for j in range(2)}
    full = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
    return (comp, hole) if comp == full - hole else None


def _piece(g, clamp):
    """含夹子在内的色8/色12 四连通块（地图区内）。"""
    seen = set(clamp)
    out = dict.fromkeys(clamp, 8)
    st = list(clamp)
    while st:
        r, c = st.pop()
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (r + dr, c + dc)
            if p in seen or not (0 <= p[0] < min(MAP_ROWS, len(g))
                                 and 0 <= p[1] < min(PANEL_COL0, len(g[0]))):
                continue
            v = g[p[0]][p[1]]
            if v not in PIECE:
                continue
            seen.add(p)
            out[p] = v
            st.append(p)
    return out


def _target(g, action):
    """这一下点击之后件该长在哪：{位置: 颜色}；不动返回空 dict；认不出返回 None。"""
    x, lit = _clicked(g, action)
    if x is None or not lit:
        return None
    d = diamond_dir(g, x)
    if d is None:
        return None
    got = _clamp(g)
    if got is None:
        return None
    clamp, hole = got
    if any(g[r][c] != HOLE for r, c in hole):
        return None                       # 没咬住件，不是这条概念管的局面
    cells = _piece(g, clamp)
    dr, dc = DELTA[d]
    dr, dc = dr * 2, dc * 2               # DELTA 是一格 2 像素，一次点击走两格
    want = {(r + dr, c + dc): v for (r, c), v in cells.items()}
    if any(not (0 <= r < len(g) and 0 <= c < len(g[0])) for r, c in want):
        return {}                         # 件会被推出帧外
    if any(g[r + dr][c + dc] == WALL for r, c in hole):
        return {}                         # 新中心压在墙上
    if any(0 <= r < len(g) and 0 <= c < len(g[0]) and (r, c) not in cells and g[r][c] == 2
           for r, c in want):
        return {}                         # 件新占的那一圈里有色2 的地板（v5）
    return want


def centre_field(g, goals, limit=4000):
    """**只供规划器，永不参与断言、不进结算**：把件当刚体在这张图上平移，报一张
    「从 `goals` 里任一个中心位置倒着走回来，每个中心位置各差几下点击」的表（{中心: 几下}）。

    判据就是 `_target` 那三条否决条件（出帧外 / 夹子正中 2×2 压色4 的墙 / 新占的一圈里有色2 的
    地板），一条不多一条不少——改那三条，这张表跟着改。所以它不是第二套世界读法，
    是同一套读法被问了很多遍。边是可逆的（走得过去就走得回来：两端的落点各自合法），
    倒着搜和正着搜出来的距离一样。

    为什么规划器要它：`mover_px` 只说件此刻在哪，规划器于是拿「中心离落点多少像素」当排序尺，
    而那把尺在**绕路**面前会骗人——件正上方有一堵墙时，往左挪一步的读数更差，
    可那正是唯一走得通的方向。贪心排序在那种地方会把整层平台铺满然后撞上限
    （实测：件中心离落点 5 下点击，搜了两万个局面没到终点，而真路线是先横后竖）。
    这张表把「还差几下」算成**真的还差几下**，绕路那一步的读数于是照样往下掉。

    近似摆在明处：表是拿**此刻这张帧**算的，件自己占的那些像素当成件走得过去的地方
    （它就是从那儿来的），件让开之后底下真正露出什么，这张帧上看不见。所以它是排序用的读数，
    不是主张；错了只会让搜索走得笨，不会让谁被判对或判错。
    """
    got = _clamp(g)
    if got is None:
        return None
    clamp, hole = got
    if any(g[r][c] != HOLE for r, c in hole):
        return None
    cells = set(_piece(g, clamp))
    here = min(hole)
    steps = [(dr * 2, dc * 2) for dr, dc in DELTA.values()]
    nr, nc = len(g), len(g[0])

    def ok(off):
        orow, ocol = off[0] - here[0], off[1] - here[1]
        for r, c in hole:
            r, c = r + orow, c + ocol
            if not (0 <= r < nr and 0 <= c < nc) or g[r][c] == WALL:
                return False
        for r, c in cells:
            r, c = r + orow, c + ocol
            if not (0 <= r < nr and 0 <= c < nc):
                return False
            if (r, c) not in cells and g[r][c] == 2:
                return False
        return True

    field, front = {}, []
    for gpos in goals:
        gpos = tuple(gpos)
        if ok(gpos):
            field[gpos] = 0
            front.append(gpos)
    seen = 0
    while front and seen < limit:
        nxt = []
        for p in front:
            seen += 1
            for dr, dc in steps:
                q = (p[0] + dr, p[1] + dc)
                if q in field or not ok(q):
                    continue
                field[q] = field[p] + 1
                nxt.append(q)
        front = nxt
    return field


def mover_px(g):
    """**只供规划器，永不参与断言、不进结算**：此刻那个会被菱形搬运的件占了哪些像素
    （{位置: 颜色}，含夹子），不问点哪一颗菱形、也不问它亮没亮；没合口或认不出返回 None。
    和 `lit_diamond_moves_box.mover_px` 是同一个接口，理由见那边。
    """
    got = _clamp(g)
    if got is None:
        return None
    clamp, hole = got
    if any(g[r][c] != HOLE for r, c in hole):
        return None
    return dict(_piece(g, clamp))


def apply_mover(prev, action, ctx=None):
    """**只供规划器，永不参与断言、不进结算**：这一下点击里会挪窝的那个件占了哪些像素——
    返回 (挪之前, 挪之后) 两个像素集合；这一下走不动、或认不出局面就返回 None。

    为什么要有它：`apply` 按设计**只填件的落点，不填让开的那一圈**（底下露出什么读不出来，
    见 SCOPE）。离场规划里「不填」= 上一帧原样留着，于是件每挪一次就在原地留下一个影子，
    下一步「地图区里只有一块色8」认不出来，这条概念整条闭嘴，链条断在第二次点击上。
    这里报的不是「让开那格是什么色」（那才是主张），只是**坐标**：哪些像素被盖住了、哪些露出来了。
    规划器拿它自己记账——件盖上去之前那一格是什么色，它上一帧见过，还回去就是了。
    """
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    want = _target(prev, action)
    if not want:
        return None
    got = _clamp(prev)
    if got is None:
        return None
    return set(_piece(prev, got[0])), set(want)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    want = _target(prev, action)
    if want is None:
        return "NA"
    if not want:
        return "TRUE" if prev == nxt else "FALSE"
    if prev == nxt:
        return "TRUE"                     # v4：什么时候不动，这条概念不再声称自己算得出来
    for (r, c), v in want.items():
        if prev[r][c] == ME or nxt[r][c] == ME:
            continue
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    want = _target(prev, action)
    if want is None:
        return None
    return want or None
