"""ACTION1/2/3/4 遇阻挡时 me 不动，整帧不变或只改 HUD。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1/2/3/4；me() 定位不到返回 NA"
NOTE = "阻挡发生时 me(prev) == me(nxt)；可能整帧不变，也可能只改 row 63（HUD）"
EVIDENCE = ["f81f81a1f3c1165e", "60a4f4c075bc5776", "07a51c4a22bbd04a"]

from _lib import me

def assert_(prev, action, nxt, ctx=None):
    if action not in ["ACTION1", "ACTION2", "ACTION3", "ACTION4"]:
        return "NA"
    pos_prev = me(prev)
    pos_next = me(nxt)
    if pos_prev is None or pos_next is None:
        return "NA"

    # 这条概念断言「遇阻挡时 me 不动」
    if pos_prev != pos_next:
        return "NA"  # me 移动了，不是阻挡情况

    # me 没动，应该是阻挡
    return "TRUE"
