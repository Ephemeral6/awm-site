"""点面板上那张色11 的卡：地图行54-55 上那条 6 像素宽的色1 横条整体右移 2 像素——原来最左的两列退回色4，右端接上两列变成色1，这两行列0-37 里其余像素仍是色4；地图别处一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 且被点像素在 prev 里是色11、落在面板区（列>=42）、所在同色四连通块至少 8 像素"
         "（_lib.clicked_card）；换关（ctx 的 level_prev != level_next）返回 NA。再要三件事同时成立，否则 NA：\n"
         "(a) 行54 与行55 在列0-37 上逐像素相同、取值只有色1 和色4、而且色1 恰好是一段连续的 6 像素"
         "（玩家站上去、横条被压住、两条横条叠在一起都读不出来，一律闭嘴）；\n"
         "(b) 行56-61 的列0-37 全是色4，也就是这两行是**孤零零一条带**。另有一处装置长得几乎一样但是三条带"
         "（行54/56/58 各一条），那边点色11 卡是三条一起动、而且横条停到轨道最右一档会变成色12；"
         "这一条界线是拿那边的反例换来的，见 NOTE。\n"
         "(c) 横条左端列 <= 20（也就是落点左端列 <= 22）。这一条不是反例换来的，是主动闭嘴："
         "列22 上的色1 横条我在帧上亲眼见过，再往右的档位一次都没见过，而同种装置在轨道最右一档会把横条变成色12，"
         "轨道到哪一列为止是帧上读不出来的隐藏状态。\n"
         "断言范围是地图区行0-61、列0-39；HUD 两行与面板不管。")
NOTE = ("v1。第一稿的 SCOPE 只有 (a)：只要行54-55 读得出一条 6 像素的横条就开口，落点一律押色1。"
        "它在第 5 关那处装置上当场判 FALSE 四条（1301e6f71a1ae832、bf9283cc3d81b896、b764234d57ec65cc、def81d3ccdfc401c）："
        "横条左端从列14 挪到列16 时，那六个像素不是色1 而是色12——那边的轨道到列16 为止，最右一档变色。"
        "补 (b) 之后那边全部落回 NA：三条带的那处装置，行56-61 里还有两条横条，一眼分得开。\n"
        "「隐藏状态」在这里具体是什么：轨道的档位区间。行54-55 的列0-37 除了横条本身全是色4，"
        "帧上没有任何边框、刻度、端点标记能告诉你轨道从哪一列起、到哪一列止；"
        "只有横条走到最右一档变色12 的那一瞬间才漏出一点消息，而那一瞬间之前来不及知道。"
        "所以 (c) 把预测限制在「落点我在帧上见过、当时是色1」的那一段——这是拿观测划的界，不是拿机制划的界，"
        "以后有了列24 及以后的记录就该放宽。\n"
        "认卡只按被点像素的颜色和连通块大小，不认坐标；别的关也有色11 的卡（有一关的色11 卡管的是另外两条横带），"
        "它们全靠 (a)(b) 挡成 NA。")
EVIDENCE = ["27fb6d6928572c18", "1301e6f71a1ae832", "bf9283cc3d81b896"]

from _lib import clicked_card, MAP_ROWS

MAP_COLS = 40          # 列40-41 是虚线分隔，列>=42 是面板
TRACK_ROWS = (54, 55)  # 这条带占的两个像素行
TRACK_C1 = 38          # 轨道所在两行里属于地图的列：0..37
BAR_W = 6              # 横条宽 6 像素
BAR_COLOR, TRACK_BG = 1, 4
STRIDE = 2             # 一次右移 2 像素
MAX_LEFT = 20          # SCOPE (c)：只在左端列 <= 20 时开口
QUIET_ROWS = range(56, 62)   # SCOPE (b)：这几行全是色4 才算「只有一条带」
CARD_COLOR = 11


def _single_band(g):
    """行56-61 的列0-37 全是色4：这一处只有一条带（三条带的那处装置在这几行里还有横条）。"""
    return all(g[r][c] == TRACK_BG for r in QUIET_ROWS for c in range(TRACK_C1))


def _bar_left(g):
    """行54-55 上那条 6 像素横条的左端列；读不出唯一一条返回 None。"""
    r0, r1 = TRACK_ROWS
    row = []
    for c in range(TRACK_C1):
        if g[r0][c] != g[r1][c] or g[r0][c] not in (BAR_COLOR, TRACK_BG):
            return None
        row.append(g[r0][c])
    runs = []
    c = 0
    while c < TRACK_C1:
        if row[c] == BAR_COLOR:
            s = c
            while c < TRACK_C1 and row[c] == BAR_COLOR:
                c += 1
            runs.append((s, c - s))
        else:
            c += 1
    if len(runs) != 1 or runs[0][1] != BAR_W:
        return None
    return runs[0][0]


def _pred(g):
    """行54-55 列0-37 这 76 个像素点完之后的颜色；读不出来返回 None。"""
    if not _single_band(g):
        return None
    p = _bar_left(g)
    if p is None or p > MAX_LEFT:
        return None
    q = p + STRIDE
    return {(r, c): (BAR_COLOR if q <= c < q + BAR_W else TRACK_BG)
            for r in TRACK_ROWS for c in range(TRACK_C1)}


def assert_(prev, action, nxt, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    pred = _pred(prev)
    if pred is None:
        return "NA"
    for r in range(min(MAP_ROWS, len(prev))):
        row_p, row_n = prev[r], nxt[r]
        for c in range(MAP_COLS):
            if row_n[c] != pred.get((r, c), row_p[c]):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not clicked_card(prev, action, CARD_COLOR):
        return None
    return _pred(prev)
