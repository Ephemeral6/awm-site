/-
# UnionOpen —— 「模型不描述的机关格，走过去的时候都开着」（↔ `rule/说了但不进模型/union_open.py`）　**身份：不进模型**

**为什么不进模型**：第 4、5 关那几种机关（爪子与它夹的杆、十字件、方框……）会让一些格时开时关（U）。
模型没有这几种机关的对象，说不出它们什么时候开关；每关那一层在这些格上取整关并集——**一律当开着**。

**这一条是那个口径在语料上的检验**，固定打两个数：

    论域   方向键、目标格在这一关的 U 里、且不是出口：316 条
    驳倒   其中目标格此刻走不进的：0 条（下面的定理）

没被驳倒不等于成立：它只对这批语料里**真的走过去的那几次**成立。
-/

import Obs.Replay

set_option autoImplicit false
set_option maxRecDepth 200000

namespace Game
namespace Assume

open Replay

/-- 这一步是方向键，目标格在这一关的 U 里（不在 keep 里）、不是出口：给出目标格。 -/
def uTarget (s : Step) : Option Cell :=
  match s.act with
  | .move d =>
    match (frameAt s.pre).me.move d with
    | some t => if s.kind == 0 && !(t.inMask (boardAt s.lvl).keep) && !(t.inMask (boardAt s.lvl).goal)
                then some t else none
    | none => none
  | _ => none

def uScope : List Step := steps.filter (fun s => (uTarget s).isSome)

theorem unionOpen_scope : uScope.length = 316 := by decide +kernel

/-- **驳倒 0 次**：论域里每一步，目标格此刻都走得进。 -/
theorem unionOpen_holds :
    uScope.all (fun s => match uTarget s with
                         | some t => t.inMask (frameAt s.pre).opn
                         | none   => true) = true := by decide +kernel

#print axioms unionOpen_scope
#print axioms unionOpen_holds

end Assume
end Game
