/-
# ResetToStart —— 「RESET 把局面放回开局」（↔ `rule/说了但不进模型/reset_to_start.py`）　**身份：不进模型**

**为什么不进模型**：「这一关的开局长什么样」不是当前状态的函数，是**历史**，一帧上读不出来。
硬塞一个「开局」字段进世界，就是给模型加一位帧上读不出来的信息。所以写成假设：

    假设：重来一次把局面放回这一关的开局（整局重开放回第 0 关的开局）。

两处给它被驳倒的机会：
  1. 这里：每一次 RESET 之后的那一帧，和开局那一帧（核对口径下）读成同一个样子；
  2. `Proof/Levels.lean`：第 5 关每一段都**从开局起算**往下走，假设错了那一段的第一帧就对不上。
**没红不构成证明**，这句话原样留在这里。

    论域   RESET：10 条
    驳倒   0 条（下面的定理）
-/

import Obs.Replay

set_option autoImplicit false
set_option maxRecDepth 200000

namespace Game
namespace Assume

open Replay

/-- （RESET 那一行的 seq，它该回到的那个开局所在那一行的 seq）。开局 = 进这一关时的第一帧，
    由导出器按「这一段（guid）里这一关的第一行」读出来；整局重开取第 0 关第一次的开局。 -/
def resetPairs : List (Nat × Nat) := [(42, 1), (57, 1), (662, 1), (1167, 1), (1627, 1), (2088, 1946), (2226, 1946), (2279, 1946), (2345, 1946), (2468, 1946)]

theorem reset_scope : resetPairs.length = 10 := by decide

/-- **驳倒 0 次**：每一次 RESET 之后的那一帧，和开局那一帧读成同一个样子。 -/
theorem reset_holds :
    resetPairs.all (fun (r, s) => seenEq (boardAt (bySeq r).lvl) (frameAt (bySeq r).post) (frameAt (bySeq s).pre)) = true := by
  decide +kernel

#print axioms reset_scope
#print axioms reset_holds

end Assume
end Game
