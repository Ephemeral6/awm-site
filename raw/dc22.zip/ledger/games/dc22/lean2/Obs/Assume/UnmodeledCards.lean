/-
# UnmodeledCards —— 「模型不描述的那几种卡，不碰模型推进的那几样」（↔ `rule/说了但不进模型/unmodeled_cards_leave_model_alone.py`）　**身份：不进模型**

**为什么不进模型**：第 4 关推爪子的色 9 / 10 箭头与合爪子的色 8 卡、第 5 关推方框的亮菱形、灭着的菱形心……
模型没有它们要读的对象（爪子、十字件、方框）。模型里点它们是**空操作**。

这一条检验「对模型推进的那几样（玩家、垫子、相变格、臂、大卡）来说，它们确实是空操作」：

    论域   点中一张大卡而它不归任何一条建了模的规则管（没有这种颜色的相变格、没有归它管的枢纽、不是色 6），
           或者点中一张小卡（箭头、菱形）：239 条
    驳倒   其中逐条判对不上的：0 条

Python 那一条的论域按**这一帧**的相变格判，这里按**这一关的版面**判，两边条数各报各的（Python 239 条）。
-/

import Obs.Corpus

set_option autoImplicit false
set_option maxRecDepth 200000

namespace Game
namespace Assume

open Replay

def unmodeled (s : Step) : Bool :=
  s.kind == 0 &&
  match s.act with
  | .press (.card k big) =>
    !big || (bridgeMask (boardAt s.lvl).bridges k == 0 && !((boardAt s.lvl).hubs.any (fun h => h.card == k)) && k != 6
             && !(k == 11 && !(boardAt s.lvl).tracks.isEmpty) && !(k == 2 && !(boardAt s.lvl).bands.isEmpty))
  | _ => false

def unmodScope : List Step := steps.filter unmodeled

theorem unmodeled_scope : unmodScope.length = 239 := by decide +kernel

/-- **驳倒 0 次**：这些点击，模型说「什么都不变」，现实里模型推进的那几样也确实没变。 -/
theorem unmodeled_holds : unmodScope.all Corpus.ok = true := by decide +kernel

#print axioms unmodeled_scope
#print axioms unmodeled_holds

end Assume
end Game
