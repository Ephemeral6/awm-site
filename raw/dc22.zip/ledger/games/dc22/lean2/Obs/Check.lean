/-
# Check —— 判据层：两把尺子，**0 条定理**（尺子不自证，它只是被用）

    agrees   **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比
    traceOk  **一整条路**对不对：从开局起**带着自己算出来的状态**往下走，逐帧比

两把尺子分量差得很远：`agrees` 每一步都被观测拉回正轨，`traceOk` 只有开局那一帧是观测给的。

## 看得见的那部分：`Seen`

玩家在哪、keep 里哪些格走得进、露着的垫子（**按集合比**，帧上读不出先后）、面板上大卡的颜色（集合）。
**不含两位隐藏量**（`under` 脚下的垫子、`rise` 带子的方向）——它们帧上读不出来。
所以逐条那一层判一条转移时，前一帧对应的是**一组**世界（5 × 2 = 10 种可能，一条纤维）：有一个对上就算对上。
-/

import Step

set_option autoImplicit false

namespace Game

structure Seen where
  me    : Cell
  opn   : Nat
  pads  : List Pad
  cards : List Nat
deriving DecidableEq, Repr

def seenOf (w : World) : Seen := ⟨w.me, w.opn, w.pads, w.cards⟩

/-- 两串颜色当集合相等。 -/
def natSetEq (a b : List Nat) : Bool := a.all (fun x => b.contains x) && b.all (fun x => a.contains x)

/-- 核对口径下两份观测一样：U 里的格不比（模型不描述那几种机关）。 -/
def seenEq (b : Board) (x y : Seen) : Bool :=
  x.me == y.me && (x.opn &&& b.keep) == (y.opn &&& b.keep) && padsEq x.pads y.pads && natSetEq x.cards y.cards

/-- 从一份观测搭一个世界，两位隐藏量由调用方给（它们帧上读不出来）。 -/
def worldOf (o : Seen) (u : Option Nat) (r : Bool) : World := ⟨o.me, o.opn, o.pads, o.cards, u, r⟩

/-- 两位隐藏量的全部可能：脚下（不是垫子，或四对之一）× 带子下一下的方向。 -/
def fibers : List (Option Nat × Bool) :=
  [none, some 0, some 1, some 2, some 3].flatMap (fun u => [(u, true), (u, false)])

/-- 一条转移，隐藏量取定一种可能：模型算一步，和看到的比。`won` = 现实里这一步过了关。 -/
def agreesAt (b : Board) (o : Seen) (a : Act) (o' : Seen) (won : Bool) (f : Option Nat × Bool) : Bool :=
  match step b (worldOf o f.1 f.2) a with
  | .won    => won
  | .ok w'  => !won && seenEq b (seenOf w') o'

/-- **逐条**：纤维里有一个对上就算对上。 -/
def agrees (b : Board) (o : Seen) (a : Act) (o' : Seen) (won : Bool) : Bool :=
  fibers.any (agreesAt b o a o' won)

/-- **每关**：从 `w` 出发沿 `play` 走，下一轮喂进去的是模型自己算出来的 `w'`，不是观测到的那一帧。 -/
def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, []             => true
  | w, (a, o) :: rest =>
    match step b w a with
    | .ok w' => seenEq b (seenOf w') o && traceOk b w' rest
    | .won   => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，它不是定理。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [],             _ => none
  | w, (a, o) :: rest, i =>
    match step b w a with
    | .ok w' => if seenEq b (seenOf w') o then firstSplit b w' rest (i + 1) else some i
    | .won   => some i

/-- 照着一串动作走，中途赢过没有。 -/
def everWon (b : Board) : World → List Act → Bool
  | _, []        => false
  | w, a :: rest =>
    match step b w a with
    | .won   => true
    | .ok w' => everWon b w' rest

/-- **这个局面走得通**：有一串动作，照着走中途赢过。
    动作里**没有 RESET**：模型不描述重来。所以「走不通」若有，说的是「不经过 RESET 就赢不了」。 -/
def Winnable (b : Board) (w : World) : Prop := ∃ as : List Act, everWon b w as = true

/-- **这个局面走不通**（不经过 RESET）。 -/
def Unsolvable (b : Board) (w : World) : Prop := ∀ as : List Act, everWon b w as = false

end Game
