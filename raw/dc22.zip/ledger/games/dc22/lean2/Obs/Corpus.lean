/-
# Corpus —— 逐条：模型面对**每一条**真实转移（自动生成；生成器 `lean2/export_corpus.py`）

    用例     除 RESET 以外的每一行，共 2654 条（其中过关那一步 22 条：模型该说「赢了」）
    判法     从观测到的那一帧起算一步，和看到的下一帧比（`agrees`）；脚下那块垫子帧上读不出，取遍纤维
    RESET    10 条不在这里：模型不描述重来之后是哪一帧。它们由 `Obs/Assume/ResetToStart.lean` 逐条核

按关各一条，免得一条大定理一红说不清红在哪一关。
-/

import Obs.Replay

set_option autoImplicit false
set_option maxRecDepth 200000

namespace Game
namespace Corpus

open Replay

/-- 逐条那一层的用例：除 RESET 以外的每一行。 -/
def cases : List Step := steps.filter (fun s => s.kind != 2)

/-- 一条用例对不对得上。 -/
def ok (s : Step) : Bool := agrees (boardAt s.lvl) (frameAt s.pre) s.act (frameAt s.post) (s.kind == 1)

def casesAt (lv : Nat) : List Step := cases.filter (fun s => s.lvl == lv)

theorem cases_len : cases.length = 2654 := by decide +kernel

#print axioms cases_len

theorem L0_cases_len : (casesAt 0).length = 220 := by decide +kernel
/-- **第 0 关的 220 条真实转移，模型条条对上。** -/
theorem L0_all_agree : (casesAt 0).all ok = true := by decide +kernel

#print axioms L0_cases_len
#print axioms L0_all_agree

theorem L1_cases_len : (casesAt 1).length = 215 := by decide +kernel
/-- **第 1 关的 215 条真实转移，模型条条对上。** -/
theorem L1_all_agree : (casesAt 1).all ok = true := by decide +kernel

#print axioms L1_cases_len
#print axioms L1_all_agree

theorem L2_cases_len : (casesAt 2).length = 186 := by decide +kernel
/-- **第 2 关的 186 条真实转移，模型条条对上。** -/
theorem L2_all_agree : (casesAt 2).all ok = true := by decide +kernel

#print axioms L2_cases_len
#print axioms L2_all_agree

theorem L3_cases_len : (casesAt 3).length = 338 := by decide +kernel
/-- **第 3 关的 338 条真实转移，模型条条对上。** -/
theorem L3_all_agree : (casesAt 3).all ok = true := by decide +kernel

#print axioms L3_cases_len
#print axioms L3_all_agree

theorem L4_cases_len : (casesAt 4).length = 461 := by decide +kernel
/-- **第 4 关的 461 条真实转移，模型条条对上。** -/
theorem L4_all_agree : (casesAt 4).all ok = true := by decide +kernel

#print axioms L4_cases_len
#print axioms L4_all_agree

theorem L5_cases_len : (casesAt 5).length = 1234 := by decide +kernel
/-- **第 5 关的 1234 条真实转移，模型条条对上。** -/
theorem L5_all_agree : (casesAt 5).all ok = true := by decide +kernel

#print axioms L5_cases_len
#print axioms L5_all_agree

end Corpus
end Game
