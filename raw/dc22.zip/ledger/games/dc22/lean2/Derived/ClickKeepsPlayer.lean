/-
# ClickKeepsPlayer —— 点卡不挪玩家，色 6 的大卡除外（↔ `rule/世界怎么回应/click_keeps_player.py`）　**身份：推论**

Python 那条是一句独立的断言；在模型里它是**推出来的**：`press` 里改 `me` 的只有 `teleport` 一处，
而 `teleport` 只在点色 6 的卡时才进得去。相变、转臂、换花色、点空白——四个定义里没有一处碰 `me`。
-/

import Step

set_option autoImplicit false

namespace Game

theorem phaseFlip_me (b : Board) (k : Nat) (w : World) : (phaseFlip b k w).me = w.me := by
  unfold phaseFlip; split <;> rfl

theorem Hub.turn_me (h : Hub) (w : World) : (h.turn w).me = w.me := by
  unfold Hub.turn; split <;> rfl

theorem hubTurn_me (b : Board) (k : Nat) (w : World) : (hubTurn b k w).me = w.me := by
  unfold hubTurn
  generalize b.hubs = hs
  induction hs generalizing w with
  | nil => rfl
  | cons h t ih =>
    simp only [List.foldl]
    rw [ih]
    split
    · exact Hub.turn_me h w
    · rfl

theorem iconPress_me (b : Board) (w : World) : (iconPress b w).me = w.me := by
  unfold iconPress; split
  · rfl
  · split <;> rfl

theorem barsShift_me (b : Board) (w : World) : (barsShift b w).me = w.me := by
  unfold barsShift; split <;> rfl

theorem bandsNotch_me (b : Board) (w : World) : (bandsNotch b w).me = w.me := by
  unfold bandsNotch; split <;> rfl

/-- **点任何卡（色 6 的大卡除外）、点小图标、点空白，玩家都不动。** -/
theorem press_keeps_me (b : Board) (w : World) (p : Press)
    (h6 : ∀ big, p ≠ .card 6 big) : (press b w p).me = w.me := by
  cases p with
  | blank => rfl
  | icon => exact iconPress_me b w
  | card k big =>
    simp only [press]
    split
    · have hk : k ≠ 6 := fun e => h6 big (by rw [e])
      have : (k == 6) = false := by simp [hk]
      simp only [cardEffect, this, Bool.false_eq_true, ↓reduceIte, id_eq]
      have e1 : ((if k == 2 then bandsNotch b else id) (hubTurn b k (phaseFlip b k w))).me = w.me := by
        split
        · rw [bandsNotch_me, hubTurn_me, phaseFlip_me]
        · simp only [id_eq]; rw [hubTurn_me, phaseFlip_me]
      split
      · rw [barsShift_me, e1]
      · exact e1
    · rfl

/-- 同一句话落到 `step` 上：一步点击之后，玩家还在原来那一格。 -/
theorem step_press_keeps_me (b : Board) (w w' : World) (p : Press)
    (h6 : ∀ big, p ≠ .card 6 big) (h : step b w (.press p) = .ok w') : w'.me = w.me := by
  simp only [step] at h
  cases h
  exact press_keeps_me b w p h6

#print axioms phaseFlip_me
#print axioms Hub.turn_me
#print axioms hubTurn_me
#print axioms iconPress_me
#print axioms barsShift_me
#print axioms bandsNotch_me
#print axioms press_keeps_me
#print axioms step_press_keeps_me

end Game
