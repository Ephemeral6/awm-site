/-
# ClickTouchesOwnCells —— 点一张卡，只动它自己管的格（↔ `rule/世界怎么回应/click_touches_own_cells.py`）　**身份：推论**

Python 那条说：点一张卡，「走得进」变了的格只可能是这张卡自己管的那几格
（色 k 卡 → 色 k 相变格；枢纽卡 → 臂区与它的转置位置；色 11 卡 → 轨道；色 2 卡 → 带子），外加模型不描述的机关格。
在模型里后一半根本不出现（模型不改 U 里的格），前一半是**推出来的**——下面这条对任何一格、任何世界成立。

「自己管的格」写成 `ownBit`：一个布尔函数，**不是一张表**，它从版面上的相变格、枢纽、轨道、带子算出来。
-/

import Step

set_option autoImplicit false

namespace Game

/-- 第 i 位是不是色 k 的卡自己管的格。 -/
def ownBit (b : Board) (k i : Nat) : Bool :=
  (Nat.testBit (bridgeMask b.bridges k) i ||
   b.hubs.any (fun h => h.card == k && h.zone.any (fun c => c.idx == i || (h.reflect c).idx == i))) ||
  ((k == 11 && b.tracks.any (fun t => Nat.testBit (trackMask t) i)) ||
   (k == 2 && b.bands.any (fun x => Nat.testBit (bandMask x.1 x.2.1) i)))

/-- 一串「每一步都不碰第 i 位」的折叠，第 i 位不变。 -/
theorem foldl_keep {α : Type} (l : List α) (g : Nat → α → Nat) (o i : Nat)
    (h : ∀ a ∈ l, ∀ x, Nat.testBit (g x a) i = Nat.testBit x i) :
    Nat.testBit (l.foldl g o) i = Nat.testBit o i := by
  induction l generalizing o with
  | nil => rfl
  | cons a t ih =>
    simp only [List.foldl]
    rw [ih _ (fun a' ha' => h a' (List.mem_cons_of_mem _ ha')), h a List.mem_cons_self]

theorem setTrack_bit (old o i : Nat) (t : Nat × Nat × Nat) (h : Nat.testBit (trackMask t) i = false) :
    Nat.testBit (setTrack old o t) i = Nat.testBit o i := by
  simp [setTrack, Nat.testBit_or, Nat.testBit_xor, Nat.testBit_and, h]

theorem setBand_bit (s o i : Nat) (x : Nat × Nat × Bool) (h : Nat.testBit (bandMask x.1 x.2.1) i = false) :
    Nat.testBit (setBand s o x) i = Nat.testBit o i := by
  simp [setBand, Nat.testBit_or, Nat.testBit_xor, Nat.testBit_and, h]

theorem barsShift_bit (b : Board) (w : World) (i : Nat)
    (h : b.tracks.any (fun t => Nat.testBit (trackMask t) i) = false) :
    Nat.testBit (barsShift b w).opn i = Nat.testBit w.opn i := by
  unfold barsShift
  split
  · rfl
  · simp only
    rw [List.any_eq_false] at h
    apply foldl_keep
    intro t ht x
    exact setTrack_bit _ _ _ t (by simpa using h t ht)

theorem bandsNotch_bit (b : Board) (w : World) (i : Nat)
    (h : b.bands.any (fun x => Nat.testBit (bandMask x.1 x.2.1) i) = false) :
    Nat.testBit (bandsNotch b w).opn i = Nat.testBit w.opn i := by
  rw [List.any_eq_false] at h
  unfold bandsNotch
  split
  · rfl
  · simp only [bandsNotchFrom]
    apply foldl_keep
    intro x hx y
    exact setBand_bit _ _ _ x (by simpa using h x hx)

theorem bit_testBit (c : Cell) (i : Nat) : Nat.testBit c.bit i = decide (c.idx = i) := by
  unfold Cell.bit
  rw [Nat.shiftLeft_eq, Nat.one_mul, Nat.testBit_two_pow]

/-- 一串或上去的位，只要每一位都不是第 i 位，第 i 位就不变。 -/
theorem foldl_or_bit (l : List Cell) (f : Cell → Bool) (g : Cell → Nat) (acc i : Nat)
    (h : ∀ c ∈ l, Nat.testBit (g c) i = false) :
    Nat.testBit (l.foldl (fun m c => if f c then m ||| g c else m) acc) i = Nat.testBit acc i := by
  induction l generalizing acc with
  | nil => rfl
  | cons c t ih =>
    simp only [List.foldl]
    rw [ih _ (fun x hx => h x (List.mem_cons_of_mem _ hx))]
    split
    · rw [Nat.testBit_or, h c List.mem_cons_self, Bool.or_false]
    · rfl

theorem zoneMask_bit (h : Hub) (i : Nat) (hz : ∀ c ∈ h.zone, c.idx ≠ i) :
    Nat.testBit h.zoneMask i = false := by
  unfold Hub.zoneMask
  have := foldl_or_bit h.zone (fun _ => true) Cell.bit 0 i
    (fun c hc => by rw [bit_testBit]; simp [hz c hc])
  simp only [ite_true] at this
  rw [this]
  simp

theorem flipped_bit (h : Hub) (opn i : Nat) (hr : ∀ c ∈ h.zone, (h.reflect c).idx ≠ i) :
    Nat.testBit (h.flipped opn) i = false := by
  unfold Hub.flipped
  rw [foldl_or_bit h.zone (fun c => c.inMask opn) (fun c => (h.reflect c).bit) 0 i
    (fun c hc => by rw [bit_testBit]; simp [hr c hc])]
  simp

theorem Hub.turn_bit (h : Hub) (w : World) (i : Nat)
    (hz : ∀ c ∈ h.zone, c.idx ≠ i) (hr : ∀ c ∈ h.zone, (h.reflect c).idx ≠ i) :
    Nat.testBit (h.turn w).opn i = Nat.testBit w.opn i := by
  unfold Hub.turn
  split
  · rfl
  · simp only
    rw [Nat.testBit_or, flipped_bit h w.opn i hr, Bool.or_false, Nat.testBit_xor, Nat.testBit_and,
      zoneMask_bit h i hz, Bool.and_false, Bool.xor_false]

theorem hubTurn_bit (b : Board) (k : Nat) (w : World) (i : Nat)
    (hown : b.hubs.any (fun h => h.card == k && h.zone.any (fun c => c.idx == i || (h.reflect c).idx == i)) = false) :
    Nat.testBit (hubTurn b k w).opn i = Nat.testBit w.opn i := by
  unfold hubTurn
  revert hown
  generalize b.hubs = hs
  intro hown
  induction hs generalizing w with
  | nil => rfl
  | cons h t ih =>
    simp only [List.any_cons, Bool.or_eq_false_iff] at hown
    simp only [List.foldl]
    rw [ih _ hown.2]
    split
    · rename_i hk
      have hk' : (h.card == k) = true := hk
      have hzone := hown.1
      rw [hk', Bool.true_and, List.any_eq_false] at hzone
      apply Hub.turn_bit
      · intro c hc e
        have := hzone c hc
        simp [e] at this
      · intro c hc e
        have := hzone c hc
        simp [e] at this
    · rfl

theorem phaseFlip_bit (b : Board) (k : Nat) (w : World) (i : Nat)
    (hm : Nat.testBit (bridgeMask b.bridges k) i = false) :
    Nat.testBit (phaseFlip b k w).opn i = Nat.testBit w.opn i := by
  unfold phaseFlip
  split
  · rfl
  · simp only
    rw [Nat.testBit_xor, hm, Bool.xor_false]

theorem teleport_opn (w : World) : (teleport w).opn = w.opn := by
  unfold teleport
  split
  · rfl
  · split <;> rfl

theorem iconPress_opn (b : Board) (w : World) : (iconPress b w).opn = w.opn := by
  unfold iconPress
  split
  · rfl
  · split <;> rfl

/-- **点一下，第 i 格走不走得进变不变**：只要第 i 格不是被点的那张卡自己管的格，它就不变。 -/
theorem press_frame (b : Board) (w : World) (p : Press) (i : Nat)
    (hi : ∀ k big, p = .card k big → ownBit b k i = false) :
    Nat.testBit (press b w p).opn i = Nat.testBit w.opn i := by
  cases p with
  | blank => rfl
  | icon => simp only [press]; rw [iconPress_opn]
  | card k big =>
    have hk := hi k big rfl
    unfold ownBit at hk
    simp only [Bool.or_eq_false_iff] at hk
    obtain ⟨⟨hb, hh⟩, ht, hd⟩ := hk
    simp only [press]
    split
    · have e1 : Nat.testBit (hubTurn b k (phaseFlip b k w)).opn i = Nat.testBit w.opn i := by
        rw [hubTurn_bit b k _ i hh, phaseFlip_bit b k w i hb]
      have e2 : Nat.testBit ((if k == 2 then bandsNotch b else id) (hubTurn b k (phaseFlip b k w))).opn i
          = Nat.testBit w.opn i := by
        split
        · rename_i h2
          rw [h2, Bool.true_and] at hd
          rw [bandsNotch_bit b _ i hd, e1]
        · exact e1
      have e3 : Nat.testBit ((if k == 11 then barsShift b else id)
          ((if k == 2 then bandsNotch b else id) (hubTurn b k (phaseFlip b k w)))).opn i = Nat.testBit w.opn i := by
        split
        · rename_i h11
          rw [h11, Bool.true_and] at ht
          rw [barsShift_bit b _ i ht, e2]
        · exact e2
      simp only [cardEffect]
      split
      · rw [teleport_opn, e3]
      · exact e3
    · rfl

#print axioms foldl_keep
#print axioms setTrack_bit
#print axioms setBand_bit
#print axioms barsShift_bit
#print axioms bandsNotch_bit
#print axioms bit_testBit
#print axioms foldl_or_bit
#print axioms zoneMask_bit
#print axioms flipped_bit
#print axioms Hub.turn_bit
#print axioms hubTurn_bit
#print axioms phaseFlip_bit
#print axioms teleport_opn
#print axioms iconPress_opn
#print axioms press_frame

end Game
