/-
# MoveKeepsMap —— 走一步不碰版面（↔ `rule/世界怎么回应/move_keeps_map.py`）　**身份：推论**

Python 那条说：走一步（没过关），除了玩家离开和走进的那两格，地图上走得进的格、露着的垫子、相变格、臂，一格都不变。
在模型里这不是一条独立的规则，它是**架构推出来的**：

* 相变格在哪、臂区在哪、出口、图标在哪，都住在 `Board` 里，`step` 碰不到——**表示不出来**，不用证；
* 此刻走得进的格（`opn`）：`move` / `walk` / `pickup` 三个定义里没有一处改它——下面第一条；
* 露着的垫子：只可能在离开的那一格多一块、在走进的那一格少一块——下面第二条。
-/

import Step

set_option autoImplicit false

namespace Game

theorem walk_opn (w : World) (t : Cell) : (walk w t).opn = w.opn := rfl

theorem pickup_opn (b : Board) (w : World) : (pickup b w).opn = w.opn := by
  unfold pickup
  split
  · split <;> rfl
  · rfl

theorem pickup_pads (b : Board) (w : World) : (pickup b w).pads = w.pads := by
  unfold pickup
  split
  · split <;> rfl
  · rfl

/-- **走一步，走得进的格一格不变。** -/
theorem move_keeps_opn (b : Board) (w w' : World) (d : Dir)
    (h : step b w (.move d) = .ok w') : w'.opn = w.opn := by
  simp only [step] at h
  split at h
  · cases h
  · cases h; rfl
  · cases h; rw [pickup_opn, walk_opn]

/-- **走一步，露着的垫子只在那两格上变**：走完之后露着的一块垫子，要么走之前就露着，要么就在玩家离开的那一格上。 -/
theorem move_pads_local (b : Board) (w w' : World) (d : Dir)
    (h : step b w (.move d) = .ok w') : ∀ p ∈ w'.pads, p ∈ w.pads ∨ p.cell = w.me := by
  simp only [step] at h
  split at h
  · cases h
  · cases h; intro p hp; exact Or.inl hp
  · rename_i t _
    cases h
    intro p hp
    rw [pickup_pads] at hp
    simp only [walk] at hp
    split at hp
    · rcases List.mem_cons.mp hp with h1 | h1
      · exact Or.inr (by rw [h1])
      · exact Or.inl (List.mem_filter.mp h1).1
    · exact Or.inl (List.mem_filter.mp hp).1

#print axioms walk_opn
#print axioms pickup_opn
#print axioms pickup_pads
#print axioms move_keeps_opn
#print axioms move_pads_local

end Game
