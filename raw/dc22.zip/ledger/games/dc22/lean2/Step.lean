/-
# Step —— 一步怎么走：**只做分发，0 条定理**

方向键交给 `move`（走过去之后脚下与图标归 `walk` / `pickup`）；点一下交给 `press`。
点色 k 的大卡、而面板上确实有这张卡：依次过相变、枢纽、带子、横条、换位五条规则——
每条只在归它管的时候改东西（没有色 k 的相变格就不翻、没有归色 k 管的枢纽就不转、
k ≠ 2 不动带子、k ≠ 11 不动横条、k ≠ 6 不换位）。
-/

import Obj.Frame.Act
import Rule.Move.Move
import Rule.Respond.Under
import Rule.Respond.Pickup
import Rule.Respond.PhaseFlip
import Rule.Respond.HubTranspose
import Rule.Respond.Teleport
import Rule.Respond.IconCyclesPad
import Rule.Respond.ClickNothing
import Rule.Respond.BarsShift
import Rule.Respond.BandsNotch

namespace Game

/-- 点色 k 的大卡时依次过的几条规则。每条只在归它管的时候改东西。 -/
def cardEffect (b : Board) (k : Nat) (w : World) : World :=
  (if k == 6 then teleport else id)
    ((if k == 11 then barsShift b else id)
      ((if k == 2 then bandsNotch b else id) (hubTurn b k (phaseFlip b k w))))

def press (b : Board) (w : World) : Press → World
  | .blank      => clickNothing w
  | .icon       => iconPress b w
  | .card k big => if big && w.cards.contains k then cardEffect b k w else w

def step (b : Board) (w : World) : Act → Res
  | .move d  => match move b w d with
                | .won    => .won
                | .stay   => .ok w
                | .goTo t => .ok (pickup b (walk w t))
  | .press p => .ok (press b w p)

end Game
