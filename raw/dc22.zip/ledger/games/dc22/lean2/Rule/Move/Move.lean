/-
# Move —— 方向键：玩家落在哪（↔ `rule/一步怎么走/move.py`）　**身份：定义**

目标格是出口 ⇒ 赢；目标格此刻走得进 ⇒ 走过去；否则原地不动。
「走得进」完全由 `World.opn` 说——什么格走得进是对象层的事，这里不再判一遍。
走过去之后脚下、垫子、图标怎么变，归 `Rule/Respond/Under.lean` 与 `Rule/Respond/Pickup.lean`。
-/

import Obj.Frame.World
import Rule.Win.ReachGoal

namespace Game

/-- 方向键的三种结局。 -/
inductive Went where
  | stay
  | goTo (t : Cell)
  | won
deriving DecidableEq, Repr

def move (b : Board) (w : World) (d : Dir) : Went :=
  match w.me.move d with
  | none   => .stay
  | some t =>
    if isGoal b t then .won
    else if t.inMask w.opn then .goTo t
    else .stay

end Game
