/-
# BarsShift —— 点色 11 的卡：横条右移一格，到头绕回（↔ `rule/世界怎么回应/bars_shift.py`）　**身份：定义**

轨道是墙、横条盖着的格走得进，所以一行轨道上走得进的格就是横条。读法：
一段连着的走得进的格，3 格 = 一条横条，4–6 格 = 两条叠在一起（一头一尾）；更长的拆不唯一，丢掉不读。

每条横条右移一格，左端已在最后一档（最右列 − 2）的绕回最左一档。
**玩家站在轨道上、转完之后他那一格不再被横条盖着 ⇒ 整个点击被拒**，所有轨道一格不动（卡不搬玩家脚下的地）。

写新的一行时只动这条轨道的格（`&&& 轨道掩码`）：别处一位都碰不到——这一句在 `Derived/ClickTouchesOwnCells.lean` 里证。
-/

import Obj.Frame.Board
import Obj.Frame.World

set_option autoImplicit false

namespace Game

/-- 一行里、按列表里的列依次看，连着走得进的段：（起点列, 长度）。 -/
def runsFrom (opn r : Nat) : List Nat → Nat → Nat → List (Nat × Nat)
  | [],      s, l => if l > 0 then [(s, l)] else []
  | c :: cs, s, l =>
    if (Cell.mk r c).inMask opn then
      (if l > 0 then runsFrom opn r cs s (l + 1) else runsFrom opn r cs c 1)
    else
      (if l > 0 then (s, l) :: runsFrom opn r cs 0 0 else runsFrom opn r cs 0 0)

/-- 段 → 横条的左端列。 -/
def barsOf (rs : List (Nat × Nat)) : List Nat :=
  rs.flatMap (fun p => if p.2 == 3 then [p.1] else if 3 < p.2 && p.2 ≤ 6 then [p.1, p.1 + p.2 - 3] else [])

/-- 一条轨道的掩码。 -/
def trackMask (t : Nat × Nat × Nat) : Nat := rangeMask t.1 t.2.1 (t.2.2 + 1 - t.2.1)

/-- 这条轨道转一档之后，横条盖着的格。 -/
def trackAfter (opn : Nat) (t : Nat × Nat × Nat) : Nat :=
  (barsOf (runsFrom opn t.1 (List.range' t.2.1 (t.2.2 + 1 - t.2.1)) 0 0)).foldl
    (fun m b => m ||| rangeMask t.1 (if b == t.2.2 - 2 then t.2.1 else b + 1) 3) 0

/-- 玩家站在这条轨道上、而转完之后他那一格不再被横条盖着。 -/
def strands (w : World) (t : Nat × Nat × Nat) : Bool :=
  w.me.inMask (trackMask t) && !(w.me.inMask (trackAfter w.opn t))

/-- 把一条轨道换成它转完之后的样子（只动这条轨道的格）。 -/
def setTrack (old : Nat) (o : Nat) (t : Nat × Nat × Nat) : Nat :=
  (o ^^^ (o &&& trackMask t)) ||| (trackAfter old t &&& trackMask t)

def barsShift (b : Board) (w : World) : World :=
  if b.tracks.any (strands w) then w
  else { w with opn := b.tracks.foldl (setTrack w.opn) w.opn }

end Game
