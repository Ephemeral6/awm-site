/-
# Under —— 玩家脚下被盖住的那块垫子（↔ `rule/世界怎么回应/under_revealed.py`）　**身份：定义**

走进一块露着的垫子：它从露着的垫子里消失，记成 `under`；
走开：`under` 里记着的那块垫子回到原格，露出来。走到不是垫子的格上，`under` 清空。

这是这一局唯一的隐藏量。它不在帧上，所以只能这样沿着历史推进——
单看一帧，玩家脚下是不是垫子、是哪一对，**读不出来**。
-/

import Obj.Frame.World

namespace Game

/-- 玩家从原格走到 `t`。 -/
def walk (w : World) (t : Cell) : World :=
  { w with
    me    := t
    pads  := (match w.under with
              | some k => ⟨w.me, k⟩ :: dropPad w.pads t
              | none   => dropPad w.pads t)
    under := padAt w.pads t }

end Game
