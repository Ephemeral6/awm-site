/-
# HubTranspose —— 点枢纽那张卡：臂过主对角线转置（↔ `rule/世界怎么回应/hub_transpose.py`）　**身份：定义**

玩家不在臂区里 ⇒ 臂区里此刻走得进的每一格，翻到它的转置位置上；臂区别的格变成墙。
玩家站在臂上 ⇒ 臂一格不动。
（玩家在臂区里就一定在臂上：臂区里不是臂的格是墙，站不上去。）
-/

import Obj.Frame.Board
import Obj.Frame.World

namespace Game

/-- 臂区里此刻走得进的格，各自翻到转置位置之后的掩码。 -/
def Hub.flipped (h : Hub) (opn : Nat) : Nat :=
  h.zone.foldl (fun m c => if c.inMask opn then m ||| (h.reflect c).bit else m) 0

/-- 一座枢纽转一次：先把臂区的位清掉（`opn ^^^ (opn &&& 臂区)`），再或上翻过去的臂。 -/
def Hub.turn (h : Hub) (w : World) : World :=
  if w.me.inMask h.zoneMask then w
  else { w with opn := (w.opn ^^^ (w.opn &&& h.zoneMask)) ||| h.flipped w.opn }

/-- 点色 k 的卡：归这张卡管的每一座枢纽各转一次。 -/
def hubTurn (b : Board) (k : Nat) (w : World) : World :=
  b.hubs.foldl (fun w h => if h.card == k then h.turn w else w) w

end Game
