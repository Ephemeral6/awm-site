/-
# ClickNothing —— 点在卡面以外：什么都不变（↔ `rule/世界怎么回应/click_nothing.py`）　**身份：定义**
-/

import Obj.Frame.World

namespace Game

def clickNothing (w : World) : World := w

end Game
