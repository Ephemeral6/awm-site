/-
# IconCyclesPad —— 点四色小图标：那一格垫子换下一对花色（↔ `rule/世界怎么回应/icon_cycles_pad.py`）　**身份：定义**

版面上记着那一格（`Board.cycSite`）。它露着 ⇒ 那块垫子的色对 +1（模 4）；
玩家正踩着它 ⇒ 被盖住的那块照样换（`under` +1）——帧上看不见，后面一换位就露馅。
-/

import Obj.Frame.Board
import Obj.Frame.World

namespace Game

def iconPress (b : Board) (w : World) : World :=
  match b.cycSite with
  | none   => w
  | some s =>
    if w.me == s then { w with under := w.under.map (fun k => (k + 1) % 4) }
    else { w with pads := w.pads.map (fun p => if p.cell == s then { p with pair := (p.pair + 1) % 4 } else p) }

end Game
