/-
# PhaseFlip —— 点色 K 的卡：色 K 的相变格翻相（↔ `rule/世界怎么回应/phase_flip.py`）　**身份：定义**

玩家不在色 K 的桥上 ⇒ 那一族每一格「走得进 ↔ 走不进」互换（一次异或）；
玩家站在色 K 的桥上 ⇒ 一格都不翻（卡不搬玩家脚下的地）。
-/

import Obj.Frame.Board
import Obj.Frame.World

namespace Game

def phaseFlip (b : Board) (k : Nat) (w : World) : World :=
  if w.me.inMask (bridgeMask b.bridges k) then w
  else { w with opn := w.opn ^^^ bridgeMask b.bridges k }

end Game
