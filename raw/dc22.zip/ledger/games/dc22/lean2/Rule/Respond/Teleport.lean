/-
# Teleport —— 点色 6 的卡：和同色对的垫子换位（↔ `rule/世界怎么回应/teleport.py`）　**身份：定义**

玩家脚下是色对 k 的垫子（`under = some k`），而露着一块色对 k 的垫子 ⇒ 玩家落到那一块上，
他原来那一格露出色对 k 的垫子；脚下仍然是色对 k（落点那一块）。
脚下不是垫子、或者露着的没有同色对的 ⇒ 什么都不发生。

「什么时候会换」取决于 `under`，而 `under` 帧上读不出来——Python 那条只能核「换了的话换得对不对」，
这里才说得出「会不会换」。
-/

import Obj.Frame.World

namespace Game

def teleport (w : World) : World :=
  match w.under with
  | none   => w
  | some k =>
    match w.pads.find? (fun p => p.pair == k) with
    | none   => w
    | some p => { w with me := p.cell, pads := ⟨w.me, k⟩ :: dropPad w.pads p.cell, under := some k }

end Game
