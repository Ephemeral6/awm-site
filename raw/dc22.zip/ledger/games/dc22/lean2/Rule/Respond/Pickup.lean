/-
# Pickup —— 走进图标：面板上多一张同色的卡（↔ `rule/世界怎么回应/pickup.py`）　**身份：定义**

玩家站进一枚图标盖着的格，而那种颜色的卡还不在面板上 ⇒ 多出那张卡。
图标在哪是版面；它被捡过没有，就是那种颜色的卡在不在 `cards` 里。
-/

import Obj.Frame.Board
import Obj.Frame.World

namespace Game

def pickup (b : Board) (w : World) : World :=
  match b.icons.find? (fun ic => ic.cells.contains w.me) with
  | some ic => if w.cards.contains ic.color then w else { w with cards := ic.color :: w.cards }
  | none    => w

end Game
