/-
# BandsNotch —— 点色 2 的卡：带子挪一档，到头折返（↔ `rule/世界怎么回应/bands_notch.py`）　**身份：定义**

一条带子 8 格；档位 s = 两端各有几格走得进（0..3），整条走得进是 4。
第一条带子的档位按下面走，别的带子跟着：反相的取 4 − s，同相的取 s。

    s = 0  ⇒ 涨到 1         s = 4  ⇒ 落到 3
    中间   ⇒ 朝 `rise` 那一边走一档

`rise` 是**隐藏量**：中间档两个方向帧上长得一模一样，只能沿历史记着——走到头之后才被逼着折返。
写新的样子时只动带子的格（`&&& 带子掩码`）。
-/

import Obj.Frame.Board
import Obj.Frame.World

set_option autoImplicit false

namespace Game

def bandMask (r c0 : Nat) : Nat := rangeMask r c0 8

/-- 档位 s 时走得进的格。 -/
def bandCells (r c0 s : Nat) : Nat :=
  if s ≥ 4 then bandMask r c0 else rangeMask r c0 s ||| rangeMask r (c0 + 8 - s) s

/-- 此刻的档位：整条走得进是 4，否则数左端连着走得进的格（至多 3）。 -/
def bandState (opn r c0 : Nat) : Nat :=
  if bandMask r c0 &&& opn == bandMask r c0 then 4
  else if (Cell.mk r c0).inMask opn then
    (if (Cell.mk r (c0 + 1)).inMask opn then (if (Cell.mk r (c0 + 2)).inMask opn then 3 else 2) else 1)
  else 0

/-- 第一条带子下一档是几。 -/
def nextBand (s : Nat) (rise : Bool) : Nat :=
  if s == 0 then 1 else if s ≥ 4 then 3 else if rise then s + 1 else s - 1

def setBand (s' : Nat) (o : Nat) (x : Nat × Nat × Bool) : Nat :=
  (o ^^^ (o &&& bandMask x.1 x.2.1)) ||| (bandCells x.1 x.2.1 (if x.2.2 then 4 - s' else s') &&& bandMask x.1 x.2.1)

/-- 从档位 s 挪到 s'：每条带子换成新样子；`rise` 记下这一下的方向（到头就折返）。 -/
def bandsNotchFrom (b : Board) (w : World) (s s' : Nat) : World :=
  { w with opn  := b.bands.foldl (setBand s') w.opn,
           rise := if s' ≥ 4 then false else if s' == 0 then true else decide (s' > s) }

def bandsNotch (b : Board) (w : World) : World :=
  match b.bands with
  | []              => w
  | (r, c0, _) :: _ => bandsNotchFrom b w (bandState w.opn r c0) (nextBand (bandState w.opn r c0) w.rise)

end Game
