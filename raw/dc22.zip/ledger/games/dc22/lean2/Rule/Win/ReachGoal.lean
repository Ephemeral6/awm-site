/-
# ReachGoal —— 什么算赢（↔ `rule/什么算赢/reach_goal.py`）　**身份：定义**

「赢」是一个**格的性质**：出口格。方向键走向出口格，这一步就过关。
这不是一件要去证的事——它就是赢的定义。
-/

import Obj.Frame.Board

namespace Game

/-- 这一格是不是出口。 -/
def isGoal (b : Board) (c : Cell) : Bool := c.inMask b.goal

end Game
