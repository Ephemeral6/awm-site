/-
# Reachable —— 一个局面做不做得了：骨架

`Winnable` / `Unsolvable` 定义在 `Obs/Check.lean`（每关那一层要用）。这一份放**唯一一条做归纳的定理**：

    找一个性质 Φ：每走一步都还成立，而且和「赢」直接矛盾。
    那么从满足 Φ 的局面出发，**无论怎么走、走多少步，都赢不了**。

它和盘面多大无关，不枚举任何状态、不搜索。

## 这一局用到它没有

**没有。** 六关在成绩单认证的那一段里全部通关，`Proof/Levels.lean` 里每一关都有 `_winnable`（见证是真人走过的路）。
没有一关需要「走不通」的定理，所以这里没有钥匙——**不为了填满这一栏去编一个局面**。

## 动作里没有 RESET

`Act` 只有方向键与点击；模型不描述重来。所以若有 `Unsolvable`，它说的是
「**不经过 RESET** 就赢不了」——这半句写在这里、`Obs/Check.lean`、页面三处。
-/

import Obs.Check
import Obj.Frame.World

set_option autoImplicit false

namespace Game

/-- **骨架**：不变量 ⇒ 走不通（不经过 RESET）。 -/
theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w w' a, P w → step b w a = .ok w' → P w')
    (hwin : ∀ w a, P w → step b w a ≠ .won) :
    ∀ w, P w → Unsolvable b w := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hs : step b w a with
    | won => exact absurd hs (hwin w a hp)
    | ok w' => exact ih w' (hkeep w w' a hp hs)

/-- 两句话不能同时成立：走得通与走不通。 -/
theorem not_both (b : Board) (w : World) (h1 : Winnable b w) (h2 : Unsolvable b w) : False := by
  obtain ⟨as, h⟩ := h1
  rw [h2 as] at h
  exact Bool.false_ne_true h

#print axioms unsolvable_of_invariant
#print axioms not_both

end Game
