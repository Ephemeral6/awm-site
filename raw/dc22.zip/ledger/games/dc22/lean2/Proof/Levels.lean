/-
# Levels —— 每一关一条定理（**自动生成，不要手改**；生成器 `lean2/export_levels.py`）

语料是成绩单认证的那一段（guid `fb6bb78d-d1fa-4023-b1df-ce85ac67a761`，seq 1628–2664）。每关：

    L<n>_len         这一段切出来恰好这么多步（切歪了会是空表，空表让下面那条平凡为真）
    L<n>_trace       沿真人走过的那条路，模型**每一帧都和观测对上**——只有开局那一帧是观测给的
    L<n>_winnable    这一关走得通（见证就是那条路，最后一脚是过关那一步）

第 5 关中途 RESET 过 5 次：每一段各有一条 `_trace`，都**从这一关的开局起算**——
那用到一条假设：**重来一次把局面放回这一关的开局**（不进模型，见 `Obs/Assume/ResetToStart.lean`）。
没红不构成证明，但那是这条假设在这批语料上唯一一次有机会被驳倒。

「走得通」只用最后那一段（重来之后到过关）；它不经过 RESET。

**开局口径**：看得见的照读；第 4、5 关模型不描述的机关格（U）按整关并集当开着；玩家开局不站在垫子上；带子开局往涨的方向走。
**核对口径**：U 里的格不比（`Board.keep`）。第 0–3 关 U 是空的——那四关是完整的模型。
-/

import Obs.Replay

set_option autoImplicit false
set_option maxRecDepth 200000

namespace Game
namespace Levels

open Replay


/-! ## 第 0 关（开局 = seq 1628 之前那一帧；RESET 0 次；过关在 seq 1651）-/

/-- 第 0 关第 0 段：seq 1628 起 23 步（开局到过关前一步）。 -/
def L0_0_play : List (Act × Seen) := playFrom 1628 23

theorem L0_0_len : L0_0_play.length = 23 := by decide

#eval match firstSplit (boardAt 0) (startAt 0 1628) L0_0_play 0 with
  | none   => "L0_0  一处都没分家（共 23 步）"
  | some i => "L0_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1628 那一步之前的那一帧）。 -/
theorem L0_0_trace : traceOk (boardAt 0) (startAt 0 1628) L0_0_play = true := by decide +kernel

#print axioms L0_0_len
#print axioms L0_0_trace

/-- 第 0 关的见证：最后一段的走法，再加上过关那一脚（seq 1651）。 -/
def L0_acts : List Act := L0_0_play.map Prod.fst ++ [(bySeq 1651).act]

/-- **第 0 关走得通。** 从开局照 `L0_acts` 走，中途赢过。 -/
theorem L0_winnable : Winnable (boardAt 0) (startAt 0 1628) :=
  ⟨L0_acts, by decide +kernel⟩

#print axioms L0_winnable

/-! ## 第 1 关（开局 = seq 1652 之前那一帧；RESET 0 次；过关在 seq 1694）-/

/-- 第 1 关第 0 段：seq 1652 起 42 步（开局到过关前一步）。 -/
def L1_0_play : List (Act × Seen) := playFrom 1652 42

theorem L1_0_len : L1_0_play.length = 42 := by decide

#eval match firstSplit (boardAt 1) (startAt 1 1652) L1_0_play 0 with
  | none   => "L1_0  一处都没分家（共 42 步）"
  | some i => "L1_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1652 那一步之前的那一帧）。 -/
theorem L1_0_trace : traceOk (boardAt 1) (startAt 1 1652) L1_0_play = true := by decide +kernel

#print axioms L1_0_len
#print axioms L1_0_trace

/-- 第 1 关的见证：最后一段的走法，再加上过关那一脚（seq 1694）。 -/
def L1_acts : List Act := L1_0_play.map Prod.fst ++ [(bySeq 1694).act]

/-- **第 1 关走得通。** 从开局照 `L1_acts` 走，中途赢过。 -/
theorem L1_winnable : Winnable (boardAt 1) (startAt 1 1652) :=
  ⟨L1_acts, by decide +kernel⟩

#print axioms L1_winnable

/-! ## 第 2 关（开局 = seq 1695 之前那一帧；RESET 0 次；过关在 seq 1739）-/

/-- 第 2 关第 0 段：seq 1695 起 44 步（开局到过关前一步）。 -/
def L2_0_play : List (Act × Seen) := playFrom 1695 44

theorem L2_0_len : L2_0_play.length = 44 := by decide

#eval match firstSplit (boardAt 2) (startAt 2 1695) L2_0_play 0 with
  | none   => "L2_0  一处都没分家（共 44 步）"
  | some i => "L2_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1695 那一步之前的那一帧）。 -/
theorem L2_0_trace : traceOk (boardAt 2) (startAt 2 1695) L2_0_play = true := by decide +kernel

#print axioms L2_0_len
#print axioms L2_0_trace

/-- 第 2 关的见证：最后一段的走法，再加上过关那一脚（seq 1739）。 -/
def L2_acts : List Act := L2_0_play.map Prod.fst ++ [(bySeq 1739).act]

/-- **第 2 关走得通。** 从开局照 `L2_acts` 走，中途赢过。 -/
theorem L2_winnable : Winnable (boardAt 2) (startAt 2 1695) :=
  ⟨L2_acts, by decide +kernel⟩

#print axioms L2_winnable

/-! ## 第 3 关（开局 = seq 1740 之前那一帧；RESET 0 次；过关在 seq 1831）-/

/-- 第 3 关第 0 段：seq 1740 起 91 步（开局到过关前一步）。 -/
def L3_0_play : List (Act × Seen) := playFrom 1740 91

theorem L3_0_len : L3_0_play.length = 91 := by decide

#eval match firstSplit (boardAt 3) (startAt 3 1740) L3_0_play 0 with
  | none   => "L3_0  一处都没分家（共 91 步）"
  | some i => "L3_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1740 那一步之前的那一帧）。 -/
theorem L3_0_trace : traceOk (boardAt 3) (startAt 3 1740) L3_0_play = true := by decide +kernel

#print axioms L3_0_len
#print axioms L3_0_trace

/-- 第 3 关的见证：最后一段的走法，再加上过关那一脚（seq 1831）。 -/
def L3_acts : List Act := L3_0_play.map Prod.fst ++ [(bySeq 1831).act]

/-- **第 3 关走得通。** 从开局照 `L3_acts` 走，中途赢过。 -/
theorem L3_winnable : Winnable (boardAt 3) (startAt 3 1740) :=
  ⟨L3_acts, by decide +kernel⟩

#print axioms L3_winnable

/-! ## 第 4 关（开局 = seq 1832 之前那一帧；RESET 0 次；过关在 seq 1945）-/

/-- 第 4 关第 0 段：seq 1832 起 113 步（开局到过关前一步）。 -/
def L4_0_play : List (Act × Seen) := playFrom 1832 113

theorem L4_0_len : L4_0_play.length = 113 := by decide

#eval match firstSplit (boardAt 4) (startAt 4 1832) L4_0_play 0 with
  | none   => "L4_0  一处都没分家（共 113 步）"
  | some i => "L4_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1832 那一步之前的那一帧）。 -/
theorem L4_0_trace : traceOk (boardAt 4) (startAt 4 1832) L4_0_play = true := by decide +kernel

#print axioms L4_0_len
#print axioms L4_0_trace

/-- 第 4 关的见证：最后一段的走法，再加上过关那一脚（seq 1945）。 -/
def L4_acts : List Act := L4_0_play.map Prod.fst ++ [(bySeq 1945).act]

/-- **第 4 关走得通。** 从开局照 `L4_acts` 走，中途赢过。 -/
theorem L4_winnable : Winnable (boardAt 4) (startAt 4 1832) :=
  ⟨L4_acts, by decide +kernel⟩

#print axioms L4_winnable

/-! ## 第 5 关（开局 = seq 1946 之前那一帧；RESET 5 次；过关在 seq 2664）-/

/-- 第 5 关第 0 段：seq 1946 起 142 步（开局到第一次 RESET）。 -/
def L5_0_play : List (Act × Seen) := playFrom 1946 142

theorem L5_0_len : L5_0_play.length = 142 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_0_play 0 with
  | none   => "L5_0  一处都没分家（共 142 步）"
  | some i => "L5_0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_0_trace : traceOk (boardAt 5) (startAt 5 1946) L5_0_play = true := by decide +kernel

#print axioms L5_0_len
#print axioms L5_0_trace

/-- 第 5 关第 1 段：seq 2089 起 137 步（第 1 次重来之后到下一次重来）。 -/
def L5_1_play : List (Act × Seen) := playFrom 2089 137

theorem L5_1_len : L5_1_play.length = 137 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_1_play 0 with
  | none   => "L5_1  一处都没分家（共 137 步）"
  | some i => "L5_1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_1_trace : traceOk (boardAt 5) (startAt 5 1946) L5_1_play = true := by decide +kernel

#print axioms L5_1_len
#print axioms L5_1_trace

/-- 第 5 关第 2 段：seq 2227 起 52 步（第 2 次重来之后到下一次重来）。 -/
def L5_2_play : List (Act × Seen) := playFrom 2227 52

theorem L5_2_len : L5_2_play.length = 52 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_2_play 0 with
  | none   => "L5_2  一处都没分家（共 52 步）"
  | some i => "L5_2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_2_trace : traceOk (boardAt 5) (startAt 5 1946) L5_2_play = true := by decide +kernel

#print axioms L5_2_len
#print axioms L5_2_trace

/-- 第 5 关第 3 段：seq 2280 起 65 步（第 3 次重来之后到下一次重来）。 -/
def L5_3_play : List (Act × Seen) := playFrom 2280 65

theorem L5_3_len : L5_3_play.length = 65 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_3_play 0 with
  | none   => "L5_3  一处都没分家（共 65 步）"
  | some i => "L5_3  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_3_trace : traceOk (boardAt 5) (startAt 5 1946) L5_3_play = true := by decide +kernel

#print axioms L5_3_len
#print axioms L5_3_trace

/-- 第 5 关第 4 段：seq 2346 起 122 步（第 4 次重来之后到下一次重来）。 -/
def L5_4_play : List (Act × Seen) := playFrom 2346 122

theorem L5_4_len : L5_4_play.length = 122 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_4_play 0 with
  | none   => "L5_4  一处都没分家（共 122 步）"
  | some i => "L5_4  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_4_trace : traceOk (boardAt 5) (startAt 5 1946) L5_4_play = true := by decide +kernel

#print axioms L5_4_len
#print axioms L5_4_trace

/-- 第 5 关第 5 段：seq 2469 起 195 步（重来之后到过关前一步）。 -/
def L5_5_play : List (Act × Seen) := playFrom 2469 195

theorem L5_5_len : L5_5_play.length = 195 := by decide

#eval match firstSplit (boardAt 5) (startAt 5 1946) L5_5_play 0 with
  | none   => "L5_5  一处都没分家（共 195 步）"
  | some i => "L5_5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这一段一步不差。** 起点是这一关的开局（seq 1946 那一步之前的那一帧）。 -/
theorem L5_5_trace : traceOk (boardAt 5) (startAt 5 1946) L5_5_play = true := by decide +kernel

#print axioms L5_5_len
#print axioms L5_5_trace

/-- 第 5 关的见证：最后一段的走法，再加上过关那一脚（seq 2664）。 -/
def L5_acts : List Act := L5_5_play.map Prod.fst ++ [(bySeq 2664).act]

/-- **第 5 关走得通。** 从开局照 `L5_acts` 走，中途赢过。 -/
theorem L5_winnable : Winnable (boardAt 5) (startAt 5 1946) :=
  ⟨L5_acts, by decide +kernel⟩

#print axioms L5_winnable

end Levels
end Game
