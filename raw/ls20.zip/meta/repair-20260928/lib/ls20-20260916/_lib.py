"""ls20 修复用读数（meta/repair-20260928；原册子在 archive/ls20-20260916/concepts/_lib.py）。

这一份只保留「这一帧看得见的东西」：玩家块位置、能量、命数、左下 HUD 图样与墨色、
以及按 5×5 格位（行 0,5,…,55 × 列 4,9,…,59，共 12×12 = 144 格，格号 = 12*行号 + 列号）
读出的墙、色 1 直线、开关（十字 / 非十字）、染色物件、补给块、目标框。
动作后果（落点、滑到哪、踩到什么、HUD 变成什么、会不会换关）一概不在这里算——那些由 Lean 的 stepRules 从这些原语推。

原册子的读数（alive、goal_*、hud_pattern、hud_ink、hud_match、mirror_h、rot_cw、paints、toggles、toggle_hidden、
under、under_known、under_paint、walls；另有 mover_rows / mover_cols 两个误被当成读数、全程读不出的函数）退出状态。
它们在全部帧上的值是新状态字段的函数，证明（构造性）：meta/repair-20260928/_scratch/ls20-20260916/render_proof.py——
由新状态 + 每关一张固定底图逐像素重画整帧，第 0–6 关全部 2931 帧 0 像素不符；第 7 关（WIN 后）只有 2 种帧，命数不同。
帧是新状态的函数，原读数（都是帧的函数）也就是新状态的函数。retire_proof.py 的分组检查只作旁证：1284 种不同帧分成 1284 组、没有一组含两种帧，分组本身没有证明力。
me、energy、lives 三个原读数原样保留。

迷雾（第 6 关）：远处的像素画成色 5。下面每个读数的判据都选成「真物件里不含色 5 的那几个像素全是期望值」
（框另要求外圈一圈地板色 3），所以被迷雾盖住一部分的物件读不出来、不会读成别的东西。
"""
from __future__ import annotations

from geo import cells_of, bbox  # noqa: F401

CELL = 5
NI = 12                 # 格位行数：行 0,5,…,55
NJ = 12                 # 格位列数：列 4,9,…,59（玩家块左上角 row≡0, col≡4 mod 5，首帧 (45,34) 读出）
ME_TOP = 12
ME_BOT = 9
FLOOR = 3
WALL = 4
HUD_ROW = 61
HUD_COLOR = 11
LIFE_COLOR = 8
HUD_BG = 5
LINE = 1
REFILL = 11


def _cell(k):
    """格号 k -> 左上角像素 (t, l)。"""
    return 5 * (k // NJ), 4 + 5 * (k % NJ)


# ---------------------------------------------------------------- 原样保留的三个读数
def me(g):
    """玩家块左上角 (top_row, left_col)：某个色 12 连通块恰好 10 格、bbox 为 2×5，其下 3 行 5 列全为色 9；
    这样的块必须恰好一个。（原册子原文，未改）"""
    from geo import components
    found = []
    for comp in components(cells_of(g, ME_TOP)):
        if len(comp) != 10:
            continue
        t, b, l, r = bbox(comp)
        if (b - t, r - l) != (1, 4):
            continue
        ok = True
        for dr in range(2, 5):
            for dc in range(5):
                rr, cc = t + dr, l + dc
                if rr >= len(g) or cc >= len(g[0]) or g[rr][cc] != ME_BOT:
                    ok = False
        if ok:
            found.append((t, l))
    return found[0] if len(found) == 1 else None


def energy(g):
    """能量条长度：第 HUD_ROW 行里色 11 的格数。（原册子原文）"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_COLOR)


def lives(g):
    """命数：第 HUD_ROW 行里色 8 的 2×2 块数（cols 56–63 处三个位）。（原册子原文）"""
    return sum(1 for c in (56, 59, 62) if g[HUD_ROW][c] == LIFE_COLOR)


# ---------------------------------------------------------------- HUD
def _hud_bits(g):
    return sum(1 << (3 * i + j) for i in range(3) for j in range(3) if g[55 + 2 * i][3 + 2 * j] != HUD_BG)


def _hud_ink(g):
    cs = {g[r][c] for r in range(55, 61) for c in range(3, 9)} - {HUD_BG}
    return next(iter(cs)) if len(cs) == 1 else 0


def hud(g):
    """左下 HUD（rows 55–60、cols 3–8，每 2×2 一格）：3×3 图样按 (i,j) 占第 3i+j 位（非底色 5 为 1），
    加上 512 × 墨色（图样区里唯一的非底色颜色；没有或不止一种记 0）。"""
    return _hud_bits(g) + 512 * _hud_ink(g)


# ---------------------------------------------------------------- 格位读数（位掩码：格号 k 占第 k 位）
def wall_mask(g):
    """墙格：格中心像素 (t+2, l+2) 是墙色 4。"""
    m = 0
    for k in range(NI * NJ):
        t, l = _cell(k)
        if g[t + 2][l + 2] == WALL:
            m |= 1 << k
    return m


def _line_dirs(g, t, l):
    """格 (t,l) 四边外侧贴着的 5 格长色 1 直线：左侧（推向右）0、右侧（推向左）1、上侧（推向下）2、下侧（推向上）3。"""
    H, W = len(g), len(g[0])
    out = []
    if l - 1 >= 0 and all(g[t + k][l - 1] == LINE for k in range(CELL)):
        out.append(0)
    if l + CELL < W and all(g[t + k][l + CELL] == LINE for k in range(CELL)):
        out.append(1)
    if t - 1 >= 0 and all(g[t - 1][l + k] == LINE for k in range(CELL)):
        out.append(2)
    if t + CELL < H and all(g[t + CELL][l + k] == LINE for k in range(CELL)):
        out.append(3)
    return out


def line_mask(g):
    """贴线格：方向 d 的格集合占第 d*144 .. d*144+143 位（d 见 _line_dirs）。只看线本身的 5 个像素。"""
    m = 0
    for k in range(NI * NJ):
        t, l = _cell(k)
        for d in _line_dirs(g, t, l):
            m |= 1 << (d * 144 + k)
    return m


CROSS_INNER = (3, 0, 3, 1, 0, 0, 3, 1, 3)      # 十字开关内 3×3（首帧 (30,19) 格读出）：行主序
NONCROSS_INNER = (0, 3, 3, 3, 0, 0, 3, 0, 3)   # 非十字开关内 3×3（第 3 关 (30,24) 格读出）
PAINT_INNER = (9, 14, 14, 9, 0, 8, 12, 12, 8)  # 染色物件内 3×3（第 2 关 (45,29) 格读出）


def _inner(g, k):
    t, l = _cell(k)
    return tuple(g[t + 1 + i][l + 1 + j] for i in range(3) for j in range(3))


def _mask_of(g, pred):
    m = 0
    for k in range(NI * NJ):
        if pred(_inner(g, k)):
            m |= 1 << k
    return m


def tog_mask(g):
    """十字开关格：内 3×3 恰为 CROSS_INNER。"""
    return _mask_of(g, lambda x: x == CROSS_INNER)


def nc_mask(g):
    """非十字开关格：内 3×3 恰为 NONCROSS_INNER。"""
    return _mask_of(g, lambda x: x == NONCROSS_INNER)


def paint_mask(g):
    """染色物件格：内 3×3 恰为 PAINT_INNER。"""
    return _mask_of(g, lambda x: x == PAINT_INNER)


def refill_mask(g):
    """补给块格：内 3×3 外圈 8 格全是色 11（中心不看）。"""
    return _mask_of(g, lambda x: all(x[q] == REFILL for q in (0, 1, 2, 3, 5, 6, 7, 8)))


def _frame_at(g, k, a=None):
    """格 k 是不是目标框的内 5×5 区：以它为中心的 9×9 外圈全是地板 3、7×7 边框全是 5、内 5×5 外圈全是 5，
    中央 3×3 至少一格非 5 且非 5 的只有一种颜色。三圈里被玩家块 a（左上角）盖住的像素不看（第 10 步：
    玩家站在框下沿那格时盖住了框的底边）。是则返回 (图样位, 墨色)，否则 None。"""
    t, l = _cell(k)
    if t - 2 < 0 or l - 2 < 0 or t + 6 >= 64 or l + 6 >= 64:
        return None
    for r in range(t - 2, t + 7):
        for c in range(l - 2, l + 7):
            if a is not None and a[0] <= r < a[0] + CELL and a[1] <= c < a[1] + CELL:
                continue
            dr, dc = r - (t - 2), c - (l - 2)
            ring = min(dr, dc, 8 - dr, 8 - dc)
            v = g[r][c]
            if ring == 0 and v != FLOOR:
                return None
            if ring in (1, 2) and v != HUD_BG:
                return None
    cen = [g[t + 1 + i][l + 1 + j] for i in range(3) for j in range(3)]
    ink = {v for v in cen} - {HUD_BG}
    if len(ink) != 1:
        return None
    bits = sum(1 << q for q in range(9) if cen[q] != HUD_BG)
    return bits, next(iter(ink))


def frame0(g):
    """格号较小的那个目标框的编码；没有为 -1。编码见 _frame_codes。"""
    return _frame_codes(g)[0]


def frame1(g):
    """格号较大的那个目标框的编码；只有一个或没有为 -1。"""
    return _frame_codes(g)[1]


def _frame_codes(g):
    """目标框（至多两个，按格号排序；空位 -1）：格号 + 144 × (图样位 + 512 × 墨色)。"""
    out = []
    a = me(g)
    for k in range(NI * NJ):
        f = _frame_at(g, k, a)
        if f is not None:
            out.append(k + 144 * (f[0] + 512 * f[1]))
    if len(out) > 2:
        raise ValueError("more than two frames")
    return tuple(out + [-1] * (2 - len(out)))        # 按格号升序（循环本身按格号走）


# ---------------------------------------------------------------- 隐藏状态（修订 R1）
# t  ：本关（或掉命重开后）玩家块真正挪了位置的步数（me(prev) != me(nxt)）——会动的开关、会动的染色物件的位置由它决定。
#      撞墙不动的步不算：第 4 关 seq 1262–1265 连撞四次，会动的开关一直停在 (35,14)，seq 1266 挪了一步它才走到 (35,19)。
# rg ：本关已吃掉的补给块格（位掩码）。第 6 关远处的补给被迷雾盖住，看不见不等于被吃掉，所以要记。
# fg ：本关已消掉的目标框格（位掩码），理由同上。
# 只用 prev / action / nxt 三样：命数减少（掉命重开）→ 全部回初值；
# 吃掉 = prev 里格 k 有补给（框），nxt 里 me 正站在 k 上或 k 的内 3×3 全是地板 3（被迷雾盖住时是全 5，不算）。
HIDDEN_INIT = {"t": 0, "rg": 0, "fg": 0}


def _gone(prev, nxt, mask_prev, k_me):
    out = 0
    for k in range(NI * NJ):
        if mask_prev >> k & 1:
            if k == k_me or all(v == FLOOR for v in _inner(nxt, k)):
                out |= 1 << k
    return out


def _frame_mask(g):
    m = 0
    a = me(g)
    for k in range(NI * NJ):
        if _frame_at(g, k, a) is not None:
            m |= 1 << k
    return m


def hidden_step(h, prev, action, nxt):
    if lives(nxt) < lives(prev):
        return dict(HIDDEN_INIT)
    a, b = me(prev), me(nxt)
    k_me = -1 if b is None else (b[0] // 5) * NJ + (b[1] - 4) // 5
    return {"t": h["t"] + (1 if a != b else 0),
            "rg": h["rg"] | _gone(prev, nxt, refill_mask(prev), k_me),
            "fg": h["fg"] | _gone(prev, nxt, _frame_mask(prev), k_me)}


# ---------------------------------------------------------------- 每关常数（修订 R1：游戏内容，与换关后的布局同类）
# 生成脚本：meta/repair-20260928/_scratch/ls20-20260916/mk_consts2.py（数值原样由它打印），核对脚本 mk_consts.py、fit_movers.py、fit_l6.py。
# 来源：
#   第 0–5 关的布局 = 该关开局帧（换关那一步的后帧）按上面的读数读出；同一关的各次开局帧（第 0 关 seq 430/1099，
#     第 1 关 24/443/1112，第 2 关 91/488/1157，第 3 关 187/529/1196，第 4 关 250/572/1239，第 5 关 342/616/1316，
#     第 6 关 926/1414）读数逐项相同。掉命那一步的后帧与本关开局帧只差命数（p3_death.py，11 次掉命全部如此）。
#   第 6 关（迷雾）布局 = 第 6 关全部帧里落在迷雾圆内的像素之并（每像素取出现最多的颜色；见过色 11 的记 11，
#     因为补给被吃后变地板）。中心从未照亮的两格 (55,54)、(55,59) 按墙填（从未进入照亮范围，不影响任何读数）。
#   cost  普通一步能量减少量：p2_energy.py 各关「挪动且未踩补给」的步全部等于此值（第 0 关 43 次 -1、第 1 关 135 次 -2、
#         第 2 关 152 次 -2、第 3 关 130 次 -1、第 4 关 164 次 -2、第 5 关 410 次 -1、第 6 关 152 次 -2）。
#   tfree 踩开关那一步不扣能量：只见于第 0 关（seq 17、436、1105 三次都是 0）；第 1–6 关踩开关一律照扣（p2_energy.py）。
#         原因不明，按关登记。
#   fog   有迷雾的关：第 6 关（迷雾圆的拟合见 p4_fog.py：像素 (r,c) 看得见 ⇔ (2r-2·me_r-3)²+(2c-2·me_c-3)² < 1600，
#         第 6 关 223 帧 × 2181 个可被迷雾的像素 0 不符；1594 以内全可见、1602 起全不可见）。
#   start / hud0  开局帧的玩家格号、HUD 读数（掉命重开也回到这里）。
#   wall / lines  墙格、贴线格掩码（读数同 wall_mask / line_mask）。
#   tog / nc / pnt  不动的十字开关、非十字开关、染色物件格（开局帧读数里剔掉会动的那几个）。
#   ref   开局时的补给块格。  frm0 / frm1  开局时的目标框编码（同 frame_codes）。
#   mv0 / mv1  会动的开关：种类(0 十字/1 非十字) + 2×(轴(0 沿行/1 沿列) + 2×(固定坐标 + 64×(lo + 64×(hi + 64×相位))))；-1 = 无。
#         位置律：n=(hi-lo)/5，P=2n，u=(t+相位) mod P，坐标 = lo + 5×(u≤n ? u : P-u)，t 为隐藏量 h_t。
#         第 4 关行 35：14↔24、相位 0；第 5 关行 10（非十字）：14↔34、相位 0；行 40（十字）：14↔34、相位 4；
#         第 6 关列 54：5↔30、相位 1。fit_movers.py / fit_l6.py：全部可见观测 0 不符（第 6 关另核「该看见却没看见」0 次）。
#         端点不是墙：第 4 关行 35 的走廊西到列 9、第 6 关列 54 的走廊南到行 40，开关都不去——端点只能照观测登记。
#   orb   会动的染色物件：中心格号 + 144×相位；-1 = 无。位置律：绕中心格的 8 个邻格，次序 下、左下、左、左上、上、右上、右、右下，
#         第 t 步在 (相位 + t) mod 8。第 5 关中心 (25,24)、相位 0；fit_movers.py：483 次可见观测 0 不符。
LEVEL_CONST = {
    0: {"cost": 1, "tfree": 1, "fog": 0, "start": 114, "hud0": 4943, "wall": 22295300350872325632478711437365685925183487, "lines": 0, "tog": 37778931862957161709568, "nc": 0, "pnt": 0, "ref": 0, "frm0": 715278, "frm1": -1, "mv0": -1, "mv1": -1, "orb": -1},
    1: {"cost": 2, "tfree": 0, "fog": 0, "start": 101, "hud0": 4967, "wall": 22292747981220821407119587987496409816399871, "lines": 0, "tog": 166153499473114484112975882535043072, "nc": 0, "pnt": 0, "ref": 170141183460469231731687303990762012672, "frm0": 711890, "frm1": -1, "mv0": -1, "mv1": -1, "orb": -1},
    2: {"cost": 2, "tfree": 0, "fog": 0, "start": 109, "hud0": 6503, "wall": 22293790306965989147832372311336196887814143, "lines": 2085924839766513752338888384931203236916703635113918720651407820138886450957656787131798921216, "tog": 8589934592, "nc": 0, "pnt": 10384593717069655257060992658440192, "ref": 37778931867355208220672, "frm0": 730066, "frm1": -1, "mv0": -1, "mv1": -1, "orb": -1},
    3: {"cost": 1, "tfree": 0, "fog": 0, "start": 22, "hud0": 7578, "wall": 22293109491026249823643923008368716917645311, "lines": 1636695303948070935006594848413799576185278066409701277827973051612578970404959334055835502197918923433381286727191499940879830163806694168697510035456, "tog": 0, "nc": 75557863725914323419136, "pnt": 302231454903657293676544, "ref": 85070591730234615865843652407697866752, "frm0": 715261, "frm1": -1, "mv0": -1, "mv1": -1, "orb": -1},
    4: {"cost": 2, "tfree": 0, "fog": 0, "start": 105, "hud0": 6554, "wall": 22292588714002969868473017653531003249115135, "lines": 15095849699286165410602913627901146498674279730079561289614348677806409246923050876760615346580509877704447798618789109458568121243604940930310569704828518386653053583360, "tog": 0, "nc": 134217728, "pnt": 36893488147419103232, "ref": 1298074214633706907132624116908032, "frm0": 649318, "frm1": -1, "mv0": 396940, "mv1": -1, "orb": -1},
    5: {"cost": 1, "tfree": 0, "fog": 0, "start": 124, "hud0": 7539, "wall": 22293774312084739548213163249238841263923199, "lines": 1042962419883256876169444192465604832334440335537510444249888592394648269884815959151570059264, "tog": 0, "nc": 0, "pnt": 0, "ref": 649037107316853453566312041684992, "frm0": 649390, "frm1": 733522, "mv0": 560681, "mv1": 4755104, "orb": 64},
    6: {"cost": 2, "tfree": 0, "fog": 1, "start": 39, "hud0": 6610, "wall": 22292875990803608430953782003818362534371327, "lines": 3351951982485649274893506249551461531869841455148116262388827783364125467056631291754707027679037309438684497966972732863744730562760959792795136913571840, "tog": 0, "nc": 633825300114114700748351602688, "pnt": 158456325028528675187087900672, "ref": 1361130765757968487560414569550412521472, "frm0": 649421, "frm1": -1, "mv0": 1541594, "mv1": -1, "orb": -1},
}
