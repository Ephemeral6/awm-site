/-
# key_reshapes —— 踩到非十字开关：换下一种形状，朝向不变（对应 `rule/key/key_reshapes.py` 与 `derive/next_form.py`）

六种形状排成一个环（`forms`，起点朝向任取），一个图样 = 某一种形状转了 r 次。
换形 = 环上的下一种、同样转 r 次。图样不在这 24 种里 ⇒ `none`（说不出来，不编）。

    466 = .#. / .#. / ###      493 = #.# / #.# / ###      174 = .## / #.# / .#.
    410 = .#. / ##. / .##      359 = ### / ..# / #.#      371 = ##. / .## / #.#

（位序：第 k 位 = 第 k // 3 行第 k % 3 列；这六个数是按这个位序手算的，和 Python 那一份各自独立写，
由每关的逐帧核对去对账。）
-/
import Obj.Hud.Key
import Rule.Key.KeyRotates

namespace Game

def forms : List Nat := [466, 493, 174, 410, 359, 371]

def rotN : Nat → Nat → Nat
  | 0, s     => s
  | n + 1, s => rotN n (rotCw s)

/-- 在第 `i` 种形状起，找 `s` 是哪一种、转了几次。 -/
def findForm (s : Nat) : List Nat → Nat → Option (Nat × Nat)
  | [], _      => none
  | f :: fs, i =>
    if rotN 0 f == s then some (i, 0)
    else if rotN 1 f == s then some (i, 1)
    else if rotN 2 f == s then some (i, 2)
    else if rotN 3 f == s then some (i, 3)
    else findForm s fs (i + 1)

def nextForm (s : Nat) : Option Nat :=
  match findForm s forms 0 with
  | none        => none
  | some (i, r) => some (rotN r (forms.getD ((i + 1) % 6) 0))

def reshapeKey (k : Key) : Option Key :=
  (nextForm k.shape).map (fun s => { k with shape := s })

end Game
