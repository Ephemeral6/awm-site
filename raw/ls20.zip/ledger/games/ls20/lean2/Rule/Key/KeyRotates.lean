/-
# key_rotates —— 踩到十字开关：钥匙顺时针转 90°（对应 `rule/key/key_rotates.py` 与 `derive/rot_cw.py`）

九位掩码上的一个置换：新 (i, j) = 旧 (2−j, i)，即新第 k 位取旧的第 `[6,3,0,7,4,1,8,5,2][k]` 位。
它是四阶的（`Derived/RotCwOrder.lean`）。
-/
import Obj.Hud.Key

namespace Game

def bitOf (s k : Nat) : Nat := (s / 2 ^ k) % 2

def rotCw (s : Nat) : Nat :=
  bitOf s 6 + 2 * bitOf s 3 + 4 * bitOf s 0 + 8 * bitOf s 7 + 16 * bitOf s 4
    + 32 * bitOf s 1 + 64 * bitOf s 8 + 128 * bitOf s 5 + 256 * bitOf s 2

def rotateKey (k : Key) : Key := { k with shape := rotCw k.shape }

end Game
