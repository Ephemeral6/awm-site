/-
# key_recolors —— 踩到染色物件：墨色换下一档（对应 `rule/key/key_recolors.py` 与 `derive/next_ink.py`）

四色环 12 → 9 → 14 → 8 → 12。环外的颜色 ⇒ `none`（没见过，不编）。
-/
import Obj.Hud.Key

namespace Game

def nextInk : Nat → Option Nat
  | 12 => some 9
  | 9  => some 14
  | 14 => some 8
  | 8  => some 12
  | _  => none

def recolorKey (k : Key) : Option Key :=
  (nextInk k.ink).map (fun i => { k with ink := i })

end Game
