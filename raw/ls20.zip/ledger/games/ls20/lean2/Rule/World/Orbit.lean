/-
# orbit —— 绕圈的染色物件（对应 `rule/world/orbit.py`）

玩家挪一格，它沿 `Board.orbit` 走一格（循环）。圈是从读数抄下来的循环表，不是从帧算的。
-/
import Obj.World

namespace Game

def orbitTick (b : Board) (i : Nat) : Nat :=
  if b.orbit.length == 0 then i else (i + 1) % b.orbit.length

/-- 绕圈的那一个此刻在哪（这一关没有就是空表）。 -/
def orbitCells (b : Board) (i : Nat) : List Cell :=
  match b.orbit with
  | []     => []
  | c :: _ => [b.orbit.getD i c]

end Game
