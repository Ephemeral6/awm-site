/-
# energy_cost —— 能量怎么掉（对应 `rule/world/energy_cost.py`）

    挪了格（走、滑、开门）   掉 `Board.cost`；落脚在补给上则回满（`refill`）；
                            这一关登记为 `pressFree` 且这一步踩到十字开关 ⇒ 不掉
    撞墙                    掉 `Board.cost`
    撞锁                    不掉
    减到 0 为止（`Nat` 减法本来就截到 0）。

「撞墙都扣、撞锁不扣」和「只有这两关撞墙扣」这批语料分不开（撞墙的全在那两关，
撞锁的全在另两关）；模型取前者。分开它的实验写在 `analysis/gaps.txt`。
-/
import Obj.World
import Rule.World.Refill

namespace Game

def energyAfterWall (b : Board) (w : World) : Nat := w.energy - b.cost

def energyAfterMove (b : Board) (w : World) (c : Cell) (pressedRot : Bool) : Nat :=
  if refillHere w c then fullEnergy
  else if b.pressFree && pressedRot then w.energy
  else w.energy - b.cost

end Game
