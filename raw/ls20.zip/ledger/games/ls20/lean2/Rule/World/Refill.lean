/-
# refill —— 落脚在补给上：能量回满，补给用掉（对应 `rule/world/refill.py` 与 `rule/world/devices_stay.py` 的补给那一半）
-/
import Obj.World

namespace Game

def refillHere (w : World) (c : Cell) : Bool := memC c w.refills

def refillsAfter (w : World) (c : Cell) : List Cell := eraseC c w.refills

end Game
