/-
# fog —— 迷雾（对应 `rule/world/fog.py` 与 `objects/parse.py` 的迷雾那一段）

有雾的关只看得见玩家中心周围一个圆盘（像素平方距离 ≤ 425）。
一格**整格都在圆里**才算看得见。格阵对齐之后，一格离玩家中心最远的那个像素
行差 = 5·|Δ行| + 2、列差 = 5·|Δ列| + 2，所以判据只剩一个整数不等式：

    (5·|Δ行| + 2)² + (5·|Δ列| + 2)² ≤ 425

这一行和解析里逐像素算的那一份**各自独立写**；两份对不上的话，每关逐帧核对第一帧就红。
雾是**关的属性**（`Board.fog`），不是某一帧的偶然。
-/
import Obj.Board.Board

namespace Game

def absDiff (a b : Nat) : Nat := if a ≤ b then b - a else a - b

def visible (b : Board) (me c : Cell) : Bool :=
  !b.fog ||
    (let dr := 5 * absDiff me.row c.row + 2
     let dc := 5 * absDiff me.col c.col + 2
     Nat.ble (dr * dr + dc * dc) 425)

end Game
