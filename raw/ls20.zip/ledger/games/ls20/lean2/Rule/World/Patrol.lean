/-
# patrol —— 巡逻的装置（对应 `rule/world/patrol.py` 与 `derive/patrol_next.py`）

玩家走一步（**真的挪了格**），线上的装置走一格，越过端点就先掉头再走；
玩家没挪（撞墙、撞锁），它不走——所以 `tick` 只在 `Step.lean` 的「挪了格」那一支里调。
-/
import Obj.World

namespace Game

def PState.tick (p : Patrol) (s : PState) : PState :=
  if s.fwd then (if s.pos + 1 ≤ p.hi then ⟨s.pos + 1, true⟩ else ⟨s.pos - 1, false⟩)
  else (if p.lo + 1 ≤ s.pos then ⟨s.pos - 1, false⟩ else ⟨s.pos + 1, true⟩)

def tickAll : List Patrol → List PState → List PState
  | p :: ps, s :: ss => s.tick p :: tickAll ps ss
  | _, _             => []

/-- 第 `kind` 种巡逻装置此刻在哪几格。 -/
def patrolCells (kind : Nat) : List Patrol → List PState → List Cell
  | p :: ps, s :: ss => (if p.kind == kind then [p.at s.pos] else []) ++ patrolCells kind ps ss
  | _, _             => []

end Game
