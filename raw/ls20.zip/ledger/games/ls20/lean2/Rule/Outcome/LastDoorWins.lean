/-
# last_door_wins —— 过关 ⇔ 钥匙对上、走进的是最后一道门（对应 `rule/outcome/last_door_wins.py`）

「钥匙对上的门」由 `landing` 分出来（`.opened`）；这一条只说**是不是最后一道**。
-/
import Obj.World

namespace Game

def lastDoorWins (w : World) : Bool := w.goals.length == 1

end Game
