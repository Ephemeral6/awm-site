/-
# out_of_energy —— 能量为 0 时再按：不是走进补给就掉命（对应 `rule/outcome/out_of_energy.py`）

掉命之后是哪一帧模型说不出来（这一关的开局是历史），所以 `step` 在这里返回 `died`、不带下一帧；
「掉命之后回到开局、命少一条」写成明处的假设（`unmodeled/restart_to_start.py`，
`Obs/Check.lean` 的 `restart`）。

能量为 0 而目标格是补给：照常走（`step` 往下走普通那一支，补给把能量回满）。
-/
import Obj.World

namespace Game

def targetIsRefill (w : World) (d : Delta) : Bool :=
  match w.me.shift d with
  | none   => false
  | some t => memC t w.refills

def outOfEnergy (w : World) (d : Delta) : Bool := w.energy == 0 && !(targetIsRefill w d)

end Game
