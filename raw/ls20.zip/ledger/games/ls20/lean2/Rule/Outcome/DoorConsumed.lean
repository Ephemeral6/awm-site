/-
# door_consumed —— 开的不是最后一道门：那道门消失（对应 `rule/outcome/door_consumed.py`）
-/
import Obj.World

namespace Game

def consumeDoor (c : Cell) (w : World) : List Goal := eraseGoal c w.goals

end Game
