/-
# reset_restarts_game —— **不进模型**（对应 `rule/unmodeled/reset_restarts_game.py`）

说的是：按 RESET 之后，下一帧就是整局第一帧（第 0 关开局）。

它不进模型，而且在这里**连一个定义都没有**，理由有两层：

  · RESET 不是一步棋：`Act` 里只有四个方向键，模型根本说不出「按 RESET」；
  · 「整局第一帧长什么样」是历史，不是任何一帧的函数。

它在形式化里留下的痕迹只有一处：每关一条定理的开局**从这一关第一帧读**，不从 RESET 推。
语料那一侧的两个数（论域 2 / 被驳倒 0）由 `run_rules.py` 打在 `analysis/readings.json`。
-/
import Obj.World
