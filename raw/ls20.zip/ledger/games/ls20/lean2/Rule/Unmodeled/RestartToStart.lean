/-
# restart_to_start —— **不进模型**（对应 `rule/unmodeled/restart_to_start.py`）

说的是：能量用光掉了命之后，这一关从开局重来，只有命少一条。

它不进 `step`：「这一关的开局长什么样」不是当前状态的函数，是历史，一帧上读不出来；
硬塞一个「开局」字段进 `World`，就是给世界加一位帧上读不出来的信息。
所以 `step` 在那一支返回 `died`、不带下一帧，而这句话写成下面这个**明处的假设**，
只在 `Proof/Levels.lean` 里掉过命的那一关用：尾段的逐帧核对从 `restart` 起算，
假设错了，那一段第一帧就对不上。**没红不构成证明。**

语料那一侧的两个数（论域 / 被驳倒）由 `run_rules.py` 打在 `analysis/readings.json`。
-/
import Obj.World

namespace Game

def restart (start : World) (lives : Nat) : World := { start with lives := lives }

end Game
