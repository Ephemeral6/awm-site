/-
# walk —— 按一个方向键，玩家停在哪（对应 `rule/move/walk.py` 与 `derive/landing.py`）

`landing` 把五种结局分开：

    wall        目标格不是地板                → 原地不动（`blocked`）
    locked      目标格是门心、钥匙对不上        → 原地不动（`blocked`）
    opened c    目标格是门心、钥匙对上          → 走进去（`outcome/`）
    step c      普通地板                      → 走进去一格（**这一条规则本身**）
    slide c     贴着弹簧线                    → 滑到 c（`slide`）

判的顺序和 Python 那一份一样：先看是不是地板，再看是不是门，再看贴没贴线。
-/
import Obj.World
import Rule.Move.Blocked
import Rule.Move.Slide

namespace Game

inductive Land where
  | wall
  | locked
  | opened (c : Cell)
  | step (c : Cell)
  | slide (c : Cell)
deriving Repr

def landingAt (b : Board) (w : World) (t : Cell) : Land :=
  if isWall b t then .wall
  else if isLocked w t then .locked
  else if (goalAt t w.goals).isSome then .opened t
  else match slideFrom b w t with
    | some c => .slide c
    | none   => .step t

def landing (b : Board) (w : World) (d : Delta) : Land :=
  match w.me.shift d with
  | none   => .wall
  | some t => landingAt b w t

end Game
