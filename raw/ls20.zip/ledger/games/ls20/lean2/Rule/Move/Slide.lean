/-
# slide —— 弹簧线（对应 `rule/move/slide.py` 与 `derive/landing.py` 的滑动那一段）

落脚格贴着线，就沿线推的方向一格格滑：下一格不是地板、或是门心，就停。
**不拐弯**（滑到的格也贴着线也不再转向），**不滑进门**（哪怕钥匙对上了）。
最多滑 12 格（格阵只有 12 格宽，滑不出更远）。
-/
import Obj.World

namespace Game

def slideRun (b : Board) (goals : List Goal) (d : Delta) : Nat → Cell → Cell
  | 0, c     => c
  | n + 1, c =>
    match c.shift d with
    | none    => c
    | some nx =>
      if memC nx b.floor && (goalAt nx goals).isNone then slideRun b goals d n nx else c

/-- 落在 `t` 上之后会滑到哪；`t` 不贴线返回 `none`。 -/
def slideFrom (b : Board) (w : World) (t : Cell) : Option Cell :=
  match pushAt t b.lines with
  | none   => none
  | some p => some (slideRun b w.goals p 12 t)

end Game
