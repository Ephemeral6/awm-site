/-
# blocked —— 撞墙、撞锁：原地不动（对应 `rule/move/blocked.py`）

两个谓词，`Rule/Move/Walk.lean` 里的 `landing` 用它们分出「挡住了」那两支。
-/
import Obj.World

namespace Game

/-- 目标格不是地板（含走出格阵）。 -/
def isWall (b : Board) (t : Cell) : Bool := !(memC t b.floor)

/-- 目标格是门心而钥匙（形状与颜色）对不上。 -/
def isLocked (w : World) (t : Cell) : Bool :=
  match goalAt t w.goals with
  | some g => !(Key.eqb g.key w.key)
  | none   => false

end Game
