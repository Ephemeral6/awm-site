/-
# Corpus —— 模型面对**每一条**真实转移（第三条腿的 ①）

每一步都从**观测到的那一帧**重新起算（按纤维：帧上读不出来的那几位全列出来），
算一步，和看到的下一帧比。RESET 不是用例（模型的动作里没有它），条数单列。

## 读数不是定理

下面那句 `#eval` 走的是**求值器**，不进可信基——它是读数。
所以另挑了几条（每类一条）用 `decide` 走内核真证出来；**两者的差别写在明处**：
全量的「反例 0」是读数，那几条是定理。
-/
import Obj.World
import Obs.Replay

set_option maxRecDepth 100000

-- 不开命名空间：装置的 `lean_check` 按短名 `#print axioms`。
open Game Game.Replay

def verdicts : List (Nat × Nat × Verdict) :=
  rows.filterMap (fun r => (caseOf r).map (fun c => (r.seq, r.kind, agrees (board c.lvl) c)))

def count (v : Verdict) : Nat := (verdicts.filter (fun x => x.2.2 == v)).length

-- 读数：一行，`verify.py` 按前缀 `CORPUS` 取。
#eval "CORPUS cases=" ++ toString verdicts.length ++ " yes=" ++ toString (count .yes)
  ++ " no=" ++ toString (count .no) ++ " na=" ++ toString (count .na)
  ++ " reset=" ++ toString (rows.length - verdicts.length)
  ++ " no_seqs=" ++ toString ((verdicts.filter (fun x => x.2.2 == .no)).map (·.1) |>.take 20)
  ++ " na_seqs=" ++ toString ((verdicts.filter (fun x => x.2.2 == .na)).map (·.1) |>.take 20)

/-- 一条转移上「有一个和这一帧相符的世界，`step` 从它算出来的正是下一帧」。 -/
def holdsAt (s : Nat) : Bool :=
  ((rowAt s).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes))

/-! ## 每类一条，走内核

语句写开（而不是只写 `holdsAt s = true`），好让人一眼看出它说的是「存在一个世界 + `step`」。 -/

/-- 普通的一步（第 0 关第 1 步）。 -/
theorem corpus_walk : ((rowAt 1).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 撞锁（第 0 关第 11 步，钥匙还没转对，门不开、能量不掉）。 -/
theorem corpus_locked : ((rowAt 11).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 踩十字开关（第 0 关第 1105 步，而且这一关踩它不扣能量）。 -/
theorem corpus_rotate_free : ((rowAt 1105).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 过关（第 0 关第 1112 步）。 -/
theorem corpus_levelup : ((rowAt 1112).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 滑（第 4 关第 1244 步：左一格落在线上，往上滑到底）。 -/
theorem corpus_slide : ((rowAt 1244).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 撞墙（第 4 关第 1262 步：原地不动，能量照扣，巡逻的也不动）。 -/
theorem corpus_wall : ((rowAt 1262).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 掉命（第 4 关第 1261 步）。 -/
theorem corpus_died : ((rowAt 1261).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 巡逻的十字开关撞上玩家（第 4 关第 1305 步）。 -/
theorem corpus_patrol_press : ((rowAt 1305).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 绕圈的染色物件撞上玩家（第 5 关第 1367 步）。 -/
theorem corpus_orbit_press : ((rowAt 1367).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 开一道不是最后的门（第 5 关第 1351 步）。 -/
theorem corpus_door_consumed : ((rowAt 1351).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 能量 0 走进补给（第 2 关第 1179 步：不掉命，回满）。 -/
theorem corpus_empty_refill : ((rowAt 1179).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 巡逻的非十字开关撞上玩家（第 5 关第 1388 步）。 -/
theorem corpus_reshape : ((rowAt 1388).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

/-- 迷雾关里被巡逻的十字开关撞上（第 6 关第 1457 步）。 -/
theorem corpus_fog_press : ((rowAt 1457).bind caseOf).any (fun c =>
    (fiber (board c.lvl) c.prev).any (fun w : World => judgeOne (board c.lvl) c w == .yes)) = true := by
  decide

#print axioms corpus_walk
#print axioms corpus_locked
#print axioms corpus_rotate_free
#print axioms corpus_levelup
#print axioms corpus_slide
#print axioms corpus_wall
#print axioms corpus_died
#print axioms corpus_patrol_press
#print axioms corpus_orbit_press
#print axioms corpus_door_consumed
#print axioms corpus_empty_refill
#print axioms corpus_reshape
#print axioms corpus_fog_press
