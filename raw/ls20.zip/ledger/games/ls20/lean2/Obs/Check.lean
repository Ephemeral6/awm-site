/-
# Check —— 判据层：两把尺子。**0 条定理**，尺子不自证。

    agrees     **一条转移**对不对：从**观测到的那一帧**起算一步，和看到的下一帧比
    traceOk    **一整条路**对不对：只有开局那一帧是观测给的，**后面全是模型自己算的**

## `Seen`：只装帧上看得见的

Python 那一份 `parse` 读出来的就是它（去掉版面那三样：版面住在 `Board`）。
装置和门**按集合比**：帧上读不出先后。玩家脚下那一格、雾里的格，帧上看不见，
模型那一侧投影成 `Seen` 时同样去掉（`seenOf`）。

## 逐条那一把要按「纤维」判

一帧对应的不止一个世界：巡逻装置**往哪走**帧上读不出来；它此刻被玩家盖着、或在雾里时，
**在哪**也读不出来。所以 `fiber` 把这些可能全列出来，逐个算一步：

    有一个对上了                  ⇒ yes
    都没对上，但有一个说不出话     ⇒ na    说不出话不是反对
    都没对上，也没人说不出话       ⇒ no    模型被这一帧证伪

「说不出话」有两种：`step` 返回 `unknown`；或者有雾而玩家落脚的那一格
**前一帧看不见**（那一格上有什么，前一帧没给）。
-/
import Step
import Rule.World.Fog
import Rule.Unmodeled.RestartToStart

namespace Game

structure Seen where
  me       : Cell
  key      : Key
  energy   : Nat
  lives    : Nat
  goals    : List Goal
  rotators : List Cell
  shapers  : List Cell
  painters : List Cell
  refills  : List Cell
deriving Repr

/-- 看得见：不是玩家脚下，且（有雾时）整格在圆盘里。 -/
def shown (b : Board) (me c : Cell) : Bool := !(Cell.eqb c me) && visible b me c

def seenOf (b : Board) (w : World) : Seen :=
  { me := w.me, key := w.key, energy := w.energy, lives := w.lives,
    goals    := w.goals.filter (fun g => shown b w.me g.cell),
    rotators := (rotatorsAll b w).filter (shown b w.me),
    shapers  := (shapersAll b w).filter (shown b w.me),
    painters := (paintersAll b w).filter (shown b w.me),
    refills  := w.refills.filter (shown b w.me) }

/-- 两份 `Seen` 在 `ok` 这一组格上是否一致（`ok` 之外的格不比）。 -/
def seenEqOn (ok : Cell → Bool) (a o : Seen) : Bool :=
  Cell.eqb a.me o.me && Key.eqb a.key o.key && a.energy == o.energy && a.lives == o.lives
  && setEqG (a.goals.filter (fun g => ok g.cell)) (o.goals.filter (fun g => ok g.cell))
  && setEqC (a.rotators.filter ok) (o.rotators.filter ok)
  && setEqC (a.shapers.filter ok) (o.shapers.filter ok)
  && setEqC (a.painters.filter ok) (o.painters.filter ok)
  && setEqC (a.refills.filter ok) (o.refills.filter ok)

def seenEq (a o : Seen) : Bool := seenEqOn (fun _ => true) a o

/-! ## 每关那一把：带着自己算出来的状态往下走 -/

/-- 从 `w` 出发沿 `play` 走，每一步都和当时看到的那一帧比。全对才是 `true`。
    **下一轮喂进去的是模型自己算出来的 `w'`**，不是观测到的那一帧。 -/
def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, []             => true
  | w, (a, o) :: rest =>
    match step b w a with
    | .ok w' => seenEq (seenOf b w') o && traceOk b w' rest
    | _      => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [],             _ => none
  | w, (a, o) :: rest, i =>
    match step b w a with
    | .ok w' => if seenEq (seenOf b w') o then firstSplit b w' rest (i + 1) else some i
    | _      => some i

/-- 沿一串动作走，中途赢过没有。 -/
def everWon (b : Board) : World → List Act → Bool
  | _, []      => false
  | w, a :: as =>
    match step b w a with
    | .won    => true
    | .ok w'  => everWon b w' as
    | _       => false

/-! ## 逐条那一把：按纤维判 -/

inductive Verdict where
  | yes | no | na
deriving Repr, DecidableEq

/-- 帧上读不出来的那几位的全部可能：巡逻装置的位置（被盖住 / 在雾里时）与方向、绕圈的第几格。 -/
def patrolChoices (b : Board) (s : Seen) (p : Patrol) : List PState :=
  let seen := (if p.kind == 0 then s.rotators else s.shapers).filter
                (fun c => (List.range (p.hi + 1)).any (fun k => p.lo ≤ k && Cell.eqb (p.at k) c))
  let ks := match seen with
    | c :: _ => [if p.alongRow then c.col else c.row]
    | []     => (List.range (p.hi + 1)).filter (fun k => p.lo ≤ k && !(shown b s.me (p.at k)))
  ks.flatMap (fun k => [⟨k, true⟩, ⟨k, false⟩])

def product : List (List PState) → List (List PState)
  | []        => [[]]
  | xs :: xss => xs.flatMap (fun x => (product xss).map (fun r => x :: r))

def orbChoices (b : Board) (s : Seen) : List Nat :=
  let idx := List.range b.orbit.length
  match idx.filter (fun i => memC (b.orbit.getD i ⟨0, 0⟩) s.painters) with
  | i :: _ => [i]
  | []     => match idx.filter (fun i => !(shown b s.me (b.orbit.getD i ⟨0, 0⟩))) with
    | [] => [0]
    | l  => l

/-- 在轨道上的格（巡逻线 / 圈）不算「静止的装置」。 -/
def onTrack (b : Board) (kind : Nat) (c : Cell) : Bool :=
  b.patrols.any (fun p => p.kind == kind &&
    (List.range (p.hi + 1)).any (fun k => p.lo ≤ k && Cell.eqb (p.at k) c))

/-- 玩家脚下那一格盖着什么，帧上也读不出来：0 什么都没有，1/2/3 一个静止的十字 / 非十字 / 染色物件。
    （补给不会在脚下：走进补给那一刻它就被吃了。） -/
def underAdd (u : Nat) (kind : Nat) (me : Cell) (l : List Cell) : List Cell :=
  if u == kind then me :: l else l

def fiber (b : Board) (s : Seen) : List World :=
  (product (b.patrols.map (patrolChoices b s))).flatMap (fun ps =>
    (orbChoices b s).flatMap (fun o =>
      [0, 1, 2, 3].map (fun u =>
      { me := s.me, key := s.key, energy := s.energy, lives := s.lives, goals := s.goals,
        rotators := underAdd u 1 s.me (s.rotators.filter (fun c => !(onTrack b 0 c))),
        shapers  := underAdd u 2 s.me (s.shapers.filter (fun c => !(onTrack b 1 c))),
        painters := underAdd u 3 s.me (s.painters.filter (fun c => !(memC c b.orbit))),
        refills  := s.refills, pats := ps, orb := o })))

/-- 一条转移。`kind`：0 普通的一步，1 过关，2 掉命（现实那一侧的事实，模型看不见它们）。 -/
structure Case where
  seq  : Nat
  lvl  : Nat
  prev : Seen
  act  : Act
  next : Seen
  kind : Nat

/-- 一个候选世界上的判决。 -/
def judgeOne (b : Board) (c : Case) (w : World) : Verdict :=
  match step b w c.act with
  | .won     => if c.kind == 1 then .yes else .no
  | .died    => if c.kind == 2 then .yes else .no
  | .unknown => .na
  | .ok w'   =>
    if c.kind != 0 then .no
    else if !(visible b c.prev.me w'.me) then .na
    else if seenEqOn (fun x => shown b c.prev.me x || Cell.eqb x c.prev.me) (seenOf b w') c.next then .yes
    else .no

def agrees (b : Board) (c : Case) : Verdict :=
  let vs := (fiber b c.prev).map (judgeOne b c)
  if vs.any (· == .yes) then .yes else if vs.any (· == .na) then .na else .no

end Game
