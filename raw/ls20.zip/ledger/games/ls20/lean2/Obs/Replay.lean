/-
# Replay —— 整条轨迹，**只存这一份**（自动生成，不要手改；生成器 `export_replay.py`）

逐条（`Obs/Corpus.lean`）和每关（`Proof/Levels.lean`）都从这里切。

    frames      每一帧**真正读到的**那张（去重后 1284 张）：只装这一帧看得见的
    rows        全部 1467 条转移，按 `seq` 排；`kind` 是现实那一侧的事实（0 普通 / 1 过关 / 2 掉命 / 3 RESET）
    boards      每关**整关取并集**的版面（7 张）
    statics     每关**整关取并集**的静止装置、补给、门

**切片按 `seq`，不按 `step`**：`step` 有 2 处重号（429、1097），`seq` 唯一（生成时数过）。
**过关那一步的下一帧不并进本关**（地板、装置、门三样一起防）。
-/

import Obs.Check

set_option maxRecDepth 100000

namespace Game
namespace Replay

def f0 : Seen := { me := ⟨9, 6⟩, key := ⟨335, 9⟩, energy := 42, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f1 : Seen := { me := ⟨8, 6⟩, key := ⟨335, 9⟩, energy := 41, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f2 : Seen := { me := ⟨9, 6⟩, key := ⟨335, 9⟩, energy := 40, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f3 : Seen := { me := ⟨9, 5⟩, key := ⟨335, 9⟩, energy := 39, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f4 : Seen := { me := ⟨9, 6⟩, key := ⟨335, 9⟩, energy := 38, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f5 : Seen := { me := ⟨8, 6⟩, key := ⟨335, 9⟩, energy := 37, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f6 : Seen := { me := ⟨7, 6⟩, key := ⟨335, 9⟩, energy := 36, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f7 : Seen := { me := ⟨6, 6⟩, key := ⟨335, 9⟩, energy := 35, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f8 : Seen := { me := ⟨5, 6⟩, key := ⟨335, 9⟩, energy := 34, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f9 : Seen := { me := ⟨4, 6⟩, key := ⟨335, 9⟩, energy := 33, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f10 : Seen := { me := ⟨3, 6⟩, key := ⟨335, 9⟩, energy := 32, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f11 : Seen := { me := ⟨4, 6⟩, key := ⟨335, 9⟩, energy := 31, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f12 : Seen := { me := ⟨5, 6⟩, key := ⟨335, 9⟩, energy := 30, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f13 : Seen := { me := ⟨5, 5⟩, key := ⟨335, 9⟩, energy := 29, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f14 : Seen := { me := ⟨5, 4⟩, key := ⟨335, 9⟩, energy := 28, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f15 : Seen := { me := ⟨5, 3⟩, key := ⟨335, 9⟩, energy := 27, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f16 : Seen := { me := ⟨6, 3⟩, key := ⟨359, 9⟩, energy := 27, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f17 : Seen := { me := ⟨5, 3⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f18 : Seen := { me := ⟨5, 4⟩, key := ⟨359, 9⟩, energy := 25, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f19 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f20 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 23, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f21 : Seen := { me := ⟨4, 6⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f22 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 9⟩, energy := 21, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f23 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 42, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f24 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 9⟩, energy := 40, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f25 : Seen := { me := ⟨7, 6⟩, key := ⟨359, 9⟩, energy := 38, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f26 : Seen := { me := ⟨6, 6⟩, key := ⟨359, 9⟩, energy := 36, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f27 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 34, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f28 : Seen := { me := ⟨4, 6⟩, key := ⟨359, 9⟩, energy := 32, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f29 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 9⟩, energy := 30, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f30 : Seen := { me := ⟨2, 6⟩, key := ⟨359, 9⟩, energy := 28, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f31 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f32 : Seen := { me := ⟨2, 8⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f33 : Seen := { me := ⟨3, 8⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f34 : Seen := { me := ⟨3, 9⟩, key := ⟨359, 9⟩, energy := 20, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f35 : Seen := { me := ⟨4, 9⟩, key := ⟨359, 9⟩, energy := 18, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f36 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 9⟩, energy := 16, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f37 : Seen := { me := ⟨6, 9⟩, key := ⟨359, 9⟩, energy := 14, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f38 : Seen := { me := ⟨7, 9⟩, key := ⟨359, 9⟩, energy := 12, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f39 : Seen := { me := ⟨8, 9⟩, key := ⟨359, 9⟩, energy := 10, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f40 : Seen := { me := ⟨9, 9⟩, key := ⟨485, 9⟩, energy := 8, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f41 : Seen := { me := ⟨8, 9⟩, key := ⟨485, 9⟩, energy := 6, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f42 : Seen := { me := ⟨9, 9⟩, key := ⟨461, 9⟩, energy := 4, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f43 : Seen := { me := ⟨8, 9⟩, key := ⟨461, 9⟩, energy := 2, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f44 : Seen := { me := ⟨9, 9⟩, key := ⟨335, 9⟩, energy := 0, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f45 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 42, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f46 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 9⟩, energy := 40, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f47 : Seen := { me := ⟨7, 6⟩, key := ⟨359, 9⟩, energy := 38, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f48 : Seen := { me := ⟨6, 6⟩, key := ⟨359, 9⟩, energy := 36, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f49 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 34, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f50 : Seen := { me := ⟨4, 6⟩, key := ⟨359, 9⟩, energy := 32, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f51 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 9⟩, energy := 30, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f52 : Seen := { me := ⟨2, 6⟩, key := ⟨359, 9⟩, energy := 28, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f53 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 9⟩, energy := 26, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f54 : Seen := { me := ⟨2, 8⟩, key := ⟨359, 9⟩, energy := 24, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f55 : Seen := { me := ⟨3, 8⟩, key := ⟨359, 9⟩, energy := 22, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f56 : Seen := { me := ⟨3, 9⟩, key := ⟨359, 9⟩, energy := 20, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f57 : Seen := { me := ⟨4, 9⟩, key := ⟨359, 9⟩, energy := 18, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f58 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 9⟩, energy := 16, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f59 : Seen := { me := ⟨6, 9⟩, key := ⟨359, 9⟩, energy := 14, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f60 : Seen := { me := ⟨7, 9⟩, key := ⟨359, 9⟩, energy := 12, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f61 : Seen := { me := ⟨8, 9⟩, key := ⟨359, 9⟩, energy := 10, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f62 : Seen := { me := ⟨9, 9⟩, key := ⟨485, 9⟩, energy := 8, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f63 : Seen := { me := ⟨10, 9⟩, key := ⟨485, 9⟩, energy := 6, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f64 : Seen := { me := ⟨10, 8⟩, key := ⟨485, 9⟩, energy := 4, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f65 : Seen := { me := ⟨10, 7⟩, key := ⟨485, 9⟩, energy := 42, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f66 : Seen := { me := ⟨10, 8⟩, key := ⟨485, 9⟩, energy := 40, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f67 : Seen := { me := ⟨9, 8⟩, key := ⟨485, 9⟩, energy := 38, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f68 : Seen := { me := ⟨9, 9⟩, key := ⟨461, 9⟩, energy := 36, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f69 : Seen := { me := ⟨8, 9⟩, key := ⟨461, 9⟩, energy := 34, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f70 : Seen := { me := ⟨9, 9⟩, key := ⟨335, 9⟩, energy := 32, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f71 : Seen := { me := ⟨8, 9⟩, key := ⟨335, 9⟩, energy := 30, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f72 : Seen := { me := ⟨7, 9⟩, key := ⟨335, 9⟩, energy := 28, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f73 : Seen := { me := ⟨6, 9⟩, key := ⟨335, 9⟩, energy := 26, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f74 : Seen := { me := ⟨5, 9⟩, key := ⟨335, 9⟩, energy := 24, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f75 : Seen := { me := ⟨4, 9⟩, key := ⟨335, 9⟩, energy := 22, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f76 : Seen := { me := ⟨3, 9⟩, key := ⟨335, 9⟩, energy := 20, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f77 : Seen := { me := ⟨2, 9⟩, key := ⟨335, 9⟩, energy := 18, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f78 : Seen := { me := ⟨2, 8⟩, key := ⟨335, 9⟩, energy := 16, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f79 : Seen := { me := ⟨2, 7⟩, key := ⟨335, 9⟩, energy := 14, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f80 : Seen := { me := ⟨2, 6⟩, key := ⟨335, 9⟩, energy := 12, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f81 : Seen := { me := ⟨2, 5⟩, key := ⟨335, 9⟩, energy := 10, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f82 : Seen := { me := ⟨2, 4⟩, key := ⟨335, 9⟩, energy := 8, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f83 : Seen := { me := ⟨2, 3⟩, key := ⟨335, 9⟩, energy := 6, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f84 : Seen := { me := ⟨3, 3⟩, key := ⟨335, 9⟩, energy := 4, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f85 : Seen := { me := ⟨3, 2⟩, key := ⟨335, 9⟩, energy := 42, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f86 : Seen := { me := ⟨4, 2⟩, key := ⟨335, 9⟩, energy := 40, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f87 : Seen := { me := ⟨5, 2⟩, key := ⟨335, 9⟩, energy := 38, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f88 : Seen := { me := ⟨6, 2⟩, key := ⟨335, 9⟩, energy := 36, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f89 : Seen := { me := ⟨7, 2⟩, key := ⟨335, 9⟩, energy := 34, lives := 2, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f90 : Seen := { me := ⟨9, 1⟩, key := ⟨359, 12⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f91 : Seen := { me := ⟨8, 1⟩, key := ⟨359, 12⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f92 : Seen := { me := ⟨7, 1⟩, key := ⟨359, 12⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f93 : Seen := { me := ⟨6, 1⟩, key := ⟨359, 12⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f94 : Seen := { me := ⟨5, 1⟩, key := ⟨359, 12⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f95 : Seen := { me := ⟨4, 1⟩, key := ⟨359, 12⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f96 : Seen := { me := ⟨3, 1⟩, key := ⟨359, 12⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f97 : Seen := { me := ⟨2, 1⟩, key := ⟨359, 12⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f98 : Seen := { me := ⟨1, 6⟩, key := ⟨359, 12⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f99 : Seen := { me := ⟨1, 5⟩, key := ⟨359, 12⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f100 : Seen := { me := ⟨2, 5⟩, key := ⟨359, 12⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f101 : Seen := { me := ⟨3, 5⟩, key := ⟨359, 12⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f102 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 12⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f103 : Seen := { me := ⟨4, 6⟩, key := ⟨359, 12⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f104 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 12⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f105 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 12⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f106 : Seen := { me := ⟨5, 8⟩, key := ⟨359, 12⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f107 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 12⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f108 : Seen := { me := ⟨5, 10⟩, key := ⟨359, 12⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f109 : Seen := { me := ⟨4, 10⟩, key := ⟨359, 12⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f110 : Seen := { me := ⟨3, 10⟩, key := ⟨359, 12⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f111 : Seen := { me := ⟨2, 10⟩, key := ⟨359, 12⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f112 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 12⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f113 : Seen := { me := ⟨1, 9⟩, key := ⟨485, 12⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f114 : Seen := { me := ⟨2, 9⟩, key := ⟨461, 12⟩, energy := 18, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f115 : Seen := { me := ⟨1, 9⟩, key := ⟨461, 12⟩, energy := 16, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f116 : Seen := { me := ⟨9, 10⟩, key := ⟨461, 12⟩, energy := 14, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f117 : Seen := { me := ⟨8, 10⟩, key := ⟨461, 12⟩, energy := 12, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f118 : Seen := { me := ⟨7, 10⟩, key := ⟨461, 12⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f119 : Seen := { me := ⟨6, 10⟩, key := ⟨461, 12⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f120 : Seen := { me := ⟨5, 10⟩, key := ⟨461, 12⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f121 : Seen := { me := ⟨4, 10⟩, key := ⟨461, 12⟩, energy := 4, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f122 : Seen := { me := ⟨3, 10⟩, key := ⟨461, 12⟩, energy := 2, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f123 : Seen := { me := ⟨2, 10⟩, key := ⟨461, 12⟩, energy := 0, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f124 : Seen := { me := ⟨9, 1⟩, key := ⟨359, 12⟩, energy := 42, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f125 : Seen := { me := ⟨8, 1⟩, key := ⟨359, 12⟩, energy := 40, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f126 : Seen := { me := ⟨7, 1⟩, key := ⟨359, 12⟩, energy := 38, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f127 : Seen := { me := ⟨6, 1⟩, key := ⟨359, 12⟩, energy := 36, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f128 : Seen := { me := ⟨5, 1⟩, key := ⟨359, 12⟩, energy := 34, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f129 : Seen := { me := ⟨4, 1⟩, key := ⟨359, 12⟩, energy := 32, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f130 : Seen := { me := ⟨3, 1⟩, key := ⟨359, 12⟩, energy := 30, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f131 : Seen := { me := ⟨2, 1⟩, key := ⟨359, 12⟩, energy := 28, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f132 : Seen := { me := ⟨1, 6⟩, key := ⟨359, 12⟩, energy := 26, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f133 : Seen := { me := ⟨1, 5⟩, key := ⟨359, 12⟩, energy := 24, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f134 : Seen := { me := ⟨2, 5⟩, key := ⟨359, 12⟩, energy := 22, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f135 : Seen := { me := ⟨3, 5⟩, key := ⟨359, 12⟩, energy := 20, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f136 : Seen := { me := ⟨4, 5⟩, key := ⟨359, 12⟩, energy := 18, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f137 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 12⟩, energy := 16, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f138 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 12⟩, energy := 14, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f139 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 12⟩, energy := 12, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f140 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 12⟩, energy := 10, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f141 : Seen := { me := ⟨8, 4⟩, key := ⟨359, 12⟩, energy := 8, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f142 : Seen := { me := ⟨9, 4⟩, key := ⟨359, 12⟩, energy := 6, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f143 : Seen := { me := ⟨9, 5⟩, key := ⟨359, 9⟩, energy := 4, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f144 : Seen := { me := ⟨9, 4⟩, key := ⟨359, 9⟩, energy := 2, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f145 : Seen := { me := ⟨9, 5⟩, key := ⟨359, 14⟩, energy := 0, lives := 2, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f146 : Seen := { me := ⟨9, 1⟩, key := ⟨359, 12⟩, energy := 42, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f147 : Seen := { me := ⟨8, 1⟩, key := ⟨359, 12⟩, energy := 40, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f148 : Seen := { me := ⟨7, 1⟩, key := ⟨359, 12⟩, energy := 38, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f149 : Seen := { me := ⟨6, 1⟩, key := ⟨359, 12⟩, energy := 36, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f150 : Seen := { me := ⟨5, 1⟩, key := ⟨359, 12⟩, energy := 34, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f151 : Seen := { me := ⟨4, 1⟩, key := ⟨359, 12⟩, energy := 32, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f152 : Seen := { me := ⟨3, 1⟩, key := ⟨359, 12⟩, energy := 30, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f153 : Seen := { me := ⟨2, 1⟩, key := ⟨359, 12⟩, energy := 28, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f154 : Seen := { me := ⟨1, 6⟩, key := ⟨359, 12⟩, energy := 26, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f155 : Seen := { me := ⟨1, 5⟩, key := ⟨359, 12⟩, energy := 24, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f156 : Seen := { me := ⟨2, 5⟩, key := ⟨359, 12⟩, energy := 22, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f157 : Seen := { me := ⟨3, 5⟩, key := ⟨359, 12⟩, energy := 20, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f158 : Seen := { me := ⟨4, 5⟩, key := ⟨359, 12⟩, energy := 18, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f159 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 12⟩, energy := 16, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f160 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 12⟩, energy := 14, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f161 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 12⟩, energy := 12, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f162 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 12⟩, energy := 10, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f163 : Seen := { me := ⟨9, 5⟩, key := ⟨359, 9⟩, energy := 8, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f164 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 6, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f165 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 9⟩, energy := 4, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f166 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 9⟩, energy := 2, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f167 : Seen := { me := ⟨6, 4⟩, key := ⟨359, 9⟩, energy := 0, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f168 : Seen := { me := ⟨6, 3⟩, key := ⟨359, 9⟩, energy := 42, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f169 : Seen := { me := ⟨5, 3⟩, key := ⟨359, 9⟩, energy := 40, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f170 : Seen := { me := ⟨5, 4⟩, key := ⟨359, 9⟩, energy := 38, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f171 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 9⟩, energy := 36, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f172 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 34, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f173 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 9⟩, energy := 32, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f174 : Seen := { me := ⟨5, 8⟩, key := ⟨359, 9⟩, energy := 30, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f175 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 9⟩, energy := 28, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f176 : Seen := { me := ⟨5, 10⟩, key := ⟨359, 9⟩, energy := 26, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f177 : Seen := { me := ⟨4, 10⟩, key := ⟨359, 9⟩, energy := 24, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f178 : Seen := { me := ⟨3, 10⟩, key := ⟨359, 9⟩, energy := 22, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f179 : Seen := { me := ⟨2, 10⟩, key := ⟨359, 9⟩, energy := 20, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f180 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 9⟩, energy := 18, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f181 : Seen := { me := ⟨1, 9⟩, key := ⟨485, 9⟩, energy := 16, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f182 : Seen := { me := ⟨2, 9⟩, key := ⟨461, 9⟩, energy := 14, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f183 : Seen := { me := ⟨1, 9⟩, key := ⟨461, 9⟩, energy := 12, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f184 : Seen := { me := ⟨9, 10⟩, key := ⟨461, 9⟩, energy := 10, lives := 1, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f185 : Seen := { me := ⟨1, 10⟩, key := ⟨410, 14⟩, energy := 42, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f186 : Seen := { me := ⟨1, 9⟩, key := ⟨410, 14⟩, energy := 41, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f187 : Seen := { me := ⟨1, 8⟩, key := ⟨410, 14⟩, energy := 40, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f188 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 14⟩, energy := 39, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f189 : Seen := { me := ⟨2, 7⟩, key := ⟨410, 14⟩, energy := 38, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f190 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 14⟩, energy := 37, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f191 : Seen := { me := ⟨4, 7⟩, key := ⟨410, 14⟩, energy := 36, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f192 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 14⟩, energy := 35, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f193 : Seen := { me := ⟨2, 7⟩, key := ⟨410, 14⟩, energy := 34, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f194 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 14⟩, energy := 33, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f195 : Seen := { me := ⟨4, 7⟩, key := ⟨410, 14⟩, energy := 32, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f196 : Seen := { me := ⟨4, 10⟩, key := ⟨410, 14⟩, energy := 31, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f197 : Seen := { me := ⟨5, 10⟩, key := ⟨410, 14⟩, energy := 30, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f198 : Seen := { me := ⟨6, 10⟩, key := ⟨410, 14⟩, energy := 29, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f199 : Seen := { me := ⟨6, 9⟩, key := ⟨410, 14⟩, energy := 28, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f200 : Seen := { me := ⟨6, 8⟩, key := ⟨410, 14⟩, energy := 27, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f201 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 26, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f202 : Seen := { me := ⟨6, 6⟩, key := ⟨410, 8⟩, energy := 25, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f203 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 8⟩, energy := 24, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f204 : Seen := { me := ⟨6, 6⟩, key := ⟨410, 12⟩, energy := 23, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f205 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 12⟩, energy := 22, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f206 : Seen := { me := ⟨4, 10⟩, key := ⟨410, 12⟩, energy := 21, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f207 : Seen := { me := ⟨4, 9⟩, key := ⟨410, 12⟩, energy := 20, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f208 : Seen := { me := ⟨9, 8⟩, key := ⟨410, 12⟩, energy := 19, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f209 : Seen := { me := ⟨8, 6⟩, key := ⟨410, 12⟩, energy := 18, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f210 : Seen := { me := ⟨9, 6⟩, key := ⟨410, 12⟩, energy := 17, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f211 : Seen := { me := ⟨10, 6⟩, key := ⟨410, 12⟩, energy := 42, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f212 : Seen := { me := ⟨10, 5⟩, key := ⟨410, 12⟩, energy := 41, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f213 : Seen := { me := ⟨9, 5⟩, key := ⟨410, 12⟩, energy := 40, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f214 : Seen := { me := ⟨9, 4⟩, key := ⟨410, 12⟩, energy := 39, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f215 : Seen := { me := ⟨8, 1⟩, key := ⟨410, 12⟩, energy := 38, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f216 : Seen := { me := ⟨7, 4⟩, key := ⟨410, 12⟩, energy := 37, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f217 : Seen := { me := ⟨6, 4⟩, key := ⟨359, 12⟩, energy := 36, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f218 : Seen := { me := ⟨7, 4⟩, key := ⟨359, 12⟩, energy := 35, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f219 : Seen := { me := ⟨8, 1⟩, key := ⟨359, 12⟩, energy := 34, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f220 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 12⟩, energy := 33, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f221 : Seen := { me := ⟨7, 2⟩, key := ⟨359, 12⟩, energy := 32, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f222 : Seen := { me := ⟨6, 2⟩, key := ⟨359, 12⟩, energy := 31, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f223 : Seen := { me := ⟨5, 2⟩, key := ⟨359, 12⟩, energy := 30, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f224 : Seen := { me := ⟨4, 2⟩, key := ⟨359, 12⟩, energy := 29, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f225 : Seen := { me := ⟨4, 3⟩, key := ⟨359, 12⟩, energy := 28, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩] }
def f226 : Seen := { me := ⟨3, 3⟩, key := ⟨359, 12⟩, energy := 42, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f227 : Seen := { me := ⟨3, 4⟩, key := ⟨359, 12⟩, energy := 41, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f228 : Seen := { me := ⟨3, 5⟩, key := ⟨359, 12⟩, energy := 40, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f229 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 12⟩, energy := 39, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f230 : Seen := { me := ⟨4, 10⟩, key := ⟨359, 12⟩, energy := 38, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f231 : Seen := { me := ⟨5, 10⟩, key := ⟨359, 12⟩, energy := 37, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f232 : Seen := { me := ⟨6, 10⟩, key := ⟨359, 12⟩, energy := 36, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f233 : Seen := { me := ⟨6, 9⟩, key := ⟨359, 12⟩, energy := 35, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f234 : Seen := { me := ⟨6, 8⟩, key := ⟨359, 12⟩, energy := 34, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f235 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 12⟩, energy := 33, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f236 : Seen := { me := ⟨6, 6⟩, key := ⟨359, 9⟩, energy := 32, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [] }
def f237 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 31, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f238 : Seen := { me := ⟨1, 7⟩, key := ⟨359, 9⟩, energy := 30, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f239 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 9⟩, energy := 29, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f240 : Seen := { me := ⟨3, 7⟩, key := ⟨359, 9⟩, energy := 28, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f241 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 9⟩, energy := 27, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f242 : Seen := { me := ⟨3, 5⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f243 : Seen := { me := ⟨3, 4⟩, key := ⟨359, 9⟩, energy := 25, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f244 : Seen := { me := ⟨2, 4⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f245 : Seen := { me := ⟨1, 4⟩, key := ⟨359, 9⟩, energy := 23, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f246 : Seen := { me := ⟨1, 3⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f247 : Seen := { me := ⟨1, 2⟩, key := ⟨359, 9⟩, energy := 21, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [] }
def f248 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 42, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f249 : Seen := { me := ⟨7, 9⟩, key := ⟨410, 12⟩, energy := 40, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f250 : Seen := { me := ⟨7, 8⟩, key := ⟨410, 12⟩, energy := 38, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f251 : Seen := { me := ⟨6, 8⟩, key := ⟨410, 12⟩, energy := 36, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f252 : Seen := { me := ⟨5, 8⟩, key := ⟨410, 12⟩, energy := 34, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f253 : Seen := { me := ⟨4, 8⟩, key := ⟨410, 12⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f254 : Seen := { me := ⟨3, 8⟩, key := ⟨410, 12⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f255 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 12⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f256 : Seen := { me := ⟨3, 6⟩, key := ⟨410, 12⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f257 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 12⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f258 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 12⟩, energy := 22, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f259 : Seen := { me := ⟨2, 4⟩, key := ⟨410, 12⟩, energy := 20, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f260 : Seen := { me := ⟨2, 3⟩, key := ⟨359, 12⟩, energy := 18, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f261 : Seen := { me := ⟨3, 3⟩, key := ⟨359, 12⟩, energy := 16, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f262 : Seen := { me := ⟨2, 3⟩, key := ⟨371, 12⟩, energy := 14, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f263 : Seen := { me := ⟨2, 2⟩, key := ⟨371, 12⟩, energy := 12, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f264 : Seen := { me := ⟨2, 1⟩, key := ⟨371, 12⟩, energy := 42, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f265 : Seen := { me := ⟨2, 2⟩, key := ⟨371, 12⟩, energy := 40, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f266 : Seen := { me := ⟨3, 2⟩, key := ⟨371, 12⟩, energy := 38, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f267 : Seen := { me := ⟨3, 3⟩, key := ⟨371, 12⟩, energy := 36, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f268 : Seen := { me := ⟨4, 3⟩, key := ⟨371, 12⟩, energy := 34, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f269 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 12⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f270 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 12⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f271 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 12⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f272 : Seen := { me := ⟨8, 1⟩, key := ⟨371, 12⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f273 : Seen := { me := ⟨8, 2⟩, key := ⟨371, 12⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨9, 2⟩] }
def f274 : Seen := { me := ⟨9, 2⟩, key := ⟨371, 12⟩, energy := 42, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f275 : Seen := { me := ⟨8, 2⟩, key := ⟨371, 12⟩, energy := 40, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f276 : Seen := { me := ⟨7, 2⟩, key := ⟨245, 12⟩, energy := 38, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f277 : Seen := { me := ⟨7, 3⟩, key := ⟨413, 12⟩, energy := 36, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f278 : Seen := { me := ⟨7, 4⟩, key := ⟨350, 12⟩, energy := 34, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f279 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f280 : Seen := { me := ⟨7, 4⟩, key := ⟨350, 12⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f281 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f282 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f283 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f284 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 22, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f285 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 20, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f286 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 18, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f287 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 16, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f288 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 14, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f289 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 12, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f290 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 10, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f291 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 8, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f292 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 6, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f293 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 4, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f294 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 12⟩, energy := 2, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f295 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 12⟩, energy := 0, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩] }
def f296 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 42, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f297 : Seen := { me := ⟨7, 9⟩, key := ⟨410, 12⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f298 : Seen := { me := ⟨7, 8⟩, key := ⟨410, 12⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f299 : Seen := { me := ⟨6, 8⟩, key := ⟨410, 12⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f300 : Seen := { me := ⟨5, 8⟩, key := ⟨410, 12⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f301 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 12⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f302 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 12⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f303 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 9⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f304 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 9⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f305 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 14⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f306 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 22, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f307 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 8⟩, energy := 20, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f308 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 8⟩, energy := 18, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f309 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 8⟩, energy := 16, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f310 : Seen := { me := ⟨1, 8⟩, key := ⟨410, 8⟩, energy := 42, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f311 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 8⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f312 : Seen := { me := ⟨2, 7⟩, key := ⟨410, 8⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f313 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 8⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f314 : Seen := { me := ⟨3, 6⟩, key := ⟨410, 8⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f315 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 8⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f316 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 8⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f317 : Seen := { me := ⟨2, 4⟩, key := ⟨410, 8⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f318 : Seen := { me := ⟨2, 3⟩, key := ⟨359, 8⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f319 : Seen := { me := ⟨1, 3⟩, key := ⟨359, 8⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f320 : Seen := { me := ⟨2, 3⟩, key := ⟨371, 8⟩, energy := 22, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f321 : Seen := { me := ⟨3, 3⟩, key := ⟨371, 8⟩, energy := 20, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f322 : Seen := { me := ⟨4, 3⟩, key := ⟨371, 8⟩, energy := 18, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f323 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 16, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f324 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 14, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f325 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 12, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f326 : Seen := { me := ⟨7, 2⟩, key := ⟨371, 8⟩, energy := 10, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f327 : Seen := { me := ⟨7, 3⟩, key := ⟨245, 8⟩, energy := 8, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f328 : Seen := { me := ⟨7, 2⟩, key := ⟨413, 8⟩, energy := 6, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f329 : Seen := { me := ⟨8, 2⟩, key := ⟨413, 8⟩, energy := 4, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f330 : Seen := { me := ⟨9, 2⟩, key := ⟨413, 8⟩, energy := 42, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f331 : Seen := { me := ⟨9, 3⟩, key := ⟨413, 8⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f332 : Seen := { me := ⟨10, 3⟩, key := ⟨413, 8⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f333 : Seen := { me := ⟨10, 4⟩, key := ⟨413, 8⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f334 : Seen := { me := ⟨10, 5⟩, key := ⟨413, 8⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f335 : Seen := { me := ⟨10, 6⟩, key := ⟨413, 8⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f336 : Seen := { me := ⟨10, 7⟩, key := ⟨413, 8⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f337 : Seen := { me := ⟨10, 8⟩, key := ⟨413, 8⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f338 : Seen := { me := ⟨10, 9⟩, key := ⟨413, 8⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f339 : Seen := { me := ⟨2, 10⟩, key := ⟨413, 8⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f340 : Seen := { me := ⟨10, 4⟩, key := ⟨371, 14⟩, energy := 42, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f341 : Seen := { me := ⟨9, 4⟩, key := ⟨371, 14⟩, energy := 41, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f342 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f343 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f344 : Seen := { me := ⟨8, 6⟩, key := ⟨371, 14⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f345 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f346 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f347 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f348 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f349 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f350 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f351 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f352 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f353 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f354 : Seen := { me := ⟨9, 5⟩, key := ⟨371, 14⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f355 : Seen := { me := ⟨9, 6⟩, key := ⟨371, 14⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f356 : Seen := { me := ⟨8, 6⟩, key := ⟨245, 14⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f357 : Seen := { me := ⟨8, 5⟩, key := ⟨413, 14⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f358 : Seen := { me := ⟨8, 6⟩, key := ⟨413, 14⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f359 : Seen := { me := ⟨8, 7⟩, key := ⟨413, 14⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f360 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 14⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f361 : Seen := { me := ⟨6, 7⟩, key := ⟨413, 14⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f362 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f363 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f364 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 14⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f365 : Seen := { me := ⟨6, 5⟩, key := ⟨413, 14⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f366 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 14⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f367 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f368 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f369 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 14⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f370 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 14⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f371 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 14⟩, energy := 11, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f372 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 14⟩, energy := 10, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f373 : Seen := { me := ⟨2, 7⟩, key := ⟨413, 14⟩, energy := 9, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f374 : Seen := { me := ⟨1, 7⟩, key := ⟨413, 14⟩, energy := 42, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f375 : Seen := { me := ⟨2, 7⟩, key := ⟨413, 14⟩, energy := 41, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f376 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f377 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f378 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f379 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f380 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 14⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f381 : Seen := { me := ⟨6, 5⟩, key := ⟨413, 14⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f382 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 14⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f383 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f384 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f385 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 14⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f386 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 14⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f387 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 14⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f388 : Seen := { me := ⟨4, 8⟩, key := ⟨413, 14⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f389 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 14⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f390 : Seen := { me := ⟨4, 8⟩, key := ⟨413, 14⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f391 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 14⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f392 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f393 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f394 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 8⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f395 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 8⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f396 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f397 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f398 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f399 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 8⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f400 : Seen := { me := ⟨3, 9⟩, key := ⟨413, 8⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f401 : Seen := { me := ⟨2, 9⟩, key := ⟨413, 8⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f402 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f403 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f404 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f405 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 11, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f406 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f407 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 9, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f408 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f409 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 7, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f410 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f411 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 5, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f412 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 4, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f413 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 3, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f414 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 2, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f415 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 1, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f416 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 0, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f417 : Seen := { me := ⟨10, 4⟩, key := ⟨371, 14⟩, energy := 42, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f418 : Seen := { me := ⟨9, 4⟩, key := ⟨371, 14⟩, energy := 41, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f419 : Seen := { me := ⟨8, 4⟩, key := ⟨245, 14⟩, energy := 40, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f420 : Seen := { me := ⟨9, 4⟩, key := ⟨245, 14⟩, energy := 39, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f421 : Seen := { me := ⟨9, 3⟩, key := ⟨245, 14⟩, energy := 38, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f422 : Seen := { me := ⟨9, 4⟩, key := ⟨245, 14⟩, energy := 37, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f423 : Seen := { me := ⟨8, 4⟩, key := ⟨413, 14⟩, energy := 36, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f424 : Seen := { me := ⟨9, 4⟩, key := ⟨413, 14⟩, energy := 35, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f425 : Seen := { me := ⟨9, 3⟩, key := ⟨413, 14⟩, energy := 34, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f426 : Seen := { me := ⟨9, 4⟩, key := ⟨413, 14⟩, energy := 33, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f427 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 14⟩, energy := 32, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f428 : Seen := { me := ⟨9, 5⟩, key := ⟨335, 9⟩, energy := 41, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f429 : Seen := { me := ⟨9, 4⟩, key := ⟨335, 9⟩, energy := 40, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f430 : Seen := { me := ⟨9, 3⟩, key := ⟨335, 9⟩, energy := 39, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f431 : Seen := { me := ⟨8, 3⟩, key := ⟨335, 9⟩, energy := 38, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f432 : Seen := { me := ⟨7, 3⟩, key := ⟨335, 9⟩, energy := 37, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f433 : Seen := { me := ⟨6, 3⟩, key := ⟨359, 9⟩, energy := 37, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f434 : Seen := { me := ⟨5, 3⟩, key := ⟨359, 9⟩, energy := 36, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f435 : Seen := { me := ⟨5, 4⟩, key := ⟨359, 9⟩, energy := 35, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f436 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 9⟩, energy := 34, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f437 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 33, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f438 : Seen := { me := ⟨4, 6⟩, key := ⟨359, 9⟩, energy := 32, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f439 : Seen := { me := ⟨3, 6⟩, key := ⟨359, 9⟩, energy := 31, lives := 3, goals := [⟨⟨2, 6⟩, ⟨359, 9⟩⟩], rotators := [⟨6, 3⟩], shapers := [], painters := [], refills := [] }
def f440 : Seen := { me := ⟨10, 9⟩, key := ⟨485, 9⟩, energy := 6, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f441 : Seen := { me := ⟨10, 8⟩, key := ⟨485, 9⟩, energy := 4, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩, ⟨10, 7⟩] }
def f442 : Seen := { me := ⟨10, 7⟩, key := ⟨485, 9⟩, energy := 42, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f443 : Seen := { me := ⟨10, 8⟩, key := ⟨485, 9⟩, energy := 40, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f444 : Seen := { me := ⟨9, 8⟩, key := ⟨485, 9⟩, energy := 38, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f445 : Seen := { me := ⟨9, 9⟩, key := ⟨461, 9⟩, energy := 36, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f446 : Seen := { me := ⟨8, 9⟩, key := ⟨461, 9⟩, energy := 34, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f447 : Seen := { me := ⟨9, 9⟩, key := ⟨335, 9⟩, energy := 32, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f448 : Seen := { me := ⟨8, 9⟩, key := ⟨335, 9⟩, energy := 30, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f449 : Seen := { me := ⟨7, 9⟩, key := ⟨335, 9⟩, energy := 28, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f450 : Seen := { me := ⟨6, 9⟩, key := ⟨335, 9⟩, energy := 26, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f451 : Seen := { me := ⟨5, 9⟩, key := ⟨335, 9⟩, energy := 24, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f452 : Seen := { me := ⟨4, 9⟩, key := ⟨335, 9⟩, energy := 22, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f453 : Seen := { me := ⟨3, 9⟩, key := ⟨335, 9⟩, energy := 20, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f454 : Seen := { me := ⟨2, 9⟩, key := ⟨335, 9⟩, energy := 18, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f455 : Seen := { me := ⟨2, 8⟩, key := ⟨335, 9⟩, energy := 16, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f456 : Seen := { me := ⟨2, 7⟩, key := ⟨335, 9⟩, energy := 14, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f457 : Seen := { me := ⟨2, 6⟩, key := ⟨335, 9⟩, energy := 12, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f458 : Seen := { me := ⟨2, 5⟩, key := ⟨335, 9⟩, energy := 10, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f459 : Seen := { me := ⟨2, 4⟩, key := ⟨335, 9⟩, energy := 8, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f460 : Seen := { me := ⟨2, 3⟩, key := ⟨335, 9⟩, energy := 6, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f461 : Seen := { me := ⟨3, 3⟩, key := ⟨335, 9⟩, energy := 4, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [⟨3, 2⟩] }
def f462 : Seen := { me := ⟨3, 2⟩, key := ⟨335, 9⟩, energy := 42, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f463 : Seen := { me := ⟨4, 2⟩, key := ⟨335, 9⟩, energy := 40, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f464 : Seen := { me := ⟨5, 2⟩, key := ⟨335, 9⟩, energy := 38, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f465 : Seen := { me := ⟨6, 2⟩, key := ⟨335, 9⟩, energy := 36, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f466 : Seen := { me := ⟨7, 2⟩, key := ⟨335, 9⟩, energy := 34, lives := 3, goals := [⟨⟨8, 2⟩, ⟨335, 9⟩⟩], rotators := [⟨9, 9⟩], shapers := [], painters := [], refills := [] }
def f467 : Seen := { me := ⟨6, 6⟩, key := ⟨359, 12⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f468 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 12⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f469 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 12⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f470 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 12⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f471 : Seen := { me := ⟨9, 5⟩, key := ⟨359, 9⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [], refills := [⟨6, 3⟩] }
def f472 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f473 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f474 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f475 : Seen := { me := ⟨6, 4⟩, key := ⟨359, 9⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨6, 3⟩] }
def f476 : Seen := { me := ⟨6, 3⟩, key := ⟨359, 9⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f477 : Seen := { me := ⟨5, 3⟩, key := ⟨359, 9⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f478 : Seen := { me := ⟨5, 4⟩, key := ⟨359, 9⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f479 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 9⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f480 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f481 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 9⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f482 : Seen := { me := ⟨5, 8⟩, key := ⟨359, 9⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f483 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 9⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f484 : Seen := { me := ⟨5, 10⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f485 : Seen := { me := ⟨4, 10⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f486 : Seen := { me := ⟨3, 10⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f487 : Seen := { me := ⟨2, 10⟩, key := ⟨359, 9⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f488 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 9⟩, energy := 18, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f489 : Seen := { me := ⟨1, 9⟩, key := ⟨485, 9⟩, energy := 16, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f490 : Seen := { me := ⟨2, 9⟩, key := ⟨461, 9⟩, energy := 14, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f491 : Seen := { me := ⟨1, 9⟩, key := ⟨461, 9⟩, energy := 12, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f492 : Seen := { me := ⟨9, 10⟩, key := ⟨461, 9⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [] }
def f493 : Seen := { me := ⟨4, 10⟩, key := ⟨410, 14⟩, energy := 35, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f494 : Seen := { me := ⟨5, 10⟩, key := ⟨410, 14⟩, energy := 34, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f495 : Seen := { me := ⟨6, 10⟩, key := ⟨410, 14⟩, energy := 33, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f496 : Seen := { me := ⟨6, 9⟩, key := ⟨410, 14⟩, energy := 32, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f497 : Seen := { me := ⟨6, 8⟩, key := ⟨410, 14⟩, energy := 31, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f498 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 30, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f499 : Seen := { me := ⟨6, 6⟩, key := ⟨410, 8⟩, energy := 29, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f500 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 8⟩, energy := 28, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f501 : Seen := { me := ⟨6, 6⟩, key := ⟨410, 12⟩, energy := 27, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f502 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 12⟩, energy := 26, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f503 : Seen := { me := ⟨6, 6⟩, key := ⟨410, 9⟩, energy := 25, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f504 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 9⟩, energy := 24, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f505 : Seen := { me := ⟨4, 10⟩, key := ⟨410, 9⟩, energy := 23, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f506 : Seen := { me := ⟨4, 9⟩, key := ⟨410, 9⟩, energy := 22, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f507 : Seen := { me := ⟨9, 8⟩, key := ⟨410, 9⟩, energy := 21, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f508 : Seen := { me := ⟨8, 6⟩, key := ⟨410, 9⟩, energy := 20, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f509 : Seen := { me := ⟨9, 6⟩, key := ⟨410, 9⟩, energy := 19, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f510 : Seen := { me := ⟨9, 5⟩, key := ⟨410, 9⟩, energy := 18, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f511 : Seen := { me := ⟨9, 4⟩, key := ⟨410, 9⟩, energy := 17, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f512 : Seen := { me := ⟨8, 1⟩, key := ⟨410, 9⟩, energy := 16, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f513 : Seen := { me := ⟨7, 4⟩, key := ⟨410, 9⟩, energy := 15, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f514 : Seen := { me := ⟨6, 4⟩, key := ⟨359, 9⟩, energy := 14, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f515 : Seen := { me := ⟨7, 4⟩, key := ⟨359, 9⟩, energy := 13, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f516 : Seen := { me := ⟨8, 1⟩, key := ⟨359, 9⟩, energy := 12, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f517 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 9⟩, energy := 11, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f518 : Seen := { me := ⟨7, 2⟩, key := ⟨359, 9⟩, energy := 10, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f519 : Seen := { me := ⟨6, 2⟩, key := ⟨359, 9⟩, energy := 9, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f520 : Seen := { me := ⟨5, 2⟩, key := ⟨359, 9⟩, energy := 8, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f521 : Seen := { me := ⟨4, 2⟩, key := ⟨359, 9⟩, energy := 7, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f522 : Seen := { me := ⟨4, 3⟩, key := ⟨359, 9⟩, energy := 6, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨3, 3⟩, ⟨10, 6⟩] }
def f523 : Seen := { me := ⟨3, 3⟩, key := ⟨359, 9⟩, energy := 42, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f524 : Seen := { me := ⟨3, 4⟩, key := ⟨359, 9⟩, energy := 41, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f525 : Seen := { me := ⟨2, 4⟩, key := ⟨359, 9⟩, energy := 40, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f526 : Seen := { me := ⟨1, 4⟩, key := ⟨359, 9⟩, energy := 39, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f527 : Seen := { me := ⟨1, 3⟩, key := ⟨359, 9⟩, energy := 38, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f528 : Seen := { me := ⟨1, 2⟩, key := ⟨359, 9⟩, energy := 37, lives := 3, goals := [⟨⟨1, 1⟩, ⟨359, 9⟩⟩], rotators := [], shapers := [⟨6, 4⟩], painters := [⟨6, 6⟩], refills := [⟨10, 6⟩] }
def f529 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 12⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f530 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 12⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f531 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 9⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f532 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 9⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f533 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 14⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f534 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 22, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f535 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 8⟩, energy := 20, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f536 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 8⟩, energy := 18, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f537 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 8⟩, energy := 16, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f538 : Seen := { me := ⟨1, 8⟩, key := ⟨410, 8⟩, energy := 42, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f539 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 8⟩, energy := 40, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f540 : Seen := { me := ⟨2, 7⟩, key := ⟨410, 8⟩, energy := 38, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f541 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 8⟩, energy := 36, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f542 : Seen := { me := ⟨3, 6⟩, key := ⟨410, 8⟩, energy := 34, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f543 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 8⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f544 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 8⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f545 : Seen := { me := ⟨2, 4⟩, key := ⟨410, 8⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f546 : Seen := { me := ⟨2, 3⟩, key := ⟨359, 8⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f547 : Seen := { me := ⟨1, 3⟩, key := ⟨359, 8⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f548 : Seen := { me := ⟨2, 3⟩, key := ⟨371, 8⟩, energy := 22, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f549 : Seen := { me := ⟨3, 3⟩, key := ⟨371, 8⟩, energy := 20, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f550 : Seen := { me := ⟨4, 3⟩, key := ⟨371, 8⟩, energy := 18, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f551 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 16, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f552 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 14, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f553 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 12, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f554 : Seen := { me := ⟨7, 2⟩, key := ⟨371, 8⟩, energy := 10, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f555 : Seen := { me := ⟨7, 3⟩, key := ⟨245, 8⟩, energy := 8, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f556 : Seen := { me := ⟨7, 2⟩, key := ⟨413, 8⟩, energy := 6, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f557 : Seen := { me := ⟨8, 2⟩, key := ⟨413, 8⟩, energy := 4, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f558 : Seen := { me := ⟨9, 2⟩, key := ⟨413, 8⟩, energy := 42, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f559 : Seen := { me := ⟨9, 3⟩, key := ⟨413, 8⟩, energy := 40, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f560 : Seen := { me := ⟨10, 3⟩, key := ⟨413, 8⟩, energy := 38, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f561 : Seen := { me := ⟨10, 4⟩, key := ⟨413, 8⟩, energy := 36, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f562 : Seen := { me := ⟨10, 5⟩, key := ⟨413, 8⟩, energy := 34, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f563 : Seen := { me := ⟨10, 6⟩, key := ⟨413, 8⟩, energy := 32, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f564 : Seen := { me := ⟨10, 7⟩, key := ⟨413, 8⟩, energy := 30, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f565 : Seen := { me := ⟨10, 8⟩, key := ⟨413, 8⟩, energy := 28, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f566 : Seen := { me := ⟨10, 9⟩, key := ⟨413, 8⟩, energy := 26, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f567 : Seen := { me := ⟨2, 10⟩, key := ⟨413, 8⟩, energy := 24, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩] }
def f568 : Seen := { me := ⟨8, 4⟩, key := ⟨245, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f569 : Seen := { me := ⟨8, 5⟩, key := ⟨245, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f570 : Seen := { me := ⟨8, 6⟩, key := ⟨245, 14⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f571 : Seen := { me := ⟨8, 7⟩, key := ⟨245, 14⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f572 : Seen := { me := ⟨7, 7⟩, key := ⟨245, 14⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f573 : Seen := { me := ⟨6, 7⟩, key := ⟨245, 14⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f574 : Seen := { me := ⟨5, 7⟩, key := ⟨245, 14⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f575 : Seen := { me := ⟨4, 7⟩, key := ⟨245, 14⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f576 : Seen := { me := ⟨3, 7⟩, key := ⟨245, 14⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f577 : Seen := { me := ⟨2, 7⟩, key := ⟨245, 14⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f578 : Seen := { me := ⟨2, 6⟩, key := ⟨121, 14⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f579 : Seen := { me := ⟨2, 7⟩, key := ⟨121, 14⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f580 : Seen := { me := ⟨2, 6⟩, key := ⟨121, 14⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f581 : Seen := { me := ⟨2, 7⟩, key := ⟨121, 14⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f582 : Seen := { me := ⟨2, 6⟩, key := ⟨121, 14⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f583 : Seen := { me := ⟨2, 7⟩, key := ⟨121, 14⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f584 : Seen := { me := ⟨2, 6⟩, key := ⟨121, 14⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f585 : Seen := { me := ⟨2, 7⟩, key := ⟨121, 14⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f586 : Seen := { me := ⟨2, 6⟩, key := ⟨463, 14⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f587 : Seen := { me := ⟨2, 7⟩, key := ⟨463, 14⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f588 : Seen := { me := ⟨2, 6⟩, key := ⟨463, 14⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f589 : Seen := { me := ⟨2, 5⟩, key := ⟨463, 14⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f590 : Seen := { me := ⟨2, 4⟩, key := ⟨463, 14⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f591 : Seen := { me := ⟨2, 3⟩, key := ⟨426, 14⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f592 : Seen := { me := ⟨2, 4⟩, key := ⟨122, 14⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f593 : Seen := { me := ⟨2, 5⟩, key := ⟨485, 14⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f594 : Seen := { me := ⟨2, 4⟩, key := ⟨485, 14⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f595 : Seen := { me := ⟨1, 4⟩, key := ⟨485, 14⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f596 : Seen := { me := ⟨1, 5⟩, key := ⟨485, 14⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f597 : Seen := { me := ⟨1, 6⟩, key := ⟨485, 14⟩, energy := 11, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f598 : Seen := { me := ⟨1, 7⟩, key := ⟨485, 14⟩, energy := 42, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f599 : Seen := { me := ⟨2, 7⟩, key := ⟨485, 14⟩, energy := 41, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f600 : Seen := { me := ⟨3, 7⟩, key := ⟨485, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f601 : Seen := { me := ⟨4, 7⟩, key := ⟨485, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f602 : Seen := { me := ⟨5, 7⟩, key := ⟨485, 14⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f603 : Seen := { me := ⟨5, 6⟩, key := ⟨485, 14⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f604 : Seen := { me := ⟨5, 5⟩, key := ⟨485, 8⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f605 : Seen := { me := ⟨6, 5⟩, key := ⟨485, 12⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f606 : Seen := { me := ⟨6, 4⟩, key := ⟨485, 9⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f607 : Seen := { me := ⟨5, 4⟩, key := ⟨485, 9⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f608 : Seen := { me := ⟨5, 5⟩, key := ⟨485, 9⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f609 : Seen := { me := ⟨5, 6⟩, key := ⟨485, 9⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f610 : Seen := { me := ⟨5, 7⟩, key := ⟨485, 9⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f611 : Seen := { me := ⟨6, 7⟩, key := ⟨485, 9⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f612 : Seen := { me := ⟨7, 7⟩, key := ⟨485, 9⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f613 : Seen := { me := ⟨8, 7⟩, key := ⟨485, 9⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f614 : Seen := { me := ⟨8, 6⟩, key := ⟨461, 9⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f615 : Seen := { me := ⟨8, 5⟩, key := ⟨335, 9⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f616 : Seen := { me := ⟨8, 4⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f617 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f618 : Seen := { me := ⟨8, 6⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f619 : Seen := { me := ⟨8, 7⟩, key := ⟨359, 9⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f620 : Seen := { me := ⟨7, 7⟩, key := ⟨359, 9⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f621 : Seen := { me := ⟨6, 7⟩, key := ⟨359, 9⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f622 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 9⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f623 : Seen := { me := ⟨4, 7⟩, key := ⟨359, 9⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f624 : Seen := { me := ⟨3, 7⟩, key := ⟨359, 9⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f625 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 9⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f626 : Seen := { me := ⟨1, 7⟩, key := ⟨359, 9⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f627 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 9⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f628 : Seen := { me := ⟨2, 6⟩, key := ⟨359, 9⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f629 : Seen := { me := ⟨2, 5⟩, key := ⟨359, 9⟩, energy := 11, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f630 : Seen := { me := ⟨2, 4⟩, key := ⟨359, 9⟩, energy := 10, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f631 : Seen := { me := ⟨2, 3⟩, key := ⟨371, 9⟩, energy := 9, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f632 : Seen := { me := ⟨1, 3⟩, key := ⟨371, 9⟩, energy := 8, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f633 : Seen := { me := ⟨1, 2⟩, key := ⟨371, 9⟩, energy := 7, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f634 : Seen := { me := ⟨1, 1⟩, key := ⟨371, 9⟩, energy := 42, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f635 : Seen := { me := ⟨2, 1⟩, key := ⟨371, 9⟩, energy := 41, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f636 : Seen := { me := ⟨3, 1⟩, key := ⟨371, 9⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨9, 1⟩] }
def f637 : Seen := { me := ⟨4, 1⟩, key := ⟨371, 9⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨9, 1⟩] }
def f638 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 9⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨9, 1⟩] }
def f639 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 9⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨9, 1⟩] }
def f640 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 9⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨9, 1⟩] }
def f641 : Seen := { me := ⟨8, 1⟩, key := ⟨371, 9⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨9, 1⟩] }
def f642 : Seen := { me := ⟨8, 2⟩, key := ⟨245, 9⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f643 : Seen := { me := ⟨8, 3⟩, key := ⟨413, 9⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f644 : Seen := { me := ⟨8, 2⟩, key := ⟨413, 9⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨9, 1⟩] }
def f645 : Seen := { me := ⟨8, 1⟩, key := ⟨413, 9⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨9, 1⟩] }
def f646 : Seen := { me := ⟨7, 1⟩, key := ⟨413, 9⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨9, 1⟩] }
def f647 : Seen := { me := ⟨6, 1⟩, key := ⟨413, 9⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨9, 1⟩] }
def f648 : Seen := { me := ⟨5, 1⟩, key := ⟨413, 9⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨9, 1⟩] }
def f649 : Seen := { me := ⟨5, 2⟩, key := ⟨413, 9⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨9, 1⟩] }
def f650 : Seen := { me := ⟨5, 3⟩, key := ⟨413, 9⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f651 : Seen := { me := ⟨5, 4⟩, key := ⟨413, 9⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f652 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 14⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨9, 1⟩] }
def f653 : Seen := { me := ⟨6, 5⟩, key := ⟨413, 8⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨9, 1⟩] }
def f654 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 8⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨9, 1⟩] }
def f655 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 8⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨9, 1⟩] }
def f656 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨9, 1⟩] }
def f657 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨9, 1⟩] }
def f658 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f659 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 8⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f660 : Seen := { me := ⟨3, 9⟩, key := ⟨413, 8⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨9, 1⟩] }
def f661 : Seen := { me := ⟨2, 9⟩, key := ⟨413, 8⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨9, 1⟩] }
def f662 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨9, 1⟩] }
def f663 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨9, 1⟩] }
def f664 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨9, 1⟩] }
def f665 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 11, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨9, 1⟩] }
def f666 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f667 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 9, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f668 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨9, 1⟩] }
def f669 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 7, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨9, 1⟩] }
def f670 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨9, 1⟩] }
def f671 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 5, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨9, 1⟩] }
def f672 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 4, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨9, 1⟩] }
def f673 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 3, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨9, 1⟩] }
def f674 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 2, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨9, 1⟩] }
def f675 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 1, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨9, 1⟩] }
def f676 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 0, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨9, 1⟩] }
def f677 : Seen := { me := ⟨8, 5⟩, key := ⟨245, 14⟩, energy := 39, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f678 : Seen := { me := ⟨8, 6⟩, key := ⟨245, 14⟩, energy := 38, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f679 : Seen := { me := ⟨8, 7⟩, key := ⟨245, 14⟩, energy := 37, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f680 : Seen := { me := ⟨7, 7⟩, key := ⟨245, 14⟩, energy := 36, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f681 : Seen := { me := ⟨6, 7⟩, key := ⟨245, 14⟩, energy := 35, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f682 : Seen := { me := ⟨5, 7⟩, key := ⟨245, 14⟩, energy := 34, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f683 : Seen := { me := ⟨4, 7⟩, key := ⟨245, 14⟩, energy := 33, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f684 : Seen := { me := ⟨3, 7⟩, key := ⟨245, 14⟩, energy := 32, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f685 : Seen := { me := ⟨2, 7⟩, key := ⟨245, 14⟩, energy := 31, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f686 : Seen := { me := ⟨2, 6⟩, key := ⟨121, 14⟩, energy := 30, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f687 : Seen := { me := ⟨2, 5⟩, key := ⟨463, 14⟩, energy := 29, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f688 : Seen := { me := ⟨2, 4⟩, key := ⟨426, 14⟩, energy := 28, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f689 : Seen := { me := ⟨2, 3⟩, key := ⟨122, 14⟩, energy := 27, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f690 : Seen := { me := ⟨2, 2⟩, key := ⟨485, 14⟩, energy := 26, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f691 : Seen := { me := ⟨2, 1⟩, key := ⟨485, 14⟩, energy := 25, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f692 : Seen := { me := ⟨3, 1⟩, key := ⟨485, 14⟩, energy := 24, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f693 : Seen := { me := ⟨4, 1⟩, key := ⟨485, 14⟩, energy := 23, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f694 : Seen := { me := ⟨5, 1⟩, key := ⟨485, 14⟩, energy := 22, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f695 : Seen := { me := ⟨6, 1⟩, key := ⟨485, 14⟩, energy := 21, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f696 : Seen := { me := ⟨7, 1⟩, key := ⟨485, 14⟩, energy := 20, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f697 : Seen := { me := ⟨8, 1⟩, key := ⟨485, 14⟩, energy := 19, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f698 : Seen := { me := ⟨8, 2⟩, key := ⟨485, 14⟩, energy := 18, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f699 : Seen := { me := ⟨8, 3⟩, key := ⟨485, 14⟩, energy := 17, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f700 : Seen := { me := ⟨8, 4⟩, key := ⟨461, 14⟩, energy := 16, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f701 : Seen := { me := ⟨8, 3⟩, key := ⟨335, 14⟩, energy := 15, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f702 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 14⟩, energy := 14, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f703 : Seen := { me := ⟨8, 3⟩, key := ⟨485, 14⟩, energy := 13, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f704 : Seen := { me := ⟨8, 4⟩, key := ⟨461, 14⟩, energy := 12, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f705 : Seen := { me := ⟨8, 5⟩, key := ⟨335, 14⟩, energy := 11, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f706 : Seen := { me := ⟨8, 6⟩, key := ⟨359, 14⟩, energy := 10, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f707 : Seen := { me := ⟨8, 7⟩, key := ⟨359, 14⟩, energy := 9, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f708 : Seen := { me := ⟨7, 7⟩, key := ⟨359, 14⟩, energy := 8, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f709 : Seen := { me := ⟨6, 7⟩, key := ⟨359, 14⟩, energy := 7, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f710 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 14⟩, energy := 6, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f711 : Seen := { me := ⟨4, 7⟩, key := ⟨359, 14⟩, energy := 5, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f712 : Seen := { me := ⟨3, 7⟩, key := ⟨359, 14⟩, energy := 4, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f713 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 14⟩, energy := 3, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f714 : Seen := { me := ⟨1, 7⟩, key := ⟨359, 14⟩, energy := 42, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f715 : Seen := { me := ⟨2, 7⟩, key := ⟨359, 14⟩, energy := 41, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f716 : Seen := { me := ⟨2, 6⟩, key := ⟨359, 14⟩, energy := 40, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f717 : Seen := { me := ⟨2, 5⟩, key := ⟨371, 14⟩, energy := 39, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f718 : Seen := { me := ⟨1, 5⟩, key := ⟨371, 14⟩, energy := 38, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f719 : Seen := { me := ⟨1, 6⟩, key := ⟨371, 14⟩, energy := 37, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f720 : Seen := { me := ⟨2, 6⟩, key := ⟨371, 14⟩, energy := 36, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f721 : Seen := { me := ⟨2, 7⟩, key := ⟨371, 14⟩, energy := 35, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f722 : Seen := { me := ⟨3, 7⟩, key := ⟨371, 14⟩, energy := 34, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f723 : Seen := { me := ⟨4, 7⟩, key := ⟨371, 14⟩, energy := 33, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f724 : Seen := { me := ⟨5, 7⟩, key := ⟨371, 14⟩, energy := 32, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f725 : Seen := { me := ⟨6, 7⟩, key := ⟨371, 14⟩, energy := 31, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f726 : Seen := { me := ⟨7, 7⟩, key := ⟨371, 14⟩, energy := 30, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f727 : Seen := { me := ⟨8, 7⟩, key := ⟨371, 14⟩, energy := 29, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f728 : Seen := { me := ⟨8, 6⟩, key := ⟨371, 14⟩, energy := 28, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f729 : Seen := { me := ⟨8, 5⟩, key := ⟨245, 14⟩, energy := 27, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f730 : Seen := { me := ⟨8, 6⟩, key := ⟨413, 14⟩, energy := 26, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f731 : Seen := { me := ⟨8, 7⟩, key := ⟨413, 14⟩, energy := 25, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f732 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 14⟩, energy := 24, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f733 : Seen := { me := ⟨6, 7⟩, key := ⟨413, 14⟩, energy := 23, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f734 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 14⟩, energy := 22, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f735 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 14⟩, energy := 21, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f736 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 8⟩, energy := 20, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f737 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 8⟩, energy := 19, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f738 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 18, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f739 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 17, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f740 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 16, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f741 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 8⟩, energy := 15, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f742 : Seen := { me := ⟨3, 9⟩, key := ⟨413, 8⟩, energy := 14, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f743 : Seen := { me := ⟨2, 9⟩, key := ⟨413, 8⟩, energy := 13, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f744 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 12, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f745 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 11, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f746 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 10, lives := 2, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f747 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 9, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f748 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 8, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f749 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 7, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f750 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 6, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f751 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 5, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f752 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 4, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f753 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 3, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f754 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 2, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f755 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 1, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f756 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 0, lives := 2, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f757 : Seen := { me := ⟨10, 4⟩, key := ⟨371, 14⟩, energy := 42, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f758 : Seen := { me := ⟨9, 4⟩, key := ⟨371, 14⟩, energy := 41, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f759 : Seen := { me := ⟨8, 4⟩, key := ⟨245, 14⟩, energy := 40, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f760 : Seen := { me := ⟨8, 3⟩, key := ⟨413, 14⟩, energy := 39, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f761 : Seen := { me := ⟨8, 2⟩, key := ⟨350, 14⟩, energy := 38, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f762 : Seen := { me := ⟨8, 1⟩, key := ⟨350, 14⟩, energy := 37, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f763 : Seen := { me := ⟨7, 1⟩, key := ⟨350, 14⟩, energy := 36, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f764 : Seen := { me := ⟨6, 1⟩, key := ⟨350, 14⟩, energy := 35, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f765 : Seen := { me := ⟨5, 1⟩, key := ⟨350, 14⟩, energy := 34, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f766 : Seen := { me := ⟨5, 2⟩, key := ⟨350, 14⟩, energy := 33, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f767 : Seen := { me := ⟨5, 3⟩, key := ⟨350, 8⟩, energy := 32, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f768 : Seen := { me := ⟨5, 4⟩, key := ⟨350, 8⟩, energy := 31, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f769 : Seen := { me := ⟨5, 5⟩, key := ⟨350, 8⟩, energy := 30, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f770 : Seen := { me := ⟨5, 6⟩, key := ⟨350, 8⟩, energy := 29, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f771 : Seen := { me := ⟨5, 7⟩, key := ⟨350, 8⟩, energy := 28, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f772 : Seen := { me := ⟨4, 7⟩, key := ⟨350, 8⟩, energy := 27, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f773 : Seen := { me := ⟨3, 7⟩, key := ⟨350, 8⟩, energy := 26, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f774 : Seen := { me := ⟨2, 7⟩, key := ⟨350, 8⟩, energy := 25, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f775 : Seen := { me := ⟨1, 7⟩, key := ⟨350, 8⟩, energy := 42, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f776 : Seen := { me := ⟨2, 7⟩, key := ⟨350, 8⟩, energy := 41, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f777 : Seen := { me := ⟨1, 7⟩, key := ⟨350, 8⟩, energy := 40, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f778 : Seen := { me := ⟨2, 7⟩, key := ⟨350, 8⟩, energy := 39, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f779 : Seen := { me := ⟨3, 7⟩, key := ⟨350, 8⟩, energy := 38, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f780 : Seen := { me := ⟨4, 7⟩, key := ⟨350, 8⟩, energy := 37, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f781 : Seen := { me := ⟨5, 7⟩, key := ⟨350, 8⟩, energy := 36, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f782 : Seen := { me := ⟨6, 7⟩, key := ⟨350, 8⟩, energy := 35, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f783 : Seen := { me := ⟨7, 7⟩, key := ⟨350, 8⟩, energy := 34, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f784 : Seen := { me := ⟨8, 7⟩, key := ⟨350, 8⟩, energy := 33, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f785 : Seen := { me := ⟨8, 6⟩, key := ⟨350, 8⟩, energy := 32, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f786 : Seen := { me := ⟨8, 5⟩, key := ⟨350, 8⟩, energy := 31, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f787 : Seen := { me := ⟨8, 4⟩, key := ⟨371, 8⟩, energy := 30, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f788 : Seen := { me := ⟨8, 5⟩, key := ⟨245, 8⟩, energy := 29, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f789 : Seen := { me := ⟨8, 6⟩, key := ⟨413, 8⟩, energy := 28, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f790 : Seen := { me := ⟨8, 7⟩, key := ⟨413, 8⟩, energy := 27, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f791 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 8⟩, energy := 26, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f792 : Seen := { me := ⟨6, 7⟩, key := ⟨413, 8⟩, energy := 25, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f793 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 24, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f794 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 23, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f795 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 22, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f796 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 8⟩, energy := 21, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f797 : Seen := { me := ⟨3, 9⟩, key := ⟨413, 8⟩, energy := 20, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f798 : Seen := { me := ⟨2, 9⟩, key := ⟨413, 8⟩, energy := 19, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f799 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 18, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f800 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 17, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f801 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 16, lives := 1, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f802 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 15, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f803 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 14, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f804 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 13, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f805 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 12, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f806 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 11, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f807 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 10, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f808 : Seen := { me := ⟨6, 7⟩, key := ⟨413, 8⟩, energy := 9, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f809 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 8⟩, energy := 8, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f810 : Seen := { me := ⟨8, 7⟩, key := ⟨413, 8⟩, energy := 7, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f811 : Seen := { me := ⟨9, 7⟩, key := ⟨413, 8⟩, energy := 6, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f812 : Seen := { me := ⟨9, 6⟩, key := ⟨413, 8⟩, energy := 5, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f813 : Seen := { me := ⟨9, 5⟩, key := ⟨413, 8⟩, energy := 4, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f814 : Seen := { me := ⟨9, 4⟩, key := ⟨413, 8⟩, energy := 3, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f815 : Seen := { me := ⟨9, 3⟩, key := ⟨413, 8⟩, energy := 2, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f816 : Seen := { me := ⟨9, 2⟩, key := ⟨413, 8⟩, energy := 1, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨9, 1⟩] }
def f817 : Seen := { me := ⟨9, 1⟩, key := ⟨413, 8⟩, energy := 42, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f818 : Seen := { me := ⟨8, 1⟩, key := ⟨413, 8⟩, energy := 41, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f819 : Seen := { me := ⟨7, 1⟩, key := ⟨413, 8⟩, energy := 40, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f820 : Seen := { me := ⟨8, 1⟩, key := ⟨413, 8⟩, energy := 39, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f821 : Seen := { me := ⟨8, 2⟩, key := ⟨413, 8⟩, energy := 38, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f822 : Seen := { me := ⟨8, 3⟩, key := ⟨413, 8⟩, energy := 37, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f823 : Seen := { me := ⟨8, 4⟩, key := ⟨350, 8⟩, energy := 36, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f824 : Seen := { me := ⟨8, 3⟩, key := ⟨371, 8⟩, energy := 35, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f825 : Seen := { me := ⟨8, 2⟩, key := ⟨245, 8⟩, energy := 34, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f826 : Seen := { me := ⟨8, 1⟩, key := ⟨245, 8⟩, energy := 33, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f827 : Seen := { me := ⟨7, 1⟩, key := ⟨245, 8⟩, energy := 32, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f828 : Seen := { me := ⟨6, 1⟩, key := ⟨245, 8⟩, energy := 31, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f829 : Seen := { me := ⟨5, 1⟩, key := ⟨245, 8⟩, energy := 30, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f830 : Seen := { me := ⟨4, 1⟩, key := ⟨245, 8⟩, energy := 29, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f831 : Seen := { me := ⟨3, 1⟩, key := ⟨245, 8⟩, energy := 28, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f832 : Seen := { me := ⟨2, 1⟩, key := ⟨245, 8⟩, energy := 27, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f833 : Seen := { me := ⟨2, 2⟩, key := ⟨245, 8⟩, energy := 26, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f834 : Seen := { me := ⟨2, 3⟩, key := ⟨245, 8⟩, energy := 25, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f835 : Seen := { me := ⟨2, 4⟩, key := ⟨121, 8⟩, energy := 24, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f836 : Seen := { me := ⟨2, 3⟩, key := ⟨463, 8⟩, energy := 23, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f837 : Seen := { me := ⟨2, 2⟩, key := ⟨426, 8⟩, energy := 22, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f838 : Seen := { me := ⟨2, 3⟩, key := ⟨122, 8⟩, energy := 21, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f839 : Seen := { me := ⟨2, 4⟩, key := ⟨485, 8⟩, energy := 20, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f840 : Seen := { me := ⟨2, 3⟩, key := ⟨485, 8⟩, energy := 19, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f841 : Seen := { me := ⟨2, 2⟩, key := ⟨485, 8⟩, energy := 18, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f842 : Seen := { me := ⟨2, 1⟩, key := ⟨485, 8⟩, energy := 17, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f843 : Seen := { me := ⟨3, 1⟩, key := ⟨485, 8⟩, energy := 16, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f844 : Seen := { me := ⟨4, 1⟩, key := ⟨485, 8⟩, energy := 15, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f845 : Seen := { me := ⟨5, 1⟩, key := ⟨485, 8⟩, energy := 14, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f846 : Seen := { me := ⟨5, 2⟩, key := ⟨485, 8⟩, energy := 13, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f847 : Seen := { me := ⟨5, 3⟩, key := ⟨485, 12⟩, energy := 12, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩] }
def f848 : Seen := { me := ⟨4, 3⟩, key := ⟨485, 9⟩, energy := 11, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [], refills := [⟨1, 1⟩] }
def f849 : Seen := { me := ⟨5, 3⟩, key := ⟨485, 9⟩, energy := 10, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f850 : Seen := { me := ⟨5, 2⟩, key := ⟨485, 9⟩, energy := 9, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f851 : Seen := { me := ⟨5, 1⟩, key := ⟨485, 9⟩, energy := 8, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f852 : Seen := { me := ⟨4, 1⟩, key := ⟨485, 9⟩, energy := 7, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f853 : Seen := { me := ⟨3, 1⟩, key := ⟨485, 9⟩, energy := 6, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f854 : Seen := { me := ⟨2, 1⟩, key := ⟨485, 9⟩, energy := 5, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f855 : Seen := { me := ⟨1, 1⟩, key := ⟨485, 9⟩, energy := 42, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [] }
def f856 : Seen := { me := ⟨1, 2⟩, key := ⟨485, 9⟩, energy := 41, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [] }
def f857 : Seen := { me := ⟨1, 3⟩, key := ⟨485, 9⟩, energy := 40, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [] }
def f858 : Seen := { me := ⟨1, 4⟩, key := ⟨485, 9⟩, energy := 39, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [] }
def f859 : Seen := { me := ⟨1, 5⟩, key := ⟨485, 9⟩, energy := 38, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [] }
def f860 : Seen := { me := ⟨2, 5⟩, key := ⟨485, 9⟩, energy := 37, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [] }
def f861 : Seen := { me := ⟨2, 6⟩, key := ⟨485, 9⟩, energy := 36, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [] }
def f862 : Seen := { me := ⟨2, 7⟩, key := ⟨485, 9⟩, energy := 35, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [] }
def f863 : Seen := { me := ⟨3, 7⟩, key := ⟨485, 9⟩, energy := 34, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [] }
def f864 : Seen := { me := ⟨3, 8⟩, key := ⟨485, 9⟩, energy := 33, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [] }
def f865 : Seen := { me := ⟨3, 9⟩, key := ⟨485, 9⟩, energy := 32, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [] }
def f866 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 9⟩, energy := 31, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [] }
def f867 : Seen := { me := ⟨5, 9⟩, key := ⟨485, 9⟩, energy := 30, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [] }
def f868 : Seen := { me := ⟨5, 10⟩, key := ⟨485, 9⟩, energy := 29, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [] }
def f869 : Seen := { me := ⟨6, 10⟩, key := ⟨485, 9⟩, energy := 28, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [] }
def f870 : Seen := { me := ⟨7, 10⟩, key := ⟨485, 9⟩, energy := 27, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [] }
def f871 : Seen := { me := ⟨8, 10⟩, key := ⟨485, 9⟩, energy := 26, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [] }
def f872 : Seen := { me := ⟨9, 10⟩, key := ⟨485, 9⟩, energy := 25, lives := 1, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [] }
def f873 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f874 : Seen := { me := ⟨3, 2⟩, key := ⟨466, 12⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f875 : Seen := { me := ⟨3, 2⟩, key := ⟨466, 12⟩, energy := 38, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f876 : Seen := { me := ⟨3, 2⟩, key := ⟨466, 12⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f877 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f878 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f879 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f880 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f881 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f882 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f883 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f884 : Seen := { me := ⟨2, 3⟩, key := ⟨466, 12⟩, energy := 20, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f885 : Seen := { me := ⟨1, 3⟩, key := ⟨466, 12⟩, energy := 18, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f886 : Seen := { me := ⟨1, 4⟩, key := ⟨466, 12⟩, energy := 16, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨4, 5⟩] }
def f887 : Seen := { me := ⟨1, 5⟩, key := ⟨466, 12⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨4, 5⟩] }
def f888 : Seen := { me := ⟨2, 5⟩, key := ⟨466, 12⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨4, 5⟩] }
def f889 : Seen := { me := ⟨2, 6⟩, key := ⟨466, 12⟩, energy := 10, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨1, 9⟩, ⟨4, 5⟩] }
def f890 : Seen := { me := ⟨3, 6⟩, key := ⟨466, 12⟩, energy := 8, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨4, 5⟩] }
def f891 : Seen := { me := ⟨4, 6⟩, key := ⟨466, 12⟩, energy := 6, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨4, 5⟩] }
def f892 : Seen := { me := ⟨4, 5⟩, key := ⟨466, 12⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f893 : Seen := { me := ⟨4, 6⟩, key := ⟨466, 12⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩] }
def f894 : Seen := { me := ⟨8, 7⟩, key := ⟨466, 12⟩, energy := 38, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f895 : Seen := { me := ⟨8, 7⟩, key := ⟨466, 12⟩, energy := 36, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f896 : Seen := { me := ⟨8, 7⟩, key := ⟨466, 12⟩, energy := 34, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f897 : Seen := { me := ⟨8, 7⟩, key := ⟨466, 12⟩, energy := 32, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f898 : Seen := { me := ⟨7, 7⟩, key := ⟨466, 12⟩, energy := 30, lives := 3, goals := [], rotators := [⟨6, 10⟩], shapers := [], painters := [], refills := [] }
def f899 : Seen := { me := ⟨6, 5⟩, key := ⟨466, 12⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f900 : Seen := { me := ⟨7, 5⟩, key := ⟨466, 12⟩, energy := 26, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f901 : Seen := { me := ⟨8, 5⟩, key := ⟨466, 12⟩, energy := 24, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f902 : Seen := { me := ⟨9, 5⟩, key := ⟨466, 12⟩, energy := 22, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f903 : Seen := { me := ⟨8, 5⟩, key := ⟨466, 12⟩, energy := 20, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f904 : Seen := { me := ⟨7, 5⟩, key := ⟨466, 12⟩, energy := 18, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f905 : Seen := { me := ⟨6, 5⟩, key := ⟨466, 12⟩, energy := 16, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f906 : Seen := { me := ⟨2, 6⟩, key := ⟨466, 12⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨1, 9⟩] }
def f907 : Seen := { me := ⟨2, 7⟩, key := ⟨466, 12⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩, ⟨1, 9⟩] }
def f908 : Seen := { me := ⟨1, 7⟩, key := ⟨466, 12⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f909 : Seen := { me := ⟨2, 7⟩, key := ⟨466, 12⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f910 : Seen := { me := ⟨2, 6⟩, key := ⟨466, 12⟩, energy := 38, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f911 : Seen := { me := ⟨3, 6⟩, key := ⟨466, 12⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f912 : Seen := { me := ⟨4, 6⟩, key := ⟨466, 12⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f913 : Seen := { me := ⟨5, 6⟩, key := ⟨466, 12⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f914 : Seen := { me := ⟨5, 5⟩, key := ⟨466, 12⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f915 : Seen := { me := ⟨5, 4⟩, key := ⟨466, 12⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f916 : Seen := { me := ⟨5, 3⟩, key := ⟨466, 12⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f917 : Seen := { me := ⟨5, 2⟩, key := ⟨466, 12⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f918 : Seen := { me := ⟨5, 1⟩, key := ⟨466, 12⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f919 : Seen := { me := ⟨6, 1⟩, key := ⟨466, 12⟩, energy := 20, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f920 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 12⟩, energy := 18, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f921 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 9⟩, energy := 16, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f922 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 9⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f923 : Seen := { me := ⟨6, 1⟩, key := ⟨466, 9⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f924 : Seen := { me := ⟨5, 1⟩, key := ⟨466, 9⟩, energy := 10, lives := 3, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f925 : Seen := { me := ⟨4, 1⟩, key := ⟨466, 9⟩, energy := 8, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f926 : Seen := { me := ⟨3, 1⟩, key := ⟨466, 9⟩, energy := 6, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f927 : Seen := { me := ⟨2, 1⟩, key := ⟨466, 9⟩, energy := 4, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f928 : Seen := { me := ⟨1, 1⟩, key := ⟨466, 9⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f929 : Seen := { me := ⟨1, 2⟩, key := ⟨466, 9⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f930 : Seen := { me := ⟨1, 3⟩, key := ⟨466, 9⟩, energy := 38, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f931 : Seen := { me := ⟨1, 4⟩, key := ⟨466, 9⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f932 : Seen := { me := ⟨1, 5⟩, key := ⟨466, 9⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f933 : Seen := { me := ⟨2, 5⟩, key := ⟨466, 9⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f934 : Seen := { me := ⟨2, 6⟩, key := ⟨466, 9⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f935 : Seen := { me := ⟨3, 6⟩, key := ⟨466, 9⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f936 : Seen := { me := ⟨4, 6⟩, key := ⟨466, 9⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f937 : Seen := { me := ⟨8, 7⟩, key := ⟨466, 9⟩, energy := 24, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f938 : Seen := { me := ⟨7, 7⟩, key := ⟨466, 9⟩, energy := 22, lives := 3, goals := [], rotators := [⟨6, 10⟩], shapers := [], painters := [], refills := [] }
def f939 : Seen := { me := ⟨7, 8⟩, key := ⟨466, 9⟩, energy := 20, lives := 3, goals := [], rotators := [⟨5, 10⟩], shapers := [], painters := [], refills := [] }
def f940 : Seen := { me := ⟨7, 9⟩, key := ⟨466, 9⟩, energy := 18, lives := 3, goals := [], rotators := [⟨4, 10⟩], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f941 : Seen := { me := ⟨7, 10⟩, key := ⟨466, 9⟩, energy := 16, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f942 : Seen := { me := ⟨6, 10⟩, key := ⟨466, 9⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f943 : Seen := { me := ⟨5, 10⟩, key := ⟨466, 9⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f944 : Seen := { me := ⟨4, 10⟩, key := ⟨466, 9⟩, energy := 10, lives := 3, goals := [], rotators := [⟨2, 10⟩], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f945 : Seen := { me := ⟨3, 10⟩, key := ⟨121, 9⟩, energy := 8, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f946 : Seen := { me := ⟨2, 10⟩, key := ⟨121, 9⟩, energy := 6, lives := 3, goals := [], rotators := [⟨4, 10⟩], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f947 : Seen := { me := ⟨1, 10⟩, key := ⟨121, 9⟩, energy := 4, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f948 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f949 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f950 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 38, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f951 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f952 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f953 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f954 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f955 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f956 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f957 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f958 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f959 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 20, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f960 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 18, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f961 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 16, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f962 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f963 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f964 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 10, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f965 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 8, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f966 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 6, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f967 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 4, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f968 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 2, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f969 : Seen := { me := ⟨1, 9⟩, key := ⟨121, 9⟩, energy := 0, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f970 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 42, lives := 2, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f971 : Seen := { me := ⟨3, 2⟩, key := ⟨466, 12⟩, energy := 40, lives := 2, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f972 : Seen := { me := ⟨3, 1⟩, key := ⟨466, 12⟩, energy := 38, lives := 2, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f973 : Seen := { me := ⟨4, 1⟩, key := ⟨466, 12⟩, energy := 36, lives := 2, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f974 : Seen := { me := ⟨5, 1⟩, key := ⟨466, 12⟩, energy := 34, lives := 2, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f975 : Seen := { me := ⟨6, 1⟩, key := ⟨466, 12⟩, energy := 32, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f976 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 12⟩, energy := 30, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f977 : Seen := { me := ⟨7, 2⟩, key := ⟨466, 12⟩, energy := 28, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f978 : Seen := { me := ⟨8, 2⟩, key := ⟨466, 12⟩, energy := 26, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f979 : Seen := { me := ⟨8, 3⟩, key := ⟨493, 12⟩, energy := 24, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f980 : Seen := { me := ⟨8, 2⟩, key := ⟨493, 12⟩, energy := 22, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f981 : Seen := { me := ⟨8, 3⟩, key := ⟨174, 12⟩, energy := 20, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f982 : Seen := { me := ⟨8, 2⟩, key := ⟨174, 12⟩, energy := 18, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f983 : Seen := { me := ⟨8, 3⟩, key := ⟨410, 12⟩, energy := 16, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f984 : Seen := { me := ⟨8, 2⟩, key := ⟨410, 12⟩, energy := 14, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f985 : Seen := { me := ⟨8, 3⟩, key := ⟨359, 12⟩, energy := 12, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f986 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 12⟩, energy := 10, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f987 : Seen := { me := ⟨8, 3⟩, key := ⟨371, 12⟩, energy := 8, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f988 : Seen := { me := ⟨8, 2⟩, key := ⟨371, 12⟩, energy := 6, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f989 : Seen := { me := ⟨8, 3⟩, key := ⟨466, 12⟩, energy := 4, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f990 : Seen := { me := ⟨8, 2⟩, key := ⟨466, 12⟩, energy := 2, lives := 2, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f991 : Seen := { me := ⟨8, 3⟩, key := ⟨493, 12⟩, energy := 0, lives := 2, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f992 : Seen := { me := ⟨3, 3⟩, key := ⟨466, 12⟩, energy := 42, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f993 : Seen := { me := ⟨3, 2⟩, key := ⟨466, 12⟩, energy := 40, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩, ⟨4, 5⟩] }
def f994 : Seen := { me := ⟨3, 1⟩, key := ⟨466, 12⟩, energy := 38, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f995 : Seen := { me := ⟨4, 1⟩, key := ⟨466, 12⟩, energy := 36, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f996 : Seen := { me := ⟨5, 1⟩, key := ⟨466, 12⟩, energy := 34, lives := 1, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f997 : Seen := { me := ⟨6, 1⟩, key := ⟨466, 12⟩, energy := 32, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f998 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 12⟩, energy := 30, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f999 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 9⟩, energy := 28, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1000 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 9⟩, energy := 26, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1001 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 14⟩, energy := 24, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1002 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 14⟩, energy := 22, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1003 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 8⟩, energy := 20, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1004 : Seen := { me := ⟨8, 2⟩, key := ⟨466, 8⟩, energy := 18, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1005 : Seen := { me := ⟨9, 2⟩, key := ⟨466, 8⟩, energy := 42, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1006 : Seen := { me := ⟨8, 2⟩, key := ⟨466, 8⟩, energy := 40, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1007 : Seen := { me := ⟨8, 3⟩, key := ⟨493, 8⟩, energy := 38, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1008 : Seen := { me := ⟨7, 3⟩, key := ⟨493, 8⟩, energy := 36, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1009 : Seen := { me := ⟨8, 3⟩, key := ⟨174, 8⟩, energy := 34, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1010 : Seen := { me := ⟨7, 3⟩, key := ⟨174, 8⟩, energy := 32, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1011 : Seen := { me := ⟨8, 3⟩, key := ⟨410, 8⟩, energy := 30, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1012 : Seen := { me := ⟨7, 3⟩, key := ⟨410, 8⟩, energy := 28, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1013 : Seen := { me := ⟨8, 3⟩, key := ⟨359, 8⟩, energy := 26, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1014 : Seen := { me := ⟨7, 3⟩, key := ⟨359, 8⟩, energy := 24, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1015 : Seen := { me := ⟨8, 3⟩, key := ⟨371, 8⟩, energy := 22, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1016 : Seen := { me := ⟨7, 3⟩, key := ⟨371, 8⟩, energy := 20, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1017 : Seen := { me := ⟨7, 2⟩, key := ⟨371, 8⟩, energy := 18, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1018 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 16, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1019 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 14, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1020 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 12, lives := 1, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1021 : Seen := { me := ⟨5, 2⟩, key := ⟨371, 8⟩, energy := 10, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨4, 5⟩] }
def f1022 : Seen := { me := ⟨5, 3⟩, key := ⟨371, 8⟩, energy := 8, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨4, 5⟩] }
def f1023 : Seen := { me := ⟨5, 4⟩, key := ⟨371, 8⟩, energy := 6, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨4, 5⟩] }
def f1024 : Seen := { me := ⟨5, 5⟩, key := ⟨371, 8⟩, energy := 4, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨4, 5⟩] }
def f1025 : Seen := { me := ⟨4, 5⟩, key := ⟨371, 8⟩, energy := 42, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1026 : Seen := { me := ⟨4, 6⟩, key := ⟨371, 8⟩, energy := 40, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩] }
def f1027 : Seen := { me := ⟨8, 7⟩, key := ⟨371, 8⟩, energy := 38, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f1028 : Seen := { me := ⟨7, 7⟩, key := ⟨371, 8⟩, energy := 36, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1029 : Seen := { me := ⟨7, 8⟩, key := ⟨371, 8⟩, energy := 34, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1030 : Seen := { me := ⟨7, 9⟩, key := ⟨371, 8⟩, energy := 32, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f1031 : Seen := { me := ⟨6, 9⟩, key := ⟨371, 8⟩, energy := 30, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1032 : Seen := { me := ⟨5, 9⟩, key := ⟨371, 8⟩, energy := 28, lives := 1, goals := [], rotators := [⟨2, 10⟩], shapers := [], painters := [], refills := [] }
def f1033 : Seen := { me := ⟨4, 9⟩, key := ⟨371, 8⟩, energy := 26, lives := 1, goals := [], rotators := [⟨3, 10⟩], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f1034 : Seen := { me := ⟨4, 10⟩, key := ⟨245, 8⟩, energy := 24, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f1035 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 22, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1036 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 20, lives := 1, goals := [], rotators := [⟨6, 10⟩], shapers := [], painters := [], refills := [] }
def f1037 : Seen := { me := ⟨6, 9⟩, key := ⟨413, 8⟩, energy := 18, lives := 1, goals := [], rotators := [⟨5, 10⟩], shapers := [], painters := [], refills := [] }
def f1038 : Seen := { me := ⟨7, 9⟩, key := ⟨413, 8⟩, energy := 16, lives := 1, goals := [], rotators := [⟨4, 10⟩], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f1039 : Seen := { me := ⟨7, 8⟩, key := ⟨413, 8⟩, energy := 14, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1040 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 8⟩, energy := 12, lives := 1, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1041 : Seen := { me := ⟨6, 5⟩, key := ⟨413, 8⟩, energy := 10, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1042 : Seen := { me := ⟨7, 5⟩, key := ⟨413, 8⟩, energy := 8, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1043 : Seen := { me := ⟨8, 5⟩, key := ⟨413, 8⟩, energy := 6, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1044 : Seen := { me := ⟨9, 5⟩, key := ⟨413, 8⟩, energy := 4, lives := 1, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1045 : Seen := { me := ⟨10, 5⟩, key := ⟨413, 8⟩, energy := 2, lives := 1, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1046 : Seen := { me := ⟨4, 5⟩, key := ⟨359, 12⟩, energy := 18, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1047 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 12⟩, energy := 16, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1048 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 12⟩, energy := 14, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1049 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 12⟩, energy := 12, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1050 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 12⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1051 : Seen := { me := ⟨9, 5⟩, key := ⟨359, 9⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1052 : Seen := { me := ⟨8, 5⟩, key := ⟨359, 9⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1053 : Seen := { me := ⟨7, 5⟩, key := ⟨359, 9⟩, energy := 4, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1054 : Seen := { me := ⟨6, 5⟩, key := ⟨359, 9⟩, energy := 2, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1055 : Seen := { me := ⟨6, 4⟩, key := ⟨359, 9⟩, energy := 0, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩, ⟨6, 3⟩] }
def f1056 : Seen := { me := ⟨6, 3⟩, key := ⟨359, 9⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1057 : Seen := { me := ⟨5, 3⟩, key := ⟨359, 9⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1058 : Seen := { me := ⟨5, 4⟩, key := ⟨359, 9⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1059 : Seen := { me := ⟨5, 5⟩, key := ⟨359, 9⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1060 : Seen := { me := ⟨5, 6⟩, key := ⟨359, 9⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1061 : Seen := { me := ⟨5, 7⟩, key := ⟨359, 9⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1062 : Seen := { me := ⟨5, 8⟩, key := ⟨359, 9⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1063 : Seen := { me := ⟨5, 9⟩, key := ⟨359, 9⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1064 : Seen := { me := ⟨5, 10⟩, key := ⟨359, 9⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1065 : Seen := { me := ⟨4, 10⟩, key := ⟨359, 9⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1066 : Seen := { me := ⟨3, 10⟩, key := ⟨359, 9⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1067 : Seen := { me := ⟨2, 10⟩, key := ⟨359, 9⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1068 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 9⟩, energy := 18, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1069 : Seen := { me := ⟨1, 9⟩, key := ⟨485, 9⟩, energy := 16, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1070 : Seen := { me := ⟨2, 9⟩, key := ⟨461, 9⟩, energy := 14, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1071 : Seen := { me := ⟨1, 9⟩, key := ⟨461, 9⟩, energy := 12, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1072 : Seen := { me := ⟨9, 10⟩, key := ⟨461, 9⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨461, 9⟩⟩], rotators := [⟨2, 9⟩], shapers := [], painters := [⟨9, 5⟩], refills := [⟨3, 6⟩] }
def f1073 : Seen := { me := ⟨4, 8⟩, key := ⟨410, 8⟩, energy := 16, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1074 : Seen := { me := ⟨3, 8⟩, key := ⟨410, 8⟩, energy := 14, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1075 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 8⟩, energy := 12, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1076 : Seen := { me := ⟨3, 6⟩, key := ⟨410, 8⟩, energy := 10, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1077 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 8⟩, energy := 8, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1078 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 8⟩, energy := 6, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1079 : Seen := { me := ⟨3, 3⟩, key := ⟨410, 8⟩, energy := 4, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1080 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 8⟩, energy := 2, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1081 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 8⟩, energy := 0, lives := 3, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1082 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1083 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1084 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1085 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1086 : Seen := { me := ⟨8, 10⟩, key := ⟨410, 12⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1087 : Seen := { me := ⟨8, 10⟩, key := ⟨410, 12⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1088 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1089 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1090 : Seen := { me := ⟨8, 9⟩, key := ⟨410, 12⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1091 : Seen := { me := ⟨8, 10⟩, key := ⟨410, 12⟩, energy := 22, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1092 : Seen := { me := ⟨7, 10⟩, key := ⟨410, 12⟩, energy := 20, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1093 : Seen := { me := ⟨6, 8⟩, key := ⟨410, 12⟩, energy := 18, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1094 : Seen := { me := ⟨5, 8⟩, key := ⟨410, 12⟩, energy := 16, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1095 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 12⟩, energy := 14, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1096 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 12⟩, energy := 12, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1097 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 9⟩, energy := 10, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1098 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 9⟩, energy := 8, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1099 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 14⟩, energy := 6, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1100 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 4, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1101 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 14⟩, energy := 2, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩] }
def f1102 : Seen := { me := ⟨1, 8⟩, key := ⟨410, 14⟩, energy := 42, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1103 : Seen := { me := ⟨1, 7⟩, key := ⟨410, 14⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1104 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 14⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1105 : Seen := { me := ⟨5, 5⟩, key := ⟨410, 8⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1106 : Seen := { me := ⟨5, 6⟩, key := ⟨410, 8⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1107 : Seen := { me := ⟨4, 8⟩, key := ⟨410, 8⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1108 : Seen := { me := ⟨3, 8⟩, key := ⟨410, 8⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1109 : Seen := { me := ⟨3, 7⟩, key := ⟨410, 8⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1110 : Seen := { me := ⟨3, 6⟩, key := ⟨410, 8⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1111 : Seen := { me := ⟨3, 5⟩, key := ⟨410, 8⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1112 : Seen := { me := ⟨3, 4⟩, key := ⟨410, 8⟩, energy := 22, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1113 : Seen := { me := ⟨2, 4⟩, key := ⟨410, 8⟩, energy := 20, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1114 : Seen := { me := ⟨2, 3⟩, key := ⟨359, 8⟩, energy := 18, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1115 : Seen := { me := ⟨2, 2⟩, key := ⟨359, 8⟩, energy := 16, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨2, 1⟩, ⟨9, 2⟩] }
def f1116 : Seen := { me := ⟨2, 1⟩, key := ⟨359, 8⟩, energy := 42, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1117 : Seen := { me := ⟨2, 2⟩, key := ⟨359, 8⟩, energy := 40, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1118 : Seen := { me := ⟨2, 3⟩, key := ⟨371, 8⟩, energy := 38, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1119 : Seen := { me := ⟨3, 3⟩, key := ⟨371, 8⟩, energy := 36, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1120 : Seen := { me := ⟨4, 3⟩, key := ⟨371, 8⟩, energy := 34, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1121 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 32, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1122 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 30, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1123 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 28, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1124 : Seen := { me := ⟨7, 2⟩, key := ⟨245, 8⟩, energy := 26, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1125 : Seen := { me := ⟨7, 3⟩, key := ⟨413, 8⟩, energy := 24, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1126 : Seen := { me := ⟨8, 3⟩, key := ⟨413, 8⟩, energy := 22, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1127 : Seen := { me := ⟨9, 3⟩, key := ⟨413, 8⟩, energy := 20, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1128 : Seen := { me := ⟨10, 3⟩, key := ⟨413, 8⟩, energy := 18, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1129 : Seen := { me := ⟨10, 4⟩, key := ⟨413, 8⟩, energy := 16, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1130 : Seen := { me := ⟨10, 5⟩, key := ⟨413, 8⟩, energy := 14, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1131 : Seen := { me := ⟨10, 6⟩, key := ⟨413, 8⟩, energy := 12, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1132 : Seen := { me := ⟨10, 7⟩, key := ⟨413, 8⟩, energy := 10, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 2⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1133 : Seen := { me := ⟨10, 8⟩, key := ⟨413, 8⟩, energy := 8, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1134 : Seen := { me := ⟨10, 9⟩, key := ⟨413, 8⟩, energy := 6, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 4⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1135 : Seen := { me := ⟨2, 10⟩, key := ⟨413, 8⟩, energy := 4, lives := 2, goals := [⟨⟨1, 10⟩, ⟨413, 8⟩⟩], rotators := [⟨7, 3⟩], shapers := [⟨2, 3⟩], painters := [⟨5, 5⟩], refills := [⟨9, 2⟩] }
def f1136 : Seen := { me := ⟨9, 3⟩, key := ⟨371, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f1137 : Seen := { me := ⟨9, 2⟩, key := ⟨371, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩] }
def f1138 : Seen := { me := ⟨9, 1⟩, key := ⟨371, 14⟩, energy := 42, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1139 : Seen := { me := ⟨8, 1⟩, key := ⟨371, 14⟩, energy := 41, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1140 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 14⟩, energy := 40, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1141 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 14⟩, energy := 39, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1142 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 14⟩, energy := 38, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1143 : Seen := { me := ⟨5, 2⟩, key := ⟨371, 14⟩, energy := 37, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1144 : Seen := { me := ⟨5, 3⟩, key := ⟨371, 8⟩, energy := 36, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1145 : Seen := { me := ⟨5, 2⟩, key := ⟨371, 8⟩, energy := 35, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1146 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 34, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1147 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 33, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1148 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 32, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1149 : Seen := { me := ⟨8, 1⟩, key := ⟨371, 8⟩, energy := 31, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1150 : Seen := { me := ⟨8, 2⟩, key := ⟨371, 8⟩, energy := 30, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1151 : Seen := { me := ⟨8, 3⟩, key := ⟨371, 8⟩, energy := 29, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1152 : Seen := { me := ⟨8, 4⟩, key := ⟨245, 8⟩, energy := 28, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1153 : Seen := { me := ⟨8, 3⟩, key := ⟨413, 8⟩, energy := 27, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1154 : Seen := { me := ⟨8, 4⟩, key := ⟨413, 8⟩, energy := 26, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1155 : Seen := { me := ⟨8, 5⟩, key := ⟨413, 8⟩, energy := 25, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1156 : Seen := { me := ⟨8, 6⟩, key := ⟨413, 8⟩, energy := 24, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1157 : Seen := { me := ⟨8, 7⟩, key := ⟨413, 8⟩, energy := 23, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1158 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 8⟩, energy := 22, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1159 : Seen := { me := ⟨6, 7⟩, key := ⟨413, 8⟩, energy := 21, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1160 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 20, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1161 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 19, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1162 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 18, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1163 : Seen := { me := ⟨3, 8⟩, key := ⟨413, 8⟩, energy := 17, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1164 : Seen := { me := ⟨3, 9⟩, key := ⟨413, 8⟩, energy := 16, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1165 : Seen := { me := ⟨2, 9⟩, key := ⟨413, 8⟩, energy := 15, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1166 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 14, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1167 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 13, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1168 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 12, lives := 3, goals := [⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1169 : Seen := { me := ⟨7, 10⟩, key := ⟨413, 8⟩, energy := 11, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1170 : Seen := { me := ⟨6, 10⟩, key := ⟨413, 8⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1171 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 9, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1172 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1173 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 7, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1174 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1175 : Seen := { me := ⟨2, 7⟩, key := ⟨413, 8⟩, energy := 5, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩, ⟨1, 7⟩] }
def f1176 : Seen := { me := ⟨1, 7⟩, key := ⟨413, 8⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f1177 : Seen := { me := ⟨2, 7⟩, key := ⟨413, 8⟩, energy := 41, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f1178 : Seen := { me := ⟨3, 7⟩, key := ⟨413, 8⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f1179 : Seen := { me := ⟨4, 7⟩, key := ⟨413, 8⟩, energy := 39, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f1180 : Seen := { me := ⟨5, 7⟩, key := ⟨413, 8⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f1181 : Seen := { me := ⟨5, 6⟩, key := ⟨413, 8⟩, energy := 37, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f1182 : Seen := { me := ⟨5, 5⟩, key := ⟨413, 8⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f1183 : Seen := { me := ⟨5, 4⟩, key := ⟨413, 8⟩, energy := 35, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f1184 : Seen := { me := ⟨5, 3⟩, key := ⟨413, 12⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [], refills := [⟨1, 1⟩] }
def f1185 : Seen := { me := ⟨4, 3⟩, key := ⟨413, 9⟩, energy := 33, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [], refills := [⟨1, 1⟩] }
def f1186 : Seen := { me := ⟨5, 3⟩, key := ⟨413, 9⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f1187 : Seen := { me := ⟨5, 2⟩, key := ⟨413, 9⟩, energy := 31, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f1188 : Seen := { me := ⟨5, 1⟩, key := ⟨413, 9⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f1189 : Seen := { me := ⟨6, 1⟩, key := ⟨413, 9⟩, energy := 29, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f1190 : Seen := { me := ⟨7, 1⟩, key := ⟨413, 9⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f1191 : Seen := { me := ⟨8, 1⟩, key := ⟨413, 9⟩, energy := 27, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f1192 : Seen := { me := ⟨8, 2⟩, key := ⟨413, 9⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f1193 : Seen := { me := ⟨8, 3⟩, key := ⟨350, 9⟩, energy := 25, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f1194 : Seen := { me := ⟨8, 2⟩, key := ⟨371, 9⟩, energy := 24, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f1195 : Seen := { me := ⟨8, 3⟩, key := ⟨245, 9⟩, energy := 23, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f1196 : Seen := { me := ⟨8, 2⟩, key := ⟨245, 9⟩, energy := 22, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f1197 : Seen := { me := ⟨8, 1⟩, key := ⟨245, 9⟩, energy := 21, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f1198 : Seen := { me := ⟨7, 1⟩, key := ⟨245, 9⟩, energy := 20, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f1199 : Seen := { me := ⟨6, 1⟩, key := ⟨245, 9⟩, energy := 19, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f1200 : Seen := { me := ⟨5, 1⟩, key := ⟨245, 9⟩, energy := 18, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f1201 : Seen := { me := ⟨4, 1⟩, key := ⟨245, 9⟩, energy := 17, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f1202 : Seen := { me := ⟨3, 1⟩, key := ⟨245, 9⟩, energy := 16, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f1203 : Seen := { me := ⟨2, 1⟩, key := ⟨245, 9⟩, energy := 15, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f1204 : Seen := { me := ⟨2, 2⟩, key := ⟨245, 9⟩, energy := 14, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f1205 : Seen := { me := ⟨2, 3⟩, key := ⟨121, 9⟩, energy := 13, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f1206 : Seen := { me := ⟨2, 2⟩, key := ⟨463, 9⟩, energy := 12, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [], painters := [⟨6, 4⟩], refills := [⟨1, 1⟩] }
def f1207 : Seen := { me := ⟨2, 3⟩, key := ⟨426, 9⟩, energy := 11, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [], painters := [⟨6, 3⟩], refills := [⟨1, 1⟩] }
def f1208 : Seen := { me := ⟨2, 4⟩, key := ⟨122, 9⟩, energy := 10, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [], painters := [⟨5, 3⟩], refills := [⟨1, 1⟩] }
def f1209 : Seen := { me := ⟨2, 5⟩, key := ⟨485, 9⟩, energy := 9, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [], painters := [⟨4, 3⟩], refills := [⟨1, 1⟩] }
def f1210 : Seen := { me := ⟨1, 5⟩, key := ⟨485, 9⟩, energy := 8, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [⟨1, 1⟩] }
def f1211 : Seen := { me := ⟨1, 4⟩, key := ⟨485, 9⟩, energy := 7, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [⟨1, 1⟩] }
def f1212 : Seen := { me := ⟨1, 3⟩, key := ⟨485, 9⟩, energy := 6, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [⟨1, 1⟩] }
def f1213 : Seen := { me := ⟨1, 2⟩, key := ⟨485, 9⟩, energy := 5, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [⟨1, 1⟩] }
def f1214 : Seen := { me := ⟨1, 1⟩, key := ⟨485, 9⟩, energy := 42, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [] }
def f1215 : Seen := { me := ⟨1, 2⟩, key := ⟨485, 9⟩, energy := 41, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [] }
def f1216 : Seen := { me := ⟨1, 3⟩, key := ⟨485, 9⟩, energy := 40, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [] }
def f1217 : Seen := { me := ⟨1, 4⟩, key := ⟨485, 9⟩, energy := 39, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [] }
def f1218 : Seen := { me := ⟨1, 5⟩, key := ⟨485, 9⟩, energy := 38, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [] }
def f1219 : Seen := { me := ⟨1, 6⟩, key := ⟨485, 9⟩, energy := 37, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [] }
def f1220 : Seen := { me := ⟨2, 6⟩, key := ⟨485, 9⟩, energy := 36, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [] }
def f1221 : Seen := { me := ⟨2, 7⟩, key := ⟨485, 9⟩, energy := 35, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [] }
def f1222 : Seen := { me := ⟨3, 7⟩, key := ⟨485, 9⟩, energy := 34, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [] }
def f1223 : Seen := { me := ⟨3, 8⟩, key := ⟨485, 9⟩, energy := 33, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [] }
def f1224 : Seen := { me := ⟨3, 9⟩, key := ⟨485, 9⟩, energy := 32, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 3⟩], refills := [] }
def f1225 : Seen := { me := ⟨2, 9⟩, key := ⟨485, 9⟩, energy := 31, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 3⟩], refills := [] }
def f1226 : Seen := { me := ⟨5, 9⟩, key := ⟨485, 9⟩, energy := 30, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 2⟩], shapers := [⟨2, 6⟩], painters := [⟨4, 4⟩], refills := [] }
def f1227 : Seen := { me := ⟨5, 10⟩, key := ⟨485, 9⟩, energy := 29, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 3⟩], shapers := [⟨2, 5⟩], painters := [⟨4, 5⟩], refills := [] }
def f1228 : Seen := { me := ⟨6, 10⟩, key := ⟨485, 9⟩, energy := 28, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 4⟩], shapers := [⟨2, 4⟩], painters := [⟨5, 5⟩], refills := [] }
def f1229 : Seen := { me := ⟨7, 10⟩, key := ⟨485, 9⟩, energy := 27, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 5⟩], refills := [] }
def f1230 : Seen := { me := ⟨8, 10⟩, key := ⟨485, 9⟩, energy := 26, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 6⟩], shapers := [⟨2, 2⟩], painters := [⟨6, 4⟩], refills := [] }
def f1231 : Seen := { me := ⟨9, 10⟩, key := ⟨485, 9⟩, energy := 25, lives := 3, goals := [⟨⟨10, 10⟩, ⟨485, 9⟩⟩], rotators := [⟨8, 5⟩], shapers := [⟨2, 3⟩], painters := [⟨6, 3⟩], refills := [] }
def f1232 : Seen := { me := ⟨3, 1⟩, key := ⟨466, 12⟩, energy := 38, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f1233 : Seen := { me := ⟨4, 1⟩, key := ⟨466, 12⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 1⟩] }
def f1234 : Seen := { me := ⟨5, 1⟩, key := ⟨466, 12⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1235 : Seen := { me := ⟨6, 1⟩, key := ⟨466, 12⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1236 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 12⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1237 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 9⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1238 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 9⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1239 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 14⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1240 : Seen := { me := ⟨7, 1⟩, key := ⟨466, 14⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1241 : Seen := { me := ⟨8, 1⟩, key := ⟨466, 8⟩, energy := 20, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨9, 2⟩] }
def f1242 : Seen := { me := ⟨8, 2⟩, key := ⟨466, 8⟩, energy := 18, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1243 : Seen := { me := ⟨8, 3⟩, key := ⟨493, 8⟩, energy := 16, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1244 : Seen := { me := ⟨7, 3⟩, key := ⟨493, 8⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1245 : Seen := { me := ⟨8, 3⟩, key := ⟨174, 8⟩, energy := 12, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1246 : Seen := { me := ⟨7, 3⟩, key := ⟨174, 8⟩, energy := 10, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1247 : Seen := { me := ⟨8, 3⟩, key := ⟨410, 8⟩, energy := 8, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1248 : Seen := { me := ⟨7, 3⟩, key := ⟨410, 8⟩, energy := 6, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1249 : Seen := { me := ⟨8, 3⟩, key := ⟨359, 8⟩, energy := 4, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1250 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 8⟩, energy := 2, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨9, 2⟩] }
def f1251 : Seen := { me := ⟨9, 2⟩, key := ⟨359, 8⟩, energy := 42, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1252 : Seen := { me := ⟨8, 2⟩, key := ⟨359, 8⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1253 : Seen := { me := ⟨8, 3⟩, key := ⟨371, 8⟩, energy := 38, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1254 : Seen := { me := ⟨7, 3⟩, key := ⟨371, 8⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1255 : Seen := { me := ⟨7, 2⟩, key := ⟨371, 8⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1256 : Seen := { me := ⟨7, 1⟩, key := ⟨371, 8⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1257 : Seen := { me := ⟨6, 1⟩, key := ⟨371, 8⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [] }
def f1258 : Seen := { me := ⟨5, 1⟩, key := ⟨371, 8⟩, energy := 28, lives := 3, goals := [], rotators := [], shapers := [], painters := [⟨8, 1⟩], refills := [] }
def f1259 : Seen := { me := ⟨5, 2⟩, key := ⟨371, 8⟩, energy := 26, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [⟨8, 1⟩], refills := [⟨4, 5⟩] }
def f1260 : Seen := { me := ⟨5, 3⟩, key := ⟨371, 8⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨4, 5⟩] }
def f1261 : Seen := { me := ⟨5, 4⟩, key := ⟨371, 8⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [⟨4, 5⟩] }
def f1262 : Seen := { me := ⟨5, 5⟩, key := ⟨371, 8⟩, energy := 20, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨4, 5⟩] }
def f1263 : Seen := { me := ⟨4, 5⟩, key := ⟨371, 8⟩, energy := 42, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1264 : Seen := { me := ⟨4, 6⟩, key := ⟨371, 8⟩, energy := 40, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 7⟩] }
def f1265 : Seen := { me := ⟨8, 7⟩, key := ⟨371, 8⟩, energy := 38, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [], painters := [], refills := [] }
def f1266 : Seen := { me := ⟨7, 7⟩, key := ⟨371, 8⟩, energy := 36, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1267 : Seen := { me := ⟨7, 8⟩, key := ⟨371, 8⟩, energy := 34, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1268 : Seen := { me := ⟨7, 9⟩, key := ⟨371, 8⟩, energy := 32, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f1269 : Seen := { me := ⟨6, 9⟩, key := ⟨371, 8⟩, energy := 30, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1270 : Seen := { me := ⟨5, 9⟩, key := ⟨371, 8⟩, energy := 28, lives := 3, goals := [], rotators := [⟨2, 10⟩], shapers := [], painters := [], refills := [] }
def f1271 : Seen := { me := ⟨4, 9⟩, key := ⟨371, 8⟩, energy := 26, lives := 3, goals := [], rotators := [⟨3, 10⟩], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f1272 : Seen := { me := ⟨4, 10⟩, key := ⟨245, 8⟩, energy := 24, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [⟨1, 9⟩] }
def f1273 : Seen := { me := ⟨5, 10⟩, key := ⟨413, 8⟩, energy := 22, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1274 : Seen := { me := ⟨5, 9⟩, key := ⟨413, 8⟩, energy := 20, lives := 3, goals := [], rotators := [⟨6, 10⟩], shapers := [], painters := [], refills := [] }
def f1275 : Seen := { me := ⟨6, 9⟩, key := ⟨413, 8⟩, energy := 18, lives := 3, goals := [], rotators := [⟨5, 10⟩], shapers := [], painters := [], refills := [] }
def f1276 : Seen := { me := ⟨7, 9⟩, key := ⟨413, 8⟩, energy := 16, lives := 3, goals := [], rotators := [⟨4, 10⟩], shapers := [], painters := [], refills := [⟨10, 10⟩] }
def f1277 : Seen := { me := ⟨7, 8⟩, key := ⟨413, 8⟩, energy := 14, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1278 : Seen := { me := ⟨7, 7⟩, key := ⟨413, 8⟩, energy := 12, lives := 3, goals := [], rotators := [], shapers := [], painters := [], refills := [] }
def f1279 : Seen := { me := ⟨6, 5⟩, key := ⟨413, 8⟩, energy := 10, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1280 : Seen := { me := ⟨7, 5⟩, key := ⟨413, 8⟩, energy := 8, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1281 : Seen := { me := ⟨8, 5⟩, key := ⟨413, 8⟩, energy := 6, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1282 : Seen := { me := ⟨9, 5⟩, key := ⟨413, 8⟩, energy := 4, lives := 3, goals := [⟨⟨10, 5⟩, ⟨413, 8⟩⟩], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }
def f1283 : Seen := { me := ⟨10, 5⟩, key := ⟨413, 8⟩, energy := 2, lives := 3, goals := [], rotators := [], shapers := [⟨8, 3⟩], painters := [], refills := [] }

/-- 一条转移。`act = none` 是 RESET（模型的动作里没有它）。 -/
structure Row where
  seq : Nat
  lvl : Nat
  act : Option Act
  prev : Seen
  next : Seen
  kind : Nat

/-- 全部 1467 条转移。 -/
def rows : List Row := [
  ⟨1, 0, some .a1, f0, f1, 0⟩,
  ⟨2, 0, some .a2, f1, f2, 0⟩,
  ⟨3, 0, some .a3, f2, f3, 0⟩,
  ⟨4, 0, some .a4, f3, f4, 0⟩,
  ⟨5, 0, some .a1, f4, f5, 0⟩,
  ⟨6, 0, some .a1, f5, f6, 0⟩,
  ⟨7, 0, some .a1, f6, f7, 0⟩,
  ⟨8, 0, some .a1, f7, f8, 0⟩,
  ⟨9, 0, some .a1, f8, f9, 0⟩,
  ⟨10, 0, some .a1, f9, f10, 0⟩,
  ⟨11, 0, some .a1, f10, f10, 0⟩,
  ⟨12, 0, some .a2, f10, f11, 0⟩,
  ⟨13, 0, some .a2, f11, f12, 0⟩,
  ⟨14, 0, some .a3, f12, f13, 0⟩,
  ⟨15, 0, some .a3, f13, f14, 0⟩,
  ⟨16, 0, some .a3, f14, f15, 0⟩,
  ⟨17, 0, some .a2, f15, f16, 0⟩,
  ⟨18, 0, some .a1, f16, f17, 0⟩,
  ⟨19, 0, some .a4, f17, f18, 0⟩,
  ⟨20, 0, some .a4, f18, f19, 0⟩,
  ⟨21, 0, some .a4, f19, f20, 0⟩,
  ⟨22, 0, some .a1, f20, f21, 0⟩,
  ⟨23, 0, some .a1, f21, f22, 0⟩,
  ⟨24, 0, some .a1, f22, f23, 1⟩,
  ⟨25, 1, some .a1, f23, f24, 0⟩,
  ⟨26, 1, some .a4, f24, f25, 0⟩,
  ⟨27, 1, some .a1, f25, f26, 0⟩,
  ⟨28, 1, some .a1, f26, f27, 0⟩,
  ⟨29, 1, some .a1, f27, f28, 0⟩,
  ⟨30, 1, some .a1, f28, f29, 0⟩,
  ⟨31, 1, some .a1, f29, f30, 0⟩,
  ⟨32, 1, some .a4, f30, f31, 0⟩,
  ⟨33, 1, some .a4, f31, f32, 0⟩,
  ⟨34, 1, some .a2, f32, f33, 0⟩,
  ⟨35, 1, some .a4, f33, f34, 0⟩,
  ⟨36, 1, some .a2, f34, f35, 0⟩,
  ⟨37, 1, some .a2, f35, f36, 0⟩,
  ⟨38, 1, some .a2, f36, f37, 0⟩,
  ⟨39, 1, some .a2, f37, f38, 0⟩,
  ⟨40, 1, some .a2, f38, f39, 0⟩,
  ⟨41, 1, some .a2, f39, f40, 0⟩,
  ⟨42, 1, some .a1, f40, f41, 0⟩,
  ⟨43, 1, some .a2, f41, f42, 0⟩,
  ⟨44, 1, some .a1, f42, f43, 0⟩,
  ⟨45, 1, some .a2, f43, f44, 0⟩,
  ⟨46, 1, some .a1, f44, f45, 2⟩,
  ⟨47, 1, some .a1, f45, f46, 0⟩,
  ⟨48, 1, some .a4, f46, f47, 0⟩,
  ⟨49, 1, some .a1, f47, f48, 0⟩,
  ⟨50, 1, some .a1, f48, f49, 0⟩,
  ⟨51, 1, some .a1, f49, f50, 0⟩,
  ⟨52, 1, some .a1, f50, f51, 0⟩,
  ⟨53, 1, some .a1, f51, f52, 0⟩,
  ⟨54, 1, some .a4, f52, f53, 0⟩,
  ⟨55, 1, some .a4, f53, f54, 0⟩,
  ⟨56, 1, some .a2, f54, f55, 0⟩,
  ⟨57, 1, some .a4, f55, f56, 0⟩,
  ⟨58, 1, some .a2, f56, f57, 0⟩,
  ⟨59, 1, some .a2, f57, f58, 0⟩,
  ⟨60, 1, some .a2, f58, f59, 0⟩,
  ⟨61, 1, some .a2, f59, f60, 0⟩,
  ⟨62, 1, some .a2, f60, f61, 0⟩,
  ⟨63, 1, some .a2, f61, f62, 0⟩,
  ⟨64, 1, some .a2, f62, f63, 0⟩,
  ⟨65, 1, some .a3, f63, f64, 0⟩,
  ⟨66, 1, some .a3, f64, f65, 0⟩,
  ⟨67, 1, some .a4, f65, f66, 0⟩,
  ⟨68, 1, some .a1, f66, f67, 0⟩,
  ⟨69, 1, some .a4, f67, f68, 0⟩,
  ⟨70, 1, some .a1, f68, f69, 0⟩,
  ⟨71, 1, some .a2, f69, f70, 0⟩,
  ⟨72, 1, some .a1, f70, f71, 0⟩,
  ⟨73, 1, some .a1, f71, f72, 0⟩,
  ⟨74, 1, some .a1, f72, f73, 0⟩,
  ⟨75, 1, some .a1, f73, f74, 0⟩,
  ⟨76, 1, some .a1, f74, f75, 0⟩,
  ⟨77, 1, some .a1, f75, f76, 0⟩,
  ⟨78, 1, some .a1, f76, f77, 0⟩,
  ⟨79, 1, some .a3, f77, f78, 0⟩,
  ⟨80, 1, some .a3, f78, f79, 0⟩,
  ⟨81, 1, some .a3, f79, f80, 0⟩,
  ⟨82, 1, some .a3, f80, f81, 0⟩,
  ⟨83, 1, some .a3, f81, f82, 0⟩,
  ⟨84, 1, some .a3, f82, f83, 0⟩,
  ⟨85, 1, some .a2, f83, f84, 0⟩,
  ⟨86, 1, some .a3, f84, f85, 0⟩,
  ⟨87, 1, some .a2, f85, f86, 0⟩,
  ⟨88, 1, some .a2, f86, f87, 0⟩,
  ⟨89, 1, some .a2, f87, f88, 0⟩,
  ⟨90, 1, some .a2, f88, f89, 0⟩,
  ⟨91, 1, some .a2, f89, f90, 1⟩,
  ⟨92, 2, some .a1, f90, f91, 0⟩,
  ⟨93, 2, some .a1, f91, f92, 0⟩,
  ⟨94, 2, some .a1, f92, f93, 0⟩,
  ⟨95, 2, some .a1, f93, f94, 0⟩,
  ⟨96, 2, some .a1, f94, f95, 0⟩,
  ⟨97, 2, some .a1, f95, f96, 0⟩,
  ⟨98, 2, some .a1, f96, f97, 0⟩,
  ⟨99, 2, some .a1, f97, f98, 0⟩,
  ⟨100, 2, some .a3, f98, f99, 0⟩,
  ⟨101, 2, some .a2, f99, f100, 0⟩,
  ⟨102, 2, some .a2, f100, f101, 0⟩,
  ⟨103, 2, some .a4, f101, f102, 0⟩,
  ⟨104, 2, some .a2, f102, f103, 0⟩,
  ⟨105, 2, some .a2, f103, f104, 0⟩,
  ⟨106, 2, some .a4, f104, f105, 0⟩,
  ⟨107, 2, some .a4, f105, f106, 0⟩,
  ⟨108, 2, some .a4, f106, f107, 0⟩,
  ⟨109, 2, some .a4, f107, f108, 0⟩,
  ⟨110, 2, some .a1, f108, f109, 0⟩,
  ⟨111, 2, some .a1, f109, f110, 0⟩,
  ⟨112, 2, some .a1, f110, f111, 0⟩,
  ⟨113, 2, some .a3, f111, f112, 0⟩,
  ⟨114, 2, some .a1, f112, f113, 0⟩,
  ⟨115, 2, some .a2, f113, f114, 0⟩,
  ⟨116, 2, some .a1, f114, f115, 0⟩,
  ⟨117, 2, some .a4, f115, f116, 0⟩,
  ⟨118, 2, some .a2, f116, f116, 0⟩,
  ⟨119, 2, some .a1, f116, f117, 0⟩,
  ⟨120, 2, some .a1, f117, f118, 0⟩,
  ⟨121, 2, some .a1, f118, f119, 0⟩,
  ⟨122, 2, some .a1, f119, f120, 0⟩,
  ⟨123, 2, some .a1, f120, f121, 0⟩,
  ⟨124, 2, some .a1, f121, f122, 0⟩,
  ⟨125, 2, some .a1, f122, f123, 0⟩,
  ⟨126, 2, some .a1, f123, f124, 2⟩,
  ⟨127, 2, some .a1, f124, f125, 0⟩,
  ⟨128, 2, some .a1, f125, f126, 0⟩,
  ⟨129, 2, some .a1, f126, f127, 0⟩,
  ⟨130, 2, some .a1, f127, f128, 0⟩,
  ⟨131, 2, some .a1, f128, f129, 0⟩,
  ⟨132, 2, some .a1, f129, f130, 0⟩,
  ⟨133, 2, some .a1, f130, f131, 0⟩,
  ⟨134, 2, some .a1, f131, f132, 0⟩,
  ⟨135, 2, some .a3, f132, f133, 0⟩,
  ⟨136, 2, some .a2, f133, f134, 0⟩,
  ⟨137, 2, some .a2, f134, f135, 0⟩,
  ⟨138, 2, some .a2, f135, f136, 0⟩,
  ⟨139, 2, some .a2, f136, f137, 0⟩,
  ⟨140, 2, some .a2, f137, f138, 0⟩,
  ⟨141, 2, some .a2, f138, f139, 0⟩,
  ⟨142, 2, some .a2, f139, f140, 0⟩,
  ⟨143, 2, some .a3, f140, f141, 0⟩,
  ⟨144, 2, some .a2, f141, f142, 0⟩,
  ⟨145, 2, some .a4, f142, f143, 0⟩,
  ⟨146, 2, some .a3, f143, f144, 0⟩,
  ⟨147, 2, some .a4, f144, f145, 0⟩,
  ⟨148, 2, some .a3, f145, f146, 2⟩,
  ⟨149, 2, some .a1, f146, f147, 0⟩,
  ⟨150, 2, some .a1, f147, f148, 0⟩,
  ⟨151, 2, some .a1, f148, f149, 0⟩,
  ⟨152, 2, some .a1, f149, f150, 0⟩,
  ⟨153, 2, some .a1, f150, f151, 0⟩,
  ⟨154, 2, some .a1, f151, f152, 0⟩,
  ⟨155, 2, some .a1, f152, f153, 0⟩,
  ⟨156, 2, some .a1, f153, f154, 0⟩,
  ⟨157, 2, some .a3, f154, f155, 0⟩,
  ⟨158, 2, some .a2, f155, f156, 0⟩,
  ⟨159, 2, some .a2, f156, f157, 0⟩,
  ⟨160, 2, some .a2, f157, f158, 0⟩,
  ⟨161, 2, some .a2, f158, f159, 0⟩,
  ⟨162, 2, some .a2, f159, f160, 0⟩,
  ⟨163, 2, some .a2, f160, f161, 0⟩,
  ⟨164, 2, some .a2, f161, f162, 0⟩,
  ⟨165, 2, some .a2, f162, f163, 0⟩,
  ⟨166, 2, some .a1, f163, f164, 0⟩,
  ⟨167, 2, some .a1, f164, f165, 0⟩,
  ⟨168, 2, some .a1, f165, f166, 0⟩,
  ⟨169, 2, some .a3, f166, f167, 0⟩,
  ⟨170, 2, some .a3, f167, f168, 0⟩,
  ⟨171, 2, some .a1, f168, f169, 0⟩,
  ⟨172, 2, some .a4, f169, f170, 0⟩,
  ⟨173, 2, some .a4, f170, f171, 0⟩,
  ⟨174, 2, some .a4, f171, f172, 0⟩,
  ⟨175, 2, some .a4, f172, f173, 0⟩,
  ⟨176, 2, some .a4, f173, f174, 0⟩,
  ⟨177, 2, some .a4, f174, f175, 0⟩,
  ⟨178, 2, some .a4, f175, f176, 0⟩,
  ⟨179, 2, some .a1, f176, f177, 0⟩,
  ⟨180, 2, some .a1, f177, f178, 0⟩,
  ⟨181, 2, some .a1, f178, f179, 0⟩,
  ⟨182, 2, some .a3, f179, f180, 0⟩,
  ⟨183, 2, some .a1, f180, f181, 0⟩,
  ⟨184, 2, some .a2, f181, f182, 0⟩,
  ⟨185, 2, some .a1, f182, f183, 0⟩,
  ⟨186, 2, some .a4, f183, f184, 0⟩,
  ⟨187, 2, some .a2, f184, f185, 1⟩,
  ⟨188, 3, some .a3, f185, f186, 0⟩,
  ⟨189, 3, some .a3, f186, f187, 0⟩,
  ⟨190, 3, some .a3, f187, f188, 0⟩,
  ⟨191, 3, some .a2, f188, f189, 0⟩,
  ⟨192, 3, some .a2, f189, f190, 0⟩,
  ⟨193, 3, some .a2, f190, f191, 0⟩,
  ⟨194, 3, some .a2, f191, f192, 0⟩,
  ⟨195, 3, some .a2, f192, f193, 0⟩,
  ⟨196, 3, some .a2, f193, f194, 0⟩,
  ⟨197, 3, some .a2, f194, f195, 0⟩,
  ⟨198, 3, some .a3, f195, f196, 0⟩,
  ⟨199, 3, some .a2, f196, f197, 0⟩,
  ⟨200, 3, some .a2, f197, f198, 0⟩,
  ⟨201, 3, some .a3, f198, f199, 0⟩,
  ⟨202, 3, some .a3, f199, f200, 0⟩,
  ⟨203, 3, some .a1, f200, f201, 0⟩,
  ⟨204, 3, some .a2, f201, f202, 0⟩,
  ⟨205, 3, some .a1, f202, f203, 0⟩,
  ⟨206, 3, some .a2, f203, f204, 0⟩,
  ⟨207, 3, some .a1, f204, f205, 0⟩,
  ⟨208, 3, some .a1, f205, f206, 0⟩,
  ⟨209, 3, some .a3, f206, f207, 0⟩,
  ⟨210, 3, some .a3, f207, f208, 0⟩,
  ⟨211, 3, some .a1, f208, f209, 0⟩,
  ⟨212, 3, some .a2, f209, f210, 0⟩,
  ⟨213, 3, some .a2, f210, f211, 0⟩,
  ⟨214, 3, some .a3, f211, f212, 0⟩,
  ⟨215, 3, some .a1, f212, f213, 0⟩,
  ⟨216, 3, some .a3, f213, f214, 0⟩,
  ⟨217, 3, some .a1, f214, f215, 0⟩,
  ⟨218, 3, some .a1, f215, f216, 0⟩,
  ⟨219, 3, some .a1, f216, f217, 0⟩,
  ⟨220, 3, some .a2, f217, f218, 0⟩,
  ⟨221, 3, some .a2, f218, f219, 0⟩,
  ⟨222, 3, some .a4, f219, f220, 0⟩,
  ⟨223, 3, some .a1, f220, f221, 0⟩,
  ⟨224, 3, some .a1, f221, f222, 0⟩,
  ⟨225, 3, some .a1, f222, f223, 0⟩,
  ⟨226, 3, some .a1, f223, f224, 0⟩,
  ⟨227, 3, some .a4, f224, f225, 0⟩,
  ⟨228, 3, some .a1, f225, f226, 0⟩,
  ⟨229, 3, some .a4, f226, f227, 0⟩,
  ⟨230, 3, some .a4, f227, f228, 0⟩,
  ⟨231, 3, some .a4, f228, f229, 0⟩,
  ⟨232, 3, some .a2, f229, f230, 0⟩,
  ⟨233, 3, some .a2, f230, f231, 0⟩,
  ⟨234, 3, some .a2, f231, f232, 0⟩,
  ⟨235, 3, some .a3, f232, f233, 0⟩,
  ⟨236, 3, some .a3, f233, f234, 0⟩,
  ⟨237, 3, some .a1, f234, f235, 0⟩,
  ⟨238, 3, some .a2, f235, f236, 0⟩,
  ⟨239, 3, some .a1, f236, f237, 0⟩,
  ⟨240, 3, some .a4, f237, f238, 0⟩,
  ⟨241, 3, some .a2, f238, f239, 0⟩,
  ⟨242, 3, some .a2, f239, f240, 0⟩,
  ⟨243, 3, some .a3, f240, f241, 0⟩,
  ⟨244, 3, some .a3, f241, f242, 0⟩,
  ⟨245, 3, some .a3, f242, f243, 0⟩,
  ⟨246, 3, some .a1, f243, f244, 0⟩,
  ⟨247, 3, some .a1, f244, f245, 0⟩,
  ⟨248, 3, some .a3, f245, f246, 0⟩,
  ⟨249, 3, some .a3, f246, f247, 0⟩,
  ⟨250, 3, some .a3, f247, f248, 1⟩,
  ⟨251, 4, some .a1, f248, f249, 0⟩,
  ⟨252, 4, some .a3, f249, f250, 0⟩,
  ⟨253, 4, some .a1, f250, f251, 0⟩,
  ⟨254, 4, some .a1, f251, f252, 0⟩,
  ⟨255, 4, some .a1, f252, f253, 0⟩,
  ⟨256, 4, some .a1, f253, f254, 0⟩,
  ⟨257, 4, some .a3, f254, f255, 0⟩,
  ⟨258, 4, some .a3, f255, f256, 0⟩,
  ⟨259, 4, some .a3, f256, f257, 0⟩,
  ⟨260, 4, some .a3, f257, f258, 0⟩,
  ⟨261, 4, some .a1, f258, f259, 0⟩,
  ⟨262, 4, some .a3, f259, f260, 0⟩,
  ⟨263, 4, some .a2, f260, f261, 0⟩,
  ⟨264, 4, some .a1, f261, f262, 0⟩,
  ⟨265, 4, some .a3, f262, f263, 0⟩,
  ⟨266, 4, some .a3, f263, f264, 0⟩,
  ⟨267, 4, some .a4, f264, f265, 0⟩,
  ⟨268, 4, some .a2, f265, f266, 0⟩,
  ⟨269, 4, some .a4, f266, f267, 0⟩,
  ⟨270, 4, some .a2, f267, f268, 0⟩,
  ⟨271, 4, some .a2, f268, f269, 0⟩,
  ⟨272, 4, some .a2, f269, f270, 0⟩,
  ⟨273, 4, some .a2, f270, f271, 0⟩,
  ⟨274, 4, some .a2, f271, f272, 0⟩,
  ⟨275, 4, some .a4, f272, f273, 0⟩,
  ⟨276, 4, some .a2, f273, f274, 0⟩,
  ⟨277, 4, some .a1, f274, f275, 0⟩,
  ⟨278, 4, some .a1, f275, f276, 0⟩,
  ⟨279, 4, some .a4, f276, f277, 0⟩,
  ⟨280, 4, some .a4, f277, f278, 0⟩,
  ⟨281, 4, some .a2, f278, f279, 0⟩,
  ⟨282, 4, some .a1, f279, f280, 0⟩,
  ⟨283, 4, some .a2, f280, f281, 0⟩,
  ⟨284, 4, some .a3, f281, f282, 0⟩,
  ⟨285, 4, some .a4, f282, f283, 0⟩,
  ⟨286, 4, some .a3, f283, f284, 0⟩,
  ⟨287, 4, some .a4, f284, f285, 0⟩,
  ⟨288, 4, some .a3, f285, f286, 0⟩,
  ⟨289, 4, some .a4, f286, f287, 0⟩,
  ⟨290, 4, some .a3, f287, f288, 0⟩,
  ⟨291, 4, some .a4, f288, f289, 0⟩,
  ⟨292, 4, some .a3, f289, f290, 0⟩,
  ⟨293, 4, some .a4, f290, f291, 0⟩,
  ⟨294, 4, some .a3, f291, f292, 0⟩,
  ⟨295, 4, some .a4, f292, f293, 0⟩,
  ⟨296, 4, some .a3, f293, f294, 0⟩,
  ⟨297, 4, some .a4, f294, f295, 0⟩,
  ⟨298, 4, some .a3, f295, f296, 2⟩,
  ⟨299, 4, some .a1, f296, f297, 0⟩,
  ⟨300, 4, some .a3, f297, f298, 0⟩,
  ⟨301, 4, some .a1, f298, f299, 0⟩,
  ⟨302, 4, some .a1, f299, f300, 0⟩,
  ⟨303, 4, some .a3, f300, f301, 0⟩,
  ⟨304, 4, some .a3, f301, f302, 0⟩,
  ⟨305, 4, some .a3, f302, f303, 0⟩,
  ⟨306, 4, some .a4, f303, f304, 0⟩,
  ⟨307, 4, some .a3, f304, f305, 0⟩,
  ⟨308, 4, some .a4, f305, f306, 0⟩,
  ⟨309, 4, some .a3, f306, f307, 0⟩,
  ⟨310, 4, some .a4, f307, f308, 0⟩,
  ⟨311, 4, some .a4, f308, f309, 0⟩,
  ⟨312, 4, some .a4, f309, f310, 0⟩,
  ⟨313, 4, some .a3, f310, f311, 0⟩,
  ⟨314, 4, some .a2, f311, f312, 0⟩,
  ⟨315, 4, some .a2, f312, f313, 0⟩,
  ⟨316, 4, some .a3, f313, f314, 0⟩,
  ⟨317, 4, some .a3, f314, f315, 0⟩,
  ⟨318, 4, some .a3, f315, f316, 0⟩,
  ⟨319, 4, some .a1, f316, f317, 0⟩,
  ⟨320, 4, some .a3, f317, f318, 0⟩,
  ⟨321, 4, some .a1, f318, f319, 0⟩,
  ⟨322, 4, some .a2, f319, f320, 0⟩,
  ⟨323, 4, some .a2, f320, f321, 0⟩,
  ⟨324, 4, some .a2, f321, f322, 0⟩,
  ⟨325, 4, some .a2, f322, f323, 0⟩,
  ⟨326, 4, some .a2, f323, f324, 0⟩,
  ⟨327, 4, some .a2, f324, f325, 0⟩,
  ⟨328, 4, some .a4, f325, f326, 0⟩,
  ⟨329, 4, some .a4, f326, f327, 0⟩,
  ⟨330, 4, some .a3, f327, f328, 0⟩,
  ⟨331, 4, some .a2, f328, f329, 0⟩,
  ⟨332, 4, some .a2, f329, f330, 0⟩,
  ⟨333, 4, some .a4, f330, f331, 0⟩,
  ⟨334, 4, some .a2, f331, f332, 0⟩,
  ⟨335, 4, some .a4, f332, f333, 0⟩,
  ⟨336, 4, some .a4, f333, f334, 0⟩,
  ⟨337, 4, some .a4, f334, f335, 0⟩,
  ⟨338, 4, some .a4, f335, f336, 0⟩,
  ⟨339, 4, some .a4, f336, f337, 0⟩,
  ⟨340, 4, some .a4, f337, f338, 0⟩,
  ⟨341, 4, some .a4, f338, f339, 0⟩,
  ⟨342, 4, some .a1, f339, f340, 1⟩,
  ⟨343, 5, some .a1, f340, f341, 0⟩,
  ⟨344, 5, some .a4, f341, f342, 0⟩,
  ⟨345, 5, some .a4, f342, f343, 0⟩,
  ⟨346, 5, some .a1, f343, f344, 0⟩,
  ⟨347, 5, some .a2, f344, f345, 0⟩,
  ⟨348, 5, some .a3, f345, f346, 0⟩,
  ⟨349, 5, some .a4, f346, f347, 0⟩,
  ⟨350, 5, some .a3, f347, f348, 0⟩,
  ⟨351, 5, some .a4, f348, f349, 0⟩,
  ⟨352, 5, some .a3, f349, f350, 0⟩,
  ⟨353, 5, some .a4, f350, f351, 0⟩,
  ⟨354, 5, some .a3, f351, f352, 0⟩,
  ⟨355, 5, some .a4, f352, f353, 0⟩,
  ⟨356, 5, some .a3, f353, f354, 0⟩,
  ⟨357, 5, some .a4, f354, f355, 0⟩,
  ⟨358, 5, some .a1, f355, f356, 0⟩,
  ⟨359, 5, some .a3, f356, f357, 0⟩,
  ⟨360, 5, some .a4, f357, f358, 0⟩,
  ⟨361, 5, some .a4, f358, f359, 0⟩,
  ⟨362, 5, some .a1, f359, f360, 0⟩,
  ⟨363, 5, some .a1, f360, f361, 0⟩,
  ⟨364, 5, some .a1, f361, f362, 0⟩,
  ⟨365, 5, some .a3, f362, f363, 0⟩,
  ⟨366, 5, some .a3, f363, f364, 0⟩,
  ⟨367, 5, some .a2, f364, f365, 0⟩,
  ⟨368, 5, some .a1, f365, f366, 0⟩,
  ⟨369, 5, some .a4, f366, f367, 0⟩,
  ⟨370, 5, some .a4, f367, f368, 0⟩,
  ⟨371, 5, some .a1, f368, f369, 0⟩,
  ⟨372, 5, some .a1, f369, f370, 0⟩,
  ⟨373, 5, some .a4, f370, f371, 0⟩,
  ⟨374, 5, some .a3, f371, f372, 0⟩,
  ⟨375, 5, some .a1, f372, f373, 0⟩,
  ⟨376, 5, some .a1, f373, f374, 0⟩,
  ⟨377, 5, some .a2, f374, f375, 0⟩,
  ⟨378, 5, some .a2, f375, f376, 0⟩,
  ⟨379, 5, some .a2, f376, f377, 0⟩,
  ⟨380, 5, some .a2, f377, f378, 0⟩,
  ⟨381, 5, some .a3, f378, f379, 0⟩,
  ⟨382, 5, some .a3, f379, f380, 0⟩,
  ⟨383, 5, some .a2, f380, f381, 0⟩,
  ⟨384, 5, some .a1, f381, f382, 0⟩,
  ⟨385, 5, some .a4, f382, f383, 0⟩,
  ⟨386, 5, some .a4, f383, f384, 0⟩,
  ⟨387, 5, some .a1, f384, f385, 0⟩,
  ⟨388, 5, some .a1, f385, f386, 0⟩,
  ⟨389, 5, some .a4, f386, f387, 0⟩,
  ⟨390, 5, some .a2, f387, f388, 0⟩,
  ⟨391, 5, some .a1, f388, f389, 0⟩,
  ⟨392, 5, some .a2, f389, f390, 0⟩,
  ⟨393, 5, some .a3, f390, f391, 0⟩,
  ⟨394, 5, some .a2, f391, f392, 0⟩,
  ⟨395, 5, some .a3, f392, f393, 0⟩,
  ⟨396, 5, some .a3, f393, f394, 0⟩,
  ⟨397, 5, some .a4, f394, f395, 0⟩,
  ⟨398, 5, some .a4, f395, f396, 0⟩,
  ⟨399, 5, some .a1, f396, f397, 0⟩,
  ⟨400, 5, some .a1, f397, f398, 0⟩,
  ⟨401, 5, some .a4, f398, f399, 0⟩,
  ⟨402, 5, some .a4, f399, f400, 0⟩,
  ⟨403, 5, some .a1, f400, f401, 0⟩,
  ⟨404, 5, some .a1, f401, f402, 0⟩,
  ⟨405, 5, some .a4, f402, f403, 0⟩,
  ⟨406, 5, some .a2, f403, f404, 0⟩,
  ⟨407, 5, some .a2, f404, f405, 0⟩,
  ⟨408, 5, some .a1, f405, f406, 0⟩,
  ⟨409, 5, some .a2, f406, f407, 0⟩,
  ⟨410, 5, some .a1, f407, f408, 0⟩,
  ⟨411, 5, some .a2, f408, f409, 0⟩,
  ⟨412, 5, some .a1, f409, f410, 0⟩,
  ⟨413, 5, some .a2, f410, f411, 0⟩,
  ⟨414, 5, some .a1, f411, f412, 0⟩,
  ⟨415, 5, some .a2, f412, f413, 0⟩,
  ⟨416, 5, some .a1, f413, f414, 0⟩,
  ⟨417, 5, some .a2, f414, f415, 0⟩,
  ⟨418, 5, some .a1, f415, f416, 0⟩,
  ⟨419, 5, some .a2, f416, f417, 2⟩,
  ⟨420, 5, some .a1, f417, f418, 0⟩,
  ⟨421, 5, some .a1, f418, f419, 0⟩,
  ⟨422, 5, some .a2, f419, f420, 0⟩,
  ⟨423, 5, some .a3, f420, f421, 0⟩,
  ⟨424, 5, some .a4, f421, f422, 0⟩,
  ⟨425, 5, some .a1, f422, f423, 0⟩,
  ⟨426, 5, some .a2, f423, f424, 0⟩,
  ⟨427, 5, some .a3, f424, f425, 0⟩,
  ⟨428, 5, some .a4, f425, f426, 0⟩,
  ⟨429, 5, some .a1, f426, f427, 0⟩,
  ⟨430, 5, none, f427, f0, 3⟩,
  ⟨431, 0, some .a3, f0, f428, 0⟩,
  ⟨432, 0, some .a3, f428, f429, 0⟩,
  ⟨433, 0, some .a3, f429, f430, 0⟩,
  ⟨434, 0, some .a1, f430, f431, 0⟩,
  ⟨435, 0, some .a1, f431, f432, 0⟩,
  ⟨436, 0, some .a1, f432, f433, 0⟩,
  ⟨437, 0, some .a1, f433, f434, 0⟩,
  ⟨438, 0, some .a4, f434, f435, 0⟩,
  ⟨439, 0, some .a4, f435, f436, 0⟩,
  ⟨440, 0, some .a4, f436, f437, 0⟩,
  ⟨441, 0, some .a1, f437, f438, 0⟩,
  ⟨442, 0, some .a1, f438, f439, 0⟩,
  ⟨443, 0, some .a1, f439, f23, 1⟩,
  ⟨444, 1, some .a1, f23, f24, 0⟩,
  ⟨445, 1, some .a4, f24, f25, 0⟩,
  ⟨446, 1, some .a1, f25, f26, 0⟩,
  ⟨447, 1, some .a1, f26, f27, 0⟩,
  ⟨448, 1, some .a1, f27, f28, 0⟩,
  ⟨449, 1, some .a1, f28, f29, 0⟩,
  ⟨450, 1, some .a1, f29, f30, 0⟩,
  ⟨451, 1, some .a4, f30, f31, 0⟩,
  ⟨452, 1, some .a4, f31, f32, 0⟩,
  ⟨453, 1, some .a2, f32, f33, 0⟩,
  ⟨454, 1, some .a4, f33, f34, 0⟩,
  ⟨455, 1, some .a2, f34, f35, 0⟩,
  ⟨456, 1, some .a2, f35, f36, 0⟩,
  ⟨457, 1, some .a2, f36, f37, 0⟩,
  ⟨458, 1, some .a2, f37, f38, 0⟩,
  ⟨459, 1, some .a2, f38, f39, 0⟩,
  ⟨460, 1, some .a2, f39, f40, 0⟩,
  ⟨461, 1, some .a2, f40, f440, 0⟩,
  ⟨462, 1, some .a3, f440, f441, 0⟩,
  ⟨463, 1, some .a3, f441, f442, 0⟩,
  ⟨464, 1, some .a4, f442, f443, 0⟩,
  ⟨465, 1, some .a1, f443, f444, 0⟩,
  ⟨466, 1, some .a4, f444, f445, 0⟩,
  ⟨467, 1, some .a1, f445, f446, 0⟩,
  ⟨468, 1, some .a2, f446, f447, 0⟩,
  ⟨469, 1, some .a1, f447, f448, 0⟩,
  ⟨470, 1, some .a1, f448, f449, 0⟩,
  ⟨471, 1, some .a1, f449, f450, 0⟩,
  ⟨472, 1, some .a1, f450, f451, 0⟩,
  ⟨473, 1, some .a1, f451, f452, 0⟩,
  ⟨474, 1, some .a1, f452, f453, 0⟩,
  ⟨475, 1, some .a1, f453, f454, 0⟩,
  ⟨476, 1, some .a3, f454, f455, 0⟩,
  ⟨477, 1, some .a3, f455, f456, 0⟩,
  ⟨478, 1, some .a3, f456, f457, 0⟩,
  ⟨479, 1, some .a3, f457, f458, 0⟩,
  ⟨480, 1, some .a3, f458, f459, 0⟩,
  ⟨481, 1, some .a3, f459, f460, 0⟩,
  ⟨482, 1, some .a2, f460, f461, 0⟩,
  ⟨483, 1, some .a3, f461, f462, 0⟩,
  ⟨484, 1, some .a2, f462, f463, 0⟩,
  ⟨485, 1, some .a2, f463, f464, 0⟩,
  ⟨486, 1, some .a2, f464, f465, 0⟩,
  ⟨487, 1, some .a2, f465, f466, 0⟩,
  ⟨488, 1, some .a2, f466, f90, 1⟩,
  ⟨489, 2, some .a1, f90, f91, 0⟩,
  ⟨490, 2, some .a1, f91, f92, 0⟩,
  ⟨491, 2, some .a1, f92, f93, 0⟩,
  ⟨492, 2, some .a1, f93, f94, 0⟩,
  ⟨493, 2, some .a1, f94, f95, 0⟩,
  ⟨494, 2, some .a1, f95, f96, 0⟩,
  ⟨495, 2, some .a1, f96, f97, 0⟩,
  ⟨496, 2, some .a1, f97, f98, 0⟩,
  ⟨497, 2, some .a3, f98, f99, 0⟩,
  ⟨498, 2, some .a2, f99, f100, 0⟩,
  ⟨499, 2, some .a2, f100, f101, 0⟩,
  ⟨500, 2, some .a4, f101, f102, 0⟩,
  ⟨501, 2, some .a2, f102, f103, 0⟩,
  ⟨502, 2, some .a2, f103, f104, 0⟩,
  ⟨503, 2, some .a2, f104, f467, 0⟩,
  ⟨504, 2, some .a3, f467, f468, 0⟩,
  ⟨505, 2, some .a2, f468, f469, 0⟩,
  ⟨506, 2, some .a2, f469, f470, 0⟩,
  ⟨507, 2, some .a2, f470, f471, 0⟩,
  ⟨508, 2, some .a1, f471, f472, 0⟩,
  ⟨509, 2, some .a1, f472, f473, 0⟩,
  ⟨510, 2, some .a1, f473, f474, 0⟩,
  ⟨511, 2, some .a3, f474, f475, 0⟩,
  ⟨512, 2, some .a3, f475, f476, 0⟩,
  ⟨513, 2, some .a1, f476, f477, 0⟩,
  ⟨514, 2, some .a4, f477, f478, 0⟩,
  ⟨515, 2, some .a4, f478, f479, 0⟩,
  ⟨516, 2, some .a4, f479, f480, 0⟩,
  ⟨517, 2, some .a4, f480, f481, 0⟩,
  ⟨518, 2, some .a4, f481, f482, 0⟩,
  ⟨519, 2, some .a4, f482, f483, 0⟩,
  ⟨520, 2, some .a4, f483, f484, 0⟩,
  ⟨521, 2, some .a1, f484, f485, 0⟩,
  ⟨522, 2, some .a1, f485, f486, 0⟩,
  ⟨523, 2, some .a1, f486, f487, 0⟩,
  ⟨524, 2, some .a3, f487, f488, 0⟩,
  ⟨525, 2, some .a1, f488, f489, 0⟩,
  ⟨526, 2, some .a2, f489, f490, 0⟩,
  ⟨527, 2, some .a1, f490, f491, 0⟩,
  ⟨528, 2, some .a4, f491, f492, 0⟩,
  ⟨529, 2, some .a2, f492, f185, 1⟩,
  ⟨530, 3, some .a3, f185, f186, 0⟩,
  ⟨531, 3, some .a3, f186, f187, 0⟩,
  ⟨532, 3, some .a3, f187, f188, 0⟩,
  ⟨533, 3, some .a2, f188, f189, 0⟩,
  ⟨534, 3, some .a2, f189, f190, 0⟩,
  ⟨535, 3, some .a2, f190, f191, 0⟩,
  ⟨536, 3, some .a3, f191, f493, 0⟩,
  ⟨537, 3, some .a2, f493, f494, 0⟩,
  ⟨538, 3, some .a2, f494, f495, 0⟩,
  ⟨539, 3, some .a3, f495, f496, 0⟩,
  ⟨540, 3, some .a3, f496, f497, 0⟩,
  ⟨541, 3, some .a1, f497, f498, 0⟩,
  ⟨542, 3, some .a2, f498, f499, 0⟩,
  ⟨543, 3, some .a1, f499, f500, 0⟩,
  ⟨544, 3, some .a2, f500, f501, 0⟩,
  ⟨545, 3, some .a1, f501, f502, 0⟩,
  ⟨546, 3, some .a2, f502, f503, 0⟩,
  ⟨547, 3, some .a1, f503, f504, 0⟩,
  ⟨548, 3, some .a1, f504, f505, 0⟩,
  ⟨549, 3, some .a3, f505, f506, 0⟩,
  ⟨550, 3, some .a3, f506, f507, 0⟩,
  ⟨551, 3, some .a1, f507, f508, 0⟩,
  ⟨552, 3, some .a2, f508, f509, 0⟩,
  ⟨553, 3, some .a3, f509, f510, 0⟩,
  ⟨554, 3, some .a3, f510, f511, 0⟩,
  ⟨555, 3, some .a1, f511, f512, 0⟩,
  ⟨556, 3, some .a1, f512, f513, 0⟩,
  ⟨557, 3, some .a1, f513, f514, 0⟩,
  ⟨558, 3, some .a2, f514, f515, 0⟩,
  ⟨559, 3, some .a2, f515, f516, 0⟩,
  ⟨560, 3, some .a4, f516, f517, 0⟩,
  ⟨561, 3, some .a1, f517, f518, 0⟩,
  ⟨562, 3, some .a1, f518, f519, 0⟩,
  ⟨563, 3, some .a1, f519, f520, 0⟩,
  ⟨564, 3, some .a1, f520, f521, 0⟩,
  ⟨565, 3, some .a4, f521, f522, 0⟩,
  ⟨566, 3, some .a1, f522, f523, 0⟩,
  ⟨567, 3, some .a4, f523, f524, 0⟩,
  ⟨568, 3, some .a1, f524, f525, 0⟩,
  ⟨569, 3, some .a1, f525, f526, 0⟩,
  ⟨570, 3, some .a3, f526, f527, 0⟩,
  ⟨571, 3, some .a3, f527, f528, 0⟩,
  ⟨572, 3, some .a3, f528, f248, 1⟩,
  ⟨573, 4, some .a1, f248, f249, 0⟩,
  ⟨574, 4, some .a3, f249, f250, 0⟩,
  ⟨575, 4, some .a1, f250, f251, 0⟩,
  ⟨576, 4, some .a1, f251, f252, 0⟩,
  ⟨577, 4, some .a3, f252, f529, 0⟩,
  ⟨578, 4, some .a3, f529, f530, 0⟩,
  ⟨579, 4, some .a3, f530, f531, 0⟩,
  ⟨580, 4, some .a4, f531, f532, 0⟩,
  ⟨581, 4, some .a3, f532, f533, 0⟩,
  ⟨582, 4, some .a4, f533, f534, 0⟩,
  ⟨583, 4, some .a3, f534, f535, 0⟩,
  ⟨584, 4, some .a4, f535, f536, 0⟩,
  ⟨585, 4, some .a4, f536, f537, 0⟩,
  ⟨586, 4, some .a4, f537, f538, 0⟩,
  ⟨587, 4, some .a3, f538, f539, 0⟩,
  ⟨588, 4, some .a2, f539, f540, 0⟩,
  ⟨589, 4, some .a2, f540, f541, 0⟩,
  ⟨590, 4, some .a3, f541, f542, 0⟩,
  ⟨591, 4, some .a3, f542, f543, 0⟩,
  ⟨592, 4, some .a3, f543, f544, 0⟩,
  ⟨593, 4, some .a1, f544, f545, 0⟩,
  ⟨594, 4, some .a3, f545, f546, 0⟩,
  ⟨595, 4, some .a1, f546, f547, 0⟩,
  ⟨596, 4, some .a2, f547, f548, 0⟩,
  ⟨597, 4, some .a2, f548, f549, 0⟩,
  ⟨598, 4, some .a2, f549, f550, 0⟩,
  ⟨599, 4, some .a2, f550, f551, 0⟩,
  ⟨600, 4, some .a2, f551, f552, 0⟩,
  ⟨601, 4, some .a2, f552, f553, 0⟩,
  ⟨602, 4, some .a4, f553, f554, 0⟩,
  ⟨603, 4, some .a4, f554, f555, 0⟩,
  ⟨604, 4, some .a3, f555, f556, 0⟩,
  ⟨605, 4, some .a2, f556, f557, 0⟩,
  ⟨606, 4, some .a2, f557, f558, 0⟩,
  ⟨607, 4, some .a4, f558, f559, 0⟩,
  ⟨608, 4, some .a2, f559, f560, 0⟩,
  ⟨609, 4, some .a4, f560, f561, 0⟩,
  ⟨610, 4, some .a4, f561, f562, 0⟩,
  ⟨611, 4, some .a4, f562, f563, 0⟩,
  ⟨612, 4, some .a4, f563, f564, 0⟩,
  ⟨613, 4, some .a4, f564, f565, 0⟩,
  ⟨614, 4, some .a4, f565, f566, 0⟩,
  ⟨615, 4, some .a4, f566, f567, 0⟩,
  ⟨616, 4, some .a1, f567, f340, 1⟩,
  ⟨617, 5, some .a1, f340, f341, 0⟩,
  ⟨618, 5, some .a1, f341, f568, 0⟩,
  ⟨619, 5, some .a4, f568, f569, 0⟩,
  ⟨620, 5, some .a4, f569, f570, 0⟩,
  ⟨621, 5, some .a4, f570, f571, 0⟩,
  ⟨622, 5, some .a1, f571, f572, 0⟩,
  ⟨623, 5, some .a1, f572, f573, 0⟩,
  ⟨624, 5, some .a1, f573, f574, 0⟩,
  ⟨625, 5, some .a1, f574, f575, 0⟩,
  ⟨626, 5, some .a1, f575, f576, 0⟩,
  ⟨627, 5, some .a1, f576, f577, 0⟩,
  ⟨628, 5, some .a3, f577, f578, 0⟩,
  ⟨629, 5, some .a4, f578, f579, 0⟩,
  ⟨630, 5, some .a3, f579, f580, 0⟩,
  ⟨631, 5, some .a4, f580, f581, 0⟩,
  ⟨632, 5, some .a3, f581, f582, 0⟩,
  ⟨633, 5, some .a4, f582, f583, 0⟩,
  ⟨634, 5, some .a3, f583, f584, 0⟩,
  ⟨635, 5, some .a4, f584, f585, 0⟩,
  ⟨636, 5, some .a3, f585, f586, 0⟩,
  ⟨637, 5, some .a4, f586, f587, 0⟩,
  ⟨638, 5, some .a3, f587, f588, 0⟩,
  ⟨639, 5, some .a3, f588, f589, 0⟩,
  ⟨640, 5, some .a3, f589, f590, 0⟩,
  ⟨641, 5, some .a3, f590, f591, 0⟩,
  ⟨642, 5, some .a4, f591, f592, 0⟩,
  ⟨643, 5, some .a4, f592, f593, 0⟩,
  ⟨644, 5, some .a3, f593, f594, 0⟩,
  ⟨645, 5, some .a1, f594, f595, 0⟩,
  ⟨646, 5, some .a4, f595, f596, 0⟩,
  ⟨647, 5, some .a4, f596, f597, 0⟩,
  ⟨648, 5, some .a4, f597, f598, 0⟩,
  ⟨649, 5, some .a2, f598, f599, 0⟩,
  ⟨650, 5, some .a2, f599, f600, 0⟩,
  ⟨651, 5, some .a2, f600, f601, 0⟩,
  ⟨652, 5, some .a2, f601, f602, 0⟩,
  ⟨653, 5, some .a3, f602, f603, 0⟩,
  ⟨654, 5, some .a3, f603, f604, 0⟩,
  ⟨655, 5, some .a2, f604, f605, 0⟩,
  ⟨656, 5, some .a3, f605, f606, 0⟩,
  ⟨657, 5, some .a1, f606, f607, 0⟩,
  ⟨658, 5, some .a4, f607, f608, 0⟩,
  ⟨659, 5, some .a4, f608, f609, 0⟩,
  ⟨660, 5, some .a4, f609, f610, 0⟩,
  ⟨661, 5, some .a2, f610, f611, 0⟩,
  ⟨662, 5, some .a2, f611, f612, 0⟩,
  ⟨663, 5, some .a2, f612, f613, 0⟩,
  ⟨664, 5, some .a3, f613, f614, 0⟩,
  ⟨665, 5, some .a3, f614, f615, 0⟩,
  ⟨666, 5, some .a3, f615, f616, 0⟩,
  ⟨667, 5, some .a4, f616, f617, 0⟩,
  ⟨668, 5, some .a4, f617, f618, 0⟩,
  ⟨669, 5, some .a4, f618, f619, 0⟩,
  ⟨670, 5, some .a1, f619, f620, 0⟩,
  ⟨671, 5, some .a1, f620, f621, 0⟩,
  ⟨672, 5, some .a1, f621, f622, 0⟩,
  ⟨673, 5, some .a1, f622, f623, 0⟩,
  ⟨674, 5, some .a1, f623, f624, 0⟩,
  ⟨675, 5, some .a1, f624, f625, 0⟩,
  ⟨676, 5, some .a1, f625, f626, 0⟩,
  ⟨677, 5, some .a2, f626, f627, 0⟩,
  ⟨678, 5, some .a3, f627, f628, 0⟩,
  ⟨679, 5, some .a3, f628, f629, 0⟩,
  ⟨680, 5, some .a3, f629, f630, 0⟩,
  ⟨681, 5, some .a3, f630, f631, 0⟩,
  ⟨682, 5, some .a1, f631, f632, 0⟩,
  ⟨683, 5, some .a3, f632, f633, 0⟩,
  ⟨684, 5, some .a3, f633, f634, 0⟩,
  ⟨685, 5, some .a2, f634, f635, 0⟩,
  ⟨686, 5, some .a2, f635, f636, 0⟩,
  ⟨687, 5, some .a2, f636, f637, 0⟩,
  ⟨688, 5, some .a2, f637, f638, 0⟩,
  ⟨689, 5, some .a2, f638, f639, 0⟩,
  ⟨690, 5, some .a2, f639, f640, 0⟩,
  ⟨691, 5, some .a2, f640, f641, 0⟩,
  ⟨692, 5, some .a4, f641, f642, 0⟩,
  ⟨693, 5, some .a4, f642, f643, 0⟩,
  ⟨694, 5, some .a3, f643, f644, 0⟩,
  ⟨695, 5, some .a3, f644, f645, 0⟩,
  ⟨696, 5, some .a1, f645, f646, 0⟩,
  ⟨697, 5, some .a1, f646, f647, 0⟩,
  ⟨698, 5, some .a1, f647, f648, 0⟩,
  ⟨699, 5, some .a4, f648, f649, 0⟩,
  ⟨700, 5, some .a4, f649, f650, 0⟩,
  ⟨701, 5, some .a4, f650, f651, 0⟩,
  ⟨702, 5, some .a4, f651, f652, 0⟩,
  ⟨703, 5, some .a2, f652, f653, 0⟩,
  ⟨704, 5, some .a1, f653, f654, 0⟩,
  ⟨705, 5, some .a4, f654, f655, 0⟩,
  ⟨706, 5, some .a4, f655, f656, 0⟩,
  ⟨707, 5, some .a1, f656, f657, 0⟩,
  ⟨708, 5, some .a1, f657, f658, 0⟩,
  ⟨709, 5, some .a4, f658, f659, 0⟩,
  ⟨710, 5, some .a4, f659, f660, 0⟩,
  ⟨711, 5, some .a1, f660, f661, 0⟩,
  ⟨712, 5, some .a1, f661, f662, 0⟩,
  ⟨713, 5, some .a4, f662, f663, 0⟩,
  ⟨714, 5, some .a2, f663, f664, 0⟩,
  ⟨715, 5, some .a2, f664, f665, 0⟩,
  ⟨716, 5, some .a1, f665, f666, 0⟩,
  ⟨717, 5, some .a2, f666, f667, 0⟩,
  ⟨718, 5, some .a1, f667, f668, 0⟩,
  ⟨719, 5, some .a2, f668, f669, 0⟩,
  ⟨720, 5, some .a1, f669, f670, 0⟩,
  ⟨721, 5, some .a2, f670, f671, 0⟩,
  ⟨722, 5, some .a1, f671, f672, 0⟩,
  ⟨723, 5, some .a2, f672, f673, 0⟩,
  ⟨724, 5, some .a1, f673, f674, 0⟩,
  ⟨725, 5, some .a2, f674, f675, 0⟩,
  ⟨726, 5, some .a1, f675, f676, 0⟩,
  ⟨727, 5, some .a1, f676, f417, 2⟩,
  ⟨728, 5, some .a1, f417, f418, 0⟩,
  ⟨729, 5, some .a1, f418, f419, 0⟩,
  ⟨730, 5, some .a4, f419, f677, 0⟩,
  ⟨731, 5, some .a4, f677, f678, 0⟩,
  ⟨732, 5, some .a4, f678, f679, 0⟩,
  ⟨733, 5, some .a1, f679, f680, 0⟩,
  ⟨734, 5, some .a1, f680, f681, 0⟩,
  ⟨735, 5, some .a1, f681, f682, 0⟩,
  ⟨736, 5, some .a1, f682, f683, 0⟩,
  ⟨737, 5, some .a1, f683, f684, 0⟩,
  ⟨738, 5, some .a1, f684, f685, 0⟩,
  ⟨739, 5, some .a3, f685, f686, 0⟩,
  ⟨740, 5, some .a3, f686, f687, 0⟩,
  ⟨741, 5, some .a3, f687, f688, 0⟩,
  ⟨742, 5, some .a3, f688, f689, 0⟩,
  ⟨743, 5, some .a3, f689, f690, 0⟩,
  ⟨744, 5, some .a3, f690, f691, 0⟩,
  ⟨745, 5, some .a2, f691, f692, 0⟩,
  ⟨746, 5, some .a2, f692, f693, 0⟩,
  ⟨747, 5, some .a2, f693, f694, 0⟩,
  ⟨748, 5, some .a2, f694, f695, 0⟩,
  ⟨749, 5, some .a2, f695, f696, 0⟩,
  ⟨750, 5, some .a2, f696, f697, 0⟩,
  ⟨751, 5, some .a4, f697, f698, 0⟩,
  ⟨752, 5, some .a4, f698, f699, 0⟩,
  ⟨753, 5, some .a4, f699, f700, 0⟩,
  ⟨754, 5, some .a3, f700, f701, 0⟩,
  ⟨755, 5, some .a3, f701, f702, 0⟩,
  ⟨756, 5, some .a4, f702, f703, 0⟩,
  ⟨757, 5, some .a4, f703, f704, 0⟩,
  ⟨758, 5, some .a4, f704, f705, 0⟩,
  ⟨759, 5, some .a4, f705, f706, 0⟩,
  ⟨760, 5, some .a4, f706, f707, 0⟩,
  ⟨761, 5, some .a1, f707, f708, 0⟩,
  ⟨762, 5, some .a1, f708, f709, 0⟩,
  ⟨763, 5, some .a1, f709, f710, 0⟩,
  ⟨764, 5, some .a1, f710, f711, 0⟩,
  ⟨765, 5, some .a1, f711, f712, 0⟩,
  ⟨766, 5, some .a1, f712, f713, 0⟩,
  ⟨767, 5, some .a1, f713, f714, 0⟩,
  ⟨768, 5, some .a2, f714, f715, 0⟩,
  ⟨769, 5, some .a3, f715, f716, 0⟩,
  ⟨770, 5, some .a3, f716, f717, 0⟩,
  ⟨771, 5, some .a1, f717, f718, 0⟩,
  ⟨772, 5, some .a4, f718, f719, 0⟩,
  ⟨773, 5, some .a2, f719, f720, 0⟩,
  ⟨774, 5, some .a4, f720, f721, 0⟩,
  ⟨775, 5, some .a2, f721, f722, 0⟩,
  ⟨776, 5, some .a2, f722, f723, 0⟩,
  ⟨777, 5, some .a2, f723, f724, 0⟩,
  ⟨778, 5, some .a2, f724, f725, 0⟩,
  ⟨779, 5, some .a2, f725, f726, 0⟩,
  ⟨780, 5, some .a2, f726, f727, 0⟩,
  ⟨781, 5, some .a3, f727, f728, 0⟩,
  ⟨782, 5, some .a3, f728, f729, 0⟩,
  ⟨783, 5, some .a4, f729, f730, 0⟩,
  ⟨784, 5, some .a4, f730, f731, 0⟩,
  ⟨785, 5, some .a1, f731, f732, 0⟩,
  ⟨786, 5, some .a1, f732, f733, 0⟩,
  ⟨787, 5, some .a1, f733, f734, 0⟩,
  ⟨788, 5, some .a3, f734, f735, 0⟩,
  ⟨789, 5, some .a3, f735, f736, 0⟩,
  ⟨790, 5, some .a4, f736, f737, 0⟩,
  ⟨791, 5, some .a4, f737, f738, 0⟩,
  ⟨792, 5, some .a1, f738, f739, 0⟩,
  ⟨793, 5, some .a1, f739, f740, 0⟩,
  ⟨794, 5, some .a4, f740, f741, 0⟩,
  ⟨795, 5, some .a4, f741, f742, 0⟩,
  ⟨796, 5, some .a1, f742, f743, 0⟩,
  ⟨797, 5, some .a1, f743, f744, 0⟩,
  ⟨798, 5, some .a4, f744, f745, 0⟩,
  ⟨799, 5, some .a2, f745, f746, 0⟩,
  ⟨800, 5, some .a2, f746, f747, 0⟩,
  ⟨801, 5, some .a1, f747, f748, 0⟩,
  ⟨802, 5, some .a2, f748, f749, 0⟩,
  ⟨803, 5, some .a1, f749, f750, 0⟩,
  ⟨804, 5, some .a2, f750, f751, 0⟩,
  ⟨805, 5, some .a1, f751, f752, 0⟩,
  ⟨806, 5, some .a2, f752, f753, 0⟩,
  ⟨807, 5, some .a1, f753, f754, 0⟩,
  ⟨808, 5, some .a2, f754, f755, 0⟩,
  ⟨809, 5, some .a1, f755, f756, 0⟩,
  ⟨810, 5, some .a1, f756, f757, 2⟩,
  ⟨811, 5, some .a1, f757, f758, 0⟩,
  ⟨812, 5, some .a1, f758, f759, 0⟩,
  ⟨813, 5, some .a3, f759, f760, 0⟩,
  ⟨814, 5, some .a3, f760, f761, 0⟩,
  ⟨815, 5, some .a3, f761, f762, 0⟩,
  ⟨816, 5, some .a1, f762, f763, 0⟩,
  ⟨817, 5, some .a1, f763, f764, 0⟩,
  ⟨818, 5, some .a1, f764, f765, 0⟩,
  ⟨819, 5, some .a4, f765, f766, 0⟩,
  ⟨820, 5, some .a4, f766, f767, 0⟩,
  ⟨821, 5, some .a4, f767, f768, 0⟩,
  ⟨822, 5, some .a4, f768, f769, 0⟩,
  ⟨823, 5, some .a4, f769, f770, 0⟩,
  ⟨824, 5, some .a4, f770, f771, 0⟩,
  ⟨825, 5, some .a1, f771, f772, 0⟩,
  ⟨826, 5, some .a1, f772, f773, 0⟩,
  ⟨827, 5, some .a1, f773, f774, 0⟩,
  ⟨828, 5, some .a1, f774, f775, 0⟩,
  ⟨829, 5, some .a2, f775, f776, 0⟩,
  ⟨830, 5, some .a1, f776, f777, 0⟩,
  ⟨831, 5, some .a2, f777, f778, 0⟩,
  ⟨832, 5, some .a2, f778, f779, 0⟩,
  ⟨833, 5, some .a2, f779, f780, 0⟩,
  ⟨834, 5, some .a2, f780, f781, 0⟩,
  ⟨835, 5, some .a2, f781, f782, 0⟩,
  ⟨836, 5, some .a2, f782, f783, 0⟩,
  ⟨837, 5, some .a2, f783, f784, 0⟩,
  ⟨838, 5, some .a3, f784, f785, 0⟩,
  ⟨839, 5, some .a3, f785, f786, 0⟩,
  ⟨840, 5, some .a3, f786, f787, 0⟩,
  ⟨841, 5, some .a4, f787, f788, 0⟩,
  ⟨842, 5, some .a4, f788, f789, 0⟩,
  ⟨843, 5, some .a4, f789, f790, 0⟩,
  ⟨844, 5, some .a1, f790, f791, 0⟩,
  ⟨845, 5, some .a1, f791, f792, 0⟩,
  ⟨846, 5, some .a1, f792, f793, 0⟩,
  ⟨847, 5, some .a1, f793, f794, 0⟩,
  ⟨848, 5, some .a1, f794, f795, 0⟩,
  ⟨849, 5, some .a4, f795, f796, 0⟩,
  ⟨850, 5, some .a4, f796, f797, 0⟩,
  ⟨851, 5, some .a1, f797, f798, 0⟩,
  ⟨852, 5, some .a1, f798, f799, 0⟩,
  ⟨853, 5, some .a4, f799, f800, 0⟩,
  ⟨854, 5, some .a2, f800, f801, 0⟩,
  ⟨855, 5, some .a2, f801, f802, 0⟩,
  ⟨856, 5, some .a1, f802, f803, 0⟩,
  ⟨857, 5, some .a1, f803, f804, 0⟩,
  ⟨858, 5, some .a3, f804, f805, 0⟩,
  ⟨859, 5, some .a1, f805, f806, 0⟩,
  ⟨860, 5, some .a2, f806, f807, 0⟩,
  ⟨861, 5, some .a2, f807, f808, 0⟩,
  ⟨862, 5, some .a2, f808, f809, 0⟩,
  ⟨863, 5, some .a2, f809, f810, 0⟩,
  ⟨864, 5, some .a2, f810, f811, 0⟩,
  ⟨865, 5, some .a3, f811, f812, 0⟩,
  ⟨866, 5, some .a3, f812, f813, 0⟩,
  ⟨867, 5, some .a3, f813, f814, 0⟩,
  ⟨868, 5, some .a3, f814, f815, 0⟩,
  ⟨869, 5, some .a3, f815, f816, 0⟩,
  ⟨870, 5, some .a3, f816, f817, 0⟩,
  ⟨871, 5, some .a1, f817, f818, 0⟩,
  ⟨872, 5, some .a1, f818, f819, 0⟩,
  ⟨873, 5, some .a2, f819, f820, 0⟩,
  ⟨874, 5, some .a4, f820, f821, 0⟩,
  ⟨875, 5, some .a4, f821, f822, 0⟩,
  ⟨876, 5, some .a4, f822, f823, 0⟩,
  ⟨877, 5, some .a3, f823, f824, 0⟩,
  ⟨878, 5, some .a3, f824, f825, 0⟩,
  ⟨879, 5, some .a3, f825, f826, 0⟩,
  ⟨880, 5, some .a1, f826, f827, 0⟩,
  ⟨881, 5, some .a1, f827, f828, 0⟩,
  ⟨882, 5, some .a1, f828, f829, 0⟩,
  ⟨883, 5, some .a1, f829, f830, 0⟩,
  ⟨884, 5, some .a1, f830, f831, 0⟩,
  ⟨885, 5, some .a1, f831, f832, 0⟩,
  ⟨886, 5, some .a4, f832, f833, 0⟩,
  ⟨887, 5, some .a4, f833, f834, 0⟩,
  ⟨888, 5, some .a4, f834, f835, 0⟩,
  ⟨889, 5, some .a3, f835, f836, 0⟩,
  ⟨890, 5, some .a3, f836, f837, 0⟩,
  ⟨891, 5, some .a4, f837, f838, 0⟩,
  ⟨892, 5, some .a4, f838, f839, 0⟩,
  ⟨893, 5, some .a3, f839, f840, 0⟩,
  ⟨894, 5, some .a3, f840, f841, 0⟩,
  ⟨895, 5, some .a3, f841, f842, 0⟩,
  ⟨896, 5, some .a2, f842, f843, 0⟩,
  ⟨897, 5, some .a2, f843, f844, 0⟩,
  ⟨898, 5, some .a2, f844, f845, 0⟩,
  ⟨899, 5, some .a4, f845, f846, 0⟩,
  ⟨900, 5, some .a4, f846, f847, 0⟩,
  ⟨901, 5, some .a1, f847, f848, 0⟩,
  ⟨902, 5, some .a2, f848, f849, 0⟩,
  ⟨903, 5, some .a3, f849, f850, 0⟩,
  ⟨904, 5, some .a3, f850, f851, 0⟩,
  ⟨905, 5, some .a1, f851, f852, 0⟩,
  ⟨906, 5, some .a1, f852, f853, 0⟩,
  ⟨907, 5, some .a1, f853, f854, 0⟩,
  ⟨908, 5, some .a1, f854, f855, 0⟩,
  ⟨909, 5, some .a4, f855, f856, 0⟩,
  ⟨910, 5, some .a4, f856, f857, 0⟩,
  ⟨911, 5, some .a4, f857, f858, 0⟩,
  ⟨912, 5, some .a4, f858, f859, 0⟩,
  ⟨913, 5, some .a2, f859, f860, 0⟩,
  ⟨914, 5, some .a4, f860, f861, 0⟩,
  ⟨915, 5, some .a4, f861, f862, 0⟩,
  ⟨916, 5, some .a2, f862, f863, 0⟩,
  ⟨917, 5, some .a4, f863, f864, 0⟩,
  ⟨918, 5, some .a4, f864, f865, 0⟩,
  ⟨919, 5, some .a1, f865, f866, 0⟩,
  ⟨920, 5, some .a1, f866, f867, 0⟩,
  ⟨921, 5, some .a4, f867, f868, 0⟩,
  ⟨922, 5, some .a2, f868, f869, 0⟩,
  ⟨923, 5, some .a2, f869, f870, 0⟩,
  ⟨924, 5, some .a2, f870, f871, 0⟩,
  ⟨925, 5, some .a2, f871, f872, 0⟩,
  ⟨926, 5, some .a2, f872, f873, 1⟩,
  ⟨927, 6, some .a3, f873, f874, 0⟩,
  ⟨928, 6, some .a2, f874, f875, 0⟩,
  ⟨929, 6, some .a2, f875, f876, 0⟩,
  ⟨930, 6, some .a4, f876, f877, 0⟩,
  ⟨931, 6, some .a2, f877, f878, 0⟩,
  ⟨932, 6, some .a2, f878, f879, 0⟩,
  ⟨933, 6, some .a4, f879, f880, 0⟩,
  ⟨934, 6, some .a4, f880, f881, 0⟩,
  ⟨935, 6, some .a4, f881, f882, 0⟩,
  ⟨936, 6, some .a4, f882, f883, 0⟩,
  ⟨937, 6, some .a1, f883, f884, 0⟩,
  ⟨938, 6, some .a1, f884, f885, 0⟩,
  ⟨939, 6, some .a4, f885, f886, 0⟩,
  ⟨940, 6, some .a4, f886, f887, 0⟩,
  ⟨941, 6, some .a2, f887, f888, 0⟩,
  ⟨942, 6, some .a4, f888, f889, 0⟩,
  ⟨943, 6, some .a2, f889, f890, 0⟩,
  ⟨944, 6, some .a2, f890, f891, 0⟩,
  ⟨945, 6, some .a3, f891, f892, 0⟩,
  ⟨946, 6, some .a4, f892, f893, 0⟩,
  ⟨947, 6, some .a4, f893, f894, 0⟩,
  ⟨948, 6, some .a2, f894, f895, 0⟩,
  ⟨949, 6, some .a2, f895, f896, 0⟩,
  ⟨950, 6, some .a2, f896, f897, 0⟩,
  ⟨951, 6, some .a1, f897, f898, 0⟩,
  ⟨952, 6, some .a1, f898, f899, 0⟩,
  ⟨953, 6, some .a2, f899, f900, 0⟩,
  ⟨954, 6, some .a2, f900, f901, 0⟩,
  ⟨955, 6, some .a2, f901, f902, 0⟩,
  ⟨956, 6, some .a1, f902, f903, 0⟩,
  ⟨957, 6, some .a1, f903, f904, 0⟩,
  ⟨958, 6, some .a1, f904, f905, 0⟩,
  ⟨959, 6, some .a4, f905, f906, 0⟩,
  ⟨960, 6, some .a4, f906, f907, 0⟩,
  ⟨961, 6, some .a1, f907, f908, 0⟩,
  ⟨962, 6, some .a2, f908, f909, 0⟩,
  ⟨963, 6, some .a3, f909, f910, 0⟩,
  ⟨964, 6, some .a2, f910, f911, 0⟩,
  ⟨965, 6, some .a2, f911, f912, 0⟩,
  ⟨966, 6, some .a2, f912, f913, 0⟩,
  ⟨967, 6, some .a3, f913, f914, 0⟩,
  ⟨968, 6, some .a3, f914, f915, 0⟩,
  ⟨969, 6, some .a3, f915, f916, 0⟩,
  ⟨970, 6, some .a3, f916, f917, 0⟩,
  ⟨971, 6, some .a3, f917, f918, 0⟩,
  ⟨972, 6, some .a2, f918, f919, 0⟩,
  ⟨973, 6, some .a2, f919, f920, 0⟩,
  ⟨974, 6, some .a2, f920, f921, 0⟩,
  ⟨975, 6, some .a1, f921, f922, 0⟩,
  ⟨976, 6, some .a1, f922, f923, 0⟩,
  ⟨977, 6, some .a1, f923, f924, 0⟩,
  ⟨978, 6, some .a1, f924, f925, 0⟩,
  ⟨979, 6, some .a1, f925, f926, 0⟩,
  ⟨980, 6, some .a1, f926, f927, 0⟩,
  ⟨981, 6, some .a1, f927, f928, 0⟩,
  ⟨982, 6, some .a4, f928, f929, 0⟩,
  ⟨983, 6, some .a4, f929, f930, 0⟩,
  ⟨984, 6, some .a4, f930, f931, 0⟩,
  ⟨985, 6, some .a4, f931, f932, 0⟩,
  ⟨986, 6, some .a2, f932, f933, 0⟩,
  ⟨987, 6, some .a4, f933, f934, 0⟩,
  ⟨988, 6, some .a2, f934, f935, 0⟩,
  ⟨989, 6, some .a2, f935, f936, 0⟩,
  ⟨990, 6, some .a4, f936, f937, 0⟩,
  ⟨991, 6, some .a1, f937, f938, 0⟩,
  ⟨992, 6, some .a4, f938, f939, 0⟩,
  ⟨993, 6, some .a4, f939, f940, 0⟩,
  ⟨994, 6, some .a4, f940, f941, 0⟩,
  ⟨995, 6, some .a1, f941, f942, 0⟩,
  ⟨996, 6, some .a1, f942, f943, 0⟩,
  ⟨997, 6, some .a1, f943, f944, 0⟩,
  ⟨998, 6, some .a1, f944, f945, 0⟩,
  ⟨999, 6, some .a1, f945, f946, 0⟩,
  ⟨1000, 6, some .a1, f946, f947, 0⟩,
  ⟨1001, 6, some .a3, f947, f948, 0⟩,
  ⟨1002, 6, some .a3, f948, f949, 0⟩,
  ⟨1003, 6, some .a3, f949, f950, 0⟩,
  ⟨1004, 6, some .a3, f950, f951, 0⟩,
  ⟨1005, 6, some .a3, f951, f952, 0⟩,
  ⟨1006, 6, some .a3, f952, f953, 0⟩,
  ⟨1007, 6, some .a3, f953, f954, 0⟩,
  ⟨1008, 6, some .a3, f954, f955, 0⟩,
  ⟨1009, 6, some .a3, f955, f956, 0⟩,
  ⟨1010, 6, some .a3, f956, f957, 0⟩,
  ⟨1011, 6, some .a3, f957, f958, 0⟩,
  ⟨1012, 6, some .a3, f958, f959, 0⟩,
  ⟨1013, 6, some .a3, f959, f960, 0⟩,
  ⟨1014, 6, some .a3, f960, f961, 0⟩,
  ⟨1015, 6, some .a3, f961, f962, 0⟩,
  ⟨1016, 6, some .a3, f962, f963, 0⟩,
  ⟨1017, 6, some .a3, f963, f964, 0⟩,
  ⟨1018, 6, some .a3, f964, f965, 0⟩,
  ⟨1019, 6, some .a3, f965, f966, 0⟩,
  ⟨1020, 6, some .a3, f966, f967, 0⟩,
  ⟨1021, 6, some .a3, f967, f968, 0⟩,
  ⟨1022, 6, some .a3, f968, f969, 0⟩,
  ⟨1023, 6, some .a3, f969, f970, 2⟩,
  ⟨1024, 6, some .a3, f970, f971, 0⟩,
  ⟨1025, 6, some .a3, f971, f972, 0⟩,
  ⟨1026, 6, some .a2, f972, f973, 0⟩,
  ⟨1027, 6, some .a2, f973, f974, 0⟩,
  ⟨1028, 6, some .a2, f974, f975, 0⟩,
  ⟨1029, 6, some .a2, f975, f976, 0⟩,
  ⟨1030, 6, some .a4, f976, f977, 0⟩,
  ⟨1031, 6, some .a2, f977, f978, 0⟩,
  ⟨1032, 6, some .a4, f978, f979, 0⟩,
  ⟨1033, 6, some .a3, f979, f980, 0⟩,
  ⟨1034, 6, some .a4, f980, f981, 0⟩,
  ⟨1035, 6, some .a3, f981, f982, 0⟩,
  ⟨1036, 6, some .a4, f982, f983, 0⟩,
  ⟨1037, 6, some .a3, f983, f984, 0⟩,
  ⟨1038, 6, some .a4, f984, f985, 0⟩,
  ⟨1039, 6, some .a3, f985, f986, 0⟩,
  ⟨1040, 6, some .a4, f986, f987, 0⟩,
  ⟨1041, 6, some .a3, f987, f988, 0⟩,
  ⟨1042, 6, some .a4, f988, f989, 0⟩,
  ⟨1043, 6, some .a3, f989, f990, 0⟩,
  ⟨1044, 6, some .a4, f990, f991, 0⟩,
  ⟨1045, 6, some .a3, f991, f992, 2⟩,
  ⟨1046, 6, some .a3, f992, f993, 0⟩,
  ⟨1047, 6, some .a3, f993, f994, 0⟩,
  ⟨1048, 6, some .a2, f994, f995, 0⟩,
  ⟨1049, 6, some .a2, f995, f996, 0⟩,
  ⟨1050, 6, some .a2, f996, f997, 0⟩,
  ⟨1051, 6, some .a2, f997, f998, 0⟩,
  ⟨1052, 6, some .a2, f998, f999, 0⟩,
  ⟨1053, 6, some .a1, f999, f1000, 0⟩,
  ⟨1054, 6, some .a2, f1000, f1001, 0⟩,
  ⟨1055, 6, some .a1, f1001, f1002, 0⟩,
  ⟨1056, 6, some .a2, f1002, f1003, 0⟩,
  ⟨1057, 6, some .a4, f1003, f1004, 0⟩,
  ⟨1058, 6, some .a2, f1004, f1005, 0⟩,
  ⟨1059, 6, some .a1, f1005, f1006, 0⟩,
  ⟨1060, 6, some .a4, f1006, f1007, 0⟩,
  ⟨1061, 6, some .a1, f1007, f1008, 0⟩,
  ⟨1062, 6, some .a2, f1008, f1009, 0⟩,
  ⟨1063, 6, some .a1, f1009, f1010, 0⟩,
  ⟨1064, 6, some .a2, f1010, f1011, 0⟩,
  ⟨1065, 6, some .a1, f1011, f1012, 0⟩,
  ⟨1066, 6, some .a2, f1012, f1013, 0⟩,
  ⟨1067, 6, some .a1, f1013, f1014, 0⟩,
  ⟨1068, 6, some .a2, f1014, f1015, 0⟩,
  ⟨1069, 6, some .a1, f1015, f1016, 0⟩,
  ⟨1070, 6, some .a3, f1016, f1017, 0⟩,
  ⟨1071, 6, some .a3, f1017, f1018, 0⟩,
  ⟨1072, 6, some .a1, f1018, f1019, 0⟩,
  ⟨1073, 6, some .a1, f1019, f1020, 0⟩,
  ⟨1074, 6, some .a4, f1020, f1021, 0⟩,
  ⟨1075, 6, some .a4, f1021, f1022, 0⟩,
  ⟨1076, 6, some .a4, f1022, f1023, 0⟩,
  ⟨1077, 6, some .a4, f1023, f1024, 0⟩,
  ⟨1078, 6, some .a1, f1024, f1025, 0⟩,
  ⟨1079, 6, some .a4, f1025, f1026, 0⟩,
  ⟨1080, 6, some .a4, f1026, f1027, 0⟩,
  ⟨1081, 6, some .a1, f1027, f1028, 0⟩,
  ⟨1082, 6, some .a4, f1028, f1029, 0⟩,
  ⟨1083, 6, some .a4, f1029, f1030, 0⟩,
  ⟨1084, 6, some .a1, f1030, f1031, 0⟩,
  ⟨1085, 6, some .a1, f1031, f1032, 0⟩,
  ⟨1086, 6, some .a1, f1032, f1033, 0⟩,
  ⟨1087, 6, some .a4, f1033, f1034, 0⟩,
  ⟨1088, 6, some .a2, f1034, f1035, 0⟩,
  ⟨1089, 6, some .a3, f1035, f1036, 0⟩,
  ⟨1090, 6, some .a2, f1036, f1037, 0⟩,
  ⟨1091, 6, some .a2, f1037, f1038, 0⟩,
  ⟨1092, 6, some .a3, f1038, f1039, 0⟩,
  ⟨1093, 6, some .a3, f1039, f1040, 0⟩,
  ⟨1094, 6, some .a1, f1040, f1041, 0⟩,
  ⟨1095, 6, some .a2, f1041, f1042, 0⟩,
  ⟨1096, 6, some .a2, f1042, f1043, 0⟩,
  ⟨1097, 6, some .a2, f1043, f1044, 0⟩,
  ⟨1098, 6, some .a2, f1044, f1045, 1⟩,
  ⟨1099, 7, none, f1045, f0, 3⟩,
  ⟨1100, 0, some .a3, f0, f428, 0⟩,
  ⟨1101, 0, some .a3, f428, f429, 0⟩,
  ⟨1102, 0, some .a3, f429, f430, 0⟩,
  ⟨1103, 0, some .a1, f430, f431, 0⟩,
  ⟨1104, 0, some .a1, f431, f432, 0⟩,
  ⟨1105, 0, some .a1, f432, f433, 0⟩,
  ⟨1106, 0, some .a1, f433, f434, 0⟩,
  ⟨1107, 0, some .a4, f434, f435, 0⟩,
  ⟨1108, 0, some .a4, f435, f436, 0⟩,
  ⟨1109, 0, some .a4, f436, f437, 0⟩,
  ⟨1110, 0, some .a1, f437, f438, 0⟩,
  ⟨1111, 0, some .a1, f438, f439, 0⟩,
  ⟨1112, 0, some .a1, f439, f23, 1⟩,
  ⟨1113, 1, some .a1, f23, f24, 0⟩,
  ⟨1114, 1, some .a4, f24, f25, 0⟩,
  ⟨1115, 1, some .a1, f25, f26, 0⟩,
  ⟨1116, 1, some .a1, f26, f27, 0⟩,
  ⟨1117, 1, some .a1, f27, f28, 0⟩,
  ⟨1118, 1, some .a1, f28, f29, 0⟩,
  ⟨1119, 1, some .a1, f29, f30, 0⟩,
  ⟨1120, 1, some .a4, f30, f31, 0⟩,
  ⟨1121, 1, some .a4, f31, f32, 0⟩,
  ⟨1122, 1, some .a2, f32, f33, 0⟩,
  ⟨1123, 1, some .a4, f33, f34, 0⟩,
  ⟨1124, 1, some .a2, f34, f35, 0⟩,
  ⟨1125, 1, some .a2, f35, f36, 0⟩,
  ⟨1126, 1, some .a2, f36, f37, 0⟩,
  ⟨1127, 1, some .a2, f37, f38, 0⟩,
  ⟨1128, 1, some .a2, f38, f39, 0⟩,
  ⟨1129, 1, some .a2, f39, f40, 0⟩,
  ⟨1130, 1, some .a2, f40, f440, 0⟩,
  ⟨1131, 1, some .a3, f440, f441, 0⟩,
  ⟨1132, 1, some .a3, f441, f442, 0⟩,
  ⟨1133, 1, some .a4, f442, f443, 0⟩,
  ⟨1134, 1, some .a1, f443, f444, 0⟩,
  ⟨1135, 1, some .a4, f444, f445, 0⟩,
  ⟨1136, 1, some .a1, f445, f446, 0⟩,
  ⟨1137, 1, some .a2, f446, f447, 0⟩,
  ⟨1138, 1, some .a1, f447, f448, 0⟩,
  ⟨1139, 1, some .a1, f448, f449, 0⟩,
  ⟨1140, 1, some .a1, f449, f450, 0⟩,
  ⟨1141, 1, some .a1, f450, f451, 0⟩,
  ⟨1142, 1, some .a1, f451, f452, 0⟩,
  ⟨1143, 1, some .a1, f452, f453, 0⟩,
  ⟨1144, 1, some .a1, f453, f454, 0⟩,
  ⟨1145, 1, some .a3, f454, f455, 0⟩,
  ⟨1146, 1, some .a3, f455, f456, 0⟩,
  ⟨1147, 1, some .a3, f456, f457, 0⟩,
  ⟨1148, 1, some .a3, f457, f458, 0⟩,
  ⟨1149, 1, some .a3, f458, f459, 0⟩,
  ⟨1150, 1, some .a3, f459, f460, 0⟩,
  ⟨1151, 1, some .a2, f460, f461, 0⟩,
  ⟨1152, 1, some .a3, f461, f462, 0⟩,
  ⟨1153, 1, some .a2, f462, f463, 0⟩,
  ⟨1154, 1, some .a2, f463, f464, 0⟩,
  ⟨1155, 1, some .a2, f464, f465, 0⟩,
  ⟨1156, 1, some .a2, f465, f466, 0⟩,
  ⟨1157, 1, some .a2, f466, f90, 1⟩,
  ⟨1158, 2, some .a1, f90, f91, 0⟩,
  ⟨1159, 2, some .a1, f91, f92, 0⟩,
  ⟨1160, 2, some .a1, f92, f93, 0⟩,
  ⟨1161, 2, some .a1, f93, f94, 0⟩,
  ⟨1162, 2, some .a1, f94, f95, 0⟩,
  ⟨1163, 2, some .a1, f95, f96, 0⟩,
  ⟨1164, 2, some .a1, f96, f97, 0⟩,
  ⟨1165, 2, some .a1, f97, f98, 0⟩,
  ⟨1166, 2, some .a3, f98, f99, 0⟩,
  ⟨1167, 2, some .a2, f99, f100, 0⟩,
  ⟨1168, 2, some .a2, f100, f101, 0⟩,
  ⟨1169, 2, some .a2, f101, f1046, 0⟩,
  ⟨1170, 2, some .a2, f1046, f1047, 0⟩,
  ⟨1171, 2, some .a2, f1047, f1048, 0⟩,
  ⟨1172, 2, some .a2, f1048, f1049, 0⟩,
  ⟨1173, 2, some .a2, f1049, f1050, 0⟩,
  ⟨1174, 2, some .a2, f1050, f1051, 0⟩,
  ⟨1175, 2, some .a1, f1051, f1052, 0⟩,
  ⟨1176, 2, some .a1, f1052, f1053, 0⟩,
  ⟨1177, 2, some .a1, f1053, f1054, 0⟩,
  ⟨1178, 2, some .a3, f1054, f1055, 0⟩,
  ⟨1179, 2, some .a3, f1055, f1056, 0⟩,
  ⟨1180, 2, some .a1, f1056, f1057, 0⟩,
  ⟨1181, 2, some .a4, f1057, f1058, 0⟩,
  ⟨1182, 2, some .a4, f1058, f1059, 0⟩,
  ⟨1183, 2, some .a4, f1059, f1060, 0⟩,
  ⟨1184, 2, some .a4, f1060, f1061, 0⟩,
  ⟨1185, 2, some .a4, f1061, f1062, 0⟩,
  ⟨1186, 2, some .a4, f1062, f1063, 0⟩,
  ⟨1187, 2, some .a4, f1063, f1064, 0⟩,
  ⟨1188, 2, some .a1, f1064, f1065, 0⟩,
  ⟨1189, 2, some .a1, f1065, f1066, 0⟩,
  ⟨1190, 2, some .a1, f1066, f1067, 0⟩,
  ⟨1191, 2, some .a3, f1067, f1068, 0⟩,
  ⟨1192, 2, some .a1, f1068, f1069, 0⟩,
  ⟨1193, 2, some .a2, f1069, f1070, 0⟩,
  ⟨1194, 2, some .a1, f1070, f1071, 0⟩,
  ⟨1195, 2, some .a4, f1071, f1072, 0⟩,
  ⟨1196, 2, some .a2, f1072, f185, 1⟩,
  ⟨1197, 3, some .a3, f185, f186, 0⟩,
  ⟨1198, 3, some .a3, f186, f187, 0⟩,
  ⟨1199, 3, some .a3, f187, f188, 0⟩,
  ⟨1200, 3, some .a2, f188, f189, 0⟩,
  ⟨1201, 3, some .a2, f189, f190, 0⟩,
  ⟨1202, 3, some .a2, f190, f191, 0⟩,
  ⟨1203, 3, some .a3, f191, f493, 0⟩,
  ⟨1204, 3, some .a2, f493, f494, 0⟩,
  ⟨1205, 3, some .a2, f494, f495, 0⟩,
  ⟨1206, 3, some .a3, f495, f496, 0⟩,
  ⟨1207, 3, some .a3, f496, f497, 0⟩,
  ⟨1208, 3, some .a1, f497, f498, 0⟩,
  ⟨1209, 3, some .a2, f498, f499, 0⟩,
  ⟨1210, 3, some .a1, f499, f500, 0⟩,
  ⟨1211, 3, some .a2, f500, f501, 0⟩,
  ⟨1212, 3, some .a1, f501, f502, 0⟩,
  ⟨1213, 3, some .a2, f502, f503, 0⟩,
  ⟨1214, 3, some .a1, f503, f504, 0⟩,
  ⟨1215, 3, some .a1, f504, f505, 0⟩,
  ⟨1216, 3, some .a3, f505, f506, 0⟩,
  ⟨1217, 3, some .a3, f506, f507, 0⟩,
  ⟨1218, 3, some .a1, f507, f508, 0⟩,
  ⟨1219, 3, some .a2, f508, f509, 0⟩,
  ⟨1220, 3, some .a3, f509, f510, 0⟩,
  ⟨1221, 3, some .a3, f510, f511, 0⟩,
  ⟨1222, 3, some .a1, f511, f512, 0⟩,
  ⟨1223, 3, some .a1, f512, f513, 0⟩,
  ⟨1224, 3, some .a1, f513, f514, 0⟩,
  ⟨1225, 3, some .a2, f514, f515, 0⟩,
  ⟨1226, 3, some .a2, f515, f516, 0⟩,
  ⟨1227, 3, some .a4, f516, f517, 0⟩,
  ⟨1228, 3, some .a1, f517, f518, 0⟩,
  ⟨1229, 3, some .a1, f518, f519, 0⟩,
  ⟨1230, 3, some .a1, f519, f520, 0⟩,
  ⟨1231, 3, some .a1, f520, f521, 0⟩,
  ⟨1232, 3, some .a4, f521, f522, 0⟩,
  ⟨1233, 3, some .a1, f522, f523, 0⟩,
  ⟨1234, 3, some .a4, f523, f524, 0⟩,
  ⟨1235, 3, some .a1, f524, f525, 0⟩,
  ⟨1236, 3, some .a1, f525, f526, 0⟩,
  ⟨1237, 3, some .a3, f526, f527, 0⟩,
  ⟨1238, 3, some .a3, f527, f528, 0⟩,
  ⟨1239, 3, some .a3, f528, f248, 1⟩,
  ⟨1240, 4, some .a1, f248, f249, 0⟩,
  ⟨1241, 4, some .a3, f249, f250, 0⟩,
  ⟨1242, 4, some .a1, f250, f251, 0⟩,
  ⟨1243, 4, some .a1, f251, f252, 0⟩,
  ⟨1244, 4, some .a3, f252, f529, 0⟩,
  ⟨1245, 4, some .a3, f529, f530, 0⟩,
  ⟨1246, 4, some .a3, f530, f531, 0⟩,
  ⟨1247, 4, some .a4, f531, f532, 0⟩,
  ⟨1248, 4, some .a3, f532, f533, 0⟩,
  ⟨1249, 4, some .a4, f533, f534, 0⟩,
  ⟨1250, 4, some .a3, f534, f535, 0⟩,
  ⟨1251, 4, some .a4, f535, f536, 0⟩,
  ⟨1252, 4, some .a1, f536, f1073, 0⟩,
  ⟨1253, 4, some .a1, f1073, f1074, 0⟩,
  ⟨1254, 4, some .a3, f1074, f1075, 0⟩,
  ⟨1255, 4, some .a3, f1075, f1076, 0⟩,
  ⟨1256, 4, some .a3, f1076, f1077, 0⟩,
  ⟨1257, 4, some .a3, f1077, f1078, 0⟩,
  ⟨1258, 4, some .a3, f1078, f1079, 0⟩,
  ⟨1259, 4, some .a4, f1079, f1080, 0⟩,
  ⟨1260, 4, some .a4, f1080, f1081, 0⟩,
  ⟨1261, 4, some .a2, f1081, f296, 2⟩,
  ⟨1262, 4, some .a2, f296, f1082, 0⟩,
  ⟨1263, 4, some .a2, f1082, f1083, 0⟩,
  ⟨1264, 4, some .a2, f1083, f1084, 0⟩,
  ⟨1265, 4, some .a2, f1084, f1085, 0⟩,
  ⟨1266, 4, some .a4, f1085, f1086, 0⟩,
  ⟨1267, 4, some .a4, f1086, f1087, 0⟩,
  ⟨1268, 4, some .a3, f1087, f1088, 0⟩,
  ⟨1269, 4, some .a2, f1088, f1089, 0⟩,
  ⟨1270, 4, some .a2, f1089, f1090, 0⟩,
  ⟨1271, 4, some .a4, f1090, f1091, 0⟩,
  ⟨1272, 4, some .a1, f1091, f1092, 0⟩,
  ⟨1273, 4, some .a1, f1092, f1093, 0⟩,
  ⟨1274, 4, some .a1, f1093, f1094, 0⟩,
  ⟨1275, 4, some .a3, f1094, f1095, 0⟩,
  ⟨1276, 4, some .a3, f1095, f1096, 0⟩,
  ⟨1277, 4, some .a3, f1096, f1097, 0⟩,
  ⟨1278, 4, some .a4, f1097, f1098, 0⟩,
  ⟨1279, 4, some .a3, f1098, f1099, 0⟩,
  ⟨1280, 4, some .a4, f1099, f1100, 0⟩,
  ⟨1281, 4, some .a4, f1100, f1101, 0⟩,
  ⟨1282, 4, some .a4, f1101, f1102, 0⟩,
  ⟨1283, 4, some .a3, f1102, f1103, 0⟩,
  ⟨1284, 4, some .a3, f1103, f1104, 0⟩,
  ⟨1285, 4, some .a3, f1104, f1105, 0⟩,
  ⟨1286, 4, some .a4, f1105, f1106, 0⟩,
  ⟨1287, 4, some .a1, f1106, f1107, 0⟩,
  ⟨1288, 4, some .a1, f1107, f1108, 0⟩,
  ⟨1289, 4, some .a3, f1108, f1109, 0⟩,
  ⟨1290, 4, some .a3, f1109, f1110, 0⟩,
  ⟨1291, 4, some .a3, f1110, f1111, 0⟩,
  ⟨1292, 4, some .a3, f1111, f1112, 0⟩,
  ⟨1293, 4, some .a1, f1112, f1113, 0⟩,
  ⟨1294, 4, some .a3, f1113, f1114, 0⟩,
  ⟨1295, 4, some .a3, f1114, f1115, 0⟩,
  ⟨1296, 4, some .a3, f1115, f1116, 0⟩,
  ⟨1297, 4, some .a4, f1116, f1117, 0⟩,
  ⟨1298, 4, some .a4, f1117, f1118, 0⟩,
  ⟨1299, 4, some .a2, f1118, f1119, 0⟩,
  ⟨1300, 4, some .a2, f1119, f1120, 0⟩,
  ⟨1301, 4, some .a2, f1120, f1121, 0⟩,
  ⟨1302, 4, some .a2, f1121, f1122, 0⟩,
  ⟨1303, 4, some .a2, f1122, f1123, 0⟩,
  ⟨1304, 4, some .a4, f1123, f1124, 0⟩,
  ⟨1305, 4, some .a4, f1124, f1125, 0⟩,
  ⟨1306, 4, some .a2, f1125, f1126, 0⟩,
  ⟨1307, 4, some .a2, f1126, f1127, 0⟩,
  ⟨1308, 4, some .a2, f1127, f1128, 0⟩,
  ⟨1309, 4, some .a4, f1128, f1129, 0⟩,
  ⟨1310, 4, some .a4, f1129, f1130, 0⟩,
  ⟨1311, 4, some .a4, f1130, f1131, 0⟩,
  ⟨1312, 4, some .a4, f1131, f1132, 0⟩,
  ⟨1313, 4, some .a4, f1132, f1133, 0⟩,
  ⟨1314, 4, some .a4, f1133, f1134, 0⟩,
  ⟨1315, 4, some .a4, f1134, f1135, 0⟩,
  ⟨1316, 4, some .a1, f1135, f340, 1⟩,
  ⟨1317, 5, some .a1, f340, f341, 0⟩,
  ⟨1318, 5, some .a3, f341, f1136, 0⟩,
  ⟨1319, 5, some .a3, f1136, f1137, 0⟩,
  ⟨1320, 5, some .a3, f1137, f1138, 0⟩,
  ⟨1321, 5, some .a1, f1138, f1139, 0⟩,
  ⟨1322, 5, some .a1, f1139, f1140, 0⟩,
  ⟨1323, 5, some .a1, f1140, f1141, 0⟩,
  ⟨1324, 5, some .a1, f1141, f1142, 0⟩,
  ⟨1325, 5, some .a4, f1142, f1143, 0⟩,
  ⟨1326, 5, some .a4, f1143, f1144, 0⟩,
  ⟨1327, 5, some .a3, f1144, f1145, 0⟩,
  ⟨1328, 5, some .a3, f1145, f1146, 0⟩,
  ⟨1329, 5, some .a2, f1146, f1147, 0⟩,
  ⟨1330, 5, some .a2, f1147, f1148, 0⟩,
  ⟨1331, 5, some .a2, f1148, f1149, 0⟩,
  ⟨1332, 5, some .a4, f1149, f1150, 0⟩,
  ⟨1333, 5, some .a4, f1150, f1151, 0⟩,
  ⟨1334, 5, some .a4, f1151, f1152, 0⟩,
  ⟨1335, 5, some .a3, f1152, f1153, 0⟩,
  ⟨1336, 5, some .a4, f1153, f1154, 0⟩,
  ⟨1337, 5, some .a4, f1154, f1155, 0⟩,
  ⟨1338, 5, some .a4, f1155, f1156, 0⟩,
  ⟨1339, 5, some .a4, f1156, f1157, 0⟩,
  ⟨1340, 5, some .a1, f1157, f1158, 0⟩,
  ⟨1341, 5, some .a1, f1158, f1159, 0⟩,
  ⟨1342, 5, some .a1, f1159, f1160, 0⟩,
  ⟨1343, 5, some .a1, f1160, f1161, 0⟩,
  ⟨1344, 5, some .a1, f1161, f1162, 0⟩,
  ⟨1345, 5, some .a4, f1162, f1163, 0⟩,
  ⟨1346, 5, some .a4, f1163, f1164, 0⟩,
  ⟨1347, 5, some .a1, f1164, f1165, 0⟩,
  ⟨1348, 5, some .a1, f1165, f1166, 0⟩,
  ⟨1349, 5, some .a4, f1166, f1167, 0⟩,
  ⟨1350, 5, some .a2, f1167, f1168, 0⟩,
  ⟨1351, 5, some .a2, f1168, f1169, 0⟩,
  ⟨1352, 5, some .a1, f1169, f1170, 0⟩,
  ⟨1353, 5, some .a1, f1170, f1171, 0⟩,
  ⟨1354, 5, some .a3, f1171, f1172, 0⟩,
  ⟨1355, 5, some .a1, f1172, f1173, 0⟩,
  ⟨1356, 5, some .a1, f1173, f1174, 0⟩,
  ⟨1357, 5, some .a1, f1174, f1175, 0⟩,
  ⟨1358, 5, some .a1, f1175, f1176, 0⟩,
  ⟨1359, 5, some .a2, f1176, f1177, 0⟩,
  ⟨1360, 5, some .a2, f1177, f1178, 0⟩,
  ⟨1361, 5, some .a2, f1178, f1179, 0⟩,
  ⟨1362, 5, some .a2, f1179, f1180, 0⟩,
  ⟨1363, 5, some .a3, f1180, f1181, 0⟩,
  ⟨1364, 5, some .a3, f1181, f1182, 0⟩,
  ⟨1365, 5, some .a3, f1182, f1183, 0⟩,
  ⟨1366, 5, some .a3, f1183, f1184, 0⟩,
  ⟨1367, 5, some .a1, f1184, f1185, 0⟩,
  ⟨1368, 5, some .a2, f1185, f1186, 0⟩,
  ⟨1369, 5, some .a3, f1186, f1187, 0⟩,
  ⟨1370, 5, some .a3, f1187, f1188, 0⟩,
  ⟨1371, 5, some .a2, f1188, f1189, 0⟩,
  ⟨1372, 5, some .a2, f1189, f1190, 0⟩,
  ⟨1373, 5, some .a2, f1190, f1191, 0⟩,
  ⟨1374, 5, some .a4, f1191, f1192, 0⟩,
  ⟨1375, 5, some .a4, f1192, f1193, 0⟩,
  ⟨1376, 5, some .a3, f1193, f1194, 0⟩,
  ⟨1377, 5, some .a4, f1194, f1195, 0⟩,
  ⟨1378, 5, some .a3, f1195, f1196, 0⟩,
  ⟨1379, 5, some .a3, f1196, f1197, 0⟩,
  ⟨1380, 5, some .a1, f1197, f1198, 0⟩,
  ⟨1381, 5, some .a1, f1198, f1199, 0⟩,
  ⟨1382, 5, some .a1, f1199, f1200, 0⟩,
  ⟨1383, 5, some .a1, f1200, f1201, 0⟩,
  ⟨1384, 5, some .a1, f1201, f1202, 0⟩,
  ⟨1385, 5, some .a1, f1202, f1203, 0⟩,
  ⟨1386, 5, some .a4, f1203, f1204, 0⟩,
  ⟨1387, 5, some .a4, f1204, f1205, 0⟩,
  ⟨1388, 5, some .a3, f1205, f1206, 0⟩,
  ⟨1389, 5, some .a4, f1206, f1207, 0⟩,
  ⟨1390, 5, some .a4, f1207, f1208, 0⟩,
  ⟨1391, 5, some .a4, f1208, f1209, 0⟩,
  ⟨1392, 5, some .a1, f1209, f1210, 0⟩,
  ⟨1393, 5, some .a3, f1210, f1211, 0⟩,
  ⟨1394, 5, some .a3, f1211, f1212, 0⟩,
  ⟨1395, 5, some .a3, f1212, f1213, 0⟩,
  ⟨1396, 5, some .a3, f1213, f1214, 0⟩,
  ⟨1397, 5, some .a4, f1214, f1215, 0⟩,
  ⟨1398, 5, some .a4, f1215, f1216, 0⟩,
  ⟨1399, 5, some .a4, f1216, f1217, 0⟩,
  ⟨1400, 5, some .a4, f1217, f1218, 0⟩,
  ⟨1401, 5, some .a4, f1218, f1219, 0⟩,
  ⟨1402, 5, some .a2, f1219, f1220, 0⟩,
  ⟨1403, 5, some .a4, f1220, f1221, 0⟩,
  ⟨1404, 5, some .a2, f1221, f1222, 0⟩,
  ⟨1405, 5, some .a4, f1222, f1223, 0⟩,
  ⟨1406, 5, some .a4, f1223, f1224, 0⟩,
  ⟨1407, 5, some .a1, f1224, f1225, 0⟩,
  ⟨1408, 5, some .a1, f1225, f1226, 0⟩,
  ⟨1409, 5, some .a4, f1226, f1227, 0⟩,
  ⟨1410, 5, some .a2, f1227, f1228, 0⟩,
  ⟨1411, 5, some .a2, f1228, f1229, 0⟩,
  ⟨1412, 5, some .a2, f1229, f1230, 0⟩,
  ⟨1413, 5, some .a2, f1230, f1231, 0⟩,
  ⟨1414, 5, some .a2, f1231, f873, 1⟩,
  ⟨1415, 6, some .a3, f873, f874, 0⟩,
  ⟨1416, 6, some .a3, f874, f1232, 0⟩,
  ⟨1417, 6, some .a2, f1232, f1233, 0⟩,
  ⟨1418, 6, some .a2, f1233, f1234, 0⟩,
  ⟨1419, 6, some .a2, f1234, f1235, 0⟩,
  ⟨1420, 6, some .a2, f1235, f1236, 0⟩,
  ⟨1421, 6, some .a2, f1236, f1237, 0⟩,
  ⟨1422, 6, some .a1, f1237, f1238, 0⟩,
  ⟨1423, 6, some .a2, f1238, f1239, 0⟩,
  ⟨1424, 6, some .a1, f1239, f1240, 0⟩,
  ⟨1425, 6, some .a2, f1240, f1241, 0⟩,
  ⟨1426, 6, some .a4, f1241, f1242, 0⟩,
  ⟨1427, 6, some .a4, f1242, f1243, 0⟩,
  ⟨1428, 6, some .a1, f1243, f1244, 0⟩,
  ⟨1429, 6, some .a2, f1244, f1245, 0⟩,
  ⟨1430, 6, some .a1, f1245, f1246, 0⟩,
  ⟨1431, 6, some .a2, f1246, f1247, 0⟩,
  ⟨1432, 6, some .a1, f1247, f1248, 0⟩,
  ⟨1433, 6, some .a2, f1248, f1249, 0⟩,
  ⟨1434, 6, some .a3, f1249, f1250, 0⟩,
  ⟨1435, 6, some .a2, f1250, f1251, 0⟩,
  ⟨1436, 6, some .a1, f1251, f1252, 0⟩,
  ⟨1437, 6, some .a4, f1252, f1253, 0⟩,
  ⟨1438, 6, some .a1, f1253, f1254, 0⟩,
  ⟨1439, 6, some .a3, f1254, f1255, 0⟩,
  ⟨1440, 6, some .a3, f1255, f1256, 0⟩,
  ⟨1441, 6, some .a1, f1256, f1257, 0⟩,
  ⟨1442, 6, some .a1, f1257, f1258, 0⟩,
  ⟨1443, 6, some .a4, f1258, f1259, 0⟩,
  ⟨1444, 6, some .a4, f1259, f1260, 0⟩,
  ⟨1445, 6, some .a4, f1260, f1261, 0⟩,
  ⟨1446, 6, some .a4, f1261, f1262, 0⟩,
  ⟨1447, 6, some .a1, f1262, f1263, 0⟩,
  ⟨1448, 6, some .a4, f1263, f1264, 0⟩,
  ⟨1449, 6, some .a4, f1264, f1265, 0⟩,
  ⟨1450, 6, some .a1, f1265, f1266, 0⟩,
  ⟨1451, 6, some .a4, f1266, f1267, 0⟩,
  ⟨1452, 6, some .a4, f1267, f1268, 0⟩,
  ⟨1453, 6, some .a1, f1268, f1269, 0⟩,
  ⟨1454, 6, some .a1, f1269, f1270, 0⟩,
  ⟨1455, 6, some .a1, f1270, f1271, 0⟩,
  ⟨1456, 6, some .a4, f1271, f1272, 0⟩,
  ⟨1457, 6, some .a2, f1272, f1273, 0⟩,
  ⟨1458, 6, some .a3, f1273, f1274, 0⟩,
  ⟨1459, 6, some .a2, f1274, f1275, 0⟩,
  ⟨1460, 6, some .a2, f1275, f1276, 0⟩,
  ⟨1461, 6, some .a3, f1276, f1277, 0⟩,
  ⟨1462, 6, some .a3, f1277, f1278, 0⟩,
  ⟨1463, 6, some .a1, f1278, f1279, 0⟩,
  ⟨1464, 6, some .a2, f1279, f1280, 0⟩,
  ⟨1465, 6, some .a2, f1280, f1281, 0⟩,
  ⟨1466, 6, some .a2, f1281, f1282, 0⟩,
  ⟨1467, 6, some .a2, f1282, f1283, 1⟩]

/-- 每关整关取并集的版面。 -/
def board : Nat → Board
  | 0 => { floor := [⟨2, 6⟩, ⟨3, 6⟩, ⟨4, 6⟩, ⟨5, 2⟩, ⟨5, 3⟩, ⟨5, 4⟩, ⟨5, 5⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 8⟩, ⟨5, 9⟩, ⟨6, 2⟩, ⟨6, 3⟩, ⟨6, 4⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨6, 8⟩, ⟨6, 9⟩, ⟨7, 2⟩, ⟨7, 3⟩, ⟨7, 4⟩, ⟨7, 6⟩, ⟨7, 7⟩, ⟨7, 8⟩, ⟨7, 9⟩, ⟨8, 3⟩, ⟨8, 6⟩, ⟨8, 7⟩, ⟨8, 8⟩, ⟨8, 9⟩, ⟨9, 3⟩, ⟨9, 4⟩, ⟨9, 5⟩, ⟨9, 6⟩, ⟨9, 7⟩, ⟨9, 8⟩, ⟨9, 9⟩], lines := [], cost := 1, pressFree := true, patrols := [], orbit := [], fog := false }
  | 1 => { floor := [⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 5⟩, ⟨1, 6⟩, ⟨1, 7⟩, ⟨1, 8⟩, ⟨1, 9⟩, ⟨2, 1⟩, ⟨2, 2⟩, ⟨2, 3⟩, ⟨2, 4⟩, ⟨2, 5⟩, ⟨2, 6⟩, ⟨2, 7⟩, ⟨2, 8⟩, ⟨2, 9⟩, ⟨3, 1⟩, ⟨3, 2⟩, ⟨3, 3⟩, ⟨3, 5⟩, ⟨3, 6⟩, ⟨3, 8⟩, ⟨3, 9⟩, ⟨4, 1⟩, ⟨4, 2⟩, ⟨4, 3⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨4, 9⟩, ⟨4, 10⟩, ⟨5, 2⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 9⟩, ⟨5, 10⟩, ⟨6, 2⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨6, 9⟩, ⟨7, 2⟩, ⟨7, 5⟩, ⟨7, 6⟩, ⟨7, 9⟩, ⟨8, 2⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨8, 8⟩, ⟨8, 9⟩, ⟨8, 10⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 7⟩, ⟨10, 8⟩, ⟨10, 9⟩, ⟨10, 10⟩], lines := [], cost := 2, pressFree := false, patrols := [], orbit := [], fog := false }
  | 2 => { floor := [⟨1, 1⟩, ⟨1, 2⟩, ⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 5⟩, ⟨1, 6⟩, ⟨1, 8⟩, ⟨1, 9⟩, ⟨1, 10⟩, ⟨2, 1⟩, ⟨2, 5⟩, ⟨2, 8⟩, ⟨2, 9⟩, ⟨2, 10⟩, ⟨3, 1⟩, ⟨3, 3⟩, ⟨3, 4⟩, ⟨3, 5⟩, ⟨3, 6⟩, ⟨3, 8⟩, ⟨3, 9⟩, ⟨3, 10⟩, ⟨4, 1⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨4, 10⟩, ⟨5, 1⟩, ⟨5, 3⟩, ⟨5, 4⟩, ⟨5, 5⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 8⟩, ⟨5, 9⟩, ⟨5, 10⟩, ⟨6, 1⟩, ⟨6, 3⟩, ⟨6, 4⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨6, 8⟩, ⟨6, 9⟩, ⟨6, 10⟩, ⟨7, 1⟩, ⟨7, 5⟩, ⟨7, 10⟩, ⟨8, 1⟩, ⟨8, 2⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨8, 10⟩, ⟨9, 1⟩, ⟨9, 2⟩, ⟨9, 4⟩, ⟨9, 5⟩, ⟨9, 6⟩, ⟨9, 10⟩, ⟨10, 4⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 10⟩], lines := [⟨⟨1, 1⟩, .right⟩, ⟨⟨1, 10⟩, .down⟩], cost := 2, pressFree := false, patrols := [], orbit := [], fog := false }
  | 3 => { floor := [⟨1, 1⟩, ⟨1, 2⟩, ⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 7⟩, ⟨1, 8⟩, ⟨1, 9⟩, ⟨1, 10⟩, ⟨2, 4⟩, ⟨2, 6⟩, ⟨2, 7⟩, ⟨3, 3⟩, ⟨3, 4⟩, ⟨3, 5⟩, ⟨3, 6⟩, ⟨3, 7⟩, ⟨3, 9⟩, ⟨3, 10⟩, ⟨4, 2⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 6⟩, ⟨4, 7⟩, ⟨4, 8⟩, ⟨4, 9⟩, ⟨4, 10⟩, ⟨5, 1⟩, ⟨5, 2⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 8⟩, ⟨5, 10⟩, ⟨6, 1⟩, ⟨6, 2⟩, ⟨6, 4⟩, ⟨6, 6⟩, ⟨6, 8⟩, ⟨6, 9⟩, ⟨6, 10⟩, ⟨7, 1⟩, ⟨7, 2⟩, ⟨7, 3⟩, ⟨7, 4⟩, ⟨7, 8⟩, ⟨7, 9⟩, ⟨7, 10⟩, ⟨8, 1⟩, ⟨8, 2⟩, ⟨8, 3⟩, ⟨8, 4⟩, ⟨8, 6⟩, ⟨8, 7⟩, ⟨8, 8⟩, ⟨8, 10⟩, ⟨9, 2⟩, ⟨9, 3⟩, ⟨9, 4⟩, ⟨9, 5⟩, ⟨9, 6⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 4⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 9⟩, ⟨10, 10⟩], lines := [⟨⟨4, 6⟩, .right⟩, ⟨⟨4, 8⟩, .down⟩, ⟨⟨5, 7⟩, .up⟩, ⟨⟨5, 8⟩, .left⟩, ⟨⟨7, 1⟩, .right⟩, ⟨⟨7, 3⟩, .down⟩, ⟨⟨8, 4⟩, .left⟩, ⟨⟨8, 8⟩, .left⟩], cost := 1, pressFree := false, patrols := [], orbit := [], fog := false }
  | 4 => { floor := [⟨1, 2⟩, ⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 6⟩, ⟨1, 7⟩, ⟨1, 8⟩, ⟨1, 10⟩, ⟨2, 1⟩, ⟨2, 2⟩, ⟨2, 3⟩, ⟨2, 4⟩, ⟨2, 6⟩, ⟨2, 7⟩, ⟨2, 10⟩, ⟨3, 2⟩, ⟨3, 3⟩, ⟨3, 4⟩, ⟨3, 5⟩, ⟨3, 6⟩, ⟨3, 7⟩, ⟨3, 8⟩, ⟨3, 10⟩, ⟨4, 3⟩, ⟨4, 6⟩, ⟨4, 7⟩, ⟨4, 8⟩, ⟨4, 10⟩, ⟨5, 1⟩, ⟨5, 2⟩, ⟨5, 3⟩, ⟨5, 5⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 8⟩, ⟨5, 10⟩, ⟨6, 1⟩, ⟨6, 8⟩, ⟨6, 9⟩, ⟨6, 10⟩, ⟨7, 1⟩, ⟨7, 2⟩, ⟨7, 3⟩, ⟨7, 4⟩, ⟨7, 6⟩, ⟨7, 7⟩, ⟨7, 8⟩, ⟨7, 9⟩, ⟨7, 10⟩, ⟨8, 1⟩, ⟨8, 2⟩, ⟨8, 3⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨8, 8⟩, ⟨8, 9⟩, ⟨8, 10⟩, ⟨9, 2⟩, ⟨9, 3⟩, ⟨9, 4⟩, ⟨9, 10⟩, ⟨10, 3⟩, ⟨10, 4⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨10, 8⟩, ⟨10, 9⟩, ⟨10, 10⟩], lines := [⟨⟨1, 6⟩, .down⟩, ⟨⟨4, 6⟩, .right⟩, ⟨⟨5, 3⟩, .left⟩, ⟨⟨5, 7⟩, .up⟩, ⟨⟨6, 9⟩, .down⟩, ⟨⟨6, 10⟩, .left⟩, ⟨⟨8, 8⟩, .right⟩, ⟨⟨10, 10⟩, .up⟩], cost := 2, pressFree := false, patrols := [⟨0, true, 7, 2, 4⟩], orbit := [], fog := false }
  | 5 => { floor := [⟨1, 1⟩, ⟨1, 2⟩, ⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 5⟩, ⟨1, 6⟩, ⟨1, 7⟩, ⟨1, 9⟩, ⟨1, 10⟩, ⟨2, 1⟩, ⟨2, 2⟩, ⟨2, 3⟩, ⟨2, 4⟩, ⟨2, 5⟩, ⟨2, 6⟩, ⟨2, 7⟩, ⟨2, 9⟩, ⟨2, 10⟩, ⟨3, 1⟩, ⟨3, 7⟩, ⟨3, 8⟩, ⟨3, 9⟩, ⟨4, 1⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 7⟩, ⟨4, 8⟩, ⟨4, 9⟩, ⟨5, 1⟩, ⟨5, 2⟩, ⟨5, 3⟩, ⟨5, 4⟩, ⟨5, 5⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 9⟩, ⟨5, 10⟩, ⟨6, 1⟩, ⟨6, 3⟩, ⟨6, 4⟩, ⟨6, 5⟩, ⟨6, 7⟩, ⟨6, 10⟩, ⟨7, 1⟩, ⟨7, 7⟩, ⟨7, 10⟩, ⟨8, 1⟩, ⟨8, 2⟩, ⟨8, 3⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨8, 7⟩, ⟨8, 10⟩, ⟨9, 1⟩, ⟨9, 2⟩, ⟨9, 3⟩, ⟨9, 4⟩, ⟨9, 5⟩, ⟨9, 6⟩, ⟨9, 7⟩, ⟨9, 10⟩, ⟨10, 2⟩, ⟨10, 3⟩, ⟨10, 4⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 10⟩], lines := [⟨⟨1, 9⟩, .down⟩, ⟨⟨4, 9⟩, .left⟩], cost := 1, pressFree := false, patrols := [⟨0, true, 8, 2, 6⟩, ⟨1, true, 2, 2, 6⟩], orbit := [⟨6, 4⟩, ⟨6, 3⟩, ⟨5, 3⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 5⟩, ⟨6, 5⟩], fog := false }
  | 6 => { floor := [⟨1, 1⟩, ⟨1, 2⟩, ⟨1, 3⟩, ⟨1, 4⟩, ⟨1, 5⟩, ⟨1, 7⟩, ⟨1, 9⟩, ⟨1, 10⟩, ⟨2, 1⟩, ⟨2, 2⟩, ⟨2, 3⟩, ⟨2, 5⟩, ⟨2, 6⟩, ⟨2, 7⟩, ⟨2, 9⟩, ⟨2, 10⟩, ⟨3, 1⟩, ⟨3, 2⟩, ⟨3, 3⟩, ⟨3, 6⟩, ⟨3, 9⟩, ⟨3, 10⟩, ⟨4, 1⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨4, 7⟩, ⟨4, 9⟩, ⟨4, 10⟩, ⟨5, 1⟩, ⟨5, 2⟩, ⟨5, 3⟩, ⟨5, 4⟩, ⟨5, 5⟩, ⟨5, 6⟩, ⟨5, 7⟩, ⟨5, 9⟩, ⟨5, 10⟩, ⟨6, 1⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨6, 9⟩, ⟨6, 10⟩, ⟨7, 1⟩, ⟨7, 2⟩, ⟨7, 3⟩, ⟨7, 5⟩, ⟨7, 7⟩, ⟨7, 8⟩, ⟨7, 9⟩, ⟨7, 10⟩, ⟨8, 1⟩, ⟨8, 2⟩, ⟨8, 3⟩, ⟨8, 5⟩, ⟨8, 7⟩, ⟨8, 8⟩, ⟨8, 9⟩, ⟨8, 10⟩, ⟨9, 2⟩, ⟨9, 5⟩, ⟨9, 9⟩, ⟨10, 5⟩, ⟨10, 8⟩, ⟨10, 9⟩, ⟨10, 10⟩], lines := [⟨⟨4, 7⟩, .down⟩, ⟨⟨6, 6⟩, .up⟩, ⟨⟨6, 7⟩, .left⟩], cost := 2, pressFree := false, patrols := [⟨0, false, 10, 1, 6⟩], orbit := [], fog := true }
  | _ => { floor := [], lines := [], cost := 0, pressFree := false, patrols := [], orbit := [], fog := false }

/-- 每关整关取并集的静止装置、补给、门（开局用）。 -/
structure Statics where
  goals : List Goal
  rotators : List Cell
  shapers : List Cell
  painters : List Cell
  refills : List Cell

def statics : Nat → Statics
  | 0 => ⟨[⟨⟨2, 6⟩, ⟨359, 9⟩⟩], [⟨6, 3⟩], [], [], []⟩
  | 1 => ⟨[⟨⟨8, 2⟩, ⟨335, 9⟩⟩], [⟨9, 9⟩], [], [], [⟨3, 2⟩, ⟨10, 7⟩]⟩
  | 2 => ⟨[⟨⟨10, 10⟩, ⟨461, 9⟩⟩], [⟨2, 9⟩], [], [⟨9, 5⟩], [⟨3, 6⟩, ⟨6, 3⟩]⟩
  | 3 => ⟨[⟨⟨1, 1⟩, ⟨359, 9⟩⟩], [], [⟨6, 4⟩], [⟨6, 6⟩], [⟨3, 3⟩, ⟨10, 6⟩]⟩
  | 4 => ⟨[⟨⟨1, 10⟩, ⟨413, 8⟩⟩], [], [⟨2, 3⟩], [⟨5, 5⟩], [⟨1, 8⟩, ⟨2, 1⟩, ⟨9, 2⟩]⟩
  | 5 => ⟨[⟨⟨7, 10⟩, ⟨413, 8⟩⟩, ⟨⟨10, 10⟩, ⟨485, 9⟩⟩], [], [], [], [⟨1, 1⟩, ⟨1, 7⟩, ⟨9, 1⟩]⟩
  | 6 => ⟨[⟨⟨10, 5⟩, ⟨413, 8⟩⟩], [], [⟨8, 3⟩], [⟨8, 1⟩], [⟨1, 1⟩, ⟨1, 7⟩, ⟨1, 9⟩, ⟨4, 5⟩, ⟨9, 2⟩, ⟨10, 10⟩]⟩
  | _ => ⟨[], [], [], [], []⟩

/-- 按 `seq` 取一条（越界给第一条——越界本身是 bug，`_len` 定理会让它露馅）。 -/
def rowAt (want : Nat) : Option Row := rows.find? (fun r => r.seq == want)

/-- 从 `seq = want` 那一条起连着取 `len` 条，只留（动作, 下一帧）。RESET 那种没有动作的一律丢掉。 -/
def playFrom (want len : Nat) : List (Act × Seen) :=
  ((rows.dropWhile (fun r => r.seq != want)).take len).filterMap
    (fun r => r.act.map (fun a => (a, r.next)))

/-- 一条转移作为逐条那一把的用例（RESET 不是用例：返回 `none`）。 -/
def caseOf (r : Row) : Option Case :=
  r.act.map (fun a => { seq := r.seq, lvl := r.lvl, prev := r.prev, act := a, next := r.next, kind := r.kind })

#eval "REPLAY rows=" ++ toString rows.length

end Replay
end Game
