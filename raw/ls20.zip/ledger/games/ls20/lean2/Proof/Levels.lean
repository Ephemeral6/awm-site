/-
# Levels —— 每一关一条定理（**自动生成，不要手改**；生成器 `export_levels.py`）

    L<n>_trace       这一段有几步（钉死，防空表）∧ 沿真人走过的那条路，模型每一帧都和观测对上
    L<n>_tail_trace  （中途掉过命的关）掉命之后那一段，同上，起点是「重来之后的开局」
    L<n>_winnable    这一关走得通 —— 见证就是真人那条路（或它掉命之后那一段）

**只有开局那一帧是观测给的，后面全是模型自己算的。** 观测一律从 `Obs/Replay.lean` 按 `seq` 切。

## 开局用的口径

    玩家、钥匙、能量、命      这一关第一帧（`Replay.f<k>`）
    版面、静止装置、补给、门   **整关取并集**（`Replay.board` / `Replay.statics`）
                             ——比玩家在第一帧看到的多知道几格（有雾的那一关尤其如此），这个代价写在明处
    会动的装置的方向          见各关的说明（端点上是定的；不在端点、或开局看不见 ⇒ 模型自己挑，候选数写在那一关）

## 一条明写的假设（不进模型）

**掉命之后，这一关从开局重来，命少一条**（`restart`，`rule/unmodeled/restart_to_start.py`）。
它不进 `step`（开局是历史）。有它，掉过命的那一关的尾段起点就是 `restart L<n>_start`；
尾段的逐帧核对**第一帧就会因为它错而红**——没红**不构成证明**，
但那是这条假设在这批语料上唯一一次有机会被驳倒。

## 一句削弱，写在明处

`everWon` 碰到掉命返回 `false`，所以 `_winnable` 的见证是一条**不经过掉命**的路；
这一局七关都有这样的路，没有一关需要靠掉命才过得去。
-/

import Obj.World
import Proof.Reachable
import Obs.Replay

set_option maxRecDepth 100000

-- 不开命名空间：装置的 `lean_check` 按短名 `#print axioms`。
open Game Game.Replay

/-- 开局：玩家、钥匙、能量、命取这一关第一帧；版面与静止的东西取整关并集；会动的装置另给。 -/
def mkStartAt (lv : Nat) (s : Seen) (pats : List PState) (orb : Nat) : World :=
  { me := s.me, key := s.key, energy := s.energy, lives := s.lives,
    goals := (statics lv).goals, rotators := (statics lv).rotators, shapers := (statics lv).shapers,
    painters := (statics lv).painters, refills := (statics lv).refills, pats := pats, orb := orb }

/-! ## 第 0 关

认证段 seq 1100–1112（成绩单记这一关 13 步）。这一关没有巡逻的装置。
-/

def L0_start : World := mkStartAt 0 f0 [] 0

/-- 开局到第一处断点为止，12 步（seq 1100–1111）。 -/
def L0_play : List (Act × Seen) := playFrom 1100 12

#eval match firstSplit (board 0) L0_start L0_play 0 with
  | none   => "LEVEL 0 play ok " ++ toString L0_play.length
  | some i => "LEVEL 0 play split at " ++ toString i

/-- **这一段有 12 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L0_trace : L0_play.length = 12 ∧ traceOk (board 0) (L0_start : World) L0_play = true := by
  decide +kernel

#print axioms L0_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1112，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L0_acts : List Act := L0_play.map Prod.fst ++ [.a1]

/-- **第 0 关走得通**：从 `L0_start` 起照着走，中途赢了。 -/
theorem L0_winnable : Winnable (board 0) (L0_start : World) :=
  ⟨L0_acts, by decide +kernel⟩

#print axioms L0_winnable

/-! ## 第 1 关

认证段 seq 1113–1157（成绩单记这一关 45 步）。这一关没有巡逻的装置。
-/

def L1_start : World := mkStartAt 1 f23 [] 0

/-- 开局到第一处断点为止，44 步（seq 1113–1156）。 -/
def L1_play : List (Act × Seen) := playFrom 1113 44

#eval match firstSplit (board 1) L1_start L1_play 0 with
  | none   => "LEVEL 1 play ok " ++ toString L1_play.length
  | some i => "LEVEL 1 play split at " ++ toString i

/-- **这一段有 44 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L1_trace : L1_play.length = 44 ∧ traceOk (board 1) (L1_start : World) L1_play = true := by
  decide +kernel

#print axioms L1_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1157，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L1_acts : List Act := L1_play.map Prod.fst ++ [.a2]

/-- **第 1 关走得通**：从 `L1_start` 起照着走，中途赢了。 -/
theorem L1_winnable : Winnable (board 1) (L1_start : World) :=
  ⟨L1_acts, by decide +kernel⟩

#print axioms L1_winnable

/-! ## 第 2 关

认证段 seq 1158–1196（成绩单记这一关 39 步）。这一关没有巡逻的装置。
-/

def L2_start : World := mkStartAt 2 f90 [] 0

/-- 开局到第一处断点为止，38 步（seq 1158–1195）。 -/
def L2_play : List (Act × Seen) := playFrom 1158 38

#eval match firstSplit (board 2) L2_start L2_play 0 with
  | none   => "LEVEL 2 play ok " ++ toString L2_play.length
  | some i => "LEVEL 2 play split at " ++ toString i

/-- **这一段有 38 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L2_trace : L2_play.length = 38 ∧ traceOk (board 2) (L2_start : World) L2_play = true := by
  decide +kernel

#print axioms L2_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1196，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L2_acts : List Act := L2_play.map Prod.fst ++ [.a2]

/-- **第 2 关走得通**：从 `L2_start` 起照着走，中途赢了。 -/
theorem L2_winnable : Winnable (board 2) (L2_start : World) :=
  ⟨L2_acts, by decide +kernel⟩

#print axioms L2_winnable

/-! ## 第 3 关

认证段 seq 1197–1239（成绩单记这一关 43 步）。这一关没有巡逻的装置。
-/

def L3_start : World := mkStartAt 3 f185 [] 0

/-- 开局到第一处断点为止，42 步（seq 1197–1238）。 -/
def L3_play : List (Act × Seen) := playFrom 1197 42

#eval match firstSplit (board 3) L3_start L3_play 0 with
  | none   => "LEVEL 3 play ok " ++ toString L3_play.length
  | some i => "LEVEL 3 play split at " ++ toString i

/-- **这一段有 42 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L3_trace : L3_play.length = 42 ∧ traceOk (board 3) (L3_start : World) L3_play = true := by
  decide +kernel

#print axioms L3_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1239，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L3_acts : List Act := L3_play.map Prod.fst ++ [.a3]

/-- **第 3 关走得通**：从 `L3_start` 起照着走，中途赢了。 -/
theorem L3_winnable : Winnable (board 3) (L3_start : World) :=
  ⟨L3_acts, by decide +kernel⟩

#print axioms L3_winnable

/-! ## 第 4 关

认证段 seq 1240–1316（成绩单记这一关 77 步）。会动的装置开局在端点上，方向是定的。
-/

def L4_start : World := mkStartAt 4 f248 [⟨2, true⟩] 0

/-- 开局到第一处断点为止，21 步（seq 1240–1260）。 -/
def L4_play : List (Act × Seen) := playFrom 1240 21

#eval match firstSplit (board 4) L4_start L4_play 0 with
  | none   => "LEVEL 4 play ok " ++ toString L4_play.length
  | some i => "LEVEL 4 play split at " ++ toString i

/-- **这一段有 21 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L4_trace : L4_play.length = 21 ∧ traceOk (board 4) (L4_start : World) L4_play = true := by
  decide +kernel

#print axioms L4_trace

/-- 第 1261 步掉了命（逐条那一层里它是一条 `died` 用例）。之后那一段 54 步（seq 1262–1315），到过关前一步为止。
    **这里用了那条明写的假设**：起点是 `restart L4_start 2`。 -/
def L4_tail : List (Act × Seen) := playFrom 1262 54

#eval match firstSplit (board 4) (restart L4_start 2) L4_tail 0 with
  | none   => "LEVEL 4 tail ok " ++ toString L4_tail.length
  | some i => "LEVEL 4 tail split at " ++ toString i

theorem L4_tail_trace : L4_tail.length = 54 ∧
    traceOk (board 4) (restart L4_start 2 : World) L4_tail = true := by
  decide +kernel

#print axioms L4_tail_trace

/-- 见证：掉命之后那一段真实走法（从开局起照样走得通：命数不影响走法），再加过关那一脚（seq 1316，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L4_acts : List Act := L4_tail.map Prod.fst ++ [.a1]

/-- **第 4 关走得通**：从 `L4_start` 起照着走，中途赢了。 -/
theorem L4_winnable : Winnable (board 4) (L4_start : World) :=
  ⟨L4_acts, by decide +kernel⟩

#print axioms L4_winnable

/-! ## 第 5 关

认证段 seq 1317–1414（成绩单记这一关 98 步）。会动的装置开局在端点上，方向是定的。
-/

def L5_start : World := mkStartAt 5 f340 [⟨6, false⟩, ⟨2, true⟩] 0

/-- 开局到第一处断点为止，97 步（seq 1317–1413）。 -/
def L5_play : List (Act × Seen) := playFrom 1317 97

#eval match firstSplit (board 5) L5_start L5_play 0 with
  | none   => "LEVEL 5 play ok " ++ toString L5_play.length
  | some i => "LEVEL 5 play split at " ++ toString i

/-- **这一段有 97 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L5_trace : L5_play.length = 97 ∧ traceOk (board 5) (L5_start : World) L5_play = true := by
  decide +kernel

#print axioms L5_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1414，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L5_acts : List Act := L5_play.map Prod.fst ++ [.a2]

/-- **第 5 关走得通**：从 `L5_start` 起照着走，中途赢了。 -/
theorem L5_winnable : Winnable (board 5) (L5_start : World) :=
  ⟨L5_acts, by decide +kernel⟩

#print axioms L5_winnable

/-! ## 第 6 关

认证段 seq 1415–1467（成绩单记这一关 53 步）。会动的装置开局**帧上看不全**（被雾遮住）：12 个（位置, 方向）候选逐个代进去算整关，恰好 1 个一处都不分家，就用它 [(2, True)]；其余各在第 [35, 36, 36, 37, 37, 37]… 步分家。
-/

def L6_start : World := mkStartAt 6 f873 [⟨2, true⟩] 0

/-- 开局到第一处断点为止，52 步（seq 1415–1466）。 -/
def L6_play : List (Act × Seen) := playFrom 1415 52

#eval match firstSplit (board 6) L6_start L6_play 0 with
  | none   => "LEVEL 6 play ok " ++ toString L6_play.length
  | some i => "LEVEL 6 play split at " ++ toString i

/-- **这一段有 52 步，而且模型沿着它一步不差。** 只有开局是观测给的。 -/
theorem L6_trace : L6_play.length = 52 ∧ traceOk (board 6) (L6_start : World) L6_play = true := by
  decide +kernel

#print axioms L6_trace

/-- 见证：整条真实走法，再加过关那一脚（seq 1467，它的下一帧是另一张盘，所以不在上面的路里）。 -/
def L6_acts : List Act := L6_play.map Prod.fst ++ [.a2]

/-- **第 6 关走得通**：从 `L6_start` 起照着走，中途赢了。 -/
theorem L6_winnable : Winnable (board 6) (L6_start : World) :=
  ⟨L6_acts, by decide +kernel⟩

#print axioms L6_winnable

