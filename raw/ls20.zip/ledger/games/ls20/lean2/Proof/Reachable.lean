/-
# Reachable —— 这个**局面**做不做得了

    Winnable   b w  :=  ∃ as, 照着走中途赢过
    Unsolvable b w  :=  ∀ as, 照着走从没赢过

这一局的动作类型 `Act` 只有四个方向键，**本来就是限死的**：模型里没有「一步跨两格」，
所以不需要另写 `Action.legal`。RESET 不在 `Act` 里——它不是一步棋。

## 一句必须写在明处的削弱

`everWon` 碰到 `died`（能量用光掉命）返回 `false`：掉命之后是哪一帧模型说不出来。
所以 `Unsolvable b w` 的准确意思是「**不经过掉命**就赢不了」，`Winnable` 的见证也是一条
**不经过掉命**的路。这一局七关全部有 `_winnable`（见 `Levels.lean`），一关都没有宣告不可做；
下面的骨架与 `not_both` 是为「每关一条结论、两样不能同时有」服务的。
-/
import Obj.World
import Obs.Check

namespace Game

def Winnable (b : Board) (w : World) : Prop := ∃ as : List Act, everWon b w as = true

def Unsolvable (b : Board) (w : World) : Prop := ∀ as : List Act, everWon b w as = false

end Game

-- 定理放在命名空间外面：装置的 `lean_check` 按短名 `#print axioms`。
open Game

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (w : World) : Winnable b w → Unsolvable b w → False := by
  intro ⟨as, h⟩ hu
  have := hu as
  rw [h] at this
  exact Bool.noConfusion this

/-- 骨架：不变量 ⇒ 不可做（**不经过掉命**）。全文唯一做归纳的地方，与盘面大小、动作串长短无关。 -/
theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w w' a, P w → step b w a = Res.ok w' → P w')
    (hwin : ∀ w a, P w → step b w a ≠ Res.won) :
    ∀ w : World, P w → Unsolvable b w := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hstep : step b w a with
    | won => exact absurd hstep (hwin w a hp)
    | ok w' => exact ih w' (hkeep w w' a hp hstep)
    | died => rfl
    | unknown => rfl

#print axioms not_both
#print axioms unsolvable_of_invariant
