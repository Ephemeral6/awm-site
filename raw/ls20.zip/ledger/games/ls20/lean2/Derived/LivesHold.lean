/-
# lives_hold —— 普通的一步命数不变（对应 `rule/world/lives_hold.py`）：**推论**

它不必单独立一条规则：`step` 的三种 `ok` 里没有一种动 `lives`；
命只在掉命那一支变，而那一支 `step` 不给下一帧（`died`）。
-/
import Obj.World
import Derived.Lemmas

open Game

theorem lives_hold (b : Board) (w w' : World) (a : Act) (h : step b w a = .ok w') :
    w'.lives = w.lives := by
  rcases step_ok_shape h with h | h | ⟨c, g, k, h⟩ <;> subst h <;> rfl

#print axioms lives_hold
