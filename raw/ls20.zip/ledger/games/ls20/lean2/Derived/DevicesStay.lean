/-
# devices_stay —— 不会动的装置不会自己挪（对应 `rule/world/devices_stay.py`）：**推论**

静止的十字 / 非十字 / 染色物件三张表，`step` 一张都不写（会动的那几个住在 `pats` / `orb`）；
补给只会少、不会多（`eraseC`）。所以这一条是分发的推论，不是一条独立的规则。

Python 那一份在语料那一侧还要多说一句「被盖住、被雾遮住的那一刻看不见」——
那是**观测**的事，在这里由 `Obs/Check.lean` 的 `seenOf` 管，不是世界的事。
-/
import Obj.World
import Derived.Lemmas

open Game

theorem devices_stay (b : Board) (w w' : World) (a : Act) (h : step b w a = .ok w') :
    w'.rotators = w.rotators ∧ w'.shapers = w.shapers ∧ w'.painters = w.painters := by
  rcases step_ok_shape h with h | h | ⟨c, g, k, h⟩ <;> subst h <;> exact ⟨rfl, rfl, rfl⟩

theorem refills_shrink (b : Board) (w w' : World) (a : Act) (h : step b w a = .ok w') :
    ∀ x, memC x w'.refills = true → memC x w.refills = true := by
  have aux : ∀ (x c : Cell) (l : List Cell), memC x (eraseC c l) = true → memC x l = true := by
    intro x c l
    induction l with
    | nil => intro h; exact h
    | cons y ys ih =>
      intro h
      unfold eraseC at h
      unfold memC
      split at h
      · simp [h]
      · unfold memC at h
        rcases Bool.or_eq_true_iff.mp h with h1 | h1
        · simp [h1]
        · simp [ih h1]
  intro x hx
  rcases step_ok_shape h with h | h | ⟨c, g, k, h⟩ <;> subst h
  · exact hx
  · exact hx
  · exact aux x _ _ hx

#print axioms devices_stay
#print axioms refills_shrink
