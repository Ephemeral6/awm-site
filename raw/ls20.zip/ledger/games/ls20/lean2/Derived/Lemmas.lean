/-
# 推论要用的两条小引理：`step` 给出 `ok` 的只有三种形状

    撞墙   `{ w with energy := … }`
    撞锁   `w` 原样
    挪格   `settle b w (relocate b w c g) k`（`advance` 那一支）

下面几份 `Derived/*.lean` 都靠这一条把 `step` 拆开。它们都是**从定义推出来的**：
写在这里不是为了「证明规则成立」（规则就是定义），是为了说出那几条规则
**其实不必单独立一条**——它们是别的规则与分发的推论。

（定理放在命名空间外面、用 `open Game`：装置的 `lean_check` 按短名 `#print axioms`。）
-/
import Obj.World
import Step

open Game

theorem advance_ok {b : Board} {w w' : World} {c : Cell} {g : List Goal}
    (h : advance b w c g = .ok w') : ∃ k, w' = settle b w (relocate b w c g) k := by
  unfold advance at h
  split at h
  · cases h
  · rename_i k _
    injection h with h
    exact ⟨k, h.symm⟩

theorem step_ok_shape {b : Board} {w w' : World} {a : Act} (h : step b w a = .ok w') :
    w' = { w with energy := energyAfterWall b w } ∨ w' = w ∨
    ∃ c g k, w' = settle b w (relocate b w c g) k := by
  unfold step at h
  split at h
  · cases h
  · split at h
    · injection h with h; exact Or.inl h.symm
    · injection h with h; exact Or.inr (Or.inl h.symm)
    · split at h
      · cases h
      · obtain ⟨k, hk⟩ := advance_ok h
        exact Or.inr (Or.inr ⟨_, _, k, hk⟩)
    · obtain ⟨k, hk⟩ := advance_ok h
      exact Or.inr (Or.inr ⟨_, _, k, hk⟩)
    · obtain ⟨k, hk⟩ := advance_ok h
      exact Or.inr (Or.inr ⟨_, _, k, hk⟩)

#print axioms advance_ok
#print axioms step_ok_shape
