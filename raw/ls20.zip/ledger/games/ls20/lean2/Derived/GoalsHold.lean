/-
# goals_hold —— 不开门的一步门不变（对应 `rule/world/goals_hold.py`）：**推论**

`step` 只在「开门」那一支写 `goals`（`consumeDoor`），别的支原样。
下面把它说成：走完一步，门要么原样，要么恰好少了玩家此刻站着的那一道。
-/
import Obj.World
import Derived.Lemmas

open Game

theorem goals_hold (b : Board) (w w' : World) (a : Act) (h : step b w a = .ok w') :
    w'.goals = w.goals ∨ w'.goals = eraseGoal w'.me w.goals := by
  unfold step at h
  split at h
  · cases h
  · split at h
    · injection h with h; subst h; exact Or.inl rfl
    · injection h with h; subst h; exact Or.inl rfl
    · split at h
      · cases h
      · obtain ⟨k, hk⟩ := advance_ok h
        subst hk
        exact Or.inr rfl
    · obtain ⟨k, hk⟩ := advance_ok h
      subst hk
      exact Or.inl rfl
    · obtain ⟨k, hk⟩ := advance_ok h
      subst hk
      exact Or.inl rfl

#print axioms goals_hold
