/-
# rot_cw 是四阶的（`derive/rot_cw.py` 的代数性质）：**推论**

判据 3（对称）说：提成对象的变换要证它的代数性质，证不出来说明提错了。
十字开关踩四次，钥匙回到原样——对全部 512 个九位图样成立（内核逐个算）。
顺带：它**不是**二阶的（踩两次一般回不来），说明它不是镜像——
起点册子第一版写过「镜像」，被第二次观测推翻；这一条把那次推翻钉成定理。

语句写在世界里的钥匙上（`w.key`），说的就是「任何一个世界里的钥匙」。
-/
import Obj.World
import Step

set_option maxRecDepth 100000

open Game

theorem rotCw_order4 (w : World) (h : w.key.shape < 512) :
    rotCw (rotCw (rotCw (rotCw w.key.shape))) = w.key.shape := by
  have all : ∀ s, s < 512 → rotCw (rotCw (rotCw (rotCw s))) = s := by decide +kernel
  exact all _ h

theorem rotCw_not_involution (w : World) (h : w.key.shape = 466) :
    rotCw (rotCw w.key.shape) ≠ w.key.shape := by
  rw [h]; decide

theorem rotateKey_order4 (w : World) (h : w.key.shape < 512) :
    rotateKey (rotateKey (rotateKey (rotateKey w.key))) = w.key := by
  have := rotCw_order4 w h
  cases hk : w.key with
  | mk s i =>
    rw [hk] at this
    simp only [rotateKey]
    simp [this]

#print axioms rotCw_order4
#print axioms rotCw_not_involution
#print axioms rotateKey_order4
