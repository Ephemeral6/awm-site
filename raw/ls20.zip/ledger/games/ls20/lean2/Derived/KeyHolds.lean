/-
# key_holds —— 什么都没踩，钥匙就不变（对应 `rule/key/key_holds.py`）：**推论**

它是「钥匙怎么变」那三条的**上界**：`pressKey` 只在玩家和某种装置同格时改钥匙，
否则原样交回。所以不必单立一条规则——它是分发（`Step.lean`）的推论：

    走完一步钥匙变了  ⇒  玩家此刻和某个十字 / 非十字 / 染色物件同格
-/
import Obj.World
import Derived.Lemmas

open Game

theorem pressKey_cases (b : Board) (w1 : World) (k : Key) (h : pressKey b w1 = some k) :
    k = w1.key ∨ memC w1.me (rotatorsAll b w1) = true ∨ memC w1.me (shapersAll b w1) = true
      ∨ memC w1.me (paintersAll b w1) = true := by
  cases h1 : memC w1.me (rotatorsAll b w1) <;> cases h2 : memC w1.me (shapersAll b w1) <;>
    cases h3 : memC w1.me (paintersAll b w1) <;> simp_all [pressKey]

theorem advance_key {b : Board} {w w' : World} {c : Cell} {g : List Goal}
    (h : advance b w c g = .ok w') :
    w'.key = w.key ∨ memC w'.me (rotatorsAll b w') = true ∨ memC w'.me (shapersAll b w') = true
      ∨ memC w'.me (paintersAll b w') = true := by
  unfold advance at h
  split at h
  · cases h
  · rename_i k hk
    injection h with h
    subst h
    exact pressKey_cases b _ k hk

theorem key_holds (b : Board) (w w' : World) (a : Act) (h : step b w a = .ok w') :
    w'.key = w.key ∨ memC w'.me (rotatorsAll b w') = true ∨ memC w'.me (shapersAll b w') = true
      ∨ memC w'.me (paintersAll b w') = true := by
  unfold step at h
  split at h
  · cases h
  · split at h
    · injection h with h; subst h; exact Or.inl rfl
    · injection h with h; subst h; exact Or.inl rfl
    · split at h
      · cases h
      · exact advance_key h
    · exact advance_key h
    · exact advance_key h

#print axioms pressKey_cases
#print axioms advance_key
#print axioms key_holds
