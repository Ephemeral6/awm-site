/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    能量为 0、目标格不是补给        → died（`outcome/out_of_energy`；之后是哪一帧不进模型）
    landing = wall                → 原地不动，能量掉单价（`move/blocked` + `world/energy_cost`）
    landing = locked              → 什么都不变（`move/blocked`；撞锁不扣能量）
    landing = opened c            → 最后一道门 ⇒ won（`outcome/last_door_wins`）；
                                     否则这道门消失，照「挪了格」那一支走进去（`outcome/door_consumed`）
    landing = step c / slide c    → 「挪了格」那一支（`move/walk`、`move/slide`）

「挪了格」那一支的顺序（`advance`）：

    1. 玩家落到 c；巡逻的装置各走一格、绕圈的走一格（`world/patrol`、`world/orbit`）
    2. 看玩家和哪种装置同格（静止的 + 刚走到的）：十字 ⇒ 转、非十字 ⇒ 换形、染色 ⇒ 换色（`key/*`）
    3. 能量：落在补给上回满并吃掉它，否则掉单价（`world/refill`、`world/energy_cost`）

换形说不出来（图样不在 24 种里）⇒ `unknown`：不编。
-/
import Rule.Move.Walk
import Rule.Key.KeyReshapes
import Rule.Key.KeyRecolors
import Rule.Outcome.LastDoorWins
import Rule.Outcome.DoorConsumed
import Rule.Outcome.OutOfEnergy
import Rule.World.Patrol
import Rule.World.Orbit
import Rule.World.EnergyCost

namespace Game

/-- 三种装置此刻各在哪几格（静止的 + 巡逻的 + 绕圈的）。 -/
def rotatorsAll (b : Board) (w : World) : List Cell := w.rotators ++ patrolCells 0 b.patrols w.pats
def shapersAll (b : Board) (w : World) : List Cell := w.shapers ++ patrolCells 1 b.patrols w.pats
def paintersAll (b : Board) (w : World) : List Cell := w.painters ++ orbitCells b w.orb

/-- 第 1 步：玩家落到 `c`，门换成 `goals`，会动的装置各走一格。 -/
def relocate (b : Board) (w : World) (c : Cell) (goals : List Goal) : World :=
  { w with me := c, goals := goals, pats := tickAll b.patrols w.pats, orb := orbitTick b w.orb }

/-- 第 2 步：踩到什么，钥匙就怎么变。说不出来返回 `none`。 -/
def pressKey (b : Board) (w1 : World) : Option Key :=
  let k1 := if memC w1.me (rotatorsAll b w1) then rotateKey w1.key else w1.key
  let k2 := if memC w1.me (shapersAll b w1) then reshapeKey k1 else some k1
  match k2 with
  | none    => none
  | some k2 => if memC w1.me (paintersAll b w1) then recolorKey k2 else some k2

/-- 第 3 步：能量与补给。 -/
def settle (b : Board) (w w1 : World) (k : Key) : World :=
  { w1 with key := k,
            energy := energyAfterMove b w w1.me (memC w1.me (rotatorsAll b w1)),
            refills := refillsAfter w w1.me }

def advance (b : Board) (w : World) (c : Cell) (goals : List Goal) : Res :=
  match pressKey b (relocate b w c goals) with
  | none   => .unknown
  | some k => .ok (settle b w (relocate b w c goals) k)

def step (b : Board) (w : World) (a : Act) : Res :=
  if outOfEnergy w a.dir then .died
  else match landing b w a.dir with
    | .wall     => .ok { w with energy := energyAfterWall b w }
    | .locked   => .ok w
    | .opened c => if lastDoorWins w then .won else advance b w c (consumeDoor c w)
    | .step c   => advance b w c w.goals
    | .slide c  => advance b w c w.goals

end Game
