"""不换关的充要条件：只有当 me 走进某个框内 5×5 区（entering_goal）、走前 HUD 与**那个**框匹配（hud_match_at）、且它是帧里最后一个框时才换关（ctx.level 加 1）；其他任何转移 level 不变。"""
LEVEL = "L5"
SCOPE = "只看 ACTION1–4；要 ctx 里有 level_prev/level_next，没有返回 NA；me(prev) 定位不到、目标区算不出、或帧里一个框都没有返回 NA。"
NOTE = "v2：第 118 步 HUD 形状已与框内一致（HUD 色 12、框内色 9），走进框被挡、没换关——匹配从「形状相同」改成「形状与颜色都相同」。v3：第 5 关有两个框，改成逐框比对。v4：第 407 步走进匹配的框，框消失了（frame_consumed）但关没换、另一个框还在——换关还要求它是最后一个框。"
EVIDENCE = ["4f8439df8317e83a", "0167dd718934d79b", "1a89a4295331ca71", "03bf7c9d0f7e2409", "76a60929da7af60a"]

from _lib import me, target_cells, goal_cells, goal_frames, hud_match_at

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if action not in ACTS:
        return "NA"
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if me(prev) is None:
        return "NA"
    tc = target_cells(prev, action)
    gcs = goal_cells(prev)
    if tc is None or not gcs:
        return "NA"
    b = tc[0]
    should = b in gcs and hud_match_at(prev, (b[0] - 1, b[1] - 1)) and len(goal_frames(prev)) == 1
    did = ctx["level_next"] != ctx["level_prev"]
    return "TRUE" if should == did else "FALSE"
