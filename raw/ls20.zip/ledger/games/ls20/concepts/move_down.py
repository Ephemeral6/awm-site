"""ACTION2 要么让玩家块 me 落到 landing 算出的格（先下移 CELL 格；目标格贴着色 1 直线就沿被推方向滑到底），且到达区变成玩家图样、离开区恢复成被盖住的底（under）；要么 me 不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION2；换关返回 NA；energy(prev)==0 返回 NA（那是 death_reset 管的）；me(prev) 或 me(nxt) 定位不到、或 landing 算不出返回 NA。只断言 me 的位移与 me 覆盖的两块 5×5，不管其他格。"
NOTE = "v3：踩过的色 5 框边会还原——玩家是覆盖不是涂改。v4：第 18 步离开开关，开关原样露出来——开关是持久物件，under 要认得它。v6：能量 0 再动是重置，缩出 scope。v7：与 move_up 同步——第 99 步（ACTION1）落点贴着色 1 直线时 me 滑了 25 格，位移改成 landing（含直线推滑）。v10：第 194 步下移后被下方直线推回来，穿过自己的出发格一路滑到顶——landing 的滑动把出发格算作可进。v11：第 263 步离开第 4 关的开关，另一个开关还在帧上，「全图看不见开关才算踩着」失效——离开区改成认「露出的是开关形状」，apply 不再认领内 3×3。v12：第 407 步走进匹配的框、框整个消失，离开区里原属框边的格变成 FLOOR——leave_ok 认下这一种。"
EVIDENCE = ["ed73bc2677ca3d87", "507201ba3b909d6c", "9edf6a2e83854287", "9a65b576745d214b", "76a60929da7af60a"]

from _lib import me, CELL, ME_TOP, ME_BOT, will_move, under_known, leave_ok, levels_up, alive, landing, consumes_frame

ACT = "ACTION2"


def _pattern(t, l):
    return {(t + dr, l + dc): (ME_TOP if dr < 2 else ME_BOT) for dr in range(CELL) for dc in range(CELL)}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != ACT:
        return "NA"
    if not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    if a == b:
        return "TRUE"
    tgt = landing(prev, action)
    if tgt is None:
        return "NA"
    if b != tgt:
        return "FALSE"
    for (r, c), v in _pattern(*b).items():
        if nxt[r][c] != v:
            return "FALSE"
    left = [(r, c) for (r, c) in _pattern(*a) if (r, c) not in _pattern(*b)]
    return "TRUE" if leave_ok(prev, a, nxt, left) else "FALSE"


def apply(prev, action, ctx=None):
    if action != ACT:
        return None
    a = me(prev)
    if a is None or not alive(prev):
        return None
    if not will_move(prev, action) or levels_up(prev, action):   # 挡住、算不出、或换关整屏重画：不开口
        return None
    b = landing(prev, action)
    if b is None:
        return None
    out = dict(under_known(prev, a, (ctx or {}).get("level_prev")))
    f = consumes_frame(prev, action)
    if f is not None:                                            # 进匹配的框那一步整个框消失（frame_consumed 管那 7×7），离开区里属于框的格不认领
        out = {k: v for k, v in out.items() if not (f[0] <= k[0] <= f[0] + 6 and f[1] <= k[1] <= f[1] + 6)}
    out.update(_pattern(*b))
    return out
