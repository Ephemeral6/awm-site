"""ACTION1–4：me 移进含 REFILL 色的目标区（吃到补给）时，主区里 3×3 补给物件的个数恰减 1（用过即消失）；其余转移里个数不变。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 且目标区不含 REFILL 返回 NA（重置步整屏重画）；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA。只数主区（行 < 60）里 8 格连通的色 REFILL 块，能量条不算。"
NOTE = "接替 refill_consumed（v1 把能量条低电量时的 8 格尾巴也数成了补给块，在 17 条转移上误判）。全局料里每次吃补给个数都恰减 1（第 1–5 关共 14 次），掉命重置后全部回来（重置步在 scope 外）。v2：第 6 关有迷雾，补给随视野出没（第 936–944 步五条反例），迷雾关缩出 scope。"
EVIDENCE = ["c54f204faa97bda8", "d82c6635d0d21420", "192d2b4285f82ef4", "3c4bec8d77df1b2d", "62d7d205529c34f7", "a4d7a1b52b659867", "e92e337ebf01b990"]

FOG_LEVELS = {6}

from _lib import me, target_cells, alive, REFILL
from geo import cells_of, components

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def _refills(g):
    cs = [(r, c) for (r, c) in cells_of(g, REFILL) if r < 60]
    return sum(1 for comp in components(cs) if len(comp) == 8)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    if ctx and ctx.get("level_prev") in FOG_LEVELS:
        return "NA"                                   # 迷雾关里补给随视野出没，全图计数没意义
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    tc = target_cells(prev, action)
    if tc is None:
        return "NA"
    hit = any(prev[r][c] == REFILL for r, c in tc) and a != b
    if not alive(prev) and not hit:
        return "NA"
    n0, n1 = _refills(prev), _refills(nxt)
    return "TRUE" if n1 == (n0 - 1 if hit else n0) else "FALSE"
