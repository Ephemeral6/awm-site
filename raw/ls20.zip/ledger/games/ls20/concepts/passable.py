"""ACTION1–4 让 me 移动 iff 目标 5×5 区在 prev 里全是 PASSABLE 色（FLOOR、色 5、开关色 0/1、补给色）、或目标格是一个染色物件（paints）、或目标区是框内且 hud_match（HUD 与框内图样形状、颜色都一致）；否则主区（行 < 60）整块不变。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA（重置步由 death_reset 管）；me(prev) 定位不到或目标区越界返回 NA。断言的是「动/不动」与「不动时整帧不变」，位移量由 L1 概念管。"
NOTE = "v2：第 17 步踩上色 0/1 小十字，玩家动了——开关色可进。v3：第 24 步 HUD 图样匹配后走进框内过关。v4：能量 0 再动是重置，缩出 scope。v5：第 118 步 HUD 形状同、颜色不同（12 对 9），进框被挡整帧不变——进框条件改成 hud_match（形状与颜色）。v6：第 145 步走进含色 14/8 的染色物件，玩家动了——按形状认的染色物件可进。v7：第 927/928 步第 6 关撞墙不动但能量条扣了——「整帧不变」缩成「主区不变」，能量条交给 energy_cost。"
EVIDENCE = ["02f43e1d95ef8c6c", "1a89a4295331ca71", "2542e684fdabf403", "4f8439df8317e83a", "eedeb19e0d864112", "03bf7c9d0f7e2409", "5d2f255f6bb3164b", "1343d15c46483cad", "bb57242f98dbe007"]

from _lib import me, will_move, alive

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    if not alive(prev):
        return "NA"
    mv = will_move(prev, action)
    if mv is None:
        return "NA"
    a, b = me(prev), me(nxt)
    if b is None:
        return "NA"
    moved = a != b
    if mv != moved:
        return "FALSE"
    if not mv and any(prev[r][c] != nxt[r][c] for r in range(60) for c in range(64)):
        return "FALSE"                              # 不动时主区（行 < 60）不变；能量条那两行由 energy_cost/energy_tick 管
    return "TRUE"


def apply(prev, action, ctx=None):
    """不动时认领 me 自己的 25 格（颜色不变）；动的情况交给 L1。"""
    if action not in ACTS or not alive(prev):
        return None
    mv = will_move(prev, action)
    if mv is None or mv:
        return None
    a = me(prev)
    return {(a[0] + dr, a[1] + dc): prev[a[0] + dr][a[1] + dc] for dr in range(5) for dc in range(5)}
