"""me 踩到一个非十字形开关（pressed_toggle 且非 toggle_is_cross；会动的开关走到 me 落点也算）时，新 HUD 图样 = TOGGLE_MAP[(开关内图样, 旧 HUD 图样)]，颜色不变；表里只登记观测过的组合，没见过的组合返回 NA；其余转移不受本条约束。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到或 me 没动返回 NA；不是踩非十字开关的步返回 NA；(内图样, 旧 HUD) 不在 TOGGLE_MAP 里返回 NA。apply 只在开关不动（prev 目标格里就是它）时开口。"
NOTE = "接替 toggle_sets_hud（第 3 关一次观测像「设成目标」，第 4 关同形开关同输入同输出，但目标不同——推翻）。只登记「这形状、这输入 → 这输出」。v3：「踩到」改用 pressed_toggle（会动的开关走到 me 落点也算）。v4/v5 曾把第 421/425/429 步登记成三条非十字映射——那三步踩的是第 5 关 row 40 的开关，内图样 303/100/313 是十字形，HUD 变化就是顺转 90°（toggle_rotates_hud 管）；v6 撤掉这三条，表里只剩第 3/4 关真正的非十字开关那两条。"
EVIDENCE = ["73d99c2327c4cc4c", "3b4ad0ec834abf70", "e43502d57737c575", "163895c90a8c0880", "8544f938283b3a5c", "0df00629a08c9820", "be881564b87e4e6f", "33f910a236fa07c5", "939b17021000a99c", "b1ef17a00ec54d0f", "8c9e8ef6fcf3d3b3", "23e1b2f6986207e4", "e491a904f44e5c30"]

from _lib import me, hud_pattern, hud_ink, steps_on_toggle, steps_on_cross, target_cells, toggle_inner, toggles, toggle_is_cross, pressed_toggle, will_move, alive, HUD_BG

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}

# 键：(内 3×3 图样按行拼成的元组, 旧 HUD 9 元组) → 新 HUD 9 元组。第 219 步（第 3 关）与第 262 步（第 4 关）同一组合。
TOGGLE_MAP = {
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (False, True, False, True, True, False, False, True, True)):
        (True, True, True, False, False, True, True, False, True),
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, True, True, False, False, True, True, False, True)):
        (True, True, False, False, True, True, True, False, True),      # 第 264 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, False, True, False, True, True, True, True, False)):
        (True, False, False, True, True, True, True, False, False),     # 第 627 步（第 5 关 row 10 的会动开关）
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, False, False, True, True, True, True, False, False)):
        (True, True, True, True, False, False, True, True, True),       # 第 635 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, True, True, True, False, False, True, True, True)):
        (False, True, False, True, False, True, False, True, True),     # 第 640 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (False, True, False, True, False, True, False, True, True)):
        (False, True, False, True, True, True, True, False, False),     # 第 641 步（开关在 me 底下随 me 走）
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (False, True, False, True, True, True, True, False, False)):
        (True, False, True, False, False, True, True, True, True),      # 第 642 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (False, True, False, False, True, False, True, True, True)):
        (True, False, True, True, False, True, True, True, True),       # 第 1031 步（第 6 关）
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, False, True, True, False, True, True, True, True)):
        (False, True, True, True, False, True, False, True, False),     # 第 1033 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (False, True, True, True, False, True, False, True, False)):
        (False, True, False, True, True, False, False, True, True),     # 第 1035 步
    ((0, 3, 3, 3, 0, 0, 3, 0, 3), (True, True, False, False, True, True, True, False, True)):
        (False, True, False, False, True, False, True, True, True),     # 第 1041 步：环闭合（.#./.#./### 起 6 档一圈）
}


def _inner_key(prev, cell):
    inner = toggle_inner(prev, cell)
    return tuple(inner[(dr, dc)] for dr in range(1, 4) for dc in range(1, 4))


def _lookup(prev, action):
    """返回新图样；不是踩非十字开关返回 None；组合没见过返回 'unseen'。"""
    tg = steps_on_toggle(prev, action)
    cr = steps_on_cross(prev, action)
    if tg is None or cr is None or not tg or cr:
        return None
    cell = target_cells(prev, action)[0]
    key = (_inner_key(prev, cell), hud_pattern(prev))
    return TOGGLE_MAP.get(key, "unseen")


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS or not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return "NA"
    t = pressed_toggle(prev, nxt, ctx.get("level_prev") if ctx else None)
    if t is None or t not in toggles(prev) or toggle_is_cross(prev, t):
        return "NA"
    key = (_inner_key(prev, t), hud_pattern(prev))
    if key not in TOGGLE_MAP:
        return "NA"
    return "TRUE" if hud_pattern(nxt) == TOGGLE_MAP[key] else "FALSE"


def apply(prev, action, ctx=None):
    if action not in ACTS or not alive(prev) or me(prev) is None:
        return None
    if not will_move(prev, action):
        return None
    new = _lookup(prev, action)
    ink = hud_ink(prev)
    if new is None or new == "unseen" or ink is None:
        return None
    out = {}
    for i in range(3):
        for j in range(3):
            v = ink if new[3 * i + j] else HUD_BG
            for dr in range(2):
                for dc in range(2):
                    out[(55 + 2 * i + dr, 3 + 2 * j + dc)] = v
    return out
