"""ACTION1–4：me 走进某个框内 5×5 区且走前 HUD 与那个框匹配（consumes_frame）、且它不是最后一个框时，那个 7×7 框整个消失（边框与图样格全变 FLOOR，me 盖住的除外），其余框原样、HUD 不变；不消框的转移里所有框原样。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA（最后一个框被消掉就是换关，整屏重画）；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；prev 里一个框都没有返回 NA。"
NOTE = "第 407 步：第 5 关两个框，走进匹配的色 8 框，它的 7×7 区变成底色，色 9 框还在，HUD 不变，关没换。只观测一次。"
EVIDENCE = ["76a60929da7af60a", "96f6b26c304f4106"]

FOG_LEVELS = {6}

from _lib import me, goal_frames, consumes_frame, hud_pattern, hud_ink, alive, will_move, FLOOR, CELL

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def _region(f):
    return [(f[0] + dr, f[1] + dc) for dr in range(7) for dc in range(7)]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx and ctx.get("level_prev") in FOG_LEVELS:
        return "NA"                                   # 迷雾关里框随视野出没，看不见不等于消掉了
    if action not in ACTS or not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    fs = goal_frames(prev)
    if not fs:
        return "NA"
    f = consumes_frame(prev, action)
    if f is None:
        return "TRUE" if goal_frames(nxt) == fs else "FALSE"
    if hud_pattern(prev) != hud_pattern(nxt) or hud_ink(prev) != hud_ink(nxt):
        return "FALSE"
    if [x for x in fs if x != f] != goal_frames(nxt):
        return "FALSE"
    mine = {(b[0] + dr, b[1] + dc) for dr in range(CELL) for dc in range(CELL)}
    return "TRUE" if all(nxt[r][c] == FLOOR for (r, c) in _region(f) if (r, c) not in mine) else "FALSE"


def apply(prev, action, ctx=None):
    """消框那一步认领框 7×7 里 me 没盖住的格：全变 FLOOR。"""
    if action not in ACTS or not alive(prev) or me(prev) is None:
        return None
    f = consumes_frame(prev, action)
    if f is None or len(goal_frames(prev)) <= 1 or not will_move(prev, action):
        return None
    mine = {(f[0] + 1 + dr, f[1] + 1 + dc) for dr in range(CELL) for dc in range(CELL)}
    return {(r, c): FLOOR for (r, c) in _region(f) if (r, c) not in mine}
