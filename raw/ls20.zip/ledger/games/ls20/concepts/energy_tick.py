"""ACTION1–4：me 移进不含开关色、不含补给色的目标区时 energy 严格减少；me 不动时 energy 不变；第 62 行始终与第 61 行相同。踩开关、走进补给区那两种步不在本条 scope 内。"""
LEVEL = "L4"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；移进含开关色的目标区返回 NA（第 0 关不扣、第 1 关扣 2，规律未知）；移进含 REFILL 色的目标区返回 NA（那是 refill 管的）。"
NOTE = "v2：被挡时不扣。v3：踩开关也不扣。v5：扣多少拆到 energy_cost。v6：第 41 步踩开关扣了 2，与第 17 步（不扣）矛盾——踩开关那步缩出 scope，等更多数据。v7：第 66 步走进补给区能量回满（29→42），与「严格减少」矛盾——补给步缩出 scope，交给 refill。"
EVIDENCE = ["96a7f535e5c750b0", "ed73bc2677ca3d87", "1a89a4295331ca71", "2542e684fdabf403",
            "7ebd25ad5f38261b", "4420aafe344dba4d", "31b2ab0471747c0e", "f76c0b6dd75794b3",
            "5a04f5e24b7438c7", "2b93804e29fd1e46", "aaf3b31e9e40532c", "cb153d347e72e1f6", "c0b15395f53b9ab5",
            "d82c6635d0d21420", "1343d15c46483cad", "bb57242f98dbe007", "de943692162ba836",
            "2026e778b3a76078", "7208fac90891931d", "72327a1a935ff1e0", "a710022e68a6805f", "cf62514d27f7eac5", "d36210868ad452ab", "d7a2f25217c26bbd"]

from _lib import energy, me, steps_on_toggle, target_cells, HUD_ROW, REFILL

BLOCKED_COSTS = {4, 6}   # 撞墙也扣的关（与 energy_cost 同一张表；第 6 关第 927/928 步、第 4 关第 1260–1268 步）

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    e0 = energy(prev)
    if e0 == 0:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    tg = steps_on_toggle(prev, action)
    if tg is None or (tg and a != b):
        return "NA"
    tc = target_cells(prev, action)
    if tc is None:
        return "NA"
    if a != b and any(prev[r][c] == REFILL for r, c in tc):
        return "NA"
    e1 = energy(nxt)
    if nxt[HUD_ROW + 1][13:56] != nxt[HUD_ROW][13:56]:
        return "FALSE"                                # 只比能量条那一段：迷雾关的圆盘边缘会切进第 61/62 行的两端（第 973 步）
    if a != b:
        return "TRUE" if e1 < e0 else "FALSE"
    if ctx and ctx.get("level_prev") in BLOCKED_COSTS:
        return "NA"                                   # 这些关撞墙也扣（energy_cost 管）
    return "TRUE" if e1 == e0 else "FALSE"
