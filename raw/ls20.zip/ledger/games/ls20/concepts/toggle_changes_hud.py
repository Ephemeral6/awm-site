"""ACTION1–4：me 踩到一个开关（pressed_toggle：prev 里可见、这一步被 me 盖住，开关会动也算）时左下 HUD 3×3 图样 hud_pattern 发生改变；其余任何转移 hud_pattern 不变。走进染色物件那一步不在本条 scope 内。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA（重置步由 death_reset 管）；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；目标格是染色物件（steps_on_paint）返回 NA。只断言「变/不变」，怎么变另写。"
NOTE = "v2：第 46 步能量 0 再动是掉命重置，HUD 整体重画，缩出 scope。v3：第 145 步走进染色物件，HUD 图样区 20 格换色（12→9）但形状没变；开关改成按形状认，染色步缩出 scope。v4：第 278 步会动的开关与 me 同时到同一格、HUD 转了——「踩到」从「prev 目标格有开关」改成「这一步有一个开关被 me 盖住」（pressed_toggle）。"
EVIDENCE = ["2542e684fdabf403", "316352592eb5850c", "eedeb19e0d864112", "5d2f255f6bb3164b", "ac13f608150732b9", "aefb02c7d11426fd", "b209d9efc223d456", "c79200ae0f16e188"]

from _lib import me, hud_pattern, pressed_toggle, steps_on_paint, alive

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    if not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    pt = steps_on_paint(prev, action)
    if pt is None:
        return "NA"
    if pt and a != b:
        return "NA"
    changed = hud_pattern(prev) != hud_pattern(nxt)
    lvl = ctx.get("level_prev") if ctx else None
    hit = pressed_toggle(prev, nxt, lvl) is not None
    return "TRUE" if changed == hit else "FALSE"
