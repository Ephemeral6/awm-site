"""ACTION1–4：me 踩到染色物件（pressed_paint：prev 里可见、这一步被 me 盖住——它会动的关里是它走到 me 落点）时，HUD 图样形状不变、HUD 颜色按 PAINT_NEXT 表换一档（12→9→14→8→12 四色循环）；其余转移 hud_ink 不变。染色物件是持久物件（离开后原样露出）。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到返回 NA；hud_ink 读不出（不止一色）返回 NA；踩染色时旧颜色不在 PAINT_NEXT 里返回 NA（没观测过）。apply 只在本关它不动（PAINT_ORBIT 没登记）时开口。"
NOTE = "第 145 步：HUD 图样区 20 格 12→9，形状原样。v1 写「踩过就消失」，第 146 步离开它原样露出来——删掉。v3：第 147 步再踩一次 9→14，改成换档表 PAINT_NEXT。v4：第 204/206 步 14→8、8→12，四色循环闭合。v5：第 5 关它会动（paint_orbits），改用 pressed_paint。v6：第 654/655 步它在 me 底下沿轨道走到 me 的落点、连染两次——pressed_paint 认下这种「一直被盖着」的踩法。"
EVIDENCE = ["5d2f255f6bb3164b", "57e74ab24fad0444", "45aa4da3bbbae5ed", "691e812cc51c26e6", "37ea07d7edd00928", "71030b1777e54acf", "eec728ca0536f09a"]

from _lib import me, hud_pattern, hud_ink, pressed_paint, steps_on_paint, alive, will_move, PAINT_NEXT, PAINT_ORBIT, HUD_BG

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS or not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    i0, i1 = hud_ink(prev), hud_ink(nxt)
    if i0 is None or i1 is None:
        return "NA"
    if pressed_paint(prev, nxt, ctx.get("level_prev") if ctx else None) is not None and not (ctx and ctx.get("level_prev") in FOG_LEVELS and steps_on_paint(prev, action) is False):
        if i0 not in PAINT_NEXT:
            return "NA"
        if hud_pattern(prev) != hud_pattern(nxt):
            return "FALSE"
        return "TRUE" if i1 == PAINT_NEXT[i0] else "FALSE"
    return "TRUE" if i1 == i0 else "FALSE"


FOG_LEVELS = {6}   # 迷雾关：染色物件出视野也会让 pressed_paint 误判（第 977 步），只认「目标格里就是它」那种踩法


def apply(prev, action, ctx=None):
    """本关染色物件不动时，踩它那一步认领 HUD 图样区（rows 55–60, cols 3–8）的 36 格：形状照旧、非底色格换成 PAINT_NEXT[旧色]。"""
    if action not in ACTS or not alive(prev):
        return None
    lvl = (ctx or {}).get("level_prev")
    if lvl is None or lvl in PAINT_ORBIT:
        return None
    if me(prev) is None or not steps_on_paint(prev, action) or not will_move(prev, action):
        return None
    i0 = hud_ink(prev)
    if i0 not in PAINT_NEXT:
        return None
    p = hud_pattern(prev)
    out = {}
    for i in range(3):
        for j in range(3):
            v = PAINT_NEXT[i0] if p[3 * i + j] else HUD_BG
            for dr in range(2):
                for dc in range(2):
                    out[(55 + 2 * i + dr, 3 + 2 * j + dc)] = v
    return out
