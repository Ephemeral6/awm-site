"""me 踩到一个十字形开关（pressed_toggle 且 toggle_is_cross）时，新 HUD 图样 = 旧 HUD 图样顺时针转 90°（rot_cw）；不踩开关的转移 HUD 图样不变。非十字形开关那一步不在本条 scope 内。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA（重置步由 death_reset 管）；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；踩的是非十字形开关返回 NA（那是 toggle_maps_hud 管的）。apply 只在帧里恰好一个开关时开口（多于一个时分不清哪个会动）。"
NOTE = "接替 toggle_mirrors_hud（一次观测像镜像，第二次不像）：两次观测都与顺时针 90° 一致。v2：能量 0 再动是重置，缩出 scope。v4：第 145 步走进染色物件（里面也有色 0），按颜色认开关把它当成了开关——开关改成按形状认（toggles）。v5：第 219 步第 3 关的开关（内图样 033/300/303）按下去不是旋转——旋转只对十字形开关成立。v7：第 278 步会动的十字开关与 me 同时到同一格、HUD 顺转了——「踩到」改用 pressed_toggle；会动的开关从 prev 单帧预测不了落点，apply 在多开关帧上不开口。"
EVIDENCE = ["2542e684fdabf403", "c0b15395f53b9ab5", "eedeb19e0d864112", "5d2f255f6bb3164b", "73d99c2327c4cc4c", "ac13f608150732b9", "aefb02c7d11426fd", "b209d9efc223d456"]

from _lib import me, hud_pattern, hud_ink, pressed_toggle, toggle_is_cross, toggles, steps_on_cross, rot_cw, will_move, alive, HUD_BG

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    if not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    t = pressed_toggle(prev, nxt, ctx.get("level_prev") if ctx else None)
    h0, h1 = hud_pattern(prev), hud_pattern(nxt)
    if t is None:
        return "TRUE" if h1 == h0 else "FALSE"
    if t not in toggles(prev):
        return "NA"                                   # 踩到的是 me 底下随行的那个：prev 里看不见它的形状
    if not toggle_is_cross(prev, t):
        return "NA"
    return "TRUE" if h1 == rot_cw(h0) else "FALSE"


def apply(prev, action, ctx=None):
    """踩十字开关那一步认领 HUD 3×3 图样区（rows 55–60, cols 3–8）的 36 格；其他步不开口。"""
    if action not in ACTS:
        return None
    a = me(prev)
    if a is None or not alive(prev):
        return None
    if len(toggles(prev)) != 1:
        return None
    if not steps_on_cross(prev, action) or not will_move(prev, action):
        return None
    p = rot_cw(hud_pattern(prev))
    ink = hud_ink(prev)
    if ink is None:
        return None
    out = {}
    for i in range(3):
        for j in range(3):
            v = ink if p[3 * i + j] else HUD_BG
            for dr in range(2):
                for dc in range(2):
                    out[(55 + 2 * i + dr, 3 + 2 * j + dc)] = v
    return out
