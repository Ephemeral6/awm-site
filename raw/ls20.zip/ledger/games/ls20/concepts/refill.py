"""ACTION1–4：me 移进含 REFILL 色（11）的目标区时，energy 回到 FULL_ENERGY（42），energy(prev)==0 也一样（不掉命、不重置）；其余转移不受本条约束。"""
LEVEL = "L4"
SCOPE = "只看 ACTION1–4；换关返回 NA；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；目标区不含 REFILL 返回 NA。"
NOTE = "零观测的假设：主区 3×3 色 11 物件与能量条同色。写下来让规划器敢走过去、让下一步判它。v2：第 170 步能量 0 走进补给——没掉命、回满；energy(prev)==0 不再排除。v3：第 1177 步能量 0 时 apply 把满条右端画到第 55 列（实际是 54），终局卡意外一次——空条时右端按常数 54。"
EVIDENCE = ["eedeb19e0d864112", "d82c6635d0d21420", "c54f204faa97bda8", "fa2f0f0846c37d54"]

from _lib import energy, me, target_cells, will_move, alive, levels_up, REFILL, FULL_ENERGY, HUD_ROW, HUD_COLOR

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def _on_refill(prev, action):
    tc = target_cells(prev, action)
    if tc is None:
        return None
    return any(prev[r][c] == REFILL for r, c in tc)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    rf = _on_refill(prev, action)
    if not rf or a == b:
        return "NA"
    return "TRUE" if energy(nxt) == FULL_ENERGY else "FALSE"


def apply(prev, action, ctx=None):
    if action not in ACTS or levels_up(prev, action):
        return None
    rf = _on_refill(prev, action)
    if not rf or not will_move(prev, action):
        return None
    # 能量条满格：第 61、62 行 cols 14..55（首帧读出 42 格的位置）
    cols = [c for c, v in enumerate(prev[HUD_ROW]) if v == HUD_COLOR]
    right = max(cols) if cols else 54                # 满格时右端在第 54 列（首帧读出 cols 13..54）；能量 0 时条是空的，只能按这个常数画
    out = {}
    for c in range(right - FULL_ENERGY + 1, right + 1):
        out[(HUD_ROW, c)] = HUD_COLOR
        out[(HUD_ROW + 1, c)] = HUD_COLOR
    return out
