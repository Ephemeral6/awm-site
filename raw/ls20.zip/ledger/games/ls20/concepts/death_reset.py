"""energy(prev)==0 时再发 ACTION1–4 且目标区不含补给色：命数 lives 恰减 1，能量条回到 FULL_ENERGY，且 me 的位置改变（本关重置）；level 不变。目标区含补给色的那一步不在本条 scope 内（那是 refill 管的：能量 0 走进补给照样回满、不掉命）。"""
LEVEL = "L5"
SCOPE = "只看 ACTION1–4 且 energy(prev)==0；其余返回 NA；me(prev)/me(nxt) 定位不到或目标区算不出返回 NA；目标区含 REFILL 返回 NA。lives(prev)==0 时会发生什么未观测，返回 NA。"
NOTE = "v2：第 170 步能量 0 走进补给块——没掉命、能量回满、me 正常移动；补给那一步缩出 scope，交给 refill。"
EVIDENCE = ["eedeb19e0d864112", "5a8e6801c827612d", "c54f204faa97bda8"]

from _lib import energy, lives, me, target_cells, FULL_ENERGY, REFILL

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if action not in ACTS:
        return "NA"
    if energy(prev) != 0:
        return "NA"
    if lives(prev) == 0:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    tc = target_cells(prev, action)
    if tc is None or any(prev[r][c] == REFILL for r, c in tc):
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "FALSE"
    if lives(nxt) != lives(prev) - 1:
        return "FALSE"
    if energy(nxt) != FULL_ENERGY:
        return "FALSE"
    return "TRUE" if a != b else "FALSE"
