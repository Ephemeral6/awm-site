"""每条转移里，prev 的每个开关在 nxt 里要么原位、要么沿行移了恰好 CELL 格、要么被 me 踩住（pressed_toggle）；nxt 里新出现的开关要么是 me 离开露出来的、要么是从相邻 CELL 格（含 me 底下）移来的；本关登记过掉头两端（MOVERS）的行，开关不越过两端。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到返回 NA；要 ctx.level_prev，没有返回 NA。只断言开关的位置变化，不断言 HUD。"
NOTE = "第 4 关（第 263 步起）有一个每步沿行来回移 5 格的十字开关，14↔24 列之间掉头；另一个开关不动。v3：第 5 关两个开关都动（第 343–346 步），v2 的「只有第 4 关那一行、那两端」被推翻——端点改成按关按行查 MOVERS 表，没登记的行只断言步长不断言端点。"
EVIDENCE = ["9a65b576745d214b", "e43502d57737c575", "71b4707b7815955a", "d24af7650d91005b", "b9961df4776c9540",
            "3f03024c3351891b", "4a462522759b2a41", "724de42c63a285f7", "d37da6e5d86f160c", "38ff90609513ecd1", "96f6b26c304f4106"]

FOG_LEVELS = {6}

from _lib import me, toggles, pressed_toggle, alive, CELL, MOVERS

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx.get("level_prev") in FOG_LEVELS:
        return "NA"                                   # 迷雾关里开关随视野出没，位置连续性无从谈起
    if action not in ACTS or not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    lvl = int(ctx["level_prev"])
    tp, tn = set(toggles(prev)), set(toggles(nxt))
    pressed = pressed_toggle(prev, nxt, lvl)
    gone = tp - tn - ({pressed} if pressed else set())
    new = tn - tp
    revealed = {t for t in new if t == a}
    moved_in = new - revealed
    tracks = MOVERS.get(lvl, {})
    for t in list(gone) + list(moved_in):
        bounds = tracks.get(t[0])
        if bounds is not None and not (bounds[0] <= t[1] <= bounds[1]):
            return "FALSE"
    for t in gone:
        if not any(u[0] == t[0] and abs(u[1] - t[1]) == CELL for u in list(moved_in) + [b]):
            return "FALSE"
    for u in moved_in:
        if not any(t[0] == u[0] and abs(u[1] - t[1]) == CELL for t in list(tp) + [a]):
            return "FALSE"
    return "TRUE"
