"""每条转移里，prev 里可见的染色物件在 nxt 里要么在 paint_next 算出的位置（本关登记了轨道 PAINT_ORBIT 就沿轨道走一格，没登记就原地）、要么被 me 盖住（me(nxt) == 那个位置）；nxt 里新出现的染色物件必是 me 离开露出来的。"""
LEVEL = "L6"
SCOPE = "只看 ACTION1–4；换关返回 NA；energy(prev)==0 返回 NA；me(prev)/me(nxt) 定位不到返回 NA；要 ctx.level_prev，没有返回 NA；prev 里看不见染色物件返回 NA。只断言它的位置，不断言 HUD。"
NOTE = "第 0–4 关它不动。第 5 关（第 343 步起）它绕一个 3×3 格的方块逆时针转、每步一格、周期 8——轨道是从 47 步读数抄下来的循环表，不是从帧算的；别的关有别的轨道就让它挨打。"
EVIDENCE = ["4a462522759b2a41", "3f03024c3351891b", "724de42c63a285f7", "d37da6e5d86f160c", "824d6c5465bee376", "eec728ca0536f09a"]

FOG_LEVELS = {6}

from _lib import me, paints, paint_next, alive

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx.get("level_prev") in FOG_LEVELS:
        return "NA"                                   # 迷雾关里染色物件随视野出没（第 977 步）
    if action not in ACTS or not alive(prev):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    pp, pn = paints(prev), paints(nxt)
    if not pp:
        return "NA"
    lvl = int(ctx["level_prev"])
    for p in pp:
        q = paint_next(p, lvl)
        if q is None:
            return "FALSE"
        if q != b and q not in pn:
            return "FALSE"
    for q in pn:
        if q not in [paint_next(p, lvl) for p in pp] and q != a:
            return "FALSE"
    return "TRUE"
