"""这一局的词汇表 —— 每个定义都是假设，走闸。

实测（第 1–4 步）：玩家是 5×5 实心块，上两行色 12、下三行色 9；四个动作各移 5 格；
底部 rows 61–62 的色 11 长条每步左端缩 1 列。
"""
from __future__ import annotations

from geo import cells_of, bbox  # noqa: F401

CELL = 5
PHASE = (0, 4)          # 玩家块左上角：row ≡ 0, col ≡ 4 (mod 5)（从首帧 (45,34) 读出）
DELTA = {"ACTION1": (-5, 0), "ACTION2": (5, 0), "ACTION3": (0, -5), "ACTION4": (0, 5)}

ME_TOP = 12             # 玩家块上两行的颜色
ME_BOT = 9              # 玩家块下三行的颜色
FLOOR = 3               # 玩家离开后留下的颜色（走廊底色）
HUD_ROW = 61            # 能量条所在行（61、62 两行相同）
HUD_COLOR = 11


def me(g):
    """玩家块左上角 (top_row, left_col)：某个色 12 连通块恰好 10 格、bbox 为 2×5，其下 3 行 5 列全为色 9；
    这样的块必须恰好一个（第 2 关起 HUD 图样区也用色 12，所以不能再按「全图色 12 恰好 10 格」找）。"""
    from geo import components
    found = []
    for comp in components(cells_of(g, ME_TOP)):
        if len(comp) != 10:
            continue
        t, b, l, r = bbox(comp)
        if (b - t, r - l) != (1, 4):
            continue
        ok = True
        for dr in range(2, 5):
            for dc in range(5):
                rr, cc = t + dr, l + dc
                if rr >= len(g) or cc >= len(g[0]) or g[rr][cc] != ME_BOT:
                    ok = False
        if ok:
            found.append((t, l))
    return found[0] if len(found) == 1 else None


def energy(g):
    """能量条长度：第 HUD_ROW 行里色 11 的格数。"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_COLOR)


LIFE_COLOR = 8


def lives(g):
    """命数：第 HUD_ROW 行里色 8 的 2×2 块数（cols 56–63 处三个位）。"""
    return sum(1 for c in (56, 59, 62) if g[HUD_ROW][c] == LIFE_COLOR)


TOGGLE = {0, 1}         # 小十字（开关）的颜色；踩上去 HUD 图样会变（第 17 步）
REFILL = 11             # 主区里 3×3 的色 11 物件：与能量条同色，押它是补给（第 1 关两块，待实测）
PASSABLE = {FLOOR, 5, 0, 1, REFILL}   # 目标区只含这些颜色才能进（色 5 框边、开关色 0/1 实测可进；REFILL 待实测）


FULL_ENERGY = 42        # 开局与重置后能量条长度（第 0 步、第 24 步换关、第 46 步重置均为 42）


def alive(g):
    """能量 > 0 才是普通的一步；energy==0 时再动是掉命重置（第 46 步）。"""
    return energy(g) > 0


HUD_BG = 5              # HUD 图样区与目标框内的底色；图样 = 不是底色的格


def hud_pattern(g):
    """左下 HUD 的 3×3 图样：rows 55–60、cols 3–8，每 2×2 一格，取左上角是否不是底色 HUD_BG。返回 9 元组。
    （第 0/1 关图样色 9，第 2 关色 12——所以按「非底色」读，不按某个具体色。）"""
    return tuple(g[55 + 2 * i][3 + 2 * j] != HUD_BG for i in range(3) for j in range(3))


def hud_ink(g):
    """HUD 图样区里非底色的那个颜色；没有非底色格返回 None，不止一种返回 None。"""
    cs = {g[r][c] for r in range(55, 61) for c in range(3, 9)} - {HUD_BG}
    return next(iter(cs)) if len(cs) == 1 else None


def goal_frames(g):
    """主区里所有 7×7 色 5 空心框的 (top,left) 列表（第 5 关起一关不止一个框）。"""
    from geo import components
    found = []
    for comp in components(cells_of(g, 5)):
        t, b, l, r = bbox(comp)
        if (b - t, r - l) == (6, 6):
            found.append((t, l))
    return sorted(found)


def frame_pattern(g, f):
    """框 f 中央的 3×3 图样（是否非底色）。"""
    t, l = f
    return tuple(g[t + 2 + i][l + 2 + j] != HUD_BG for i in range(3) for j in range(3))


def frame_ink(g, f):
    """框 f 图样区里非底色的那个颜色；没有或不止一种返回 None。"""
    t, l = f
    cs = {g[t + 2 + i][l + 2 + j] for i in range(3) for j in range(3)} - {HUD_BG}
    return next(iter(cs)) if len(cs) == 1 else None


def hud_match_at(g, f):
    """HUD 与框 f 图样匹配：形状相同且颜色相同。"""
    return hud_pattern(g) == frame_pattern(g, f) and hud_ink(g) == frame_ink(g, f)


def goal_frame(g):
    """「当前目标框」：HUD 与之匹配的那个框；没有匹配的就取第一个（只为读图样用）；一个框都没有返回 None。"""
    fs = goal_frames(g)
    if not fs:
        return None
    for f in fs:
        if hud_match_at(g, f):
            return f
    return fs[0]


def goal_cell(g):
    """当前目标框内 5×5 区的 (top,left)。"""
    f = goal_frame(g)
    return None if f is None else (f[0] + 1, f[1] + 1)


def goal_cells(g):
    """所有框内 5×5 区的 (top,left)。"""
    return [(f[0] + 1, f[1] + 1) for f in goal_frames(g)]


def goal_pattern(g):
    """当前目标框中央的 3×3 图样；没有框返回 None。"""
    f = goal_frame(g)
    return None if f is None else frame_pattern(g, f)


def goal_ink(g):
    """当前目标框图样区的颜色；没有框返回 None。"""
    f = goal_frame(g)
    return None if f is None else frame_ink(g, f)


def hud_match(g):
    """HUD 与**某一个**框的图样匹配（形状相同且颜色相同；第 118 步：形状同色不同没过关）。一个框都没有返回 None。"""
    fs = goal_frames(g)
    if not fs:
        return None
    return any(hud_match_at(g, f) for f in fs)


def mirror_h(p):
    """3×3 图样左右镜像。"""
    return tuple(p[3 * i + (2 - j)] for i in range(3) for j in range(3))


def rot_cw(p):
    """3×3 图样顺时针转 90°：新 (i,j) = 旧 (2-j, i)。"""
    return tuple(p[3 * (2 - j) + i] for i in range(3) for j in range(3))


def entering_goal(g, action):
    """按 action 走一步的目标格是否是某个框内 5×5 区；算不出返回 None。"""
    tc = target_cells(g, action)
    gcs = goal_cells(g)
    if tc is None or not gcs:
        return None
    return tc[0] in gcs


def consumes_frame(g, action):
    """按 action 走一步会不会「消掉」一个框：最终落点是某个框内区、且 HUD 与那个框匹配。返回那个框的 (top,left)，否则 None；算不出也 None。"""
    eg = entering_goal(g, action)
    if not eg:
        return None
    b = landing(g, action)
    if b is None:
        return None
    f = (b[0] - 1, b[1] - 1)
    return f if f in goal_frames(g) and hud_match_at(g, f) else None


def levels_up(g, action):
    """按 action 走一步会不会换关：消掉一个框（consumes_frame）且它是帧里最后一个框（第 407 步：两框之一被消掉、关没换）。算不出返回 None。"""
    eg = entering_goal(g, action)
    if eg is None:
        return None
    if not eg:
        return False
    return consumes_frame(g, action) is not None and len(goal_frames(g)) == 1


def will_move(g, action):
    """True/False：目标区全为 PASSABLE、或目标格是一个染色物件（paints）、或这一步走进匹配的框（consumes_frame，含换关那一次）。算不出返回 None。"""
    tc = target_cells(g, action)
    if tc is None:
        return None
    if all(g[r][c] in PASSABLE for r, c in tc) or tc[0] in paints(g):
        return True
    return consumes_frame(g, action) is not None


def steps_on_toggle(g, action):
    """按 action 走一步的目标格是否正好是一个成形的开关（toggles）；算不出返回 None。
    （第 145 步：染色物件也含色 0，按颜色认会把它当开关——所以按形状认。）"""
    tc = target_cells(g, action)
    if tc is None:
        return None
    return tc[0] in toggles(g)


def steps_on_paint(g, action):
    """按 action 走一步的目标格是否正好是一个染色物件（paints）；算不出返回 None。"""
    tc = target_cells(g, action)
    if tc is None:
        return None
    return tc[0] in paints(g)


LINE = 1                # 直线的颜色：贴在墙格边缘、长 5 宽 1 的色 1 条（第 2 关首帧出现两条）
MAX_SLIDE = 16


def line_push(g, cell):
    """格 cell=(t,l) 的四边外侧一格是否贴着一条 5 格长的色 LINE 直线；有则返回被推开的方向 (dr, dc)，没有返回 None。
    主张：直线在左推向右、在右推向左、在上推向下、在下推向上（第 99 步：左侧直线、落点右滑 25 格）。"""
    t, l = cell
    H, W = len(g), len(g[0])
    if l - 1 >= 0 and all(g[t + k][l - 1] == LINE for k in range(CELL)):
        return (0, CELL)
    if l + CELL < W and all(g[t + k][l + CELL] == LINE for k in range(CELL)):
        return (0, -CELL)
    if t - 1 >= 0 and all(g[t - 1][l + k] == LINE for k in range(CELL)):
        return (CELL, 0)
    if t + CELL < H and all(g[t + CELL][l + k] == LINE for k in range(CELL)):
        return (-CELL, 0)
    return None


def _cell_passable(g, t, l):
    H, W = len(g), len(g[0])
    if not (0 <= t <= H - CELL and 0 <= l <= W - CELL):
        return False
    return all(g[t + dr][l + dc] in PASSABLE for dr in range(CELL) for dc in range(CELL))


def _fog_cell(g, t, l):
    """5×5 格全是色 5：不可能是框边（框边只有一格厚），只能是迷雾（第 6 关）——它下面是什么看不见。"""
    return 0 <= t <= len(g) - CELL and 0 <= l <= len(g[0]) - CELL and all(g[t + dr][l + dc] == 5 for dr in range(CELL) for dc in range(CELL))


def _slide(g, b, origin=None):
    """从目标格 b 起沿直线推的方向一格格滑，下一格不可进（含框内区：图样格是色 9，不在 PASSABLE 里）就停。
    第 117 步：HUD 已与框内图样一致，me 滑到框前就停了，没有滑进框——进框只能是直接的一步。
    第 194 步：被推回来时会穿过 me 自己的出发格 origin——它走后是底色，算可进。
    第 946 步：滑进迷雾（全 5 的格）——底下是什么看不见，落点算不出，返回 None。"""
    push = line_push(g, b)
    if push is None:
        return b
    for _ in range(MAX_SLIDE):
        nb = (b[0] + push[0], b[1] + push[1])
        if _fog_cell(g, nb[0], nb[1]):
            return None
        if nb != origin and not _cell_passable(g, nb[0], nb[1]):
            break
        b = nb
    return b


def landing(g, action):
    """me 按 action 走一步后最终停在哪：目标格可进就进；目标格是框内区且 HUD 图样匹配也进；
    进了之后目标格贴着直线就沿被推的方向滑（_slide）。不会动（挡住、越界、me 定位不到）返回 None。"""
    a = me(g)
    if a is None or action not in DELTA:
        return None
    d = DELTA[action]
    b = (a[0] + d[0], a[1] + d[1])
    if not (0 <= b[0] <= len(g) - CELL and 0 <= b[1] <= len(g[0]) - CELL):
        return None
    if not _cell_passable(g, b[0], b[1]):
        if b in paints(g):
            return b
        gc = goal_cell(g)
        if b in goal_cells(g) and hud_match_at(g, (b[0] - 1, b[1] - 1)):
            return b
        return None
    return _slide(g, b, a)


def target_cells(g, action):
    """me 按 action 走一步会覆盖的 5×5 格；me 定位不到或越界返回 None。"""
    a = me(g)
    if a is None or action not in DELTA:
        return None
    d = DELTA[action]
    t, l = a[0] + d[0], a[1] + d[1]
    if not (0 <= t <= len(g) - CELL and 0 <= l <= len(g[0]) - CELL):
        return None
    return [(t + dr, l + dc) for dr in range(CELL) for dc in range(CELL)]


TOGGLE_SHAPE = {(1, 2): 0, (2, 1): 1, (2, 2): 0, (2, 3): 0, (3, 2): 1}   # 开关在 5×5 格位内的图样（首帧 (30,19) 格读出）


PAINT_SHAPE = {(1, 1): 9, (1, 2): 14, (1, 3): 14, (2, 1): 9, (2, 2): 0, (2, 3): 8,
               (3, 1): 12, (3, 2): 12, (3, 3): 8}   # 染色物件在 5×5 格位内的图样（第 2 关 (45,29) 格读出）
PAINT_NEXT = {12: 9, 9: 14, 14: 8, 8: 12}   # 踩一次染色物件 HUD 颜色怎么变：第 145 步 12→9、第 147 步 9→14、第 204 步 14→8、第 206 步 8→12（四色循环闭合）


def paints(g):
    """帧里所有按格位对齐、恰好呈 PAINT_SHAPE 的染色物件，返回其格左上角列表。"""
    H, W = len(g), len(g[0])
    out = []
    for t in range(PHASE[0] % CELL, H - CELL + 1, CELL):
        for l in range(PHASE[1] % CELL, W - CELL + 1, CELL):
            if all(g[t + dr][l + dc] == v for (dr, dc), v in PAINT_SHAPE.items()):
                out.append((t, l))
    return out


def toggles(g):
    """帧里所有按格位对齐的开关：外圈 16 格全 FLOOR、内 3×3 只含开关色 0/1 与 FLOOR、且至少一格色 0。返回格左上角列表。
    （第 0–2 关是同一个十字形 TOGGLE_SHAPE；第 3 关形状变了、没有色 1——所以按「外圈底色 + 内圈只有开关色」认，不按固定图样。）"""
    H, W = len(g), len(g[0])
    out = []
    for t in range(PHASE[0] % CELL, H - CELL + 1, CELL):
        for l in range(PHASE[1] % CELL, W - CELL + 1, CELL):
            ring = all(g[t + dr][l + dc] == FLOOR for dr in range(CELL) for dc in range(CELL) if dr in (0, 4) or dc in (0, 4))
            if not ring:
                continue
            inner = [g[t + dr][l + dc] for dr in range(1, 4) for dc in range(1, 4)]
            if all(v in TOGGLE or v == FLOOR for v in inner) and 0 in inner:
                out.append((t, l))
    return out


def toggle_inner(g, cell):
    """开关格 cell 的内 3×3 图样 {(dr,dc): 色}。"""
    t, l = cell
    return {(dr, dc): g[t + dr][l + dc] for dr in range(1, 4) for dc in range(1, 4)}


CROSS_INNER = {(dr, dc): TOGGLE_SHAPE.get((dr, dc), FLOOR) for dr in range(1, 4) for dc in range(1, 4)}


def toggle_is_cross(g, cell):
    """开关是不是第 0–2 关那种十字形（TOGGLE_SHAPE）；第 3 关的开关内图样不同、效果也不同。"""
    return toggle_inner(g, cell) == CROSS_INNER


def steps_on_cross(g, action):
    """按 action 走一步的目标格是不是十字形开关；算不出返回 None。"""
    tc = target_cells(g, action)
    if tc is None:
        return None
    return tc[0] in toggles(g) and toggle_is_cross(g, tc[0])


def toggle_hidden(g):
    """帧里一个成形的开关都找不到 → 玩家正踩着开关（主张：每关恰好一个开关）。"""
    return len(toggles(g)) == 0


def toggle_pressed(prev, nxt):
    """这一步踩到了哪些开关：prev 里看得见、nxt 里不见了的开关（被 me 盖住）。
    对会动的开关也成立——它和 me 同时到同一格，prev 里它还在旧位置（第 278 步）。"""
    return [t for t in toggles(prev) if t not in toggles(nxt)]


def pressed_toggle(prev, nxt, level=None):
    """这一步 me 踩到的那个开关在 prev 里的位置；没踩到返回 None。
    判「踩到」看数量：nxt 里的开关数（扣掉 me 离开露出来的）比 prev 少，才是有一个被盖住了；
    单看「prev 有、nxt 没有」会把移走的开关当成被踩（第 282 步）。哪一个：与 me(nxt) 同格，否则同行/同列且相距 CELL 的那个。
    给了 level 才认得「会动的开关在 me 底下随 me 走」那种踩法（第 279、280 步）。"""
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return None
    tp, tn = toggles(prev), toggles(nxt)
    if level is not None and a != b and mover_hidden(prev, level) and mover_hidden(nxt, level):
        return b                                  # 会动的开关在 me 底下随 me 同向走了一格：仍算踩到
    revealed = 1 if a in tn else 0
    if len(tn) - revealed >= len(tp):
        return None
    gone = [t for t in tp if t not in tn]
    for t in gone:
        if t == b:
            return t
    for t in gone:
        if (t[0] == b[0] and abs(t[1] - b[1]) == CELL) or (t[1] == b[1] and abs(t[0] - b[0]) == CELL):
            return t
    return None                                       # 消失的开关离 me 落点很远：不是被踩，是出了视野（第 958 步迷雾）


N_TOGGLES = {0: 1, 1: 1, 2: 1, 3: 1, 4: 2, 5: 2, 6: 2}       # 每关开关个数（各关开局帧数出来的；第 6 关按合并地图数）
# 每关会动的开关：所在行 -> 掉头两端列。端点是观测到掉头才登记的；None = 还没见它掉头。
# 第 4 关 row 35：14↔24（走廊 9..24，却不去 9——端点不是墙决定的，规律未知，只记读数）。第 5 关两个开关都动（第 343 步起）。
MOVERS = {4: {35: (14, 24)}, 5: {10: (14, 34), 40: (14, 34)}}   # 第 5 关两行端点：第 347–355 步各观测到两次掉头
# 沿列上下走的开关：所在列 -> 掉头两端行。第 6 关 col 54：第 990–998 步读出 30→25→20→15→10→15→20，端点 10↔30（30 端只见一次）。
MOVERS_V = {6: {54: (10, 30)}}

# 会动的染色物件：按关登记它的轨道（格左上角的循环序列）。第 5 关第 343–389 步读出：绕 (25,24) 那格逆时针一圈 8 格、周期 8。
PAINT_ORBIT = {5: [(30, 24), (30, 19), (25, 19), (20, 19), (20, 24), (20, 29), (25, 29), (30, 29)]}


def paint_next(pos, level):
    """会动的染色物件下一步在哪：沿本关轨道走一格；本关没登记轨道就原地不动；pos 不在轨道上返回 None。"""
    orbit = PAINT_ORBIT.get(level)
    if orbit is None:
        return pos
    if pos not in orbit:
        return None
    return orbit[(orbit.index(pos) + 1) % len(orbit)]


def pressed_paint(prev, nxt, level=None):
    """这一步 me 是否踩到了染色物件：prev 里看得见它、nxt 里看不见（被 me 盖住），且 me 动了；
    或者（给了 level 且本关它会动）它本来就在 me 底下、沿轨道走的下一格正是 me 的落点（第 654/655 步：连踩两次）。返回 prev 里它的位置或 None。"""
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return None
    pp, pn = paints(prev), paints(nxt)
    if pp and len(pn) < len(pp):
        return pp[0]
    if level is not None and level in PAINT_ORBIT and not pp and not pn and paint_next(a, level) == b:
        return a
    return None


def mover_rows(level):
    return list(MOVERS.get(level, {}))


def mover_cols(level):
    return list(MOVERS_V.get(level, {}))


def mover_hidden(g, level):
    """会动的开关此刻是否被 me 盖着：me 在本关某个会动开关的行（或列）上，且帧里可见的开关比本关该有的少。"""
    a = me(g)
    if a is None or (a[0] not in mover_rows(level) and a[1] not in mover_cols(level)):
        return False
    return len(toggles(g)) < N_TOGGLES.get(level, 1)


def mover_next(pos, vel, level):
    """会动的开关下一步在哪、速度变成多少：pos+vel 越过登记的两端就先掉头再走；两端没登记返回 None（算不出）。
    行表 MOVERS 里的沿行走（vel 是列增量），列表 MOVERS_V 里的沿列走（vel 是行增量）。"""
    t, l = pos
    bounds = MOVERS.get(level, {}).get(t)
    if bounds is not None:
        nl = l + vel
        if nl < bounds[0] or nl > bounds[1]:
            vel = -vel
            nl = l + vel
        return (t, nl), vel
    bounds = MOVERS_V.get(level, {}).get(l)
    if bounds is not None:
        nt = t + vel
        if nt < bounds[0] or nt > bounds[1]:
            vel = -vel
            nt = t + vel
        return (nt, l), vel
    return None


def under(g, a=None):
    """推断玩家块下面盖着什么：帧里看不见开关则按 TOGGLE_SHAPE 画开关；其余格若块外同一行两侧最近的格都是色 5，
    或同一列两侧最近的格都是色 5，则该格为 5，否则为 FLOOR。返回 {(r,c): 色}；me 定位不到返回 None。"""
    if a is None:
        a = me(g)
    if a is None:
        return None
    t, l = a
    b, r = t + CELL - 1, l + CELL - 1
    H, W = len(g), len(g[0])
    out = {}
    for rr in range(t, b + 1):
        for cc in range(l, r + 1):
            row5 = l - 1 >= 0 and r + 1 < W and g[rr][l - 1] == 5 and g[rr][r + 1] == 5
            col5 = t - 1 >= 0 and b + 1 < H and g[t - 1][cc] == 5 and g[b + 1][cc] == 5
            out[(rr, cc)] = 5 if (row5 or col5) else FLOOR
    if toggle_hidden(g):
        for (dr, dc), v in TOGGLE_SHAPE.items():
            out[(t + dr, l + dc)] = v
    return out


def leave_ok(prev, a, nxt, left):
    """离开区 left（me 走后露出来的格）在 nxt 里是否合乎「覆盖不是涂改」：
    要么等于 under（底 + 十字开关）；要么等于 under_paint（踩着染色物件）；
    要么露出的是一个开关形状的格（外圈底、内 3×3 只含开关色/FLOOR）——不看全图有没有别的开关，第 4 关起一关不止一个。
    走进匹配的框那一步（第 407 步）框整个消失，离开区里原属框边的格变成 FLOOR 也算合。"""
    b = me(nxt)
    consumed = None
    if b is not None:
        f = (b[0] - 1, b[1] - 1)
        if f in goal_frames(prev) and hud_match_at(prev, f):
            consumed = f
    for u in (under(prev, a), under_paint(prev, a)):
        if u is not None and all(nxt[r][c] == u[(r, c)] or (consumed and _in_frame(consumed, r, c) and nxt[r][c] == FLOOR)
                                 for (r, c) in left):
            return True
    t, l = a
    inner = {(t + dr, l + dc) for dr in range(1, 4) for dc in range(1, 4)}
    u = under(prev, a)
    ok = True
    for (r, c) in left:
        if (r, c) in inner:
            if nxt[r][c] not in TOGGLE and nxt[r][c] != FLOOR:
                ok = False
        elif nxt[r][c] != u[(r, c)]:
            ok = False
    return ok


def _in_frame(f, r, c):
    return f[0] <= r <= f[0] + 6 and f[1] <= c <= f[1] + 6


def under_paint(g, a=None):
    """under 的另一种可能：玩家正踩着染色物件（第 146 步：离开后它原样露出来，是持久物件）。
    帧里看得见染色物件时不可能，返回 None；看不见时返回 under 叠上 PAINT_SHAPE。
    看不见 ≠ 踩着（第 0/1 关根本没有它），所以这只是「可能」，assert_ 二选一、apply 不认领这 9 格。"""
    if len(paints(g)) > 0:
        return None
    u = under(g, a)
    if u is None:
        return None
    if a is None:
        a = me(g)
    t, l = a
    for (dr, dc), v in PAINT_SHAPE.items():
        u[(t + dr, l + dc)] = v
    return u


PAINT_LEVELS = {2, 3, 4, 5, 6}     # 见过染色物件的关（第 0/1 关没有）
CROSS_ONLY_LEVELS = {0, 1, 2}      # 开关全是十字形的关：me 盖着开关时 under 画的 TOGGLE_SHAPE 就是对的
N_NONCROSS = {3: 1, 4: 1, 5: 1, 6: 1}      # 每关非十字开关的个数（各关地图数出来的）
NONCROSS_SHAPE = {(1, 1): 0, (1, 2): 3, (1, 3): 3, (2, 1): 3, (2, 2): 0, (2, 3): 0, (3, 1): 3, (3, 2): 0, (3, 3): 3}   # 非十字开关内图样（第 3–6 关同一个）
FOG_LEVELS_LIB = {6}               # 迷雾关（fog_disc）
PAINT_HOME = {6: (40, 9)}          # 迷雾关里不动的染色物件所在格（合并地图读出）
NONCROSS_HOME = {6: (40, 19)}      # 迷雾关里不动的非十字开关所在格


def under_known(g, a=None, level=None):
    """me 底下盖着什么，按「持久物件 + 每关个数」推：本关该有的染色物件看不见 → 它在 me 底下（画 PAINT_SHAPE）；
    该有的开关少一个 → 它在 me 底下（十字或非十字看少的是哪种）；都齐 → 底下就是 under 算的底。
    level 不给就退回保守做法：内 3×3 不认领。"""
    u = under(g, a)
    if u is None:
        return None
    if a is None:
        a = me(g)
    t, l = a
    if level is None:
        for dr in range(1, 4):
            for dc in range(1, 4):
                u.pop((t + dr, l + dc), None)
        return u
    base = {(t + dr, l + dc): (5 if u[(t + dr, l + dc)] == 5 else FLOOR) for dr in range(5) for dc in range(5)}
    if level in FOG_LEVELS_LIB:
        base = {k: FLOOR for k in base}               # 迷雾关里两侧的色 5 多半是迷雾不是框边（链预测帧里迷雾不随 me 走），别据此推 5
    u = dict(base)
    if level in FOG_LEVELS_LIB:
        # 迷雾关里「看不见」不等于「在底下」：只有 me 正站在该物件登记的格上才画它（物件不动、位置从合并地图读出）
        if (t, l) == PAINT_HOME.get(level):
            for (dr, dc), v in PAINT_SHAPE.items():
                u[(t + dr, l + dc)] = v
        elif (t, l) == NONCROSS_HOME.get(level):
            for (dr, dc), v in NONCROSS_SHAPE.items():
                u[(t + dr, l + dc)] = v
        return u

    def _unclaim_inner():
        return u                                      # 分不清底下是什么时按底色填：露出来的物件由它自己的概念（mover_shifts / paint_orbits）管

    if level in PAINT_LEVELS and len(paints(g)) == 0:
        if level in PAINT_ORBIT:
            return _unclaim_inner()                   # 会动的染色物件在底下：它下一步走开，露出什么由 paint_orbits 管
        for (dr, dc), v in PAINT_SHAPE.items():
            u[(t + dr, l + dc)] = v
        return u
    tg = toggles(g)
    if len(tg) < N_TOGGLES.get(level, 1):
        if mover_hidden(g, level):
            return _unclaim_inner()                   # 会动的开关在底下：它下一步走开，露出什么由 mover_shifts 管
        n_movers = len(mover_rows(level)) + len(mover_cols(level))
        movers_visible = sum(1 for x in tg if x[0] in mover_rows(level) or x[1] in mover_cols(level))
        if n_movers and movers_visible < n_movers:
            return _unclaim_inner()                   # 少的那个可能是在路上的会动开关（链预测帧不画它），分不清就不认领
        vis_noncross = sum(1 for x in tg if not toggle_is_cross(g, x))
        shape = NONCROSS_SHAPE if vis_noncross < N_NONCROSS.get(level, 0) else TOGGLE_SHAPE
        for (dr, dc), v in shape.items():
            u[(t + dr, l + dc)] = v
    return u


def walls(g):
    """阻挡格集合：不在 PASSABLE 里、也不是玩家自己的格子。"""
    return frozenset((r, c) for r, row in enumerate(g) for c, v in enumerate(row)
                     if v not in PASSABLE and v not in (ME_TOP, ME_BOT))
