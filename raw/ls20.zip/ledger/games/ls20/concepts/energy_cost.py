"""ACTION1–4 让 me 移动时 energy 减 k：k 按关查 COST_BY_LEVEL 表（第 0 关 1、第 1 关 2、第 2 关 2、第 3 关 1、第 4 关 2、第 5 关 1、第 6 关 2；只登记观测过的关），第 0 关踩开关 k=0；BLOCKED_COSTS 里的关（第 6 关）撞墙不动也扣同样的 k；能量条从左端缩，减到 0 为止。"""
LEVEL = "L4"
SCOPE = "只看 ACTION1–4；要 ctx.level_prev，没有返回 NA；关不在 COST_BY_LEVEL 里返回 NA（没观测过）；换关返回 NA；energy(prev)==0 返回 NA；me 不动且本关不在 BLOCKED_COSTS 返回 NA（那是 energy_tick 管的）；目标区含 REFILL 返回 NA（那是 refill 管的）。"
NOTE = "v1 只管普通步、线性 level+1。v2：把踩开关的步也收进来。v4：第 92 步第 2 关扣 2 不是 3，改成「第 0 关 1、之后 2」。v5：第 188 步第 3 关扣 1，「之后都 2」也被推翻——读数 1/2/2/1 看不出公式，改成按关查表、没见过的关 NA；每进新关第一步都是它的考试。"
EVIDENCE = ["96a7f535e5c750b0", "7ebd25ad5f38261b", "2542e684fdabf403", "c0b15395f53b9ab5", "ce46bed81d87320e", "aa57ddc00366f899", "56abd87c9042a128", "de353117d53569fc", "3f36fc9a678ec598", "1343d15c46483cad", "bb57242f98dbe007"]

COST_BY_LEVEL = {0: 1, 1: 2, 2: 2, 3: 1, 4: 2, 5: 1, 6: 2}
BLOCKED_COSTS = {4, 6}   # 这些关里撞墙不动也照扣（第 6 关第 927/928 步；第 4 关第 1260–1268 步 7 次扣 2）；第 0/2 关撞墙不扣（各 1 次观测）

from _lib import energy, me, steps_on_toggle, target_cells, will_move, levels_up, alive, REFILL, HUD_ROW, HUD_COLOR, FLOOR

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}


def cost(prev, action, ctx):
    """这一步该扣几格；算不出返回 None；目标区含 REFILL 也返回 None（那是 refill 管的）。"""
    if not ctx or ctx.get("level_prev") is None:
        return None
    lv = int(ctx["level_prev"])
    tc = target_cells(prev, action)
    if tc is None or any(prev[r][c] == REFILL for r, c in tc):
        return None
    tg = steps_on_toggle(prev, action)
    if tg is None:
        return None
    if lv not in COST_BY_LEVEL:
        return None
    k = COST_BY_LEVEL[lv]
    return 0 if (tg and lv == 0) else k


def assert_(prev, action, nxt, ctx=None):
    if action not in ACTS:
        return "NA"
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") != ctx.get("level_prev"):
        return "NA"
    e0 = energy(prev)
    if e0 == 0:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    if a == b and int(ctx["level_prev"]) not in BLOCKED_COSTS:
        return "NA"
    k = cost(prev, action, ctx)
    if k is None:
        return "NA"
    return "TRUE" if energy(nxt) == max(0, e0 - k) else "FALSE"


def apply(prev, action, ctx=None):
    if action not in ACTS or not alive(prev):
        return None
    if levels_up(prev, action):
        return None
    mv = will_move(prev, action)
    k = cost(prev, action, ctx)
    if mv is None or not mv or k is None:
        return None
    row = prev[HUD_ROW]
    cols = sorted(c for c, v in enumerate(row) if v == HUD_COLOR)
    if not cols:
        return None
    out = {}
    for c in cols[:k]:
        out[(HUD_ROW, c)] = FLOOR
        out[(HUD_ROW + 1, c)] = FLOOR
    if k == 0:                                  # 免费的一步：认领最左那格不变，让「没扣」也能被判错
        out[(HUD_ROW, cols[0])] = HUD_COLOR
        out[(HUD_ROW + 1, cols[0])] = HUD_COLOR
    return out
