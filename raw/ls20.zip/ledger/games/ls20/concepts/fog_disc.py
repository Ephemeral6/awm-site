"""第 6 关（FOG_LEVELS）：主区（行 < 55）里离 me 中心欧氏距离 > FOG_R + 1.5 的格在 nxt 里全是色 FOG（迷雾）；其余关不受本条约束。"""
LEVEL = "L7"
SCOPE = "只看 ACTION1–4；要 ctx.level_prev，不在 FOG_LEVELS 里返回 NA；换关返回 NA；me(nxt) 定位不到返回 NA。只断言 nxt 帧里迷雾外圈的形状，不断言圈内（圈内的色 5 可能是边框或真物件）。"
NOTE = "第 926–935 步：第 6 关帧外圈全是色 5，圆盘随 me 移动；实测可见格最远 20.6（欧氏）。v1 取 19 被 20.6 打脸，v2 取 20（阈值 21.5）。"
EVIDENCE = ["3f36fc9a678ec598", "42273635017b051b", "1599da37ef2b2ed7", "1d79ae5ddc0a2e90", "c7b0e87b3f012094"]

import math
from _lib import me

ACTS = {"ACTION1", "ACTION2", "ACTION3", "ACTION4"}
FOG_LEVELS = {6}
FOG = 5
FOG_R = 20.0


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") not in FOG_LEVELS or ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ACTS:
        return "NA"
    b = me(nxt)
    if b is None:
        return "NA"
    cy, cx = b[0] + 2, b[1] + 2
    for r in range(55):
        for c in range(64):
            d = math.hypot(r - cy, c - cx)
            if d > FOG_R + 1.5 and nxt[r][c] != FOG:
                return "FALSE"
    return "TRUE"
