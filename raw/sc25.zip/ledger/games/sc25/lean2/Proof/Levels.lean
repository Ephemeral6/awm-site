/-
# Levels —— 每一关一条定理（**自动生成，不要手改**：`python lean2/export_levels.py`）

    L<n>_play_len    这一段有几步（切歪了会是空表，空表让下一条平凡为真——所以钉住它）
    L<n>_start_seen  开局状态投影回去，和语料里那一帧读出来的 World 一模一样（开局是**从帧里读出来的**）
    L<n>_trace       沿着真人走过的那条路，模型**每一帧都和观测对上**——只有开局是观测给的，后面全是模型自己算的
    L<n>_winnable    这一关走得通（见证 = 那条路再加上过关那一脚），而且开局时并不已经站在插座里

「走不通」那一种这一局没有：六关在被成绩单认证的那一段里全部走通过。
**每关核过的步数**写在每一关那一段的注释里，也写进 readings.json 与页面。

## 口径

  · 路只取**被成绩单认证的那一段**（corpus.py 对过账：逐关步数和成绩单的 level_actions 一致）。
  · 开局状态从那一关第一帧读出来（`fiber` 的第一个；开局我是 4，戴外圈的框看得见，纤维只有一个元素）。
    模型用的版面是整关拼出来的（Replay.lean 文件头写着多知道了哪几位）。
  · 这一段里没有 RESET，所以没有用到「重来一次放回开局」那条假设；
    那条假设在逐条那一层的 4 次 RESET 上也不接手（模型在 RESET 那一步说不出话）——
    **它在这批语料上没有一次被驳倒的机会**，这一句原样写在页面上。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

open Replay

def dummySt : St := { me := ⟨0, 0, 0, .U⟩, pad := [], erased := [], eaten := [], gate := 0 }

/-- 开局状态：那一帧的纤维里的第一个。 -/
def startOf (lv seq : Nat) : St :=
  match (rowAt seq).prev with
  | some o => ((fiber (board lv) o).head?).getD dummySt
  | none => dummySt


/-- 第 0 关：认证段 seq 257..268，路 11 步（之前 seq [256] 是会话第一下，世界把它吞了，不进路），过关那一脚是 seq 268。 -/
def L0_start : St := startOf 0 257
def L0_play : List (Act × World) := playFrom 257 11
def L0_acts : List Act := actsFrom 257 12

/-- 第 1 关：认证段 seq 269..273，路 4 步，过关那一脚是 seq 273。 -/
def L1_start : St := startOf 1 269
def L1_play : List (Act × World) := playFrom 269 4
def L1_acts : List Act := actsFrom 269 5

/-- 第 2 关：认证段 seq 274..285，路 11 步，过关那一脚是 seq 285。 -/
def L2_start : St := startOf 2 274
def L2_play : List (Act × World) := playFrom 274 11
def L2_acts : List Act := actsFrom 274 12

/-- 第 3 关：认证段 seq 286..315，路 29 步，过关那一脚是 seq 315。 -/
def L3_start : St := startOf 3 286
def L3_play : List (Act × World) := playFrom 286 29
def L3_acts : List Act := actsFrom 286 30

/-- 第 4 关：认证段 seq 316..365，路 49 步，过关那一脚是 seq 365。 -/
def L4_start : St := startOf 4 316
def L4_play : List (Act × World) := playFrom 316 49
def L4_acts : List Act := actsFrom 316 50

/-- 第 5 关：认证段 seq 366..401，路 35 步，过关那一脚是 seq 401。 -/
def L5_start : St := startOf 5 366
def L5_play : List (Act × World) := playFrom 366 35
def L5_acts : List Act := actsFrom 366 36

end Levels
end Game

/-! 定理写在命名空间外面：装置的 `ledger/lean_check.py` 按**不带前缀的名字**逐条 `#print axioms`。 -/

open Game Game.Replay Game.Levels

/-! ## 第 0 关：**逐帧核过的步数 11**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L0_play_len : (L0_play : List (Act × World)).length = 11 := by decide +kernel

theorem L0_start_seen :
    see (board 0) L0_start = ((rowAt 257).prev.getD dummyWorld : World) := by decide +kernel

theorem L0_trace : traceOk (board 0) L0_start (L0_play : List (Act × World)) = true := by
  decide +kernel

theorem L0_winnable : Winnable (board 0) L0_start ∧ isGoal (board 0) L0_start = false :=
  ⟨⟨L0_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L0_play_len
#print axioms L0_start_seen
#print axioms L0_trace
#print axioms L0_winnable

/-! ## 第 1 关：**逐帧核过的步数 4**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L1_play_len : (L1_play : List (Act × World)).length = 4 := by decide +kernel

theorem L1_start_seen :
    see (board 1) L1_start = ((rowAt 269).prev.getD dummyWorld : World) := by decide +kernel

theorem L1_trace : traceOk (board 1) L1_start (L1_play : List (Act × World)) = true := by
  decide +kernel

theorem L1_winnable : Winnable (board 1) L1_start ∧ isGoal (board 1) L1_start = false :=
  ⟨⟨L1_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L1_play_len
#print axioms L1_start_seen
#print axioms L1_trace
#print axioms L1_winnable

/-! ## 第 2 关：**逐帧核过的步数 11**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L2_play_len : (L2_play : List (Act × World)).length = 11 := by decide +kernel

theorem L2_start_seen :
    see (board 2) L2_start = ((rowAt 274).prev.getD dummyWorld : World) := by decide +kernel

theorem L2_trace : traceOk (board 2) L2_start (L2_play : List (Act × World)) = true := by
  decide +kernel

theorem L2_winnable : Winnable (board 2) L2_start ∧ isGoal (board 2) L2_start = false :=
  ⟨⟨L2_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L2_play_len
#print axioms L2_start_seen
#print axioms L2_trace
#print axioms L2_winnable

/-! ## 第 3 关：**逐帧核过的步数 29**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L3_play_len : (L3_play : List (Act × World)).length = 29 := by decide +kernel

theorem L3_start_seen :
    see (board 3) L3_start = ((rowAt 286).prev.getD dummyWorld : World) := by decide +kernel

theorem L3_trace : traceOk (board 3) L3_start (L3_play : List (Act × World)) = true := by
  decide +kernel

theorem L3_winnable : Winnable (board 3) L3_start ∧ isGoal (board 3) L3_start = false :=
  ⟨⟨L3_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L3_play_len
#print axioms L3_start_seen
#print axioms L3_trace
#print axioms L3_winnable

/-! ## 第 4 关：**逐帧核过的步数 49**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L4_play_len : (L4_play : List (Act × World)).length = 49 := by decide +kernel

theorem L4_start_seen :
    see (board 4) L4_start = ((rowAt 316).prev.getD dummyWorld : World) := by decide +kernel

theorem L4_trace : traceOk (board 4) L4_start (L4_play : List (Act × World)) = true := by
  decide +kernel

theorem L4_winnable : Winnable (board 4) L4_start ∧ isGoal (board 4) L4_start = false :=
  ⟨⟨L4_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L4_play_len
#print axioms L4_start_seen
#print axioms L4_trace
#print axioms L4_winnable

/-! ## 第 5 关：**逐帧核过的步数 35**（外加过关那一脚由 `_winnable` 核：模型说那一步之后 isGoal）。 -/

theorem L5_play_len : (L5_play : List (Act × World)).length = 35 := by decide +kernel

theorem L5_start_seen :
    see (board 5) L5_start = ((rowAt 366).prev.getD dummyWorld : World) := by decide +kernel

theorem L5_trace : traceOk (board 5) L5_start (L5_play : List (Act × World)) = true := by
  decide +kernel

theorem L5_winnable : Winnable (board 5) L5_start ∧ isGoal (board 5) L5_start = false :=
  ⟨⟨L5_acts, by decide +kernel, by decide +kernel⟩, by decide +kernel⟩

#print axioms L5_play_len
#print axioms L5_start_seen
#print axioms L5_trace
#print axioms L5_winnable
