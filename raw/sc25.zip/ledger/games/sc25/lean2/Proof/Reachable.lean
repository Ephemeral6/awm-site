/-
# Reachable —— 这个局面做不做得了

    Winnable   b s  :=  ∃ as, 每一下都合法 ∧ 照着走中途到过 isGoal
    Unsolvable b s  :=  ∀ as, 每一下都合法 → 照着走从没到过 isGoal

## 合法的一步

方向键四个、点击（坐标在帧里：0 ≤ x, y < 64）。**RESET 不合法**——模型在 RESET 那一步说不出话（`na`），
所以 `Unsolvable` 的准确意思是「**不经过 RESET** 就到不了 isGoal」。这半句不许含糊过去。

## 骨架（原样搬自模板，整份文件唯一做归纳的地方）

找一个每走一步都保持、而且和 isGoal 矛盾的性质 Φ，从满足 Φ 的局面出发，**任何动作串都到不了 isGoal**。
与盘面多大、动作串多长都无关，不枚举任何状态。

这一局六关在语料里**全部走通过**，所以没有一关需要这把骨架；它留在这里，是给「这一关走不通」
那种主张准备的——那种主张只许由它证出来，不许由「搜不到路」推出来。

`stepsReachGoal b s as`：沿 as 一步一步 step 下去，中途（含起点）是不是到过 isGoal。

定理写在命名空间外面：装置的 `ledger/lean_check.py` 按**不带前缀的名字**逐条 `#print axioms`。
-/

import Obj.Model.St
import Obs.Check

namespace Game

def Act.legal : Act → Bool
  | .dir _ => true
  | .click x y => x < 64 && y < 64
  | .reset => false

/-- 模型说不出话（na）的那一步，这条路到此为止、算没到。 -/
def stepsReachGoal (b : Board) (s : St) : List Act → Bool
  | [] => isGoal b s
  | a :: rest =>
    isGoal b s ||
      (match step b s a with
       | .ok s' => stepsReachGoal b s' rest
       | .na => false)

def Winnable (b : Board) (s : St) : Prop :=
  ∃ as : List Act, as.all Act.legal = true ∧ stepsReachGoal b s as = true

/-- **不经过 RESET** 就到不了 isGoal（RESET 不是合法的一步，见文件头）。 -/
def Unsolvable (b : Board) (s : St) : Prop :=
  ∀ as : List Act, as.all Act.legal = true → stepsReachGoal b s as = false

end Game

open Game

theorem unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, Act.legal a = true → P s → step b s a = Res.ok s' → P s')
    (hgoal : ∀ s, P s → isGoal b s = false) :
    ∀ s, P s → Unsolvable b s := by
  intro s hp as
  induction as generalizing s with
  | nil => intro _; simp [stepsReachGoal, hgoal s hp]
  | cons a t ih =>
    intro hall
    simp only [List.all_cons, Bool.and_eq_true] at hall
    simp only [stepsReachGoal, hgoal s hp, Bool.false_or]
    cases hstep : step b s a with
    | na => rfl
    | ok s' => exact ih s' (hkeep s s' a hall.1 hp hstep) hall.2

/-- 两句话不能同时成立：一条合法的路 step 到过 isGoal，就不可能「每一条合法的路都到不了」。 -/
theorem not_both (b : Board) (s : St) :
    (∃ as : List Act, as.all Act.legal = true ∧ stepsReachGoal b s as = true) → Unsolvable b s → False := by
  intro ⟨as, hl, hw⟩ hu
  rw [hu as hl] at hw
  exact Bool.false_ne_true hw

#print axioms unsolvable_of_invariant
#print axioms not_both
