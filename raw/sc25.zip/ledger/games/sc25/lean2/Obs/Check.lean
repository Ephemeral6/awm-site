/-
# Check —— **判据层**：模型面对观测。**这一份里没有一条定理**，尺子不自证。

    see        模型的状态投影成一帧看得见的 `World`（和 Python 读出来的那种一模一样）
    fiber      一帧观测对应哪几个 `St`（`gate` 在我是 2 时看不见，所以可能不止一个）
    judge      **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比（逐条，三值）
    traceOk    **一整条路**对不对：只有开局是观测给的，后面全是模型自己算的（每关）

两把尺子分量差得很远：`judge` 每步都被观测拉回正轨，`traceOk` 错一步后面全错。

## 纤维

一帧观测读不全模型的状态：抹掉了哪几个框、吃掉了哪几坨燃料看得见，而**戴外圈的是哪一个 4×4 搬家框**
在我是 2 时看不见。所以 `fiber` 从观测读出看得见的那几位，看不见的那一位把所有取值都列出来，
再逐个核「投影回去和观测一模一样」。判一条转移按纤维判：

    有一个对上了                        ⇒ agree
    都没对上，但一个一致的 St 都没有     ⇒ na（读不出，不是反对）
    有一致的 St，都没对上                ⇒ disagree
-/

import Step
import Obj.World

namespace Game

def see (b : Board) (s : St) : World :=
  { me := s.me, pad := s.pad, legends := b.legends, ground := render b s }

/-- 这一格我看得见吗（不在我身下）。 -/
def visible (o : World) (p : Nat × Nat) : Bool := !(o.me.cells.contains p)

/-- 抹掉了哪几个框：那一圈看得见的格里有一格不再是抹除色，**或者**场上这个标本色看得见的格里
    有一格不再是标本色（我整块站在那一圈上时，圈看不见，但墙没了看得见）。 -/
def erasedIn (b : Board) (o : World) : List Nat :=
  ((List.range b.eboxes.length).zip b.eboxes).filterMap fun q =>
    if q.2.ring.any (fun p => visible o p && colorAt o.ground p != ERASE)
       || q.2.specCells.any (fun p => visible o p && colorAt o.ground p != q.2.spec)
    then some q.1 else none

/-- 吃掉了哪几坨燃料：看得见的格里有一格不再是燃料，**或者**我正压着它
    （模型里压到就吃，站在一坨没吃的燃料上的状态根本走不到）。 -/
def eatenIn (b : Board) (o : World) (er : List Nat) : List Nat :=
  let mine := o.me.cells
  let gone := fun (cs : List (Nat × Nat)) =>
    cs.any (fun p => visible o p && colorAt o.ground p != FUEL) || cs.any (fun p => mine.contains p)
  let base := ((List.range b.fuels.length).zip b.fuels).filterMap fun q =>
    if gone q.2 then some q.1 else none
  let caches := ((List.range b.eboxes.length).zip b.eboxes).filterMap fun q =>
    if er.contains q.1 && q.2.cache && gone (cacheCells q.2) then some (100 + q.1) else none
  base ++ caches

def gatesIn (b : Board) (o : World) : List Nat :=
  let all := List.range b.portals4.length
  if o.me.side == 4 then
    let lit := all.filter fun j => match b.portals4[j]? with
      | some q => (outerRing q 4).all (fun p => !(visible o p) || colorAt o.ground p == TELEPORT)
      | none => false
    if lit.isEmpty then [0] else lit
  else if all.isEmpty then [0] else all

def fiber (b : Board) (o : World) : List St :=
  let er := erasedIn b o
  let ea := eatenIn b o er
  ((gatesIn b o).map fun g => { me := o.me, pad := o.pad, erased := er, eaten := ea, gate := g }).filter
    fun s => see b s == o

inductive Verdict where
  | agree | disagree | na
  deriving DecidableEq, Repr

def judge (b : Board) (o : World) (a : Act) (o' : World) : Verdict :=
  let cs := fiber b o
  if cs.isEmpty then .na
  else if cs.any (fun s => match step b s a with | .ok s' => see b s' == o' | .na => false) then .agree
  else if cs.all (fun s => step b s a == .na) then .na
  else .disagree

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算出来的状态。** -/
def traceOk (b : Board) : St → List (Act × World) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match step b s a with
    | .ok s' => see b s' == o && traceOk b s' rest
    | .na => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。读数不是定理。 -/
def firstSplit (b : Board) : St → List (Act × World) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match step b s a with
    | .ok s' => if see b s' == o then firstSplit b s' rest (i + 1) else some i
    | .na => some i

end Game
