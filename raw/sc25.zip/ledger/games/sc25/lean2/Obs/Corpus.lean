/-
# Corpus —— 逐条那一层：语料里的**每一行**，从观测到的那一帧起算一步，和看到的下一帧比（自动生成）

判决三值（`Obs/Check.lean` 的 `judge`）：agree / disagree / na。不接手的行（`skip ≠ 0`）不判，按理由分开计数。

**读数不是定理**：`#eval` 走的是求值器，不进可信基。下面那条 `corpus_tally` 走内核，把四个数钉死——
模型或语料哪一边动了，它当场编不过。
-/

import Obs.Replay

namespace Game
namespace Corpus

open Replay

/-- 一行的判决：0 agree · 1 disagree · 2 na · 3 不接手。名字里带 step：它就是「算一步、和观测比」。 -/
def stepVerdict (r : Row) : Nat :=
  if r.skip != 0 then 3 else
  match r.prev, r.next with
  | some o, some o' =>
    match judge (board r.lvl) o r.act o' with
    | .agree => 0
    | .disagree => 1
    | .na => 2
  | _, _ => 3

def tallyOf (vs : List Nat) : Nat × Nat × Nat × Nat :=
  (vs.count 0, vs.count 1, vs.count 2, vs.count 3)

end Corpus
end Game

/-! 定理写在命名空间外面：装置的 `ledger/lean_check.py` 按**不带前缀的名字**逐条 `#print axioms`。 -/

open Game Game.Replay Game.Corpus

/-- **全部 401 行**：对上 382、判错 0、说不出话 0、不接手 19。 -/
theorem corpus_tally : tallyOf (rows.map stepVerdict) = (382, 0, 0, 19) := by decide +kernel

/-- 其中**被成绩单认证的那一段**（147 行）：对上 139、判错 0、说不出话 0、不接手 8。 -/
theorem corpus_tally_certified :
    tallyOf ((rows.filter (·.cert)).map stepVerdict) = (139, 0, 0, 8) := by decide +kernel

#print axioms corpus_tally
#print axioms corpus_tally_certified
