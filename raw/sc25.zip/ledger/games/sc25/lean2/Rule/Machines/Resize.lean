/-
# resize —— 翻尺寸那台机器（对应 rule/三台机器/resize.py 的「我」那一半）

**定义，不是定理。** 边长 4 原地缩成 2（左上角、朝向不变）；边长 2 涨成 4：
九个候选（新的 4×4 含住原来那块 2×2）按先上后左扫，落在第一个整块涨得上去的。九个都不行：不动。

外圈跟着尺寸亮灭的那一半**不在这里**：它在 `Obj/Model/Render.lean`（外圈是画出来的，
由 `St.me.side` 决定画不画）。Python 那一侧同一条规则的「外圈」那一半，在这里是架构的一部分。
-/

import Obj.Model.Render
import Obj.Derive.Standing

namespace Game

/-- 九个候选，先上后左。越过场地上沿 / 左沿的不算。 -/
def growCands (m : Marker) : List (Nat × Nat) :=
  [2, 1, 0].flatMap fun dr => [2, 1, 0].filterMap fun dc =>
    if dr ≤ m.row && dc ≤ m.col then some (m.row - dr, m.col - dc) else none

def growLanding (b : Board) (s : St) : Option (Nat × Nat) :=
  let pic := render b s
  let mine := s.me.cells
  (growCands s.me).find? fun p => (square p.1 p.2 4).all (growable pic b.legends mine)

def resize (b : Board) (s : St) : St :=
  if s.me.side == 4 then { s with me := { s.me with side := 2 } }
  else if s.me.side == 2 then
    match growLanding b s with
    | some p => { s with me := { s.me with row := p.1, col := p.2, side := 4 } }
    | none => s
  else s

end Game
