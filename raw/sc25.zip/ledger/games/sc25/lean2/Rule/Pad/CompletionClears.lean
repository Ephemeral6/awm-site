/-
# completion_clears —— 凑齐图案（对应 rule/面板怎么响应/completion_clears.py）

**定义，不是定理。** 点亮之后，点亮的格位正好等于某一块小面板的图案（恰好一块）：
那一块的记号色就是这一下动的机器；大面板九格全部熄成地板色。
-/

import Obj.Model.Board
import Obj.Model.St

namespace Game

def completes (b : Board) (pad : List PadCell) : Option Nat :=
  match b.legends.filter (fun l => l.pattern == litSet pad) with
  | [l] => some l.color
  | _ => none

def clearPad (s : St) : St := { s with pad := s.pad.map (fun _ => PadCell.blank) }

end Game
