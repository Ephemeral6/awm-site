/-
# click_lights —— 点亮一格（对应 rule/面板怎么响应/click_lights.py）

**定义，不是定理。** 点中一个还没亮的格位：只有那一格变亮，别的格位与我都不动。
（凑齐图案的那一下另算，见 CompletionClears.lean。）
-/

import Obj.Model.St

namespace Game

def lightUp (s : St) (i : Nat) : St := { s with pad := s.pad.set i PadCell.lit }

end Game
