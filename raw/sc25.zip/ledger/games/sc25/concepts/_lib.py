"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源：第 1–19 步（run sc25-0912-1126）。
坐标一律 (row, col)，g[row][col]。注意 act 打印帧差时用的是 (col, row)，别混。
"""
from __future__ import annotations

from collections import Counter

from geo import cells_of, components  # noqa: F401

FLOOR = 2               # 可站立地板的色号
VOID = 5                # 场地之外那一片「没有格子」的色号：走不上去，也不是地面
MARK = (9, 10)          # 标记块由这两色各占一半
SOCKET = 10             # 插座内胆的色号 —— 和 MARK[1] 同色，但这是两码事（一个是地上的洞，一个是我的右半边）
FRAME_COLOR = 3         # 两块面板的外框色
BAR_COLS = (62, 63)     # 右边缘竖条所在的两列
BAR_FULL = 14           # 竖条「没消耗」那一段的色号

RESIZE_MARK = 15        # 「翻尺寸」那一台机器的记号色（图案是 .#. #.# .#. 那个菱形）
# 第 300 步逼出来的：凑齐哪一块小面板的图案，决定发生哪一类事件，而认机器靠的是**记号色**，
# 不是「这个色在场上有没有框」。全语料 19 次边长翻转（12 次 4→2、7 次 2→4）无一例外是色 15；
# 色 6 与色 11 凑齐过 24 次，一次没动过边长——包括第 300 步：色 6 的框在第 297 步被我抹掉了，
# 再凑齐色 6，世界只清了面板。
# 色与图案在六关里完全共变（色 15 总是菱形、色 6 总是竖线 .#. .#. .#.、色 11 总是拐角 ##. .#. ...），
# 所以「认的是色」和「认的是图案」这两种读法分不开；哪一天出现同色异图案（或异色同图案）才分得开。
# 走闸的那句在 resize_only_by_diamond_legend 里：边长翻转当且仅当凑齐的是这个色。

TELEPORT_MARK = 11      # 「搬家」那一台机器的记号色（图案是 ##. .#. ... 那个拐角）
# 原来只写在 panel_done_teleports_me 里，resize_swaps_marks v2 也要用它（涨大时外圈亮在这个色的框上），
# 挪到这里是为了一处取值：两条概念说的若是同一个色，就不该有两份可以各自漂移的常量。
# 它同样是「色与图案共变、分不开」的那一类假设，见上面 RESIZE_MARK 的注。

SESSION_FIRST_STEPS = (1, 251)
# 每个世界会话收到的**第一条**动作在本 run 里是第几步：开局（第 0 步之后）和换终局卡（装置记成第 250 步的一条 RESET）。
# 这是装置的记账事实（state.json 的 guids / final.from_step），不是从帧上读出来的——ctx 只给 step/level/state，
# 没有会话号，所以只能把换卡的步数抄在这里；再换一张卡就得再添一个数。
# 为什么非得有这个词：第 1 步和第 251 步的 prev 帧与第 2 步的 prev 帧逐格相同，可前两条被世界吞掉、第 2 步却转了向——
# 帧上、ctx 里都没有任何东西把它们分开，这是世界会话里一格看不见的状态（first_action_void）。
# 四次 RESET 之后的第一条动作（第 55/76/139/153 步）都没被吞，所以 RESET 不算新会话。

DIR = {                 # 方向动作 -> 单位方向 (d_row, d_col)
    "ACTION1": (-1, 0),
    "ACTION2": (1, 0),
    "ACTION3": (0, -1),
    "ACTION4": (0, 1),
}

FACE = {                # 方向动作 -> 动作后 9 色半边应该压的那一侧
    "ACTION1": "U",
    "ACTION2": "D",
    "ACTION3": "L",
    "ACTION4": "R",
}


def _solid_rects(g, color):
    """单色的实心矩形连通块，(top, left, 高, 宽)；不是实心矩形的块直接丢掉。"""
    out = []
    for comp in components(cells_of(g, color)):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        t, b, l, r = min(rs), max(rs), min(cs), max(cs)
        if (b - t + 1) * (r - l + 1) == len(comp):
            out.append((t, l, b - t + 1, r - l + 1))
    return out


def _paired_squares(g):
    """两半都是干净实心矩形连通块时，能拼出的正方形集合。"""
    hits = set()
    for t9, l9, h9, w9 in _solid_rects(g, MARK[0]):
        for t10, l10, h10, w10 in _solid_rects(g, MARK[1]):
            if (h9, w9) != (h10, w10):
                continue
            t, l = min(t9, t10), min(l9, l10)
            h = max(t9 + h9, t10 + h10) - t
            w = max(l9 + w9, l10 + w10) - l
            if h != w or h % 2 or h * w != 2 * h9 * w9:
                continue
            hits.add((t, l, h))
    return hits


def _half_squares(g):
    """只要有一半是干净实心矩形块，另一半照格子读，能拼出的正方形集合。"""
    hits = set()
    for color in MARK:
        other = MARK[0] if color == MARK[1] else MARK[1]
        for t, l, h, w in _solid_rects(g, color):
            if h * 2 == w:
                cands = [(t - h, l, w), (t + h, l, w)]
            elif w * 2 == h:
                cands = [(t, l - w, h), (t, l + w, h)]
            else:
                continue
            for rt, rl, k in cands:
                if rt < 0 or rl < 0 or rt + h > len(g) or rl + w > len(g[0]):
                    continue
                if all(g[r][c] == other for r in range(rt, rt + h) for c in range(rl, rl + w)):
                    hits.add((min(t, rt), min(l, rl), k))
    return hits


def marker(g):
    """标记块：(top_row, left_col, 边长)。两个同尺寸的 2:1 长方形，一块色 9 一块色 10，紧贴着拼成正方形。

    不唯一或找不到就返回 None。
    先按「两半都是干净的实心矩形连通块」找；这一层唯一就采信它。
    找不到（或找出好几个）才退到「只有一半是干净块，另一半照着格子读」——
    标记块贴着同色地形站的时候（插座内胆是色 10、外框是色 9），贴上去的那一半会和地形连成一块、
    自己认不出自己，得从另一半反推。两层分开是因为松的那层会把地形误读成半块：
    标记块夹在插座和自己之间时，中间那一半上下都能拼出正方形，只有严的那层分得清。
    半块永远是 2:1 的长方形，所以正方形的地形块（比如插座内胆）不会单独被误当成半块。
    """
    hits = _paired_squares(g)
    if len(hits) != 1:
        hits = _half_squares(g)
    return hits.pop() if len(hits) == 1 else None


def me(g):
    """标记块左上角 (row, col)；读不出返回 None。"""
    m = marker(g)
    return None if m is None else (m[0], m[1])


def side(g):
    """标记块边长；读不出返回 None。"""
    m = marker(g)
    return None if m is None else m[2]


def facing(g):
    """标记块朝向：9 色半边在上/下/左/右 -> "U"/"D"/"L"/"R"；读不出返回 None。"""
    m = marker(g)
    if m is None:
        return None
    r0, c0, k = m
    nine = {(r - r0, c - c0) for r in range(r0, r0 + k) for c in range(c0, c0 + k)
            if g[r][c] == MARK[0]}
    h = k // 2
    for tag, want in (("U", {(r, c) for r in range(h) for c in range(k)}),
                      ("D", {(r, c) for r in range(h, k) for c in range(k)}),
                      ("L", {(r, c) for r in range(k) for c in range(h)}),
                      ("R", {(r, c) for r in range(k) for c in range(h, k)})):
        if nine == want:
            return tag
    return None


def step_to(g, action):
    """按「走一个自身边长」平移后标记块的左上角；读不出或不是方向动作返回 None。"""
    m = marker(g)
    if m is None or action not in DIR:
        return None
    r0, c0, k = m
    dr, dc = DIR[action]
    return (r0 + dr * k, c0 + dc * k)


def target_colors(g, action):
    """平移一个自身边长后，目标方区里出现的色号集合；读不出或越界返回 None。"""
    m = marker(g)
    t = step_to(g, action)
    if t is None:
        return None
    k = m[2]
    out = set()
    for r in range(t[0], t[0] + k):
        for c in range(t[1], t[1] + k):
            if not (0 <= r < len(g) and 0 <= c < len(g[0])):
                return None
            out.add(g[r][c])
    return out


def target_all_floor(g, action):
    """按 step_to 平移后的目标方块是否整块都是地板色（越界算不是）。"""
    tc = target_colors(g, action)
    if tc is None:
        return None if marker(g) is None or action not in DIR else False
    return tc == {FLOOR}


def at_socket(g, action):
    """按 step_to 平移后的目标方区是否整块都是插座内胆色；读不出返回 None。"""
    tc = target_colors(g, action)
    return None if tc is None else tc == {SOCKET}


def bar_blocks(g):
    """右边缘竖条里还剩几个「满」的 2x2 块（自上而下被消耗）。"""
    n = 0
    for r in range(0, len(g) - 1, 2):
        if all(g[r + dr][c] == BAR_FULL for dr in (0, 1) for c in BAR_COLS):
            n += 1
    return n


def _frame_boxes(g):
    """所有色 3 外框的 bbox，按格数从大到小。第 0 块是大面板，其余是小面板（可能不止一块）。"""
    out = []
    for comp in components(cells_of(g, FRAME_COLOR)):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        out.append((len(comp), (min(rs), max(rs), min(cs), max(cs))))
    out.sort(key=lambda x: -x[0])
    return [b for _, b in out]


def _panel_bbox(g, rank=0):
    """按格数排名取一块色 3 外框的 bbox；rank=0 是大的那块。"""
    boxes = _frame_boxes(g)
    return boxes[rank] if len(boxes) > rank else None


def panel(g):
    """大面板内部的方块：{(top, left): 色}；读不出返回 None。"""
    box = _panel_bbox(g, 0)
    if box is None:
        return None
    t, b, l, r = box
    inner = [(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1)
             if g[rr][cc] != FRAME_COLOR]
    out = {}
    for comp in components(inner):
        rs = [rr for rr, _ in comp]
        cs = [cc for _, cc in comp]
        h, w = max(rs) - min(rs) + 1, max(cs) - min(cs) + 1
        if h != w or h * w != len(comp):
            continue
        out[(min(rs), min(cs))] = g[comp[0][0]][comp[0][1]]
    return out


PANEL_SIDE = 3          # 大面板里一个方块的边长
OFF = 0                 # 大面板里「没点亮」的块色
ON = 14                 # 点亮后的块色


def click_xy(action):
    """从 ACTION6:x,y 里取 (x, y)；不是带坐标的点击返回 None。上游这里用的是 (列, 行)。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return x, y


def click_off_block(g, action):
    """这一下点中的色 OFF 块 (top, left)，以及 g 的大面板里色 OFF 块共几个；没点中返回 None。"""
    xy = click_xy(action)
    p = panel(g) if xy else None
    if not p:
        return None
    x, y = xy
    off = [(t, l) for (t, l), color in p.items() if color == OFF]
    for t, l in off:
        if t <= y < t + PANEL_SIDE and l <= x < l + PANEL_SIDE:
            return (t, l), len(off)
    return None


def _marks_in_box(g, box):
    """一块小面板内部「非底色」的方块：{(行号, 列号): 色}。"""
    t, b, l, r = box
    inner = [(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1)
             if g[rr][cc] != FRAME_COLOR]
    if not inner:
        return {}
    bg = Counter(g[rr][cc] for rr, cc in inner).most_common(1)[0][0]
    out = {}
    for comp in components([x for x in inner if g[x[0]][x[1]] != bg]):
        rs = [rr for rr, _ in comp]
        cs = [cc for _, cc in comp]
        out[_grid_index(box, min(rs), min(cs))] = g[comp[0][0]][comp[0][1]]
    return out


def legends(g):
    """每块小面板挂一套图案：{记号色: frozenset 格位}。一块小面板里标记不止一色就跳过它。

    第 3 关一次挂了两块小面板，「小面板」不再是单数——这是把它写成复数的由来。
    """
    out = {}
    for box in _frame_boxes(g)[1:]:
        marks = _marks_in_box(g, box)
        colors = set(marks.values())
        if len(colors) == 1:
            out[colors.pop()] = frozenset(marks)
    return out


def legend(g):
    """小面板内部「非底色」的方块：{(top, left): 色}；读不出返回 None。（老写法，只认第一块小面板。）"""
    box = _panel_bbox(g, 1)
    if box is None:
        return None
    t, b, l, r = box
    inner = [(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1)
             if g[rr][cc] != FRAME_COLOR]
    if not inner:
        return None
    bg = Counter(g[rr][cc] for rr, cc in inner).most_common(1)[0][0]
    out = {}
    for comp in components([x for x in inner if g[x[0]][x[1]] != bg]):
        rs = [rr for rr, _ in comp]
        cs = [cc for _, cc in comp]
        out[(min(rs), min(cs))] = g[comp[0][0]][comp[0][1]]
    return out


def _in_box(box, r, c):
    return box is not None and box[0] <= r <= box[1] and box[2] <= c <= box[3]


def arena(g):
    """上方那片走得到的地板：地板色格子里，不落在任何一块色 3 外框 bbox 内的那些。"""
    boxes = _frame_boxes(g)
    return {(r, c) for r, c in cells_of(g, FLOOR)
            if not any(_in_box(b, r, c) for b in boxes)}


def fuel_cells(g):
    """场地上的色 14 格 —— 右边缘竖条那两列与任何面板之外的色 14。

    竖条「满」的那一段是色 14，大面板点亮的块也是色 14，所以这两处必须先排掉；
    排干净之后本关场地上还剩一坨 2x2（第 171 步我涨大时压到它，它整块没了、竖条反而涨了 4 块）。
    「场地上的色 14 是燃料」是个读法，不是装置给的事实；它由 fuel_absorbs 那条概念拿竖条的读数去对。
    """
    boxes = _frame_boxes(g)
    return {(r, c) for r, c in cells_of(g, BAR_FULL)
            if c not in BAR_COLS and not any(_in_box(b, r, c) for b in boxes)}


GRID = 3                # 两块面板内部都是 3x3 个方块


def _grid_index(box, top, left):
    """把面板里一个方块的左上角折成 3x3 里的 (行号, 列号)。"""
    t, b, l, r = box
    return (int((top - t) * GRID / (b - t + 1)), int((left - l) * GRID / (r - l + 1)))


def panel_grid(g):
    """大面板：{(行号, 列号): 色}；读不出返回 None。"""
    box = _panel_bbox(g, 0)
    p = panel(g)
    if box is None or not p:
        return None
    return {_grid_index(box, t, l): color for (t, l), color in p.items()}


def legend_grid(g):
    """当前记号色那块小面板的图案：{(行号, 列号): 色}；认不准返回 None。"""
    c = mark_color(g)
    pat = legends(g).get(c)
    return None if pat is None else {cell: c for cell in pat}


def grid_topleft(g, cell):
    """大面板第 (行号, 列号) 格对应的方块左上角 (top, left)；读不出返回 None。"""
    box = _panel_bbox(g, 0)
    p = panel(g)
    if box is None or not p:
        return None
    for (t, l) in p:
        if _grid_index(box, t, l) == tuple(cell):
            return (t, l)
    return None


def panel_click(g, cell):
    """大面板第 (行号, 列号) 格该点哪里——返回上游要的 "ACTION6:x,y"（x 是列 y 是行）；读不出返回 None。"""
    tl = grid_topleft(g, cell)
    if tl is None:
        return None
    t, l = tl
    return f"ACTION6:{l + PANEL_SIDE // 2},{t + PANEL_SIDE // 2}"


def mark_color(g):
    """本关此刻**在场上留了记号**的那块小面板的色号；只挂一块小面板时就是它的色。认不准返回 None。

    第 3 关同时挂了两块小面板（一套 4 记号、一套 3 记号），得挑出「说的是场上那个盒子」的那一块——
    挑法是「它的色在面板之外出现过」。这是个假设：两块小面板都在场上有记号时它认不准，宁可返回 None。
    """
    ls = legends(g)
    if not ls:
        return None
    if len(ls) == 1:
        return next(iter(ls))
    hit = [c for c in ls if _outside_cells(g, c)]
    return hit[0] if len(hit) == 1 else None


def _outside_cells(g, color):
    boxes = _frame_boxes(g)
    return {(r, c) for r, c in cells_of(g, color)
            if not any(_in_box(b, r, c) for b in boxes)}


def arena_marks(g, color=None):
    """场地上（所有面板之外）记号色的格子；不给色就用 mark_color。读不出返回空集。"""
    c = mark_color(g) if color is None else color
    return set() if c is None else _outside_cells(g, c)


def _corners(top, left, k):
    return {(top, left), (top, left + k - 1), (top + k - 1, left), (top + k - 1, left + k - 1)}


def landing_box(g, color=None):
    """记号色圈出的落点方框的左上角——和标记块同边长；认不出或不唯一返回 None。

    两种画法都认：四角就是落点自己的四角（记号画在落点上，标记块落上去会盖住它们），
    或者四角落在落点外扩一圈的那个框上（记号画在落点外面，标记块落上去盖不住）。
    """
    k = side(g)
    marks = arena_marks(g, color)
    if k is None or not marks:
        return None
    hits = {(r, c) for r, c in marks if _corners(r, c, k) <= marks}
    hits |= {(r + 1, c + 1) for r, c in marks if _corners(r, c, k + 2) <= marks}
    return hits.pop() if len(hits) == 1 else None


def _box_extra(g, box, color, k):
    """框内除地板色与记号色之外的色集合。"""
    return {g[r][c] for r in range(box[0], box[0] + k) for c in range(box[1], box[1] + k)} - {FLOOR, color}


def mark_boxes(g, color, k=None):
    """记号色在场上圈出的、和标记块同边长的**合法**方框，左上角按行列排序的列表。

    `k` 不给就用当前标记块的边长（`side`）。给了就按那个边长读同一帧——
    同一批记号在不同边长下圈出的是**不同的**方框（边长 2 时「四角」只隔 1 格，边长 4 时隔 3 格），
    所以「我涨大之后场上有哪些框」是一个当前帧就能问的问题，不必等涨大发生。

    两种画法都认（同 landing_box）。「合法」有三条：
    (a) 框内除地板色与记号色之外至多一种别的色；
    (b) 那一种不许是虚空色——虚空格站不上去，四角对齐只是两处记号碰巧连成一线，不是一个框
        （第 103 步逼出来的：同一个记号色有两组角标，其中一组框住的是一片虚空）；
    (c) 框里至少得有一格**不是**记号色——整块都是记号色的那是个记号疙瘩，不是框
        （第 111 步逼出来的：边长为 2 时「四角」就是那 2x2 的全部四格，
        于是任何一坨 2x2 的实心记号都会被读成一个空框。这条读法在 k>=4 时看不出毛病，
        k=2 时它把「框的中心装饰」当成了框本身，害得传送那条概念在这里判错）。
    """
    k = side(g) if k is None else k
    marks = arena_marks(g, color)
    if k is None or not marks:
        return []
    hits = {(r, c) for r, c in marks if _corners(r, c, k) <= marks}
    hits |= {(r + 1, c + 1) for r, c in marks if _corners(r, c, k + 2) <= marks}
    out = []
    for b in sorted(hits):
        if b[0] < 0 or b[1] < 0 or b[0] + k > len(g) or b[1] + k > len(g[0]):
            continue
        inside = {g[r][c] for r in range(b[0], b[0] + k) for c in range(b[1], b[1] + k)}
        if inside == {color}:
            continue
        extra = inside - {FLOOR, color}
        if len(extra) <= 1 and VOID not in extra:
            out.append(b)
    return out


def box_specimen(g, box, color):
    """某个框里扣着的标本色；框里是空的（只有地板与记号色）返回 None。"""
    k = side(g)
    if k is None:
        return None
    extra = _box_extra(g, box, color, k)
    return extra.pop() if len(extra) == 1 else None


def empty_box(g, color):
    """该记号色在场上**唯一**一个空框的左上角；没有或不止一个返回 None。"""
    hits = [b for b in mark_boxes(g, color) if not box_specimen(g, b, color)]
    return hits[0] if len(hits) == 1 else None


def box_ahead(g, color):
    """该记号色在场上**唯一**一个正对着标记块的框：同一条带（朝上下时同列、朝左右时同行）、整框都落在朝向那一侧。"""
    k, m, f = side(g), marker(g), facing(g)
    if k is None or m is None or f is None:
        return None
    r0, c0 = m[0], m[1]
    hits = []
    for (br, bc) in mark_boxes(g, color):
        ok = ((bc == c0 and br + k <= r0) if f == "U" else
              (bc == c0 and br >= r0 + k) if f == "D" else
              (br == r0 and bc + k <= c0) if f == "L" else
              (br == r0 and bc >= c0 + k) if f == "R" else False)
        if ok:
            hits.append((br, bc))
    return hits[0] if len(hits) == 1 else None


def corridor(g, box):
    """标记块与某个框之间、朝向那一侧的那条 k 宽带子上的格子（两端都不含）。

    只列格子，**不判通不通**——「什么色算挡住」是一条关于世界的主张，得写在概念里挨打，
    不许藏在这个词的返回值里（方法册「名字里带唯一/空/最近的词」那条的同类：
    一旦这里写成 `corridor_clear`，挡路规则就再也没被单独判过错）。
    框不在朝向那条带上、或读不出，返回 None；紧贴着时返回空集合（带子长度为 0）。
    """
    k, m, f = side(g), marker(g), facing(g)
    if k is None or m is None or f is None:
        return None
    r0, c0 = m[0], m[1]
    br, bc = box
    if f in ("U", "D"):
        if bc != c0:
            return None
        lo, hi = (br + k, r0) if f == "U" else (r0 + k, br)
        if lo > hi:
            return None
        return {(r, c) for r in range(lo, hi) for c in range(c0, c0 + k)}
    if br != r0:
        return None
    lo, hi = (bc + k, c0) if f == "L" else (c0 + k, bc)
    if lo > hi:
        return None
    return {(r, c) for r in range(r0, r0 + k) for c in range(lo, hi)}


def box_ring(g, box, color):
    """画出这个框的那一圈记号格：该记号色落在「框外扩一圈」这个矩形里的所有格子。

    两种画法都罩得住——记号画在框自己身上时它们在矩形内部，画在外扩一圈上时它们正好在边上。
    """
    k = side(g)
    if k is None:
        return set()
    br, bc = box
    return {(r, c) for r, c in arena_marks(g, color)
            if br - 1 <= r <= br + k and bc - 1 <= c <= bc + k}


def slot_box(g, color=None):
    """记号色在场上圈出的、和标记块**同尺寸**的凹槽左上角：四角画在外扩一圈的框上；认不出或不唯一返回 None。

    和 landing_box 的区别只在画法：这个词只认「记号画在槽的外面」那一种，
    也就是「场上有一个正好我这么大的洞，四周描了边」。
    记号画在落点自己身上的那种（记号和落点同尺寸）不算——那种用 landing_box 读。
    分开是因为「我塞得进去吗」和「哪里是落点」是两个问题：
    标记块尺寸一变，同一片记号可能从「不是我的槽」变成「正好是我的槽」。
    """
    k = side(g)
    marks = arena_marks(g, color)
    if k is None or not marks:
        return None
    hits = {(r + 1, c + 1) for r, c in marks if _corners(r, c, k + 2) <= marks}
    return hits.pop() if len(hits) == 1 else None


def mark_cells(g, color=None):
    """地面上记号色格子的全集，含被标记块盖住的那些：看得见的那些 + 落点的四角。

    「落点四角一定是记号」是个假设——两种画法下都成立，但它一次都没单独走过闸。
    """
    out = set(arena_marks(g, color))
    b = landing_box(g, color)
    k = side(g)
    if b is not None and k is not None:
        out |= _corners(b[0], b[1], k)
    return out


def covered(g):
    """标记块此刻压住的格子；读不出返回空集。"""
    m = marker(g)
    if m is None:
        return set()
    r0, c0, k = m
    return {(r, c) for r in range(r0, r0 + k) for c in range(c0, c0 + k)}


def specimen(g, color=None):
    """落点方框里扣着的那块「标本」的色号：方框内除地板色、记号色之外唯一的色号；没有或不止一色返回 None。"""
    b = landing_box(g, color)
    k = side(g)
    if b is None or k is None:
        return None
    mc = mark_color(g) if color is None else color
    colors = {g[r][c] for r in range(b[0], b[0] + k) for c in range(b[1], b[1] + k)}
    colors -= {FLOOR, mc}
    return colors.pop() if len(colors) == 1 else None


def all_mark_cells(g):
    """地面上每一个记号色格子 -> 它的色号，含被标记块盖住的那些。

    不挑「哪一块小面板说的是场上那个盒子」——挂着的每一块都算。
    由来（第 115 步）：mark_color 一次只认一个记号色，本关三种记号色场上都有格子，
    于是它返回 None，凡是靠它推地面色的地方全退化成「一律地板色」。
    可是记号是画在地面上的，我压住谁的记号都一样不算擦掉，问「压着的是谁的记号」本来就不该先挑出一个色。
    """
    out = {}
    for color in legends(g):
        for cell in mark_cells(g, color):
            out[cell] = color
    return out


def standing_in_ring(g):
    """标记块此刻是不是正好站在某个记号色「外描边」画法的框里。

    站在框里的时候，身子底下那几格看不见——框里本来可能扣着一块标本（传送把我送进去时就是这样）。
    描在框自己身上的那种画法不算：那种的记号格由 mark_cells 推得出来，不是未知。
    """
    m = marker(g)
    if m is None:
        return False
    r0, c0, k = m
    return any(_corners(r0 - 1, c0 - 1, k + 2) <= arena_marks(g, color) for color in legends(g))


def ground_color(g, cell, color=None):
    """cell 处的地面色。看得见的格子直接读帧；被标记块压着的格子按「记号格 -> 记号色，其余 -> 地板色」推。

    后一半是大胆的：压住的底下要是还藏着别的东西，这里会说错。第 160 步就是这样打脸的——
    传送把我送进一个扣着标本的框，走开时让出来的四格露出的是标本色，不是地板色。
    所以再加一条：**站在外描边的框里时，压住的非记号格返回 None（读不出）**，
    因为「空框」和「框里扣着标本、被我盖住了」在单帧上分不出来。调用方拿到 None 就别替它填色。
    不指定色时按 all_mark_cells 查所有记号色（第 115 步逼出来的：原先走 mark_color，多记号色的关里它认不准）。
    """
    r, c = cell
    if cell not in covered(g):
        return g[r][c]
    if color is None:
        known = all_mark_cells(g)
        if cell in known:
            return known[cell]
        return None if standing_in_ring(g) else FLOOR
    if cell in mark_cells(g, color):
        return color
    return None if standing_in_ring(g) else FLOOR


def lit_grid(g):
    """大面板里已经点亮（色 ON）的格位集合；读不出返回 None。"""
    pg = panel_grid(g)
    return None if pg is None else {k for k, v in pg.items() if v == ON}


def clicked_grid(g, action):
    """这一下点击落在大面板哪个格位；没点中返回 None。"""
    xy = click_xy(action)
    box = _panel_bbox(g, 0)
    p = panel(g)
    if xy is None or box is None or not p:
        return None
    x, y = xy
    for (t, l) in p:
        if t <= y < t + PANEL_SIDE and l <= x < l + PANEL_SIDE:
            return _grid_index(box, t, l)
    return None


def completed_legend(g, action):
    """这一下点击之后，大面板点亮的格位正好凑成哪一块小面板的图案 -> 那块小面板的记号色；凑不成返回 None。

    这是「收尾那一下」的统一写法。前三关的大面板预先把该点的格位涂成色 OFF，
    于是「点掉最后一个色 OFF 块」和「点亮的格位凑齐图案」是同一件事；
    第 3 关的大面板一块色 OFF 都没有，只能靠小面板的图案认——所以改用后一种说法。
    """
    cell = clicked_grid(g, action)
    lit = lit_grid(g)
    pg = panel_grid(g)
    if cell is None or lit is None or pg.get(cell) == ON:
        return None
    after = set(lit) | {cell}
    hits = [color for color, pat in legends(g).items() if set(pat) == after]
    return hits[0] if len(hits) == 1 else None
