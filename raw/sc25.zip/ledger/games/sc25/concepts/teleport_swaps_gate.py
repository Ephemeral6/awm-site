"""搬家那一下指路牌换一头：落点那个框的跨度 k+2 四角不再是记号色，而另一个同奇偶合法框——包括此刻正藏在我身下、等我搬走才露出来的那一个——的四角全变成记号色；没有另一个同奇偶的框时，指路牌留在原处。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且这一下点击让大面板点亮的格位正好凑齐某块小面板的图案（completed_legend 读得出）；" \
        "把该记号色的合法框（mark_boxes）按「左上角与我行列奇偶都相同」筛出 same，" \
        "再按「戴着外圈」（框外扩一格，那个 k+2 方框的四角全是记号色）筛出 gated——" \
        "要求 gated 恰好一个（那就是 panel_done_teleports_me 认定的落点）、且 same 不超过两个；" \
        "再排除「落点扣着标本而我正对着它」那一种（那一种归 panel_done_erases_specimen，标记块根本不搬）。" \
        "其余情况 NA。标记块这一步前后盖住的格子不看。" \
        "「另一个同奇偶的框」除了帧上看得见的那些，还算上**我自己腾出来的那一块**：" \
        "它和我永远同奇偶，而它是不是框，只有等我搬走、四角露出来（next 帧上那四角是记号色）才读得出——" \
        "所以这条的判定要看 next，而 apply 在 prev 上对这一种说不出话，照旧闭嘴。"
NOTE = "由来：panel_done_teleports_me v13 的末尾记着一件它不管的事——第 235 步搬完之后两组外圈对调了，" \
       "「只有一次观测，所以没写进那条概念」。第 243 步是第二次，而且是反向的：" \
       "第 235 步我从 (33,17) 搬进 (37,53)，(37,53) 的外圈灭、(33,29) 的外圈亮；" \
       "第 243 步我从 (37,45) 搬进 (33,29)，两组外圈原样换回来。" \
       "把语料里七次搬家全部摊开核对（runs 里的 whydiff.py），只有这两次发生了对调，" \
       "而这两次正是仅有的「同奇偶合法框有两个」的局面——第 27、103 步全场只有一个框，" \
       "第 135、159、220 步框不止一个但奇偶只筛剩一个，五次外圈都待在原处没动。" \
       "所以对调不是搬家的副产品，是**同奇偶有两个候选时世界替下一次搬家挑好的门**：" \
       "指路牌总是移到另一个同奇偶的框上，让同一块图案连凑两次不会把我送回原地。" \
       "这条对路线的意义和 v13 那句话一样是反的：它不是障碍，是第 5 关唯一走得通的来回。" \
       "只断言帧上读得出的那一半：灭掉的四角只说「不再是记号色」，不说它变成什么——" \
       "第 235 步那四角露出来全是虚空，第 243 步却是三格虚空加一格地板色（那一格在第 235 步亮起来之前本来就是地板色）。" \
       "所以熄灭是**还原成亮起之前的样子**，世界记得，而单帧读不出；要预测它得自己记账，那是规划器的活，不是这条概念的。" \
       "没被排除的替代读法：同奇偶三个以上时它怎么挑（本局没见过，SCOPE 里直接 NA）；" \
       "以及「另一个框」也许该按某种循环顺序而不是「剩下那个」——两个候选时两种读法同值。" \
       "v2：终局卡第 389 步打脸，打的正是「同奇偶只有一个时留在原处」那一半。" \
       "我 4x4 站在 (37,53) 上搬去 (33,29)：prev 帧上看得见的同奇偶合法框只有落点 (33,29) 一个，" \
       "这条于是说指路牌留在原处；世界却把 (33,29) 的外圈四角熄掉、在 (37,53) 的外圈四角点亮。" \
       "看 next 帧就明白了：(37,53) 的内画四角在我搬走之后露了出来——**我一直站在另一个框上**，" \
       "而内画四角的框和我同边长同位置，我站上去它在帧上就一点痕迹不剩（panel_done_teleports_me v16 同一步栽的是同一个坑）。" \
       "所以不是「只有一个框」，是「另一个框藏在我身下」。两种修法里选了强的那一种：" \
       "把我腾出来的那一块也当成候选，它是不是框按 next 帧上露出来的四角判——" \
       "这样八次观测归一个机制（指路牌总在两个同奇偶的框之间换头），" \
       "而不是把「只有一个」那一半缩成 NA、丢掉五次观测。" \
       "代价是这条的判定从此要用 next 帧：预测那一半仍然说不出（prev 上读不出身下藏着什么），apply 照旧闭嘴。" \
       "它因此更容易被打脸：哪天我从一块**没有**四角的地方搬走而指路牌照样换了头，或者腾出来的四角是记号色而指路牌没动，它当场变反例。"
EVIDENCE = ["2657799cd7a750eb", "58293a15fc50c8fa", "ab02ba4d56a16c8d", "00348bdc51b3bc76",
            "1d55cbe2e26095d8", "340bcaf4c04e8b0e", "1ca2093db355cef8", "545138eb8e7f6ed1"]

from _lib import (_corners, box_ahead, box_specimen, completed_legend, covered, facing, mark_boxes,
                  marker)


def _fire(prev, action):
    color = completed_legend(prev, action)
    if color is None:
        return None
    m, f = marker(prev), facing(prev)
    if m is None or f is None:
        return None
    k = m[2]
    same = [b for b in mark_boxes(prev, color)
            if (b[0] - m[0]) % 2 == 0 and (b[1] - m[1]) % 2 == 0]
    gated = [b for b in same
             if all(prev[r][c] == color for r, c in _corners(b[0] - 1, b[1] - 1, k + 2))]
    if len(gated) != 1 or len(same) > 2:
        return None
    dest = gated[0]
    if box_specimen(prev, dest, color) is not None and box_ahead(prev, color) == dest:
        return None
    other = [b for b in same if b != dest]
    return color, k, dest, (other[0] if other else None), (m[0], m[1])


def _ring(box, k):
    return _corners(box[0] - 1, box[1] - 1, k + 2)


def _hidden_under_me(nxt, spot, k, color):
    """我腾出来的那一块本来是不是个框：搬走之后四角露出来是记号色，就是（prev 上读不出，见 NOTE v2）。"""
    return all(nxt[r][c] == color for r, c in _corners(spot[0], spot[1], k))


def assert_(prev, action, nxt, ctx=None):
    d = _fire(prev, action)
    if d is None:
        return "NA"
    color, k, dest, other, spot = d
    skip = covered(prev) | covered(nxt)
    if other is None and spot != dest and _hidden_under_me(nxt, spot, k, color):
        other = spot                                    # 另一个框一直在我脚底下
    if other is None:                                   # 同奇偶只有一个框：指路牌留在原处
        for r, c in _ring(dest, k) - skip:
            if nxt[r][c] != color:
                return "FALSE"
        return "TRUE"
    for r, c in _ring(dest, k) - skip:                  # 我落进去的那个框：门关上
        if nxt[r][c] == color:
            return "FALSE"
    for r, c in _ring(other, k) - skip:                 # 另一个同奇偶的框：门打开
        if nxt[r][c] != color:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只填亮起来的那四格——熄灭的四格变成什么，单帧读不出（见 NOTE）。"""
    d = _fire(prev, action)
    if d is None:
        return None
    color, k, _dest, other, _spot = d
    if other is None:
        return None
    return {cell: color for cell in _ring(other, k) - covered(prev)}
