"""尺寸翻转那一下（凑齐图案、该记号色场上没有合法框），场地上的角标跟着换一套：缩成 2 时，各记号色画在 4x4 框外一圈的角标（跨度 6 的四角）全变虚空、翻转色每一坨实心 2x2 的外隔一格四角变成翻转色；涨回 4 时反过来——翻转色的跨度 6 四角变虚空，而搬家色重新在**场上按行列序最后那个合法 4x4 框**的外扩一圈四角上亮起（一个合法框都没有时，只断言新亮的格子凑成跨度 6 的四角组）。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且这一下点击凑齐某块小面板的图案（completed_legend 读得出）、那个记号色场上没有合法框（mark_boxes 为空）、" \
        "标记块读得出且边长是 4 或 2——和 panel_done_shrinks_me / panel_done_grows_me 同一个开火条件。其余情况 NA。" \
        "只看场地（面板与竖条之外），且不看我这一步之前、之后压住的格子。" \
        "涨大那一半里「亮在哪」这句只在**搬家色（_lib.TELEPORT_MARK）在 prev 帧上至少有一个合法 4x4 框**时才说，" \
        "亮在按行列序（先行后列）最后的那一个上；一个都没有时退回原来那句弱的（亮起来的格子凑成跨度 6 的四角组）。"
NOTE = "由来：第 217 步缩成 2x2 时，帧差里多出 8 格谁也没预测：一组记号色的角标灭了、另一组亮了。" \
       "回头把语料里全部九次尺寸翻转逐一比对，九次都是同一件事：" \
       "缩小时，画在某个 4x4 框**外一圈**的那组角标（四角跨度 6）变成虚空，" \
       "同时翻转色那坨实心 2x2 的**外隔一格**四角（同样跨度 6）亮起来；涨大时两组正好反过来。" \
       "画在框自己身上的角标（跨度 4）两种尺寸下都在——所以 k=2 时它们读成一个 2x2 的内框，那不是巧合，是世界按我的尺寸给我画框。" \
       "涨大时重新亮起的那组角标落在哪，帧上读不出来（它们此刻是虚空）：两关里各只有一个 4x4 内画框得到了外圈，" \
       "另一个同色同尺寸的框从来没有过——所以涨大那一半只断言「亮起来的格子凑成跨度 6 的四角组」，不预测。" \
       "v1 那一句写成了「落在某个**内画框**的外扩一圈四角上」，当场在自己的依据上判 FALSE：" \
       "第 111 步涨回 4x4 之后，我的新身子正好压住了那个内画框的两个角，`after` 里根本读不出内画框——" \
       "用「涨大后我站在哪」去认一个被我盖住的图形，是拿着遮眼布找东西。改成只看角标自己凑不凑得成跨度 6 的四角。" \
       "没被排除的替代读法：翻转色的四角也许不是「围着实心 2x2」而是「围着翻转色的 2x2 内框」——两关里那坨 2x2 都恰好被另一色的内框圈着，分不开。" \
       "v3：把涨大那一半从「不预测」补成一句能判错的话，逼它的是终局卡第 4 关——规划器把整个可达状态空间搜完" \
       "（13832 个状态）都找不到通关路线，缺口正是这里：涨大之后册子说不出外圈亮在哪，" \
       "于是那张地面上没有任何框戴外圈，而外圈是 panel_done_teleports_me 挑落点的唯一依据，" \
       "**涨大之后就再也接不上一次搬家**。这一关的地形把这件事变成生死线：插座那条走廊只有搬家进得去，" \
       "而挡在插座前的两堵墙要跑到地图另一头才抹得掉——抹完回不来，等于没抹。" \
       "补上的那句用的是 prev 帧就读得出的东西：**搬家色在 prev 上恰好一个合法 4x4 框时，外圈就亮在它的外扩一圈四角上**。" \
       "语料里八次涨大：第 120、128、149、171、179、324 步（都在第 4 关）合法框恰好一个 (35,51)，" \
       "亮起的四格每次都正好是 _corners(34,50,6)；第 111 步我自己站在那个框里、框因此不合法（零个），" \
       "第 232 步（第 5 关）有两个合法框 (33,29) 与 (37,53)、世界挑了 (37,53)——这两次都退回弱断言，不猜。" \
       "所以这条新句子的证据是**一种地形看了六遍**，不是六种地形；它随时可能在下一关垮掉，垮了就知道选择器长什么样。" \
       "没被排除的替代读法：(a) 亮在「不是某个 2x2 落脚点的外圈」的那个跨度 4 角标组上——" \
       "第 4 关的 (38,28) 正是 k=2 落脚点 (39,29) 的外圈，两种读法在这一关同值；" \
       "(b) 第 5 关那次说明真正的选择器在两个合法框之间还要再挑一次，而我一次都没见过它做这个选择的理由。" \
       "这条 NOTE 欠着的那句话（方法册「NOTE 里的只见过一次」）现在有名有姓：**两个合法框时外圈亮在哪**。" \
       "v4：上面那句欠账被终局卡的最后一关逼着还了——还法是把「恰好一个」放宽成「按行列序最后的那一个」。" \
       "逼它的局面：这一关的插座被一堵墙封着，那堵墙只有抹掉才开，而能瞄准它的位置在地图右半边；" \
       "抹那堵墙要先抹掉挡在车道上的另一色，可抹它的位置只有一个**死兜**——四面虚空，整块地面上唯一的出口是一次 k=4 搬家。" \
       "兜里只进得去 k=2（k=4 站不下），所以必须在兜里涨大再搬家；而这一关搬家色有两个合法 4x4 框，" \
       "v3 正好在这里闭嘴，于是涨大之后没有任何框戴外圈，规划器把 10360 个状态搜完找不到通关路线。" \
       "唯一那次两框观测（第 232 步）就发生在同一个兜里、同一关：我在 (35,17) 涨大，两个框是 (33,29) 与 (37,53)，" \
       "亮起来的四格正是 _corners(36,52,6)，也就是 (37,53) 的外圈；随后第 235 步我从那里搬了出去。" \
       "三种读法在这一次上同值，我挑了其中最弱的一种——「行列序最后」把 v3 的「唯一那个」包含成特例" \
       "（只有一个框时它就是最后一个），不引入新机制，八次单框观测一次不动。" \
       "另外两种没被排除：(a) 「离我最远的那个」（第 232 步 (37,53) 确实远得多）；" \
       "(b) **指路牌记忆**——teleport_swaps_gate 已经证明这个外圈是一扇有状态的门（搬一次就换一头），" \
       "所以最可能的真相是「涨大只是把世界记着的那一头重画出来」，而那件事单帧根本读不出。" \
       "(b) 如果是真的，这条概念迟早会在「搬过一次之后再缩再涨」的局面上垮掉：那时它还押行列序最后，世界会押另一头。" \
       "我认这个风险，因为通关路线上只有一次涨大，而三种读法在那一次上押的是同一个框。" \
       "顺带记一件这条概念管不着、但下一个人会问的事：兜里那次涨大的落点由 panel_done_grows_me 定，" \
       "九个候选里能站的只有一个，所以「在哪涨」不是自由的。"
EVIDENCE = ["eda8404aad485ee5", "1848d086ef1e56e4", "0c33491dcfb52651", "8c61a1545eff2a92",
            "018e8dd7d0448d39", "e59dd405d0d5dedc", "ee9e9b19882342ae", "9155d61d63a4ef4d",
            "53d8df4b82f21b25", "47525092bde0b654", "2bd4ea89a01958ec"]

from _lib import (TELEPORT_MARK, VOID, _corners, arena_marks, completed_legend, covered, legends,
                  mark_boxes, marker)


def _fire(prev, action):
    color = completed_legend(prev, action)
    if color is None:
        return None
    if mark_boxes(prev, color):
        return None
    m = marker(prev)
    if m is None or m[2] not in (2, 4):
        return None
    return color, m[2]


def _span6(marks):
    """跨度 6 的四角组：四个角都是记号格的那些 (top, left)。"""
    return {(r, c) for r, c in marks if _corners(r, c, 6) <= marks}


def _solid2(marks):
    """实心 2x2 的左上角。"""
    return {(r, c) for r, c in marks if {(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)} <= marks}


def _expect(prev, color, k):
    """从 prev 帧算出来的那部分：谁灭（off）、谁亮成什么色（on: 格子 -> 色）。

    缩小（k=4）：亮的是翻转色，围着它每一坨实心 2x2。
    涨大（k=2）：亮的是搬家色，围着它**按行列序最后那个合法 4x4 框**；一个框都没有就不说（on 空）。
    """
    off, on = set(), {}
    for c in legends(prev):
        marks = arena_marks(prev, c)
        for (r, cc) in _span6(marks):
            off |= _corners(r, cc, 6)
    if k == 4:
        for (r, cc) in _solid2(arena_marks(prev, color)):
            on.update({cell: color for cell in _corners(r - 2, cc - 2, 6)})
    else:
        boxes = mark_boxes(prev, TELEPORT_MARK, 4)
        if boxes:
            r, cc = boxes[-1]                      # 按行列序最后的那一个（mark_boxes 已排序）
            on.update({cell: TELEPORT_MARK for cell in _corners(r - 1, cc - 1, 6)})
    hidden = covered(prev)
    return off - hidden, {cell: v for cell, v in on.items() if cell not in hidden}


def assert_(prev, action, nxt, ctx=None):
    d = _fire(prev, action)
    if d is None:
        return "NA"
    color, k = d
    off, on = _expect(prev, color, k)
    skip = covered(prev) | covered(nxt)
    for r, c in off - skip:
        if nxt[r][c] != VOID:
            return "FALSE"
    for (r, c), v in on.items():
        if (r, c) in skip:
            continue
        if nxt[r][c] != v:
            return "FALSE"
    if k == 2:
        # 涨大：新亮起的记号格必须凑成跨度 6 的四角组（也就是「画在某个 4x4 框外一圈」的那种角标）
        for c in legends(prev):
            before, after = arena_marks(prev, c), arena_marks(nxt, c)
            allowed = set()
            for (r, cc) in _span6(after):
                allowed |= _corners(r, cc, 6)
            if (after - before - skip) - allowed:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    d = _fire(prev, action)
    if d is None:
        return None
    color, k = d
    off, on = _expect(prev, color, k)
    out = {cell: VOID for cell in off}
    out.update(on)
    return out or None
