"""标记块压到场地上那坨色 14 时，整坨消失（没被我压住的那几格变地板色），右边缘竖条净涨**至少「那坨的格数」块**。"""
LEVEL = "L4"
SCOPE = "只看不换关、且不是重开本关（action != \"RESET\"）的转移；标记块在 nxt 里定位不到返回 NA；" \
        "prev 帧场地上没有色 14 格、或有但这一步结束时我一格都没压到，返回 NA。" \
        "开口的只有一种局面：**这一步结束时标记块压住了 prev 帧场地上色 14 的某个连通块的至少一格**。"
NOTE = "由来：第 171 步。(41,15,2) 凑色 15 的图案涨回 4x4，落点 (39,13) 压住了 (40,13)、(41,13)，" \
       "而那两格属于 (40,12)-(41,13) 的一坨 2x2 色 14。结果整坨四格一起没了——" \
       "压住的两格成了我的身子，没压住的 (40,12)、(41,12) 变回地板色——竖条从 23 块涨到 27 块。" \
       "色 14 正是竖条「满」那一段的色号，所以这坨东西就是地上的燃料。" \
       "**碰到一格就整坨消失**，不是只吃掉压住的那部分——这一点四格里压了两格、没了四格，看得很清楚。" \
       "分不开的三件事（本关只有这一罐，只有这一次观测）：" \
       "(a) 净涨 4 是「这一下不扣钱 + 燃料补 4」还是「这一下扣 1 + 燃料补 5」；" \
       "(b) 补的量是按格数（4 格 -> 4 块）、按 2x2 块数（1 块 -> 4 块）还是定额 4；" \
       "(c) 是「压到」才吃，还是挨着就吃。这条概念押的是「按格数、净涨」与「压到才吃」，" \
       "因为那是帧上直接量得到的那一组；另外两种读法在下一罐燃料上就能分开——下一关要是尺寸不同、或者那坨不是 2x2，立刻见分晓。" \
       "这条概念活着还有一层用处：它是本局第一条**拿竖条的读数去核对一个色号读法**的概念。" \
       "fuel_cells 这个词说「竖条两列与面板之外的色 14 是地上的燃料」，这条概念让它去兑现一个数；" \
       "词本身要是圈错了格子（比如把某块装饰也圈进来），这条概念会当场判 FALSE。" \
       "漏了它 70 步的原因记在 bar_monotone v5 里：我把「这个色我已经认识了」当成了「这个色在哪都不用再看」。" \
       "v2：第 232 步打脸——同样一坨 4 格，竖条净涨 5 块，不是 4 块。两次读数摆在一起：" \
       "第 171 步 23->27（满行 46->54），第 232 步 13->18（满行 26->36）。" \
       "所以「按格数」这句话死了，剩下站得住的是**下界**：净涨不少于格数。" \
       "为什么多那一块，三条读法都还活着，本关的语料分不开：" \
       "(a) 显示粒度——竖条只按整块画（满行永远是偶数），而每个动作的开销小到能被这个粒度藏住；" \
       "把两次的区间摊开（净涨 ∈ 8..10 行 与 10..12 行），一个统一的「每坨 10 行」是容得下的；" \
       "(b) 压住几格算几分——第 171 步我压住 4 格里的 2 格，第 232 步新身子 4x4 把 4 格全压住了；" \
       "(c) 这一下的点击本身扣了多少，两次不一样。" \
       "分开它们要的不是更多推理，是一坨**不是 4 格**的燃料，或者一次只挨着不压住的吃法。" \
       "顺带一条量具教训：`bar_blocks` 只数完整的 2x2 块，半块它看不见——" \
       "拿一个会四舍五入的量具去断言一个精确的等式，等式迟早自己垮。"
EVIDENCE = ["9155d61d63a4ef4d", "2bd4ea89a01958ec"]

from _lib import BAR_FULL, FLOOR, bar_blocks, cells_of, components, covered, fuel_cells, marker


def _eaten(prev, nxt):
    """prev 帧场地上、这一步结束时被我压到了至少一格的那些色 14 连通块，合起来的格子集合。"""
    here = covered(nxt)
    out = set()
    for comp in components(sorted(fuel_cells(prev))):
        if set(comp) & here:
            out |= set(comp)
    return out


def _fire(prev, action, nxt, ctx):
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if action == "RESET":
        return None
    if marker(nxt) is None:
        return None
    eaten = _eaten(prev, nxt)
    return eaten or None


def assert_(prev, action, nxt, ctx=None):
    eaten = _fire(prev, action, nxt, ctx)
    if eaten is None:
        return "NA"
    left = {(r, c) for r, c in cells_of(nxt, BAR_FULL)} & eaten
    if left - covered(nxt):
        return "FALSE"                                  # 没被我压住的那几格还是色 14：没消失
    return "TRUE" if bar_blocks(nxt) - bar_blocks(prev) >= len(eaten) else "FALSE"


def apply(prev, action, ctx=None):
    """只敢说「没被压住的那几格变地板色」那一部分。

    压住的格子归管移动/涨大的那几条概念画；竖条哪几格变色要知道「从上往下第几块」，
    那是另一条读法（bar_blocks 只数块数，不说第几块在哪几行），这条概念不替它开口。
    一步之后标记块占哪几格这条概念算不出来（它是别人的主张），所以 apply 只在
    **prev 帧里我已经压着的那些燃料格**上开口 —— 实测里这一格都没有，于是它照例返回 None，
    不硬生生造出一份预测来冲 E。
    """
    here = covered(prev)
    out = {}
    for comp in components(sorted(fuel_cells(prev))):
        if set(comp) & here:
            for r, c in comp:
                if (r, c) not in here:
                    out[(r, c)] = FLOOR
    return out or None
