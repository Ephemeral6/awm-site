"""RESET 把场面恢复成一关的开头：竖条补到 64 行全满，大面板一格不亮，标记块边长回到 4；关号要么不变，要么归零。"""
LEVEL = "L5"
SCOPE = "只看 action == \"RESET\" 的转移；其余动作返回 NA。竖条、大面板或标记块在 nxt 里读不出来也返回 NA。"
NOTE = "v1 的首句是「重开本关：关号不变」，第 250 步被打掉——而打它的那一下正是 v1 的 NOTE 自己预告过的：" \
       "「会话要是被回收，RESET 会退回整局归零，那时关号会变，这条自然判 FALSE」。" \
       "实际触发它的不是会话回收，是换终局卡（装置把换卡记成一条 action=RESET 的转移），关号 6 → 0。" \
       "按「复合主张垮掉时抽出还站得住的那半句」办：三件恢复（竖条补满、大面板熄灭、边长回 4）在语料里**五次 RESET 全部成立**，" \
       "一条都没垮；垮的只有关号那半句。所以三件恢复改成无条件断言，关号那半句弱化成「不变，或者归零」——" \
       "它仍然可判错：哪天 RESET 把我扔到一个既不是本关、又不是第 0 关的关卡上，这条当场 FALSE。" \
       "**没断言位置**：标记块重开前后都在原处，但那几次我在本关都没走过，位置不变和「被恢复到进关位置」这一转移分不开。" \
       "也没断言竖条满格 = 64 行是这一关的预算：bar_rate_level3 管那件事。"
EVIDENCE = ["56b830dc960999ad", "539080c3ab54f231"]

from _lib import BAR_COLS, BAR_FULL, lit_grid, side


def _bar_rows(g):
    return sum(1 for r in range(len(g)) if all(g[r][c] == BAR_FULL for c in BAR_COLS))


def assert_(prev, action, nxt, ctx=None):
    if action != "RESET":
        return "NA"
    lit = lit_grid(nxt)
    k = side(nxt)
    if lit is None or k is None:
        return "NA"
    if not (_bar_rows(nxt) == len(nxt) and not lit and k == 4):
        return "FALSE"
    lp, ln = (ctx or {}).get("level_prev"), (ctx or {}).get("level_next")
    if lp is None or ln is None:
        return "TRUE"
    return "TRUE" if (ln == lp or ln == 0) else "FALSE"
