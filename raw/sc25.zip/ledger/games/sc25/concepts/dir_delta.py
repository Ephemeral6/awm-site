"""方向动作只能让标记块整体位移「一个自身边长」或者原地不动，不会是别的位移量。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1/2/3/4；换关的那一步（ctx.level_prev != ctx.level_next）返回 NA；" \
        "标记块在 prev 或 nxt 里定位不到就返回 NA；其余动作 NA"
NOTE = "v1 写死位移 4 格（CELL）。第 19 步标记块边长由 4 变 2 之后，「4 格」只是「一个边长」在边长=4 时的样子；" \
       "改成按 prev 的边长算。边长=2 时一步走几格还没测过——这条现在就是那个预测。" \
       "v3：排除换关那一步。第 23 步过关后标记块出现在新关的起点，和上一关的位置之间没有「位移」可言。"
EVIDENCE = ["da3e01cff498c8a1", "15262396f435b24d", "9dabb54dca80d95d"]

from _lib import DIR, marker


def assert_(prev, action, nxt, ctx=None):
    if action not in DIR:
        return "NA"
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = marker(prev), marker(nxt)
    if a is None or b is None:
        return "NA"
    d = (b[0] - a[0], b[1] - a[1])
    dr, dc = DIR[action]
    return "TRUE" if d == (0, 0) or d == (dr * a[2], dc * a[2]) else "FALSE"
