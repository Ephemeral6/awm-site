"""边长 4 的标记块，凑齐记号色 15 那块小面板（翻尺寸那台机器）的图案时，面板九块全变地板色，标记块原地缩成边长 2——左上角与朝向不变。"""
LEVEL = "L6"
SCOPE = "只看 ACTION6 且这一下点击让大面板点亮的格位正好凑齐某一块小面板的图案（completed_legend 读得出）；" \
        "再加两条：凑齐的那块小面板的记号色是 _lib.RESIZE_MARK、且此刻边长正好是 4。其余情况 NA。"
NOTE = "v1 没有「场地上没有角标」这个前提，第 27 步被打掉：那一关场地上有记号色角标，" \
       "点满面板的效果不是缩小而是把整块标记块搬到角标圈出的方框里（见 panel_done_teleports_me）。" \
       "第 19 步那一关场地上一个记号色格子都没有，效果才是原地减半。" \
       "「减半」仍然只有 4→2 这一个数据点，也可能是「缩成 2」；下一次在没有角标的关里点满面板才分得出来。" \
       "v3：前提从 target_box(prev) is None 改写成 arena_marks(prev) 为空——" \
       "词汇表里 target_box 已被 mark_ring/landing_box 取代，而「有没有角标」本来就是这条和传送那条的分界。" \
       "v4：开火条件从「点掉最后一个色 0 块」改成「点亮的格位凑齐某块小面板的图案」，" \
       "并把那块小面板的记号色显式传给 arena_marks——第 3 关同时挂着两块小面板，" \
       "「场上有没有角标」这句话必须问「哪一块小面板的角标」才有意义。" \
       "v5：前提从「场上一格记号也没有」放宽成「场上没有一个**合法的框**」。" \
       "第 107 步是分水岭：那一步该记号色在场上明明有四格，我照样原地减半了——" \
       "所以分界一直不是「有没有记号」，而是「有没有能进去的框」。那四格拼不出任何一种画法的角标，" \
       "于是三种结局（进框、抹标本、变尺寸）里只剩最后一种。前四次观测那个记号色一格都没有，" \
       "是「没有框」的一个特例，我把特例当成了判据。" \
       "同时加一条「此刻边长是 4」：第 111 步在边长 2 上凑齐同一块图案，结果是**涨回 4**，不是缩成 1" \
       "（见 panel_done_grows_me）。所以这个事件是 4 和 2 之间的翻转，不是单向减半；" \
       "「减半」这个词从 v1 起就一直在暗示一条本局观测不到的阶梯（8、16…），现在把它限死在 4→2 这一档上。" \
       "v6 只改 apply：缩小腾出来的格子原先写死地板色，第 115 步 97 格里错了 2 格——" \
       "(35,51) 与 (35,54) 露出来的是记号色，不是地板。这两格正是那个框的**内层**画法的两个角，" \
       "外层那圈角标一直看得见，内层这两个角一直被我自己压着。" \
       "「盖住不等于擦掉」这条第 28 步就学过，当时只补进了传送那一条，缩小这一条照旧写死地板色——" \
       "同一个教训要在所有会腾出格子的概念上各补一遍，补一条不算补。" \
       "顺带逼出词汇表的 all_mark_cells：ground_color 原先靠 mark_color 挑出唯一记号色，本关三色都在场上，它返回 None。" \
       "v7 只缩 scope，一条反例都没吃：开火条件里「那个色在场上没有合法的框」换成「凑齐的是色 15」" \
       "（_lib.RESIZE_MARK）。逼这一改的是第 300 步——那一步打的是 grows_me，" \
       "而缩小和涨大是同一台机器的两个方向，同一个借口这里也站不住：" \
       "12 次缩小全是色 15，而「色 15 在场上没有框」在全语料里恒真，两种读法因此一直同值。" \
       "现在这条概念在色 6 / 色 11 的完成上一律 NA（此前它会在「那个色刚好没框」的局面上错误开口，" \
       "第 300 步换成我是 4x4 的话，挨打的就是它）。缩小的落点与腾格那一套一字不改。"
EVIDENCE = ["bcf6976ebd8e9446", "2657799cd7a750eb", "eda8404aad485ee5", "0c33491dcfb52651",
            "018e8dd7d0448d39"]

from _lib import (FLOOR, MARK, PANEL_SIDE, RESIZE_MARK, completed_legend, facing, ground_color,
                  marker, panel)


def _fire(prev, action):
    color = completed_legend(prev, action)
    if color != RESIZE_MARK:
        return None
    m = marker(prev)
    f = facing(prev)
    if m is None or f is None or m[2] != 4:
        return None
    return m, f


def assert_(prev, action, nxt, ctx=None):
    d = _fire(prev, action)
    if d is None:
        return "NA"
    (r0, c0, k), f = d
    p = panel(nxt)
    if not p or any(color != FLOOR for color in p.values()):
        return "FALSE"
    b = marker(nxt)
    if b is None:
        return "FALSE"
    return "TRUE" if b == (r0, c0, k // 2) and facing(nxt) == f else "FALSE"


def apply(prev, action, ctx=None):
    d = _fire(prev, action)
    if d is None:
        return None
    (r0, c0, k), f = d
    out = {}
    for (t, l) in panel(prev):
        for r in range(t, t + PANEL_SIDE):
            for c in range(l, l + PANEL_SIDE):
                out[(r, c)] = FLOOR
    k2 = k // 2
    h = k2 // 2
    for r in range(r0, r0 + k):
        for c in range(c0, c0 + k):
            if r < r0 + k2 and c < c0 + k2:
                dr, dc = r - r0, c - c0
                nine = (dr < h) if f == "U" else (dr >= h) if f == "D" else \
                       (dc < h) if f == "L" else (dc >= h)
                out[(r, c)] = MARK[0] if nine else MARK[1]
            else:
                v = ground_color(prev, (r, c))
                if v is not None:
                    out[(r, c)] = v
    return out
