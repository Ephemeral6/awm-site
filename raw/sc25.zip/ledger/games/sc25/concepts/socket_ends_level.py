"""过关当且仅当这一步是方向动作、且标记块平移一个自身边长后的目标方区整块都是色 10 的插座内胆。"""
LEVEL = "L5"
SCOPE = "所有转移；没有 ctx、或标记块在 prev 里定位不到，返回 NA。"
NOTE = "第 23 步唯一一次观测：2x2 的标记块从 (19,17) 往左踏进色 10 的内胆，整屏重画、关卡 0→1。" \
       "写成「当且仅当」是故意的——只写「踏进去就过关」会是个半句，前 22 步一次都碰不到它，永远恒真。" \
       "两副口径下会变脸：预测口径里 level_next 恒等于 level_prev，所以它在那一副里永远说「不过关」。" \
       "规划器要的目标判据不该读 ctx，要读 _lib.at_socket(frame, 动作)，那一半是纯帧上的。" \
       "v2：at_socket 从这里挪进 _lib，move_iff_floor 也要用它（踏进插座那一步它不再生成「原地不动」）。" \
       "挪进词汇表就等于两条概念共用同一个没走过闸的词：如果 at_socket 读错了，这条会判错、那条会哑，" \
       "两边都不报警。所以它现在是册子里最该被另一种读法核对的一个词。" \
       "读不出（越界、点击动作）时 at_socket 返回 None，这里按「不是踏进插座」算。"
EVIDENCE = ["9dabb54dca80d95d"]

from _lib import at_socket, marker


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if marker(prev) is None:
        return "NA"
    leveled = ctx["level_next"] != ctx["level_prev"]
    return "TRUE" if leveled == (at_socket(prev, action) is True) else "FALSE"
