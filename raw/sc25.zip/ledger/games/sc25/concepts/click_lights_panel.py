"""ACTION6 点中大面板里一个还没点亮的块，而且点亮它之后凑不齐任何一块小面板的图案时，就只把那一块整块涂成色 14；别处一格不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION6 且点中的格子落在大面板某个 3x3 块内、该块在 prev 里不是色 ON；" \
        "再加一条：这一下不是收尾那一下（completed_legend 读不出）。其余情况 NA。" \
        "动作名里没带坐标、或面板读不出来，也返回 NA。右边竖条那两列不看。"
NOTE = "v1 没有「不是收尾那一下」这个前提，被第 19 步打掉：那一次点的是最后一个色 0 块，整块面板连同没点过的块一起变地板色，" \
       "标记块还缩了一半。收尾那一下是另一件事，拆出去写成 panel_done_shrinks_me；这条只管「还没点完」的常规一下。" \
       "v2 用「大面板里色 0 块数 ≥ 2」表达这个前提。" \
       "v3：第 3 关的大面板一块色 0 都没有，九块全是地板色，该点哪几格只写在小面板上——" \
       "v2 在那一关整关静默。所以前提改写成两句更弱的话：「点的这块还没亮」+「点亮它凑不齐图案」。" \
       "这把「没点亮」从「色是 0」放宽成了「色不是 ON」，是一次加大胆量的改写：" \
       "第 45 步点的那块是地板色，照样整块变 14（9 格 2→14），说明真正决定的是「亮没亮」而不是「是不是色 0」。"
EVIDENCE = ["477bf0b6c6fc98eb", "bcf6976ebd8e9446"]

from _lib import BAR_COLS, ON, PANEL_SIDE, clicked_grid, completed_legend, grid_topleft, panel_grid


def _hit(prev, action):
    cell = clicked_grid(prev, action)
    pg = panel_grid(prev)
    if cell is None or pg is None or pg.get(cell) == ON:
        return None
    if completed_legend(prev, action) is not None:
        return None
    return grid_topleft(prev, cell)


def assert_(prev, action, nxt, ctx=None):
    hit = _hit(prev, action)
    if hit is None:
        return "NA"
    t, l = hit
    box = {(r, c) for r in range(t, t + PANEL_SIDE) for c in range(l, l + PANEL_SIDE)}
    for r, row in enumerate(prev):
        for c, v in enumerate(row):
            want = ON if (r, c) in box else v
            if nxt[r][c] != want and c not in BAR_COLS:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    hit = _hit(prev, action)
    if hit is None:
        return None
    t, l = hit
    return {(r, c): ON for r in range(t, t + PANEL_SIDE) for c in range(l, l + PANEL_SIDE)}
