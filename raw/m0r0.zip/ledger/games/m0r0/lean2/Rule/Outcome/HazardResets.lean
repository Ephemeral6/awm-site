/-
# hazard_resets —— 往危险格迈一步 = 这一关从头来过

对应 Python `rule/什么算赢什么算砸/hazard_resets.py`。身份：**定义**。

这里只定义「这一步有没有块往危险格迈」。后果（`Res.reset`）**不带下一帧**：
开局长什么样是这一关的历史，不是当前状态的函数。
-/
import Obj.World

namespace Game

def hazardAt (B : Board) : Option Cell → Bool
  | some t => B.hazards.contains t
  | none   => false

/-- 两块里有一块的意图落点是危险格。 -/
def stepsOnHazard (B : Board) (s : St) (d : Dir) : Bool :=
  hazardAt B (s.pcs.d.go d) || hazardAt B (s.pcs.m.go d.mirror)

end Game
