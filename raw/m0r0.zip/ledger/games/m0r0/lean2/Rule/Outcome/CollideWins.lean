/-
# collide_wins —— 两块落到同一格 = 过关

对应 Python `rule/什么算赢什么算砸/collide_wins.py`。身份：**定义**——这就是「赢」的定义，不是一条要证的事。
-/
import Obj.World

namespace Game

def collides (p : Pieces) : Bool := p.d == p.m

end Game
