/-
# click_selects —— 点中记号就选中它，点在别处就谁都不选中

对应 Python `rule/一步怎么走/click_selects.py`。身份：**定义**。

**模型比规则说得多的一处**：Python 那一条对「点在格阵之外」闭嘴（语料里没有这种一步）；
模型每一步都得说点什么，这里按「点在别处」算（谁都不选中）。这一支在语料上没有被检验过。
-/
import Obj.World

namespace Game

def click (s : St) (x : Option Cell) : St :=
  match x with
  | some c => { s with lit := if s.markers.contains c then some c else none }
  | none   => { s with lit := none }

end Game
