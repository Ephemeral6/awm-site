/-
# wait_noop —— ACTION5 什么都不动

对应 Python `rule/一步怎么走/wait_noop.py`。身份：**定义**。计数带照样走，那归 `BandClock`。
-/
import Obj.World

namespace Game

def wait (s : St) : St := s

end Game
