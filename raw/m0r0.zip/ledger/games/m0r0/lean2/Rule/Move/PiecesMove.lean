/-
# pieces_move —— 两块怎么走

对应 Python `rule/一步怎么走/pieces_move.py`。身份：**定义**。

一块照位移走、另一块照镜像位移走；意图落点进得去就进，挡路就原地不动。
挡路的：格阵之外、墙、记号、此刻关着的门。进得去的：其余（地面、开关、开着的门、另一块此刻站的格）。
危险格不在这里：往危险格迈步的后果不是「进不去」，是整关重来（`Rule/Outcome/HazardResets.lean`），
分发在 `Step.lean` 里先问它。
-/
import Rule.Response.GateFollowsSwitch

namespace Game

def inGrid (B : Board) (x : Cell) : Bool := x.r < B.rows && x.c < B.cols

/-- 这一格此刻挡路。 -/
def blocked (B : Board) (s : St) (x : Cell) : Bool :=
  !inGrid B x || B.walls.contains x || s.markers.contains x || closedGate B s x

/-- 一块从 `x` 朝 `d` 走一步落在哪。 -/
def land (B : Board) (s : St) (x : Cell) (d : Dir) : Cell :=
  match x.go d with
  | none   => x
  | some t => if blocked B s t || B.hazards.contains t then x else t

/-- 两块各落在哪：`d` 那一块照位移，`m` 那一块照镜像位移。 -/
def pieceMove (B : Board) (s : St) (d : Dir) : Pieces :=
  ⟨land B s s.pcs.d d, land B s s.pcs.m d.mirror⟩

end Game
