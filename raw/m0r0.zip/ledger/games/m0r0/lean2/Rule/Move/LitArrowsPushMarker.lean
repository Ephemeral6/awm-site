/-
# lit_arrows_push_marker —— 选中了记号时，方向键推的是记号

对应 Python `rule/一步怎么走/lit_arrows_push_marker.py`。身份：**定义**。

两块不动；被选中的记号照位移（**不是**镜像位移）挪一格——落点进得去、不是危险格、
没有块站着才挪，否则原地；挪完仍是选中态。
-/
import Rule.Move.PiecesMove

namespace Game

/-- 被选中的记号从 `x` 朝 `d` 推一步落在哪。 -/
def markerDest (B : Board) (s : St) (x : Cell) (d : Dir) : Cell :=
  match x.go d with
  | none   => x
  | some t => if blocked B s t || B.hazards.contains t || s.pcs.covers t then x else t

/-- 把选中的那个记号从 `x` 挪到 `y`，选中跟着它走。 -/
def moveLit (s : St) (x y : Cell) : St :=
  { s with markers := s.markers.map (fun z => if z == x then y else z), lit := some y }

def pushMarker (B : Board) (s : St) (d : Dir) : St :=
  match s.lit with
  | none   => s
  | some x => moveLit s x (markerDest B s x d)

end Game
