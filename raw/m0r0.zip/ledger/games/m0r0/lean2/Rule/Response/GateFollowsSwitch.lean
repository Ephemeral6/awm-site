/-
# gate_follows_switch —— **某色的门开着，当且仅当有块站在同色的开关上**

对应 Python `rule/世界怎么回应/gate_follows_switch.py`。身份：**定义**。

Python 那一条只能在帧上看得见变化的地方判（踏上 / 走开 / 其余不变三支）；
这里按世界写：门开不开是一个**算**出来的量，读的是这一刻两块站在哪。
「门在块脚底下关上、块照样站得住」也就不用另说——关着的门只挡**进**，不挡**站**。
-/
import Obj.World

namespace Game

/-- 色 `k` 的门此刻开着：有块站在一个 `k` 色开关上。 -/
def gateOpen (B : Board) (s : St) (k : Nat) : Bool :=
  B.switches.any (fun w => w.tint == k && s.pcs.covers w.cell)

/-- 这一格是一格此刻关着的门。 -/
def closedGate (B : Board) (s : St) (x : Cell) : Bool :=
  B.gates.any (fun g => g.cell == x && !gateOpen B s g.tint)

end Game
