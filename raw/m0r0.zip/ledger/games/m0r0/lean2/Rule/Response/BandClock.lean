/-
# band_clock —— 计数带是一只时钟

对应 Python `rule/世界怎么回应/band_clock.py`。身份：**定义**。

这一关走了 m 步之后，带长 = round(64·m / 150) = (64·m + 75) div 150。每一步（不论按了什么）m 加一；
往危险格迈步、这一关从头来过时不归零（那一步模型不说下一帧，见 `Proof/Levels.lean` 里那条明写的假设）。
-/
import Obj.World

namespace Game

def band (m : Tick) : Band := (64 * m + 75) / 150

/-- 又过了一步。 -/
def tick (s : St) : St := { s with tick := s.tick + 1 }

end Game
