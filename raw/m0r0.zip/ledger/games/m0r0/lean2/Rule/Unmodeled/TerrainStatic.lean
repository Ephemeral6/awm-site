/-
# terrain_static —— 同一关内地形是死的

对应 Python `rule/说了但不进模型/terrain_static.py`。身份：**不进模型**。

理由：**表示不出来**。墙与危险格住在 `Board` 里，而 `Board` 不是 `St` 的字段——
`step : Board → St → Act → Res` 读它、不返回它，于是「走一步墙会变」在模型里连写都写不出来，
这句话没有一个能被陈述的反面，所以这里一个定义、一条定理都没有。

两个数（卡 08 要求「不进模型」那一组固定打两个）在 Python 那一侧跑，落在
`analysis/readings.json` 的 `terrain_static` 一行：论域条数、被驳倒几次。
这个架构选择要是错了，是那一行先红，然后 `Board` 就得拆。
-/
import Obj.World
