/-
# Corpus —— 模型面对全部真实转移（`lean2/export_corpus.py` 生成，不要手改）

逐条那一层：每一步都从**观测到的那一帧**重新起算，按纤维判（`Obs/Check.lean` 的 `agrees`）。
观测只在 `Obs/Replay.lean` 一份；这里只切，外加 Python 规则层的**预期计数**——
内核算出来的和预期不一样，这一份就编不过。逐行那一串由 `lean2/verify.py` 和 Python 逐行对账。

读数不是定理：`#eval` 走求值器。结论是下面三条走内核的定理。
-/
import Obs.Replay

namespace Game
namespace Corpus

set_option maxRecDepth 100000

def verdicts : List Tri := Replay.cases.map agrees

def countOf (t : Tri) : Nat := (verdicts.filter (· == t)).length

/-- 用例条数钉住：切歪了会得到空表，空表之下「判错 0」平凡为真。 -/
theorem corpus_cases_len : Replay.cases.length = 485 := by decide +kernel

/-- **模型没被语料驳倒**：485 条真实转移里，判错的一条都没有。 -/
theorem corpus_no_false : countOf .no = 0 := by decide +kernel

/-- 对上几条、闭嘴几条——**和 Python 规则层的预期逐个数对上**（预期：对上 483、闭嘴 2）。 -/
theorem corpus_tally : (countOf .yes, countOf .na) = (483, 2) := by decide +kernel

#print axioms corpus_cases_len
#print axioms corpus_no_false
#print axioms corpus_tally

def code : Tri → String
  | .yes => "y"
  | .no  => "n"
  | .na  => "a"

#eval "CORPUS " ++ String.join (verdicts.map code)

end Corpus
end Game
