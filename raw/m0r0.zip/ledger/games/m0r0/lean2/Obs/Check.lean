/-
# Check —— **判据层**：模型面对观测。这一份里**没有一条定理**，尺子不自证。

两把尺子，分量差得很远：

    agrees    **一条转移**：从观测到的那一帧起算一步，和看到的下一帧比 —— 模型每步都被拉回正轨
    traceOk   **一整段路**：只有开局那一帧是观测给的，后面全是模型自己算的

## `Seen`：只装帧上看得见的

两块（无序）、记号（无序）、选中、此刻关着且没被块盖住的门格、没被块盖住的开关、带长。
**帧上读不出顺序的一律按集合比**（`setEq`）：推记号是原地替换，列表不再有序，
拿它和帧上读出来的比会判出一片假 FALSE——那不是模型错，是判据读了一位帧上没有的信息。
墙和危险格不在 `Seen` 里：它们在 `Board` 里，模型一步也改不了它们。

## 纤维：一帧对应好几个世界

帧上读不出两位：哪一块是 direct（两种标法）、这一关走了几步（带长对应几种步数）。
逐条判时对纤维里的每一个世界各算一步：

    有一个对上了                  ⇒ yes   模型真的做了预测，而且应验
    都没对上，但有一个说不出话     ⇒ na    说不出话不是反对（往危险格迈步：重来之后的开局是历史）
    都没对上，也没有说不出话的     ⇒ no    模型被这一帧证伪
-/
import Step

namespace Game

/-- 帧上看得见的那一部分。 -/
structure Seen where
  pcs      : List Cell
  markers  : List Cell
  lit      : Option Cell
  gates    : List Cell       -- 此刻关着、没被块盖住的门格
  switches : List Cell       -- 没被块盖住的开关
  band     : Nat
deriving DecidableEq, Repr

def setEq (a b : List Cell) : Bool :=
  a.length == b.length && a.all (fun x => b.contains x) && b.all (fun x => a.contains x)

def Seen.agree (x y : Seen) : Bool :=
  setEq x.pcs y.pcs && setEq x.markers y.markers && x.lit == y.lit &&
  setEq x.gates y.gates && setEq x.switches y.switches && x.band == y.band

/-- 模型的状态在帧上会长成什么样。 -/
def seenOf (B : Board) (s : St) : Seen :=
  { pcs := [s.pcs.d, s.pcs.m]
    markers := s.markers
    lit := s.lit
    gates := (B.gates.filter (fun g => !gateOpen B s g.tint && !s.pcs.covers g.cell)).map (·.cell)
    switches := (B.switches.filter (fun w => !s.pcs.covers w.cell)).map (·.cell)
    band := band s.tick }

inductive Tri where
  | yes | no | na
deriving DecidableEq, Repr

/-- 语料里的一条转移。上一帧只装读得到的：两块（无序的 `a` `b`）、记号、选中、带长。 -/
structure Case where
  seq     : Nat
  board   : Board          -- 这一步前后两帧拼起来的盘（见 `Obs/Replay.lean` 文件头的口径）
  a       : Cell
  b       : Cell
  markers : List Cell
  lit     : Option Cell
  band    : Nat
  act     : Act
  up      : Bool           -- 现实那一侧：这一步换关了没有（上游 meta 给的，模型看不到它）
  next    : Option Seen    -- 下一帧读得到的；最后一关过关那一步的下一帧是终局画面，为 none
deriving Repr

/-- 带长 `b` 对应哪几种步数。 -/
def ticksFor (b : Nat) : List Nat := (List.range 151).filter (fun m => band m == b)

/-- 这一帧对应的全部世界：两种标法 × 几种步数。 -/
def fiber (c : Case) : List St :=
  (ticksFor c.band).flatMap (fun m =>
    [⟨⟨c.a, c.b⟩, c.markers, c.lit, m⟩, ⟨⟨c.b, c.a⟩, c.markers, c.lit, m⟩])

def judge (c : Case) : Res → Tri
  | .won   => if c.up then .yes else .no
  | .reset => if c.up then .no else .na
  | .ok s  =>
    if c.up then .no else
    match c.next with
    | some o => if (seenOf c.board s).agree o then .yes else .no
    | none   => .no

def combine (ts : List Tri) : Tri :=
  if ts.contains .yes then .yes else if ts.contains .na then .na else .no

/-- **一条转移**对不对。 -/
def agrees (c : Case) : Tri := combine ((fiber c).map (fun s => judge c (step c.board s c.act)))

/-- **一整段路**对不对：下一轮喂进去的是模型自己算出来的状态，不是观测到的那一帧。 -/
def traceOk (B : Board) : St → List (Act × Seen) → Bool
  | _, []             => true
  | s, (a, o) :: rest =>
    match step B s a with
    | .ok s' => (seenOf B s').agree o && traceOk B s' rest
    | _      => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (B : Board) : St → List (Act × Seen) → Nat → Option Nat
  | _, [],             _ => none
  | s, (a, o) :: rest, i =>
    match step B s a with
    | .ok s' => if (seenOf B s').agree o then firstSplit B s' rest (i + 1) else some i
    | _      => some i

end Game
