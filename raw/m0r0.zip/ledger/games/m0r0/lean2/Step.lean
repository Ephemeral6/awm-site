/-
# Step —— 一步怎么走：**只做分发，0 条定理**

对象、规则全是定义；这里把它们按动作拼起来，一条定理都没有。
规则写成定理的那一轮是白做的：`step` 本来就是照着规则写的，证它等于用它自己证它自己。

分发的次序就是规则之间的优先级，写在这里一处：
选中态 → 方向键推记号；否则有块往危险格迈 → 重来；否则两块落到一格 → 过关；否则平常一步。
每一步（不论结果是不是平常一步）计数带的时钟都走一格——`Res.ok` 那几支里的 `tick`。
-/
import Rule.Move.PiecesMove
import Rule.Move.LitArrowsPushMarker
import Rule.Move.ClickSelects
import Rule.Move.WaitNoop
import Rule.Outcome.CollideWins
import Rule.Outcome.HazardResets
import Rule.Response.BandClock
import Rule.Unmodeled.TerrainStatic

namespace Game

def moveStep (B : Board) (s : St) (d : Dir) : Res :=
  if s.lit.isSome then .ok (tick (pushMarker B s d))
  else if stepsOnHazard B s d then .reset
  else if collides (pieceMove B s d) then .won
  else .ok (tick { s with pcs := pieceMove B s d })

def step (B : Board) (s : St) : Act → Res
  | .move d  => moveStep B s d
  | .click x => .ok (tick (click s x))
  | .wait    => .ok (tick (wait s))

end Game
