/-
# Scenes —— 一张教学盘讲清镜像钥匙，外加**三条防线**

一个把什么都判成「走不通」的判据也能满绿（它从不说能赢，就永远不会被反例打死）。
所以「走不通」那张盘配一张**只差一格**的盘，三条缺一不可：

    scene_stuck_unsolvable   3×5 的走廊，两块镜像站在中轴两侧，中轴那一格是墙 —— 走不通
    scene_open_winnable      同一张盘只把中轴那一格改成地面 —— 一步就撞上
    scene_closed_at_start    而且不是因为它一开始就撞在一起
    scene_open_not_key       而且对照盘上钥匙的前提**真的不满足**（中轴那一格不会让块停下）

第四条把「套不上钥匙」钉死在「前提不满足」，而不是「前提满足、只是我没证出来」。

盘长这样（`#` 墙，`d` / `m` 两块，`X` 是两张盘唯一不同的那一格）：

    # # # # #
    # d X m #
    # # # # #

**不经过重置**：`Unsolvable` 的意思是不经过重置就赢不了——这张盘上没有危险格，那一支走不到。
-/
import Proof.MirrorKey

namespace Game
namespace Scenes

def ring : List Cell :=
  [⟨0, 0⟩, ⟨0, 1⟩, ⟨0, 2⟩, ⟨0, 3⟩, ⟨0, 4⟩, ⟨1, 0⟩, ⟨1, 4⟩, ⟨2, 0⟩, ⟨2, 1⟩, ⟨2, 2⟩, ⟨2, 3⟩, ⟨2, 4⟩]

/-- 中轴那一格是墙。 -/
def stuck : Board := ⟨3, 5, ⟨1, 2⟩ :: ring, [], [], []⟩
/-- 只差一格：中轴那一格是地面。 -/
def opened : Board := ⟨3, 5, ring, [], [], []⟩

def start : St := ⟨⟨⟨1, 1⟩, ⟨1, 3⟩⟩, [], none, 0⟩

/-- 一个固定的状态：没有门、没有记号的盘上，「会不会停」和状态无关，拿它当代表。 -/
def canon : St := ⟨⟨⟨0, 0⟩, ⟨0, 0⟩⟩, [], none, 0⟩

theorem stop_canon (B : Board) (s : St) (t : Cell) (hm : s.markers = []) (hg : B.gates = []) :
    stop B s t = stop B canon t := by
  unfold stop blocked closedGate
  rw [hm, hg]
  rfl

theorem stop_out_row (B : Board) (s : St) (r c : Nat) (h : B.rows ≤ r) : stop B s ⟨r, c⟩ = true := by
  unfold stop blocked inGrid
  have : ¬ r < B.rows := by omega
  simp [this]

theorem stuck_symm : ∀ s : St, s.markers = [] → symmetric stuck s := by
  intro s hm r c hc
  rw [stop_canon _ _ _ hm rfl, stop_canon _ _ _ hm rfl]
  have hc' : c < 5 := hc
  rcases Nat.lt_or_ge r 3 with hr | hr
  · rcases (by omega : r = 0 ∨ r = 1 ∨ r = 2) with rfl | rfl | rfl <;>
    rcases (by omega : c = 0 ∨ c = 1 ∨ c = 2 ∨ c = 3 ∨ c = 4) with rfl | rfl | rfl | rfl | rfl <;>
    decide
  · rw [stop_out_row _ _ _ _ hr, stop_out_row _ _ _ _ hr]

theorem stuck_axis : ∀ (s : St) (r c : Nat), s.markers = [] → c + c + 1 = stuck.cols →
    stop stuck s ⟨r, c⟩ = true := by
  intro s r c hm hc
  have hc' : c + c + 1 = 5 := hc
  have : c = 2 := by omega
  subst this
  rw [stop_canon _ _ _ hm rfl]
  rcases Nat.lt_or_ge r 3 with hr | hr
  · rcases (by omega : r = 0 ∨ r = 1 ∨ r = 2) with rfl | rfl | rfl <;> decide
  · exact stop_out_row _ _ _ _ hr

theorem stuck_keyboard : KeyBoard stuck := ⟨rfl, stuck_symm, stuck_axis⟩

theorem start_key : Key stuck start := by
  unfold Key mirrorPair start stuck
  decide

/-- **这张盘走不通**（不经过重置）。挂钥匙，没有一处枚举。 -/
theorem scene_stuck_unsolvable : Unsolvable stuck start :=
  unsolvable_by_mirror_key stuck stuck_keyboard start start_key

/-- 防线一：只差一格的盘，**一步就撞上**（内核算）。 -/
theorem scene_open_winnable : Winnable opened start := ⟨[.move .right], by decide +kernel⟩

/-- 防线二：不是因为它一开始就撞在一起。 -/
theorem scene_closed_at_start : start.pcs.d ≠ start.pcs.m := by decide

/-- 防线三：对照盘上钥匙的前提**真的不满足**——中轴那一格不会让块停下。 -/
theorem scene_open_not_key : ¬ KeyBoard opened := by
  intro kb
  have h := kb.axis start 1 2 rfl rfl
  exact absurd h (by decide)

/-- 两句话不能同时成立（对照盘上）：顺手核一遍 `not_both` 用得上。 -/
theorem scene_open_not_unsolvable : ¬ Unsolvable opened start :=
  fun u => not_both opened start scene_open_winnable u

#print axioms stop_canon
#print axioms stop_out_row
#print axioms stuck_symm
#print axioms stuck_axis
#print axioms stuck_keyboard
#print axioms start_key
#print axioms scene_stuck_unsolvable
#print axioms scene_open_winnable
#print axioms scene_closed_at_start
#print axioms scene_open_not_key
#print axioms scene_open_not_unsolvable

end Scenes
end Game
