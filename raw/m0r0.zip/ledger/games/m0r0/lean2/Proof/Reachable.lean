/-
# Reachable —— 这个**局面**做不做得了

整套形式化里只有两句话是要证的：

    Winnable   B s  :=  ∃ as, 照着走中途赢过
    Unsolvable B s  :=  ∀ as, 照着走从没赢过

**「合法的一步」不另写谓词**：`Act` 这个类型本身就限死了——位移只有四个方向各一格
（`Obj/Geometry/Delta.lean`），点击不搬块，ACTION5 什么都不动。表示不出别的动作。

## 写在明处的削弱：**不经过重置**

`everWon` 碰到 `Res.reset`（往危险格迈步、这一关从头来过）返回 `false`——模型说不出重来之后的样子。
于是 `Unsolvable B s` 的准确意思是「**不经过重置**就赢不了」。`∀ as` 这个形状一个字都看不出来，
所以这半句写在这里、写在 `Levels.lean`、写在页面上。这一局六关都有「走得通」的定理，
没有一条「走不通」的宣告；这一句是给以后要写钥匙的人留的。
-/
import Step

namespace Game

/-- 从 `s` 出发照着 `as` 走，中途赢过没有。重来那一支返回 `false`（见文件头）。 -/
def everWon (B : Board) : St → List Act → Bool
  | _, []      => false
  | s, a :: as =>
    match step B s a with
    | .won   => true
    | .reset => false
    | .ok s' => everWon B s' as

def Winnable (B : Board) (s : St) : Prop := ∃ as : List Act, everWon B s as = true

def Unsolvable (B : Board) (s : St) : Prop := ∀ as : List Act, everWon B s as = false

/-- 两句话不能同时成立。 -/
theorem not_both (B : Board) (s : St) (h : Winnable B s) (u : Unsolvable B s) : False := by
  obtain ⟨as, ha⟩ := h
  have := u as
  rw [this] at ha
  exact Bool.false_ne_true ha

/-- **骨架**：不变量 ⇒ 不经过重置就赢不了。全文唯一做归纳的地方，与盘面大小、动作串长短都无关。 -/
theorem unsolvable_of_invariant (B : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, P s → step B s a = Res.ok s' → P s')
    (hwin : ∀ s a, P s → step B s a ≠ Res.won) :
    ∀ s, P s → Unsolvable B s := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hstep : step B s a with
    | won => exact absurd hstep (hwin s a hp)
    | reset => rfl
    | ok s' => exact ih s' (hkeep s s' a hp hstep)

#print axioms not_both
#print axioms unsolvable_of_invariant

end Game
