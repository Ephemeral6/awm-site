/-
# MirrorKey —— 一把「走不通」的钥匙：**对称盘上的镜像两块，中轴全堵就永远撞不上**

这一局的六关都走得通（`Proof/Levels.lean`），没有一关宣告走不通。这一把钥匙是给**局面**用的：
拿到一张盘，看出它为什么走不通，再把那个理由写成一条严谨的定理。
第 5 关就是这个形状差一点——对称盘、镜像开局、中轴那一列是危险格与墙，**只留了一个记号的缺口**；
推开记号（盘不再是「没有记号」）就不满足这把钥匙的前提，所以那一关走得通不矛盾。

## 不变量 Φ

    两块互为镜像 ∧ 盘上没有记号 ∧ 没有选中 ∧ 两块不在同一格

盘的前提：没有门（门的开合随块站在哪变，会破坏对称）、通行图对称、**中轴上每一格都会让块停下来**
（列宽为偶数时中轴根本不存在，这一条自动成立——那是一把纯算术的钥匙，一个障碍都不用）。

## 为什么撞不上（证明里没有枚举、没有搜索，与盘多大无关）

撞到一格要两块落在同一格；两块互为镜像，同一格只能在中轴上。一块要落上中轴，
要么它原来就在那里（那另一块也在，两块同格，Φ 排除了），要么它这一步走进去——而中轴每一格都会让它停下。

## 写在明处的削弱

`Unsolvable` 用的 `everWon` 碰到「重来」那一支返回 false：这把钥匙说的是「**不经过重置**就赢不了」。
-/
import Derived.MirrorPairPersists
import Proof.Reachable

namespace Game

/-- 盘的前提。 -/
structure KeyBoard (B : Board) : Prop where
  noGates : B.gates = []
  symm    : ∀ s : St, s.markers = [] → symmetric B s
  axis    : ∀ (s : St) (r c : Nat), s.markers = [] → c + c + 1 = B.cols → stop B s ⟨r, c⟩ = true

/-- 不变量。 -/
def Key (B : Board) (s : St) : Prop :=
  mirrorPair B.cols s.pcs ∧ s.markers = [] ∧ s.lit = none ∧ s.pcs.d ≠ s.pcs.m

theorem cell_eq (a b : Cell) (h1 : a.r = b.r) (h2 : a.c = b.c) : a = b := by
  cases a; cases b; simp_all

/-- 一块落在 `X` 上：要么原地，要么这一步走进了一格不会让它停下来的 `X`。 -/
theorem land_cases (B : Board) (s : St) (x : Cell) (d : Dir) :
    land B s x d = x ∨ stop B s (land B s x d) = false := by
  rw [land_eq]
  cases h : x.go d with
  | none => left; rfl
  | some t =>
    simp only
    by_cases hs : stop B s t = true
    · left; simp [hs]
    · right; simp [hs]

theorem key_no_collide (B : Board) (kb : KeyBoard B) (s : St) (d : Dir) (hk : Key B s) :
    collides (pieceMove B s d) = false := by
  obtain ⟨hm, hmk, _, hne⟩ := hk
  obtain ⟨hr, hc⟩ := hm
  unfold collides
  cases hx : decide ((pieceMove B s d).d = (pieceMove B s d).m) with
  | false => simpa using hx
  | true =>
    exfalso
    have heq : (pieceMove B s d).d = (pieceMove B s d).m := of_decide_eq_true hx
    have hmir := pieceMove_mirror B s d (kb.symm s hmk) ⟨hr, hc⟩
    obtain ⟨_, hc'⟩ := hmir
    rw [heq] at hc'
    -- 落点 X 在中轴上：X.c + X.c + 1 = 列宽
    have hax := kb.axis s (pieceMove B s d).m.r (pieceMove B s d).m.c hmk hc'
    rcases land_cases B s s.pcs.d d with h1 | h1
    · -- d 那块原地：它原来就在中轴上，另一块作为镜像也在同一格
      have hd : (pieceMove B s d).d = s.pcs.d := h1
      rw [heq] at hd
      apply hne
      have : (pieceMove B s d).m.c = s.pcs.d.c := by rw [hd]
      exact cell_eq _ _ hr (by omega)
    · have hd : stop B s (pieceMove B s d).d = false := h1
      rw [heq] at hd
      have : stop B s ⟨(pieceMove B s d).m.r, (pieceMove B s d).m.c⟩ = false := hd
      rw [hax] at this
      exact Bool.noConfusion this

theorem key_keep (B : Board) (kb : KeyBoard B) :
    ∀ s s' a, Key B s → step B s a = Res.ok s' → Key B s' := by
  intro s s' a hk h
  obtain ⟨hm, hmk, hl, hne⟩ := hk
  cases a with
  | move d =>
    simp only [step, moveStep, hl, Option.isSome_none] at h
    split at h
    · contradiction
    · split at h
      · cases h
      · split at h
        · cases h
        · rename_i hcol
          injection h with h
          subst h
          unfold Key
          simp only [tick]
          refine ⟨pieceMove_mirror B s d (kb.symm s hmk) hm, hmk, trivial, ?_⟩
          intro heq
          apply hcol
          unfold collides
          simp [heq]
  | click x =>
    simp only [step] at h
    injection h with h
    subst h
    unfold Key
    cases x with
    | none => exact ⟨hm, hmk, rfl, hne⟩
    | some c => simp only [click, tick, hmk]; exact ⟨hm, trivial, by simp, hne⟩
  | wait =>
    simp only [step] at h
    injection h with h
    subst h
    unfold Key
    exact ⟨hm, hmk, hl, hne⟩

theorem key_no_win (B : Board) (kb : KeyBoard B) : ∀ s a, Key B s → step B s a ≠ Res.won := by
  intro s a hk h
  have hl := hk.2.2.1
  cases a with
  | move d =>
    simp only [step, moveStep, hl, Option.isSome_none] at h
    split at h
    · contradiction
    · split at h
      · cases h
      · split at h
        · rename_i hcol
          rw [key_no_collide B kb s d hk] at hcol
          exact Bool.noConfusion hcol
        · cases h
  | click x => simp [step] at h
  | wait => simp [step] at h

/-- **钥匙**：满足前提的盘上，从满足 Φ 的局面出发，**不经过重置**就赢不了。挂在骨架上，没有证明体。 -/
theorem unsolvable_by_mirror_key (B : Board) (kb : KeyBoard B) (s : St) (h : Key B s) : Unsolvable B s :=
  unsolvable_of_invariant B (Key B) (key_keep B kb) (key_no_win B kb) s h

#print axioms cell_eq
#print axioms land_cases
#print axioms key_no_collide
#print axioms key_keep
#print axioms key_no_win
#print axioms unsolvable_by_mirror_key

end Game
