/-
# Levels —— 每一关一条定理（`lean2/export_levels.py` 生成，**不要手改**）

    L<n>_trace       成绩单认证的那一段：沿真人走过的路，模型每一帧都和观测对上
    L<n>_play_len    那一段核过几步（空表会让上一条平凡为真）
    L<n>_winnable    这一关走得通 —— 见证就是那一段路，再加上过关那一脚

    A<n>_trace       探索段（**不当见证**）：同一关另一次真实走法，同样逐帧对上
    A<n>_tail_trace  探索段里撞过危险格的那两关，重来之后的那一截

只有开局那一帧是观测给的（`Replay.startOf`），**后面全是模型自己算的**。
开局挑哪一块当 direct（`_swap`）是导出器按真实下一帧追出来的猜测；挑错了 `_trace` 编不过。

## 明写的假设

**往危险格迈步之后，两块、记号、选中回到这一关的开局；计数带的时钟接着走。**
它不进模型（开局是历史，`Res.reset` 不带下一帧）。`A<n>_tail_trace` 就从「开局 + 接着走的时钟」起算，
假设要是错的，那一截第一帧就对不上。**没红不构成证明**——这是这条假设在这批语料上
唯一一次有机会被驳倒，不是它被证明了。

## 写在明处的削弱

`Winnable` 用的 `everWon` 在「重来」那一支返回 false（`Proof/Reachable.lean`）。
这里全是「走得通」，那一支只会让见证更难成立，不会让它更容易——但同一个 `everWon`
若拿去写「走不通」，意思就是「**不经过重置**就赢不了」。
-/
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

set_option maxRecDepth 100000


/-! ## 第 0 关（认证段，行 271–285） -/

def L0_board : Board := Replay.levelBoard 1 0
def L0_swap : Bool := false
/-- 第 0 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L0_startWith (swap : Bool) : St := Replay.startOf 272 swap 0
/-- 第 0 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L0_start : St := L0_startWith L0_swap
/-- 开局到过关前一步，14 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L0_play : List (Act × Seen) := Replay.playFrom 272 14
def L0_acts : List Act := L0_play.map Prod.fst ++ [Replay.actAt 286]

#eval match firstSplit L0_board L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

theorem L0_play_len : L0_play.length = 14 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L0_trace : traceOk L0_board L0_start L0_play = true := by decide +kernel

/-- **第 0 关走得通。** 见证是那 14 步再加过关那一脚，内核从开局算到底。 -/
theorem L0_winnable : Winnable L0_board L0_start := ⟨L0_acts, by decide +kernel⟩

#print axioms L0_play_len
#print axioms L0_trace
#print axioms L0_winnable

/-! ## 第 1 关（认证段，行 286–308） -/

def L1_board : Board := Replay.levelBoard 1 1
def L1_swap : Bool := false
/-- 第 1 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L1_startWith (swap : Bool) : St := Replay.startOf 287 swap 0
/-- 第 1 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L1_start : St := L1_startWith L1_swap
/-- 开局到过关前一步，22 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L1_play : List (Act × Seen) := Replay.playFrom 287 22
def L1_acts : List Act := L1_play.map Prod.fst ++ [Replay.actAt 309]

#eval match firstSplit L1_board L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

theorem L1_play_len : L1_play.length = 22 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L1_trace : traceOk L1_board L1_start L1_play = true := by decide +kernel

/-- **第 1 关走得通。** 见证是那 22 步再加过关那一脚，内核从开局算到底。 -/
theorem L1_winnable : Winnable L1_board L1_start := ⟨L1_acts, by decide +kernel⟩

#print axioms L1_play_len
#print axioms L1_trace
#print axioms L1_winnable

/-! ## 第 2 关（认证段，行 309–385） -/

def L2_board : Board := Replay.levelBoard 1 2
def L2_swap : Bool := false
/-- 第 2 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L2_startWith (swap : Bool) : St := Replay.startOf 310 swap 0
/-- 第 2 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L2_start : St := L2_startWith L2_swap
/-- 开局到过关前一步，76 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L2_play : List (Act × Seen) := Replay.playFrom 310 76
def L2_acts : List Act := L2_play.map Prod.fst ++ [Replay.actAt 386]

#eval match firstSplit L2_board L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

theorem L2_play_len : L2_play.length = 76 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L2_trace : traceOk L2_board L2_start L2_play = true := by decide +kernel

/-- **第 2 关走得通。** 见证是那 76 步再加过关那一脚，内核从开局算到底。 -/
theorem L2_winnable : Winnable L2_board L2_start := ⟨L2_acts, by decide +kernel⟩

#print axioms L2_play_len
#print axioms L2_trace
#print axioms L2_winnable

/-! ## 第 3 关（认证段，行 386–400） -/

def L3_board : Board := Replay.levelBoard 1 3
def L3_swap : Bool := true
/-- 第 3 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L3_startWith (swap : Bool) : St := Replay.startOf 387 swap 0
/-- 第 3 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L3_start : St := L3_startWith L3_swap
/-- 开局到过关前一步，14 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L3_play : List (Act × Seen) := Replay.playFrom 387 14
def L3_acts : List Act := L3_play.map Prod.fst ++ [Replay.actAt 401]

#eval match firstSplit L3_board L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

theorem L3_play_len : L3_play.length = 14 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L3_trace : traceOk L3_board L3_start L3_play = true := by decide +kernel

/-- **第 3 关走得通。** 见证是那 14 步再加过关那一脚，内核从开局算到底。 -/
theorem L3_winnable : Winnable L3_board L3_start := ⟨L3_acts, by decide +kernel⟩

#print axioms L3_play_len
#print axioms L3_trace
#print axioms L3_winnable

/-! ## 第 4 关（认证段，行 401–440） -/

def L4_board : Board := Replay.levelBoard 1 4
def L4_swap : Bool := true
/-- 第 4 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L4_startWith (swap : Bool) : St := Replay.startOf 402 swap 0
/-- 第 4 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L4_start : St := L4_startWith L4_swap
/-- 开局到过关前一步，39 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L4_play : List (Act × Seen) := Replay.playFrom 402 39
def L4_acts : List Act := L4_play.map Prod.fst ++ [Replay.actAt 441]

#eval match firstSplit L4_board L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

theorem L4_play_len : L4_play.length = 39 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L4_trace : traceOk L4_board L4_start L4_play = true := by decide +kernel

/-- **第 4 关走得通。** 见证是那 39 步再加过关那一脚，内核从开局算到底。 -/
theorem L4_winnable : Winnable L4_board L4_start := ⟨L4_acts, by decide +kernel⟩

#print axioms L4_play_len
#print axioms L4_trace
#print axioms L4_winnable

/-! ## 第 5 关（认证段，行 441–485） -/

def L5_board : Board := Replay.levelBoard 1 5
def L5_swap : Bool := false
/-- 第 5 关开局那一帧，挑哪一块当 direct 由 `swap` 定（`Broken.lean` 拿反过来的那一种当破坏测试）。 -/
def L5_startWith (swap : Bool) : St := Replay.startOf 442 swap 0
/-- 第 5 关的真实开局：成绩单认证那一段里这一关第一帧，**从语料读出来的**。 -/
def L5_start : St := L5_startWith L5_swap
/-- 开局到过关前一步，44 步。过关那一脚不在这里：那一步的下一帧是另一关的盘。 -/
def L5_play : List (Act × Seen) := Replay.playFrom 442 44
def L5_acts : List Act := L5_play.map Prod.fst ++ [Replay.actAt 486]

#eval match firstSplit L5_board L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

theorem L5_play_len : L5_play.length = 44 := by decide +kernel

/-- **模型沿着真人的路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L5_trace : traceOk L5_board L5_start L5_play = true := by decide +kernel

/-- **第 5 关走得通。** 见证是那 44 步再加过关那一脚，内核从开局算到底。 -/
theorem L5_winnable : Winnable L5_board L5_start := ⟨L5_acts, by decide +kernel⟩

#print axioms L5_play_len
#print axioms L5_trace
#print axioms L5_winnable

/-! ## 第 0 关（探索段，行 0–19；**不当见证**） -/

def A0_board : Board := Replay.levelBoard 0 0
def A0_swap : Bool := false
def A0_start : St := Replay.startOf 1 A0_swap 0
def A0_play : List (Act × Seen) := Replay.playFrom 1 19

theorem A0_play_len : A0_play.length = 19 := by decide +kernel
theorem A0_trace : traceOk A0_board A0_start A0_play = true := by decide +kernel

#print axioms A0_play_len
#print axioms A0_trace

/-! ## 第 1 关（探索段，行 20–54；**不当见证**） -/

def A1_board : Board := Replay.levelBoard 0 1
def A1_swap : Bool := false
def A1_start : St := Replay.startOf 21 A1_swap 0
def A1_play : List (Act × Seen) := Replay.playFrom 21 11

theorem A1_play_len : A1_play.length = 11 := by decide +kernel
theorem A1_trace : traceOk A1_board A1_start A1_play = true := by decide +kernel

#print axioms A1_play_len
#print axioms A1_trace

/-- 第 1 关探索段第 1 次往危险格迈步（行 31）之后的那一截，22 步。
    **起点用了那条明写的假设**：两块、记号、选中回到开局，时钟接着走（已走 12 步）。 -/
def A1_tail1_start : St := { A1_start with tick := 12 }
def A1_tail1 : List (Act × Seen) := Replay.playFrom 33 22

theorem A1_tail1_len : A1_tail1.length = 22 := by decide +kernel
/-- 那条假设唯一一次有机会被驳倒的地方。**没红不构成证明。** -/
theorem A1_tail1_trace : traceOk A1_board A1_tail1_start A1_tail1 = true := by decide +kernel

#print axioms A1_tail1_len
#print axioms A1_tail1_trace

/-! ## 第 2 关（探索段，行 55–155；**不当见证**） -/

def A2_board : Board := Replay.levelBoard 0 2
def A2_swap : Bool := false
def A2_start : St := Replay.startOf 56 A2_swap 0
def A2_play : List (Act × Seen) := Replay.playFrom 56 100

theorem A2_play_len : A2_play.length = 100 := by decide +kernel
theorem A2_trace : traceOk A2_board A2_start A2_play = true := by decide +kernel

#print axioms A2_play_len
#print axioms A2_trace

/-! ## 第 3 关（探索段，行 156–177；**不当见证**） -/

def A3_board : Board := Replay.levelBoard 0 3
def A3_swap : Bool := true
def A3_start : St := Replay.startOf 157 A3_swap 0
def A3_play : List (Act × Seen) := Replay.playFrom 157 8

theorem A3_play_len : A3_play.length = 8 := by decide +kernel
theorem A3_trace : traceOk A3_board A3_start A3_play = true := by decide +kernel

#print axioms A3_play_len
#print axioms A3_trace

/-- 第 3 关探索段第 1 次往危险格迈步（行 164）之后的那一截，12 步。
    **起点用了那条明写的假设**：两块、记号、选中回到开局，时钟接着走（已走 9 步）。 -/
def A3_tail1_start : St := { A3_start with tick := 9 }
def A3_tail1 : List (Act × Seen) := Replay.playFrom 166 12

theorem A3_tail1_len : A3_tail1.length = 12 := by decide +kernel
/-- 那条假设唯一一次有机会被驳倒的地方。**没红不构成证明。** -/
theorem A3_tail1_trace : traceOk A3_board A3_tail1_start A3_tail1 = true := by decide +kernel

#print axioms A3_tail1_len
#print axioms A3_tail1_trace

/-! ## 第 4 关（探索段，行 178–223；**不当见证**） -/

def A4_board : Board := Replay.levelBoard 0 4
def A4_swap : Bool := true
def A4_start : St := Replay.startOf 179 A4_swap 0
def A4_play : List (Act × Seen) := Replay.playFrom 179 45

theorem A4_play_len : A4_play.length = 45 := by decide +kernel
theorem A4_trace : traceOk A4_board A4_start A4_play = true := by decide +kernel

#print axioms A4_play_len
#print axioms A4_trace

/-! ## 第 5 关（探索段，行 224–269；**不当见证**） -/

def A5_board : Board := Replay.levelBoard 0 5
def A5_swap : Bool := false
def A5_start : St := Replay.startOf 225 A5_swap 0
def A5_play : List (Act × Seen) := Replay.playFrom 225 45

theorem A5_play_len : A5_play.length = 45 := by decide +kernel
theorem A5_trace : traceOk A5_board A5_start A5_play = true := by decide +kernel

#print axioms A5_play_len
#print axioms A5_trace

end Levels
end Game
