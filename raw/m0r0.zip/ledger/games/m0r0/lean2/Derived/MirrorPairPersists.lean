/-
# mirror_pair_persists —— **推论**：对称的通行图上，镜像走一步还是镜像

对应 Python `rule/一步怎么走/mirror_pair_persists.py`。身份：**推论**——它不是一条独立的规则，
是 `pieces_move`（一块照位移、一块照镜像位移，各自进得去就进）在对称盘上推出来的。

    镜像   两块同行，列和 = 列数 − 1
    对称   每一行里，第 c 列「会不会停下来（挡路或危险）」和第 (列数 − 1 − c) 列一样

证明不看盘有多大、不枚举任何一格：四个方向各一支，每一支里两块的意图落点互为镜像，
对称假设说它们要么都停、要么都走——镜像于是传下去。出了格阵那一侧（左移时列已是 0）
另一块一定撞在格阵外，也停。选中态下方向键不搬块，镜像原样留着，那一支一行带过。
-/
import Step

namespace Game

/-- 一块往 `t` 走会停下来：挡路或危险（`land` 里那一句）。 -/
def stop (B : Board) (s : St) (t : Cell) : Bool := blocked B s t || B.hazards.contains t

/-- 两块互为镜像（相对一张 `W` 列宽的盘）。 -/
def mirrorPair (W : Nat) (p : Pieces) : Prop :=
  p.d.r = p.m.r ∧ p.d.c + p.m.c + 1 = W

/-- 通行图左右对称。 -/
def symmetric (B : Board) (s : St) : Prop :=
  ∀ r c, c < B.cols → stop B s ⟨r, c⟩ = stop B s ⟨r, B.cols - 1 - c⟩

theorem land_eq (B : Board) (s : St) (x : Cell) (d : Dir) :
    land B s x d = match x.go d with
      | none => x
      | some t => if stop B s t = true then x else t := by
  unfold land stop
  cases x.go d <;> rfl

theorem land_up (B : Board) (s : St) (x : Cell) :
    land B s x .up = if x.r = 0 then x else if stop B s ⟨x.r - 1, x.c⟩ = true then x else ⟨x.r - 1, x.c⟩ := by
  rw [land_eq]; unfold Cell.go; by_cases h : x.r = 0 <;> simp [h]

theorem land_down (B : Board) (s : St) (x : Cell) :
    land B s x .down = if stop B s ⟨x.r + 1, x.c⟩ = true then x else ⟨x.r + 1, x.c⟩ := by
  rw [land_eq]; rfl

theorem land_left (B : Board) (s : St) (x : Cell) :
    land B s x .left = if x.c = 0 then x else if stop B s ⟨x.r, x.c - 1⟩ = true then x else ⟨x.r, x.c - 1⟩ := by
  rw [land_eq]; unfold Cell.go; by_cases h : x.c = 0 <;> simp [h]

theorem land_right (B : Board) (s : St) (x : Cell) :
    land B s x .right = if stop B s ⟨x.r, x.c + 1⟩ = true then x else ⟨x.r, x.c + 1⟩ := by
  rw [land_eq]; rfl

theorem stop_out (B : Board) (s : St) (r c : Nat) (h : B.cols ≤ c) : stop B s ⟨r, c⟩ = true := by
  unfold stop blocked inGrid
  have : ¬ c < B.cols := by omega
  simp [this]

/-- 核心：一步 `pieceMove` 保持镜像。 -/
theorem pieceMove_mirror (B : Board) (s : St) (d : Dir) (hsym : symmetric B s)
    (hm : mirrorPair B.cols s.pcs) : mirrorPair B.cols (pieceMove B s d) := by
  unfold mirrorPair pieceMove at *
  obtain ⟨hr, hc⟩ := hm
  generalize s.pcs.d = D at *
  generalize s.pcs.m = M at *
  obtain ⟨r, c1⟩ := D
  obtain ⟨r2, c2⟩ := M
  simp only at hr hc ⊢
  subst hr
  cases d with
  | up =>
    simp only [Dir.mirror, land_up]
    by_cases h0 : r = 0
    · simp [h0]; omega
    · have hs := hsym (r - 1) c1 (by omega)
      have e : B.cols - 1 - c1 = c2 := by omega
      rw [e] at hs
      by_cases h1 : stop B s ⟨r - 1, c1⟩ = true
      · have h2 : stop B s ⟨r - 1, c2⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega
      · have h2 : ¬ stop B s ⟨r - 1, c2⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega
  | down =>
    simp only [Dir.mirror, land_down]
    have hs := hsym (r + 1) c1 (by omega)
    have e : B.cols - 1 - c1 = c2 := by omega
    rw [e] at hs
    by_cases h1 : stop B s ⟨r + 1, c1⟩ = true
    · have h2 : stop B s ⟨r + 1, c2⟩ = true := by rw [← hs]; exact h1
      simp [h1, h2]; omega
    · have h2 : ¬ stop B s ⟨r + 1, c2⟩ = true := by rw [← hs]; exact h1
      simp [h1, h2]; omega
  | left =>
    simp only [Dir.mirror, land_left, land_right]
    by_cases h0 : c1 = 0
    · have hout : stop B s ⟨r, c2 + 1⟩ = true := stop_out B s r (c2 + 1) (by omega)
      simp [h0, hout]; omega
    · have hs := hsym r (c1 - 1) (by omega)
      have e : B.cols - 1 - (c1 - 1) = c2 + 1 := by omega
      rw [e] at hs
      by_cases h1 : stop B s ⟨r, c1 - 1⟩ = true
      · have h2 : stop B s ⟨r, c2 + 1⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega
      · have h2 : ¬ stop B s ⟨r, c2 + 1⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega
  | right =>
    simp only [Dir.mirror, land_left, land_right]
    by_cases h0 : c2 = 0
    · have hout : stop B s ⟨r, c1 + 1⟩ = true := stop_out B s r (c1 + 1) (by omega)
      simp [h0, hout]; omega
    · have hs := hsym r (c1 + 1) (by omega)
      have e : B.cols - 1 - (c1 + 1) = c2 - 1 := by omega
      rw [e] at hs
      by_cases h1 : stop B s ⟨r, c1 + 1⟩ = true
      · have h2 : stop B s ⟨r, c2 - 1⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega
      · have h2 : ¬ stop B s ⟨r, c2 - 1⟩ = true := by rw [← hs]; exact h1
        simp [h0, h1, h2]; omega

theorem pushMarker_pcs (B : Board) (s : St) (d : Dir) : (pushMarker B s d).pcs = s.pcs := by
  unfold pushMarker moveLit
  cases s.lit <;> rfl

/-- **镜像保持**：对称的通行图上，两块互为镜像时，按任何一个方向键之后（只要这一步是平常一步）仍互为镜像。 -/
theorem mirror_pair_persists (B : Board) (s s' : St) (d : Dir) (hsym : symmetric B s)
    (hm : mirrorPair B.cols s.pcs) (h : step B s (.move d) = .ok s') : mirrorPair B.cols s'.pcs := by
  simp only [step, moveStep] at h
  split at h
  · injection h with h
    subst h
    simp only [tick, pushMarker_pcs]
    exact hm
  · split at h
    · cases h
    · split at h
      · cases h
      · injection h with h
        subst h
        exact pieceMove_mirror B s d hsym hm

#print axioms land_eq
#print axioms land_up
#print axioms land_down
#print axioms land_left
#print axioms land_right
#print axioms stop_out
#print axioms pieceMove_mirror
#print axioms pushMarker_pcs
#print axioms mirror_pair_persists

end Game
