/-
# parity_flips_iff_blocked —— **推论**：列差的奇偶只有「恰有一块被挡」能翻

对应 Python `rule/一步怎么走/parity_flips_iff_blocked.py`。身份：**推论**（从 `pieces_move` 推出来）。

左右键下，一块照 (0, ±1) 走、另一块照 (0, ∓1) 走，各自要么走成、要么原地：

    都走成   列和变 0          奇偶不变
    都原地   列和不变          奇偶不变
    恰走一块 列和变 ±1         奇偶翻

「列差」与「列和」奇偶相同，这里按列和写（不用处理减法）。这一局撞到一格要列差为 0，
所以一关的全部工作是用墙、门、记号制造奇数次「恰有一块被挡」——这条定理就是那句算术。
借用 `Derived/MirrorPairPersists.lean` 里的 `land_left` / `land_right`。
-/
import Derived.MirrorPairPersists

namespace Game

/-- 这一块这一步原地没动。 -/
def stays (B : Board) (s : St) (x : Cell) (d : Dir) : Bool := decide (land B s x d = x)

theorem pieceMove_parity (B : Board) (s : St) (d : Dir) (hd : d = .left ∨ d = .right) :
    ((pieceMove B s d).d.c + (pieceMove B s d).m.c) % 2 ≠ (s.pcs.d.c + s.pcs.m.c) % 2 ↔
      stays B s s.pcs.d d ≠ stays B s s.pcs.m d.mirror := by
  unfold pieceMove stays
  generalize s.pcs.d = D
  generalize s.pcs.m = M
  obtain ⟨r1, c1⟩ := D
  obtain ⟨r2, c2⟩ := M
  rcases hd with hd | hd <;> subst hd <;> simp only [Dir.mirror, land_left, land_right]
  · -- 左键：d 那块往左，m 那块往右
    by_cases h0 : c1 = 0
    · by_cases h2 : stop B s ⟨r2, c2 + 1⟩ = true
      · simp [h0, h2]
      · simp [h0, h2]; omega
    · by_cases h1 : stop B s ⟨r1, c1 - 1⟩ = true <;>
      by_cases h2 : stop B s ⟨r2, c2 + 1⟩ = true <;> simp [h0, h1, h2] <;> omega
  · -- 右键：d 那块往右，m 那块往左
    by_cases h0 : c2 = 0
    · by_cases h1 : stop B s ⟨r1, c1 + 1⟩ = true
      · simp [h0, h1]
      · simp [h0, h1]; omega
    · by_cases h1 : stop B s ⟨r1, c1 + 1⟩ = true <;>
      by_cases h2 : stop B s ⟨r2, c2 - 1⟩ = true <;> simp [h0, h1, h2] <;> omega

/-- **列差奇偶翻转 ⇔ 恰有一块被挡**（左右键、这一步是平常一步、没选中记号）。 -/
theorem parity_flips_iff_blocked (B : Board) (s s' : St) (d : Dir) (hd : d = .left ∨ d = .right)
    (hl : s.lit = none) (h : step B s (.move d) = .ok s') :
    (s'.pcs.d.c + s'.pcs.m.c) % 2 ≠ (s.pcs.d.c + s.pcs.m.c) % 2 ↔
      stays B s s.pcs.d d ≠ stays B s s.pcs.m d.mirror := by
  simp only [step, moveStep, hl, Option.isSome_none] at h
  split at h
  · contradiction
  · split at h
    · cases h
    · split at h
      · cases h
      · injection h with h
        subst h
        exact pieceMove_parity B s d hd

#print axioms pieceMove_parity
#print axioms parity_flips_iff_blocked

end Game
