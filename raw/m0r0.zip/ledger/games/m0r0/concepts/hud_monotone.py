"""计数带：顶行与底行的带长恒相等，本关内只增不减、每步至多加 1，换关归零。

v1 还断言「没有块换格点时带长不变」，第 64 步 594db52aa44db62a 打脸——
ACTION5 一块没动，带照样加了 1。所以它数的不是移动，也不是动作
（第 2 关关内第 7、8 两步连着没加，第 9 步才加），更像是一条和我的动作无关的时钟。
既然它推进的时机说不出来，就别再声称说得出来：只留还站得住的那几句。

顶带与底带相等这一句是拿来自我核对的：同一个量在帧上有两处读法，
一处读错了、或者它们实际上是两个不同的量，这条当场变反例。
"""
LEVEL = "L4"
SCOPE = ("所有动作；换关返回 NA（换关时它归零重来）；两块定位不到返回 NA。"
         "**不断言它什么时候推进**——那一条已被证伪，现在只断言相等、单调、步进上限")
NOTE = ("v2：删掉「没块动就不变」那一句（被 ACTION5 证伪），加上顶带=底带的自我核对。"
        "缩了就不再声称管「带长为什么会涨」——那还是个空槽。")
EVIDENCE = ["6ff14786341388c8", "aac9b64b6347dbdf", "594db52aa44db62a"]

from _lib import pieces, FLOOR


def _bands(g):
    return (sum(1 for v in g[0] if v != FLOOR),
            sum(1 for v in g[-1] if v != FLOOR))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if pieces(prev) is None or pieces(nxt) is None:
        return "NA"
    tp, bp = _bands(prev)
    tn, bn = _bands(nxt)
    if tp != bp or tn != bn:          # 两处读法对不上
        return "FALSE"
    return "TRUE" if 0 <= bn - bp <= 1 else "FALSE"
