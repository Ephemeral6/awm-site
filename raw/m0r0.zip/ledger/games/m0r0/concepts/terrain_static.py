"""同一关内地形是死的——**记号格与物件格除外**：其余格点的 kind_of 逐帧不变，且记号格个数不变。

写 v1 是为了对准第 2 关那三个色 9 的小方块：如果它们不是死地形，这条当场变反例。
它响了。第 71 步 19c8b95e5cc76810（点亮 (7,9) 之后按 ACTION3）实测：记号从 (7,9) 挪到 (7,8)，
两个格点的 kind_of 同时翻了面（一个 wall->free，一个 free->wall）。记号格不是地形，是**能被推的物件**。

v3 又让出一类，理由同上：第 186 步 aec3abdcbf3f67e7，块踏上一个开关格，
同色的六格门在同一帧由「墙」变「地面」。那六格也不是地形，是**能被开的门**（见 switch_opens_gate）。
让出去的是「物件格」这一类——_lib.objects 认出来的那些整格纯色、色又不是两半墙色的格点。

这条每让一次都在缩小，所以要说清剩下的还断言什么：墙还是死的、危险格还是死的、格点几何还是死的、
记号个数还是不变。它现在还额外把 objects 这个词架在火上：物件集合要是认漏一格，
那一格变了脸就会当场判 FALSE；认多了，一格真墙被让出去，这条就默默变松——
所以 switch_opens_gate 必须从**另一头**核同一个词（它拿门的颜色和帧上的变化对）。
"""
LEVEL = "L7"
SCOPE = ("换关返回 NA；任一帧量不出几何、或 markers 读不出来返回 NA。"
         "只看整关网格内的格点，越界不算。"
         "**在 prev 或 nxt 任一帧上是记号格、或是物件格（_lib.objects）的那些格点，明确不管**")
NOTE = ("v2：第 71 步 19c8b95e5cc76810 打脸——被点亮的记号格被 ACTION3 推走了一格。"
        "缩 scope：把记号格这一类让给 push_door，剩下的地形照旧断言死的。"
        "v3：第 186 步 aec3abdcbf3f67e7 打脸——踏上开关，同色门六格 wall->free。"
        "再让一类：物件格（开关与门）归 switch_opens_gate，剩下的地形照旧断言死的。")
EVIDENCE = ["6ff14786341388c8", "de906fa51c958612", "aac9b64b6347dbdf", "0697e3336bd6bffa",
            "19c8b95e5cc76810", "aec3abdcbf3f67e7"]

from _lib import geom, kind_of, markers, objects


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    ga, gb = geom(prev), geom(nxt)
    if ga is None or gb is None or ga != gb:
        return "NA"
    ma, mb = markers(prev), markers(nxt)
    if ma is None or mb is None:
        return "NA"
    oa, ob = objects(prev), objects(nxt)
    if oa is None or ob is None:
        return "NA"
    if len(ma) != len(mb):
        return "FALSE"
    skip = set(ma) | set(mb) | set(oa) | set(ob)
    side, r0, c0 = ga
    nr, nc = (len(prev) - r0) // side, (len(prev[0]) - c0) // side
    for i in range(nr):
        for j in range(nc):
            if (i, j) in skip:
                continue
            if kind_of(prev, (i, j)) != kind_of(nxt, (i, j)):
                return "FALSE"
    return "TRUE"
