"""块踏上一个开关格（孤立的物件格），同色的整条门当场变成地面。

第 4 关摆了三种色的物件（见 _lib.terrain_colors / switches / gates）：每种色有孤立的单格，
也有嵌在墙行里连成三格的一条。规划器在「门全是墙」的读法下穷尽两块的所有走法，
报「任何走法都撞不上」——那不是这一关无解，是册子缺了一条机制。
第 186 步 aec3abdcbf3f67e7 把它撞了出来：mirror 从 (12,2) 踏进那个孤立的色15 格，
两条色15 的门（六格）同一帧整条由色15 变地面色，帧差 160 格里有 96 格是它们。

所以物件不是地形，是**开关与门**：孤立的那格站得上去，站上去就把同色的门打开。
这条只断言「踏上去的那一步，同色门变地面」，不断言：
  ——门开了之后还开不开（块离开开关会不会关上）；
  ——不同色之间有没有牵连；
  ——开关自己踩完还在不在。
这三件都还没测过，各自是下一步该走的地方，不该在这里蒙混过去。

它同时核了 terrain_colors 这个词：地形色要是认错了，物件集合就认错，
「同色门」要么找不到、要么把真墙当门——两种都会让这条当场判 FALSE。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；两块在 nxt 帧定位不到、或 prev 帧上量不出物件返回 NA；"
         "**prev 帧上没有任何开关格被块占上**时返回 NA——那一步这条没话说；"
         "只断言被占上的那些开关的同色门在 nxt 帧上是地面，"
         "不断言别的色的门、也不断言门在往后的帧里还开着")
NOTE = "v1：第 186 步 aec3abdcbf3f67e7 立案。"
EVIDENCE = ["aec3abdcbf3f67e7"]

from _lib import (pieces, cell_of, kind_of, switches, gates, intents, outcome,
                  geom, FLOOR, DELTA)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    sw, gt, pb = switches(prev), gates(prev), pieces(nxt)
    if sw is None or gt is None or pb is None:
        return "NA"
    on = {cell_of(nxt, x) for x in pb}
    hit = [col for col, cs in sw.items() if cs & on]
    if not hit:
        return "NA"
    for col in hit:
        for c in gt.get(col, ()):
            if kind_of(nxt, c) != "free":
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只在两种标法都说「踏上同一批开关」时开口——身份读不出来，说不准就闭嘴。"""
    if action not in DELTA:
        return None
    sw, gt, gm = switches(prev), gates(prev), geom(prev)
    labs = intents(prev, action)
    if not sw or gt is None or gm is None or labs is None:
        return None
    hits = []
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz:
            return None
        hits.append(frozenset(col for col, cs in sw.items() if cs & set(dest)))
    if not hits[0] or hits[0] != hits[1]:
        return None
    side, pr, pc = gm
    out = {}
    for col in hits[0]:
        for (i, j) in gt.get(col, ()):
            for a in range(side):
                for b in range(side):
                    out[(pr + side * i + a, pc + side * j + b)] = FLOOR
    return out
