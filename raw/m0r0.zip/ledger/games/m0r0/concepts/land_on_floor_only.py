"""两块每一步的落点，在上一帧上都是 kind_of=='free' 的格点——地形分类的自由类和真实站位对得上。

这条是拿来考**词汇表**的：kind_of 是 _lib 里的一个假设（结构式读法：整格纯地面色=free），
它从来没有被单独评过分。这里用另一种读法核它——下一帧上「块实际站在哪」。
两种读法来自不同的帧、不同的通道，对不上就是 kind_of 错了。
"""
LEVEL = "L2"
SCOPE = ("换关返回 NA（换关那一步整屏重画，上一帧的地形不再适用）；"
         "两块在任一帧定位不到返回 NA。不断言反向（free 的格不一定到得了）")
NOTE = ("v2：第 186 步 aec3abdcbf3f67e7 打脸，伤在词汇表不在正文——块踏进了一个整格纯色、"
        "色号不在两半墙色里的格，而 kind_of 把这种格一律读成 wall。"
        "改 _lib：孤立的那种（四邻无同色）是**开关**，站得上去，判 free；连成条的（门）仍判 wall。"
        "本条正文未动，改完在这条 tid 上判 TRUE。这正是 v1 要它挨打的场合：改词汇不能免检。"
        "v1：第 2 关把「危险=色8」证伪了——色 8 在第 2 关是右半边的墙色。"
        "kind_of 改成结构式读法之后，需要一条概念替它挨打，否则改词汇表等于免检改判据。")
EVIDENCE = ["6ff14786341388c8", "de906fa51c958612", "aac9b64b6347dbdf", "fd8457fb4e3950ca",
            "aec3abdcbf3f67e7"]

from _lib import pieces, cell_of, kind_of


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    b = pieces(nxt)
    if pieces(prev) is None or b is None:
        return "NA"
    for top in b:
        if kind_of(prev, cell_of(nxt, top)) != "free":
            return "FALSE"
    return "TRUE"
