"""被点亮的记号格是一扇能推的门：ACTION1..4 让它按 DELTA 移一格，落点是空地面且没有块占着才动，否则原地；别的记号一格不动。

两条实测撑着这句话：
  第 70 步 47639cc0772cd063：(7,9) 点亮，ACTION4 指向 (7,10)——那里正站着一块——整帧一格没变，门没动。
  第 71 步 19c8b95e5cc76810：(7,9) 点亮，ACTION3 指向 (7,8)——空地面——门挪过去了，8 格：
      旧位中心 2x2 由 11 变回地面 5，新位中心 2x2 由 5 变 11。门挪走之后**仍是点亮态**。

门按 DELTA 走，不按列取反的 DELTA 走：ACTION3 是 (0,-1)，(7,9) 去了 (7,8) 而不是 (7,10)。
「被墙挡住就不动」这一句还没实测过（只测过被块挡），这里是故意大胆说的：
它在下一次把门推向墙的时候要么兑现要么当场变反例，两种都比不说好。

为什么这条要紧：第 2 关两块相撞需要 cd+cm 为偶数、rd-rm 为 0，而这两个量在「两块都走成」的步里守恒
（行同增同减、列一增一减）。只有「一块被挡、另一块走成」能改动它们，所以整关都在拿墙破对称——
门就是唯一能被搬动的那面墙。BFS 实测：门在原位时 457 个可达联合状态无一相撞，三扇门全撤掉则相撞可达。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；量不出几何、两块定位不到、markers 读不出来返回 NA；"
         "**prev 帧上没有恰好一个记号是点亮色时返回 NA**（没点亮归 terrain_static，点亮两个是没见过的局面）。"
         "只断言各记号格的位置与颜色，不断言两块（那归 frozen_when_selected）、不断言计数带")
NOTE = "v1"
EVIDENCE = ["47639cc0772cd063", "19c8b95e5cc76810"]

from _lib import (geom, pieces, cell_of, kind_of, markers, top_of, mark_box,
                  DELTA, FLOOR, MARK, MARK_HI)


def _plan(prev, action):
    """返回 (旧位, 新位, 别的记号 dict)。算不出返回 None。"""
    if action not in DELTA:
        return None
    ms = markers(prev)
    p = pieces(prev)
    if ms is None or p is None or geom(prev) is None:
        return None
    hi = [c for c, v in ms.items() if v == MARK_HI]
    if len(hi) != 1:
        return None
    here = hi[0]
    dr, dc = DELTA[action]
    tgt = (here[0] + dr, here[1] + dc)
    busy = {cell_of(prev, x) for x in p}
    dest = tgt if (kind_of(prev, tgt) == "free" and tgt not in busy) else here
    return here, dest, {c: v for c, v in ms.items() if c != here}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    r = _plan(prev, action)
    if r is None:
        return "NA"
    here, dest, others = r
    mb = markers(nxt)
    if mb is None:
        return "NA"
    want = dict(others)
    want[dest] = MARK_HI
    return "TRUE" if mb == want else "FALSE"


def apply(prev, action, ctx=None):
    """认领两个格点：门的旧位（整格还原成地面）与新位（地面 + 中心点亮色）。"""
    r = _plan(prev, action)
    gm = geom(prev)
    if r is None or gm is None:
        return None
    here, dest, _ = r
    side = gm[0]
    lo, h = mark_box(side)
    out = {}
    for cell, mid in ((here, None), (dest, MARK_HI)):
        rr, cc = top_of(prev, cell)
        for a in range(side):
            for b in range(side):
                inner = lo <= a < lo + h and lo <= b < lo + h
                out[(rr + a, cc + b)] = mid if (inner and mid is not None) else FLOOR
    if here == dest:                      # 没动：那一格照旧是点亮的门
        rr, cc = top_of(prev, here)
        for a in range(side):
            for b in range(side):
                inner = lo <= a < lo + h and lo <= b < lo + h
                out[(rr + a, cc + b)] = MARK_HI if inner else FLOOR
    return out
