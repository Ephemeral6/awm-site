"""ACTION1..4 时，两种标法**说得一样**的那些像素，实际就长成那样——身份未知也能预测一部分。

两块互为镜像（一块 (dr,dc)、另一块 (dr,-dc)），列差小的时候哪块是哪个读不出来
（left_is_direct 在那里按 scope 闭嘴）。但「读不出身份」不等于「什么都说不了」：
把两种标法各自算出的整帧预测摆在一起，**逐像素**取它们一致的那部分，
那部分与身份无关，敢说。

v1 的口径是「两种标法的落点**集合**相同才开口」，太苛刻：集合不同的时候，
仍然常有一大片像素两边说的一样（最典型的是两块当前所在的格——两种标法都认为它会空出来）。
交叉窗口里 v1 一格不说，而那正是最需要有人核对的一段：
押注在那里预测 0 格，--strict 只在预测与实际不符时停，没有预测就永远不会停。

配套的读数（v1 留下的）：两标法落点集合相同与否，和**两块列差的奇偶**强相关——
列差为偶数时常相同（0/2/4/6/8/10 各桶有 TRUE），奇数时几乎从不（3/5/7 桶开口率 0%）。
镜像移动每步把列差改变 0 或 ±2，所以奇偶是这一局的守恒量。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；两块定位不到、量不出几何返回 NA；"
         "prev 帧上有记号格被点亮（两块变暗）时返回 NA——那时移动键不搬块，归 frozen_when_selected 管；"
         "任一标法下有块撞危险色时返回 NA（归 hazard_resets 管）；"
         "任一标法下预测相撞（两块同格）时返回 NA，那归 collide_wins 管；"
         "两种标法逐像素没有任何一致处时返回 NA。"
         "**本关有物件格（objects 非空）时不预测走空的格**——块盖住了底下的地形，"
         "从这一帧读不出它站的是地面还是开关格；那时只剩落点像素，常常一格不剩，于是判 NA。"
         "帧的最后一行不管——计数带画在那里，归 hud_monotone 管。"
         "断言的只是「两种标法一致的那些像素」，**不断言哪一块落在哪一格**")
NOTE = ("v3：第 192 步 bb6416a135313d67 打脸——mirror 从 (12,3) 走开，那一格没有变成地面色，"
        "而是**变回了它自己的色**：块此前踏在一个开关格上，块盖住了它。伤在本条正文的一个暗假设"
        "「块底下永远是地面」——前四关成立，因为前四关根本没有物件格，第 4 关有 16 个。"
        "从这一帧读不出块底下盖着什么（整格都是块色，一个像素都不剩），所以缩口径："
        "**本关一旦有物件格，就不再预测走空的那一格**，只留两种标法一致的其余像素。"
        "代价明说：第 4 关的移动步里，两种标法一致的像素常常只有那两个走空的格，"
        "缩完这条在第 4 关多半判 NA、也不再为 --strict 提供护栏。宁可少说，不拿一个读不出来的东西当已知。"
        "v2：口径从「落点集合相同才开口」放宽成「逐像素取两种标法的交集」。"
        "起因是第 175 步起这一段——两块列差 2，v1 预测 0 格，而本关的判别步排在这段盲区之后，"
        "落空了分不清是机制错还是前面漂了。集合口径下 N=55、C=0.324、开口率随列差奇偶跳变（偶 58~81%、奇 0%）。"
        "v1：起因同上，补这条不是为了多一条主张，是为了让交叉窗口里的每一步都有人核对。")
EVIDENCE = ["14dbaaee74e9e2dd", "9ad082100dcdffb2", "aac863a41447fb39", "a3fe86c271ddada8",
            "bb6416a135313d67"]

from _lib import (pieces, cell_of, top_of, geom, intents, outcome, piece_color, sel_dim,
                  objects, FLOOR)


def _agree(prev):
    """两种标法逐像素一致的那部分预测。算不出返回 None。"""
    gm = geom(prev)
    a = pieces(prev)
    if gm is None or a is None or sel_dim(prev) is True:
        return None
    col = piece_color(prev)
    if col is None:
        return None
    return gm[0], col, {cell_of(prev, x) for x in a}


def _paint(prev, dest, here, side, col, vacate):
    """一种标法下的整帧预测：落点涂块色；走空的格回地面——只在 vacate 时才敢说。"""
    out = {}
    if vacate:
        for cell in here - set(dest):
            r, c = top_of(prev, cell)
            for i in range(side):
                for j in range(side):
                    out[(r + i, c + j)] = FLOOR
    for cell in dest:
        r, c = top_of(prev, cell)
        for i in range(side):
            for j in range(side):
                out[(r + i, c + j)] = col
    return out


def _expect(prev, action):
    """两种标法一致的那些像素。撞危险 / 相撞 / 说不了都返回 None。"""
    labs = intents(prev, action)
    got = _agree(prev)
    if labs is None or got is None:
        return None
    side, col, here = got
    obj = objects(prev)
    if obj is None:
        return None
    vacate = not obj                      # 本关有物件格就不碰走空的格：底下盖着什么读不出来
    views = []
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz or dest[0] == dest[1]:
            return None
        views.append(_paint(prev, dest, here, side, col, vacate))
    out = {k: v for k, v in views[0].items() if views[1].get(k) == v}
    for c in range(len(prev[0])):              # 计数带那一行不管，归 hud_monotone
        out.pop((len(prev) - 1, c), None)
    return out or None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    exp = _expect(prev, action)
    if exp is None:
        return "NA"
    for (r, c), v in exp.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    return _expect(prev, action)
