"""两块色的格数恒为偶数完全平方的两倍，且恰好由两个对齐的同边长方块拼成（两种读法互核）。"""
LEVEL = "L0"
SCOPE = "所有动作、所有帧；换关返回 NA（换关帧另算）。断言的是 nxt 这一帧"
NOTE = ("v3：块不止一种颜色。第 65 步 f88e3eb7a2f063c4 打脸——点了记号格，两块一步没动，"
        "整体从 10 变成 1，按 PIECE=10 数就成了 0 格。伤在词汇表（PIECE 是单色）不在正文，"
        "所以正文只把 PIECE 换成 PIECE_COLORS：主张没变，还是「恰好两个同边长对齐方块」。"
        "v2：不再写死块边长 5——第 1 关块边长是 4。")
EVIDENCE = ["6ff14786341388c8", "aac9b64b6347dbdf", "0018d6fe5f1d1d0f",
            "f88e3eb7a2f063c4", "ff7dc84818c86e8d", "809d96697e11b714"]

from _lib import PIECE_COLORS, geom, pieces


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    n = sum(1 for row in nxt for v in row if v in PIECE_COLORS)
    gm = geom(nxt)
    if gm is None:
        return "FALSE"
    side = gm[0]
    if 2 * side * side != n:
        return "FALSE"
    return "TRUE" if pieces(nxt) is not None else "FALSE"
