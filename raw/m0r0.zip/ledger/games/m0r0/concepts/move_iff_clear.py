"""ACTION1..4 且没有块撞危险色时：两块中恰有一块按 DELTA 走、另一块按列取反的 DELTA 走，各自落点全地面才进、否则原地不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；两块定位不到返回 NA；"
         "**prev 帧上有记号格被点亮（两块处于变暗色）时返回 NA**——那时移动键不搬块，归 frozen_when_selected 管；"
         "两种标法下都有块撞危险色时返回 NA（那归 hazard_resets 管）；"
         "两种标法都能解释这一步时仍判 TRUE（身份读不出来），但落点集合对不上任何一种标法就判 FALSE。"
         "apply 只在两种标法预测相同、且不相撞时开口；**本关有物件格时 apply 不涂走空的那一格**——"
         "块盖住了底下的地形，从这一帧读不出它站的是地面还是别的什么")
NOTE = ("v12：第 205 步 0eeea54055bfd39d 打脸的是 **apply**，不是 assert_——mirror 从 (9,4) 走开，"
        "那一格露出来的是门色不是地面色：它此前压着一格门。伤和 dest_set v2 一模一样，"
        "一个暗设「块底下永远是地面」，前四关成立是因为前四关一个物件格都没有。"
        "apply 改成：本关有物件格时不涂走空的那一格，只涂落点。assert_ 一个字没动——"
        "它只比落点，从来没说过走空的格变成什么。这次是押注提前点了名的：下注时就写了"
        "「如果 move_iff_clear 在这里翻了，伤和 dest_set v2 一模一样」。"
        "v11：第 186 步 aec3abdcbf3f67e7 打脸，伤又在词汇表不在正文——kind_of 把「孤立的物件格」"
        "读成 wall，实测块一步踏了进去。改 _lib（孤立物件格 = 开关，判 free），本条正文未动，改完判 TRUE。"
        "v10：第 165 步 d3efe0230197451a 打脸，伤在词汇表不在正文——scope 里「有块撞危险色时返回 NA」"
        "早就写着，但 kind_of 的棋盘判据要求「非地面像素恰占半格」，块边长为奇数时那等式永远不成立，"
        "第 3 关 54 格 hazard 全被读成 wall，那道 scope 一次都没生效过。改 _lib，本条正文未动，改完判 NA。"
        "v9：第 70 步 47639cc0772cd063 打脸——点亮记号格 (7,9) 之后按 ACTION4，**整帧一格没变**，"
        "连计数带都没走，而这条按落点算 (10,5) 该走到 (10,6)。"
        "所以「有记号点亮」是一个另外的模式，模式里 ACTION1..4 不搬块。缩 scope 把那个模式让出去。"
        "v8：apply 不再拿写死的 PIECE 涂块，改成从 prev 读两块此刻的颜色——"
        "第 65 步发现两块有两种颜色（点选模式下整体变暗），而这条只主张落点，不主张颜色。"
        "v5：第 53 步 fd8457fb4e3950ca 打脸——两块交叉换了边，按列排序认身份是错的。"
        "v4 把「列小的那块」当成按 DELTA 走的那块，两块同列时这个读法根本定不了身份。"
        "改成对身份不可知：只断言存在一种标法能解释落点。"
        "v6：apply 改成逐块开口（有些块的落点与身份无关，那些敢说）。"
        "第 63 步 d79f2f209a03887e 的反例出在词汇表不在正文：kind_of 曾把「地面上画了记号的格」"
        "读成可通行，实测它挡路——改 _lib，本条正文未动。")
EVIDENCE = ["6ff14786341388c8", "de906fa51c958612", "aac9b64b6347dbdf", "0697e3336bd6bffa",
            "fd8457fb4e3950ca", "d79f2f209a03887e", "47639cc0772cd063", "d3efe0230197451a",
            "aec3abdcbf3f67e7", "0eeea54055bfd39d"]

from _lib import (pieces, cell_of, top_of, geom, intents, outcome, piece_color, sel_dim,
                  objects, DELTA, FLOOR)


def _fits(prev, nxt, lab):
    dest, hz = outcome(prev, lab)
    if hz:
        return None
    b = pieces(nxt)
    if b is None:
        return False
    return sorted(dest) == sorted(cell_of(nxt, x) for x in b)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if sel_dim(prev) is True:                     # 点选模式：这条不管，归 frozen_when_selected
        return "NA"
    labs = intents(prev, action)
    if labs is None or pieces(nxt) is None:
        return "NA"
    res = [_fits(prev, nxt, lab) for lab in labs]
    if all(r is None for r in res):
        return "NA"
    return "TRUE" if any(r is True for r in res) else "FALSE"


def _paint(prev, out, cell, color, side):
    r, c = top_of(prev, cell)
    for i in range(side):
        for j in range(side):
            out[(r + i, c + j)] = color


def apply(prev, action, ctx=None):
    """逐块开口：身份读不出来，但**有些块的落点和身份无关**，那些块就敢说。

    对第 k 块，若两种标法算出的落点相同（两边都被挡、或 dc=0 时镜像等于直走），
    它的落点就是确定的；另一块不确定就不碰它那两格。

    走空的那一格只在**本关没有物件格**时才敢涂地面色：块盖住一格时底下是什么读不出来，
    而第 4 关的块会踩在开关格和被按开的门格上（第 205 步实测）。
    """
    labs = intents(prev, action)
    gm = geom(prev)
    if labs is None or gm is None or sel_dim(prev) is True:
        return None
    obj = objects(prev)
    if obj is None:
        return None
    vacate = not obj
    outs = []
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz or dest[0] == dest[1]:      # 撞危险 / 相撞换关：都是整屏重画，不预测
            return None
        outs.append(dest)
    side = gm[0]
    col = piece_color(prev)               # 块此刻是什么色就还它什么色，不主张颜色会变
    if col is None:
        return None
    here = [h for h, _ in labs[0]]        # 两块当前格点，下标与 outs 内的一致
    out = {}
    for k in (0, 1):
        if outs[0][k] != outs[1][k]:      # 这一块的落点取决于身份：闭嘴
            continue
        dst = outs[0][k]
        maybe = {outs[0][1 - k], outs[1][1 - k]}   # 另一块可能落在哪
        if here[k] != dst and here[k] not in maybe and vacate:
            _paint(prev, out, here[k], FLOOR, side)   # 走了，且另一块不会补上来
        _paint(prev, out, dst, col, side)
    return out or None
