"""两块处在变暗色，当且仅当恰好有一个记号格是点亮色；不变暗时点亮的记号数为 0。

这条是拿来核**词汇表**的，不是拿来预测的。同一个隐藏比特（「有没有选中一个记号」）
在帧上有两条互不相干的读法：一条读两块的颜色（PIECE / PIECE_SEL），
一条读记号格中心的颜色（MARK / MARK_HI）。两个常量都是我从四条转移上认出来的，
谁都没单独走过闸。它们要是各说各话——比如色 1 其实不是「变暗的块」而是别的什么，
或者色 11 在这里不是「点亮」——这条当场变反例。

prev 与 nxt 两帧都要成立：它是一条帧内不变量，不是转移规律。
"""
LEVEL = "L7"
SCOPE = ("所有动作、所有帧；换关返回 NA；量不出几何、两块定位不到、"
         "或这一帧上一个记号格都没有（第 0/1 关）返回 NA")
NOTE = "v1"
EVIDENCE = ["f88e3eb7a2f063c4", "ff7dc84818c86e8d", "809d96697e11b714", "1cacd527a7c0f6c4"]

from _lib import markers, sel_dim, MARK, MARK_HI


def _ok(g):
    ms = markers(g)
    if ms is None or not ms:
        return None
    d = sel_dim(g)
    if d is None:
        return None
    hi = [c for c, v in ms.items() if v == MARK_HI]
    if any(v not in (MARK, MARK_HI) for v in ms.values()):
        return False              # 记号还有第三种颜色 —— 这两个常量没穷尽
    if len(hi) > 1:
        return False              # 同时点亮两个 —— 「至多一个」被打破
    return d == (len(hi) == 1)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = _ok(prev), _ok(nxt)
    if a is None and b is None:
        return "NA"
    if a is False or b is False:
        return "FALSE"
    return "TRUE"
