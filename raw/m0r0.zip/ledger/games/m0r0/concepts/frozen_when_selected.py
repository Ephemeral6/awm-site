"""有记号格被点亮时，ACTION1..4 不搬动那两块——两块的格点位置在这一步里原样不动。

第 70 步 47639cc0772cd063 实测：点亮 (7,9) 之后按 ACTION4，**整帧一格没变**，连帧顶帧底那条计数带都没走。
按 move_iff_clear 的算法，(10,5) 该走到 (10,6)（那一格是地面），它没走。

为什么只断言「两块不动」而不断言「整帧不变」：整帧不变只见过一次，而它有一个同样合身的对手解释——
第 2 关三个记号格全都卡在走廊上（(3,7) 卡 (3,6)↔(3,8)，(4,2) 卡 (3,2)↕(5,2)，(7,9) 卡 (7,8)↔(7,10)），
点亮也许是「选中这扇门」，方向键推的是门；那一步 ACTION4 什么也没发生，是因为门右边 (7,10) 正被块占着，推不动。
两种解释对「两块不动」的预言相同，对「整帧不变」的预言相反。所以这条只说两边都同意的那一半，
把分歧留给下一步去判——那一步会推门往左（(7,8) 是空的）。

apply 只认领两块占的那几十格：这几格两种解释都说不变。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；量不出几何、两块定位不到返回 NA；"
         "**prev 帧上没有记号被点亮（两块不是变暗色）时返回 NA**——那归 move_iff_clear / left_is_direct。"
         "只断言两块的格点位置，不断言帧上别的地方")
NOTE = "v1"
EVIDENCE = ["47639cc0772cd063"]

from _lib import pieces, cell_of, geom, sel_dim, piece_color, DELTA


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if sel_dim(prev) is not True:
        return "NA"
    a, b = pieces(prev), pieces(nxt)
    if a is None or b is None:
        return "NA"
    here = sorted(cell_of(prev, x) for x in a)
    there = sorted(cell_of(nxt, x) for x in b)
    return "TRUE" if here == there else "FALSE"


def apply(prev, action, ctx=None):
    if action not in DELTA or sel_dim(prev) is not True:
        return None
    gm = geom(prev)
    p = pieces(prev)
    col = piece_color(prev)
    if gm is None or p is None or col is None:
        return None
    side = gm[0]
    return {(r + a, c + b): col
            for r, c in p for a in range(side) for b in range(side)}
