"""ACTION5 不动两块、也不改地形：变的只有网格之外那条计数带。

v1 说的是「从不改变任何一格」，第 64 步 594db52aa44db62a 打脸——
它确实改了 2 格，但那 2 格都在格点网格之外（帧顶行与帧底行的计数带），
和普通移动动作每隔几步推进的是同一条带。所以 ACTION5 不是空动作，
它是「花掉一步、什么也不做」——代价照付，状态不动。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；换关返回 NA；两帧量不出几何、或两块定位不到返回 NA。"
         "只断言网格**之内**不变，网格之外（计数带）明确不管")
NOTE = ("v2：缩 scope，从「整帧不变」缩到「网格内不变」。"
        "缩了就不再声称管计数带那一片——那归 hud_monotone。")
EVIDENCE = ["167784775ae6ec05", "594db52aa44db62a"]

from _lib import geom, pieces, cell_of, kind_of


def _cells(g):
    gm = geom(g)
    if gm is None:
        return None
    side, r0, c0 = gm
    nr, nc = (len(g) - r0) // side, (len(g[0]) - c0) // side
    return {(i, j): kind_of(g, (i, j)) for i in range(nr) for j in range(nc)}


def assert_(prev, action, nxt, ctx=None):
    if action != "ACTION5":
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = pieces(prev), pieces(nxt)
    if a is None or b is None:
        return "NA"
    if sorted(cell_of(prev, x) for x in a) != sorted(cell_of(nxt, x) for x in b):
        return "FALSE"
    ka, kb = _cells(prev), _cells(nxt)
    if ka is None or kb is None:
        return "NA"
    return "TRUE" if ka == kb else "FALSE"


def apply(prev, action, ctx=None):
    """只对网格之内的像素开口；网格之外那两行不碰。"""
    if action != "ACTION5":
        return None
    gm = geom(prev)
    if gm is None:
        return None
    side, r0, c0 = gm
    nr, nc = (len(prev) - r0) // side, (len(prev[0]) - c0) // side
    return {(r, c): prev[r][c]
            for r in range(r0, r0 + nr * side) for c in range(c0, c0 + nc * side)}
