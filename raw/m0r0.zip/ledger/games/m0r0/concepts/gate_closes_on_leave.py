"""块走开的那一格在下一帧现出一个**开关**色 X 时，色 X 的门当场整条长回来——门是踩着才开的，不是开了就不关。

这是 switch_opens_gate 明说不管的那一半。那条只断言「踏上开关的那一步，同色门变地面」，
并在正文里列出它不断言的三件事，头一件就是「门开了之后还开不开」。
第 192 步 bb6416a135313d67 把它测了：mirror 从 (12,3) 往右走开，同一帧里
那一格变回它自己的色，两条色15 的门（6 格）从地面色变回门色。所以答案是**关**。

这条断言的形状是这样的：块盖住一格时，那一格底下是什么读不出来（整格都是块色，
一个像素不剩）；但块**走开**的那一帧，底下是什么就露出来了。露出来的若是一个
**孤立的**物件格（开关），那就说明块此前一直踩着它——于是这一帧同色的门必须回来。
「回来」写成两句可判的话：nxt 上色 X 有门（gates 非空），且这些门格在 prev 上都是通行的。
第二句是关键的一句：门格在 prev 上要是本来就挡着，那这一帧根本没发生「关」，
本条就成了一句永远为真的废话。

**露出来的是门格（连成条的那种）时本条闭嘴**——那说明块此前站在一格门上，
门是在它脚底下关上的（第 200 步关的，第 205 步它才走开），和「谁按着开关」无关。
v1 没分这两种，当场被第 205 步判 FALSE。

不写 apply：从 prev 读不出块底下盖着什么，所以这条生成不了下一帧，只会判。
dest_set v3 与 move_iff_clear v12 也是为这件事缩的口径——它们原先暗设「块底下永远是地面」，
前四关成立，第 4 关有 16 个物件格就不成立了。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；两块在任一帧定位不到、量不出几何返回 NA；"
         "prev 帧上有记号格被点亮时返回 NA（那时移动键不搬块）；"
         "**没有块走开、或走开的格在 nxt 上不是开关格时返回 NA**——"
         "露出地面归别人管，露出门格是另一回事（块站在已关的门上），本条都不说。"
         "只断言「露出开关色 ⇒ 同色门这一帧长回来」这一个方向；"
         "不断言反向（门关着不一定是因为有块刚走开），不断言开关格本身在关内是否不变，"
         "不断言不同色之间有没有牵连")
NOTE = ("v2：第 205 步 0eeea54055bfd39d 打脸——mirror 从 (9,4) 走开，露出色12，而色12 的门在 prev 上"
        "早就关着（第 200 步 direct 离开开关时关的），于是「门格 prev 通行」这一句判 FALSE。"
        "病在 v1 把「露出物件色」当成「刚才踩的是开关」：mirror 站的那一格本身就是一格门，"
        "门在它脚底下关上，它照样站得住。改成只在露出的格是**孤立**物件格（开关）时开口。"
        "缩掉的那一片不是丢了，是换了归属：它属于一条还没写的话——块站在已关的门格上不受伤。"
        "v1：起因是第 192 步 bb6416a135313d67——它同时是 dest_set v2 的反例。"
        "同一条转移在两条概念上说的是两件事：dest_set 错在「块底下是地面」，"
        "这条记的是「门跟着关」。前者缩口径，后者立新条，不合并——"
        "一条概念只断言一件事。")
EVIDENCE = ["bb6416a135313d67", "0eeea54055bfd39d"]

from _lib import pieces, cell_of, kind_of, switches, gates, sel_dim, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    if sel_dim(prev) is True:
        return "NA"
    a, b = pieces(prev), pieces(nxt)
    if a is None or b is None:
        return "NA"
    was = {cell_of(prev, x) for x in a}
    now = {cell_of(nxt, x) for x in b}
    sw, gt = switches(nxt), gates(nxt)
    if sw is None or gt is None:
        return "NA"
    at = {c: col for col, cs in sw.items() for c in cs}
    said = False
    for cell in was - now:                       # 块走开的那些格：底下是什么，这一帧露出来了
        col = at.get(cell)
        if col is None:                          # 露出的是地面、或是一格门：本条不管
            continue
        said = True
        shut = gt.get(col) or set()
        if not shut:                             # 露出开关色，却一扇同色门都没有
            return "FALSE"
        for g in shut:
            if kind_of(prev, g) != "free":       # 这门 prev 上就挡着，根本没发生「关」
                return "FALSE"
    return "TRUE" if said else "NA"
