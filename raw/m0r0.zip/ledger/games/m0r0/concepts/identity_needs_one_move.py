"""dc != 0 的一步里，两种标法恰有一种能解释实际下一帧——一次列移动就把身份这一位测出来。

身份（两块中哪一块按 DELTA 走）**不是帧的函数**：两块同色同形，单帧上没有任何像素能区分它们。
前四关里「列小的那块是 direct」成立了 52 次，第 4 关开局第一次列移动就翻了（第 181 步
cc99099ef7ce6bd9，列大的那块才是 direct）——那 52 次量的是前四关的出生位置，不是定律。
撤掉 left_is_direct 与 identity_two_channels 之后，册子里不再有任何从单帧读身份的话。

这条说的是另一件事，而且是**可操作**的那件：身份虽然读不出来，却测得出来。
拿两种标法各自算一遍落点，与实际下一帧比，剩下的那一种就是这一关的身份归属。
它同时钉死一步一格：动了的块行位移恒为 dr、列位移恒为 ±dc，没有别的花样
（若两种标法都解释不了，本条判 FALSE）。

「恰有一种」是有内容的两面：
  ——至少一种，说的是运动模型没错（一直一格、一直镜像）；
  ——至多一种，说的是这一步真的能测出身份，规划器可以拿它当锚点往后追。
两种标法算出的落点集合相同时（例如两块都被挡）这一步测不出身份，本条返回 NA：
那不是它错，是那一步没有信息。全语料 53 条列移动里，这种情况 0 条。

它同时核了 pieces / cell_of / intents / outcome / kind_of 这一串词：
落点是从 prev 帧的静态像素算的，比对的是 nxt 帧的实际位置，两条不同的通道。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1..ACTION4 且 dc != 0（dc == 0 时两种标法本来就一样，测不出身份）；"
         "换关返回 NA；两块在任一帧定位不到返回 NA；"
         "prev 帧上有记号格被点亮（两块变暗）时返回 NA——那时移动键不搬块，归 frozen_when_selected；"
         "任一标法下有块的意图落点是 hazard 时返回 NA（归 hazard_resets）；"
         "两种标法算出的落点集合相同时返回 NA——那一步没有身份信息。"
         "只断言「恰有一种标法对得上」，不断言是哪一种、也不断言身份在关内是否不变")
NOTE = ("v2：第 186 步 aec3abdcbf3f67e7 打脸，伤在词汇表不在正文——两种标法算落点都要过 kind_of，"
        "而它把「孤立的物件格」读成 wall，于是两种标法都说「有一块被挡住」，谁都解释不了实际那一帧。"
        "改 _lib（孤立物件格 = 开关，判 free），本条正文未动，改完那一步恰有一种标法对得上，判 TRUE。"
        "这也正是这条概念的用处：它把「落点算得对不对」和「身份测不测得出来」绑在一起，"
        "词汇一旦认错地形，它当场响。"
        "v1：从 identity_two_channels 里救出来的那半句。原概念的主张是「位移读法与位置读法一致」，"
        "位置读法被第 181 步推翻并撤册，那句整个塌掉；但「一次列移动唯一定出身份」这半句"
        "从没被单独说过，也没被推翻——而且它正是规划器追身份的合法性来源，所以单立一条。")
EVIDENCE = ["de906fa51c958612", "ccd3fa9a601ac286", "2c0f42bb424cafa1", "c35bf96fbb019315",
            "acf7aab4b10d10a1", "595fc20ea625a393", "cc99099ef7ce6bd9", "aec3abdcbf3f67e7"]

from _lib import pieces, cell_of, intents, outcome, sel_dim, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA or DELTA[action][1] == 0:
        return "NA"
    if sel_dim(prev) is True:
        return "NA"
    labs = intents(prev, action)
    b = pieces(nxt)
    if labs is None or b is None:
        return "NA"
    got = sorted(cell_of(nxt, x) for x in b)
    views = []
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz:
            return "NA"
        views.append(sorted(dest))
    if views[0] == views[1]:
        return "NA"                       # 这一步两种标法说的一样，测不出身份
    return "TRUE" if sum(1 for v in views if v == got) == 1 else "FALSE"
