"""某种标法下有块的意图落点含危险色时：不换关，两块都不在意图落点上，且至少一块换了格点。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..ACTION4；两块定位不到返回 NA；没有任何标法让某块撞上危险色时返回 NA；"
         "记号被点亮（两块处在变暗色）时返回 NA——那时方向键搬的是记号，两块根本没往危险格迈步。"
         "断言的是「重置发生了」的可观测形状，不断言出生点在哪")
NOTE = ("v4：终局卡第 394 步 50e3d2ecd39873c8 打脸——记号被点亮时按方向键，"
        "intents 照旧算出「某块要迈进危险格」，可实际动的是记号，两块一格没动，也没重置。"
        "这条概念管的是**块迈步撞危险**，点亮态下块不迈步，所以缩 scope 判 NA，不改正文的形状断言。"
        "教训：一条概念的前提是「谁在动」，而读意图的那个词不知道此刻谁在动——"
        "前提得自己补，别指望词汇替你分情况。"
        "v3：第 165 步 d3efe0230197451a 是它的第二个实例，也是第一次在**第 3 关**开口。"
        "在此之前它 N=0、开口率 0/163——不是因为世界没重置过，是因为 kind_of 在块边长为奇数的关上"
        "一格 hazard 都认不出来（棋盘判据要求「非地面像素恰占半格」，奇数边长上永远不成立），"
        "这条概念于是整关闭嘴。改 _lib 之后它认出第 3 关 54 格 hazard，本条正文未动就多了一个实例。"
        "教训：一条概念长期 100% NA，先怀疑它读世界的那个词瞎了，别当成「这机制很罕见」。"
        "v2：intents 改成返回两种标法（身份读不出来），这里跟着改成对所有标法取并——"
        "只要有一种标法说会撞危险，这一步就归它管。")
EVIDENCE = ["0697e3336bd6bffa", "d3efe0230197451a", "50e3d2ecd39873c8"]

from _lib import pieces, cell_of, kind_of, intents, sel_dim, DELTA


def assert_(prev, action, nxt, ctx=None):
    if action not in DELTA:
        return "NA"
    if sel_dim(prev):                      # 点亮态：方向键搬记号，两块不迈步，本条不管
        return "NA"
    labs = intents(prev, action)
    b = pieces(nxt)
    if labs is None or b is None:
        return "NA"
    hz = [(here, tgt) for lab in labs for here, tgt in lab if kind_of(prev, tgt) == "hazard"]
    if not hz:
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "FALSE"
    got = sorted(cell_of(nxt, x) for x in b)
    if any(t in got for _, t in hz):
        return "FALSE"
    here = sorted(h for lab in labs for h, _ in lab[:1]) or []
    prev_cells = sorted({h for lab in labs for h, _ in lab})
    return "TRUE" if got != prev_cells else "FALSE"
