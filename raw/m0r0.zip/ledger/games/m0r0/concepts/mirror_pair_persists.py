"""可通行格集合关于竖直中轴对称、且两块互为镜像（同行、列和 = 列数-1）时，下一帧两块仍互为镜像。

这条是第 5 关的骨架，也是任何「这一关走不通」的论证要用的第一块砖。

为什么它成立：direct 走 (dr, dc)、mirror 走 (dr, -dc)（move_delta）。
两块关于竖直轴互为镜像时，两个意图落点也互为镜像——不管哪一块是 direct，
两种标法给出的落点集合都是一对镜像格。挡不挡得住只看落点通不通行，
所以**通行图对称**这个前提一旦成立，镜像关系就传下去。

前提不是装饰：v1 漏了它，当场被四条转移打脸，四条全来自地形左右不对称的关。
那些关里两块确实是镜像起手的，然后一块撞墙、另一块没撞，镜像就断了。
断得对——那正是这条概念该闭嘴的地方。

于是它有真牙齿：通行图对称的关里，两块要撞到一起只能撞在轴上。
第 5 关的轴那一列是危险格与墙，所以镜像不破就赢不了。
而那一关唯一能让通行图变得不对称的事，是两组同位置、不同色的门恰好开了一组——
门开不开又取决于谁踩着同色开关。所以「制造一次不对称」就是第 5 关的题眼，
这条概念判 NA 的那些步，正是该去找路的地方；判 FALSE 的那一步，就是路本身。

不写 apply：它断言的是两块之间的一个关系，不预测任何一格的颜色。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；两块在任一帧定位不到、量不出几何返回 NA；"
         "prev 帧上有记号格被点亮时返回 NA（那时移动键不搬块）；"
         "**prev 上通行格集合不是左右对称时返回 NA**——那时两块各自撞到的东西不一样，"
         "镜像本来就没有理由保持；"
         "**prev 上两块不是镜像关系（不同行、或列和 != nc-1）时返回 NA**——"
         "这条只说「镜像一旦成立就保持」，不说镜像是怎么来的、也不说它非成立不可。"
         "两块落到同一格（相撞）时仍按镜像判：同格意味着列和 = 2c，恰好落在轴上才算镜像")
NOTE = ("v2：v1 少写了「通行图对称」这个前提，被四条转移打脸——"
        "d61db9a0ceea4321 / 0ae3843ea1ea8da7 / aaf84485024b820d / 3355b8a052a81ffe，"
        "全部出在地形左右不对称的关里（最典型的是一块被墙挡住、它的镜像位置那边是空地）。"
        "补上前提之后这四条判 NA。这不是缩到没内容：第 5 关的通行图是对称的，"
        "它在那一关每一步都开口，而且开口就等于说「这一步赢不了」。"
        "v1：立案理由不是它可能对，是它**可能错**，而错了正好是第 5 关的通路。"
        "这条把「按现有规则走不通」那个论证的第一步变成可判错的对象："
        "世界哪天让镜像破掉，它当场变反例关闸，而那一步就是要找的东西。")
EVIDENCE = ["899b597f70b0be88", "d61db9a0ceea4321", "0ae3843ea1ea8da7",
            "aaf84485024b820d", "3355b8a052a81ffe"]

from _lib import geom, pieces, cell_of, kind_of, sel_dim, DELTA


def _sym_board(g, nr, nc):
    """通行格集合左右对称吗。危险格与墙都算不通行，但两者不混为一谈：
    这里只关心「进得去还是进不去」，因为镜像传不传下去只取决于挡不挡得住。"""
    for i in range(nr):
        for j in range((nc + 1) // 2):
            if (kind_of(g, (i, j)) == "free") != (kind_of(g, (i, nc - 1 - j)) == "free"):
                return False
    return True


def _mirror(cells, nc):
    if len(cells) != 2:
        return False
    (r1, c1), (r2, c2) = cells
    return r1 == r2 and c1 + c2 == nc - 1


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    if sel_dim(prev) is True:
        return "NA"
    gm = geom(prev)
    a, b = pieces(prev), pieces(nxt)
    if gm is None or a is None or b is None:
        return "NA"
    side, pr, pc = gm
    nr, nc = (len(prev) - pr) // side, (len(prev[0]) - pc) // side
    was = sorted(cell_of(prev, x) for x in a)
    if not _mirror(was, nc):
        return "NA"                              # prev 上就不是镜像：这条不管
    if not _sym_board(prev, nr, nc):
        return "NA"                              # 通行图不对称：镜像没有理由保持
    now = sorted(cell_of(nxt, x) for x in b)
    if len(now) == 1:                            # 两块重合成一团：撞在一起了
        now = now * 2
    return "TRUE" if _mirror(now, nc) else "FALSE"
