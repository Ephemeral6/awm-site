"""这一步没有任何一格露出开关色时，没有任何一格从地面变回门色——门不会自己关上。

册子里关于门的开关只有两条，而且都只说**变化的那一瞬**：
  switch_opens_gate    块踏上开关的那一步，同色门当场变地面；
  gate_closes_on_leave 块走开、那一格露出开关色的那一步，同色门当场长回来。
中间那段「一直按着、一直开着」谁也没说过。它不是废话：整条第 5 关的解法里有十步
是「块冻在开关上不动、我在推门」（frozen_when_selected：有记号被点亮时移动键不搬块），
这十步里门必须一直开着，那扇被推的门才过得去。规划器默认了这件事，
默认就是绕开检验——所以把它写成这里这一条。

为什么反着写（说「不关」而不是说「开着」）：开着的门读不出来。
门一开，那几格就是地面色，和真地面一个样，帧上分不出「这里本来有扇门」。
可观测的是**变化**：一格从地面变成门色，就是关上了。
于是这条断言的形状只能是「没人松手的那一步，一扇也不关」。
这也是上一条概念教的：判据不能建在不可观测的量上，要换一个量得到的时刻去量。

不写 apply：它断言的是「什么都没发生」，没有哪一格是它敢生成的。
"""
LEVEL = "L6"
SCOPE = ("换关返回 NA（换关整屏重画）；两块在任一帧定位不到、量不出几何返回 NA；"
         "prev 与 nxt 上一个门格都没有（本关没有门）时返回 NA；"
         "**这一步有开关色露出来（有块从开关上走开）时返回 NA**——那一步归 gate_closes_on_leave 管；"
         "只看「地面 -> 门色」这一个方向，不断言门开的那一侧，也不断言块底下是什么"
         "（prev 里被块盖住的格一律排除：那底下是什么，帧上读不出来）")
NOTE = "v1：为第 5 关那十步「块冻在开关上、门被推着走」立案——规划器默认了它，默认等于免检。"
EVIDENCE = ["3355b8a052a81ffe", "6384d436abdb4b3f"]

from _lib import pieces, cell_of, kind_of, switches, gates


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = pieces(prev), pieces(nxt)
    if a is None or b is None:
        return "NA"
    ga, gb = gates(prev), gates(nxt)
    if ga is None or gb is None or not (ga or gb):
        return "NA"                                  # 本关没有门：这条没话说
    was_piece = {cell_of(prev, x) for x in a}
    sw = switches(nxt) or {}
    if any(cs & was_piece for cs in sw.values()):
        return "NA"                                  # 有块从开关上走开：归 gate_closes_on_leave
    for col, cells in gb.items():
        for c in cells:
            if c in was_piece:
                continue                             # 块盖着的格，底下是什么读不出来
            if kind_of(prev, c) == "free":
                return "FALSE"                       # 一格从地面变成了门色：门自己关上了
    return "TRUE"
