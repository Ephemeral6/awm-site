"""两块落到同一格点当步就换关；两种标法下都不相撞则绝不换关。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1..ACTION4；ctx 缺 level 返回 NA；两块定位不到返回 NA；"
         "有块撞危险色时返回 NA；**两种标法一个说相撞一个说不相撞时返回 NA**（身份读不出来，这一步说不了）")
NOTE = ("v2：第 55 步 e6be8c13eaa8de65 打脸——它按「列小的那块按 DELTA 走」算出不相撞，实际换关了。"
        "身份靠列序认是错的（见 move_delta v5）。改成只在两种标法一致时开口。")
EVIDENCE = ["0018d6fe5f1d1d0f", "aac9b64b6347dbdf", "d61db9a0ceea4321", "e6be8c13eaa8de65"]

from _lib import pieces, intents, outcome, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") is None:
        return "NA"
    labs = intents(prev, action)
    if labs is None:
        return "NA"
    votes = []
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz:
            return "NA"
        votes.append(dest[0] == dest[1])
    if votes[0] != votes[1]:
        return "NA"
    up = ctx["level_next"] != ctx["level_prev"]
    return "TRUE" if votes[0] == up else "FALSE"
