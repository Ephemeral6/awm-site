"""ACTION6:x,y 是点选不是移动：点中记号格就点亮它（其余记号复原、两块变暗），点在别处就全部复原；两块一格不动。

第 65~68 步实测的四次点击：
  点记号 (7,9)：该记号中心 9->11，两块整体 10->1，两块位置不动；
  点记号 (4,2)：(4,2) 9->11，(7,9) 11->9  —— 至多一个记号是点亮态；
  点记号 (3,7)：(3,7) 9->11，(4,2) 11->9；
  点块自己 (10,5)：(3,7) 11->9，两块整体 1->10 —— 点非记号处 = 全部复原。

「点非记号处就复原」这一句只在「点块自己」上见过一次，现在把它推广到**任何非记号格**
（地面、墙、记号以外一切）。推广是故意的：这一句要么在下一次点空地时兑现，要么当场变反例，
两种结果都比缩到只认「点块」有用。
点一个**已经点亮**的记号会怎样，同样没见过，这里按「它仍是被点亮的那个」预测。
"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6（裸 ACTION6 上游回 500，不是动作）；换关返回 NA；"
         "两块定位不到、量不出几何、或点在格点原点之外返回 NA。"
         "断言整个格点网格之内的每一像素，**帧的最后一行除外**——计数带画在那里，归 hud_monotone 管")
NOTE = ("v3：第 170 步 --strict 报 apply 押错 (63,4)(63,5) 两格。不是断言错，是 apply 越界："
        "SCOPE 一直写着「网格之外那条计数带明确不管」，但这一关的计数带**画在网格最后一行上**"
        "（网格覆盖行 4..63，带子就在第 63 行），「网格之外」这个说法在这里失效了。"
        "apply 照抄 prev 整块网格，于是替带子押了「不变」，而带子每隔一步吃掉一格。"
        "链式押注里这个错会积累：前几步没人预测带子增长，到点击那步 apply 抄的是陈旧值。"
        "改的是 _expect（末行整行让给 hud_monotone），assert_ 与 apply 共用它——"
        "断言和生成必须是同一份主张，否则 assert_ 仍在断言一件 SCOPE 说不管的事。"
        "v1")
EVIDENCE = ["f88e3eb7a2f063c4", "ff7dc84818c86e8d", "809d96697e11b714", "1cacd527a7c0f6c4",
            "45f8be5461ab1d94"]

from _lib import (geom, pieces, cell_of, markers, marker_of, click_cell, mark_box,
                  MARK, MARK_HI, PIECE, PIECE_SEL)


def _expect(prev, action):
    """点这一下之后，网格内每一格像素该是什么（不含计数带那一行）。算不出返回 None。

    末行整行剔掉——SCOPE 明写「计数带明确不管」，但这一关的计数带**画在网格最后一行上**
    （网格覆盖行 4..63，带子就在第 63 行，从左往右每步吃掉一格 5->0）。
    「网格之外」这个说法在这里失效了：带子在网格之内。
    照抄 prev 的那一句于是替带子押了「不变」，而带子每隔一步就走一格。
    断言和生成用同一份 exp，两边一起让出这一行——否则 assert_ 仍在断言一件 SCOPE 说不管的事。
    """
    gm = geom(prev)
    if gm is None:
        return None
    side, pr, pc = gm
    p = pieces(prev)
    ms = markers(prev)
    hit = click_cell(prev, action)
    if p is None or ms is None or hit is None:
        return None
    nr, nc = (len(prev) - pr) // side, (len(prev[0]) - pc) // side
    if not (0 <= hit[0] < nr and 0 <= hit[1] < nc):
        return None

    on_marker = hit in ms
    out = {}
    # 底子：整个网格照抄
    for r in range(pr, pr + nr * side):
        for c in range(pc, pc + nc * side):
            out[(r, c)] = prev[r][c]
    # 记号：点中的那个点亮，其余复原
    for cell in ms:
        col = MARK_HI if (on_marker and cell == hit) else MARK
        lo, h = mark_box(side)
        r0, c0 = pr + side * cell[0], pc + side * cell[1]
        for a in range(lo, lo + h):
            for b in range(lo, lo + h):
                out[(r0 + a, c0 + b)] = col
    # 两块：位置不动，颜色随模式
    col = PIECE_SEL if on_marker else PIECE
    for top in p:
        for a in range(side):
            for b in range(side):
                out[(top[0] + a, top[1] + b)] = col
    for c in range(len(prev[0])):              # 计数带那一行整行让出去，归 hud_monotone 管
        out.pop((len(prev) - 1, c), None)
    return out


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6:"):
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    exp = _expect(prev, action)
    if exp is None:
        return "NA"
    # 位置这一句单独再核一次：两块的格点在 nxt 上还是原来那两个
    q = pieces(nxt)
    if q is None:
        return "FALSE"
    if sorted(cell_of(prev, x) for x in pieces(prev)) != sorted(cell_of(nxt, x) for x in q):
        return "FALSE"
    for (r, c), v in exp.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6:"):
        return None
    return _expect(prev, action)
