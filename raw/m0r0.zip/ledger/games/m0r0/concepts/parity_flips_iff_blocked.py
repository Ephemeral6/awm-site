"""ACTION1..4 且 dc != 0 时，两块列差的奇偶翻转 <=> 恰有一块被挡（被挡块数为奇数）。

推导：两块一块按 (dr,dc) 走、另一块按 (dr,-dc) 走，各自要么走成、要么原地。
都走成或都没走成时列差变 0 或 ±2、奇偶不变；恰有一块被挡时列差变 ±1、奇偶翻转。
所以列差奇偶**不是**守恒量——只有「被挡」能翻它；而相撞要同列（列差 0，偶数），
一局的全部工作就是用墙（和门）制造奇数次被挡。这一句把那个算术写成可判错的话。

它同时核了三个词：pieces/cell_of（读位置）、intents/outcome（算谁被挡）——
拿两帧之间的**位移奇偶**去核 outcome 算出的**被挡块数**，是 kind_of 走闸的又一条通道。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..ACTION4，且 dc != 0（ACTION1/2 列不变，说了等于没说）；换关返回 NA；"
         "两块定位不到返回 NA；prev 帧上有记号格被点亮时返回 NA（移动键不搬块）；"
         "任一标法下有块撞危险色时返回 NA；两种标法算出的被挡块数奇偶不同时返回 NA")
NOTE = ("v1：起因是 dest_set v1 的分桶读数——它只在两块列差为偶数时开口（偶 58~81%、奇 0%）。"
        "追下去发现列差奇偶不是守恒量，只有「被挡」能翻它；而相撞要同列，"
        "所以一局的全部工作就是用墙（和门）制造奇数次被挡。这一句把那个算术写成可判错的话。")
EVIDENCE = ["14dbaaee74e9e2dd", "9ad082100dcdffb2", "aac863a41447fb39", "a3fe86c271ddada8"]

from _lib import pieces, cell_of, intents, outcome, sel_dim, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA or DELTA[action][1] == 0:
        return "NA"
    if sel_dim(prev) is True:
        return "NA"
    labs = intents(prev, action)
    a, b = pieces(prev), pieces(nxt)
    if labs is None or a is None or b is None:
        return "NA"
    blocked = set()
    for lab in labs:
        dest, hz = outcome(prev, lab)
        if hz:
            return "NA"
        blocked.add(sum(1 for (here, _), d in zip(lab, dest) if d == here) % 2)
    if len(blocked) != 1:
        return "NA"
    p = sorted(cell_of(prev, x) for x in a)
    q = sorted(cell_of(nxt, x) for x in b)
    gap_before = abs(p[0][1] - p[1][1]) % 2
    gap_after = abs(q[0][1] - q[1][1]) % 2
    flipped = gap_before != gap_after
    return "TRUE" if flipped == bool(blocked.pop()) else "FALSE"
