"""两块的格点位移集合恒等于 {(dr,dc) 或 (0,0)} 与 {(dr,-dc) 或 (0,0)} 各取一个——一块按 DELTA、一块按镜像 DELTA。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1..ACTION4；换关返回 NA；两块定位不到返回 NA；任一标法下有块撞危险色时返回 NA。不断言哪一块是哪一个"
NOTE = ("v6：第 165 步 d3efe0230197451a 打脸，伤在词汇表不在正文——scope 里「任一标法下有块撞危险色时返回 NA」"
        "早就写着，但 kind_of 的棋盘判据是「非地面像素恰占半格」，块边长为奇数时永远不成立，"
        "第 3 关 54 格 hazard 全读成 wall。改 _lib，本条正文未动，改完判 NA。"
        "v5：第 53 步 fd8457fb4e3950ca 打脸——两块交叉换边，「列小的那块按 DELTA 走」这个读法在两块同列时定不了身份。"
        "v4 之前 move_delta 与 lockstep_mirror 各断言一块，现在合成一条对身份不可知的：位移多重集。")
EVIDENCE = ["6ff14786341388c8", "f8760f8bfce7e6fd", "de906fa51c958612", "ccd3fa9a601ac286",
            "aac9b64b6347dbdf", "0697e3336bd6bffa", "fd8457fb4e3950ca", "d3efe0230197451a"]

from _lib import pieces, cell_of, intents, outcome, kind_of, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    labs = intents(prev, action)
    a, b = pieces(prev), pieces(nxt)
    if labs is None or a is None or b is None:
        return "NA"
    if any(kind_of(prev, tgt) == "hazard" for lab in labs for _, tgt in lab):
        return "NA"
    p = [cell_of(prev, x) for x in a]
    q = [cell_of(nxt, x) for x in b]
    dr, dc = DELTA[action]
    ok = {(0, 0), (dr, dc)}, {(0, 0), (dr, -dc)}
    # 两块和两个落点之间的配对未知：枚举配对与标法
    for perm in ((0, 1), (1, 0)):
        d0 = (q[perm[0]][0] - p[0][0], q[perm[0]][1] - p[0][1])
        d1 = (q[perm[1]][0] - p[1][0], q[perm[1]][1] - p[1][1])
        for s0, s1 in ((ok[0], ok[1]), (ok[1], ok[0])):
            if d0 in s0 and d1 in s1:
                return "TRUE"
    return "FALSE"
