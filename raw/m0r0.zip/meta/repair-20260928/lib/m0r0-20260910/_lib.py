"""这一局的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测来源：第 0 关 tid 6ff14786341388c8 / de906fa51c958612 / aac9b64b6347dbdf 等；
第 1 关 tid 0018d6fe5f1d1d0f（换关帧）。

**几何逐帧从帧上量，不写死**：第 0 关块边长 5、格点原点 (9,9)、镜像轴 62；
第 1 关块边长 4、格点原点 (6,6)、镜像轴 60。写死 CELL=5 的概念会在换关那一刻静默失效。
"""
from __future__ import annotations

FLOOR = 5                      # 可走地面（第 0/1/2 关都是 5）
PIECE = 10                     # 两个可动块的常态色
PIECE_SEL = 1                  # 有记号格被点亮时，两块整体变成这个色（第 65 步实测）
PIECE_COLORS = (PIECE, PIECE_SEL)
# 色 1 的来历：全局颜色普查（68 条转移）里它只在第 2 关出现，最多 32 像素 = 恰好两个 4x4 方块，
# 位置就是两块所在，点块自己又整体变回 10。所以两块共有两种色，块还是那两块。
# 不按「会动的色」认块了：进了点选模式两块一步不动也会变色。
# 结构护栏：geom 要求这些色的像素恰好拼成两个同边长对齐方块，拼不出就返回 None（宁可闭嘴不乱认）。

MARK = 9                       # 记号格中心 2x2 的常态色（第 2 关）
MARK_HI = 11                   # 被点亮的记号格中心色；注意色 11 在第 0 关是**墙色**（1294 像素），
                               # 所以记号只能按结构认（见 marker_of），按色号认会把第 0 关半张图当记号。

# 危险不按色号认。第 1 关的危险色 8，在第 2 关是右半边的**墙色**（65 个整格）——
# 按色号写死会让规划器把整个右半张图当禁手，一步都规划不出来。
# 结构上的读法：每关有一条接缝列（镜像轴），两半用**不同的墙色**（第0关 11/12、第1关 6/15、第2关 15/8），
# 地面两半同色（恒 5）。所以：整格含地面色又含别的色 = 地面上覆了花纹 = 危险；整格不含地面色 = 墙。

# 动作对**左块**的意图（单位：格点）。右块列取反（镜像），行相同。
DELTA = {
    "ACTION1": (-1, 0),
    "ACTION2": (1, 0),
    "ACTION3": (0, -1),
    "ACTION4": (0, 1),
}


def _piece_cells(g):
    return [(r, c) for r in range(len(g)) for c in range(len(g[0])) if g[r][c] in PIECE_COLORS]


_MEMO = {}


def _memo(tag, g, make):
    """按帧缓存派生量。键里存着帧对象本身的引用，所以 id 不会被回收后复用；只留最近几帧。

    这不是主张，是算得起：地形色是**全图**的性质（见 terrain_colors），
    而 kind_of 每判一格都要问一次；不缓存就得为每一格重扫一遍整帧。
    """
    key = (tag, id(g))
    hit = _MEMO.get(key)
    if hit is not None and hit[0] is g:
        return hit[1]
    val = make()
    if len(_MEMO) > 16:
        _MEMO.clear()
    _MEMO[key] = (g, val)
    return val


def geom(g):
    """从帧上量出 (CELL, r0, c0)：块边长与格点原点。量不出来返回 None。

    两块同色同形，总格数 = 2*CELL^2；行/列的最小值给出原点相位。
    """
    return _memo("geom", g, lambda: _geom(g))


def _geom(g):
    cs = _piece_cells(g)
    n = len(cs)
    if n == 0 or n % 2:
        return None
    side = int(round((n / 2) ** 0.5))
    if side < 1 or 2 * side * side != n:
        return None
    # 原点相位：所有块格的行/列都 ≡ 某个相位 (mod side)，取最小行/列所在的对齐
    rows = sorted({r for r, _ in cs})
    cols = sorted({c for _, c in cs})
    return side, rows[0] % side, cols[0] % side


def pieces(g):
    """两个块的 top-left，按列排序 -> [左块, 右块]；不是恰好两个对齐方块就 None。"""
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    tops = []
    for r in range(pr, len(g) - side + 1, side):
        for c in range(pc, len(g[0]) - side + 1, side):
            if all(g[r + a][c + b] in PIECE_COLORS for a in range(side) for b in range(side)):
                tops.append((r, c))
    if len(tops) != 2:
        return None
    tops.sort(key=lambda t: t[1])
    return tops


def cell_of(g, top):
    """块 top-left -> 格点 (i, j)（相对帧上量出来的原点相位）。"""
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    return ((top[0] - pr) // side, (top[1] - pc) // side)


def top_of(g, cell):
    """格点 (i,j) -> 块 top-left 像素坐标。"""
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    return (pr + side * cell[0], pc + side * cell[1])


def block_is(g, cell, colors):
    """格点 (i,j) 的 side x side 区是不是全在 colors 里（越界 False）。"""
    gm = geom(g)
    if gm is None:
        return False
    side, pr, pc = gm
    r, c = pr + side * cell[0], pc + side * cell[1]
    if r < 0 or c < 0 or r + side > len(g) or c + side > len(g[0]):
        return False
    return all(g[r + a][c + b] in colors for a in range(side) for b in range(side))


def _cell_pixels(g, cell):
    """格点 (i,j) 的 side x side 像素方阵；越界或量不出几何返回 None。"""
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    r, c = pr + side * cell[0], pc + side * cell[1]
    if r < 0 or c < 0 or r + side > len(g) or c + side > len(g[0]):
        return None
    return side, [[g[r + a][c + b] for b in range(side)] for a in range(side)]


def terrain_colors(g):
    """这一关的**地形色**：镜像轴左右两半各自最常见的那个非地面非块色。量不出几何返回 None。

    为什么不按色号：色号每关都换——同一个色号在这一关是危险花纹、在那一关是半边墙色。
    为什么按「两半各一种」：这一局每关都有一条接缝列，两半用不同的墙色，地面两半同色
    （见本文件开头 kind_of 那一段的实测记录）。所以两半的主色就是这一关的地形色；
    剩下的「整格纯色、色又不是这两种」的格子，是这一关额外摆进来的**物件**。

    先写过一版「贴着外框那一圈出现过的色就是地形色」，当场被第 4 关证伪：
    那一关有个物件格正好嵌在最外一列上，于是它那个色被整个判成地形，
    同色的门也就跟着认不出来了。外框会被物件打断，两半的主色不会。
    """
    def make():
        gm = _geom(g)
        if gm is None:
            return None
        side, pr, pc = gm
        nr, nc = (len(g) - pr) // side, (len(g[0]) - pc) // side
        cnt = [{}, {}]
        for i in range(nr):
            for j in range(nc):
                d = cnt[0] if j * 2 < nc else cnt[1]
                got = _cell_pixels(g, (i, j))
                if got is None:
                    continue
                for row in got[1]:
                    for v in row:
                        if v != FLOOR and v not in PIECE_COLORS:
                            d[v] = d.get(v, 0) + 1
        return {max(d, key=d.get) for d in cnt if d}
    return _memo("terrain", g, make)


def _object_color(g, cell):
    """格点是不是「物件格」：整格单一纯色、且那个色既不是地面色也不是这一关的地形色。
    是就返回那个色，不是返回 None。"""
    tc = terrain_colors(g)
    got = _cell_pixels(g, cell)
    if tc is None or got is None:
        return None
    vals = {v for row in got[1] for v in row}
    if len(vals) != 1:
        return None
    col = next(iter(vals))
    if col == FLOOR or col in PIECE_COLORS or col in tc:
        return None
    return col


def objects(g):
    """所有物件格 {格点: 色}。量不出几何返回 None。"""
    def make():
        gm = _geom(g)
        if gm is None:
            return None
        side, pr, pc = gm
        nr, nc = (len(g) - pr) // side, (len(g[0]) - pc) // side
        return {(i, j): col for i in range(nr) for j in range(nc)
                if (col := _object_color(g, (i, j))) is not None}
    return _memo("objects", g, make)


def switches(g):
    """孤立的物件格，按色分组 {色: {格点…}}：四邻里没有同色物件格的那些。

    第 186 步 aec3abdcbf3f67e7 实测：块**踏得进**这样一格（此前 kind_of 把它读成墙）。
    """
    obj = objects(g)
    if obj is None:
        return None
    out = {}
    for c, col in obj.items():
        if any(obj.get((c[0] + dr, c[1] + dc)) == col
               for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
            continue
        out.setdefault(col, set()).add(c)
    return out


def gates(g):
    """连成条的物件格，按色分组 {色: {格点…}}：四邻里有同色物件格的那些。挡路。"""
    obj = objects(g)
    if obj is None:
        return None
    out = {}
    for c, col in obj.items():
        if any(obj.get((c[0] + dr, c[1] + dc)) == col
               for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
            out.setdefault(col, set()).add(c)
    return out


def kind_of(g, cell):
    """格点 (i,j) 的类型，按**花纹**判、不按色号判。越界算 'wall'。

    实测三种花纹（第 0/1/2/3 关各出一种），色号完全不同、结构完全不同：
      纯地面色            -> 'free'   （PIECE 色按 free 算：另一块站着不改变地形）
      地面色与另一色**棋盘交错**：非地面像素同奇偶、且占满那种奇偶的全部位置 -> 'hazard'
      其余一律 'wall'：整格不含地面色（纯的另一色、或两半墙色的接缝），
                       以及地面上画了记号的格——记号格**挡路**，第 63 步实测。

    为什么不按色号：第 1 关的危险色 8 到第 2 关是右半边的墙色（65 个整格）。
    为什么棋盘要单列一类：第 1 关的危险格是 8/16 的棋盘，第 32 步实测踩上去整关重置；
    第 2 关那三个居中 2x2 的记号格（地面占 12/16）曾被读成可通行，
    第 63 步 d79f2f209a03887e 打脸——块撞上去原地不动，既没进去也没重置，就是堵墙。

    棋盘判据从「恰占半格」改成「占满一种奇偶」：块边长为奇数时 side*side 是奇数，
    两种奇偶各占 (n+1)//2 和 n//2 个，「恰占一半」**永远不成立**，那种边长上一格 hazard
    都认不出来，全部落进 'wall'——看着只是挡路，踩上去整关重置（第 165 步 d3efe0230197451a）。
    偶数边长上两种奇偶各占一半，新判据退化成旧判据：全语料新旧逐格对比，
    第 0/1/2 关一格不差（含第 1 关那 78 格 hazard），只有第 3 关多认出 54 格。
    第 186 步 aec3abdcbf3f67e7 又添一条：**孤立的物件格是站得上去的**（见 terrain_colors /
    switches）。此前它整格纯色、色号不认识，落进 'wall'，于是「块进不去」——
    实测块一步踏了进去，同色的整条门当场变地面。连成条的物件格（门）仍算 'wall'。
    """
    got = _cell_pixels(g, cell)
    if got is None:
        return "wall"
    side, px = got
    vals = {v for row in px for v in row}
    if vals <= {FLOOR, *PIECE_COLORS}:
        return "free"
    off = [(a, b) for a in range(side) for b in range(side) if px[a][b] != FLOOR]
    par = {(a + b) % 2 for a, b in off}
    if off and len(par) == 1:
        p = next(iter(par))
        want = sum(1 for a in range(side) for b in range(side) if (a + b) % 2 == p)
        if len(off) == want:
            return "hazard"
    sw = switches(g)
    if sw is not None and any(cell in cs for cs in sw.values()):
        return "free"
    return "wall"


def mark_box(side):
    """记号格中心小方块在格内的 (起点偏移, 边长)。边框恒一格宽。

    单独抽出来，是因为 marker_of 读它、概念的 apply 涂它，两处必须同一个几何；
    分开写死过一次（`side // 2`），在块边长 5 的关上读法和涂法会各错各的。
    """
    return 1, side - 2


def marker_of(g, cell):
    """记号格：整格只有正中央一小方块非地面色，四周留一圈**一格宽**的地面色边框。

    返回那一小块的颜色（第 2 关实测：常态 9，被点亮 11）；不是这个花纹返回 None。
    按结构不按色号：色 11 在第 0 关是墙色，色 9 在别的关也可能另有身份。
    注意 kind_of 仍把记号格判 'wall'——第 63/75 步实测块撞上去进不去。
    这两句是两件事：marker_of 说它长什么样，kind_of 说它挡不挡路。

    中心边长取 side-2（边框一格宽），不是 side//2：side=4 时两者都是 2，
    但 side=5 时 side//2 会读成 2，而且旧版还有一句 `if side % 2: return None`，
    把奇数边长的关整个读成「一个记号都没有」——静默失效，不报错。
    全语料普查（155 帧）：第 0/1/2 关两种读法逐帧一致（0 / 0 / 3 扇），
    只有块边长 5 的那一关新读法多认出 1 个，正是帧上那个 3x3 物件。
    改错了会被 terrain_static 的「记号个数不变」当场逮住。
    """
    got = _cell_pixels(g, cell)
    if got is None:
        return None
    side, px = got
    lo, h = mark_box(side)
    if h < 1:
        return None
    inner, outer = set(), set()
    for a in range(side):
        for b in range(side):
            (inner if lo <= a < lo + h and lo <= b < lo + h else outer).add(px[a][b])
    if outer != {FLOOR} or len(inner) != 1 or FLOOR in inner:
        return None
    return inner.pop()


def markers(g):
    """{格点: 中心色}，全部记号格。量不出几何返回 None（和「没有记号」区分开）。"""
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    nr, nc = (len(g) - pr) // side, (len(g[0]) - pc) // side
    out = {}
    for i in range(nr):
        for j in range(nc):
            m = marker_of(g, (i, j))
            if m is not None:
                out[(i, j)] = m
    return out


def piece_color(g):
    """两块此刻的颜色（两块必须同色）。定位不到或两块不同色返回 None。"""
    p = pieces(g)
    if p is None:
        return None
    side = geom(g)[0]
    cols = {g[r + a][c + b] for r, c in p for a in range(side) for b in range(side)}
    return cols.pop() if len(cols) == 1 else None


def sel_dim(g):
    """两块是不是处在「变暗」色。两块颜色不一致或定位不到返回 None。"""
    col = piece_color(g)
    return None if col is None else col == PIECE_SEL


def click_cell(g, action):
    """`ACTION6:x,y` 点中哪个格点。**x 是列、y 是行**（world/play.py 的参数序，第 65 步实测对上）。

    不是带坐标的 ACTION6、坐标解析不出、量不出几何、或落在格点原点之外，返回 None。
    裸 `ACTION6`（不带坐标）上游直接回 500，是畸形请求，不是一个动作。
    """
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    gm = geom(g)
    if gm is None:
        return None
    side, pr, pc = gm
    if y < pr or x < pc:
        return None
    return ((y - pr) // side, (x - pc) // side)


def intents(g, action):
    """两块在这个动作下的两种标法。

    两块中恰有一块按 DELTA 走（direct）、另一块按列取反的 DELTA 走（mirror），
    但**哪一块是哪一个读不出来**：第 53 步实测两块可以交叉换边，按列排序会把身份对调。
    所以返回两种标法，每种是 [(块0当前格点, 块0意图), (块1当前格点, 块1意图)]。
    定位不到或动作不在 DELTA 里返回 None。
    """
    p = pieces(g)
    if p is None or action not in DELTA:
        return None
    dr, dc = DELTA[action]
    here = [cell_of(g, x) for x in p]
    out = []
    for d0, d1 in (((dr, dc), (dr, -dc)), ((dr, -dc), (dr, dc))):
        out.append([(here[0], (here[0][0] + d0[0], here[0][1] + d0[1])),
                    (here[1], (here[1][0] + d1[0], here[1][1] + d1[1]))])
    return out


def outcome(g, labeling):
    """给定一种标法，算两块的落点与这一步的性质。

    返回 (落点列表, 有没有块撞危险)。落点：kind='free' 进，否则原地。
    """
    dest, hz = [], False
    for here, tgt in labeling:
        k = kind_of(g, tgt)
        if k == "hazard":
            hz = True
        dest.append(tgt if k == "free" else here)
    return dest, hz


def free_cells(g):
    """所有 kind_of == 'free' 的格点 (i,j) —— 静态可站位。"""
    gm = geom(g)
    if gm is None:
        return set()
    side, pr, pc = gm
    nr, nc = (len(g) - pr) // side, (len(g[0]) - pc) // side
    return {(i, j) for i in range(nr) for j in range(nc) if kind_of(g, (i, j)) == "free"}


def hud_len(g):
    """行 63 上非地面色的格数（第 0 关那条计数带；规则尚未解出）。"""
    return sum(1 for v in g[63] if v != FLOOR)


# ======================================================================
# 修复（2026-09-28，meta/repair-20260928）新增部分。以上原函数一字未改。
# ======================================================================

def hazard_cells(g):
    """所有 kind_of == 'hazard' 的格点（棋盘花纹格）。只读当前帧像素。

    原状态只有 free_cells（可走格），分不出「墙」与「危险」：意图落点是墙 = 原地不动，
    是危险 = 整关重置（hazard_resets）。step 要分这两种，就得有这个集合。
    """
    gm = geom(g)
    if gm is None:
        return set()
    side, pr, pc = gm
    nr, nc = (len(g) - pr) // side, (len(g[0]) - pc) // side
    return {(i, j) for i in range(nr) for j in range(nc) if kind_of(g, (i, j)) == "hazard"}


# ---- 隐藏状态（判据修订 R1.1）----
# 计数带 hud_len 的推进规律：本关已走步数 n（每个动作都算，含 ACTION5、点选、推记号、被弹回的那一步）
# 满足 hud_len = round(64 * n / 150)。实测：全部 473 条关内转移（6 关、两段整局）逐条相等，
# 且在 B ∈ [100, 200) 里只有 B = 150 在每一关都成立（脚本 _scratch/m0r0-20260910/probe3.py）。
# 单帧读不出 n（带子每 7 步只长 3 格，同一个带长对应两三个不同的 n），所以用隐藏量数步。
#
# 第二个隐藏量 flip：两块的**身份**（哪一块按 DELTA 走）跟着块本身走，不跟着「列序」走。
# 两块交叉换边（第 1 关 seq 53：(11,6)/(12,6) 同列，一步后成 (12,5)/(11,7)）之后，
# 按列序排在前面的那一块就换了人。flip = 自本关开局（或被弹回出生点）以来，按列序排的两块
# 换过几次位（mod 2）。本关开局时 direct 是列序第 k_dir 块（LEVEL_CONST），此后是第 k_dir XOR flip 块。
# 实测：seq 55 / 309（第 1 关换关那一步）只有带上 flip 才算得出两块撞到同一格。
# 怎么算（纯感知的「物体恒存」追踪，不用任何移动规则）：前后两帧各按列序排出两块的格点，
# 看哪种一一对应让每一块的格点位移（曼哈顿距离）都不超过 1——块一步最多挪一格。
#   只有「交叉对应」满足 -> 列序换了人，flip 翻转；
#   两种都满足（两块都没动之类）或只有「原序对应」满足 -> flip 不变；
#   两种都不满足（块跳了不止一格：被危险格弹回出生点）-> 追踪断了，两块回到出生格，flip 归 0。
HIDDEN_INIT = {"steps": 0, "flip": 0}


def _col_sorted_cells(g):
    p = pieces(g)
    if p is None:
        return None
    return sorted((cell_of(g, x) for x in p), key=lambda t: (t[1], t[0]))


def _near(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) <= 1


def hidden_step(h, prev, action, nxt):
    """steps：本关已走步数 +1。flip：见上。只用四个参数（action 也不看）；不看 tid、步序、关卡号。"""
    flip = h["flip"]
    p, q = _col_sorted_cells(prev), _col_sorted_cells(nxt)
    if p is not None and q is not None:
        same = _near(p[0], q[0]) and _near(p[1], q[1])
        cross = _near(p[0], q[1]) and _near(p[1], q[0])
        if cross and not same:
            flip ^= 1
        elif not cross and not same:
            flip = 0
    return {"steps": h["steps"] + 1, "flip": flip}


# ---- 每关常数（判据修订 R1.1）：游戏内容，与换关后的布局同类 ----
# 位掩码与生成器的格集合编码一致：格点 (r,c) 占第 r*64+c 位。
# 反推依据（脚本 _scratch/m0r0-20260910/derive_consts.py 实跑）：
#   spawn —— 本关出生格点：该关第一帧（换关那一步的 next / run 开头的 prev）上两块的格点。
#            用途：危险格整关重置时两块被弹回这里（第 1 关 seq 32、第 3 关 seq 165 实测落点正是这两格）。
#   mark0 —— 本关开局记号格位置：同一帧上 markers 的格点。重置时记号也回到这里（第 3 关 seq 165 实测）。
#   o12 / o14 / o15 —— 本关各色物件格的**全布局**（开关 + 门）：同一帧上 objects 按色分的格点。
#            核对：该关其余所有帧上见到的物件格都落在这份布局里（unseen-in-first 为空）。
#            开关 = 布局里四邻无同色的格，门 = 连成条的格；开门后门格变地面、块站上去盖住，帧上都看不见，
#            所以要靠布局记住它们在哪。
#   dir —— 两块按「列小在前、同列行小在前」排序后，按 DELTA 走的那一块（direct）的下标。
#            核对：该关全部未点亮态的列移动里，这个下标的标法都解释得了落点（第 0/1/2/3/5 关 0，第 4 关 1，
#            各关证据条数 12/25/42/14/38/16）；identity_needs_one_move 说的正是「身份要靠一次列移动测出」。
#            （这组计数按「不交叉」数的；带上隐藏量 flip 之后，_scratch/m0r0-20260910/sim.py 在全部 473 条
#            关内转移与 12 次换关上复核：关内逐字段对上，12 次换关全是按真身份算出的相撞。）
#   第 6 关是通关后的画面，没有内容，全部记 0（只为让字段不是 Option）。
def _cells_mask(cells):
    m = 0
    for r, c in cells:
        m |= 1 << (r * 64 + c)
    return m


_LEVEL_LAYOUT = {
    0: dict(dir=0, spawn=[(9, 3), (9, 7)], mark0=[], o12=[], o14=[], o15=[]),
    1: dict(dir=0, spawn=[(2, 5), (2, 9)], mark0=[], o12=[], o14=[], o15=[]),
    2: dict(dir=0, spawn=[(11, 5), (11, 9)], mark0=[(3, 7), (4, 2), (7, 9)], o12=[], o14=[], o15=[]),
    3: dict(dir=0, spawn=[(6, 2), (4, 8)], mark0=[(5, 5)], o12=[], o14=[], o15=[]),
    4: dict(dir=1, spawn=[(12, 1), (12, 13)], mark0=[],
            o12=[(6, 14), (9, 2), (9, 3), (9, 4)],
            o14=[(5, 3), (5, 4), (5, 5), (6, 8)],
            o15=[(1, 3), (5, 10), (5, 11), (5, 12), (9, 10), (9, 11), (9, 12), (12, 3)]),
    5: dict(dir=0, spawn=[(5, 4), (5, 10)], mark0=[(10, 7)],
            o12=[(3, 4), (7, 9), (7, 10), (7, 11)],
            o14=[(3, 10), (7, 3), (7, 4), (7, 5), (10, 4)], o15=[]),
    6: dict(dir=0, spawn=[], mark0=[], o12=[], o14=[], o15=[]),
}

LEVEL_CONST = {lv: {k: (v if k == "dir" else _cells_mask(v)) for k, v in d.items()}
               for lv, d in _LEVEL_LAYOUT.items()}
