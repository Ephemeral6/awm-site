"""底条消耗的**上界**：走完第 step 步时，底条里已消耗（色3）的格数 used <= floor(step / 3)。"""
LEVEL = "L4"
SCOPE = "每条转移都判；ctx 里没有 step、或换关，返回 NA"
NOTE = ("v3：砍掉下界，只留上界。v2 是一条窄带 floor((step-1)/3)-1 <= used <= floor(step/3)，"
        "第 31、34 步双双被下界推翻。死因查明了：**ACTION6 不推进这只钟**。"
        "实测扣格出现在第 4、8、11、14、17、20、24、27、32、35 步，原始间隔 4,3,3,3,3,4,3,5,3——"
        "那个 5 正好跨过第 28、29 两步 ACTION6；把 ACTION6 从步数里剔掉重排，间隔变成 4,3,3,3,3,4,3,3,3，"
        "v2 的下界在全部 35 条上就都成立了。但『非 ACTION6 的步数』要数历史才算得出来，"
        "单条转移的 assert_ 看不见它，所以不把下界硬塞回来——写不成可判错的形式就不写。"
        "上界不受这件事影响（少走的钟只会更慢），而上界正是规划要用的那一半："
        "底条一共 64 格，used <= floor(step/3) 意味着这一关至少还有 190 步左右的预算，预算不是当前的约束。"
        "先后死掉的假设：『每 N 步扣一格』的精确形式（v1，第 23 步）、『每次缩绳扣 1』（第 16 步缩绳没扣）、"
        "『伸到最右列扣 1』（第 13 步伸到最右列没扣）、『动作被拒不算一步』（第 10 步被拒照样算）、"
        "v2 的下界（第 31、34 步）。上界在第 4、11、14、17、20 步是顶到边的，不是随手放宽。"
        "为什么每 3 步扣一格里还会时不时多出一步空档，仍然不知道。")
EVIDENCE = ["ffa9f1be044bfcb7", "33382ab46ed81e55", "e31b50c2cbc262a7",
            "61bdae5b089bd2ee", "de556bbfa08901b9", "2f430e8ba6f2b5f8",
            "4bc3c5dd7488afa6", "67c3963bceb3915d",
            "d6d37479730e7523", "a60ccd338ee24c94"]

from _lib import bar_used

BAR_CELLS = 64


def ceiling(step):
    """假设：走完第 step 步时底条已消耗格数的上界。"""
    return step // 3


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("step") is None:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    return "TRUE" if bar_used(nxt) <= ceiling(ctx["step"]) else "FALSE"
