"""ACTION7 在新绳尖要落进的那一格是墙时，绳子绝不会加长：要么绳长一节不变而玩家整体移动一行（上下都可能），要么绳子收短恰好一节而玩家不换行；两者之外没有第三种，绳尖尤其永远不会越过墙那一格。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7，且只看 extend_ok 为假（新绳尖那一格是墙）的局面；"
         "伸得出去那一半归 a7_shuttle / a7_drag；换关返回 NA；me() 或 rope_cells() 定位不到返回 NA。"
         "**不说什么时候是哪一种**——那由一个帧里看不见的方向位决定（frame_not_state）；"
         "也**不说杆下和身后的靶跟不跟着走**"
         "（第 372 步身后三块靶一块没动，第 413 步身后那一块跟着走了，还没人管这条差别）。")
NOTE = ("v1 只有第 372 步 95bb69228812c934 一条依据，写着『下移一行』，"
        "死于第 406 步 b27ff4012f8e7dd4：同一行、同样 n=3、绳尖落点同样是那格墙，玩家往**上**抬了一行。"
        "v2 把方向摘掉，只留下两件在两条转移上都成立的事：绳长一节不变、玩家整体走一行。\n"
        "v2 死在它自己 NOTE 里预告过的那个局面上——第 452 步 6270570132f48bf9："
        "同一行、同样 n=3、绳尖落点同样是那格墙，这一次方向位是向左，于是它**收了一节**、玩家没换行。"
        "v2 的 NOTE 原话是「那多半会收一节而不是换行，这条概念当场判 FALSE」，一字不差地应验了。"
        "**这条欠条能被兑现，是因为它被写成了『去把那个局面造出来』的待办，不是写成一句自我表扬**："
        "造那个局面只花了六步（把杆顶到墙跟前，然后连按 ACTION7），"
        "而它躺在 NOTE 里当摆设的那四十几步里，我一直以为自己已经处理过它了。\n"
        "v3 因此不再声称『会发生哪一种』，改说一件两种情形下都成立、而且正是阻断论证要用的事："
        "**撞墙时绳子只会不变或变短，绝不会加长**。加长一节、一次变两节、玩家换了格列、"
        "或者绳长和格行同时变，都当场判 FALSE。"
        "这一版比 v2 弱，但它管的那半句是有分母的：三次撞墙（第 372、406、452 步）全部成立。")
EVIDENCE = ["95bb69228812c934", "b27ff4012f8e7dd4", "6270570132f48bf9"]

from _lib import CELL, me, rope_cells, extend_ok


def _is(action):
    return action.startswith("ACTION7")


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _is(action):
        return "NA"
    if extend_ok(prev) is not False:
        return "NA"                          # 伸得出去 / 没把握：不归这一条管
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    if a[1] != b[1]:
        return "FALSE"                       # 玩家的格列永远不变
    if nb == na:                             # 绳长不变 → 必须整体走一行
        return "TRUE" if b[0] in (a[0] + CELL, a[0] - CELL) else "FALSE"
    if nb == na - 1:                         # 收一节 → 必须不换行
        return "TRUE" if b[0] == a[0] else "FALSE"
    return "FALSE"                           # 加长、或一次变两节以上
