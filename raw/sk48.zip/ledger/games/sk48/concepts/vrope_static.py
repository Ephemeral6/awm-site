"""头上没有玩家的那种竖绳是死的：有几根、每根占哪个格列、伸下来几节、头是什么色、头占哪几行，一步都不变。"""
LEVEL = "L6"
SCOPE = ("所有动作；换关返回 NA；"
         "**只管头不是玩家精灵的竖绳**（vrope_owner 为 None 的那些）——头上坐着玩家的那种归它主人的动作管；"
         "prev 和 nxt 里都一根这样的竖绳都认不出（第 0、1、4、5 关就是这样）返回 NA")
NOTE = ("由来：第 85 步缩绳，绳尖格上正压着一块靶、落点空着，它却一动没动，"
        "而第 1 关一条各分量都相同的转移里同样的靶动了。看整幅帧才发现第 2 关多了一根竖绳——"
        "双列的链，压在某个格列正中两列上，从棋盘上边缘往下伸若干格，把那一列的靶全串上；"
        "头是棋盘正上方压在同两列上的一个 2×2 小块。"
        "写成『它不动』是因为这是规划最要紧的一件事：它不动，那一格列的靶就只能沿它上下滑。"
        "故意写成一串分量的合取，好死：根数变了、列变了、节数变了、头变色或挪了，任意一样都是反例。\n"
        "v2 → v3 是**被推翻后缩的**，不是修 bug。v2 说的是「棋盘里的竖绳全是死的」，"
        "它死在第 491 步 11131d8a77ef8941：第 5 关那根竖绳的头根本不是装饰，是第二个玩家的精灵，"
        "选中它、再按一下方向键，整根绳跟着往右挪了一格列（第 492 步）。"
        "所以『竖绳』从来不是一类东西：一类挂着玩家、跟着主人走，一类光秃秃地钉在那儿。"
        "v3 只认后一类，分界线写成可读的判据 vrope_owner —— 头上那个 2×2 小块有没有玩家精灵的填色环。\n"
        "**v2 能活到 S=0.988，靠的是读数在最该说话的时候瞎了**：读竖绳的词按色2/3 找，"
        "而选中的绳是色1/2；第 5 关一选中，那根绳在它眼里就消失了，它于是判 NA 而不是判 FALSE。"
        "词汇改成不看颜色只看几何之后（vropes 的由来里记着全语料 277/279 逐帧对账），它才说得出话。"
        "教训跟撤掉的那条阻断主张是同一个：**沉默不是安全**，一条概念在新关整关判 NA，"
        "要先怀疑是读数瞎了，不是世界变简单了。\n"
        "还不知道的：第 2、3 关那种死绳，有没有哪个动作能让它动——只是至今没见过，不是证明了不能。")
EVIDENCE = ["b424b0d06a2ae875", "aef9b660922ca25a", "62f19bc0aa76f57b", "11131d8a77ef8941"]

from _lib import CELL, board_box, vropes, vrope_head, vrope_owner


def head_span(g, vc, color):
    """假设：某根竖绳的头占的行 —— 棋盘上方、压在它那一格列正中两列上、两列都是这个色的行。"""
    b = board_box(g)
    if b is None:
        return None
    top, _, left, _ = b
    c0 = left + CELL * vc + 2
    return tuple(r for r in range(top) if g[r][c0] == color == g[r][c0 + 1])


def state(g):
    """假设：盘上**没有主人**的竖绳的全部状态 —— 每根一条 (格列, 节数, 头色, 头占的行)，按格列排。
    一根也没有返回 None；有、但哪根的头认不出来，也返回 None。"""
    v = [(vc, n) for vc, n in vropes(g) if vrope_owner(g, vc) is None]
    if not v:
        return None
    out = []
    for vc, n in v:
        h = vrope_head(g, vc)
        span = head_span(g, vc, h) if h is not None else None
        if not span:
            return None
        out.append((vc, n, h, span))
    return tuple(out)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = state(prev), state(nxt)
    if a is None and b is None:
        return "NA"
    if a is None or b is None:
        return "FALSE"                   # 一头有一头没有，也是它变了
    return "TRUE" if a == b else "FALSE"
