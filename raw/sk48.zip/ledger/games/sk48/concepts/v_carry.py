"""竖绳伸一节（选中竖玩家按 ACTION2）时，杆上串着的每一颗靶都跟着往下挪一格；
挪不动的（落点出棋盘下边缘、是墙、或压着一颗没挪成的靶）留在原地；盘上别的靶一块不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION2，且只看绳长恰好加一节、玩家没换格列的那一批；换关返回 NA；"
         "**选中的不是竖玩家就返回 NA**（那时 ACTION2 是横玩家下移，归 a2_down 管）；"
         "players()/cell_map()/walls() 读不出来、或绳已经伸满整列，返回 NA。"
         "**新绳尖要落进的那一格上压着靶，返回 NA** —— 绳尖前面那一串怎么走归 v_push / v_capture 管，"
         "这一条只说**杆上已经串着的**那些靶；杆上一颗靶都没有也返回 NA（没什么可说的）。"
         "**杆上有一颗靶同时串在横玩家那根杆上，那一颗搬不动**（第 986 步在缩绳那一侧实测），"
         "它下面那一串跟着卡住，绳照样伸；落点被横杆盖着的也当搬不动（这半是押注）。"
         "这一支从 v2 起不再返回 NA。"
         "只说靶落在哪一格，不说绳子和玩家精灵怎么画。")
NOTE = ("由来：第 875、876 步，而且**是押注落空换来的**。当时押的是「绳尖落点空着 → 盘上六颗靶一颗不动」，"
        "依据是 _lib.vextend_map 当时的写法。世界给的是：绳 5→6→7，那颗串在杆上第 4 行的色9"
        "跟着走到 (5,4) 再到 (6,4)。\n"
        "**这一步差点从眼皮底下溜过去**：settle 报的是 0 条反例、闸是开的——"
        "因为 v_extend 的 assert_ 只断言「绳自己的几何」（玩家没挪、n 加一），靶挪没挪它压根不看，"
        "而 v_push / v_capture 都因为绳尖那一格空着而返回 NA。全册没有一条概念对这两步的靶说过话。"
        "抓住它的是另一个数：settle 的「**说错却判 TRUE**」——v_extend 的 apply 认领 36 格、说错 16 格，"
        "正好是一颗靶的两个 4×4。生成器比检查器诚实，因为它必须把话说到像素上。\n"
        "规律本身是 v_drag 的镜像，也是 hmoved_cells 转 90 度的另一半：杆上的靶跟着杆走，"
        "**伸和缩两个方向都算**。到这一步为止，竖绳的四件事凑齐了："
        "杆上的靶跟着走（v_carry / v_drag）、绳尖前面连续的一串被顶着走（v_push）、"
        "顶不动就被绳串上（v_capture）、绳尖落点是墙就一节都不伸（v_extend）。\n"
        "**还没验的**：一、杆上两颗以上、彼此不相连时是不是各走各的（这两步杆上都只有一颗）；"
        "二、「挪不动的留在原地」这一支零证据，纯粹照横向那边补齐——路线上第一次撞它是"
        "在格列 0 上把三颗靶顶着棋盘下边缘的时候（那一步归 v_capture 管），"
        "而杆上的靶被下面不动的靶挡住这一支要等更后面。\n"
        "v2：**只改 scope 和 NOTE，断言一个字没动**——因为改的是共用的词 `_lib.vpole_now`，"
        "而改词不算改版，这个文件里的话就落在了代码后面。第 986 步（468e503ea57c795f，缩绳那一侧）："
        "竖绳 7→6 节，杆上那颗同时串在横杆上的 8 一格没动，它上面那颗自由的 9 照常走。"
        "`vpole_now` 于是从「有一颗被横杆串着就整条返回 None」改成「跳过那一颗、它后面的一串跟着卡住」，"
        "伸绳这一侧共用同一份，scope 里那句「语料 0 条，不表态」当场作废。"
        "**这条概念在那条 tid 上自己判 NA**（它只看 ACTION2），事实是经由共用的词传过来的——"
        "所以它在伸绳方向上仍是押注，第一次真在伸绳时撞到一颗被横杆串着的靶就兑现或落空。"
        "只管**伸缩**这一点同 v_drag：平移那两条（vslide_blocks、vmove_blocks）串没串着一概不管。")
EVIDENCE = ["93778eca4e036704", "c6898ee4c58523a2", "468e503ea57c795f"]

from _lib import (CELL, board_box, cell_map, cell_topleft, nrows, players,
                  sel_v, vpole_now, vpole_map, vrope_map, repaint_pending)


def _span_case(prev):
    """这一条管不管这一步：管，就返回 (格列, 绳长, 真的走成的那些格)；不管返回 None。"""
    p = sel_v(prev)
    nr = nrows(prev)
    if p is None or nr is None:
        return None
    _, _, cc, n, _ = p
    if n >= nr:
        return None
    m = cell_map(prev)
    if m is None or (n, cc) in m:          # 绳尖那一格有靶 → 归 v_push / v_capture
        return None
    if not [r for r in range(n) if (r, cc) in m]:
        return None                        # 杆上一颗靶都没有
    mv = vpole_now(prev, +1)
    if mv is None:
        return None
    return cc, n, mv


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    p = sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v' or (q[0][2], q[0][3]) != (cc, n + 1):
        return "NA"                        # 不是「伸一节且没换列」，不归这一条管
    if _span_case(prev) is None:
        return "NA"
    want, m2 = vpole_map(prev, +1), cell_map(nxt)
    if want is None or m2 is None:
        return "NA"
    return "TRUE" if want == m2 else "FALSE"


def apply(prev, action, ctx=None):
    """走成的那些靶画在新落点上；腾出来的那一格露出的是**绳子**——伸绳只会让杆更长，
    刚腾空的那一格照旧被绳盖着（这一点和 v_drag 正相反：那边腾出的是绳尖外面，露出的是底色）。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION2"):
        return None
    case = _span_case(prev)
    if case is None:
        return None
    cc, n, mv = case
    if not mv:
        return None
    b, m = board_box(prev), cell_map(prev)
    after = vpole_map(prev, +1)
    rope = vrope_map(prev, cc, n + 1, True)
    if b is None or after is None or rope is None:
        return None
    out = {}
    for (r, c) in set(mv) | {(r + 1, c) for (r, c) in mv}:
        tl = cell_topleft(prev, r, c)
        if tl is None:
            return None
        t0, l0 = tl
        color = after.get((r, c))
        for dr in range(4):
            for dc in range(4):
                rc = (t0 + dr, l0 + dc)
                if color is not None:
                    out[rc] = color                 # 这一格上有靶：画 4×4
                elif rc in rope:
                    out[rc] = rope[rc]              # 腾空了，露出绳子那两列
                else:
                    out[rc] = 4                     # 其余是棋盘底色
    return out
