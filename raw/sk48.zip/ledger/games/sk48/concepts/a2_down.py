"""ACTION2 对玩家方块只有两种可能：整体下移恰好 CELL 行（列不变、绳节数不变），或者原地不动；不会有第三种位移。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION2；换关返回 NA；me() 或 rope_tip() 定位不到返回 NA。"
         "**什么时候动归 move_block 管**，这一条只管动起来长什么样；也不管棋盘以外的层（钟、示意图）。")
NOTE = ("v4：删掉『或者整帧不动』那条兜底，与 a1_up 同因——盘上有一只自己会走的钟，"
        "「整帧不动」的真假挂在钟的相位上，和这条主张说的事情无关。对象缩到玩家方块。"
        "v3：apply 不再往靶块像素上画绳子（与 a1_up 同因）。"
        "v2：apply 加上 move_ok 守卫（与 a1_up 同因——生成器要知道什么时候不该开口）。"
        " || v5 只改 apply，与 a1_up v5 同因：第 5 关方向键作用在第二个玩家身上时断言照样成立"
        "（横玩家原地不动那一支），生成器却照着「动了」画了整只精灵。多一道 h_selected 守卫。"
        "没有反例 tid——这一版是靠「说错 N 格」这个读数改的，不是靠死因改的。")
EVIDENCE = ["47d23cc787256054"]

from _lib import (CELL, me, rope_cells, sprite_cells, bg_at, move_ok, vmove_map,
                  map_pixels, h_selected, repaint_pending)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    if nb != na:
        return "FALSE"
    return "TRUE" if b in (a, (a[0] + CELL, a[1])) else "FALSE"


def apply(prev, action, ctx=None):
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION2"):
        return None
    if h_selected(prev) is not True:
        return None                      # 方向键此刻作用在另一个玩家身上，这条不开口
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None or not move_ok(prev, 1):
        return None
    old = sprite_cells(a[0], a[1], n)
    new = sprite_cells(a[0] + CELL, a[1], n)
    covered = map_pixels(prev, vmove_map(prev, 1) or {})
    out = {rc: v for rc, v in new.items() if rc not in covered}
    for rc in old:
        if rc not in new and rc not in covered:
            out[rc] = bg_at(prev, *rc)
    return {rc: v for rc, v in out.items() if 0 <= rc[0] < len(prev) and 0 <= rc[1] < len(prev[0])}
