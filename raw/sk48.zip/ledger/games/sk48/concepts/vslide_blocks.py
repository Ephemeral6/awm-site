"""选中的是竖玩家时，ACTION3/ACTION4 让那根竖绳像一根竖杆从第 c 列扫到第 c+d 列；杆盖住的每一行各自结算：本列那一格有靶就从它起沿 d 的一串连续靶跟着走，本列空而对面那一格有靶就是被杆顶走、从对面那一格起的一串跟着走；杆够不着的行一格不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION3/ACTION4；换关返回 NA；"
         "**此刻方向键作用的不是竖玩家（sel_player 不是 v）返回 NA** —— "
         "那时 ACTION3/4 伸缩的是横玩家那根绳，靶的落点归 a3_retract、a4_extend、move_block 管；"
         "棋盘/玩家/墙读不出来返回 NA。"
         "只说靶的落点（cell_map）；玩家精灵和绳自己那两像素列归 v_slide 管。")
NOTE = ("这是 vmove_blocks 转 90 度：同一条「平移=一根杆扫过去、杆盖住的每一条线各自推链」，"
        "换成绳当竖杆、扫的是列、推的是行。**为什么敢照搬**：v_slide v2 的 NOTE 里留了一段白——"
        "「绳横着刮过去会不会把靶带走或被靶挡住」当时一次都没量过，只说了「横向那边的对应事实说明这里很可能有话要说，"
        "但那要另立一条，且要先赶上一步真的刮到靶的转移」。第 987 步就是那一步，一步把三件事全给了。\n"
        "由来（第 987 步 ACTION4，竖玩家在格列 3、绳 6 节，往右挪进格列 4）：\n"
        "  · 绳上第 3 行那颗自由的 9 跟着走进 (3,4)——「靶就在杆上、跟着走」；\n"
        "  · 第 5 行那颗 8 **同时串在 4 节横杆上**，照样被带进 (5,4)——所以平移一概不管另一根绳串没串着它。"
        "    这一条和伸缩正好相反（伸缩里串在另一根绳上的那颗搬不动，见 _lib.vpole_now、h_extend 的 pinned 判据），"
        "    两条合起来才是这一局的推挤规矩：**搬得动搬不动看的是「平移还是伸缩」，不是「串没串着」**；\n"
        "  · 要挪进去的第 4 列在第 4 行上坐着一颗 14，被杆顶到 (4,5)——「本列空而对面那一格有靶就是被顶走」。\n"
        "帧差 272 格，当时全册只说得出 72 格（v_slide 认领的那两个 6×6 精灵框），"
        "靶那 200 格是无人区；这一条就是去接那 200 格的。\n"
        "**押注那一半**：slide_ok 里「推链会把某一块顶出棋盘 → 整个动作被拒、棋盘一格不变」"
        "是从横向那边（move_ok，第 5 关实测过）搬过来的类比，这一侧还没赶上过。落空就在这里改。\n"
        "v2：**只改 apply，断言一个字没动**。v1 里靶走掉之后腾出来的那几个像素，"
        "凡是被横杆压着的一概不认领（怕说错）；第 1026 步量清了画的顺序——靶盖横杆、横杆盖竖绳、竖绳盖棋盘，"
        "于是那几个像素改成按 _lib.hrope_map（横杆的色，按主人选中与否取）画。"
        "同一批 v_slide 升到 v3 认领了绳自己那两像素列，两边合起来，"
        "竖玩家横挪这一类步的帧差才第一次有人全说完——**这不只是 E 的事**："
        "链式预测里没人认领的像素会留着旧值，下一步的概念读到的就是一张脏帧，"
        "第 1017-1021、1032-1035 步就是这么把后面的预测一步步带偏的（每步实际帧差两百上下，"
        "全册只说得出七十二格）。终局卡上一批十几步全靠链式推下去，这种脏帧会直接把批停掉。")
EVIDENCE = ["3e8ee74dab13bf15", "f3fbf4ef485fe8a7"]

from _lib import (bg_at, cell_map, cell_topleft, hrope_map, ncols, sel_v,
                  slide_ok, vrope_map, vslide_cells, vslide_map, repaint_pending)


def _d(action):
    if action.startswith("ACTION3"):
        return -1
    if action.startswith("ACTION4"):
        return 1
    return None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = _d(action)
    if d is None:
        return "NA"
    if sel_v(prev) is None:
        return "NA"                      # 方向键此刻作用在横玩家身上
    ok = slide_ok(prev, d)
    if ok is None:
        return "NA"
    if not ok:
        return "TRUE" if cell_map(nxt) == cell_map(prev) else "FALSE"
    want = vslide_map(prev, d)
    if want is None:
        return "NA"
    return "TRUE" if cell_map(nxt) == want else "FALSE"


def apply(prev, action, ctx=None):
    """只画靶：新落点整块 4×4 涂靶色（靶盖在绳上、也盖在横杆上，实测过），腾出来的那一格退回底色——
    露出横杆的那几个像素按横杆的色画（第 1026 步实测：靶盖横杆、横杆盖竖绳）。
    新绳那两像素列不认领，归 v_slide。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    d = _d(action)
    if d is None:
        return None
    p = sel_v(prev)
    if p is None:
        return None
    if not slide_ok(prev, d):
        return None                      # 动作会被拒（或没把握）：这一步不开口
    mv = vslide_cells(prev, d)
    if not mv:
        return None
    _, _, cc, n, _ = p
    nc = ncols(prev)
    if nc is None or any(not (0 <= c + d < nc) for (_, c) in mv):
        return None
    m = cell_map(prev)
    new_cells = {(r, c + d): m[(r, c)] for (r, c) in mv}
    out = {}
    for (r, c), color in new_cells.items():
        top, left = cell_topleft(prev, r, c)
        for dr in range(4):
            for dc in range(4):
                out[(top + dr, left + dc)] = color
    old_rope = vrope_map(prev, cc, n)
    new_rope = vrope_map(prev, cc + d, n)
    hr = hrope_map(prev)
    if old_rope is None or new_rope is None or hr is None:
        return None
    for (r, c) in mv:
        if (r, c) in new_cells:
            continue
        top, left = cell_topleft(prev, r, c)
        for dr in range(4):
            for dc in range(4):
                rc = (top + dr, left + dc)
                if rc in out or rc in new_rope:
                    continue             # 新绳那两列归 v_slide 画
                if rc in hr:
                    out[rc] = hr[rc]     # 靶走掉之后露出来的是横杆（第 1026 步实测）
                    continue
                v = bg_at(prev, rc[0], rc[1], with_ropes=(rc not in old_rope))
                if v is None:
                    return None
                out[rc] = v
    return out
