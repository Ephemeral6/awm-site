"""sk48 的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测来源（第 1-8 步）：ACTION1/2 让左侧色6方块整体上/下移 6 行；ACTION4/ACTION7 让 rows(t+2,t+3)
那条 1/2 链的右端右伸 6 列；ACTION3 让它缩 6 列。格边 6。

第 49 步换关后重写过一次：原来棋盘的行列范围、格数、示意图的坐标和目标色都是写死的常数，
换关就全错。现在这些量一律从帧里认出来（棋盘 = 底条以上色4 的最大连通块；示意图 = 底条以下那个
和玩家同形的 6×6 环），常数只剩下真正跨关不变的（格边 6、底条行号、各物件的色号约定）。
代价是 cell_of / cell_topleft / map_pixels / bg_at / hud_* 都多吃一个帧参数。
"""
from __future__ import annotations

from collections import deque

from geo import cells_of, components  # noqa: F401

CELL = 6
BAR_ROW = 53               # 底部横条所在行（色2=未消耗，色3=已消耗）
PLAYER_COLOR = 6
ROPE_COLORS = (1, 2)
BG = (4, 5)
BOARD_COLOR = 4            # 棋盘底色
NOT_TARGET = (0, 1, 2, 4, 5, 6)   # 不可能是靶子的色号

DELTA = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0)}   # 方块的位移
ROPE_DELTA = {"ACTION4": CELL, "ACTION7": CELL, "ACTION3": -CELL}  # 绳尖列的位移

_BOX_CACHE = []            # [(帧的引用, box)]，按引用比对，最多留 4 条


def _ring6(g, rows):
    """在给定行范围里找一个 6×6 的色6 环，返回 (top, left)；找不到返回 None。"""
    cells = [rc for rc in cells_of(g, PLAYER_COLOR) if rows[0] <= rc[0] <= rows[1]]
    for comp in components(cells):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        if len(comp) >= 16 and max(rs) - min(rs) == 5 and max(cs) - min(cs) == 5:
            return (min(rs), min(cs))
    return None


def _comps4(g):
    """底条以上、色4 的所有连通块，返回 [(格数, top, bottom, left, right)]。"""
    W = len(g[0])
    seen = set()
    out = []
    for y in range(min(BAR_ROW, len(g))):
        row = g[y]
        for x in range(W):
            if row[x] != BOARD_COLOR or (y, x) in seen:
                continue
            q, cur = deque([(y, x)]), []
            seen.add((y, x))
            while q:
                cy, cx = q.popleft()
                cur.append((cy, cx))
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = cy + dy, cx + dx
                    if (0 <= ny < BAR_ROW and 0 <= nx < W
                            and (ny, nx) not in seen and g[ny][nx] == BOARD_COLOR):
                        seen.add((ny, nx))
                        q.append((ny, nx))
            ys = [p[0] for p in cur]
            xs = [p[1] for p in cur]
            out.append((len(cur), min(ys), max(ys), min(xs), max(xs)))
    return out


_SPRITE_CACHE = []         # [(帧的引用, sprites)]，同 _BOX_CACHE 的用法


def _sprites_cached(g):
    """sprites(g) 要扫全帧，board_box 又被每条概念反复调；不缓存的话全语料结算慢得没法用。"""
    for ref, s in _SPRITE_CACHE:
        if ref is g:
            return s
    s = sprites(g)
    _SPRITE_CACHE.append((g, s))
    del _SPRITE_CACHE[:-4]
    return s


def _inside_sprite(g, comp):
    """这个色4 连通块是不是整个躲在某个精灵的 6×6 外框里？

    由来（第 5 关）：没被选中的精灵内圈填的正是棋盘底色4，于是它自成一个色4 连通块，
    而 board_box 的「被绳子切开就并回来」那条规则会把它并进棋盘，
    棋盘上沿因此往上跑了 5 行——nrows 照样返回 7、什么都不报错，
    只是 walls() 和 cell_map 从此按两套格线读同一张盘：一个说那堵墙不存在，一个说靶在第 3 行。
    前五关碰不到这个坑，因为那时盘上只有一个玩家、它永远是选中的，内圈填色0 不是4。"""
    _, t, b, l, r = comp
    for sr, sc, _, _ in _sprites_cached(g):
        if sr - 2 <= t and b <= sr + 3 and sc - 2 <= l and r <= sc + 3:
            return True
    return False


def board_box(g):
    """假设：棋盘就是底条以上、色4 的最大连通块的外接矩形 (top, bottom, left, right)，
    再并上被绳子切开的另外那几块 —— 绳子压在棋盘上面，一根伸满的绳子会把色4 切成两块：
    横绳伸满全宽切成上下两块（列范围相同、只隔着绳子那 2 行），
    竖绳伸到底切成左右两块（行范围相同、只隔着绳子那 2 列）。切开的两块算同一个棋盘。
    实测：第 0 关得 行12..41 列17..46（5×5 格），第 1 关得 行6..47 列11..52（7×7 格）；
    语料里 8 帧出现过被横绳切成两块，合并后 bbox 与其余 43 帧一致。认不出返回 None。
    左右那一半是照着上下那一半的教训先写上的：第 2 关有一根竖绳，它现在只伸到一半、
    切不断棋盘，但它一旦伸到底，「最大连通块」会静默返回半个棋盘而什么都不报错。
    精灵内圈的色4 先剔掉，理由见 _inside_sprite。"""
    for ref, box in _BOX_CACHE:
        if ref is g:
            return box
    cs = [t for t in _comps4(g) if not _inside_sprite(g, t)]
    if not cs:
        box = None
    else:
        big = max(cs, key=lambda t: t[0])
        top, bottom, left, right = big[1], big[2], big[3], big[4]
        changed = True
        while changed:
            changed = False
            for (_, t, b, l, r) in cs:
                # 被横绳切开：列范围落在盒子里，只隔着绳子那 2 行
                cut_h = (l >= left and r <= right and t <= bottom + 5 and b >= top - 5)
                # 被竖绳切开：行范围落在盒子里，只隔着绳子那 2 列
                cut_v = (t >= top and b <= bottom and l <= right + 5 and r >= left - 5)
                if not (cut_h or cut_v):
                    continue
                nt, nb, nl, nr = min(top, t), max(bottom, b), min(left, l), max(right, r)
                if (nt, nb, nl, nr) != (top, bottom, left, right):
                    top, bottom, left, right = nt, nb, nl, nr
                    changed = True
        box = (top, bottom, left, right)
    _BOX_CACHE.append((g, box))
    del _BOX_CACHE[:-4]
    return box


def nrows(g):
    """棋盘有几行格；认不出返回 None。"""
    b = board_box(g)
    return None if b is None else (b[1] - b[0] + 1) // CELL


def ncols(g):
    """棋盘有几列格；认不出返回 None。"""
    b = board_box(g)
    return None if b is None else (b[3] - b[2] + 1) // CELL


def me(g):
    """玩家：棋盘左外侧那个 6×6 的色6环（右边两行被绳子占掉，剩 18 格）。
    返回 (top_row, left_col)；底条以下那个同形状的示意图环不算。"""
    return _ring6(g, (0, BAR_ROW - 1))


def player_cell_row(g):
    """玩家占棋盘的第几行格；定位不到返回 None。"""
    a, b, n = me(g), board_box(g), nrows(g)
    if a is None or b is None or n is None:
        return None
    r = (a[0] - b[0]) // CELL
    return r if 0 <= r < n else None


HROPE_COLORS = (1, 2, 3)   # 横绳色。原先按 ROPE_COLORS=(1,2) 找——那是「被选中的绳」的配色，见 rope_tip 的由来


def rope_tip(g):
    """绳子（双行链）最右一列。绳子沿玩家块中间两行 (top+2, top+3) 向右伸，
    经过靶块时被 4×4 靶盖住中间四列——但每个格的**最左那一列**（dc=0）不会被盖，
    所以逐格只看那一列的两行在不在绳色里；某一格的头一列断了，绳就到此为止。
    返回列号；玩家定位不到或紧邻处不是绳子则返回 None。

    由来（第 5 关）：原先按色 (1,2) 找。第 5 关盘上有了第二个玩家，横玩家没被选中时
    它那根绳的配色整体 +1（1/2 变 2/3），这个词当场认不出绳子、rope_cells 返回 None，
    建在它上面的整册概念对那一批一句话都说不出来——lens predict 四个方向键全是 0 格。
    和竖绳那次是同一个坑：把「生效态的配色」当成了物件的标识。改成不看是哪两个色、
    只要求两行都落在绳色里，并逐格判断。全语料 439 张去重帧逐帧对过：427 张一模一样，
    分歧的 12 张全部是「选中的是另一个玩家」的帧——老读法在那 12 张上是瞎的。"""
    a = me(g)
    if a is None:
        return None
    r1, r2 = a[0] + 2, a[0] + 3
    c0 = a[1] + CELL - 1               # 玩家块右边缘那一列就是绳子的第一节
    if g[r1][c0] not in HROPE_COLORS or g[r2][c0] not in HROPE_COLORS:
        return None
    tip = c0
    W = len(g[0])
    for k in range(W - c0):
        c = c0 + k
        if g[r1][c] in HROPE_COLORS and g[r2][c] in HROPE_COLORS:
            tip = c
        elif k % CELL == 0:            # 每一格的头一列断了，才算绳断了
            break
    return tip


def rope_cells(g):
    """绳子伸出去的格数（1 = 只盖住棋盘第 0 列格）。定位不到返回 None。"""
    a, t = me(g), rope_tip(g)
    if a is None or t is None:
        return None
    return (t - (a[1] + 5)) // CELL


def bar_used(g):
    """底部横条里已消耗（色3）的格数。"""
    return sum(1 for v in g[BAR_ROW] if v == 3)


def bar_left(g):
    """底部横条里还剩（色2）的格数。"""
    return sum(1 for v in g[BAR_ROW] if v == 2)


def targets(g):
    """棋盘里的靶子：色号不在 NOT_TARGET 里的 4×4 实心块。
    返回 {色号: [(top_row, left_col), …]}，只算落在棋盘范围内的。"""
    b = board_box(g)
    if b is None:
        return {}
    r0, r1, c0, c1 = b
    seen = {}
    for color in set(v for row in g[r0:r1 + 1] for v in row[c0:c1 + 1]):
        if color in NOT_TARGET:
            continue
        cells = [rc for rc in cells_of(g, color)
                 if r0 <= rc[0] <= r1 and c0 <= rc[1] <= c1]
        for comp in components(cells):
            rows = [r for r, _ in comp]
            cols = [c for _, c in comp]
            if len(comp) == 16 and max(rows) - min(rows) == 3 and max(cols) - min(cols) == 3:
                seen.setdefault(color, []).append((min(rows), min(cols)))
    return seen


def cell_of(g, top_row, left_col):
    """靶块像素左上角 -> (格行, 格列)。靶是 6×6 格里内缩 1 的 4×4，所以先减 1。"""
    b = board_box(g)
    if b is None:
        return None
    return ((top_row - 1 - b[0]) // CELL, (left_col - 1 - b[2]) // CELL)


def cell_topleft(g, cr, cc):
    """(格行, 格列) -> 该格里 4×4 靶块的像素左上角。"""
    b = board_box(g)
    if b is None:
        return None
    return (b[0] + CELL * cr + 1, b[2] + CELL * cc + 1)


def cell_map(g):
    """棋盘格 -> 靶色：{(格行, 格列): 色号}。只收落在盘内的。"""
    nr, nc = nrows(g), ncols(g)
    if nr is None:
        return {}
    out = {}
    for color, tops in targets(g).items():
        for tl in tops:
            cr, cc = cell_of(g, *tl)
            if 0 <= cr < nr and 0 <= cc < nc:
                out[(cr, cc)] = color
    return out


def target_pixels(g):
    """所有 4×4 靶块占的像素格集合。"""
    out = set()
    for tops in targets(g).values():
        for (t, l) in tops:
            for dr in range(4):
                for dc in range(4):
                    out.add((t + dr, l + dc))
    return out


def tip_cell(g):
    """绳尖所在的棋盘格 (格行, 格列)；定位不到或不在盘内返回 None。"""
    a, t, b = me(g), rope_tip(g), board_box(g)
    if a is None or t is None or b is None:
        return None
    cr = (a[0] - b[0]) // CELL
    cc = (t - b[2]) // CELL
    if 0 <= cr < nrows(g) and 0 <= cc < ncols(g):
        return (cr, cc)
    return None


def walls(g):
    """假设：整格 6×6 像素同一个颜色、且那个颜色不是棋盘底色 4 的格，是一堵墙。
    返回 {(格行, 格列): 色号}；棋盘认不出返回 None。
    由来：第 4 关玩家那一行的第 3 格是 5×36。cell_map 只认 4×4 实心靶块、
    NOT_TARGET 又滤掉色5，所以它在此前所有读数里都显示成空格；
    绳尖伸不进它，靶也推不进它。全语料扫下来只有这一堵。"""
    b = board_box(g)
    nr, nc = nrows(g), ncols(g)
    if b is None or nr is None or nc is None:
        return None
    r0, _, c0, _ = b
    out = {}
    for r in range(nr):
        for c in range(nc):
            top, left = r0 + r * CELL, c0 + c * CELL
            v = g[top][left]
            if v == 4:
                continue
            if all(g[top + dr][left + dc] == v
                   for dr in range(CELL) for dc in range(CELL)):
                out[(r, c)] = v
    return out


def chain(g, d):
    """绳尖格沿方向 d（-1 上 / +1 下）相邻起，连续靶子的色列表，以及链后第一个空格的格行号
    （可能越界）。绳尖定位不到返回 (None, None)。"""
    t = tip_cell(g)
    if t is None:
        return (None, None)
    nr = nrows(g)
    cr, cc = t
    m = cell_map(g)
    out, r = [], cr + d
    while 0 <= r < nr and (r, cc) in m:
        out.append(m[(r, cc)])
        r += d
    return out, r


def move_ok(g, d):
    """假设：玩家沿方向 d 能不能动 —— 自己不出盘、**目标格行落在左边竖轨那条花纹带里**、
    杆扫过去要盖住的那一行里**杆下**（格列 0..n-1）没有墙、
    且被绳子扫到的每一串靶都推得动（串里没有一块会被顶出棋盘）。定位不到返回 None。
    由来：第 4 关杆伸满 n=7 在空行里往墙那一行扫，动作被直接拒、整帧一格没变。
    目标行杆下有靶的转移语料里有 30 条，玩家全都照走（靶被杆顶走），所以挡住的不是靶是墙。
    「杆下」这个限定此刻还没检验过——另一种读法是「目标行里只要有墙就过不去」，
    两者要等杆缩到盖不住那堵墙时再往那一行扫一次才分得开。
    **带子那一句是后加的**：新场景里轨上的花纹带只铺三个格行，玩家走到带外那一行时动作被整个拒掉、
    整帧零格，一步之内打死三条概念。此前每个场景的带子都铺满整条轨，所以「不出盘」和「不出带」
    在语料里一直同分布，分不开——分得开它们的局面直到那一步才第一次出现。"""
    r = player_cell_row(g)
    if r is None:
        return None
    nr, nc, n, w = nrows(g), ncols(g), rope_cells(g), walls(g)
    if nr is None or nc is None or n is None or w is None:
        return None
    if not (0 <= r + d < nr):
        return False
    sp = vrail_span(g)
    if sp is None:
        return None
    if not (sp[0] <= r + d <= sp[1]):
        return False
    if any((r + d, c) in w for c in range(min(n, nc))):
        return False
    mv = vmoved_cells(g, d)
    if mv is None:
        return None
    return all(0 <= rr + d < nr for (rr, _) in mv)


def vmoved_cells(g, d):
    """假设：玩家沿 d 竖移一格时，跟着动的那些格。绳子是玩家那一行上从第 0 列到绳尖列的一根横杆，
    它从第 r 行扫到第 r+d 行；杆下每一列 c 单独结算：(r,c) 上有靶，就从它起沿 d 那一串连续靶跟着走；
    (r,c) 空而 (r+d,c) 上有靶，就是杆扫过去把它顶走，从 (r+d,c) 起那一串跟着走；都空则这一列不动。
    返回格坐标列表（顺序无关）；定位不到返回 None。"""
    r = player_cell_row(g)
    n = rope_cells(g)
    nr, nc = nrows(g), ncols(g)
    if r is None or n is None or nr is None:
        return None
    m = cell_map(g)
    out = []
    for c in range(min(n, nc)):
        if (r, c) in m:
            start = r
        elif 0 <= r + d < nr and (r + d, c) in m:
            start = r + d
        else:
            continue
        rr = start
        while 0 <= rr < nr and (rr, c) in m:
            out.append((rr, c))
            rr += d
    return out


def vmove_map(g, d):
    """假设：玩家沿 d 竖移一格之后，棋盘上的 {格: 色}。定位不到返回 None。"""
    mv = vmoved_cells(g, d)
    if mv is None:
        return None
    m = cell_map(g)
    out = {k: v for k, v in m.items() if k not in mv}
    for (r, c) in mv:
        out[(r + d, c)] = m[(r, c)]
    return out


def map_pixels(g, m):
    """{格: 色} -> {像素: 色}（每格 4×4）。几何取自帧 g。"""
    out = {}
    for (r, c), color in m.items():
        tl = cell_topleft(g, r, c)
        if tl is None:
            continue
        top, left = tl
        for dr in range(4):
            for dc in range(4):
                out[(top + dr, left + dc)] = color
    return out


def hmoved_cells(g, k):
    """假设：绳子伸（k=+1）/缩（k=-1）一节时，被绳子带着走的靶格（还没算走不走得成）。
    绳子是一根杆，盖住玩家那一行的格列 0..n-1；**杆上的每一块都被带着走**，不要求彼此相连
    （靶像串在杆上的珠子，杆挪一节，珠子跟着挪一节）。
    伸出去时新绳尖落到格列 n，从那儿起往右**连续**的一串被顶着一起走。
    定位不到返回 None。"""
    r = player_cell_row(g)
    n = rope_cells(g)
    nc = ncols(g)
    if r is None or n is None or nc is None:
        return None
    m = cell_map(g)
    out = [(r, c) for c in range(min(n, nc)) if (r, c) in m]
    if k > 0:
        c = n
        while 0 <= c < nc and (r, c) in m:
            out.append((r, c))
            c += 1
    return out


def extend_ok(g):
    """假设：绳子还伸不伸得出去——新绳尖要落进的那一格（玩家那一行的格列 n）不是墙。
    定位不到返回 None；绳子已经占满整行时也返回 None（语料里从没试过，不表态）。"""
    r = player_cell_row(g)
    n = rope_cells(g)
    nc = ncols(g)
    w = walls(g)
    if r is None or n is None or nc is None or w is None:
        return None
    if n >= nc:
        return None
    return (r, n) not in w


def hmoved_now(g, k):
    """假设：被带着走的那些格里，**真的**走成的那些。
    伸绳时先问伸不伸得出去（绳尖要落进的那一格是墙就一节都伸不出，珠子也一块都不动）；
    伸得出去分两拨结算：
      · **绳尖外那一串是刚性的**：连成一串的珠子被绳尖顶着一起走，串里只要有一块走不成
        （自己被竖绳钉住、串尾的落点出盘 / 是竖绳钉住的格 / 是墙），整串一块都不动——
        推力靠接触一节一节传过去，前面那块不动，后面那块就没人推。
      · **杆上（格列 < n）的逐块结算**：它们是串在杆上被带着走的，不靠彼此推；
        沿运动方向从排头往后依次算，五种走不成：自己站在竖绳串住的格上（横向出不去）、
        落点出盘、落点是竖绳串住的格（横向进不来）、落点是墙、落点上压着一块没走成的。
    定位不到返回 None。

    由来：终局卡第 1227 步（tid 4bee75c397a1b2d7）。绳 3 节，绳尖外 (2,3)(2,4)(2,5) 连着三颗，
    中间那颗被一根没主的竖绳钉住。这里原先整串也逐块结算，于是最外那颗自己滑走一格、
    里面两颗留在原地，凭空撕出一个洞；世界里**一颗都没动**，绳照样伸到 4 节。"""
    if k > 0:
        ok = extend_ok(g)
        if ok is None:
            return None
        if not ok:
            return []
    cells = hmoved_cells(g, k)
    r0 = player_cell_row(g)
    n = rope_cells(g)
    if cells is None or r0 is None or n is None:
        return None
    m = cell_map(g)
    nc = ncols(g)
    pin = pinned_cells(g)
    w = walls(g)
    if pin is None or w is None or nc is None:
        return None
    moving = set()
    run = sorted(c for (_r, c) in cells if c >= n) if k > 0 else []
    if run:
        t = run[-1] + 1
        if (not any((r0, c) in pin for c in run)
                and 0 <= t < nc and (r0, t) not in pin and (r0, t) not in w):
            moving |= {(r0, c) for c in run}
    for (r, c) in sorted([x for x in cells if x[1] < n],
                         key=lambda rc: rc[1], reverse=(k > 0)):
        t = c + k
        if (r, c) in pin or not (0 <= t < nc) or (r, t) in pin or (r, t) in w:
            continue
        if (r, t) in m and (r, t) not in moving:
            continue
        moving.add((r, c))
    return sorted(moving)


def hmove_map(g, k):
    """假设：绳子伸（k=+1）/缩（k=-1）一节之后，棋盘上的 {格: 色}。
    该走的那些格（见 hmoved_now）各移一格，其余原地不动。定位不到返回 None。"""
    mv = hmoved_now(g, k)
    if mv is None:
        return None
    m = cell_map(g)
    out = {kk: v for kk, v in m.items() if kk not in mv}
    for (r, c) in mv:
        out[(r, c + k)] = m[(r, c)]
    return out


# ---- 竖绳（第 2 关起）------------------------------------------------------
# 和玩家那根横绳同构、转了 90 度：压在某一格列正中两列上，从棋盘上边缘往下伸，
# 把经过的靶串起来。色号整体 +1（横绳 1/2，竖绳 2/3），排布规律同 rope_color。
# 头是棋盘上方一个 2×2 的小块（第 2 关是色11，第 3 关两根分别是色10 和色11）。
# 被它串着的靶，横绳拖不动。**不止一根**：第 3 关起盘上同时有两根。

VROPE_COLORS = (1, 2, 3)   # 绳色。原先写 (2, 3)——那是「闲着的绳」的配色，见 vropes 的由来


def vropes(g):
    """假设：盘内所有竖绳，[(格列, 往下伸的格数)]，按格列从左到右。
    一根竖绳压在一格列正中相邻的两像素列上，从格行 0 起往下连续；判一格在不在绳上，
    只看那格的**第一像素行**（dr=0）两列是不是都是绳色 —— 因为串在绳上的靶会把中间四行盖掉
    （实测第 2 关那根绳四格全被靶盖住，每格只剩头尾两行绳色），而横绳压的是某格行正中的
    dr=2,3 两行，永远碰不到 dr=0，于是横绳横穿过去也不会被算进来。
    认不出棋盘返回空表。

    由来：v1 靠「盘内的色3 只可能是竖绳」。这句话前五关成立，是因为盘上只有一个玩家、
    它永远是选中的，选中的绳用色1/2，盘内不出现色3。第 5 关有了第二个玩家，闲着的那根**横**绳
    变成色2/3，盘内立刻多出色3，v1 当场报出一根根本不存在的竖绳（格列 0、3 节），
    不报错、不掉分，只是从此读的是另一件事。新读法不看颜色只看几何，
    在全语料 279 张去重帧上与 v1 逐帧对过：277 张一模一样，剩下 2 张正是 v1 那两张幻觉。"""
    b = board_box(g)
    if b is None:
        return []
    top, bottom, left, right = b
    out = []
    for cc in range((right - left + 1) // CELL):
        c0 = left + CELL * cc + 2
        n = 0
        for cr in range((bottom - top + 1) // CELL):
            r = top + cr * CELL
            if g[r][c0] in VROPE_COLORS and g[r][c0 + 1] in VROPE_COLORS:
                n = cr + 1
            else:
                break
        if n:
            out.append((cc, n))
    return out


def vrope_owner(g, cell_col):
    """假设：这根竖绳属于谁 —— 棋盘上方压在它那两像素列上的那个玩家精灵的芯色。
    头不是精灵（第 2、3 关那种光秃秃的 2×2 小块）返回 None。
    这一条是「会动的绳」和「死绳」的分界线：前者跟着它的主人走，后者一步不动。"""
    b = board_box(g)
    if b is None:
        return None
    top, _, left, _ = b
    c0 = left + CELL * cell_col + 2
    for r, c, core, _ in _sprites_cached(g):
        if r < top and c <= c0 <= c + 1:
            return core
    return None


def vrope_head(g, cell_col):
    """假设：某根竖绳的头 —— 棋盘正上方、压在它那一格列正中两列上的 2×2 小块的色号。
    认不出返回 None。"""
    b = board_box(g)
    if b is None:
        return None
    top, _, left, _ = b
    c0 = left + CELL * cell_col + 2
    for r in range(top - 1, -1, -1):
        v = g[r][c0]
        if v == g[r][c0 + 1] and v not in (5,) and v not in VROPE_COLORS:
            return v
    return None


def vrope_col(g):
    """盘内**只有一根**竖绳时它占的格列；没有、或不止一根，返回 None。
    不止一根时返回 None 而不是返回第一根：给个偏的读数比给不出读数更坏，
    它不报错、断言照判 TRUE，只有预测的格数会悄悄少一截。"""
    v = vropes(g)
    return v[0][0] if len(v) == 1 else None


def vrope_tip(g):
    """盘内只有一根竖绳时，它最下面那一像素行。两列都是竖绳色才算，所以横绳横穿过去也认不错
    （横绳相邻两列不可能同时落在 {2,3} 里）。认不出返回 None。"""
    b = board_box(g)
    vc = vrope_col(g)
    if b is None or vc is None:
        return None
    top, bottom, left, _ = b
    c0 = left + CELL * vc + 2
    tip = None
    for r in range(max(0, top - 1), bottom + 1):
        if g[r][c0] in VROPE_COLORS and g[r][c0 + 1] in VROPE_COLORS:
            tip = r
    return tip


def vrope_cells(g):
    """盘内只有一根竖绳时它往下伸了几格（1 = 只盖住第 0 行格）；没有或不止一根返回 None。"""
    v = vropes(g)
    return v[0][1] if len(v) == 1 else None


def pinned_cells(g):
    """假设：被竖绳串住的格 —— 每根竖绳那一列上、从第 0 行到它绳尖那一格。
    没有竖绳就是空集；有几根就并几根。"""
    return {(r, vc) for vc, n in vropes(g) for r in range(n)}


def rope_map(g, n):
    """假设：玩家不动、绳子 n 节时，绳子占的 {像素: 色}。定位不到返回 None。"""
    a = me(g)
    if a is None or n is None or n < 0:
        return None
    out = {}
    for k in range(CELL * n + 1):
        c = a[1] + CELL - 1 + k
        out[(a[0] + 2, c)] = rope_color(k, False)
        out[(a[0] + 3, c)] = rope_color(k, True)
    return out


def rail_cols(g):
    """假设：玩家的竖轨占棋盘左外侧的哪两列。认不出返回 None。"""
    b = board_box(g)
    return None if b is None else (b[2] - 4, b[2] - 3)


def bg_at(g, r, c, with_ropes=True):
    """假设：这一格「空着」时是什么色 —— 棋盘内 4，玩家竖轨上每 6 行头两行 2、后四行 3
    （**只在 vrail_span 给出的那一段里**，段外是 5），
    上边横轨上每 6 列头两列 2、后四列 3（**只在 hrail_span 给出的那一段里**，段外是 5），其余 5；
    竖绳压着的那两列按竖绳的色（横绳的色号整体 +1，左右两列的角色对调）。
    竖轨相位从棋盘上边缘下数第 2 行起算，正好和每一格行的绳子两行对齐；
    横轨相位同理，从棋盘左边缘右数第 2 列起算。
    实测自第 0 关开局帧与前 8 步的空出格；第 1 关的竖轨（行8..41）逐格核过同一条公式；
    竖绳那一段核过第 2 关开局帧行5..29 列31..32 的全部可见像素。
    横轨那一支是第 5 关补的：竖玩家横挪一格列时，它腾出来的 6×6 里正中两行不退回 5 而是这个花纹，
    在全语料 5 步横挪上逐格核过（每步 12 格，补上之后 0 格说错）。
    **两条轨上的带子都是每关不同宽的**（见 hrail_span / vrail_span）：写死成全宽在头两个有它的场景上一格不差，
    换了场景之后两条带子各只剩三个格，玩家从带子端上挪开时那 4 格各说错一次——横轨那一支先挨的打，
    竖轨这一支是照着对称搬过来的（同一场景里横玩家上下走各说错 4 格，补完归零）。

    `with_ropes=False` 把「竖绳压着」那一支关掉，问的是「连绳也不在时」是什么色。
    横挪那一步要的正是这个：腾出来的那一格，绳是跟着主人一起走掉的。"""
    b = board_box(g)
    if b is None:
        return 5
    top, bottom, left, right = b
    if with_ropes:
        for vc, vn in vropes(g):
            c0 = left + CELL * vc + 2
            if c in (c0, c0 + 1) and top - 1 <= r <= top - 1 + CELL * vn:
                return rope_color(r - (top - 1), c == c0) + 1
    if top <= r <= bottom and left <= c <= right:
        return 4
    if c in (left - 4, left - 3):
        sp = vrail_span(g)
        if sp is None:
            return 5
        a, b2 = sp
        if top + CELL * a + 2 <= r <= top + CELL * b2 + 3:
            return 2 if (r - (top + 2)) % 6 < 2 else 3
        return 5
    if r in (top - 4, top - 3):
        sp = hrail_span(g)
        if sp is None:
            return 5
        a, b2 = sp
        if left + CELL * a + 2 <= c <= left + CELL * b2 + 3:
            return 2 if (c - (left + 2)) % 6 < 2 else 3
    return 5


def hrail_span(g):
    """假设：上边横轨那条 2/3 花纹带覆盖的格列区间 (a, b)（闭区间），每关静态。
    带子从格列 a 的正中两列左端（left+6a+2）铺到格列 b 的正中两列右端（left+6b+3）：
    每个格列正中两列是色 2，其余是色 3。
    读法：扫第 top-4 行上所有色 2/3 的像素定出可见区间，再和竖玩家自己的格列取并——
    玩家那个 6 列宽的精灵会把带子的一端整段盖住，不并进来就会少读一个格列。
    第 top-4 行上一个 2/3 都没有（没有竖玩家的那几关就是这样）返回 None：那时这条带子不存在。
    由来：原先写死成「铺满整个盘宽」，那是它在**头两个有竖玩家的场景**里的样子；
    换了场景之后带子只铺三个格列，而带子外面是纯底色 5——
    竖玩家从带子右端挪开时，腾出来的那 4 格照旧被写成花纹色，逐格量出来才现形。
    **它同时是竖玩家能滑到的格列范围**，见 slide_ok。"""
    b = board_box(g)
    if b is None:
        return None
    top, _bottom, left, right = b
    if top - 4 < 0:
        return None
    row = g[top - 4]
    cols = [c for c in range(len(row)) if row[c] in (2, 3) and left + 2 <= c <= right - 2]
    ks = {(c - left - 2) // CELL for c in cols}
    for q in (players(g) or []):
        if q[1] == 'v':
            ks.add(q[2])
    if not ks:
        return None
    return min(ks), max(ks)


def vrail_span(g):
    """假设：左边竖轨那条 2/3 花纹带覆盖的格行区间 (a, b)（闭区间），每关静态。
    hrail_span 转 90 度：带子从格行 a 的正中两行上端（top+6a+2）铺到格行 b 的正中两行下端（top+6b+3）。
    读法同样要和横玩家自己的格行取并（6 行高的精灵会盖住带子的一端），
    并且**只认落在 top+2..bottom-2 之间的像素**——盘下边还有一条整幅的色 2 分隔线，不挡掉会把带子读到盘外去。
    **它同时是横玩家能走到的格行范围**，见 move_ok。"""
    b = board_box(g)
    if b is None:
        return None
    top, bottom, left, _right = b
    if left - 4 < 0:
        return None
    rows = [r for r in range(len(g)) if g[r][left - 4] in (2, 3) and top + 2 <= r <= bottom - 2]
    ks = {(r - top - 2) // CELL for r in rows}
    r0 = player_cell_row(g)
    if r0 is not None:
        ks.add(r0)
    if not ks:
        return None
    return min(ks), max(ks)


def rope_color(k, lower, sel=True):
    """横绳第 k 像素节（k=0 是紧挨方块的那一列）的颜色。lower=False 是上面那行，True 是下面那行。
    实测：上行 1,2,1 循环，下行 2,1,1 循环；**主人没被选中时同一花纹整体 +1**（2,3,2 / 3,2,2）。
    sel 那一半是第 5 关才量到的：全语料每一张去重帧上、每一节的头一列两行逐个核过，
    选中 3100 个像素全对，没选中 64 个像素全对。"""
    m = k % 3
    base = (2 if m == 1 else 1) if not lower else (2 if m == 0 else 1)
    return base if sel else base + 1


def vrope_color(k, right, sel=True):
    """竖绳第 k 像素节（k=0 是紧贴棋盘上边缘那一行）的颜色。right=False 是左列，True 是右列。
    实测：左列 1,1,2 循环，右列 2,1,1 循环；没被选中时整体 +1。
    这是横绳那块花纹转了 90 度：右列和横绳的下行同相，左列比横绳的上行错开一节。
    同一次核账里选中 52 个像素全对、没选中 10 个像素全对。"""
    m = k % 3
    base = (2 if m == 0 else 1) if right else (2 if m == 2 else 1)
    return base if sel else base + 1


def vrope_map(g, cell_col, n, sel=True):
    """假设：一根竖绳（在格列 cell_col、往下伸 n 节、主人选中与否 sel）占的 {像素: 色}。
    只给绳自己的两像素列；靶盖在上面的那几行由调用者自己剔。棋盘认不出返回 None。"""
    b = board_box(g)
    if b is None or n is None or n < 0:
        return None
    top, _, left, _ = b
    c0 = left + CELL * cell_col + 2
    return {(top + k, c0 + j): vrope_color(k, j == 1, sel)
            for k in range(CELL * n) for j in (0, 1)}


def player_block(g):
    """玩家 6×6 方块（含被绳子占掉的右边缘两格）的 {(row, col): 色}。定位不到返回 None。"""
    a = me(g)
    if a is None:
        return None
    return {(a[0] + dr, a[1] + dc): g[a[0] + dr][a[1] + dc]
            for dr in range(CELL) for dc in range(CELL)}


def sprite_cells(top, left, n):
    """假设：方块左上角在 (top,left)、绳子伸出 n 节时，它占的 {(row,col): 色}。
    方块是 6×6 的色6环 + 色0内圈 + 正中 2×2 色6；绳子从 left+5 起向右 6n+1 列，压在中间两行。"""
    out = {}
    for dr in range(CELL):
        for dc in range(CELL):
            if dr in (0, CELL - 1) or dc in (0, CELL - 1):
                v = 6
            elif 2 <= dr <= 3 and 2 <= dc <= 3:
                v = 6
            else:
                v = 0
            out[(top + dr, left + dc)] = v
    for k in range(CELL * n + 1):
        c = left + CELL - 1 + k
        out[(top + 2, c)] = rope_color(k, False)
        out[(top + 3, c)] = rope_color(k, True)
    return out


# ---- 屏幕下方的示意图 ----------------------------------------------------
# 若干个 6×6 的图标，每个图标右边串着几个 4×4 块，块之间画着绳子的像素。
# 图标说这一组是谁的绳子：正中 2×2 是色6 就是玩家（他那根横绳），
# 是别的色就去棋盘上方找同色的 2×2 小块——那是某根竖绳的头。
# 块相对图标的排布和棋盘上格相对绳主的排布同构：第 i 个块的左上角 = 图标左 + 7 + 6i。
# 所以「示意图 = 每根绳子该串成什么样」，组数、块数、色号全从帧里读，不写死。
#
# 定位不再靠「找色6 环」：第 3 关的图标是色5 边框（竖绳头画在背景上），色6 只剩玩家自己。
# 改用长度定位——示意图那一带的**头一行**上，长 6 的段只可能是图标，靶槽是 4×4 画出来长 4。

def _runs(row):
    """一行像素里的连续同色段：[(起列, 长度, 色号)]。"""
    out, x, W = [], 0, len(row)
    while x < W:
        v, s = row[x], x
        while x < W and row[x] == v:
            x += 1
        out.append((s, x - s, v))
    return out


def hud_bg(g):
    """底条以下那一片的底色。"""
    return g[BAR_ROW + 1][0]


def hud_top(g):
    """示意图那一带最上面那一像素行 —— 底条以下、头一个出现长 6 非底色段的行。
    认不出返回 None。"""
    bg = hud_bg(g)
    for r in range(BAR_ROW + 1, len(g)):
        if any(ln == CELL and v != bg for _, ln, v in _runs(g[r])):
            return r
    return None


def hud_icons(g):
    """假设：示意图里的图标 —— [(最左列, 芯色)]，按列从左到右。
    图标是 6×6 的框，正中 2×2 就是它指谁。认不出返回 None。"""
    top = hud_top(g)
    if top is None:
        return None
    bg = hud_bg(g)
    return [(x, g[top + 2][x + 2]) for x, ln, v in _runs(g[top])
            if ln == CELL and v != bg]


def hud_ring(g):
    """示意图里色6 那个图标（玩家的那一组）的 (top, left)；没有返回 None。"""
    top = hud_top(g)
    icons = hud_icons(g)
    if top is None or not icons:
        return None
    for x, core in icons:
        if core == 6:
            return (top, x)
    return None


def hud_slots(g):
    """假设：示意图里从左到右的靶槽 —— [(块最左列, 色号)]。
    在图标那一行的下一行上扫，取长 4、色号不在 NOT_TARGET 里的实心段；
    落在某个图标那 6 列之内的段不算 —— 图标的内圈画出来也是长 4 的一段。认不出返回 None。"""
    top = hud_top(g)
    icons = hud_icons(g)
    if top is None or icons is None:
        return None
    spans = [(x, x + CELL - 1) for x, _ in icons]
    return [(x, v) for x, ln, v in _runs(g[top + 1])
            if ln == 4 and v not in NOT_TARGET
            and not any(a <= x <= b for a, b in spans)]


def hud_groups(g):
    """假设：示意图按图标分组 —— [(芯色, (靶色, …)), …]。
    一个图标开一组，它右边、下一个图标之前的靶槽都归它：「这根绳子要串的靶，按这个顺序」。
    第 2 关只有一组（芯色 6 = 玩家的横绳），第 3 关有两组（两根竖绳的头色）。
    认不出、或有靶槽排在头一个图标左边（说明读法不对），返回 None。"""
    top = hud_top(g)
    icons = hud_icons(g)
    slots = hud_slots(g)
    if top is None or not icons or slots is None:
        return None
    icons = sorted(icons)
    xs = [x for x, _ in icons]
    buckets = [[] for _ in icons]
    for x, v in sorted(slots):
        i = -1
        for j, ix in enumerate(xs):
            if ix < x:
                i = j
        if i < 0:
            return None
        buckets[i].append(v)
    return [(core, tuple(vs)) for (_, core), vs in zip(icons, buckets)]


def goal_order(g):
    """假设：示意图从左到右的色号序列 = 目标顺序（不分组，一整串读）。认不出返回 None。"""
    s = hud_slots(g)
    return None if s is None else tuple(v for _, v in s)


def hud_pixels(g):
    """示意图整块占的 {(row, col)}（用来把它从「底板逐格不变」里放行）。认不出返回空集。"""
    top = hud_top(g)
    icons = hud_icons(g)
    slots = hud_slots(g)
    if top is None:
        return set()
    lefts = [x for x, _ in (icons or [])] + [x for x, _ in (slots or [])]
    rights = ([x + CELL - 1 for x, _ in (icons or [])]
              + [x + 3 for x, _ in (slots or [])])
    if not lefts:
        return set()
    left, right = min(lefts), max(rights)
    return {(r, c) for r in range(top, top + CELL) for c in range(left - 1, right + 2)}


def hud_hollow(g):
    """假设：示意图里各个靶槽是不是被挖空了（中心 2×2 由块色变成色 0）。
    返回和 goal_order 等长的布尔列表；认不出返回 None。"""
    top = hud_top(g)
    slots = hud_slots(g)
    if top is None or slots is None:
        return None
    out = []
    for x, _ in slots:
        core = [g[y][xx] for y in (top + 2, top + 3) for xx in (x + 1, x + 2)]
        out.append(all(v == 0 for v in core))
    return out


def threaded(g):
    """假设：玩家那一行上、绳子盖得到的那一段（格列 0..n-1）里的靶，按列从左到右。
    定位不到返回 None。"""
    r = player_cell_row(g)
    n = rope_cells(g)
    nc = ncols(g)
    if r is None or n is None or nc is None:
        return None
    m = cell_map(g)
    return [m[(r, c)] for c in range(min(n, nc)) if (r, c) in m]


def rope_of_icon(g, icon):
    """假设：示意图某一组的图标芯色，指的是盘上哪根绳子。
    **先问玩家**：芯色等于这个色的那个玩家，它那根绳就是这一栏的绳
    —— 横玩家返回 ('h', 它的格行)，竖玩家返回 ('v', 它的格列)。
    没有这个芯色的玩家，再去认光秃秃的竖绳头（第 2~4 关那种没有主人的绳）。认不出返回 None。

    由来：原先写的是「色6 = 玩家那根横绳，别的色去比 vrope_head」。前一半是把
    「这一局的玩家是色6」这个答案写死在词里，第 5 关起盘上有第二个玩家（色15）就不够用了；
    后一半更糟——vrope_head 从棋盘上边往上找第一行「两列同色、不是轨底色也不是绳色」的像素，
    绳头是玩家精灵时它先撞上的是精灵的**环**（选中态环色 0），于是把 15 号玩家那根绳的头读成 0，
    rope_of_icon 遍历一圈没有匹配，返回 None。后果不是报错是**沉默**：
    rope_geom → None → rope_seq → None → 通关判据 threaded_all 返回 None → 判 NA。
    这条通道恰好在整张卡通关的那一步（选中竖玩家按 ACTION3）上全线闭嘴。"""
    for core, kind, a, _b, _s in (players(g) or []):
        if core == icon:
            return (kind, a)
    if icon == 6:                              # players() 认不出玩家时的退路（第 0、1 关的老读法）
        r = player_cell_row(g)
        if r is not None:
            return ('h', r)
    for vc, _ in vropes(g):
        if vrope_head(g, vc) == icon:
            return ('v', vc)
    return None


def action_delta(action):
    """假设：一个动作对「玩家格行、绳节数」的改变量 (d, k)。别的动作返回 (0, 0)。"""
    if action.startswith("ACTION1"):
        return (-1, 0)
    if action.startswith("ACTION2"):
        return (1, 0)
    if action.startswith("ACTION3"):
        return (0, -1)
    if action.startswith("ACTION4") or action.startswith("ACTION7"):
        return (0, 1)
    return (0, 0)


def rope_geom(g, icon, action=None):
    """假设：图标芯色指的那根绳子的几何 —— ('h', 格行, 绳节数) 或 ('v', 格列, 伸下的格数)。
    给了 action 就算**这一步走完之后**的几何。方向键只作用在**被选中**的那个玩家身上，
    所以先看谁被选中：没被选中的那根绳这一步动不着（第 2~4 关的竖绳没有主人，恒属此列，
    见 vrope_static）；被选中的那根，横绳跟着玩家走、跟着伸缩变长短，竖绳上下是伸缩、
    左右是整根挪列。伸不出去 / 缩不动 / 挪出盘（那几种局面还没量过）返回 None。
    认不出返回 None。"""
    who = rope_of_icon(g, icon)
    if who is None:
        return None
    kind, k = who
    sel = sel_player(g) if action else None
    if action and sel is None:
        return None
    if kind == 'h':
        n = rope_cells(g)
        if n is None:
            return None
        if action is None or sel[1] != 'h':
            return ('h', k, n)
        d, dk = action_delta(action)
        return ('h', k + d, n + dk)
    for vc, vn in vropes(g):
        if vc != k:
            continue
        if action is None or sel[1] != 'v' or sel[2] != vc:
            return ('v', vc, vn)
        nr, nc, w = nrows(g), ncols(g), walls(g)
        if nr is None or nc is None or w is None:
            return None
        if action.startswith("ACTION1"):
            return ('v', vc, vn - 1) if vn > 0 else None
        if action.startswith("ACTION2"):
            return None if (vn >= nr or (vn, vc) in w) else ('v', vc, vn + 1)
        if action.startswith("ACTION3") or action.startswith("ACTION4"):
            t = vc + (-1 if action.startswith("ACTION3") else 1)
            return ('v', t, vn) if 0 <= t < nc else None
        return ('v', vc, vn)
    return None


def rope_seq(g, icon, m=None, action=None):
    """假设：一根绳子串着的靶色，按「从绳主往外」的顺序读。
    横绳挂在玩家右边，所以是玩家那一行、格列 0..n-1，从左往右；
    竖绳挂在棋盘上边，所以是它那一格列、格行 0..伸下的格数-1，从上往下。
    空格跳过（只看顺序，不看落在哪一格）。
    m 给了就用它当靶的分布，action 给了就用走完之后的几何——
    两个一起给，问的就是「照这一步算出来的落点，这根绳子会串成什么」。定位不到返回 None。"""
    geom = rope_geom(g, icon, action)
    if geom is None:
        return None
    if m is None:
        m = cell_map(g)
    nr, nc = nrows(g), ncols(g)
    if nr is None or nc is None:
        return None
    kind, a, b = geom
    if kind == 'h':
        if not (0 <= a < nr) or b < 0:
            return None
        return [m[(a, c)] for c in range(min(b, nc)) if (a, c) in m]
    return [m[(r, a)] for r in range(min(b, nr)) if (r, a) in m]


def threaded_on(g, icon):
    """假设：图标芯色指的那根绳子**此刻**串着哪些靶（rope_seq 的当下版本）。定位不到返回 None。"""
    return rope_seq(g, icon)


# ---- 玩家与选中（第 5 关起盘上不止一个玩家）--------------------------------

SEL_FILL = 0               # 选中的精灵，内圈填这个色
IDLE_FILL = 4              # 没选中的，内圈填这个色


def sprites(g):
    """假设：一个「玩家形状」= 2×2 的芯 + 围它一圈的填充环，环色只取 SEL_FILL / IDLE_FILL。
    芯色不限（色6 是左边那个，色15 是上边那个），所以新玩家出现时这个词自己认得出来。
    返回 [(行, 列, 芯色, 环色), …]，按位置排序；行列指 2×2 芯的左上角。

    注意它**同时认出示意图里的小图标**——图标和精灵同形，而且带同一个环色。
    这是好事：选中态在一帧里被写了两遍，可以互相核对；要只看棋盘上的就按行号筛。
    """
    H, W = len(g), len(g[0])
    out = []
    for r in range(1, H - 2):
        for c in range(1, W - 2):
            core = g[r][c]
            if core in (SEL_FILL, IDLE_FILL, 5):
                continue
            if not (g[r][c + 1] == g[r + 1][c] == g[r + 1][c + 1] == core):
                continue
            ring = [(r - 1, cc) for cc in range(c - 1, c + 3)]
            ring += [(r + 2, cc) for cc in range(c - 1, c + 3)]
            ring += [(rr, c - 1) for rr in (r, r + 1)]
            ring += [(rr, c + 2) for rr in (r, r + 1)]
            vals = {g[rr][cc] for rr, cc in ring if 0 <= rr < H and 0 <= cc < W}
            if len(vals) == 1 and vals.pop() in (SEL_FILL, IDLE_FILL):
                out.append((r, c, core, g[r - 1][c - 1]))
    return sorted(out)


def selected_core(g):
    """假设：环色 = SEL_FILL 的那个芯色就是此刻被选中的玩家。
    认出不止一个不同的芯色、或一个都没有，返回 None（读不出来不许猜）。"""
    cores = {core for _, _, core, fill in sprites(g) if fill == SEL_FILL}
    return cores.pop() if len(cores) == 1 else None


def sprite_at(g, x, y):
    """假设：像素 (列=x, 行=y) 落在哪个玩家/图标的 6×6 外框里——返回它的芯色，没落在任何一个上返回 None。
    外框 = 2×2 芯往外各扩 2 格（芯 + 环 + 边），也就是 sprites() 认出的那个形状的整块。"""
    for r, c, core, _ in sprites(g):
        if r - 2 <= y <= r + 3 and c - 2 <= x <= c + 3:
            return core
    return None


def _hrope_cells_at(g, top, left):
    """假设：挂在竖轨上、外框左上角在 (top,left) 的那个玩家，绳往右伸了几节。
    读法与 rope_tip 同（逐格只看头一列的两行）；认不出返回 None。"""
    r1, r2 = top + 2, top + 3
    c0 = left + CELL - 1
    if not (0 <= r1 < len(g) and 0 <= c0 < len(g[0])):
        return None
    if g[r1][c0] not in HROPE_COLORS or g[r2][c0] not in HROPE_COLORS:
        return None
    tip = c0
    W = len(g[0])
    for k in range(W - c0):
        c = c0 + k
        if g[r1][c] in HROPE_COLORS and g[r2][c] in HROPE_COLORS:
            tip = c
        elif k % CELL == 0:
            break
    return (tip - (left + CELL - 1)) // CELL


def _vrope_cells_at(g, top, left):
    """假设：挂在横轨上、外框左上角在 (top,left) 的那个竖玩家，绳往下伸了几节。
    读法是 _hrope_cells_at 转 90 度：从它自己框的底边那一像素行起（绳的根就画在框里），
    盯住它那一格列正中的两像素列往下扫，只在整格边界上判断断没断——
    格内那四行会被串在绳上的靶盖掉。认不出返回 None。

    由来：`vropes` 按盘内的绳色像素找绳，绳长 0 时盘内一个绳色像素都没有，
    于是 `players` 对这个玩家整体返回 None，**全册当场对这一帧失语**（第 909、910 步就是这样：
    28 条概念全 NA，两条转移成了地图上的无人区，而世界那两步给的正是零证据分支的答案）。
    横玩家那边从来没犯这个病，因为它的读法从精灵框读起、不依赖盘内有没有绳。
    补上之后在全语料 123 帧次上与 vropes 逐帧对过：120 次两者都有读数且一致，
    3 次是 vropes 报不出的绳长 0，0 次不一致，0 次读不出。"""
    r0 = top + CELL - 1
    c1, c2 = left + 2, left + 3
    H = len(g)
    if not (0 <= r0 < H and 0 <= c2 < len(g[0])):
        return None
    if g[r0][c1] not in VROPE_COLORS or g[r0][c2] not in VROPE_COLORS:
        return None
    tip = r0
    for k in range(H - r0):
        r = r0 + k
        if g[r][c1] in VROPE_COLORS and g[r][c2] in VROPE_COLORS:
            tip = r
        elif k % CELL == 0:
            break
    return (tip - r0) // CELL


def players(g):
    """假设：盘上的玩家 —— [(芯色, 'h' 或 'v', 位置, 绳节数, 选中没有)]，按芯色排。
    'h' 挂在棋盘左外侧的竖轨上，位置是它占的格行，绳往右伸；
    'v' 挂在棋盘正上方的横轨上，位置是它占的格列，绳往下伸。
    底条以下那些同形的示意图图标不算（它们不在轨上）。
    某个玩家的位置或绳节数读不出来，**整个函数返回 None** —— 少给一个玩家比给半张盘更坏，
    这正是第 5 关那次全册失语的由来（读数瞎了却不报错）。

    由来（第 5 关）：盘上第一次同时有两个玩家，方向键作用在**被选中的那一个**身上。
    这个词是给「谁在动」立的一个可读的名字；四个方向键各自是什么意思，归各条概念管。"""
    b = board_box(g)
    if b is None:
        return None
    top, bottom, left, right = b
    out = []
    for r, c, core, fill in sprites(g):
        rt, lf = r - 2, c - 2                      # 2×2 芯的左上角往外退两格 = 外框左上角
        if lf < left and top <= rt < bottom:       # 左侧竖轨
            cr = (rt - top) // CELL
            n = _hrope_cells_at(g, rt, lf)
            if n is None or not (0 <= cr < (bottom - top + 1) // CELL):
                return None
            out.append((core, 'h', cr, n, fill == SEL_FILL))
        elif rt < top and left <= lf <= right:     # 上方横轨
            cc = (lf - left) // CELL
            n = _vrope_cells_at(g, rt, lf)
            if n is None or not (0 <= cc < (right - left + 1) // CELL):
                return None
            out.append((core, 'v', cc, n, fill == SEL_FILL))
    return sorted(out) if out else None


def sel_player(g):
    """假设：此刻方向键作用在谁身上 —— players() 里被选中的那一个。
    读不出来、或不恰好一个被选中，返回 None。"""
    ps = players(g)
    if ps is None:
        return None
    sel = [p for p in ps if p[4]]
    return sel[0] if len(sel) == 1 else None


def h_selected(g):
    """假设：此刻方向键作用在横玩家身上吗。读不出来返回 None。
    前五关只有一个玩家、它永远是选中的，所以这个词恒为 True；第 5 关起才分得开。"""
    p = sel_player(g)
    return None if p is None else (p[1] == 'h')


# ---- 选中竖玩家时，两个「伸缩键」把靶搬到哪 ---------------------------------
# 和横向那套（hmoved_cells / hmove_map）同构，转了 90 度：
# 竖绳是一根从棋盘上边缘往下插的杆，盖住它那一格列的格行 0..n-1。

def sel_v(g):
    """选中的那个玩家，且它是竖玩家；否则 None。"""
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def h_pole_cells(g):
    """假设：横玩家那根杆此刻盖住的格 —— 它那一行的格列 0..n-1。
    盘上不恰好一个横玩家、或读不出来，返回 None。"""
    ps = players(g)
    if ps is None:
        return None
    hs = [p for p in ps if p[1] == 'h']
    if len(hs) != 1:
        return None
    _, _, hr, hn, _ = hs[0]
    return {(hr, c) for c in range(hn)}


def vpole_cells(g, k):
    """假设：竖绳伸（k=+1）/缩（k=-1）一节时，被绳子带着走的靶格（还没算走不走得成）。
    和 hmoved_cells 同构、转 90 度：绳是一根从棋盘上边缘往下插的杆，盖住那一格列的
    格行 0..n-1，**杆上的每一块都被带着走**；伸下去时新绳尖落到格行 n，
    从那儿起往下**连续**的一串被顶着一起走。
    选中的不是竖玩家、或读不出来，返回 None。

    由来：第 875、876 步。绳 5 节、杆上第 4 行串着一颗色9、绳尖下方 (5,4) 空着，
    按 ACTION2 之后那颗 9 到了 (5,4)、再按一次到 (6,4)——
    也就是说**杆上的靶跟着绳尖一起往下走**，不是只有绳尖前面那一串会动。
    在这两步之前这里写的是「绳尖那一格空着 → 靶全不动」，两步都判错了 16 格
    （assert_ 却判 TRUE，因为 v_extend 只断言绳的几何、不管靶——settle 的「说错却判 TRUE」
    正是照见这种事的镜子）。"""
    p = sel_v(g)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr = nrows(g)
    if nr is None:
        return None
    m = cell_map(g)
    out = [(r, cc) for r in range(min(n, nr)) if (r, cc) in m]
    if k > 0:
        r = n
        while 0 <= r < nr and (r, cc) in m:
            out.append((r, cc))
            r += 1
    return out


def vslide_cells(g, d):
    """假设：竖玩家沿 d（-1 左 / +1 右）横挪一格时，跟着动的那些格。
    vmoved_cells 转 90 度：绳是一根从棋盘上边缘往下插的杆，盖住它那一列的格行 0..n-1，
    它从第 c 列扫到第 c+d 列；杆盖住的每一行 r 单独结算：(r,c) 上有靶，就从它起沿 d 那一串
    连续靶跟着走；(r,c) 空而 (r,c+d) 上有靶，就是杆扫过去把它顶走，从 (r,c+d) 起那一串跟着走；
    都空则这一行不动。**串在横杆上与否一概不管**——平移搬得动伸缩搬不动的那些靶。
    选中的不是竖玩家、或读不出来，返回 None。

    由来：第 987 步。竖玩家在第 3 列、绳 6 节，绳上第 3 行有一颗自由的 9、第 5 行有一颗
    同时串在横杆（第 5 行 4 节）上的 8，要挪进去的第 4 列在第 4 行上坐着 14。按 ACTION4 之后：
    9 到 (3,4)、8 到 (5,4)（横杆没拦住）、14 被顶到 (4,5)。三件事一次全给了。"""
    p = sel_v(g)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, nc = nrows(g), ncols(g)
    if nr is None or nc is None or n is None:
        return None
    m = cell_map(g)
    out = []
    for r in range(min(n, nr)):
        if (r, cc) in m:
            start = cc
        elif 0 <= cc + d < nc and (r, cc + d) in m:
            start = cc + d
        else:
            continue
        k = start
        while 0 <= k < nc and (r, k) in m:
            out.append((r, k))
            k += d
    return out


def slide_ok(g, d):
    """假设：竖玩家沿 d 横挪得动吗 —— 自己不出盘、**目标格列落在上边横轨那条花纹带里**、
    绳盖住的那几行里目标列没有墙、且被绳扫到的每一串靶都推得动（串里没有一块会被顶出棋盘）。
    读不出来返回 None。
    move_ok 转 90 度；「顶出棋盘就整个动作被拒」这一半是押注（横向那边实测过）；
    带子那一句同样是横向那边实测出来之后搬过来的（见 move_ok），这一侧还没赶上一步撞带子的转移。"""
    p = sel_v(g)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, nc, w = nrows(g), ncols(g), walls(g)
    if nr is None or nc is None or w is None or n is None:
        return None
    if not (0 <= cc + d < nc):
        return False
    sp = hrail_span(g)
    if sp is None:
        return None
    if not (sp[0] <= cc + d <= sp[1]):
        return False
    if any((r, cc + d) in w for r in range(min(n, nr))):
        return False
    mv = vslide_cells(g, d)
    if mv is None:
        return None
    return all(0 <= c + d < nc for (_, c) in mv)


def vslide_map(g, d):
    """假设：竖玩家沿 d 横挪一格之后，棋盘上的 {格: 色}。读不出来返回 None。"""
    mv = vslide_cells(g, d)
    if mv is None:
        return None
    m = cell_map(g)
    out = {k: v for k, v in m.items() if k not in mv}
    for (r, c) in mv:
        out[(r, c + d)] = m[(r, c)]
    return out


def hrope_map(g):
    """假设：横玩家那根绳连同它的 6×6 方块此刻占的 {像素: 色}。
    和 sprite_cells 同一份几何，只多一件事：绳的花纹按**主人此刻选中与否**取
    （sprite_cells 写死了「选中」那一支，rope_color 的 sel 参数才是全的）。
    定位不到返回 None。

    由来：第 1026 步。竖绳从格列 3 挪到 2，横杆在第 3 行、4 节，
    两根绳交叉的那 4 个像素上原本压着一颗靶 14；靶跟着平移走掉之后，
    那 4 个像素露出来的是 2/3/3/2 —— **横杆的颜色，不是竖绳的，也不是棋盘底色**。
    所以画的顺序是：靶盖横杆，横杆盖竖绳，竖绳盖棋盘。
    2/3 而不是 1/2，是因为那一刻被选中的是竖玩家、横玩家没被选中（rope_color 的 sel 那一半）。"""
    a, n, s = me(g), rope_cells(g), h_selected(g)
    if a is None or n is None or s is None:
        return None
    top, left = a
    out = {}
    for dr in range(CELL):
        for dc in range(CELL):
            v = 6 if (dr in (0, CELL - 1) or dc in (0, CELL - 1)
                      or (2 <= dr <= 3 and 2 <= dc <= 3)) else 0
            out[(top + dr, left + dc)] = v
    for k in range(CELL * n + 1):
        c = left + CELL - 1 + k
        out[(top + 2, c)] = rope_color(k, False, bool(s))
        out[(top + 3, c)] = rope_color(k, True, bool(s))
    return out


def vextend_ok(g):
    """假设：竖绳还伸不伸得下去 —— 新绳尖要落进的那一格（格行 n）不是墙。
    绳已占满整列时返回 None（语料里从没试过，不表态）。"""
    p = sel_v(g)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, w = nrows(g), walls(g)
    if nr is None or w is None or n >= nr:
        return None
    return (n, cc) not in w


def vpole_now(g, k):
    """假设：被竖绳带着走的那些格里，**真的**走成的那些。同 hmoved_now 转 90 度：
    伸绳时先问伸不伸得下去（绳尖落点是墙就一节都不伸、靶也一块不动）；
    伸得下去分两拨：**绳尖外那一串是刚性的**（串里有一块走不成就整串不动），
    **杆上的逐块结算**（落点出盘、落点是墙、落点上压着一块没走成的都走不成，留在原地）。
    **串在横杆上的那一颗搬不动**（第 986 步实测：竖绳 7→6 节，横杆第 5 行 4 节上串着的那颗 8
    一格没动，它上面那颗自由的 9 照常上移一格），落点被横杆盖着的也当作推不动
    （这一半是押注，从横向那边「伸绳推不进被竖绳钉住的格」转 90 度搬过来的）。
    **刚性串这一条也是押注**：横向那边终局卡第 1227 步实测（tid 4bee75c397a1b2d7，
    中间一颗被钉住整串就一块不动），这一侧还没撞上一步能分辨的转移。"""
    if k > 0:
        ok = vextend_ok(g)
        if ok is None:
            return None
        if not ok:
            return []
    cells = vpole_cells(g, k)
    p = sel_v(g)
    if cells is None or p is None:
        return None
    _, _, cc, n, _ = p
    nr, w, hp = nrows(g), walls(g), h_pole_cells(g)
    if nr is None or w is None or hp is None or n is None:
        return None
    m = cell_map(g)
    moving = set()
    run = sorted(r for (r, _c) in cells if r >= n) if k > 0 else []
    if run:
        t = run[-1] + 1
        if (not any((r, cc) in hp for r in run)
                and 0 <= t < nr and (t, cc) not in hp and (t, cc) not in w):
            moving |= {(r, cc) for r in run}
    for (r, c) in sorted([x for x in cells if x[0] < n], reverse=(k > 0)):
        t = r + k
        if (r, c) in hp or (t, c) in hp:
            continue
        if not (0 <= t < nr) or (t, c) in w:
            continue
        if (t, c) in m and (t, c) not in moving:
            continue
        moving.add((r, c))
    return sorted(moving)


def vpole_map(g, k):
    """假设：竖绳伸（k=+1）/缩（k=-1）一节之后棋盘上的 {格: 色}。
    该走的那些格（见 vpole_now）各移一格，其余原地不动。读不出来返回 None。"""
    mv = vpole_now(g, k)
    if mv is None:
        return None
    m = cell_map(g)
    out = {kk: v for kk, v in m.items() if kk not in mv}
    for (r, c) in mv:
        out[(r + k, c)] = m[(r, c)]
    return out


def vdrag_cells(g):
    """假设：竖绳缩一节（ACTION1）时，杆上**真的**被带着往上走的靶格。
    见 vpole_now(g, -1)；绳已经 0 节返回 None（语料里没试过，不表态）。"""
    p = sel_v(g)
    if p is None or p[3] <= 0:
        return None
    return vpole_now(g, -1)


def vdrag_map(g):
    """假设：竖绳缩一节之后棋盘上的 {格: 色}。见 vpole_map(g, -1)。
    绳已经 0 节返回 None。"""
    p = sel_v(g)
    if p is None or p[3] <= 0:
        return None
    return vpole_map(g, -1)


def vextend_map(g):
    """假设：竖绳伸一节（ACTION2）之后棋盘上的 {格: 色}。见 vpole_map(g, +1)。
    绳已伸满整列返回 None（语料里没试过，不表态）。"""
    p = sel_v(g)
    nr = nrows(g)
    if p is None or nr is None or p[3] >= nr:
        return None
    return vpole_map(g, +1)


# ---- 这一步走完会是什么样、会不会过关 --------------------------------------
# 主张在 levelup_threaded 里（「摆满 ⟺ 过关」是可判错的那句话）；
# 这里只放算法，因为**两个地方要用同一份算法**：那条概念的断言，和各条概念 apply 的换关守卫。
# 从前两处各写各的，代价是分数表上看不出它们不一致（见 levelup_threaded v4 的由来）。

def moved_map(g, action):
    """假设：这一步走完之后棋盘上的 {格: 色}。算不出返回 None。
    方向键作用在被选中的那个玩家身上，所以先看选的是谁：
    横玩家 —— 左右是绳的伸缩、上下是沿轨移动；
    竖玩家 —— 上下是绳的伸缩、左右是整根绳横着挪列（挪不动那半还没跟上，返回 None）。
    ACTION6 是「换选中的人」，靶一颗不动，所以答案就是此刻的分布（a6_select 的两支都不动靶：
    点空/点已选中的整帧全同，换人只换两个精灵的填色和两根绳的花纹）。
    **ACTION7 返回 None**：它的方向是帧上没有的一位（见 frame_not_state / a7_shuttle），
    「伸长一节」只是它一半的样子，另一半是缩短一节 —— 这里曾经写成 hmove_map(g, +1)，
    第 453、454 步各说错 4 格（hud_checklist 的生成器上线当天抓出来的）。"""
    if action.startswith("ACTION7"):
        return None
    if action.startswith("ACTION6"):
        return cell_map(g)
    hs = h_selected(g)
    if hs is None:
        return None
    if hs:
        if action.startswith("ACTION3"):
            return hmove_map(g, -1)
        if action.startswith("ACTION4"):
            return hmove_map(g, 1)
        if action.startswith("ACTION1"):
            return vmove_map(g, -1)
        if action.startswith("ACTION2"):
            return vmove_map(g, 1)
        return None
    if action.startswith("ACTION1"):
        return vdrag_map(g)
    if action.startswith("ACTION2"):
        return vextend_map(g)
    if action.startswith("ACTION3") or action.startswith("ACTION4"):
        d = -1 if action.startswith("ACTION3") else 1
        ok = slide_ok(g, d)
        if ok is None or not ok:
            return None
        return vslide_map(g, d)
    return None


def threaded_done(g, action):
    """假设：这一步走完之后，示意图每一栏的每一个槽是不是都对上了 ——
    那一栏指的绳子上，从绳主往外数第 j 颗靶正是左数第 j 块的颜色；
    绳上多串的、排在目标之后的靶不算数（这一条和 hud_checklist 逐槽的读法同源）。
    算不出返回 None。"""
    groups = hud_groups(g)
    if not groups:
        return None
    m = moved_map(g, action)
    if m is None:
        return None
    for icon, colors in groups:
        seq = rope_seq(g, icon, m, action)
        if seq is None:
            return None
        if not all(j < len(seq) and seq[j] == color
                   for j, color in enumerate(colors)):
            return False
    return True


def repaint_pending(g, action, ctx=None):
    """这一步之后是不是整屏重画（换关）。
    结算口径下 ctx 直接说得出；**预测口径下 level_next 恒等于 level_prev，ctx 说不出** ——
    那就问册子：摆满了每一栏就是过关那一步（主张见 levelup_threaded）。算不出当作不是。

    由来：各条概念的 SCOPE 都写着「换关返回 NA」，assert_ 也都照做了，
    可 apply 里那道守卫问的是 ctx —— 于是同一条概念在结算口径下闭嘴、在预测口径下照画，
    而分数表量的是结算那一条，这一类错**在册子里完全看不见**，只会在终局卡上变成一次意外。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return True
    return threaded_done(g, action) is True


def uncomputable_cells(g):
    """本册算不出、因而任何 apply 都不该照抄的格：底条那一整行。

    底条消耗的是「本关按下的方向键数」k（实测 used == k * 16 // 49，1119 步里对 1091 步），
    而 **k 不在帧上**：从 used 只读得出 k*16//49，读不出 k 本身，所以「下一步扣不扣格」
    不是当前帧的函数（同 frame_not_state 说的那件事：帧不是完整状态）。
    没有任何概念能从一帧算出下一帧的底条，也就没有概念该声称它。

    单步预测里这无所谓 —— prev 就是真帧，「这一片没变」照抄就对。
    链式预测里 prev 是模型自己画出来的帧，底条停在旧值上，谁再声称「这一片没变」，
    谁就把别人的无知签成自己的主张（a6_select 的「整帧全同」那一支就这么把残差变成了说错）。

    这个词只用来**缩**（让 apply 少认领几格），不用来算，所以它不会替谁造出一个假 TRUE；
    它的代价只在 E 上：底条那一行从此永远算残差。"""
    return {(BAR_ROW, c) for c in range(len(g[BAR_ROW]))}
