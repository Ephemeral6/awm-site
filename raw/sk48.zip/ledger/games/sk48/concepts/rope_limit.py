"""绳子最长伸到和棋盘一样宽：任何一帧里节数都不超过棋盘的列数。"""
LEVEL = "L2"
SCOPE = ("所有动作都判（n <= 列数）；换关返回 NA；绳子或棋盘认不出返回 NA。"
         "**只说上限存在，不说撞到上限会怎样**——ACTION7 撞上限归 a7_bounce，"
         "ACTION4 撞上限归 rope_ceiling（v3 起：那一片本来写着「册子里没人认领」，现在认领了——"
         "语料里 12 条满行 ACTION4，绳长、玩家、靶都不变）。")
NOTE = ("v2：后半句『节数已经等于列数时 ACTION4/ACTION7 整帧不动』死于第 377 步 06cf08bbd51ca612——"
        "绳子在第 4 关伸满 7 节时按 ACTION7，它不但动了，还**往回收了一节**（帧差 12 格，正好是上一步伸绳的逆）。"
        "v1 的 NOTE 里白纸黑字写着这后半句是零证据的、『写进来就是为了下次撞上时它能死』，"
        "它就这么死了——那句话该算兑现，不该算辩解：零证据的子句活着的每一天都在给整条概念的 S 充水，"
        "因为它一次都没被判过。教训进方法册：**一条概念里塞两句，只要有一句零证据，S 就不是这条概念的分数**。"
        "v2 只留可判的前半句，撞上限那一片交给 a7_bounce（ACTION7）；ACTION4 那一片现在是明写的空白。"
        "v1 由来：规划器要搜路线就必须知道绳子能伸多长，我在规划器里先随手填了个 NMAX=6，"
        "拿语料自检当场对不上三条（第 58、69、72 步绳子到了 7）。"
        "**这就是把世界事实写在规划器里而不是概念里的下场：它没有分数、没有反例、没人替我核。**")
EVIDENCE = ["33382ab46ed81e55", "9a68d00127b954d4", "67c3963bceb3915d",
            "b342a6deb6edd9d6", "3f3d51f1d9818a59", "7cf85e4f91e47a2d",
            "06cf08bbd51ca612"]

from _lib import rope_cells, ncols


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    nb = rope_cells(nxt)
    cb = ncols(nxt)
    if nb is None or cb is None:
        return "NA"
    return "FALSE" if nb > cb else "TRUE"
