"""绳子已经占满整行（绳尖顶在最右一格）时按 ACTION7，绳子反而收回一节：绳尖左移 CELL 列，玩家不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7，且只看 rope_cells >= ncols（绳子占满整行）的局面；"
         "别的 ACTION7 局面归 a7_extend / a7_fallthrough；换关返回 NA；定位不到返回 NA。"
         "**不说杆下的靶跟不跟着往左走**（唯一那一步杆下是空的，没看见过），"
         "也不说这一节收回去之后下一次 ACTION7 往哪走——那要看它有没有一个看不见的方向位。")
NOTE = ("v1：唯一的依据是第 377 步 06cf08bbd51ca612——玩家在第 4 行、绳 n=7 顶到最右格、"
        "整行空着，ACTION7 发出去帧差 12 格，恰好是上一步（第 376 步伸绳）那 12 格的逆操作，n 回到 6。"
        "这一条把 ACTION7 的第三种表现单独立出来：伸得出去就伸（a7_extend），"
        "落点是墙就把玩家往下挪一行（a7_fallthrough），顶到棋盘右边缘就往回收一节（这一条）。"
        "三种表现共用一个动作，触发条件全是位置，**暂时没有任何一条需要看不见的状态**——"
        "这句话是这一条最脆的地方：如果 ACTION7 记着一个方向位，收回一节之后它会接着往回收，"
        "而不是又伸出去。下一批第一步就去撞这个（n=6 再按一次 ACTION7，伸=无状态，缩=有状态）。")
EVIDENCE = ["06cf08bbd51ca612"]

from _lib import (CELL, me, rope_cells, ncols, bg_at, hmove_map, map_pixels,
                  target_pixels, repaint_pending)


def _full(g):
    n, nc = rope_cells(g), ncols(g)
    if n is None or nc is None:
        return None
    return n >= nc


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION7"):
        return "NA"
    if _full(prev) is not True:
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    return "TRUE" if (b == a and nb == na - 1) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION7"):
        return None
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if _full(prev) is not True:
        return None
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None or n <= 0:
        return None
    out = {}
    after = hmove_map(prev, -1)
    covered = map_pixels(prev, after) if after is not None else target_pixels(prev)
    for k in range(CELL * (n - 1) + 1, CELL * n + 1):
        c = a[1] + CELL - 1 + k
        for dr in (2, 3):
            if (a[0] + dr, c) in covered:
                continue                 # 靶块压在绳子上面，这一格不归我说
            out[(a[0] + dr, c)] = bg_at(prev, a[0] + dr, c)
    return out
