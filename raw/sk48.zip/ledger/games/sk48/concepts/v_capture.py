"""竖绳往下伸的那一节，绳尖要落进的格上压着一颗**顶不动**的靶（它下面是棋盘下边缘或墙）时，那颗靶一格不动，绳照样伸过去把它盖住——靶就此串在这根绳上。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION2；换关返回 NA；players()/sel_player()/cell_map/walls 读不出来返回 NA；"
         "**选中的不是竖玩家就返回 NA**；新绳尖那一格是墙、或那一格上没有靶，返回 NA；"
         "从绳尖那一格起往下的那一串靶**推得动**（串尾下面既不是盘外也不是墙）返回 NA —— 那一片归 v_push 管。"
         "**只说绳尖那一格上那颗靶留在原地、绳长加一**（v4 起）：同一列上别的靶动没动，一概不说，归 v_push。"
         "不说绳子怎么画。")
NOTE = ("由来：第 872 步。竖玩家在格列 4、绳 6 节，新绳尖要落进的 (6,4) 上压着一颗色9，"
        "而 (6,4) 就是棋盘最下面那一行——这颗靶无处可去。"
        "帧差只有 4 格：绳子那两像素列在格行 6 的头一行和末一行由底色变成绳色，"
        "中间四行被那颗 4×4 的靶盖着看不见；靶自己一个像素没动。"
        "**押注押的就是这一条**，并且写明了落空会长什么样（动作被整个拒掉、绳还是 6 节），"
        "那样死的就该是 v_extend。世界给的是「盖过去」。\n"
        "这是横绳那边「推不动就被串上」的 90 度旋转版（hmoved_now：推不动的靶不动，绳照伸）——"
        "也是这一局唯一把靶串上绳的办法：绳伸出去只会把推得动的靶往前顶，顶不动的那一颗才留得下来。"
        "**只有一条转移撑着，而且只试过「串尾抵着棋盘下边缘」这一种顶不动**；"
        "「串尾抵着墙」和「串尾抵着另一根绳钉住的格」都还没试过。\n"
        "v2：**只加 apply，断言一个字没动**。和 v_push v2 同一个由来——预押注时输出写着"
        "「预测 0 格 ← 没有概念开口」：绳尖那一格有靶时 v_extend 闭嘴，而这条只判不生成。"
        "补的生成器就是由来里那 4 格：绳照伸，靶一个像素没动，"
        "所以只有那一格里**没被 4×4 的靶盖住的**绳像素（头一行和末一行各两格）会变。\n"
        "v3：**只给 apply 补上换关守卫，断言一个字没动。**"
        "assert_ 开头一直写着「换关返回 NA」，apply 里没有对应的 return None——"
        "于是换关那一步检查器闭嘴、生成器照着旧局面的坐标往整屏重画过的新帧上开口，4 格全错，"
        "而它在分数表上仍是满分（说错不掉分，判 NA 的那一步也没人去看生成器说了什么）。"
        "全册当时的 8 格说错里有 4 格是这一处。抄进 EVIDENCE 的那条转移 assert_ 判 NA，"
        "它进来的身份是**回归样本**不是依据：以后 apply 再多嘴，它当场再报一次。\n"
        "v4：第 1129 步（755b883c9cd8a8da）判 FALSE。绳尖那一格的靶确实一格没动、绳确实伸过去盖住了它——"
        "首行那句话一个字没错，**错的是断言比首行多说了一句**：v1 起写的是 `m2 == m`，"
        "整张盘的靶都不许动。而这一步同一列上还有一颗**和它不相连**的靶，"
        "在绳伸下来时照常被顶下一格（那正是 v_push v4 刚放开的那一支）。"
        "两条概念在同一步上一个说「全盘不动」一个说「那一颗动」，"
        "被打的是多说话的那一条。改法是把断言收回首行的范围：只看绳尖那一格上的那颗靶，"
        "别的格归 v_push。**教训是「顺手多断言一句」比断错更难发现**——"
        "`m2 == m` 在只有一颗靶的那条老证据上和正确的说法一模一样，"
        "它多出来的那半句话要等到盘上出现第二颗靶才现形。")
EVIDENCE = ["f5c36ad68398b1a7", "e47360d33a5798ff", "755b883c9cd8a8da"]

from _lib import (players, sel_player, walls, nrows, cell_map,
                  cell_topleft, vrope_map, repaint_pending)


def _sel_v(g):
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    p = _sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    nr, w = nrows(prev), walls(prev)
    m, m2 = cell_map(prev), cell_map(nxt)
    if nr is None or w is None or m is None or m2 is None:
        return "NA"
    if n >= nr or (n, cc) in w or (n, cc) not in m:
        return "NA"
    r = n
    while r < nr and (r, cc) in m:              # 绳尖那一格起，往下连续的一串靶
        r += 1
    if r < nr and (r, cc) not in w:             # 串推得动：不归这条管
        return "NA"
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v':
        return "FALSE"
    return "TRUE" if ((q[0][2], q[0][3]) == (cc, n + 1)
                      and m2.get((n, cc)) == m.get((n, cc))) else "FALSE"


def _case(prev):
    """这一条管不管这一步：管，就返回 (格列, 绳长)；不管返回 None。条件与 assert_ 同源，只是不看 nxt。"""
    p = _sel_v(prev)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, w, m = nrows(prev), walls(prev), cell_map(prev)
    if nr is None or w is None or m is None:
        return None
    if n >= nr or (n, cc) in w or (n, cc) not in m:
        return None
    r = n
    while r < nr and (r, cc) in m:
        r += 1
    if r < nr and (r, cc) not in w:                  # 推得动：归 v_push
        return None
    return cc, n


def apply(prev, action, ctx=None):
    """靶一个像素没动，绳多盖一格。会变的只有绳尖那一格里露在 4×4 靶外面的绳像素。"""
    if repaint_pending(prev, action, ctx):
        return None                      # v3：assert_ 早就有这一句，apply 漏了；v4：预测口径下改问册子
    if not action.startswith("ACTION2"):
        return None
    case = _case(prev)
    if case is None:
        return None
    cc, n = case
    rope = vrope_map(prev, cc, n + 1, True)
    tl = cell_topleft(prev, n, cc)
    if rope is None or tl is None:
        return None
    t0, l0 = tl
    bead = {(t0 + dr, l0 + dc) for dr in range(4) for dc in range(4)}
    return {rc: v for rc, v in rope.items()
            if t0 - 1 <= rc[0] <= t0 + 4 and rc not in bead}
