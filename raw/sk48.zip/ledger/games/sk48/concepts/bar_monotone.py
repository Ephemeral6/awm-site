"""底条（第 BAR_ROW 行）已消耗的色3格数：普通动作下只增不减且一步至多加 1；RESET 把它清零。"""
LEVEL = "L4"
SCOPE = "所有动作；换关返回 NA"
NOTE = ("v2：v1 说「只增不减」，被 RESET 那一条推翻——底条从 10 格回到 0 格。"
        "改成两段：RESET 归零，其余每步 +0 或 +1。这不是缩 scope 躲开 RESET，"
        "而是把 RESET 也纳进同一条计数器规律里，所以它照样能被推翻（RESET 后不为 0，或普通动作一步跳 2 格）。")
EVIDENCE = ["ffa9f1be044bfcb7", "33382ab46ed81e55", "f171ca1ba9e1992b"]

from _lib import bar_used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.strip().upper() == "RESET":
        return "TRUE" if bar_used(nxt) == 0 else "FALSE"
    d = bar_used(nxt) - bar_used(prev)
    return "TRUE" if 0 <= d <= 1 else "FALSE"
