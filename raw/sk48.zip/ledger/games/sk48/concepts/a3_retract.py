"""ACTION3 让绳子缩掉一节：绳尖左移 CELL 列，玩家自己不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3；换关返回 NA；me() 或 rope_cells() 认不出来返回 NA；"
         "**此刻方向键作用的不是横玩家（h_selected 不为 True）返回 NA** —— 那时 ACTION3 是竖玩家左移，归 v_slide 管；"
         "绳子已经是 0 节时返回 NA —— 缩不动的那一片归 retract_floor 管，这里不再声称")
NOTE = ("v3：apply 不再往靶块像素上画底色。缩绳时被收回的那一节如果正压在靶底下，"
        "那几列的中间四行仍是靶的颜色（绳子本来就是从靶底下穿过去的），"
        "v2 一律按 bg_at 画，第 85 步 24 格里说错 8 格，而 assert_ 照样判 TRUE——"
        "『说错 N 格却判 TRUE』那一行是唯一会点破这件事的地方。避让办法照抄 a47_extend："
        "按**缩完之后**的靶分布（hmove_map）算哪些像素归靶。"
        " || v4：删掉「要么整帧不动」这个退路，并把 0 节那一片交出去（返回 NA）。"
        "退路是被一条转移打死的：0 节时按缩绳，绳子确实没动，但**帧变了 1 格**——"
        "底部那条计时的每三个动作走一格，而第 168 步正好是它走的那一步。"
        "也就是说这个退路的真假挂在步号除以 3 的余数上：全局 prev==nxt 只有 4/168 条，"
        "步号 10、28、29、91，一个能被 3 整除的都没有。同一个物理情形，钟走的那一步判 FALSE、"
        "不走的两步判 TRUE——用一个和主张无关的相位去豁免一个会发生的失败。"
        "查了一遍：ACTION3 一共 45 条，减一节以外的情形只有 0 节那一条（1/168）。"
        "所以这一版是更强的说法——没有兜底，减不掉就是反例。"
        "apply 早就写着 n<=0 返回 None，assert_ 到这一版才跟上，两处现在同步。"
        " || v6 是**被推翻后缩的**：死于 123fc813a0c1aa1e（第 865 步）。"
        "第 5 关盘上有两个玩家，那一步选中的是挂在上边横轨的那个，ACTION3 让它整体左移了一格列，"
        "横玩家的绳一节没缩。所以这条从来说的都不是『ACTION3 缩绳』，"
        "而是『方向键作用在横玩家身上时，ACTION3 缩绳』——前五关只有一个玩家、它永远被选中，"
        "那个前提一直在，只是没写出来。v6 把它写进 scope，判据是 h_selected。")
EVIDENCE = ["ffa9f1be044bfcb7", "aef9b660922ca25a", "3bf4c5c19b77617d", "123fc813a0c1aa1e"]

from _lib import (CELL, me, rope_cells, bg_at, hmove_map, map_pixels,
                  target_pixels, h_selected, repaint_pending)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION3"):
        return "NA"
    if h_selected(prev) is not True:
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    if na == 0:
        return "NA"
    return "TRUE" if (b == a and nb == na - 1) else "FALSE"


def apply(prev, action, ctx=None):
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION3"):
        return None
    if h_selected(prev) is not True:
        return None
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None or n <= 0:
        return None
    out = {}
    after = hmove_map(prev, -1)
    covered = map_pixels(prev, after) if after is not None else target_pixels(prev)
    for k in range(CELL * (n - 1) + 1, CELL * n + 1):
        c = a[1] + CELL - 1 + k
        for dr in (2, 3):
            if (a[0] + dr, c) in covered:
                continue                 # 靶块压在绳子上面，这一格不归我说
            out[(a[0] + dr, c)] = bg_at(prev, a[0] + dr, c)
    return out
