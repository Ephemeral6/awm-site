"""示意图是一张按绳子分栏的对账单：每一栏开头那个 6×6 图标指着盘上一根绳子（芯色 6 = 玩家的横绳，
别的芯色 = 头是这个色的那根竖绳），栏里的块从左到右就是这根绳子该串成的顺序。
从这一栏左数第 j 个块被挖空（中心 2×2 变色 0），当且仅当这根绳子此刻串着的第 j 个靶正好是这个块的颜色。"""
LEVEL = "L5"
SCOPE = "所有动作，判 nxt 这一帧；换关返回 NA；示意图分不出组、或哪一组的绳子在盘上认不出来，返回 NA"
NOTE = ("由来：示意图整整 42 步一个像素没动，一直被当成静态的目标画面；第 42 步绳子伸满 5 格、"
        "玩家那一行上第一个（也是唯一一个）靶正好是示意图最左那块的颜色，它的中心 2×2 当场被挖空。"
        "反过来在此之前，玩家那一行上第一个靶是别的颜色时从没挖空过——两边都对得上，就写成充要条件。"
        "这条比原来那张「目标画面」有用得多：它把「还差多少」变成每一步都读得到的量，"
        "而不是只有摆成的那一刻才知道。它也顺带把目标的判据说清楚了——"
        "要紧的是「绳子上串着的靶按顺序对不对」，不是靶落在哪几列。"
        "写成充要条件是为了让它容易死：多挖空一个、少挖空一个，都是反例。"
        "第 49 步换关后把写死的三色目标换成从示意图上读（goal_order），块数也不再假定是三个——"
        "换的是词汇的读法不是主张，所以不算改版。"
        "v3 不是被推翻的，是被看穿的：v1/v2 一直假定示意图只有一串、串的是玩家那根横绳。"
        "第 3 关的开局帧摆明了这是特例——示意图里有**两个**图标，芯色分别是盘上两根竖绳头的颜色，"
        "而玩家那个色6 图标一个也没有；块被两个图标分成两栏。回头看第 0~2 关，"
        "那唯一的一个图标芯色正是 6，也就是「这一串归玩家的横绳」，只是当时只有一栏，看不出栏是栏。"
        "所以主张的形状本来就该是「每个图标一栏，各自对自己那根绳子结账」，"
        "v2 只是它在「恰好一栏、恰好归玩家」时的样子。"
        "按 v2 的字面读法，第 3 关的目标会被读成『玩家那一行上摆出 8,12,9,14』——"
        "那是把两根竖绳该干的活派给了横绳，早晚要塌；与其等它塌，不如把新看见的结构写进主张。"
        "留着的没检验处：竖绳那一栏的顺序我按「从绳主往外」定成从上往下（横绳是从左往右，"
        "两者都是从绳子挂着的那一头数起），第 3 关一挖空就知道对不对；"
        "还有靶之间留空格算不算数——threaded_on 跳过空格，只看顺序，这一条同样没受过检验。"
        "第 135 步把上面那条顺序的欠条还了，而且是**造出来的**局面不是等来的："
        "特意把两块靶叠进同一根竖绳，让两种读法给出相反的预言——"
        "那一列自上而下串着 (14, 9)，而它那一栏要的是 (9, 14)。"
        "自上而下读 = 对不上 = 一块都不该挖空；自下而上读 = 正好对上 = 该挖空两块。"
        "实测四块一个没挖。所以「从绳主往外」是对的，竖绳从上往下，"
        "「自下而上」那一版当场出局。此前这条只是和横绳的类比，零证据。"
        "第 145 步把第二张欠条也还了，同样是造出来的：让 8 单独上竖绳列4，"
        "而且特意让它落在绳子**最下面**那一格，上面两格空着。"
        "若「串上」要求紧挨着绳头才算数，8 在最下面就不算第一个，四块该全不挖空；"
        "若 threaded_on 跳过空格、只看顺序是对的，就该只挖空左起第一块。"
        "实测挖空 [True,False,False,False]，跳空格这一条成立。"
        "这两步之前，分栏读法在「该挖空」的一侧一条证据都没有——"
        "只验过「说不该挖、果然没挖」，那一侧一条恒假的规则也能全对。\n"
        "v6：**补生成器，断言一个字没动。** 这条概念一直只会判不会生成，"
        "于是示意图那两行（挖空的中心 2×2）在语料上有 54 条转移是残差——没人认领。"
        "单步预测里残差只是 E 低一点；**链式预测里它会变成说错**：模型帧那两行停在旧值上，"
        "下一步谁声称「这一片没变」，谁就把旧值抄成主张。"
        "生成器用的是和断言同一条规则、和 levelup_threaded 同一份算法（_lib.moved_map + rope_seq）——"
        "差别只在断言问「nxt 这一帧挖空对不对」，生成器问「照这一步算出来的落点，下一帧该挖空哪几块」。"
        "换关那一帧整屏重画，返回 None（守卫是 repaint_pending，预测口径下 ctx 说不出换关）。\n"
        "v7：生成器上线当天先抓出词里的一处旧伤——`moved_map` 把 ACTION7 当成「伸长一节」，"
        "而 ACTION7 的方向不在帧上（frame_not_state / a7_shuttle）；第 453、454 步这条各说错 4 格"
        "（说那两块该挖空，实际没挖）。修在词里（ACTION7 一律返回 None），本条源码一个字没动，"
        "这两条 tid 进 EVIDENCE 当回归样本。"
        )
EVIDENCE = ["ebf6a5f8c687760e", "3ef2ba1535db4a4e", "210e539c12d2ca36",
            "9a54a99329845b36", "2ca643bf5d861ab6",
            "f2a1a338cc4d5a60", "2484ff2214ff32e6"]

from _lib import (hud_groups, hud_hollow, hud_slots, hud_top, threaded_on,
                  moved_map, rope_seq, repaint_pending)


def expected(g):
    """假设：这一帧示意图各个块该不该被挖空，按 hud_slots 的顺序排平。定位不到返回 None。"""
    groups = hud_groups(g)
    slots = hud_slots(g)
    if not groups or not slots:
        return None
    out = []
    for icon, colors in groups:
        seq = threaded_on(g, icon)
        if seq is None:
            return None                      # 这一栏的绳子在盘上认不出来，整条闭嘴
        out.extend(j < len(seq) and seq[j] == color for j, color in enumerate(colors))
    return out if len(out) == len(slots) else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    want = expected(nxt)
    if want is None:
        return "NA"
    got = hud_hollow(nxt)
    if got is None:
        return "NA"
    return "TRUE" if got == want else "FALSE"


def apply(prev, action, ctx=None):
    """这一步走完之后，示意图各个块的中心 2×2 该是什么色：该挖空的填 0，没挖空的填块自己的色。
    落点按本册的运动规律现算（和 levelup_threaded 同一份算法），所以它也就只敢说这几格。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画
    top = hud_top(prev)
    groups = hud_groups(prev)
    slots = hud_slots(prev)
    if top is None or not groups or not slots:
        return None
    m = moved_map(prev, action)
    if m is None:
        return None                      # 落点算不出来，这一步闭嘴
    want = []
    for icon, colors in groups:
        seq = rope_seq(prev, icon, m, action)
        if seq is None:
            return None
        want.extend(j < len(seq) and seq[j] == color for j, color in enumerate(colors))
    if len(want) != len(slots):
        return None
    out = {}
    for (x, color), hollow in zip(slots, want):
        for r in (top + 2, top + 3):
            for c in (x + 1, x + 2):
                out[(r, c)] = 0 if hollow else color
    return out
