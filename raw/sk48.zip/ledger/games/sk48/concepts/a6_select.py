"""ACTION6:x,y 是「选中」而不是死键：像素 (列x,行y) 落在哪个玩家/图标的 6×6 外框里，就把选中标记换到那个芯色上（被选中的精灵内圈填色0、其余填色4）；落在没有精灵的地方、或落在此刻已经选中的那个芯色上，整帧一格不变。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION6；换关返回 NA；选中者认不出（selected_core 为 None）返回 NA。"
         "**只说选中标记归谁**：不说选中之后 ACTION1/2/3/4 各自变成什么意思（那归 a1/a2/a3/a4 各条管），"
         "也不说两根绳的配色为什么跟着换（观察到了，但没单独立条）。")
NOTE = ("撤掉的 a6_noop v1 说 ACTION6 是死键，靠的是 17 次按下 17 次帧全同。"
        "它死在第 491 步 11131d8a77ef8941：第 5 关棋盘上边多了第二个玩家（芯色15），"
        "点它的芯，104 格当场变了。\n"
        "**它能活这么久，是因为分母数错了对象**：ACTION6 带坐标，17 次说的是按了十七次，"
        "不是试了十七种。把历史坐标按 (列,行) 解出来（这个读法本身也是这次才查实的："
        "17 次里按 (列,行) 读全部落在有意义的东西上，按 (行,列) 读一半落在背景），"
        "17 次覆盖的是靶、绳子、底条、示意图槽、装饰、以及**我自己那个已经选中的精灵**——"
        "唯独没有『另一个玩家』这一类，因为前五关盘上只有一个玩家，这一类的坐标根本不存在。\n"
        "改成这一条之后，全部 18 次 ACTION6 各归各位、一次不剩：\n"
        "  · 15 次点在没有精灵的像素上 —— 帧全同；\n"
        "  · 2 次（第 394、395 步）点中的正是**当时已经选中**的芯色6（一次点棋盘上的精灵、一次点示意图里的小图标）—— 帧全同；\n"
        "  · 1 次（第 491 步）点中另一个芯色15 —— 帧变了。\n"
        "所以「死键」是「点不中别人」的样子，而不是这个键的性质。\n"
        "选中标记读在**内圈填色**上：选中的精灵 2×2 芯外面那一圈是色0，没选中的是色4；"
        "示意图里的小图标同形同色，于是同一帧把选中态写了两遍，可以互相核对——"
        "全语料 981 张帧里 selected_core 认不出唯一选中者的有 0 张。\n"
        "**还没检验的**（按方法册的规矩明写成待办，不留在暗处替我判 TRUE）："
        "一、点中另一个芯色时我只见过 1 次，『换到那个芯色上』这半句 N=1；"
        "二、点示意图里的小图标算不算数——第 395 步点中的图标芯色恰好就是已选中的那个，"
        "所以『点图标能不能选中另一个人』一次都没试过。这两件下一批顺手撞。\n"
        "v2：第一件销了。第 877 步 ACTION6:7,28 点在**横玩家**（芯6）的精灵框里，"
        "而当时选中的是芯15——192 格当场变了，选中标记回到芯6。"
        "此前两次换人（第 491、859 步）都是芯6→芯15，只有一个方向；这一步是回程，"
        "『换到那个芯色上』不再是一条单向的孤证。押注押的就是它，并写明了落空的样子："
        "帧全同（点不中或点了不换人）、或换到别的芯色上。第二件（点示意图的小图标）仍未试过。\n"
        "顺带记一个数：三次换人的帧差分别是 104、104、192 格。"
        "前两次两根绳都短，第三次两根绳都伸得长——差额正是绳子换配色的那些像素，"
        "和『被选中的精灵内圈填色0』这半句无关。这也说明 apply 只敢生成帧全同那一支是对的。\n"
        "apply 只生成帧全同那一支：选中真的换人时画面怎么变（两个精灵的填色互换、两根绳的配色互换、"
        "示意图两个图标跟着换），观察到了但只有三条证据，不敢生成。\n"
        "v3：**换人那一支的生成器补上了，断言一个字没动。** 由来是一次押注："
        "一批 21 个动作里第 8 个是换人，押注输出在那一步写着「预测 0 格 ← 没有概念开口」，"
        "而后面 13 步的预测全是在「没换人」那张假帧上推出来的——**静默不是零成本，它会把同一批里后面每一步的推演一起带偏**。"
        "（那一批当场改短，只走到换人为止，拿真帧再续。）\n"
        "生成器的规律是把上面那段观察数清楚之后写出来的，五次换人（第 491、859、877、902、953 步，"
        "帧差 104、128、192、156、140 格）结构完全一样，一格不多一格不少：\n"
        "  · 芯色是「原来选中的」或「新选中的」那几个精灵（盘上两个 + 示意图里两个图标），"
        "各自内圈那 12 格换填色，一共 48 格——这半句本来就写在首行主张里；\n"
        "  · 其余全是绳子：每根绳的花纹整体 ±1（词 `rope_color` 的 sel 那一半），"
        "**盘上的绳和示意图里画的绳同一套花纹、同一个锚点**——从精灵框的边缘那一列/行起算第 0 节。"
        "帧差为什么每次不一样，就是两根绳当时伸出去多少的差别。\n"
        "生成器对每一个像素只在**它此刻正好是这根绳该有的旧色**时才表态：靶盖住的那几格、绳尽头之外的那几格，"
        "prev 对不上就跳过。所以「靶压着绳」这种局面它自动闭嘴，不用另写一条守卫。\n"
        "v4：**「整帧全同」那一支不再照抄底条那一行，断言一个字没动。**"
        "断言说的「整帧一格不变」是真的，单步预测里也一格没错（127688/127688）；"
        "错的是**链式**预测——终局卡上一批动作是接着自己画的帧往下推的，"
        "而底条的消耗要数「本关按了多少方向键」，那个数不在帧上，没有概念算得出来（词 uncomputable_cells）。"
        "于是模型帧的底条停在旧值上，这一支照抄旧值，就把**别人的残差签成了自己的主张**："
        "语料上链式重放 121 批里有 10 批停在这里，每次 1~3 格、全在底条那一行、全是 ACTION6 那一步。"
        "这是 apply 协议的一个尖角——「没变」在协议里只能写成「等于输入帧的那个值」，"
        "所以任何声称一整片没变的概念，都在替这一片里它算不出的格子背书。"
        "缩掉之后底条永远算残差（E 少一点），但它本来就没人算得出，"
        "写成残差是实话，写成主张是替无知担保。")
EVIDENCE = ["11131d8a77ef8941", "e5ff3c1e07eebdb9", "fe16f35839177fa9"]

from _lib import (selected_core, sprite_at, sprites, board_box, players,
                  hud_top, hud_icons, hud_groups, rope_color,
                  SEL_FILL, IDLE_FILL, CELL, repaint_pending, uncomputable_cells)


def _xy(action):
    try:
        x, y = action.split(":")[1].split(",")
        return int(x), int(y)
    except Exception:
        return None


def _hit(prev, action):
    """这一击点中的芯色，以及当时选中的芯色；读不出来返回 None。"""
    if not action.startswith("ACTION6"):
        return None
    xy = _xy(action)
    if xy is None:
        return None
    cur = selected_core(prev)
    if cur is None:
        return None
    return sprite_at(prev, xy[0], xy[1]), cur


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    h = _hit(prev, action)
    if h is None:
        return "NA"
    hit, cur = h
    if hit is None or hit == cur:
        return "TRUE" if prev == nxt else "FALSE"      # 点空 / 点已选中的：帧必须全同
    if prev == nxt:
        return "FALSE"                                 # 点中别人却什么都没发生
    return "TRUE" if selected_core(nxt) == hit else "FALSE"


def _ring(r, c):
    """精灵内圈那 12 格（2×2 芯外面围一圈）的像素坐标。"""
    out = [(r - 1, cc) for cc in range(c - 1, c + 3)]
    out += [(r + 2, cc) for cc in range(c - 1, c + 3)]
    out += [(rr, c - 1) for rr in (r, r + 1)]
    out += [(rr, c + 2) for rr in (r, r + 1)]
    return out


def _rope_of(g, r, c, core):
    """假设：每个精灵（盘上的玩家、示意图里的图标）身上都拴着一根同花纹的绳，
    从它 6×6 框的边缘那一列/行起算第 0 节；盘上的按 players() 给的节数，图标按它那一组的靶槽数。
    返回 [(行, 列, 节号, 下面那半)]；读不出来返回 None。"""
    b = board_box(g)
    if b is None:
        return None
    rt, lf = r - 2, c - 2
    ht = hud_top(g)
    n, down = None, False
    if ht is not None and rt == ht:                      # 示意图里的图标：绳往右画
        icons, groups = hud_icons(g), hud_groups(g)
        if icons is None or groups is None:
            return None
        for (x, _ic), (_gc, slots) in zip(sorted(icons), groups):
            if x == lf:
                n = len(slots)
    else:                                                # 盘上的玩家
        ps = players(g)
        if ps is None:
            return None
        for pc, kind, _pos, pn, _sel in ps:
            if pc == core:
                n, down = pn, (kind == 'v')
    if n is None:
        return None
    out = []
    for k in range(CELL * n + 1):
        if down:
            out.append((rt + CELL - 1 + k, lf + 2, k, True))
            out.append((rt + CELL - 1 + k, lf + 3, k, False))
        else:
            out.append((rt + 2, lf + CELL - 1 + k, k, False))
            out.append((rt + 3, lf + CELL - 1 + k, k, True))
    return out


def apply(prev, action, ctx=None):
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    h = _hit(prev, action)
    if h is None:
        return None
    hit, cur = h
    H, W = len(prev), len(prev[0])
    if hit is None or hit == cur:
        skip = uncomputable_cells(prev)              # 底条不照抄：见 v4
        return {(r, c): prev[r][c] for r in range(H) for c in range(W)
                if (r, c) not in skip}
    out = {}
    for r, c, core, _fill in sprites(prev):
        if core not in (cur, hit):
            continue
        sel = (core == hit)                              # 换人之后它选没选中
        for rc in _ring(r, c):
            if 0 <= rc[0] < H and 0 <= rc[1] < W:
                out[rc] = SEL_FILL if sel else IDLE_FILL
        pix = _rope_of(prev, r, c, core)
        if pix is None:
            return None
        for rr, cc, k, lower in pix:
            if not (0 <= rr < H and 0 <= cc < W):
                continue
            if prev[rr][cc] != rope_color(k, lower, not sel):
                continue                                 # 靶盖着 / 不是绳：不表态
            out[(rr, cc)] = rope_color(k, lower, sel)
    return out
