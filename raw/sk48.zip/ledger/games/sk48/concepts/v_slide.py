"""选中的是挂在棋盘上边横轨的那个玩家时，ACTION3/ACTION4 让它连同整根竖绳往左/右整体挪恰好一格列，绳的节数不变。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3 和 ACTION4；换关返回 NA；players()/sel_player() 读不出来返回 NA；"
         "**选中的不是竖玩家就返回 NA**（那时这两个键是横玩家的绳缩/伸，归 a3_retract、a4_extend 管）；"
         "要挪出棋盘（目标格列越界）返回 NA——语料里还没试过，不表态。"
         "只说这个玩家和它的绳；盘上的靶会不会被绳横向刮走，本条不表态。")
NOTE = ("由来：第 865 步 ACTION3 让它从格列 3 挪到 2，第 866、867 步两次 ACTION4 挪回 3、再到 4，"
        "三步的帧差都是一百二十格上下——玩家精灵、上边横轨、整根绳一起换了位置。\n"
        "这一条是四个方向键统一读法的最后一块：**方向是屏幕方向，作用对象是被选中的那个玩家**，"
        "而「上下」对横玩家是沿轨移动、对竖玩家是绳的伸缩，「左右」正好反过来。"
        "两个玩家各挂在自己那条轨上，轨的方向决定了哪两个键是走、哪两个键是伸缩。\n"
        "**留白**：这三步里绳只伸下 2~3 节、扫过的格里一颗靶都没有，"
        "所以「绳横着刮过去会不会把靶带走或被靶挡住」一次都没量过。"
        "横向那边的对应事实（竖绳把靶钉住、横杆扫过去把靶顶走）说明这里很可能有话要说，"
        "但那要另立一条，且要先赶上一步真的刮到靶的转移。\n"
        "v2：**只加 apply，断言一个字没动**。由来是两次实测的漏：第 910、925 步都是空绳的竖玩家横挪一格列，"
        "整帧各变 73 格，而全册一个像素都没说（押注里写着「预测 0 格 ← 没有概念开口」）。"
        "这条概念判得出来却生成不出来，正是「检查器不说错话、生成器不表态」那种静默洞，"
        "而路线上这样的挪动还剩八次。\n"
        "**apply 只认领玩家自己那个 6×6 精灵框**：旧位置整块退回上边横轨的底色（走 _lib.bg_at），"
        "新位置照抄旧位置那 36 个像素（精灵横挪不换样子）。"
        "第一版把旧位置一律写成色 5，在五步横挪上各说错 12 格——上边横轨正中那两行有花纹"
        "（每 6 列头两列 2、后四列 3），正是左边竖轨那条花纹转 90 度；"
        "改的是词 `bg_at`（补上横轨那一支），这里只管调用它。"
        "绳那两像素列**故意不认领**——绳长 0 时它压根不在盘上（路线上八次挪动都是空绳），"
        "绳长 >0 时绳会不会刮到靶正是上面那段留白，没量过就不表态。"
        "所以绳长 >0 的那几步这条只解释一部分帧差，剩下的照旧算残差，那是诚实的欠账不是错。\n"
        "v3：**上面那段留白填了，所以绳那两像素列现在认领了**，断言仍然一个字没动。"
        "填它的是 vslide_blocks（第 987 步：绳横扫会把靶带走、也会把靶顶开），"
        "以及第 1004、1026 两步逐格量出来的画法：\n"
        "  · 旧列那 6n×2 个像素**整列退回棋盘底色**（连原来压着靶的那几行也是——靶跟着走掉了）；\n"
        "  · 新列那 6n×2 个像素**按 vrope_map 画**；\n"
        "  · 两根绳交叉处露出来的是**横杆的颜色**（第 1026 步实测 2/3/3/2）——画的顺序是"
        "靶盖横杆、横杆盖竖绳、竖绳盖棋盘，所以横杆那几个像素按 _lib.hrope_map 画；\n"
        "  · 挪完被靶盖住的像素**不认领**，让给 vslide_blocks，省得两条概念对同一格各说一色。\n"
        "为此 apply（**只有 apply**）借了 vslide_blocks 的词 vslide_map 来问「哪些像素挪完被靶盖着」——"
        "断言里没有一个字提靶，scope 也没变：这一条仍然只主张「玩家连同整根绳整体挪一格列」。"
        "**代价说清**：借来的那条规矩要是错了，这里也会跟着说错格；那正是它该有的样子，"
        "一条规矩错了应当有两处显形。同一版补上 slide_ok 守卫：说挪不动（目标列有墙、推链会顶出棋盘）就不开口，"
        "老写法会照着「挪了」画一整块——语料里还没赶上这种步，是防患不是补漏。")
EVIDENCE = ["123fc813a0c1aa1e", "f75b1402e82d8215", "b9fa25944fed90b6",
            "b706d1adfcb561cd", "f3fbf4ef485fe8a7"]

from _lib import (players, sel_player, ncols, board_box, sprites, bg_at, CELL,
                  cell_topleft, hrope_map, slide_ok, vrope_map, vslide_map,
                  repaint_pending)


def _sel_v(g):
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.startswith("ACTION3"):
        d = -1
    elif action.startswith("ACTION4"):
        d = 1
    else:
        return "NA"
    p = _sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    nc = ncols(prev)
    if nc is None or not (0 <= cc + d < nc):
        return "NA"
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v':
        return "FALSE"
    return "TRUE" if (q[0][2], q[0][3]) == (cc + d, n) else "FALSE"


def _frame(g, cc):
    """在格列 cc 上那个竖玩家的 6×6 精灵框左上角；找不到返回 None。"""
    b = board_box(g)
    if b is None:
        return None
    top, _, left, right = b
    for r, c, _core, _fill in sprites(g):
        rt, lf = r - 2, c - 2
        if rt < top and lf == left + CELL * cc:
            return rt, lf
    return None


def apply(prev, action, ctx=None):
    """玩家那个 6×6 精灵框整块挪一格列：新位置照抄旧位置的像素，旧位置退回横轨底色。
    绳那两像素列（v3 起）：旧列退回棋盘底色、新列按 vrope_map 画，
    横杆盖着的按横杆的色画，挪完被靶盖着的不认领（归 vslide_blocks）。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if action.startswith("ACTION3"):
        d = -1
    elif action.startswith("ACTION4"):
        d = 1
    else:
        return None
    p = _sel_v(prev)
    if p is None:
        return None
    _, _, cc, _n, _ = p
    nc = ncols(prev)
    if nc is None or not (0 <= cc + d < nc):
        return None
    if slide_ok(prev, d) is not True:
        return None                      # 说挪不动（或没把握）：这一步不开口
    f = _frame(prev, cc)
    if f is None:
        return None
    rt, lf = f
    W = len(prev[0])
    lf2 = lf + CELL * d
    if not (0 <= lf2 and lf2 + CELL - 1 < W):
        return None
    out = {}
    for dr in range(CELL):
        for dc in range(CELL):
            out[(rt + dr, lf2 + dc)] = prev[rt + dr][lf + dc]
    for dr in range(CELL):
        for dc in range(CELL):
            rc = (rt + dr, lf + dc)
            if rc not in out:
                v = bg_at(prev, rc[0], rc[1], with_ropes=False)
                if v is None:
                    return None
                out[rc] = v
    _rope(prev, d, cc, _n, out)
    return out


def _rope(prev, d, cc, n, out):
    """把绳那两像素列画进 out；画不出来就原样返回（只交精灵那一块，v2 的老行为）。"""
    old_rope = vrope_map(prev, cc, n)
    new_rope = vrope_map(prev, cc + d, n)
    hr = hrope_map(prev)
    after = vslide_map(prev, d)          # 借 vslide_blocks 的词：挪完哪一格上有靶
    if old_rope is None or new_rope is None or hr is None or after is None:
        return
    covered = set()
    for (r, c) in after:
        tl = cell_topleft(prev, r, c)
        if tl is None:
            return
        for dr in range(4):
            for dc in range(4):
                covered.add((tl[0] + dr, tl[1] + dc))
    for rc in old_rope:
        if rc in out or rc in covered:
            continue
        if rc in hr:
            out[rc] = hr[rc]             # 横杆盖在竖绳上面
            continue
        v = bg_at(prev, rc[0], rc[1], with_ropes=False)
        if v is None:
            continue
        out[rc] = v
    for rc, color in new_rope.items():
        if rc in out or rc in covered:
            continue
        out[rc] = hr[rc] if rc in hr else color
