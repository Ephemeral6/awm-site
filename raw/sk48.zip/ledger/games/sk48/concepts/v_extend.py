"""选中的是挂在棋盘上边横轨的那个玩家时，ACTION2 让它那根竖绳往下多伸一节（玩家自己不动、格列不变）；除非新绳尖要落进的那一格是墙，那时一节都不伸。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION2；换关返回 NA；players()/sel_player() 读不出来返回 NA；"
         "**选中的不是竖玩家就返回 NA**（那时 ACTION2 是横玩家下移一格行，归 a2_down 管）；"
         "竖绳已经伸满整列（n >= 行数）返回 NA——那种局面语料里还没出现过，不表态。"
         "**只说这根绳自己的几何**：绳尖底下那颗靶被顶到哪去了归 v_push 管，另一个玩家怎么样也不管。")
NOTE = ("由来：第 5 关盘上第一次同时有两个玩家，方向键作用在被选中的那一个身上。"
        "第 859 步点中上边那个玩家之后，连按四次 ACTION2："
        "n 从 1 长到 2、再到 3，第三次整帧只有钟走了、第四次整帧一格没变——"
        "而它当时在格列 3，墙正好在 (3,3)，也就是它 n=3 时新绳尖要落进的那一格。"
        "所以这条是 a4_extend 转 90 度：同一个『落点是墙就一节都不伸』。\n"
        "**这一批之前，全册对竖玩家一句话都说不出来**（lens predict 四个方向键全是 0 格、没有概念开口），"
        "而且不是因为世界简单，是因为读数瞎了：横绳那个词按色 (1,2) 找绳子，"
        "横玩家一旦没被选中，它那根绳整体换成 2/3，词当场返回 None，建在它上面的概念集体噤声。"
        "修的是词（rope_tip 改成只看几何），核账见它自己的由来。\n"
        "**最可能死在哪**：新绳尖那一格上压着一颗推不动的靶时会怎样，至今一次都没试过——"
        "语料里唯一一次绳尖撞上靶（第 869 步），那颗靶下面是空的、被顶走了。"
        "如果推不动时动作被整个拒掉，这条会在那一步判 FALSE，那时该缩的是这里而不是 v_push。\n"
        "v2：**只改 apply，断言一个字没动**。第 875、876 步它判 TRUE（绳的几何确实对了），"
        "而它的 apply 说错了 16 格——杆上一颗靶跟着绳尖挪下来，盖住了它刚画上去的那一节绳子。"
        "那条规律另立了 v_carry；这里补的是 apply 的自知之明：绳尖那一格上会不会落下一颗靶，"
        "现在先问 vpole_map 一句，会落就闭嘴。\n"
        "留一句自省：这条概念的 scope 明写「只说这根绳自己的几何」，所以它判 TRUE 没有错；"
        "**错在全册当时没有任何一条对那两步的靶说话，而 settle 报的是「0 条反例、闸开着」**。"
        "抓住它的是 P（说错 16 格）不是 S。检查器可以靠缩 scope 一直不说错话，生成器不行——"
        "它必须把话说到像素上。以后再遇到「零反例而盘面明明变了」，先看 P 和残差。\n"
        "v3：**又是只改 apply，断言一个字没动**。新伸的这一节要是横穿了横杆，"
        "那 4 个像素上画的是横杆不是绳（第 1026 步量出来的画序：靶盖横杆、横杆盖竖绳、竖绳盖棋盘），"
        "v2 一律按绳色画，在第 1034 步说错 2 格——另 2 格蒙对了，因为交叉处横杆那一行的花纹恰好也是 2。"
        "**蒙对的那两格比说错的那两格更值得记**：全册说错数从 0 变 2 时我以为是刚改的 v_slide 干的，"
        "回头一查 settle6 里就有——一个只在唯一一步上现形、还自带一半伪装的洞，"
        "靠盯总数盯不出来，是把 apply 拉到全语料上逐格比才掉出来的（runs/…/findwrong.py）。\n"
        "这也是为什么它非修不可：终局卡上预测错一格就停批（退出码 5），"
        "2 格和 200 格一样能把一批停掉。")
EVIDENCE = ["829eb9fd19aa7491", "6a57ede9b8236adb", "3b0942e599c1bc3a",
            "95018f7b84a9eab3", "9ffa4ac4b68d6fcb", "93778eca4e036704",
            "c6898ee4c58523a2", "96cf21572db7dad2"]

from _lib import (players, sel_player, walls, nrows, cell_map, vrope_map,
                  vpole_map, cell_topleft, board_box, hrope_map, CELL,
                  repaint_pending)


def _sel_v(g):
    """选中的那个玩家，且它是竖的；否则 None。"""
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    p = _sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    nr, w = nrows(prev), walls(prev)
    if nr is None or w is None or n >= nr:
        return "NA"
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v':
        return "FALSE"
    want = (cc, n) if (n, cc) in w else (cc, n + 1)
    return "TRUE" if (q[0][2], q[0][3]) == want else "FALSE"


def apply(prev, action, ctx=None):
    """多出来的这一节绳子占的像素。绳尖那一格上会落下一颗靶时（杆上的靶跟着绳尖挪下来，
    见 v_carry），那颗靶盖住的 8 个像素不算数——那 8 格归 v_carry 画，这里只留露在外面的 4 格。
    横杆压在这一节上的那几个像素（v3 起）按横杆的色画，不按绳色：画的顺序是靶盖横杆、横杆盖竖绳。
    绳尖那一格原本就压着靶的情形整条不开口，留给 v_push / v_capture。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION2"):
        return None
    p = _sel_v(prev)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, w, m, b = nrows(prev), walls(prev), cell_map(prev), board_box(prev)
    if nr is None or w is None or b is None or n >= nr:
        return None
    if (n, cc) in w or (n, cc) in m:
        return None
    after = vpole_map(prev, +1)
    if after is None:
        return None
    full = vrope_map(prev, cc, n + 1, True)
    if full is None:
        return None
    hr = hrope_map(prev)
    if hr is None:
        return None
    hide = set()
    if (n, cc) in after:                       # 有靶要挪进绳尖那一格
        tl = cell_topleft(prev, n, cc)
        if tl is None:
            return None
        t0, l0 = tl
        hide = {(t0 + dr, l0 + dc) for dr in range(4) for dc in range(4)}
    top = b[0]
    lo, hi = top + CELL * n, top + CELL * (n + 1)
    return {rc: (hr[rc] if rc in hr else v) for rc, v in full.items()
            if lo <= rc[0] < hi and rc not in hide}
