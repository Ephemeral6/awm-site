"""选中的是挂在棋盘上边横轨的那个玩家时，ACTION1 让它那根竖绳往回缩恰好一节（玩家自己不动、格列不变）。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1；换关返回 NA；players()/sel_player() 读不出来返回 NA；"
         "**选中的不是竖玩家就返回 NA**（那时 ACTION1 是横玩家上移一格行，归 a1_up 管）；"
         "绳已经缩到 n=0 返回 NA——那种局面语料里还没出现过，不表态。"
         "只说这根绳自己的几何；空出来那一格里的靶会不会跟着被带上去，本条不表态。")
NOTE = ("由来：第 869 步那一批之前的第 864 步，竖绳 n 从 3 缩回 2，帧差 12 格，玩家一格没动。"
        "这是 a3_retract 转 90 度。\n"
        "**只有一条转移撑着**（N 会很小），而且横向那边的同一个动作是会**拖着靶一起走**的"
        "（缩绳把杆上的靶整串往左带）。竖向会不会也这样，语料里一次都没赶上——"
        "第 864 步缩掉的那一格是空的。所以这条现在说的是「绳自己怎么变」，"
        "靶跟不跟着走留白；等哪一步在有靶的格上缩绳，那一步要么给它补一条，要么把它推翻。\n"
        "v2：**只放宽 apply，断言一个字没动**。留白已经由 v_drag 补上了（杆上的靶跟着走），"
        "所以「那一格上有靶就不开口」这条自保没必要再留着——它留下的洞是实测出来的："
        "第 909 步绳 1→0、那颗靶顶在格行 0 挪不动，整帧只变 4 格（绳那两列露在 4×4 靶外面的头尾两行），"
        "而全册当时一个像素都没说，那一条转移成了地图上的无人区。"
        "现在改成：靶留在原地就只认领露在它外面的那几格，靶走掉就认领整节绳的 12 格；"
        "两种情形都是「这一节绳不再盖着那一格」，颜色一律是底色，和 v_drag 画的重合处给的值相同、不打架。\n"
        "同一次还改掉了 v1 apply 里一处**一直是错的**取色：它用 `bg_at(prev, …)` 问底色，"
        "而 bg_at 的语义是「此刻这一格空着会是什么色」——此刻绳还盖在那里，它返回的是绳色。"
        "缩绳之后那两列露出的是棋盘底色 4。放宽 scope 之后这处错当场以「认领 100 格、说错 100 格」爆出来。"
        "**它在 v1 里躺了整整一版没被任何数字发现**：v1 唯一会开口的那条转移正是它自己的 EVIDENCE，"
        "而 settle 的 P 只在 held-out 上算——生成器可以在自己的依据上一直说错话而 P 显示「认领 0 格」。"
        "以后写 apply，先在**自己的 EVIDENCE** 上逐格对一遍，别等 held-out 来判。\n"
        "v3：**还是只改 apply，断言一个字没动**。缩掉的那一节要是横穿了横杆，"
        "露出来的不是棋盘底色 4 而是横杆（画序：靶盖横杆、横杆盖竖绳、竖绳盖棋盘，第 1026 步实测）。"
        "第 1052 步为此说错 4 格。**这已经是同一个洞的第三次**——v_slide、v_extend、这里，"
        "三条概念各自把「绳撤走之后露出什么」写死成一种底色，而正确答案要问横杆在不在那儿。"
        "第一次是逐格量出来的，第二次是全语料扫 apply 扫出来的，第三次是照着前两次直接找的。"
        "教训不是「记得横杆盖竖绳」，是**同一个像素被几层东西盖着时，别在每条概念里各写一遍谁在上面**——"
        "该有一个词回答「这一格露出来是什么」；现在的做法是每条概念自己问 hrope_map，"
        "还差一步，但至少三处的答案是同一个函数给的。")
EVIDENCE = ["b151bdfdcef25bb8", "49236ea04ec1de51"]

from _lib import (players, sel_player, board_box, cell_map, CELL,
                  cell_topleft, hrope_map, vpole_map, repaint_pending)


def _sel_v(g):
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION1"):
        return "NA"
    p = _sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    if n <= 0:
        return "NA"
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v':
        return "FALSE"
    return "TRUE" if (q[0][2], q[0][3]) == (cc, n - 1) else "FALSE"


def apply(prev, action, ctx=None):
    """缩掉的那一节绳（原来的绳尖那一格）不再盖着它，露出的是棋盘底色——
    横杆压在那儿的几个像素露出的是横杆（v3 起）。
    那一格上留着一颗挪不动的靶时，只认领露在那颗 4×4 外面的几格——靶自己归 v_drag 说。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION1"):
        return None
    p = _sel_v(prev)
    if p is None:
        return None
    _, _, cc, n, _ = p
    b = board_box(prev)
    hr = hrope_map(prev)
    if b is None or hr is None or n <= 0:
        return None
    hide = set()
    if (n - 1, cc) in cell_map(prev):
        after = vpole_map(prev, -1)
        if after is None:
            return None
        if (n - 1, cc) in after:                 # 靶留在原地，它那 4×4 盖住的不算
            tl = cell_topleft(prev, n - 1, cc)
            if tl is None:
                return None
            t0, l0 = tl
            hide = {(t0 + dr, l0 + dc) for dr in range(4) for dc in range(4)}
    top, bottom, left, right = b
    c0 = left + CELL * cc + 2
    out = {}
    for k in range(CELL * (n - 1), CELL * n):
        for j in (0, 1):
            r, c = top + k, c0 + j
            if (r, c) in hide:
                continue
            if not (top <= r <= bottom and left <= c <= right):
                return None
            out[(r, c)] = hr.get((r, c), 4)      # 盘内、绳撤走之后 = 横杆或棋盘底色
    return out
