"""ACTION1/ACTION2 让玩家动，当且仅当 move_ok 成立：玩家自己不出盘、杆扫过去要盖住的那一行里杆下（格列 0..n-1）没有墙、且绳子这根横杆扫到的每一串靶都推得动（串里没有一块会被顶出棋盘）。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1/ACTION2；换关返回 NA；绳尖不在盘内或定位不到返回 NA；"
         "**此刻方向键作用的不是横玩家（h_selected 不为 True）返回 NA** —— "
         "那时 ACTION1/2 是竖玩家的绳缩/伸，归 v_retract、v_extend 管")
NOTE = ("v3 死于第 363 步（f9c757762d16cd94）：第 4 关，玩家在空的第 4 行、绳伸满 n=7，"
        "往上朝第 3 行扫——v2 说 move_ok 成立（没人出盘、该被顶的三块 8 上面全空），实际动作被直接拒，"
        "整帧一格没变（连钟都没走）。第 3 行的格列 3 是那堵 W5。"
        "拒的原因当时有两种读法：挡住的是墙，还是杆扫不进有靶的行。"
        "把全语料里『竖移且目标行杆下有东西』的转移排成一张表：33 条，其中 30 条目标行杆下有靶没有墙，"
        "玩家**全都照走**（靶被杆顶走，vmoved_cells 早就这么写着）；另外两条（第 10 / 185 步，同一条重走）"
        "被拒的原因是推链顶出棋盘，本来就在 move_ok 里。所以靶不挡，墙挡——语料里唯一一堵墙只在第 4 关，"
        "这也正是这条概念活到第 363 步才挨打的原因。"
        "改的是 _lib.move_ok，主张跟着加了一句；『杆下』这个限定还没检验过，"
        "另一种读法是『目标行里只要有墙就过不去』——把绳缩到 n=3（盖不住格列 3 那堵墙）再往那一行扫一次就分得开，"
        "这一步紧接着就走。"
        "v2：只改了措辞。move_ok 的判据随 _lib 从『绳尖前方那一串』换成『杆下每一列各自的串』"
        "（vmove_blocks v2 的同一次修正），断言本身一个字没动，第 10 步那次被拒仍然是它的依据。"
        " || v4 是**被推翻后缩的**：七条反例全在第 5 关，全是同一件事——那一批被选中的是第二个玩家，"
        "ACTION1/2 作用在它身上（伸缩它那根竖绳），横玩家一格没动，"
        "而 v3 里 move_ok 说「动得了」，于是判 FALSE。"
        "这条从来说的都不是『ACTION1/2 让玩家动』，而是『方向键作用在横玩家身上时，ACTION1/2 让它动』。"
        "判据是 h_selected。竖玩家什么时候滑得动，是另一条概念的事，此刻还没人写。\n"
        "v5 死于 1bc3387069dfd74f：玩家在格行 4 往下走，move_ok 说动得了（不出盘、没墙、没有推链顶出去），"
        "实际整帧零格——动作被世界整个拒掉。**漏的是第三个条件：玩家只能停在轨上那条花纹带覆盖的格行里。**"
        "带子一直在那儿，此前每个场景它都铺满整条轨，于是「不出盘」和「不出带」在语料里同分布，分不开；"
        "新场景第一次把带子缩到三个格行，一步之内同时打死三条概念。"
        "改的是 _lib.move_ok（加一句 vrail_span 区间判断）与新词 vrail_span/hrail_span，"
        "断言本身一个字没动——它说的一直是「当且仅当 move_ok 成立」，错的是 move_ok 少数了一条。"
        "带子读法在全语料 731 条转移上核过：**玩家落在带外的次数 0**，所以收紧不冤枉任何一条既有转移。")
EVIDENCE = ["210e539c12d2ca36", "7f7e3f01bb9d54d9", "f9c757762d16cd94",
            "3b0942e599c1bc3a", "6a57ede9b8236adb", "829eb9fd19aa7491",
            "95018f7b84a9eab3", "9ffa4ac4b68d6fcb", "b0bb1879238eb3c0",
            "b151bdfdcef25bb8", "1bc3387069dfd74f"]

from _lib import me, move_ok, h_selected


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.startswith("ACTION1"):
        d = -1
    elif action.startswith("ACTION2"):
        d = 1
    else:
        return "NA"
    if h_selected(prev) is not True:
        return "NA"
    ok = move_ok(prev, d)
    if ok is None:
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if (a != b) == bool(ok) else "FALSE"
