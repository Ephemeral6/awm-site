"""竖绳往下伸的那一节，绳尖要落进的格上压着靶时，从那颗靶起沿这一列往下连续的一串靶整串下移一格；除非这一串里有一颗钉在横杆上（或它的落点被横杆盖着），那时整串一颗不动、绳照样伸下去。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION2；换关返回 NA；players()/sel_player()/cell_map 读不出来返回 NA；"
         "**选中的不是竖玩家就返回 NA**；新绳尖那一格是墙、或那一格上没有靶，返回 NA（没有靶就没有推挤可言）；"
         "串里有一颗要被顶出棋盘下边缘、或要顶进墙里，**v4 起照样表态**（说：那一颗连同它前面的一串原地不动）。"
         "只说这一列上靶的落点，不说绳子怎么画、也不说别的列。")
NOTE = ("由来：第 869 步。竖玩家在格列 4、绳伸下 3 节，新绳尖要落进的 (3,4) 上压着一颗色9，"
        "按下 ACTION2 之后色9 出现在 (4,4)，绳尖盖住了 (3,4)。"
        "这正是横向那条推挤规律（伸绳撞上靶就把它连着往前顶）转 90 度。\n"
        "**押注押的就是这一条**，而且当时明写了另外两种可能的样子：靶不动而绳串上它、或者整帧不动。"
        "世界给的是「顶走」。\n"
        "**只有一条转移撑着，而且串长只有 1**：整串一起走这件事是从横向那边借来的类比，"
        "在竖向一次都没验过。链长 ≥2 的那一步是它最该去撞的地方。\n"
        "v2：**只加 apply，断言一个字没动**。由来是一次押注前的自查：给「绳尖顶着一颗靶往下走」"
        "那一串动作预押注时，输出写着「预测 0 格 ← 没有概念开口」——绳尖那一格有靶时 v_extend 按 scope 闭嘴，"
        "而这条和 v_capture 都只判不生成，于是整批四步全册一个像素都不敢说。"
        "**这正是 v_carry 那次险些溜过去的同一种洞**：检查器判 TRUE、生成器不表态，"
        "settle 报 0 条反例，而盘面明明整块在变。所以这里补的是生成器："
        "串上每颗靶的新落点画 4×4，绳尖腾出来的那一格画成「绳子 + 底色」——伸绳之后那一格归绳子盖。"
        "腾空那一格只认领它真会变的那些像素（绳占的两列 + 原来那颗靶的 4×4），"
        "剩下的底色格本来就没变，认领它们只会把 P 的分母灌水。\n"
        "v3：**上面那句「链长 ≥2 的那一步是它最该去撞的地方」应验了，撞法却不是我以为的那种。**"
        "第 1058、1059 两步各判 FALSE：绳尖落进的格上那颗靶**一格没动，被串上了**"
        "（侧栏里它那一格从色号变成 0），而这条按 v1 的算法说整串下移。"
        "断错的不是「整串一起走」，是**漏了一个前提**：串里第二颗（14）正钉在横杆上，"
        "而钉在横杆上的靶伸缩搬不动（第 986 步实测，写在词 vpole_now 里），它一卡，"
        "排在它前面的那颗也就走不成，于是绳尖那一格的靶原地被串上。\n"
        "**这条反例真正照见的不是这条概念，是我自己**：规划器 sim8 里早就有这条卡住规则"
        "（不然它算不出第 1058 步之后靶不动），是我从 vpole_now 里读来直接写进搜索的，"
        "却没回头把同一件事写进这条概念的断言。世界事实漏在规划器里而不在概念里，"
        "闸就照不到它——照到它的是世界本身，晚了整整一批。"
        "改法是把断言整个换成问词 vpole_map（它已经把「钉住 / 出盘 / 撞墙 / 前面那颗没走成」四种走不成"
        "一起结算了），这一条从此不再自己算链，只声称「这一步的落点等于 vpole_map 说的那样」。\n"
        "v4：**动手之前把话说宽，不是挨了打才改**。下一步（第 1129 步）正要撞进 v3 明写「不表态」的那一格局面："
        "绳尖那一格上的靶就在棋盘最下一行，再往下就出盘了。写押注时看见「这一步全册只预测 4 格」，"
        "回头去问词——`vpole_map(+1)` 早就把这一局面结算得清清楚楚（顶不动的那颗原地不动、"
        "和它不相连的那颗照常下移），而 assert_ 里那道「链尾抵边就返回 NA」的闸把这句话拦在了闸外。"
        "**这就是 v3 那条反例照见的同一个毛病换了个位置**：世界事实躺在词里、躺在规划器里，"
        "唯独没躺在任何一条走闸的概念里，于是它一次都没被判过。"
        "既然断言早就整个委托给 vpole_map，这道闸只是让它闭嘴，删掉即可；"
        "落空的样子：这一颗被顶出去、或者整列一颗不动、或者整个动作被拒。\n"
        "同一版还给 apply 补了换关那道闸：闸一放宽，它就在第 1064 步那张**换关重画帧**上开了口，"
        "画错 4 格（全册第一次出现「说错」非零）。assert_ 在那一帧按 scope 判 NA，apply 却照画不误——"
        "**检查器守着 scope、生成器没守**，这是同一条概念里两张嘴说不同的话。"
        "换关帧整屏重画，这一条从不声称管它，所以 apply 也照 scope 闭嘴。")
EVIDENCE = ["9ffa4ac4b68d6fcb", "9687680d8b27816e", "558d5bccd90cd5bc"]

from _lib import (players, sel_player, walls, nrows, cell_map, board_box,
                  cell_topleft, vrope_map, vpole_map, hrope_map, bg_at, CELL,
                  repaint_pending)


def _sel_v(g):
    p = sel_player(g)
    return p if (p is not None and p[1] == 'v') else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    p = _sel_v(prev)
    if p is None:
        return "NA"
    _, _, cc, n, _ = p
    nr, w = nrows(prev), walls(prev)
    m, m2 = cell_map(prev), cell_map(nxt)
    if nr is None or w is None or m is None or m2 is None:
        return "NA"
    if n >= nr or (n, cc) in w or (n, cc) not in m:
        return "NA"
    want = vpole_map(prev, +1)              # 钉住 / 卡住 / 出盘 / 撞墙 由词自己结算（v4 起）
    if want is None:
        return "NA"
    return "TRUE" if want == m2 else "FALSE"


def _case(prev):
    """这一条管不管这一步：管，就返回 (格列, 绳长)；不管返回 None。
    条件与 assert_ 逐条同源，只是不看 nxt。"""
    p = _sel_v(prev)
    if p is None:
        return None
    _, _, cc, n, _ = p
    nr, w, m = nrows(prev), walls(prev), cell_map(prev)
    if nr is None or w is None or m is None:
        return None
    if n >= nr or (n, cc) in w or (n, cc) not in m:
        return None
    return cc, n


def apply(prev, action, ctx=None):
    """v3：落点一律问 vpole_map（整串走得成就各下移一格，卡住就一颗不动）。
    画三样：落点变了的格整块 4×4 涂新色；腾空的格退回它底下那一层（横杆 > 竖绳 > 棋盘底色）；
    新伸的那一节绳里没被靶盖住的像素。靶盖横杆、横杆盖竖绳，是第 1026 步量出来的画序。"""
    if not action.startswith("ACTION2"):
        return None
    if repaint_pending(prev, action, ctx):
        return None                                  # 换关那一帧是整屏重画，这一条不画；预测口径下 ctx 说不出，只能问册子
    case = _case(prev)
    if case is None:
        return None
    cc, n = case
    m = cell_map(prev)
    want = vpole_map(prev, +1)
    rope = vrope_map(prev, cc, n + 1, True)
    hr = hrope_map(prev)
    b = board_box(prev)
    if want is None or rope is None or hr is None or b is None:
        return None

    def box(r, c):
        tl = cell_topleft(prev, r, c)
        if tl is None:
            return None
        t0, l0 = tl
        return [(t0 + dr, l0 + dc) for dr in range(4) for dc in range(4)]

    out = {}
    for (r, c), color in want.items():               # 1) 落点变了的格
        if m.get((r, c)) == color:
            continue
        px = box(r, c)
        if px is None:
            return None
        for rc in px:
            out[rc] = color
    covered = set()
    for (r, c) in want:
        px = box(r, c)
        if px is None:
            return None
        covered.update(px)
    for (r, c) in m:                                 # 2) 靶走掉腾空的格
        if (r, c) in want:
            continue
        px = box(r, c)
        if px is None:
            return None
        for rc in px:
            if rc in out or rc in covered:
                continue
            if rc in hr:
                out[rc] = hr[rc]
            elif rc in rope:
                out[rc] = rope[rc]
            else:
                v = bg_at(prev, rc[0], rc[1], with_ropes=False)
                if v is None:
                    return None
                out[rc] = v
    lo, hi = b[0] + CELL * n, b[0] + CELL * (n + 1)   # 3) 新伸的那一节绳
    for rc, color in rope.items():
        if not (lo <= rc[0] < hi) or rc in out or rc in covered:
            continue
        out[rc] = hr[rc] if rc in hr else color
    return out
