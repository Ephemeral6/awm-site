"""ACTION1 对玩家方块只有两种可能：整体上移恰好 CELL 行（列不变、绳节数不变），或者原地不动；不会有第三种位移。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1；换关返回 NA；me() 或 rope_tip() 定位不到返回 NA。"
         "**什么时候动归 move_block 管**，这一条只管动起来长什么样；也不管棋盘以外的层（钟、示意图）。")
NOTE = ("v4：删掉『或者整帧不动』那条兜底。它把「动作被拒」偷换成「屏幕上什么都没变」，"
        "而盘上有一只每 3 个动作走一格的钟——同一个物理情形（玩家没动），钟走的那一步判 FALSE、"
        "钟不走的那两步判 TRUE，判决被一个和主张毫不相干的计数器的相位决定。"
        "v4 把对象从「整帧」缩到「玩家方块」，于是不动这件事说得干净了；"
        "代价是这条概念不再回答『什么时候动』——那句话归 move_block，本来也该归它。"
        "它仍然可判错：位移不是 0 也不是恰好一格、列变了、绳节数变了，都是反例。"
        "v3：apply 不再往靶块像素上画绳子——靶压在绳子上面（第 15 步：绳尖同格的靶被带着上移，绳子那 8 格被它盖住）。"
        "v2：apply 加上 move_ok 守卫。v1 的 apply 在第 10 步（推链顶到盘外、动作被拒）上把 192 格全说错了——"
        "assert_ 没错（『或整帧不动』兜住了），错的是生成器不知道什么时候不该开口。"
        "第 363 步又栽了一次同样的跟头（说错 240 格而 assert_ 判 TRUE），"
        "因为 move_ok 当时还不知道墙挡竖扫；那是 _lib 的漏，补在 move_ok 里。"
        " || v5 只改 apply，断言一个字没动。第 5 关方向键作用在第二个玩家身上时，"
        "ACTION1 伸缩的是它那根竖绳，横玩家一格不动——断言照样成立（『或者原地不动』那一支），"
        "**但生成器照着「动了」画了整只精灵**，而 move_ok 只看横玩家、说得出「动得了」。"
        "这正是「说错 N 格却判 TRUE」那一行专门用来照出来的东西：检查器看不见生成器画了什么。"
        "apply 现在多一道 h_selected 守卫。这一版不是被推翻的，没有反例 tid 可加，"
        "所以它是**靠读数改的**，不是靠死因改的。\n"
        "再一版：apply 补上换关守卫（scope 和 assert_ 里本来就有，只有 apply 漏了）。"
        "全册的「说错 168 格」一直只出在同一条换关转移上，这条占 136 格——"
        "换关那一帧整屏重画，而这条照旧按本关的移动去画，画的每一格都不作数。"
        "**这个漏是自己写的探针照出来的**，而探针一开始也是错的：它给的 ctx 里 level_prev 和 level_next"
        "都取自记录里不存在的顶层字段（真值在 meta 下），于是两边都是 None、恒等，换关守卫在探针里从来没生效过。"
        "探针的 ctx 必须和结算的 ctx 同源，否则它报的每一条错、每一条漏都要打折。")
EVIDENCE = ["210e539c12d2ca36", "7f7e3f01bb9d54d9", "bd2eb2762d3a3972", "f9c757762d16cd94"]

from _lib import (CELL, me, rope_cells, sprite_cells, bg_at, move_ok, vmove_map,
                  map_pixels, h_selected, repaint_pending)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION1"):
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    if nb != na:
        return "FALSE"
    return "TRUE" if b in (a, (a[0] - CELL, a[1])) else "FALSE"


def apply(prev, action, ctx=None):
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION1"):
        return None
    if h_selected(prev) is not True:
        return None                      # 方向键此刻作用在另一个玩家身上，这条不开口
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None or not move_ok(prev, -1):
        return None
    old = sprite_cells(a[0], a[1], n)
    new = sprite_cells(a[0] - CELL, a[1], n)
    covered = map_pixels(prev, vmove_map(prev, -1) or {})
    out = {rc: v for rc, v in new.items() if rc not in covered}
    for rc in old:
        if rc not in new and rc not in covered:
            out[rc] = bg_at(prev, *rc)
    return {rc: v for rc, v in out.items() if 0 <= rc[0] < len(prev) and 0 <= rc[1] < len(prev[0])}
