"""ACTION7 只有三种结果，没有第四种：绳尖右移一节、绳尖左移一节、或绳长不变而玩家整体移动一行（上下都可能）；玩家的格列永远不变。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7；换关返回 NA；me() 或 rope_cells() 定位不到返回 NA。"
         "**只说这三种之外没有第四种，不说什么时候是哪一种**——"
         "『什么时候』要看一个帧里看不见的方向位，见 frame_not_state；"
         "能只从帧算出来的那两块另有其人：绳子占满整行时必收（a7_bounce）、"
         "绳尖右邻是墙时必下落（a7_fallthrough）。")
NOTE = ("v1：取代 a7_extend。a7_extend 说『落点不是墙就伸一节』，死于第 378、379 步——"
        "同一行同样空着、右邻不是墙，ACTION7 把绳子收了回去。"
        "九条 ACTION7 转移排出来是这样：第 371 步伸（n 2->3）、第 372 步右邻是墙于是玩家下落一行、"
        "第 373~376 步连伸四次（n 3->7）、第 377 步顶到棋盘右边缘掉头收一节（n 7->6）、"
        "第 378、379 步接着收（6->5->4）。掉头之后它记着方向，不会自己再翻回来——"
        "所以这是一根来回扫的梭子，不是一个『能伸就伸』的动作。"
        "这一条把可判的那部分单独留下：三选一。它在每一条 ACTION7 转移上都开口，"
        "出现第四种结果（比如绳长一次变 2、玩家换了格列、或者绳长和格行同时变）就当场死。"
        "v2 死于第 406 步（b27ff4012f8e7dd4）：同样在行 3、n=3、绳尖右邻同样是墙格，"
        "第 372 步玩家往下掉一行，第 406 步玩家往**上**抬一行。所以换行的方向也是帧里看不见的一位，"
        "而且这两次是相反的——三次换行按时间排是下、上、下（第 372、406、413 步），像在交替，"
        "但三个样本不够立主张，只把『上下都可能』写进来。"
        "另外这一版把两件已经看见、但这条概念**不管**的事记在这里，免得下次又当成新发现："
        "一、绳尖左移时会拖动绳尖右边那一串靶（第 409~412 步），归 a7_drag；"
        "二、第 413 步换行时把身后一行的一块靶也带走了，而第 372 步同样的身后有靶却没带走——"
        "这条差别还没有概念管它。")
EVIDENCE = ["95bb69228812c934", "06cf08bbd51ca612", "38dec5c118950db1", "5af4067896025cfd",
            "b27ff4012f8e7dd4"]

from _lib import CELL, me, rope_cells


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION7"):
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    if b == a and nb in (na + 1, na - 1):
        return "TRUE"                        # 绳尖右移 / 左移一节
    if b in ((a[0] + CELL, a[1]), (a[0] - CELL, a[1])) and nb == na:
        return "TRUE"                        # 绳长不变，玩家整体移动一行
    return "FALSE"
