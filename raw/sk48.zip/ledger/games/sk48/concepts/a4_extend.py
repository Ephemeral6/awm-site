"""ACTION4 让绳子多伸一节（绳尖右移 CELL 列、方块不动）；除非新绳尖要落进的那一格是墙，那时绳子一节都不伸、玩家也不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION4；换关返回 NA；me() 或 rope_tip() 定位不到返回 NA；"
         "**此刻方向键作用的不是横玩家（h_selected 不为 True）返回 NA** —— 那时 ACTION4 是竖玩家右移，归 v_slide 管；"
         "绳子已经占满整行返回 NA（那种局面语料里从没出现过，不表态）")
NOTE = ("v2 是**被推翻后缩的**：死于 86c8487591e16ed2。第 5 关盘上有两个玩家，"
        "那一步选中的是挂在上边横轨的那个，ACTION4 让它整体右移了一格列，横玩家的绳一节没伸。"
        "所以这条说的从来不是『ACTION4 伸绳』，而是『方向键作用在横玩家身上时，ACTION4 伸绳』——"
        "前五关只有一个玩家、它永远被选中，那个前提一直在，只是没写出来。判据是 h_selected。"
        "同一天同一批里 a3_retract 死于对称的一条（竖玩家左移）。\n"
        "v1 = a47_extend v6 砍掉 ACTION7 那一半。a47_extend 死于第 372 步："
        "同样是绳尖落点为墙，ACTION7 会让玩家整体下移一行，ACTION4 不会。"
        "『ACTION4 那时一格不动』这一句在全语料只有一条转移撑着（第 172 步 6435a75cc4a7d68d，"
        "唯一一条帧不变的 ACTION4），而它正好是我拿来和 ACTION7 对照的那一条——"
        "两条转移的局面并不完全同：172 步绳上串着三块靶，372 步绳上是空的。"
        "所以『ACTION4 撞墙不动』还欠一次同局面的直接对照，别把它当已验的。"
        "以下为 a47_extend 留下的死因，逐条仍对 ACTION4 成立："
        "v6：『要么伸一节、要么整帧不动』这种兜底写法是掷硬币——盘上有一只自己会走的钟，"
        "同一个物理情形（动作被拒）钟走了就判 FALSE、钟没走就判 TRUE。换成一条说得出口的前提："
        "落点是墙就一节都不伸。cell_map 只认 4×4 实心靶块、NOT_TARGET 又滤掉色5，"
        "所以那堵墙在此前每一张表里都印着一个『.』。"
        "v5：apply 必须原样抄 assert_ 的 scope 子句——换关时 assert_ 返回 NA，没有任何东西会去看生成器，"
        "生成器却照着旧关的玩家位置往新盘上画绳子，躲了两关。"
        "v3：apply 按**伸完之后**的靶分布避让（hmove_map）。"
        "v2：绳子从靶底下穿过去，只有格的左右边缘两列露出来。")
EVIDENCE = ["419bb51b683fd42d", "20fa92e98ea53bf3", "9a68d00127b954d4",
            "7adf8c84dcc52b37", "51d33aaf02be1629", "c36c918ed97efe32",
            "5373cb4a801927e3", "6435a75cc4a7d68d", "86c8487591e16ed2"]

from _lib import (CELL, me, rope_cells, rope_color, map_pixels, hmove_map,
                  target_pixels, extend_ok, h_selected, repaint_pending)


def _is(action):
    return action.startswith("ACTION4")


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _is(action):
        return "NA"
    if h_selected(prev) is not True:
        return "NA"
    a, b = me(prev), me(nxt)
    na, nb = rope_cells(prev), rope_cells(nxt)
    if a is None or b is None or na is None or nb is None:
        return "NA"
    ok = extend_ok(prev)
    if ok is None:
        return "NA"
    if b != a:
        return "FALSE"
    return "TRUE" if nb == (na + 1 if ok else na) else "FALSE"


def apply(prev, action, ctx=None):
    if not _is(action):
        return None
    if repaint_pending(prev, action, ctx):
        return None                          # 换关：整幅帧重画；预测口径下 ctx 说不出，只能问册子
    if h_selected(prev) is not True:
        return None                          # 方向键此刻作用在另一个玩家身上，这条不开口
    if extend_ok(prev) is not True:
        return None                          # 伸不出去（落点是墙）或没把握：这一步不开口
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None:
        return None
    out = {}
    w = len(prev[0])
    after = hmove_map(prev, 1)
    covered = map_pixels(prev, after) if after is not None else target_pixels(prev)
    for k in range(CELL * n + 1, CELL * (n + 1) + 1):
        c = a[1] + CELL - 1 + k
        if c >= w:
            return None
        for dr, lower in ((2, False), (3, True)):
            if (a[0] + dr, c) in covered:
                continue                     # 靶块压在绳子上面，这一格不归我说
            out[(a[0] + dr, c)] = rope_color(k, lower)
    return out
