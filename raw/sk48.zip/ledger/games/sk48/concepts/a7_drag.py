"""ACTION7 把绳尖往回收一节时，会拖着绳尖外面的靶一起走：从旧绳尖右邻那一格起、往右连续的一串靶，整串左移一格；盘上别的靶一块都不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION7，且只看绳长恰好减一节、玩家没换行的那一批（伸出去、撞墙换行的归 a7_shuttle / "
         "a7_fallthrough）；换关返回 NA；玩家、绳节数或棋盘认不出返回 NA。"
         "三种局面明说不管、返回 NA，因为语料里一次都没出现过："
         "杆盖着的格列 0..n-1 上有靶（左移时它们跟不跟着走，没见过）；"
         "盘上有竖绳（pinned_cells 非空——ACTION7 只在第 4 关出现过，那关没有竖绳）；"
         "被拖的那一串里有哪一块要落进墙格。")
NOTE = ("由来：hmove_blocks v13 死在第 409~412 步，它把 ACTION7 当成向右的伸绳。"
        "拆出来的这一半只管一件事——**左移时靶跟着走**，而 ACTION3 的左移不跟着走。"
        "这不是猜的，是一次对照：第 400 步 ACTION3 与第 409 步 ACTION7 在同一行、同样 n 5->4、"
        "同样两块靶在格列 5、6，第 400 步帧差只有 12 格（全是绳子那一节），靶一块没动；"
        "第 409 步那两块从格列 5、6 挪到了 4、5。同样的位置、同样的绳长变化，两种结果。"
        "所以绳子对靶有两套关系：ACTION3/ACTION4 搬的是**杆上串着的**（hmove_blocks），"
        "ACTION7 收回来时还**勾着杆外面顶头的那一串**。物理上像是梭子回程带着线上的珠子往回捋。"
        "依据是第 409~412 连续四步，绳长 5->4->3->2->1，每一步那一串都跟着左移一格。"
        "**没有 apply**：这条概念说不出什么时候会发生左移——ACTION7 的方向是帧里看不见的一位"
        "（见 frame_not_state），所以它只能在事后判对错，不能生成下一帧。"
        "**它最可能死在哪**：一、被拖的一串顶到盘左边缘或墙上时会怎样（此刻 SCOPE 判 NA，"
        "但那是回避不是回答，等第 4 关那三块色8 被捋到墙边就见分晓）；"
        "二、杆上同时有靶时，杆上的和杆外的会不会一起走——语料里 ACTION7 左移时杆上从来是空的。")
EVIDENCE = ["38c4abbc1a9dbdd5", "b47148ff18c9af28", "2876467db4c2757e", "fad1e0baa6b6af80"]

from _lib import cell_map, ncols, pinned_cells, player_cell_row, rope_cells, walls


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION7"):
        return "NA"
    na, nb = rope_cells(prev), rope_cells(nxt)
    ra, rb = player_cell_row(prev), player_cell_row(nxt)
    nc = ncols(prev)
    w = walls(prev)
    if None in (na, nb, ra, rb, nc, w):
        return "NA"
    if nb != na - 1 or rb != ra:
        return "NA"                          # 不是「收一节且没换行」，不归这一条管
    m = cell_map(prev)
    if any((ra, c) in m for c in range(na)):
        return "NA"                          # 杆上有靶：没见过，不表态
    if pinned_cells(prev):
        return "NA"                          # 有竖绳：没见过，不表态

    run = []
    c = na
    while c < nc and (ra, c) in m:
        run.append(c)
        c += 1
    if any((ra, x - 1) in w for x in run):
        return "NA"                          # 要撞墙：没见过，不表态

    want = dict(m)
    for x in run:
        del want[(ra, x)]
    for x in run:
        want[(ra, x - 1)] = m[(ra, x)]
    return "TRUE" if cell_map(nxt) == want else "FALSE"
