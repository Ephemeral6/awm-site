"""ACTION1/ACTION2 让玩家动时，绳子像一根横杆从第 r 行扫到第 r+d 行；杆盖住的每一列各自结算：本行那一格有靶就从它起沿 d 的一串连续靶跟着走，本行空而对面那一格有靶就是被杆顶走、从对面那一格起的一串跟着走；杆够不着的列一格不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1/ACTION2；换关返回 NA；绳尖不在盘内或定位不到返回 NA；"
         "**此刻方向键作用的不是横玩家（h_selected 不为 True）返回 NA** —— "
         "那时 ACTION1/2 伸缩的是竖玩家那根绳，靶的落点归 v_push 管")
NOTE = ("v4 是**被推翻后缩的**：死于 9ffa4ac4b68d6fcb（第 869 步）。第 5 关被选中的是第二个玩家，"
        "ACTION2 让它那根竖绳往下多伸一节，绳尖顶着一颗靶往**下**走了一格；"
        "v3 里 move_ok 说横玩家动得了，于是拿 vmove_map（横杆扫过去带走的那些格）对答案，判 FALSE。"
        "这条说的从来是『横杆扫行』那一种推挤，判据是 h_selected；竖绳顶靶是另一种，归 v_push。"
        "v3：把『整帧不动返回 NA』换成一句说得出口的话。老写法拿「屏幕上什么都没变」当挡箭牌，"
        "而盘上有一只自己会走的钟——同一个物理情形（动作被拒），钟走的那一步它开口、钟不走的那一步它闭嘴，"
        "开不开口由一个和主张毫不相干的相位决定。v3 改成问 move_ok：说动不了，就断言**棋盘一格不变**；"
        "说动得了，才拿 vmove_map 对答案。两头都能死，也不再看钟的脸色。"
        "apply 同时补上 move_ok 守卫——第 363 步（动作被拒）它照着「动了」画了 72 格，assert_ 却在闭嘴。"
        "v2：跟着走的不止绳尖那一列。第 25 步玩家下移，绳子 5 节盖住全部 5 列，"
        "靶14 压在绳子中段（第 3 列、不是绳尖列）——v1 说它不动，实际它跟着下去了，224 格帧差里说错一片。"
        "改成『绳子是一根横杆，杆下每一列各自推链』之后，第 9 步（杆扫进的新行上有靶、被顶起一串三块）"
        "和第 15/17/20 步（靶就在杆上、跟着走）就是同一条规矩的两个面，不用再分『绳尖格』和『绳尖前方』。"
        "v1 取代 push_up：它只说了『前方那一串』，第 15 步（绳尖同格的靶被带着上移、前方是空格）它会判错。\n"
        "再一版：apply 补上换关守卫（scope 和 assert_ 里本来就有，只有 apply 漏了），"
        "全册「说错 168 格」里的 32 格是这条在同一条换关转移上画的——那一帧整屏重画，按本关规则画的每一格都不作数。"
        "同一批把 a1_up 的 136 格一起补了；两条都是只改 apply、断言一个字没动。\n"
        "再一版死于 1bc3387069dfd74f（第 1080 步）：move_ok 说横玩家动得了，这条就断言棋盘按横杆扫行来变，"
        "实际动作被整个拒掉、帧差零格。错不在这条身上——是 move_ok 少了一条件："
        "玩家只能停在轨上花纹带覆盖的格行里，而新场景第一次把带子缩到三行。"
        "修在 _lib（vrail_span + move_ok），本条断言与 apply 一个字没动，那条 tid 进 EVIDENCE 的身份是**回归样本**："
        "以后 move_ok 再放宽，它当场再报一次。")
EVIDENCE = ["51be6437911f9ef5", "bd2eb2762d3a3972", "6df45d95bccc97a6", "f9c757762d16cd94",
            "9ffa4ac4b68d6fcb", "1bc3387069dfd74f"]

from _lib import (CELL, cell_map, cell_topleft, vmove_map, vmoved_cells, bg_at,
                  me, rope_cells, sprite_cells, nrows, move_ok, h_selected,
                  repaint_pending)


def _d(action):
    if action.startswith("ACTION1"):
        return -1
    if action.startswith("ACTION2"):
        return 1
    return None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = _d(action)
    if d is None:
        return "NA"
    if h_selected(prev) is not True:
        return "NA"
    ok = move_ok(prev, d)
    if ok is None:
        return "NA"
    if not ok:
        return "TRUE" if cell_map(nxt) == cell_map(prev) else "FALSE"
    want = vmove_map(prev, d)
    if want is None:
        return "NA"
    return "TRUE" if cell_map(nxt) == want else "FALSE"


def apply(prev, action, ctx=None):
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    d = _d(action)
    if d is None:
        return None
    if h_selected(prev) is not True:
        return None                      # 方向键此刻作用在另一个玩家身上，这条不开口
    if not move_ok(prev, d):
        return None                      # 动作会被拒（或没把握）：棋盘不动，这一步不开口
    mv = vmoved_cells(prev, d)
    if not mv:
        return None
    m = cell_map(prev)
    new_cells = {(r + d, c): m[(r, c)] for (r, c) in mv}
    nr = nrows(prev)
    if nr is None or any(not (0 <= r < nr) for (r, _) in new_cells):
        return None
    out = {}
    for (r, c), color in new_cells.items():
        top, left = cell_topleft(prev, r, c)
        for dr in range(4):
            for dc in range(4):
                out[(top + dr, left + dc)] = color
    a, n = me(prev), rope_cells(prev)
    if a is None or n is None:
        return None
    taken = set(sprite_cells(a[0] + d * CELL, a[1], n))   # 移动后绳子/方块占的像素，让给 a1_up/a2_down
    for (r, c) in mv:
        if (r, c) in new_cells:
            continue
        top, left = cell_topleft(prev, r, c)
        for dr in range(4):
            for dc in range(4):
                rc = (top + dr, left + dc)
                if rc not in out and rc not in taken:
                    out[rc] = bg_at(prev, *rc)
    return out
