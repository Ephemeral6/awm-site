"""帧不是完整状态，但差的只有 ACTION7 那一位：除 ACTION7 以外的每个动作，下一帧的绳长与玩家格行都只由这一帧决定。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1/2/3/4/6；ACTION7 返回 NA（那一半正是这条概念说算不出来的，归 a7_shuttle）；"
         "换关返回 NA；定位不到、或 extend_ok 没把握（绳子已占满整行）返回 NA；"
         "**此刻方向键作用的不是横玩家（h_selected 不为 True）返回 NA**。"
         "**只赌横玩家的绳长和格行这两个量**，不赌棋盘上靶的落点（那归 hmove_blocks / vmove_blocks），"
         "也不赌第二个玩家的那两个量——那一半此刻无人认领。")
NOTE = ("由来是一次机器可核的观测：第 376 步的 prev 与第 378 步的 prev **逐格完全相同**"
        "（runs/<run>/p_dd.py 打出 0 格差，连底下那条计时也一样），动作同为 ACTION7，"
        "next 一个是绳尖右移一节、一个是绳尖左移一节。所以『同一帧 + 同一动作 -> 同一帧』"
        "在这一局是**假的**，帧里藏着一个看不见的位（梭子的方向）。"
        "这件事有两个后果，都得写下来："
        "一、走回断点那 176 步踩的假设『同一初始局面 + 同一动作串 -> 同一帧』并没有被推翻——"
        "整串从头重放会把看不见的位一起重放出来；被推翻的是**单步**的『同一帧 -> 同一结果』。"
        "二、规划器不能只看帧：要用 ACTION7 就得自己记着方向。绕开的办法是别用它——"
        "伸缩用 ACTION3/ACTION4 就够，ACTION7 唯一独有的本事是右邻是墙时把玩家往下带一行。"
        "这一条断言的是**剩下的部分是干净的**：别的动作没有隐藏状态。它在两百多条转移上开口，"
        "任何一条非 ACTION7 的转移只要绳长或格行算不准，它就死——那说明还有第二个看不见的位。"
        " || v2 是**被推翻后缩的**：九条反例（123fc813a0c1aa1e、3b0942e599c1bc3a、6a57ede9b8236adb、"
        "829eb9fd19aa7491、86c8487591e16ed2、95018f7b84a9eab3、9ffa4ac4b68d6fcb、b0bb1879238eb3c0、"
        "b151bdfdcef25bb8）全在第 5 关，全是同一件事：那一批被选中的是第二个玩家，"
        "方向键作用在它身上，横玩家的格行与绳长一动不动，而 v1 照着「ACTION2 = 横玩家往下」在算。"
        "**这不是第二个隐藏位**——选中的是谁明明白白写在帧上（精灵内圈的填充色），"
        "v1 只是没去读它。缩 scope 用的是 h_selected。"
        "缩完之后这条概念在第 5 关只管两个玩家里的一个，**另一半是新开的空白**："
        "竖玩家的『格列 + 绳长只由这一帧决定』还没有任何概念声称过。"
        "要补上它，先得知道竖玩家什么时候滑不动、绳缩到 0 会怎样——这两件事目前都零证据，"
        "现在就写等于拿兜底冒充规律。\n"
        "v3 死于 1bc3387069dfd74f（第 1080 步）：这一帧上 move_ok 说横玩家往下走得了，"
        "于是它算出格行 +1，实际整帧零格。它断言的是「下一帧的绳长与格行只由这一帧决定」——"
        "**决定关系没有被推翻，被推翻的是它拿去算的那个函数**：move_ok 少了一条件，"
        "玩家只能停在轨上花纹带覆盖的格行里，而新场景第一次把带子缩到三行。"
        "修在 _lib（新词 vrail_span + move_ok 加一句），本条源码一个字没动；"
        "这条 tid 进 EVIDENCE 的身份是回归样本。"
        "顺带记一件：这条概念是「有没有隐藏位」的探针，而它这次报的错并不是隐藏位，"
        "是**帧上一直摆着、我没去读的一块像素**——两者在读数上长得一模一样，只能靠去看帧分辨。")
EVIDENCE = ["38dec5c118950db1", "093c0be663751e0c", "93c4addf6a378a32",
            "123fc813a0c1aa1e", "3b0942e599c1bc3a", "6a57ede9b8236adb",
            "829eb9fd19aa7491", "86c8487591e16ed2", "95018f7b84a9eab3",
            "9ffa4ac4b68d6fcb", "b0bb1879238eb3c0", "b151bdfdcef25bb8",
            "1bc3387069dfd74f"]

from _lib import player_cell_row, rope_cells, move_ok, extend_ok, h_selected


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.startswith("ACTION7"):
        return "NA"
    if h_selected(prev) is not True:
        return "NA"
    r, n = player_cell_row(prev), rope_cells(prev)
    r2, n2 = player_cell_row(nxt), rope_cells(nxt)
    if None in (r, n, r2, n2):
        return "NA"
    if action.startswith("ACTION1") or action.startswith("ACTION2"):
        d = -1 if action.startswith("ACTION1") else 1
        ok = move_ok(prev, d)
        if ok is None:
            return "NA"
        want = (r + d if ok else r, n)
    elif action.startswith("ACTION3"):
        want = (r, n - 1 if n > 0 else n)
    elif action.startswith("ACTION4"):
        ok = extend_ok(prev)
        if ok is None:
            return "NA"
        want = (r, n + 1 if ok else n)
    elif action.startswith("ACTION6"):
        want = (r, n)
    else:
        return "NA"
    return "TRUE" if (r2, n2) == want else "FALSE"
