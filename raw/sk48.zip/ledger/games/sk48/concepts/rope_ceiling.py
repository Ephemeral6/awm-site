"""绳子已经占满整行（节数等于棋盘列数）时按 ACTION4：绳长一节不变、玩家不动、盘上的靶一块不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION4，且只看 rope_cells >= ncols（绳子占满整行）的局面；"
         "换关返回 NA；玩家、绳节数或棋盘认不出返回 NA。"
         "只说这三样不变，**不说屏幕上别的东西不变**——盘外那根走时钟的条子照走（bar_clock 管它）。"
         "ACTION7 撞上限归 a7_bounce（那一条实测是往回收一节，和这条完全不同）。")
NOTE = ("由来：rope_limit v2 的 SCOPE 里写着「ACTION4 撞上限至今一次都没试过，册子里没人认领」——"
        "这是一张明写的欠条。把走子器拿到全语料上逐步对答案时它自己冒出来了："
        "1084 条可核对的转移里，走子器唯一说不出话的就是这 12 条，全在第 4 关、绳 7 节 = 棋盘 7 列。"
        "12 条转移（去重 9 个 tid）逐条量过：9 条帧差 0 格，3 条帧差 1 格而且那一格都在第 53 行"
        "（2→3，正是 bar_clock 那根条子），绳节数前后都是 7，靶一块没动。\n"
        "**它是被机器找出来的，不是被想起来的**：欠条写在一条概念的 SCOPE 里，"
        "而 SCOPE 不会因为语料变了就来敲门。把册子里的规矩重写成一个走子器、"
        "再让它在全语料上逐步对答案，说不出话的地方就是欠条的到期通知——"
        "这比「回头看一眼当初说没量过的事」可靠，因为它不依赖我记得有这么一张欠条。\n"
        "**它最可能死在哪**：别的关卡的满行 ACTION4。这 12 条全在同一关同一行（第 0 行、行上没有靶），"
        "「靶一块不动」那一句在「杆上根本没有靶」的局面里是恒真的。"
        "杆上有靶时满行再按 ACTION4，靶会不会像 ACTION7 那样被往回捋，这条概念说不会——"
        "第一次遇到就见分晓。")
EVIDENCE = ["5ba00c12dce3e756", "85d3b080a73b4bf9"]

from _lib import rope_cells, ncols, cell_map, me


def _full(g):
    n, nc = rope_cells(g), ncols(g)
    if n is None or nc is None:
        return None
    return n >= nc


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION4"):
        return "NA"
    full = _full(prev)
    if full is None or not full:
        return "NA"
    n1, n2 = rope_cells(prev), rope_cells(nxt)
    a1, a2 = me(prev), me(nxt)
    m1, m2 = cell_map(prev), cell_map(nxt)
    if n2 is None or a1 is None or a2 is None or m1 is None or m2 is None:
        return "NA"
    return "TRUE" if (n1 == n2 and a1 == a2 and m1 == m2) else "FALSE"
