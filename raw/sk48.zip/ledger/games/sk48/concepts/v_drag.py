"""竖绳缩一节（选中竖玩家按 ACTION1）时，杆上串着的每一颗靶都跟着往上挪一格；
挪不动的（落点出棋盘上边缘、是墙、或压着一颗没挪成的靶）留在原地；盘上别的靶一块不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1，且只看绳长恰好减一节、玩家没换格列的那一批；换关返回 NA；"
         "**选中的不是竖玩家就返回 NA**（那时 ACTION1 是横玩家上移，归 a1_up / vmove_blocks 管）；"
         "players()/cell_map()/walls() 读不出来、或绳已经 n=0，返回 NA。"
         "**杆上有一颗靶同时串在横玩家那根杆上，那一颗搬不动**（第 986 步实测），"
         "它上面那一串跟着卡住，绳照样缩；落点被横杆盖着的也当搬不动（这半是押注）。"
         "这一支从 v3 起不再返回 NA。"
         "只说靶落在哪一格，不说绳子和玩家精灵怎么画。")
NOTE = ("由来：第 873、874 步。竖玩家在格列 4、绳 7 节伸满整列，绳尖那一格 (6,4) 上串着一颗色9"
        "（它是第 872 步被 v_capture 串上去的）。连按两次 ACTION1，绳 7→6→5，"
        "那颗 9 跟着从 (6,4) 到 (5,4) 再到 (4,4)。\n"
        "这是 v_retract 留下的那块留白的答案。v_retract 的 NOTE 写着："
        "「横向那边的同一个动作是会拖着靶一起走的，竖向会不会也这样，语料里一次都没赶上；"
        "等哪一步在有靶的格上缩绳，那一步要么给它补一条，要么把它推翻。」这就是补上的那一条。"
        "**押注押的就是这一条**，并写明了落空的样子：绳缩了而靶一动不动。世界给的是「跟着走」。\n"
        "规律本身是从横向那边搬过来的：hmoved_cells 的 k<0 那一支——"
        "跟着走的是**杆盖着的**那一段，甩在绳尖外面的够不着。竖向的「杆外面」是绳尖下方，"
        "这两步里绳尖下方就是棋盘下边缘，所以这一半还没验过。\n"
        "**只有两条转移撑着，而且杆上只有一颗靶、就在绳尖那一格**："
        "「杆上有两颗以上、彼此不相连时是不是各走各的」「靶在杆的上半段（离绳尖远）会不会也跟着走」"
        "都还没试过——那两句是从横杆借来的类比，不是量出来的。"
        "第 864 步（b151bdfdcef25bb8）是杆上一颗靶都没有的那一支：绳缩了，盘上的靶一块没动。\n"
        "v2：**主动把话说宽了，不是挨了打才改**。v1 的 scope 写着「杆上有一颗靶在格行 0、"
        "或落点是墙，返回 NA」——那时确实一条证据都没有。但接下来的路线要连着七次在格行 0 上缩绳"
        "（把一颗靶留在顶上），全靠这一支；把它继续留在 NA 里，等于让规划器踩着一句册子从没说过的话走路。"
        "于是照横向那边的 hmoved_now 补齐：**挪不动的留在原地**（横向缩绳到格列 0 时就是这样）。"
        "这一支到此刻**零证据**，纯粹是 90 度类比，写出来就是为了让它挨打——"
        "如果世界给的是「顶到边就被挤掉」或者「整个动作被拒」，它当场判 FALSE。"
        "同一次把落地的算法挪进 _lib.vpole_now，和伸绳那一支（v_carry）共用一份，"
        "省得两边的阻挡规矩各写各的、各错各的。\n"
        "v3：**留白被填上了，而填它的那次改动改的是词，不是这个文件**——所以这一版只是把话追上代码。"
        "第 986 步（468e503ea57c795f）：竖绳 7→6 节，杆上第 5 行那颗 8 同时串在 4 节横杆上，"
        "它一格没动；它上面那颗自由的 9 照常上移一格。于是 `_lib.vpole_now` 里"
        "「有一颗被横杆串着就整条返回 None」改成「跳过那一颗、它后面的一串跟着卡住」，"
        "这条概念的 scope 也就从「不表态」变成了「表态：搬不动」。"
        "**改 _lib 不算改版，所以这个漏是自己找的不是被打出来的**：词换了意思，"
        "文件里的 scope 却还写着「语料 0 条，不表态」，而它此刻已经在对这一支表态了。"
        "另一半（落点被横杆盖着 → 也搬不动）仍是押注，是从横向那边 h_extend 的 pinned 判据转 90 度搬来的。"
        "注意这条只管**伸缩**：平移（横杆上下走、竖玩家左右挪）反过来，串在另一根绳上一概不管，"
        "见 vslide_blocks 与 vmove_blocks。\n"
        "v4：**只改 apply，assert_ 一个字没动，也没有反例**——这一版是被「押注的逐格预测」逼出来的。"
        "第 1124、1125 步各有 32 格帧差没人管：杆上两颗靶隔着空格，各自往上挪一格，"
        "v3 的 apply 只画新落点、只把绳尖那一格复原，**腾出来的那两格一格没画**。"
        "同一批里没有一格「说错」，S 也没掉——腾空的格子落进残差，而残差不关闸、不掉分。"
        "它是从另一头显形的：`bet --predict` 是拿自己预测出来的帧接着往下预测的，"
        "腾空的格子带着旧色一路传下去，第 1125 步就变成「预测 84 格对 52 格」。"
        "**残差在单步上只是没说话，在链式预测里会变成说错。** 照 v_carry 那一支的写法补齐："
        "腾空的格子上还盖着绳就画绳（vrope_map 按缩完的 n-1 节算），没绳就画底色；"
        "缩掉的那一节整节复原，除非绳尖那一格上还压着一颗没挪成的靶。")
EVIDENCE = ["91088af687586164", "27869e0b018ef1a8", "b151bdfdcef25bb8", "468e503ea57c795f"]

from _lib import (CELL, board_box, cell_map, cell_topleft, players, sel_v,
                  vdrag_cells, vdrag_map, vrope_map, repaint_pending)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION1"):
        return "NA"
    p = sel_v(prev)
    if p is None:
        return "NA"
    core, _, cc, n, _ = p
    qs = players(nxt)
    if qs is None:
        return "NA"
    q = [x for x in qs if x[0] == core]
    if len(q) != 1 or q[0][1] != 'v' or (q[0][2], q[0][3]) != (cc, n - 1):
        return "NA"                      # 不是「缩一节且没换列」，不归这一条管
    want = vdrag_map(prev)
    m2 = cell_map(nxt)
    if want is None or m2 is None:
        return "NA"
    return "TRUE" if want == m2 else "FALSE"


def apply(prev, action, ctx=None):
    """靶的新落点画 4×4；腾出来的格子露出的是**绳**（缩完还盖着的那几行）或棋盘底色；
    缩掉的那一节绳整节复原成底色——它不再盖着任何东西。"""
    if repaint_pending(prev, action, ctx):
        return None                      # 换关那一帧整屏重画；预测口径下 ctx 说不出，只能问册子
    if not action.startswith("ACTION1"):
        return None
    p = sel_v(prev)
    mv = vdrag_cells(prev)
    if p is None or not mv:
        return None
    _, _, cc, n, _ = p
    after = vdrag_map(prev)
    b = board_box(prev)
    if after is None or b is None:
        return None
    top, _, left, _ = b
    rope = vrope_map(prev, cc, n - 1, True)
    if rope is None:
        return None
    out = {}
    for (r, c) in set(mv) | {(r - 1, c) for (r, c) in mv}:
        tl = cell_topleft(prev, r, c)
        if tl is None:
            return None
        t0, l0 = tl
        color = after.get((r, c))
        for dr in range(4):
            for dc in range(4):
                rc = (t0 + dr, l0 + dc)
                if color is not None:
                    out[rc] = color                 # 这一格上有靶：画 4×4
                elif rc in rope:
                    out[rc] = rope[rc]              # 腾空了，露出绳子那两列
                else:
                    out[rc] = 4                     # 其余是棋盘底色
    r0 = top + CELL * (n - 1)                       # 缩掉的那一节
    c0 = left + CELL * cc + 2
    tip = after.get((n - 1, cc))
    for dr in range(CELL):
        for j in (0, 1):
            out[(r0 + dr, c0 + j)] = tip if (tip is not None and 1 <= dr <= 4) else 4
    return out
