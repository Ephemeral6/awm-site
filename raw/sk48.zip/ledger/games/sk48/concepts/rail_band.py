"""两条轨上那条 2/3 花纹带是玩家的活动范围：在一关之内，把带子的像素读数与玩家自己的格位取并之后，横轨那段格列区间与竖轨那段格行区间在每一对相邻帧上都相同——带子不动，玩家也走不出去。"""
LEVEL = "L2"
SCOPE = ("换关返回 NA（换关那一帧整屏重画，带子会换）；"
         "prev / nxt 任一帧上棋盘框读不出来、或轨落在屏幕外、或区间读成空，返回 NA（RESET 的空白帧全在这里）。"
         "只说这两个区间相不相等，不说带子具体铺到哪（那是每关不同的常数，问 hrail_span / vrail_span）。")
NOTE = ("由来：第 1080 步（1bc3387069dfd74f）。横玩家在格行 4 按往下，move_ok 的三个条件全满足，"
        "实际动作被世界整个拒掉、帧差零格，一步之内打死三条概念（frame_not_state、move_block、vmove_blocks）。"
        "去看像素才发现轨上一直画着一条 2/3 花纹带，而这个场景里它只铺三个格——"
        "此前每个场景的带子都铺满整条轨，于是「不出盘」和「不出带」在语料里一直同分布，"
        "分得开它们的局面直到那一步才第一次出现。\n"
        "**为什么这样写才判得错**：带子的一端会被玩家自己 6 像素高的精灵盖住，"
        "所以读法里必须把玩家自己的格位并进去，否则玩家站在端点上时带子会被读窄。"
        "并进去之后「玩家在带内」就成了同义反复——但**区间在一关内恒定**没有变成同义反复："
        "玩家真要走出带外，这个并集当场变宽，这条概念就死在那一步；带子自己动了、变宽变窄了，同样死。"
        "所以它一条断言同时押住了「带子每关静态」和「带子就是活动范围」这两件事。\n"
        "全语料 731 条转移逐帧核过带子读法：玩家落在带外 0 次（runs/<run>/bandcheck.py）。"
        "这条概念是把那次核对写成能被后续每一步继续核的形式。"
        "还没检验过的一半：竖玩家横挪时撞上横轨带子的端点——语料里从没出现过，"
        "slide_ok 里那一句是照着 move_ok 对称搬的，属于押注。")
EVIDENCE = ["1bc3387069dfd74f", "b4a36dab36e529f9"]

from _lib import hrail_span, vrail_span


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a1, a2 = hrail_span(prev), hrail_span(nxt)
    b1, b2 = vrail_span(prev), vrail_span(nxt)
    if a1 is None or a2 is None or b1 is None or b2 is None:
        return "NA"
    return "TRUE" if (a1 == a2 and b1 == b2) else "FALSE"
