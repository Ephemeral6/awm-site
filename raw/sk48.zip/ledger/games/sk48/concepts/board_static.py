"""帧上会变的格子只有四类：**每个**玩家精灵（方块+它那根绳）前后占的格、4×4 靶块前后占的格、底条那一行、屏幕下方的示意图。别处逐格不变。"""
LEVEL = "L0"
SCOPE = "所有动作；换关返回 NA；players() 在前后任一帧读不出来返回 NA"
NOTE = ("v1 只放行玩家精灵，第 9 步绳尖把靶子推上去时挨了反例（51be6437911f9ef5）：靶块也会动。"
        "v2 把靶块前后占的格一并放行——主张退成「除了会动的那几样，底板逐格不变」。"
        "v3：示意图也会动。第 42 步（ebf6a5f8c687760e）示意图里第 0 个块的中心 2×2 由块色变成色 0，"
        "而它此前 42 步一个像素没动过，所以一直被当成静态装饰。它不是装饰，是进度指示器，"
        "另立一条 hud_checklist 管它变的规律；这里只负责把它从「底板不变」里放行。"
        "v4 挨的五条反例（25c1448d06ab606b / 3ef2ba1535db4a4e / 61bdae5b089bd2ee / "
        "6df45d95bccc97a6 / 9bd444247764f470）不是世界打的，是词汇打的：换关后把写死的棋盘范围改成"
        "「色4 的最大连通块」，而绳子伸满全宽时正好把色4 横切成上下两块，最大块只剩半个棋盘，"
        "靶块的像素于是掉出 target_pixels 的放行名单。修的是 _lib.board_box（把被绳子切开的另半边并回来），"
        "主张一个字没改。留着这五条 tid：它们现在是「棋盘认得对不对」的回归样本。"
        " || v5 挨的十条反例全在第 5 关，全是同一件事：盘上出现了**第二个玩家**（挂在棋盘上边横轨、"
        "绳往下伸），而 v4 的放行名单是照「世上只有一个玩家」写的——只放行 me() 那一个精灵和它那根横绳。"
        "第二个玩家一走一伸，它的精灵、它那根竖绳、它扫过的横轨全落在名单外，逐条判 FALSE。"
        "改的是名单不是主张：现在按 players() 逐个玩家放行（精灵 6×6 外框 + 它自己那根绳），"
        "横玩家的绳往右、竖玩家的绳往下。顺带把「选中态换人时两根绳一起变色」也盖住了——"
        "变色的像素本来就在各自的绳上。这十条 tid 从此是「盘上有几个玩家、认全了没有」的回归样本。"
        " || 第十一条 9ffa4ac4b68d6fcb 是**改完之后才披露的**（第 869 步，竖绳把靶往下顶）："
        "v6 在它上面判 TRUE，逐格核过未放行的变格 0 个。它进 EVIDENCE 是登记，不是死因。")
EVIDENCE = ["210e539c12d2ca36", "419bb51b683fd42d", "51be6437911f9ef5", "ebf6a5f8c687760e",
            "25c1448d06ab606b", "3ef2ba1535db4a4e", "61bdae5b089bd2ee",
            "6df45d95bccc97a6", "9bd444247764f470",
            "11131d8a77ef8941", "86c8487591e16ed2", "fed73fba2052c500",
            "829eb9fd19aa7491", "6a57ede9b8236adb", "b151bdfdcef25bb8",
            "123fc813a0c1aa1e", "f75b1402e82d8215", "b9fa25944fed90b6",
            "b0bb1879238eb3c0", "9ffa4ac4b68d6fcb"]

from _lib import (BAR_ROW, CELL, board_box, players, sprites,
                  target_pixels, hud_pixels)


def _live_pixels(g):
    """这一帧里「会动的东西」占的像素：底条以上每个精灵的 6×6 外框，加它自己那根绳
    （横玩家的绳沿中间两行往右，竖玩家的绳沿中间两列往下）。读不出来返回 None。"""
    b = board_box(g)
    ps = players(g)
    if b is None or ps is None:
        return None
    top = b[0]
    H, W = len(g), len(g[0])
    byc = {p[0]: p for p in ps}
    out = set()
    for r, c, core, _ in sprites(g):
        rt, lf = r - 2, c - 2                  # 2×2 芯往外退两格 = 6×6 外框左上角
        if rt >= BAR_ROW:
            continue                           # 底条以下的示意图图标，归 hud_pixels 管
        for dr in range(CELL):
            for dc in range(CELL):
                out.add((rt + dr, lf + dc))
        p = byc.get(core)
        if p is None:
            continue                           # 不在轨上的精灵：只放行它的外框
        _, kind, _, n, _ = p
        if kind == 'h':
            for k in range(CELL * n + 1):
                out.add((rt + 2, lf + CELL - 1 + k))
                out.add((rt + 3, lf + CELL - 1 + k))
        else:
            for rr in range(top - 1, top + CELL * n + 1):
                out.add((rr, lf + 2))
                out.add((rr, lf + 3))
    return {(rr, cc) for rr, cc in out if 0 <= rr < H and 0 <= cc < W}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    lp, ln = _live_pixels(prev), _live_pixels(nxt)
    if lp is None or ln is None:
        return "NA"
    allowed = (lp | ln
               | target_pixels(prev) | target_pixels(nxt) | hud_pixels(prev) | hud_pixels(nxt))
    for r in range(len(prev)):
        if r == BAR_ROW:
            continue
        row_p, row_n = prev[r], nxt[r]
        if row_p == row_n:
            continue
        for c in range(len(row_p)):
            if row_p[c] != row_n[c] and (r, c) not in allowed:
                return "FALSE"
    return "TRUE"
