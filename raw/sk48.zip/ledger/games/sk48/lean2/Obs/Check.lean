/-
# Check —— 判据层：两把尺子。**这一份里没有一条定理**，尺子不自证。

    judge      **一条转移**：从观测到的那一帧起算一步，和看到的下一帧比（三值：对上 / 对不上 / 说不出话）
    traceOk    **一整条路**：只有开局那一帧是观测给的，后面全是模型自己算的，逐帧和观测比

两把尺子的分量差得很远：一个「每步单独看都对、走两步就和现实分家」的模型，
在 `judge` 那里是满分，在 `traceOk` 这里过不了。

## 比什么：只比帧上看得见的

  · 靶按**集合**比：帧上读出来的靶没有先后，模型里的列表顺序是它自己搬出来的；
  · 竖玩家按集合比，同一个理由；
  · **底条不比**：它不进模型（Python `rule/说了但不进模型/bar_clock.py`）。
-/
import Step

namespace Game

def sameSet {α : Type} [BEq α] (a b : List α) : Bool :=
  a.length == b.length && a.all (fun x => b.contains x) && b.all (fun x => a.contains x)

/-- 模型算出来的和看到的，在帧上看得见的那几样上一样吗。 -/
def seenEq (x y : St) : Bool :=
  sameSet x.blocks y.blocks && x.h == y.h && sameSet x.vs y.vs && x.sel == y.sel

/-- 语料里的一条转移（前一帧读得成的那些）。`next = none`：下一帧不是一个局面（终局画面）。 -/
structure Case where
  seq : Nat
  board : Board
  prev : St
  act : Act
  next : Option St
  levelup : Bool

inductive Verdict where
  | agree | disagree | silent
  deriving DecidableEq, BEq, Repr

/-- 三值，**不是两值**：`silent`（模型说不出话）不是 `agree`。

    过关那一步：模型要说 `won`（下一帧是另一张盘，不拿它比）；
    没过关：模型要说 `ok s`，且 `s` 与看到的下一帧一样。 -/
def judge (c : Case) : Verdict :=
  match step c.board c.prev c.act with
  | .na => .silent
  | .won _ => if c.levelup then .agree else .disagree
  | .ok s =>
    if c.levelup then .disagree
    else match c.next with
      | some o => if seenEq s o then .agree else .disagree
      | none => .disagree

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算出来的状态。** -/
def traceOk (b : Board) : St → List (Act × St) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match step b s a with
    | .ok s' => seenEq s' o && traceOk b s' rest
    | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，它是读数不是定理。 -/
def firstSplit (b : Board) : St → List (Act × St) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match step b s a with
    | .ok s' => if seenEq s' o then firstSplit b s' rest (i + 1) else some i
    | _ => some i

end Game
