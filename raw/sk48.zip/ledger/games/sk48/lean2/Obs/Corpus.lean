/-
# Corpus —— 模型面对全部真实转移：逐条（`lean2/export_corpus.py` 生成，不要手改）

    verdictCode r   Lean 对这一行的判决：0 对上 / 1 对不上 / 2 说不出话（ACTION7、RESET）/ 3 前一帧不是局面
    reconciled_k    第 k 块（100 行一块）：**每一行 Lean 的判决 = Python 规则层的判决**
    py_no_disagree  Python 那一侧一行「对不上」都没有
    py_counts       Python 那一侧四类各几行

几条合起来：Lean 模型面对这 1407 行，对上 1364、对不上 **0**、说不出话 42、前一帧不是局面 1。
**`#eval` 那一行只是读数**（走求值器）；结论是上面那几条走内核的定理。
-/
import Obj.World
import Obs.Replay

namespace Game
namespace Corpus
open Replay

-- 独立的一条命令（夹在文档注释和定理之间是语法错）。不够深时 Lean 报一行错照常往下编、公理表里多出 sorryAx。
set_option maxRecDepth 200000

def verdictCode (r : Row) : Nat :=
  match caseOf r with
  | none => 3
  | some c =>
    match judge c with
    | .agree => 0
    | .disagree => 1
    | .silent => 2

def reconciled (rs : List Row) : Bool := rs.all (fun r => verdictCode r == r.py)

def chunk (k : Nat) : List Row := (rows.drop (k * 100)).take 100

def count (c : Nat) : Nat := (rows.filter (fun r => r.py == c)).length

end Corpus
end Game

-- 定理放在根命名空间：装置 `ledger/lean_check.py` 的公理表探针按短名打 `#print axioms`。
open Game Game.Replay Game.Corpus

-- `set_option` 的作用域到 `end` 为止：出了命名空间要再说一遍，不然下面的 `decide` 又会撞深度上限。
set_option maxRecDepth 200000

#eval (rows.map verdictCode).foldl (fun (acc : Nat × Nat × Nat × Nat) v =>
  match v with
  | 0 => (acc.1 + 1, acc.2)
  | 1 => (acc.1, acc.2.1 + 1, acc.2.2)
  | 2 => (acc.1, acc.2.1, acc.2.2.1 + 1, acc.2.2.2)
  | _ => (acc.1, acc.2.1, acc.2.2.1, acc.2.2.2 + 1)) (0, 0, 0, 0)

theorem rows_len : rows.length = 1407 := by decide

theorem py_no_disagree : rows.all (fun r => r.py != 1) = true := by decide

theorem py_counts : count 0 = 1364 ∧ count 1 = 0 ∧ count 2 = 42 ∧ count 3 = 1 := by decide

#print axioms rows_len
#print axioms py_no_disagree
#print axioms py_counts

theorem reconciled_0 : reconciled (chunk 0) = true := by decide
#print axioms reconciled_0
theorem reconciled_1 : reconciled (chunk 1) = true := by decide
#print axioms reconciled_1
theorem reconciled_2 : reconciled (chunk 2) = true := by decide
#print axioms reconciled_2
theorem reconciled_3 : reconciled (chunk 3) = true := by decide
#print axioms reconciled_3
theorem reconciled_4 : reconciled (chunk 4) = true := by decide
#print axioms reconciled_4
theorem reconciled_5 : reconciled (chunk 5) = true := by decide
#print axioms reconciled_5
theorem reconciled_6 : reconciled (chunk 6) = true := by decide
#print axioms reconciled_6
theorem reconciled_7 : reconciled (chunk 7) = true := by decide
#print axioms reconciled_7
theorem reconciled_8 : reconciled (chunk 8) = true := by decide
#print axioms reconciled_8
theorem reconciled_9 : reconciled (chunk 9) = true := by decide
#print axioms reconciled_9
theorem reconciled_10 : reconciled (chunk 10) = true := by decide
#print axioms reconciled_10
theorem reconciled_11 : reconciled (chunk 11) = true := by decide
#print axioms reconciled_11
theorem reconciled_12 : reconciled (chunk 12) = true := by decide
#print axioms reconciled_12
theorem reconciled_13 : reconciled (chunk 13) = true := by decide
#print axioms reconciled_13
theorem reconciled_14 : reconciled (chunk 14) = true := by decide
#print axioms reconciled_14

/-- 分块没有漏行：15 块拼起来就是全部 1407 行。 -/
theorem chunks_cover : ((List.range 15).map (fun k => (chunk k).length)).foldl (· + ·) 0 = 1407 := by decide
#print axioms chunks_cover

