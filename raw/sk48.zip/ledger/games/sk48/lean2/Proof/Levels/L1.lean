/-
# 第 1 关 —— 走得通（`lean2/export_levels.py` 生成，不要手改）

开局：认证那一段 seq 1159 的前一帧（**从语料的帧里读出来的**，不是手写的盘）。
真人走过的路：seq 1159 .. 1187，29 步，每一步都进路（点击、方向键一步不挑）；
过关那一脚是 seq 1188（.right），它的下一帧已经是下一关的盘，**不进路里**，进 `_winnable` 的见证。

    L1_len        这一段确实是 29 步（切歪了会得到空表，而空表让下一条平凡为真）
    L1_clean      这一段每一行都在第 1 关、属于认证那一段、没有断点
    L1_trace      **模型沿这条路每一帧都和观测对上**：只有开局那一帧是观测给的，后面全是模型自己算的
    L1_winnable   这一关走得通：见证是这 29 步再加过关那一脚，一共 30 步

这一关核过的步数：**29 步逐帧对上 + 1 步过关**。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels
open Replay

-- 语料那张表有一千多行，`decide` 要一层层归约下去：默认的递归深度不够，
-- 不够的时候 Lean **报一行错然后照常往下编**，那条定理的公理表里悄悄多出 `sorryAx`
-- （实测第一版就是这样，而同一份文件里 `#eval` 照样打出「一处都没分家」）。
-- 这一行是独立的一条命令，不能夹在文档注释和定理之间。
set_option maxRecDepth 200000

def L1_board : Board := boardAt (bySeq 1159).board
def L1_start : St := startOf 1159
def L1_rows : List Row := rowsFrom 1159 29
def L1_play : List (Act × St) := pathOf L1_rows
def L1_winAct : Act := (bySeq 1188).act

end Levels
end Game

-- 定理放在根命名空间：装置 `ledger/lean_check.py` 的公理表探针按短名打 `#print axioms`。
open Game Game.Replay Game.Levels

-- `set_option` 的作用域到 `end` 为止：出了命名空间要再说一遍。
set_option maxRecDepth 200000

theorem L1_len : L1_play.length = 29 := by decide

theorem L1_clean :
    (L1_rows.all (fun r => r.lvl == 1 && r.cert && !r.levelup && !r.reset && r.next.isSome)
      && (bySeq 1188).levelup && (bySeq 1188).lvl == 1 && (bySeq 1188).cert) = true := by decide

#eval match firstSplit L1_board L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着真人那条路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L1_trace : traceOk L1_board L1_start L1_play = true := by decide

/-- **这一关走得通。** 见证：那条路的动作，再加过关那一脚。 -/
theorem L1_winnable : Winnable L1_board L1_start :=
  ⟨L1_play.map Prod.fst ++ [L1_winAct], by decide, by decide⟩

#print axioms L1_len
#print axioms L1_clean
#print axioms L1_trace
#print axioms L1_winnable
