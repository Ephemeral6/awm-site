/-
# 第 7 关 —— 走得通（`lean2/export_levels.py` 生成，不要手改）

开局：认证那一段 seq 1362 的前一帧（**从语料的帧里读出来的**，不是手写的盘）。
真人走过的路：seq 1362 .. 1406，45 步，每一步都进路（点击、方向键一步不挑）；
过关那一脚是 seq 1407（.up），它的下一帧已经是下一关的盘，**不进路里**，进 `_winnable` 的见证。

    L7_len        这一段确实是 45 步（切歪了会得到空表，而空表让下一条平凡为真）
    L7_clean      这一段每一行都在第 7 关、属于认证那一段、没有断点
    L7_trace      **模型沿这条路每一帧都和观测对上**：只有开局那一帧是观测给的，后面全是模型自己算的
    L7_winnable   这一关走得通：见证是这 45 步再加过关那一脚，一共 46 步

这一关核过的步数：**45 步逐帧对上 + 1 步过关**。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels
open Replay

-- 语料那张表有一千多行，`decide` 要一层层归约下去：默认的递归深度不够，
-- 不够的时候 Lean **报一行错然后照常往下编**，那条定理的公理表里悄悄多出 `sorryAx`
-- （实测第一版就是这样，而同一份文件里 `#eval` 照样打出「一处都没分家」）。
-- 这一行是独立的一条命令，不能夹在文档注释和定理之间。
set_option maxRecDepth 200000

def L7_board : Board := boardAt (bySeq 1362).board
def L7_start : St := startOf 1362
def L7_rows : List Row := rowsFrom 1362 45
def L7_play : List (Act × St) := pathOf L7_rows
def L7_winAct : Act := (bySeq 1407).act

end Levels
end Game

-- 定理放在根命名空间：装置 `ledger/lean_check.py` 的公理表探针按短名打 `#print axioms`。
open Game Game.Replay Game.Levels

-- `set_option` 的作用域到 `end` 为止：出了命名空间要再说一遍。
set_option maxRecDepth 200000

theorem L7_len : L7_play.length = 45 := by decide

theorem L7_clean :
    (L7_rows.all (fun r => r.lvl == 7 && r.cert && !r.levelup && !r.reset && r.next.isSome)
      && (bySeq 1407).levelup && (bySeq 1407).lvl == 7 && (bySeq 1407).cert) = true := by decide

#eval match firstSplit L7_board L7_start L7_play 0 with
  | none   => "L7  一处都没分家（共 " ++ toString L7_play.length ++ " 步）"
  | some i => "L7  第 " ++ toString i ++ " 步分家"

/-- **模型沿着真人那条路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L7_trace : traceOk L7_board L7_start L7_play = true := by decide

/-- **这一关走得通。** 见证：那条路的动作，再加过关那一脚。 -/
theorem L7_winnable : Winnable L7_board L7_start :=
  ⟨L7_play.map Prod.fst ++ [L7_winAct], by decide, by decide⟩

#print axioms L7_len
#print axioms L7_clean
#print axioms L7_trace
#print axioms L7_winnable
