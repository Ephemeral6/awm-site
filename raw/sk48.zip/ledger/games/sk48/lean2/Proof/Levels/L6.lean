/-
# 第 6 关 —— 走得通（`lean2/export_levels.py` 生成，不要手改）

开局：认证那一段 seq 1335 的前一帧（**从语料的帧里读出来的**，不是手写的盘）。
真人走过的路：seq 1335 .. 1360，26 步，每一步都进路（点击、方向键一步不挑）；
过关那一脚是 seq 1361（.right），它的下一帧已经是下一关的盘，**不进路里**，进 `_winnable` 的见证。

    L6_len        这一段确实是 26 步（切歪了会得到空表，而空表让下一条平凡为真）
    L6_clean      这一段每一行都在第 6 关、属于认证那一段、没有断点
    L6_trace      **模型沿这条路每一帧都和观测对上**：只有开局那一帧是观测给的，后面全是模型自己算的
    L6_winnable   这一关走得通：见证是这 26 步再加过关那一脚，一共 27 步

这一关核过的步数：**26 步逐帧对上 + 1 步过关**。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels
open Replay

-- 语料那张表有一千多行，`decide` 要一层层归约下去：默认的递归深度不够，
-- 不够的时候 Lean **报一行错然后照常往下编**，那条定理的公理表里悄悄多出 `sorryAx`
-- （实测第一版就是这样，而同一份文件里 `#eval` 照样打出「一处都没分家」）。
-- 这一行是独立的一条命令，不能夹在文档注释和定理之间。
set_option maxRecDepth 200000

def L6_board : Board := boardAt (bySeq 1335).board
def L6_start : St := startOf 1335
def L6_rows : List Row := rowsFrom 1335 26
def L6_play : List (Act × St) := pathOf L6_rows
def L6_winAct : Act := (bySeq 1361).act

end Levels
end Game

-- 定理放在根命名空间：装置 `ledger/lean_check.py` 的公理表探针按短名打 `#print axioms`。
open Game Game.Replay Game.Levels

-- `set_option` 的作用域到 `end` 为止：出了命名空间要再说一遍。
set_option maxRecDepth 200000

theorem L6_len : L6_play.length = 26 := by decide

theorem L6_clean :
    (L6_rows.all (fun r => r.lvl == 6 && r.cert && !r.levelup && !r.reset && r.next.isSome)
      && (bySeq 1361).levelup && (bySeq 1361).lvl == 6 && (bySeq 1361).cert) = true := by decide

#eval match firstSplit L6_board L6_start L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- **模型沿着真人那条路一步不差。** 只有开局那一帧是观测给的。 -/
theorem L6_trace : traceOk L6_board L6_start L6_play = true := by decide

/-- **这一关走得通。** 见证：那条路的动作，再加过关那一脚。 -/
theorem L6_winnable : Winnable L6_board L6_start :=
  ⟨L6_play.map Prod.fst ++ [L6_winAct], by decide, by decide⟩

#print axioms L6_len
#print axioms L6_clean
#print axioms L6_trace
#print axioms L6_winnable
