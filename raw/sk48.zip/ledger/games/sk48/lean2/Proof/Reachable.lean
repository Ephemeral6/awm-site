/-
# Reachable —— 这个局面做不做得了（骨架）

    Winnable   b s  :=  ∃ as, 照着走中途赢过
    Unsolvable b s  :=  ∀ as, 每一下合法 → 照着走从没赢过

## 那半句，写在明处

`step` 在 ACTION7 与 RESET 上说不出话（`Res.na`），`everWon` 碰到 `na` 就停下、返回 `false`。
于是 `Unsolvable` 的准确意思是：**不经过 ACTION7、不经过 RESET，就赢不了**。
「合法的一下」因此只许是 上 / 下 / 左 / 右 / 点击（点中谁都行）——这个限制写进了 `Act.legal`。

## 唯一的骨架

    找一个性质 Φ：每走合法的一步都还成立，而且满足 Φ 的局面这一步赢不了。
    那么从满足 Φ 的局面出发，**任何合法动作串都赢不了**。

证明对动作串做归纳，与盘面多大、串多长都无关，**不枚举任何状态**。
这一局全部八关都有真人走通的路（`Proof/Levels/`），所以这一份里**没有一条「这一关走不通」**；
骨架留着，是给以后的钥匙挂的。
-/
import Obj.World
import Step

namespace Game

/-- 合法的一下：方向键与点击。ACTION7 与 RESET 模型不描述，**不算在合法里**。 -/
def Act.legal : Act → Bool
  | .up | .down | .left | .right => true
  | .click _ => true
  | .a7 | .reset => false

/-- 照着 `as` 走，中途赢过没有。碰到模型说不出话的一步就停下（返回 `false`）。 -/
def everWon (b : Board) : St → List Act → Bool
  | _, [] => false
  | s, a :: as =>
    match step b s a with
    | .won _ => true
    | .ok s' => everWon b s' as
    | .na => false

def Winnable (b : Board) (s : St) : Prop :=
  ∃ as : List Act, (∀ a ∈ as, Act.legal a = true) ∧ everWon b s as = true

def Unsolvable (b : Board) (s : St) : Prop :=
  ∀ as : List Act, (∀ a ∈ as, Act.legal a = true) → everWon b s as = false

end Game

-- 定理放在根命名空间（装置的公理表探针按短名打 `#print axioms`）。
open Game

/-- **骨架**：不变量 ⇒ 不可做。全文唯一做归纳的地方。 -/
theorem unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, Act.legal a = true → P s → step b s a = Res.ok s' → P s')
    (hwin : ∀ s a, P s → ∀ s', step b s a ≠ Res.won s') :
    ∀ s, P s → Unsolvable b s := by
  intro s hp as
  induction as generalizing s with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [everWon]
    cases hstep : step b s a with
    | won s' => exact absurd hstep (hwin s a hp s')
    | na => rfl
    | ok s' =>
      exact ih s' (hkeep s s' a (hall a (by simp)) hp hstep) (fun x hx => hall x (by simp [hx]))

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (s : St) (hw : Winnable b s) (hu : Unsolvable b s) : False := by
  obtain ⟨as, hl, h⟩ := hw
  rw [hu as hl] at h
  exact Bool.false_ne_true h

#print axioms unsolvable_of_invariant
#print axioms not_both
