/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    点击            ⇒ ClickSelect
    沿绳的键        ⇒ RopeSlide
    垂直于绳的键    ⇒ PoleSweep
    ACTION7 / RESET ⇒ `na`：**模型在这一步说不出话**（见 `Proof/Reachable.lean` 的那半句）

算完一步先问 `isGoal`：是就 `won`（过关，下一帧是另一张盘，不给出来），否则 `ok`。
选中的既不是横玩家也不是任何一个竖玩家 ⇒ `na`（语料里 0 次）。
-/
import Rule.Move.RopeSlide
import Rule.Move.PoleSweep
import Rule.Move.ClickSelect
import Rule.Win.WinIffThreaded

namespace Game

inductive Res where
  | ok (s : St)
  | won (s : St)
  | na
  deriving DecidableEq, BEq, Repr

def settle (b : Board) (s : St) : Res := if isGoal b s then .won s else .ok s

def step (b : Board) (s : St) (a : Act) : Res :=
  match a, keyAxis s.hSel a with
  | .click t, _ => settle b (clickSelect s t)
  | _, some (along, fwd) =>
    if !s.hSel && s.vSel.isNone then .na
    else settle b (if along then ropeSlide b s fwd else poleSweep b s fwd)
  | _, none => .na

end Game
