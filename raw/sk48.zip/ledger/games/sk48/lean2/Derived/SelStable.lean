/-
# SelStable —— 方向键不换选中　**身份：推论**

「只有点击换选中」在 Python 规则层里没有单独立条：`rope_slide` / `pole_sweep` 主张的是整个下一帧，
选中不变是它们框架条件的一部分。在 Lean 里它**不用再测**：从两条规则的定义直接推出来。
（册子里对应的是 a6_select 那半句「方向键只作用在被选中的那个身上、不改选中」。）
-/
import Obj.World
import Step

-- 定理放在根命名空间（`open Game` 引名字）：装置 `ledger/lean_check.py` 的公理表探针按**短名**打
-- `#print axioms`，放在 `namespace Game` 里它就找不到（见 UNIFY-REPORT「装置事故」）。
open Game

theorem ropeSlideV_sel (b : Board) (s : St) (ext : Bool) : (ropeSlideV b s ext).sel = s.sel := by
  unfold ropeSlideV
  split
  · split <;> rfl
  · rfl

theorem ropeSlide_sel (b : Board) (s : St) (ext : Bool) : (ropeSlide b s ext).sel = s.sel := by
  unfold ropeSlide
  split
  · split
    · split <;> rfl
    · exact ropeSlideV_sel b s ext
  · exact ropeSlideV_sel b s ext

theorem poleSweepV_sel (b : Board) (s : St) (fwd : Bool) : (poleSweepV b s fwd).sel = s.sel := by
  unfold poleSweepV
  split
  · split
    · rfl
    · split
      · rfl
      · split <;> rfl
  · rfl

theorem poleSweep_sel (b : Board) (s : St) (fwd : Bool) : (poleSweep b s fwd).sel = s.sel := by
  unfold poleSweep
  split
  · split
    · split
      · rfl
      · split
        · rfl
        · split <;> rfl
    · exact poleSweepV_sel b s fwd
  · exact poleSweepV_sel b s fwd

theorem settle_eq (b : Board) (x s' : St) (h : settle b x = .ok s' ∨ settle b x = .won s') : s' = x := by
  unfold settle at h
  split at h <;> rcases h with h | h <;> simp_all

/-- **推论**：按方向键（`keyAxis` 认得的那四个键），不论走成什么样，选中都不变。 -/
theorem step_arrow_keeps_sel (b : Board) (s s' : St) (a : Act) (ha : keyAxis s.hSel a ≠ none)
    (h : step b s a = .ok s' ∨ step b s a = .won s') : s'.sel = s.sel := by
  cases a with
  | click t => simp [keyAxis] at ha
  | a7 => simp [keyAxis] at ha
  | reset => simp [keyAxis] at ha
  | up | down | left | right =>
    simp only [step, keyAxis] at h
    split at h
    · rcases h with h | h <;> simp at h
    · have e := settle_eq _ _ _ h
      subst e
      split
      · exact ropeSlide_sel b s _
      · exact poleSweep_sel b s _

#print axioms settle_eq
#print axioms step_arrow_keeps_sel
#print axioms ropeSlideV_sel
#print axioms ropeSlide_sel
#print axioms poleSweepV_sel
#print axioms poleSweep_sel
