/-
# RopeLimit —— 横绳伸不出棋盘　**身份：推论**

册子里的 `rope_limit`（「绳长不超过列数」）是一条每帧去测的概念。
在这一套里它**不是一条独立的规则**：`RopeSlide` 伸绳之前先问「伸满了没有」，
于是「一步之后横绳长度 ≤ 列数」是从定义推出来的，每走一步都保持。
-/
import Obj.World
import Derived.SelStable

namespace Game

def hRopeOk (b : Board) (s : St) : Prop :=
  match s.h with
  | some h => h.rope ≤ b.grid.cols
  | none => True

end Game

-- 定理放在根命名空间（理由同 SelStable.lean 文件头）。
open Game

theorem ropeCore_ext_lt (w p : List Cell) (s : St) (ln : Line) (n : Nat) (bl : List Block)
    (h : ropeCore w p s ln n true = some bl) : n < ln.len := by
  unfold ropeCore at h
  split at h
  · exact absurd h (by simp)
  · rename_i hc
    simp only [Bool.true_and, Bool.or_eq_true, decide_eq_true_eq] at hc
    omega

theorem ropeSlideV_h (b : Board) (s : St) (ext : Bool) : (ropeSlideV b s ext).h = s.h := by
  unfold ropeSlideV
  split
  · split <;> rfl
  · rfl

theorem poleSweepV_h (b : Board) (s : St) (fwd : Bool) : (poleSweepV b s fwd).h = s.h := by
  unfold poleSweepV
  split
  · split
    · rfl
    · split
      · rfl
      · split <;> rfl
  · rfl

theorem ropeSlide_keeps (b : Board) (s : St) (ext : Bool) (hs : hRopeOk b s) :
    hRopeOk b (ropeSlide b s ext) := by
  unfold ropeSlide
  split
  · rename_i h hh
    split
    · split
      · rename_i bl hc
        simp only [hRopeOk]
        simp only [hRopeOk, hh] at hs
        cases ext with
        | true =>
          have := ropeCore_ext_lt _ _ _ _ _ _ hc
          simp at this
          simp [stepLen]
          omega
        | false =>
          simp only [stepLen]
          simp
          omega
      · exact hs
    · simp only [hRopeOk, ropeSlideV_h]; exact hs
  · simp only [hRopeOk, ropeSlideV_h]; exact hs

theorem poleSweep_keeps (b : Board) (s : St) (fwd : Bool) (hs : hRopeOk b s) :
    hRopeOk b (poleSweep b s fwd) := by
  unfold poleSweep
  split
  · rename_i h hh
    split
    · split
      · exact hs
      · split
        · exact hs
        · split
          · simp only [hRopeOk]; simp only [hRopeOk, hh] at hs; exact hs
          · exact hs
    · simp only [hRopeOk, poleSweepV_h]; exact hs
  · simp only [hRopeOk, poleSweepV_h]; exact hs

theorem clickSelect_h (s : St) (t : Option Nat) : (clickSelect s t).h = s.h := by
  unfold clickSelect
  split
  · split <;> rfl
  · rfl

/-- **推论**：从横绳没伸出棋盘的局面走任何一步，横绳仍然没伸出棋盘。 -/
theorem step_keeps_hrope (b : Board) (s s' : St) (a : Act) (hs : hRopeOk b s)
    (h : step b s a = .ok s' ∨ step b s a = .won s') : hRopeOk b s' := by
  cases a with
  | click t =>
    simp only [step] at h
    have e := settle_eq _ _ _ h
    subst e
    simp only [hRopeOk, clickSelect_h]; exact hs
  | a7 => simp [step, keyAxis] at h
  | reset => simp [step, keyAxis] at h
  | up | down | left | right =>
    simp only [step, keyAxis] at h
    split at h
    · rcases h with h | h <;> simp at h
    · have e := settle_eq _ _ _ h
      subst e
      split
      · exact ropeSlide_keeps b s _ hs
      · exact poleSweep_keeps b s _ hs

#print axioms ropeCore_ext_lt
#print axioms ropeSlideV_h
#print axioms poleSweepV_h
#print axioms ropeSlide_keeps
#print axioms poleSweep_keeps
#print axioms clickSelect_h
#print axioms step_keeps_hrope
