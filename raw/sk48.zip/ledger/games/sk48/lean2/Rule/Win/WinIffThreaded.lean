/-
# WinIffThreaded —— 什么算赢（Python：`rule/什么算赢/win_iff_threaded.py`）　**身份：定义**

赢是一个**状态性质**：每根绳从绳主往外数第 j 颗靶恰好是示意图那一组第 j 个颜色（空格跳过、多串的不算）。
「这一步过关 ⟺ 这一步走完之后赢了」在 `Step.lean` 里就是 `step` 的写法：算完一步先问 `isGoal`。
-/
import Obj.Derive.Beads

namespace Game

def isGoal (b : Board) (s : St) : Bool := won b s

end Game
