/-
# PoleSweep —— 杆平移（Python：`rule/一步怎么走/pole_sweep.py`）　**身份：定义**

按垂直于绳的键：玩家挪到相邻一条线（出盘 / 出轨 / 杆盖得到的格在新那条线上有墙 ⇒ 不变）。
杆盖住的每一格各自结算：它有靶就从它起、没有而挪过去那一格有靶就从那一格起，
沿挪动方向连着的一串整串挪一格；任何一串会被推出盘 ⇒ 不变。

`dest c` 是格 `c` 挪一步之后的那一格（出盘给 `none`）。`sweepCore` 返回 `none` 表示「整个世界不变」。
-/
import Obj.Derive.Line

namespace Game

/-- 从 `x` 起沿 `dest` 连着有靶的格，最多 `fuel` 格。 -/
def chainFrom (s : St) (dest : Cell → Option Cell) : Cell → Nat → List Cell
  | _, 0 => []
  | x, fuel + 1 =>
    if s.has x then
      x :: (match dest x with
            | some y => chainFrom s dest y fuel
            | none => [])
    else []

def sweepCore (b : Board) (s : St) (pole : List Cell) (dest : Cell → Option Cell) : Option (List Block) :=
  let fuel := b.grid.rows + b.grid.cols
  let cells := pole.flatMap (fun p =>
    if s.has p then chainFrom s dest p fuel
    else match dest p with
      | some q => if s.has q then chainFrom s dest q fuel else []
      | none => [])
  if cells.any (fun x => (dest x).isNone) then none
  else some (s.blocks.map (fun bl =>
    if cells.contains bl.cell then
      match dest bl.cell with
      | some y => { bl with cell := y }
      | none => bl
    else bl))

/-- 行方向挪一格（`fwd` = 往下）。 -/
def downOrUp (rows : Nat) (fwd : Bool) (c : Cell) : Option Cell :=
  if fwd then (if c.row + 1 < rows then some ⟨c.row + 1, c.col⟩ else none)
  else (if c.row == 0 then none else some ⟨c.row - 1, c.col⟩)

/-- 列方向挪一格（`fwd` = 往右）。 -/
def rightOrLeft (cols : Nat) (fwd : Bool) (c : Cell) : Option Cell :=
  if fwd then (if c.col + 1 < cols then some ⟨c.row, c.col + 1⟩ else none)
  else (if c.col == 0 then none else some ⟨c.row, c.col - 1⟩)

def railOk (r : Option Rail) (k : Nat) : Bool :=
  match r with
  | some r => r.covers k
  | none => false

-- 下面两份**不用 `let`**：`def` 里的 `let` 会让 `split` 进不去（Derived/ 里的推论要拆它）。

def poleSweepV (b : Board) (s : St) (fwd : Bool) : St :=
  match s.vSel with
  | some v =>
    match rightOrLeft b.grid.cols fwd ⟨0, v.col⟩ with
    | none => s
    | some t0 =>
      if !(railOk b.vrail t0.col) || (vCells v.col v.rope b.grid.rows).any (fun c => b.isWall ⟨c.row, t0.col⟩) then s
      else match sweepCore b s (vCells v.col v.rope b.grid.rows) (rightOrLeft b.grid.cols fwd) with
        | some bl => { s with blocks := bl,
                              vs := s.vs.map (fun x => if x.owner == v.owner then { x with col := t0.col } else x) }
        | none => s
  | none => s

def poleSweep (b : Board) (s : St) (fwd : Bool) : St :=
  match s.h with
  | some h =>
    if h.owner == s.sel then
      match downOrUp b.grid.rows fwd ⟨h.row, 0⟩ with
      | none => s
      | some t0 =>
        if !(railOk b.hrail t0.row) || (hCells h.row h.rope b.grid.cols).any (fun c => b.isWall ⟨t0.row, c.col⟩) then s
        else match sweepCore b s (hCells h.row h.rope b.grid.cols) (downOrUp b.grid.rows fwd) with
          | some bl => { s with blocks := bl, h := some { h with row := t0.row } }
          | none => s
    else poleSweepV b s fwd
  | none => poleSweepV b s fwd

end Game
