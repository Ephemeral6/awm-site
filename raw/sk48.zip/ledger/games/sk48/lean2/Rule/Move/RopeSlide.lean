/-
# RopeSlide —— 绳伸缩（Python：`rule/一步怎么走/rope_slide.py`）　**身份：定义**

按沿绳的键：绳长 ±1（缩到 0、伸满、伸的那一格是墙 ⇒ 不变）。
绳上每颗靶朝同一方向各挪一格——被钉住的、目标被钉住的、目标被一颗不挪的靶占着的，不挪；
伸的时候绳尖前面连着的一串被整串推一格（串里有钉子、或串尾外是盘边 / 钉子 / 墙 ⇒ 这一串不动，绳照样伸过去）。

`ropeCore` 返回 `none` 表示「整个世界不变」。
-/
import Obj.Derive.Line

namespace Game

/-- 从第 `i` 格起沿线连着有靶的格号，最多 `fuel` 格。 -/
def runFrom (s : St) (ln : Line) : Nat → Nat → List Nat
  | _, 0 => []
  | i, fuel + 1 => if i < ln.len && s.has (ln.cellAt i) then i :: runFrom s ln (i + 1) fuel else []

/-- 一颗在第 `i` 格的靶，挪到第 `t` 格去被不被拦下（钉子 / 出线 / 被一颗不挪的靶占着）。 -/
def blocked (s : St) (ln : Line) (pins : List Cell) (acc run : List Nat) (t : Nat) : Bool :=
  !(t < ln.len) || pins.contains (ln.cellAt t) ||
    (s.has (ln.cellAt t) && !(acc.contains t) && !(run.contains t))

def ropeCore (walls pins : List Cell) (s : St) (ln : Line) (n : Nat) (ext : Bool) : Option (List Block) :=
  if ext && (decide (ln.len ≤ n) || walls.contains (ln.cellAt n)) then none
  else if !ext && n == 0 then none
  else
    let occ := (List.range (min n ln.len)).filter (fun i => s.has (ln.cellAt i))
    let run := if ext then runFrom s ln n ln.len else []
    let runOk : Bool :=
      match run.getLast? with
      | none => false
      | some last =>
        !(run.any (fun i => pins.contains (ln.cellAt i))) && last + 1 < ln.len &&
          !(pins.contains (ln.cellAt (last + 1))) && !(walls.contains (ln.cellAt (last + 1)))
    let movingRun := if runOk then run else []
    let order := if ext then occ.reverse else occ
    let moving := order.foldl (fun acc i =>
        if pins.contains (ln.cellAt i) then acc
        else if ext then (if blocked s ln pins acc movingRun (i + 1) then acc else acc ++ [i])
        else if i == 0 then acc
        else if blocked s ln pins acc movingRun (i - 1) then acc else acc ++ [i]) []
    let go := movingRun ++ moving
    some (s.blocks.map (fun bl =>
      match go.find? (fun i => ln.cellAt i == bl.cell) with
      | some i => { bl with cell := ln.cellAt (if ext then i + 1 else i - 1) }
      | none => bl))

def stepLen (ext : Bool) (n : Nat) : Nat := if ext then n + 1 else n - 1

/-- 选中的是竖玩家：它那一列就是这条线。 -/
def ropeSlideV (b : Board) (s : St) (ext : Bool) : St :=
  match s.vSel with
  | some v =>
    match ropeCore b.walls (pinsOf b s v.owner) s ⟨fun i => ⟨i, v.col⟩, b.grid.rows⟩ v.rope ext with
    | some bl => { s with blocks := bl,
                          vs := s.vs.map (fun x => if x.owner == v.owner then { x with rope := stepLen ext x.rope } else x) }
    | none => s
  | none => s

/-- 选中的是横玩家：它那一行就是这条线；否则交给竖玩家那一支。 -/
def ropeSlide (b : Board) (s : St) (ext : Bool) : St :=
  match s.h with
  | some h =>
    if h.owner == s.sel then
      match ropeCore b.walls (pinsOf b s h.owner) s ⟨fun i => ⟨h.row, i⟩, b.grid.cols⟩ h.rope ext with
      | some bl => { s with blocks := bl, h := some { h with rope := stepLen ext h.rope } }
      | none => s
    else ropeSlideV b s ext
  | none => ropeSlideV b s ext

end Game
