/-
# ClickSelect —— 点击换选中（Python：`rule/一步怎么走/click_select.py`）　**身份：定义**

点中某个玩家（横 / 竖）的精灵 ⇒ 选中换成它；点在别处（记号不是玩家，或者 `none`）⇒ 不变。
-/
import Obj.World

namespace Game

def isMover (s : St) (o : Nat) : Bool :=
  (match s.h with | some h => h.owner == o | none => false) || s.vs.any (fun v => v.owner == o)

def clickSelect (s : St) (t : Option Nat) : St :=
  match t with
  | some o => if isMover s o then { s with sel := o } else s
  | none => s

end Game
