/-
# 规则 nothing_else_changes —— **推论**，不是定义   （对应 `rule/step/nothing_else_changes.py`）

Python 那一条说两件事：

1. **版面、题面、调色板、底板一步之内不变。** 在这里它是 `rfl`——
   `World.step` 把 `board` 原样放回去，`step` 的签名根本交不出一个新 `Board`。
   这一半**表示不出来会错**，所以它不是一条要每帧去测的规则，是架构本身。
2. **没被点、也没被记号牵动的瓦片底色不变。** 由 `step` 的定义推出（下面那条定理）。

一条规则重排之后掉进 `Derived/`，说明它本来就不是一条独立的规则：
它是另外两条规则（点中的那块 / 被牵动的那几块）加上「`step` 只动它们」的推论。
-/

import Obj.World
import Step

/-- 一半：版面不变。**它是 `rfl`**——那正是「表示不出来」的意思。 -/
theorem board_fixed (w : World) (a : Act) : (w.step a).board = w.board := rfl

/-- 另一半：不在「被点 + 被牵动」名单里的那块瓦片，走一步之后底色原样。 -/
theorem nothing_else_changes (w : World) (a : Act) (i : Nat)
    (h : (w.board.moved a).contains i = false) :
    (w.step a).colors[i]? = w.colors[i]? := by
  have h' : i ∉ w.board.moved a := by simpa using h
  simp only [World.step, step, List.getElem?_mapIdx]
  cases hc : w.colors[i]? with
  | none => rfl
  | some c => simp [h']

#print axioms board_fixed
#print axioms nothing_else_changes
