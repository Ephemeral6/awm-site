/-
# Levels —— 每一关一条定理（自动生成：`python lean2/export_levels.py`，不要手改）

只用成绩单认证的那一段（seq 88..168）。每关：`_len` / `_trace` / `_winnable` / `_not_goal_at_start`。
只有开局那一帧是观测给的，后面全是模型自己算的。

    关   开局 seq   逐帧核过的步数   + 过关那一脚
    L0   seq 89              3          + 1
    L1   seq 93              6          + 1
    L2   seq 100            13          + 1
    L3   seq 114            20          + 1
    L4   seq 135            20          + 1
    L5   seq 156            12          + 1

**这一局没有任何一关被宣告不可做**：六关都有 `_winnable`（真人走通的那条路就是见证）。
`Unsolvable` 在 `Proof/Reachable.lean`，准确的意思是「只靠点击、不经过重开就到不了」。

**一条明写的假设**：重开把局面放回开局。它不进模型；每关的路都没被重开切开，所以每关的定理用不上它。
`restart_matches_opening` 给它一次被驳倒的机会——**没红不构成证明**（只有一次，且是从通关画面重开）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

/-- 第 0 关的真实开局（认证段 seq 89 那一帧，从语料读出来的）。 -/
def L0_start : World := (bySeq 89).before

/-- 开局到过关前一步，3 步。过关那一脚（seq 92）不在这里：它的下一帧是下一关的盘。 -/
def L0_play : List (Act × World) := playFrom 89 3

def L0_winAct : Act := (bySeq 92).act.getD .void

theorem L0_len : (L0_play : List (Act × World)).length = 3 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L0_trace : traceOk (L0_start : World) L0_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 3 步再加过关那一脚，每一下都合法。 -/
theorem L0_winnable : Winnable (L0_start : World) :=
  ⟨L0_play.map Prod.fst ++ [L0_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L0_not_goal_at_start : (L0_start : World).isGoal = false := by decide +kernel

#print axioms L0_len
#print axioms L0_trace
#print axioms L0_winnable
#print axioms L0_not_goal_at_start

/-- 第 1 关的真实开局（认证段 seq 93 那一帧，从语料读出来的）。 -/
def L1_start : World := (bySeq 93).before

/-- 开局到过关前一步，6 步。过关那一脚（seq 99）不在这里：它的下一帧是下一关的盘。 -/
def L1_play : List (Act × World) := playFrom 93 6

def L1_winAct : Act := (bySeq 99).act.getD .void

theorem L1_len : (L1_play : List (Act × World)).length = 6 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L1_trace : traceOk (L1_start : World) L1_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 6 步再加过关那一脚，每一下都合法。 -/
theorem L1_winnable : Winnable (L1_start : World) :=
  ⟨L1_play.map Prod.fst ++ [L1_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L1_not_goal_at_start : (L1_start : World).isGoal = false := by decide +kernel

#print axioms L1_len
#print axioms L1_trace
#print axioms L1_winnable
#print axioms L1_not_goal_at_start

/-- 第 2 关的真实开局（认证段 seq 100 那一帧，从语料读出来的）。 -/
def L2_start : World := (bySeq 100).before

/-- 开局到过关前一步，13 步。过关那一脚（seq 113）不在这里：它的下一帧是下一关的盘。 -/
def L2_play : List (Act × World) := playFrom 100 13

def L2_winAct : Act := (bySeq 113).act.getD .void

theorem L2_len : (L2_play : List (Act × World)).length = 13 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L2_trace : traceOk (L2_start : World) L2_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 13 步再加过关那一脚，每一下都合法。 -/
theorem L2_winnable : Winnable (L2_start : World) :=
  ⟨L2_play.map Prod.fst ++ [L2_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L2_not_goal_at_start : (L2_start : World).isGoal = false := by decide +kernel

#print axioms L2_len
#print axioms L2_trace
#print axioms L2_winnable
#print axioms L2_not_goal_at_start

/-- 第 3 关的真实开局（认证段 seq 114 那一帧，从语料读出来的）。 -/
def L3_start : World := (bySeq 114).before

/-- 开局到过关前一步，20 步。过关那一脚（seq 134）不在这里：它的下一帧是下一关的盘。 -/
def L3_play : List (Act × World) := playFrom 114 20

def L3_winAct : Act := (bySeq 134).act.getD .void

theorem L3_len : (L3_play : List (Act × World)).length = 20 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L3_trace : traceOk (L3_start : World) L3_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 20 步再加过关那一脚，每一下都合法。 -/
theorem L3_winnable : Winnable (L3_start : World) :=
  ⟨L3_play.map Prod.fst ++ [L3_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L3_not_goal_at_start : (L3_start : World).isGoal = false := by decide +kernel

#print axioms L3_len
#print axioms L3_trace
#print axioms L3_winnable
#print axioms L3_not_goal_at_start

/-- 第 4 关的真实开局（认证段 seq 135 那一帧，从语料读出来的）。 -/
def L4_start : World := (bySeq 135).before

/-- 开局到过关前一步，20 步。过关那一脚（seq 155）不在这里：它的下一帧是下一关的盘。 -/
def L4_play : List (Act × World) := playFrom 135 20

def L4_winAct : Act := (bySeq 155).act.getD .void

theorem L4_len : (L4_play : List (Act × World)).length = 20 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L4_trace : traceOk (L4_start : World) L4_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 20 步再加过关那一脚，每一下都合法。 -/
theorem L4_winnable : Winnable (L4_start : World) :=
  ⟨L4_play.map Prod.fst ++ [L4_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L4_not_goal_at_start : (L4_start : World).isGoal = false := by decide +kernel

#print axioms L4_len
#print axioms L4_trace
#print axioms L4_winnable
#print axioms L4_not_goal_at_start

/-- 第 5 关的真实开局（认证段 seq 156 那一帧，从语料读出来的）。 -/
def L5_start : World := (bySeq 156).before

/-- 开局到过关前一步，12 步。过关那一脚（seq 168）不在这里：它的下一帧是通关画面（同一张盘）。 -/
def L5_play : List (Act × World) := playFrom 156 12

def L5_winAct : Act := (bySeq 168).act.getD .void

theorem L5_len : (L5_play : List (Act × World)).length = 12 := by decide +kernel

/-- **模型沿着这条路一步不差**，路上没有提前到齐。 -/
theorem L5_trace : traceOk (L5_start : World) L5_play = true := by decide +kernel

/-- **这一关走得通。** 见证：那 12 步再加过关那一脚，每一下都合法。 -/
theorem L5_winnable : Winnable (L5_start : World) :=
  ⟨L5_play.map Prod.fst ++ [L5_winAct], by decide +kernel, by decide +kernel⟩

/-- 而且不是开局就已经到齐。 -/
theorem L5_not_goal_at_start : (L5_start : World).isGoal = false := by decide +kernel

#print axioms L5_len
#print axioms L5_trace
#print axioms L5_winnable
#print axioms L5_not_goal_at_start

/-- 「重开把局面放回开局」的**唯一一次被驳倒的机会**：seq 88 重开之后那一帧 = 语料第一帧（seq 1）。 -/
theorem restart_matches_opening : ((bySeq 88).after : World) = (bySeq 1).before := by decide +kernel

#print axioms restart_matches_opening
