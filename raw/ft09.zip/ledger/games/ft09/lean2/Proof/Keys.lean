/-
# Keys —— 「不可做」的钥匙，每把配三条防线

这一局语料里六关都走通了，**没有任何一关被宣告不可做**。这一份不是在给某一关下结论，
是在证明这套模型**说得出**「做不了」——而且说的时候有防线，不是对谁都说不可做。

## 钥匙一：调色板造不出点亮色

某个网格的点亮色**不在**本关调色板里，而它外环上有一块 ON 位置的瓦片此刻不是点亮色
⇒ 那块瓦片永远变不成点亮色（点一下只会沿调色板前进，造不出调色板外的色）⇒ 永远到不了。

它不是「挡住了」（这一局没有任何阻挡）：它是一个**守恒的性质**——「这块不是点亮色」每走一步都还成立。
证明对动作串做归纳（骨架 `unsolvable_of_invariant`），**不枚举任何状态**，与盘面大小无关。

## 三条防线（`scene1`：一张只差一处的盘）

    scene1_winnable        调色板里补上点亮色，那张盘点一下就赢
    scene1_closed_at_start 而且不是开局就已经赢了
    scene1_not_key         而且钥匙在那张盘上**前提真的不满足**（点亮色在调色板里）——
                           钥匙套不上去是因为那张盘不是那种盘，不是因为我没找到证明

## 边界写在明处

`step` 没有重开那一支（重开不进模型），所以 `scene0_unsolvable` 的准确意思是
**「只靠点击、不经过重开，就到不了」**。
-/

import Obj.World
import Step
import Proof.Reachable


/-- 一步之后第 i 块的底色：在「被动」名单里就前进一位，否则原样。 -/
theorem step_color (w : World) (a : Act) (i : Nat) :
    (w.step a).colors[i]? =
      w.colors[i]?.map (fun c => if (w.board.moved a).contains i then advance w.board.palette c else c) := by
  simp only [World.step, step, List.getElem?_mapIdx]

/-- 调色板外的色，在这个世界的调色板上前进一位也到不了它。 -/
theorem advance_ne (w : World) (c lit : Nat) (hlit : lit ∉ w.board.palette) (hc : c ≠ lit) :
    advance w.board.palette c ≠ lit := by
  unfold advance
  split
  · rw [List.getD_eq_getElem?_getD]
    cases h : w.board.palette[(_ + 1) % w.board.palette.length]? with
    | none => simpa using hc
    | some x =>
      simp only [Option.getD_some]
      intro hx
      exact hlit (hx ▸ List.mem_of_getElem? h)
  · exact hc

/-- 钥匙一的不变量：网格 `g` 在盘上、点亮色不在调色板里、外环有一块 ON 位置的瓦片此刻不是点亮色。 -/
def Key (g : Grid) (w : World) : Prop :=
  g ∈ w.board.grids ∧ g.lit ∉ w.board.palette ∧
    ∃ p ∈ g.ring, p.2 = .on ∧ ∃ c, p.1.bind w.colorAt = some c ∧ c ≠ g.lit

theorem key_keep (g : Grid) : ∀ w a, Act.legal w a = true → Key g w → Key g (w.step a) := by
  intro w a _ ⟨hg, hlit, p, hp, hon, c, hc, hne⟩
  refine ⟨hg, hlit, p, hp, hon, ?_⟩
  cases hp1 : p.1 with
  | none => simp [hp1] at hc
  | some cell =>
    simp only [hp1, Option.bind_some, World.colorAt] at hc ⊢
    cases hi : w.board.indexOf cell with
    | none => simp [hi] at hc
    | some i =>
      simp only [hi, Option.bind_some] at hc
      have hb : (w.step a).board = w.board := rfl
      simp only [hb, hi, Option.bind_some, step_color, hc, Option.map_some]
      split
      · exact ⟨_, rfl, advance_ne w _ _ hlit hne⟩
      · exact ⟨_, rfl, hne⟩

theorem key_no_goal (g : Grid) (w : World) (h : Key g w) : w.isGoal = false := by
  obtain ⟨hg, _, p, hp, hon, c, hc, hne⟩ := h
  have hdone : w.gridDone g = false := by
    simp only [World.gridDone, Bool.and_eq_false_iff]
    left; left; left
    rw [List.all_eq_false]
    refine ⟨(p.1.bind w.colorAt, p.2), List.mem_map.mpr ⟨p, hp, rfl⟩, ?_⟩
    simp [hon, hc, hne]
  simp only [World.isGoal, List.all_eq_false]
  exact ⟨g, hg, by simp [hdone]⟩

theorem key_no_win (g : Grid) : ∀ w a, Act.legal w a = true → Key g w → (w.step a).isGoal = false :=
  fun w a hl h => key_no_goal g (w.step a) (key_keep g w a hl h)

/-- **钥匙一挂上骨架**：满足它的局面，只靠点击怎么走都到不了。 -/
theorem unsolvable_by_key (g : Grid) (w : World) (h : Key g w) : Unsolvable w :=
  unsolvable_of_invariant (Key g) (key_keep g) (key_no_win g) w h

/-! ## 教学盘：一张做不了的，一张只差一处、做得了的 -/

/-- 一个网格，中心在 (0,1,1)，外环只有正上方那一格有瓦片（ON），点亮色 3。 -/
def g0 : Grid := ⟨⟨0, 1, 1⟩, 3, [.none, .on, .none, .none, .none, .none, .none, .none]⟩

/-- 调色板 [1, 2]：**造不出 3**。 -/
def scene0 : World := ⟨⟨[1, 2], [⟨⟨0, 0, 1⟩, []⟩], [g0], 0⟩, [1]⟩

/-- 只差一处：调色板换成 [1, 3]。 -/
def scene1 : World := ⟨⟨[1, 3], [⟨⟨0, 0, 1⟩, []⟩], [g0], 0⟩, [1]⟩

theorem scene0_key : Key g0 (scene0 : World) := by
  refine ⟨by decide, by decide, (some ⟨0, 0, 1⟩, .on), by decide, rfl, 1, by decide, by decide⟩

/-- **scene0 做不了**（只靠点击、不经过重开）。 -/
theorem scene0_unsolvable : Unsolvable (scene0 : World) := unsolvable_by_key g0 scene0 scene0_key

/-- 防线一：只差一处的那张盘，点一下就赢。 -/
theorem scene1_winnable : Winnable (scene1 : World) := ⟨[.click ⟨0, 0, 1⟩], by decide, by decide⟩

/-- 防线二：而且不是开局就已经赢了。 -/
theorem scene1_closed_at_start : (scene1 : World).isGoal = false := by decide

/-- 防线三：钥匙在那张盘上**前提真的不满足**（点亮色 3 在调色板里）。 -/
theorem scene1_not_key : ¬ Key g0 (scene1 : World) := by
  intro ⟨_, h, _⟩
  exact h (by decide)

/-! ## 钥匙二：题面自相矛盾

两个网格共用一块外环瓦片，两边都在那个位置写 ON，而两个网格的点亮色不同
⇒ 那块瓦片要同时是两个色 ⇒ 永远到不了。

理由和钥匙一**真的不同**：钥匙一是「调色板造不出」（一个守恒的性质，每一步都要证它还成立），
钥匙二是「题面本身要求矛盾」——调色板里两个色都有，点多少下都没用。
它的不变量只看版面，而版面一步之内不变（`board_fixed` 那一条的道理），所以「每步保持」是一行。 -/

/-- 一个网格到齐了，它外环上写 ON 的那一格就一定是点亮色。 -/
theorem on_color (w : World) (g : Grid) (cell : Cell)
    (hmem : (some cell, Code.on) ∈ g.ring) (hd : w.gridDone g = true) :
    w.colorAt cell = some g.lit := by
  simp only [World.gridDone, Bool.and_eq_true] at hd
  obtain ⟨⟨⟨hon, _⟩, _⟩, _⟩ := hd
  rw [List.all_eq_true] at hon
  have := hon _ (List.mem_map.mpr ⟨_, hmem, rfl⟩)
  simpa using this

def Key2 (g1 g2 : Grid) (cell : Cell) (w : World) : Prop :=
  g1 ∈ w.board.grids ∧ g2 ∈ w.board.grids ∧ (some cell, Code.on) ∈ g1.ring ∧
    (some cell, Code.on) ∈ g2.ring ∧ g1.lit ≠ g2.lit

theorem key2_no_goal (g1 g2 : Grid) (cell : Cell) (w : World) (h : Key2 g1 g2 cell w) :
    w.isGoal = false := by
  obtain ⟨h1, h2, m1, m2, hne⟩ := h
  cases hg : w.isGoal with
  | false => rfl
  | true =>
    simp only [World.isGoal, List.all_eq_true] at hg
    have c1 := on_color w g1 cell m1 (hg g1 h1)
    have c2 := on_color w g2 cell m2 (hg g2 h2)
    rw [c1] at c2
    exact absurd (Option.some.inj c2) hne

/-- **钥匙二挂上骨架。** 每步保持只有一行：版面一步之内不变。 -/
theorem unsolvable_by_key2 (g1 g2 : Grid) (cell : Cell) (w : World) (h : Key2 g1 g2 cell w) :
    Unsolvable w :=
  unsolvable_of_invariant (Key2 g1 g2 cell) (fun _ _ _ h => h)
    (fun w a _ h => key2_no_goal g1 g2 cell (w.step a) h) w h

/-- 两个网格左右相邻，共用中间那一格 (0,1,2)：左边点亮色 1，右边点亮色 2，两边都在那一格写 ON。 -/
def gl : Grid := ⟨⟨0, 1, 1⟩, 1, [.none, .none, .none, .none, .on, .none, .none, .none]⟩
def gr2 : Grid := ⟨⟨0, 1, 3⟩, 2, [.none, .none, .none, .on, .none, .none, .none, .none]⟩
def gr1 : Grid := ⟨⟨0, 1, 3⟩, 1, [.none, .none, .none, .on, .none, .none, .none, .none]⟩

def scene2 : World := ⟨⟨[1, 2], [⟨⟨0, 1, 2⟩, []⟩], [gl, gr2], 0⟩, [2]⟩
/-- 只差一处：右边那个网格的点亮色也是 1。 -/
def scene3 : World := ⟨⟨[1, 2], [⟨⟨0, 1, 2⟩, []⟩], [gl, gr1], 0⟩, [2]⟩

theorem scene2_unsolvable : Unsolvable (scene2 : World) :=
  unsolvable_by_key2 gl gr2 ⟨0, 1, 2⟩ scene2 ⟨by decide, by decide, by decide, by decide, by decide⟩

theorem scene3_winnable : Winnable (scene3 : World) := ⟨[.click ⟨0, 1, 2⟩], by decide, by decide⟩
theorem scene3_closed_at_start : (scene3 : World).isGoal = false := by decide
theorem scene3_not_key2 : ¬ Key2 gl gr1 ⟨0, 1, 2⟩ (scene3 : World) := by
  intro ⟨_, _, _, _, h⟩
  exact h rfl

#print axioms on_color
#print axioms key2_no_goal
#print axioms unsolvable_by_key2
#print axioms scene2_unsolvable
#print axioms scene3_winnable
#print axioms scene3_closed_at_start
#print axioms scene3_not_key2

#print axioms step_color
#print axioms advance_ne
#print axioms key_keep
#print axioms key_no_goal
#print axioms key_no_win
#print axioms unsolvable_by_key
#print axioms scene0_key
#print axioms scene0_unsolvable
#print axioms scene1_winnable
#print axioms scene1_closed_at_start
#print axioms scene1_not_key
