/-
# Reachable —— 这个局面做不做得了

    everGoal w as    从 w 起照着 as 走，途中有没有哪一刻到齐过
    Winnable w    := ∃ as, everGoal w as = true
    Unsolvable w  := ∀ as, (每一下合法) → everGoal w as = false

## 合法的一步

这一局唯一的动作是点一下。模型里的 `Act.click c` 可以点任何槽位，**但点空、点在中心上
在模型里什么也不动**（`step` 只动 `moved` 里的那几块），所以不需要另外把动作限死：
一步不可能「跨过」任何东西——这一局没有位移。`legal` 仍然写出来，给骨架用：
点的必须是这张盘上的一块瓦片（这是这一局真有的那一种动作）。

## 骨架：不变量 ⇒ 不可做

全文唯一做归纳的地方，与盘面大小、动作串长短都无关，**不枚举任何状态**。

## 「不经过重开就赢不了」

`step` 没有重开那一支（重开不进模型），所以 `Unsolvable` 的准确意思是
**「只靠点击、不经过重开，就赢不了」**。这一局语料里每一关都走通了（`Proof/Levels.lean`），
这里没有任何一关被宣告不可做；骨架留着，是给「一个具体局面为什么做不了」用的。
-/

import Obj.World
import Step

def everGoal (w : World) : List Act → Bool
  | []      => false
  | a :: as => (w.step a).isGoal || everGoal (w.step a) as

def Act.legal (w : World) : Act → Bool
  | .click c => (w.board.indexOf c).isSome
  | .void    => false

def Winnable (w : World) : Prop :=
  ∃ as : List Act, as.all (Act.legal w) = true ∧ everGoal w as = true

def Unsolvable (w : World) : Prop :=
  ∀ as : List Act, as.all (Act.legal w) = true → everGoal w as = false

/-- 一步之内版面不变，所以「合法」这件事走一步之后照样成立（它只看版面）。 -/
theorem legal_step (w : World) (a b : Act) : Act.legal (w.step a) b = Act.legal w b := by
  cases b <;> rfl

/-- **骨架**：Φ 每走一步都还成立（`hkeep`），满足 Φ 的局面这一步不可能到齐（`hwin`）
    ⇒ 从满足 Φ 的局面出发，**任何**合法动作串都到不了。 -/
theorem unsolvable_of_invariant (P : World → Prop)
    (hkeep : ∀ w a, Act.legal w a = true → P w → P (w.step a))
    (hwin : ∀ w a, Act.legal w a = true → P w → (w.step a).isGoal = false) :
    ∀ w, P w → Unsolvable w := by
  intro w hp as
  induction as generalizing w with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [List.all_cons, Bool.and_eq_true] at hall
    obtain ⟨ha, hrest⟩ := hall
    simp only [everGoal, hwin w a ha hp, Bool.false_or]
    apply ih (w.step a) (hkeep w a ha hp)
    rw [List.all_eq_true] at hrest ⊢
    intro b hb
    rw [legal_step]
    exact hrest b hb

/-- 两句话不能同时成立（`Levels` 那一层据此说「有 `_winnable` 就不会有 `_unsolvable`」）。 -/
theorem not_both (w : World) (hw : Winnable w) (hu : Unsolvable w) : False := by
  obtain ⟨as, hl, h⟩ := hw
  rw [hu as hl] at h
  exact Bool.false_ne_true h

#print axioms legal_step
#print axioms unsolvable_of_invariant
#print axioms not_both
