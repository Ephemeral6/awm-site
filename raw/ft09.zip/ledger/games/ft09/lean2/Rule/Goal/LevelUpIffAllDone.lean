/-
# 规则 level_up_iff_all_done —— **定义**   （对应 `rule/goal/level_up_iff_all_done.py`）

点完那一刻，全部网格的外环都到齐 ⇔ 这一步换关。

在模型里这就是 `isGoal` 的**定义**：一个**状态**性质（不是转移事件）。
写成事件的话，没有任何一个状态是目标，「这个局面可不可做」就无从问起。

一个网格到齐：
    on  的位置   那块的底色 = 点亮色
    off 的位置   那几块都有瓦片、彼此同色、而且不是点亮色
    none 的位置  不管（解析的 G2 保证那里没有瓦片）
-/

import Obj.World

def World.gridDone (w : World) (g : Grid) : Bool :=
  let cols := g.ring.map (fun p => (p.1.bind w.colorAt, p.2))
  let onsOk := cols.all (fun p => p.2 != .on || p.1 == some g.lit)
  let offs := cols.filter (fun p => p.2 == .off)
  let offCols := offs.filterMap (fun p => p.1)
  onsOk && offCols.length == offs.length
    && offCols.all (fun c => c != g.lit)
    && offCols.all (fun c => c == offCols.headD 0)

/-- **赢**的定义：每一个网格都到齐。 -/
def World.isGoal (w : World) : Bool :=
  w.board.grids.all w.gridDone
