/-
# 规则 click_advances_tile —— **定义**   （对应 `rule/step/click_advances_tile.py`）

点中一块可涂瓦片，它的底色沿本关调色板前进一位（到头绕回第一个）。

这里是两样定义：「沿调色板前进一位」是什么，和「点一下，被点的是哪一块」。
它们不是待证的定理——`step` 就是照着它们写的，证它等于用它自己证它自己。
Python 那一份（`derive/advance.py` + 那条规则）是**独立写的另一份**，
两份的判决在 `Obs/Corpus.lean` 与 `verify.py` 里逐条对账。
-/

import Obj.World
import Obj.Act.Act

/-- 调色板上前进一位；到头绕回。颜色不在调色板里就原样（解析保证不会发生）。 -/
def advance (pal : List Nat) (c : Nat) : Nat :=
  match pal.idxOf? c with
  | some i => pal.getD ((i + 1) % pal.length) c
  | none   => c

/-- 这一下点中了哪一块瓦片（下标）；点空、点在中心上 → 空表。 -/
def Board.selfMoved (b : Board) : Act → List Nat
  | .click c => (b.indexOf c).toList
  | .void    => []
