/-
# 规则 marks_push_neighbours —— **定义**   （对应 `rule/step/marks_push_neighbours.py`）

点中一块带记号的瓦片时，它每个记号指向的那个槽位上若有一块可涂瓦片，那一块也前进一位；
指向中心、空槽、出界的方向什么也不牵动；被牵动的那几块不再往下传。

「指向空处」三种情形在这里是同一件事：`Cell.shift` 给 `none`，或者 `indexOf` 给 `none`。
「只走一步」也不用另写：这里只看被点那一块自己的记号。
-/

import Obj.World
import Obj.Act.Act

/-- 被点那一块的记号牵动的那几块（下标）。 -/
def Board.linked (b : Board) : Act → List Nat
  | .click c =>
      match b.indexOf c with
      | some i =>
          match b.tiles[i]? with
          | some t => t.marks.filterMap (fun d => (c.shift d).bind b.indexOf)
          | none   => []
      | none => []
  | .void => []
