/-
# Step —— 一步怎么走：**只做分发，0 条定理**

被点那一块（`selfMoved`，规则 click_advances_tile）和它记号牵动的那几块
（`linked`，规则 marks_push_neighbours）各自沿调色板前进一位，别的原样。

签名里没有新的 `Board`：一步之内版面、题面、调色板、底板**表示不出来**会变。

## 规则的身份表（`verify.py` 逐条机械核，和 `rule/` 目录对账）

    click_advances_tile        定义      Rule/Step/ClickAdvancesTile.lean
    marks_push_neighbours      定义      Rule/Step/MarksPushNeighbours.lean
    level_up_iff_all_done      定义      Rule/Goal/LevelUpIffAllDone.lean（`World.isGoal`）
    nothing_else_changes       推论      Derived/NothingElseChanges.lean
    bar_grows_slowly           不进模型  计数条下一步不是当前世界的函数（本关已走几步是历史）
    bar_refills_on_new_board   不进模型  说的是换关后那张新盘，新盘是历史
    reset_returns_to_opening   不进模型  「开局长什么样」是历史；在 Levels 那一层是明写的假设
-/

import Obj.World
import Obj.Act.Act
import Rule.Step.ClickAdvancesTile
import Rule.Step.MarksPushNeighbours
import Rule.Goal.LevelUpIffAllDone

def Board.moved (b : Board) (a : Act) : List Nat := b.selfMoved a ++ b.linked a

def step (b : Board) (s : List Nat) (a : Act) : List Nat :=
  s.mapIdx (fun i c => if (b.moved a).contains i then advance b.palette c else c)

def World.step (w : World) (a : Act) : World := ⟨w.board, _root_.step w.board w.colors a⟩
