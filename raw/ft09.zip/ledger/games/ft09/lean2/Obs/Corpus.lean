/-
# Corpus —— 逐条那一层（自动生成：`python lean2/export_corpus.py`，不要手改）

全部 168 步里，模型描述的 167 步（筛掉 RESET 1 步：模型不描述重开，见 `Obs/Check.lean`）。
每一步都从**观测到的那一帧**起算一步，和看到的下一帧比。三种：
同一张盘 155 / 通关 2 / 换关 10（换关只判「点完到齐了」那一半，新盘长什么样模型不说）。

`#eval` 那一行是读数（求值器），`corpus_agrees` 是结论（内核）。
-/

import Obs.Replay

def corpusCases : List Obs := steps.filter (fun o => o.kind != .reset)

def corpusVerdict (o : Obs) : Bool :=
  match o.act with
  | some a => agrees o.kind o.before a o.after
  | none   => false

/-- 筛完之后到底有几条。**切歪了会是空表，而空表让下面那条平凡为真。** -/
theorem corpus_len : (corpusCases.map Obs.before : List World).length = 167 := by decide +kernel

/-- **模型面对全部 167 条真实转移：一条都没被驳倒。** 走内核。 -/
theorem corpus_agrees :
    corpusCases.all (fun o => match o.act with
      | some a => agrees o.kind (o.before : World) a o.after
      | none   => false) = true := by decide +kernel

#print axioms corpus_len
#print axioms corpus_agrees

/- 读数：每一条的判决（`verify.py` 拿它和 Python 规则那一侧逐条对账）。
   第一次生成时 `corpus_len` 用的是普通 `decide`，爆了 maxRecDepth——Lean 报一行错照常往下编，
   公理表里当场多出 `sorryAx`，而同一份文件里这一行 `#eval` 照样打出满绿的读数。所以现在两条都走 `+kernel`。 -/
#eval "CORPUS " ++ toString (corpusCases.map (fun o => (o.seq, corpusVerdict o)))
