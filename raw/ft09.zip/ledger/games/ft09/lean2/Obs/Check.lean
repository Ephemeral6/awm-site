/-
# Check —— 判据层：两把尺子。**0 条定理**，尺子不自证。

    agrees    一条转移对不对：从**观测到的那一帧**算一步，和看到的下一帧比
    traceOk   一整条路对不对：只有开局是观测给的，**后面全是模型自己算的**

一个「每步单独看都对、走两步就和现实分家」的模型，在 `agrees` 那里满分，在 `traceOk` 这里过不了。

## 一条转移有三种（语料里的标记，上游给的事实）

    same      同一张盘上走一步：算出来的下一帧要**逐字段**等于看到的（含 Board），而且**没有**到齐
    win       通关那一步：下一帧仍是同一张盘，算出来的要等于看到的，而且**到齐了**
    newBoard  换关那一步：下一帧已经是下一关的盘，**只判「到齐了」这一半**——新盘长什么样模型不说

重开（RESET）不在这里：模型不描述它（见 `Obj/Act/Act.lean`）。
它**不是没人核**——Python 那一侧的规则 `reset_returns_to_opening` 对它开口，
这一侧 `Proof/Levels.lean` 里有一条 `restart_matches_opening` 把「重开 = 开局」对着观测核一次。
-/

import Obj.World
import Step

inductive Kind where
  | same | win | newBoard | reset
deriving DecidableEq, Repr

/-- 一条转移判不判得过。`reset` 那一支不是「反正算它对」：它根本不进这一层（`Obs/Corpus.lean` 先筛掉并报条数）。 -/
def agrees (k : Kind) (w : World) (a : Act) (o : World) : Bool :=
  match k with
  | .same     => w.step a == o && !(w.step a).isGoal
  | .win      => w.step a == o && (w.step a).isGoal
  | .newBoard => (w.step a).isGoal
  | .reset    => false

/-- 从 `w` 出发沿 `play` 走，每一步都和当时看到的那一帧比，而且**路上不许提前到齐**。
    **下一轮喂进去的是模型自己算出来的 `w'`**，不是观测——错一步，后面全错。 -/
def traceOk : World → List (Act × World) → Bool
  | _, []             => true
  | w, (a, o) :: rest =>
      let w' := w.step a
      w' == o && !w'.isGoal && traceOk w' rest

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit : World → List (Act × World) → Nat → Option Nat
  | _, [],             _ => none
  | w, (a, o) :: rest, i =>
      let w' := w.step a
      if w' == o && !w'.isGoal then firstSplit w' rest (i + 1) else some i
