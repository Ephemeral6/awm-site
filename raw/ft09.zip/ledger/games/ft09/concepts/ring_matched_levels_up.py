"""把这一步点中的外环瓦片换到下一个色之后，所有 3x3 网格的外环都到齐了目标色，这一步就换关（level +1）。"""
LEVEL = "L5"
SCOPE = ("只看带坐标的 ACTION6；没有 ctx 返回 NA；"
         "网格扫不出来 / 调色板读不出来 / 目标锁不死 / 中心图样含 PAT 之外的图样色 / "
         "被点瓦片颜色不在调色板里，返回 NA；"
         "换色之后还有网格没到齐时返回 NA —— 那一半交给 no_levelup_before_ring_matches")
NOTE = ("v5：跟 no_levelup 一起改成『沿调色板循环前进』+『目标由共用瓦片一致性锁死』。"
        "v4 熄灭色改成清点出来的另一色；v3 点亮色从画面上读；"
        "v2 只看 prev 加这一下点击的效果、不再读 nxt —— 换关那一步 nxt 已经是新一关的画面，"
        "v1 是靠『nxt 里网格读不出来就当换关了』兜底才判 TRUE 的。")
EVIDENCE = ["6ad68317227cf68f", "c2484e5c3063e99d"]

from _lib import all_matched_after_click, click_xy

PAT_ON = 0
PAT_OFF = 2


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or click_xy(action) is None:
        return "NA"
    ok = all_matched_after_click(prev, action, PAT_ON, PAT_OFF)
    if ok is None or not ok:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
