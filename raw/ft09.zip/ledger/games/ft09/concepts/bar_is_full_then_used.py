"""最后一行任何时刻都是「左边一段色12、右边一段色11」两段（任一段可以为空），已用段永远贴着最右端连续。"""
LEVEL = "L4"
SCOPE = "看所有动作；prev 与 nxt 都要满足；最后一行出现色12/色11 之外的颜色时判 FALSE（那说明这个形状描述本身错了）"
NOTE = ("从 bar_eats_two v1 拆出来的那一半。v1 把『形状』和『每步吃 2 格』捆在一句话里，"
        "第 2 关每步吃 2/3 格把整条打倒，连带这一半也一起死了——其实它没错。一条概念只断言一件事。")
EVIDENCE = ["d89ef1db9b3187a9"]

from _lib import BAR_FULL, BAR_USED, bar_runs


def _ok(g):
    rs = bar_runs(g)
    if any(c not in (BAR_FULL, BAR_USED) for c, _ in rs):
        return False
    return [c for c, _ in rs] in ([BAR_FULL], [BAR_USED], [BAR_FULL, BAR_USED])


def assert_(prev, action, nxt, ctx=None):
    return "TRUE" if _ok(prev) and _ok(nxt) else "FALSE"
