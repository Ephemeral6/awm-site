"""不换关的一步，计数条已用格数只会增加 0 到 2 格，从不减少。"""
LEVEL = "L4"
SCOPE = "看所有动作；换关（level_prev != level_next）返回 NA；prev 或 nxt 的最后一行读不出已用格数时返回 NA"
NOTE = ("从 bar_eats_two v1 退下来的那一半。v1 说『正好加 2』，那只是第 0、1 关的样子；"
        "第 2 关六步只吃掉 4 格（增量 1,0,1,1,0,1，看着像 round(本关步数×2/3)），"
        "所以『每步吃几格』是随关变的速率，不是常数 2。速率写不成单步断言（ctx 只给全局步数，"
        "给不了本关第几步），所以这里只保下能单步判的那一句：单调、且一步不超过 2 格。"
        "这条弱，但它是真的，而且哪天出现『点了一下条反而变长』或者『一步吃 3 格』就当场倒。")
EVIDENCE = ["d89ef1db9b3187a9", "86b247993dc04d91", "97e6fe26db533cf4"]

from _lib import bar_used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = bar_used(prev), bar_used(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if 0 <= b - a <= 2 else "FALSE"
