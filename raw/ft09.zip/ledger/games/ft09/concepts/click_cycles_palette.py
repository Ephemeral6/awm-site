"""ACTION6 点在任何一块外环瓦片上时，这块瓦片的**底色**前进到本关调色板里的下一个色（到头绕回第一个）。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关那一步返回 NA —— 换关后整屏重画；"
         "换关有两种认法，**两种都用**：ctx 里 level_prev != level_next（结算时），"
         "以及 levelup_imminent(prev, action) 为真（押注时 ctx 给不出关卡变化，只能从帧上看出来）；"
         "点击坐标不落在任何被扫出来的网格的外环位置上返回 NA（含落在中心瓦片、落在瓦片之间的缝里、落在网格之外）；"
         "本关调色板读不出来（少于两色）返回 NA；"
         "被点位置上的底色读不出来（那里是空槽、是中心瓦片、或是没见过的花纹）、"
         "或它的颜色不在调色板里，返回 NA")
NOTE = ("v3：换关免责从「只认 ctx」改成「ctx 或帧，两种都算」。原来那句在结算时够用，"
        "在**押注**时是个空条款——押注时这一步还没走，ctx 里的关卡号必然相等，"
        "于是这条概念会对换关那一下照常出预测，而换关后整屏重画，预测必错。"
        "换关册子本来看得出（levelup_imminent），所以补上帧上的那一半。"
        "旧语料上这是空改动：ctx 那一半已经把同一批步盖住了，C/N 应当一格不变。"
        "v2：把「瓦片的颜色」换成「瓦片的**底色**」。第 4 关出现带 MARK 花纹的瓦片——底色之上盖着一层花纹，"
        "整块不是单色，v1 因此对它一句话都说不出（tid 690d3d0a7349b356 判 NA）。实测那一下点击"
        "把它花纹底下那个色 14 推成了 15，花纹原样保留：所以变的是底色，不是整块像素。"
        "它同时牵动四个邻居，那半条主张归 plus_tile_cycles_neighbours 管，这里只说被点的那一块。"
        "v1 接替 click_toggles_tile（v4 撤册）：那一条说『在两个色之间来回翻转』，"
        "第 3 关一次点击 9→8 就把它打倒了——三色关里点击是循环前进不是二元互换。"
        "顺序取自图例从上到下；没有图例的关退回从瓦片上清点后排序（那些关只有两色，顺序无所谓）。")
EVIDENCE = ["d89ef1db9b3187a9", "6f06e09e88984ff9", "6db074a25f82b9f4", "75f5ee75281d2552",
            "690d3d0a7349b356", "8d9c57c6425e0300"]

from _lib import (base_at, base_cells, click_xy, grid_ring_tile, levelup_imminent,
                  next_color, palette_seq, tile_box)


def _target(prev, action, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    xy = click_xy(action)
    if xy is None:
        return None
    if levelup_imminent(prev, action) is True:
        return None
    hit = grid_ring_tile(prev, xy[0], xy[1])
    if hit is None:
        return None
    box = tile_box(hit[0], hit[1], hit[2])
    want = next_color(palette_seq(prev), base_at(prev, *box))
    if want is None:
        return None
    return box, want


def assert_(prev, action, nxt, ctx=None):
    t = _target(prev, action, ctx)
    if t is None:
        return "NA"
    box, want = t
    return "TRUE" if base_at(nxt, *box) == want else "FALSE"


def apply(prev, action, ctx=None):
    t = _target(prev, action, ctx)
    if t is None:
        return None
    box, want = t
    cells = base_cells(prev, *box)
    return None if cells is None else {c: want for c in cells}
