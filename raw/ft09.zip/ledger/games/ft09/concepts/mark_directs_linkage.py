"""点在一块带记号的瓦片上时，它每个记号位指向的那块邻居瓦片的底色也前进一位（上边中点的记号指上邻居，依此类推）；记号指向出界、指向空槽、指向另一个网格的中心瓦片时，那个方向无效，那一块一格不动。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关那一步返回 NA，两种认法都用："
         "ctx 里 level_prev != level_next（结算时）、levelup_imminent(prev, action) 为真（押注时）；"
         "点击没落在任何网格的外环位置上、被点那块的底色与记号读不出来、一个记号都没有、"
         "调色板读不出来，返回 NA；"
         "记号指到的邻居里只要有一块**底色读不出来、或读得出却不在调色板里**（压在图例上、"
         "压在方框线上、没见过的花纹）就返回 NA —— 那种局面这条概念没被检验过。"
         "**不管**没被记号指到的邻居会怎样（那归 nothing_else_changes），也不管被点那一块自己"
         "（那归 click_cycles_palette）。")
NOTE = ("v3：换关免责补上帧上的那一半（levelup_imminent）。原来只认 ctx，那在押注时是空条款——"
        "押注时这一步还没走，ctx 里关卡号必然相等，概念会对换关那一下照常出预测，而换关整屏重画。"
        "旧语料上应是空改动（ctx 那一半已盖住同一批步），验收判据就是 C/N 与 E 一格不变。"
        "v2 接替 plus_tile_cycles_neighbours（撤册）：那一条说的是「加号瓦片牵动四个正交邻居」。"
        "『加号瓦片』这个名字本身就是错的抽象。全五关机械核对（runs/.../marks.py）后的形态是："
        "每块瓦片读成 3x3 小格，四角与正中承载底色，四条边的中点是记号位，取值只能是底色或 MARK；"
        "带 MARK 的边有几条就联动几个方向。第 0~3 关一条记号都没有（所以点击只改自己）；"
        "第 4 关只有 3 块瓦片四条边全带（当时管它们叫「加号」）；第 5 关全部可涂瓦片只带上边一条。"
        "所以旧那条是「四条边都带」的特例，不是规律本身。"
        "v1 写下时方向语义还没被检验过（第 4 关三块都是四条边全带，分不出记号指哪边），"
        "v1 就把『上边的记号指上邻居』写成了会判错的话；6e1d... 之前的 f3cafc0883ae34a4 兑现了它："
        "点 top30 left28，帧差 64 = 自己 32 + **上**邻居 32，下邻居一格不动，也没有链式传递。"
        "v2 补上「记号指向虚空」那一类，也是实测来的，不是推的："
        "6e1d2bfeccd3d6a0 的记号指向空槽（整块背景色）、600415924f90231d 的记号指向画面外，"
        "两步帧差都是 33 = 自己 32 + 计数条 1，那个方向什么都没发生，背景也没长出瓦片。"
        "加上早先 4f9ef6ccd97f6f5f 测到的『指向中心瓦片时那一块一格不动』，"
        "「指不到可涂瓦片就无效」这三种情形现在都有 tid。"
        "同一 tid 还测到：联动按**物理相邻**算，不管邻居属不属于任何网格（那一步有一块"
        "不属于任何网格外环的瓦片照样被牵动 36 格）。"
        "还没检验过的：记号指向一块底色读得出、却不在调色板里的瓦片 —— 走 NA。")
EVIDENCE = ["690d3d0a7349b356", "4f9ef6ccd97f6f5f", "f3cafc0883ae34a4",
            "6e1d2bfeccd3d6a0", "600415924f90231d"]

from _lib import (TILE, base_at, base_cells, centers, click_xy, grid_ring_tile, levelup_imminent,
                  link_boxes, next_color, palette_seq, tile_read, tile_box)


def _split(prev, action, ctx=None):
    """({(top,left): 新底色}, [该一格不动的框])；说不出话返回 None。"""
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    xy = click_xy(action)
    if xy is None:
        return None
    if levelup_imminent(prev, action) is True:
        return None
    hit = grid_ring_tile(prev, xy[0], xy[1])
    if hit is None:
        return None
    t, l = tile_box(hit[0], hit[1], hit[2])
    base, marks = tile_read(prev, t, l)
    if base is None or not marks:
        return None
    pal = palette_seq(prev)
    if pal is None:
        return None
    lb = link_boxes(prev, t, l, marks, set(centers(prev)))
    if lb is None:
        return None
    boxes, frozen = lb
    move = {}
    for box in boxes:
        want = next_color(pal, base_at(prev, *box))
        if want is None:
            return None
        move[box] = want
    return move, frozen


def assert_(prev, action, nxt, ctx=None):
    sp = _split(prev, action, ctx)
    if sp is None:
        return "NA"
    move, frozen = sp
    for box, w in move.items():
        if base_at(nxt, *box) != w:
            return "FALSE"
    for t, l in frozen:
        for dr in range(TILE):
            for dc in range(TILE):
                if prev[t + dr][l + dc] != nxt[t + dr][l + dc]:
                    return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    sp = _split(prev, action, ctx)
    if sp is None:
        return None
    move, frozen = sp
    out = {}
    for box, w in move.items():
        cells = base_cells(prev, *box)
        if cells is None:
            return None
        for c in cells:
            out[c] = w
    for t, l in frozen:
        for dr in range(TILE):
            for dc in range(TILE):
                out[(t + dr, l + dc)] = prev[t + dr][l + dc]
    return out
