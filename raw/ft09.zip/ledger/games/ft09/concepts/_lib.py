"""ft09 的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测出来的形态（第 0~4 关）：
  屏幕上有若干「3x3 瓦片网格」：瓦片边长 6 像素、相邻瓦片左上角相差 8（中间 2 像素背景）。
  8 个外环瓦片一般是单色；正中间那个瓦片是 3x3 个 2x2 小格的**图样**，图样格取值只见过 {0, 2, 3}，
  正中那一格是这个网格的「点亮色」。
  **网格没有全局格点**：第 0 关左右两组网格的相位就不一样，所以一切都从中心瓦片往外定位。
  最后一行是一条计数条，换关时重新填满。
  右上角可能有一列 4x4 的色块图例（第 0 关没有）。

留 None / 返回 None 的都是没量出来的，别猜着填。
"""
from __future__ import annotations

from geo import bbox, cells_of, components

TILE = 6           # 瓦片边长（像素）
PITCH = 8          # 相邻瓦片左上角的距离
SUB = 2            # 中心瓦片里小格的边长：6 = 3x2
FRAME = 4          # 第 0 关圈住待凑网格的方框颜色
FRAME_PAD = 4      # 方框外接框往内缩多少像素才是首个瓦片的左上角

CELL = TILE        # 兼容模板里的名字
PHASE = None       # 这一局没有全图格点，不用相位
DELTA = {}         # 这一局只有 ACTION6（带坐标），没有方向性位移

PAT_CODES = (0, 2, 3)   # 中心图样格只见过这三个值
PAT_NONE = 3            # 主张：3 的位置根本不是可涂的外环瓦片（出界 / 空槽 / 另一个网格的中心）
LEGEND_W = 4            # 图例色块边长
MARK = 6                # 加号瓦片上那层交错花纹的颜色（第 4 关第一次出现）
NEIGH = ((-1, 0), (1, 0), (0, -1), (0, 1))   # 加号瓦片牵动的四个正交邻居


def me(g):
    """这一局没有「玩家块」；保持 None，任何引用它的概念都该返回 NA。"""
    return None


def walls(g):
    """这一局没有量出「阻挡」这回事。"""
    return None


def bg(g):
    """背景色：左上角那一格。第 0 关是 5，之后几关是 4。"""
    return g[0][0]


def click_xy(action):
    """'ACTION6:38,46' -> (38, 46)（x=列, y=行）。不是带坐标的点击返回 None。

    实测（第 3 步 ACTION6:38,46 改的是 rows44-49 x cols36-41）：x 是列、y 是行。
    注意装置打帧差时每格印成 (x, y)，而概念的 apply 用 (row, col) —— 两种序并存。
    """
    if not isinstance(action, str) or ":" not in action:
        return None
    name, _, coords = action.partition(":")
    if name.strip().upper() != "ACTION6":
        return None
    try:
        x, y = (int(v) for v in coords.split(","))
    except ValueError:
        return None
    return (x, y)


# ---------- 瓦片 ----------

def _uniform(g, r, c, n):
    """(r,c) 起 n x n 是不是单色；越界或不单色返回 None。"""
    if r < 0 or c < 0 or r + n > len(g) or c + n > len(g[0]):
        return None
    v = g[r][c]
    for dr in range(n):
        row = g[r + dr]
        for dc in range(n):
            if row[c + dc] != v:
                return None
    return v


def tile_box(origin, i, j):
    """网格里第 (i, j) 个瓦片的 (top, left)。i/j 都在 0..2。"""
    return (origin[0] + i * PITCH, origin[1] + j * PITCH)


def tile_cells(origin, i, j):
    """第 (i, j) 个瓦片覆盖的全部像素 (row, col)。"""
    t, l = tile_box(origin, i, j)
    return [(t + dr, l + dc) for dr in range(TILE) for dc in range(TILE)]


def tile_solid(g, origin, i, j):
    """第 (i, j) 个瓦片是单色时返回色号，不是单色（或越界）返回 None。"""
    t, l = tile_box(origin, i, j)
    return _uniform(g, t, l, TILE)


def tile_of_click(origin, x, y):
    """点击坐标（x=列, y=行）落在这个网格的哪个瓦片：返回 (i, j)，落在瓦片之外返回 None。"""
    if origin is None:
        return None
    di, dj = y - origin[0], x - origin[1]
    if di < 0 or dj < 0:
        return None
    i, j = di // PITCH, dj // PITCH
    if not (i <= 2 and j <= 2):
        return None
    if di - i * PITCH >= TILE or dj - j * PITCH >= TILE:
        return None          # 落在瓦片之间的缝里
    return (i, j)


def pattern_at(g, t, l):
    """(t,l) 起的 6x6 读成 3x3 的 SUB x SUB 图样；任一小格不单色、或整块单色，返回 None。"""
    if t < 0 or l < 0 or t + TILE > len(g) or l + TILE > len(g[0]):
        return None
    out = []
    for a in range(3):
        row = []
        for b in range(3):
            v = _uniform(g, t + a * SUB, l + b * SUB, SUB)
            if v is None:
                return None
            row.append(v)
        out.append(row)
    return out if len({v for r_ in out for v in r_}) > 1 else None


def is_center(g, t, l):
    """(t,l) 起的 6x6 是不是一个网格的中心瓦片。

    判据（位置无关，不依赖任何全局格点）：能读成 3x3 图样、**周围八格取值都在 PAT_CODES 里**、
    **正中那格不在 PAT_CODES 里**（它是这个网格的点亮色）。
    图例的 4x4 色块、外环的棋盘格瓦片、以及从真中心平移 2 像素的假窗口，都被这两条挡掉。
    """
    pat = pattern_at(g, t, l)
    if pat is None:
        return False
    if pat[1][1] in PAT_CODES:
        return False
    return all(pat[i][j] in PAT_CODES for i in range(3) for j in range(3) if (i, j) != (1, 1))


def centers(g):
    """全图所有中心瓦片的 (top, left)，按行列序。"""
    return [(t, l)
            for t in range(len(g) - TILE + 1)
            for l in range(len(g[0]) - TILE + 1)
            if is_center(g, t, l)]


# ---------- 底色与边上的记号 ----------

# 瓦片读成 3x3 小格后：四角与正中承载底色，四条边的中点是「记号位」。
# 记号位 -> 它指向的邻居（以瓦片为单位的偏移）。
EDGE_DIR = {(0, 1): (-1, 0), (2, 1): (1, 0), (1, 0): (0, -1), (1, 2): (0, 1)}
BASE_SUB = ((0, 0), (0, 2), (1, 1), (2, 0), (2, 2))   # 承载底色的五个小格


def tile_read(g, t, l):
    """把一块物理瓦片读成 (底色, 记号方向集合)；读不出来返回 (None, None)。

    判据：3x3 小格里四角与正中同色（=底色），四条边的中点要么也是底色、要么是 MARK 色。
    出现第三种颜色就是读不出——那不是一块瓦片（压在方框线上、压在图例上、是中心图样）。
    这一条把「整块单色的普通瓦片」「四条边全带记号的『加号』」「只带一条边的」统一成同一种形态。
    """
    pat = pattern_at(g, t, l)
    if pat is None:
        v = _uniform(g, t, l, TILE)
        return (v, frozenset()) if v is not None else (None, None)
    base = pat[0][0]
    if any(pat[a][b] != base for a, b in BASE_SUB):
        return (None, None)
    marks = set()
    for (a, b), d in EDGE_DIR.items():
        if pat[a][b] == base:
            continue
        if pat[a][b] != MARK:
            return (None, None)
        marks.add(d)
    return (base, frozenset(marks))


def base_at(g, t, l):
    """一块物理瓦片的**底色**（四角与正中那五个小格的共同色）；读不出来（含越界）返回 None。"""
    return tile_read(g, t, l)[0]


def marks_at(g, t, l):
    """这块瓦片带记号的方向集合（(dr,dc) 以瓦片为单位）；读不出来返回 None。"""
    return tile_read(g, t, l)[1]


def marked_at(g, t, l):
    """这块瓦片带不带记号。"""
    m = marks_at(g, t, l)
    return bool(m)


plus_at = marked_at   # 旧名：第 4 关只见过四条边全带记号的，当时管它叫「加号瓦片」


def base_cells(g, t, l):
    """这块瓦片里**承载底色**的像素 (row, col)：整块 36 格，减去每个记号位占的 4 格。"""
    base, marks = tile_read(g, t, l)
    if base is None:
        return None
    skip = {sub for sub, d in EDGE_DIR.items() if d in marks}
    return [(t + a * SUB + dr, l + b * SUB + dc)
            for a in range(3) for b in range(3) if (a, b) not in skip
            for dr in range(SUB) for dc in range(SUB)]


def link_boxes(g, t, l, marks, cset=None):
    """(t,l) 的记号指向的邻居里，**真正会被推色**的那些框；说不出话返回 None。

    实测：记号指向出界、指向空槽（底色=背景色）、指向另一个网格的中心瓦片时，
    那个方向就是无效的 —— 那一块一格不动，也不算说不出话。
    指向一块底色读不出来的东西才是没量过，返回 None。
    第二个返回值是「在画面内、被跳过、因此应当一格不动」的那些框。
    """
    if cset is None:
        cset = set(centers(g))
    move, frozen = [], []
    for dr, dc in sorted(marks):
        box = (t + dr * PITCH, l + dc * PITCH)
        if box[0] < 0 or box[1] < 0 or box[0] + TILE > len(g) or box[1] + TILE > len(g[0]):
            continue
        if box in cset:
            frozen.append(box)
            continue
        b = base_at(g, *box)
        if b is None:
            return None
        if b == bg(g):
            frozen.append(box)
            continue
        move.append(box)
    return move, frozen


def click_effect(g, action):
    """这一下点击把哪些物理瓦片的底色推到什么色：{(top,left): 新底色}；说不出话返回 None。

    压着这几条主张（随引用它的概念一起被推翻）：
      1. 点中的那块瓦片，底色沿调色板前进一位；
      2. 它每一个**记号位**指向的那块邻居瓦片，底色也各自前进一位 —— 按**物理相邻**算，
         不管那块瓦片属不属于任何网格（实测有一块不属于任何网格的瓦片照样被牵动）；
         联动只走一步，不沿着记号继续传下去；
      3. 记号指向出界、指向空槽、指向另一个网格的中心瓦片时，那个方向无效，那一块一格不动。
    点在瓦片之外、调色板读不出来、被点那块或某个该受影响的邻居底色读不出来 / 不在调色板里，
    一律返回 None ——**不是「没有影响」，是册子说不出话**。
    """
    xy = click_xy(action)
    if xy is None:
        return None
    hit = grid_ring_tile(g, xy[0], xy[1])
    if hit is None:
        return None
    pal = palette_seq(g)
    t, l = tile_box(hit[0], hit[1], hit[2])
    base, marks = tile_read(g, t, l)
    if base is None:
        return None
    lb = link_boxes(g, t, l, marks)
    if lb is None:
        return None
    out = {}
    for box in [(t, l)] + lb[0]:
        nxt = next_color(pal, base_at(g, *box))
        if nxt is None:
            return None
        out[box] = nxt
    return out


def tile_grids(g):
    """全图所有「3x3 瓦片网格」的左上角 (top, left) —— 即每个中心瓦片往左上退一个 PITCH。

    网格允许伸到画面外、允许某些外环位置是空的，这两种位置在图样里记作 PAT_NONE。
    """
    return [(t - PITCH, l - PITCH) for t, l in centers(g)]


def center_pattern(g, origin):
    """中心瓦片 (1,1) 里的 3x3 图样：返回 3x3 的色号表；读不出来则 None。"""
    if origin is None:
        return None
    t, l = tile_box(origin, 1, 1)
    return pattern_at(g, t, l)


def center_mid_color(g, origin):
    """中心瓦片正中那格（3x3 图样的 (1,1)）的颜色 —— 这个网格的「点亮色」。"""
    pat = center_pattern(g, origin)
    return None if pat is None else pat[1][1]


def slot_kind(g, origin, i, j, cset=None):
    """外环某个位置是什么：

      'off'    出界（哪怕只出一点）
      'empty'  底色就是背景色 —— 那里根本没有瓦片
      'center' 那里是另一个网格的中心瓦片
      'solid'  底色读得出来且不是背景色 —— 可涂（带不带记号都算）
      'other'  底色读不出来（压在方框线上、压在图例上、没见过的花纹）
    """
    t, l = tile_box(origin, i, j)
    if t < 0 or l < 0 or t + TILE > len(g) or l + TILE > len(g[0]):
        return "off"
    if cset is None:
        cset = set(centers(g))
    if (t, l) in cset:
        return "center"
    v = base_at(g, t, l)
    if v is None:
        return "other"
    return "empty" if v == bg(g) else "solid"


def unpaintable(g, origin, i, j, cset=None):
    """主张 PAT_NONE 对应的就是这三种位置。"""
    return slot_kind(g, origin, i, j, cset) in ("off", "empty", "center")


def ring_colors(g, origin):
    """外环 8 个瓦片：{(i, j): 色}，不是单色的位置给 None。origin 为 None 时返回 None。"""
    if origin is None:
        return None
    return {(i, j): tile_solid(g, origin, i, j)
            for i in range(3) for j in range(3) if (i, j) != (1, 1)}


def grid_ring_tile(g, x, y):
    """点击坐标（x=列, y=行）落在哪个网格的哪个外环位置：返回 (origin, i, j)。

    纯几何，不管那个位置上有没有瓦片。落在中心瓦片、瓦片之间的缝里、所有网格之外，返回 None。
    共用瓦片取扫到的第一个网格 —— 同一块物理瓦片，取哪个网格算出来的色号都一样。
    """
    for o in tile_grids(g):
        ij = tile_of_click(o, x, y)
        if ij is not None and ij != (1, 1):
            return (o, ij[0], ij[1])
    return None


# ---------- 调色板 ----------

def _runs(line, skip):
    out = []
    i, n = 0, len(line)
    while i < n:
        if line[i] == skip:
            i += 1
            continue
        j = i
        while j < n and line[j] == line[i]:
            j += 1
        out.append((i, j - i, line[i]))
        i = j
    return out


def legend_col(g):
    """图例所在的列：第 0 行里非背景色的极大游程恰好一条、且长 LEGEND_W 时，返回它的起点列。

    第 0 关第 0 行整行背景 → None；第 1~3 关是 60；第 4 关挪到了 54 —— 所以不能写死列号。
    """
    rs = _runs(g[0], bg(g))
    if len(rs) != 1 or rs[0][1] != LEGEND_W:
        return None
    return rs[0][0]


def legend_colors(g):
    """图例列从 row0 往下，每 LEGEND_W 行一个色块，读到不单色或撞背景色为止。

    实测：第 0 关 []、第 1 关 [9,12]、第 2 关 [8,12]、第 3 关 [9,8,12]、第 4 关 [14,15]。
    """
    c0 = legend_col(g)
    if c0 is None:
        return []
    out, r = [], 0
    while r + LEGEND_W <= len(g):
        v = _uniform(g, r, c0, LEGEND_W)
        if v is None or v == bg(g):
            break
        out.append(v)
        r += LEGEND_W
    return out


def grid_palette_colors(g):
    """清点：所有网格的**外环瓦片底色**（读得出且非背景的）与**正中格**颜色，去重后排序。

    纯清点，不含「这些色就是本关的调色板」这类断言 —— 那是概念的主张。
    没有网格、或某个网格读不出正中色时返回 None。
    """
    grids = tile_grids(g)
    if not grids:
        return None
    b = bg(g)
    out = set()
    for o in grids:
        mid = center_mid_color(g, o)
        if mid is None:
            return None
        out.add(mid)
        for i in range(3):
            for j in range(3):
                if (i, j) == (1, 1):
                    continue
                v = base_at(g, *tile_box(o, i, j))
                if v is not None and v != b:
                    out.add(v)
    return sorted(out)


def palette_seq(g):
    """本关外环可用色的**有序**表：有图例就用图例的从上到下，没图例就退回从瓦片上清点后排序。

    第 0 关没有图例，只能清点（那一关只有两色，顺序无所谓）。少于两色返回 None。
    """
    seq = legend_colors(g)
    if not seq:
        cs = grid_palette_colors(g)
        seq = list(cs) if cs else []
    return seq if len(seq) >= 2 else None


def next_color(seq, c):
    """在有序调色板里前进一位（循环）。c 不在表里返回 None。"""
    if seq is None or c not in seq:
        return None
    return seq[(seq.index(c) + 1) % len(seq)]


# ---------- 目标 ----------

def _product(lists):
    out = [()]
    for xs in lists:
        out = [t + (v,) for t in out for v in xs]
    return out


def ring_targets(g, pat_on, pat_off):
    """每个网格的外环目标色表 {origin: {(i,j): 色}}；定不死就返回 None。

    这里面压着四条主张，它们随引用本函数的概念一起被推翻：
      1. 中心图样里 pat_on 的位置，外环应为该网格正中那格的颜色；
      2. pat_off 的位置，外环应为调色板里**别的**某一个色（同一个网格里统一一个）；
      3. PAT_NONE 的位置不是可涂瓦片，没有目标 —— 不进色表；
      4. 同一块物理瓦片被两个网格共用时，两边要求的颜色必须相同。
    调色板多于两色时第 2 条本身不唯一，靠第 4 条锁死；锁不死（解不唯一）就返回 None。
    """
    grids = tile_grids(g)
    pal = palette_seq(g)
    if not grids or pal is None:
        return None
    mids, pats = {}, {}
    for o in grids:
        m, p = center_mid_color(g, o), center_pattern(g, o)
        if m is None or p is None or m not in pal:
            return None
        for i in range(3):
            for j in range(3):
                if (i, j) != (1, 1) and p[i][j] not in (pat_on, pat_off, PAT_NONE):
                    return None
        mids[o], pats[o] = m, p
    box = {}
    for o in grids:
        for i in range(3):
            for j in range(3):
                if (i, j) != (1, 1) and pats[o][i][j] != PAT_NONE:
                    box.setdefault(tile_box(o, i, j), []).append((o, i, j))
    cands = [[c for c in pal if c != mids[o]] for o in grids]
    if not box:
        return None
    sols = []
    for combo in _product(cands):
        x = dict(zip(grids, combo))
        want, ok = {}, True
        for k, vs in box.items():
            cols = {mids[o] if pats[o][i][j] == pat_on else x[o] for o, i, j in vs}
            if len(cols) != 1:
                ok = False
                break
            want[k] = cols.pop()
        if ok:
            sols.append(want)
    if len(sols) != 1:
        return None
    want = sols[0]
    return {o: {(i, j): want[tile_box(o, i, j)]
                for i in range(3) for j in range(3)
                if (i, j) != (1, 1) and pats[o][i][j] != PAT_NONE}
            for o in grids}


def all_matched_after_click(g, action, pat_on, pat_off):
    """把这一下点击的换色算进去之后，是否**每一个**网格的外环都等于目标色表。

    返回 True / False；网格扫不出来、目标定不死、目标位置上底色读不出来、
    点击的影响面算不出来，一律返回 None（说不出话，不是说没到齐）。
    比的是**底色**：加号瓦片带着 MARK 花纹也算数，只看它花纹底下那个色。
    共用瓦片存在，所以「凑齐」必须对所有网格同时成立。
    """
    targets = ring_targets(g, pat_on, pat_off)
    if targets is None:
        return None
    eff = click_effect(g, action)
    if eff is None and click_xy(action) is not None:
        return None
    eff = eff or {}
    for o, want in targets.items():
        for (i, j), w in want.items():
            box = tile_box(o, i, j)
            cur = eff.get(box, base_at(g, *box))
            if cur is None:
                return None
            if cur != w:
                return False
    return True


PAT_MID = 0        # 中心图样里代表「该位置外环应为中心正中那格的颜色」的图样色
PAT_OTHER = 2      # 中心图样里代表「该位置外环应为调色板里别的某一个色」的图样色


def levelup_imminent(g, action):
    """这一下点击会不会当场换关——只从**帧**算，不看 ctx。说不出话返回 None。

    为什么要有它：概念一直靠 ctx 的 level_prev != level_next 给换关那一步免责，
    那在结算时管用，在**押注**时失效——押注时这一步还没走，ctx 里两个关卡号必然相等，
    于是概念会照常预测，而换关后整屏重画，预测必错。
    换关这件事册子本来就看得出（ring_matched_levels_up 判的就是它），所以写成帧上的判据，
    结算和押注两头都成立。
    """
    return all_matched_after_click(g, action, PAT_MID, PAT_OTHER)


# ---------- 第 0 关的方框 ----------

def frame_bbox(g):
    """FRAME 色最大连通块的外接框；没有就 None。"""
    cs = components(cells_of(g, FRAME))
    if not cs:
        return None
    return bbox(cs[0])


def active_origin(g):
    """第 0 关那种「被 FRAME 方框圈住的网格」的左上瓦片 (top, left)；不是那种画面返回 None。"""
    bb = frame_bbox(g)
    if bb is None:
        return None
    t, b, l, r = bb
    side = 3 * PITCH + TILE - 1
    if (b - t, r - l) != (side, side):
        return None
    return (t + FRAME_PAD, l + FRAME_PAD)


# ---------- 计数条 ----------

BAR_ROW = -1       # 计数条在最后一行
BAR_FULL = 12      # 还没用掉的那一段的颜色
BAR_USED = 11      # 已经用掉的那一段的颜色


def bar_used(g):
    """计数条上「已用」格数：最后一行里 BAR_USED 色的格数。行里出现别的颜色时返回 None。"""
    row = g[BAR_ROW]
    if any(v not in (BAR_FULL, BAR_USED) for v in row):
        return None
    return sum(1 for v in row if v == BAR_USED)


def bar_runs(g):
    """清点：最后一行的游程 [(色, 长度), …]。不含任何「它是计数条」的断言。"""
    out = []
    for v in g[BAR_ROW]:
        if out and out[-1][0] == v:
            out[-1][1] += 1
        else:
            out.append([v, 1])
    return [(a, b) for a, b in out]
