"""一步之内，画面上变的只有这几处：点中的那块瓦片、它记号指向的那些**可涂**邻居瓦片、和最后一行。别处一格不动。"""
LEVEL = "L6"
SCOPE = ("只看带坐标的 ACTION6；换关（level_prev != level_next）返回 NA —— 换关后整屏重画；"
         "点击没落在任何网格的外环位置上、或被点那块的记号读不出来时，"
         "断言收紧为『只有最后一行会变』，照常判；"
         "记号指到一块底色读不出来的东西时（没量过），放宽到允许全部被指邻居都变")
NOTE = ("v4：影响面再收一次 —— 从「记号指向的邻居」收到「记号指向的**可涂**邻居」。"
        "实测记号指向出界（600415924f90231d）、指向空槽（6e1d2bfeccd3d6a0）、指向中心瓦片"
        "（4f9ef6ccd97f6f5f）时那个方向什么都不发生，帧差里只有被点那一块加计数条；"
        "v3 把那些方向的 36 格一律放行，放得越宽越判不错，所以收紧。"
        "v3 把影响面从「加号瓦片的四个正交邻居」改成「记号位指向的邻居」——第 5 关全部可涂瓦片"
        "只带上边一条记号，v2 那句『加号牵动四邻』在这一关会把三个多余的邻居一起放行。"
        "方向与可涂性的语义由 mark_directs_linkage 承担；这里只管**影响面**，不管变成什么色，"
        "所以邻居按整块 36 格放行，不校验记号保留。"
        "v2 死于 690d3d0a7349b356（点一块四条边全带记号的瓦片，帧差 164 格，它自己加四邻一起换色），"
        "那一步把 v1 的『变的只有被点那一块』当场作废。"
        "v1 接替 matched_grid_is_locked（v3 撤册）：那一条说『凑齐的网格外环一格不变』，"
        "被 b7a2cae509e5177f 打倒——把刚凑齐的网格的左上瓦片再点一次，它照样翻回去了，凑齐不锁定。")
EVIDENCE = ["d89ef1db9b3187a9", "b7a2cae509e5177f", "690d3d0a7349b356", "4f9ef6ccd97f6f5f",
            "6e1d2bfeccd3d6a0", "600415924f90231d"]

from _lib import PITCH, TILE, click_xy, grid_ring_tile, link_boxes, tile_read, tile_box


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    xy = click_xy(action)
    if xy is None:
        return "NA"
    boxes = []
    hit = grid_ring_tile(prev, xy[0], xy[1])
    if hit is not None:
        t, l = tile_box(hit[0], hit[1], hit[2])
        boxes.append((t, l))
        marks = tile_read(prev, t, l)[1] or ()
        lb = link_boxes(prev, t, l, marks)
        if lb is None:
            boxes += [(t + dr * PITCH, l + dc * PITCH) for dr, dc in marks]
        else:
            boxes += lb[0]
    allowed = {(t + dr, l + dc) for t, l in boxes for dr in range(TILE) for dc in range(TILE)}
    last = len(prev) - 1
    for r in range(len(prev)):
        if r == last:
            continue
        pr, nr = prev[r], nxt[r]
        for c in range(len(pr)):
            if pr[c] != nr[c] and (r, c) not in allowed:
                return "FALSE"
    return "TRUE"
