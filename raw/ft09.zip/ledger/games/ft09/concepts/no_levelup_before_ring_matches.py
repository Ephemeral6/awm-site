"""把这一步点中的外环瓦片换到下一个色之后，只要还有任何一个 3x3 网格的外环没到齐目标色，这一步就不换关。"""
LEVEL = "L5"
SCOPE = ("只看带坐标的 ACTION6；没有 ctx（拿不到关卡号）返回 NA；"
         "一个网格都扫不出来、调色板读不出来、中心图样里有 PAT 之外的图样色、"
         "某网格的正中色不在调色板里，返回 NA；"
         "调色板多于两色而共用瓦片又锁不死目标（解不唯一）返回 NA；"
         "被点瓦片的颜色不在调色板里返回 NA；"
         "换到下一个色之后所有网格都已到齐时返回 NA —— 那一半交给 ring_matched_levels_up。"
         "点击落在瓦片之间的缝里 / 网格之外 / 中心瓦片上时，按『外环不变』算，照常判。")
NOTE = ("v6：目标色不再是『两色里的另一个』。第 3 关调色板三色，"
        "『图样色2 该显示哪个色』本身不唯一，靠共用瓦片必须一致这条约束锁死（这一关锁出色8）。"
        "点击也从二元互换改成沿调色板循环前进（v5 的 flip_of 死于 6db074a25f82b9f4）。"
        "v5 熄灭色从写死的色9 改成清点出来的另一色；v4 点亮色改成从中心正中那格读；"
        "v3 两个映射色都写死；v2 只认色4 方框圈住的那一个网格；"
        "v1 死于 6ad68317227cf68f：只看 prev 的外环，而凑齐外环的那一下点击本身就是换关的那一步。")
EVIDENCE = ["d89ef1db9b3187a9", "6ad68317227cf68f", "6f06e09e88984ff9", "c2484e5c3063e99d", "6db074a25f82b9f4"]

from _lib import all_matched_after_click, click_xy

PAT_ON = 0         # 中心图样里代表「该位置外环应为中心正中那格的颜色」的图样色
PAT_OFF = 2        # 中心图样里代表「该位置外环应为调色板里别的某一个色」的图样色


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or click_xy(action) is None:
        return "NA"
    ok = all_matched_after_click(prev, action, PAT_ON, PAT_OFF)
    if ok is None or ok:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] else "FALSE"
