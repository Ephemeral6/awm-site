"""中心图样里取值 3 的那些位置，恰好就是外环上「没有可涂瓦片」的位置：出界、空槽、或另一个网格的中心。"""
LEVEL = "L7"
SCOPE = ("看 prev 与 nxt 两帧；一个网格都扫不出来的帧跳过，两帧都扫不出来返回 NA；"
         "只管中心图样里 0/2/3 三种取值的位置——出现第四种取值时判 FALSE，"
         "因为那说明『图样格只有这三种意思』这个前提本身塌了。")
NOTE = ("第 4 关才第一次出现取值 3：那一关有 8 个网格互相咬合，有的伸到画面外、有的角上是空的、"
        "有的角上是另一个网格的中心。前四关每个网格八个角都实打实有瓦片，所以图样里只有 0 和 2。"
        "这条一并给旧词汇里两处写死的东西平了反：网格不再要求『八个外环都单色』，"
        "也不再要求全图共用一套格点（第 0 关左右两组网格的相位本来就不一样）。")
EVIDENCE = ["3e15bdb9dfa25a5e"]

from _lib import PAT_NONE, center_pattern, centers, slot_kind, tile_grids

CODES = (0, 2, PAT_NONE)


def _check(g):
    """这一帧上主张成不成立：TRUE / FALSE / None（这帧没有网格，说不出话）。"""
    grids = tile_grids(g)
    if not grids:
        return None
    cset = set(centers(g))
    for o in grids:
        pat = center_pattern(g, o)
        if pat is None:
            return None
        for i in range(3):
            for j in range(3):
                if (i, j) == (1, 1):
                    continue
                code = pat[i][j]
                if code not in CODES:
                    return False
                gone = slot_kind(g, o, i, j, cset) in ("off", "empty", "center")
                if (code == PAT_NONE) != gone:
                    return False
    return True


def assert_(prev, action, nxt, ctx=None):
    verdicts = [v for v in (_check(prev), _check(nxt)) if v is not None]
    if not verdicts:
        return "NA"
    return "TRUE" if all(verdicts) else "FALSE"
