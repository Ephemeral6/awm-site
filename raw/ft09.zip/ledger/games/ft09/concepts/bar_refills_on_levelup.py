"""换关那一步之后，只要游戏还没结束，计数条就重新填满：已用格数回到 0。"""
LEVEL = "L4"
SCOPE = ("只看换关的一步（level_next == level_prev + 1）；别的步返回 NA；"
         "**换关同时游戏结束（state_next 不是 NOT_FINISHED）的那一步返回 NA** —— "
         "没有下一关，也就没有下一关的预算；nxt 的最后一行读不出已用格数时返回 NA")
NOTE = ("从 bar_eats_two v1 拆出来的第三半。它是这一局『预算』这个部件的关键一句："
        "预算按关重置，所以一关里走了多少步不会记到下一关头上。"
        "v2：v1 死于 bb2425ba3bde9b7b —— 打完最后一关（level 5→6，state 变 WIN）那一步，"
        "计数条**没有**重填，整屏也没有重画（帧差只有 32 格，就是被点那一块）。"
        "v1 那句『换关就重填』把「过关」和「过完最后一关」混成了一件事。"
        "这条边界只有在真的通关时才露出来，所以它是这一局跑到 WIN 才买到的一条判据。")
EVIDENCE = ["6ad68317227cf68f", "bb2425ba3bde9b7b"]

from _lib import bar_used


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx["level_next"] != ctx["level_prev"] + 1:
        return "NA"
    if ctx.get("state_next") not in (None, "NOT_FINISHED"):
        return "NA"
    b = bar_used(nxt)
    if b is None:
        return "NA"
    return "TRUE" if b == 0 else "FALSE"
