"""r11l 的读数（修复用副本，2026-09-28）。

来源：`archive/r11l-20260907/concepts/_lib.py`（词汇：菱形 / 圆块 / 靶环 / 漆块 / 竖条 / 底色、坐标口径）
与 `ledger/games/r11l/objects/parse.py`（按结构把一帧读成一个世界、每一格都要有人解释）。
形状常量、竖条、线段、质心的写法照抄原 `_lib.py`；认物件的顺序照抄 `parse.py`。

**为什么换读数。** 原 `_lib.py` 的读数只留计数与「中心点 / 整格」掩码，不留「谁是谁」：
哪颗菱形属于哪一组、罐子环上什么颜色、漆块什么墨、靶环什么颜色集合，都不在抽象状态里，
于是 step 一步都写不出来（原 WORLD.json 把 23 个变化字段全部声明成 unpredicted）。
这里只留 stepRules 真正要用、而且能从**当前这一帧**像素读出来的量：

    bar_rows   第 0 列色0 的行（原读数，不变）
    selected   选中菱形（环色0）的中心
    groups     每一组（罐子 + 牵着它的菱形）：罐子中心、罐子环 20 格的墨、各菱形中心与核色
    blobs      还没被取走的漆块：中心、环 20 格的墨
    reticles   靶环：中心、四条臂的颜色集合（位掩码；锁上的靶环记 0）
    walls      色2 的格（硬墙；一关之内不变，实测全语料关内 0 处变化）

全部读数只看传进来的这一帧 g，不看别的帧、不看动作、不看步序。

## 编码（定长元组，好让 formalize 按位展开成字段）

  · 组按「第一颗菱形的 (行,列)」排序，最多 3 组；每组 15 个整数：
      [罐子行, 罐子列, 墨, 菱形0行, 菱形0列, 菱形0核色, …, 菱形3行, 菱形3列, 菱形3核色]
    菱形按 (行,列) 排序，空位与空组一律填 -1。核色被罐子盖住读不到时记 -1。
  · 漆块按中心排序，最多 9 块，每块 [行, 列, 墨]；空位 -1。
  · 靶环按中心排序，最多 8 个，每个 [行, 列, 颜色集合位掩码]；锁上的记 0；空位 -1。
  · 墨 = 环上 20 格（DISC_RING 顺序）的颜色按 16 进制拼成的整数：第 i 格占 16^i 那一位。
    **环格上的色1 记成色10**：虚线只画在「显底色」的格上（概念 road_covers_fresh_ink / road_is_lines），
    而 21 格轮廓里不可能有色2 / 色5（有就不是轮廓，见 _disc_candidates），所以一格环色读到 1，
    它底下只能是色10。这是从这一帧的结构推出来的，不看别的帧。

读不成一个世界的帧（全语料 368 帧里 0 帧），各读数返回 None。

## 每关常数 LEVEL_CONST（修订 R1.1）：k_soft = 这一关的软地（色10）格

软地是「圆块压不上去」的那种底色（概念 move_rejected_on_blocked_terrain）。它和硬墙不同，
**不能**写成单帧读数：菱形能站在软地上、虚线也画在软地上，盖住的格这一帧读不出底色，
挪开之后露出来什么只有下一帧知道，所以「这一帧露着的软地」在关内会变、前向预测不了。
但软地本身是这一关的地形（游戏内容，和换关后的新盘面同类），一关之内不变。

来源（可复算：`meta/repair-20260928/_scratch/r11l-20260907/softmap.py`）：run r11l-0907-0045 的全部 184 条转移，
按 meta 的 level_prev / level 把前帧、后帧归到各自的关，用 ledger/games/r11l/objects/parse.py 读出每帧
**露着的**底色格（没被菱形 13 格、圆盘 21 格、靶环 12 格盖住，也不是虚线色1），把显色10 的格按关取并集。
核对：同一格在同一关里从没有一帧露成 10、另一帧露成 5 或 2（冲突 0 处）。
各关帧数：第0关 21、第1关 42、第2关 74、第3关 54、第4关 80、第5关 94、第6关（通关画面）3。
第 0、4、5、6 关一格软地都没露出来过，记 0。第 6 关是通关那一帧，盘面就是第 5 关的盘面。
整关都被盖着、从没露出来的格不知道是什么，按「不是软地」记——语料里 6 次驳回全部由这份软地图 + 硬墙解释，
收下的落子没有一次踩到它（对照输出见同目录 soft.py）。
"""
from __future__ import annotations

import itertools

N = 64
C_SEL, C_UNSEL, C_ROAD, C_WALL, C_GROUND, C_SOFT = 0, 3, 1, 2, 5, 10
TERRAIN = (C_WALL, C_GROUND, C_SOFT)

DIAMOND_RING = tuple((dr, dc) for dr in range(-2, 3) for dc in range(-2, 3)
                     if 1 <= abs(dr) + abs(dc) <= 2)                              # 12
DIAMOND = ((0, 0),) + DIAMOND_RING                                                 # 13
DISC_RING = tuple((dr, dc) for dr in range(-2, 3) for dc in range(-2, 3)
                  if (dr, dc) != (0, 0) and not (abs(dr) == 2 and abs(dc) == 2))   # 20
DISC = ((0, 0),) + DISC_RING                                                       # 21
RETICLE = tuple((dr, dc) for dr in range(-3, 4) for dc in range(-3, 4)
                if abs(dr) + abs(dc) == 4 and dr and dc)                           # 12
RETICLE_ARMS = tuple(tuple((dr, dc) for dr, dc in RETICLE
                           if (dr > 0) == (sr > 0) and (dc > 0) == (sc > 0))
                     for sr in (-1, 1) for sc in (-1, 1))                          # 4 × 3

MAX_GROUPS, MAX_ANCHORS, MAX_BLOBS, MAX_RETICLES = 3, 4, 9, 8


class _Unreadable(Exception):
    pass


def _cells(center, shape):
    r, c = center
    return frozenset((r + dr, c + dc) for dr, dc in shape)


def _at(g, r, c):
    return g[r][c] if 0 <= r < N and 1 <= c < N else None


def _centroid(ps):
    ps = list(ps)
    return (sum(p[0] for p in ps) // len(ps), sum(p[1] for p in ps) // len(ps))


def _rnd(a, n):
    q = (2 * abs(a) + n) // (2 * n)
    return q if a >= 0 else -q


def _line(p, q):
    (r0, c0), (r1, c1) = p, q
    dr, dc = r1 - r0, c1 - c0
    n = max(abs(dr), abs(dc))
    if n == 0:
        return [(r0, c0)]
    return [(r0 + _rnd(dr * i, n), c0 + _rnd(dc * i, n)) for i in range(n + 1)]


def _diamonds(g):
    out = []
    for r in range(N):
        for c in range(1, N):
            ring = {_at(g, r + a, c + b) for a, b in DIAMOND_RING}
            if len(ring) == 1:
                v = next(iter(ring))
                if v in (C_SEL, C_UNSEL) and g[r][c] != v:
                    out.append(((r, c), v, g[r][c]))
    return out


def _disc_candidates(g, taken):
    strict, loose = [], []
    for r in range(N):
        for c in range(1, N):
            cs = _cells((r, c), DISC)
            if any(_at(g, *q) is None for q in cs) or cs & taken:
                continue
            vals = [g[q[0]][q[1]] for q in cs]
            if any(v in (C_WALL, C_GROUND, C_UNSEL) for v in vals):
                continue
            solid = [v for v in vals if v != C_ROAD]
            if not solid or all(v == C_SOFT for v in solid):
                continue
            (strict if len(solid) == len(vals) else loose).append((r, c))
    occ = set()
    for m in strict:
        occ |= _cells(m, DISC)
    cand = sorted(strict + [m for m in loose if not (_cells(m, DISC) & occ)])
    out = []
    for m in cand:
        others = set()
        for m2 in cand:
            if m2 != m:
                others |= _cells(m2, DISC)
        priv = [g[q[0]][q[1]] for q in _cells(m, DISC) - others]
        if priv and not all(v in (C_SOFT, C_ROAD) for v in priv):
            out.append(m)
    return out


def _readings(sil):
    conf = {m: {m2 for m2 in sil if m2 != m and _cells(m, DISC) & _cells(m2, DISC)} for m in sil}
    hot = [m for m in sil if conf[m]]
    if not hot:
        return [list(sil)]
    if len(hot) > 10:
        raise _Unreadable("too many overlapping discs")
    free = [m for m in sil if not conf[m]]
    out = []
    for k in range(len(hot), 0, -1):
        for sub in itertools.combinations(hot, k):
            if any(b in conf[a] for a in sub for b in sub):
                continue
            if all(conf[x] & set(sub) for x in hot if x not in sub):
                out.append(sorted(free + list(sub)))
    return out


def _ink(g, m):
    """罐子 / 漆块环上 20 格的墨，16 进制拼成一个整数；色1 记成色10（见文件头）。"""
    v = 0
    for i, (a, b) in enumerate(DISC_RING):
        x = g[m[0] + a][m[1] + b]
        if x == C_ROAD:
            x = C_SOFT
        v += x * 16 ** i
    return v


def _finish(g, dia, sil):
    taken = set()
    for d in dia:
        taken |= _cells(d[0], DIAMOND)
    discs = set()
    for m in sil:
        discs |= _cells(m, DISC)
    taken |= discs
    rets, locked = [], []
    for r in range(N):
        for c in range(1, N):
            cs = _cells((r, c), RETICLE)
            vals = [_at(g, *q) for q in cs]
            if None in vals:
                continue
            if all(v == C_SEL for v in vals) and (r, c) in sil:
                locked.append((r, c))
                continue
            if cs & taken:
                continue
            if any(v in (C_SEL, C_UNSEL, C_GROUND, C_ROAD) for v in vals) or all(v in TERRAIN for v in vals):
                continue
            arms = []
            for arm in RETICLE_ARMS:
                s = {g[r + a][c + b] for a, b in arm}
                if len(s) != 1:
                    break
                arms.append(next(iter(s)))
            if len(arms) == 4:
                rets.append(((r, c), sum(1 << x for x in set(arms))))
    for t, _ in rets:
        taken |= _cells(t, RETICLE)
    for t in locked:
        taken |= _cells(t, RETICLE)
    stray = {(r, c) for r in range(N) for c in range(1, N)
             if (r, c) not in taken and g[r][c] in (C_SEL, C_UNSEL)}
    cands = []
    for r, c in sorted(discs):
        ring = [(r + a, c + b) for a, b in DIAMOND_RING]
        if any(_at(g, *q) is None for q in ring):
            continue
        vis = [q for q in ring if q not in discs]
        if not vis or not all(q in stray for q in vis):
            continue
        vs = {g[q[0]][q[1]] for q in vis}
        if len(vs) == 1:
            cands.append((len(vis), (r, c), next(iter(vs)), frozenset(vis)))
    cands.sort(key=lambda x: (-x[0], x[1]))
    expl = set()
    for n, cen, v, vis in cands:
        if vis & expl:
            continue
        tie = [x for x in cands if x[0] == n and x[1] != cen and x[3] & vis and not (x[3] & expl)]
        if tie:
            raise _Unreadable("covered diamond ambiguous")
        dia.append((cen, v, None))
        expl |= vis
    taken |= expl
    dia.sort(key=lambda d: d[0])
    occ = set(taken) | {(r, 0) for r in range(N)}
    members = {}
    for d in dia:
        segs, ok = {}, []
        for m in sil:
            seg = [q for q in _line(m, d[0]) if q not in occ]
            if all(_at(g, *q) == C_ROAD for q in seg):
                segs[m] = seg
                ok.append(m)
        seen_, blind = [], []
        for m in ok:
            others = set()
            for m2 in ok:
                if m2 != m:
                    others |= set(_line(m2, d[0]))
            (seen_ if [q for q in segs[m] if q not in others] else blind).append(m)
        cand = seen_ or blind
        if len(cand) != 1:
            raise _Unreadable("diamond not linked to exactly one disc")
        members.setdefault(cand[0], []).append(d)
    for m, ds in members.items():
        if _centroid([d[0] for d in ds]) != m:
            raise _Unreadable("disc not at centroid")
    roads = set()
    for m, ds in members.items():
        for d in ds:
            roads |= set(_line(m, d[0]))
    for r in range(N):
        for c in range(1, N):
            if (r, c) in taken:
                continue
            v = g[r][c]
            if v in TERRAIN or (v == C_ROAD and (r, c) in roads):
                continue
            raise _Unreadable("unexplained cell")
    sel = [d[0] for d in dia if d[1] == C_SEL]
    if len(sel) != 1:
        raise _Unreadable("selection not unique")
    groups = sorted((sorted((d[0], -1 if d[2] is None else d[2]) for d in ds), m, _ink(g, m))
                    for m, ds in members.items())
    blobs = sorted((m, _ink(g, m)) for m in sil if m not in members)
    reticles = sorted(rets + [(t, 0) for t in locked])
    return {"sel": sel[0], "groups": groups, "blobs": blobs, "reticles": reticles}


_CACHE: dict = {}


def _world(g):
    """一帧 → {sel, groups, blobs, reticles}；读不成返回 None。按帧内容缓存。"""
    try:
        k = hash(tuple(map(tuple, g)))
    except TypeError:
        return None
    if k in _CACHE:
        return _CACHE[k]
    if len(_CACHE) > 64:
        _CACHE.clear()
    w = None
    try:
        if len(g) == N and all(len(row) == N for row in g):
            dia = _diamonds(g)
            taken = set()
            for d in dia:
                taken |= _cells(d[0], DIAMOND)
            sil = _disc_candidates(g, taken)
            ok = []
            for s in _readings(sil):
                try:
                    ok.append(_finish(g, list(dia), s))
                except _Unreadable:
                    pass
            uniq = []
            for x in ok:
                if x not in uniq:
                    uniq.append(x)
            if len(uniq) == 1:
                w = uniq[0]
    except _Unreadable:
        w = None
    _CACHE[k] = w
    return w


# ---------------------------------------------------------------- 读数（formalize 按「一个参数」认它们）

def bar_rows(g):
    """第 0 列上色0 的行号集合。"""
    return {r for r in range(len(g)) if g[r][0] == C_SEL}


def selected(g):
    """选中菱形（环色0）的中心。"""
    w = _world(g)
    return None if w is None else w["sel"]


def groups(g):
    """每组 15 个整数：[罐子行, 罐子列, 墨, (菱形行, 菱形列, 核色) × 4]，最多 3 组，空位 -1。"""
    w = _world(g)
    if w is None or len(w["groups"]) > MAX_GROUPS:
        return None
    out = []
    for anchors, m, ink in w["groups"]:
        if len(anchors) > MAX_ANCHORS:
            return None
        row = [m[0], m[1], ink]
        for (r, c), core in anchors:
            row += [r, c, core]
        row += [-1] * (3 * (MAX_ANCHORS - len(anchors)))
        out += row
    out += [-1] * (15 * (MAX_GROUPS - len(w["groups"])))
    return tuple(out)


def blobs(g):
    """每块漆 3 个整数：[行, 列, 墨]，最多 9 块，空位 -1。"""
    w = _world(g)
    if w is None or len(w["blobs"]) > MAX_BLOBS:
        return None
    out = []
    for m, ink in w["blobs"]:
        out += [m[0], m[1], ink]
    out += [-1] * (3 * (MAX_BLOBS - len(w["blobs"])))
    return tuple(out)


def reticles(g):
    """每个靶环 3 个整数：[行, 列, 臂色集合位掩码（锁上记 0）]，最多 8 个，空位 -1。"""
    w = _world(g)
    if w is None or len(w["reticles"]) > MAX_RETICLES:
        return None
    out = []
    for t, cs in w["reticles"]:
        out += [t[0], t[1], cs]
    out += [-1] * (3 * (MAX_RETICLES - len(w["reticles"])))
    return tuple(out)


def walls(g):
    """色2（硬墙）的格，第 0 列除外。"""
    return {(r, c) for r in range(len(g)) for c in range(1, len(g[0])) if g[r][c] == C_WALL}


# ---------------------------------------------------------------- 每关常数（见文件头「LEVEL_CONST」一节）
# 'x' = 这一关露出来过的色10 底色格；位掩码与数据段同一口径：格 (r,c) 占第 r*64+c 位。

def _map_mask(rows):
    return sum(1 << (r * N + c) for r, row in enumerate(rows) for c, ch in enumerate(row) if ch == "x")


_SOFT_L1 = (
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    ".........................xxxxxxxxxx.............................",
    "........................xxxxxxxxxxxxxx..........................",
    ".....................xxxxxxxxxxxxxxxxx..........................",
    "...................xxxxxxxxxxxxxxxxxxxx.........................",
    ".................xxxxxxxxxxxxxxxxxxx............................",
    ".................xxxxxxxxxxxxxx.................................",
    ".................xxxxxxxxxxxxxx.................................",
    ".................xxxxxxxxxxxxxx........................xxxx.....",
    "................xxxxxxxxxxxxxxx.......................xxxxx.....",
    "..............xxxxxxxxxxxxxxxxx......................xxxxxxxxxxx",
    ".x............xxxxxxxxxx............................xxxxxxxxxxxx",
    ".x..................................................xxxxxxxxxxxx",
    ".xx.................................................xxxxxxxxxxxx",
    ".xxxx.................................................xxxxxxxxxx",
    ".xxxxx.................................................xxxxxxxxx",
    ".xxxxxx................................................xxxxxxxxx",
    ".xxxxxx............xxxxx.................................xxxxxxx",
    ".xxxxxx.........xxxxxxxxxx................................xxxxxx",
    ".xxxxxx.........xxxxxxxxxxxx..............................xxxxxx",
    ".xxxxxx.........xxxxxxxxxxxxx.............................xxxxxx",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxx..............................xxxxx",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxx..............................xxxxx",
    "....xxxxxxxxxxxxxxxxxxxxxxxxx..............................xxxxx",
    "....xxxxxxxxxxxxxxxxxxx....................................xxxxx",
    "....xxxxxxxxxxxxxxxxxxx....................................xxxxx",
    "....xxxxxxxxxxxxxxxxxxx.....................................xxxx",
    "....xxxxxxxxxxxxxxx.............................................",
    "....xxxxxxxxxxxxxxx.............................................",
    ".......xxxxxxxxxxxx.............................................",
    ".......xxx.......xx.............................................",
    ".......xx........xx.............................................",
    ".......xx........xx.............................................",
    ".......xx........xx.............................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
)
_SOFT_L2 = (
    ".........xx.....................................................",
    ".........xx.....................................................",
    ".........xx.....................................................",
    ".........xx.....................................................",
    ".........xx.....................................................",
    ".........xx.....................................................",
    ".........xxxx...................................................",
    ".........xxxx...................................................",
    "........xxxxx...................................................",
    "........xxxxx...................................................",
    ".......xxxx.....................................................",
    "...xxxxxxx......................................................",
    "...xxxxxx.......................................................",
    "...xxxxxx.......................................................",
    "...xxxxxx.......................................................",
    "...xxxxxx.......................................................",
    "...xxxxxx.......................................................",
    "...xxxxx........................................................",
    ".xxxxxxx.....................................................xxx",
    ".xxxxxx......................................................xxx",
    ".xxxxx......................................................xxxx",
    ".xxxxx.....................................................xxxxx",
    ".xxxxx....................................................xxxxxx",
    ".xxxx...........................................xxxxxxxxxxxxxxxx",
    ".xxxx.......................x...................xxxxxxxxxxxxxxxx",
    ".xxxx.....................xxxx..................xxxxxxxxxxxxxxxx",
    ".xxxx...................xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    ".xxxx..................xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    ".xxxx.................xxxxxxxxx..........xxxxxxxxxxxxxxxxxxxxxxx",
    ".xxxx.................xxxxxxx................xxxxxxxxxxxxxxxxxxx",
    ".xxxx..................xxxx....................xxxxxxxxxxxxxxxxx",
    ".xxxx..................xxx.......................xxxxxxxxxxxxxxx",
    ".xxxx.............................................xxxxxxxxxxxxxx",
    ".xxxx...............................................xxxxxxxxxxxx",
    ".xxxxx...............................................xxxxxxxxxxx",
    ".xxxxx................................................xxxxxxxxxx",
    ".xxxxx..................................................xxxxxxxx",
    ".xxxxxx..................................................xxxxxxx",
    ".xxxxxxx..................................................xxxxxx",
    ".xxxxxxxx..............................x....................xxxx",
    ".xxxxxxxx...........................xxxxx...................xxxx",
    ".xxxxxxxxx.....................xxxxxxxxxxx..................xxxx",
    ".xxxxxxxxxx.................xxxxxxxxxxxxxxxx................xxxx",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...............xxxx",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.............xx",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...............x",
    ".xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx................",
    ".xxxxxxxxxxxxxxxxxxxxxx............xxxxxxxxxxxx.................",
    ".....xxxxxxxxxxxxxxxxxx................xxxxxxxx.................",
    ".....xxxxxxxxxxxxxxxxxx...................x.....................",
    ".....xx.........xxxxxxx.........................................",
    "................xxxxxxx.........................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
)
_SOFT_L3 = (
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "..................................xxxxxxxxx.....................",
    ".................................xxxxxxxxxx.....................",
    ".................................xxxxxxxxxx.....................",
    ".............................xxxxxxxxxxxxxx.....................",
    ".............................xxxxxxxxxxxxxx.....................",
    "............................xxxxxxxxxxxxxxx.....................",
    "..........................xxxxxxxxxxxxxxxxx.....................",
    "..........................xxxxxxxxxxxxxxxx......................",
    ".........................xxxxxxxxxxxxxxxx.......................",
    ".........................xxxxxxxxxxxxxxx........................",
    ".........................xxxxxxxxxxxxxxx........................",
    ".........................xxxxxxxxxxxxxxx........................",
    ".........................xxxxxxxxxxxxxxx........................",
    ".........................xxxxxxxxxxxxx..........................",
    ".........................xxxxxxxxxxx............................",
    ".........................xxxxxxxxxx.............................",
    ".........................xxxxxxxx...............................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
    "................................................................",
)

LEVEL_CONST = {
    0: {"soft": 0},
    1: {"soft": _map_mask(_SOFT_L1)},
    2: {"soft": _map_mask(_SOFT_L2)},
    3: {"soft": _map_mask(_SOFT_L3)},
    4: {"soft": 0},
    5: {"soft": 0},
    6: {"soft": 0},
}
