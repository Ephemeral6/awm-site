"""21 格图案里，同色的区块只有三种形状：左半 10 格、右半 11 格、或整整 21 格；左右两半互不相交、并起来正好 21 格。

这是本关「取色」能凑成的全部原因：漆块的有色格是左半或右半，圆块的空格（色0）也是左半或右半，
所以取一次正好填掉一半，取两次正好装满。若哪一帧冒出第三种形状（比如斜着切三片），
两次取色就凑不满，本关的赢法讲法当场作废——所以这条要单独立起来挨打，而不是躺在规划器里当默认。

「左」「右」不是硬编码的：每一帧自己去看盘上所有 21 格图案分出来的偏移集，
再检验这些集合只有那三种、且两个半区互补。
"""
LEVEL = "L7"
SCOPE = ("同一帧内的结构不变量，prev 和 nxt 各判一次，都读得出来才算。"
         "**只在盘上存在「不牵虚线的 21 格漆块」时发话**——那是这套空罐子/漆块机制的标志；"
         "别的关的圆块环被切成两三片扇区，形状本来就不是这三种，本条管不到，返回 NA。"
         "**并且要求盘上每个靶环最多两种扇区色**：扇区色的种数就是世界公示的「这只罐子要取几次色」，"
         "三种色的靶环意味着漆块被切成三份，那不是本条管的那套形状，返回 NA。"
         "**同一个数还有第二个见证人，也要查**（v4）：任何一只圆块身上带了三种以上非色0 的颜色，"
         "同样返回 NA——锁定会把靶环整圈刷成色0，扇区色那份证据就消失了，而罐子里的墨不会消失。"
         "读不全（readable 为假）返回 NA。只看形状，不看颜色是什么、不看谁配谁。")
NOTE = ("v1。它是从一关的盘面量出来的：4 个漆块的有色格分别是 10/11/10 格，"
        "两个圆块一个整片色0（21 格）、一个 10 格色0 + 11 格色8，"
        "所有偏移集只有两个（10 格的和 11 格的），互不相交、并起来 21 格。"
        "**这条概念的用处在闸外**：规划器要靠「取两次正好装满」才排得出路线，"
        "而那个前提本来只活在我脑子里。写成概念之后，哪一帧出现第三种形状它当场报，"
        "而不是等我按着排好的路线走到一半发现凑不满。\n"
        "v2：它真的报了，而且报得有用（011cc2cb2680fa54）。新盘上 9 个漆块的墨色区块是 7/8/9/10/11 格，"
        "一眼就不是「左半/右半」。查出来的机制是：**靶环的扇区色种数变成了三**，"
        "于是漆块从对半切变成切三份，三块的墨色区块两两略有相交、并起来仍正好 21 格。"
        "所以缩 scope 的判据不是「打不过就改」，而是世界自己在靶环上写着的那个数："
        "扇区色 ≤ 2 时本条管，≥ 3 时另一条管（见 reticle_colors_have_tiling_inks）。"
        "取一次填一半这个前提，在扇区色为三的关里已经失效——规划器不许再默认它。\n"
        "v3 -> v4 修的不是主张，是**守卫的输入会消失**：通关那一步（002d9458b02bad4f）判 FALSE。"
        "那一帧盘上还是三墨的局面（两只罐子身上各带三种颜色），可 v3 的守卫读的是"
        "「**未锁定**靶环的扇区色数」——最后一只三色靶环刚被锁上，整圈刷成色0，"
        "于是守卫的输入没了，盘面「忘了」自己是三墨盘，本条开口，对着三色的罐子当场判错。"
        "这是同一类病的第二次：**沉默的守卫依赖一个会被世界擦掉的量**。"
        "改法不是把守卫放宽，是给同一个数换一个不会消失的见证人——罐子身上的墨。"
        "锁定不清空罐子（实测那一帧锁完的罐子仍是三色），所以这个见证人活得比靶环长。"
        "两个守卫都留着：开局罐子是空的、只有靶环说得出这个数；锁完靶环没了、只有罐子说得出。"
        "**代价要写明**：加了第二个守卫之后，本条在扇区色为三的那两关里从此全程 NA，N 不再增长；"
        "这不是修好了，是把它管不到的那一档标出来。"
        "另一条路是直接撤册（方法册「第三版还挨打就撤」），没走：它的主张是「两墨盘」这一档的特例，"
        "而那一档在终局卡的前几关还会再出现，撤掉就没人管那几关的形状了。")
EVIDENCE = ["3052579c3753d0c4", "011cc2cb2680fa54", "002d9458b02bad4f"]

from _lib import (C_SEL, CIRCLE2, circle_cells, clusters, disc_pattern, mids,
                  readable, reticles, silhouettes)

FULL = frozenset(CIRCLE2) | {(0, 0)}      # 21 格的偏移全集


def _shapes(g):
    """这一帧所有 21 格图案分出来的偏移集（含色0 的那些块）。读不出来返回 None。"""
    if not readable(g):
        return None
    rs = reticles(g)
    if rs and max(len(by) for by in rs.values()) >= 3:
        return None                       # 靶环公示「要取三次色」：漆块切三份，不是本条管的形状
    ms = mids(g)
    for m in ms.values():
        if len({v for v in disc_pattern(g, m).values() if v != C_SEL}) >= 3:
            return None                   # 罐子身上带三种以上的墨：同一个数的第二个见证人（v4）
    cl = clusters(g)
    bare = {m for m in silhouettes(g) if m not in cl}
    if not bare:
        return None                       # 没有漆块：不是这套机制
    out = []
    for m in list(bare) + list(ms.values()):
        by = {}
        for r, c in circle_cells(m):
            by.setdefault(g[r][c], set()).add((r - m[0], c - m[1]))
        out.extend(frozenset(v) for v in by.values())
    return out


def _ok(g):
    shapes = _shapes(g)
    if shapes is None:
        return None
    halves = sorted({s for s in shapes if s != FULL}, key=lambda s: -len(s))
    if not halves:
        return None                       # 全是整片：形状说不出左右，没得判
    if len(halves) > 2:
        return False                      # 冒出第三种形状
    if any(not s or not (s < FULL) for s in halves):
        return False
    if len(halves) == 2:
        a, b = halves
        return not (a & b) and (a | b) == FULL
    return len(halves[0]) in (len(FULL) // 2, len(FULL) - len(FULL) // 2)


def assert_(prev, action, nxt, ctx=None):
    vs = [v for v in (_ok(prev), _ok(nxt)) if v is not None]
    if not vs:
        return "NA"
    return "TRUE" if all(vs) else "FALSE"
