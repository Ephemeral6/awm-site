"""一组的圆块核落到本组靶心上就锁定：那圈靶环的 12 格从组色整圈变成色0，并且此后一直是色0。

推论（这条概念真正在判的形状）：任何一帧里都不存在「圆块核正好压在一圈**组色**靶环的中心上」——
一压上，那圈就已经不是组色了。
"""
LEVEL = "L5"
SCOPE = "同一帧内的结构不变量，看 nxt；帧里一个圆块都没有返回 NA"
NOTE = ("先误判成「靶环消失」——因为 targets() 只认组色的圈，锁定后就找不着了。"
        "把第 13 步前后同一块 9x9 打出来才看见：12 格一个不少，全从组色翻成了色0。"
        "教训记在方法册：一个物件「不见了」，先怀疑是自己的读法只认一种颜色。")
EVIDENCE = ["a7be1cf4a467a7e3"]

from _lib import mids, targets


def assert_(prev, action, nxt, ctx=None):
    ms = mids(nxt)
    if not ms:
        return "NA"
    for group, t in targets(nxt).items():          # 还是组色的圈 = 没锁
        if ms.get(group) == t:
            return "FALSE"
    return "TRUE"
