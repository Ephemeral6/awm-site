"""点击格不落在任何菱形上、且这一击不踩禁地时，选中菱形（环色0）的核就落在被点的那一格 (y, x)，且核色不变。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关那一步、点击格落在任一菱形上、prev/nxt 里选中菱形定位不到，都返回 NA；"
         "**这一击若被判踩禁地（move_verdict 为 True）也返回 NA**——那一档归 move_rejected_on_blocked_terrain 管；"
         "禁地判据本身看不全（底色被动件盖住）时，assert_ 保守返回 NA，apply 照旧生成（说错了 settle 会当场报）")
NOTE = ("v6：v5 用「撞车」当驳回判据，被 400b24d73506a804 打翻——世界收了一次明明压在菱形上的落子。"
        "换成底色判据（见 move_rejected_on_blocked_terrain）。"
        "v5：01bf5de21e68d4d6 把 v4 打翻——点在纯空地上、没命中任何菱形，整帧却只掉了一格竖条。")
EVIDENCE = ["1d2dcfbed7cf1d56", "a57029d2ec8f97c4", "15080d68a357ebbf", "01bf5de21e68d4d6",
            "795900e09ff3befb"]

from _lib import (C_SEL, DIAMOND2, after_click, click_xy, hit_diamond,
                  levelup, move_open, move_verdict, quiet, sel)


def _open(prev, action, strict):
    """这一击是不是「空地落子且放得下」那一档；是就返回 (点击格, 选中中心)。

    strict=True 给 assert_ 用：底色看不全就闭嘴。strict=False 给 apply 用：只要没看见禁色就敢生成。
    """
    if (p := click_xy(action)) is None:
        return None
    if hit_diamond(prev, p) is not None:
        return None
    s = sel(prev)
    if s is None:
        return None
    if after_click(prev, p) is None:
        return None
    if strict:
        if move_verdict(prev, p) is not False:
            return None
    elif not move_open(prev, p):
        return None
    return p, s


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    o = _open(prev, action, True)
    if o is None:
        return "NA"
    p, s0 = o
    s1 = sel(nxt)
    if s1 is None:
        return "NA"
    if s1 != p:
        return "FALSE"
    return "TRUE" if nxt[p[0]][p[1]] == prev[s0[0]][s0[1]] else "FALSE"


def apply(prev, action, ctx=None):
    if quiet(prev, action):
        return None                       # 换关那一步整盘重画，落点那 13 格也不作数
    o = _open(prev, action, False)
    if o is None:
        return None
    p, s = o
    out = {p: prev[s[0]][s[1]]}
    for dr, dc in DIAMOND2:
        rr, cc = p[0] + dr, p[1] + dc
        if 0 <= rr < len(prev) and 0 <= cc < len(prev[0]):
            out[(rr, cc)] = C_SEL
    return out
