"""算出来的新落点（挪动那个锚点的13格、或跟着挪的圆块的21格）跟别的已经认得出的动件（别的菱形、别的圆块、靶环）有几何重叠时，这一击照样会被世界收下——几何重叠本身不是驳回的判据。"""
LEVEL = "L2"
SCOPE = ("只看点在空地上的落子（ACTION6:x,y，不命中任何菱形，且 after_click 算出来确实是『选中的那个挪到 p』这一档）；"
        "换关那一步、选中菱形/所属簇定位不到，返回 NA。"
        "**只在算出来的新落点（新锚点 13 格 ∪ 新圆块 21 格，扣掉这个簇自己挪之前占的老格子）"
        "跟 prev 里别的已认得出的动件有交集时开口**——没有几何重叠，这一步不归本条管"
        "（那是 move_rejected_on_blocked_terrain 的地盘），返回 NA。"
        "**底色已经拦住这一击时也返回 NA**（v2）：本条主张的是『重叠**本身**不是驳回的判据』，"
        "而底色说不通的那一步根本考不出这件事——重叠和驳回在那里同时发生，谁是因说不清。"
        "判据直接用 move_open（move_rejected_on_blocked_terrain 用的同一套读法），不新发明一份。")
NOTE = ("v1。规划器（runs/r11l-0907-0045/policy.py 的 _check_move/_blocked_local）把『算出来的新落点"
        "跟别的动件的格子有交集』当成驳回的理由，用它去排除候选落点——但这句话从来没有被任何一条已入册"
        "的概念断言过：move_rejected_on_blocked_terrain 的首行主张只说底色（色2/色10）决定驳回与否，"
        "对『跟别的动件重叠』这件事一个字都没提，覆盖不到规划器暗中信的这句话。这里把它单独立出来接受检验："
        "重叠发生的转移在语料里本来就少，N 可能很小，那也要如实报，不是『没测过』就等于『没关系』。\n"
        "v2：出反例 01bf5de21e68d4d6（这一帧是读法改成两趟通配之后才读得出来的，v1 立案时它还是盲的）。"
        "查出来的是**混因**，不是主张错：那一步 move_open 为假，落脚的 34 格里有 19 格底色是色10，"
        "世界是按底色驳回的；重叠只有 1 格，而且是顺便发生。"
        "所以加的守卫不是缩到打得过为止，是把『考不出这件事的那一档』标出来——"
        "底色已经拦住的一步，无论重不重叠都会被驳回，它对『重叠本身要不要背这个锅』一个字都说不出。"
        "**代价要写明**：这条守卫会吃掉一部分本来开口的转移，N 会往下掉；"
        "而剩下的每一条都是干净的（底色放行、只有重叠这一个可疑因素、世界照样收下）。")
EVIDENCE = ["400b24d73506a804", "01bf5de21e68d4d6"]

from _lib import (after_click, centroid, circle_cells, click_xy, cluster_of,
                  diamond_cells, hit_diamond, levelup, mids, move_open, objects,
                  sel)


def _in_bounds(g, q):
    return 0 <= q[0] < len(g) and 0 <= q[1] < len(g[0])


def _landing(prev, action):
    """这一击若属于『空地落子、算得出新布局』那一档，返回 (落点, 簇, 新锚点, 新圆心)；否则 None。"""
    p = click_xy(action)
    if p is None or hit_diamond(prev, p) is not None:
        return None
    s = sel(prev)
    if s is None:
        return None
    a = after_click(prev, p)
    if a is None or a[1] != p:
        return None
    grp = cluster_of(prev, s)
    if grp is None or grp not in a[0]:
        return None
    new_anchors = a[0][grp]
    new_circle = centroid(new_anchors)
    return p, grp, new_anchors, new_circle


def _overlap(prev, p, grp, new_circle):
    """新落点（新锚点13格 ∪ 新圆块21格，界内）跟 prev 里『别的』动件（扣掉这个簇自己老占的格子）的交集。"""
    own_old = set()
    for a0 in grp:
        own_old |= diamond_cells(a0)
    old_mid = mids(prev).get(grp)
    if old_mid is not None:
        own_old |= circle_cells(old_mid)
    footprint = {q for q in (diamond_cells(p) | circle_cells(new_circle)) if _in_bounds(prev, q)}
    others = objects(prev) - own_old
    return footprint & others


def _frozen(prev, nxt):
    """除第 0 列外整帧一格没动——跟 move_rejected_on_blocked_terrain 用的是同一条判据。"""
    return all(prev[r][c] == nxt[r][c] for r in range(len(prev)) for c in range(1, len(prev[0])))


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    got = _landing(prev, action)
    if got is None:
        return "NA"
    p, grp, new_anchors, new_circle = got
    if not move_open(prev, p):
        return "NA"                      # 底色已经拦住：这一步考不出「重叠本身」（v2）
    if not _overlap(prev, p, grp, new_circle):
        return "NA"
    return "TRUE" if not _frozen(prev, nxt) else "FALSE"
