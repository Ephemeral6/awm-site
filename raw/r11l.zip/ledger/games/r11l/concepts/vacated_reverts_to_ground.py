"""菱形/圆块挪走后腾出来的格（prev 占着、按新布局不再占着的那些），在 next 里落在新路网上的显示色1，其余一律显示空地色5。"""
LEVEL = "L2"
SCOPE = ("只看带坐标的 ACTION6。换关那一步（ctx 的 level_prev != level_next）、prev 或 nxt 菱形读不全"
         "（stray_ring 非空）、布局算不出来（after_click 为 None，比如点在选中菱形自己身上）、"
         "这一击一格没腾出来（落子被驳回或只换选中）——全部 NA。"
         "两类格不认领：第 0 列竖条（另有其主），以及 prev 或 nxt 里认得出的靶环 12 格"
         "（菱形若停在靶环上再走开，露出来的该是靶环色不是底色；语料里 0 例，先划出去）。"
         "落在新路网上的那些格本条只断言、apply 不生成——色1 归 road_is_lines，避免同格双主。")
NOTE = ("腾空格的底色在 prev 里**看不见**（被物件自己盖着），所以这是一条「猜不见的东西」的主张，分两档，"
        "档次不同、可信度不同，SCOPE 没有把第二档摘出去，是故意的：\n"
        "  第一档（有机制）：prev 里被**圆块**盖着的腾空格。圆块压不上色2/色10（BLOCK_MID），"
        "所以圆块脚下的底色必然是色5——这一档是从既有概念推出来的，不是巧合。实测 233 格：色5 220、路网色1 13、其它 0。\n"
        "  第二档（只有实测，没有机制）：prev 里被**菱形**盖着的腾空格。菱形是能站在色10 上的（BLOCK_DIAMOND 只禁色2），"
        "所以原则上它一走就该露出色10。实测 156 格里 155 是色5、1 是路网色1、色10 零例——"
        "**但这只说明语料里还没有一个菱形从色10 上走开过**。已经能指出死因：拿跨帧攒的底色图反查，"
        "有菱形正整片压在色10 上（13 格里 10 格是色10），它一挪走这条概念就该判 FALSE。"
        "明知这一档要死还一起断言，是为了让世界在那一步当场把它打翻、进 PENDING，"
        "而不是让它悄悄错在 apply 里只掉几个 P。要把主张缩到第一档，把 ONLY_CIRCLE_VACATED 改成 True 即可（同时缩 assert_ 和 apply）。\n"
        "apply 用的腾空格集合只由 (prev, action) 算：occ(prev) − occ(after_click 布局)。"
        "实测 27 条转移上这个集合与事后按 nxt 算出来的**完全一致**（0 条不一致），"
        "预测的 409 格颜色全对——所以链式预测里旧位置擦得掉，模拟帧不会再留一圈鬼影让读法认出多余锚点。")
EVIDENCE = ["08c4dadd57a9ac9a", "659c9b89d4f9314e", "a23a2635e1d6d220"]

from _lib import (C_GROUND, C_ROAD, after_click, centroid, circle_cells,
                  click_xy, diamond_cells, diamonds, levelup, locked_targets,
                  mids, move_open, quiet, readable, reticle_cells, roads_of,
                  targets)

ONLY_CIRCLE_VACATED = False       # True = 只认领「圆块腾出来的」那一档（有机制支撑的那半）


def _inb(g, q):
    return 0 <= q[0] < len(g) and 0 <= q[1] < len(g[0])


def _diamond_occ(g):
    out = set()
    for center, _ring, _core in diamonds(g):
        out |= diamond_cells(center)
    return out


def _circle_occ(g):
    out = set()
    for _k, m in mids(g).items():
        out |= circle_cells(m)
    return out


def _occ(g):
    return {q for q in _diamond_occ(g) | _circle_occ(g) if _inb(g, q)}


def _layout_occ(g, gs):
    """只用 prev+action 算出来的新占位：每组每个锚点 13 格 + 该组质心 21 格。"""
    out = set()
    for _k, v in gs.items():
        for c in v:
            out |= diamond_cells(c)
        out |= circle_cells(centroid(v))
    return {q for q in out if _inb(g, q)}


def _reticles(g):
    out = set()
    for tt in (targets(g), locked_targets(g)):
        for _k, t in tt.items():
            out |= reticle_cells(t)
    return out


def _bar(g):
    return {(r, 0) for r in range(len(g))}


def _narrow(prev, cells):
    if not ONLY_CIRCLE_VACATED:
        return cells
    return cells & (_circle_occ(prev) - _diamond_occ(prev))


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    if not (readable(prev) and readable(nxt)):
        return "NA"
    p = click_xy(action)
    if p is None:
        return "NA"
    a = after_click(prev, p)
    if a is None:
        return "NA"
    cells = _narrow(prev, _occ(prev) - _occ(nxt) - _bar(prev)
                    - _reticles(prev) - _reticles(nxt))
    if not cells:
        return "NA"                      # 一格没腾出来：驳回、或只换选中
    road = {q for q in roads_of(a[0]) if _inb(prev, q)}
    for (r, c) in cells:
        if nxt[r][c] != (C_ROAD if (r, c) in road else C_GROUND):
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if quiet(prev, action):
        return None                      # 换关那一步整盘重画，旧位置也不作数
    p = click_xy(action)
    if p is None or not move_open(prev, p):
        return None
    a = after_click(prev, p)
    if a is None:
        return None
    road = {q for q in roads_of(a[0]) if _inb(prev, q)}
    cells = _narrow(prev, _occ(prev) - _layout_occ(prev, a[0])
                    - _bar(prev) - _reticles(prev) - road)
    return {q: C_GROUND for q in cells} or None
