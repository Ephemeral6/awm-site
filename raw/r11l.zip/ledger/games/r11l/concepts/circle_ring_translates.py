"""圆块环上的扇区图案跟着核平移，不变形——同一组的圆块在 prev 和 nxt 里，每个相对偏移上的颜色一模一样。"""
LEVEL = "L6"
SCOPE = ("同帧之间比同一个组的圆块；换关那一步（ctx 的 level_prev != level_next）返回 NA；"
         "prev 或 nxt 读不全（readable 为假）、某组的圆块在两帧里没有都认出来，返回 NA。"
         "只管环上那 20 格的配色，不管核落在哪——核的位置是 m_is_centroid 的主张。"
         "**圆块被上层轮廓遮住的那一簇跳过不谈**（见 NOTE v3）：一帧里是不牵虚线的轮廓、"
         "另一帧里同一位置牵上了虚线，说明那儿有个圆块钻到轮廓底下或者刚从底下出来，"
         "那一片显出来的是轮廓的颜色，不是这个圆块的环——读不到的东西不认领。别的簇照常发话。"
         "**圆盘里有虚线格的那一簇也跳过**（v4）：虚线压住的那一格真色读不到。")
NOTE = ("从 m_is_centroid 的 apply 里拆出来的。那条 apply 原来顺手把整圈 20 格涂成组色，"
        "第 0~2 关环本来就是纯组色，所以一直判对（273 格全中）；第 3 关环被切成扇区，"
        "同一句涂法就会把扇区信息抹平：组14 的颜色集合从 {11,14} 塌成 {14}，"
        "targets() 当场配不上靶环、把这一组丢掉，接着 road_is_lines 不再保护那个靶环、"
        "虚线盖上去、靶环从读法里彻底消失——一条错涂法引出四步连锁，全程没有任何东西报错。"
        "所以把「环随核平移」单独立成一条：它是一个独立的世界事实，该自己挨打。\n"
        "**第 3 关这一档还没测过**：第 0~2 关环是单色，平移与否看不出差别，"
        "所以现有证据只覆盖退化情形。真正检验它的是下一批——那是第一次在扇区环上搬圆块。"
        "要是图案其实会随移动方向翻转或旋转，这条会当场判 FALSE，那就是它该被发现的方式。\n"
        "v3：扇区环上第一次搬圆块（f6bd296b1788364d）判 FALSE，但推翻的不是「跟着平移」——"
        "那一步我把一个整片色0 的圆块搬到了一个不牵虚线的 21 格轮廓上，落点那 21 格一格没变"
        "（色8 的 11 格还是色8），虚线却重画到了那里。圆块在轮廓**底下**。"
        "所以那一簇的环在 nxt 里根本读不到，我读到的是轮廓。缩掉这一档，不是修补，是承认看不见。\n"
        "**这一版还留着一个预注册的错**：apply 只在「落点是上层轮廓」时闭嘴，"
        "「圆块从上层轮廓底下**搬出来**」那一档没闭嘴——那时 circles(prev) 读到的是轮廓的 0|8，"
        "apply 会照这个图案往新位置涂。于是下一步的说错格数本身就是读数："
        "圆块出来还是整片色0 → 那 11 格色8 涂错、说错约 11 格；"
        "圆块被染成了 0|8（轮廓是染色装置）→ 一格不错。两种结果我都要，所以故意不提前堵。\n"
        "v4 缩 scope，缩的是**读法的前提**不是主张：75d7cd93bd0af35a 上判 FALSE，"
        "而推翻的不是「跟着平移」——prev 里那个圆块被虚线破了一格（虚线画在它刚吸进来的"
        "那笔新墨上层，见 road_covers_fresh_ink），circles() 于是把色1 当成环上的一种色读进来，"
        "搬完那一格露出真的墨色，前后图案就「不一样」了。变的是我读到的东西，不是世界做的事——"
        "拿自己派生出来的东西前后比相等，响的永远是读法。改法：任一帧里这一簇的圆盘有虚线格"
        "就跳过这一簇（_lib.ring_broken），不猜被压住的那一格是什么色；别的簇照常发话。")
EVIDENCE = ["15080d68a357ebbf", "f6bd296b1788364d", "75d7cd93bd0af35a"]

from _lib import (after_click, centroid, circles, click_xy,
                  cluster_of, clusters, hit_diamond, levelup, mids, move_open,
                  quiet, readable, ring_broken, sel, silhouettes)


def _bare(g):
    """认得出轮廓、却牵不到任何菱形的那些位置。"""
    cl = clusters(g)
    return {m for m in silhouettes(g) if m not in cl}


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    if not (readable(prev) and readable(nxt)):
        return "NA"
    a, b = mids(prev), mids(nxt)
    ca, cb = circles(prev), circles(nxt)
    if not a or not b:
        return "NA"
    hidden = _bare(prev) | _bare(nxt)     # 一帧空着、一帧牵线的轮廓位置：底下压着圆块
    said = False
    for ka, ma in a.items():
        # 簇的名字是锚点元组，一步只动一个菱形，所以同一簇在 nxt 里换了名字。
        # 按锚点交集最大配对；交集为 0 就当它不在了，配不唯一就整条闭嘴。
        rank = sorted(((len(set(ka) & set(kb)), kb) for kb in b), reverse=True)
        if not rank or rank[0][0] == 0:
            continue
        if len(rank) > 1 and rank[0][0] == rank[1][0]:
            return "NA"
        mb = b[rank[0][1]]
        if ma in hidden or mb in hidden:
            continue                      # 这一簇的环被上层轮廓遮着，读不到，不认领
        if ring_broken(prev, ma) or ring_broken(nxt, mb):
            continue                      # 圆盘被虚线破了格：那一格的真色读不到，不猜
        pa, pb = ca.get(ma), cb.get(mb)
        if pa is None or pb is None:
            return "NA"
        if pa != pb:
            return "FALSE"
        said = True
    return "TRUE" if said else "NA"


def apply(prev, action, ctx=None):
    """把选中那一组的圆块环，按新核的位置整块搬过去。"""
    if quiet(prev, action):
        return None
    p = click_xy(action)
    s = sel(prev)
    if p is None or s is None or not readable(prev) or hit_diamond(prev, p) is not None:
        return None                       # 点在菱形上：只换选中，圆块不动
    if after_click(prev, p) is None or not move_open(prev, p):
        return None                       # 踩禁地会被驳回，圆块不动
    group = cluster_of(prev, s)
    if group is None:
        return None
    old = mids(prev).get(group)
    if old is None or ring_broken(prev, old):
        return None                       # 圆盘被虚线破了格：照这个图案涂过去会把色1 也搬走
    pat = circles(prev).get(old)
    if pat is None:
        return None
    a = [q for q in group if q != s] + [p]
    r, c = centroid(a)
    if (r, c) in _bare(prev):
        return None                       # 落点是个上层轮廓：搬过去就被盖住，这一片显的不是环
    out = {}
    for color, offs in pat.items():
        for dr, dc in offs:
            rr, cc = r + dr, c + dc
            if 0 <= rr < len(prev) and 0 <= cc < len(prev[0]):
                out[(rr, cc)] = color
    return out
