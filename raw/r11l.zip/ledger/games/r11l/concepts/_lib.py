"""r11l 的词汇表 —— 每个定义都是假设，不是装置给的事实。

第 0、1 关实测出来的读法：
    菱形 = 半径2实心菱形的**环**（12格，环色 0 或 3）裹一个**核**（1格，核色标明它属于哪一组）。
        环色 0 = 当前选中的那个（全图只有一个）；环色 3 = 没选中的。
    圆块 M = 切角 5×5（20格，环色 = 组色）裹一个色6 的核。每组一个。
    靶环 = 半径4菱形环去掉四个轴向尖端（12格，色 = 组色），中心空着或被 M 占。
    竖条 = 第 0 列的色0 竖线（每关开局 64 格），每个动作从上往下少一格。

第 3 关加的一层：圆块环和靶环都被**切成几片扇区**，一片一色，不再整圈同色。
    靶环是四条 3 格的臂（左上/右上/左下/右下），每条臂一个颜色；圆块的 20 格环照同一套配色切。
    盘上靶环比圆块多（8 个靶环 3 个圆块），**配对靠环上的颜色集合相同**，多出来的 5 个是幌子。
    扇区色**不是一张颜色清单**：色6 既当圆块核色又当靶环臂色，色10 既是底色又当靶环臂色。
    第 0~2 关是它的特例：只有一片扇区，颜色就是组色。读法见 _sectors / circles / reticles / targets。

底下还有一层**静态底色**：色5 是空地，色2 和色10 是两种不同的禁地（见 move_verdict）。
动件叠在底色上，所以底色只在没被盖住的地方读得到。

坐标一律 (行, 列)；动作串里的 ACTION6:x,y 是 (列, 行)，别弄反。
"""
from __future__ import annotations

from geo import bbox, cells_of  # noqa: F401

_CACHE: dict = {}


def _memo(fn):
    """按帧内容缓存。读法函数要全图扫 4096 格，一条转移上被十来条概念反复问同一件事。"""
    def wrap(g):
        try:
            k = (fn.__name__, hash(tuple(map(tuple, g))))
        except TypeError:
            return fn(g)
        if k not in _CACHE:
            if len(_CACHE) > 400:
                _CACHE.clear()
            _CACHE[k] = fn(g)
        return _CACHE[k]
    wrap.__name__ = fn.__name__
    wrap.__doc__ = fn.__doc__
    return wrap

DIAMOND2 = [(dr, dc) for dr in range(-2, 3) for dc in range(-2, 3)
            if 1 <= abs(dr) + abs(dc) <= 2]                                    # 12 格
CIRCLE2 = [(dr, dc) for dr in range(-2, 3) for dc in range(-2, 3)
           if (dr, dc) != (0, 0) and not (abs(dr) == 2 and abs(dc) == 2)]      # 20 格
RETICLE = [(dr, dc) for dr in range(-3, 4) for dc in range(-3, 4)
           if abs(dr) + abs(dc) == 4 and dr and dc]                            # 12 格

C_SEL, C_UNSEL, C_MID_CORE, C_GROUND, C_ROAD = 0, 3, 6, 5, 1
N, RING_COLORS = 64, (C_SEL, C_UNSEL)
TERRAIN = (2, C_GROUND, 10)          # 底色层用到的三种色：硬墙 / 空地 / 菱形能站但圆块压不上去


def _at(g, r, c):
    return g[r][c] if 0 <= r < len(g) and 0 <= c < len(g[0]) else None


def _match(g, r, c, offs):
    """(r,c) 周围 offs 这组偏移是否同色；同色就返回那个色，否则 None。"""
    v = _at(g, r + offs[0][0], c + offs[0][1])
    if v is None:
        return None
    for dr, dc in offs[1:]:
        if _at(g, r + dr, c + dc) != v:
            return None
    return v


@_memo
def diamonds(g):
    """全部菱形：[(中心, 环色, 核色)]，按中心排序。"""
    out = []
    for r in range(len(g)):
        for c in range(len(g[0])):
            ring = _match(g, r, c, DIAMOND2)
            if ring in RING_COLORS and g[r][c] != ring:
                out.append(((r, c), ring, g[r][c]))
    return sorted(out)


@_memo
def stray_ring(g):
    """说不清归属的色0/色3 格：读法被盖住的证据。

    这两个色只该出现在三处——菱形环、第0列竖条、锁定后的靶环。剩下的就是某个菱形被圆块压住、
    只露出半圈环的残片；那个菱形 diamonds() 认不出来，于是 sel/groups_of 全都少算一个。
    """
    ok = {(r, 0) for r in range(len(g))}
    for center, _ring, _core in diamonds(g):
        ok |= diamond_cells(center)
    for m in silhouettes(g):
        ok |= circle_cells(m)          # 第 4 关的圆块整片色0；它自己的格不算「说不清」
        if _match(g, m[0], m[1], RETICLE) == C_SEL:
            ok |= reticle_cells(m)     # 锁定后的靶环也是色0
    return sorted((r, c) for r in range(len(g)) for c in range(len(g[0]))
                  if g[r][c] in RING_COLORS and (r, c) not in ok)


def readable(g):
    """这一帧的动件能不能全认出来。认不全时凡是依赖 groups_of/centroid/mids 的话都不许说。

    三件事都要查：
      1. 有没有说不清归属的色0/色3 格（某个菱形被压住、只露半圈环）；
      2. 有没有两个轮廓互相重叠——21 格的东西不会叠在一起，叠了说明其中至少一个是幻影
         （圆块压住菱形时，把露出来的半圈环算进去会多认出一个错位的轮廓）；
      3. 每个菱形是不是都**恰好**归进了一个簇（clusters 认不准就不认，于是这里少人）。
    第 2 关吃过一次亏：圆块压住菱形，读法当场瞎掉而**没有任何东西报错**，册子只是集体沉默，
    我照着错的锚点算了四步。第 3 关圆块换成多色扇区，老 mids() 直接返回空——同一个坑的第二种长相。
    第 4 关圆块没有色6 的核，老 circles() 又一次全盘认不出——第三种长相。
    所以「读不出来」必须是一个能被问出来的状态，不能靠事后发现读数不对。
    第 2 条是新读法欠下的债：stray_ring 现在把轮廓的格算作「有归属」，幻影轮廓会顺手把压住的
    那半圈环吸收掉，让第 1 条失灵；所以直接查重叠，别指望第 1 条兜底。
    """
    if stray_ring(g):
        return False
    sil = silhouettes(g)
    seen: set = set()
    for m in sil:
        cells = circle_cells(m)
        if cells & seen:
            return False
        seen |= cells
    cl = clusters(g)
    if not cl:
        return False
    got = [d for v in cl.values() for d in v]
    return len(got) == len(set(got)) == len(diamonds(g))


def sel(g):
    """选中菱形（环色0）的中心；不唯一、没有、或这一帧读不全，返回 None。"""
    if not readable(g):
        return None
    cs = [d[0] for d in diamonds(g) if d[1] == C_SEL]
    return cs[0] if len(cs) == 1 else None


def anchors(g, group):
    """一个簇的全部菱形中心，排序。簇本身就是它的锚点元组（见 clusters）。"""
    return sorted(group)


def cluster_of(g, center):
    """含这个菱形中心的簇；认不出来返回 None。"""
    for v in clusters(g).values():
        if center in v:
            return v
    return None


def sector_colors():
    """已弃用：扇区色不是一张清单。留着只为让老代码报错而不是静默取错的值。"""
    raise RuntimeError("扇区色不再按颜色清单判（色6 是圆块核色也是靶环扇区色，色10 是底色也是靶环扇区色）；"
                       "改用 _sectors() 的结构判据")


NON_SECTOR = (C_SEL, C_UNSEL, C_GROUND, C_ROAD)   # 扇区里不会出现的色：菱形环色、空地、虚线
RETICLE_ARMS = [tuple((dr, dc) for dr, dc in RETICLE
                      if (dr > 0) == (sr > 0) and (dc > 0) == (sc > 0))
                for sr in (-1, 1) for sc in (-1, 1)]                       # 四条臂，各 3 格


def _sectors(g, center, offs, owned=(), arms=None):
    """center 周围 offs 这一圈的扇区分色：{色: frozenset(相对偏移)}；不成立返回 None。

    判据是结构性的，不是「哪些颜色算扇区色」：
      · 每一格都在盘内、不是空地/虚线/菱形环色、不属于别的物件；
      · 整圈不能全是底色——全是底色的那就是底色，不是物件（否则大片色10 里到处都是假靶环）；
      · 给了 arms 就要求每条臂内部同色（实测 8 个靶环条条如此，这是读法假设，错了会让配对整个塌掉）。
    """
    by: dict = {}
    for dr, dc in offs:
        q = (center[0] + dr, center[1] + dc)
        v = _at(g, q[0], q[1])
        if v is None or v in NON_SECTOR or q in owned:
            return None
        by.setdefault(v, set()).add((dr, dc))
    if all(k in TERRAIN for k in by):
        return None
    if arms and any(len({_at(g, center[0] + dr, center[1] + dc) for dr, dc in arm}) != 1
                    for arm in arms):
        return None
    return {k: frozenset(v) for k, v in by.items()}


@_memo
def silhouettes(g):
    """盘上所有 21 格圆块轮廓的中心，**不问它有没有色6 的核**。

    判据是结构的：21 格全在盘内、不属于菱形也不属于第0列竖条、且没有一格是硬墙/空地/虚线。
    第 0~3 关这么认和「找色6 核」认出来的是同一批；第 4 关的圆块整片色0、一个核都没有，
    只有这个判据认得出。注意它认出来的**不都是圆块**——有的关有几个同样形状的摆设/漆块，
    区别在于圆块牵着虚线、摆设不牵（见 clusters）。

    **色10 不再一律排除。** 原来把色10 和空地、硬墙并列排掉，理由是「大片色10 是底色」。
    代价是：墨色恰好是色10 的那种漆块整块看不见，而它的 21 格里有 14 格是色0，
    于是 stray_ring 把那 14 格算成「说不清」，readable() 整帧返回假——一关的册子当场集体失语，
    而且没有任何东西报错。现在的判据改成和 _sectors() 同一套：色10 允许出现在轮廓里，
    但**整圈全是色10 就不算物件**（那才是底色）。硬墙、空地照旧一格都不许有。

    **色1 虚线改成通配格。** 同一颗钉子的第二种长相：虚线原来和硬墙、空地并列排掉，
    可实测有一种局面里虚线就画在圆块自己那 21 格上——圆块刚吸进来的那笔墨所在的格，
    虚线压得上去；圆块原有的色所在的格，虚线压不上去。于是一格虚线就让整个轮廓消失，
    readable() 返回假，册子集体失语，`visible_terrain` 还把那 21 格当成地形去读，
    等圆块一走就报「地形变了」——反例落在地基那条概念头上，病因却在这里。
    改法：先按硬墙/空地否掉，再把虚线格从色集里剔掉，剩下的格按原来的判据审
    （非空、且不全是色10）。全量语料 202 帧的新旧对照：多认出 22 处轮廓（全部只破一格虚线）、
    原来认得而现在不认的 0 处、整圈只有底色被误认成物件的 0 处。

    **但通配格是一个让步，无条件通配会造假。** 上面那个对照漏量了一个数：读不出来的帧数。
    实测无条件通配之下 44/204 帧 readable 为假，而通配之前是 26/204——多出来的 20 帧
    全是同一个长相：真轮廓**错开一行**的那个位置，靠一格虚线蒙成了第二个候选，
    于是两个 21 格的东西叠在一起，readable() 第 2 条当场否掉整帧。
    幻影的形状认得出来：它的核色不在中心、底下压着某个菱形露出来的半圈环、而且必须用掉那一格通配。
    真货一格通配都不需要。所以判据是**让步分档**，不是格数阈值：
      第一趟不许有虚线格（严格），第二趟允许（宽松）；宽松候选凡是压在任何严格轮廓上的一律不认。
    宽松之间互相重叠的照旧留着，让 readable() 报「读不出来」——那是真的分不清，不许悄悄挑一个。
    全量语料 204 帧三方对照：读不出来 24（两趟）/ 26（只严格）/ 44（无条件通配）；
    两趟比只严格多认 2 处轮廓、少认 0 处；比无条件通配少认 20 处（就是那些幻影）、多认 0 处。
    两趟严格优于另外两套，不是折中。剩下的 24 帧读不出来另有病因（被压住的菱形，stray_ring），
    全部落在两个中间关卡，不在取色那几关。
    """
    n, m = len(g), len(g[0])
    taken = {(r, 0) for r in range(n)}
    for center, _ring, _core in diamonds(g):
        taken |= diamond_cells(center)
    strict, loose = [], []
    for r in range(n):
        for c in range(m):
            cells = circle_cells((r, c))
            if any(not (0 <= q[0] < n and 0 <= q[1] < m) for q in cells):
                continue
            if cells & taken:
                continue
            vals = [g[q[0]][q[1]] for q in cells]
            if any(v in (C_WALL, C_GROUND) for v in vals):
                continue
            solid = [v for v in vals if v != C_ROAD]
            if not solid or all(v == C_SOFT for v in solid):
                continue                     # 整片色10（或整片虚线）是底色，不是物件
            (strict if len(solid) == len(vals) else loose).append((r, c))
    occ: set = set()
    for m0 in strict:
        occ |= circle_cells(m0)
    cand = sorted(strict + [m0 for m0 in loose if not (circle_cells(m0) & occ)])

    # 「不全是色10 才算物件」这句话里的「全」，范围错了：它数的是候选自己的 21 格，
    # 可其中有些格是**邻居真物件的像素**。于是一块纯底色只要蹭到旁边真物件露出来的
    # 一格，就不再「全是色10」，当场被认成第二个物件，和真物件叠在一起，
    # readable() 第 2 条否掉整帧，全册对下一击集体沉默。实测有一处底色只借到**一格**
    # （21 格里 20 格色10 + 1 格邻居的环色），而且它一格虚线都不用——所以上面那道
    # 严格/宽松分档拦不住它，它是严格候选。
    # 改法：把「全」的范围缩到**私有格**——候选的 21 格里减掉别的候选也占的格，
    # 剩下的才算它自己的证据；自己的格全是色10 或全是虚线，判底色。
    # 一块候选之所以是物件，得靠它自己的格，不能靠邻居借来的那一格。
    # 全量语料 236 帧对照（对照脚本先逐帧比过自己抄的 readable 与本函数，0 处不一致）：
    # 读不出来的帧 25 → 12，少认 37 处轮廓、多认 0 处。少认的 37 处逐个看了色直方图，
    # 全是同一个长相（15+6 / 18+3 / 19+2 / 20+1 的色10 与借来的环色），没有真物件被误杀；
    # 真物件的直方图是 20 格环色 + 1 格核色**在正中**。剩下 12 帧另有病因（stray_ring 1 格），
    # 不再有任何一帧死在轮廓重叠上。
    cells_of = {c0: circle_cells(c0) for c0 in cand}
    keep = []
    for c0 in cand:
        others: set = set()
        for c1 in cand:
            if c1 != c0:
                others |= cells_of[c1]
        private = [g[q[0]][q[1]] for q in cells_of[c0] - others]
        if not private or all(v in (C_SOFT, C_ROAD) for v in private):
            continue
        keep.append(c0)
    return sorted(keep)


@_memo
def clusters(g):
    """哪些菱形归哪个圆块：{圆块中心: (锚点, ...)}。**靠虚线认，不靠质心。**

    第 0~3 关「一个核色一个圆块」，第 4 关同一种核色的 5 个菱形分成了两簇、各有各的圆块，
    所以「组」不能再用核色当名字，改用它的锚点元组。

    认法：轮廓 m 与菱形 d 之间，把 line(m, d) 上被物件盖住的格扣掉，剩下的**露在外面的格
    只要有一格不是虚线，就排除这条边**。没被排除的边分两档：露出过虚线的是**实证**，
    整条线都被两头的物件吞掉的只是「说不准」。有实证的边就只在实证里挑，一条实证都没有才退回
    「说不准」那一档。挑完恰好剩一个才认，否则这个菱形不归任何簇——readable() 会因此返回假。
    两档都用得上：有一关是「另外五个候选全被排除」才把整条线被吞掉的那个锚点认回来，
    另一关是「有实证的那个赢过整条线被吞掉的那个」才没把已经确定的边丢掉。

    **刻意不用质心认**（比如「谁的质心在这儿就是谁的」）：那会让 m_is_centroid 变成同义反复。
    虚线是世界画在盘上的成员关系，质心是我们要检验的主张，两者必须分开取证。
    """
    sil = silhouettes(g)
    if not sil:
        return {}
    occ = {(r, 0) for r in range(len(g))}
    for center, _ring, _core in diamonds(g):
        occ |= diamond_cells(center)
    for m in sil:
        occ |= circle_cells(m)
        if _match(g, m[0], m[1], RETICLE) == C_SEL:
            occ |= reticle_cells(m)          # 锁定后的靶环是色0，盖在虚线上
    for t in reticles(g):
        occ |= reticle_cells(t)
    out: dict = {}
    for center, _ring, _core in diamonds(g):
        # 「露出来的格全是虚线」不够——还要问那几格是不是**它自己的**。
        # 实测局面：一颗菱形离另一组的圆块很近，两头的物件把它们之间 6 格的线吞掉 5 格，
        # 剩下唯一那一格恰好落在它与真属主之间那条长线上。于是两条边都算「实证」，
        # 候选剩两个，下面 len(cand)==1 不成立，这颗菱形不归任何簇，
        # readable() 假，全册对下一击集体沉默，规划器退到兜底。
        # 真属主那条边有 11 格私有虚线，冒充的那条边私有 0 格——强弱差一个数量级，
        # 而旧判据把两者并列。这和 silhouettes 那处是同一颗钉子：
        # 判据的作用域盖过了边界，邻居就会替候选作证。
        # 改法：实证那一档要求**至少一格私有**（不在其他存活候选的线上）；
        # 私有格为零的边退回「说不准」那一档——它自己的线确实一格都没露出来。
        # 全量语料 256 帧对照（对照直接替换本函数走真代码路径，不手抄 readable）：
        # 读不出来的帧 13 → 12，新归上 1 颗菱形，丢掉归属 0 颗，改判给另一个簇 0 颗。
        segs, ok = {}, []
        for m in sil:
            seg = [q for q in line(m, center) if q not in occ]
            if not all(_at(g, q[0], q[1]) == C_ROAD for q in seg):
                continue
            segs[m] = seg
            ok.append(m)
        shown, blind = [], []
        for m in ok:
            others: set = set()
            for m2 in ok:
                if m2 != m:
                    others |= set(line(m2, center))
            private = [q for q in segs[m] if q not in others]
            (shown if private else blind).append(m)
        cand = shown or blind
        if len(cand) == 1:
            out.setdefault(cand[0], []).append(center)
    return {m: tuple(sorted(v)) for m, v in out.items()}


@_memo
def circles(g):
    """每个圆块 20 格环上的颜色分区：{圆块中心: {色: frozenset(相对偏移)}}。

    第 0~2 关整圈一色（就是组色）；第 3 关切成几片扇区，一片一色；第 4 关整圈色0。
    圆块是谁由 clusters() 说了算，这里只负责把环上的颜色摆出来。
    """
    out = {}
    for m in clusters(g):
        by: dict = {}
        for dr, dc in CIRCLE2:
            by.setdefault(_at(g, m[0] + dr, m[1] + dc), set()).add((dr, dc))
        out[m] = {k: frozenset(v) for k, v in by.items()}
    return out


def disc_pattern(g, m):
    """m 那 21 格：相对偏移 -> 颜色。纯读法，不主张任何东西。"""
    return {(r - m[0], c - m[1]): _at(g, r, c) for r, c in circle_cells(m)}


def ring_broken(g, m):
    """m 那 21 格里有没有虚线格。

    有就说明这个圆块环上的**真色读不全**：虚线会画在圆块刚吸进来的那笔墨上层
    （见概念 road_covers_fresh_ink），被压住的那一格的组色是读不到的。
    凡是拿环上颜色集合吃饭的判断（配对、平移比较），遇到 broken 一律闭嘴，别猜。
    """
    return any(_at(g, r, c) == C_ROAD for r, c in circle_cells(m))


def pickup(prev, action):
    """这一击会不会取色：会 -> (旧圆块核, 漆块核)；不会 -> None。

    取色 = 把选中那一簇的圆块核，正好搬到一个「认得出 21 格轮廓、却牵不到任何菱形」的
    位置（漆块）的核上。**这是读法**：它只说这一击落在哪儿，不说落下去以后那 21 格变成什么
    （那是 circle_absorbs_blob_ink 与 road_covers_fresh_ink 各自的主张）。
    放进词汇是因为两条以上概念共用它——检查器和生成器各算一份，就等着分岔。
    """
    p = click_xy(action)
    s = sel(prev)
    if p is None or s is None or not readable(prev) or hit_diamond(prev, p) is not None:
        return None
    if after_click(prev, p) is None or not move_open(prev, p):
        return None
    group = cluster_of(prev, s)
    if group is None:
        return None
    old = mids(prev).get(group)
    if old is None:
        return None
    tgt = centroid([q for q in group if q != s] + [p])
    cl = clusters(prev)
    if tgt not in {m for m in silhouettes(prev) if m not in cl}:
        return None
    return old, tgt


def fresh_ink(prev, action):
    """取色那一步，漆块**要改掉颜色**的那些绝对格 -> 漆块的墨色；不是取色返回 {}。

    只读 prev：漆块在这个偏移上有色（非色0）、而且和圆块现在这个偏移的色不一样。
    「不一样的格才算」是要紧的——漆块和圆块碰巧同色的格，压过去看不出变化，
    拿它当证据会把恒真当成读数。
    """
    got = pickup(prev, action)
    if got is None:
        return {}
    old, tgt = got
    was, ink = disc_pattern(prev, old), disc_pattern(prev, tgt)
    out = {}
    for off, v in was.items():
        new = ink.get(off, C_SEL)
        if new != C_SEL and new != v:
            out[(tgt[0] + off[0], tgt[1] + off[1])] = new
    return out


def soft_ink(prev, action):
    """fresh_ink 里**墨色恰好是底色之一**的那些格 -> 墨色。纯读法。

    为什么单独拿出来：虚线的遮挡判据不是「这一格属于某个物件」，而是「这一格显的颜色不是底色」。
    墨色撞上底色的那些格，物件占着也照样被虚线画过去（road_covers_fresh_ink 正面主张，
    road_is_lines 从遮挡名单里减掉它们）。两条概念共用这一份，不各算一次。
    """
    return {q: v for q, v in fresh_ink(prev, action).items() if v in TERRAIN}


def soft_cells(g):
    """帧 g 的物件格里**挡不住虚线**的那些：显底色三色之一的，加上已经显色1 的。纯读法。

    比 soft_ink 宽在哪：soft_ink 只认「圆块这一击刚吸进来的墨」，要 prev+动作两样东西才算得出，
    因而只覆盖罐子里的墨。这里只看一帧的颜色，谁占着这一格不问——摆设、漆块、菱形、靶环一视同仁。

    为什么敢把「显色1」也算进来：色0 的空格挡得住虚线（全量语料 1525 格次，无一例外），
    所以物件格显色1 只可能是「底色系的格被虚线盖住了」，不会是别的东西。
    这一句只在**读上一帧、预测下一帧**时能用；拿同一帧的色1 去判同一帧的虚线是循环，
    road_is_lines 的 SCOPE 里写明了这个盲点。
    """
    out = set()
    for p in objects(g):
        v = _at(g, p[0], p[1])
        if v in TERRAIN or v == C_ROAD:
            out.add(p)
    return out


@_memo
def reticles(g):
    """全部还没锁定的靶环，按中心认：{中心: {扇区色: frozenset(相对偏移)}}。

    靶环 = 12 格（半径4菱形环去掉四个轴向尖端）= 四条 3 格的臂，每条臂一个颜色。
    第 3 关盘上 8 个：色6 和色10 都当过臂色，所以判据只能是结构的，不能列颜色清单。
    """
    taken = set()
    for center, _ring, _core in diamonds(g):
        taken |= diamond_cells(center)
    for m in silhouettes(g):
        taken |= circle_cells(m)
    out = {}
    for r in range(len(g)):
        for c in range(len(g[0])):
            by = _sectors(g, (r, c), RETICLE, taken, RETICLE_ARMS)
            if by:
                out[(r, c)] = by
    return out


@_memo
def mids(g):
    """全部圆块：{簇: 圆块中心}。簇的名字是它的锚点元组，见 clusters()。"""
    return {v: m for m, v in clusters(g).items()}


@_memo
def targets(g):
    """还没锁定的靶环：{组色: 靶心}。**配对靠环上的颜色集合相同**。

    第 0~2 关：圆块环是纯组色，靶环也是纯组色，颜色集合都是 {组色}，配对就是老规则。
    第 3 关：盘上 8 个靶环、3 个圆块，颜色集合给出唯一配对（组9 的 {8,9} 只配得上 (54,17)，
    组14 的 {11,14} 只配得上 (12,50)，组15 的 {12,14,15} 只配得上 (49,36)）；
    剩下 5 个靶环（{6,7}、{9,12}、{13}、{10,12}、{10,14}）没有对应的圆块，是幌子。
    配不上、或配上不止一个，那个组就不出现在结果里——宁可不说。

    还看出一层更强的对应但**没写进判据**：圆块环的四个象限和靶环的四条臂逐块同色
    （组15 的圆块是左上12 / 右上14 / 下8格15，靶环 (49,36) 正是左上12 右上14 左下15 右下15）。
    集合相等已经给出唯一配对，先不上更强的条件——真要用它得先把象限的切法量准。
    """
    cs = circles(g)
    rs = reticles(g)
    out = {}
    for k, m in mids(g).items():
        want = frozenset(cs.get(m, {}))
        hit = [t for t, by in rs.items() if frozenset(by) == want]
        if len(hit) == 1:
            out[k] = hit[0]
    return out


def locked_targets(g):
    """已锁定的靶环：{簇: 靶心}。锁定后整圈 12 格从组色变成色0，靶心上正压着本簇圆块。"""
    out = {}
    for group, m in mids(g).items():
        if _match(g, m[0], m[1], RETICLE) == C_SEL:
            out[group] = m
    return out


def reticle_cells(t):
    """靶环占的 12 格。"""
    return {(t[0] + dr, t[1] + dc) for dr, dc in RETICLE}


@_memo
def objects(g):
    """动件层里「不是虚线」的那部分：菱形 13 格、圆块 21 格、靶环 12 格、第 0 列竖条。

    靶环这里要数**全部**，不只是配得上圆块的那些：第 3 关盘上有 3 个谁也配不上的幌子靶环，
    它们不在 targets() 里，可它们照样盖着底色。漏掉就会把色7/色13 之类当成底色读进底色图。
    """
    out = {(r, 0) for r in range(len(g))}
    for center, _ring, _core in diamonds(g):
        out |= diamond_cells(center)
    for m in silhouettes(g):
        out |= circle_cells(m)         # 摆设也要数：它照样盖着底色（第 4 关有 4 个）
    for t in list(reticles(g)) + list(locked_targets(g).values()):
        out |= reticle_cells(t)
    return out



def centroid(ps):
    """一组点的下取整质心。"""
    return (sum(p[0] for p in ps) // len(ps), sum(p[1] for p in ps) // len(ps))


def on_diamond(center, p):
    """p 是否落在以 center 为心的半径2实心菱形（13 格：核+环）上。"""
    if center is None or p is None:
        return False
    return abs(p[0] - center[0]) + abs(p[1] - center[1]) <= 2


def hit_diamond(g, p):
    """p 落在哪个菱形上：返回 (中心, 环色, 核色) 或 None。"""
    for d in diamonds(g):
        if on_diamond(d[0], p):
            return d
    return None


def bar_rows(g):
    """第 0 列上色0 的行号集合。"""
    return {r for r in range(len(g)) if g[r][0] == C_SEL}


def click_xy(action):
    """'ACTION6:x,y' -> (行, 列)；不是带坐标的 ACTION6 就返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return (y, x)


def levelup(ctx):
    """这一条转移是不是换关。ctx 拿不到就当不是。"""
    return bool(ctx) and ctx.get("level_prev") != ctx.get("level_next")


def finished(ctx):
    """这一条转移把整局走完了没有（上游的 state 从 NOT_FINISHED 变成别的）。

    要紧的区别：通关那一步上游的关数**也会加一**（打完第 n 关，level 变成 n）。
    所以 levelup(ctx) 在通关那一步同样为真，而那一步并没有「进入新的一关」——
    盘面还是刚才那一盘，只是标成赢了。「关数加一」和「进入新一关」在这里分开。
    链式模拟里拿不到 state（是 None），当作没结束，不然模拟一开始就集体闭嘴。
    """
    return bool(ctx) and ctx.get("state_next") not in (None, "NOT_FINISHED")


def line(p, q):
    """p 到 q 的整格直线（沿长轴逐格，短轴四舍五入），含两端。"""
    (r0, c0), (r1, c1) = p, q
    dr, dc = r1 - r0, c1 - c0
    n = max(abs(dr), abs(dc))
    if n == 0:
        return [p]
    return [(r0 + int(dr * i / n + (0.5 if dr >= 0 else -0.5)),
             c0 + int(dc * i / n + (0.5 if dc >= 0 else -0.5)))
            for i in range(n + 1)]


def diamond_cells(center):
    """菱形占的 13 格（核 + 环）。"""
    return {(center[0] + dr, center[1] + dc) for dr, dc in DIAMOND2} | {center}


def circle_cells(m):
    """圆块占的 21 格（核 + 切角环）。"""
    return {(m[0] + dr, m[1] + dc) for dr, dc in CIRCLE2} | {m}


def groups_of(g):
    """{簇: [该簇全部菱形中心]}。第 4 关起同一种核色可以有好几簇，所以名字不能再用核色。"""
    return {v: list(v) for v in clusters(g).values()}


def after_click(g, p):
    """这一击之后的菱形布局：({簇: [锚点…]}, 新的选中中心)。

    点在没选中的菱形上 = 只换选中权，布局不变；点在空处 = 选中的那个挪到 p。
    点在选中菱形自己身上、或选中菱形定位不到，返回 None（没测过的情形）。
    **键沿用挪动前那个簇的名字**，好让「挪之前的这一簇」和「挪之后的这一簇」在两帧之间对得上。
    """
    s = sel(g)
    if s is None or p is None:
        return None
    d = hit_diamond(g, p)
    gs = groups_of(g)
    if d is None:
        grp = cluster_of(g, s)
        if grp is None:
            return None
        gs[grp] = sorted([q for q in grp if q != s] + [p])
        return gs, p
    if d[1] == C_UNSEL:
        return gs, d[0]
    return None


C_WALL, C_SOFT = 2, 10
BLOCK_DIAMOND = (C_WALL,)          # 菱形落不上去的底色
BLOCK_MID = (C_WALL, C_SOFT)       # 圆块压不上去的底色


def visible_terrain(g, cells):
    """这些格在这一帧里**露着的**底色：{格: 色}，被动件或虚线盖住的给 None。

    底色是静态层（见 terrain_is_static），可动件叠在它上面；所以只有没被盖住的格能直接读。
    说不清归属的色0/色3 格（stray_ring）也算看不见——它们是被压住的菱形露出来的环残片，不是底色。
    """
    occ = objects(g) | set(stray_ring(g))
    out = {}
    for q in cells:
        v = _at(g, q[0], q[1])
        out[q] = None if (v is None or q in occ or v == C_ROAD) else v
    return out


def _blocked(g, cells, bad):
    """(踩到禁色吗, 有几格看不见)。"""
    t = visible_terrain(g, cells)
    return any(v in bad for v in t.values() if v is not None), sum(1 for v in t.values() if v is None)


def move_verdict(g, p):
    """这一击的落子会被驳回吗：True=驳回, False=放得下, None=不适用或底色看不全。

    判据（第 2 关实测，18 次落子分得干净）：菱形 13 格踩到色2、或算出来的圆块 21 格踩到色2/色10，就驳回。
    色10 在菱形底下无所谓，在圆块底下不行——所以两层各有各的禁色。
    """
    a = after_click(g, p)
    if a is None or a[1] != p:
        return None                                    # 换选中那一档不落子
    s = sel(g)
    grp = cluster_of(g, s)
    if grp is None or grp not in a[0]:
        return None
    db, du = _blocked(g, diamond_cells(p), BLOCK_DIAMOND)
    mb, mu = _blocked(g, circle_cells(centroid(a[0][grp])), BLOCK_MID)
    if db or mb:
        return True
    return None if (du or mu) else False


def move_open(g, p):
    """给 apply 用的宽版：只要没**看见**禁色就敢生成（看不全当放得下）。

    assert_ 那边看不全就 NA，是为了不说没根据的话；apply 这边宽一档，是因为说错了 settle 会当场报出来。
    """
    return move_verdict(g, p) is not True


def leftover_mids(g):
    """既没锁定、也配不上任何靶环的组，按「罐子满没满」分成两堆：(没装满的, 满了却配不上的)。

    为什么要它：targets() 的策略是「配不上就不出现在结果里——宁可不说」，作为读法很稳健；
    可目标判定问的是「**每一个**组都到位了吗」，拿 targets() 当分母，配不上的组就从分母里消失了，
    「每一个都到位」会在只到位一个的时候成立。读法的谦虚在目标判定里变成断言的激进。
    环上还带色0 的圆块是没装满的罐子，它一定不在任何靶心上；满了却配不上唯一靶环的，说不清。
    判据是概念 levelup_iff_mids_on_targets 的主张，这里只把算式摆出来给两处共用。
    """
    t, locked, cs = targets(g), locked_targets(g), circles(g)
    unfilled, puzzling = [], []
    for k, m in mids(g).items():
        if k in t or k in locked:
            continue
        (unfilled if C_SEL in cs.get(m, {}) else puzzling).append(k)
    return unfilled, puzzling


def completes_level(g, p):
    """这一击会不会换关：True/False，判不出来 None。

    换关那一步整盘重画（新底色、新靶、新锚点），一格都不是从这一帧能算出来的。
    所以这是给 apply 用的**闭嘴开关**：会换关就一条都不生成，别拿旧盘的布局去填新盘。
    判据本身不在这儿——它是概念 levelup_iff_mids_on_targets 的主张，这里只是把它的算式借来一次。

    落子成不成判不出来（底色被自己的动件盖住，move_verdict 返回 None）时，这里**当它放得下**。
    和 move_open 反着的取舍：move_open 宽是为了敢生成，这里宽是为了敢沉默——
    多闭一次嘴只丢 E，少闭一次嘴就会拿旧盘的格子去赌新盘。所以这一档必须往「会换关」偏。

    但「往会换关偏」不等于可以少算一个组：借来的算式跟着概念走到了第 4 版，
    盘上还有没装满的罐子时它判**不换关**，于是这里也不再闭嘴（那 123 格帧差本来白丢了 E）。
    """
    t = targets(g)
    if not t:
        return None
    a = after_click(g, p)
    if a is None:
        return None
    if move_verdict(g, p) is True:
        after = dict(mids(g))                     # 被驳回：一格没动，肯定不换关
    else:
        after = {k: centroid(v2) for k, v2 in a[0].items()}
    if any(k not in after for k in t):
        return None
    if not all(after[k] == t[k] for k in t):
        return False
    unfilled, puzzling = leftover_mids(g)
    if unfilled:
        return False                              # 空罐子必然不在靶心上
    if puzzling:
        return None                               # 满了却配不上：说不清，按「宁可闭嘴」那一档走
    return True


def quiet(g, action):
    """apply 该不该整条闭嘴：菱形读不全、或这一击**确定**会换关。

    判不出来会不会换关（None）时照旧生成——和 move_open 一个道理：apply 宽一档，说错了 settle 当场报。
    这里要是把 None 也算成闭嘴，靶环全锁的那些帧（targets 为空 -> None）会一起被闷掉，E 白掉一截。
    """
    if not readable(g):
        return True
    p = click_xy(action)
    if p is None:
        return True
    return completes_level(g, p) is True


def roads_of(gs):
    """这套布局该画的虚线：每簇圆块到本簇每个锚点的整数直线之并。"""
    out = set()
    for _k, v in gs.items():
        m = centroid(v)
        for a in v:
            out |= set(line(m, a))
    return out

