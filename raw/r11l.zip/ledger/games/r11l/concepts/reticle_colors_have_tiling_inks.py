"""扇区色不止一种的靶环，若每种扇区色在盘上都恰好有一块漆带这个墨色，那这几块漆的墨色格并起来正好铺满 21 格圆盘。

换句话说：世界把「装满一只罐子要取哪几次色」写在了靶环上——扇区色的种数就是取色的次数，
而对应的那几块漆的有色区块**互相之间可以重叠，并集却不多不少正好是整片 21 格**。
所以按靶环的颜色集合去取色，取完罐子一定是满的（环上再没有色0），不会差一格也不会多出第四块。

这条概念的用处在闸外：整局的赢法就架在它上面——「照着靶环的颜色集合挨个去取，取完就能锁」。
那个前提本来只活在规划器里。写成概念之后，哪一帧的漆块凑不满 21 格它当场报，
而不是等我把三块漆都吸完、发现罐子还缺一角、而那几块漆已经被吸没了、这一关再也救不回来。

不断言配对（那归 target_pairs_by_sector_colors）、不断言取色怎么填（那归 circle_absorbs_blob_ink）、
也不断言哪个靶环是幌子——扇区色找不到唯一漆块的靶环，本条直接跳过不发话。
"""
LEVEL = "L7"
SCOPE = ("同一帧内的结构不变量，prev 和 nxt 各判一次，都读得出来才算。"
         "读不全（readable 为假）、盘上没有靶环、或者没有一个靶环够格发话，一律返回 NA。"
         "**够格 = 扇区色不止一种，且每种扇区色在盘上恰好有一块漆带它。** 不够格的整个跳过："
         "只有一种扇区色的靶环见 NOTE v2（那种一定装不满，是构造出来的幌子）；"
         "扇区色找不到漆块的多半是幌子、或者那几块漆已经被取走了；找到不止一块的说不清该用哪块。"
         "只看漆块（认得出 21 格轮廓、却牵不到任何菱形的那些），不看罐子自己环上已有的颜色。")
NOTE = ("v1。由来：进这一关的开局帧上，9 块漆的墨色区块是 7/8/9/10/11 格，"
        "而 blob_inks_are_complementary_halves 断言的「左半 10 / 右半 11 / 整片 21」当场被打成反例。"
        "查下去发现规律没消失，只是换了个数：靶环的扇区色从两种变成三种，漆就从对半切变成切三份，"
        "三块两两重叠 2 格、并集仍然正好 21。那条老概念缩了 scope（扇区色 >= 3 时返回 NA），"
        "空出来的那一片由本条接手，两条合起来才是完整的话。"
        "**这里刻意不写成「k 种扇区色对应 k 块漆、每块 21/k 格左右」**：格数不是判据，铺满才是；"
        "写成格数就等于把这一关量到的那几个数字硬编进概念里，换一关立刻失效而且看不出为什么。\n"
        "v2：v1 一入册就在上一关的 12 条转移上挨了 18 记反例，全是同一个靶环干的——"
        "它**只有一种扇区色**（12 格臂全同色），而那个色在盘上只有一块漆、墨色区块 10 格，并集 10/21。"
        "缩 scope 到「扇区色不止一种」。为什么这不是打不过就改判据：一种扇区色要装满，"
        "得有一块漆的 21 格**全是**墨色，而至今每一块漆都有 10~14 格是色0——"
        "所以单色靶环是构造上就填不满的，它必然是幌子，本条对它无话可说才是对的。"
        "**残留的风险照实记，引线也刻意不拆**：两种扇区色的幌子靶环、而且两种色都恰好在盘上有唯一漆块，"
        "至今一次没出现过；真出现而且并集凑不满，本条会再次判 FALSE。那时该改的是这条概念，"
        "不是把规划器里的算术前提悄悄放宽——规划器在下手之前照旧要自己核一遍并集等不等于 21。")
EVIDENCE = ["011cc2cb2680fa54", "71cecc10786fa7b6", "2d797f36994f0b23",
            "3052579c3753d0c4", "41369dcbd32a535f", "540822271c6e2ca9",
            "5cbd559243c0fbca", "60586d72ac08218e", "6f16429f269b5fd8",
            "a3795b7b9b732cf8", "a4b6c45f435eb790", "bbf759ed458fbd9d",
            "c724d1129e167360", "c8c5507b92c8d5da", "d3831a6431ef3c82",
            "d869bcac56d69ba8", "f3735c6385e1197c", "f4e64ab994bad2cc",
            "f6bd296b1788364d"]
# 这 19 条里只有第一条是我主动抽出来立论的；其余 18 条是 v1 挨的那 18 记反例，
# 一条不落地抄进来——装置会在它们上面重跑 assert_，v2 在这些帧上判 TRUE（单色靶环已跳过）。

from _lib import CIRCLE2, C_SEL, circle_cells, clusters, readable, reticles, silhouettes

FULL = frozenset(CIRCLE2) | {(0, 0)}          # 21 格圆盘的偏移全集


def _ink_by_color(g):
    """{墨色: [漆块的有色偏移集, ...]}。漆块 = 认得出轮廓、却不牵虚线的那些。"""
    cl = clusters(g)
    out = {}
    for m in silhouettes(g):
        if m in cl:
            continue
        by = {}
        for r, c in circle_cells(m):
            v = g[r][c]
            if v != C_SEL:
                by.setdefault(v, set()).add((r - m[0], c - m[1]))
        for k, v in by.items():
            out.setdefault(k, []).append(frozenset(v))
    return out


def _ok(g):
    if not readable(g):
        return None
    rs = reticles(g)
    if not rs:
        return None
    by_color = _ink_by_color(g)
    verdicts = []
    for _t, sec in rs.items():
        want = sorted(sec)
        if len(want) < 2:
            continue                          # 单色靶环：构造上就填不满，见 NOTE v2
        if not all(len(by_color.get(k, ())) == 1 for k in want):
            continue                          # 幌子、或漆已被取走：本条不发话
        u = set()
        for k in want:
            u |= by_color[k][0]
        verdicts.append(u == FULL)
    if not verdicts:
        return None
    return all(verdicts)


def assert_(prev, action, nxt, ctx=None):
    vs = [v for v in (_ok(prev), _ok(nxt)) if v is not None]
    if not vs:
        return "NA"
    return "TRUE" if all(vs) else "FALSE"
