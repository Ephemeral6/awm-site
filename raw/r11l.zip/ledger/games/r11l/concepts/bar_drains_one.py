"""不换关的动作，第 0 列的色0 竖条只会从**最上面**连续地少，一次少 1 格或 2 格（绝不一格不少，绝不从中间少，绝不长回来）。"""
LEVEL = "L4"
SCOPE = "换关那一步返回 NA（见 bar_refills_on_levelup）；prev 的竖条为空时返回 NA（耗尽后的扣法还没测过）"
NOTE = ("v4：6f512af63e12d76b（第 16 步）一步扣了两格，把 v3 的「恰好少一格」打翻。"
        "对齐时间戳排除了「按真实时间走」；数下来第 1 关 9 击共扣 10 格，多出来的那一格紧跟在**被驳回的那一击**"
        "（01bf5de21e68d4d6，第 15 步）之后——最像的解释是「驳回罚 1 格、且延到下一帧才落」。"
        "但一条概念只看得见一条转移，看不见上一击有没有被驳回，所以这里只主张看得见的部分："
        "扣 1 或 2 格、且一定从最上面扣。锐化要靠专门的实验（连着两次驳回，看是 1/2/2 还是 1/3/1）。")
EVIDENCE = ["08c4dadd57a9ac9a", "1d2dcfbed7cf1d56", "15080d68a357ebbf", "6f512af63e12d76b"]

from _lib import C_GROUND, bar_rows, completes_level, click_xy, levelup


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    a = bar_rows(prev)
    if not a:
        return "NA"
    b = bar_rows(nxt)
    k = len(a) - len(b)
    if k not in (1, 2):
        return "FALSE"
    top = sorted(a)[:k]
    return "TRUE" if b == a - set(top) else "FALSE"


def apply(prev, action, ctx=None):
    a = bar_rows(prev)
    if not a:
        return None
    p = click_xy(action)
    if p is not None and completes_level(prev, p) is True:
        return None                         # 换关那一步竖条是长回来的，不是掉一格（见 bar_refills_on_levelup）
    return {(min(a), 0): C_GROUND}          # 最上面那一格一定掉，第二格看情况，不多说
