"""换关 ⟺ 这一击之后，每一个还没锁定的组，圆块核都恰好落在本组靶心上；环上还带着色0 的空罐子算「没到位」，少一组都不换关。"""
LEVEL = "L5"
SCOPE = ("只看带坐标的 ACTION6；prev 里一个靶环都没有、选中菱形定位不到、布局算不出来（比如点在选中菱形自己身上）、"
         "这一击是不是被驳回判不出来（底色被盖住）、或这一帧菱形读不全（stray_ring 非空），返回 NA。"
         "靶环变色的组视为已锁定、不再参与判定（见 lock_turns_reticle_zero）。"
         "v4 新增一档 NA：若某个既没锁定、也配不上任何靶环的组，它的圆块环上**没有**色0（罐子是满的，"
         "却仍然配不上唯一一个靶环），那就说不清它算不算到位，整条返回 NA——宁可不说。")
NOTE = ("v2：第 13 步组12 压靶之后，它的靶环从帧里消失，v1 的「靶组集合 == 圆块组集合」前置条件从此永远不成立，"
        "这条概念在第 15、17 步一句话都没说——沉默不是通过。改成只对「还挂着靶环的组」发话。"
        "同时补上驳回那一档：被驳回的一击谁都没动，圆块核照旧。"
        "v3：驳回判据从「撞车」换成底色（见 move_rejected_on_blocked_terrain），判不出来就 NA。\n"
        "v4 挨了反例 d3831a6431ef3c82，而且是**先押后走**押出来的：那一步把一个装满的圆块锁上了它的靶环，"
        "盘上另一个圆块是 21 格全色0 的空罐子。v3 的分母是 `_lib.targets()`，它的策略是「配不上任何靶环的组"
        "就不出现在结果里——宁可不说」；空罐子配不上任何靶环，于是**从分母里消失**，"
        "「每一组都到位」在只到位一组的时候就成立了，v3 据此主张换关。世界没换关。\n"
        "读法的谦虚（少说）在目标判定里变成了断言的激进（提前说赢）。而且 `_lib.quiet()` 借的是同一个算式，"
        "所以那一步全册 apply 集体闭嘴、预测 0 格——**沉默看起来像谨慎，其实是册子在说「下一帧是新世界」**。"
        "这是走进去之前就看见的：predict 报 0 格，而不是事后翻帧翻出来的。\n"
        "v4 的改法不是把这一档缩成 NA（那会让它在本关大部分步上闭嘴），而是让它**敢说不换关**："
        "环上还带色0 的圆块是没装满的罐子，它一定不在任何靶心上（取色机制见 circle_absorbs_blob_ink）。"
        "结构上只在 v3 判「换关」的那一支后面加检查，v3 判「不换关」的那些步一个字没动——"
        "所以 v3 已经判对的 21 条不会回归。"
        "注意这条修在**概念**里而不是 `_lib` 里：改 _lib 不算改版、词汇里的世界主张从来没被评过分，"
        "拿一条没走闸的主张换另一条不叫修。")
EVIDENCE = ["15080d68a357ebbf", "659c9b89d4f9314e", "d3831a6431ef3c82"]

from _lib import (after_click, centroid, click_xy, leftover_mids, levelup,
                  mids, move_verdict, targets)


def _after(g, p):
    """这一击之后各组圆块核的落点；算不出来返回 None。"""
    a = after_click(g, p)
    if a is None:
        return None
    v = move_verdict(g, p)
    if v is True:
        return dict(mids(g))          # 踩禁地被驳回：一格没动
    if v is None and a[1] == p:
        return None                   # 落子那一档，但判不出成没成
    return {k: centroid(v2) for k, v2 in a[0].items()}


def assert_(prev, action, nxt, ctx=None):
    p = click_xy(action)
    if p is None:
        return "NA"
    t = targets(prev)
    after = _after(prev, p)
    if not t or after is None or any(k not in after for k in t):
        return "NA"
    ok = all(after[k] == t[k] for k in t)
    if ok:                                       # v3 到此就主张换关；v4 先问还有谁没到位
        unfilled, puzzling = leftover_mids(prev)
        if unfilled:
            ok = False                           # 空罐子必然不在靶心上
        elif puzzling:
            return "NA"                          # 满了却配不上：说不清
    return "TRUE" if ok == levelup(ctx) else "FALSE"
