"""虚线在新墨格上层还是底层，由**墨色是不是底色**决定：墨色属于底色三色时那一格显色1，否则显墨色。

挡得住虚线的不是「这一格属于某个物件」，而是「这一格显的颜色不是底色」。圆块吸进来的墨大多是
非底色（组色、扇区色），所以它们照旧压住虚线；但漆块的墨里有一种恰好就是底色里那种「圆块压不上去
的软地色」，取到它的那一格在渲染上和底色不可分，虚线就照样画过去。

这一条只管新墨那些格——它是**唯一**能拿到「这一格真色是什么」的档口：墨色由 prev 里的漆块图案算出来，
不必从被虚线盖住的像素里反推。圆块原有色的格归 circle_absorbs_blob_ink，别处的虚线归 road_is_lines。
"""
LEVEL = "L6"
BLOCKING = False
SCOPE = ("只在取色那一步发话（pickup 返回 None、或这一笔一格颜色都不改，返回 NA）。"
         "换关那一步返回 NA；prev 或 nxt 读不全返回 NA。"
         "只断言新墨那些格的颜色，不断言圆块原有色的格（那归 circle_absorbs_blob_ink）、"
         "也不断言别处的虚线画在哪（那归 road_is_lines）。"
         "**不断言「圆块原有的底色格」挡不挡虚线**：那种格的真色我从像素里读不到（被色1 盖住的话），"
         "现有语料里也没有一步能判开，见 NOTE v2 的分岔。"
         "**没有取色的关卡里它一句话不说，所以 N 会很小，这是应该的。**")
NOTE = ("v1 的主张是「新墨一律在虚线底下」，被 9 条取色步打成反例、S=0.000、说错 48 格。"
        "病因是我拿一次观测的**措辞**当成了规律：立案时手上只有一步（be4b08e54f234f0e），"
        "那一步虚线经过圆盘 5 格、4 格是原有色（挡住）1 格是新墨（没挡住），"
        "我就把分岔挑在「新／旧」上，因为那是那一帧里唯一显眼的差别。\n"
        "v2 是全量核过的：语料里 10 条取色步，线上新墨格 24 个。"
        "9 条步的墨色是色6/8/9/11/14/15，线上那 22 格**全显墨色**；"
        "只有 1 条步的墨色是底色里的软地色，它线上那 1 格显色1。"
        "按颜色分，10 条 10 条一致，没有例外。\n"
        "**顺手否掉的另一个候选**：本来还怀疑判据是「这一笔把罐子装满了」——那一步取完确实 0 格色0 剩。"
        "但另有 3 条取色步也是取完 0 格色0 剩，虚线照样被墨挡住。装满与否分不开这 10 条，颜色能。"
        "两个候选都是从同一帧看出来的，先核了才没有把第二版又写错。\n"
        "**正面那一支只有 1 格证据**，说清楚：24 个线上新墨格里只有它是底色墨，n=1。"
        "反面那一支 22 格，扎实。所以这条概念的强度是不对称的，别拿它的 S 当两支都验过。\n"
        "**没测过的推广**：如果判据真的是颜色而不是「新不新」，那么圆块**原有**的底色格"
        "（上一步吸进来、这一步没再动的那种）也该让虚线画过去。现有语料判不开——"
        "取色之后我把圆块搬到的位置，虚线只经过原有的非底色偏移，一个底色墨格都不经过"
        "（搬之前用线段算过，是故意选的对照位）。判开它的实验：把带底色墨的圆块搬到一个"
        "「虚线线段正好经过那个墨格偏移」的位置，那一步不取色。显示色1 = 颜色说成立到底，"
        "显示墨色 = 只有取色那一瞬间才透。这一档留着不猜，也不许 road_is_lines 替它猜。")
EVIDENCE = ["be4b08e54f234f0e", "f6bd296b1788364d", "2d797f36994f0b23",
            "a3795b7b9b732cf8", "5cbd559243c0fbca", "21a120b4a9a6ae91",
            "28bb177f16d0f941", "7139cbac3ab26f3f", "3f4e17e248e225e4",
            "bef889735f7a80cc"]

from _lib import (C_ROAD, TERRAIN, after_click, click_xy, fresh_ink, groups_of,
                  levelup, move_open, quiet, readable, roads_of)


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    if not (readable(prev) and readable(nxt)):
        return "NA"
    ink = fresh_ink(prev, action)
    if not ink:
        return "NA"
    n, m = len(nxt), len(nxt[0])
    lines = {q for q in roads_of(groups_of(nxt)) if 0 <= q[0] < n and 0 <= q[1] < m}
    for q, color in ink.items():
        if not (0 <= q[0] < n and 0 <= q[1] < m):
            return "NA"
        # 线上且墨色是底色 -> 虚线画在上层；线上而墨色不是底色 -> 墨压住虚线；不在线上 -> 墨色
        want = C_ROAD if (q in lines and color in TERRAIN) else color
        if nxt[q[0]][q[1]] != want:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只认领一种格：新墨里落在虚线上、而且墨色是底色的那些——它们显示色1。"""
    if quiet(prev, action):
        return None
    ink = fresh_ink(prev, action)
    if not ink:
        return None
    p = click_xy(action)
    if p is None:
        return None
    a = after_click(prev, p)
    if a is None or not move_open(prev, p):
        return None
    n, m = len(prev), len(prev[0])
    lines = {q for q in roads_of(a[0]) if 0 <= q[0] < n and 0 <= q[1] < m}
    out = {q: C_ROAD for q, v in ink.items() if q in lines and v in TERRAIN}
    return out or None
