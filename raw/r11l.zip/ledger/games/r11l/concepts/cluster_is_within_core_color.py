"""一个簇里的菱形，核色全都一样——簇是「按核色分组」的细分，不会跨色。

第 0~3 关簇和核色一一对应（一个核色一个圆块）；第 4 关同一个核色的 5 个菱形分成了两簇、
各牵各的圆块，所以「组 = 核色」不再成立。但反过来那一半还站着：簇不会把两种核色混进来。
这一条把它明说出来——簇的成员关系是虚线认的（见 _lib.clusters），核色是另一路证据，
两路要是对不上，说明我把虚线读错了，或者世界比这更松。
"""
LEVEL = "L7"
SCOPE = ("prev / nxt 里读不出来（readable 为假）的那一帧跳过；两帧都跳过就返回 NA。"
         "盘上一个簇都没有也返回 NA。只看盘面，不看动作。")
NOTE = ("v1。立它是因为第 4 关推翻了「组 = 核色」，而推翻之后**剩下什么**必须重新说清楚："
        "否则「簇」这个词就成了一个只由虚线定义、和菱形的颜色毫无关系的东西，"
        "那第 0~3 关那些按核色分组也能跑通的转移就变成了巧合。这条概念是那个巧合的对立面。")
EVIDENCE = ["71cecc10786fa7b6"]

from _lib import clusters, diamonds, readable


def _ok(g):
    if not readable(g):
        return None
    cl = clusters(g)
    if not cl:
        return None
    core = {d[0]: d[2] for d in diamonds(g)}
    return all(len({core[a] for a in v if a in core}) == 1 for v in cl.values())


def assert_(prev, action, nxt, ctx=None):
    vs = [v for v in (_ok(prev), _ok(nxt)) if v is not None]
    if not vs:
        return "NA"
    return "TRUE" if all(vs) else "FALSE"
