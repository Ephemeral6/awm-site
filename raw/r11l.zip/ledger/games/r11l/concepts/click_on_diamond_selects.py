"""点击格落在某个环色3的菱形上时，所有菱形一格不动，只是选中权转过去：被点的那个环变色0，原来的色0菱形环变色3。"""
LEVEL = "L1"
SCOPE = "只在带坐标的 ACTION6 且点击格落在某个环色3菱形的 13 格内时开口；换关那一步、选中菱形定位不到返回 NA"
NOTE = "取代 swap_on_other_core：第 1 关有 5 个菱形，「另一个」要说成「被点的那一个」。"
EVIDENCE = ["24a7cc2c3327a98e", "a57029d2ec8f97c4"]

from _lib import (C_SEL, C_UNSEL, DIAMOND2, click_xy, diamonds, hit_diamond,
                  levelup, sel)


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    p = click_xy(action)
    if p is None:
        return "NA"
    d = hit_diamond(prev, p)
    s0 = sel(prev)
    if d is None or d[1] != C_UNSEL or s0 is None:
        return "NA"
    if sorted(x[0] for x in diamonds(nxt)) != sorted(x[0] for x in diamonds(prev)):
        return "FALSE"
    return "TRUE" if sel(nxt) == d[0] else "FALSE"


def apply(prev, action, ctx=None):
    p = click_xy(action)
    s0 = sel(prev)
    if p is None or s0 is None:
        return None
    d = hit_diamond(prev, p)
    if d is None or d[1] != C_UNSEL:
        return None
    out = {}
    for center, ring in ((d[0], C_SEL), (s0, C_UNSEL)):
        for dr, dc in DIAMOND2:
            rr, cc = center[0] + dr, center[1] + dc
            if 0 <= rr < len(prev) and 0 <= cc < len(prev[0]):
                out[(rr, cc)] = ring
    return out
