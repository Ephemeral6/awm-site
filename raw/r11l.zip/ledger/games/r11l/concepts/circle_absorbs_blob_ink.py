"""圆块是空罐子：中心搬到一个不牵虚线的 21 格漆块上，漆块的有色格就按相同偏移**盖到**圆块那 21 格上。

圆块那 21 格里，色0 = 空。盘上另有几个 21 格轮廓，谁也不牵虚线、位置固定，每个是
「一片单色 + 其余色0」。把某一簇的圆块中心正好搬到这样一个轮廓的中心上，下一帧那 21 格
= 漆块有色的偏移取漆块的色，漆块是色0 的偏移保留圆块原来的色。
所以这是**覆盖**，不是填空：罐子里已经有的颜色，被后来这一笔压过去的地方会消失。

怎么发现的：先按「轮廓是压在圆块上层的固定景物」押了一步，落点那 21 格一格没变，两种解释
（上层遮住 / 图案被搬到圆块身上）在那一帧完全同像素、分不开。下一步把圆块搬走才分开：
图案跟着圆块走了，原地退回底色。同像素的两种解释，要靠再走一步才判得开。
"""
LEVEL = "L6"
SCOPE = ("只看带坐标的 ACTION6。换关那一步（levelup）返回 NA；prev 或 nxt 读不全"
         "（readable 为假）返回 NA；这一击不是搬圆块（点在菱形上、被驳回、after_click 算不出来）返回 NA。"
         "**落点的圆块中心不在任何「prev 里不牵虚线的 21 格轮廓」中心上，返回 NA**——"
         "没发生取色，本条没话说。取色那一步之外它一律沉默，所以 N 会很小，这是应该的。"
         "只断言那 21 格的颜色，不断言轮廓原地变成什么（那归 vacated_reverts_to_ground）、"
         "也不断言取色会不会记账或过关（那归 levelup_iff_mids_on_targets）。"
         "**新墨里落在虚线线段上、而且墨色恰好是底色的那些格不由本条断言**"
         "（v3 让出去、v4 缩准的，归 road_covers_fresh_ink）。")
NOTE = ("v1。证据两条，缺一条这件事就判不出来："
        "f6bd296b1788364d 是取色发生的那一步（圆块从整片色0 变成 0|8）；"
        "3052579c3753d0c4 是把它搬走、看见图案跟着走的那一步——"
        "**第二条不在本条的 scope 里**（那一步没取色，本条判 NA），"
        "它进 EVIDENCE 是因为「填空而不是遮挡」这个措辞是从它那里才定下来的。"
        "本条的 apply 和 circle_ring_translates 的 apply 在取色那一步管的是同一批格："
        "那条已经缩掉了「落点是不牵虚线的轮廓」这一档（返回 None），所以不打架，接力关系是明说的。\n"
        "v2 改主张，不是缩 scope：v1 说的是**填空**（只有色0 的格会被写，本来有色的一格不改），"
        "被 7139cbac3ab26f3f 打成反例——4 格对不上，全是罐子里已有的色被新墨盖掉的那 4 格："
        "偏移 (-2,0) 与 (-1,0) 原色14、(0,-2) 与 (0,-1) 原色9，全变成了新墨的色15。"
        "为什么以前看不出来：在此之前每次取色，漆块的有色偏移和罐子里已有的色**从不相交**，"
        "「填空」和「覆盖」在那些帧上逐格同像素，分不开。等到一只罐子要取三次色、"
        "三块漆两两重叠 2 格，两种讲法才第一次给出不同的答案，而世界站在覆盖这一边。"
        "**这不影响赢法但影响顺序**：颜色集合和「取完没有色0 剩下」都不受顺序影响"
        "（并集铺满 21 格，见 reticle_colors_have_tiling_inks），可每种色最后剩几格是随顺序变的，"
        "所以任何靠格数吃饭的判断都不许用——配对只许按颜色集合（target_pairs_by_sector_colors）。\n"
        "v3 缩 scope，让位给一条新概念：be4b08e54f234f0e 上判 FALSE，1 格——"
        "新墨里落在虚线线段上的那一格显示色1，不显示墨色。那一片不再由本条断言，"
        "改由 road_covers_fresh_ink 正面主张「新墨在虚线底下」。"
        "**这不是打不过就改判据**：让出去的那一格没有变成谁都不管的地方，"
        "它被另一条概念接手，而那条概念说错了照样挨反例；判据是「让出去的格必须有主」。"
        "为什么以前不出这事：虚线经过圆盘的格通常都是圆块原有的色，圆块压住虚线；"
        "要等到某一格既是新墨、又正好在线段上，两者才第一次分开。"
        "同时把「哪一击在取色」和「新墨改了哪些格」两段读法搬进 _lib（pickup / fresh_ink），"
        "两条概念共用一份——检查器和生成器各算一份就等着分岔，这颗钉子踩过三次了。\n"
        "v4 把 v3 让出去的那一片**缩回来**：v3 让的是「新墨里所有落在虚线上的格」，"
        "而全量核过之后，10 条取色步里线上新墨 24 格，只有墨色恰好是底色的 1 格真的显色1，"
        "另外 22 格显的是墨色——那 22 格本条说得对，却因为让得太宽而闭了嘴。"
        "改成只让 `_lib.soft_ink`（墨色属于底色的那部分）。"
        "**这也是让位的成本第一次算清**：让出去的地方不但要有主，还得只有该让的那么大；"
        "让宽了不会有任何东西报错，它只是让 E 白掉一截，而 E 掉了看起来跟「这一步没什么可说」一样。")
EVIDENCE = ["f6bd296b1788364d", "3052579c3753d0c4", "7139cbac3ab26f3f",
            "be4b08e54f234f0e"]

from _lib import (C_SEL, after_click, click_xy, disc_pattern, groups_of,
                  levelup, move_open, pickup, quiet, readable, roads_of,
                  soft_ink)


def _filled(prev, old, blob):
    """取色之后那 21 格该是什么：漆块有色的偏移取漆块的色，漆块是色0 的偏移保留罐子原色。"""
    was, ink = disc_pattern(prev, old), disc_pattern(prev, blob)
    out = {}
    for off, v in was.items():
        got = ink.get(off, C_SEL)
        out[off] = got if got != C_SEL else v
    return out


def _yielded(prev, action, gs):
    """让给 road_covers_fresh_ink 的那些格：新墨里落在虚线线段上、且墨色是底色的（v4 缩准）。"""
    ink = soft_ink(prev, action)
    if not ink:
        return set()
    return {q for q in ink if q in set(roads_of(gs))}


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    if not (readable(prev) and readable(nxt)):
        return "NA"
    got = pickup(prev, action)
    if got is None:
        return "NA"
    old, blob = got
    tgt = blob
    skip = _yielded(prev, action, groups_of(nxt))
    want = _filled(prev, old, blob)
    for off, v in want.items():
        r, c = tgt[0] + off[0], tgt[1] + off[1]
        if not (0 <= r < len(nxt) and 0 <= c < len(nxt[0])):
            return "NA"
        if (r, c) in skip:
            continue
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if quiet(prev, action):
        return None
    got = pickup(prev, action)
    if got is None:
        return None
    old, blob = got
    tgt = blob
    p = click_xy(action)
    a = after_click(prev, p) if p is not None else None
    skip = _yielded(prev, action, a[0]) if (a is not None and move_open(prev, p)) else set()
    out = {}
    for off, v in _filled(prev, old, blob).items():
        r, c = tgt[0] + off[0], tgt[1] + off[1]
        if 0 <= r < len(prev) and 0 <= c < len(prev[0]) and (r, c) not in skip:
            out[(r, c)] = v
    return out or None
