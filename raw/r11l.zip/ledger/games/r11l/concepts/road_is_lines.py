"""色1 虚线恰好是「每组圆块核到本组每个锚点的整数直线」之并，减掉挡得住它的格——**而挡不挡得住由颜色定，不由谁占着这一格定：颜色属于底色三色的物件格挡不住**。"""
LEVEL = "L6"
SCOPE = ("断言是同一帧内的结构不变量，看 nxt；帧里一个圆块都没有、或这一帧菱形读不全（stray_ring 非空）返回 NA。"
         "apply 只在「空地落子且没看见禁色」那一档发话：换关那一步、点在菱形上（布局不变）、踩禁地被驳回，都不预测。"
         "**盲点写在明处**：遮挡名单靠颜色算，而被虚线盖住的格已经显色1、底下的真色本帧读不出来，"
         "只能反推成「底色系」。所以「线上的物件格显色1」这一类本条判不错它（永远算一致）；"
         "能判错的是另外三类——线上的物件格显底色系却没变成色1、线上的格显色0 或非底色的墨却变成了色1、"
         "以及不在线上的格显色1。")
NOTE = ("先按肉眼看到的两段横线猜「M 到锚点的直线」，用 line() 逐格核："
        "34 帧（17 条转移的 prev+next）里色1 格与算出来的集合一格不差。"
        "被挡住的那些线段格，颜色全属于动件（3/6/0/组色），没有第三种解释。"
        "v2：驳回判据换成底色（见 move_rejected_on_blocked_terrain）；加读不全就 NA——"
        "有菱形被圆块压住时 groups_of 少算一个锚点，算出来的路网必然缺一条。"
        "v3 只改 apply：挡住虚线的靶环从「配得上圆块的那几个」改成**盘上每一个**。"
        "assert_ 那边一直用 objects()，本来就数全部靶环；apply 这边却只挡 targets()，"
        "两边对不上。第 3 关盘上 5 个幌子靶环不在 targets() 里，于是模拟帧里虚线糊了它们一脸，"
        "reticles() 再也认不出来。实测的依据是：第 0~2 关虚线算下来该经过靶环格 86 次，"
        "真帧显示色1 **0 次**——靶环盖虚线，从来不是反过来。\n"
        "v4 又是同一颗钉子的第三种长相，这次是**摆设**：assert_ 用 objects()，它数的是 silhouettes() "
        "——盘上每一个 21 格轮廓，包不包着簇都算；apply 这边只挡「有簇的那些圆块」，"
        "于是那几个不牵虚线的 21 格摆设在模拟帧里被虚线糊了一脸。"
        "这是拿册子当规划器跑空转时发现的：那一步 apply 与 decoy_silhouettes_are_fixed 在 4 格上正面冲突"
        "（它说色0、这条说色1），冲突格全在一个摆设身上。"
        "改法：把 prev 里**不属于任何簇**的轮廓一律加进遮挡；属于簇的那些照旧按挪动后的位置算，"
        "因为圆块原来占的格挪走后虚线是可以经过的。被取走的那一件不必特殊对待——"
        "取色时圆块核正落在它的核上，两者 21 格重合，按新位置挡一次就够。\n"
        "v7 第一次改的是**主张本身**，不是遮挡名单的口径：be4b08e54f234f0e 上判 FALSE，"
        "算出来 50 格、实际 51 格，多的那一格在一个圆块的 21 格里面。"
        "「圆块挡住虚线」这句话原来是无条件的，现在要加一个例外："
        "这一步刚被漆块改掉颜色的那些格挡不住虚线。那一步虚线经过圆盘 5 格，"
        "4 格是圆块原有的色（全都挡住了），1 格是新墨（没挡住），5/5 与例外一致。"
        "例外那一支的正面主张归 road_covers_fresh_ink，本条只负责把它从遮挡名单里减掉；"
        "两条概念用同一个 _lib.fresh_ink 算这批格，不各算一份。"
        "为什么以前没发作：虚线总是从圆块核往外射，经过圆盘的格几乎都是圆块原有的色。\n"
        "v8 把 v7 的例外**缩到真正的判据上**：v7 写的是「新墨一律挡不住」，被 9 条取色步打成反例"
        "（算出来的虚线比实际多，多的那些格全是线上的新墨）。全量核过之后判据是颜色不是新旧——"
        "线上新墨 24 格里，墨色是非底色的 22 格全把虚线挡住了，只有墨色恰好是底色的那 1 格没挡住。"
        "所以减掉的从 `fresh_ink` 换成 `_lib.soft_ink`（墨色属于 TERRAIN 的那一部分）。"
        "**这一版更该记的是教训**：v7 的例外是从一帧的措辞推出来的，一次都没在别的同类步上核过，"
        "而它照样能在那一帧上「5/5 一致」。同类步只有 10 条、跑一遍不到一秒——"
        "立案时省下的这一秒，代价是两条概念各挨 9 条反例、关闸一轮。\n"
        "v9 拆掉 v8 例外里的一个限定词：v8 写的是「**圆块刚吸进来的**墨色恰好是底色的格挡不住虚线」，"
        "「刚吸进来的」从来没有证据——它只是当初第一次看见这件事的地方。"
        "229ea7bae98df73e 上世界在**漆块**身上给出了同一件事：虚线经过一个还没被取走的漆块，"
        "那块漆的墨色是色10（底色之一），虚线照样画了上去，本条算出来的虚线少了 2 格。"
        "这一次没有只看这一帧就改：把同一把尺子架到全部四种物件上数了一遍——"
        "虚线落在物件格上共 8750 格次（菱形 4224、圆块 3871、漆块 239、靶环 416，竖条 0），"
        "「显底色系却挡住了虚线」**0 格次**。所以判据是颜色，与谁占着这一格无关，"
        "减掉的从 soft_ink（要 prev+动作才算得出，只覆盖罐子里的墨）换成 _lib.soft_cells（只看一帧的颜色）。\n"
        "**但正面那一侧很薄，得说清**：物件格显底色系的共 4168 格次（色5 2800、色10 1368），"
        "其中被虚线路过的只有 4 格次、3 个不同的格，**全是色10**；色5 一次都没轮到虚线经过。"
        "「底色三色」是顺着 road_covers_fresh_ink 的口径押的，不是量出来的——"
        "哪天色5 的物件格上了线又把虚线挡住，这里就该收回来。写成「只对色10」同样没有证据"
        "（没人证明色5 会挡），那种限定词正是 v8 挨打的原因，所以不写。\n"
        "还有一个同像素的解释没排除：也许虚线画在地形之上、物件之下，而底色系的那几格根本不属于物件，"
        "是地面透出来的。两种讲法在现有语料上给同样的像素，判开它们要另找局面。")
EVIDENCE = ["e8f92374d6507ea9", "be4b08e54f234f0e", "f6bd296b1788364d",
            "2d797f36994f0b23", "a3795b7b9b732cf8", "5cbd559243c0fbca",
            "21a120b4a9a6ae91", "28bb177f16d0f941", "7139cbac3ab26f3f",
            "3f4e17e248e225e4", "bef889735f7a80cc", "229ea7bae98df73e"]

from _lib import (C_ROAD, TERRAIN, after_click, circle_cells, click_xy, centroid,
                  diamond_cells, disc_pattern, groups_of, levelup, locked_targets,
                  mids, move_open, objects, quiet, readable, reticle_cells,
                  reticles, roads_of, silhouettes, soft_cells, soft_ink)


def assert_(prev, action, nxt, ctx=None):
    if not mids(nxt) or not readable(nxt):
        return "NA"
    n, m = len(nxt), len(nxt[0])
    # 挡不挡得住由颜色定：底色系的物件格（含已被虚线盖住、显色1 的那些）不进遮挡名单
    blocked = objects(nxt) - soft_cells(nxt)
    want = {p for p in roads_of(groups_of(nxt)) if 0 <= p[0] < n and 0 <= p[1] < m} - blocked
    got = {(r, c) for r in range(n) for c in range(m) if nxt[r][c] == C_ROAD}
    return "TRUE" if want == got else "FALSE"


def apply(prev, action, ctx=None):
    if levelup(ctx) or quiet(prev, action):
        return None
    # levelup(ctx) 是事后才知道的（换关标志来自上游 meta）；押注时只有 quiet 这一档管用，两个都留着。
    p = click_xy(action)
    if p is None:
        return None
    a = after_click(prev, p)
    if a is None or not move_open(prev, p):
        return None
    gs = a[0]
    if gs == groups_of(prev):
        return None                       # 布局没变，路网也不变，不多说
    n, m = len(prev), len(prev[0])
    blocked = {(r, 0) for r in range(n)}
    own = set(mids(prev).values())
    for s in silhouettes(prev):
        if s not in own:
            blocked |= circle_cells(s)    # 摆设/漆块：不牵虚线，但照样盖着格子，而且它们不动
    for _k, v in gs.items():
        for c in v:
            blocked |= diamond_cells(c)
        blocked |= circle_cells(centroid(v))
    # reticles() 按中心存，locked_targets() 按**组色**存——直接 for t in 两个 dict 会把组色
    # 当成坐标喂给 reticle_cells()，抛 TypeError。objects() 里踩过同一颗钉子。
    for t in list(reticles(prev)) + list(locked_targets(prev).values()):
        blocked |= reticle_cells(t)
    blocked -= soft_cells(prev)           # 不动的物件（漆块/摆设/靶环/竖条）：格和色都不变，直接按 prev 减
    for k, v in gs.items():               # 挪动的圆块：那 21 格跟着走，底色系的偏移也跟着走
        oc = mids(prev).get(k)
        if oc is None:
            continue
        nc = centroid(v)
        for off, col in disc_pattern(prev, oc).items():
            if col in TERRAIN or col == C_ROAD:
                blocked.discard((nc[0] + off[0], nc[1] + off[1]))
    blocked -= set(soft_ink(prev, action))    # 这一击新吸进来的墨：prev 里还在漆块身上，上面两句都够不着
    want = {q for q in roads_of(gs) if 0 <= q[0] < n and 0 <= q[1] < m} - blocked
    return {q: C_ROAD for q in want}
