"""每个圆块的中心，都落在它那一簇菱形中心的下取整质心上。

「它那一簇」是虚线认出来的（_lib.clusters），不是按质心认的——不然这句话就是同义反复。
"""
LEVEL = "L6"
SCOPE = ("同一帧内的结构不变量，看 nxt；帧里没有圆块、某个圆块所属的簇一个菱形都没有、"
         "或这一帧读不全（readable 为假），返回 NA")
NOTE = ("取代 m_is_midpoint：两个锚点时质心=中点，第 1 关出现三锚点的组，中点讲法当场不成立。"
        "v2 只改 apply：被驳回的那一击（01bf5de21e68d4d6）圆块并没有挪，apply 不再对那一档发话；"
        "断言本身是同帧不变量，没动过。"
        "v3：驳回判据从「撞车」换成底色（见 move_rejected_on_blocked_terrain），并加读不全就 NA——"
        "82d916ac0a069e4e 起有一个菱形被圆块压住，anchors 少算一个，质心算出来必然是错的。"
        "v4 只改 apply：不再顺手把整圈 20 格涂成组色，只涂色6 的核。"
        "环的配色是另一条主张（circle_ring_translates），本条只断言核落在质心上——"
        "原来那句涂法在扇区环上会把颜色抹平，而它借的是本条的名义，本条的断言根本没管过环。\n"
        "v8：第 4 关推翻了「一个核色一个圆块」（同一核色的 5 个菱形分成两簇、各有各的圆块），"
        "而且那一关的圆块**没有色6 的核**，整片色0。所以主张里两处措辞都得改："
        "「色6核」→「圆块的中心」，「核色与它环色相同的那一组」→「它那一簇」。"
        "断言的内容没变（中心 == 锚点质心），变的是「锚点是谁」由谁说了算——现在是虚线。"
        "apply 也跟着改：中心那一格涂 prev 里圆块中心原本的颜色，不再硬涂色6。"
        "v9 只改 apply：f6bd296b1788364d 上它说错 1 格却判 TRUE——断言（中心落在质心上）在那一步确实成立，"
        "错的是涂法：圆块搬到了一个不牵虚线的 21 格轮廓上、钻到底下去了，那一格显的是轮廓的色8。"
        "落点是这种轮廓就不涂。**装置报的「说错却判 TRUE」是这里唯一的报警**——"
        "断言看得见的东西和 apply 画得出的东西不是同一批，光看 S 永远看不出来。")
EVIDENCE = ["15080d68a357ebbf", "f6bd296b1788364d"]

from _lib import (after_click, centroid, click_xy, cluster_of, clusters,
                  hit_diamond, mids, move_open, quiet, readable, sel,
                  silhouettes)


def assert_(prev, action, nxt, ctx=None):
    if not readable(nxt):
        return "NA"
    ms = mids(nxt)
    if not ms:
        return "NA"
    for group, m in ms.items():
        a = list(group)
        if not a:
            return "NA"
        if centroid(a) != m:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if quiet(prev, action):
        return None                       # 换关那一步整盘重画，新盘的圆块不在这一帧的算式里
    p = click_xy(action)
    s = sel(prev)
    if p is None or s is None or not readable(prev) or hit_diamond(prev, p) is not None:
        return None                       # 点在菱形上：只换选中，谁都没动，M 也不动
    if after_click(prev, p) is None or not move_open(prev, p):
        return None                       # 踩禁地会被驳回，圆块不动
    group = cluster_of(prev, s)           # 选中菱形属于哪一簇（簇靠虚线认，不靠核色）
    if group is None:
        return None
    old = mids(prev).get(group)
    if old is None:
        return None
    a = [q for q in group if q != s] + [p]
    tgt = centroid(a)
    cl = clusters(prev)
    if tgt in {m for m in silhouettes(prev) if m not in cl}:
        return None                       # 落点是个上层轮廓：圆块钻到它底下，那一格显的不是圆块
    return {tgt: prev[old[0]][old[1]]}    # 只涂中心那一格；环归 circle_ring_translates
