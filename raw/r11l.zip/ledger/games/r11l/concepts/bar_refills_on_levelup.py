"""**进入新一关**那一步之后，第 0 列的色0 竖条补满整列 64 格——通关那一步不算，那时竖条照常只掉一格。"""
LEVEL = "L4"
SCOPE = ("只在换关那一步开口（ctx 里 level_prev != level_next）；ctx 拿不到返回 NA。"
         "**通关那一步返回 NA**（v3）：上游打完第 n 关也会把 level 加到 n，于是 levelup 为真，"
         "可那一步并没有进入新的一关——盘面还是刚才那一盘。那一步的竖条归 bar_drains_one。"
         "只管第 0 列；换关那一帧别的地方整盘重画，本条一个字都不说。")
NOTE = ("v2 只加 apply，断言没动。换关那一帧是整盘重画（新关的地形、菱形、靶环全是新生成的），"
        "那几步的帧差是全册残差最大的地方，而且**原则上预测不了**——新布局不在旧帧里。"
        "但整盘重画里有一样东西是定的：竖条补满。所以这一格地皮该由它认领，"
        "而不是留在残差里冒充「还没想明白的机制」。"
        "认领的格数不多（只有原先漏掉的那几格算进帧差），记在这里免得后来的人以为这条 apply 没用："
        "它的意义是把「预测不了的」和「还没去预测的」分开。\n"
        "v3 分开了两件一直被我当成一件的事：通关那一步（002d9458b02bad4f）判 FALSE，"
        "竖条不但没补满，还照常掉了一格（39 -> 38）。查上游的 meta 才看清，"
        "打完最后一关时 level 也会加一（5 -> 6，同时 state 变 WIN），"
        "于是我这条概念的开口判据 `levelup` 把「进入新一关」和「整局结束」混在了一起。"
        "**这不是缩 scope 迎合结果，是一个我以前没有过样本的区分**："
        "在此之前每一次 level 加一都真的是进了新一关，两种情形逐格同像素，分不开。"
        "让出去的那一格有主：竖条掉一格归 bar_drains_one，它在这一步照常说对。"
        "判据放在 `_lib.finished`（看上游的 state_next），不看像素——"
        "「整局有没有结束」是上游公示的事实，不该由我从盘面猜。")
EVIDENCE = ["15080d68a357ebbf", "002d9458b02bad4f"]

from _lib import C_SEL, N, bar_rows, finished, levelup


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    if not levelup(ctx) or finished(ctx):
        return "NA"
    return "TRUE" if bar_rows(nxt) == set(range(N)) else "FALSE"


def apply(prev, action, ctx=None):
    if not ctx or not levelup(ctx) or finished(ctx):
        return None
    return {(r, 0): C_SEL for r in range(N)}
