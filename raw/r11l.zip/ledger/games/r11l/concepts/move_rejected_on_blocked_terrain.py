"""落子成不成，只看底色：菱形的 13 格碰上底色2、或算出来的圆块 21 格碰上底色2 或色10 ⟺ 这一击被驳回（除第 0 列竖条外整帧一格不改）。

底色2 和色10 是两种不同的禁地：色10 在菱形底下无所谓，在圆块底下不行；色2 两层都不行。
反过来也成立——没踩禁地的落子一定被收下，帧不会只掉一格竖条。
"""
LEVEL = "L2"
SCOPE = ("只看点在空地上的落子（ACTION6:x,y 且不命中任何菱形、算出来确实是「选中的那个挪到 p」）。"
         "换关、**这一击自己的**判据读不全，一律 NA——看不见就不说。"
         "v3 起「读不全」是局部的：选中菱形要在直接扫描下唯一，落点那 13 格不许碰 stray_ring 残片"
         "（碰上说明那里可能藏着一个认不出来的被遮菱形，这一击是挪动还是换选中说不清）；"
         "盘上别处有遮挡不再封口。")
NOTE = ("v1 只主张单向（踩禁地⇒驳回），结果对 27 条 held-out 全是 NA：驳回本来就少，"
        "而我接下来的策略正是要避开驳回——一条只在自己犯错时才开口的概念等于不开口。"
        "v2 改成双向：每一次落子都要说成或不成，说反了就是反例。"
        "由来：取代撤册的 move_rejected_if_mid_collides（「圆块压上别的动件就驳回」），"
        "它被 400b24d73506a804 打翻——世界收了一次明明压在菱形上的落子。"
        "把每一关的静态底色重建出来之后，成与驳按底色分得干净：11 次读得全的落子，4 驳 7 成，无一例外。"
        "v3 只改「什么时候敢开口」，主张一个字没动。原来走 _lib.move_verdict，它内部经 sel() 查**全图**"
        "可读性；于是盘上任何一处遮挡都把无关的落子一起封口——包括「圆块踩色10 ⇒ 驳回」这一支唯一的"
        "独立证据。那一支此前全部依据都来自 EVIDENCE，等于只有自我确认。"
        "换成局部判据后它在这批语料上多判出 1 条、判 TRUE，且没有任何回归或矛盾（草稿在 proposals/ 里"
        "跑过全量对照）。那条 tid **故意不写进 EVIDENCE**：它不是本条的依据，写进去只会把它从 universe 里"
        "踢掉，held-out 就白得了。教训另记：全局可读性当开口门槛，会让概念在无关遮挡下集体沉默，"
        "而沉默不掉分。")
EVIDENCE = ["01bf5de21e68d4d6", "8e2969cf2a0a9364", "1851f054beb5efa0", "698a77472f6ca77b",
            "795900e09ff3befb"]

from _lib import (BLOCK_DIAMOND, BLOCK_MID, C_SEL, C_UNSEL, _blocked, centroid,
                   circle_cells, click_xy, cluster_of, diamond_cells, diamonds,
                   groups_of, hit_diamond, levelup, stray_ring)


def _sel_local(g):
    """选中菱形中心：只要求「环色0 的菱形」在直接扫描下唯一，不查全图可读性。"""
    cs = [d[0] for d in diamonds(g) if d[1] == C_SEL]
    return cs[0] if len(cs) == 1 else None


def _after_click_local(g, p):
    """这一击之后的菱形布局，读法与 _lib.after_click 一致，只把 sel 换成局部版。"""
    s = _sel_local(g)
    if s is None or p is None:
        return None
    d = hit_diamond(g, p)
    gs = groups_of(g)
    if d is None:
        grp = cluster_of(g, s)
        if grp is None:
            return None
        gs[grp] = sorted([q for q in grp if q != s] + [p])
        return gs, p
    if d[1] == C_UNSEL:
        return gs, d[0]
    return None


def _verdict(prev, action, ctx):
    """这一击若属于「空地落子」那一档，返回底色给出的判决 True/False；不属于或判不出来返回 None。"""
    if levelup(ctx):
        return None
    p = click_xy(action)
    if p is None or hit_diamond(prev, p) is not None:
        return None
    if diamond_cells(p) & set(stray_ring(prev)):
        return None            # 落点碰上残片：这里可能藏着认不出的被遮菱形，挪动还是换选中说不清
    a = _after_click_local(prev, p)
    if a is None or a[1] != p:
        return None
    grp = cluster_of(prev, _sel_local(prev))
    if grp is None or grp not in a[0]:
        return None
    db, du = _blocked(prev, diamond_cells(p), BLOCK_DIAMOND)
    mb, mu = _blocked(prev, circle_cells(centroid(a[0][grp])), BLOCK_MID)
    if db or mb:
        return True
    return None if (du or mu) else False


def _frozen(prev, nxt):
    """除第 0 列外整帧一格没动。"""
    return all(prev[r][c] == nxt[r][c]
               for r in range(len(prev)) for c in range(1, len(prev[0])))


def assert_(prev, action, nxt, ctx=None):
    v = _verdict(prev, action, ctx)
    if v is None:
        return "NA"
    return "TRUE" if v == _frozen(prev, nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if _verdict(prev, action, ctx) is not True:
        return None
    return {(r, c): prev[r][c] for r in range(len(prev)) for c in range(1, len(prev[0]))}
