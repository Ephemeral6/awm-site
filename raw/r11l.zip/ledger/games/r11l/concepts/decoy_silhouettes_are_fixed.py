"""还没被取走的漆块，颜色一格不变——**除了被虚线盖住的那几格**：不牵虚线的那些 21 格轮廓，一步之内它那 21 格里除了「底色系↔色1」这一种来回，一格都不改。

第 4 关盘上有若干 21 格轮廓，牵着虚线连到菱形的是圆块，谁也不连的是漆块。
这条只管漆块：只要还没有圆块搬上去把它取走，它就一动不动——所以它是可规划的目标，
路线排到第三步还能指着它。

**名字里的两个词都已经被推翻，留着是为了让这条引线的出身看得见。**
「摆设」错了：漆块不是背景板，圆块能把它取走（circle_absorbs_blob_ink）。
「压在上层」也错了：取色那一步落点 21 格一格没变，我据此以为轮廓盖在圆块之上；
下一步把圆块搬走，图案跟着圆块走了、原地退回底色——是颜色被搬到了圆块身上，不是遮挡。
两种解释在那一帧同像素，判开它们要多走一步。
"""
LEVEL = "L6"
SCOPE = ("换关那一步（levelup）返回 NA——整盘重画，谈不上动没动。"
         "prev 或 nxt 读不出来（readable 为假）返回 NA。prev 上一个不牵虚线的轮廓都没有返回 NA。"
         "**只按 prev 的名单点**，且把这一击正要取走的那一个从名单里摘掉："
         "落点由 prev 与动作算出（after_click + centroid，不看 nxt），"
         "算出来的新圆块中心正好压在名单里某个漆块上，那一个本条不发话，交给 circle_absorbs_blob_ink；"
         "名单上其余的漆块照旧一格不许变。圆块**再搬走**时那个位置在 prev 里已经不在名单上，本条同样不发话。"
         "**唯一放行的变化是「底色系↔色1」**：某格 prev 显底色三色之一而 nxt 显色1、或反过来，本条放过——"
         "那不是漆块变了，是虚线画在它上层又移走（road_is_lines）。别的任何变化照旧判 FALSE。"
         "apply 对应地不预测这两类格：prev 里颜色已经是底色系或色1 的格本条不认领，交给虚线那条。")
NOTE = ("v1。写它的时候第 4 关只走过 0 步，所以它一条证据都还没有——"
        "EVIDENCE 里那条是**发现它们的那一帧**（换关进第 4 关那一步），它在上面判 NA（prev 还是第 3 关的盘）。"
        "**这是预注册**：先押再走，不是先看结果再写。\n"
        "v2：引线响了，但响在我自己身上。f6bd296b1788364d 上它判 FALSE，原因是 `_decoys(prev) != _decoys(nxt)`——"
        "而那 21 格的颜色一格都没变。变的是**我的读法**：世界把虚线重画到了那个位置，"
        "我的 clusters() 于是把它从「不牵虚线」改判成「牵虚线」。"
        "那个集合相等的检查是一条关于读法的主张，不是关于世界的主张，删掉；颜色不变那半留下。\n"
        "v3 只改措辞，代码一行没动：v2 把颜色不变解释成「轮廓压在圆块上层」，"
        "下一步（3052579c3753d0c4）把圆块搬走就否掉了——图案跟着圆块走，原地退回底色5。"
        "真相是取色：颜色被搬到圆块身上（circle_absorbs_blob_ink）。"
        "**留下来的主张比 v2 弱**：只说「还没被取走的漆块不变色」，不再说层次、不再解释取色那一步为什么没变。"
        "记这一笔是因为 v2 的代码是对的而故事是错的，而分数只考代码——"
        "故事错了没有任何东西会报警，只有下一步的实验会。\n"
        "v4 把代码收回到首行主张的范围里，**在挨反例之前改，而不是之后**。"
        "v3 的 SCOPE 里写着「取色那一步那 21 格恰好也没变（圆块顶上去了）」——那句话只在**空罐子**取色时成立："
        "空圆块 21 格全是色0，填完正好等于漆块原样，所以一格没变。"
        "半满的圆块不是这样：它已有的那些有色格会盖到漆块的色0 格上，那些格当场变色。"
        "所以 v3 的代码在「半满圆块取色」这一步上必然说错——`lens.py predict` 事先就把它和 "
        "circle_absorbs_blob_ink 的 11 格分歧摆出来了，两边给同一格不同颜色。"
        "改法不是缩紧主张，是让代码不再宽于主张：首行一直写的是「**还没被取走的**漆块」，"
        "「正在被取走的那一个」本来就不在管辖范围内，v3 只是漏了这个排除项。"
        "摘除条件用 prev + 动作算，不看 nxt——v2 的教训是拿 nxt 的读法做判断会让世界的锅算到读法头上。"
        "留下的仍然可判错：名单上其余的漆块，一格都不许变。\n"
        "v5：229ea7bae98df73e 上判 FALSE，2 格——(56,25) 与 (57,24) 由色10 变成了色1。"
        "漆块没变，是虚线画到了它上层：那块漆的墨色是色10，恰好是底色三色之一。"
        "同一条转移上 road_is_lines 也倒了（它算出来的虚线少这 2 格），两条概念一个病灶。"
        "这条一直在说的是「颜色不变」，而虚线本来就不属于漆块——**v2 那颗钉子的第三次**："
        "v2 是把「我的读法变了」算成世界变了，这次是把「上层画了别的东西」算成漆块变了。"
        "两次都是判据的作用域盖过了「我」和「邻居」的边界。放行的口子只开这一种颜色对，"
        "不是「凡是变成色1 就放过」——后者会把「漆块整块被虚线糊掉」这种真反例也放走。")
EVIDENCE = ["71cecc10786fa7b6", "f6bd296b1788364d", "229ea7bae98df73e"]

from _lib import (C_ROAD, TERRAIN, after_click, centroid, circle_cells, click_xy,
                  cluster_of, clusters, hit_diamond, levelup, quiet, readable,
                  sel, silhouettes)


def _road_swap(a, b):
    """a→b 这个变化是不是「虚线盖上来 / 虚线移走」——底色系与色1 之间的来回。"""
    return (a in TERRAIN and b == C_ROAD) or (a == C_ROAD and b in TERRAIN)


def _decoys(g):
    """认得出轮廓、却牵不到任何菱形的那些。"""
    cl = clusters(g)
    return sorted(m for m in silhouettes(g) if m not in cl)


def _landing(prev, action):
    """这一击算出来的新圆块中心（只用 prev 和动作，不看 nxt）；不属于「空地落子」那一档返回 None。"""
    p = click_xy(action)
    if p is None or not readable(prev) or hit_diamond(prev, p) is not None:
        return None
    a = after_click(prev, p)
    if a is None or a[1] != p:
        return None
    grp = cluster_of(prev, sel(prev))
    if grp is None or grp not in a[0]:
        return None
    return centroid(a[0][grp])


def _watched(prev, action):
    """本条这一步真正管辖的漆块：prev 的名单，减去这一击正要取走的那一个。"""
    taken = _landing(prev, action)
    return [m for m in _decoys(prev) if m != taken]


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    if not (readable(prev) and readable(nxt)):
        return "NA"
    if not _decoys(prev):
        return "NA"
    w = _watched(prev, action)
    if not w:
        return "NA"                   # 名单上只有正被取走的那一个：本条无话可说
    for m in w:                       # 只按 prev 的名单点；名单本身变没变不是世界的事，是读法的事
        for r, c in circle_cells(m):
            if prev[r][c] == nxt[r][c]:
                continue
            if _road_swap(prev[r][c], nxt[r][c]):
                continue              # 虚线在上层来去，漆块本身没动（road_is_lines）
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if quiet(prev, action):
        return None
    out = {}
    for m in _watched(prev, action):
        for r, c in circle_cells(m):
            v = prev[r][c]
            if v in TERRAIN or v == C_ROAD:
                continue              # 这几格虚线可能盖上来或移走，本条不认领
            out[(r, c)] = v
    return out
