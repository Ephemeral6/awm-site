"""同一关内底色层不动：prev 和 nxt 里都露着底色的格（没被动件或虚线盖住），颜色一定相同。

这是「底色可以从单帧读出来」这件事的前提——动件在上面来回走，底下那层是这一关的地形。
"""
LEVEL = "L2"
SCOPE = ("换关那一步返回 NA（换关会整关换地形）。只比较两帧都露着的格；任一帧被盖住的格、"
         "以及说不清归属的色0/色3 残片（被圆块压住的菱形环），都不参与。")
NOTE = ("v1。它是 move_rejected_on_blocked_terrain 与 visible_terrain 的地基：把每一关全部帧叠起来重建地形时，"
        "第 0、1 关 0 个格出现过两种颜色，第 2 关 6 个（正是被圆块压住的那半圈菱形环，读法问题不是地形问题）。"
        "这条概念把那次离线核对变成每条转移都复核一次的主张。"
        "82d916ac0a069e4e 与 e26602d7005e25eb 当场把 v1 打翻，反倒证明了上面那句话："
        "那被压住的半圈环在这两步 3→0 地变了色，而 visible_terrain 当时把它当成底色在读。"
        "改的是词汇不是断言：visible_terrain 现在把 stray_ring 一并算作看不见。\n"
        "v3 又一次被同一种病打翻，断言仍旧没动：75d7cd93bd0af35a 这一步，prev 里一个圆块被虚线"
        "破了一格（虚线会画在圆块刚吸进来的那笔墨上层），silhouettes 于是认不出它，"
        "visible_terrain 就把那 21 格的组色当成底色在读；圆块一走，那片露出真底色5，"
        "本条当场判「地形变了」。**反例落在地基上，病因在读法里**——这是第三次了"
        "（前两次是被压住的菱形环、墨色是色10 的漆块）。改法照旧改词汇：silhouettes 把色1"
        "当通配格。改完这一步 0 格不一致。留着这条 tid 是为了记住这条概念的用途："
        "它是「底色读得出来」的看门狗，它一叫，先查读法，别查地形。")
EVIDENCE = ["795900e09ff3befb", "82d916ac0a069e4e", "e26602d7005e25eb",
            "75d7cd93bd0af35a"]

from _lib import levelup, visible_terrain


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    cells = [(r, c) for r in range(len(prev)) for c in range(len(prev[0]))]
    a, b = visible_terrain(prev, cells), visible_terrain(nxt, cells)
    both = [q for q in cells if a[q] is not None and b[q] is not None]
    if not both:
        return "NA"
    return "TRUE" if all(a[q] == b[q] for q in both) else "FALSE"
