"""点击格不落在任何菱形上时，除选中菱形外，其余菱形的中心一个都不动。"""
LEVEL = "L1"
SCOPE = "只看带坐标的 ACTION6；换关那一步、点击格落在任一菱形上、prev/nxt 里选中菱形定位不到，都返回 NA"
NOTE = "v4：推广到多菱形（第 1 关有 5 个）并加换关豁免。"
EVIDENCE = ["1d2dcfbed7cf1d56", "a57029d2ec8f97c4", "15080d68a357ebbf"]

from _lib import click_xy, diamonds, hit_diamond, levelup, sel


def assert_(prev, action, nxt, ctx=None):
    if levelup(ctx):
        return "NA"
    p = click_xy(action)
    if p is None or hit_diamond(prev, p) is not None:
        return "NA"
    s0, s1 = sel(prev), sel(nxt)
    if s0 is None or s1 is None:
        return "NA"
    before = sorted(d[0] for d in diamonds(prev) if d[0] != s0)
    after = sorted(d[0] for d in diamonds(nxt) if d[0] != s1)
    return "TRUE" if before == after else "FALSE"
