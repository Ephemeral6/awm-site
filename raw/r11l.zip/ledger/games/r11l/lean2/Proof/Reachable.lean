/-
# Reachable —— 这个**局面**做不做得了：骨架 + 一把钥匙 + 三条防线。

这一局六关**全部走得通**（`Proof/Levels.lean`），所以这里**不对任何一关的真实开局宣告「走不通」**。
这一份的用处是：拿到一个局面，能把「它为什么赢不了」写成一条严谨的定理——
而且证明里**没有一处枚举、没有一处搜索，和盘面多大、走多少步都无关**。

## 唯一的骨架

    找一个性质 Φ：每走一步都还成立（`hkeep`），而且和「赢」直接矛盾（`hgoal`）。
    那么从满足 Φ 的局面出发，**任何**点击串都赢不了。

结论里的 `∀ as` 是对**所有**点击串说的（连点到盘外的都算——那是更强的话，不是更弱的）。
模型里没有 RESET：所以准确的意思是「**不经过重置**就赢不了」。这半句写在这里，也写在页面上。

## 这一局的钥匙：「墨用光了，颜色又不对」

    盘上一块漆块都不剩；没有一个靶环锁着；每一组的墨都配不上任何一个靶环（靶环颜色都非空）。

为什么它是一把**真**钥匙、不是「挡住了」：盘上一格墙都没有也照样赢不了——
墨只能从漆块来（`Absorb`），锁靶只看墨的颜色集合（`Lock`），而过关要每一组都压在锁上的靶心上（`LevelClear`）。

**只有这一把。** 技能要求「至少两把理由不同的钥匙」，第二把（例如「挡住了」：罐子的落点全被软地围死）
这一轮没写——这是一个明写的缺口，不是忘了。

装置的「长在世界上」那条检查要求每条定理的语句里出现 `World` / `step` / `isGoal`，
所以下面几条小引理都写成关于 `World` 的话（而不是关于任意列表的话）。
-/

import Step
import Obj.World


/-! ## 一、骨架（全文唯一一条对「任意点击串」做归纳的定理） -/

theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w a, P w → P (step b w a))
    (hgoal : ∀ w, P w → isGoal w = false) :
    ∀ w, P w → ∀ as : List Cell, everGoal b w as = false := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    have h1 := hkeep w a hp
    simp only [everGoal, hgoal _ h1, ih _ h1, Bool.or_false]
#print axioms unsolvable_of_invariant

/-! ## 二、钥匙 -/

/-- 墨用光了，颜色又不对。 -/
def NoInk (w : World) : Prop :=
  w.groups ≠ [] ∧ w.blobs = [] ∧
  (∀ t ∈ w.reticles, ∃ cs, t.colors = some cs ∧ cs ≠ []) ∧
  (∀ g ∈ w.groups, ∀ t ∈ w.reticles, pairs g.ink t.colors = false)

instance (w : World) : Decidable (NoInk w) := by unfold NoInk; exact inferInstance

/-- 挪完之后组不会变没。 -/
theorem moved_groups_ne_nil (w : World) (i : Nat) (a : Cell) (h : w.groups ≠ []) :
    (clickMove w i a).groups ≠ [] := by
  show mapAt (fun g => { g with anchors := movedAnchors g w.selected a }) i w.groups ≠ []
  cases hg : w.groups with
  | nil => exact absurd hg h
  | cons x xs => cases i <;> simp [mapAt]
#print axioms moved_groups_ne_nil

/-- 挪那一下只改锚点：挪完之后每一组的墨，都还是挪之前某一组的墨。 -/
theorem moved_groups_ink (w : World) (i : Nat) (a : Cell) :
    ∀ g ∈ (clickMove w i a).groups, ∃ g0 ∈ w.groups, g0.ink = g.ink := by
  show ∀ g ∈ mapAt (fun g => { g with anchors := movedAnchors g w.selected a }) i w.groups,
    ∃ g0 ∈ w.groups, g0.ink = g.ink
  generalize w.groups = l
  induction l generalizing i with
  | nil => intro g h; simp [mapAt] at h
  | cons x xs ih =>
    intro g h
    cases i with
    | zero =>
      simp only [mapAt, List.mem_cons] at h
      rcases h with h | h
      · exact ⟨x, by simp, by rw [h]⟩
      · exact ⟨g, by simp [h], rfl⟩
    | succ n =>
      simp only [mapAt, List.mem_cons] at h
      rcases h with h | h
      · exact ⟨x, by simp, by rw [h]⟩
      · obtain ⟨g0, hm, he⟩ := ih n g h
        exact ⟨g0, by simp [hm], he⟩
#print axioms moved_groups_ink

/-- 按下标取一组：要么取到盘上真有的一组，要么越界拿到空组。 -/
theorem groups_getD_mem_or (w : World) (i : Nat) :
    w.groups.getD i ⟨[], []⟩ ∈ w.groups ∨ w.groups.getD i ⟨[], []⟩ = ⟨[], []⟩ := by
  generalize w.groups = l
  induction l generalizing i with
  | nil => exact Or.inr (by simp)
  | cons x xs ih =>
    cases i with
    | zero => exact Or.inl (by simp)
    | succ n =>
      have e : (x :: xs).getD (n + 1) ⟨[], []⟩ = xs.getD n ⟨[], []⟩ := rfl
      rw [e]
      rcases ih n with h | h
      · exact Or.inl (List.mem_cons_of_mem x h)
      · exact Or.inr h
#print axioms groups_getD_mem_or

/-- 墨配不上任何一个靶环时，`lock` 什么也不做。 -/
theorem lock_noop (w : World) (i : Nat) (c : Cell)
    (hp : ∀ t ∈ w.reticles, pairs (w.groups.getD i ⟨[], []⟩).ink t.colors = false) :
    lock w i c = w := by
  unfold lock
  have : w.reticles.map (fun t =>
      if t.center = c && pairs (w.groups.getD i ⟨[], []⟩).ink t.colors then { t with colors := none } else t)
      = w.reticles := by
    conv => rhs; rw [← List.map_id w.reticles]
    apply List.map_congr_left
    intro t ht
    rw [hp t ht]
    simp
  simp only [this]
#print axioms lock_noop

/-- 钥匙走不坏：`NoInk` 每走一步都还成立。 -/
theorem noInk_keep (b : Board) : ∀ w a, NoInk w → NoInk (step b w a) := by
  intro w a ⟨hg, hb, hr, hp⟩
  have pairs_nil : ∀ cs : List Nat, cs ≠ [] → pairs [] (some cs) = false := by
    intro cs h
    cases cs with
    | nil => exact absurd rfl h
    | cons x xs => simp [pairs, sameSet]
  unfold step tick
  split
  · exact ⟨hg, hb, hr, hp⟩
  · split
    · exact ⟨hg, hb, hr, hp⟩
    · rename_i i _
      split
      · exact ⟨hg, hb, hr, hp⟩
      · -- 挪动：只改锚点；取墨：没有漆块，什么都不做；锁靶：配不上，什么都不做
        have hab : absorb (clickMove w i a) i (landing w i a) = clickMove w i a := by
          simp [absorb, clickMove, hb]
        rw [hab]
        have hgs := moved_groups_ink w i a
        have hlk : lock (clickMove w i a) i (landing w i a) = clickMove w i a := by
          apply lock_noop
          intro t ht
          rcases groups_getD_mem_or (clickMove w i a) i with h | h
          · obtain ⟨g0, hm, he⟩ := hgs _ h
            rw [← he]; exact hp g0 hm t ht
          · rw [h]; obtain ⟨cs, hcs, hne⟩ := hr t ht; rw [hcs]; exact pairs_nil cs hne
        rw [hlk]
        refine ⟨moved_groups_ne_nil w i a hg, hb, hr, ?_⟩
        intro g hgm t ht
        obtain ⟨g0, hm, he⟩ := hgs g hgm
        rw [← he]; exact hp g0 hm t ht
#print axioms noInk_keep

/-- 钥匙与目标矛盾：没有一个靶环锁着，而组不空，就不可能每一组都压在锁上的靶心上。 -/
theorem noInk_no_goal : ∀ w, NoInk w → isGoal w = false := by
  intro w ⟨hg, _, hr, _⟩
  unfold isGoal
  cases hgs : w.groups with
  | nil => exact absurd hgs hg
  | cons g gs =>
    have : w.reticles.any (fun t => t.center = g.center && t.locked) = false := by
      rw [List.any_eq_false]
      intro t ht
      obtain ⟨cs, hcs, _⟩ := hr t ht
      simp [Reticle.locked, hcs]
    simp [this]
#print axioms noInk_no_goal

/-- **钥匙挂上骨架**：满足 `NoInk` 的局面，**不经过重置**，任何点击串都过不了关。 -/
theorem unsolvable_by_noInk (b : Board) (w : World) (h : NoInk w) :
    ∀ as : List Cell, everGoal b w as = false :=
  unsolvable_of_invariant b NoInk (noInk_keep b) noInk_no_goal w h
#print axioms unsolvable_by_noInk

/-! ## 三、防线：一张「只差一处」的盘

    `stuck`   一组两颗菱形，墨全是 7；一个靶环，颜色 [8]；没有漆块、没有墙 —— 钥匙套得上
    `twin`    同一张盘，只把靶环的颜色从 [8] 换成 [7] —— **改的正是钥匙要害那一处**

三条缺一不可：

    twin_winnable        它确实赢得了（给一条真路线，内核算）
    twin_closed_at_start 而且不是因为它一开始就通
    twin_not_noInk       而且钥匙的前提在它身上**真的不满足**——不是「我没找到证明」
-/

def blankBoard : Board := ⟨[], []⟩

def stuck : World :=
  ⟨0, ⟨10, 20⟩, [⟨[⟨10, 10⟩, ⟨10, 20⟩], List.replicate 20 7⟩], [], [⟨⟨20, 15⟩, some [8]⟩]⟩

def twin : World :=
  ⟨0, ⟨10, 20⟩, [⟨[⟨10, 10⟩, ⟨10, 20⟩], List.replicate 20 7⟩], [], [⟨⟨20, 15⟩, some [7]⟩]⟩

theorem stuck_noInk : NoInk (stuck : World) := by decide
#print axioms stuck_noInk

theorem stuck_unsolvable : ∀ as : List Cell, everGoal blankBoard (stuck : World) as = false :=
  unsolvable_by_noInk blankBoard stuck stuck_noInk
#print axioms stuck_unsolvable

theorem twin_winnable : Winnable blankBoard (twin : World) := ⟨[⟨30, 20⟩], by decide⟩
#print axioms twin_winnable

theorem twin_closed_at_start : isGoal (twin : World) = false := by decide
#print axioms twin_closed_at_start

theorem twin_not_noInk : ¬ NoInk (twin : World) := by decide
#print axioms twin_not_noInk

