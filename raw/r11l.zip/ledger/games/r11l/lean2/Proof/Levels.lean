/-
# Levels —— 每一关一条定理（自动生成，不要手改；生成器 `lean2/export_levels.py`）

    L<n>_trace         沿着成绩单认证的那一段真实走法，模型**每一帧**都和观测对上（中途没提前过关）
    L<n>_winnable      这一关走得通 —— 见证就是那一段走法，再加上过关那一脚
    L<n>_trace_seg1    另一段（没被认证）的走法，同样逐帧对上 —— **只是更多的核对，不当见证**
    L<n>_same_opening  两段的开局一样 —— 「每关开局固定」这件事在这批语料上唯一一次被驳倒的机会

开局**从语料的帧里读出来**（`Replay.worldAt`），不是手写的盘。盘用 `levelBoards`（整关取并集，口径见 Replay）。

这一局六关**全部走得通**，所以这一份里没有 `_unsolvable`。
「这一关走不通」只有在 Lean 里证出来才写；这里一条也没有，因为每一关都有人走通过。
-/

import Obs.Replay
import Obj.World

set_option maxRecDepth 100000

/-- 一段步号 → (点击, 看到的下一帧) 的路。 -/
def pathOf (xs : List Row) : List (Cell × Seen) := xs.map (fun s => (s.act, worldAt s.next))

/-! ## 第 0 关 -/

/-- 第 0 关的真实开局（认证段 seq 104 那一行的前一帧）。**从帧里读出来的。** -/
def L0_start : World := worldAt (bySeq 104).prev

/-- 认证段里第 0 关、过关之前的全部点击：seq 104..105，2 步。过关那一脚（seq 106）不在这里。 -/
def L0_play : List (Cell × Seen) := pathOf (segment 104 105)

theorem L0_len : (L0_play : List (Cell × World)).length = 2 := by decide +kernel
#print axioms L0_len

#eval match firstSplit (levelBoard 0) L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 2 帧全是模型自己算的。 -/
theorem L0_trace : traceOk (levelBoard 0) (L0_start : World) L0_play = true := by decide +kernel
#print axioms L0_trace

/-- **第 0 关走得通。** 见证：那 2 步，再加过关那一脚 ⟨39, 43⟩。 -/
theorem L0_winnable : Winnable (levelBoard 0) (L0_start : World) :=
  ⟨L0_play.map Prod.fst ++ [⟨39, 43⟩], by decide +kernel⟩
#print axioms L0_winnable

/-- 另一段（成绩单**不认证**）里第 0 关的开局与路：seq 1..7，7 步。**不当见证。** -/
def L0_start_seg1 : World := worldAt (bySeq 1).prev
def L0_play_seg1 : List (Cell × Seen) := pathOf (segment 1 7)

theorem L0_len_seg1 : (L0_play_seg1 : List (Cell × World)).length = 7 := by decide +kernel
#print axioms L0_len_seg1

theorem L0_trace_seg1 : traceOk (levelBoard 0) (L0_start_seg1 : World) L0_play_seg1 = true := by
  decide +kernel
#print axioms L0_trace_seg1

/-- 两段的第 0 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L0_same_opening : seenAgree (L0_start_seg1 : World) L0_start = true := by decide +kernel
#print axioms L0_same_opening

/-! ## 第 1 关 -/

/-- 第 1 关的真实开局（认证段 seq 107 那一行的前一帧）。**从帧里读出来的。** -/
def L1_start : World := worldAt (bySeq 107).prev

/-- 认证段里第 1 关、过关之前的全部点击：seq 107..115，9 步。过关那一脚（seq 116）不在这里。 -/
def L1_play : List (Cell × Seen) := pathOf (segment 107 115)

theorem L1_len : (L1_play : List (Cell × World)).length = 9 := by decide +kernel
#print axioms L1_len

#eval match firstSplit (levelBoard 1) L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 9 帧全是模型自己算的。 -/
theorem L1_trace : traceOk (levelBoard 1) (L1_start : World) L1_play = true := by decide +kernel
#print axioms L1_trace

/-- **第 1 关走得通。** 见证：那 9 步，再加过关那一脚 ⟨61, 34⟩。 -/
theorem L1_winnable : Winnable (levelBoard 1) (L1_start : World) :=
  ⟨L1_play.map Prod.fst ++ [⟨61, 34⟩], by decide +kernel⟩
#print axioms L1_winnable

/-- 另一段（成绩单**不认证**）里第 1 关的开局与路：seq 9..18，10 步。**不当见证。** -/
def L1_start_seg1 : World := worldAt (bySeq 9).prev
def L1_play_seg1 : List (Cell × Seen) := pathOf (segment 9 18)

theorem L1_len_seg1 : (L1_play_seg1 : List (Cell × World)).length = 10 := by decide +kernel
#print axioms L1_len_seg1

theorem L1_trace_seg1 : traceOk (levelBoard 1) (L1_start_seg1 : World) L1_play_seg1 = true := by
  decide +kernel
#print axioms L1_trace_seg1

/-- 两段的第 1 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L1_same_opening : seenAgree (L1_start_seg1 : World) L1_start = true := by decide +kernel
#print axioms L1_same_opening

/-! ## 第 2 关 -/

/-- 第 2 关的真实开局（认证段 seq 117 那一行的前一帧）。**从帧里读出来的。** -/
def L2_start : World := worldAt (bySeq 117).prev

/-- 认证段里第 2 关、过关之前的全部点击：seq 117..130，14 步。过关那一脚（seq 131）不在这里。 -/
def L2_play : List (Cell × Seen) := pathOf (segment 117 130)

theorem L2_len : (L2_play : List (Cell × World)).length = 14 := by decide +kernel
#print axioms L2_len

#eval match firstSplit (levelBoard 2) L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 14 帧全是模型自己算的。 -/
theorem L2_trace : traceOk (levelBoard 2) (L2_start : World) L2_play = true := by decide +kernel
#print axioms L2_trace

/-- **第 2 关走得通。** 见证：那 14 步，再加过关那一脚 ⟨59, 61⟩。 -/
theorem L2_winnable : Winnable (levelBoard 2) (L2_start : World) :=
  ⟨L2_play.map Prod.fst ++ [⟨59, 61⟩], by decide +kernel⟩
#print axioms L2_winnable

/-- 另一段（成绩单**不认证**）里第 2 关的开局与路：seq 20..40，21 步。**不当见证。** -/
def L2_start_seg1 : World := worldAt (bySeq 20).prev
def L2_play_seg1 : List (Cell × Seen) := pathOf (segment 20 40)

theorem L2_len_seg1 : (L2_play_seg1 : List (Cell × World)).length = 21 := by decide +kernel
#print axioms L2_len_seg1

theorem L2_trace_seg1 : traceOk (levelBoard 2) (L2_start_seg1 : World) L2_play_seg1 = true := by
  decide +kernel
#print axioms L2_trace_seg1

/-- 两段的第 2 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L2_same_opening : seenAgree (L2_start_seg1 : World) L2_start = true := by decide +kernel
#print axioms L2_same_opening

/-! ## 第 3 关 -/

/-- 第 3 关的真实开局（认证段 seq 132 那一行的前一帧）。**从帧里读出来的。** -/
def L3_start : World := worldAt (bySeq 132).prev

/-- 认证段里第 3 关、过关之前的全部点击：seq 132..143，12 步。过关那一脚（seq 144）不在这里。 -/
def L3_play : List (Cell × Seen) := pathOf (segment 132 143)

theorem L3_len : (L3_play : List (Cell × World)).length = 12 := by decide +kernel
#print axioms L3_len

#eval match firstSplit (levelBoard 3) L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 12 帧全是模型自己算的。 -/
theorem L3_trace : traceOk (levelBoard 3) (L3_start : World) L3_play = true := by decide +kernel
#print axioms L3_trace

/-- **第 3 关走得通。** 见证：那 12 步，再加过关那一脚 ⟨32, 59⟩。 -/
theorem L3_winnable : Winnable (levelBoard 3) (L3_start : World) :=
  ⟨L3_play.map Prod.fst ++ [⟨32, 59⟩], by decide +kernel⟩
#print axioms L3_winnable

/-- 另一段（成绩单**不认证**）里第 3 关的开局与路：seq 42..54，13 步。**不当见证。** -/
def L3_start_seg1 : World := worldAt (bySeq 42).prev
def L3_play_seg1 : List (Cell × Seen) := pathOf (segment 42 54)

theorem L3_len_seg1 : (L3_play_seg1 : List (Cell × World)).length = 13 := by decide +kernel
#print axioms L3_len_seg1

theorem L3_trace_seg1 : traceOk (levelBoard 3) (L3_start_seg1 : World) L3_play_seg1 = true := by
  decide +kernel
#print axioms L3_trace_seg1

/-- 两段的第 3 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L3_same_opening : seenAgree (L3_start_seg1 : World) L3_start = true := by decide +kernel
#print axioms L3_same_opening

/-! ## 第 4 关 -/

/-- 第 4 关的真实开局（认证段 seq 145 那一行的前一帧）。**从帧里读出来的。** -/
def L4_start : World := worldAt (bySeq 145).prev

/-- 认证段里第 4 关、过关之前的全部点击：seq 145..160，16 步。过关那一脚（seq 161）不在这里。 -/
def L4_play : List (Cell × Seen) := pathOf (segment 145 160)

theorem L4_len : (L4_play : List (Cell × World)).length = 16 := by decide +kernel
#print axioms L4_len

#eval match firstSplit (levelBoard 4) L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 16 帧全是模型自己算的。 -/
theorem L4_trace : traceOk (levelBoard 4) (L4_start : World) L4_play = true := by decide +kernel
#print axioms L4_trace

/-- **第 4 关走得通。** 见证：那 16 步，再加过关那一脚 ⟨23, 3⟩。 -/
theorem L4_winnable : Winnable (levelBoard 4) (L4_start : World) :=
  ⟨L4_play.map Prod.fst ++ [⟨23, 3⟩], by decide +kernel⟩
#print axioms L4_winnable

/-- 另一段（成绩单**不认证**）里第 4 关的开局与路：seq 56..77，22 步。**不当见证。** -/
def L4_start_seg1 : World := worldAt (bySeq 56).prev
def L4_play_seg1 : List (Cell × Seen) := pathOf (segment 56 77)

theorem L4_len_seg1 : (L4_play_seg1 : List (Cell × World)).length = 22 := by decide +kernel
#print axioms L4_len_seg1

theorem L4_trace_seg1 : traceOk (levelBoard 4) (L4_start_seg1 : World) L4_play_seg1 = true := by
  decide +kernel
#print axioms L4_trace_seg1

/-- 两段的第 4 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L4_same_opening : seenAgree (L4_start_seg1 : World) L4_start = true := by decide +kernel
#print axioms L4_same_opening

/-! ## 第 5 关 -/

/-- 第 5 关的真实开局（认证段 seq 162 那一行的前一帧）。**从帧里读出来的。** -/
def L5_start : World := worldAt (bySeq 162).prev

/-- 认证段里第 5 关、过关之前的全部点击：seq 162..183，22 步。过关那一脚（seq 184）不在这里。 -/
def L5_play : List (Cell × Seen) := pathOf (segment 162 183)

theorem L5_len : (L5_play : List (Cell × World)).length = 22 := by decide +kernel
#print axioms L5_len

#eval match firstSplit (levelBoard 5) L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着认证的那一段走法一步不差**：只有开局是观测给的，后面 22 帧全是模型自己算的。 -/
theorem L5_trace : traceOk (levelBoard 5) (L5_start : World) L5_play = true := by decide +kernel
#print axioms L5_trace

/-- **第 5 关走得通。** 见证：那 22 步，再加过关那一脚 ⟨61, 19⟩。 -/
theorem L5_winnable : Winnable (levelBoard 5) (L5_start : World) :=
  ⟨L5_play.map Prod.fst ++ [⟨61, 19⟩], by decide +kernel⟩
#print axioms L5_winnable

/-- 另一段（成绩单**不认证**）里第 5 关的开局与路：seq 79..101，23 步。**不当见证。** -/
def L5_start_seg1 : World := worldAt (bySeq 79).prev
def L5_play_seg1 : List (Cell × Seen) := pathOf (segment 79 101)

theorem L5_len_seg1 : (L5_play_seg1 : List (Cell × World)).length = 23 := by decide +kernel
#print axioms L5_len_seg1

theorem L5_trace_seg1 : traceOk (levelBoard 5) (L5_start_seg1 : World) L5_play_seg1 = true := by
  decide +kernel
#print axioms L5_trace_seg1

/-- 两段的第 5 关开局一样（按 `seenAgree` 的口径）。 -/
theorem L5_same_opening : seenAgree (L5_start_seg1 : World) L5_start = true := by decide +kernel
#print axioms L5_same_opening

