/-
# TerrainStatic —— 一关之内底色不变。身份：**推论**（由架构推出，不是一条独立的规则）。

对应 `rule/世界怎么回应/terrain_static.py`（Python 那一侧它是一条要逐步判的规则：前后两帧都露着的格颜色一样）。

形式化这一侧它**不用再写成规则**：底色住在 `Board` 里，`Board` 是 `step` 的参数、不是 `World` 的字段，
`step` 的结果里根本没有底色——「走一步底色变了」这句话**表示不出来**。

能写下来、而且能失败的那一句是它的另一半：**`step` 只通过「每一格挡不挡路」读底色**。
两张盘只要每一格的硬墙位、软地位都一样，走出来的就是同一个世界。
（要是 `step` 偷偷读了底色的别的什么——比如看不见的格按别的算——这一条就证不出来。）
-/

import Step
import Obj.World


/-- **一关之内底色不变**的可证那一半：`step` 对底色的依赖只经过「挡不挡路」这一位。 -/
theorem terrain_static (b₁ b₂ : Board)
    (h : ∀ q, b₁.wallAt q = b₂.wallAt q ∧ b₁.softAt q = b₂.softAt q) (w : World) (p : Cell) :
    step b₁ w p = step b₂ w p := by
  have hb : ∀ c, blocked b₁ p c = blocked b₂ p c := by
    intro c
    have hw : (fun q => b₁.wallAt q) = (fun q => b₂.wallAt q) := funext fun q => (h q).1
    have hs : (fun q => b₁.wallAt q || b₁.softAt q) = (fun q => b₂.wallAt q || b₂.softAt q) :=
      funext fun q => by rw [(h q).1, (h q).2]
    unfold blocked
    rw [hw, hs]
  unfold step
  simp only [hb]
#print axioms terrain_static

