/-
# Step —— 一步怎么走。**只做分发，0 条定理。**

    点在菱形上            → ClickSelects
    没点在菱形上、踩禁地    → ClickRejected
    没点在菱形上、不踩禁地  → ClickMoves，然后 Absorb（落在漆块上才有事），然后 Lock（落在配得上的靶心上才有事）
    每一种都要 Bar（点了几下加一）

（落点 `landing w i p` 写了三遍而不 `let` 一次：`def` 里的 `let` 会让 `split` 进不去，
 `Proof/Reachable.lean` 要对这里分情形。）

`Board` 是参数，不是状态：`step` 的结果里没有它（「一关之内底色不变」表示不出反例来）。
模型里**没有** RESET（`Rule/NotModeled/Reset.lean`）；也不描述过关之后的下一关——
过关那一步 `step` 照常给出一个 `World`，它满足 `isGoal`，下一关的盘从帧里读。
-/

import Rule.Move.ClickSelects
import Rule.Move.ClickMoves
import Rule.Move.ClickRejected
import Rule.Response.Absorb
import Rule.Response.Bar
import Rule.Win.Lock
import Rule.Win.LevelClear
import Rule.NotModeled.Reset


def step (b : Board) (w : World) (p : Cell) : World :=
  tick <|
    match hitAnchor w p with
    | some a => clickSelect w a
    | none =>
      match groupOf w w.selected with
      | none => w
      | some i =>
        if blocked b p (landing w i p) then clickReject w
        else lock (absorb (clickMove w i p) i (landing w i p)) i (landing w i p)

/-- 沿一串点击走下去，**中途**有没有哪一刻赢过（`isGoal`）。 -/
def everGoal (b : Board) : World → List Cell → Bool
  | _, [] => false
  | w, a :: as => isGoal (step b w a) || everGoal b (step b w a) as

/-- 这个局面走得通：有一串点击，中途赢过。 -/
def Winnable (b : Board) (w : World) : Prop := ∃ as : List Cell, everGoal b w as = true

