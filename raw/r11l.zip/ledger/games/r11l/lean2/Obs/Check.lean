/-
# Check —— 判据层：模型面对现实的两把尺子。**0 条定理**，尺子不自证。

    agrees      **一条转移**对不对：从观测到的那一帧算一步，和看到的下一帧比
    traceOk     **一整条路**对不对：从开局起带着**自己算出来的**状态往下走，逐帧比

两把尺子的分量差得很远：`agrees` 每一步都被拉回正轨；`traceOk` 只有开局是观测给的。
一个「每步单独看都对、走两步就和现实分家」的模型，在前一把满分，在后一把过不了。

## Seen：只装帧上看得见的

观测到的那一帧读成 `World`（同一个形状，所以 `Seen := World`），但比的时候有三处口径：

    · 锚点**按集合比**：帧上读不出哪颗是「第几颗」，模型里的顺序是自己挪出来的
    · 组、漆块、靶环**按集合比**：同上
    · 墨逐格比，**帧上的 1 和底色三色（2 / 5 / 10）都对得上**：虚线画在显底色的墨格上，
      那一格帧上是 1，真色读不出来——这是判据的口径，不是世界的规律（Python 那一侧 `derive/seen.py` 同一条）

## 三值

逐条那一层对 RESET **不判**（模型不描述它），带标记剔出去、条数打在明处——`na` 不是 `true`。
-/

import Step
import Obj.World


abbrev Seen := World

def cellAgree (a b : Nat) : Bool :=
  a == b || (a == 1 && (b == 2 || b == 5 || b == 10)) || (b == 1 && (a == 2 || a == 5 || a == 10))

def inkAgree : List Nat → List Nat → Bool
  | [], [] => true
  | a :: as, b :: bs => cellAgree a b && inkAgree as bs
  | _, _ => false

def sameCells (xs ys : List Cell) : Bool :=
  xs.length == ys.length && xs.all (ys.contains ·)

def groupsAgree (m o : List Group) : Bool :=
  m.length == o.length && m.all (fun g => o.any (fun h => sameCells g.anchors h.anchors && inkAgree g.ink h.ink))

def blobsAgree (m o : List Blob) : Bool :=
  m.length == o.length && m.all (fun x => o.any (fun y => x.center == y.center && inkAgree x.ink y.ink))

def retsAgree (m o : List Reticle) : Bool :=
  m.length == o.length && m.all (fun x => o.any (fun y => x.center == y.center && x.colors == y.colors))

/-- 模型算出的世界 m 和看到的那一帧 o 对不对得上。 -/
def seenAgree (m o : Seen) : Bool :=
  m.spent == o.spent && m.selected == o.selected &&
  groupsAgree m.groups o.groups && blobsAgree m.blobs o.blobs && retsAgree m.reticles o.reticles

/-- 上游说这一步是什么。模型**看不到**它；逐条判用它挑「该比什么」。 -/
inductive Kind where
  | move | levelup | win | reset
deriving DecidableEq, Repr

/-- 一条转移对不对。**每一支都要对上一种观测**，不许有一支写成「算不出来就算它对」：

    move     没过关，而且算出来的那一帧和看到的一样
    win      过关了（isGoal），而且盘还是这一盘，一样
    levelup  过关了（isGoal）；下一帧是下一关的盘，不比
    reset    不在这把尺子的论域里（调用方剔除；这里给 false，剔漏了会当场红） -/
def agrees (b : Board) (k : Kind) (prev : World) (a : Cell) (next : Seen) : Bool :=
  let w' := step b prev a
  match k with
  | .move => !isGoal w' && seenAgree w' next
  | .win => isGoal w' && seenAgree w' next
  | .levelup => isGoal w'
  | .reset => false

/-- 从 s 出发沿 play 走，每一步都和当时看到的那一帧比；中途不许提前过关。

    **要害在那个 `s'`**：下一轮喂进去的是模型自己算出来的状态，不是观测到的那一帧。 -/
def traceOk (b : Board) : World → List (Cell × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    let s' := step b s a
    !isGoal s' && seenAgree s' o && traceOk b s' rest

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (b : Board) : World → List (Cell × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    let s' := step b s a
    if !isGoal s' && seenAgree s' o then firstSplit b s' rest (i + 1) else some i

