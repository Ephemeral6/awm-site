/-
# Corpus —— 逐条那一层（自动生成，不要手改；生成器 `lean2/export_corpus.py`）

每一条真实转移（RESET 除外）：从**观测到的那一帧**起算一步，和看到的下一帧比（`agrees`）。
模型每一步都被拉回正轨——所以这一层是满分并不说明「走两步不分家」，那一句归 `Proof/Levels.lean`。

盘用 `frameBoards`：这一步真正读到的那张（口径见 `Obs/Replay.lean` 文件头）。

**读数不是定理**：下面每一条 `#eval` 走求值器，不进可信基；结论是那几条走内核的 `theorem`。

## RESET：不进模型的那一条假设

模型里没有 RESET。语料里的 RESET 带标记剔出逐条判（`resets`，条数有一条 `_len` 钉住），
而「RESET 把整局放回第 0 关开局」这条假设在这里有**一次**被驳倒的机会：`reset_back_to_opening`。
**没被驳倒不构成证明**——那只是它在这批语料上唯一一次有机会被驳倒而没被驳倒。
-/

import Obs.Replay
import Obj.World

set_option maxRecDepth 100000

/-- 一条转移，模型站不站得住。 -/
def caseOk (s : Row) : Bool := agrees (boardAt s.board) s.kind (worldAt s.prev) s.act (worldAt s.next)

/-- 逐条判的论域：RESET 以外的全部转移。 -/
def judged : List Row := steps.filter (fun s => s.kind != .reset)

/-- 剔出去的：RESET。 -/
def resets : List Row := steps.filter (fun s => s.kind == .reset)

theorem corpus_judged_len : (judged.map (fun s => worldAt s.prev) : List World).length = 183 := by decide +kernel
#print axioms corpus_judged_len

theorem corpus_resets_len : (resets.map (fun s => worldAt s.prev) : List World).length = 1 := by decide +kernel
#print axioms corpus_resets_len

#eval "CORPUS_FAIL " ++ toString ((judged.filter (fun s => !caseOk s)).map (·.seq))

/-- 第 0 关的全部转移（两段都算，RESET 除外），11 条。 -/
def corpusL0 : List Row := judged.filter (fun s => s.lvl == 0)

theorem corpus_L0_len : (corpusL0.map (fun s => worldAt s.prev) : List World).length = 11 := by decide +kernel
#print axioms corpus_L0_len

/-- **第 0 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L0_agrees :
    (corpusL0.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L0_agrees

/-- 第 1 关的全部转移（两段都算，RESET 除外），21 条。 -/
def corpusL1 : List Row := judged.filter (fun s => s.lvl == 1)

theorem corpus_L1_len : (corpusL1.map (fun s => worldAt s.prev) : List World).length = 21 := by decide +kernel
#print axioms corpus_L1_len

/-- **第 1 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L1_agrees :
    (corpusL1.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L1_agrees

/-- 第 2 关的全部转移（两段都算，RESET 除外），37 条。 -/
def corpusL2 : List Row := judged.filter (fun s => s.lvl == 2)

theorem corpus_L2_len : (corpusL2.map (fun s => worldAt s.prev) : List World).length = 37 := by decide +kernel
#print axioms corpus_L2_len

/-- **第 2 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L2_agrees :
    (corpusL2.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L2_agrees

/-- 第 3 关的全部转移（两段都算，RESET 除外），27 条。 -/
def corpusL3 : List Row := judged.filter (fun s => s.lvl == 3)

theorem corpus_L3_len : (corpusL3.map (fun s => worldAt s.prev) : List World).length = 27 := by decide +kernel
#print axioms corpus_L3_len

/-- **第 3 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L3_agrees :
    (corpusL3.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L3_agrees

/-- 第 4 关的全部转移（两段都算，RESET 除外），40 条。 -/
def corpusL4 : List Row := judged.filter (fun s => s.lvl == 4)

theorem corpus_L4_len : (corpusL4.map (fun s => worldAt s.prev) : List World).length = 40 := by decide +kernel
#print axioms corpus_L4_len

/-- **第 4 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L4_agrees :
    (corpusL4.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L4_agrees

/-- 第 5 关的全部转移（两段都算，RESET 除外），47 条。 -/
def corpusL5 : List Row := judged.filter (fun s => s.lvl == 5)

theorem corpus_L5_len : (corpusL5.map (fun s => worldAt s.prev) : List World).length = 47 := by decide +kernel
#print axioms corpus_L5_len

/-- **第 5 关的每一条真实转移，模型都站得住**（从观测到的那一帧起算一步）。 -/
theorem corpus_L5_agrees :
    (corpusL5.all (fun s => agrees (boardAt s.board) s.kind (worldAt s.prev : World) s.act (worldAt s.next))) = true := by
  decide +kernel
#print axioms corpus_L5_agrees

/-- RESET 之后那一帧 = 语料第一行的开局（第 0 关）。给「不进模型」的那条假设一次被驳倒的机会。 -/
theorem reset_back_to_opening :
    (resets.all (fun s => seenAgree (worldAt s.next : World) (worldAt (bySeq 1).prev))) = true := by
  decide +kernel
#print axioms reset_back_to_opening

