/-
# Absorb —— 罐子的中心正好落到一块漆块的中心上：取墨，漆块消失。

对应 `rule/世界怎么回应/absorb.py`。身份：**定义**。

漆块有墨（非 0）的格按同一偏移**盖**到罐子上（原来的颜色也被盖掉），没墨的格罐子原样。
没落在漆块上：什么都不变（`absorb` 在那时就是恒等）。
-/

import Obj.World


def overwrite (ink blob : List Nat) : List Nat :=
  List.zipWith (fun a b => if b = 0 then a else b) ink blob

/-- 第 i 组的罐子落在 c 上：若 c 正好是某块漆块的中心，取墨并拿走那块漆块。 -/
def absorb (w : World) (i : Nat) (c : Cell) : World :=
  match w.blobs.find? (fun x => x.center = c) with
  | none => w
  | some x =>
    { w with
      groups := mapAt (fun g => { g with ink := overwrite g.ink x.ink }) i w.groups
      blobs := w.blobs.filter (fun y => y.center ≠ c) }

