/-
# Bar —— 预算：同一关里每点一下，`spent` 加一。

对应 `rule/世界怎么回应/bar.py`。身份：**定义**（关内那一半）。

那条规则还有另一半：「进入新一关之后 `spent` = 0」。那一半**不进这一份**：
模型不描述下一关（整盘重画），每一关的开局是从帧里读出来的（`Proof/Levels.lean` 的 `L<n>_start`），
而那一帧里 `spent` 就是 0——它由「开局从帧里读」承担，逐条那一层（`Obs/Corpus.lean`）不比换关那一步的下一帧。
-/

import Obj.World


def tick (w : World) : World := { w with spent := w.spent + 1 }

