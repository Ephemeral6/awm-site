/-
# ClickMoves —— 没点在菱形上、也没踩禁地：选中那颗挪到点击格，别的菱形一颗不动。

对应 `rule/一步怎么走/click_moves.py`。身份：**定义**。

挪的只是一个锚点；罐子跟到哪不用说——罐子的中心是锚点的质心（`Group.center`），不是字段。
-/

import Obj.World


/-- 选中那颗在第几组。 -/
def groupOf (w : World) (s : Cell) : Option Nat :=
  w.groups.findIdx? (fun g => g.anchors.contains s)

/-- 把第 i 组里的 s 换成 p 之后的锚点。 -/
def movedAnchors (g : Group) (s p : Cell) : List Cell :=
  g.anchors.map (fun a => if a = s then p else a)

/-- 挪过去之后罐子会在哪（给「挡不挡路」与「落在哪」用）。 -/
def landing (w : World) (i : Nat) (p : Cell) : Cell :=
  centroid (movedAnchors (w.groups.getD i ⟨[], []⟩) w.selected p)

/-- 挪：第 i 组的 s 换成 p，选中跟到 p。 -/
def clickMove (w : World) (i : Nat) (p : Cell) : World :=
  { w with
    selected := p
    groups := mapAt (fun g => { g with anchors := movedAnchors g w.selected p }) i w.groups }

