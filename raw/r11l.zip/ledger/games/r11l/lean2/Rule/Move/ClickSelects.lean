/-
# ClickSelects —— 点在某颗菱形上：选中换到那一颗，谁也不挪。

对应 `rule/一步怎么走/click_selects.py`。身份：**定义**。

「点在菱形上」= 点击格落进某颗菱形的 13 格（曼哈顿距离 ≤ 2）。
点在两颗菱形重叠处取哪一颗：语料 0 次；这里取 `anchors` 里的第一颗，Python 那一侧取排序后的第一颗——
**两边在这一处可能不同，而语料分不开**，写在明处。
-/

import Obj.World


/-- 点击格 p 落在哪颗菱形上。 -/
def hitAnchor (w : World) (p : Cell) : Option Cell :=
  w.anchors.find? (fun a => manhattan a p ≤ 2)

/-- 选中换到 a。别的一概不动（竖条那一格归 `Bar`）。 -/
def clickSelect (w : World) (a : Cell) : World := { w with selected := a }

