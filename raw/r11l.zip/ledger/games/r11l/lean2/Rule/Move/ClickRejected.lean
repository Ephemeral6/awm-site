/-
# ClickRejected —— 挪过去会踩禁地：这一下被驳回，谁也不挪、选中不变。

对应 `rule/一步怎么走/click_rejected.py`。身份：**定义**。

    菱形 13 格：不许踩硬墙
    罐子 21 格：不许踩硬墙，也不许踩软地

压到别的东西（别的菱形、罐子、漆块、靶环）**不算**挡路——只有底色说了算。
看不见的格在 `Board` 的两个掩码里都是 0，也就是不挡路（明写的假设，见 `Obj/Board/Terrain.lean`）。
-/

import Obj.World


def Board.wallAt (b : Board) (q : Cell) : Bool := Board.bit b.wall q.r q.c
def Board.softAt (b : Board) (q : Cell) : Bool := Board.bit b.soft q.r q.c

/-- 菱形落在 p、罐子落在 c：踩没踩禁地。 -/
def blocked (b : Board) (p c : Cell) : Bool :=
  (footprint diamondOffs p).any (fun q => b.wallAt q) ||
  (footprint discOffs c).any (fun q => b.wallAt q || b.softAt q)

/-- 被驳回：世界原样（竖条那一格归 `Bar`）。 -/
def clickReject (w : World) : World := w

