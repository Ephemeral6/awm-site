/-
# Lock —— 罐子落在一个没锁的靶心上、颜色集合对得上：那个靶环锁上。

对应 `rule/什么算赢/lock.py`。身份：**定义**。

「对得上」= 罐子环上 20 格出现过的颜色集合 = 靶环的颜色集合。
环上还有 0（没装满）的罐子集合里带 0，靶环从不带 0 —— 它锁不上任何靶环。

**这一条的「颜色集合」那一半，这批语料考不动**：反向测试里把配对改成「不看颜色」，判错 0 处——
语料里罐子从没落在配不上的靶心上。写在明处。
-/

import Obj.World


/-- 两份颜色清单作为集合相等。 -/
def sameSet (xs ys : List Nat) : Bool := xs.all (ys.contains ·) && ys.all (xs.contains ·)

def pairs (ink : List Nat) : Option (List Nat) → Bool
  | none => false
  | some cs => sameSet ink cs

/-- 第 i 组的罐子落在 c 上：c 上那个没锁、配得上的靶环锁上。 -/
def lock (w : World) (i : Nat) (c : Cell) : World :=
  let ink := (w.groups.getD i ⟨[], []⟩).ink
  { w with reticles := w.reticles.map (fun t =>
      if t.center = c && pairs ink t.colors then { t with colors := none } else t) }

