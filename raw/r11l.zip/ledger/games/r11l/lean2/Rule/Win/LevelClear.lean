/-
# LevelClear —— 这一关过了 ⟺ 每一组的罐子都压在一个锁上的靶心上。

对应 `rule/什么算赢/level_clear.py`。身份：**定义**——这就是「赢」的定义，不是待证的定理。

`isGoal` 是**状态**的性质（不是一个转移事件）：这样「这个局面赢不赢得了」才问得出来。
-/

import Obj.World


def isGoal (w : World) : Bool :=
  w.groups.all (fun g => w.reticles.any (fun t => t.center = g.center && t.locked))

