"""cn04 的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测依据（第 1-18 步）：
  帧 64x64，一切物件都由 3x3 的同色块拼成，块左上角落在 row/col ≡ 2 (mod 3)。
  20x20 的块网格覆盖像素行/列 2..61；像素行 0/1 与 62/63 在网格之外（行 0 是顶栏）。
  底色是块网格里格数最多的那个色。MARK（色 8）是贴在各件末端的小方块。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 3
PHASE = (2, 2)
NB = 20
MARK = 8         # 各件末端的插头的颜色（第 0/1 关都是 8）
WELD = 3         # 两个插头重合时那一格显示的色（第 24 步实测；第 25 步分开又变回 8，可逆）
MOVER = 0        # **被选中**的那个件被画成这个色（第 28 步实测：ACTION6 点在色 9 的件上，
#                  它整件变成色 0，而原来的色 0 件露出真色 15 —— 色 0 是选中态，不是某个件的身份）


def bpos(i, j):
    return PHASE[0] + CELL * i, PHASE[1] + CELL * j


def bcell(x, y):
    """像素坐标 (x=列, y=行) 落在哪个块上；不在块网格里返回 None。"""
    j, i = (x - PHASE[1]) // CELL, (y - PHASE[0]) // CELL
    return (i, j) if 0 <= i < NB and 0 <= j < NB else None


def click_target(action):
    """把 "ACTION6:51,54" 解析成块坐标；不是带坐标的动作返回 None。"""
    if ":" not in action:
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return bcell(x, y)


def blocks(g):
    """把帧折成 20x20 块网格；块内不同色记 -1。"""
    out = []
    for i in range(NB):
        r = PHASE[0] + CELL * i
        line = []
        for j in range(NB):
            c = PHASE[1] + CELL * j
            vals = {g[r + di][c + dj] for di in range(CELL) for dj in range(CELL)}
            line.append(vals.pop() if len(vals) == 1 else -1)
        out.append(line)
    return out


def bg(bs):
    """底色 = 块网格里出现次数最多的色。"""
    cnt = {}
    for row in bs:
        for v in row:
            cnt[v] = cnt.get(v, 0) + 1
    return max(cnt, key=cnt.get)


def solid_comps(bs):
    """同色 4 连通分量（不含底色、不含 MARK、不含 WELD）。返回 [set(块坐标)]。"""
    b = bg(bs)
    out = []
    seen = set()
    for i in range(NB):
        for j in range(NB):
            v = bs[i][j]
            if v in (b, MARK, WELD) or (i, j) in seen:
                continue
            comp = {(i, j)}
            seen.add((i, j))
            stack = [(i, j)]
            while stack:
                r, c = stack.pop()
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p = (r + dr, c + dc)
                    if (0 <= p[0] < NB and 0 <= p[1] < NB and p not in seen
                            and bs[p[0]][p[1]] == v):
                        seen.add(p)
                        comp.add(p)
                        stack.append(p)
            out.append(comp)
    return out


def _mark_cells(bs):
    return [(i, j) for i in range(NB) for j in range(NB) if bs[i][j] == MARK]


def _weld_cells(bs):
    return [(i, j) for i in range(NB) for j in range(NB) if bs[i][j] == WELD]


def _nb4(p):
    """p 的 4 邻居，只给图内的——块网格有界（NB），图外没有格子，也就不可能是焊格或插头。
    曾经不设界：第 413 步 44 格糊块（p1+p3+p2 贴睡）贴着底边（行 19），边缘件的邻居 (20, j)
    让焊格扫描 `bp[q[0]][q[1]]` 越界，sleep_wake / wake_plugs 在同一条转移上双双 ERROR 关闸。
    其余调用点本来就自带 `0 <= r[0] < NB` 判断，收界对它们是零变化；deg1 里是集合成员测试，
    图外邻居从来不在 cells 里，度数也不变。"""
    i, j = p
    return tuple(q for q in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1))
                 if 0 <= q[0] < NB and 0 <= q[1] < NB)


def pieces(g, bs=None):
    """件 = 一个实心分量 + 归它的插头块（字典里插头一律记成 MARK，色 3 只是显示）。

    件与件**永不合并**：第 24 步两对插头重合显示成色 3，第 25 步一个上移就各自变回色 8，
    可动件只带走自己那 10 块 —— 「焊上了就一起动」被这一步推翻。

    插头归属：
      色 3 的格子是**两个**插头重合，贴着它的每个分量都算有一个插头在那里；
      色 8 的格子只贴着一个分量时判给那个分量；
      同时贴着两个以上分量时**判给非可动件的那个**（它至少不会跟着走），
      并由 `mover_plug_ambiguous` 单独把这种局面标出来 —— 见那个函数的说明，这时册子该闭嘴。
    """
    bs = bs if bs is not None else blocks(g)
    comps = solid_comps(bs)
    idx = {}
    for k, comp in enumerate(comps):
        for p in comp:
            idx[p] = k
    mover_k = None
    for k, comp in enumerate(comps):
        if bs[next(iter(comp))[0]][next(iter(comp))[1]] == MOVER:
            mover_k = k
    l2 = mover_k is None             # 第 2 关 regime：没有色 0，插头归唯一醒着的件
    if l2:
        awake = [k for k, comp in enumerate(comps)
                 if any(bs[p[0]][p[1]] != 4 for p in comp)]
        if len(awake) == 1:
            mover_k = awake[0]
    out = [{p: bs[p[0]][p[1]] for p in comp} for comp in comps]
    for p in _mark_cells(bs) + _weld_cells(bs):
        own = sorted({idx[q] for q in _nb4(p) if q in idx})
        if not own:
            continue
        if bs[p[0]][p[1]] == WELD:
            for k in own:
                out[k][p] = MARK
        elif len(own) == 1:
            out[own[0]][p] = MARK
        elif l2 and mover_k in own:
            out[mover_k][p] = MARK   # 醒件旁边贴着的色 8 是它自己的插头（睡眠件的插头画 4，显不出来）
        else:
            cand = [k for k in own if k != mover_k] or own
            out[cand[0]][p] = MARK
    return out


def sleepers(g, bs=None):
    """沉睡件的格集列表（实心一格全 4 的连通件，含它们盖着的隐藏插头格）。"""
    bs = bs if bs is not None else blocks(g)
    return [c for c in solid_comps(bs) if all(bs[p[0]][p[1]] == 4 for p in c)]


def sleeper_touch(g, new, bs=None):
    """可动件的落位 new 压到任何沉睡件的格子上吗（实心或隐藏插头都算）。

    第 118 步实测：可动件的插头压上沉睡件盖着的隐藏插头，那一格显色 3——焊越过沉睡照样显示；
    而没被压到的隐藏插头继续隐身（第 118 步 (15,15) 仍是 4）。隐藏插头在哪帧上读不出，
    所以「落位压到沉睡件」的局面预测不了那一格显 3 还是显 8——含糊就闭嘴，render 返回 None。
    """
    bs = bs if bs is not None else blocks(g)
    return any(q in c for c in sleepers(g, bs) for q in new)


def mover_plug_ambiguous(g, bs=None):
    """有没有色 8 的格子同时贴着可动件和别的件的实心块 —— 那就分不清这个插头归谁。

    第 36/37 步逼出来的：可动件的横臂扫到小件的插头旁边，「可动件优先」把人家的插头抢了过来，
    render 于是预测那一格跟着走，实际它一动没动（说错 27 格）。
    全量语料上考过四条归属规则（runs 里的 attrib.py）：可动件优先说错 2 条，反过来判给静止件说错 2 条（另外两条），
    「含糊就闭嘴」说错 0 条、代价是 4 条转移没人开口。选了闭嘴——预测错比不预测贵。
    """
    bs = bs if bs is not None else blocks(g)
    comps = solid_comps(bs)
    idx = {}
    mover_k = None
    for k, comp in enumerate(comps):
        for p in comp:
            idx[p] = k
        if bs[next(iter(comp))[0]][next(iter(comp))[1]] == MOVER:
            mover_k = k
    if mover_k is None:
        return False
    for p in _mark_cells(bs):
        own = {idx[q] for q in _nb4(p) if q in idx}
        if len(own) > 1 and mover_k in own:
            return True
    return False


def active(g, bs=None):
    """可动件（这一步会被 ACTION1-4/5 作用的那个件）。

    两种 regime，帧上自己可辨：
      第 1 关式：被点中的件整件画成色 0（含插头画成 8）——含 MOVER 色的件就是它；
      第 2 关式：没有色 0，场上其余件**沉睡**（实心一色 4、无插头），唯一不睡的件
        （实心里有非 4、非底色的真色）就是它。两关的移动/旋转实测同款（第 108/111 步）。
    都找不到（第 2 关全员沉睡）、或找到多个，返回 None。

    **色 0 的实心只有 1 块时，件 = 这个笔头 + 与它 4 连通的整团**（第 181-189 步实测）：
    那种局面里色 0 不是「被涂成选中色的整件」，而是一个单块的笔头，贴着它的一大团跟着一起动
    （ACTION1-4 让笔头连同那一团整体平移 1 块，21 块一起变，色 4 的沉睡件一格不动）。
    第 1 关式的辨认规则在那里认出来的只有笔头自己，于是预测「只有这 1 块动」，格格皆错。
    团的判据：从笔头出发，沿**非底色且非 4**的格子 4 连通泛洪（色 4 是沉睡件，不跟着走）。
    """
    bs = bs if bs is not None else blocks(g)
    b = bg(bs)
    cands = [p for p in pieces(g, bs) if MOVER in p.values()]
    if len(cands) == 1:
        if len([1 for v in cands[0].values() if v != MARK]) < 2:
            head = next(p for p, v in cands[0].items() if v == MOVER)
            blob = {head}
            stack = [head]
            while stack:
                p = stack.pop()
                for q in _nb4(p):
                    if (0 <= q[0] < NB and 0 <= q[1] < NB and q not in blob
                            and bs[q[0]][q[1]] not in (b, 4)):
                        blob.add(q)
                        stack.append(q)
            return {p: (MARK if bs[p[0]][p[1]] == MARK else bs[p[0]][p[1]]) for p in blob}
        return cands[0]
    b = bg(bs)
    awake = []
    for p in pieces(g, bs):
        # 单格的插头（8）/焊格（3）显示不是件：件按颜色切的时候，醒着的件身上带 Mark 会粘进
        # 件分量，但**焊格**跟它隔着颜色（第 435 步后的帧：醒着的 25 格整件 + 单格焊格 +
        # 单格插头，被数成 3 个「清醒候选」，active() 返回 None，全场从此没有可动件）。
        # 焊格是「谁醒着」的显示，不是第三个件。
        if len(p) == 1 and set(p.values()) <= {MARK, WELD}:
            continue
        solids = {v for v in p.values() if v not in (MARK,)}
        if solids == {4} or solids == {b}:
            continue
        if 4 in solids and len(solids) == 1:
            continue
        awake.append(p)
    return awake[0] if len(awake) == 1 else None


def movable(g, bs=None):
    """可动件：active() 的旧名。"""
    return active(g, bs)


PEN = 11          # 「那支笔画出来的件」的实心色（第 180-191 步：它长节/撤节，从不旋转）


def is_pen(g, bs=None):
    """醒着的件是不是那支笔画出来的件。

    为什么要这个词：ACTION5 在同一关里干两件不同的事——作用在笔件上是长节/撤节
    （第 185 步长、第 190 步撤），作用在别的醒着的件上是照旧旋转（第 195 步实测）。
    分界不是「帧上有没有笔头」：第 190 步的 prev 帧里色 0 已经没了，它照样撤节。

    判据（只看帧）：带笔头（色 0），或实心色全是 PEN。**后半句是一条会被打错的假设**——
    颜色不是「谁画的」的证据，只是这一关里它俩恰好可分；哪天出现一个色 PEN 的普通件，
    引用本词汇的概念当场吃反例。调用方自己决定在哪些关问这个问题
    （更早的关里有过色 PEN 的普通件，它照常旋转，那里不该问）。
    """
    bs = bs if bs is not None else blocks(g)
    a = active(g, bs)
    if a is None:
        return False
    if MOVER in a.values():
        return True
    return {v for v in a.values() if v != MARK} == {PEN}


def targets(g, bs=None):
    """除可动件之外的其余件。

    排除判据是 `active()` 的结果，不是「不含色 0」——第 2 关帧上没有色 0，
    激活件靠「唯一不睡的件」辨认（第 112 步排路线时暴露：旧筛法把激活件自己留在了
    静态层里，render 看见实心压真色就闭嘴，move_* 全体不开口）。

    激活件是笔头那一团时（第 4 关画图态），它由好几个 `pieces()` 分量拼成（笔头是色 0 一个分量、
    画出来的实体是另一个），`p != a` 逐个比对认不出来，静态层会把自己的身子当成别人、跟落位撞车。
    所以再排一刀：**格集整个落在激活件里的分量也是激活件的一部分**。
    焊住的靶件不会被误伤——它有自己的实心，不是激活件的子集。"""
    bs = bs if bs is not None else blocks(g)
    a = active(g, bs)
    if a is None:
        return list(pieces(g, bs))
    ac = set(a)
    return [p for p in pieces(g, bs) if p != a and not set(p) <= ac]


def marks(d):
    return sorted(p for p, v in d.items() if v == MARK)


def anchor(m):
    return min(p[0] for p in m), min(p[1] for p in m)


def norm(m):
    r0, c0 = anchor(m)
    return {(r - r0, c - c0): v for (r, c), v in m.items()}


def rot_cw_shape(m):
    """绕自身 bbox 左上角顺时针 90°，仍以 bbox 左上角为原点。"""
    n = norm(m)
    h = max(r for r, _ in n) + 1
    return {(c, h - 1 - r): v for (r, c), v in n.items()}


def place(m, r0, c0):
    return {(r + r0, c + c0): v for (r, c), v in m.items()}


def to_pixels(m):
    out = {}
    for (i, j), v in m.items():
        r, c = bpos(i, j)
        for di in range(CELL):
            for dj in range(CELL):
                out[(r + di, c + dj)] = v
    return out


def me(g):
    m = movable(g)
    if m is None:
        return None
    return bpos(*anchor(m))


DELTA = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def placed(g, action, bs=None):
    """按 move_*/rot_cw 的主张算可动件这一步的落位（块字典）；算不出来返回 None。"""
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    if m is None:
        return None
    if action == "ACTION5":
        return place(rot_cw_shape(m), *anchor(m))
    d = DELTA.get(action)
    if d is None:
        return None
    return {(r + d[0], c + d[1]): v for (r, c), v in m.items()}


def pairing(g, action, bs=None):
    """这一步的插头配对情况。

    返回 (落位, 这一步新重合的格, 走完这一步还没配上对的插头格)。
    **按格计重数**：一个格子上落了两个插头就算配上了对（帧上显示成 WELD），落一个就是自由插头。
    `pieces()` 已经把 WELD 格同时判给贴着它的每个分量，所以对各件的插头求和天然得到重数。
    插头总数在一关里守恒（第 1 关 12 个）。算不出来返回 (None, None, None)。

    **场上有沉睡件就返回 None**（第 118 步后的决定）：睡眠件的隐藏插头帧上不可见，
    「还剩几个没配」数不出来——硬数只会把赢步数成没赢（goal_needs_dock 会在换关那步假摔）。
    沉睡 regime 里配没配光，册子暂时不开口。

    早先这里写成「别的件的插头集合减去可动件这一步压上的」，那是只有可动件会焊时的写法：
    两个**靶件**互相焊上之后，那个格子在集合里只剩一份，被当成还没配对，
    于是「最后一步配光」永远算不出来。改成按重数计。
    """
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    new = placed(g, action, bs)
    if m is None or new is None or mover_plug_ambiguous(g, bs):
        return None, None, None
    if sleepers(g, bs):
        return None, None, None          # 隐藏插头看不见，配对数不出来
    cnt = {}
    for t in targets(g, bs):
        for q in marks(t):
            cnt[q] = cnt.get(q, 0) + 1
    others = set(cnt)
    mine_new = set(marks(new))
    for q in mine_new:
        cnt[q] = cnt.get(q, 0) + 1
    welds = mine_new & others
    rest = {q for q, c in cnt.items() if c == 1}
    return new, welds, rest


def clears_level(g, action, bs=None):
    """这一步是否把场上最后剩的插头都配上对 —— 按 goal_dock_wins 的主张，这时会换关、整帧换掉，
    所以 move_*/rot_cw 的 apply 在这种步上不该生成任何格子。"""
    new, welds, rest = pairing(g, action, bs)
    return bool(new is not None and welds and not rest)


def dock_undecidable(g, action, bs=None):
    """沉睡 regime 里「这一步会不会把最后一对插头配上」——册子答不出的那一类局面。

    为什么要单写：`pairing` 有沉睡件时返回 None（隐藏插头在帧上读不出来），于是
    `clears_level` 一律为假，生成器就按「没换关」逐格生成。真换了关整帧重画，那些格子全错。
    答不出该闭嘴，不该当成「答案是否」——这两件事在代码里长得一模一样，是这个坑的全部难处。

    判据只看帧，尽量窄，三条同时成立才闭嘴：
      1. 场上有沉睡件（没有的话 pairing 数得出来，走 clears_level）；
      2. 可动件之外没有自由插头（帧上没有不属于可动件的色 MARK）——只要还剩一个，
         依 goal_needs_dock 这一步就一定不换关，照常生成；
      3. 可动件这一步的每个插头都落到**非底色**的格子上（有可能全部成焊）。
         这一条起初写成「落到别的件占着的格子上」，漏掉了一整类：可动件画在最上面，
         沉睡件被它盖住的那些格子在帧上显的是可动件的色，`targets()` 看不见——
         而插头正可能藏在那底下。落到底色上才是真的什么都没有、那个插头一定还自由。
    差一条就说明这一步一定不换关，生成器照常说话。
    """
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    if m is None or not sleepers(g, bs):
        return False
    new = placed(g, action, bs)
    if new is None:
        return False
    mine = set(m)
    if any(bs[i][j] == MARK and (i, j) not in mine
           for i in range(NB) for j in range(NB)):
        return False                     # 还剩自由插头，一定不换关
    mine_new = marks(new)
    if not mine_new:
        return False
    b = bg(bs)
    return all(0 <= i < NB and 0 <= j < NB and bs[i][j] != b for (i, j) in mine_new)


def may_clear(g, action, bs=None):
    """这一步有没有可能换关。换关会整帧重画，所以生成器在这种步上一律闭嘴。

    数得出来时就是 `clears_level`；沉睡 regime 里数不出来时按 `dock_undecidable` 保守判。
    """
    bs = bs if bs is not None else blocks(g)
    return clears_level(g, action, bs) or dock_undecidable(g, action, bs)



def static_layer(g, bs=None):
    """除可动件之外的一切，画成 20x20 块网格（空处填底色，插头画成 MARK）。

    两个**靶件**彼此焊住的格子画成 WELD：按「几个靶件的插头落在这格」计重数，≥2 就是焊。
    （pieces() 把色 3 一律记成 MARK，平铺时那份信息会丢；第 88/89 步两个靶件焊着、
    可动件在别处动，render 把焊格画回 8，被 move_down 判了 FALSE。可动件自己参与的那份
    不在这里 —— 它落位后的重合由 render 画 new 那一段负责。）

    **显示跟可见性走**（第 118/119 步）：靶件的插头格，主人全在沉睡就画 4（隐藏插头不显形，
    焊也跟着隐——第 119 步 (10,10) 沉睡后显 4），有醒着的才画 MARK；多重插头照旧画 WELD。
    第 1 关没有沉睡件，这条规则退化成原画法，一字不变。"""
    bs = bs if bs is not None else blocks(g)
    b = bg(bs)
    grid = [[b] * NB for _ in range(NB)]
    cnt = {}
    hidden = {}
    for t in targets(g, bs):
        t_asleep = all(v == 4 for v in t.values() if v != MARK)
        for (i, j), v in t.items():
            if v == MARK:
                cnt[(i, j)] = cnt.get((i, j), 0) + 1
                hidden[(i, j)] = hidden.get((i, j), True) and t_asleep
            else:
                grid[i][j] = v
    for (i, j), c in cnt.items():
        if c >= 2:
            grid[i][j] = 4 if hidden[(i, j)] else WELD
        else:
            grid[i][j] = 4 if hidden[(i, j)] else MARK
    return grid


def render(g, new, bs=None):
    """可动件落到 new、别的件一格不动时，块网格应该长什么样。

    让出的格子显示底下原本有的东西（别的件的插头，或底色）；两个插头重合的格子显示 WELD。
    可动件的实心块撞上别的件的任何块时返回 None —— 那种局面册子还没见过。
    有插头分不清归谁时（`mover_plug_ambiguous`）也返回 None —— 连谁跟着走都说不准，画不出来。

    可动件的插头落点分三种（第 155 步打脸后补全——可动件自己带着焊格转，焊格在 prev 显 3、
    被 static_layer 重画成 4，旧画法画成 8）：
      落在**可见插头或既有焊上**（静态层画 8、或 prev 就显 3）→ 几何上就是焊，可动件醒着，显 WELD；
      落在**沉睡件的格子上**（静态层画 4 且底色不是 4）→ 那一格是不是隐藏插头帧上读不出
        （第 118 步的老问题），含糊闭嘴返回 None；
      落在空地上 → 显 8。
    """
    bs = bs if bs is not None else blocks(g)
    if mover_plug_ambiguous(g, bs):
        return None
    if sleeper_touch(g, new, bs):
        return None                      # 压到沉睡件：那一格显 3 还是显 8 读不出（第 118 步）
    b = bg(bs)
    grid = static_layer(g, bs)
    m = movable(g, bs)
    sl = sleepers(g, bs) if m is not None else []
    if sl:
        for p in set(m) - set(new):
            # 让出的格子：静态层以为是底色、却贴着沉睡件 —— 它可能是被可动件盖住的
            # 沉睡块（让出后显 4），也可能真是空地（显底色）。帧上读不出，闭嘴。
            # （第 178 步打脸：可动件的实心盖住沉睡件的格，prev 那里显可动件的色、
            # 被算进可动件的连通域；让出时世界显 4，render 画了底色。）
            if grid[p[0]][p[1]] == b and any(q in c for c in sl for q in _nb4(p)):
                return None
    for (i, j), v in new.items():
        if not (0 <= i < NB and 0 <= j < NB):
            return None
        if v == MARK:
            if grid[i][j] == MARK or bs[i][j] == WELD:
                grid[i][j] = WELD        # 可见插头/既有焊：醒着的可动件参与，焊照样显 3
            elif grid[i][j] == 4 and b != 4:
                return None              # 沉睡件的格子：隐藏插头读不出（第 118 步）
            else:
                grid[i][j] = MARK
        else:
            if grid[i][j] != b:
                return None
            grid[i][j] = v
    return grid


# =====================================================================================
# 修复副本（meta/repair-20260928，2026-09-29）新增段。上面的原文一字未改。
#
# 1. 新读数（只从这一帧像素算）：
#    cells(g)     整个 20x20 块网格里非底色的格 → 颜色（生成器编成 cells_m 与每色一个 cells_m_c<色>）
#    hud_spent(g) 顶栏第 0 行第 16..47 列里已花掉（色 0）的格数
# 2. 让以下原读数退出抽象状态（改成 *args 签名，内部调用照旧）：
#    active, movable, me, is_pen, mover_plug_ambiguous, pieces, sleepers, solid_comps, targets。
#    它们都是 blocks(g)（solid_comps 另加第 0 行像素）的确定函数，而 cells + bg + hud_spent 能还原
#    blocks(g) 与第 0 行——证明脚本 _scratch/cn04-20260909/exit_proof.py 在全部帧上按新状态分组、组内唯一。
# 3. 隐藏状态 HIDDEN_INIT / hidden_step 与每关常数 LEVEL_CONST（修订 R1），见下。
# =====================================================================================

def cells(g):
    """块网格里非底色的格及其颜色（底色 = 整帧最多的像素色）。"""
    bs = blocks(g)
    b = bg(g)
    return {(i, j): bs[i][j] for i in range(NB) for j in range(NB) if bs[i][j] != b}


def hud_spent(g):
    """顶栏（像素第 0 行第 16..47 列）里色 0 的格数。"""
    return sum(1 for v in g[0][16:48] if v == 0)


def _exit(f):
    def wrapped(*args, **kw):
        return f(*args, **kw)
    wrapped.__doc__ = f.__doc__
    return wrapped


active = _exit(active)
movable = _exit(movable)
me = _exit(me)
is_pen = _exit(is_pen)
mover_plug_ambiguous = _exit(mover_plug_ambiguous)
pieces = _exit(pieces)
sleepers = _exit(sleepers)
solid_comps = _exit(solid_comps)
targets = _exit(targets)


# ---- 隐藏状态 -----------------------------------------------------------------------
# 件以「真色」为身份（每关各件真色互不相同）。帧上看不见的东西有三类：
#   · 不在上层的件（第 0/1 关：被选中色盖住前的真色；沉睡关：通体色 4，插头与真色都看不见）的格局；
#   · 第 0/1 关当前选中件的真色（它被画成色 0）；
#   · 本关已按了几次 ACTION5（笔 / 伸缩件的进度是它的三角波）。
# hidden_step 只做「记账」：件离开上层那一刻把它的格局（前帧可见）记下，件回到上层那一刻清掉记录；
# 按键计数；步数计数。它不预测任何东西——下一帧会怎样全由 Lean 规则从这些记录 + LEVEL_CONST 算。
PIECE_COLS = (9, 10, 11, 12, 14, 15)

HIDDEN_INIT = {"steps": 0, "has": 0, "sel": -1,
               **{f"s{c}": 0 for c in PIECE_COLS}, **{f"p{c}": 0 for c in PIECE_COLS},
               **{f"n{c}": 0 for c in PIECE_COLS}}


def _mask(cs):
    m = 0
    for r, c in cs:
        m |= 1 << (r * 32 + c)
    return m


def _sleep_top(bs, b):
    """沉睡画法下的上层件：非底色、非 4 的格。返回 (实心+笔头格, 插头格, 真色或 None)。"""
    sol, plg, cols = set(), set(), set()
    for i in range(NB):
        for j in range(NB):
            v = bs[i][j]
            if v in (b, 4):
                continue
            if v in (MARK, WELD):
                plg.add((i, j))
            else:
                sol.add((i, j))
                if v != MOVER:
                    cols.add(v)
    return sol, plg, (cols.pop() if len(cols) == 1 else None)


def hidden_step(h, prev, action, nxt):
    h = dict(h)
    h["steps"] += 1
    act = action.split("|")[0]
    bp, bn = blocks(prev), blocks(nxt)
    b = bg(prev)
    sleep = any(v == 4 for row in bp for v in row)
    if sleep:
        sp, pp, cp = _sleep_top(bp, b)
        if act == "ACTION5" and cp is not None:
            h[f"n{cp}"] += 1
        if act.startswith("ACTION6"):
            _, _, cn = _sleep_top(bn, b)
            if cp != cn:
                if cp is not None:
                    h[f"s{cp}"], h[f"p{cp}"] = _mask(sp), _mask(pp)
                    h["has"] |= 1 << cp
                if cn is not None:
                    h[f"s{cn}"], h[f"p{cn}"] = 0, 0
                    h["has"] |= 1 << cn
    elif act.startswith("ACTION6"):
        z0 = {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] == MOVER}
        z1 = {(i, j) for i in range(NB) for j in range(NB) if bn[i][j] == MOVER}
        if z0 != z1 and z0 and z1:
            pc = {bn[i][j] for (i, j) in z0 - z1} - {MOVER, MARK, WELD, b}
            qc = {bp[i][j] for (i, j) in z1 - z0} - {MOVER, MARK, WELD, b}
            plugs = {q for p in z0 for q in _nb4(p) if bp[q[0]][q[1]] in (MARK, WELD)}
            if len(pc) == 1 and len(qc) == 1:
                pc, qc = pc.pop(), qc.pop()
                h[f"s{pc}"], h[f"p{pc}"] = _mask(z0), _mask(plugs)
                h["has"] |= (1 << pc) | (1 << qc)
                h[f"s{qc}"], h[f"p{qc}"] = 0, 0
                h["sel"] = qc
    return h


# ---- 每关常数（游戏内容，和换关后的布局同类）------------------------------------------------
# 全部由 _scratch/cn04-20260909/gen_content.py 从 runs/cn04-0907-1226 的帧反推（model2.py 做推断，sim.py 用它们
# 逐步重放全部 742 条非 RESET 转移，块网格 742/742 逐格吻合、换关与否 742/742 吻合）：
#   s<c>/p<c>：开关时静置（不在上层）的件的实心格 / 插头格掩码（格 (r,c) 在第 32r+c 位）。
#     第 0/1 关：直接读开关帧（第 0 关 seq 1/44/304/485、第 1 关 seq 19/62/320/499 四次开关帧逐格相同），插头按相邻归属。
#     第 2~5 关：沉睡件在开关帧上通体画 4；真色与插头取自它本关第一次被点醒那一帧（沉睡件不会动，醒来时的布局就是开关布局）：
#       第 2 关 f seq 106、b seq 111；第 3 关 e 145、c 146、b 147；第 4 关 e 193、a 194、c 195；第 5 关 c 244、b 245、a 246、f 247。
#       每个件的格集都等于开关帧上对应的色 4 块（第 3 关 b 与 a 的插头在 (15,5) 重合）。
#   sel：第 0/1 关开关时被画成色 0 的那个件的真色，取自第一次换人那步 nxt 里它露出的颜色（第 0 关 12，第 1 关 15）；沉睡关 -1。
#   sleep：1 = 沉睡画法（开关帧上有色 4），0 = 选中色画法。
#   budget：顶栏花格 = floor(steps·32/budget + 1/2)，steps = 本关已走步数（每个动作都算）。逐关在全部关内转移上反推（hudfit.py）：
#     第 0 关 {74,75} 取 75；第 1 关唯一 100；第 2 关 {125..128} 取 125；第 3 关唯一 125；第 4 关唯一 150；第 5 关唯一 200。
#   a11/L11、a15/L15：第 4/5 关的笔（色 11）与第 5 关的伸缩件（色 15）各节布局（关卡坐标）与最后一节的编号。
#     编码：以 4096 为底的数位流（低位在前），每节依次列出格码 1024·类 + 32r + c（类 1 实心、2 插头、3 笔头），节尾一个 0。
#     取自该件当可动件时每次 ACTION5 前后的帧（第 4 关笔 seq 182–203、659–662；第 5 关笔 245–272、705–710，伸缩件 247–256、713–716）：
#     同一按键计数下看到的布局全部相同，按键计数 n 对应第 tri(n, L) 节（走到头折返的三角波）；件被平移过时先扣掉平移再记。
LEVEL_CONST = {
    0: {
        's9': 0,
        'p9': 0,
        's10': 0,
        'p10': 0,
        's11': 0,
        'p11': 0,
        's12': 0,
        'p12': 0,
        's14': 179013548899091572670426044019075575131066397762329217895195175427912639926436660910436516731669253463198840321282292996565923752428823360819962052608,
        'p14': 693167423530203714932180227360152257505340958392583536230630815936188444882723061304508945927868629619766986714507192205754499072,
        's15': 0,
        'p15': 0,
        'sleep': 0,
        'sel': 12,
        'budget': 75,
        'a11': 0,
        'L11': 0,
        'a15': 0,
        'L15': 0,
    },
    1: {
        's9': 113463316355459463333431359284012960627937921117463740086338457250609819313299827940077733880078003000956204799735097829359936636717143654224655696908110865825242670155007002673152,
        'p9': 4393470502483590217588416511412091659052438592091715462012456613878747637374499873358438170023330915185469639290547749143758072319818652040047378106313636577280,
        's10': 0,
        'p10': 0,
        's11': 12013395907526173934646296946830657361248915091766863606543980311022954909692714082281743802498867702242220186166131299188789220269455675877173284233510125568,
        'p11': 14742040721959145907193572581997054774732953227542118122814156502932294312461080198604100568081731301000028604572023808141850117665269386731801832308287321704327282688,
        's12': 0,
        'p12': 0,
        's14': 131235043503277003276820297498216648052699645413273868690713717052366387966972418387678192064777945088,
        'p14': 2037035983923036446525199872099902373911140633282155447622530736275341421282488626479890432,
        's15': 0,
        'p15': 0,
        'sleep': 0,
        'sel': 15,
        'budget': 100,
        'a11': 0,
        'L11': 0,
        'a15': 0,
        'L15': 0,
    },
    2: {
        's9': 0,
        'p9': 0,
        's10': 0,
        'p10': 0,
        's11': 21603846911076541168362727076628100208918528,
        'p11': 348449146323189415853909412275378813140992,
        's12': 0,
        'p12': 0,
        's14': 0,
        'p14': 0,
        's15': 100695121251273312506428775871448419878260113633382015234433604010171400819746227998848953763769863059488923052141553105467535431526894069560836620288,
        'p15': 23817051317718446589520242536874132581700120107002547458297954468272755304321925496092891216887021000357725343106468713851002660342990897152,
        'sleep': 1,
        'sel': -1,
        'budget': 125,
        'a11': 0,
        'L11': 0,
        'a15': 0,
        'L15': 0,
    },
    3: {
        's9': 0,
        'p9': 0,
        's10': 0,
        'p10': 0,
        's11': 199791907220223502808422222706762643567910281130558153654986045416023791284464999687699590596063486154228923591770023865308670443474450259602571264,
        'p11': 499479768050558757021055556766906608919775702826395384137465113540059478211162499219248976490158715385572308979425059663271676108686125649006428160,
        's12': 56731658177729731668912414893759742705366026238254886371490052909603086168836874922718125345043053129131694539172829138265667563030174410346071431342489082814029575931680765509632,
        'p12': 4052261297735344686047273304385899561535592023677027454846129925885606550329561195421900352062781865684738728224463048243738390345121786230212415783286808874107088926713260802048,
        's14': 14259251836712824592011495209012181046873706799522042043988683622984167582741043203037724672,
        'p14': 218543574019222677473706844558398113943019607154459825600987136,
        's15': 0,
        'p15': 0,
        'sleep': 1,
        'sel': -1,
        'budget': 125,
        'a11': 0,
        'L11': 0,
        'a15': 0,
        'L15': 0,
    },
    4: {
        's9': 0,
        'p9': 0,
        's10': 335233399620165050775195712191724350308775585915076608,
        'p10': 604462910370264540774400,
        's11': 0,
        'p11': 0,
        's12': 13208868487314741783093800055217782769350433437362785358525893597060930229760395746038893525457649503397472404126220421078251821119112581445946885084019173963404247302144,
        'p12': 1757388201095729543532121038002748841646837910343456248743828420222851910202804130481021347849434556459372360627184308536489481146965500083077869775441971118080,
        's14': 80446847585899079702437166798110373224015489702221331270779612141165811341889156953431145621110605837762787135412631700143531495671448633040037801814392832,
        'p14': 107262463439540776802406909780011624144544733077414339130315854756073805633280935322023832263585997155363749045373974616207445365384781308166199029000044544,
        's15': 0,
        'p15': 0,
        'sleep': 1,
        'sel': -1,
        'budget': 150,
        'a11': 1198878248538244762966385912465008468485158572148557001405363806919582038075216659834370907214039666353422406257865935779590208377239656368157293628727930499599531413165259680124759808095512982760834931206428987822350183543386473913683097067154462530946123882946004104,
        'L11': 4,
        'a15': 0,
        'L15': 0,
    },
    5: {
        's9': 0,
        'p9': 0,
        's10': 115172193167121443266078477097994847495168807380193384958500715406060168748118710777805971378137904539019685985490556084336781581837634352507906136305473226025205760,
        'p10': 230344386280611654799899571593522271174128492457136935627151474276150642210580466187945042607060142779411847211244761273851257643264136676587005808541909645363511296,
        's11': 273406340661533864821836856018320690966342178156774127853915929849502169597552556606300086125723648,
        'p11': 7410693711188236508715481084815016378151241110942158701047488370289233132257280,
        's12': 89202980814891680005722349795092324952309760,
        'p12': 44601490399657394712338850359561971176570880,
        's14': 0,
        'p14': 0,
        's15': 7851256265364689098680513022615862965814476873618418634770766170578963449372681840970755473293513864945236712421409344770060536550351666060221349361012713732216484830939300495360,
        'p15': 29484081443918291814387145171413679247075461593728516639462278152450226302126799844205324680060205431698916414788038897588396603763495663690051867128712258518024978432,
        'sleep': 1,
        'sel': -1,
        'budget': 200,
        'a11': 27106828105730442772353384563903216481350188390068235469283474655928609607866896810591282220674862460566249156308141003662879867116015754260790731598678959477575597542842022624186774948330671063109404869709826937113428606039660881417073917126921060873621992083139435594038963051771997209286940748957474918139111,
        'L11': 5,
        'a15': 320006661948087557342278780756299139588392534263491774301118779046345811116098290500387763651647857538927112053052459545769962822809295491583481349293399459285978319976229643769795141522663141866684833136141521123041218685723857396858145199524219083917098678670827,
        'L15': 3,
    },
}
