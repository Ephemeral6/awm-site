/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    方向键  → Move       ACTION5 → 普通件 Turn / 笔 Grow（没有选中件就什么也不动）
    点击    → Pick
    然后    → 走了一步（Hud 的 tick），走完是赢的局面（Win 的 isGoal）就是 `won`

注意 `step` 的类型里**没有 `Board`**：空地色、画法、预算它碰都碰不到。
-/
import Rule.Step.Move
import Rule.Step.Turn
import Rule.Step.Grow
import Rule.Pick.Pick
import Rule.Goal.Win
import Rule.Budget.Hud

namespace Game

def five (s : World) : World :=
  match s.sel with
  | none => s
  | some i => if (s.piece i).isPen then grow s i else turn s i

def settle (s : World) : Res :=
  if isGoal (tick s) then .won (tick s) else .ok (tick s)

def step (s : World) : Act → Res
  | .up => settle (move (-1, 0) s)
  | .down => settle (move (1, 0) s)
  | .left => settle (move (0, -1) s)
  | .right => settle (move (0, 1) s)
  | .five => settle (five s)
  | .click x y => settle (pick s x y)

end Game
