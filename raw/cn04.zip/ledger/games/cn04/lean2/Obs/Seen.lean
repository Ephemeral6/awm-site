/-
# Obs/Seen —— 世界画到帧上是什么样（模型面对现实的那一侧）

帧上看得见的只有这些：顶栏花掉几格，以及每个非空地格显什么色。Python 那边
`objects/parse.py` 从像素读出的正是这一份（`World.color_at` 逐格查表），
导出器把它写进 `Replay.lean`，**这里不从 Python 抄任何算法**——画法在下面独立写一遍，
两边对不对得上由逐帧核对来判。

## 画法（选中那件在最上面）

    选中那件    笔头 0 > 插头（叠着 ≥ 2 个插头显 3，否则 8）> 实心（'paint' 画法显 0，'sleep' 显真色）
    其余的件    插头优先：'sleep' 一律显 4；'paint' 叠着 ≥ 2 个显 3，否则 8
                否则按次序最后一件的笔头 / 实心：'sleep' 显 4；'paint' 显 0（笔头）/ 真色
    都没有      空地色
-/
import Step

namespace Game

structure Seen where
  spent : Nat
  cells : List (Int × Int × Nat)
  deriving DecidableEq, Repr

/-- 其余的件（不是选中那件）在 p 这一格画出来的颜色。 -/
def underColor (b : Board) (s : World) (p : Cell) (w : Nat) : Nat :=
  let others := (List.range s.pieces.length).filter (fun i => s.sel != some i)
  if others.any (fun i => (s.piece i).cur.plugs.contains p) then
    (match b.look with | .sleep => 4 | .paint => w)
  else
    others.foldl (fun acc i =>
      let sh := (s.piece i).cur
      if sh.head == some p then (match b.look with | .sleep => 4 | .paint => 0)
      else if sh.solid.contains p then (match b.look with | .sleep => 4 | .paint => (s.piece i).color)
      else acc) b.ground

/-- p 这一格显什么色。 -/
def colorAt (b : Board) (s : World) (p : Cell) : Nat :=
  let w := if plugCount s p ≥ 2 then 3 else 8
  match s.sel with
  | none => underColor b s p w
  | some i =>
    let sh := (s.piece i).cur
    if sh.head == some p then 0
    else if sh.plugs.contains p then w
    else if sh.solid.contains p then (match b.look with | .paint => 0 | .sleep => (s.piece i).color)
    else underColor b s p w

def pieceCells (s : World) : List Cell :=
  s.pieces.flatMap (fun q => q.cur.solid ++ q.cur.plugs ++ q.cur.head.toList)

def inGrid (p : Cell) : Bool := decide (0 ≤ p.1 ∧ p.1 < 20 ∧ 0 ≤ p.2 ∧ p.2 < 20)

/-- **这个世界画出来就是这一帧吗。** 三件都要对：顶栏；帧上每个非空地格的颜色；
    世界里每一格件（在网格里的）帧上都有。后两件合起来就是「两张图逐格相等」。 -/
def seenOk (b : Board) (s : World) (o : Seen) : Bool :=
  spentOf b s.ticks == o.spent &&
  o.cells.all (fun t => t.2.2 != b.ground && colorAt b s (t.1, t.2.1) == t.2.2) &&
  (pieceCells s).all (fun p => !inGrid p || o.cells.any (fun t => (t.1, t.2.1) == p))

end Game
