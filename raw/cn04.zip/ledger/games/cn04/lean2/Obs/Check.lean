/-
# Obs/Check —— **判据层**：两把尺子，**0 条定理**（尺子不自证，它只是被用）

    agrees    **一条转移**对不对：从这一帧的纤维里取一个世界，算一步，和看到的下一帧比
    traceOk   **一整条路**对不对：从开局起带着自己算出来的状态往下走，逐帧比

    agrees   每一步都**从观测拉回来**——模型每步都被拉回正轨
    traceOk  只有开局那一帧是给的，**后面全是模型自己算的**

## 纤维：一帧对应一组世界

帧上读不出的几位（沉睡件的真色与插头、笔的剩余几节与方向、这一关走了几步）让一帧对应一组世界。
逐条那一层按纤维判：每一步给一个世界 `pre`，**先核它确实画得出这一帧**（`seenOk b pre prev`），
再算一步去比下一帧。所以「有一个对上了 ⇒ 对」里的「有一个」是被核过属于这一帧的。

三值，不是两值：`na` 只给 RESET（模型不描述那一步），**不许混进 `yes`**。
-/
import Obs.Seen

namespace Game

inductive Next where
  | frame (o : Seen)     -- 一关之内：下一帧
  | won                  -- 过关 / 通关：下一帧是另一张盘，只核「赢了」
  | reset                -- RESET：模型不描述
  deriving DecidableEq, Repr

inductive Verdict where
  | yes | no | na
  deriving DecidableEq, Repr

structure Case where
  seq   : Nat
  board : Board
  pre   : World
  act   : Act
  prev  : Seen
  next  : Next

def agrees (c : Case) : Verdict :=
  match c.next with
  | .reset => .na
  | .frame o =>
    if !seenOk c.board c.pre c.prev then .no else
    (match step c.pre c.act with
     | .ok s' => if seenOk c.board s' o then .yes else .no
     | .won _ => .no)
  | .won =>
    if !seenOk c.board c.pre c.prev then .no else
    (match step c.pre c.act with
     | .won _ => .yes
     | .ok _ => .no)

/-- 一批转移的判决计数 (对上, 判错, 闭嘴)。**三个数分开报**，闭嘴不许并进对上。 -/
def stepVerdicts (cs : List Case) : Nat × Nat × Nat :=
  cs.foldl (fun acc c =>
    match agrees c with
    | .yes => (acc.1 + 1, acc.2.1, acc.2.2)
    | .no => (acc.1, acc.2.1 + 1, acc.2.2)
    | .na => (acc.1, acc.2.1, acc.2.2 + 1)) (0, 0, 0)

/-- 只给读数用：判错的那几条的 seq。 -/
def badSeqs (cs : List Case) : List Nat := (cs.filter (fun c => agrees c == .no)).map Case.seq

def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match step s a with
    | .ok s' => seenOk b s' o && traceOk b s' rest
    | .won _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，它不是定理。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match step s a with
    | .ok s' => if seenOk b s' o then firstSplit b s' rest (i + 1) else some i
    | .won _ => some i

end Game
