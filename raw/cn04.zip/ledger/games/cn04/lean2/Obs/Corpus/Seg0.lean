/-
# Obs/Corpus/Seg0 —— 逐条那一层，第 0 段（`lean2/export_corpus.py` 生成，不要手改）

段的身份：guid fdfe3f68-6d74-404f-8134-8d8db246a744，seq 1–42，42 条转移；成绩单没有认证这一段。

每一条：前一帧的世界取纤维见证（`Witness.w<seq>`），**先核它画得出前一帧**，再算一步去比下一帧。
过关那一步只核「赢了」；RESET 那一步模型不描述，判 `na`，条数写在定理里。
-/
import Obs.Replay
import Obs.Witness

namespace Game
namespace Corpus

-- 独立一条命令（夹在文档注释和定理之间会变成语法错误）
set_option maxRecDepth 200000


def seg0 : List Case := [
  ⟨1, Witness.board0, Witness.w1, (Replay.r1.act.getD .five), Replay.r1.prev, (.frame Replay.r1.next)⟩,
  ⟨2, Witness.board0, Witness.w2, (Replay.r2.act.getD .five), Replay.r2.prev, (.frame Replay.r2.next)⟩,
  ⟨3, Witness.board0, Witness.w3, (Replay.r3.act.getD .five), Replay.r3.prev, (.frame Replay.r3.next)⟩,
  ⟨4, Witness.board0, Witness.w4, (Replay.r4.act.getD .five), Replay.r4.prev, (.frame Replay.r4.next)⟩,
  ⟨5, Witness.board0, Witness.w5, (Replay.r5.act.getD .five), Replay.r5.prev, (.frame Replay.r5.next)⟩,
  ⟨6, Witness.board0, Witness.w6, (Replay.r6.act.getD .five), Replay.r6.prev, (.frame Replay.r6.next)⟩,
  ⟨7, Witness.board0, Witness.w7, (Replay.r7.act.getD .five), Replay.r7.prev, (.frame Replay.r7.next)⟩,
  ⟨8, Witness.board0, Witness.w8, (Replay.r8.act.getD .five), Replay.r8.prev, (.frame Replay.r8.next)⟩,
  ⟨9, Witness.board0, Witness.w9, (Replay.r9.act.getD .five), Replay.r9.prev, (.frame Replay.r9.next)⟩,
  ⟨10, Witness.board0, Witness.w10, (Replay.r10.act.getD .five), Replay.r10.prev, (.frame Replay.r10.next)⟩,
  ⟨11, Witness.board0, Witness.w11, (Replay.r11.act.getD .five), Replay.r11.prev, (.frame Replay.r11.next)⟩,
  ⟨12, Witness.board0, Witness.w12, (Replay.r12.act.getD .five), Replay.r12.prev, (.frame Replay.r12.next)⟩,
  ⟨13, Witness.board0, Witness.w13, (Replay.r13.act.getD .five), Replay.r13.prev, (.frame Replay.r13.next)⟩,
  ⟨14, Witness.board0, Witness.w14, (Replay.r14.act.getD .five), Replay.r14.prev, (.frame Replay.r14.next)⟩,
  ⟨15, Witness.board0, Witness.w15, (Replay.r15.act.getD .five), Replay.r15.prev, (.frame Replay.r15.next)⟩,
  ⟨16, Witness.board0, Witness.w16, (Replay.r16.act.getD .five), Replay.r16.prev, (.frame Replay.r16.next)⟩,
  ⟨17, Witness.board0, Witness.w17, (Replay.r17.act.getD .five), Replay.r17.prev, (.frame Replay.r17.next)⟩,
  ⟨18, Witness.board0, Witness.w18, (Replay.r18.act.getD .five), Replay.r18.prev, .won⟩,
  ⟨19, Witness.board1, Witness.w19, (Replay.r19.act.getD .five), Replay.r19.prev, (.frame Replay.r19.next)⟩,
  ⟨20, Witness.board1, Witness.w20, (Replay.r20.act.getD .five), Replay.r20.prev, (.frame Replay.r20.next)⟩,
  ⟨21, Witness.board1, Witness.w21, (Replay.r21.act.getD .five), Replay.r21.prev, (.frame Replay.r21.next)⟩,
  ⟨22, Witness.board1, Witness.w22, (Replay.r22.act.getD .five), Replay.r22.prev, (.frame Replay.r22.next)⟩,
  ⟨23, Witness.board1, Witness.w23, (Replay.r23.act.getD .five), Replay.r23.prev, (.frame Replay.r23.next)⟩,
  ⟨24, Witness.board1, Witness.w24, (Replay.r24.act.getD .five), Replay.r24.prev, (.frame Replay.r24.next)⟩,
  ⟨25, Witness.board1, Witness.w25, (Replay.r25.act.getD .five), Replay.r25.prev, (.frame Replay.r25.next)⟩,
  ⟨26, Witness.board1, Witness.w26, (Replay.r26.act.getD .five), Replay.r26.prev, (.frame Replay.r26.next)⟩,
  ⟨27, Witness.board1, Witness.w27, (Replay.r27.act.getD .five), Replay.r27.prev, (.frame Replay.r27.next)⟩,
  ⟨28, Witness.board1, Witness.w28, (Replay.r28.act.getD .five), Replay.r28.prev, (.frame Replay.r28.next)⟩,
  ⟨29, Witness.board1, Witness.w29, (Replay.r29.act.getD .five), Replay.r29.prev, (.frame Replay.r29.next)⟩,
  ⟨30, Witness.board1, Witness.w30, (Replay.r30.act.getD .five), Replay.r30.prev, (.frame Replay.r30.next)⟩,
  ⟨31, Witness.board1, Witness.w31, (Replay.r31.act.getD .five), Replay.r31.prev, (.frame Replay.r31.next)⟩,
  ⟨32, Witness.board1, Witness.w32, (Replay.r32.act.getD .five), Replay.r32.prev, (.frame Replay.r32.next)⟩,
  ⟨33, Witness.board1, Witness.w33, (Replay.r33.act.getD .five), Replay.r33.prev, (.frame Replay.r33.next)⟩,
  ⟨34, Witness.board1, Witness.w34, (Replay.r34.act.getD .five), Replay.r34.prev, (.frame Replay.r34.next)⟩,
  ⟨35, Witness.board1, Witness.w35, (Replay.r35.act.getD .five), Replay.r35.prev, (.frame Replay.r35.next)⟩,
  ⟨36, Witness.board1, Witness.w36, (Replay.r36.act.getD .five), Replay.r36.prev, (.frame Replay.r36.next)⟩,
  ⟨37, Witness.board1, Witness.w37, (Replay.r37.act.getD .five), Replay.r37.prev, (.frame Replay.r37.next)⟩,
  ⟨38, Witness.board1, Witness.w38, (Replay.r38.act.getD .five), Replay.r38.prev, (.frame Replay.r38.next)⟩,
  ⟨39, Witness.board1, Witness.w39, (Replay.r39.act.getD .five), Replay.r39.prev, (.frame Replay.r39.next)⟩,
  ⟨40, Witness.board1, Witness.w40, (Replay.r40.act.getD .five), Replay.r40.prev, (.frame Replay.r40.next)⟩,
  ⟨41, Witness.board1, Witness.w41, (Replay.r41.act.getD .five), Replay.r41.prev, (.frame Replay.r41.next)⟩,
  ⟨42, Witness.board1, Witness.w42, (Replay.r42.act.getD .five), Replay.r42.prev, (.frame Replay.r42.next)⟩]

/-- 第 0 段 42 条：对上 42、判错 0、闭嘴 0（闭嘴的全是 RESET）。
    判错不为 0、或者条数对不上，这一条就编不过。读数行在下面，定理走内核。 -/
theorem corpus_seg0 : stepVerdicts seg0 = (42, 0, 0) := by decide +kernel

#print axioms corpus_seg0
#eval "CORPUS seg0 " ++ toString (stepVerdicts seg0) ++ " bad=" ++ toString (badSeqs seg0)

end Corpus
end Game
