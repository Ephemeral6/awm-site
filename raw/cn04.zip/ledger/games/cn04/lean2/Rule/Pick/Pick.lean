/-
# Rule/Pick/Pick —— 点击（Python 那边：`rule/pick/pick.py`）

点在别的件上 ⇒ 选中它；点在已选中的那件上 ⇒ 取消选中；点在空地上 ⇒ 不变。
**点击从不挪动任何一件**——这一句在这里不用写：`pick` 只改 `sel`，
`Derived/ClickKeepsPieces.lean` 把它当推论证出来。

一格上叠着好几件时点中的是**次序最前**的那一件（语料里这种点击 1 次；次序是这一关的设定）。
像素 → 格：块网格原点 (2, 2)、每块 3 像素（和 Python `parse` 同一组常量）。
-/
import Obj.Frame.World
import Rule.Step.Move

namespace Game

def clickCell (x y : Nat) : Option Cell :=
  if x < 2 || y < 2 then none else some (((y - 2) / 3 : Nat), ((x - 2) / 3 : Nat))

def Shape.covers (sh : Shape) (p : Cell) : Bool :=
  sh.solid.contains p || sh.plugs.contains p || sh.head == some p

/-- 这一格上有哪几件（按次序）。 -/
def hits (s : World) (p : Cell) : List Nat :=
  (List.range s.pieces.length).filter (fun i => (s.piece i).cur.covers p)

/-- **点击的定义**。 -/
def pick (s : World) (x y : Nat) : World :=
  match clickCell x y with
  | none => s
  | some p =>
    match s.sel with
    | some i =>
      if (hits s p).contains i then { s with sel := none }
      else (match hits s p with
            | [] => s
            | j :: _ => { s with sel := some j })
    | none =>
      (match hits s p with
       | [] => s
       | j :: _ => { s with sel := some j })

end Game
