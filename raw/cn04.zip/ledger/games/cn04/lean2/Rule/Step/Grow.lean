/-
# Rule/Step/Grow —— ACTION5 作用在笔上（Python 那边：`rule/step/grow.py`）

笔有若干节，k 是现在第几节，up 是下一次往哪边走。ACTION5 走一节；**走到头就掉头**：
画满了再按会缩回一节，缩到第 0 节再按又往回长。

Python 那一侧只核得到「只有笔在变」：长哪一节、往哪边走帧上读不出（那是这支笔的隐藏剧本）。
这里把剧本当成笔的一部分记着（`Piece.stages`），逐帧对上了语料里全部 49 次笔上的 ACTION5。
-/
import Obj.Frame.World
import Rule.Step.Move

namespace Game

def Piece.grow (p : Piece) : Piece :=
  if p.up then
    (if p.k + 1 < p.stages.length then { p with k := p.k + 1 } else { p with k := p.k - 1, up := false })
  else
    (if p.k > 0 then { p with k := p.k - 1 } else { p with k := p.k + 1, up := true })

/-- **ACTION5 对笔的定义**。 -/
def grow (s : World) (i : Nat) : World := { s with pieces := mapAt Piece.grow i s.pieces }

end Game
