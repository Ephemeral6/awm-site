/-
# Rule/Step/Move —— 方向键（Python 那边：`rule/step/move.py`）

**这是定义，不是定理。** 「ACTION1-4 让选中那件平移一格，别的件不动，从不被挡」
就是方向键的**定义**；证它等于用它自己证它自己。

没有选中件时什么也不动（那一支在 `Derived/Idle.lean` 里被**推出来**，不是另一条规则）。
-/
import Obj.Frame.World

namespace Game

def shiftCell (d : Int × Int) (p : Cell) : Cell := (p.1 + d.1, p.2 + d.2)

def Shape.shift (d : Int × Int) (sh : Shape) : Shape :=
  ⟨sh.solid.map (shiftCell d), sh.plugs.map (shiftCell d), sh.head.map (shiftCell d)⟩

/-- 一件整体平移：**每一节都跟着挪**（笔还没画的那几节也挪，所以笔挪完接着画是接得上的）。 -/
def Piece.shift (d : Int × Int) (p : Piece) : Piece := { p with stages := p.stages.map (Shape.shift d) }

/-- 把第 i 个换成 f 作用之后的样子。 -/
def mapAt {α : Type} (f : α → α) : Nat → List α → List α
  | _, [] => []
  | 0, x :: xs => f x :: xs
  | n + 1, x :: xs => x :: mapAt f n xs

/-- **方向键的定义**：选中那件平移 d；别的件、选中哪件、步数都不在这里变。 -/
def move (d : Int × Int) (s : World) : World :=
  match s.sel with
  | none => s
  | some i => { s with pieces := mapAt (Piece.shift d) i s.pieces }

end Game
