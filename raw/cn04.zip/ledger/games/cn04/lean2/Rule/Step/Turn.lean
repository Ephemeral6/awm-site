/-
# Rule/Step/Turn —— ACTION5 作用在普通件上（Python 那边：`rule/step/turn.py`）

绕（实心 ∪ 插头）外框的左上角顺时针转 90°：(r, c) ↦ (r0 + (c − c0), c0 + (h − 1 − (r − r0)))，
h 是外框的高。**定义，不是定理。**
-/
import Obj.Frame.World
import Rule.Step.Move

namespace Game

def minOf (xs : List Int) : Int := xs.foldl min (xs.headD 0)
def maxOf (xs : List Int) : Int := xs.foldl max (xs.headD 0)

def Shape.turn (sh : Shape) : Shape :=
  let all := sh.solid ++ sh.plugs
  let r0 := minOf (all.map Prod.fst)
  let c0 := minOf (all.map Prod.snd)
  let h := maxOf (all.map Prod.fst) - r0 + 1
  let f : Cell → Cell := fun p => (r0 + (p.2 - c0), c0 + (h - 1 - (p.1 - r0)))
  ⟨sh.solid.map f, sh.plugs.map f, sh.head.map f⟩

def Piece.turn (p : Piece) : Piece := { p with stages := p.stages.map Shape.turn }

/-- **ACTION5 对普通件的定义**。 -/
def turn (s : World) (i : Nat) : World := { s with pieces := mapAt Piece.turn i s.pieces }

end Game
