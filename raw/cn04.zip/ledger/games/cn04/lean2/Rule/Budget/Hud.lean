/-
# Rule/Budget/Hud —— 顶栏（Python 那边：`rule/budget/hud.py`）

顶栏 32 格，花掉的格数 = round(32 · ticks / budget) = (64·ticks + budget) / (2·budget)。
ticks 是这一关走过的步数（每个动作 +1，点空地也算），budget 按关依次是 75/100/125/125/150/200。

Python 那一侧只核得到「每步不动或多花一格」：ticks 是历史，帧上读不出。
这里把它当世界的一位记着，从开局（ticks = 0）起逐帧对上了全部语料。
-/
import Obj.Frame.World

namespace Game

/-- **顶栏的定义**：花掉几格。 -/
def spentOf (b : Board) (t : Nat) : Nat := (64 * t + b.budget) / (2 * b.budget)

/-- 走了一步。 -/
def tick (s : World) : World := { s with ticks := s.ticks + 1 }

end Game
