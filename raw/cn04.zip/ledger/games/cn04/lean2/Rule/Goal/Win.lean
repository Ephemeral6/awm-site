/-
# Rule/Goal/Win —— 什么算赢（Python 那边：`rule/goal/win.py`）

**赢是一个状态性质**：场上每个插头格上都至少叠着两个插头。
写成状态性质，「这个局面赢不赢得了」才问得出来（写成转移事件的话，没有一个状态是目标）。
-/
import Obj.Frame.World

namespace Game

/-- 这一格上叠着几个插头（所有件、此刻那一节）。 -/
def plugCount (s : World) (p : Cell) : Nat :=
  s.pieces.foldl (fun n q => n + q.cur.plugs.count p) 0

def allPlugs (s : World) : List Cell := s.pieces.flatMap (fun q => q.cur.plugs)

/-- **赢的定义**。 -/
def isGoal (s : World) : Bool := (allPlugs s).all (fun p => decide (plugCount s p ≥ 2))

end Game
