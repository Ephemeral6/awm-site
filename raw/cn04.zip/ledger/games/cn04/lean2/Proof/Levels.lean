/-
# Proof/Levels —— 每一关一条定理（`lean2/export_levels.py` 生成，**不要手改**）

    L<n>_trace      沿着成绩单认证的那一段真实走法，从开局起**模型自己算**，每一帧都和观测对上
                    （连同开局那一帧本身、以及这一段到底有几步——空表会让「一步不差」平凡为真）
    L<n>_winnable   这一关走得通：见证就是那一段走法，再加上过关那一脚

**开局从哪来**：`Witness.start<n>`——看得见的部分就是开局那一帧；看不见的那几位
（沉睡件的真色与插头、笔的每一节、选中件在 'paint' 画法下的真色）取自这一关全部语料段里
它们露出来的那一帧。`L<n>_trace` 的第一个合取项核的正是「这个开局画出来就是开局那一帧」。

**「走不通」一条都没有**：6 关在认证的那一段里全部走通了。
**关内 RESET 0 次**：「重来一次放回开局」这条假设在这一段上**没有被用到**，也就没有被检验。

| 关 | 认证段 seq | 逐帧核的步数 | 过关那一步 |
|---|---|---|---|
| 0 | 485–498 | 开局 + 13 | seq 498 ACTION2 |
| 1 | 499–529 | 开局 + 30 | seq 529 ACTION3 |
| 2 | 530–563 | 开局 + 33 | seq 563 ACTION2 |
| 3 | 564–658 | 开局 + 94 | seq 658 ACTION3 |
| 4 | 659–704 | 开局 + 45 | seq 704 ACTION5 |
| 5 | 705–745 | 开局 + 40 | seq 745 ACTION4 |
-/
import Obj.Frame.World
import Obs.Replay
import Obs.Witness
import Proof.Reachable

namespace Game
namespace Levels

-- 独立一条命令（夹在文档注释和定理之间会变成语法错误）：内核逐帧算的那条 `decide` 递归很深
set_option maxRecDepth 200000

/-- 第 0 关：认证那一段的 seq 485–498。开局 + 13 步逐帧核，第 14 步（seq 498，`ACTION2`）过关。 -/
def L0_play : List (Act × Seen) := Replay.playFrom 485 13
def L0_acts : List Act := Replay.actsFrom 485 14

#eval match firstSplit Witness.board0 Witness.start0 L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 13 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L0_trace : L0_play.length = 13 ∧
    seenOk Witness.board0 (Witness.start0 : World) Replay.r485.prev = true ∧
    traceOk Witness.board0 (Witness.start0 : World) L0_play = true := by
  decide +kernel

#print axioms L0_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（14 个动作）。 -/
theorem L0_winnable : L0_acts.length = 14 ∧ Winnable (Witness.start0 : World) :=
  ⟨by decide +kernel, ⟨L0_acts, by decide +kernel⟩⟩

#print axioms L0_winnable

/-- 第 1 关：认证那一段的 seq 499–529。开局 + 30 步逐帧核，第 31 步（seq 529，`ACTION3`）过关。 -/
def L1_play : List (Act × Seen) := Replay.playFrom 499 30
def L1_acts : List Act := Replay.actsFrom 499 31

#eval match firstSplit Witness.board1 Witness.start1 L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 30 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L1_trace : L1_play.length = 30 ∧
    seenOk Witness.board1 (Witness.start1 : World) Replay.r499.prev = true ∧
    traceOk Witness.board1 (Witness.start1 : World) L1_play = true := by
  decide +kernel

#print axioms L1_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（31 个动作）。 -/
theorem L1_winnable : L1_acts.length = 31 ∧ Winnable (Witness.start1 : World) :=
  ⟨by decide +kernel, ⟨L1_acts, by decide +kernel⟩⟩

#print axioms L1_winnable

/-- 第 2 关：认证那一段的 seq 530–563。开局 + 33 步逐帧核，第 34 步（seq 563，`ACTION2`）过关。 -/
def L2_play : List (Act × Seen) := Replay.playFrom 530 33
def L2_acts : List Act := Replay.actsFrom 530 34

#eval match firstSplit Witness.board2 Witness.start2 L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 33 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L2_trace : L2_play.length = 33 ∧
    seenOk Witness.board2 (Witness.start2 : World) Replay.r530.prev = true ∧
    traceOk Witness.board2 (Witness.start2 : World) L2_play = true := by
  decide +kernel

#print axioms L2_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（34 个动作）。 -/
theorem L2_winnable : L2_acts.length = 34 ∧ Winnable (Witness.start2 : World) :=
  ⟨by decide +kernel, ⟨L2_acts, by decide +kernel⟩⟩

#print axioms L2_winnable

/-- 第 3 关：认证那一段的 seq 564–658。开局 + 94 步逐帧核，第 95 步（seq 658，`ACTION3`）过关。 -/
def L3_play : List (Act × Seen) := Replay.playFrom 564 94
def L3_acts : List Act := Replay.actsFrom 564 95

#eval match firstSplit Witness.board3 Witness.start3 L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 94 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L3_trace : L3_play.length = 94 ∧
    seenOk Witness.board3 (Witness.start3 : World) Replay.r564.prev = true ∧
    traceOk Witness.board3 (Witness.start3 : World) L3_play = true := by
  decide +kernel

#print axioms L3_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（95 个动作）。 -/
theorem L3_winnable : L3_acts.length = 95 ∧ Winnable (Witness.start3 : World) :=
  ⟨by decide +kernel, ⟨L3_acts, by decide +kernel⟩⟩

#print axioms L3_winnable

/-- 第 4 关：认证那一段的 seq 659–704。开局 + 45 步逐帧核，第 46 步（seq 704，`ACTION5`）过关。 -/
def L4_play : List (Act × Seen) := Replay.playFrom 659 45
def L4_acts : List Act := Replay.actsFrom 659 46

#eval match firstSplit Witness.board4 Witness.start4 L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 45 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L4_trace : L4_play.length = 45 ∧
    seenOk Witness.board4 (Witness.start4 : World) Replay.r659.prev = true ∧
    traceOk Witness.board4 (Witness.start4 : World) L4_play = true := by
  decide +kernel

#print axioms L4_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（46 个动作）。 -/
theorem L4_winnable : L4_acts.length = 46 ∧ Winnable (Witness.start4 : World) :=
  ⟨by decide +kernel, ⟨L4_acts, by decide +kernel⟩⟩

#print axioms L4_winnable

/-- 第 5 关：认证那一段的 seq 705–745。开局 + 40 步逐帧核，第 41 步（seq 745，`ACTION4`）过关。 -/
def L5_play : List (Act × Seen) := Replay.playFrom 705 40
def L5_acts : List Act := Replay.actsFrom 705 41

#eval match firstSplit Witness.board5 Witness.start5 L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：这一段有 40 步；开局世界画出来就是开局那一帧；
    之后每一步都是模型自己算的，每一帧都和观测对上。 -/
theorem L5_trace : L5_play.length = 40 ∧
    seenOk Witness.board5 (Witness.start5 : World) Replay.r705.prev = true ∧
    traceOk Witness.board5 (Witness.start5 : World) L5_play = true := by
  decide +kernel

#print axioms L5_trace

/-- **这一关走得通。** 见证是那一段走法加过关那一脚（41 个动作）。 -/
theorem L5_winnable : L5_acts.length = 41 ∧ Winnable (Witness.start5 : World) :=
  ⟨by decide +kernel, ⟨L5_acts, by decide +kernel⟩⟩

#print axioms L5_winnable

end Levels
end Game
