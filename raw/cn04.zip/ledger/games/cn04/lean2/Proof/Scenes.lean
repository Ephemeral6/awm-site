/-
# Proof/Scenes —— 两把理由不同的「赢不了」钥匙，各配一张只差一处的对照盘

这一局六关在语料里全部走通了，没有一关要证「走不通」。这一份是**教学盘**：
说明「赢不了」在这个模型里能被**证出来**（不是搜不到路），而且这把钥匙不是对谁都说不可做。

## 钥匙 A：场上只有一件（不是笔），它的插头互不重合

赢要求每个插头格上**至少叠两个**插头，而插头只长在件上。场上只有一件的时候，
它的插头两两不同格，平移、转向都不会让两个插头叠到一格上（两种挪法都是单射），
点击不挪任何一件——所以**无论怎么走、走多少步，都凑不出一对**。
证明里没有一处枚举、没有一处搜索，与盘面多大无关。

**「赢不了」的准确意思是「不经过 RESET 就赢不了」**（`Act` 里没有 RESET）。

## 三条防线

    A_ctrl_winnable        对照盘（只多了一件带插头的件）一步就赢
    A_ctrl_closed_at_start 而且不是一开始就赢了
    A_ctrl_not_key         而且钥匙的前提在对照盘上**真的不满足**（不是「没找到证明」）

钥匙 B（在下面）的理由完全不同：不是「配不成对」，是「拿不到控制权」——同样三条防线。
-/
import Obj.Frame.World
import Proof.Reachable
import Derived.ClickKeepsPieces

namespace Game
namespace Scenes

/-- 钥匙 A 的前提：场上恰好一件，一节（不是笔），在第 0 节，插头至少一个且两两不同格。 -/
def KeyA (w : World) : Prop :=
  ∃ c sh u, w.pieces = [⟨c, [sh], 0, u⟩] ∧ sh.plugs ≠ [] ∧ sh.plugs.Nodup

theorem nodup_map_of_inj {α β : Type} (f : α → β) (hf : ∀ a b, f a = f b → a = b) :
    ∀ l : List α, l.Nodup → (l.map f).Nodup
  | [], _ => List.Pairwise.nil
  | a :: l, h => by
    rw [List.nodup_cons] at h
    rw [List.map_cons, List.nodup_cons]
    refine ⟨?_, nodup_map_of_inj f hf l h.2⟩
    intro hm
    rcases List.mem_map.mp hm with ⟨b, hb, hfb⟩
    exact h.1 (hf b a hfb ▸ hb)

theorem mapAt_single {α : Type} (f : α → α) (i : Nat) (q : α) :
    mapAt f i [q] = if i = 0 then [f q] else [q] := by
  cases i with
  | zero => rfl
  | succ n => simp [mapAt]

theorem shiftCell_inj (d : Int × Int) : ∀ a b, shiftCell d a = shiftCell d b → a = b := by
  intro a b h
  simp only [shiftCell, Prod.mk.injEq] at h
  exact Prod.ext (by omega) (by omega)

theorem turn_plugs (sh : Shape) : ∃ f : Cell → Cell, (∀ a b, f a = f b → a = b) ∧
    (Shape.turn sh).plugs = sh.plugs.map f := by
  refine ⟨fun p => (minOf ((sh.solid ++ sh.plugs).map Prod.fst) + (p.2 - minOf ((sh.solid ++ sh.plugs).map Prod.snd)),
      minOf ((sh.solid ++ sh.plugs).map Prod.snd) +
        (maxOf ((sh.solid ++ sh.plugs).map Prod.fst) - minOf ((sh.solid ++ sh.plugs).map Prod.fst) + 1 - 1 -
          (p.1 - minOf ((sh.solid ++ sh.plugs).map Prod.fst)))), ?_, rfl⟩
  intro a b h
  simp only [Prod.mk.injEq] at h
  exact Prod.ext (by omega) (by omega)

/-- 走一步之前那一刻（`settle` 之前）的世界。`step` 就是它再加上 `settle`。 -/
def pre (w : World) : Act → World
  | .up => move (-1, 0) w
  | .down => move (1, 0) w
  | .left => move (0, -1) w
  | .right => move (0, 1) w
  | .five => five w
  | .click x y => pick w x y

theorem step_eq (w : World) (a : Act) : step w a = settle (pre w a) := by
  cases a <;> rfl

theorem keyA_move (d : Int × Int) (w : World) (h : KeyA w) : KeyA (move d w) := by
  obtain ⟨c, sh, u, hp, hne, hnd⟩ := h
  unfold move
  split
  · exact ⟨c, sh, u, hp, hne, hnd⟩
  · rename_i i _
    simp only [hp, mapAt_single]
    split
    · refine ⟨c, sh.shift d, u, rfl, ?_, ?_⟩
      · simp [Shape.shift, hne]
      · exact nodup_map_of_inj _ (shiftCell_inj d) _ hnd
    · exact ⟨c, sh, u, rfl, hne, hnd⟩

theorem keyA_five (w : World) (h : KeyA w) : KeyA (five w) := by
  obtain ⟨c, sh, u, hp, hne, hnd⟩ := h
  unfold five
  split
  · exact ⟨c, sh, u, hp, hne, hnd⟩
  · rename_i i _
    have hpen : (w.piece i).isPen = false := by
      cases i with
      | zero => simp [World.piece, hp, Piece.isPen]
      | succ n => simp [World.piece, hp, Piece.isPen]
    rw [if_neg (by simp [hpen])]
    by_cases hi : i = 0
    · obtain ⟨f, hf, hfe⟩ := turn_plugs sh
      refine ⟨c, sh.turn, u, ?_, ?_, ?_⟩
      · simp [turn, hp, mapAt_single, hi, Piece.turn]
      · rw [hfe]; simp [hne]
      · rw [hfe]; exact nodup_map_of_inj f hf _ hnd
    · exact ⟨c, sh, u, by simp [turn, hp, mapAt_single, hi], hne, hnd⟩

theorem keyA_pre (w : World) (a : Act) (h : KeyA w) : KeyA (pre w a) := by
  cases a with
  | up => exact keyA_move _ w h
  | down => exact keyA_move _ w h
  | left => exact keyA_move _ w h
  | right => exact keyA_move _ w h
  | five => exact keyA_five w h
  | click x y =>
    obtain ⟨c, sh, u, hp, hne, hnd⟩ := h
    exact ⟨c, sh, u, by simp only [pre, pick_keeps_pieces, hp], hne, hnd⟩

theorem keyA_tick (w : World) (h : KeyA w) : KeyA (tick w) := h

/-- 钥匙 A 的局面**不是赢的局面**：随便取一个插头，那一格上只有它自己。 -/
theorem keyA_not_goal (w : World) (h : KeyA w) : isGoal w = false := by
  obtain ⟨c, sh, u, hp, hne, hnd⟩ := h
  match hs : sh.plugs, hne, hnd with
  | [], hne, _ => exact absurd rfl hne
  | p :: rest, _, hnd =>
    have hc : List.count p (p :: rest) = 1 := by
      rw [List.Nodup.count hnd]; simp
    simp [isGoal, allPlugs, plugCount, hp, Piece.cur, hs, hc]

theorem keyA_keep : ∀ w w' a, KeyA w → step w a = .ok w' → KeyA w' := by
  intro w w' a h hs
  rw [step_eq] at hs
  unfold settle at hs
  split at hs
  · cases hs
  · cases hs; exact keyA_tick _ (keyA_pre w a h)

theorem keyA_nowin : ∀ w a w', KeyA w → step w a ≠ .won w' := by
  intro w a w' h hs
  rw [step_eq] at hs
  unfold settle at hs
  split at hs
  · rename_i hg
    rw [keyA_not_goal _ (keyA_tick _ (keyA_pre w a h))] at hg
    exact Bool.false_ne_true hg
  · cases hs

/-- **钥匙 A**：满足前提的局面，不经过 RESET 就赢不了。 -/
theorem keyA_unsolvable (w : World) (h : KeyA w) : Unsolvable w :=
  unsolvable_of_invariant KeyA keyA_keep keyA_nowin w h

/-! ## 盘与对照盘（只差一处：对照盘多了一件带插头的件） -/

def A_scene : World := ⟨[⟨12, [⟨[(5, 5), (5, 6)], [(4, 5), (6, 6)], none⟩], 0, true⟩], some 0, 0⟩

def A_ctrl : World :=
  ⟨[⟨12, [⟨[(5, 5), (5, 6)], [(4, 5), (6, 6)], none⟩], 0, true⟩,
    ⟨14, [⟨[(5, 4)], [(4, 4), (6, 5)], none⟩], 0, true⟩], some 1, 0⟩

theorem A_scene_key : KeyA (A_scene : World) := ⟨12, _, true, rfl, by decide, by decide⟩

/-- **这张盘赢不了**（不经过 RESET）。 -/
theorem A_scene_unsolvable : Unsolvable (A_scene : World) := keyA_unsolvable _ A_scene_key

/-- 对照盘**赢得了**：把第二件往右挪一格，两对插头同时叠上。 -/
theorem A_ctrl_winnable : Winnable (A_ctrl : World) := ⟨[.right], by decide⟩

/-- 对照盘**一开始并没有赢**。 -/
theorem A_ctrl_closed_at_start : isGoal (A_ctrl : World) = false := by decide

/-- 钥匙 A 的前提在对照盘上**真的不满足**（它有两件）——不是「没找到证明」。 -/
theorem A_ctrl_not_key : ¬ KeyA (A_ctrl : World) := by
  rintro ⟨c, sh, u, h, _, _⟩
  simp [A_ctrl] at h

/-! ## 钥匙 B：没有选中件，而且每一件都在点不到的地方

理由和钥匙 A 完全不同：A 是「配不成对」，B 是「拿不到控制权」。没有选中件时方向键和 ACTION5
什么也不动（`Derived/Idle`），而点击只落在网格里（行、列都 ≥ 0）；每一件都在网格上方（行 < 0）的话，
点哪里都选不中——世界一格都变不了，一开始没赢就永远赢不了。 -/

def KeyB (w : World) : Prop :=
  w.sel = none ∧ (∀ i (p : Cell), 0 ≤ p.1 → (w.piece i).cur.covers p = false) ∧ isGoal w = false

theorem clickCell_nonneg (x y : Nat) (p : Cell) (h : clickCell x y = some p) : 0 ≤ p.1 := by
  unfold clickCell at h
  split at h
  · cases h
  · cases h; exact Int.natCast_nonneg _

theorem keyB_pre (w : World) (a : Act) (h : KeyB w) : pre w a = w := by
  obtain ⟨hs, hc, _⟩ := h
  cases a with
  | up => simp [pre, move, hs]
  | down => simp [pre, move, hs]
  | left => simp [pre, move, hs]
  | right => simp [pre, move, hs]
  | five => simp [pre, five, hs]
  | click x y =>
    simp only [pre, pick]
    split
    · rfl
    · rename_i p hp
      have hh : hits w p = [] := by
        unfold hits
        rw [List.filter_eq_nil_iff]
        intro i _
        simp [hc i p (clickCell_nonneg x y p hp)]
      simp [hs, hh]

theorem keyB_keep : ∀ w w' a, KeyB w → step w a = .ok w' → KeyB w' := by
  intro w w' a h hs
  rw [step_eq, keyB_pre w a h] at hs
  unfold settle at hs
  split at hs
  · cases hs
  · cases hs; exact h

theorem keyB_nowin : ∀ w a w', KeyB w → step w a ≠ .won w' := by
  intro w a w' h hs
  rw [step_eq, keyB_pre w a h] at hs
  unfold settle at hs
  split at hs
  · rename_i hg
    have : isGoal (tick w) = isGoal w := rfl
    rw [this, h.2.2] at hg
    exact Bool.false_ne_true hg
  · cases hs

/-- **钥匙 B**：满足前提的局面，不经过 RESET 就赢不了。 -/
theorem keyB_unsolvable (w : World) (h : KeyB w) : Unsolvable w :=
  unsolvable_of_invariant KeyB keyB_keep keyB_nowin w h

/-- 盘：两件，插头本来一步就能叠上，但都在网格上方（行 −3 / −2），没有选中件。 -/
def B_scene : World :=
  ⟨[⟨12, [⟨[(-3, 5)], [(-2, 5)], none⟩], 0, true⟩, ⟨14, [⟨[(-3, 7)], [(-2, 6)], none⟩], 0, true⟩], none, 0⟩

/-- 对照盘：只差一处——第二件挪进了网格（行 3 / 2），它点得到。 -/
def B_ctrl : World :=
  ⟨[⟨12, [⟨[(3, 5)], [(2, 5)], none⟩], 0, true⟩, ⟨14, [⟨[(3, 7)], [(2, 6)], none⟩], 0, true⟩], none, 0⟩

theorem B_scene_key : KeyB (B_scene : World) := by
  refine ⟨rfl, ?_, by decide⟩
  intro i p hp
  rcases p with ⟨a, b⟩
  simp only at hp
  rcases i with _ | _ | i
  · simp [World.piece, B_scene, Piece.cur, Shape.covers]; omega
  · simp [World.piece, B_scene, Piece.cur, Shape.covers]; omega
  · simp [World.piece, B_scene, Piece.cur, Shape.covers, Shape.empty]

theorem B_scene_unsolvable : Unsolvable (B_scene : World) := keyB_unsolvable _ B_scene_key

/-- 对照盘赢得了：点第二件（像素 (23, 11) 落在格 (3, 7)），往左挪一格，两个插头叠上。 -/
theorem B_ctrl_winnable : Winnable (B_ctrl : World) := ⟨[.click 23 11, .left], by decide⟩

theorem B_ctrl_closed_at_start : isGoal (B_ctrl : World) = false := by decide

/-- 钥匙 B 的前提在对照盘上真的不满足：第二件在格 (3, 7) 上，点得到。 -/
theorem B_ctrl_not_key : ¬ KeyB (B_ctrl : World) := by
  rintro ⟨_, hc, _⟩
  have := hc 1 (3, 7) (by decide)
  simp [World.piece, B_ctrl, Piece.cur, Shape.covers] at this

#print axioms clickCell_nonneg
#print axioms keyB_pre
#print axioms keyB_keep
#print axioms keyB_nowin
#print axioms keyB_unsolvable
#print axioms B_scene_key
#print axioms B_scene_unsolvable
#print axioms B_ctrl_winnable
#print axioms B_ctrl_closed_at_start
#print axioms B_ctrl_not_key
#print axioms nodup_map_of_inj
#print axioms mapAt_single
#print axioms shiftCell_inj
#print axioms turn_plugs
#print axioms step_eq
#print axioms keyA_move
#print axioms keyA_five
#print axioms keyA_pre
#print axioms keyA_tick
#print axioms keyA_not_goal
#print axioms keyA_keep
#print axioms keyA_nowin
#print axioms keyA_unsolvable
#print axioms A_scene_key
#print axioms A_scene_unsolvable
#print axioms A_ctrl_winnable
#print axioms A_ctrl_closed_at_start
#print axioms A_ctrl_not_key

end Scenes
end Game
