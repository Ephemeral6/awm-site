/-
# Proof/Reachable —— 这个**局面**做不做得了（骨架）

    Winnable w    有一串动作，走下去某一刻赢（`isGoal`）
    Unsolvable w  任何一串动作走下去都从没赢过

**「赢不了」的准确意思是「不经过 RESET 就赢不了」**：`Act` 里没有 RESET（模型不描述它），
所以 `∀ as` 量的是模型描述得了的那几种动作。这半句写在这里、写在 `Levels`、写在页面上。

动作不用另外限「合法」：`Act` 本身就只有这一局真有的那几种（方向键一次挪一格、ACTION5、点一格），
没有「一步跨两格」这种东西可以量。

## 唯一的骨架

找一个性质 Φ：每走一步都还成立，而且成立时这一步不可能赢。那么从满足 Φ 的局面出发，
**无论走多少步、怎么走，都赢不了**。这是全文唯一做归纳的地方，与盘面大小无关，不枚举任何状态。
-/
import Obj.Frame.World
import Step

namespace Game

/-- 从 w 出发照着 as 走，途中有没有哪一步赢了。 -/
def everWon : World → List Act → Bool
  | _, [] => false
  | w, a :: as =>
    match step w a with
    | .won _ => true
    | .ok w' => everWon w' as

def Winnable (w : World) : Prop := ∃ as : List Act, everWon w as = true
def Unsolvable (w : World) : Prop := ∀ as : List Act, everWon w as = false

/-- 两句话不能同时成立。 -/
theorem not_both (w : World) (h1 : Winnable w) (h2 : Unsolvable w) : False := by
  obtain ⟨as, h⟩ := h1
  rw [h2 as] at h
  exact Bool.false_ne_true h

/-- **骨架**：不变量 ⇒ 赢不了。`generalizing` 是要害：走一步换了局面，归纳假设照样用得上。 -/
theorem unsolvable_of_invariant (P : World → Prop)
    (hkeep : ∀ w w' a, P w → step w a = .ok w' → P w')
    (hwin : ∀ w a w', P w → step w a ≠ .won w') :
    ∀ w, P w → Unsolvable w := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hs : step w a with
    | won w' => exact absurd hs (hwin w a w' hp)
    | ok w' => exact ih w' (hkeep w w' a hp hs)

#print axioms not_both
#print axioms unsolvable_of_invariant

end Game
