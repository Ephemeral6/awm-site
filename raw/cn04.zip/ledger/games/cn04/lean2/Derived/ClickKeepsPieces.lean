/-
# Derived/ClickKeepsPieces —— 「点击从不挪动任何一件，也从不过关」是**推论**

Python 那边这一句分在两处：`rule/pick/pick.py` 的「点击不挪任何一件」，
`rule/goal/win.py` 的论域说明「点击从不过关」。这里把它们从 `pick` 与 `isGoal` 的定义**推出来**：
`pick` 只改 `sel`；`isGoal` 只看件——所以点击前没赢，点击后也不会赢。
-/
import Obj.Frame.World
import Step

namespace Game

theorem pick_keeps_pieces (w : World) (x y : Nat) : (pick w x y).pieces = w.pieces := by
  unfold pick
  split
  · rfl
  · split
    · split
      · rfl
      · split <;> rfl
    · split <;> rfl

/-- 点击之前没赢，点击这一步就不会赢（`step` 给的是 `ok`，不是 `won`）。 -/
theorem click_never_wins (w : World) (x y : Nat) (h : isGoal w = false) :
    step w (.click x y) = .ok (tick (pick w x y)) := by
  have hp : isGoal (tick (pick w x y)) = isGoal w := by
    show isGoal { pick w x y with ticks := (pick w x y).ticks + 1 } = isGoal w
    unfold isGoal allPlugs plugCount
    simp only [pick_keeps_pieces]
  simp only [step, settle, hp, h]
  rfl

#print axioms pick_keeps_pieces
#print axioms click_never_wins

end Game
