/-
# Derived/Idle —— 「没有选中件时按键什么也不动」是**推论**（Python 那边：`rule/step/idle.py`）

Python 那一侧它是一条独立的规则（逐帧核）。重排成定义之后它掉进这里：
方向键和 ACTION5 的定义里本来就写着「没有选中件 ⇒ 原样返回」，
所以这一句**不是一条独立的规则**，是 `move` / `five` 的定义推出来的。
-/
import Obj.Frame.World
import Step

namespace Game

/-- 没有选中件时，方向键和 ACTION5 只让步数 +1，件一格不动、选中照旧（`settle w` 只动 ticks）。 -/
theorem idle (w : World) (h : w.sel = none) :
    step w .up = settle w ∧ step w .down = settle w ∧ step w .left = settle w ∧
    step w .right = settle w ∧ step w .five = settle w := by
  simp [step, move, five, h]

/-- `settle` 只动步数：件和选中都不变。 -/
theorem settle_keeps (w : World) :
    (settle w = .ok (tick w) ∨ settle w = .won (tick w)) ∧
    (tick w).pieces = w.pieces ∧ (tick w).sel = w.sel := by
  refine ⟨?_, rfl, rfl⟩
  unfold settle
  split
  · exact Or.inr rfl
  · exact Or.inl rfl

#print axioms idle
#print axioms settle_keeps

end Game
