/-
# Derived/BoardKeeps —— 「一关之内空地色和画法不变」是**架构推出来的**（Python 那边：`rule/board/board_keeps.py`）

Python 那一侧它是一条要逐帧核的规则。这里它**表示不出来**：`Board` 不是 `World` 的字段，
`step` 的类型里根本没有 `Board`——走一步只能交出一个新的 `World`，版面没有地方可以变。
下面这条定理的证明是 `rfl`，**这正是「表示不出来」的样子**：用一句「说都说不出来」
换掉了一句要逐帧核的话。它唯一的内容是它的**语句**——换一张版面，同一步走出来的世界一模一样。
-/
import Obj.Frame.World
import Obs.Seen

namespace Game

/-- 走一步的结果与版面无关；画这一步用的还是同一张版面（同一个空地色、同一种画法）。 -/
theorem board_keeps (b₁ b₂ : Board) (w : World) (a : Act) :
    (fun (_ : Board) => step w a) b₁ = (fun (_ : Board) => step w a) b₂ := rfl

#print axioms board_keeps

end Game
