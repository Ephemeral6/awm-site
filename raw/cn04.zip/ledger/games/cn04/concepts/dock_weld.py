"""插头只会重合、不会消耗：一关里插头总数恒定，两个插头占同一格时那一格显示色 3（一格算两个插头），分开后各自照旧显示色 8。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1-5（其余动作返回 NA）；换关返回 NA（换关整帧换掉，插头总数当然会变）；"
         "可动件定位不到、或场上只有可动件一个件时返回 NA。只数 20x20 块网格里的色 8 与色 3 块。"
         "**可动件这一步会压到别的件身上时返回 NA**（判据：`_lib.render` 说不出下一帧——"
         "要么有色 8 的格子同时贴着可动件和别的件的实心块、分不清插头归谁，"
         "要么可动件的实心块落到别人的块上、会把它盖掉）。"
         "缩这一刀是因为本条数的是**帧上看得见的**插头，而盖住的插头看不见。"
         "**醒着的是那支笔画出来的件时，ACTION5 返回 NA**（`_lib.is_pen`）：对它 ACTION5 造节/撤节，"
         "插头凭空多一个少一个，守恒在那一族上是假的；对别的醒着的件（ACTION5 = 旋转）照旧数。")
NOTE = ("第 24 步：两对插头重合，色 8 块 12->8、色 3 块 0->2，插头总数 12->12。"
        "第 25 步：可动件上移一格，色 3 块 2->0、色 8 块 8->12，总数还是 12 —— "
        "焊接可逆，件也没合并（这一步推翻了 move_up v3 的「组合体一起动」）。"
        "本条不写 apply：它是不变量，具体哪一格由 move_*/rot_cw 生成。"
        "v4（第 39/40 步打脸后缩 scope）：第 39 步可动件的实心块右移到色 9 小件的实心块上——"
        "世界不挡，它画在最上面，把小件的块和邻格的色 8 插头一起盖住了，"
        "帧上的插头总数当场 12->11，本条判 FALSE。第 40 步左移回来，插头原样回来，又是一次 FALSE。"
        "但**世界里的插头一个没少**，少的是看得见的那些（见 overlap_draws_over）。"
        "所以这不是不变量被推翻，是本条的量法在重叠局面下失效：改成一压就闭嘴。"
        "代价：36 条 ACTION1-5 里有 4 条从此不表态。"
        "注意这是**症状**不是证明——帧上读不出「有没有重叠」，"
        "`render` 说不出话的局面里也许并没真压上；宁可多闭嘴。"
        "v5：第 118 步判 FALSE——L2 装配路上，可动件的插头压上沉睡底件盖着的隐藏插头，"
        "那一格显 3。帧上的插头「多」了一个（看得见的从 2 变 3）：隐藏插头参与配对时"
        "会突然显形，可见数守恒在沉睡 regime 里本来就不成立。修在词汇层："
        "_lib.sleeper_touch——落位压到沉睡件时 render 返回 None，本条跟着闭嘴。"
        "v6：第 138 步判 FALSE——撕焊那步，prev 帧的焊格计 2 个插头（含沉睡件盖着的那个），"
        "撕开后隐藏插头回帧不可见，可见数 3->2，几何上一个插头都没少。可见计数在"
        "「焊格里掺着隐藏插头」时本来就不守恒：焊格贴着沉睡件就闭嘴（_weld_with_hidden）。"
        "v7（词汇）：第 185 步判 FALSE —— 那个 regime 里 ACTION5 会**凭空长出一个色 8 插头**"
        "（笔头下移，原处补一节实体加一个插头），插头总数当场 +1，本条的守恒主张在那里是假的。"
        "修在 _lib.active：色 0 单块时，件 = 笔头 + 与它 4 连通的那一团；改完本条在第 181-184 步判 TRUE"
        "（画图态的整体平移不造也不撤插头，守恒照旧成立）。真正不守恒的只有第 4 关的 ACTION5。"
        "**缩掉的这一片本条从此不再声称管**——那里插头是被创造出来的，守恒得另写一条。"
        "v9：第 190 步判 FALSE —— 第 4 关画完之后按 ACTION5，世界把上一节**撤了**，"
        "连带那一节的插头一起消失（可见插头 7→6）。造得出来也撤得掉，守恒在**笔件的** ACTION5 上就是假的。"
        "v10：缩错了维度。当时缩成「第 4 关 + ACTION5 一律 NA」，"
        "第 195 步实测证明那一刀多切了：同一关里点亮一个靶件再按 ACTION5 是旋转，"
        "插头一个不多一个不少（2 个原地换位置），守恒照旧成立。"
        "改成 `_lib.is_pen`：只对笔画出来的那个件闭嘴，别的醒着的件照旧数。")
EVIDENCE = ["d1e1ed10398efa35", "6ed6465515ce9755", "6b406ed12e9ef9ab", "e743b4b3d639b895",
            "ffb5f6e3c31db8bd", "fefb7969d2beb867", "b630d38809ca109a", "64b6398ce8ef40bf",
            "86ddc938ab99d0b2"]

from _lib import blocks, movable, targets, placed, render, MARK, WELD, NB, sleepers, is_pen

KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5")
_NB4 = ((1, 0), (-1, 0), (0, 1), (0, -1))


def _plugs(bs):
    """插头总数：色 8 的格算 1 个，色 3 的格算 2 个。"""
    n = 0
    for i in range(NB):
        for j in range(NB):
            if bs[i][j] == MARK:
                n += 1
            elif bs[i][j] == WELD:
                n += 2
    return n


def _weld_with_hidden(bs):
    """有没有贴着沉睡件的焊格——那一格的计数贡献是瞬态的：撕开后隐藏插头回帧不可见，
    可见计数掉 1，几何上一个插头都没少（第 138 步）。"""
    sl = sleepers(None, bs)
    if not sl:
        return False
    for i in range(NB):
        for j in range(NB):
            if bs[i][j] == WELD:
                for di, dj in _NB4:
                    p = (i + di, j + dj)
                    if any(p in c for c in sl):
                        return True
    return False


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action == "ACTION5" and (ctx or {}).get("level_prev", 0) >= 4 and is_pen(prev):
        return "NA"                      # 笔件的 ACTION5 会造出/撤掉插头，不是搬运（第 185/190 步）
    if action not in KEYS:
        return "NA"
    bp = blocks(prev)
    if movable(prev, bp) is None or not targets(prev, bp):
        return "NA"
    new = placed(prev, action, bp)
    if new is None or render(prev, new, bp) is None:
        return "NA"                      # 要压到别人身上了：帧上数不全，本条闭嘴
    if _weld_with_hidden(bp):
        return "NA"                      # 焊格里掺着隐藏插头：可见数本来就不守恒
    return "TRUE" if _plugs(bp) == _plugs(blocks(nxt)) else "FALSE"
