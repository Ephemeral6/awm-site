"""点击那一步是**身份交换**：原来显 MOVER 色的那件整件换成某一种固定色，被点中的那件整件换成 MOVER 色，两件一格没挪，别的格子一格没变。

第 504 步逼出来的：我一直以为点击是在 MOVER 色和某个背景色之间来回涂，
实际那一步是十格 14→0 配十格 0→15 —— 放下的件回到的是**它自己的色**，不是刚才那件的色。
所以每件带着一种固有色，MOVER 色只是「此刻选中」这个身份的画法。
固有色具体是几，在件显 MOVER 色的帧上根本读不出来（第 1 关有两件都是十格，一个 14 一个 15），
所以本条只断言交换这件事本身，不写 apply —— 说不出颜色的主张不该假装说得出。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6；换关返回 NA；场上有沉睡件（实心全 4）时返回 NA（那是另一套画法，"
         "MOVER 色在那边是笔头不是选中态）；前帧或后帧里显 MOVER 色的实心分量不是恰好一个时返回 NA。"
         "只管 20x20 块网格——顶栏的罚数柱在块网格外，blocks() 看不见它，本条也就不管它。")
NOTE = ""
EVIDENCE = ["a17d5d6fabd79f7f", "679f074a30d17d43", "c7dd47fb8417c450", "eba813eed866edbf"]

from _lib import blocks, solid_comps, sleepers, MOVER, NB


def _sel(bs):
    """显 MOVER 色的实心分量，恰好一个才返回它，否则 None。"""
    got = [c for c in solid_comps(bs) if all(bs[i][j] == MOVER for (i, j) in c)]
    return got[0] if len(got) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    bp, bn = blocks(prev), blocks(nxt)
    if sleepers(None, bp) or sleepers(None, bn):
        return "NA"
    a = _sel(bp)          # 点击之前选中的那件
    b = _sel(bn)          # 点击之后选中的那件
    if a is None or b is None:
        return "NA"

    changed = {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] != bn[i][j]}
    if changed != (a | b) - (a & b):
        return "FALSE"    # 变了的格子必须正好是这两件互不重合的那部分

    # a 整件从 MOVER 色换成同一种非 MOVER 的色
    ca = {bn[i][j] for (i, j) in a - b}
    if len(ca) != 1 or ca.pop() == MOVER:
        return "FALSE"
    # b 整件从同一种非 MOVER 的色换成 MOVER 色
    cb = {bp[i][j] for (i, j) in b - a}
    if len(cb) != 1 or cb.pop() == MOVER:
        return "FALSE"
    if any(bn[i][j] != MOVER for (i, j) in b):
        return "FALSE"
    return "TRUE"
