"""帧上有沉睡件时，点在沉睡件的实心块上：被点的那块不再全 4（它醒了）；
**非底色格集一格不变**（点击不移动任何件、不生出格子也不吃掉格子）；
颜色只在「许变区」内变——许变区 = 被点块经由激活件的遮挡能连到的全部沉睡块
（真身被可动件切断成几段，段与段只在可动件底下相连）∪ 激活件自己 ∪ 焊格；此外一格不动。"""
LEVEL = "L6"
SCOPE = ("只管 prev 帧上有沉睡件、且点在沉睡件实心块上的局面："
         "没有沉睡件让给 select_click 的色 0 regime；点在激活件上/插头上/空处返回 NA；"
         "点在网格外返回 NA；换关返回 NA。只管 20x20 块网格。"
         "**许变区内部一律不断言**：真身到底覆盖哪些格子、醒来后哪格显真色哪格显插头 8、"
         "旧激活件睡回去显真色还是色 4（取决于它是否曾醒过，第 439 步），帧上全读不出来。"
         "本条只断言三件两帧都算得出的事：被点块不再全 4、非底色格集不变、许变区之外颜色不动。"
         "本条不写 apply：三条主张里没有一条能给出帧差格的颜色。")
NOTE = ("v8：v7 的三条分支全返 NA（点沉睡件 NA、点激活件 NA、点别处 NA），只剩「点空处整帧不动」"
        "而那种转移没有帧差 —— 所以 N=0 / NA率 100% 是**构造出来的**，不是还没轮到它。"
        "v7 缩得对的只有一处：旧激活件睡回去的颜色读不出（第 439 步）。那是一块格子的颜色，"
        "不该让掉整条转移。v8 把它连同真身覆盖范围一起放进许变区不断言，"
        "另外三件帧上算得出的事照旧断言，全语料 57 条入 scope 的点沉睡件转移上 P1/P2/P3 各 57/57 TRUE"
        "（施测脚本 runs/<run>/clickclaims.py，含第 439 步与最近那次点击）。"
        "许变区的形状是这次施测逼出来的：最初只收「贴着激活件的色 4 块」，7 条判 FALSE，"
        "全是同一个死因——真身被可动件遮断成两段，两段只经由可动件**底下**的格子相连，"
        "隔着一整段遮挡收不到。改成在「色4 ∪ 激活件格」上取被点块的连通闭包，7 条全转 TRUE。"
        "教训（已进方法册草稿）：**「许变区」不是「贴着谁」，是「经由遮挡连通到谁」**；"
        "遮挡把一件切成几段时，段与段的连接路径整个在遮挡物底下，任何「相邻」口径都收不到它。"
        "v7：点沉睡件唤醒、连带旧激活件沉睡，旧激活件的格子变成真色而非 4（曾醒过的件睡回去显真色，"
        "没醒过的显 4，帧上读不出「这件是否曾醒过」）。v7 的处置是整条返 NA，v8 只把那块格子让进许变区。"
        "v6：点了团块中央，醒来的是真身整件——可动件坐在整件顶行上把它切成两块还盖住 3 格，"
        "点其中一块，另一块连同被盖住的格子一起显真形；可动件睡回去但它压住的格子没有变 4，"
        "露出的是底下唤醒件的真形。「格集不变」和「原激活件全变 4」在叠盖局面下双双不成立，"
        "`_match_piece` 就此退役：格集层面的核对在叠盖世界里没有可核对的对象。"
        "v5：点醒一个一侧焊在醒着的件上的沉睡件时判 FALSE，错在**「格集不变」这句话的两边由两个不同的"
        "函数算出来**（prev 侧 solid_comps 按实心色切、漏掉显 3 的焊格；next 侧 pieces 把焊格算进来），"
        "两边差一格当场判不匹配。同一天同一种病在 wake_plugs 上也犯过（v8），教训进方法册："
        "一个集合在两帧上由两个函数分别算出来时，先核对这两个函数的切分口径是不是同一个。"
        "v4：把睡着的笔件点醒，醒来那些块里色 0 的笔头自成一个 pieces() 分量，`_match_piece` 要求"
        "整个格集恰好等于某一个分量，把一次完全正常的唤醒判成了错；改成覆盖核对。"
        "顺带记下：唤醒把睡前的样子原样还回来，笔头连同颜色一起回来，逐格一格不差。"
        "v3（词汇）：画图态里点亮沉睡件时，原激活件是「笔头 + 与它连通的那一团」，"
        "而当时 _lib.active 只认得整件式的件、返回 None，本条于是把那一团整体变色当成了「别的格子乱动」。"
        "修在 _lib.active/targets，主张一字没动。"
        "v2：焊上第一对之后发现焊的显示不归睡眠管——可动件的插头压上隐藏插头照样显 3，"
        "于是「沉睡全变 4」缩掉焊格：焊格在沉睡后显 3 还是 4 没实测过，不断言也不生成。"
        "最早几步实测拼出来的：点激活件它全变 4；点沉睡件它显真形，同时原激活的全变 4"
        "——**同一时刻至多一个件醒着**；点空处两连测帧不动；唤醒的件直接被 ACTION1-4/5 移动。")
EVIDENCE = ["97360c6e90200cb3", "d0fc0b89c35b2cdd", "74620651464eb92a", "be98e01ecd5cdf50",
            "9c849f4dea42159d", "e96c6e25a450bcd7", "33bad5f050c05a79", "ddba77f9c630b642",
            "8fa62b9667502576", "4ce04d06f06f711c", "be575e164358377c", "508909ab56ad1152",
            "1af5698036838cc6", "1a0207f75bdf8fc6", "a8088e79d08dbd62", "4ed8b0a5faf1fdbb",
            "71b082a6f120062b", "a83c3e05c8315f4e"]

from _lib import blocks, bg, active, solid_comps, click_target, WELD, NB, _nb4


def _sleepers(bp):
    return [c for c in solid_comps(bp) if all(bp[p[0]][p[1]] == 4 for p in c)]


def _free_zone(bp, tgt, ap):
    """许变区：被点块经由**激活件的遮挡**能连到的全部沉睡块，加上激活件自己和焊格。

    为什么是连通闭包而不是「贴着激活件」：可动件坐在一件上时把它在帧上切成几段，
    段与段的连接路径整个压在可动件底下（最近那次点击是两段各 3 格、只经由 3 个被盖格相连）。
    任何「相邻」口径都收不到隔着一整段遮挡的那一半，只有在「色4 ∪ 激活件格」上取连通闭包才收得到。"""
    node = {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] == 4} | set(ap)
    zone, stack = {tgt}, [tgt]
    while stack:
        q = stack.pop()
        for n in _nb4(q):
            if n in node and n not in zone:
                zone.add(n)
                stack.append(n)
    zone |= set(ap)
    zone |= {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] == WELD}
    return zone


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.upper().startswith("ACTION6") or ":" not in action:
        return "NA"
    bp = blocks(prev)
    sl = _sleepers(bp)
    if not sl:
        return "NA"                                  # 让给 select_click 的色 0 regime
    tgt = click_target(action)
    if tgt is None or not (0 <= tgt[0] < NB and 0 <= tgt[1] < NB):
        return "NA"                                  # 点在网格外，没实测过
    hit = next((c for c in sl if tgt in c), None)
    if hit is None:
        return "NA"                                  # 点在激活件/插头/空处，v7 起不断言
    bn = blocks(nxt)

    # P1 被点的那块醒了
    if all(bn[p[0]][p[1]] == 4 for p in hit):
        return "FALSE"

    # P2 非底色格集一格不变（点击不移动任何件）
    nz_p = {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] != bg(bp)}
    nz_n = {(i, j) for i in range(NB) for j in range(NB) if bn[i][j] != bg(bn)}
    if nz_p != nz_n:
        return "FALSE"

    # P3 许变区之外颜色不动
    zone = _free_zone(bp, tgt, active(prev, bp) or {})
    for i in range(NB):
        for j in range(NB):
            if (i, j) not in zone and bp[i][j] != bn[i][j]:
                return "FALSE"
    return "TRUE"
