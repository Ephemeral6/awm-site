"""顶栏（像素第 0 行，列 16..47，32 格）是一条进度条，每条转移只有两种走法：整段一格不动，或恰好最左端那一格色 4 变色 0（至多退 1 格、只退最左）；
换关那一步例外：整段精确变回 32 格满色 4——但**通关整局的那一次不续满**，那一步照普通步走。"""
LEVEL = "L4"
SCOPE = ("只管像素第 0 行、列 16..47 这 32 格；不管其余像素。"
         "换关（ctx 里 level_prev != level_next）且 state_next 不是终局：断言这 32 格在 nxt 里精确等于 32 个色 4。"
         "换关且 state_next 是 WIN/GAME_OVER（整局结束）：不续满，按下面「未换关」那一支判。"
         "未换关（任意动作，含 ACTION6 点选）：prev 段里数不出色 4 时 NA；否则 nxt 只许两种——与 prev 完全相同，"
         "或恰好把当前最左端的色 4 变成色 0（其余 31 格不许动）。"
         "ctx 缺失时按未换关处理。")
NOTE = ("v2 缩了一刀：v1 曾主张「ACTION6 点选时顶栏一格不动」（依据第 28、30 步两次点选都没动），"
        "第 87 步点选件0 时顶栏推进了 1 格（tid e39d63a0ce0103cf），这条被打掉——点选也会推进，"
        "于是点选和其余动作合并回同一条弱主张。"
        "「推进到底数的是什么」册子现在说不出，两条候选都被数据打掉，记在这——"
        "『推进对应配对/焊』：第 66 步帧上出现 18 格焊色时顶栏只推进过 2 格，第 86 步焊出 18 格、第 87 步才推进第 9 格，对不上，弃；"
        "『推进按真实等待时长』：四次长间隔（422~844 秒）里只有一次恰好赶上推进，弃。"
        "但有一条硬观察：第 1 关第一次访问推进的位置（关内编号 2,5,8,11,15,18,21,24），"
        "在第 42 步之后 RESET、沿同样的动作串走回（第 60~84 步）时**逐一复现**，一个不差——"
        "推进是动作串的确定函数，不是墙钟；触发规律全表在 runs/cn04-0907-1226/hud_findings.md，单步断言钉不进「距上次推进过了几步」，留待词汇升级。"
        "v3：v2 死在第 301 步（tid 4a586a5d25195873）——那一步既是第 5 关通关、也是整局 WIN，"
        "level_prev=5、level=6，按 v2 该续满，实际顶栏**一格没动**（进 32 格前还剩 23 格色 4）。"
        "前五次换关都续满，唯独这次不续，差别是 state 变成了 WIN：局都结束了，没有下一关要给预算。"
        "所以「换关就续满」要拆成两支，终局那一支断言「不动」——这比原来更强，不是缩 scope 躲开。"
        "v4：v3 那一支死在终局卡的第 742 步（tid 860df159c06b6132）——同样是第 5 关通关、同样 state_next=WIN，"
        "顶栏这次**退了最左一格**（26→25 格色 4，列 22 由 4 变 0）。"
        "v3 的死因不是判断错了机制，是**样本只有一条**：终局那一步整个语料里只发生过两次，"
        "第一次恰好不动，我就把「不动」写成了主张。两次并排看，它们正好是普通步允许的两种走法（不动 / 退最左一格）。"
        "所以终局那一支不再单独断言，直接落回普通步那一支——弱了，但两条转移都判 TRUE，"
        "而「不续满」这半句仍然是真主张（十七次非终局换关全部续满，终局两次一次都没续）。")
EVIDENCE = ["f6a961fe2c16e51e", "d0153d5b9f4cb065", "0884f4858d4b2371", "cc7736b187c53fa5",
            "ed8565b06c21bc15", "99028d06707aaa31", "a5f08d1d81d0bf8a", "58632b08ea39b084",
            "848bbf4d455b1df1", "ec080db28d36a461", "ef68d9f442a9c18b", "34baa5e568adccaa",
            "6b406ed12e9ef9ab", "e39d63a0ce0103cf", "4a586a5d25195873", "860df159c06b6132"]

BAR = 4
SPENT = 0
COLS = list(range(16, 48))  # 32 格


def _seg(row):
    return [row[c] for c in COLS]


def _leftmost4(seg):
    for i, v in enumerate(seg):
        if v == BAR:
            return i
    return None


ENDED = ("WIN", "GAME_OVER")


def assert_(prev, action, nxt, ctx=None):
    seg_a = _seg(prev[0])
    seg_b = _seg(nxt[0])

    level_changed = bool(ctx) and ctx.get("level_prev") is not None and \
        ctx.get("level_next") is not None and ctx.get("level_prev") != ctx.get("level_next")

    if level_changed and not (bool(ctx) and ctx.get("state_next") in ENDED):
        return "TRUE" if seg_b == [BAR] * len(COLS) else "FALSE"
    # 终局那一步不续满，落到下面按普通步判（v4：两次终局一次不动、一次退最左一格）。

    if seg_a == seg_b:
        return "TRUE"
    i = _leftmost4(seg_a)
    if i is None:
        return "NA"
    want = list(seg_a)
    want[i] = SPENT
    return "TRUE" if want == seg_b else "FALSE"


def apply(prev, action, ctx=None):
    """只认领猜得准的那一支：换关且局没结束（整段填满色 4）。其余动作猜不出这一步退不退，不生成。"""
    level_changed = bool(ctx) and ctx.get("level_prev") is not None and \
        ctx.get("level_next") is not None and ctx.get("level_prev") != ctx.get("level_next")
    if level_changed and ctx.get("state_next") not in ENDED:
        return {(0, c): BAR for c in COLS}
    return None
