"""ACTION5 让可动件绕自身 bbox 左上角顺时针转 90°（bbox 左上角的块坐标不变），别的件一格不动（帧按 _lib.render 的画法核对）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION5；换关返回 NA；可动件定位不到返回 NA；落位出界、或可动件的实心块要压到别的件身上时返回 NA"
         "（那是 L2 阻挡的空槽，册子还没见过）；**有色 8 的格子同时贴着可动件和别的件的实心块时返回 NA**"
         "（分不清那个插头归谁，连谁跟着走都说不准）；只管 20x20 块网格（像素行 0/1/62/63 的顶栏不管）。"
         "**第 4 关起，醒着的是那支笔画出来的件时返回 NA**（`_lib.is_pen`）：对它 ACTION5 是长节/撤节；"
         "对同一关里别的醒着的件，ACTION5 照旧是旋转（第 195 步实测）。")
NOTE = ("v2：底色按帧现算，可动件改成含 MOVER 色的连通分量。"
        "v3：EVIDENCE 从 3 条砍到 1 条 —— 把同一动作的转移全塞进依据，等于吃掉自己的考场，E 反而掉。"
        "v4：插头配上对的那一步让给 dock_weld。"
        "v5：跟 move_* 同步 —— 焊接可逆、件从不合并，改成用 _lib.render 分层画。"
        "v8（词汇）：第 155 步判 FALSE —— 可动件带着焊格原地转，焊格 prev 显 3、被 static_layer "
        "重画成 4，render 把落点画成 8。修在 _lib.render：插头落点见既有焊显 3、见沉睡件格闭嘴。"
        "主张本身（绕 bbox 左上角转、别件不动）没动。"
        "v9（词汇）：第 185 步判 FALSE —— 那个 regime 里色 0 只有单块，ACTION5 根本不是转："
        "笔头下移一格、原处长出一节实体加一个插头（只动 3 块）。修在 _lib.active："
        "色 0 单块时件 = 笔头 + 与它 4 连通的那一团（见 _lib.active）；当时按关卡缩成「只管第 0-3 关」。"
        "v10：第 190 步判 FALSE —— 画完之后（笔头消失、册子按第 2 关式认回醒着的件）再按 ACTION5，"
        "世界把**上一节撤了**：(10,7) 11→0 笔头回来、(10,8)(10,9) 11→15、(10,10) 8→15，只动 4 块。"
        "当时据此断定「第 4 关的 ACTION5 与旋转无关」，继续按关卡缩。"
        "v11：**那个断定是错的，而且是我自己缩错了维度**。第 195 步押注实测：第 4 关里点亮一个靶件"
        "（6 格、真色 12）再按 ACTION5，它照旧绕 bbox 左上角顺时针转 90°，恰好 6 块变，与本条的预测一格不差。"
        "所以第 4 关的 ACTION5 分两族，分界是**作用在谁身上**，不是第几关："
        "笔画出来的那个件 → 长节/撤节；别的醒着的件 → 旋转。按关卡缩把后一族一起闭掉了，"
        "白丢了整整一关的覆盖率，而终局卡上这一关还要再走一遍。"
        "换成 `_lib.is_pen` 之后本条在第 195 步判 TRUE，第 185/190 步照旧 NA。"
        "教训写进 runs/cn04-0907-1226/METHOD.proposals.md：换 regime 挨打时，"
        "先问清楚「新动作是对所有件都变了，还是只对某一类件变了」再决定缩哪一维。"
        "下一版（生成器）：加 _lib.may_clear 闸——沉睡 regime 里 clears_level 数不出隐藏插头、"
        "一律为假，apply 在真换关那一步照旧逐格生成，而换关整帧重画。可能换关就闭嘴"
        "（全量语料 433 步 move/rot 里挡 57 步，5 步真换关、0 漏网、52 步白挡）。assert_ 不动。")
EVIDENCE = ["b6e2eef29df84193", "d5e7653baf7e542e", "b630d38809ca109a", "64b6398ce8ef40bf",
            "86ddc938ab99d0b2"]

from _lib import (blocks, movable, anchor, rot_cw_shape, place, render, clears_level,
                  may_clear, to_pixels, is_pen, NB)

KEY = "ACTION5"


def _pred(prev):
    bp = blocks(prev)
    m = movable(prev, bp)
    if m is None:
        return None, None
    if clears_level(prev, KEY, bp):
        return bp, None
    new = place(rot_cw_shape(m), *anchor(m))
    return bp, render(prev, new, bp)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if (ctx or {}).get("level_prev", 0) >= 4 and is_pen(prev):
        return "NA"                      # 笔画出来的那个件：ACTION5 是长节/撤节（第 185/190 步）
    if action != KEY:
        return "NA"
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return "NA"
    return "TRUE" if pred == blocks(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if action != KEY or ((ctx or {}).get("level_prev", 0) >= 4 and is_pen(prev)):
        return None
    if may_clear(prev, KEY):
        return None                      # 可能换关：整帧会重画，生成器闭嘴
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return None
    out = {}
    for i in range(NB):
        for j in range(NB):
            if pred[i][j] != bp[i][j]:
                out.update(to_pixels({(i, j): pred[i][j]}))
    return out or None
