"""这一步把场上最后剩的 MARK 块全部配上对（可动件的 MARK 全落在别的件的 MARK 上，且别的件再没有别的 MARK 剩下），就换关（level 加一）。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1-5（其余动作返回 NA）；可动件定位不到、或场上只有可动件一个件时返回 NA；"
         "这一步之后场上还剩没配对的 MARK 块时返回 NA（那是 goal_needs_dock 管的方向）。"
         "落位按 move_*/rot_cw 的主张算，配对按 _lib.pairing 算"
         "（有色 8 的格子同时贴着可动件和别的件的实心块时 pairing 说不清、本条返回 NA）。")
NOTE = ("v1「可动件的 MARK 全落在别的件的 MARK 上就换关」在第 24 步被推翻：色 0 件的两个 MARK 确实全对上了"
        "（那两格 8->3，见 dock_weld），但**没有换关** —— 场上还剩 8 个 MARK。"
        "v2 改成「把场上最后剩的 MARK 全配掉才换关」：第 0 关全场只有 4 个 MARK（可动件 2 + 靶 2），"
        "第 18 步一次配光，换关；第 1 关有 12 个，第 24 步只配掉 4 个，不换关。两条转移都对得上。")
EVIDENCE = ["58632b08ea39b084", "d1e1ed10398efa35"]

from _lib import blocks, movable, targets, pairing

KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5")


def assert_(prev, action, nxt, ctx=None):
    if action not in KEYS:
        return "NA"
    bs = blocks(prev)
    if movable(prev, bs) is None or not targets(prev, bs):
        return "NA"
    new, welds, rest = pairing(prev, action, bs)
    if new is None:
        return "NA"
    if not welds or rest:
        return "NA"                      # 没配光：这一条不管
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
