"""这一步之后场上还剩着没配对的 MARK 块，就绝不换关。"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1-5（其余动作返回 NA）；可动件定位不到、或场上只有可动件一个件时返回 NA。"
         "「落位」按 move_*/rot_cw 的主张算：平移 1 块或绕自身 bbox 左上角顺时针 90°；配对按 _lib.pairing 算"
         "（有色 8 的格子同时贴着可动件和别的件的实心块时 pairing 说不清、本条返回 NA）。"
         "只断言否定方向：还剩 MARK 就不换关；配光了会不会换关是 goal_dock_wins 的事。")
NOTE = ("v2：从「可动件的 MARK 没全落在别的件的 MARK 上就不换关」放宽成「场上还剩没配对的 MARK 就不换关」。"
        "第 24 步是它管得着的新一类：可动件自己的 MARK 全配上了，但场上还剩 8 个，果然没换关。"
        "v1 在那一步返回 NA（它只看可动件自己），漏掉了一次真检验。")
EVIDENCE = ["d9d20c16b6598792", "2a4dfa29a1aaf221", "a3e234c929772b97", "d1e1ed10398efa35"]

from _lib import blocks, movable, targets, pairing

KEYS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5")


def assert_(prev, action, nxt, ctx=None):
    if action not in KEYS:
        return "NA"
    bs = blocks(prev)
    if movable(prev, bs) is None or not targets(prev, bs):
        return "NA"
    new, welds, rest = pairing(prev, action, bs)
    if new is None:
        return "NA"
    if not rest:
        return "NA"                      # 配光了：这一条不管
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    return "TRUE" if ctx["level_prev"] == ctx["level_next"] else "FALSE"
