"""ACTION1-4 让可动件的每个实心块都恰好挪 1 格，落点在 next 里一律显示 MOVER 色——哪怕那一格原本是别的件的块。

也就是说：**这个世界没有碰撞判定**，可动件想去哪去哪，重叠处它画在最上面。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1-4（ACTION5 转向不管：转向要用 bbox，而 bbox 含插头，重叠时插头归属说不准）；"
         "换关返回 NA；可动件定位不到返回 NA；落位有块出 20x20 网格时返回 NA（没实测过）。"
         "**只断言可动件自己的实心块**：它们挪到哪、那一格显不显示 MOVER 色，以及 MOVER 色的格数一格不多一格不少。"
         "让出来的格子露出什么，本条一个字不说——那是 move_* 用 _lib.render 管的事，"
         "而被盖住的东西帧上根本读不出来。只管 20x20 块网格。")
NOTE = ("第 39 步实测：可动件的实心块 (17,15) 右移到 (17,16)——那里原本是色 9 小件的实心块——"
        "没有被挡住，那一格变成色 0，小件的块被盖住看不见了。第 40 步左移回来，(17,16) 原样显示色 9，"
        "(15,16) 的色 8 插头也原样回来了：**盖住是可逆的，底下的东西原封不动**。"
        "但「原封不动地留在底下」这半句写不进主张：单帧上读不出被盖住的是什么，"
        "assert_ 只拿得到 (prev, action, next)。所以本条只断言看得见的那一半。"
        "这一条填的是地图 L2（阻挡）——填进去的内容是「没有阻挡」，空槽不等于没答案。"
        "它的 apply 在 move_* 闭嘴的局面（mover_plug_ambiguous）里照样开口："
        "可动件的实心块是色 MOVER，不管重叠不重叠都认得出来。"
        "v2（只改 apply，主张一字未动）：v1 的 apply 比它的 assert_ 话多——assert_ 换关判 NA，"
        "apply 却照样按旧关的帧算落点，第 18、60、99 步三次换关整批说错（315 格里的 315 格全在这三步）。"
        "这不是主张错，是生成器漏了判断器早就写着的那一刀；补上后全语料 apply 说错 0 格。"
        "同一刀写了两遍、判据不同：ctx 那一遍只在结算时有用（链预测的 ctx 一律按「不换关」给），"
        "真正管终局卡的是 `clears_level` 那一遍——它从 prev 帧和动作算得出，和 move_* 同款。"
        "查法留档：runs/cn04-0907-1226/cscore.py 逐条复算任一概念的 apply 命中，"
        "settle 只报总数，出处得自己找。"
        "下一版（生成器）：apply 里的换关闸从 clears_level 换成 _lib.may_clear——沉睡 regime 里"
        "隐藏插头数不出来，clears_level 一律为假，真换关那一步照旧生成、整批说错。"
        "（全量语料 433 步 move/rot 里挡 57 步，5 步真换关、0 漏网、52 步白挡）。assert_ 不动。")
EVIDENCE = ["6b406ed12e9ef9ab"]

from _lib import blocks, bg, clears_level, may_clear, to_pixels, MOVER, NB

DELTA = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def _pred(prev, action):
    d = DELTA.get(action)
    if d is None:
        return None, None
    bp = blocks(prev)
    if bg(bp) == MOVER:
        return None, None
    cells = [(i, j) for i in range(NB) for j in range(NB) if bp[i][j] == MOVER]
    if not cells:
        return None, None
    new = [(i + d[0], j + d[1]) for i, j in cells]
    if any(not (0 <= i < NB and 0 <= j < NB) for i, j in new):
        return None, None
    return bp, new


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    bp, new = _pred(prev, action)
    if bp is None:
        return "NA"
    bn = blocks(nxt)
    for i, j in new:
        if bn[i][j] != MOVER:
            return "FALSE"
    got = sum(1 for i in range(NB) for j in range(NB) if bn[i][j] == MOVER)
    return "TRUE" if got == len(new) else "FALSE"


def apply(prev, action, ctx=None):
    """只认领可动件实心块的新位置。被盖住的东西说不出来，让出的格子也不归本条管。

    换关那一步闭嘴：新关的帧和旧关的可动件没关系（第 18、60、99 步都是这么整批说错的）。
    判「这一步换不换关」用 `_lib.may_clear`（帧上算得出，和 move_* 同款），不靠 ctx——
    链预测里的 ctx 一律按「这一步不换关」给，靠它等于在真正换关那一步睁眼说瞎话。
    沉睡 regime 里 `clears_level` 数不出隐藏插头、一律为假，所以要连「可能换关」一起闭嘴。"""
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    bp, new = _pred(prev, action)
    if bp is None:
        return None
    if may_clear(prev, action, bp):
        return None
    return to_pixels({p: MOVER for p in new})
