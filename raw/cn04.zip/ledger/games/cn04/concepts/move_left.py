"""ACTION3 让可动件整体左移恰好 1 块，别的件一格不动（帧按 _lib.render 的画法核对：让出的格子露出底下原本有的东西，插头重合的格子显示色 3）。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3；换关返回 NA；可动件定位不到返回 NA；落位出界、或可动件的实心块要压到别的件身上时返回 NA"
         "（那是 L2 阻挡的空槽，册子还没见过）；**有色 8 的格子同时贴着可动件和别的件的实心块时返回 NA**"
         "（分不清那个插头归谁，连谁跟着走都说不准）；只管 20x20 块网格（像素行 0/1/62/63 的顶栏不管）。"
         "**不留「整帧不动」这条退路** —— 27/27 步每一步都真的动了，这条主张就得赌它总是动。")
NOTE = ("v2：底色按帧现算，可动件改成含 MOVER 色的连通分量。"
        "v3：插头配上对的那一步让给 dock_weld。"
        "v4：跟 move_up/move_down 同步 —— 焊接可逆、件从不合并，改成用 _lib.render 分层画，"
        "去掉「或整帧不动」的退路，本条也管配对那一步。"
        "v7（词汇）：第 178 步判 FALSE —— 可动件的实心盖住沉睡件的格，prev 那里显可动件的色、"
        "被算进可动件的连通域；让出时世界显 4（沉睡块露出来），render 画了底色。修在 _lib.render："
        "让出的格子贴着沉睡件格集且静态层以为是底色时闭嘴。主张本身（左移 1 块、别件不动）没动。"
        "v8（词汇）：第 183 步判 FALSE —— 那里色 0 只有单块，贴着它的一大团跟着一起动，"
        "「可动件动、别件不动」整个不成立。修在 _lib.active：色 0 单块时，件 = 笔头 + 与它 4 连通的那一团，"
        "targets 再排掉整个落在件里的分量。改完本条在第 183 步判 TRUE —— **主张一字没动，"
        "错的是词汇认错了件**：那一步动的确实是「可动件整体左移 1 块、别件不动」，可动件是一整团。"
        "（v8 曾把这一片缩成闭嘴，是我先认输得太早。）"
        "下一版（生成器）：加 _lib.may_clear 闸——沉睡 regime 里 clears_level 数不出隐藏插头、"
        "一律为假，apply 在真换关那一步照旧逐格生成，而换关整帧重画。可能换关就闭嘴"
        "（全量语料 433 步 move/rot 里挡 57 步，5 步真换关、0 漏网、52 步白挡）。assert_ 不动。")
EVIDENCE = ["0884f4858d4b2371", "cb9e244fb7a7413f", "ceacd5626b0cc04d"]

from _lib import blocks, movable, render, clears_level, may_clear, to_pixels, NB

DR, DC = 0, -1
KEY = "ACTION3"


def _pred(prev):
    bp = blocks(prev)
    m = movable(prev, bp)
    if m is None:
        return None, None
    if clears_level(prev, KEY, bp):
        return bp, None
    new = {(r + DR, c + DC): v for (r, c), v in m.items()}
    return bp, render(prev, new, bp)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != KEY:
        return "NA"
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return "NA"
    return "TRUE" if pred == blocks(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if action != KEY:
        return None
    if may_clear(prev, KEY):
        return None                      # 可能换关：整帧会重画，生成器闭嘴
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return None
    out = {}
    for i in range(NB):
        for j in range(NB):
            if pred[i][j] != bp[i][j]:
                out.update(to_pixels({(i, j): pred[i][j]}))
    return out or None
