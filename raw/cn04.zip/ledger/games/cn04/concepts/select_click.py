"""ACTION6:x,y 点在某个件的实心块上，就把那个件变成可动件：它整件变成色 0，原来的色 0 件整件换成另一个非底色的颜色，插头照旧色 8，所有件一格都不动。（只管色 0 高亮 regime；帧上有沉睡件——实心全 4 的件——时返回 NA，那套开关由 sleep_wake 主张。）"""
LEVEL = "L6"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；点在底色/插头/网格外、或点到的件已经是可动件时返回 NA（都没实测过）；"
         "prev 帧上有沉睡件（实心一格全 4 的连通件）时返回 NA——那是另一套 regime，见 sleep_wake；"
         "**不断言原来那个件会变成哪个色** —— 选中时它的真色被色 0 盖着，帧上看不出来；"
         "只断言「变成同一个非底色非色 0 的颜色」。只管 20x20 块网格。")
NOTE = ("第 28 步实测：点在色 9 件的实心块 (17,16) 上，色 9 的 5 个实心块 9->0，"
        "同时色 0 那个件的 10 个实心块 0->15，两个件的插头（色 8）一格没变，位置也一格没动，共 135 格。"
        "第 29 步紧接着的 ACTION1 移动的正是新选中的那个件（色 9 那个），"
        "move_up 靠 movable() 找色 0 的件，因此不用改就判对了 —— 「色 0」原来是选中态的画法，不是某个件的身份。"
        "这一条解开了本关的死结：本关 12 个插头，可动件自己只有 2 个，非得能换件才配得完。"
        "v2 缩了一刀：第 2 关的点击是另一套开关（唤醒/沉睡，见 sleep_wake），"
        "第 100/106/109/110 步四条转移上本条的「变色 0」被判 FALSE——那几步帧上根本没有色 0。"
        "缩法不是按关卡号，是按帧上可辨的 regime：有实心全 4 的沉睡件就让给 sleep_wake。")
EVIDENCE = ["848bbf4d455b1df1", "97360c6e90200cb3", "74620651464eb92a", "9c849f4dea42159d",
            "e96c6e25a450bcd7"]

from _lib import blocks, bg, pieces, movable, click_target, MARK, MOVER, to_pixels, NB


def _has_sleeper(bp):
    for comp in __import__("_lib").solid_comps(bp):
        if all(bp[p[0]][p[1]] == 4 for p in comp):
            return True
    return False


def _parts(prev, action):
    """返回 (块网格, 点到的件, 原来的可动件)；任一项拿不到返回 (None, None, None)。"""
    tgt = click_target(action)
    if tgt is None or not action.upper().startswith("ACTION6"):
        return None, None, None
    bp = blocks(prev)
    if bp[tgt[0]][tgt[1]] in (bg(bp), MARK):
        return None, None, None
    hit = None
    for p in pieces(prev, bp):
        if tgt in p and p[tgt] != MARK:
            hit = p
    old = movable(prev, bp)
    if hit is None or old is None or MOVER in hit.values():
        return None, None, None
    return bp, hit, old


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    bp = blocks(prev)
    if _has_sleeper(bp):
        return "NA"
    _bp, hit, old = _parts(prev, action)
    if hit is None:
        return "NA"
    bn = blocks(nxt)
    hit_solid = [p for p in hit if hit[p] != MARK]
    old_solid = [p for p in old if old[p] != MARK]
    for (i, j) in hit_solid:
        if bn[i][j] != MOVER:
            return "FALSE"
    got = {bn[i][j] for (i, j) in old_solid}
    if len(got) != 1:
        return "FALSE"
    c = got.pop()
    if c in (MOVER, bg(bp)):
        return "FALSE"
    touched = set(hit_solid) | set(old_solid)
    for i in range(NB):
        for j in range(NB):
            if (i, j) not in touched and bp[i][j] != bn[i][j]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只生成点到的那个件（它变成色 0）；原来那个件会变成哪个色，帧上读不出来，本条不猜。"""
    bp, hit, _old = _parts(prev, action)
    if bp is None:
        return None
    if _has_sleeper(bp):
        return None                      # 沉睡 regime 是 sleep_wake 的地盘，本条不生成
    out = {}
    for (i, j), v in hit.items():
        if v != MARK and bp[i][j] != MOVER:
            out.update(to_pixels({(i, j): MOVER}))
    return out or None
