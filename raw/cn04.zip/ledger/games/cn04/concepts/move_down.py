"""ACTION2 让可动件整体下移恰好 1 块，别的件一格不动（帧按 _lib.render 的画法核对：让出的格子露出底下原本有的东西，插头重合的格子显示色 3）。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION2；换关返回 NA；可动件定位不到返回 NA；落位出界、或可动件的实心块要压到别的件身上时返回 NA"
         "（那是 L2 阻挡的空槽，册子还没见过）；**有色 8 的格子同时贴着可动件和别的件的实心块时返回 NA**"
         "（分不清那个插头归谁，连谁跟着走都说不准）；只管 20x20 块网格（像素行 0/1/62/63 的顶栏不管）。"
         "**不留「整帧不动」这条退路** —— 27/27 步每一步都真的动了，这条主张就得赌它总是动。")
NOTE = ("v2：底色按帧现算，可动件改成含 MOVER 色的连通分量。"
        "v3：第 24 步判 FALSE（插头重合的两格 8->3 不是照搬颜色），当时把那一步让给了 dock_weld。"
        "v4：第 25 步证明焊接可逆、件从不合并，改成用 _lib.render 分层画，本条重新接管配对那一步，"
        "并去掉「或整帧不动」的退路。第 24 步现在由本条直接判 TRUE。"
        "v6：第 36/37 步判 FALSE，各说错 27 格 —— 可动件的横臂扫到小件插头旁边，_lib 的「可动件优先」"
        "把人家的插头判给了可动件，于是预测它跟着走，实际它一动没动。这不是本条的主张错，是词汇分不清；"
        "在 _lib 里加了 mover_plug_ambiguous，含糊就闭嘴（全量语料上考过四条归属规则，只有闭嘴这条说错 0）。"
        "v7：第 88/89 步判 FALSE，各说错 2 格 —— 两个靶件（件2 与基座）焊住之后，可动件（件0）在别处动，"
        "_lib.static_layer 平铺各靶件时把焊格画回了色 8（pieces() 把色 3 一律记成 MARK，重数信息丢了）。"
        "修在词汇层：static_layer 按几个靶件的插头落格计重数，≥2 画 WELD；本条主张一字未改。"
        "v8：第 118 步判 FALSE（说错 1 格）——L2 装配路上，可动件的插头压上沉睡底件盖着的隐藏插头，"
        "那一格显 3（焊越过沉睡照样显示），render 预测的是 8。隐藏插头在哪帧上读不出，"
        "修在词汇层：_lib.sleeper_touch——落位压到沉睡件的格子上时 render 返回 None，本条跟着闭嘴。"
        "v9（词汇）：第 182 步判 FALSE —— 色 0 只有单块、贴着它的一大团跟着一起动（11 块一起变），"
        "「可动件动、别件不动」在那个 regime 里整个不成立。修在 _lib.active：色 0 单块时，"
        "件 = 笔头 + 与它 4 连通的那一团（沿非底色非 4 泛洪），targets 再排掉整个落在件里的分量。"
        "改完本条在第 182 步判 TRUE —— **主张一字没动，错的是词汇认错了件**：那一步动的确实是"
        "「可动件整体下移 1 块、别件不动」，只不过可动件是一整团而不是那一个笔头。"
        "（v9 曾把这一片缩成闭嘴，是我先认输得太早。）"
        "v10（生成器）：沉睡 regime 里 _lib.pairing 数不出隐藏插头，clears_level 于是一律为假，"
        "apply 在真换关那一步照旧逐格生成——而换关整帧重画，那一批全错。加 _lib.may_clear："
        "可能换关就闭嘴。全量去重语料 433 步 move/rot 里挡下 57 步，其中 5 步真换了关（0 漏网），"
        "52 步白挡。assert_ 一字未动——它有 ctx，看得见换没换关，本来就判得动。")
EVIDENCE = ["d0153d5b9f4cb065", "d1e1ed10398efa35", "410b8dfa20d304b6", "4b054b4f5291b66c",
            "742e1307f04e8af1", "335fc07120075ce3", "ffb5f6e3c31db8bd", "383922ec0abce260"]

from _lib import blocks, movable, render, clears_level, may_clear, to_pixels, NB

DR, DC = 1, 0
KEY = "ACTION2"


def _pred(prev):
    bp = blocks(prev)
    m = movable(prev, bp)
    if m is None:
        return None, None
    if clears_level(prev, KEY, bp):
        return bp, None
    new = {(r + DR, c + DC): v for (r, c), v in m.items()}
    return bp, render(prev, new, bp)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != KEY:
        return "NA"
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return "NA"
    return "TRUE" if pred == blocks(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if action != KEY:
        return None
    if may_clear(prev, KEY):
        return None                      # 可能换关：整帧会重画，生成器闭嘴
    bp, pred = _pred(prev)
    if bp is None or pred is None:
        return None
    out = {}
    for i in range(NB):
        for j in range(NB):
            if pred[i][j] != bp[i][j]:
                out.update(to_pixels({(i, j): pred[i][j]}))
    return out or None
