"""可动件的一个插头（MARK）这一步的落位落到格子 c 上，c 本身**不是**沉睡件的格子，
但 c 的 4 邻里有沉睡件格（贴着，没压上去）时——只要这个插头不是落在可动件自己上一帧
就占着的格子上（连体件平移时前段让位、插头顶进自己刚空出的地盘，跟沉睡件无关）——
next 帧上 c 必显 MARK(8)，不会显 WELD(3)。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1-4；换关返回 NA；movable() 定位不到可动件、或 mover_plug_ambiguous() 为真"
         "（插头分不清归谁）返回 NA；场上没有沉睡件返回 NA；placed() 算不出落位返回 NA。"
         "落位里逐个插头(MARK)格子过：落在可动件自己 prev 帧就占着的格子上——跳过，不归本条管"
         "（那是自己给自己让位，跟沉睡件无关，混进来会把不相干的噪声算成反例）；"
         "落在沉睡件格子本身上——跳过，不归本条管（那是 sleep_overlay 的地盘，端末格分不清）；"
         "只管**不落在沉睡件格子上、但贴着沉睡件格**的插头。这一转移里一个符合条件的插头也没有，返回 NA。"
         "只管 20x20 块网格。")
NOTE = ("为什么要单独立这条：render() 现在见到落位的整个格集（不分实心/插头）跟沉睡件有任何交集"
        "（sleeper_touch）就整帧闭嘴——不区分「插头真压在沉睡件身上」（确实分不清，帧上读不出）跟"
        "「插头只是落在沉睡件旁边的空地上」（跟沉睡件完全无关，紧邻纯属巧合）。"
        "sleep_overlay.py 已经把前一半（sleeper_touch 为真时怎么判）啃过了；它的 SCOPE 明写"
        "「sleeper_touch() 为真」才管，贴着不压上去的这半从来没被断言过，是本条要补的空。"
        "\n"
        "普查脚本 runs/cn04-0907-1226/plug_sleeper_census.py，语料 runs/cn04-0907-1226/transitions.jsonl。"
        "全量原始行 578，按 tid 去重后 525 条；其中 ACTION1-4 去重后 378 条。"
        "先剔除「插头落在可动件自己旧地盘」这类噪声（182 个插头，cell 级，跟沉睡件无关——"
        "第 135/437/378 步实测：这类格子 prev 显的是可动件自己的实心色，不是底色也不是 MARK/WELD，"
        "next 是 8 还是 3 由别的规则决定，不该混进这题的统计）。"
        "剩下按「c 是不是沉睡件格」分两桶："
        "c 本身是沉睡件格（本条不管，留给 sleep_overlay）：28 个事件、22 条 tid，"
        "next 分布 {WELD(3): 23, MARK(8): 5}——不干净，这条真读不出来（跟 sleep_overlay 端末格的发现一致）。"
        "c 不是沉睡件格、但贴着沉睡件格（本条断言的这半）：50 个事件、41 条 tid，"
        "next 分布 {MARK(8): 50}——0 例外，全部显 8。"
        "\n"
        "顺带查过这条断言在 render() 现有保守规则下到底解不解禁：41 条 tid 里 40 条那一步的转移"
        "整体不含「插头真压沉睡件」的事件（纯桶B）；这 40 条里，render() 现在仍对 14 条返回 None——"
        "不是因为这个插头本身，是因为可动件落位的**别的格子**（实心块的某一格）另外压到了同一沉睡件上，"
        "触发了 sleeper_touch 对整帧的封口。本条只断言这一个插头格子的颜色，不接管整帧生成，"
        "所以不承诺解开那 14 条——那是可动件实心压沉睡件的问题，归 sleep_overlay 的 Q2 管。"
        "\n"
        "老实写死角：样本量 50/41，都在这一局的语料里；没有跨局验证。「自占」判据"
        "（插头落点是不是可动件自己 prev 帧的旧格子）只查了这一条件本身，没有再往下分——"
        "如果哪天出现「插头落在自己旧地盘、又贴着沉睡件」还显 WELD 之外的第三种颜色，本条不受影响"
        "（那种格子从一开始就被本条跳过，不进 checked 计数）。"
        "\n"
        "入册（从影子册提拔）：草稿由 specialist 写、由 settle 在影子册里打分——"
        "S=1.000 / C=0.056 / N=29 / P=1.000(315格)。提拔时只动 EVIDENCE，主张与代码一字未改。"
        "EVIDENCE 从 12 条砍到 3 条：sleep_overlay v1 刚在这上面吃过一记"
        "（23 条依据把自己能判的转移全吃光，settle 当场给 S=UNMEASURABLE / C=0 / N=0，"
        "等于吃掉自己的考场；rot_cw v3 更早挨过同一记）。本条 N=29 说明考场还在，"
        "但没有理由留着 12 条——留下的三条是：桶 B 普查里字典序第一条，"
        "加第 570、571 两步**事前押中**的（那两步押注明写「插头落点贴着沉睡件、显 8 不显 3」，实测对）。"
        "其余 9 条放回 held-out。")
EVIDENCE = [
    "03b52cf0cc1b674a",                     # 桶B 事后普查里的第一条
    "0ce14e76b5ec92ee",                     # 第 570 步：事前押中
    "3d304e2601544a58",                     # 第 571 步：事前押中
]

from _lib import (blocks, movable, placed, sleepers, mover_plug_ambiguous,
                   MARK, NB, _nb4, to_pixels)

MOVE_ACTIONS = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _sleeper_cells(prev, bp):
    out = set()
    for c in sleepers(prev, bp):
        out |= c
    return out


def _qualifying_marks(prev, action, bp=None):
    """这一步落位里，符合本条 SCOPE 的插头格子列表：不落沉睡件本身、不落自己旧地盘、贴着沉睡件。
    算不出来（movable/placed 失败、无沉睡件、插头归属分不清）返回 None。"""
    bp = bp if bp is not None else blocks(prev)
    if mover_plug_ambiguous(prev, bp):
        return None
    m = movable(prev, bp)
    if m is None:
        return None
    sl_cells = _sleeper_cells(prev, bp)
    if not sl_cells:
        return None
    new = placed(prev, action, bp)
    if new is None:
        return None
    out = []
    for p, v in new.items():
        if v != MARK:
            continue
        if p in m:
            continue                       # 自占：跟沉睡件无关
        if p in sl_cells:
            continue                       # 落在沉睡件身上：sleep_overlay 的地盘
        if any(q in sl_cells for q in _nb4(p)):
            out.append(p)
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in MOVE_ACTIONS:
        return "NA"
    bp = blocks(prev)
    cells = _qualifying_marks(prev, action, bp)
    if not cells:
        return "NA"
    bn = blocks(nxt)
    for (i, j) in cells:
        if not (0 <= i < NB and 0 <= j < NB) or bn[i][j] != MARK:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if action not in MOVE_ACTIONS:
        return None
    bp = blocks(prev)
    cells = _qualifying_marks(prev, action, bp)
    if not cells:
        return None
    return to_pixels({p: MARK for p in cells}) or None
