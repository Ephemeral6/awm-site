"""可动件让出的格子（prev 属可动件、next 不属），在 next 上只显两种色：底色，或沉睡色 4。
不显焊 3、不显插头 8、不显任何件的真色——**底下只可能是「什么都没有」或「一件睡着的东西」**。
究竟是哪一种，单帧读不出来，本条不断言。"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1-5、prev 帧上有沉睡件（睡眠 regime；没有沉睡件的关让给别人——"
         "那时让出格露出过插头 8 和别的物件色）、两帧都解得出可动件、且确有让出格的转移；"
         "换关返回 NA。只管 20x20 块网格。"
         "**「是底色还是 4」本条不断言**：那要知道这一格上一次没被盖住时显什么，"
         "而 assert_ 只拿到 (prev, action, nxt)——底层色不是单帧函数。这条 scope 就是观测极限本身。")
NOTE = ("为什么单立一条：模拟器（runs/<run>/step1.py）里那套「让出格露回底层色」连中十余批、"
        "每批都拿它押注，却一次没走过闸——它是藏在 runs/ 脚本里的世界事实。"
        "而管落位的 sleep_overlay 只管「落位压在沉睡件上」，没有一条概念管让出格露回什么。"
        "施测（runs/<run>/uncoverclaims.py）拿全语料 move 转移跑，两轮："
        "第一轮不设 regime 门槛，6 条判 FALSE——让出格露出过插头 8，还在一关里露出过色 9 而那一关底色不是 9；"
        "那几关场上没有沉睡件，是另一套 regime。收紧到「prev 有沉睡件」后 316/316 TRUE 零反例，"
        "且这 316 条里让出格出现过的色只有底色与 4 两种（其余色全是别的关的底色）。"
        "**同时被证伪并作废的一条**：本想再断言「显 4 的让出格必与别的非可动件色 4 格 4-连通」"
        "（露出来的是一件沉睡件的一部分，不是孤立的 4），12 条判 FALSE——"
        "可动件一格一格让出同一件时，露出的 4 四周全是它自己还盖着的格子，"
        "最狠的一条一次露出三个互不相邻的孤立 4。这条不写，理由记在这里："
        "**「露出来的是一整件」是记忆里的事，不是这一帧上的事**——和 sleep_wake v8 那个"
        "「许变区不是贴着谁、是经由遮挡连通到谁」是同一个死角的两面。"
        "本条不写 apply：它把让出格框到两个色里，给不出是哪一个，生成不了。"
        "它涨不了完成度 E，只把一条一直在用却没被检验的世界事实变成可判错的对象。")
EVIDENCE = ["9bad7a075c0d73ef", "57b1a913eaa995ed", "6044c57fccfe7d63", "748107641a3dfd65",
            "3d2ae491613ddc47", "d804951a4dfe5e45", "779e4ea343aee5e4", "9895779cd12aaeee",
            "ee822c21a217fb25", "0346fcdfa99ab187"]

from _lib import blocks, bg, active, solid_comps, NB


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = action.upper()
    if not any(a.startswith(x) for x in ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5")):
        return "NA"
    bp = blocks(prev)
    if not [c for c in solid_comps(bp) if all(bp[p[0]][p[1]] == 4 for p in c)]:
        return "NA"                                   # 不是睡眠 regime
    ap = active(prev, bp)
    bn = blocks(nxt)
    an = active(nxt, bn)
    if not ap or not an:
        return "NA"
    gone = set(ap) - set(an)
    if not gone:
        return "NA"                                   # 没走成，或整件落位与原位重合
    BG = bg(bn)
    for (i, j) in gone:
        if bn[i][j] not in (BG, 4):
            return "FALSE"
    return "TRUE"
