"""ACTION5 作用在带笔头（色 0）的醒着的件上不是旋转，是画：笔头原来那格下一帧要么显该件的实心色
（长节），要么显底色（撤节）；全帧至多剩一个笔头，且它若存在、原笔头那格又没变底色，两者下一帧
属于同一个连通团；件的格数一定改变；场上别的块一格不动。**新笔头落在哪，本条不说**。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION5，且 prev 帧上恰有一个带笔头（色 0）的非底色连通团；换关返回 NA；"
         "prev 帧上没有笔头（那是 rot_cw 的旋转那一族）返回 NA；"
         "**只断言结构，不断言画出什么**：新长出/撤掉哪些格子、朝哪个方向画，本条一概不说——"
         "方向是件自己的隐藏状态，帧上定不出来（第 4 关笔头度为 1 时是「背着邻居走」，"
         "第 5 关笔头度为 2，两边对称）。只管 20x20 块网格。")
NOTE = ("由来：第 4 关第 185-191 步与第 5 关第 247-248 步。两关的笔画法**不一样**——"
        "第 4 关只增不减，一次冒出一整段（第 186 步一下多 5 块），笔头沿一条竖线往下走；"
        "第 5 关是把笔头前方那截「手臂」整体平移一格、笔头进一格、原笔头留一块实心，净增 1 块，"
        "所以第 5 关每一步都有格子**消失**。差别这么大，还敢写成一条，是因为下面几件事两关都成立："
        "原笔头那格必变（长节变实心、撤节变底色）、新笔头必与原笔头 4 相邻（或消失）、格数必变、别的件不动。"
        "这条的用处是把「ACTION5 的第二族」从 rot_cw 的一句 NA（『我不管』）变成一句有内容的话，"
        "并且把「画完了」这个事件写成可判的：笔头消失 = 这件成形了，装配才有解"
        "（第 4 关三种中途形态全零解，成形后唯一解）。"
        "**没写进来的是方向**：它是隐藏状态位，两端都会翻，且睡一觉还在（第 4 关第 188/190/196-199 步）。"
        "写不出来就不写，不拿设计冒充结果。"
        "v2：v1 在第 191/197/198 步判 FALSE（三条反例，闸关了一次）——我只写了长节那一半，"
        "**撤节时原笔头那格是消失（变底色），不是变实心**。三步都是同一个错，一次改完："
        "断言改成「原笔头那格要么显实心色、要么显底色」。"
        "同时**撤掉 apply**：v1 的 apply 一律赌「原笔头变实心」，在撤节上说错 27 格（P=0.571）。"
        "分不清长/撤就生成不了——两族在这一格上的预测正好相反，取交集是空的，"
        "所以这条只判不生成。为了 E 好看而硬猜一个方向，等于把 50% 的猜写成主张。"
        "v4：v3 在第 257/258 步判 FALSE（两条反例，闸关第二次）——**「新笔头必与原笔头 4 相邻」是假的**。"
        "第 5 关第二支笔（7 块、c11、笔头度为 1）一按就把一整段吐出来：笔头从 (10,7) 直接跳到 (10,9)，"
        "中间那格同时长出来，件从 7 块变 10 块（还顺带冒出一个新插头）。断言放宽成「同行或同列 + 中间"
        "那条直线段全属于该件」——笔沿直线走，一步走几格不定。"
        "同一批还打掉了另一句我从第 4 关带过来的话（它只在押注里，没进过册子，所以没吃反例）："
        "**方向不是「背着邻居走」**。这支笔的笔头 (10,7) 唯一的邻居在正上方 (9,7)，按那句话它该往下，"
        "实际往右。方向仍是帧上定不出来的隐藏位，三支笔三种笔法都指着同一件事。"
        "v5：v4 在第 259 步判 FALSE（第三次关闸）——**「同行或同列」也是假的，笔会拐弯**。"
        "那一步吐出来的是一条**竖**段 (9,12)(10,12)(11,12)，笔头从 (10,11) 斜跳到 (9,12)，"
        "段的另一端 (11,12) 成了插头。三次被打死的都是同一个东西：我一直想说清「笔头下一步去哪」。"
        "现在明说它说不清：**笔迹是一条预定路径，帧上看不见下一段**——方向、段长、拐不拐弯，"
        "三样都藏在件自己的状态里（第 4 关 +2/+5/+2，这支 +3/+2/+3/+2，16 块那支恒 +1）。"
        "本条从此只保留三关三支笔上都成立的结构：原笔头那格必变、至多一个笔头且与原笔头同团、"
        "格数必变、别的件不动。"
        "**对策略的用处反而更清楚了**：不用知道笔迹，照样能把笔画完——一直按 ACTION5 直到帧上"
        "没有笔头为止，「笔头消失 = 成形」是帧上读得出来的（第 249/255 步）。")
EVIDENCE = ["b630d38809ca109a", "1e68ba8714324515", "285979dcd31b0536", "74a01fae1831885f",
            "59b4b1544984c821", "271b87e64d236b32",
            "a53402f88d057ff9", "c0bb6640e198e0bc", "52003287d4b0d4d2",
            "1395f9b6ef76a1de", "1d7500000526cada", "a989b9e0c23eb40a"]

from _lib import blocks, bg, _nb4, MARK, WELD, MOVER, NB


def _pen(b):
    """带笔头的那一团：色 0 的格子 + 与它 4 连通的非底色非 4 的格子。恰好一团才返回。"""
    bgc = bg(b)
    heads = [(i, j) for i in range(NB) for j in range(NB) if b[i][j] == MOVER]
    if len(heads) != 1:
        return None, None
    h = heads[0]
    comp, st, seen = set(), [h], {h}
    while st:
        q = st.pop()
        comp.add(q)
        for r in _nb4(q):
            if (0 <= r[0] < NB and 0 <= r[1] < NB and r not in seen
                    and b[r[0]][r[1]] not in (bgc, 4)):
                seen.add(r)
                st.append(r)
    return comp, h


def _solid_color(b, comp, h):
    cols = [b[p[0]][p[1]] for p in comp
            if p != h and b[p[0]][p[1]] not in (MARK, WELD)]
    return cols[0] if cols and len(set(cols)) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action.upper() != "ACTION5":
        return "NA"
    bp = blocks(prev)
    comp, h = _pen(bp)
    if comp is None:
        return "NA"
    bn = blocks(nxt)
    col = _solid_color(bp, comp, h)
    if col is None:
        return "NA"                       # 实心色不唯一，本条不管
    # 1. 原笔头那格：长节变实心色，撤节变底色
    if bn[h[0]][h[1]] not in (col, bg(bn)):
        return "FALSE"
    # 2. 全帧至多一个笔头
    nh = [(i, j) for i in range(NB) for j in range(NB) if bn[i][j] == MOVER]
    if len(nh) > 1:
        return "FALSE"
    # 3. 件的格数一定变了
    ncomp, _ = _pen(bn)
    if ncomp is None:                     # 笔头没了：数与原笔头连通的那团
        bgc = bg(bn)
        st, seen = [h], {h}
        ncomp = set()
        while st:
            q = st.pop()
            ncomp.add(q)
            for r in _nb4(q):
                if (0 <= r[0] < NB and 0 <= r[1] < NB and r not in seen
                        and bn[r[0]][r[1]] not in (bgc, 4)):
                    seen.add(r)
                    st.append(r)
    # 新笔头若还在、原笔头那格又没变底色，两者必在同一团里（笔头不会跳到别的件上去）
    if len(nh) == 1 and bn[h[0]][h[1]] != bg(bn) and (h not in ncomp or nh[0] not in ncomp):
        return "FALSE"
    if len(ncomp) == len(comp):
        return "FALSE"
    # 4. 别的块一格不动
    touched = comp | ncomp
    for i in range(NB):
        for j in range(NB):
            if (i, j) not in touched and bp[i][j] != bn[i][j]:
                return "FALSE"
    return "TRUE"
