"""cn04 的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测依据（第 1-18 步）：
  帧 64x64，一切物件都由 3x3 的同色块拼成，块左上角落在 row/col ≡ 2 (mod 3)。
  20x20 的块网格覆盖像素行/列 2..61；像素行 0/1 与 62/63 在网格之外（行 0 是顶栏）。
  底色是块网格里格数最多的那个色。MARK（色 8）是贴在各件末端的小方块。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 3
PHASE = (2, 2)
NB = 20
MARK = 8         # 各件末端的插头的颜色（第 0/1 关都是 8）
WELD = 3         # 两个插头重合时那一格显示的色（第 24 步实测；第 25 步分开又变回 8，可逆）
MOVER = 0        # **被选中**的那个件被画成这个色（第 28 步实测：ACTION6 点在色 9 的件上，
#                  它整件变成色 0，而原来的色 0 件露出真色 15 —— 色 0 是选中态，不是某个件的身份）


def bpos(i, j):
    return PHASE[0] + CELL * i, PHASE[1] + CELL * j


def bcell(x, y):
    """像素坐标 (x=列, y=行) 落在哪个块上；不在块网格里返回 None。"""
    j, i = (x - PHASE[1]) // CELL, (y - PHASE[0]) // CELL
    return (i, j) if 0 <= i < NB and 0 <= j < NB else None


def click_target(action):
    """把 "ACTION6:51,54" 解析成块坐标；不是带坐标的动作返回 None。"""
    if ":" not in action:
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return bcell(x, y)


def blocks(g):
    """把帧折成 20x20 块网格；块内不同色记 -1。"""
    out = []
    for i in range(NB):
        r = PHASE[0] + CELL * i
        line = []
        for j in range(NB):
            c = PHASE[1] + CELL * j
            vals = {g[r + di][c + dj] for di in range(CELL) for dj in range(CELL)}
            line.append(vals.pop() if len(vals) == 1 else -1)
        out.append(line)
    return out


def bg(bs):
    """底色 = 块网格里出现次数最多的色。"""
    cnt = {}
    for row in bs:
        for v in row:
            cnt[v] = cnt.get(v, 0) + 1
    return max(cnt, key=cnt.get)


def solid_comps(bs):
    """同色 4 连通分量（不含底色、不含 MARK、不含 WELD）。返回 [set(块坐标)]。"""
    b = bg(bs)
    out = []
    seen = set()
    for i in range(NB):
        for j in range(NB):
            v = bs[i][j]
            if v in (b, MARK, WELD) or (i, j) in seen:
                continue
            comp = {(i, j)}
            seen.add((i, j))
            stack = [(i, j)]
            while stack:
                r, c = stack.pop()
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p = (r + dr, c + dc)
                    if (0 <= p[0] < NB and 0 <= p[1] < NB and p not in seen
                            and bs[p[0]][p[1]] == v):
                        seen.add(p)
                        comp.add(p)
                        stack.append(p)
            out.append(comp)
    return out


def _mark_cells(bs):
    return [(i, j) for i in range(NB) for j in range(NB) if bs[i][j] == MARK]


def _weld_cells(bs):
    return [(i, j) for i in range(NB) for j in range(NB) if bs[i][j] == WELD]


def _nb4(p):
    """p 的 4 邻居，只给图内的——块网格有界（NB），图外没有格子，也就不可能是焊格或插头。
    曾经不设界：第 413 步 44 格糊块（p1+p3+p2 贴睡）贴着底边（行 19），边缘件的邻居 (20, j)
    让焊格扫描 `bp[q[0]][q[1]]` 越界，sleep_wake / wake_plugs 在同一条转移上双双 ERROR 关闸。
    其余调用点本来就自带 `0 <= r[0] < NB` 判断，收界对它们是零变化；deg1 里是集合成员测试，
    图外邻居从来不在 cells 里，度数也不变。"""
    i, j = p
    return tuple(q for q in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1))
                 if 0 <= q[0] < NB and 0 <= q[1] < NB)


def pieces(g, bs=None):
    """件 = 一个实心分量 + 归它的插头块（字典里插头一律记成 MARK，色 3 只是显示）。

    件与件**永不合并**：第 24 步两对插头重合显示成色 3，第 25 步一个上移就各自变回色 8，
    可动件只带走自己那 10 块 —— 「焊上了就一起动」被这一步推翻。

    插头归属：
      色 3 的格子是**两个**插头重合，贴着它的每个分量都算有一个插头在那里；
      色 8 的格子只贴着一个分量时判给那个分量；
      同时贴着两个以上分量时**判给非可动件的那个**（它至少不会跟着走），
      并由 `mover_plug_ambiguous` 单独把这种局面标出来 —— 见那个函数的说明，这时册子该闭嘴。
    """
    bs = bs if bs is not None else blocks(g)
    comps = solid_comps(bs)
    idx = {}
    for k, comp in enumerate(comps):
        for p in comp:
            idx[p] = k
    mover_k = None
    for k, comp in enumerate(comps):
        if bs[next(iter(comp))[0]][next(iter(comp))[1]] == MOVER:
            mover_k = k
    l2 = mover_k is None             # 第 2 关 regime：没有色 0，插头归唯一醒着的件
    if l2:
        awake = [k for k, comp in enumerate(comps)
                 if any(bs[p[0]][p[1]] != 4 for p in comp)]
        if len(awake) == 1:
            mover_k = awake[0]
    out = [{p: bs[p[0]][p[1]] for p in comp} for comp in comps]
    for p in _mark_cells(bs) + _weld_cells(bs):
        own = sorted({idx[q] for q in _nb4(p) if q in idx})
        if not own:
            continue
        if bs[p[0]][p[1]] == WELD:
            for k in own:
                out[k][p] = MARK
        elif len(own) == 1:
            out[own[0]][p] = MARK
        elif l2 and mover_k in own:
            out[mover_k][p] = MARK   # 醒件旁边贴着的色 8 是它自己的插头（睡眠件的插头画 4，显不出来）
        else:
            cand = [k for k in own if k != mover_k] or own
            out[cand[0]][p] = MARK
    return out


def sleepers(g, bs=None):
    """沉睡件的格集列表（实心一格全 4 的连通件，含它们盖着的隐藏插头格）。"""
    bs = bs if bs is not None else blocks(g)
    return [c for c in solid_comps(bs) if all(bs[p[0]][p[1]] == 4 for p in c)]


def sleeper_touch(g, new, bs=None):
    """可动件的落位 new 压到任何沉睡件的格子上吗（实心或隐藏插头都算）。

    第 118 步实测：可动件的插头压上沉睡件盖着的隐藏插头，那一格显色 3——焊越过沉睡照样显示；
    而没被压到的隐藏插头继续隐身（第 118 步 (15,15) 仍是 4）。隐藏插头在哪帧上读不出，
    所以「落位压到沉睡件」的局面预测不了那一格显 3 还是显 8——含糊就闭嘴，render 返回 None。
    """
    bs = bs if bs is not None else blocks(g)
    return any(q in c for c in sleepers(g, bs) for q in new)


def mover_plug_ambiguous(g, bs=None):
    """有没有色 8 的格子同时贴着可动件和别的件的实心块 —— 那就分不清这个插头归谁。

    第 36/37 步逼出来的：可动件的横臂扫到小件的插头旁边，「可动件优先」把人家的插头抢了过来，
    render 于是预测那一格跟着走，实际它一动没动（说错 27 格）。
    全量语料上考过四条归属规则（runs 里的 attrib.py）：可动件优先说错 2 条，反过来判给静止件说错 2 条（另外两条），
    「含糊就闭嘴」说错 0 条、代价是 4 条转移没人开口。选了闭嘴——预测错比不预测贵。
    """
    bs = bs if bs is not None else blocks(g)
    comps = solid_comps(bs)
    idx = {}
    mover_k = None
    for k, comp in enumerate(comps):
        for p in comp:
            idx[p] = k
        if bs[next(iter(comp))[0]][next(iter(comp))[1]] == MOVER:
            mover_k = k
    if mover_k is None:
        return False
    for p in _mark_cells(bs):
        own = {idx[q] for q in _nb4(p) if q in idx}
        if len(own) > 1 and mover_k in own:
            return True
    return False


def active(g, bs=None):
    """可动件（这一步会被 ACTION1-4/5 作用的那个件）。

    两种 regime，帧上自己可辨：
      第 1 关式：被点中的件整件画成色 0（含插头画成 8）——含 MOVER 色的件就是它；
      第 2 关式：没有色 0，场上其余件**沉睡**（实心一色 4、无插头），唯一不睡的件
        （实心里有非 4、非底色的真色）就是它。两关的移动/旋转实测同款（第 108/111 步）。
    都找不到（第 2 关全员沉睡）、或找到多个，返回 None。

    **色 0 的实心只有 1 块时，件 = 这个笔头 + 与它 4 连通的整团**（第 181-189 步实测）：
    那种局面里色 0 不是「被涂成选中色的整件」，而是一个单块的笔头，贴着它的一大团跟着一起动
    （ACTION1-4 让笔头连同那一团整体平移 1 块，21 块一起变，色 4 的沉睡件一格不动）。
    第 1 关式的辨认规则在那里认出来的只有笔头自己，于是预测「只有这 1 块动」，格格皆错。
    团的判据：从笔头出发，沿**非底色且非 4**的格子 4 连通泛洪（色 4 是沉睡件，不跟着走）。
    """
    bs = bs if bs is not None else blocks(g)
    b = bg(bs)
    cands = [p for p in pieces(g, bs) if MOVER in p.values()]
    if len(cands) == 1:
        if len([1 for v in cands[0].values() if v != MARK]) < 2:
            head = next(p for p, v in cands[0].items() if v == MOVER)
            blob = {head}
            stack = [head]
            while stack:
                p = stack.pop()
                for q in _nb4(p):
                    if (0 <= q[0] < NB and 0 <= q[1] < NB and q not in blob
                            and bs[q[0]][q[1]] not in (b, 4)):
                        blob.add(q)
                        stack.append(q)
            return {p: (MARK if bs[p[0]][p[1]] == MARK else bs[p[0]][p[1]]) for p in blob}
        return cands[0]
    b = bg(bs)
    awake = []
    for p in pieces(g, bs):
        # 单格的插头（8）/焊格（3）显示不是件：件按颜色切的时候，醒着的件身上带 Mark 会粘进
        # 件分量，但**焊格**跟它隔着颜色（第 435 步后的帧：醒着的 25 格整件 + 单格焊格 +
        # 单格插头，被数成 3 个「清醒候选」，active() 返回 None，全场从此没有可动件）。
        # 焊格是「谁醒着」的显示，不是第三个件。
        if len(p) == 1 and set(p.values()) <= {MARK, WELD}:
            continue
        solids = {v for v in p.values() if v not in (MARK,)}
        if solids == {4} or solids == {b}:
            continue
        if 4 in solids and len(solids) == 1:
            continue
        awake.append(p)
    return awake[0] if len(awake) == 1 else None


def movable(g, bs=None):
    """可动件：active() 的旧名。"""
    return active(g, bs)


PEN = 11          # 「那支笔画出来的件」的实心色（第 180-191 步：它长节/撤节，从不旋转）


def is_pen(g, bs=None):
    """醒着的件是不是那支笔画出来的件。

    为什么要这个词：ACTION5 在同一关里干两件不同的事——作用在笔件上是长节/撤节
    （第 185 步长、第 190 步撤），作用在别的醒着的件上是照旧旋转（第 195 步实测）。
    分界不是「帧上有没有笔头」：第 190 步的 prev 帧里色 0 已经没了，它照样撤节。

    判据（只看帧）：带笔头（色 0），或实心色全是 PEN。**后半句是一条会被打错的假设**——
    颜色不是「谁画的」的证据，只是这一关里它俩恰好可分；哪天出现一个色 PEN 的普通件，
    引用本词汇的概念当场吃反例。调用方自己决定在哪些关问这个问题
    （更早的关里有过色 PEN 的普通件，它照常旋转，那里不该问）。
    """
    bs = bs if bs is not None else blocks(g)
    a = active(g, bs)
    if a is None:
        return False
    if MOVER in a.values():
        return True
    return {v for v in a.values() if v != MARK} == {PEN}


def targets(g, bs=None):
    """除可动件之外的其余件。

    排除判据是 `active()` 的结果，不是「不含色 0」——第 2 关帧上没有色 0，
    激活件靠「唯一不睡的件」辨认（第 112 步排路线时暴露：旧筛法把激活件自己留在了
    静态层里，render 看见实心压真色就闭嘴，move_* 全体不开口）。

    激活件是笔头那一团时（第 4 关画图态），它由好几个 `pieces()` 分量拼成（笔头是色 0 一个分量、
    画出来的实体是另一个），`p != a` 逐个比对认不出来，静态层会把自己的身子当成别人、跟落位撞车。
    所以再排一刀：**格集整个落在激活件里的分量也是激活件的一部分**。
    焊住的靶件不会被误伤——它有自己的实心，不是激活件的子集。"""
    bs = bs if bs is not None else blocks(g)
    a = active(g, bs)
    if a is None:
        return list(pieces(g, bs))
    ac = set(a)
    return [p for p in pieces(g, bs) if p != a and not set(p) <= ac]


def marks(d):
    return sorted(p for p, v in d.items() if v == MARK)


def anchor(m):
    return min(p[0] for p in m), min(p[1] for p in m)


def norm(m):
    r0, c0 = anchor(m)
    return {(r - r0, c - c0): v for (r, c), v in m.items()}


def rot_cw_shape(m):
    """绕自身 bbox 左上角顺时针 90°，仍以 bbox 左上角为原点。"""
    n = norm(m)
    h = max(r for r, _ in n) + 1
    return {(c, h - 1 - r): v for (r, c), v in n.items()}


def place(m, r0, c0):
    return {(r + r0, c + c0): v for (r, c), v in m.items()}


def to_pixels(m):
    out = {}
    for (i, j), v in m.items():
        r, c = bpos(i, j)
        for di in range(CELL):
            for dj in range(CELL):
                out[(r + di, c + dj)] = v
    return out


def me(g):
    m = movable(g)
    if m is None:
        return None
    return bpos(*anchor(m))


DELTA = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def placed(g, action, bs=None):
    """按 move_*/rot_cw 的主张算可动件这一步的落位（块字典）；算不出来返回 None。"""
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    if m is None:
        return None
    if action == "ACTION5":
        return place(rot_cw_shape(m), *anchor(m))
    d = DELTA.get(action)
    if d is None:
        return None
    return {(r + d[0], c + d[1]): v for (r, c), v in m.items()}


def pairing(g, action, bs=None):
    """这一步的插头配对情况。

    返回 (落位, 这一步新重合的格, 走完这一步还没配上对的插头格)。
    **按格计重数**：一个格子上落了两个插头就算配上了对（帧上显示成 WELD），落一个就是自由插头。
    `pieces()` 已经把 WELD 格同时判给贴着它的每个分量，所以对各件的插头求和天然得到重数。
    插头总数在一关里守恒（第 1 关 12 个）。算不出来返回 (None, None, None)。

    **场上有沉睡件就返回 None**（第 118 步后的决定）：睡眠件的隐藏插头帧上不可见，
    「还剩几个没配」数不出来——硬数只会把赢步数成没赢（goal_needs_dock 会在换关那步假摔）。
    沉睡 regime 里配没配光，册子暂时不开口。

    早先这里写成「别的件的插头集合减去可动件这一步压上的」，那是只有可动件会焊时的写法：
    两个**靶件**互相焊上之后，那个格子在集合里只剩一份，被当成还没配对，
    于是「最后一步配光」永远算不出来。改成按重数计。
    """
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    new = placed(g, action, bs)
    if m is None or new is None or mover_plug_ambiguous(g, bs):
        return None, None, None
    if sleepers(g, bs):
        return None, None, None          # 隐藏插头看不见，配对数不出来
    cnt = {}
    for t in targets(g, bs):
        for q in marks(t):
            cnt[q] = cnt.get(q, 0) + 1
    others = set(cnt)
    mine_new = set(marks(new))
    for q in mine_new:
        cnt[q] = cnt.get(q, 0) + 1
    welds = mine_new & others
    rest = {q for q, c in cnt.items() if c == 1}
    return new, welds, rest


def clears_level(g, action, bs=None):
    """这一步是否把场上最后剩的插头都配上对 —— 按 goal_dock_wins 的主张，这时会换关、整帧换掉，
    所以 move_*/rot_cw 的 apply 在这种步上不该生成任何格子。"""
    new, welds, rest = pairing(g, action, bs)
    return bool(new is not None and welds and not rest)


def dock_undecidable(g, action, bs=None):
    """沉睡 regime 里「这一步会不会把最后一对插头配上」——册子答不出的那一类局面。

    为什么要单写：`pairing` 有沉睡件时返回 None（隐藏插头在帧上读不出来），于是
    `clears_level` 一律为假，生成器就按「没换关」逐格生成。真换了关整帧重画，那些格子全错。
    答不出该闭嘴，不该当成「答案是否」——这两件事在代码里长得一模一样，是这个坑的全部难处。

    判据只看帧，尽量窄，三条同时成立才闭嘴：
      1. 场上有沉睡件（没有的话 pairing 数得出来，走 clears_level）；
      2. 可动件之外没有自由插头（帧上没有不属于可动件的色 MARK）——只要还剩一个，
         依 goal_needs_dock 这一步就一定不换关，照常生成；
      3. 可动件这一步的每个插头都落到**非底色**的格子上（有可能全部成焊）。
         这一条起初写成「落到别的件占着的格子上」，漏掉了一整类：可动件画在最上面，
         沉睡件被它盖住的那些格子在帧上显的是可动件的色，`targets()` 看不见——
         而插头正可能藏在那底下。落到底色上才是真的什么都没有、那个插头一定还自由。
    差一条就说明这一步一定不换关，生成器照常说话。
    """
    bs = bs if bs is not None else blocks(g)
    m = movable(g, bs)
    if m is None or not sleepers(g, bs):
        return False
    new = placed(g, action, bs)
    if new is None:
        return False
    mine = set(m)
    if any(bs[i][j] == MARK and (i, j) not in mine
           for i in range(NB) for j in range(NB)):
        return False                     # 还剩自由插头，一定不换关
    mine_new = marks(new)
    if not mine_new:
        return False
    b = bg(bs)
    return all(0 <= i < NB and 0 <= j < NB and bs[i][j] != b for (i, j) in mine_new)


def may_clear(g, action, bs=None):
    """这一步有没有可能换关。换关会整帧重画，所以生成器在这种步上一律闭嘴。

    数得出来时就是 `clears_level`；沉睡 regime 里数不出来时按 `dock_undecidable` 保守判。
    """
    bs = bs if bs is not None else blocks(g)
    return clears_level(g, action, bs) or dock_undecidable(g, action, bs)



def static_layer(g, bs=None):
    """除可动件之外的一切，画成 20x20 块网格（空处填底色，插头画成 MARK）。

    两个**靶件**彼此焊住的格子画成 WELD：按「几个靶件的插头落在这格」计重数，≥2 就是焊。
    （pieces() 把色 3 一律记成 MARK，平铺时那份信息会丢；第 88/89 步两个靶件焊着、
    可动件在别处动，render 把焊格画回 8，被 move_down 判了 FALSE。可动件自己参与的那份
    不在这里 —— 它落位后的重合由 render 画 new 那一段负责。）

    **显示跟可见性走**（第 118/119 步）：靶件的插头格，主人全在沉睡就画 4（隐藏插头不显形，
    焊也跟着隐——第 119 步 (10,10) 沉睡后显 4），有醒着的才画 MARK；多重插头照旧画 WELD。
    第 1 关没有沉睡件，这条规则退化成原画法，一字不变。"""
    bs = bs if bs is not None else blocks(g)
    b = bg(bs)
    grid = [[b] * NB for _ in range(NB)]
    cnt = {}
    hidden = {}
    for t in targets(g, bs):
        t_asleep = all(v == 4 for v in t.values() if v != MARK)
        for (i, j), v in t.items():
            if v == MARK:
                cnt[(i, j)] = cnt.get((i, j), 0) + 1
                hidden[(i, j)] = hidden.get((i, j), True) and t_asleep
            else:
                grid[i][j] = v
    for (i, j), c in cnt.items():
        if c >= 2:
            grid[i][j] = 4 if hidden[(i, j)] else WELD
        else:
            grid[i][j] = 4 if hidden[(i, j)] else MARK
    return grid


def render(g, new, bs=None):
    """可动件落到 new、别的件一格不动时，块网格应该长什么样。

    让出的格子显示底下原本有的东西（别的件的插头，或底色）；两个插头重合的格子显示 WELD。
    可动件的实心块撞上别的件的任何块时返回 None —— 那种局面册子还没见过。
    有插头分不清归谁时（`mover_plug_ambiguous`）也返回 None —— 连谁跟着走都说不准，画不出来。

    可动件的插头落点分三种（第 155 步打脸后补全——可动件自己带着焊格转，焊格在 prev 显 3、
    被 static_layer 重画成 4，旧画法画成 8）：
      落在**可见插头或既有焊上**（静态层画 8、或 prev 就显 3）→ 几何上就是焊，可动件醒着，显 WELD；
      落在**沉睡件的格子上**（静态层画 4 且底色不是 4）→ 那一格是不是隐藏插头帧上读不出
        （第 118 步的老问题），含糊闭嘴返回 None；
      落在空地上 → 显 8。
    """
    bs = bs if bs is not None else blocks(g)
    if mover_plug_ambiguous(g, bs):
        return None
    if sleeper_touch(g, new, bs):
        return None                      # 压到沉睡件：那一格显 3 还是显 8 读不出（第 118 步）
    b = bg(bs)
    grid = static_layer(g, bs)
    m = movable(g, bs)
    sl = sleepers(g, bs) if m is not None else []
    if sl:
        for p in set(m) - set(new):
            # 让出的格子：静态层以为是底色、却贴着沉睡件 —— 它可能是被可动件盖住的
            # 沉睡块（让出后显 4），也可能真是空地（显底色）。帧上读不出，闭嘴。
            # （第 178 步打脸：可动件的实心盖住沉睡件的格，prev 那里显可动件的色、
            # 被算进可动件的连通域；让出时世界显 4，render 画了底色。）
            if grid[p[0]][p[1]] == b and any(q in c for c in sl for q in _nb4(p)):
                return None
    for (i, j), v in new.items():
        if not (0 <= i < NB and 0 <= j < NB):
            return None
        if v == MARK:
            if grid[i][j] == MARK or bs[i][j] == WELD:
                grid[i][j] = WELD        # 可见插头/既有焊：醒着的可动件参与，焊照样显 3
            elif grid[i][j] == 4 and b != 4:
                return None              # 沉睡件的格子：隐藏插头读不出（第 118 步）
            else:
                grid[i][j] = MARK
        else:
            if grid[i][j] != b:
                return None
            grid[i][j] = v
    return grid
