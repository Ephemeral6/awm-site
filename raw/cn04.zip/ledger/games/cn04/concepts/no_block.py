"""ACTION1-4 一定改变帧：可动件解得出、且整件的落位不出网格时，世界从不驳回移动。
move_up/down/left/right 那句「要么位移恰好一格、要么整帧不动」里的后一半，在这一局从未发生过。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1-4（旋转 ACTION5 不管，它的落位另有算法）、prev 帧解得出可动件、"
         "且整件沿动作方向平移一格后**全部落在 20x20 块网格内**的转移；换关返回 NA。"
         "**落位会出网格的情形返回 NA——那一支一次都没实测过**："
         "全语料 404 条入 scope 的 move 里，前沿出界的有 0 条，策略从来没提出过那种动作，"
         "所以「出界会不会被驳回」这一局到此为止是空的，不许顺手断言。"
         "本条只断言「帧一定变」，不断言变成什么样——位移多少由 move_* 四条各自断言。")
NOTE = ("为什么单立这一条：L2 阻挡一直是规划器的空槽，而 move_* 四条的主张都写成"
        "「要么位移恰好一格、要么整帧不动」，那个析取把「会不会被挡住」整个藏起来了——"
        "只要世界驳回一步，四条概念全判 TRUE，册子一句话都不会说错，可策略的路线会当场作废。"
        "起因是一条 23 步的绕路：净位移只有「上 2 左 4」，策略却排了 23 步，"
        "看上去像直路上有东西挡着。拿全语料回头查（runs/<run>/blockprobe.py），"
        "404 条 ACTION1-4 里**没走成的 0 条**——一次驳回都没有；前沿压到沉睡件的 59 条、"
        "压到别的件真色或插头的 15 条，全部照样走成（覆盖优先、没有碰撞判定，"
        "这一点和 sleep_overlay 说的一致）。所以那条绕路不是被世界挡的，是策略自己的搜索"
        "绕开了沉睡件；世界这边没有阻挡这回事。"
        "结论反过来更有用：**「整帧不动」这一支在这一局是空的**，封掉它，"
        "move_* 的析取就塌成等式，策略的路线才是可算的。"
        "顺带记下没能立成的一半：出界会不会被驳回，语料里没有一条，只能留 NA。"
        "证明「帧一定变」的方式：prev==nxt 蕴含「可动件格集不变」，而探针按格集判"
        "没走成 0 条，所以 404 条里 prev 与 nxt 的块网格必然逐条不同。")
EVIDENCE = ["9bad7a075c0d73ef", "57b1a913eaa995ed", "6044c57fccfe7d63", "748107641a3dfd65",
            "3d2ae491613ddc47", "d804951a4dfe5e45", "779e4ea343aee5e4", "ee822c21a217fb25",
            "0346fcdfa99ab187", "285200ff65171fdc"]

from _lib import blocks, active, NB

DV = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = action.upper().split(":")[0]
    if a not in DV:
        return "NA"
    bp = blocks(prev)
    mv = active(prev, bp)
    if not mv:
        return "NA"
    dv = DV[a]
    for (i, j) in mv:
        if not (0 <= i + dv[0] < NB and 0 <= j + dv[1] < NB):
            return "NA"                      # 落位出网格：这一支一次都没实测过
    return "TRUE" if bp != blocks(nxt) else "FALSE"
