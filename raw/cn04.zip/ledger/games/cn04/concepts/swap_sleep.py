"""沉睡 regime 里点一下：被点中的件整件醒来（实心显固有色、端点显 MARK 或 WELD），原来醒着的那件整件沉睡（连端点一律显 4），两件一格没挪，别的格子一格没变；两件共用的格子归醒着的那件画。

这是 swap_selection 在另一套画法下的对应物。两套画法的差别不在「谁醒着」，在**沉睡怎么画**：
第 0/1 关那套里没醒的件照样显自己的固有色、插头照样显 8，只有选中的那件被涂成 MOVER 色；
这一套里没醒的件整件（连端点）沉成 4，醒着的那件才显固有色、端点才显 8。

v2 改三处，都由 v1 的 26 条反例逼出来（tid 全在 EVIDENCE 里）：
1. **焊点跟着主人睡醒改色。** 一个焊上的端点在主人醒着时显 WELD(3)，主人一睡就沉成 4，醒回来再变回 3。
   实测漏算的格，前后色对全是 3→4（22 个）或 4→3（7 个），一个例外都没有。
   v1 的 `_cells` 只把 MARK 端点算作件的一部分，于是每次都漏掉焊点那一格。
2. **端点不再靠 SLEEP 收。** v1 收「4 邻是 MARK 或 SLEEP」的格，本意是「沉睡的端点也算」，
   实际后果是把整个贴着的邻居件（沉睡 regime 里通体是 4）吞进来。改成只收 MARK/WELD：
   要判的这两件在各自那一帧里都是醒着的，醒着的件端点必显 MARK 或 WELD，不会显 4。
3. **两件占的格子会重叠。** 实测有三格同时属于两件：a 醒着时显 a 的固有色 14，
   换成 b 醒着就显 b 的固有色 10，从没显过 4；还有一种共用格是两件焊在一起的那一格，
   谁醒它都显 3，于是换人时它一格不变。所以把 ca∩cb 单列：这些格子不必变，
   也不受「沉成 4 / 此前沉睡」两条约束，但仍须满足醒来那件的画法。
另外补一道 NA：`solid_comps` 只按邻接切，不看颜色，两件贴在一起就并成一个分量。
醒着的分量里混进 4 就是并错了，件的边界说不清，返回 NA 不硬判。

固有色具体是几，在件沉睡的帧上读不出来（全是 4），所以本条不写 apply——
说不出颜色的主张不该假装说得出，和 swap_selection 同一个理由。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6；换关返回 NA；场上没有沉睡件（实心全 4 的连通件）时返回 NA"
         "（那是 swap_selection 管的另一套画法）；前帧或后帧里醒着的件不是恰好一个时返回 NA；"
         "醒着的那个实心分量里混着 4（两件贴在一起被并成一块，件的边界说不清）时返回 NA；"
         "前后两帧的沉睡件集合完全一样时返回 NA（点在空处或点在已醒的件上，没换人）。"
         "只管 20x20 块网格——顶栏的罚数柱在块网格外，blocks() 看不见它，本条也就不管它。")
NOTE = ("v3：v1 判 25 条 FALSE、v2 还剩 8 条。三个病因：焊点(WELD)跟着主人睡醒在 3 和 4 之间来回，"
        "v1 的 _cells 不收它；_cells 靠 SLEEP 收端点，把贴着的整个沉睡邻居吞进来；"
        "以及两件占的格子会重叠，共用格归当下醒着的那件画，两件焊在一起的那一格谁醒都显 3、换人时不变。"
        "改成端点只收 MARK/WELD、对「醒着的分量里混着 4」返回 NA、把 ca∩cb 单列。")
EVIDENCE = [
    "09919513db67fdcd",
    # 以下 25 条是 v1 的反例，v2 就是从它们推出来的
    "093ef54eb1b12b58", "0b8f108a82c3c52a", "1af5698036838cc6", "3d1fb94bc7478758",
    "454f6e0d5a168568", "46b787d943d24c10", "4ed8b0a5faf1fdbb", "508909ab56ad1152",
    "57471e84c994886a", "6838ff11ad36da2f", "71b082a6f120062b", "7788a63b73e6683f",
    "9229ac29ed737cbd", "944c6d1561f37b5b", "a1d1d21a1c388b5a", "a7cc6e77555c314c",
    "a8088e79d08dbd62", "a83c3e05c8315f4e", "bfb86e462c3de12c", "cb2b417da225ba41",
    "d12c873bb0af6817", "e4de1bf674da774e", "eaa8e7cf8e21d82e", "f6500f6875e05853",
    "ff299c5a5eeb9a98",
    # v2 自己招出来的第 26 条（重叠与焊点共用格），v3 从它推出来
    "be575e164358377c",
]

from _lib import blocks, solid_comps, sleepers, MARK, WELD, NB

SLEEP = 4


def _awake(bs):
    """醒着的件：实心里有非 4 真色的那个分量。恰好一个、且整块不含 4 才返回，否则 None。"""
    got = [c for c in solid_comps(bs) if any(bs[i][j] != SLEEP for (i, j) in c)]
    if len(got) != 1:
        return None
    c = got[0]
    if any(bs[i][j] == SLEEP for (i, j) in c):
        return None                       # 并进了贴着的沉睡件，边界说不清
    return c


def _cells(bs, comp):
    """件占的全部块 = 实心分量 + 4 邻贴着它的端点块。醒着的件端点显 MARK，焊上了显 WELD。"""
    out = set(comp)
    for (i, j) in comp:
        for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            a, b = i + di, j + dj
            if 0 <= a < NB and 0 <= b < NB and (a, b) not in comp and bs[a][b] in (MARK, WELD):
                out.add((a, b))
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    bp, bn = blocks(prev), blocks(nxt)
    sp, sn = sleepers(None, bp), sleepers(None, bn)
    if not sp or not sn:
        return "NA"
    if sorted(sorted(c) for c in sp) == sorted(sorted(c) for c in sn):
        return "NA"                       # 没换人，本条不管
    a, b = _awake(bp), _awake(bn)         # 点击前醒着的、点击后醒着的
    if a is None or b is None or a == b:
        return "NA"

    changed = {(i, j) for i in range(NB) for j in range(NB) if bp[i][j] != bn[i][j]}
    ca, cb = _cells(bp, a), _cells(bn, b)
    both = ca & cb                        # 两件共用的格子
    if changed - (ca | cb):
        return "FALSE"                    # 别的格子一格没变
    if (ca | cb) - changed - both:
        return "FALSE"                    # 这两件的格子都得变；只有共用格允许原样不动

    if any(bn[i][j] != SLEEP for (i, j) in ca - both):
        return "FALSE"                    # 原来醒着的那件整件（含端点）沉成 4
    for (i, j) in cb:
        if (i, j) in b:
            if bn[i][j] in (SLEEP, MARK, WELD):
                return "FALSE"            # 醒来那件的实心显固有色
        elif bn[i][j] not in (MARK, WELD):
            return "FALSE"                # 醒来那件的端点显 MARK，焊上了显 WELD
    if any(bp[i][j] != SLEEP for (i, j) in cb - both):
        return "FALSE"                    # 它此前整件是沉睡的
    return "TRUE"
