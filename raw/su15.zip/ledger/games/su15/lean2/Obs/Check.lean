/-
# Check —— 判据层：两把尺子，**0 条定理**（尺子不自证，它只是被用）

    agrees    一条转移：从**观测到的那一帧**算一步，和看到的下一帧比（三值：对 / 错 / 闭嘴）
    traceOk   一整段：只有开头那一帧是观测给的，**后面全是模型自己算的**，逐帧比

一个「每步单独看都对、走两步就和现实分家」的模型，在 `agrees` 那里是满分，在 `traceOk` 这里过不了。
逐条那一层（`Obs/Corpus.lean`）与每关那一层（`Proof/Levels.lean`）都从这里拿尺子，不许各抄一份。
-/

import Step

namespace Game

/-- 下一帧在现实那一侧是什么：还是这一关的一个世界 / 换关了 / 通关了 / 终局了。 -/
inductive Post where
  | same (w : World)
  | levelUp
  | win
  | gameOver
deriving DecidableEq, Repr

/-- 三值：`some true` 模型说的就是这样；`some false` 模型说的不是这样；`none` 模型这一步说不出话。
    **`none` 不是 `some true`。** -/
def agrees (b : Board) (lim : Nat) (prev : World) (a : Act) (post : Post) : Option Bool :=
  match step b lim prev a, post with
  | .na, _ => none
  | .ok w, .same o => some (w == o)
  | .won, .levelUp => some true
  | .won, .win => some true
  | .over, .gameOver => some true
  | _, _ => some false

/-- 从 `s` 出发沿 `play` 走，每一步都和那时看到的那一帧比。**下一轮喂进去的是模型自己算出来的 `s'`。** -/
def traceOk (b : Board) (lim : Nat) : World → List (Act × World) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
      match step b lim s a with
      | .ok s' => s' == o && traceOk b lim s' rest
      | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，不是定理。 -/
def firstSplit (b : Board) (lim : Nat) : World → List (Act × World) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
      match step b lim s a with
      | .ok s' => if s' == o then firstSplit b lim s' rest (i + 1) else some i
      | _ => some i

end Game
