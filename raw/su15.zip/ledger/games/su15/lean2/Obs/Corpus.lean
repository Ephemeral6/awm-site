/-
# Corpus —— 模型面对全部 904 行真实转移（`lean2/export_corpus.py` 生成，不要手改）

观测从 `Obs/Replay.lean` 切，这里不另存一份。

    verdicts      #eval 读数：T 对 / F 错 / N 模型闭嘴。**读数不是定理**（求值器不进可信基）
    case_<seq>    每一类挑一条，内核算出「模型对」
    case_<seq>_bad 同一条换一个错的下一帧，内核算出「模型说不对」—— 这把尺子不是恒真的
-/

import Obs.Replay

namespace Game
namespace Corpus
open Replay

def verdictOf (r : Row) : Char :=
  match agrees (boardOf r.lvl) (limitOf r.lvl) (worldAt r.prev) r.act r.post with
  | some true => 'T'
  | some false => 'F'
  | none => 'N'

def verdicts : String := String.ofList (rows.map verdictOf)

#eval "VERDICTS " ++ verdicts
#eval s!"COUNTS T={(rows.filter (fun r => verdictOf r == 'T')).length} F={(rows.filter (fun r => verdictOf r == 'F')).length} N={(rows.filter (fun r => verdictOf r == 'N')).length}"

/-- 顶带点击：世界原样：第 13 行（认证段外）。内核算。 -/
theorem case_13 : agrees (boardOf 0) (limitOf 0) (worldAt 6) (.click 4 59) (.same (worldAt 6)) = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_13_bad : agrees (boardOf 0) (limitOf 0) (worldAt 6) (.click 4 59) (.same (worldAt 0)) = some false := by decide +kernel

#print axioms case_13
#print axioms case_13_bad

/-- 搬一件（没有会动的东西）：第 815 行（认证段）。内核算。 -/
theorem case_815 : agrees (boardOf 0) (limitOf 0) (worldAt 0) (.click 52 10) (.same (worldAt 205)) = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_815_bad : agrees (boardOf 0) (limitOf 0) (worldAt 0) (.click 52 10) (.same (worldAt 0)) = some false := by decide +kernel

#print axioms case_815
#print axioms case_815_bad

/-- 并两件：第 823 行（认证段）。内核算。 -/
theorem case_823 : agrees (boardOf 1) (limitOf 1) (worldAt 48) (.click 54 18) (.same (worldAt 49)) = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_823_bad : agrees (boardOf 1) (limitOf 1) (worldAt 48) (.click 54 18) (.same (worldAt 48)) = some false := by decide +kernel

#print axioms case_823
#print axioms case_823_bad

/-- 会动的东西追一步（没咬）：第 850 行（认证段）。内核算。 -/
theorem case_850 : agrees (boardOf 3) (limitOf 3) (worldAt 75) (.click 27 31) (.same (worldAt 350)) = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_850_bad : agrees (boardOf 3) (limitOf 3) (worldAt 75) (.click 27 31) (.same (worldAt 75)) = some false := by decide +kernel

#print axioms case_850
#print axioms case_850_bad

/-- 咬：件降一级甩开 10 格：第 871 行（认证段）。内核算。 -/
theorem case_871 : agrees (boardOf 5) (limitOf 5) (worldAt 281) (.click 10 63) (.same (worldAt 282)) = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_871_bad : agrees (boardOf 5) (limitOf 5) (worldAt 281) (.click 10 63) (.same (worldAt 281)) = some false := by decide +kernel

#print axioms case_871
#print axioms case_871_bad

/-- 过关：第 821 行（认证段）。内核算。 -/
theorem case_821 : agrees (boardOf 0) (limitOf 0) (worldAt 210) (.click 12 47) .levelUp = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_821_bad : agrees (boardOf 0) (limitOf 0) (worldAt 210) (.click 12 47) (.same (worldAt 210)) = some false := by decide +kernel

#print axioms case_821
#print axioms case_821_bad

/-- 终局：第 41 行（认证段外）。内核算。 -/
theorem case_41 : agrees (boardOf 0) (limitOf 0) (worldAt 31) (.click 15 48) .gameOver = some true := by decide +kernel

/-- 同一条，下一帧换成错的：模型说不对（判据不是恒真的）。 -/
theorem case_41_bad : agrees (boardOf 0) (limitOf 0) (worldAt 31) (.click 15 48) (.same (worldAt 31)) = some false := by decide +kernel

#print axioms case_41
#print axioms case_41_bad


end Corpus
end Game
