/-
# Step —— 一步怎么走：**只做分发，0 条定理**

把规则（`Rule/`，全是定义）按语料量出来的次序拼成一步。对应 Python `derive/step.py`——
**两份独立写**，判决逐条对账（`verify.py`：同一批 904 行，两边各判一次，对不上就红）。

起点是整个 `State`：帧上看得见的会动的东西和看不见的 `hidden` **一起**照同一套规则走。

    1. 顶带点击         世界原样交回（`isTopBand`）
    2. 点击这一相       `resolve`（射程里 n 件同级 → 一件新件）；被点的件去哪这里就定了
    3. 预算             `nextBar`：步数 +1（驳回那一支不进模型）
    4. 会动的东西那一相  先定好谁冲刺（`initMover`：离点击近的追猎者冲、菱形扑，其余照常追），再逐小步（`frames`）：
                         挪   冲刺的每小步挪 v；扑的第 1 小步扑过去；照常追的只在前 4 小步 `chase` 此刻最近的那一件
                              （被点的件正滑过去；这一步里被咬过的件不在候选里）
                         并   同种外接框相交就并（`mergeAll`）
                         咬   照常追的压上没被点的件就当场咬（`hitsOf` / `applyBites`）：咬的那只停下，
                              被咬的件记进 `gone`，这一步拖到这一小步之后再 4 小步
                         问   `covered`（件按此刻的位置）
                       没有咬是 4 小步；咬只发生在前 4 小步（之后照常追的不动、别的不咬），所以最多 8 小步：燃料给 8
    5. 看不见的         整只压在件底下的进 `hidden`，其余进 `creatures`
    6. 过关             `covered`（看得见的和看不见的一起算）⇒ `won`（不给下一帧：下一帧是下一关的盘）
    7. 终局             `overAt` ⇒ `over`（不给下一帧）

**模型说不出话的那几支返回 `na`，不编一个下一帧出来**：撤销、RESET（要历史）、射程里 ≥3 件、
盘上没有件、蟹离点击近、两只同一小步咬同一件。
`na` 在判据层是「闭嘴」，**不是「对」**；在 `Winnable` 里走到 `na` 就算没赢——
所以每一条「走得通」都是「**不经过模型说不出话的那几支**就走得通」，这半句写在 `Proof/Reachable.lean` 与页面上。

`step`（只吃 `World`）是 `stepS` 从「看不见的部分是空的」起算、只交出看得见那一半：
`Obs/Check.lean` 的两把尺子吃的是它——那就是「不带记忆」那一读。
-/

import Rule.Click.LandsFresh
import Rule.Click.TopBandInert
import Rule.Budget.StepCost
import Rule.Budget.GameOverAtZero
import Rule.Creature.Chase
import Rule.Creature.Bite
import Rule.Creature.Dash
import Rule.Creature.Merge
import Rule.Goal.Covered

namespace Game

inductive Act where
  | click (r c : Int)
  | undo
  | reset
deriving DecidableEq, Repr, Inhabited

/-- 一步的结局（只交出看得见的那一半）：`Obs/Check.lean` 用它。 -/
inductive Res where
  | ok (w : World)
  | won
  | over
  | na
deriving DecidableEq, Repr, Inhabited

/-- 一步的结局（交出整个 `State`，看不见的那几只带着）。 -/
inductive ResS where
  | ok (s : State)
  | won
  | over
  | na
deriving DecidableEq, Repr, Inhabited

inductive Mode where
  | chase
  | dash
  | pounce
  | born
deriving DecidableEq, Repr

/-- 会动的东西那一相里的一只：此刻的样子、怎么动、位移（冲 / 扑）、停没停、最后一次盯的那一项。 -/
structure Mover where
  c       : Creature
  mode    : Mode
  v       : Int × Int
  stopped : Bool
  tgt     : Option Cand
deriving DecidableEq, Repr

/-- 开始前定好它怎么动；蟹离点击近 ⇒ `none`（说不出）。 -/
def initMover (r x : Int) (c : Creature) : Option Mover :=
  if !nearClick c r x then some ⟨c, .chase, (0, 0), false, none⟩
  else if c.kind = 7 then some ⟨c, .dash, dashV c r x, false, none⟩
  else if c.kind = 14 then some ⟨c, .pounce, pounceV c r x, false, none⟩
  else none

/-- 第 `i` 小步挪一只。照常追的只在前 4 小步动；没有件可追就停下。 -/
def moveOne (i : Nat) (cs : List Cand) (m : Mover) : Mover :=
  match m.mode with
  | .dash => { m with c := place m.c.kind (m.c.row + m.v.1) (m.c.col + m.v.2) }
  | .pounce => if i = 1 then { m with c := place m.c.kind (m.c.row + m.v.1) (m.c.col + m.v.2) } else m
  | .born => m
  | .chase =>
      if m.stopped || 4 < i then m
      else
        match chase m.c cs with
        | none => { m with tgt := none, stopped := true }
        | some r => { m with c := r.1, tgt := some r.2.1, stopped := r.2.2 }

def bornMover (a b : Mover) : Mover := ⟨bornAt a.c b.c, .born, (0, 0), true, none⟩

/-- `x` 后面第一只能和它并的：那一只、拿掉它之后剩下的。 -/
def partner (x : Mover) : List Mover → Option (Mover × List Mover)
  | [] => none
  | y :: ys => if canMerge x.c y.c then some (y, ys) else (partner x ys).map (fun p => (p.1, y :: p.2))

/-- 按名单次序找第一对，并成一只放在前一只的位置上。 -/
def mergeOnce : List Mover → Option (List Mover)
  | [] => none
  | x :: xs =>
      match partner x xs with
      | some (y, rest) => some (bornMover x y :: rest)
      | none => (mergeOnce xs).map (x :: ·)

def mergeAll : Nat → List Mover → List Mover
  | 0, ms => ms
  | n + 1, ms =>
      match mergeOnce ms with
      | some ms' => mergeAll n ms'
      | none => ms

/-- 这一只这一小步咬不咬：照常追的、盯的那件此刻还在盘上、不是被点的那件、外接框压上了它。 -/
def bites (fresh : Option Piece) (now : List Piece) (m : Mover) : Bool :=
  match m.mode, m.tgt with
  | .chase, some t => fresh != some t.dest && now.contains t.dest && touches m.c t.dest
  | _, _ => false

/-- 这一小步咬的：(被咬那件点击之前是哪一件, 被咬的件, 咬它的那只)，按名单次序。 -/
def hitsOf (fresh : Option Piece) (now : List Piece) (ms : List Mover) : List (Piece × Piece × Creature) :=
  ms.filterMap (fun m =>
    match m.tgt with
    | some t => if bites fresh now m then some (t.src, t.dest, m.c) else none
    | none => none)

def hasDup : List Piece → Bool
  | [] => false
  | x :: xs => xs.contains x || hasDup xs

def applyBites (ps : List Piece) : List (Piece × Piece × Creature) → List Piece
  | [] => ps
  | (_, p, c) :: hs => applyBites (ps.erase p ++ (bitten p c).toList) hs

inductive Sim where
  | won
  | na
  | done (now : List Piece) (ms : List Mover)

/-- 逐小步。`i` = 已经走了几小步，`stop` = 这一步走到第几小步为止（4；有咬就拖到那一小步之后再 4），
    `now` = 此刻的件，`gone` = 这一步里被咬过的件（按点击之前的那一件记）。燃料 `fuel` 给 8。 -/
def frames (b : Board) (fresh : Option Piece) (srcs : List Piece) (dst : Piece → Piece) :
    Nat → Nat → Nat → List Piece → List Piece → List Mover → Sim
  | 0, _, _, now, _, ms => .done now ms
  | fuel + 1, i, stop, now, gone, ms =>
      if stop ≤ i then .done now ms
      else
        let j := i + 1
        let ms1 := ms.map (moveOne j (cands (srcs.filter (fun p => !gone.contains p)) dst j))
        let ms2 := mergeAll ms1.length ms1
        let hs := hitsOf fresh now ms2
        if hasDup (hs.map (·.2.1)) then .na
        else
          let now' := applyBites now hs
          let ms3 := ms2.map (fun m => if bites fresh now m then { m with stopped := true } else m)
          let stop' := if hs.isEmpty then stop else max stop (j + 4)
          if covered b now' (ms3.map (·.c)) then .won
          else frames b fresh srcs dst fuel j stop' now' (gone ++ hs.map (·.1)) ms3

/-- 整只压在件底下：帧上一格都没有（按形状那几格）。 -/
def unseen (ps : List Piece) (c : Creature) : Bool := c.cells.all (fun x => ps.any (fun p => p.has x.1 x.2))

def finish (b : Board) (ps : List Piece) (vis hid : List Creature) (bar : Nat) : ResS :=
  if covered b ps (vis ++ hid) then .won
  else if overAt bar then .over
  else .ok ⟨⟨ps, vis, bar⟩, hid⟩

def afterFrames (b : Board) (now : List Piece) (bar : Nat) (ms : List Mover) : ResS :=
  let ps := sortBy Piece.lt now
  let cs := ms.map (·.c)
  finish b ps (sortBy Creature.lt (cs.filter (fun c => !unseen ps c))) (sortBy Creature.lt (cs.filter (unseen ps))) bar

def clickStep (b : Board) (lim : Nat) (s : State) (r c : Int) : ResS :=
  match resolve s.world.pieces r c, nextBar s.world.budget lim with
  | some res, some bar =>
      let all := s.world.creatures ++ s.hidden
      if !all.isEmpty && s.world.pieces.isEmpty then .na
      else
        match all.mapM (initMover r c) with
        | none => .na
        | some ms0 =>
            match frames b res.fresh s.world.pieces (ident s.world.pieces r c res) 8 0 4 res.pieces [] ms0 with
            | .won => .won
            | .na => .na
            | .done now ms => afterFrames b now bar ms
  | _, _ => .na

/-- 一步：吃整个 `State`，交出整个 `State`。 -/
def stepS (b : Board) (lim : Nat) (s : State) : Act → ResS
  | .undo => .na
  | .reset => .na
  | .click r c => if isTopBand r then .ok s else clickStep b lim s r c

/-- 一步（不带记忆）：从这一帧起算、看不见的部分是空的，只交出看得见的那一半。 -/
def step (b : Board) (lim : Nat) (w : World) (a : Act) : Res :=
  match stepS b lim (State.ofWorld w) a with
  | .ok s => .ok s.world
  | .won => .won
  | .over => .over
  | .na => .na

end Game
