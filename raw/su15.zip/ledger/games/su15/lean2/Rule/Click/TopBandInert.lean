/-
# TopBandInert —— 点在顶带（第 0..9 行）：世界一位都不变

对应 Python `rule/一步怎么走/click_top_band_inert.py`。**只有定义**：它就是「顶带」这个词的定义，
`Step.lean` 的分发在这一支原样交回世界。
-/

import Obj.World

namespace Game

def isTopBand (r : Int) : Bool := decide (r < 10)

end Game
