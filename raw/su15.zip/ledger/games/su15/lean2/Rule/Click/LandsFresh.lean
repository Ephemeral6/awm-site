/-
# LandsFresh —— 射程里 n 件同级（n = 1, 2）：变成一件 t+n−1 级的新件，落在点击处

对应 Python `rule/一步怎么走/click_lands_fresh.py`（算法那一半在 `derive/click/`）。**只有定义。**
两份各自独立写，判决逐条对账（`lean2/verify.py`）。

    射程   件里离点击格最近那一格，距离² ≤ 64
    落点   左上角 = (行 − 边长/2, 列 − 边长/2)，夹进 行 ∈ [10, 63−边长+1]、列 ∈ [0, 64−边长]
    ≥3 件  说不出（`none`）；两件不同级 / 两件都是 6 级：件不动
-/

import Obj.World

namespace Game

def reach2 (p : Piece) (r c : Int) : Int :=
  let dr := max (max (p.row - r) 0) (r - (p.row + p.sideI - 1))
  let dc := max (max (p.col - c) 0) (c - (p.col + p.sideI - 1))
  dr * dr + dc * dc

def inReach (ps : List Piece) (r c : Int) : List Piece :=
  ps.filter (fun p => decide (reach2 p r c ≤ 64))

def placedRow (s r : Int) : Int := min (max (r - s / 2) 10) (63 - s + 1)
def placedCol (s c : Int) : Int := min (max (c - s / 2) 0) (64 - s)

def placedPiece (t : Nat) (r c : Int) : Piece :=
  ⟨t, placedRow (side t : Int) r, placedCol (side t : Int) c⟩

/-- 点击这一相之后：件（未排序）、这一下刚落下的那一件。 -/
structure Resolved where
  pieces : List Piece
  fresh  : Option Piece
deriving DecidableEq, Repr

def resolve (ps : List Piece) (r c : Int) : Option Resolved :=
  match inReach ps r c with
  | [] => some ⟨ps, none⟩
  | [p] =>
      let q := placedPiece p.tier r c
      some ⟨ps.map (fun z => if z = p then q else z), some q⟩
  | [a, b] =>
      if a.tier = b.tier ∧ a.tier < 6 then
        let q := placedPiece (a.tier + 1) r c
        some ⟨(ps.filter (fun z => z ≠ a ∧ z ≠ b)) ++ [q], some q⟩
      else some ⟨ps, none⟩
  | _ => none

/-- 点击前的一件 → 点击后它是哪一件（搬走 / 并掉的指向新件）。会动的东西认身份不认位置。 -/
def ident (ps : List Piece) (r c : Int) (res : Resolved) (p : Piece) : Piece :=
  if p ∈ inReach ps r c then res.fresh.getD p else p

end Game
