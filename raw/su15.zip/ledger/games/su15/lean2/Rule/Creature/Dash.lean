/-
# Dash —— 离点击近的会动的东西不追件：追猎者朝点击处冲，菱形一下扑到点击处

对应 Python `rule/会动的东西/creature_dashes_near_click.py`（算法在 `derive/creature/dash.py`）。**只有定义。**

    谁冲     点击格到 4×5 外接框最近那一格的距离² ≤ 64（修复第 2 轮；原先是框心距离² ≤ 107）
    追猎者   每小步同一个位移 round(3.4 · 从挑点（外接框中间格）指向点击格的单位向量)，每轴四舍五入（½ 往上；修复第 4 轮），
             冲到这一步结束（没有咬 4 小步；有咬则最后一次咬之后再 4 小步——次序在 `Step.lean`）
    菱形     第一小步挪 floor(点击格 − 重心 + ½)，之后不动
    蟹       说不出（`Step.lean` 判 `na`）

round(17·d / (5·√L2)) 不开方：找整数 r 使 5(2r−1)·√L2 ≤ 34·d < 5(2r+1)·√L2（`leMulSqrt` 按符号平方比）。
-/

import Rule.Creature.Bite

namespace Game

/-- 离点击够不够近：点击格到 4×5 外接框最近那一格的距离² ≤ 64（和件的射程 `reach2` 同一个数）。 -/
def nearClick (c : Creature) (r x : Int) : Bool :=
  let dr := max (max (c.row - r) 0) (r - (c.row + 3))
  let dc := max (max (c.col - x) 0) (x - (c.col + 4))
  decide (dr * dr + dc * dc ≤ 64)

def roundDash (d l2 : Int) : Int :=
  match (List.range 9).find? (fun (i : Nat) =>
      leMulSqrt (5 * (2 * ((i : Int) - 4) - 1)) l2 (34 * d) &&
        !(leMulSqrt (5 * (2 * ((i : Int) - 4) + 1)) l2 (34 * d))) with
  | some i => (i : Int) - 4
  | none => 0

/-- 追猎者冲刺每小步的位移：从挑点（外接框中间格，`pickPoint`）指向点击格（修复第 4 轮，原先从重心）。 -/
def dashV (c : Creature) (r x : Int) : Int × Int :=
  let dy := r * 104 - (pickPoint c).1
  let dx := x * 104 - (pickPoint c).2
  let l2 := dy * dy + dx * dx
  if l2 = 0 then (0, 0) else (roundDash dy l2, roundDash dx l2)

/-- 菱形第一小步扑过去的位移（`/` 是向下取整：除数是正的）。 -/
def pounceV (c : Creature) (r x : Int) : Int × Int :=
  ((r * 104 - (cCentre c).1 + 52) / 104, (x * 104 - (cCentre c).2 + 52) / 104)

end Game
