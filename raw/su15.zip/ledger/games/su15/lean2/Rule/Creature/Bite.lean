/-
# Bite —— 照常追的那只哪一小步压上没被点的件，就当场咬：那件降一级，沿「咬它的那只 → 件心」甩开 10 格

对应 Python `rule/会动的东西/bite_demotes_and_flings.py`（算法在 `derive/creature/bite.py`）。**只有定义。**
什么时候咬、咬完谁停、被咬的件还被不被盯、这一步拖多长，是次序的事，在 `Step.lean`（`hitsOf` / `frames`）。
round(10·v/√L2) 不开方：找整数 r 使 (2r−1)·√L2 ≤ 20v < (2r+1)·√L2，两边按符号平方比较。
-/

import Rule.Creature.Chase

namespace Game

/-- a·√l2 ≤ b（l2 > 0）。 -/
def leMulSqrt (a l2 b : Int) : Bool :=
  if a ≤ 0 ∧ 0 ≤ b then true
  else if 0 < a ∧ b < 0 then false
  else if 0 ≤ a then decide (a * a * l2 ≤ b * b)
  else decide (b * b ≤ a * a * l2)

def roundRatio (v l2 : Int) : Int :=
  match (List.range 21).find? (fun (i : Nat) =>
      leMulSqrt (2 * ((i : Int) - 10) - 1) l2 (20 * v) && !(leMulSqrt (2 * ((i : Int) - 10) + 1) l2 (20 * v))) with
  | some i => (i : Int) - 10
  | none => 0

/-- 被 `c` 咬了之后的那一件；1 级件被咬就没了（`none`）。 -/
def bitten (p : Piece) (c : Creature) : Option Piece :=
  if p.tier ≤ 1 then none
  else
    let dy := (pCentre p).1 - (cCentre c).1
    let dx := (pCentre p).2 - (cCentre c).2
    let l2 := dy * dy + dx * dx
    let sr := if l2 = 0 then 0 else roundRatio dy l2
    let sc := if l2 = 0 then 0 else roundRatio dx l2
    let s : Int := (side (p.tier - 1) : Int)
    some ⟨p.tier - 1, min (max (p.row + sr) 10) (63 - s + 1), min (max (p.col + sc) 0) (64 - s)⟩

end Game
