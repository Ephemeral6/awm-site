/-
# Merge —— 同种两只挪完压在一起 ⇒ 并成高一级的一只（7+7→14、14+14→13）

对应 Python `rule/会动的东西/creatures_merge_on_overlap.py`（算法在 `derive/creature/merge.py`）。**只有定义。**

    什么时候   每一小步挪完：两只同种（追猎者或菱形）的 4×5 外接框相交（左上角行差 < 4、列差 < 5）
    落在哪     两只左上角的中点，向下取整
-/

import Rule.Creature.Chase

namespace Game

def upKind : Nat → Nat
  | 7 => 14
  | 14 => 13
  | _ => 0

def canMerge (a b : Creature) : Bool :=
  a.kind == b.kind && (a.kind == 7 || a.kind == 14) &&
  decide (a.row - b.row < 4) && decide (b.row - a.row < 4) &&
  decide (a.col - b.col < 5) && decide (b.col - a.col < 5)

/-- 并出来的那一只：两只左上角的中点（`/` 是向下取整：除数是正的）。 -/
def bornAt (a b : Creature) : Creature :=
  ⟨upKind a.kind, (a.row + b.row) / 2, (a.col + b.col) / 2⟩

end Game
