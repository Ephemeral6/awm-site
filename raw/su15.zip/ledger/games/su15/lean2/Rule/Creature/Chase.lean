/-
# Chase —— 离点击远的会动的东西：每一小步追**此刻**最近的那一件（追猎者、菱形 1 格，蟹 2 格）

对应 Python `rule/会动的东西/creature_chases_target.py`（算法在 `derive/creature/chase.py`、`slide.py`）。**只有定义。**
坐标 ×104 算整数：件心偏 (边长−1)·52，会动的东西的重心行偏 `rowOff`、列偏 208；一小步里某一轴差够半格（52）才挪。

    件在哪   被点的件滑过去：第 i 小步每轴最多挪 416·i（4 格），到了就停（`slideAt`）
    盯谁     每一小步：此刻离**挑点**（4×5 外接框中间格，行 + 2、列 + 2，`pickPoint`）最近的那一项；
             并列取排在前面的（点击之前的件按 (级, 行, 列) 排）；
             这一步里被咬过的件不在候选里（`Step.lean` 先筛掉再交给 `cands`）；
             上一小步盯的那件没被点动、此刻最近的那件也没被点动 ⇒ 接着盯上一小步那件（`choose`，修复第 1 轮）
    怎么挪   每轴 `speed · sgn`（按重心 `cCentre`；`speed` 追猎者、菱形 1，蟹 2，修复第 3 轮）；
             两轴都不动 ⇒ 停；挪完夹进棋盘（`place`）。压上了件不在这里停：挪完当场咬（4×5 外接框和件的正方形相交，
             `touches`；`Step.lean`）——修复第 3 轮去掉了「压上刚落下的那件就停」
-/

import Obj.World

namespace Game

def cCentre (c : Creature) : Int × Int := (c.row * 104 + rowOff c.kind, c.col * 104 + 208)
def pCentre (p : Piece) : Int × Int := (p.row * 104 + (p.sideI - 1) * 52, p.col * 104 + (p.sideI - 1) * 52)

def dist2 (a b : Int × Int) : Int := (a.1 - b.1) * (a.1 - b.1) + (a.2 - b.2) * (a.2 - b.2)

/-- 半格以上朝它挪一格；**正好 +½ 挪、正好 −½ 不挪**（= floor(差 + ½)，语料量出来的）。 -/
def sgn (d : Int) : Int := if 52 ≤ d then 1 else if d < -52 then -1 else 0

/-- 这一只压没压在这一件上：它的 4×5 外接框和件的正方形相交（两段区间各自有交）。 -/
def touches (c : Creature) (p : Piece) : Bool :=
  decide (p.row < c.row + 4) && decide (c.row < p.row + p.sideI) &&
  decide (p.col < c.col + 5) && decide (c.col < p.col + p.sideI)

/-- 夹进棋盘：4×5 的框整个在棋盘里（左上角行 10..60、列 0..59）。 -/
def place (k : Nat) (r c : Int) : Creature := ⟨k, min (max r 10) 60, min (max c 0) 59⟩

def clampI (x lo hi : Int) : Int := max lo (min hi x)

/-- 件心从 `a` 滑向 `b`，第 `i` 小步时在哪：每轴最多挪 416·i。 -/
def slideAt (a b : Int × Int) (i : Nat) : Int × Int :=
  (a.1 + clampI (b.1 - a.1) (-(416 * (i : Int))) (416 * (i : Int)),
   a.2 + clampI (b.2 - a.2) (-(416 * (i : Int))) (416 * (i : Int)))

/-- 某一小步时的一件：点击之前是哪一件、点击之后是哪一件、此刻件心在哪、落定没有。 -/
structure Cand where
  src     : Piece
  dest    : Piece
  centre  : Int × Int
  arrived : Bool
deriving DecidableEq, Repr

/-- 这一项此刻所在的那件：级同点击之后那一件，左上角按此刻的件心倒推（滑行每轴整格，倒推整除）。 -/
def Cand.at (k : Cand) : Piece :=
  ⟨k.dest.tier, (k.centre.1 - (k.dest.sideI - 1) * 52) / 104, (k.centre.2 - (k.dest.sideI - 1) * 52) / 104⟩

/-- 第 `i` 小步时盘上的件：点击之前的每一件（`srcs`，已排好）一项；`dst` 说它点击之后是哪一件。 -/
def cands (srcs : List Piece) (dst : Piece → Piece) (i : Nat) : List Cand :=
  srcs.map (fun p =>
    let x := slideAt (pCentre p) (pCentre (dst p)) i
    ⟨p, dst p, x, x == pCentre (dst p)⟩)

/-- 离 `cc` 最近的那一项；并列取排在前面的（严格更近才换）。没有件 ⇒ `none`。 -/
def nearest (cc : Int × Int) : List Cand → Option Cand
  | [] => none
  | k :: ks => some (ks.foldl (fun best x => if dist2 cc x.centre < dist2 cc best.centre then x else best) k)

/-- 挑目标用的那一点：4×5 外接框的中间格（行 + 2，列 + 2），×104。挪仍按重心（`cCentre`）。 -/
def pickPoint (c : Creature) : Int × Int := (c.row * 104 + 208, c.col * 104 + 208)

/-- 这一项没被这一下点动：点击之前和之后是同一件。 -/
def Cand.still (k : Cand) : Bool := k.src == k.dest

/-- 这一小步盯哪一项：此刻离挑点最近的 `best`；但上一小步盯的 `prev` 没被点动、还在候选里、`best` 也没被点动 ⇒ 接着盯 `prev`。 -/
def choose (prev : Option Cand) (cs : List Cand) (best : Cand) : Cand :=
  match prev with
  | some p => if p.still && best.still then (cs.find? (fun k => k.src == p.src)).getD best else best
  | none => best

/-- 照常追的每小步每轴挪几格：追猎者、菱形 1，蟹 2（修复第 3 轮）。 -/
def speed : Nat → Int
  | 13 => 2
  | _ => 1

/-- 一小步：挪完的样子、这一小步盯的那一项、停没停。没有件 ⇒ `none`。`prev` = 上一小步盯的那一项。
    压上了件不在这里停：挪完当场咬（`Step.lean`）。 -/
def chase (prev : Option Cand) (c : Creature) (cs : List Cand) : Option (Creature × Cand × Bool) :=
  match nearest (pickPoint c) cs with
  | none => none
  | some b =>
      let t := choose prev cs b
      let sr := sgn (t.centre.1 - (cCentre c).1)
      let sc := sgn (t.centre.2 - (cCentre c).2)
      if sr = 0 ∧ sc = 0 then some (c, t, true)
      else some (place c.kind (c.row + speed c.kind * sr) (c.col + speed c.kind * sc), t, false)

/-- 只看追的那一支：从第 `i` 小步起走 `n` 小步，停了就不再动（`Derived/StepBounded.lean` 用）。 -/
def chaseRun (srcs : List Piece) (dst : Piece → Piece) : Nat → Nat → Option Cand → Creature → Creature
  | 0, _, _, c => c
  | n + 1, i, prev, c =>
      match chase prev c (cands srcs dst i) with
      | none => c
      | some (c', t, stop) => if stop then c' else chaseRun srcs dst n (i + 1) (some t) c'

end Game
