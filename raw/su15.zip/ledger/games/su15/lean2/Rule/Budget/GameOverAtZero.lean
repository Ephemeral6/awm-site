/-
# GameOverAtZero —— 条上 0 格 ⇔ 终局

对应 Python `rule/预算/budget_game_over_at_zero.py`。**只有定义**：它是「终局」的定义。
-/

import Obj.World

namespace Game

def overAt (bar : Nat) : Bool := bar == 0

end Game
