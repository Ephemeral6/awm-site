/-
# StepCost —— 条上格数 = 64 − ⌊64k/N⌋；一下棋盘点击 k+1

对应 Python `rule/预算/budget_step_cost.py`（换算在 `derive/budget/steps.py`）。**只有定义。**

驳回（第 n 次罚 2n 步）修复第 4 轮起进模型：哪一下被驳回在 `Step.lean`（`clash`），罚几步按 `State.refused`
（模型自己数的这一条命里的驳回次数）算，`refusedBar`。
-/

import Obj.World

namespace Game

def barOf (k n : Nat) : Nat := 64 - (64 * k) / n

/-- 条上的格数反读出步数；读不出 `none`。 -/
def stepsOf (bar n : Nat) : Option Nat :=
  (List.range (n + 1)).find? (fun k => barOf k n == bar)

def nextBar (bar n : Nat) : Option Nat :=
  (stepsOf bar n).map (fun k => barOf (k + 1) n)

/-- 驳回（修复第 4 轮）：这一条命里第 `r + 1` 次驳回罚 2(r + 1) 步。 -/
def refusedBar (bar n r : Nat) : Option Nat :=
  (stepsOf bar n).map (fun k => barOf (k + 2 * (r + 1)) n)

end Game
