/-
# StepCost —— 条上格数 = 64 − ⌊64k/N⌋；一下棋盘点击 k+1

对应 Python `rule/预算/budget_step_cost.py`（换算在 `derive/budget/steps.py`）。**只有定义。**

**不进模型的那一支**：驳回（第 n 次罚 2n 步）。哪一下会被驳回说不出、罚几步要数历史，
模型照常按 k+1 算，驳回那几步在逐条对账里是判错，归因写在明处。
-/

import Obj.World

namespace Game

def barOf (k n : Nat) : Nat := 64 - (64 * k) / n

/-- 条上的格数反读出步数；读不出 `none`。 -/
def stepsOf (bar n : Nat) : Option Nat :=
  (List.range (n + 1)).find? (fun k => barOf k n == bar)

def nextBar (bar n : Nat) : Option Nat :=
  (stepsOf bar n).map (fun k => barOf (k + 1) n)

end Game
