/-
# Covered —— 样板都配上了：每个样板配一样**不同的**东西，落在某个圈的 9×9 框里

对应 Python `rule/什么算赢/levelup_iff_covered_after_step.py`（算法在 `derive/goal/covered.py`）。
**只有定义**：它就是「赢」的定义（`Step.lean` 在会动的东西每挪一小步之后、咬完之后各问它一次）。

    件样板        配**同级**的件，件整块落在框里（语料分不开同级与不低于，取同级）
    会动的东西样板 配同种的，它的**重心**落在框里（含边）
-/

import Rule.Creature.Chase

namespace Game

structure Thing where
  isPiece : Bool
  grade   : Nat
  inRing  : Bool

def pieceCells (p : Piece) : List (Int × Int) :=
  (List.range (side p.tier)).flatMap (fun (i : Nat) =>
    (List.range (side p.tier)).map (fun (j : Nat) => (p.row + (i : Int), p.col + (j : Int))))

def insideSome (cells : List (Int × Int)) (rs : List Ring) : Bool :=
  rs.any (fun r => cells.all (fun x => r.boxHas x.1 x.2))

/-- 重心（×104）落在某个圈的 9×9 框里。 -/
def centreInside (c : Creature) (rs : List Ring) : Bool :=
  rs.any (fun r =>
    decide (r.row * 104 ≤ (cCentre c).1) && decide ((cCentre c).1 ≤ (r.row + 8) * 104) &&
    decide (r.col * 104 ≤ (cCentre c).2) && decide ((cCentre c).2 ≤ (r.col + 8) * 104))

def things (rs : List Ring) (ps : List Piece) (cs : List Creature) : List Thing :=
  ps.map (fun p => ⟨true, p.tier, insideSome (pieceCells p) rs⟩) ++
  cs.map (fun c => ⟨false, c.kind, centreInside c rs⟩)

/-- 每个元素配上「拿掉它之后剩下的」。 -/
def picks {α : Type} : List α → List (α × List α)
  | [] => []
  | x :: xs => (x, xs) :: (picks xs).map (fun p => (p.1, x :: p.2))

def matchAll : List Sample → List Thing → Bool
  | [], _ => true
  | s :: ss, ts =>
      (picks ts).any (fun p =>
        p.1.isPiece == s.isPiece && p.1.grade == s.grade && p.1.inRing && matchAll ss p.2)

def covered (b : Board) (ps : List Piece) (cs : List Creature) : Bool :=
  !b.samples.isEmpty && matchAll b.samples (things b.rings ps cs)

end Game
