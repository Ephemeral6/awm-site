/-
# StillUncovered —— **推论**：模型交回一个「还在玩」的世界，那个世界上样板一定没配齐

对应 Python `rule/什么算赢/still_uncovered_while_playing.py`（只看观测到的下一帧：还在这一关，就没配齐）。
在这里它是 `Step.lean` 的分发 + `Rule/Goal/Covered.lean` 的**推论**，写成不变量的形状：
从一个没配齐的 `State` 出发（看得见的和看不见的会动的东西一起算），只要 `stepS` 交回的是 `.ok s'`（不是 `.won`），
`s'` 也没配齐。顶带点击那一支原样交回，所以要「出发时没配齐」这个前提；其余各支 `.ok` 只从 `finish` 出来，
而它先问过 `covered`（问的正是交出去的那两份：看得见的 ++ 看不见的）。
-/

import Step

namespace Game

/-- 整个 `State` 上的会动的东西：看得见的 ++ 看不见的。 -/
def State.all (s : State) : List Creature := s.world.creatures ++ s.hidden

theorem finish_ok (b : Board) (ps : List Piece) (vis hid : List Creature) (bar : Nat) (s' : State)
    (h : finish b ps vis hid bar = ResS.ok s') : covered b s'.world.pieces s'.all = false := by
  unfold finish at h
  split at h
  · simp at h
  · rename_i hc
    split at h
    · simp at h
    · simp only [ResS.ok.injEq] at h
      subst h
      simpa [State.all] using hc

theorem step_keeps_uncovered (b : Board) (lim : Nat) (s s' : State) (a : Act)
    (h0 : covered b s.world.pieces s.all = false)
    (h : stepS b lim s a = ResS.ok s') : covered b s'.world.pieces s'.all = false := by
  cases a with
  | undo => simp [stepS] at h
  | reset => simp [stepS] at h
  | click r c =>
    simp only [stepS] at h
    split at h
    · simp only [ResS.ok.injEq] at h
      subst h
      exact h0
    · unfold clickStep at h
      split at h
      · dsimp only at h
        split at h
        · simp at h
        · split at h
          · simp at h
          · split at h
            · simp at h
            · simp at h
            · unfold afterFrames at h
              dsimp only at h
              exact finish_ok _ _ _ _ _ _ h
      · simp at h

#print axioms finish_ok
#print axioms step_keeps_uncovered

end Game
