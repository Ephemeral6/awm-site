/-
# StepBounded —— **推论**：离点击远的会动的东西一步最多挪 4·速度 格（行、列各自；追猎者、菱形 4 格，蟹 8 格）

对应 Python `rule/会动的东西/creature_step_bounded.py`。它在 Python 那一侧是一条要逐帧核的规则（上界），
在这里是 `Rule/Creature/Chase.lean` 的**推论**：`chase` 一小步每轴挪 −速度 / 0 / +速度、夹进棋盘之后仍在棋盘里、种类不变，
`chaseRun` 最多走 4 小步。所以它不是一条独立的规则——它是「追」这个定义自己带出来的。
修复第 3 轮：蟹的速度是 2（`speed`），上界随之是 4·速度；追猎者、菱形仍是 4 格。

注意分量：这条定理说的是**模型**里照常追的那一支。离点击近的那些冲十几格、或一下扑过去（`Rule/Creature/Dash.lean`），
Python 那一条的论域也把它们排除在外；两边口径一致。前提「起点在棋盘里」是 parse 给的（4×5 的框整个在棋盘里）。
-/

import Rule.Creature.Chase

namespace Game

theorem sgn_bounds (d : Int) : sgn d ≤ 1 ∧ -1 ≤ sgn d := by
  unfold sgn
  split
  · omega
  · split <;> omega

theorem speed_cases (k : Nat) : speed k = 1 ∨ speed k = 2 := by
  unfold speed
  split <;> simp

/-- 在棋盘里：左上角行 10..60、列 0..59。 -/
def onBoard (c : Creature) : Prop := 10 ≤ c.row ∧ c.row ≤ 60 ∧ 0 ≤ c.col ∧ c.col ≤ 59

/-- 一小步：种类不变，每轴挪不超过它的速度，挪完还在棋盘里。 -/
theorem chase_step (prev : Option Cand) (c : Creature) (cs : List Cand)
    (c' : Creature) (t : Cand) (s : Bool)
    (hb : onBoard c) (h : chase prev c cs = some (c', t, s)) :
    c'.kind = c.kind ∧
    c'.row - c.row ≤ speed c.kind ∧ c.row - c'.row ≤ speed c.kind ∧
    c'.col - c.col ≤ speed c.kind ∧ c.col - c'.col ≤ speed c.kind ∧ onBoard c' := by
  have hv := speed_cases c.kind
  unfold onBoard at hb ⊢
  unfold chase at h
  split at h
  · simp at h
  · rename_i b _
    dsimp only at h
    split at h
    · simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -, -⟩ := h
      omega
    · simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -, -⟩ := h
      have s1 := sgn_bounds ((choose prev cs b).centre.1 - (cCentre c).1)
      have s2 := sgn_bounds ((choose prev cs b).centre.2 - (cCentre c).2)
      simp only [place]
      rcases hv with hv | hv <;> rw [hv] <;> refine ⟨trivial, ?_⟩ <;> omega

theorem chaseRun_bounded (srcs : List Piece) (dst : Piece → Piece) (v : Int) (hv : v = 1 ∨ v = 2) (n : Nat) :
    ∀ (i : Nat) (prev : Option Cand) (c : Creature), onBoard c → speed c.kind = v →
    (chaseRun srcs dst n i prev c).kind = c.kind ∧
    (chaseRun srcs dst n i prev c).row - c.row ≤ n * v ∧ c.row - (chaseRun srcs dst n i prev c).row ≤ n * v ∧
    (chaseRun srcs dst n i prev c).col - c.col ≤ n * v ∧ c.col - (chaseRun srcs dst n i prev c).col ≤ n * v := by
  rcases hv with rfl | rfl
  all_goals
    induction n with
    | zero => intro i prev c _ _; simp [chaseRun]
    | succ n ih =>
      intro i prev c hb hs
      simp only [chaseRun]
      split
      · omega
      · rename_i c' t s h
        have ⟨k1, a1, a2, a3, a4, hb'⟩ := chase_step prev c _ c' t s hb h
        rw [hs] at a1 a2 a3 a4
        split
        · refine ⟨k1, ?_, ?_, ?_, ?_⟩ <;> push_cast <;> omega
        · have hs' : speed c'.kind = speed c.kind := by rw [k1]
          rw [hs] at hs'
          have ⟨k2, b1, b2, b3, b4⟩ := ih (i + 1) (some t) c' hb' hs'
          refine ⟨by rw [k2, k1], ?_, ?_, ?_, ?_⟩ <;> push_cast <;> omega

/-- **离点击远的一步最多挪 4·速度 格**（行、列各自；追猎者、菱形 4，蟹 8）——对任何一只、任何一盘件都成立，不枚举。 -/
theorem chase_bounded (srcs : List Piece) (dst : Piece → Piece) (c : Creature) (hb : onBoard c) :
    (chaseRun srcs dst 4 1 none c).row - c.row ≤ 4 * speed c.kind ∧
    c.row - (chaseRun srcs dst 4 1 none c).row ≤ 4 * speed c.kind ∧
    (chaseRun srcs dst 4 1 none c).col - c.col ≤ 4 * speed c.kind ∧
    c.col - (chaseRun srcs dst 4 1 none c).col ≤ 4 * speed c.kind := by
  have ⟨_, h1, h2, h3, h4⟩ := chaseRun_bounded srcs dst (speed c.kind) (speed_cases c.kind) 4 1 none c hb rfl
  push_cast at h1 h2 h3 h4
  exact ⟨h1, h2, h3, h4⟩

#print axioms sgn_bounds
#print axioms speed_cases
#print axioms chase_step
#print axioms chaseRun_bounded
#print axioms chase_bounded

end Game
