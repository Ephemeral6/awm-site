/-
# StepBounded —— **推论**：离点击远的会动的东西一步最多挪 4 格（行、列各自）

对应 Python `rule/会动的东西/creature_step_bounded.py`。它在 Python 那一侧是一条要逐帧核的规则（上界），
在这里是 `Rule/Creature/Chase.lean` 的**推论**：`chase` 一小步每轴挪 −1 / 0 / +1、夹进棋盘之后仍在棋盘里，
`chaseRun` 最多走 4 小步。所以它不是一条独立的规则——它是「追」这个定义自己带出来的。

注意分量：这条定理说的是**模型**里照常追的那一支。离点击近的那些冲十几格、或一下扑过去（`Rule/Creature/Dash.lean`），
Python 那一条的论域也把它们排除在外；两边口径一致。前提「起点在棋盘里」是 parse 给的（4×5 的框整个在棋盘里）。
-/

import Rule.Creature.Chase

namespace Game

theorem sgn_bounds (d : Int) : sgn d ≤ 1 ∧ -1 ≤ sgn d := by
  unfold sgn
  split
  · omega
  · split <;> omega

/-- 在棋盘里：左上角行 10..60、列 0..59。 -/
def onBoard (c : Creature) : Prop := 10 ≤ c.row ∧ c.row ≤ 60 ∧ 0 ≤ c.col ∧ c.col ≤ 59

/-- 一小步：每轴挪不超过 1，挪完还在棋盘里。 -/
theorem chase_step (c : Creature) (cs : List Cand) (c' : Creature) (t : Cand) (s : Bool)
    (hb : onBoard c) (h : chase c cs = some (c', t, s)) :
    c'.row - c.row ≤ 1 ∧ c.row - c'.row ≤ 1 ∧ c'.col - c.col ≤ 1 ∧ c.col - c'.col ≤ 1 ∧ onBoard c' := by
  unfold onBoard at hb ⊢
  unfold chase at h
  split at h
  · simp at h
  · rename_i t0 _
    split at h
    · simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -, -⟩ := h
      omega
    · dsimp only at h
      split at h
      · simp only [Option.some.injEq, Prod.mk.injEq] at h
        obtain ⟨rfl, -, -⟩ := h
        omega
      · simp only [Option.some.injEq, Prod.mk.injEq] at h
        obtain ⟨rfl, -, -⟩ := h
        have s1 := sgn_bounds (t0.centre.1 - (cCentre c).1)
        have s2 := sgn_bounds (t0.centre.2 - (cCentre c).2)
        simp only [place]
        omega

theorem chaseRun_bounded (srcs : List Piece) (dst : Piece → Piece) (n : Nat) : ∀ (i : Nat) (c : Creature),
    onBoard c →
    (chaseRun srcs dst n i c).row - c.row ≤ n ∧ c.row - (chaseRun srcs dst n i c).row ≤ n ∧
    (chaseRun srcs dst n i c).col - c.col ≤ n ∧ c.col - (chaseRun srcs dst n i c).col ≤ n := by
  induction n with
  | zero => intro i c _; simp [chaseRun]
  | succ n ih =>
    intro i c hb
    simp only [chaseRun]
    split
    · omega
    · rename_i c' t s h
      have ⟨a1, a2, a3, a4, hb'⟩ := chase_step c _ c' t s hb h
      split
      · push_cast; omega
      · have ⟨b1, b2, b3, b4⟩ := ih (i + 1) c' hb'
        push_cast; omega

/-- **离点击远的一步最多挪 4 格**（行、列各自）——对任何一只、任何一盘件都成立，不枚举。 -/
theorem chase_bounded (srcs : List Piece) (dst : Piece → Piece) (c : Creature) (hb : onBoard c) :
    (chaseRun srcs dst 4 1 c).row - c.row ≤ 4 ∧ c.row - (chaseRun srcs dst 4 1 c).row ≤ 4 ∧
    (chaseRun srcs dst 4 1 c).col - c.col ≤ 4 ∧ c.col - (chaseRun srcs dst 4 1 c).col ≤ 4 :=
  chaseRun_bounded srcs dst 4 1 c hb

#print axioms sgn_bounds
#print axioms chase_step
#print axioms chaseRun_bounded
#print axioms chase_bounded

end Game
