/-
# OutOfReach —— **推论**：点击这一相碰不到射程外的件

对应 Python `rule/一步怎么走/pieces_out_of_reach_stay_or_bitten.py`（上界：射程外的件只许原地不动或被咬）。
「原地不动」那一半在这里是 `Rule/Click/LandsFresh.lean` 的**推论**：`resolve` 之后射程外的每一件原样还在。
「或被咬」那一半归咬（`Rule/Creature/Bite.lean`）：`Step.lean` 里件只在 `applyBites` 那一处再变。
-/

import Rule.Click.LandsFresh

namespace Game

theorem resolve_keeps_far (ps : List Piece) (r c : Int) (res : Resolved) (p : Piece)
    (h : resolve ps r c = some res) (hp : p ∈ ps) (hfar : 64 < reach2 p r c) : p ∈ res.pieces := by
  have hnot : ∀ q, q ∈ inReach ps r c → q ≠ p := by
    intro q hq heq
    subst heq
    simp [inReach, List.mem_filter] at hq
    omega
  unfold resolve at h
  split at h
  · simp only [Option.some.injEq] at h
    subst h
    exact hp
  · rename_i q hq
    simp only [Option.some.injEq] at h
    subst h
    have hne : q ≠ p := hnot q (by rw [hq]; simp)
    simp only [List.mem_map]
    exact ⟨p, hp, by simp [Ne.symm hne]⟩
  · rename_i a b hab
    have hna : a ≠ p := hnot a (by rw [hab]; simp)
    have hnb : b ≠ p := hnot b (by rw [hab]; simp)
    split at h
    · simp only [Option.some.injEq] at h
      subst h
      simp only [List.mem_append, List.mem_filter]
      left
      exact ⟨hp, by simp [Ne.symm hna, Ne.symm hnb]⟩
    · simp only [Option.some.injEq] at h
      subst h
      exact hp
  · simp at h

#print axioms resolve_keeps_far

end Game
