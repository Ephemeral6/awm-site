/-
# Memory —— 带记忆的两把尺子，与全部 904 行的带记忆判决（**手写**，不是生成的）

`Obs/Check.lean` 的两把尺子（`agrees` / `traceOk`）吃的是 `step`：每一步从**这一帧**起算，看不见的部分是空的。
这一份是它们的带记忆版——**比的东西一模一样**（模型交出的看得见的那三位 = 观测到的那一帧），
多出来的只有一件：模型自己上一步算出来的、帧上看不见的那几只（`State.hidden`）接着往下传。
`Obs/` 一个字没动：不带记忆那一读（`Obs/Corpus.lean`）照旧在，就是「拿掉记忆」那一处消融的读数。

    agreesS / traceOkS   带记忆的两把尺子
    carry                逐行判决的喂法：上一行模型给了 `ok s`、同一关、`s` 看得见的那一半 = 这一行观测到的那一帧
                         ⇒ 带上 `s.hidden`；否则空（Python 那一份在 `derive/memory.py`，独立写，逐条对账）
    verdictsM            #eval 读数：全部 904 行的带记忆判决（**读数不是定理**）
    hides_903 / wins_904_mem / wins_904_nomem   内核算出来的三件事：第 903 行模型看着一只菱形扑进件底下；
                         带着它，第 904 行模型说过关；不带它（从帧起算），模型说没过关
-/

import Obs.Replay

namespace Game
namespace Memory
open Replay

/-- 一步的结局（带记忆）对着现实那一侧：三值，同 `agrees`。 -/
def judgeS : ResS → Post → Option Bool
  | .na, _ => none
  | .ok s, .same o => some (s.world == o)
  | .won, .levelUp => some true
  | .won, .win => some true
  | .over, .gameOver => some true
  | _, _ => some false

def agreesS (b : Board) (lim : Nat) (s : State) (a : Act) (post : Post) : Option Bool :=
  judgeS (stepS b lim s a) post

/-- 从 `s` 出发沿 `play` 走，每一步只比看得见的那一半；**下一轮喂进去的是模型自己算出来的整个 `s'`**。 -/
def traceOkS (b : Board) (lim : Nat) : State → List (Act × World) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
      match stepS b lim s a with
      | .ok s' => s'.world == o && traceOkS b lim s' rest
      | _ => false

/-- 这一行起始时带上的看不见的那几只。 -/
def carry (prev : Option (Row × ResS)) (r : Row) : List Creature :=
  match prev with
  | some (p, .ok s) => if p.lvl == r.lvl && s.world == worldAt r.prev then s.hidden else []
  | _ => []

def charOf : Option Bool → Char
  | some true => 'T'
  | some false => 'F'
  | none => 'N'

def runM : Option (Row × ResS) → List Row → List Char
  | _, [] => []
  | prev, r :: rs =>
      let res := stepS (boardOf r.lvl) (limitOf r.lvl) ⟨worldAt r.prev, carry prev r⟩ r.act
      charOf (judgeS res r.post) :: runM (some (r, res)) rs

def verdictsM : String := String.ofList (runM none rows)

#eval "VERDICTS_MEM " ++ verdictsM
#eval s!"COUNTS_MEM T={(verdictsM.toList.filter (· == 'T')).length} F={(verdictsM.toList.filter (· == 'F')).length} N={(verdictsM.toList.filter (· == 'N')).length}"

/-- 第 903 行（认证段，第 8 关）：从观测到的那一帧起算，模型交出的世界看得见的那一半和观测一致，
    看不见的那一半里有一只菱形——它扑进了 5 级件底下，帧上一格不露。内核算。 -/
theorem hides_903 :
    (match stepS (boardOf 8) (limitOf 8) (State.ofWorld (worldAt (bySeq 903).prev)) (bySeq 903).act with
     | .ok s => s.world == worldAt (bySeq 903).next && s.hidden == [⟨14, 39, 11⟩]
     | _ => false) = true := by decide +kernel

/-- 第 904 行（过关那一脚）：带着那只看不见的菱形，模型说过关——和现实一致。内核算。 -/
theorem wins_904_mem :
    agreesS (boardOf 8) (limitOf 8) ⟨worldAt (bySeq 904).prev, [⟨14, 39, 11⟩]⟩ (bySeq 904).act (bySeq 904).post
      = some true := by decide +kernel

/-- 同一行，不带它（`Obs/Check.lean` 的 `agrees`，从帧起算）：模型说没过关——和现实不一致。内核算。 -/
theorem wins_904_nomem :
    agrees (boardOf 8) (limitOf 8) (worldAt (bySeq 904).prev) (bySeq 904).act (bySeq 904).post = some false := by
  decide +kernel

#print axioms hides_903
#print axioms wins_904_mem
#print axioms wins_904_nomem

end Memory
end Game
