/-
# Reachable —— 这个局面走得通 / 走不通

    Winnable   w  :=  ∃ as, 每一下合法 ∧ 从 w 起照着走中途赢过
    Unsolvable w  :=  ∀ as, 每一下合法 → 从 w 起照着走从没赢过

「从 w 起」= 从观测到的那一帧起，看不见的部分是空的（`State.ofWorld`）；之后每一步模型自己算出来的
`State` 原样传下去——看不见的那几只一路带着（`everWonS`）。**起点不凭空补看不见的东西**。

**写在明处的削弱**：`everWonS` 碰到模型说不出话的那一支（撤销、RESET、射程里 ≥3 件、蟹离点击近、两只同一小步咬同一件……）
返回 `false`。于是 `Winnable` 的意思是「**不经过那几支**就走得通」——见证路线里一步 `na` 都没有，这一条是被内核算出来的；
而 `Unsolvable` 的意思会变成「**不经过那几支**就赢不了」。**这一局没有宣告任何一关走不通**
（全部 9 关都有人通过，成绩单 9/9），所以下面那条骨架只是骨架：它在这里一次都没被用来说「不可做」。
-/

import Step

namespace Game

/-- 合法的一下：点在 64×64 的帧里。谈可不可做时必须限死，否则「一下点到帧外某处」就成了一种走法。 -/
def Act.legal : Act → Bool
  | .click r c => decide (0 ≤ r) && decide (r < 64) && decide (0 ≤ c) && decide (c < 64)
  | .undo => true
  | .reset => true

def everWonS (b : Board) (lim : Nat) : State → List Act → Bool
  | _, [] => false
  | s, a :: as =>
      match stepS b lim s a with
      | .won => true
      | .ok s' => everWonS b lim s' as
      | _ => false

/-- 从观测到的那一帧起照着走，中途赢过没有。 -/
def everWon (b : Board) (lim : Nat) (w : World) (as : List Act) : Bool := everWonS b lim (State.ofWorld w) as

def Winnable (b : Board) (lim : Nat) (w : World) : Prop :=
  ∃ as : List Act, (as.all Act.legal = true) ∧ everWon b lim w as = true

def Unsolvable (b : Board) (lim : Nat) (w : World) : Prop :=
  ∀ as : List Act, as.all Act.legal = true → everWon b lim w as = false

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (lim : Nat) (w : World) : Winnable b lim w → Unsolvable b lim w → False := by
  intro ⟨as, hl, hw⟩ hu
  have := hu as hl
  rw [this] at hw
  exact Bool.false_ne_true hw

/-- 骨架：`State` 上的不变量 ⇒ 不可做。**全文唯一做归纳的地方**，与盘面大小、动作串多长都无关，不枚举任何状态。 -/
theorem unsolvable_of_invariant (b : Board) (lim : Nat) (P : State → Prop)
    (hkeep : ∀ s s' a, Act.legal a = true → P s → stepS b lim s a = ResS.ok s' → P s')
    (hwin : ∀ s a, P s → stepS b lim s a ≠ ResS.won) :
    ∀ w, P (State.ofWorld w) → Unsolvable b lim w := by
  intro w hp as
  unfold everWon
  generalize State.ofWorld w = s at hp
  induction as generalizing s with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [List.all_cons, Bool.and_eq_true] at hall
    simp only [everWonS]
    cases hstep : stepS b lim s a with
    | won => exact absurd hstep (hwin s a hp)
    | over => rfl
    | na => rfl
    | ok s' => exact ih s' (hkeep s s' a hall.1 hp hstep) hall.2

#print axioms not_both
#print axioms unsolvable_of_invariant

end Game
