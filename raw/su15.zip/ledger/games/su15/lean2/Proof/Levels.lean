/-
# Levels —— 每一关一条定理（`lean2/export_levels.py` 生成，不要手改）

见证路线 = 成绩单认证的那一段（guid b99b56c2-927c-4317-9c5b-cabe92435957，第 815..904 行，90 行）。

    L<n>_trace         沿着真人走过的那条路，只有开局那一帧是观测给的（看不见的部分是空的），
                       模型每一帧看得见的那一半都和观测对上；模型自己算出来的整个 `State`（含帧上看不见的那几只）一路带着
    L<n>_winnable      这一关从开局起走得通 —— 见证就是那条路（{不经过模型说不出话的那几支}）
    L<n>_seg<k>_trace  这一关的路断成几段时，每一段各自对上；**每一段的起点是观测到的那一帧**（看不见的部分是空的）
    L<n>_tail_winnable 最后一段接上过关那一脚：从那一段的起点（观测到的）走得通
    L<n>_gap           这一关两样都没有从开局起的定理 —— 明写的缺口，断在哪一行、为什么，写在它的注释里

这一局没有任何一关写 `_unsolvable`：9 关全部有人通过（成绩单 9/9），也就没有「走不通」可证。
-/

import Obs.Replay
import Proof.Reachable
import Proof.Memory

namespace Game
namespace Levels
open Replay Memory

/-- 第 0 关的真实开局：第 815 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L0_start : World := worldAt 0

/-- 开局到过关前一步，6 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L0_play : List (Act × World) := playFrom 815 6

/-- 整关的动作，7 下（含过关那一脚）。 -/
def L0_acts : List Act := actsFrom 815 7

theorem L0_play_len : L0_play.length = 6 := by decide +kernel
theorem L0_acts_len : L0_acts.length = 7 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 6 帧全是模型自己算的。 -/
theorem L0_trace : traceOkS (boardOf 0) (limitOf 0) (State.ofWorld L0_start) L0_play = true := by decide +kernel

/-- **第 0 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 7 下。 -/
theorem L0_winnable : Winnable (boardOf 0) (limitOf 0) L0_start :=
  ⟨L0_acts, by decide +kernel, by decide +kernel⟩

#print axioms L0_play_len
#print axioms L0_acts_len
#print axioms L0_trace
#print axioms L0_winnable

/-- 第 1 关的真实开局：第 822 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L1_start : World := worldAt 47

/-- 开局到过关前一步，11 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L1_play : List (Act × World) := playFrom 822 11

/-- 整关的动作，12 下（含过关那一脚）。 -/
def L1_acts : List Act := actsFrom 822 12

theorem L1_play_len : L1_play.length = 11 := by decide +kernel
theorem L1_acts_len : L1_acts.length = 12 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 11 帧全是模型自己算的。 -/
theorem L1_trace : traceOkS (boardOf 1) (limitOf 1) (State.ofWorld L1_start) L1_play = true := by decide +kernel

/-- **第 1 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 12 下。 -/
theorem L1_winnable : Winnable (boardOf 1) (limitOf 1) L1_start :=
  ⟨L1_acts, by decide +kernel, by decide +kernel⟩

#print axioms L1_play_len
#print axioms L1_acts_len
#print axioms L1_trace
#print axioms L1_winnable

/-- 第 2 关的真实开局：第 834 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L2_start : World := worldAt 59

/-- 开局到过关前一步，15 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L2_play : List (Act × World) := playFrom 834 15

/-- 整关的动作，16 下（含过关那一脚）。 -/
def L2_acts : List Act := actsFrom 834 16

theorem L2_play_len : L2_play.length = 15 := by decide +kernel
theorem L2_acts_len : L2_acts.length = 16 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 15 帧全是模型自己算的。 -/
theorem L2_trace : traceOkS (boardOf 2) (limitOf 2) (State.ofWorld L2_start) L2_play = true := by decide +kernel

/-- **第 2 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 16 下。 -/
theorem L2_winnable : Winnable (boardOf 2) (limitOf 2) L2_start :=
  ⟨L2_acts, by decide +kernel, by decide +kernel⟩

#print axioms L2_play_len
#print axioms L2_acts_len
#print axioms L2_trace
#print axioms L2_winnable

/-- 第 3 关的真实开局：第 850 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L3_start : World := worldAt 75

/-- 开局到过关前一步，11 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L3_play : List (Act × World) := playFrom 850 11

/-- 整关的动作，12 下（含过关那一脚）。 -/
def L3_acts : List Act := actsFrom 850 12

theorem L3_play_len : L3_play.length = 11 := by decide +kernel
theorem L3_acts_len : L3_acts.length = 12 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 11 帧全是模型自己算的。 -/
theorem L3_trace : traceOkS (boardOf 3) (limitOf 3) (State.ofWorld L3_start) L3_play = true := by decide +kernel

/-- **第 3 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 12 下。 -/
theorem L3_winnable : Winnable (boardOf 3) (limitOf 3) L3_start :=
  ⟨L3_acts, by decide +kernel, by decide +kernel⟩

#print axioms L3_play_len
#print axioms L3_acts_len
#print axioms L3_trace
#print axioms L3_winnable

/-- 第 4 关的真实开局：第 862 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L4_start : World := worldAt 91

/-- 开局到过关前一步，5 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L4_play : List (Act × World) := playFrom 862 5

/-- 整关的动作，6 下（含过关那一脚）。 -/
def L4_acts : List Act := actsFrom 862 6

theorem L4_play_len : L4_play.length = 5 := by decide +kernel
theorem L4_acts_len : L4_acts.length = 6 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 5 帧全是模型自己算的。 -/
theorem L4_trace : traceOkS (boardOf 4) (limitOf 4) (State.ofWorld L4_start) L4_play = true := by decide +kernel

/-- **第 4 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 6 下。 -/
theorem L4_winnable : Winnable (boardOf 4) (limitOf 4) L4_start :=
  ⟨L4_acts, by decide +kernel, by decide +kernel⟩

#print axioms L4_play_len
#print axioms L4_acts_len
#print axioms L4_trace
#print axioms L4_winnable

/-- 第 5 关的真实开局：第 868 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L5_start : World := worldAt 103

/-- 开局到过关前一步，10 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L5_play : List (Act × World) := playFrom 868 10

/-- 整关的动作，11 下（含过关那一脚）。 -/
def L5_acts : List Act := actsFrom 868 11

theorem L5_play_len : L5_play.length = 10 := by decide +kernel
theorem L5_acts_len : L5_acts.length = 11 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 10 帧全是模型自己算的。 -/
theorem L5_trace : traceOkS (boardOf 5) (limitOf 5) (State.ofWorld L5_start) L5_play = true := by decide +kernel

/-- **第 5 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 11 下。 -/
theorem L5_winnable : Winnable (boardOf 5) (limitOf 5) L5_start :=
  ⟨L5_acts, by decide +kernel, by decide +kernel⟩

#print axioms L5_play_len
#print axioms L5_acts_len
#print axioms L5_trace
#print axioms L5_winnable

/-- 第 6 关的真实开局：第 879 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L6_start : World := worldAt 115

/-- 开局到过关前一步，5 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L6_play : List (Act × World) := playFrom 879 5

/-- 整关的动作，6 下（含过关那一脚）。 -/
def L6_acts : List Act := actsFrom 879 6

theorem L6_play_len : L6_play.length = 5 := by decide +kernel
theorem L6_acts_len : L6_acts.length = 6 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 5 帧全是模型自己算的。 -/
theorem L6_trace : traceOkS (boardOf 6) (limitOf 6) (State.ofWorld L6_start) L6_play = true := by decide +kernel

/-- **第 6 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 6 下。 -/
theorem L6_winnable : Winnable (boardOf 6) (limitOf 6) L6_start :=
  ⟨L6_acts, by decide +kernel, by decide +kernel⟩

#print axioms L6_play_len
#print axioms L6_acts_len
#print axioms L6_trace
#print axioms L6_winnable

/-- 第 7 关的真实开局：第 885 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L7_start : World := worldAt 121

/-- 开局到过关前一步，9 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L7_play : List (Act × World) := playFrom 885 9

/-- 整关的动作，10 下（含过关那一脚）。 -/
def L7_acts : List Act := actsFrom 885 10

theorem L7_play_len : L7_play.length = 9 := by decide +kernel
theorem L7_acts_len : L7_acts.length = 10 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 9 帧全是模型自己算的。 -/
theorem L7_trace : traceOkS (boardOf 7) (limitOf 7) (State.ofWorld L7_start) L7_play = true := by decide +kernel

/-- **第 7 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 10 下。 -/
theorem L7_winnable : Winnable (boardOf 7) (limitOf 7) L7_start :=
  ⟨L7_acts, by decide +kernel, by decide +kernel⟩

#print axioms L7_play_len
#print axioms L7_acts_len
#print axioms L7_trace
#print axioms L7_winnable

/-- 第 8 关的真实开局：第 895 行动作之前那一帧（从 Replay 取，不是手写的盘）。 -/
def L8_start : World := worldAt 143

/-- 开局到过关前一步，9 步（过关那一脚的下一帧是下一关的盘，不在这里）。 -/
def L8_play : List (Act × World) := playFrom 895 9

/-- 整关的动作，10 下（含过关那一脚）。 -/
def L8_acts : List Act := actsFrom 895 10

theorem L8_play_len : L8_play.length = 9 := by decide +kernel
theorem L8_acts_len : L8_acts.length = 10 := by decide +kernel

/-- **模型沿着真人的路一步不差**：只有开局那一帧是观测给的，后面 9 帧全是模型自己算的。 -/
theorem L8_trace : traceOkS (boardOf 8) (limitOf 8) (State.ofWorld L8_start) L8_play = true := by decide +kernel

/-- **第 8 关走得通**（不经过模型说不出话的那几支）。见证 = 真人那 10 下。 -/
theorem L8_winnable : Winnable (boardOf 8) (limitOf 8) L8_start :=
  ⟨L8_acts, by decide +kernel, by decide +kernel⟩

#print axioms L8_play_len
#print axioms L8_acts_len
#print axioms L8_trace
#print axioms L8_winnable


end Levels
end Game
