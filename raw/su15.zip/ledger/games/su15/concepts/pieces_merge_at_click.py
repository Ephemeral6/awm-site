"""ACTION6 点棋盘区：最近一格在 REACH 内的件——0 件则棋盘不变；1 件则它搬到点击处；2 件同级则两件消失、点击处出现高一级的件；世界整条驳回这次点击（除第 63 行外一格不变）时本概念不主张。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6:x,y 且 10<=y<63；换关返回 NA；REACH 内 ≥3 件或两件不同级返回 NA（没见过）；"
         "**落点按 _lib.placed 算，出界的那一档夹回去：左右下夹帧的边，上夹棋盘顶（第 10 行）**"
         "（三次观测，左右上各一次，见 NOTE v13/v16/v18）；"
         "**REACH 内有件、而这一帧除第 63 行外一格不变（世界整条驳回了这次点击）返回 NA**（见 NOTE v11）；"
         "**nxt 里的色7 格压在或 8-邻接挨着点击后任一件的格子返回 NA**（色7 追上件会毁件，毁件的落点规律还没找出来）；"
         "**nxt 上件的总容量比 prev 少（这一步有件被降级）返回 NA**（降级件的落点没有模型，见 NOTE v10）；"
         "只断言棋盘区（不含第 63 行）；非件颜色占的格子不断言——新件该出现的格子照常严格核对，"
         "其余格子只要 prev 或 nxt 上是非底色的非件颜色（色9 圈、色3 引导点、色7 会自己动的物件）就跳过；"
         "**腾出的格子落在认不出原点的色9 碎块附近（_lib.octagons 的 unsure）也跳过**（底下是圈还是底色说不准）")
NOTE = ("v1: 由第 0 关的 3×3 搬家（Δ(6,6)/(7,0)/(9,0) 能、(7,7)/(10,1) 不能）与第 1 关的单点搬家、两点合成 2×2 抽出；件的中心 = 方块几何中心（2×2 取半格），4×4 的落点公式待测。"
        "v2: 4×4 落点 (y-2,x-2) 已由 720d4f9031bb562d 证实；apply 的静态物件保守分支收窄成只在静态物件包围盒内不认领腾出格——第 3 关角落里一个 8 格色7 物件本来会让全盘腾出格都不认领，链式预测从第 5 步起全哑。"
        "v3: 死于 1c3a9aa1bacfeea4——那个色7 物件不是静态的，它每步自己平移，整帧比对就把它的搬家算成本概念说错。"
        "改成只对『件该在哪』负责：非件颜色的格子一律不断言，apply 的不认领区按物件包围盒外扩 8 格。"
        "v4: 死于 a8573ce41bed5fd8——色7 追上 (27,32) 的 2×2 并压上去，那件消失、一个 1×1 出现在 (27,22)。"
        "件被毁不是本概念的事，但它让『没被点到的件不动』落空；毁件规律只见过一次，先把这种转移划出去"
        "v5: 主张没变，只是 apply 不再对色7 打整片折扣——色7 的去向现在有模型（_lib.mover_next），"
        "把它将占的那几格排除掉就行，剩下的腾出格照常认领。包围盒外扩只留给位置事先不可知的非件颜色。"
        "v6: 死于 f69577c44363eda4——色7 没压上件、只是 4-邻接挨着 (15,20) 的 3×3（它的尖端在件的左下角旁边），"
        "那件就没了、一个 2×2 出现在 (10,26)。而前一步 a8dbb391a055b5cf 里另一个色7 同样 4-邻接挨着 (18,43) 的 3×3（尖端在件正下方），件却没事。"
        "什么算『追上』还说不清，先把『挨着』也划出去，规律留给 L6 的概念去写"
        "v7: 主张没变，改的是 apply 腾出格填什么。第 119 步意外 5 格：件从色9 圈上搬走，露出来的是色9 不是底色。"
        "色9 圈是静态背景（_lib.octagons 按 9×9 正八边形模板补全，probe_octagon 清点过全部 121 帧），"
        "腾出格改填『那一格底下是什么』；认不出原点的色9 碎块附近一律不认领。"
        "assert_ 本来就放过非件颜色，所以这五格从来没被记成反例——生成器超额主张，闸是看不见的，只有 --strict 看得见。"
        "改的头一版当场死在 c54b78f52b0ef1fd（就是第 119 步那条）：圈被那块 7×7 盖掉一角、认不出原点，"
        "腾出格落进 unsure 就从 exp 里被删了，而 assert_ 对不在 exp 里的格子拿 prev 当押注，于是件明明搬走了却押它还在。"
        "两处一起改才对：octagons 改成能从碎片反推原点（模板里露不出色9 的格子必须正被别的东西盖着，只剩一个原点才算认出），"
        "assert_ 对 unsure 的格子显式闭嘴。改完全 250 帧一个圈都不剩 unsure。"
        "v9: 主张与 assert_ 没动，只让 apply 在**这一步要过关**时闭嘴。assert_ 一直在换关时返回 NA，"
        "apply 却看不见换关（预测时 ctx 里 level_next = level_prev），于是照旧把件画在新关的整屏重画上——"
        "全册 apply 说错的 65 格就是这么来的。改用 _lib.will_level_up（由 levelup_when_samples_in_octagon 走闸）判。"
        "v10: 死于 868bde228addb7ee——第 147 步点 (42,40)，那块 7×7 该整块搬到 (行37-43,列39-45)，"
        "实际 nxt 上是一块 5×5 在 (行42-46,列40-44)：它被降了一级又被挪走。"
        "v4/v6 立的那道闸（nxt 上色7 压着或挨着点击后的件就闭嘴）这次一点用没有——**毁它的东西在 nxt 上不是色7**："
        "唯一剩下的追猎者远在 (行33-36,列23-27)，而件原地冒出来一块 8 格的色14（行31-34,列32-36），"
        "整块落在它上一帧的footprint 里（色14 以前只在第 111 步出现过 3 格，也是追猎者撞上件的那一步）。"
        "所以判据换成直接量结果：**件的总容量掉了就是有件被毁**，不管毁它的是什么颜色、在不在场上看得见。"
        "这比『色7 挨着』严格——降级一定让容量掉，而『挨着』既漏（第 147 步）又误伤（挨着但没事的步）。"
        "v11: 死于 896e274a965f31be（第 165 步）——点 (列28,行50)，3 级件（行44-46列20-22）最近一格离点击点"
        "行差4 列差6、欧氏 7.211，稳稳在 REACH 内，本概念说它搬到行49-51列27-29；**世界一格没动**："
        "件没搬、两只色7 没走、色14 没走、顶带没变，只有第 63 行被吃掉 2 格。全语料 143 次棋盘点击里独此一次。"
        "先横着查了共用词 in_reach 会不会本来就错（方法册『模型破口要横着查』）：把全部点击按"
        "『点击点到件里最近一格』的行差列差摊成方位图，抓到的最远是欧氏 8.0（(8,0) 与 (0,8)），"
        "抓空的最近是 8.062（(7,4)），中间还有 (6,6)=8.485、(9,0)=9.0 都在外侧——**R=8 是一条干净的分界线**，"
        "拿 R^2 从 16 扫到 400 重拟合整条规则，R^2=64 仍是反例最少的那个。所以破口不在 REACH。"
        "又试了几条能解释它的规律，全被语料打死：(a)『歧义半径 Ra 内出现异级件就驳回』——"
        "第 95/96/143 步的异级件分别在 8.944/10.05/10.296 格，世界照常搬件，而这一步的 5 级件在 10.817，"
        "Ra 只剩 (10.296, 10.817] 这条缝，且换成按件中心量立刻自相矛盾（第 95 步两件中心都在 9.7 内）；"
        "(b)『点击点离会动物件太近就驳回』——第 155 步点在物件格上（距离 0）照样搬件；"
        "(c)『只能沿八方向搬』——第 146 步位移 Δ(+6,+10) 成功；(d) 落点被占/出界——落点行49-51列27-29 全是底色。"
        "所以**世界能整条驳回一次棋盘点击，触发条件还没找出来**，这是册子上一个明说的洞。"
        "同类只有一次先例：18759a98b7574fbc（第 165 步之外唯一的冻帧点击，两件不同级在 REACH 内，"
        "本概念一直就对它返回 NA，budget_step_cost v4 记下它罚了双倍预算）。"
        "本版只做诚实的缩 scope：REACH 内有件而整帧冻住时闭嘴，不发明触发条件。"
        "apply 照旧认领搬家——生成器敢押，押错了在 --strict 上当场停批，比闭嘴更早暴露这个洞。"
        "v12: 主张与 assert_ 没动，只把 apply 的那道『色7 会挨上件就整条不认领』换成按结果分档。"
        "由来：第 8 关每一步都是合并步或捕获步，追猎者必然挨上件，于是 apply 整关一格不认——"
        "第 190 步 `lens.py predict` 只押中 1 格（还是计价条那一格），一只追猎者跑错 11 行也没人报警，"
        "`act --strict` 在最需要它的那一关形同虚设。旧判据用的还是全场并集 mover_next，粒度也不够。"
        "新判据逐只算 capture_landing：落点压上**没被点的**件才闭嘴（那件要降级，落点无模型，仍是 v10 那条）；"
        "压上刚点的那件不闭嘴——件画在物件上面，新件的格子照样是件色。"
        "另外两档硬剪：新件的格子盖在某只物件的原位上（第 155/190 步实测被甩出 12 行，公式未知），"
        "以及两只同时压上新鲜件要并（新物件生在哪，第 111/146/157 步三次观测对不上任何公式）——"
        "后者只把件包围盒外扩 5 格之内的腾出格让出去，别处照常认领。"
        "v13: 死于 7728de94e67f5fc1（第 289 步，终局卡）——点 (列63,行28)，3 级件按 placed 该落在左上 (行27,列62)，"
        "那样它要占列 62/63/64，而帧只有 0..63 列；实测左上是 (行27,列61)，整件贴着右边界放下。"
        "主张没变（『它搬到点击处』），改的是词汇 `_lib.placed`：落点先按老公式算，**再夹进帧的四边**。"
        "夹的是帧 0..63 而不是棋盘区 10..62——反面证据是第 158 步 766c3c0a：5 级件落在 (行59,列51)，"
        "占到第 63 行（计价条那一行）世界没有夹它。全语料 254 次棋盘点击里按老公式会出界的只有这两次，"
        "所以『夹进帧』这一档总共只有一次正面观测（probe_edge.py 摊的）：它是个能被下一次贴边点击打死的猜测，不是实测规律。"
        "v14: 主张、assert_ 都没动，只把 apply 里那次 `capture_landing` 也带上 `shape`——"
        "追猎者贴右边界时它的落点同样要整块平移塞回帧（见 mover7_lands_when_target_unique 的 NOTE v2）。"
        "第 294 步押错的 (45,61)/(45,62) 就是这么来的：这两格是件腾出来的，本概念把「追猎者会占走的格」让开，"
        "而让开的位置比世界实际的位置偏了一列，于是两格被押成底色。"
        "v15: 主张、assert_ 都没动，只在 apply 里补一道闸。由来是第 305 步（终局卡）退出码 5："
        "点 (列13,行39) 把 5 级件从 (行36,列1) 搬到 (行37,列11)，色7 在 列17-21；"
        "本概念按 capture_landing 算它会落到 列15-19（贴着**点击后**那件的右边），于是把那几格让开、"
        "把件腾出的 (39,5) 押成底色。世界给的是 列5-9——贴着那件**点击前**的位置的右边，整整差 10 列。"
        "**这一档不是本概念该算的**：色7 到刚落下的新件只隔 2 格，不超过 REACH，"
        "正是 mover7_lands_when_target_unique 明说没有模型的「甩飞档」——它自己的 apply 在这一档整条返回 None，"
        "而本概念绕过那四道闸直接用了词汇里的原始公式 capture_landing，等于替一条已经声明闭嘴的概念开口。"
        "教训和 v7 是同一条、方向相反：生成器超额主张闸看不见，只有 --strict 看得见；"
        "而超额的来源这次是**从共用词取值时把上游的 scope 丢了**——词汇是假设，它的适用范围写在引用它的那条概念里，"
        "不在词本身。补的闸就照抄那一档：色7 离新件不超过 REACH 就整条不认领（外扩一圈圈不住，它能被扔到十几格外）。"
        "代价照记：件被搬到追猎者跟前的那一类步，本概念从此一格不押——而那正是本关每一步都要走的路。"
        "v16: 主张、assert_、apply 都没动，只把「夹进帧」那一档的观测数从 1 改成 2，并且**两次不在同一条边**。"
        "第 326 步（64e1c8251fbe7c13，终局卡）点 (列0,行45)：5 级件按老公式该落在左上 (行43,列-2)，"
        "那样它要占列 -2..2，而帧从第 0 列起；实测左上是 (行43,列0)，整件贴着**左**边界放下。"
        "v13 里那一次量的是右边的列，这一次量的是左边，夹的方向相反而公式同一条。"
        "它仍然只是两次正面观测、上下两条边一次都没量过（全语料按老公式会出界的就这三次），"
        "所以照旧是个能被下一次贴边点击打死的猜测——只是不再是孤证。"
        "v18: 上边那次贴边把 v16 最后一句兑现了——**打死的正是「四条边都夹帧」这个口径本身**。"
        "第 400 步（c142babf4705afd3，终局卡第 4 关）点 (列38,行10)：2 级件按公式左上该是 (行9,列37)，"
        "夹帧不动它（行 9 在帧内），实测左上是 (行10,列37)——行 9 属于顶带 0..9，件进不去。"
        "改的是词（_lib.placed 的上界从 0 抬到 TOP_BAND_LAST_ROW+1），主张和 assert_ 一个字没动。"
        "**另一种读法当场排掉**：同一条也能读成「偶数边长本来就取 top=y」，"
        "但 probe_400b.out 把没碰边界的边长 2 落点数了一遍，31 条全是 y 减 边长//2，0 条落在 top=y。"
        "四条边现在是三种口径：左右夹帧、上夹棋盘顶、下一次都没夹到过（只知道件压得上第 63 行）。"
        "不对称是照实记的，不是推的——顶带是 HUD，计价条不是。"
        "预先写明这次错了怎么办：下一次贴**下**边的落点若被推到第 62 行以上，"
        "那就是「下界=帧底」也错了，届时改的仍是 _lib.placed 的那一行，不是给本概念加闸。")
EVIDENCE = ["7622f4450dfeec33", "dcb76f47a4905987", "1ff1cb224b6f36f7", "fa48413ff92ed667", "8d0d32507f10520b",
            "6ad59a999900f476", "756c29bd656094f0", "2c04ec89f25ea959", "5aeaa143202f0697", "04fc031a768f3ce1",
            "55ccf297a8d2140c", "5b7118503c3f63e7", "720d4f9031bb562d", "1c3a9aa1bacfeea4", "a8573ce41bed5fd8",
            "f69577c44363eda4", "a8dbb391a055b5cf", "c54b78f52b0ef1fd", "868bde228addb7ee", "896e274a965f31be",
            "7728de94e67f5fc1", "766c3c0aee19eb7c", "8863f9bc138f39c5", "6e7faf1611f3ce37",
            "64e1c8251fbe7c13", "c142babf4705afd3"]

from geo import cells_of
from _lib import (click_xy, pieces, piece_cells, placed, in_reach, TOP_BAND_LAST_ROW, BUDGET_ROW,
                  COLOR_OF_TIER, BG, MOVER_COLOR, OCT_COLOR, capacity, octagons, will_level_up,
                  CREATURE_COLORS, creature_blocks, capture_landing, piece_gap, REACH)


def _cap(g):
    """棋盘上件的总容量。合成守恒，所以它掉了就一定是有件被毁/降级。"""
    return sum(capacity(t) for t, _, _ in pieces(g))


def _case(prev, action):
    xy = click_xy(action)
    if xy is None:
        return None
    x, y = xy
    if y <= TOP_BAND_LAST_ROW or y >= BUDGET_ROW:
        return None
    near = [p for p in pieces(prev) if in_reach(p, x, y)]
    if len(near) == 0:
        return (x, y, near, None)
    if len(near) == 1:
        return (x, y, near, placed(near[0][0], x, y, prev))
    if len(near) == 2 and near[0][0] == near[1][0] and near[0][0] + 1 in COLOR_OF_TIER:
        return (x, y, near, placed(near[0][0] + 1, x, y, prev))
    return None


def _expected(prev, x, y, near, new):
    """返回 (exp, skip)：exp = {cell: color} 新件的格子与旧件腾出的格子，skip = 说不出来的腾出格。
    腾出的格子填「那一格底下是什么」：在色9 八边形上就填色9（圈是静态背景），认不出原点的碎块附近不认领。"""
    out, skip = {}, set()
    if new is not None:
        for cell in piece_cells(new):
            out[cell] = COLOR_OF_TIER[new[0]]
    known, unsure = octagons(prev)
    for p in near:
        for cell in piece_cells(p):
            if cell in out:
                continue
            if cell in unsure:
                skip.add(cell)
                continue
            out[cell] = OCT_COLOR if cell in known else BG
    ok = lambda cell: TOP_BAND_LAST_ROW < cell[0] < BUDGET_ROW and 0 <= cell[1] < len(prev[0])
    return {cell: v for cell, v in out.items() if ok(cell)}, {cell for cell in skip if ok(cell)}


PIECE_COLORS = set(COLOR_OF_TIER.values())


def _foreign(v):
    """非底色、非件色 = 本概念不负责的东西（色9 圈、色3 引导点、色7 会动的物件）。"""
    return v != BG and v not in PIECE_COLORS


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    c = _case(prev, action)
    if c is None:
        return "NA"
    if _cap(nxt) < _cap(prev):
        return "NA"                     # 这一步有件被降级，它落在哪本概念说不出（NOTE v10）
    x, y, near, new = c
    if near and all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW):
        return "NA"                     # 世界整条驳回了这次点击，触发条件未知（NOTE v11）
    exp, skip = _expected(prev, x, y, near, new)
    # 色7 压到或挨着点击后的件 = 可能毁件，不归本概念管
    after = [p for p in pieces(prev) if p not in near] + ([new] if new else [])
    occupied = {cell for p in after for cell in piece_cells(p)}
    halo = {(r + dr, col + dc) for r, col in occupied for dr in (-1, 0, 1) for dc in (-1, 0, 1)}
    mover_nxt = {(r, col) for r, col in cells_of(nxt, MOVER_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW}
    if mover_nxt & halo:
        return "NA"
    for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW):
        for col in range(len(prev[0])):
            if (r, col) in skip:
                continue                    # 认不出原点的色9 碎块附近：腾出格底下是什么说不准
            want = exp.get((r, col), prev[r][col])
            got = nxt[r][col]
            if got == want:
                continue
            # 新件该占的格子严格核对；其余格子上有非件颜色就不归本概念管
            if want in PIECE_COLORS and exp.get((r, col)) == want:
                return "FALSE"
            if _foreign(prev[r][col]) or _foreign(got):
                continue
            return "FALSE"
    return "TRUE"


def _blocks(g):
    """场上每只完整的物件 (颜色, 格集)。有一只被盖掉一部分就返回 None：重心算不准，落点也就算不准。"""
    out = []
    for colour in CREATURE_COLORS:
        for b, full in creature_blocks(g, colour):
            if not full:
                return None
            out.append((colour, frozenset(b)))
    return out


def apply(prev, action, ctx=None):
    c = _case(prev, action)
    if c is None:
        return None
    if will_level_up(prev, action):
        return None                                      # 过关那一步整屏重画，件画在哪本概念说不出
    x, y, near, new = c
    exp, _skip = _expected(prev, x, y, near, new)
    # 腾出的格子可能被非件颜色占走。物件有落点模型（_lib.capture_landing）：它们将占的格子让给它们；
    # 其余非件颜色（第 0 关的引导点）位置事先不可知：在它们包围盒外扩 8 格的范围内不认领腾出格。
    after = [p for p in pieces(prev) if p not in near] + ([new] if new else [])
    crs = _blocks(prev)
    if crs is None:
        return None
    if crs and after:
        occupied = {cell for p in after for cell in piece_cells(p)}
        freshcells = set(piece_cells(new)) if new else set()
        oldcells = {cell for p in after if p != new for cell in piece_cells(p)}
        ps_prev = list(pieces(prev))
        lands = []
        for colour, b in crs:
            if b & freshcells:
                return None                              # 新件盖在物件原位上：那只被甩到哪没模型（第 155/190 步）
            if colour == MOVER_COLOR and new is not None and piece_gap(b, new) <= REACH:
                return None                              # 甩飞档：色7 离刚落下的新件不超过 REACH，落点没模型（NOTE v15）
            tgt, land = capture_landing(b, after, occupied, colour,
                                        ps_prev=ps_prev if colour == MOVER_COLOR else None,
                                        shape=(len(prev), len(prev[0])))
            if land is None:
                return None
            if land & oldcells:
                return None                              # 捕获了没被点的件：那件降级后落在哪没模型（NOTE v10）
            lands.append(frozenset(land))
        allland = set().union(*lands) if lands else set()
        # 件画在物件上面：新件的格子照常认领；被物件占走的腾出格不认领
        exp = {cell: v for cell, v in exp.items() if cell in freshcells or cell not in allland}
        if len([land for land in lands if land & freshcells]) >= 2:
            return None                              # 这一步要并：新物件生在哪说不出，件本身也未必保得住（第 147 步）
    foreign = [(r, col) for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW) for col in range(len(prev[0]))
               if prev[r][col] not in (9, MOVER_COLOR) and _foreign(prev[r][col])]
    if foreign:
        r0 = min(r for r, _ in foreign) - 8; r1 = max(r for r, _ in foreign) + 8
        c0 = min(c for _, c in foreign) - 8; c1 = max(c for _, c in foreign) + 8
        exp = {cell: v for cell, v in exp.items()
               if v != BG or not (r0 <= cell[0] <= r1 and c0 <= cell[1] <= c1)}
    return exp
