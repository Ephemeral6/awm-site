"""ACTION6 点到棋盘区（10<=y<63）且合成规则说得出结果、且世界没整条驳回这次点击时，第 63 行最右侧的 1 或 2 个色0 格不再是色0（没被件盖住就变色5）、其余没被盖住的格不变；点顶带或非点击动作第 63 行色0 的格数不变。"""
LEVEL = "L4"
SCOPE = ("所有动作；换关返回 NA；**色0 的格子全算数**（未用的预算画在件之上，见 NOTE v8），"
         "只有已用掉、又被件盖住的那几列不断言颜色；"
         "只说『扣 1 格或 2 格』，不说这一步扣几格——每关的扣费表还没找出来；"
         "REACH 内有两件不同级 / ≥3 件（after_click 返回 None）的点击返回 NA——见过一次扣 4 格、棋盘一格不动；"
         "**这一帧除第 63 行外一格不变、而册子算出来本该有件或有会动物件挪窝（世界整条驳回了这次点击）返回 NA**——"
         "见过同一次驳回扣 2 格、又扣 6 格（NOTE v7），也见过空地点击被驳回扣 14 格（NOTE v9）；"
         "**不问 REACH 里有没有件**——点到件不是驳回的必要条件；"
         "帧冻住而册子算不出该不该动，同样返回 NA")
NOTE = ("v1: 合并 action6_consumes_color0_bottom_right v8 与 budget_decrements_by_two v3——第 2 关一次点击只扣 1 格，扣几格随关变，用顶带样板数解释。"
        "v2: 「每关每次扣的格数固定」被 1240ba2a852364cd / de50d739e7c96539 推翻（第 2 关第 3、6 次点击扣 2 格）；改成条长按比例走：用掉 = floor(64*j/T)。"
        "v3: 「T 由顶带样板数定」被 1c3a9aa1bacfeea4 推翻——第 3 关只有 1 个样板却第一次点击只扣 1 格（T=32 要求扣 2）。"
        "退回只说得准的那半句：每次棋盘点击吃掉最右侧的 1 或 2 格色0。T 是什么定的还不知道，apply 只认领必中的那 1 格。"
        "v4: 死于 18759a98b7574fbc——REACH 内一件 2×2 一件 3×3，棋盘一格没动，第 63 行却扣了 4 格。"
        "『不合法的点击罚双倍』只有这一次，不敢写成主张，先划出去"
        "v5: 死于 2f8864ee29041099——追猎者压上第 5 关那块 7×7，它变成一块 5×5 的色12 落在棋盘右下角，"
        "有 5 格正压在第 63 行上（列59-63，原本是已用掉的色5）。预算条不是一条谁都碰不到的仪表盘，件能盖到它上面。"
        "被盖住的列本概念不再断言；预算到底还剩几格该怎么读（盖住的列算不算）还没见过区分性证据。"
        "v6: 主张与 assert_ 一个字没改，只让 apply 在**这一步要过关**时闭嘴。第 124 步意外 1 格：(63,41) 我押色5、"
        "实际还是色0——那一步过了关，预算条整条换成了新关的。assert_ 本来就在换关时返回 NA，"
        "可 apply 看不见换关（预测时 ctx 里 level_next = level_prev），于是照旧开口。"
        "补上 _lib.will_level_up（由 levelup_when_samples_in_octagon 走闸）：它说这一步会过关，apply 就不认领。"
        "v7: 死于 b6e4569d87727d29（第 166 步）——扣了 6 格。要紧的不是这个数，是它的来历："
        "第 165 步（896e274a965f31be）与第 166 步是**逐格相同的局面、逐字相同的动作** ACTION6:28,50，"
        "两次世界都整条驳回（除第 63 行外一格不变），可第一次扣 2 格、第二次扣 6 格。"
        "所以**驳回的代价不是局面的函数**——棋盘那一半是确定的（两次都一格不动），预算这一半不是。"
        "为查这个，probe_budget.py 把全部 169 次动作的扣费摊开：棋盘点击只出现过扣 1（35 次）与扣 2（99 次），"
        "扣 4 一次（18759a98b7574fbc，REACH 内两件不同级）、扣 6 一次（本条），"
        "两次都是棋盘一格不动的驳回步；ACTION7 与点顶带一律扣 0（18 次）；负数全是过关换新条。"
        "1 和 2 之间怎么定仍然不知道（v2/v3 两次都猜错了），现在又多一条不知道：驳回罚几格不知道，"
        "而且**同一次驳回重来一遍罚得不一样**，可能是累犯加罚，也可能是别的隐藏状态。"
        "本版只做诚实的缩 scope：REACH 内有件而整帧冻住时闭嘴，不发明罚则。"
        "**不缩『REACH 内没件的冻帧』**——那是早关点空地的正常点击（扣 1~2 格），它们是这条概念的主要证据。"
        "v8: 死于 61c0f5c05c2d2f95（第 172 步）——我读成『扣 0 格』，真相是**读法错了**，实扣 1 格。"
        "第 63 行的分段是 (色0, 列0-22) (色5, 列23-63)，而 5 级件占 行59-63列18-22："
        "prev 里列18-22 在第 63 行上显色0，next 里被吃掉的列22 显色12。"
        "也就是说**未用的预算格画在件之上，用掉的格才露出底下件的颜色**——v5 那次（色12 压在列59-63 上）"
        "看到的是被盖住的**已用**格，我却把结论推广成了『件盖住的列一律读不出来』，"
        "于是 _zeros 把列18-22 整段真·未用的预算从右端切掉，最右的未用格从列22 读成了列17，"
        "然后 apply 去认领列17、assert_ 在切过的列表上怎么配都配不出扣 1 或 2。"
        "连带后果：这一关的剩余预算一直被我少报 5 格（真值 23，我读 18）。"
        "本版把『排除盖住列』从**找最右未用格**这一步拿掉（色0 就是色0），只保留在**逐格比颜色**那一步："
        "被吃掉的格若正被件盖着，它变成件的颜色而不是色5，那一格的颜色归 pieces_merge_at_click 管。"
        "v9: 死于 2976b42a461cdd67（一次 REACH 内一件都没有的空地点击，扣了 14 格）。"
        "垮的是 scope 里那句『**REACH 内有件**、而这一帧除第 63 行外一格不变』——"
        "『点到件』根本不是整条驳回的必要条件。这一步场上两只会动物件、册子算出来它们各该走一步，"
        "帧却除第 63 行外一格没变。本版把驳回判据换成 _lib.world_refused：**帧冻住 + 册子说本该有东西挪窝**，"
        "不再问 REACH 里有没有件；算不出该不该动时也返回 NA。"
        "这样缩得比『所有冻帧一律闭嘴』窄：早关那些『场上根本没有会动的东西，点空地帧本来就该冻住』的点击"
        "（本概念的主要证据）仍然在 scope 内照判。"
        "顺带一条与本概念相邻的读数（罚则仍不写成主张）：驳回扣的格数在**同一关内单调往上爬**，"
        "一次重开回到最小值——本关第一轮 2,6,8,11,14，重开后 2,6,8,11,13，这一轮 3,5,8,10,14。"
        "所以 v7 说的『同一次驳回重来一遍罚得不一样』现在有了更具体的形状：它跟着本关已驳回次数走，"
        "但仍然不是 (prev, action) 的函数，本概念不认领。")
EVIDENCE = ["d721b9982492084b", "d216fa4736c23574", "9b50d95cf121f213", "c26e907db2e8d46d", "b9701d7da52ee051",
            "9e91564de215ec53", "8571ad9a47d3a9a1", "7622f4450dfeec33", "04fc031a768f3ce1",
            "363bfa92ce80ecff", "ba56431e8ebe843b", "ccebc3c4c4b0b628",
            "1240ba2a852364cd", "de50d739e7c96539", "1c3a9aa1bacfeea4", "18759a98b7574fbc", "2f8864ee29041099",
            "b6e4569d87727d29", "61c0f5c05c2d2f95", "2976b42a461cdd67"]

from _lib import (click_xy, after_click, pieces, piece_cells, in_reach, will_level_up,
                  world_refused,
                  TOP_BAND_LAST_ROW, BUDGET_ROW, BG)

MAX_COST = 2


def _covered(g):
    """第 63 行上被件盖住的列。注意：**只有已用掉的格才会被盖住**（未用的色0 画在件之上，NOTE v8），
    所以这个集合只用来决定「哪几列不比颜色」，不用来找最右的未用格。"""
    return {c for p in pieces(g) for r, c in piece_cells(p) if r == BUDGET_ROW}


def _zeros(row):
    return [c for c in range(len(row)) if row[c] == 0]


def _is_board_click(action):
    if action == "RESET":
        return None
    xy = click_xy(action)
    if xy is None:
        return False
    return TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    board = _is_board_click(action)
    if board is None:
        return "NA"
    skip = _covered(prev) | _covered(nxt)
    cols = [c for c in range(len(prev[BUDGET_ROW])) if c not in skip]
    z_p, z_n = _zeros(prev[BUDGET_ROW]), _zeros(nxt[BUDGET_ROW])
    if not board:
        return "TRUE" if z_p == z_n and all(nxt[BUDGET_ROW][c] == prev[BUDGET_ROW][c] for c in cols) else "FALSE"
    if after_click(prev, action) is None:
        return "NA"
    xy = click_xy(action)
    if world_refused(prev, action, nxt) is not False:
        return "NA"                     # 世界整条驳回了这次点击，罚几格不知道（NOTE v7/v9）
    k = len(z_p) - len(z_n)
    if not (1 <= k <= MAX_COST):
        return "FALSE"
    if z_n != z_p[:-k]:
        return "FALSE"                  # 被吃掉的不是最右侧那 k 格
    eaten = set(z_p[-k:])
    for c in cols:
        want = BG if c in eaten else prev[BUDGET_ROW][c]
        if nxt[BUDGET_ROW][c] != want:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    ps2 = after_click(prev, action) if _is_board_click(action) else None
    if ps2 is None:
        return None
    if will_level_up(prev, action):
        return None                     # 过关那一步整条预算条换新，本概念说不出
    zeros = _zeros(prev[BUDGET_ROW])
    if not zeros:
        return None
    c = zeros[-1]
    if any(cell == (BUDGET_ROW, c) for p in ps2 for cell in piece_cells(p)):
        return None                     # 吃掉之后露出的是件的颜色，那一格归 pieces_merge_at_click
    return {(BUDGET_ROW, c): BG}
