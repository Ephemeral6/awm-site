"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测到的：
    棋盘区 = 第 10..62 行（第 0..9 行是色4的顶带，第 63 行是预算条）。
    光标 = 棋盘区里 3×3 的色15 块；cursor(g) 返回它的中心 (row, col)。
    REACH = 一次点击能把光标搬走的最远欧氏距离（点击点到光标中心）。
      实测：Δ(6,6)=8.49、Δ(7,0)、Δ(9,0) 能跳；Δ(7,7)=9.9、Δ(10,1)=10.05 不能。取 9。
    dot_cells(g) = 棋盘区里色3 的单格（引导点）。

几何工具从 geo 拿（`from geo import components, diff_sum, fold, moved`），那里没有世界断言。
"""
from __future__ import annotations

from geo import cells_of, components  # noqa: F401

TOP_BAND_LAST_ROW = 9
BUDGET_ROW = 63
CURSOR_COLOR = 15
DOT_COLOR = 3
BG = 5
REACH = 8              # 点击点到件里最近一格的欧氏距离上限（见 in_reach 的实测）

CELL = 3               # 光标边长
PHASE = None
DELTA = {}


def click_xy(action):
    """ACTION6:x,y -> (x, y)，x=列 y=行；解析不出来返回 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        a, b = action.split(":", 1)[1].split(",")
        return int(a), int(b)
    except ValueError:
        return None


def cursor(g):
    """棋盘区里 3×3 色15 块的中心 (row, col)；找不到恰好一块 9 格的返回 None。"""
    cs = [(r, c) for r, c in cells_of(g, CURSOR_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    blocks = [b for b in components(cs) if len(b) == 9]
    if len(blocks) != 1:
        return None
    b = blocks[0]
    r0 = min(r for r, c in b)
    c0 = min(c for r, c in b)
    if all((r0 + dr, c0 + dc) in set(b) for dr in range(3) for dc in range(3)):
        return (r0 + 1, c0 + 1)
    return None


def dot_cells(g):
    """棋盘区里色3 的单格集合（引导点）。"""
    cs = [(r, c) for r, c in cells_of(g, DOT_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    return frozenset(x for b in components(cs) if len(b) == 1 for x in b)


def budget(g):
    """预算 = 第 63 行色0 格数。"""
    return sum(1 for c in range(len(g[BUDGET_ROW])) if g[BUDGET_ROW][c] == 0)


# 顶带左上角一排 2×2 调色板（行1-2）占的列。第 0-4 关只有 4 格调色板（列 1..14），第 5 关多出色12、色8
# 两格，排到列 22；样板从来都画在行 3-6、列 >=30（probe_legend 清点过全部 115 帧），所以边界放到 23 两头都不碰。
LEGEND_LAST_COL = 23


def samples(g):
    """顶带（行 0..9、列 >15）里件色的连通块 = 本关要交付的样板：[(tier, top_row, left_col)]。"""
    out = []
    for color, s in TIER_OF_COLOR.items():
        cs = [(r, c) for r, c in cells_of(g, color) if r <= TOP_BAND_LAST_ROW and c > LEGEND_LAST_COL]
        for b in components(cs):
            r0 = min(r for r, c in b); c0 = min(c for r, c in b)
            out.append((s, r0, c0))
    return out


# 每次棋盘点击吃掉第 63 行最右侧的 1 或 2 格色0。到底扣几格随关变：
#   第 0、1 关每次 2（共 32 次点击），第 2 关 1,1,2,1,1,2…（共 48 次），第 3 关第一次只扣 1。
# 「T 由顶带样板数定」已被 1c3a9aa1bacfeea4 推翻（第 3 关 1 个样板却扣 1），所以这里不再留查表。
MAX_STEP_COST = 2


# 件的级：颜色 -> 级。顶带调色板从左到右（列 1,5,9,13,17,21）的顺序就是级：色10=1、色6=2、色15=3、色11=4、色12=5、色8=6。
# **级不等于边长**：边长量出来是 1,2,3,4,5,7——6 级的边长是 7，跳过了 6。
#   色8 的 7×7：第 114/115 步两次按 placed 搬家（左上=(y-3,x-3)）量到。
#   色12 的 5×5：第 121 步追猎者压上那块 7×7，它变成一块 5×5 的色12（行59-63 列59-63，有 5 格压在预算行上）。
# 合成是两件同级并成高一级，capacity=2^(级-1) 沿合成守恒；按这张表，色8 是 32、色12 是 16、色11 是 8。
TIER_OF_COLOR = {10: 1, 6: 2, 15: 3, 11: 4, 12: 5, 8: 6}
COLOR_OF_TIER = {v: k for k, v in TIER_OF_COLOR.items()}
SIDE_OF_TIER = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 7}


def side(tier):
    """一件 tier 级的件的边长。表外的级返回 None（没见过的级不许瞎猜边长）。"""
    return SIDE_OF_TIER.get(tier)


def pieces(g):
    """棋盘区的件：[(tier, top_row, left_col)]。件 = 边长等于其级对应边长的正方形连通块；形状不对的块不算件。
    扫到第 63 行（含）：件会落到预算条上——第 121 步那块 5×5 就有 5 格压在预算行里。

    **缺角的补全**：预算条（第 63 行的色0）画在件**上面**——第 157 步那块降下来的 5 级件落在行59-63 列41-45，
    行63 的 5 格被预算条盖成色0，块上只剩 20 格，于是它整个读不出来（两条概念同时判 FALSE）。
    补法照八边形那条：枚举所有装得下这块碎片的左上角，模板里**既不是件色、又没被预算条盖着**的格子
    出现一个就否掉这个候选；只剩一个候选才算认出来。只认预算条这一种遮挡——别的遮挡一次都没量到，
    件是画在追猎者/菱形上面的（第 146 步那只菱形整块藏在件底下）。"""
    out = []
    covered = {(BUDGET_ROW, c) for c in range(len(g[BUDGET_ROW])) if g[BUDGET_ROW][c] == 0}
    ncol = len(g[0])
    for color, t in TIER_OF_COLOR.items():
        s = SIDE_OF_TIER[t]
        cs = [(r, c) for r, c in cells_of(g, color) if TOP_BAND_LAST_ROW < r <= BUDGET_ROW]
        for b in components(cs):
            b = set(b)
            if len(b) > s * s:
                continue
            rs = [r for r, _ in b]; cls = [c for _, c in b]
            cands = []
            for r0 in range(max(rs) - s + 1, min(rs) + 1):
                for c0 in range(max(cls) - s + 1, min(cls) + 1):
                    if not (TOP_BAND_LAST_ROW < r0 and r0 + s - 1 <= BUDGET_ROW):
                        continue
                    if not (0 <= c0 and c0 + s - 1 < ncol):
                        continue
                    tmpl = {(r0 + dr, c0 + dc) for dr in range(s) for dc in range(s)}
                    if not b <= tmpl:
                        continue
                    if any(cell not in b and cell not in covered for cell in tmpl):
                        continue
                    cands.append((t, r0, c0))
            if len(cands) == 1 and cands[0] not in out:
                out.append(cands[0])
    return out


def piece_center(p):
    t, r0, c0 = p
    s = SIDE_OF_TIER[t]
    return (r0 + (s - 1) / 2, c0 + (s - 1) / 2)


def piece_cells(p):
    t, r0, c0 = p
    s = SIDE_OF_TIER[t]
    return {(r0 + dr, c0 + dc) for dr in range(s) for dc in range(s)}


def placed(tier, x, y, g=None):
    """点击 (x,y) 处放一件 tier 级的件：左上 = (y - 边长//2, x - 边长//2)，**再夹进帧的四边**。
    边长 1/2/3/4 实测如此，7（色8）由第 114/115 步证实。

    夹边这一档的观测（左右/下/上各自算各自的，别互相推）：
    - 右：第 289 步点 (列63,行28)，3 级件按公式该占列 62/63/64，而帧只有 0..63 列，
      实测左上是 (行27,列61)——整件贴着帧的右边界放下。
    - 下：一次都没夹到过（全语料没有一条公式算出来会掉出帧底的落点）。只有一条旁证：
      第 158 步 5 级件落在 (行59,列51)，占到第 63 行（计价条那一行）而世界没有把它往上推，
      所以下界至少到第 63 行，不是棋盘区的 62。「夹到 len(g)-s」这一档仍是没量过的猜测。
    - 上：第 400 步点 (列38,行10)，2 级件按公式左上该是 (行9,列37)，行 9 在顶带里，
      实测是 (行10,列37)——上边夹的是**棋盘顶** TOP_BAND_LAST_ROW+1，不是帧顶 0。
      只有这一次观测。同一条也能读成「偶数边长本来就取 top=y」，但 probe_400b.out 把没碰边界的
      边长 2 落点数了一遍：31 条全是 y 减 边长//2，0 条落在 top=y——那种读法当场排掉。
    上下不对称是照实记的读数，不是推出来的：顶带 0..9 是 HUD，件进不去；第 63 行是计价条，件压得上去。
    传 g 才夹（算得出帧多大）；不传就是老公式。"""
    s = SIDE_OF_TIER[tier]
    top, left = y - s // 2, x - s // 2
    if g is not None:
        top = min(max(top, TOP_BAND_LAST_ROW + 1), len(g) - s)
        left = min(max(left, 0), len(g[0]) - s)
    return (tier, top, left)


def in_reach(p, x, y):
    """点击点到件里最近一格的欧氏距离 <= REACH。
    实测：3×3 中心 Δ(9,0)（最近格 8）能、Δ(7,7)（最近格 8.49）不能；
    单点 7.8 能、8.06 不能 → 从最近格量、阈值 8。"""
    return min((y - r) ** 2 + (x - c) ** 2 for r, c in piece_cells(p)) <= REACH * REACH


def capacity(tier):
    """一件 tier 级的件折合多少个 1×1：合成是两件同级并成高一级，所以 2^(tier-1) 沿合成守恒。
    假设，不是事实——它被 level_dead_when_capacity_short 拿去和帧上的色2 判死对。"""
    return 1 << (tier - 1)


def after_click(g, action):
    """按合成规则算这次点击之后的件清单；说不出（REACH 内 >=3 件或两件不同级）返回 None。
    不是点棋盘（含解析不出、点顶带）返回 g 上原本的件清单。"""
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return pieces(g)
    x, y = xy
    ps = pieces(g)
    near = [p for p in ps if in_reach(p, x, y)]
    rest = [p for p in ps if p not in near]
    if len(near) == 0:
        return ps
    if len(near) == 1:
        return rest + [placed(near[0][0], x, y, g)]
    if len(near) == 2 and near[0][0] == near[1][0] and near[0][0] + 1 in COLOR_OF_TIER:
        return rest + [placed(near[0][0] + 1, x, y, g)]
    return None


def me(g):
    """玩家 = 光标；返回 (top_row, left_col)。"""
    c = cursor(g)
    return None if c is None else (c[0] - 1, c[1] - 1)


def walls(g):
    return None


# 色9 八边形：本局 6 关一共 8 个圈，每个都是 9×9 包围盒里的正八边形（四角各切 3 格 = 69 格），
# probe_octagon 把全部 121 帧清点过一遍，没盖住时一格不差。它是**静态背景**：件和追猎者从它上面走开，
# 露出来的是色9 而不是底色（第 119 步 5 格、第 122 步 2 格意外都是这么来的）。
OCT_COLOR = 9
OCT_N = 9
OCT_CUT = {(0, 0), (0, 1), (1, 0)}


def _oct_template(r0, c0, n=OCT_N):
    out = set()
    for dr in range(n):
        for dc in range(n):
            mr = min(dr, n - 1 - dr); mc = min(dc, n - 1 - dc)
            if (mr, mc) in OCT_CUT or (mc, mr) in OCT_CUT:
                continue
            out.add((r0 + dr, c0 + dc))
    return out


def octagons(g):
    """返回 (known, unsure)：known = 认得出原点的圈的全部格子的并集，unsure 见 oct_regions。"""
    known, unsure = _octagons(g)
    out = set()
    for t in known:
        out |= t
    return out, unsure


def oct_regions(g):
    """一个个圈：认得出原点的那些，各自的 69 格模板（模板是实心的：9×9 去掉四角各 3 格）。"""
    return _octagons(g)[0]


def _octagons(g):
    """返回 (known_list, unsure)：
    known_list = 每个认得出原点的圈的全部格子（含此刻被件/追猎者盖住的那些）；
    unsure = 认不出原点的色9 碎块可能所在的一片（碎块 ±8），那底下是什么说不准，概念该在那儿闭嘴。

    认原点分两步：包围盒正好 9×9 的连通块直接读原点；被盖掉一块的碎块靠「露不出来的格子必须正被别的东西盖着」
    反推——枚举所有装得下这块碎片的原点，模板里既不是色9、又没被非底色东西盖住的格子一出现就否掉这个原点；
    只剩一个原点才算认出来。"""
    cells = [(r, c) for r, c in cells_of(g, OCT_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    nine = set(cells)
    occupied = {(r, c) for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW) for c in range(len(g[0]))
                if g[r][c] not in (BG, OCT_COLOR)}
    known, rest = [], []
    seen = set()
    for b in components(cells, diag=True):
        rs = [r for r, _ in b]; cs = [c for _, c in b]
        if max(rs) - min(rs) == OCT_N - 1 and max(cs) - min(cs) == OCT_N - 1:
            t = _oct_template(min(rs), min(cs))
            if set(b) <= t:
                known.append(t); seen |= t
                continue
        rest.append(b)
    unsure = set()
    for b in rest:
        if set(b) <= seen:
            continue
        rs = [r for r, _ in b]; cs = [c for _, c in b]
        cands = []
        for r0 in range(max(rs) - OCT_N + 1, min(rs) + 1):
            for c0 in range(max(cs) - OCT_N + 1, min(cs) + 1):
                if not (TOP_BAND_LAST_ROW < r0 and r0 + OCT_N - 1 < BUDGET_ROW):
                    continue
                if not (0 <= c0 and c0 + OCT_N - 1 < len(g[0])):
                    continue
                t = _oct_template(r0, c0)
                if not set(b) <= t:
                    continue
                if any(cell not in nine and cell not in occupied for cell in t):
                    continue
                cands.append(t)
        if len(cands) == 1:
            known.append(cands[0]); seen |= cands[0]
            continue
        unsure |= {(r, c) for r in range(min(rs) - OCT_N + 1, max(rs) + OCT_N)
                   for c in range(min(cs) - OCT_N + 1, max(cs) + OCT_N)}
    return known, unsure - seen


# 顶带图例第二行（行6-7、列1-2/5-6/9-10）是三种**非件**的东西：色7 追猎者、色14 菱形、色13。
# 它们也会被画进样板条当交付要求：第 7 关要一个色14，第 8 关要一个 13 格的色13（行3-6 列43-47）。
# 色14 菱形：8 格空心菱形，第 7 关冒出来的第二种会动的东西（两个色7 撞上免疫件并成一只）。
DIAMOND_COLOR = 14
DIAMOND_CELLS = 8
CREATURE_COLORS = (7, 13, 14)


def creature_samples(g):
    """顶带样板条（行 0..9、列 > LEGEND_LAST_COL）里的非件色物件：{颜色: 块数}。"""
    out = {}
    for colour in CREATURE_COLORS:
        cs = [(r, c) for r, c in cells_of(g, colour) if r <= TOP_BAND_LAST_ROW and c > LEGEND_LAST_COL]
        n = len(components(cs, diag=True))
        if n:
            out[colour] = n
    return out


def creatures(g, colour):
    """棋盘区某个非件色的物件（8-邻接分块），缺角的按形状补全，见 creature_blocks。"""
    return [cells for cells, _ in creature_blocks(g, colour)]


# 色7 追猎者与色14 菱形**不是**同一个形状，各 8 格、都在 4×5 盒里：
#     色7  ..H..        色14  ..D..
#          .H.H.              .D.D.
#          H...H              D.D.D
#          .HHH.              .D.D.
# 色14 的形状是从第 166 步之后的帧上那只完整菱形（行37-40 列19-23）逐格量出来的（probe_shape.py）。
# 在那之前册子写「两色同一个形状」，依据是第 157 步那只刚出生的菱形「露出 5 格与追猎者逐格对得上」——
# 可那 5 格 ((0,2)(1,1)(1,3)(2,0)(2,4)) 恰好是两种形状**完全相同**的那 5 格，被 3×3 件盖掉的 3 格才是区别所在。
# 教训：拿共有部分去确认形状等于没确认；补全的那几格必须自己被另一帧看见过。
# 色13 是 13 格（顶带样板行3-6 列43-47），形状没量过，不补全。
HUNTER_SHAPE = ((0, 2), (1, 1), (1, 3), (2, 0), (2, 4), (3, 1), (3, 2), (3, 3))
DIAMOND_SHAPE = ((0, 2), (1, 1), (1, 3), (2, 0), (2, 2), (2, 4), (3, 1), (3, 3))
CREATURE_SHAPE = HUNTER_SHAPE
CREATURE_BOX = (4, 5)
SHAPE_OF_CREATURE = {7: HUNTER_SHAPE, DIAMOND_COLOR: DIAMOND_SHAPE}
SHAPED_CREATURES = tuple(SHAPE_OF_CREATURE)


def _overlay_cells(g):
    """画在会动物件**上面**的东西：件色的格 + 第 63 行的预算条色0 格。
    件盖会动物件是量到的（第 146 步整只菱形藏在 7×7 底下、第 111 步藏了 5 格、第 157 步藏了 3 格）；
    色9 八边形反过来是背景，会动物件走上去盖住它（见 level_dead_when_capacity_short v3）。"""
    out = set()
    ncol = len(g[0])
    for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW + 1):
        for c in range(ncol):
            v = g[r][c]
            if v in TIER_OF_COLOR or (r == BUDGET_ROW and v == 0):
                out.add((r, c))
    return out


def _fit_creatures(cells, over, shape, ncol):
    """用**尽量少**的 8 格模板盖住这一色的全部可见格：模板里没露出来的格必须正被遮挡物盖着。
    最小解唯一才返回模板清单，否则返回 None（读不准）。

    为什么要联合着摆而不是一块一块摆：一件压在物件中间会把它切成好几个互不相邻的碎块
    （第 168 步那只菱形被 3×3 盖掉 5 格，帧上只剩三个单格），一块一块摆谁也摆不出整只；
    反过来两只挨在一起会黏成一块，也得联合着才切得开。"""
    cells = frozenset(cells)
    nrow, ncolbox = CREATURE_BOX
    cands = []
    seen = set()
    for r, c in cells:
        for dr, dc in shape:
            r0, c0 = r - dr, c - dc
            if (r0, c0) in seen:
                continue
            seen.add((r0, c0))
            if not (TOP_BAND_LAST_ROW < r0 and r0 + nrow - 1 <= BUDGET_ROW):
                continue
            if not (0 <= c0 and c0 + ncolbox - 1 < ncol):
                continue
            t = frozenset((r0 + a, c0 + b) for a, b in shape)
            if all(x in cells or x in over for x in t):
                cands.append(t)
    best = []
    bestn = [None]

    def rec(rest, chosen):
        if bestn[0] is not None and len(chosen) >= bestn[0] and rest:
            return                                   # 再加一块就超过已知最小解
        if not rest:
            if bestn[0] is None or len(chosen) < bestn[0]:
                bestn[0] = len(chosen)
                best[:] = [list(chosen)]
            elif len(chosen) == bestn[0]:
                best.append(list(chosen))
            return
        cell = min(rest)
        for t in cands:
            if cell in t:
                rec(rest - t, chosen + [t])

    rec(cells, [])
    if bestn[0] is None:
        return None
    if len({frozenset(s) for s in best}) != 1:
        return None                                  # 摆法不唯一
    return best[0]


def creature_blocks(g, colour):
    """[(格子集, exact)]：棋盘区这一色的物件，缺角的照「露不出来的格必须正被盖着」补全。
    exact=True 表示这一块确实就是那 8 格形状（本来就完整，或补法唯一）；
    exact=False 表示读不准（形状不认识、摆法不唯一、或这一色没有形状模型），
    此时返回的是原样的可见块——个数还数得出，重心和落点就别信了。

    先看每个 8-邻接块是不是本来就是完整的一只；剩下的（缺角的、被切碎的、黏在一起的）
    交给 _fit_creatures 联合摆。"""
    cs = [(r, c) for r, c in cells_of(g, colour) if TOP_BAND_LAST_ROW < r <= BUDGET_ROW]
    blocks = [frozenset(b) for b in components(cs, diag=True)]
    if colour not in SHAPE_OF_CREATURE:
        return [(b, False) for b in blocks]
    shape = SHAPE_OF_CREATURE[colour]
    out, rest = [], []
    for b in blocks:
        r0, c0 = min(r for r, _ in b), min(c for _, c in b)
        if len(b) == len(shape) and b == frozenset((r0 + dr, c0 + dc) for dr, dc in shape):
            out.append((b, True))
        else:
            rest.append(b)
    if rest:
        cells = frozenset().union(*rest)
        sol = _fit_creatures(cells, _overlay_cells(g), shape, len(g[0]))
        if sol is None:
            out += [(b, False) for b in rest]
        else:
            out += [(t, True) for t in sol]
    return out


MOVER_LADDER = {7: 14, 14: 13}   # 图例第二行从左到右的顺序；两只并成一只，颜色升一级


def merging_movers(g, action, colour):
    """这一步落点压在**这一 click 刚搬过/刚合出的件**上的 colour 物件（假设，由 movers_merge_on_immune_piece 走闸）。
    返回它们走之前的格子集合的清单。算不出来（不是棋盘点击、合成规则说不出结果、没有新鲜的件）返回 []。
    落点用 capture_landing 而不是 _one_mover_next：后者只走到接触前一格，压没压上要含接触那一格才看得见。
    目标按 mover_target 的**认身份**读法挑（色7 传 ps_prev；色14 没有这批证据，照旧不传）——
    第 201 步（1f24d971da7043ac）之前这里漏传 ps_prev，于是一只本该追新件的色7 被算成追 5 级件，
    这一色挑出 1 只（不够两只不并），而帧上色7 由 4 只变 2 只，概念判 FALSE。"""
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return []
    ps = after_click(g, action)
    if not ps:
        return []
    ps_prev = pieces(g)
    fresh = [p for p in ps if p not in ps_prev]
    if not fresh:
        return []
    occupied = {cell for p in ps for cell in piece_cells(p)}
    out = []
    for obj in creatures(g, colour):
        tgt, land = capture_landing(obj, ps, occupied, colour,
                                    ps_prev=ps_prev if colour == MOVER_COLOR else None)
        if tgt in fresh and (land & piece_cells(tgt)):
            out.append(obj)
    return out


def colliding_hunters(g, action, colour=None):
    """这一步落点**压到同色另一只**（压它的原位或它的落点）的 colour 物件（默认色7，MOVER_COLOR 定义在后面），
    返回它们走之前的格子集合的清单。
    不含砧板并（那是 merging_movers 的事，走的是 movers_merge_on_immune_piece 那道闸）。

    这是一档「说不出」，不是一条规则。全语料非砧板的撞一共 7 条（probe_575seven.out）：
    两只追同一件**非新件**而落点相撞的 4 条里，3 条（第 498/504/574 步）两只并成一只色14、谁也没咬；
    第 465 步却是一只咬了件、没并。两只都追新件的 3 条（第 300/410/573 步）既没并也没咬。
    3/4 不是规则，所以这里不替世界说「并」，只把这一档标出来让依赖落点的读法闭嘴：
    captured_pieces 跳过撞了的那只，capture_results 遇上撞了的捕获者返回 None。"""
    if colour is None:
        colour = MOVER_COLOR
    key = (tuple(tuple(r) for r in g), action, colour)     # 纯函数，规划器一个节点会问它几十次
    hit = _COLLIDE_MEMO.get(key)
    if hit is not None:
        return list(hit)
    out = _colliding_hunters(g, action, colour)
    if len(_COLLIDE_MEMO) > 4096:
        _COLLIDE_MEMO.clear()
    _COLLIDE_MEMO[key] = tuple(out)
    return out


_COLLIDE_MEMO = {}


def _colliding_hunters(g, action, colour):
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return []
    ps = after_click(g, action)
    if not ps:
        return []
    ps_prev = pieces(g)
    fresh = [p for p in ps if p not in ps_prev]
    occupied = {cell for p in ps for cell in piece_cells(p)}
    anvil = [frozenset(x) for x in merging_movers(g, action, colour)]
    lands = []
    for obj in creatures(g, colour):
        h = frozenset(obj)
        if h in anvil:
            continue
        _t, land = capture_landing(obj, ps, occupied, colour,
                                   ps_prev=ps_prev if colour == MOVER_COLOR else None,
                                   fresh=fresh, shape=(len(g), len(g[0])))
        lands.append((h, land))
    out = []
    for i, (h1, l1) in enumerate(lands):
        for j, (h2, l2) in enumerate(lands):
            if i != j and (l1 & h2 or l1 & l2 or l2 & h1):
                out.append(h1)
                break
    return out


# 「砧板并」生出来的新物件落在哪：没有精确公式，但**有界**（probe_birth_offset.py）。
# 全语料 8 条能认出新块的砧板并里，新块**重心**与砧板件心的差是
#   行 -0.25 / -1.25 / -1.25 / -1.25 / +0.75 / -0.25 / -0.25（第 111/157/163/185/192/201/212 步）
#   列  0.00 /  0.00 /  0.00 /  -1.00 /  -1.00 /  0.00 / +1.00
# 第 8 条（第 211 步）差 (-6.25, +19.00)——那一次并根本不在砧板上，merging_movers 一只也挑不出来，
# 已由 merged_creature_born_on_anvil 的 SCOPE 划出去（NOTE v2）。
# 比左上角没有用：菱形是 4×5、件是 SIDE×SIDE，两者的左上角本来就不对等，
# 按左上角量出来的偏移谱是 8 条全散（probe_birth_offset 第一版），换成重心才收得住。
# 这两个界是**观测到的最大偏移**，不是推出来的——多一条更偏的观测就该打死它，那正是它该干的事。
# 第 761 步 ACTION6:30,41（tid ed3fd7736b42cfc0）就是那条更偏的观测：砧板是 5 级件、件心 (41.0, 30.0)，
# 新块落在 行41-44列27-31、重心 (42.75, 29.00)，差 **行 +1.75 / 列 -1.00**——列在界内，行出界 0.5。
# 照 merged_creature_born_on_anvil 的 NOTE v4 预先写好的那条退路办：**把盒子放大，别去编公式**。
# 行的界因此由 1.25 放到 1.75（列不动，-1.00 本来就在界内）。放大之后摆法由 9 种变 12 种。
# 观测到的行偏移至此是 -1.25 / -0.25 / +0.75 / +1.75 四档，恰好等距 1.0——那只是整数平移的必然，
# 不是新规律；只有一条正向观测，编不出「随件级数变」这类公式，也不该编。
BORN_DROW = 1.75
BORN_DCOL = 1.0


def sample_shape(g, colour):
    """顶带样板条（列 > LEGEND_LAST_COL）里该色最大的一块，归一化成 frozenset{(dr,dc)}；读不出返回 None。

    为什么从样板条读而不用 SHAPE_OF_CREATURE：色13 的形状一次都没在棋盘上看全过
    （它生下来就压在件底下），而样板条上画着它的 13 格。样板条上的形状与棋盘上量出来的对得上，
    这一点在两种颜色上核过（probe_born_box.py）：色7 的样板块（12 帧）与色14 的样板块（21 帧）
    都和 SHAPE_OF_CREATURE 逐格相同，各自只出现过一种形状。色13 的样板块 13 格、63 帧里一种形状。"""
    cs = [(r, c) for r, c in cells_of(g, colour)
          if r <= TOP_BAND_LAST_ROW and c > LEGEND_LAST_COL]
    blocks = components(cs, diag=True)
    if not blocks:
        return None
    b = max(blocks, key=len)
    r0 = min(r for r, _ in b)
    c0 = min(c for _, c in b)
    return frozenset((r - r0, c - c0) for r, c in b)


def born_placements(shape, anvil):
    """砧板并生出的新物件的**所有说得通的落点**（假设，由 merged_creature_born_on_anvil 走闸）：
    把 shape 平移到重心与砧板件心之差落进 (±BORN_DROW, ±BORN_DCOL) 的盒子里，枚举所有整数平移。
    返回 [frozenset{(r,c)}]；shape 为空返回 []。

    它**不说**新物件究竟落在哪一处——语料只够把落点框进这个盒子。要用它判「新物件在不在圈里」，
    就得所有落点一致（全在 / 全不在），否则这一帧说不出来。"""
    if not shape:
        return []
    tr, tc = piece_center(anvil)
    sr = sum(r for r, _ in shape) / len(shape)
    sc = sum(c for _, c in shape) / len(shape)
    out = []
    for dr in range(int(-BORN_DROW - sr + tr) - 1, int(BORN_DROW - sr + tr) + 2):
        for dc in range(int(-BORN_DCOL - sc + tc) - 1, int(BORN_DCOL - sc + tc) + 2):
            if abs(sr + dr - tr) <= BORN_DROW and abs(sc + dc - tc) <= BORN_DCOL:
                out.append(frozenset((r + dr, c + dc) for r, c in shape))
    return out


def diamond_samples(g):
    return [None] * creature_samples(g).get(DIAMOND_COLOR, 0)



def diamonds(g):
    return creatures(g, DIAMOND_COLOR)


def diamond_next(g, ps):
    """色14 各块这一步之后的格子（假设：与色7 同一条追猎规律，由 mover14_hunts_like_mover7 走闸）。
    ps 为空返回 None（没目标时怎么走没见过）。"""
    if not ps:
        return None
    occupied = {cell for p in ps for cell in piece_cells(p)}
    return [_one_mover_next(d, ps, occupied, DIAMOND_COLOR) for d in diamonds(g)]


def covers(have, want):
    """have 的级能不能一一配上 want 的每个级（同级各用一件）。"""
    pool = list(have)
    for t in want:
        if t not in pool:
            return False
        pool.remove(t)
    return True


def piece_in_ring(p, reg):
    """件 p 算不算「进了圈 reg」：**它的每一格都落在圈的 9×9 外接方框里**（假设，由
    levelup_when_samples_in_octagon 走闸）。

    v2。原先写的是「每一格都落在圈的 69 格模板里」，被 ecfc2add99ddd2eb（第 256 步）打脸：
    一块 3 级件落在 46~48 行、20~22 列，九格里只有 (46,20) 这一个**角格**露在模板外
    （圈是 9×9 去掉四角各 3 格，那格正是被去掉的角之一，帧上是底色），世界照样关2→3。

    读法不是凭那一条挑的。probe_inring.py 把六种候选放到全语料 253 条转移上各打了一遍分
    （说中/误报/漏报/闭嘴），现行读法 210/0/1/42，另外五种**全部**是 211/0/0/42——一条也分不开。
    probe_inring2.py 再量它们的差集：2412 组（帧,件,圈）里只有 24 组意见不同，
    而那 24 组一次都没参与过过关判定，所以「打平」不是证据，是语料根本没检验过这个差别。
    这里挑**最紧**的那条（外接框），理由有二，都写明代价：
      · 最紧 = 主张最多 = 最好打。另外几条（沾到一格 / 过半 / 中心格在圈里）会把大半露在圈外的件
        也算进圈——语料里真有这样的 24 组，肉眼看它们不在圈里；分数一样，但那分数不是从这件事上挣的。
      · 「最多一格露在圈外」对 1×1 的件恒真（全语料 468 组），是条坏读法，直接划掉。
    机制上说得过去：圈画出来是 9×9 的一块，四角各去掉 3 格只是画法（OCT_CUT），
    件占的是那一格**槽位**，不是那 69 个色格。

    **预先写明这次换错了会怎样**：下一条反例若是「件整块在外接框里、世界却没过关」，
    说明外接框也太松，那时候该往回收（比如「露在模板外的格子只许是被去掉的角」），不是接着放。
    会动物件那一边**没有动**——它们仍按 `set(land) <= reg` 算（模板，不是外接框）：
    那一边一条反例都没有，不跟着改。"""
    rs = [r for r, _ in reg]
    cs = [c for _, c in reg]
    r0, r1 = min(rs), max(rs)
    c0, c1 = min(cs), max(cs)
    return all(r0 <= r <= r1 and c0 <= c <= c1 for r, c in piece_cells(p))


def will_level_up(g, action):
    """这一步点下去会不会过关（假设，由 levelup_when_samples_in_octagon 走闸）：
    按合成规则算出的件里，**进了圈**（piece_in_ring：每一格都在圈的 9×9 外接框里）的那些，
    级的多重集覆盖顶带样板的级的多重集；
    **样板条里还画着几个非件物件（色7/色13/色14），就得有同样多的同色物件在走完这一步之后整块落在圈里**。
    不是棋盘点击、合成规则说不出结果、没有圈或没有件样板，一律返回 None（说不出来）。
    **这一步有追猎者捕到件时，用甩开之后的件清单算**：过关判定不在追猎者走之前（ea35b8c4036c3abd），
    落点由 capture_fling 给（captured_piece_flung_ten）；落点说不出（capture_results 返回 None）才返回 None。
    会动物件怎么走仍按降级**前**的件清单算——capture_landing 自己就是这么算的。

    「走完这一步这一色有几只在圈里」这样数（v7）：
      · 场上老的那些，按 capture_landing 的落点算，落点整块在某个圈里就算一只；
        **这一色没有走法模型（不在 SHAPE_OF_CREATURE 里，比如色13）返回 None**——它走完落在哪一次都没见过；
      · 这一步被并掉的那两只不算（它们变成了高一级的一只）；
      · **这一步砧板并生出来的那一只算进来**，位置按 born_placements 的 9 种摆法：
        9 种全在圈里就算一只，全不在就算零只，**有的在有的不在返回 None**（merged_creature_born_on_anvil v4
        只把落点框进一个盒子，框不到一个格）。并了却挑不出恰好一件新鲜件，也返回 None。
      数完比样板少就返回 False（交不出不存在的东西）。
    **走完这一步有会动物件整块落在件底下**，只拦 False 那一侧（v9，原先是整个返回 None）：
    帧上只认颜色格，被件盖住的那只数不进来——但这只会让你把场上的只数**数少**，不会让你数多，
    所以它威胁的只有「圈里的这种物件比样板少」那条 return False，威胁不到 True 那一侧
    （落点整块在圈模板里是 capture_landing 算出来的，一格都不从帧上数）。
    69db8a3038bbbe5e 走的正是 False 那一侧，照旧接得住（见 levelup_when_samples_in_octagon 的 NOTE v6/v9）。
    这条闸**不管被并掉的那两只**（它们走完就不存在了，藏不藏无所谓），
    也**不管新生的那一只**（它的位置来自 born_placements 而不是帧）——代价见 NOTE v7。

    **v10：「盯的是新鲜件」不再一律闭嘴，扑那一档说话。** 见下面那段注释。"""
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return None
    ps = after_click(g, action)
    regs = oct_regions(g)
    want = [t for t, _, _ in samples(g)]
    if ps is None or not regs or not want:
        return None
    caught = capture_results(g, action)
    if caught is None:
        return None                      # 有件被降级，而落点正好在 captured_piece_flung_ten 说不出的那一档
    occupied = {cell for p in ps for cell in piece_cells(p)}
    ps_prev = pieces(g)
    fresh = [p for p in ps if p not in ps_prev]
    # 会动物件怎么走，按**降级前**的件清单算（capture_landing 自己就是这么算的）；
    # 而「下一帧场上有哪些件」要用降级后的清单——过关判定在追猎者走完之后（ea35b8c4036c3abd）。
    ps_after = ([p for p in ps if p not in {old for old, _ in caught}]
                + [new for _, new in caught])
    occupied_after = {cell for p in ps_after for cell in piece_cells(p)}

    # 这一步谁被并掉了：某色恰好两只压上新鲜件，它们合成高一级的一只
    merged = {}                          # 低一级色 -> 那两只走之前的格子集合
    for low in MOVER_LADDER:
        mm = merging_movers(g, action, low)
        if len(mm) == 2:
            merged[low] = [frozenset(x) for x in mm]

    hidden_any = False                   # 这一步有没有会动物件整块落进件底下（v9：只影响 False 那一侧）
    for colour in CREATURE_COLORS:
        gone = merged.get(colour, [])
        for obj in creatures(g, colour):
            if frozenset(obj) in gone:
                continue                 # 它这一步并掉了：走完就不是这一色了
            if colour not in SHAPE_OF_CREATURE:
                continue                 # 没有走法模型，下面那一段会返回 None
            try:
                _t, land = capture_landing(obj, ps, occupied, colour,
                                           ps_prev=ps_prev if colour == MOVER_COLOR else None,
                                           fresh=fresh)
            except Exception:                        # noqa: BLE001
                return None
            if set(land) <= occupied_after:
                hidden_any = True    # 它走完整块藏在件底下：数得出的只数可能偏少（v9）

    for colour, n in creature_samples(g).items():
        gone = merged.get(colour, [])
        in_ring = 0
        for obj in creatures(g, colour):
            if frozenset(obj) in gone:
                continue
            if colour not in SHAPE_OF_CREATURE:
                return None              # 它走完落在哪没有模型（色13 怎么走一次都没见过）
            try:
                tgt, land = capture_landing(obj, ps, occupied, colour,
                                            ps_prev=ps_prev if colour == MOVER_COLOR else None,
                                            fresh=fresh)
            except Exception:                        # noqa: BLE001
                return None
            if tgt in fresh and not pounces(obj, tgt, colour, fresh):
                # 它盯的正是这一 click 刚搬走的件，**而且不是扑**：这一档的落点没有模型
                # （mover_captures_piece NOTE v2 记过的「对穿」，位移能到 clamp 的三倍），
                # capture_results 对它也是闭嘴的。
                # 1f8f4e39dd87ccc9（第 428 步）：按 clamp 算它落在圈外一行，世界却过了关。
                #
                # v10 把「扑」从这个洞里摘出来。原先这里不分青红皂白，只要目标是新鲜件就返回说不出；
                # 洞是按色7 的对穿挖的，却把色14 一并闭嘴了——而色14 唯一进得了圈的路子**就是**扑新鲜件
                # （它扑上去整只压在件上，件坐在圈里，它就在圈里）。上面那条第 428 步的记录正是一次扑：
                # 按 clamp 算落在圈外一行，世界过了关。
                # 同时把 `fresh=fresh` 传进 capture_landing：不传的话 `pounces` 走的是 v2 老读法
                # （只看 cdist，第 329 步已打死），落点是按一条被推翻的判据算出来的。
                # 现在这一档由 mover14_pounces_when_close（v6 读法）背书；色7 那一侧一个字没动。
                return None
            if any(set(land) <= reg for reg in regs):
                in_ring += 1
        # 这一步砧板并生出来的（低一级的两只并成这一色的一只）
        for low, up in MOVER_LADDER.items():
            if up != colour or low not in merged:
                continue
            if len(fresh) != 1:
                return None              # 并了却挑不出砧板：新生的落在哪说不出
            shape = sample_shape(g, colour) or frozenset(SHAPE_OF_CREATURE.get(colour) or ())
            if not shape:
                return None
            says = {any(pl <= reg for reg in regs) for pl in born_placements(shape, fresh[0])}
            if len(says) != 1:
                return None              # 盒子里的摆法有的在圈里有的不在：这一步说不出
            if says.pop():
                in_ring += 1
        if in_ring < n:
            # 「圈里的这种物件比样板少」是藏件下唯一骗得到的一侧——藏只会让你**数少**，不会让你数多。
            # 所以这一步确实有物件整块落进件底下时，这个 False 说不出口（v9）。
            return None if hidden_any else False
    return covers([p[0] for p in ps_after if any(piece_in_ring(p, reg) for reg in regs)], want)


# 色7 追猎者（第 3 关起；第 4 关起有两个）。形状 4-邻接下散成两块、8-邻接下是一块，所以按 8-邻接分物件。
MOVER_COLOR = 7
MOVER_STEP = 4


def mover(g):
    """棋盘区里所有色7 格（所有追猎者的并集）；没有返回 None。"""
    cs = frozenset((r, c) for r, c in cells_of(g, MOVER_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW)
    return cs or None


def movers(cells):
    """把色7 格按 8-邻接拆成一个个追猎者。"""
    return [frozenset(b) for b in components(cells, diag=True)]


def _nearest_piece(cells, ps):
    def d(p):
        return min((r - rr) ** 2 + (c - cc) ** 2 for r, c in cells for rr, cc in piece_cells(p))
    return min(ps, key=d)


def mover_target(cells, ps, ps_prev=None):
    """一个会动物件盯的件。ps 是点击**后**的件清单。

    给了 ps_prev（点击**前**的件清单）就**认身份不认位置**：先在点击前的清单里挑离它最近的那件，
    再跟到它点击后的位置（那件没被这一 click 动过就是它自己；被动过就是清单里唯一新出现的那件）。
    分不清（新件不止一个）时退回「点击后最近」。
    区分性证据：77104a652ac235d8 一步里左边两只追猎者继续朝 3 级走（(+28.125,0)→(4,0)、
    (+18.125,-1)→(4,-1) 一格不差），而点击后离它们最近的是刚被搬过去的 6 级。
    逐只打分（probe_hunter，89 条「一只走一步」）：认身份 88/89，点击后最近 86/89。
    色14 原本不传 ps_prev（那时它一条自己的区分性证据都没有）；第 333 步（b0ba75ebecd43d6f）给了它第一条：
    菱形在 行40-43列17-21，「点击后最近」挑远处那块 5 级、押 (+4,减3) 错 8 格，
    「认身份」挑的是这一 click 刚并出来的那件、押 (减4,减4)，与世界一格不差（probe_t333.out）。
    全去重语料上两条读法各开口 10 次，只有这一条判得不一样（probe_t333b.out），
    于是 mover14_hunts_like_mover7 v7 起也传 ps_prev。**色14 这一侧的区分性证据仍然只有这一条。**

    **已知的洞**：`_nearest_piece` 的 `min` 在并列时返回件清单的扫描顺序，那不是世界事实。
    要不要为此闭嘴，用 `mover_target_ambiguous` 判（第 270 步的死因，见那个词的注释）。"""
    if ps_prev:
        tgt = _nearest_piece(cells, ps_prev)
        if tgt in ps:
            return tgt
        fresh = [p for p in ps if p not in ps_prev]
        if len(fresh) == 1:
            return fresh[0]
    return _nearest_piece(cells, ps)


def _round(x):
    """半数朝 +∞ 取整。区分性证据：列 +0.5 走了 +1（d136…前一步），列 -0.5 一动不动（5777367c466554b5）。"""
    import math
    return math.floor(x + 0.5)


def _centroid(cells):
    return (sum(r for r, _ in cells) / len(cells), sum(c for _, c in cells) / len(cells))


def piece_gap(cells, p):
    """一个会动物件的格子到一件件的格子的最小欧氏距离。"""
    return min(((r - rr) ** 2 + (c - cc) ** 2) ** 0.5
               for r, c in cells for rr, cc in piece_cells(p))


# 「扑」：色14 菱形在**离目标件足够近**时不走 MOVER_STEP，而是一口气把整只挪到「重心对准件心」的位置
# （落点压在件上，途中不停）。
# 量什么距离，换过两次：
#   v1 量**最近格距**，阈值 <=7，夹在第 168 步（扑，7.00）与第 164 步（不扑，8.00）之间；
#   第 213 步打死了它——那一步一只色14 最近格距 6.71 却走了 clamp，另一只 1.41 扑了。
#   v2 改量**重心到件心的欧氏距离**（probe_pounce_centroid.py）：扑过的四次 9.25 / 9.06 / 8.78 / 7.04，
#   没扑过的 10.25 / 11.07 / 15.81~25.63，阈值夹在 (9.25, 10.25) 之间，取 10.0。
#   第 329 步（52c92c40e3fdf3d5）打死了它：cdist 9.01（**不超过** 10.0，比扑过的最小一次 9.25 还小）却走了 clamp。
#   同一对局面在第 327 步也是 9.01、也没扑——所以这不是阈值高低，是**单看这个距离分不开**。
#   v3（曾是现在这一条，probe_pounce2.out 当时 25 条「盘上恰好一块完整色14 的棋盘点击」）：
#     扑的 5 条    gap [4.0, 4.0, 6.08, 6.4, 7.0]，目标是新件 5/5
#     clamp 的 9 条 gap [5.0, 5.0, 8.0, 9.0, 11.4, 13.6, 17.03, 20.0, 21.21]，目标是新件 4/9
#                  （那 4 条新件的 gap 分别是 8.0 / 17.03 / 20.0 / 21.21，全在 7.5 以外）
#   两个条件都要：**目标是这一 click 刚搬来（或刚合出来）的那件**，**且**最近格距不超过 POUNCE_GAP。
#   少了新件这一条就判错第 327/329 步（gap 5.0，非新件，clamp）；少了 gap 这一条就判错第 164 步那一档。
#   阈值取 7.5 而不是 7.0：边界夹在 7.0（扑）与 8.0（clamp）之间，钉在观测最大值上是把判据焊死。
#   第 507 步（af26c16fca8a9323）打死了 v3 的 gap 那一半：目标**是**新件、gap 6.71（在 7.5 以内、
#   也落在扑过的 [3.61, 7.0] 区间里），世界走的却是 clamp Δ(+4,-4)。gap 分不开这两档。
#   v4 是现在这一条（probe_pounce2.out 重跑，语料涨到 51 条「盘上恰好一块完整色14 的棋盘点击」）：
#     **把新件这一条留下，量法换回 v2 的重心距**——两半各自都死过，合起来才切得开。
#     扑的 7 条          cdist [7.04, 7.32, 7.85, 8.0, 8.78, 9.06, 9.25]，目标是新件 7/7
#     clamp 里目标是新件的 11 条 cdist [10.25, 11.03, 11.88, 12.0, 14.7, 15.1, 16.25, 17.67, 21.45, 24.4, 25.63]
#   边界仍夹在 (9.25, 10.25)，仍取 10.0 —— 和 v2 同一个数，但**多了新件这一条**：
#   v2 死在第 327/329 步的 cdist 9.0，而那两步目标不是新件，新读法直接把它们排在外面。
#   反过来 v3 死在第 507 步，是因为它把量法换掉了。所以这一版不是「再调一次阈值」，是把两次死因各自的那一半拼回去。
#   剩下没切干净的：gap 在两档里完全重叠（扑 [3.61,7.0]、新件 clamp [6.71,21.21]），所以 gap 不再进判据。
#   色7 追猎者**从不扑**：最近格距<=7 的 21 条观测全是 clamp，一条扑都没有。
#   第 509 步（625241b187536c74）把 v4/v5 的 cdist 那一半也压垮了：目标是新件、cdist 10.0778
#   （**超过** 10.0，按 v5 该走 clamp），世界却扑了——件A 点击后该在 (5,25,6)，实测 (4,25,0)：
#   掉一级、列从 6-10 甩到 0，是 mover_captures_piece + captured_piece_flung_ten 的签名；
#   盘上够得着它的只有这一块色14，而 clamp 落点 行20-23 碰不到它、扑的落点 行25-28 整块压在它身上。
#   （这一条的归档是**推**出来的，不是看落点看出来的——那一帧关当场死、整屏重画。见 probe_511pounce.out）
#   只把 10.0 抬到 10.0778 以上的话窗口只剩 (10.0778, 10.25]、0.17 宽，和 gap 垮掉前一模一样。
#   v6 换的是量法本身（probe_511norm.out，新件这一侧 扑 5 条 / clamp 13 条）：
#     cdist 量的是重心到件**心**，件越大件心离件的边越远——同样贴着边，大件的 cdist 天生更大。
#     扑过的 5 条里 4 条目标是 3 级件，第 509 步那条是 5 级，两档因此被件的大小拌在一起。
#     把边长折掉（`cdist - side/2`，记作 hdist）之后：
#       扑    [5.5401, 7.2785, 7.5588, 7.5778, 7.75]
#       clamp [8.5255, 8.75, 9.377, 9.5026, 12.1991, 12.1991, 12.6017, 13.7038, 13.75, 15.1653, …]
#     零重叠，窗口 (7.75, 8.5255) 宽 0.7755 —— 是 cdist 的 4.5 倍。阈值取窗口中点 8.14，不钉在端点上。
#     同一批数据里别的量法全有重叠：cdist−side 重叠 3、cdist/side 重叠 10、gap 重叠 2、切比雪夫 3、曼哈顿 4。
#   **预注册的薄处**：扑这一档只有 5 条观测，其中 5 级件只有第 509 步这一条；
#   下一条 5 级件的扑（或不扑）落在 7.75~8.53 之间，这个量法就当场垮。垮了不要再削阈值——
#   两个量法各被削垮过一次，第三次该换的是「扑不扑由距离决定」这个假设本身。
POUNCE_COLORS = (DIAMOND_COLOR,)
POUNCE_REACH = 7          # v1 的阈值，留着给 NOTE 引用
POUNCE_CDIST = 10.0       # v2/v4/v5 的阈值，第 509 步打死；已不进判据，留着给 NOTE 与老调用处引用
POUNCE_GAP = 7.5          # v3 的阈值，第 507 步打死；已不进判据，留着给 NOTE 与老调用处引用
POUNCE_HALF = 8.14        # v6 的阈值：窗口 (7.75, 8.5255) 的中点


def pounce_cdist(cells, tgt):
    """会动物件的重心到目标件中心的欧氏距离。v2/v4/v5 的判据用它，第 509 步打死。"""
    tr, tc = piece_center(tgt)
    mr, mc = _centroid(cells)
    return ((tr - mr) ** 2 + (tc - mc) ** 2) ** 0.5


def pounce_hdist(cells, tgt):
    """会动物件的重心到目标件中心的距离，**减掉件的半边长**——把件的大小归一化掉。

    为什么减 side/2：`pounce_cdist` 量到的是件心，件越大件心越深，同样贴着件的边、大件的读数天生更大。
    减掉半边长之后量的大致是「重心到件的边」，跨级可比。v6 的判据用它（由来见上面的注释块）。"""
    return pounce_cdist(cells, tgt) - SIDE_OF_TIER[tgt[0]] / 2


def pounces(cells, tgt, colour, fresh=None):
    """扑不扑。`fresh` 是这一 click 新出现的件的清单。

    **两条读法并存，由调用处选**，这是明写的欠账不是疏忽：
      · 给了 `fresh`（哪怕是空清单）→ v6：目标在 fresh 里、**且** hdist 不超过 POUNCE_HALF。
      · 不给（None）→ v2 的老读法（只看 cdist，不问新件）。它已被第 329 步打死，
        留着只是为了不让**还没被重新审过**的调用处在我没看的时候悄悄改判——
        改一个词会让所有引用它的概念一起重算，而这一批里我只重审得动两条色14 概念。
        哪条概念把它的调用处改成传 fresh，哪条就换到 v6；老读法的调用处一条也别当成已检验过的。

    v3（新件 + gap<=POUNCE_GAP）死在第 507 步：目标是新件、gap 6.71 在阈值内，世界却走 clamp。
    v4/v5（新件 + cdist<=POUNCE_CDIST）死在第 509 步：cdist 10.0778 在阈值外，世界却扑了。
    v6 只把量法换成归一化过的 hdist，新件那一半原样留着——那一半是 v3 挣出来的，三版都没被推翻过。

    **v7：新件那一半死了**（b066e2def828150a，终局卡第 751 步 ACTION6:5,56）。那一击搬的是另一头的件，
    色14 盯的那件**一格没动、不在 fresh 里**，按 v6 它不该扑；hdist 是 6.51，在 POUNCE_HALF 之内。
    逐格手算两种落点：clamp 落点 行16-19列8-12（dr=_round(0.5)=1，dc=_round(-9) 夹到 -4），
    第 12 列出了西北圈的 9×9 外接框（列3-11），所以 will_level_up 数出「圈里零只色14」判不过关；
    扑的落点 行16-19列3-7 整块在框里。**世界升了关（7/9 → 8/9）**，也就是它扑了。
    于是这一半只保留到 hdist：`fresh` 这个参数从此只用来区分新旧两种读法，不再进判据本身。
    顺带一条同步读数：这一扑整块落在那件身上，而那件**不是新件**，世界**没有咬它**
    （咬了容量就掉破需求，关升不上去）——和影子概念 mover14_pounce_keeps_tier 说的是同一件事。
    **本条没有顺手去改捕获那一侧**：`capture_results` 不传 fresh，走的仍是老读法，一个字没动；
    「扑不咬」要不要写进捕获，得由那条影子概念自己拿分数来争，不在这里搭车。
    """
    if colour not in POUNCE_COLORS:
        return False
    if fresh is None:
        return pounce_cdist(cells, tgt) <= POUNCE_CDIST
    return pounce_hdist(cells, tgt) <= POUNCE_HALF


def _shift_into_board(cells, shape=None):
    """算出来的落点有格子出了棋盘，就把**整块**平移最少的量塞回去（形状不变）。

    实测三次，三次全中（probe_movedge.py）：第 292/293/294 步同一只色7 贴着右边界追件，
    `_one_mover_next` 算出的落点每次都含第 64 列（帧只有 0..63 列），
    而世界给的那一块每次都正好是「整块左移 1 格」——八格的菱形形状一格不差。
    逐格夹（clamp 每一格）会把菱形压扁，语料里不是那样，所以这里平移整块。

    **上边界第 402 步撞上了，也中**（probe_402.out）：一只色7 从 行11-14列36-40 去够 行10 的一级件，
    算出的落点是 行8-11列35-39（第 8、9 行在 HUD 带里，不是棋盘），
    世界给的那一块是 行10-13列35-39——正好是「整块下移 2 格」，夹到 `TOP_BAND_LAST_ROW + 1`，列一格不差。
    件的落点也是同一条边同一个口径（见 `placed` 的第 400 步）：两处独立观测，**棋盘顶是第 10 行，不是帧顶**。
    下边界仍是一次都没撞过，那一档是按同一条规则外推的。

    **行轴那两档不需要 `shape`，所以不给 `shape` 也照夹**（`TOP_BAND_LAST_ROW`、`BUDGET_ROW` 是常量）；
    左边界同理（第 0 列）。只有右边界要知道帧宽，`shape` 不给就不夹右边。
    改这一条的由来：`capture_results` 从来没往下传 `shape`，于是第 402 步它算出「落点在 HUD 带里、没压上件」
    → 报「没有捕获」，而世界吃了那件，余量 1→0。那不是豁免漏了，是落点没塞回棋盘。"""
    if not cells:
        return cells
    r0 = min(r for r, _ in cells); r1 = max(r for r, _ in cells)
    c0 = min(c for _, c in cells); c1 = max(c for _, c in cells)
    dr = max(0, TOP_BAND_LAST_ROW + 1 - r0) - max(0, r1 - (BUDGET_ROW - 1))
    dc = max(0, -c0)
    if shape is not None:
        dc -= max(0, c1 - (shape[1] - 1))
    if not dr and not dc:
        return cells
    return frozenset((r + dr, c + dc) for r, c in cells)


def _one_mover_next(cells, ps, occupied, colour=MOVER_COLOR, ps_prev=None, shape=None, fresh=None):
    tgt = mover_target(cells, ps, ps_prev)
    tr, tc = piece_center(tgt)
    mr, mc = _centroid(cells)
    if pounces(cells, tgt, colour, fresh):
        return _shift_into_board(
            frozenset((r + _round(tr - mr), c + _round(tc - mc)) for r, c in cells), shape)
    dr = max(-MOVER_STEP, min(MOVER_STEP, _round(tr - mr)))
    dc = max(-MOVER_STEP, min(MOVER_STEP, _round(tc - mc)))
    # 途中压到件就停在第一次接触处：按整条位移的比例分段试
    n = max(abs(dr), abs(dc))
    for k in range(1, n):
        moved = frozenset((r + _round(dr * k / n), c + _round(dc * k / n)) for r, c in cells)
        if moved & occupied:
            return _shift_into_board(moved, shape)
    return _shift_into_board(frozenset((r + dr, c + dc) for r, c in cells), shape)


def mover_next(cells, ps, ps_prev=None):
    """色7 这一步之后的格子集合（假设，由 mover7_lands_when_target_unique 走闸）：
    每个追猎者各自独立，拿自己格子的重心去够它盯的那件（见 mover_target：给了 ps_prev 就认身份）的中心：
    行、列偏移各 = floor(差 + 0.5) 再 clamp 到 ±MOVER_STEP；途中压到件就停在第一次接触处。
    返回所有追猎者的并集。ps 为空返回 None（没目标时怎么走没见过）。
    **行差绝对值小于 MOVER_STEP 的那一档，这套算法是错的**——不是「暂时没量准」，是形式上错：
    第 258 步（6ca265628823954a）行差 +2.625 世界走 +3，第 267 步（f7a2712626fa5938）行差 +3.625 世界走 +3。
    行差大了整整 1.000，位移反而没变；任何平移等变的取整 f 都满足 f(x+1)=f(x)+1，
    连「位移是行差的**单调**函数」都被这两点否掉（probe_rowfun.out）。两点都在概念的开口范围内。
    换参考点也救不回来：{重心/包围盒中心/离目标最近格/左上角} × {件心/件里最近格/件左上角} × 七种取整
    共 84 组，现行这一组仍是最高分（行 117/118、列 118/118），没有一组救得了第 267 步而不赔掉别的
    （probe_anchor2.out）；件心在偶数边长上的三种写法也不行（probe_anchor3.out）。
    这个函数照旧给数、不划界；界在走闸的概念里（四道：**目标并列**、甩飞档、目标存疑档、行差没被 clamp 顶死）。
    曾经记过「77104a652ac235d8 那条反例落进甩飞档了所以行差那道闸可以撤」——那是 v7 的账，
    撤错了，见 history/mover7_chases_locked_target.v8.py 的 NOTE。
    **这个函数喂进去的目标也可能没有定义**：并列时 `mover_target` 返回的是件清单的扫描顺序
    （第 270 步的死因），要不要为此闭嘴由 `mover_target_ambiguous` 判。"""
    if not ps:
        return None
    occupied = {cell for p in ps for cell in piece_cells(p)}
    out = frozenset()
    for obj in movers(cells):
        out |= _one_mover_next(obj, ps, occupied, ps_prev=ps_prev)
    return out


def mover_row_clamped(obj, ps, ps_prev=None):
    """这一只色7 朝它盯的件的**行**差有没有被 clamp 顶死：**原始行差**的绝对值不小于 MOVER_STEP。

    v2。**先取整再比**（`abs(_round(差)) >= MOVER_STEP`）改成**拿原始差比**。
    区别只在 |差| 落在 [3.5, 4) 的那一窄条：取整会把它抬到 4，于是这个函数说「被 clamp 了」，
    而位移其实是取整算出来的、不是 clamp 顶出来的——那正是第 267 步（f7a2712626fa5938，行差 +3.625）
    从 v7 的闸底下漏过去的缝。v7 的 NOTE 里预注册的那句话写的是「行差绝对值小于 4 的那一档」，
    按**原始差**读它，第 267 步就在那一档里；按取整后读，它不在。两种读法指向相反的结论，
    而预注册的判据不许事后改口径，所以这里把函数改成与预注册同一个口径：拿原始差比。

    改完这个词之后的账（probe_rowfun.out / probe_feat267.out，全去重语料、概念其余闸一道不动）：
    原始行差被 clamp 顶死的 95 只**全对**；没顶死的 23 只里 22 对 1 错，错的就是第 267 步。
    走闸的概念 mover7_lands_when_target_unique 用它划界：没顶死就闭嘴。"""
    tgt = mover_target(obj, ps, ps_prev)
    return abs(piece_center(tgt)[0] - _centroid(obj)[0]) >= MOVER_STEP


def mover_target_ambiguous(cells, ps, ps_prev=None):
    """`mover_target` 给这一只挑的那件**是并列挑出来的，而且并列的几件跟到点击后不是同一件**。

    为什么要这个词：`_nearest_piece` 用 `min(ps, key=d)`，Python 的 `min` 遇到并列取**先出现**的那个，
    而件清单的顺序来自 `pieces()` 的扫描顺序（自上而下、自左而右）。「并列时世界挑哪一件」是一条
    **从没走过闸的世界事实**，它却一直藏在这个词里冒充定义。第 270 步（692efadd54216427）撞上了：
    右边那只色7（重心列 48.0）两侧的 (2,26,42) 与 (2,26,53) 到它的最近格平方距离**都是 125**，
    连件心到重心的距离也一样；`min` 取了右边那件，世界追的是左边那件，于是落点整块错 8 格。
    那一步世界走的 (-4,-4) 正是同一条落点公式拿左边那件算出来的答案（probe_tie2.out），
    **所以错的不是落点公式，是喂给它的目标没定义**。

    并列本身不算病：并列的几件如果跟到点击后是同一件，挑谁都一样。第 101 步（d136d6fd07bdda29）
    就是这样——同一只追猎者、同一个位置、同样两件并列，但那一 click 把两件并成了 (3,26,47)，
    `mover_target` 走「唯一新件」那条岔路，答案唯一，而且说对了。所以这里判的是**跟到点击后还分不分得开**。

    全去重语料上并列的只共 2 只，这个词判 True 的只有 1 只（probe_tie.out / probe_tie2.out）。
    分母小得只够说「现有语料里这种局面罕见」，不够说「它只会在这一步出现」——
    它是不是罕见和它有没有定义是两件事，这道闸关的是后者。
    走闸的概念 mover7_lands_when_target_unique 用它划界：判 True 就闭嘴。"""
    if not ps_prev:
        return False

    def _d(p):
        return min((r - rr) ** 2 + (c - cc) ** 2 for r, c in cells for rr, cc in piece_cells(p))

    best = min(_d(p) for p in ps_prev)
    tied = [p for p in ps_prev if _d(p) == best]
    if len(tied) < 2:
        return False
    fresh = [p for p in ps if p not in ps_prev]
    followed = set()
    for p in tied:
        if p in ps:
            followed.add(p)
        elif len(fresh) == 1:
            followed.add(fresh[0])
        else:
            return True                          # 跟丢了，更说不清
    return len(followed) > 1


def mover_row_locked(cells, ps, ps_prev=None):
    """场上每一只色7 的行差是否都被 clamp。ps 为空返回 False。"""
    if not ps:
        return False
    return all(mover_row_clamped(obj, ps, ps_prev) for obj in movers(cells))


def mover_path(cells, ps, ps_prev=None):
    """一次点击里追猎者**可能**待的全部格子：每个追猎者从 k=0 到整条位移的每个子步位置的并集。
    为什么要它：捕获那一步追猎者到底停在哪，现有模型会错一格（见 runs/ 里的 probe_capture_land 读数：
    四次捕获里两次停在压上件的那一子步、两次停在挨着的前一子步），
    所以生成器该对整条路径闭嘴，而不是只让开一个落点。ps 为空返回 None。"""
    if not ps:
        return None
    out = set()
    for obj in movers(cells):
        tgt = mover_target(obj, ps, ps_prev)
        tr, tc = piece_center(tgt)
        mr, mc = _centroid(obj)
        dr = max(-MOVER_STEP, min(MOVER_STEP, _round(tr - mr)))
        dc = max(-MOVER_STEP, min(MOVER_STEP, _round(tc - mc)))
        n = max(abs(dr), abs(dc)) or 1
        for k in range(0, n + 1):
            out |= {(r + _round(dr * k / n), c + _round(dc * k / n)) for r, c in obj}
    return frozenset(out)


def capture_landing(hunter, ps, occupied, colour=MOVER_COLOR, ps_prev=None, shape=None, fresh=None):
    """这个会动物件这一步的落点，**含走到目标身上那一格**（mover_next 只到接触前一格）。
    返回 (目标件, 落点格子集)。色14 在近处是「扑」：整只压到件上，途中不停（见 POUNCE_COLORS）。
    `fresh` 传给 `pounces`：不传就按老读法判扑不扑（见 `pounces` 的 docstring，那条已被第 329 步打死）。
    给了 `shape=(行数, 列数)` 就把出帧的落点整块平移塞回棋盘（见 `_shift_into_board`，三次观测三次中）。"""
    tgt = mover_target(hunter, ps, ps_prev)
    tr, tc = piece_center(tgt)
    mr, mc = _centroid(hunter)
    if pounces(hunter, tgt, colour, fresh):
        return tgt, _shift_into_board(
            frozenset((r + _round(tr - mr), c + _round(tc - mc)) for r, c in hunter), shape)
    dr = max(-MOVER_STEP, min(MOVER_STEP, _round(tr - mr)))
    dc = max(-MOVER_STEP, min(MOVER_STEP, _round(tc - mc)))
    n = max(abs(dr), abs(dc))
    for k in range(1, n + 1):
        moved = frozenset((r + _round(dr * k / n), c + _round(dc * k / n)) for r, c in hunter)
        if moved & occupied:
            return tgt, _shift_into_board(moved, shape)
    return tgt, _shift_into_board(frozenset((r + dr, c + dc) for r, c in hunter), shape)


def hunters(g):
    """这一帧上所有**会捕件**的物件：[(格子集, 颜色, 要不要认身份), …]；说不出返回 None。

    从前这里只有色7（`movers(mover(g))`）。**色14 也捕**——全语料 31 次「件掉了容量的棋盘点击」
    逐条查谁压在被降级那块件上（probe_who14.out）：
      · 第 158 步 766c3c0aee19eb7c：容量 20→18，掉的是 3 级件 (3,35,20)，
        **色7 一块都没压上，色14 压的正是它、且它不是新件**。单只归因，没有别的嫌疑人。
      · 第 174 步 831f48174bd3597f：色14 压的是**新件** (3,54,10)，那件一点没变；
        同一步掉级的 (5,59,18) 是色7 压的。也就是**新件豁免同样管色14**。
      · 其余 29 条里色14 一次都没压上过件，所以此前「只有色7 捕」在那 29 条上分不出对错。
    还有 5 条（第 83、105、147、256、327 步）件掉了容量而按这套落点算**谁都没压上**——
    那是另一个洞，不是这条函数补得上的（第 327 步是目标读法的歧义，第 147 步疑似有个看不见的新生色14）。

    色14 的块读不准（`creature_blocks` 的 exact=False，被件盖住了）时返回 **None**：
    形状读不准落点就算不准，而这一档恰恰就是「它正压在件上」。宁可说不出，不要说「没捕」——
    第 327 步的教训是，把「算不出来」当成「没发生」会让规划器拿一关去赌。
    """
    out = []
    mv = mover(g)
    if mv is not None:
        for h in movers(mv):
            out.append((h, MOVER_COLOR, True))
    for blk, full in creature_blocks(g, DIAMOND_COLOR):
        if not full:
            return None
        out.append((blk, DIAMOND_COLOR, False))
    return out


def _top_creature_prey(g, ps):
    """梯子顶端那一色（色13）这一步咬谁：离它最近的那件，一件都没有或并列时返回 []。

    「它在场就每一 click 咬一口」由 mover13_bites_moved_piece 走闸（N=2）；
    「咬的是最近那件」是从同样这两条观测读出来的：两次被咬的都是它身下那块。
    距离按格子对的欧氏最小值量，和 roster._host_of 用的是同一种读法。"""
    top = MOVER_LADDER.get(DIAMOND_COLOR)
    if top is None or not ps:
        return []
    blocks = creatures(g, top)
    if not blocks:
        return []
    cells = set()
    for b in blocks:
        cells |= set(b)
    best, bestd, tie = None, None, False
    for p in ps:
        d = min((r - rr) ** 2 + (c - cc) ** 2 for r, c in cells for rr, cc in piece_cells(p))
        if bestd is None or d < bestd:
            best, bestd, tie = p, d, False
        elif d == bestd:
            tie = True
    if best is None or tie:
        return []
    return [best]


def captured_pieces(g, action):
    """这一步会被追猎者降级的件（假设，由 mover_captures_piece 走闸）。
    目标件是这一 click 刚搬过来 / 刚合出来的那件时不算（下称「新件豁免」）。
    **这条豁免的分母数清楚了**（probe_fresh，全语料去重、先把被世界整条驳回的那些剔掉）：
    捕获者的落点没压到新件 —— 新件原地不动 67 次、挪走或降级 1 次；
    压上了 —— 原地不动 15 次、挪走或降级 1 次。即豁免在「压上了」这一档站 15/16，不是先前这里写的「两次观测」。
    唯一的反例是第 197 步（色7 压上刚搬过来的 6 级件，它降成 5 级并被甩到 (-7,-7)）——
    而 capture_fling 对那一步算得分毫不差。留着豁免是因为撤掉它会把 15 次说对换成 1 次说对；
    但它是**带反例的假设**，不是已确认的规则，第 197 步是公开的反例。
    **追猎者不只色7，色14 也捕**（见 `hunters` 的 docstring：第 158 步单只归因，第 174 步豁免同样管它）。
    色7 的目标按 mover_target 的**认身份**读法挑，色14 按「点击后最近」：
    第 201 步（1f24d971da7043ac）之前这里漏传 ps_prev，于是一只本该追新件（3 级）的色7 被算成追 5 级件，
    算出「5 级件该降级」而帧上它一点没变。
    算不出来（不是棋盘点击、合成规则说不出结果、棋盘上没追猎者、色14 的块读不准）返回 []。
    **落点撞上同色另一只的追猎者跳过**（见 colliding_hunters：那一档 3/4 是并不是咬，说不出）。

    **梯子顶端那一色（MOVER_LADDER 的终点，这里是色13）另算**：它在盘上时，**每一次棋盘点击**
    都有一件被咬掉一级，新件豁免不管用、空点也不例外。两条观测：
      · 第 763 步（48dc2920a0a03dd3）：刚搬到 行37-41列10-14 的 5 级件当场降成 4 级被甩到 行35-38列5-8，
        而按豁免它该毫发无损；
      · 第 765 步（59634597a4058787）：点的是谁都够不着的右上角空地、**一件都没搬动**，
        它身下那块 5 级件照样降成 4 级并被甩到 行24-27列19-22。
    走闸的是 mover13_bites_moved_piece（v2）。咬的是**离它最近的那件**（两条观测都是它身下/最近那件；
    并列时说不出，返回空）；它没有形状模型、落点算不出，所以这里只说「被咬」，
    capture_results 那边整条闭嘴。豁免带反例本来就有前科（第 197 步色7 咬了刚搬的 6 级件）。"""
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return []
    hs = hunters(g)
    ps = after_click(g, action)
    if not ps:
        return []
    ps_prev = pieces(g)
    fresh = [p for p in ps if p not in ps_prev]
    bitten_by_top = _top_creature_prey(g, ps)
    if not hs:
        return bitten_by_top
    occupied = {cell for p in ps for cell in piece_cells(p)}
    collide = {(frozenset(h), colour) for colour in CREATURE_COLORS if colour in SHAPE_OF_CREATURE
               for h in colliding_hunters(g, action, colour)}
    out = []
    for h, colour, by_id in hs:
        if (frozenset(h), colour) in collide:
            continue
        tgt, land = capture_landing(h, ps, occupied, colour,
                                    ps_prev=ps_prev if by_id else None, fresh=fresh,
                                    shape=(len(g), len(g[0])))
        if tgt not in fresh and (land & piece_cells(tgt)):
            out.append(tgt)
    for p in bitten_by_top:
        if p not in out:
            out.append(p)
    return out


def capture_fling(land, tgt, ncol):
    """被捕获的件降一级之后落在哪（假设，由 captured_piece_flung_ten 走闸）。

    读法：从捕获者的**落点重心**指向件心，这个方向先按 _round 量化成整数对
    （capture_landing 自己算 dr/dc 时就是这么做的），再归一乘 POUNCE_CDIST，
    加在旧件的**左上角**上（不是件心——两件边长不同，左上角才是能平移的那个点），
    最后夹回棋盘：行落在 [TOP_BAND_LAST_ROW+1, BUDGET_ROW-边长+1]，列落在 [0, ncol-边长]。

    说不出就返回 None，有两档：
      · 量化方向是 (0,0)——没有方向；
      · 量化方向有一个分量的绝对值**恰好是 1**——这一档原始差值在 [0.5,1.5) 之间晃，
        归一乘 10 之后差着整整一格，模型分不清 (0,±10) 和 (∓2,±10)，只能闭嘴。
    """
    tier = tgt[0] - 1
    if tier < 1 or tier not in SIDE_OF_TIER:
        return None
    ar, ac = _centroid(land)
    cr, cc = piece_center(tgt)
    dr, dc = _round(cr - ar), _round(cc - ac)
    if (dr, dc) == (0, 0) or abs(dr) == 1 or abs(dc) == 1:
        return None
    n = (dr * dr + dc * dc) ** 0.5
    side = SIDE_OF_TIER[tier]
    r = _round(tgt[1] + POUNCE_CDIST * dr / n)
    c = _round(tgt[2] + POUNCE_CDIST * dc / n)
    return (tier,
            min(max(r, TOP_BAND_LAST_ROW + 1), BUDGET_ROW - side + 1),
            min(max(c, 0), ncol - side))


def capture_results(g, action):
    """这一 click 之后被降级的件各自变成什么：[(旧件, 新件), …]。

    没有捕获返回 []；有捕获但其中任何一件的落点算不出来（capture_fling 返回 None）返回 **None**，
    「没发生」和「说不出」是两件事，调用处必须分得开。
    **色14 的块读不准时也返回 None**（见 `hunters`）——那一档正是「它压在件上」。
    **捕获者的落点撞上同色另一只时也返回 None**（见 colliding_hunters：第 574 步那一撞是并不是咬，
    而第 465 步同样的撞是咬不是并——两条都在语料里，模型分不出，只能闭嘴）。
    捕获挑法照抄 captured_pieces（目标不是这一 click 刚搬来的，且落点真压上去了）。
    **梯子顶端那一色（色13）在盘上时整条返回 None**：它每一次棋盘点击都咬得出一口
    （第 763 步 48dc2920a0a03dd3 咬刚搬的件、第 765 步 59634597a4058787 空点照咬），
    可落点说不出——它没有形状模型，capture_fling 那条方向公式无从算起。
    咬得出、落点说不出，就是「说不出」，不是「没发生」。"""
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return []
    hs = hunters(g)
    ps = after_click(g, action)
    if ps and creatures(g, MOVER_LADDER[DIAMOND_COLOR]):
        return None
    if hs is None:
        return None
    if not hs or not ps:
        return []
    ps_prev = pieces(g)
    fresh = [p for p in ps if p not in ps_prev]
    occupied = {cell for p in ps for cell in piece_cells(p)}
    ncol = len(g[0])
    collide = {(frozenset(h), colour) for colour in CREATURE_COLORS if colour in SHAPE_OF_CREATURE
               for h in colliding_hunters(g, action, colour)}
    out = []
    for h, colour, by_id in hs:
        tgt, land = capture_landing(h, ps, occupied, colour,
                                    ps_prev=ps_prev if by_id else None, fresh=fresh,
                                    shape=(len(g), ncol))
        if tgt in fresh or not (land & piece_cells(tgt)):
            continue
        if (frozenset(h), colour) in collide:
            return None
        new = capture_fling(land, tgt, ncol)
        if new is None:
            return None
        out.append((tgt, new))
    return out


def board_frozen_except_budget(prev, nxt):
    """除第 BUDGET_ROW 行之外一格没变，而两帧并不完全相同。"""
    if prev == nxt:
        return False
    return all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW)


def something_should_move(g, action):
    """册子算得出：这一 click 之后至少有一件或一只会动物件不在原地。

    True = 册子说该动；False = 册子说本来就该原地不动；**None = 算不出**（说不出，不猜）。
    调用处必须把 False 和 None 分开——「本来就不该动」的冻帧是正常的，
    「算不出」的冻帧什么也不能说。
    """
    ps_prev = pieces(g)
    ps = after_click(g, action)
    if ps is None:
        return None
    if sorted(ps) != sorted(ps_prev):
        return True
    occupied = {cell for p in ps for cell in piece_cells(p)}
    for colour in CREATURE_COLORS:
        blocks = creature_blocks(g, colour)
        if any(not exact for _, exact in blocks):
            return None                    # 形状认不出，落点就是瞎算
        for b, _exact in blocks:
            if _one_mover_next(b, ps, occupied, colour=colour) != set(b):
                return True
    return False


def world_refused(g, action, nxt):
    """世界整条驳回了这次点击：帧除预算条外冻住，而册子算出来本该有东西挪窝。

    True = 驳回；False = 不是驳回（要么帧变了，要么册子本来就说不该动）；
    **None = 帧冻住了但算不出该不该动**（说不出）。

    这个判定**不带「REACH 内有没有件」这个条件**。原先三条概念都把驳回写成
    「REACH 内有件 + 帧冻住」，而 2976b42a461cdd67 是一次 REACH 内一件都没有的点击：
    场上两只会动物件，册子算出来它们各该走一步，帧却除预算条外一格没变，还扣了 14 格预算。
    所以「点到件」不是驳回的必要条件，把它写进判据只会让这一档漏出去。
    """
    if not board_frozen_except_budget(g, nxt):
        return False
    return something_should_move(g, action)
