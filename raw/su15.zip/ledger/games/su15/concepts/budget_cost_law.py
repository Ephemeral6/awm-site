"""简单棋盘点击（非驳回、非过关、after_click 算得出）扣第 63 行几格色0，
由『点击前剩余色0格数的 2-adic 赋值』（末尾连续 0 的个数，记 v2）与关卡号共同决定：
v2==0（剩余格数是奇数）扣 1 格；v2==1（剩余格数 ≡ 2 mod 4）扣 2 格；
v2>=2（剩余格数 ≡ 0 mod 4）时，关卡属于 {2,3,7,8} 扣 1 格，属于 {0,1,4,5,6} 扣 2 格。
"""
LEVEL = "L4"
SCOPE = ("只在 budget_step_cost 判 TRUE 的『简单』棋盘点击上补一句『恰好扣几格』——"
         "非棋盘点击（顶带/ACTION7）、REACH 内≥3 件或两件不同级、"
         "驳回（帧除第 63 行外冻住、而册子说本该有东西挪窝；**不问 REACH 里有没有件**）、"
         "帧冻住而册子算不出该不该动、过关那一步，一律返回 NA，把兜底留给 budget_step_cost。"
         "9 个关卡（0..8，来自 meta.win_levels=9）在这批语料里全部至少出现过一条简单点击，"
         "GROUP1（v2>=2 时扣 1 格）与 GROUP2（扣 2 格）两张表是穷举出来的，不是外推。")
NOTE = ("探针 probe_budget_law.py（runs/su15-0916-1554/）先把全部去重语料的简单点击摊开："
        "把『点击前剩余色0格数』(budget_before) 拆成偶/奇试过 level、landing_on_piece、merged、"
        "num_near、near_tiers、num_pieces、num_movers、num_diamonds、click_idx_in_level（及其奇偶）、"
        "prev_cost、budget_before 本身、budget_before 奇偶、frame_diff_cells、dist_nearest 十四个单特征，"
        "没有一个零重叠——除了一个：budget_before 奇偶，扣2组 100% 是偶数（258/258），扣1组奇偶各半。"
        "顺着这条往下追（probe_budget_law3.py）：把 budget_before 换成 2-adic 赋值 v2（末尾连续 0 的个数），"
        "v2==0（奇数）76/76 全扣1，v2==1（≡2 mod4）162/162 全扣2——这两档合计 238/413 零例外。"
        "v2>=2 的 175 条本身对 v2 继续往下拆（mod8/mod16）不再收敛，均是接近对半的混合，"
        "说明『扣几格只由 budget_before 的二进制位决定』这条思路到这里就到头了，不能再往深挖。"
        "probe_budget_law4.py 转而在这 175 条上试组合特征：(v2,level) 是唯一零重叠的组合——"
        "每一关在 v2>=2 这一档内部纯一色（要么全扣1要么全扣2），9 个关卡分成两组：GROUP1={2,3,7,8} 扣1、"
        "GROUP2={0,1,4,5,6} 扣2，175/175 零例外。probe_budget_law5.py 试图把这张关卡表换成读帧算得出的"
        "样板特征（n_samples、cap_total、cap_total mod4、tiers、max_tier、n_creatures）代替硬编关卡号——"
        "全部有重叠（例如 level3 与 level1/4/5 样板一样都是单个4级件、cap_total=8，但前者属于 GROUP1"
        "后者属于 GROUP2），没有找到能替代关卡号的帧内特征，只能承认这张表目前就是硬编的两个关卡集合。"
        "对全量 413 条简单点击核对『v2==0→1，v2==1→2，v2>=2→按关卡查表』：0 例外。"
        "**已知的洞**：GROUP1/GROUP2 是穷举 9 个关卡后得到的表，不是从关卡数字或样板特征推出的规律——"
        "如果这局以后开出第 10 个关卡，这张表当场失效，届时必须先把新关卡的简单点击摊开确认属于哪一组，"
        "不能顺着 2/3/7/8 或 0/1/4/5/6 的项数/奇偶去外推。"
        "另外这条概念不认领『驳回』『过关』『非棋盘点击』三类——那三类扣几格由 budget_step_cost 的 NOTE 记着，"
        "这里不重复。"
        "v2: 死于 2976b42a461cdd67——一次 REACH 内一件都没有的空地点击被世界整条驳回，扣了 14 格。"
        "垮的不是那张 (v2, level) 表，是 _rejected 里那句『REACH 内有件』："
        "点到件不是整条驳回的必要条件，于是这一条驳回从排除口漏了进来，被当成简单点击去查表。"
        "本版把 _rejected 换成 _lib.world_refused（帧冻住 + 册子说本该有东西挪窝，不问 REACH），"
        "算不出该不该动时也闭嘴。那张表本身在这条转移上没有被检验。")
EVIDENCE = [
    "33e363251c50f64f", "9e7d9464ad2c6a4c", "720d4f9031bb562d",   # v2==0，扣1
    "d216fa4736c23574", "c26e907db2e8d46d", "363bfa92ce80ecff",   # v2==1，扣2
    "ccebc3c4c4b0b628", "1c29050373a14018", "2e8df25f300d1f88",   # v2>=2，GROUP1（关2），扣1
    "d721b9982492084b", "9b50d95cf121f213", "b9701d7da52ee051",   # v2>=2，GROUP2（关0），扣2
    "2976b42a461cdd67",                                          # v2 的死因：空地点击照样被整条驳回
]

from _lib import (click_xy, after_click, pieces, piece_cells, in_reach, will_level_up,
                  world_refused,
                  TOP_BAND_LAST_ROW, BUDGET_ROW, BG)

GROUP1_LEVELS = {2, 3, 7, 8}   # v2>=2 时扣 1 格的关卡；其余（0,1,4,5,6）扣 2 格


def _zeros(row):
    return [c for c in range(len(row)) if row[c] == 0]


def _v2(n):
    """n 的 2-adic 赋值：末尾连续 0 的个数。n<=0 没意义，调用处保证 n>=1。"""
    c = 0
    while n % 2 == 0:
        n //= 2
        c += 1
    return c


def _cost(budget_before, level):
    """按本概念的规律推算这一步该扣几格；level 是这一步开始时的关卡号。budget_before<=0 返回 None。"""
    if budget_before <= 0:
        return None
    v = _v2(budget_before)
    if v == 0:
        return 1
    if v == 1:
        return 2
    return 1 if level in GROUP1_LEVELS else 2


def _is_board_click(action):
    if action == "RESET":
        return None
    xy = click_xy(action)
    if xy is None:
        return False
    return TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def _rejected(prev, action, nxt):
    """世界整条驳回了这次点击：帧除第 63 行外一格不变，而册子算出来本该有东西挪窝。
    代价不是局面的函数（budget_step_cost NOTE v7/v9），本概念对这一档也闭嘴；
    算不出该不该动时同样闭嘴。**不问 REACH 里有没有件**——见 NOTE v2。"""
    return world_refused(prev, action, nxt) is not False


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    board = _is_board_click(action)
    if not board:
        return "NA"
    if after_click(prev, action) is None:
        return "NA"
    if _rejected(prev, action, nxt):
        return "NA"
    level = ctx.get("level_prev") if ctx else None
    if level is None:
        return "NA"
    z_p = _zeros(prev[BUDGET_ROW])
    want = _cost(len(z_p), level)
    if want is None:
        return "NA"
    z_n = _zeros(nxt[BUDGET_ROW])
    return "TRUE" if len(z_p) - len(z_n) == want else "FALSE"


def apply(prev, action, ctx=None):
    if not _is_board_click(action):
        return None
    ps2 = after_click(prev, action)
    if ps2 is None:
        return None
    if will_level_up(prev, action):
        return None                     # 过关那一步整条预算条换新，本概念说不出
    level = ctx.get("level_prev") if ctx else None
    if level is None:
        return None
    z_p = _zeros(prev[BUDGET_ROW])
    k = _cost(len(z_p), level)
    if k is None or k > len(z_p):
        return None
    out = {}
    for c in z_p[-k:]:
        if any(cell == (BUDGET_ROW, c) for p in ps2 for cell in piece_cells(p)):
            continue                    # 吃掉之后露出的是件的颜色，归 pieces_merge_at_click
        out[(BUDGET_ROW, c)] = BG
    return out or None
