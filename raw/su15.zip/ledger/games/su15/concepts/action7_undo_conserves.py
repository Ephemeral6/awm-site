"""ACTION7 把局面回退一步：第 63 行一格不变（不扣也不退），件的总容量只增不减，每个色7 追猎者各自是 prev 里某个追猎者的同形状平移（个数不变）；若它把判死撤回（prev 无样板而 nxt 有），nxt 的容量必然够得上 nxt 的需求。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7；换关返回 NA；只断言四件事：第 63 行逐格相同、件总容量不减、"
         "nxt 的每个色7 追猎者都是 prev 里某个追猎者的平移且追猎者个数不变、判死被撤回时容量≥需求。"
         "追猎者那一条按**补全后的**块比：色7 块被件盖掉几格时，用同帧完整块的形状把它补回来"
         "（补出来的缺格必须正被件盖着）；两帧里一个完整块都没有、或某块的补法不唯一，**只跳过这一条**，其余三条照判。"
         "『回到上一步之前的局面』本身在 (prev, action, nxt) 里写不出来——概念看不到再上一帧——所以只押可核对的后果")
NOTE = ("v1: 第 91 步（aaac7cb99fa79829）第一次按 ACTION7：第 90 步合成的 3×3 拆回两个 2×2、落回原位，色7 退回上一位置，"
        "第 63 行一格没动（不扣也不退）。这像是撤销。"
        "v2: 死于 05d8d4d185c2cb95——再撤一步，容量 7→8：被色7 毁掉的那个 2×2 回来了，顶带样板从色2 变回色11，"
        "被判死的一关**被撤销救活**。所以容量不是不变而是不减；这条概念改成押『只增不减』，并加一句判死撤回时容量够得上需求。"
        "代价只有一样：预算不退还。这意味着色7 杀件不是死局——一次免费撤销就能重来。"
        "v3: 死于 d640f0a161f1aa36 / 77b206283f94ad16——第 4 关有两个追猎者，撤销时各退各的（左 Δ(−4,+4)、右 Δ(−4,0) 之类），"
        "色7 格集合不再是一个整体平移。改成逐个追猎者核对：每块都是 prev 里某块的同形状平移、块数不变。"
        "顺带记一件事：第 106 步是无效点击（棋盘没动、只扣 4 格），紧接着的两次 ACTION7 退回到了第 103 步之后的局面——"
        "无效点击不算一步，撤销跳过它。这条概念看不到，只记在这里。"
        "v4: 死于 9a1d0f355bf8a2a5——第 7 关连撤五步时，撤掉那一次捕获的这一步：nxt 里第三块色7 只剩 7 格，"
        "缺的 (27,27) 正被撤回来的那块 6 级 7×7（行24-30 列27-33）盖着。**件画在追猎者上面**，所以这不是追猎者变了形，"
        "是这个概念的读法不完整——它把遮挡读成了违约。改成先补全再比：拿同帧完整块的形状去套残块，"
        "补出来的缺格必须正被件盖着，补法唯一才算数。补不全（补法有歧义 / 两帧一个完整块都没有）就跳过这一条，"
        "另外三条照判——**跳过不是判对**。这一条同时把『追猎者是刚体、只平移』变成了可判错的东西："
        "残块套不进任何已知形状，就是真的变形了。"
        "教训与 mover_captures_piece v2 同源：这一局所有『追猎者怎么了』的读数都得先过遮挡这一关，"
        "而遮挡只在追猎者压到件上时发生——那正是最要紧的那几步。")
EVIDENCE = ["aaac7cb99fa79829", "05d8d4d185c2cb95", "d640f0a161f1aa36", "77b206283f94ad16", "9a1d0f355bf8a2a5"]

from geo import cells_of
from _lib import pieces, piece_cells, samples, capacity, movers, BUDGET_ROW, TOP_BAND_LAST_ROW

MOVER_COLOR = 7
MOVER_CELLS = 8          # 一个完整追猎者的格数（箭头形，8-邻接一块）；比这少就是被件盖掉了几格


def _shape(obj):
    r0 = min(r for r, _ in obj)
    c0 = min(c for _, c in obj)
    return frozenset((r - r0, c - c0) for r, c in obj)


def _cap(g):
    return sum(capacity(t) for t, _, _ in pieces(g))


def _need(g):
    return sum(capacity(t) for t, _, _ in samples(g))


def _mover(g):
    return frozenset((r, c) for r, c in cells_of(g, MOVER_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW)


def _fits(block, shapes, covered):
    """这块残缺的色7 能补成哪些完整追猎者：block ⊆ 形状的某个平移，且补出来的缺格全被件盖着。"""
    out = set()
    r0 = min(r for r, _ in block); c0 = min(c for _, c in block)
    for s in shapes:
        for ar, ac in s:
            t = frozenset((r + r0 - ar, c + c0 - ac) for r, c in s)
            if block <= t and all(cell in covered for cell in t - block):
                out.add(t)
    return out


def _hunters(g, shapes):
    """把帧上的色7 补成一组完整追猎者；有一块补不出唯一解就返回 None（这一条跳过）。"""
    covered = {cell for p in pieces(g) for cell in piece_cells(p)}
    out = []
    for b in movers(_mover(g)):
        cands = _fits(frozenset(b), shapes, covered)
        if len(cands) != 1:
            return None
        out.append(next(iter(cands)))
    return list(dict.fromkeys(out))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != "ACTION7":
        return "NA"
    if list(nxt[BUDGET_ROW]) != list(prev[BUDGET_ROW]):
        return "FALSE"
    if _cap(nxt) < _cap(prev):
        return "FALSE"
    if not samples(prev) and samples(nxt) and _cap(nxt) < _need(nxt):
        return "FALSE"
    a, b = _mover(prev), _mover(nxt)
    if a:
        shapes = {_shape(o) for g in (prev, nxt) for o in movers(_mover(g)) if len(o) == MOVER_CELLS}
        if shapes:
            oa, ob = _hunters(prev, shapes), _hunters(nxt, shapes)
            if oa is not None and ob is not None:
                if len(oa) != len(ob):
                    return "FALSE"
                sa = [_shape(o) for o in oa]
                if any(_shape(o) not in sa for o in ob):
                    return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if action != "ACTION7":
        return None
    return {(BUDGET_ROW, c): prev[BUDGET_ROW][c] for c in range(len(prev[BUDGET_ROW]))}
