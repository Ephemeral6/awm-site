"""被追猎者降级的那件不是原地降级：它沿「捕获者落点重心 → 件心」的方向被甩开 10 格（撞到棋盘边就夹住）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6:x,y 且 10<=y<63；换关返回 NA；prev 或 nxt 里没有色7 格返回 NA；"
         "点击后的件清单算不出来（after_click 返回 None）或为空返回 NA；"
         "**世界整条驳回了这次点击（除第 63 行预算条外整帧一格不变）返回 NA**——那一步谁也没动，"
         "捕获没发生（与 mover_captures_piece 的 NOTE v6 同一道界）；"
         "**模型认为这一步没有捕获时返回 NA**——「捕不捕得到」是 mover_captures_piece 的主张，不是这一条的；"
         "**量化方向是 (0,0)、或有分量的绝对值恰好是 1 时返回 NA**（capture_fling 返回 None，见 NOTE）；"
         "**捕获者的落点撞上同色另一只时返回 NA**（capture_results 返回 None，见 NOTE v4）；"
         "只断言**落点**，不断言「捕获会不会发生」，也不断言被降级的件之外的任何格子")
NOTE = ("v1: mover_captures_piece 的 NOTE 里写着「新件落在哪不在主张内（三次落点各不相同）」，"
        "这条补的就是那个缺口。三次变成十九次，靠的是换筛子而不是换世界："
        "旧筛子要求「恰好一件消失、恰好一件出现」，而捕获几乎总是和这一 click 搬走的那件同一步发生，"
        "于是十九条里有十五条被自己的筛子滤掉了。改成拿 after_click 的**预期件清单**当底再比，"
        "click 的效果被底扣掉，剩下的差就是捕获干的（probe_capture_landing2.py：19 条，旧法 4 条）。"
        "十九条的位移模长分布 [(1.41,1),(3.0,1),(4.0,1),(5.1,1),(7.81,2),(9.49,1),(9.85,1),(9.9,1),(10.0,10)]——"
        "十条正好 10.0，三条贴着 10，其余都能用夹边解释。10 是从这十九条量出来的，不是我挑的数。"
        "**v2 改的只有措辞**：v1 这里写的是「册子里已有 POUNCE_CDIST=10.0」，拿扑的阈值给甩的距离背书。"
        "那是个巧合——两个 10.0 各有各的来路，互不相干；而 POUNCE_CDIST 已在第 509 步被打死、退出判据。"
        "真让它们共用一个名字，日后调扑的阈值会把甩的距离一起悄悄挪走。本条的 10 只由上面那十九条位移撑着。"
        "方向锚点找了两轮。第一轮全错（第158/178/200/207 的误差是整十级别），"
        "原因是挑捕获者时漏了 captured_pieces 自己那条「落点要真压上去」的条件，"
        "于是隔着半个盘遥遥瞄准的那只被当成了捕获者（probe_fling10.py 第一版）。"
        "补上之后反过来求方向（probe_fling_dir.py：把观测位移当基准，回头找帧上与它同向的锚点），"
        "「色7 里最同向的那只」19 条中 17 条夹角不超过 30 度，其余锚点（这一 click 的落点、刚落下的新件、色14）全散。"
        "最后扫 2 锚点 × 3 基准 × 4 取整 × 量化与否共 48 组（probe_fling10.out），"
        "只有「落点重心 / 基准左上角 / 半数朝上 / 方向先量化」这一组到 13/15，别的最好 5/15。"
        "**方向必须先量化**这一步不是旋钮：capture_landing 自己算 dr/dc 时就先 _round 成整数再走，这里是抄它。"
        "基准必须是左上角而不是件心：两件边长不同，件心不是能平移的那个点（同一个教训在 probe_birth_offset 上已经吃过一次）。"
        "**NA 那一档是看了两条反例之后划的，照实记在这里**（probe_fling_edge.out）："
        "第178步 量化方向(-1,-5) 差(2,0)、第192步 量化方向(1,4) 差(-2,0)，两条都是纯行向差 2；"
        "而对上的十三条里，量化方向的分量是 0,±2,±3,±4,±5，**没有一条出现过 ±1**。"
        "划这道界的理由不止「那两条在界外」：分量量化成 1 时原始差值在 [0.5,1.5) 之间，"
        "归一乘 10 之后落点差着整整一格，模型本来就分不清 (0,±10) 和 (∓2,±10)。所以这一档判 NA 而不是判对。"
        "还有四条（第105/147/158/197 步）模型根本挑不出捕获者——那是 mover_captures_piece 的开口问题，"
        "本条在「模型说没有捕获」时闭嘴，不替它背这个账。"
        "v1 补记（只加 NOTE，断言与 apply 一字未改）：**`apply` 比 `assert_` 少一道闸，而这道闸补不上。**"
        "`assert_` 里「世界整条驳回就闭嘴」那一条要读 `nxt` 才判得出，`apply` 只有 `prev` 和动作。"
        "驳回判不判得出来，是一个已经量过的负结果（见 click_two_tiers_refused 的 NOTE v2："
        "26 个特征二值化成 264 条判据、1~3 元合取里零条分得开），所以这不是「还没写」，是**写不出来**。"
        "后果照实记：世界驳回的那些步（语料里 REACH 内一件的点击 103 次里 12 次）"
        "`apply` 照样会画出被降级的新件，逐格对答案时那几格全错——第 173 步 P=0.000 就是这么来的。"
        "终局卡上这反而是好事：预测错一格就停批（退出码 5），正好停在世界驳回的那一步，"
        "规划器接着把那条边记进死边账绕开（见 runs/<run>/plan.py）。"
        "`apply` 别为了把 P 做好看而去猜驳回——那等于把一条没走过闸的世界事实塞进生成器。"
        "v3→v4: 死于 8220997797af76a7（第 574 步），和 mover_captures_piece v8 同一步、同一个破口："
        "capture_results 挑出的捕获者 h0 按模型压上 6 级件 (6,22,14)，本条算它该甩到 (5,22,4)；"
        "帧上 6 级件一格没动——h0 和追同一件的 h2 落点相撞，并成了一只色14，咬根本没发生。"
        "同一步真被降级的是那件刚搬来的新件 (5,41,5)→(4,40,0)，模型（新件豁免）没把它当捕获，"
        "所以本条对它本来就闭嘴；它左上角挪了 (-1,-5)，和 10 格甩不像，可捕获者是谁都挑不出，"
        "这一条不进本条的分母，照实记在这里等下一条同类观测。"
        "改法在共用的词：_lib.colliding_hunters 划出「撞」这一档，capture_results 遇上撞了的捕获者返回 None，"
        "本条原有的「落点说不出返回 NA」那一行接住它。撞了是并还是咬语料分不出（3/4，"
        "见 mover_captures_piece NOTE v8），所以是 NA 不是规则。主张一个字没改。")
EVIDENCE = ["a8573ce41bed5fd8", "2f8864ee29041099", "cc66821f33a01c2e", "1daa73845b1d672d",
            "5051ca19350e3958", "9f69a0fa4c7fe868", "ea35b8c4036c3abd", "b503ce3bb31b876f",
            "16ec5df9f176d780", "831f48174bd3597f", "6a06d57b280f31fc", "0454bfe50a9a58ec",
            "1e8e55a0a15b981b", "4684c139bd72c11b", "c09968087b7b08e9", "8220997797af76a7"]

from _lib import (BUDGET_ROW, COLOR_OF_TIER, TOP_BAND_LAST_ROW, after_click, capture_results,
                  click_xy, mover, piece_cells, pieces)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return "NA"
    if mover(prev) is None or mover(nxt) is None:
        return "NA"
    if all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW):
        return "NA"                     # 世界整条驳回：谁也没动，捕获没发生
    ps = after_click(prev, action)
    if not ps:
        return "NA"
    res = capture_results(prev, action)
    if res is None or not res:
        return "NA"                     # 落点说不出，或模型认为这一步没捕获
    ps_nxt = pieces(nxt)
    for old, new in res:
        if old in ps_nxt:
            return "FALSE"              # 压上去了却没降级（那是 mover_captures_piece 的事，但这里也不能装作对）
        if new not in ps_nxt:
            return "FALSE"              # 降级了，可没落在算出来的地方
    return "TRUE"


def apply(prev, action, ctx=None):
    """只填被降级的那件：旧件的格子还原成底色由别人管，这里只画新件坐落的那些格。"""
    res = capture_results(prev, action)
    if not res:
        return None
    out = {}
    for _old, new in res:
        for r, c in piece_cells(new):
            if TOP_BAND_LAST_ROW < r <= BUDGET_ROW:
                out[(r, c)] = COLOR_OF_TIER[new[0]]
    return out or None
