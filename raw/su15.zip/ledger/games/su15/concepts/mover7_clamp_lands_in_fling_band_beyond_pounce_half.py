"""这一 click 里，一只色7 盯着的是本 click 刚搬来/合出的新件、它到全体新件的最小 piece_gap 不超过 REACH
（落在影子概念划的「甩飞档」里）、而这一 click 不是两件合成、且它的归一化重心距 pounce_hdist 超过
POUNCE_HALF 时，clamp 落点（逐轴 floor(diff+0.5) 夹到 ±MOVER_STEP、逐子步碰件即停、出帧整块塞回）
整块出现在下一帧的色7 格里。"""
LEVEL = "L6"
SCOPE = ("前提与 mover7_clamp_lands_when_target_fresh_and_far._setup 完全同一套（自己独立重算，不 import 那个模块）："
         "只看世界接受了的棋盘点击（ACTION6 且 10<y<63）；换关（ctx.level_prev != ctx.level_next，"
         "ctx 的两个键分别接 meta 的 level_prev 与 level——meta 本身没有 level_next 这个键，"
         "直接把 meta 塞给 ctx 会让 level_next 恒为 None、把全部转移误判成换关）、世界整条驳回"
         "（除第 63 行外整帧不变）返回 NA；prev 上没有色7、没有件、after_click 说不出、hunters(prev) 说不出"
         "（色14 块读不准）、这一 click 有任何捕猎者的 clamp 落点压在点击后的件上（ANYCAP）、"
         "这一 click 没有新件，一律整条 NA；nxt 上没有色7 也 NA。\n"
         "**这一 click 是合成（点击点 REACH 内恰好两件同级、按 pieces_merge_at_click 会并成高一级）整条 NA**："
         "合成的两只样本（a6510b83e3280092 第 314 步、a78e3030fe57a0d2 第 396 步）都在阈值以上却落空，"
         "是这道闸唯一的由来，分母只有 2，写明在 NOTE 里。\n"
         "**逐只开口**，当且仅当：（1）认身份目标是这一 click 的新件（FRESHTGT）；（2）mover_target_ambiguous 为假；"
         "（3）认身份目标与「点击后最近」目标是同一件（不 DOUBT）；（4）这一只到点击点最近格的欧氏距离超过 REACH"
         "（不 NEARCLK）；（5）它到**全体**新件的最小 piece_gap **不超过** REACH —— 也就是**落在甩飞档内**，"
         "这正好是 mover7_clamp_lands_when_target_fresh_and_far 整档排除、而 mover7_clamp_far_from_click_no_capture "
         "用 FRESHTGT 关着嘴的那一片，两条现有概念都不在这里说话；（6）它的落点与另一只色7 的落点切比雪夫间隔超过 2"
         "（不 MERGE，读法抄自 movers_merge_on_immune_piece 的 _NEAR）；"
         "（7）**pounce_hdist(这一只, 目标件) > POUNCE_HALF**（8.14，_lib 里给色14 定的那个常量，不是本条新拟的阈值）。"
         "一只都没开口 → NA。\n"
         "**assert_ 是转移粒度**：一条转移里只要有一只开口就数进分母；任意一只开口的落点没有整块出现在 nxt 的色7 格里"
         "就整条 FALSE。")
NOTE = ("v2（只改 apply，assert_ 一个字没动，所以 S/C/N 应当逐位不变）：删掉 apply 里「猎手让出来的格子变回"
        "底色/八边形色」那一句。由来是第 746 步 ACTION6:17,25（tid 385619732b6a23e2，**这条 tid 本来就在"
        "下面的 EVIDENCE 里、assert_ 判它 TRUE**）：终局卡上逐格对答案，错的两格正是这一只让出来的格子，"
        "下一帧它们仍是色7。assert_ 查的是 `lands[obj] <= mover(nxt)`——**子集**，不是等号；"
        "真落点比算出来的 clamp 落点大一圈时它照样判 TRUE，而 apply 那一句已经在说假话了。"
        "教训记这里：一条概念的 assert_ 用子集判，apply 就不许用等号的口气去填它没主张的格子。"
        "这一刀让 P 的分子变小，不是让它变准——它本来就不该报那些格子。\n"
        "v1（子 agent 离线量出来的片段：只读了 _lib 与 mover7_clamp_lands_when_target_fresh_and_far 的 NOTE/SCOPE，"
        "没读主 agent 的推理、没读别的探针输出）。任务是问「甩飞档能不能用**事前判据**切开」。\n"
        "**先说分母口径**：语料是活的、边打边涨（探针一跑时 759 行 / 去重 578 条转移，探针二 760 / 579，"
        "探针三首跑 761 / 580、复跑 762 / 581），下面每个读数都标明是哪一次跑的。"
        "甩飞档 = FRESHTGT 且 min_fresh_gap<=REACH，逐只计数、tid 去重。\n"
        "**主口径总体（STRICT）**：影子概念 probe_freshtgt_only 的同一套闸（AMBIG/DOUBT/NEARCLK/MERGE 全假、"
        "转移不 ANYCAP），不过滤换关。它现在是 **17 只、clamp 命中 9 只（52.9%）**（影子概念记的是 15 只中 7，"
        "差在语料变大，不是口径不同）。因为总命中只有 9 只，「一边命中率>=90% 且 n>=8」在这个总体上"
        "几乎等于**要求一条完美分界**。\n"
        "**结论：切开了，用 pounce_hdist（重心到件心距离减掉件的半边长）+ 非合成这两条**"
        "（runs/su15-0916-1554/probe_76x_flingband_search.out、probe_76x_concept_check.out）：\n"
        "  · hdist > 8.14 且非合成：**n=8，clamp 全中 8/8（100%）**；\n"
        "  · 其余 9 只：clamp 只中 1/9（11.1%），那 1 只是 95ccc0d875082bff（第 114 步，hdist 7.870）。\n"
        "  阈值**不是拟合出来的**：搜索给出的窗口是 (8.007, 8.248]（下边是落空的 f7f684ee17403e37 第 394 步 8.007，"
        "上边是命中的 a0b94bd040a140f3 第 151 步 8.248），而 _lib 里早就有一个独立来历的常量 POUNCE_HALF=8.14 "
        "正好落在这个窗口里——那是色14「扑」的阈值，由 probe_511norm 在色14 那一批数据上定的，和本条的数据无关。"
        "本条直接用它，不另立新数。\n"
        "**机制上的猜测（是猜测，不是读数）**：色14 在 hdist<=8.14 时不走 clamp 而是扑；色7 在同一个量、同一个阈值以下"
        "也不走 clamp（走的是别的什么——见下面落空的样子）。也就是说这个归一化距离可能是**两色共用**的近身开关，"
        "只是两色近身之后干的事不同。**这条猜测没有被本条验证**：本条只断言阈值以上 clamp 准，阈值以下它闭嘴。\n"
        "**阈值以下那 8 只落空的样子（实际位移，probe_76x_concept_check.out 的 STRICT 闭嘴侧逐只）**："
        "77104a652ac235d8(177) Δ(-2,-4) 只比 clamp 差 1 行；431e825fb86f2034(319) Δ(+21,+8)；"
        "f7f684ee17403e37(394) Δ(-9,-4)；b6b86a1426e76050(489) Δ(+0,+15)；040da1ea36b431e8(503) Δ(-30,+14)；"
        "6839e1036247ded5(565) 在 nxt 上找不到与它同形的色7 块（并掉或被盖住了）；"
        "加上两只合成的 a6510b83e3280092(314) Δ(-12,+8)、a78e3030fe57a0d2(396) Δ(-4,+38)。"
        "位移远超 MOVER_STEP 的确实占多数（8 只里 5 只 |Δ|>=9），但**不是全部**——177 只差 1 行、"
        "565 根本找不到块，所以「阈值以下一律穿过去」这句话本条**不敢说**，它只说「阈值以下 clamp 不可信」。\n"
        "**交办时给的那条待验猜想（clamp 落点压在新鲜目标件上就穿过去，压不到就老实停）：在主口径上无法被检验，"
        "在参考口径上单向成立但过不了门槛**——\n"
        "  · STRICT 17 只里『clamp 落点压到目标件』一只都没有（恒为假）：因为 _setup 的 ANYCAP 那道闸"
        "（任一捕猎者落点压在点击后的件上就整条排除）已经先把这类转移整条剔掉了。所以这条猜想在主口径里"
        "**切不出两边**，不是被证伪，是量不到。\n"
        "  · 放掉五道闸的参考口径 POP_WIDE（探针一那次 95 只）里它有取值：压到任何件的 50 只 clamp "
        "**命中 0/50（0%）**，没压到的 45 只命中 16/45（35.6%）。方向与猜想一致（压上去就不按 clamp 停），"
        "但硬门槛要的是「一边命中率>=90%」，0% 那一边是『一律不准』不是『一律准』，**不达标**。\n"
        "  · 顺带：第 734 步 f8fef9b4af105660（交办时点名的那条新观测）本条判命中，clamp 落点 行51-54 列48-52、"
        "实际 Δ(+0,+4)，与交办描述逐格对得上——它的 hdist 是 8.501，在阈值以上，属于本条开口并说中的那一档。\n"
        "**其余候选各自的切分效果（STRICT，全部如实报，probe_76x_flingband_split.out 的 POP_STRICT 段，"
        "那次跑是 16 只中 8）**：落点出帧 0 只（恒假，切不动）；途中碰件停 0 只（恒假，ANYCAP 的缘故）；"
        "目标件的级最好一刀 tier>4.5：10 只中 6（60%）；边长同；"
        "行轴间隔 sep_r>1.5：9 只中 5（55.6%）；列轴间隔 sep_c>4.5：9 只中 5（55.6%）；"
        "原始行差 |dr|>5.009：9 只中 5（55.6%）；原始列差 |dc|>7.75：9 只中 5（55.6%）；"
        "到点击点距离 clkdist>8.742：10 只中 8（80%，差 1 只到门槛，它放进来的两只落空是 177 与 314）；"
        "合成 2 只中 0（单用它切不开，它只当副闸）；场上有色14：3 只中 2 / 无色14 13 只中 6；"
        "色7 只数最好一刀 nmover>1.5：10 只中 5（50%）；目标是不是『点击后最近』那件：STRICT 里恒为真"
        "（DOUBT 已被闸掉，切不动）；min_fresh_gap 最好一刀 gap>6.556：8 只中 6（75%）；换关 2 只中 0。"
        "**单独一个候选没有一个过门槛。**\n"
        "**过拟合的账要摊开**：深度 1~3 的合取搜索在 STRICT 上试了 540422 条判据（去重后判据池 148 条），"
        "**有 155 条达标**——17 个点、9 中 9 空，凑得出完美分界的组合本来就多，所以『它达标』本身不是证据。"
        "本条挑这一条的理由只有两个，都写死在这里：（a）阈值用的是别处独立定下的常量 POUNCE_HALF，本条没有自由参数；"
        "（b）合成与否是交办时预注册的候选之一，不是搜出来的新特征。别的达标判据（比如 cdist>10.54、"
        "nmover<=3.5、npieces<=2.5 这一类）要么阈值是现场拟合的、要么用的是与落点机制无关的场面计数，这里不采。\n"
        "**稳健性，报坏的那一面**：（i）达标那一边 n 正好等于门槛 8，**留一法 17 次里有 8 次掉出门槛**"
        "（掉的全是『样本从 8 减到 7』这一种，不是命中率掉下去——8 只里任何一只被剔掉，剩下 7/7 仍是 100%）；"
        "（ii）同一条判据拿到参考口径 POP_WIDE 上重算是 **n=20 中16（80%）**，过不了门槛——"
        "WIDE 里混着捕获、近点击、并体那些本来就不该用 clamp 的只，本条不主张它们，但这个 80% 如实记在这里；"
        "（iii）合成那道副闸只有 2 只样本。\n"
        "**预先写明怎么算打死本条**：阈值以上、非合成、其余闸全假的一只色7，clamp 落点没整块出现在 nxt 的色7 格里——"
        "那就是一条真反例。若它的 hdist 落在 (8.007, 8.248] 这个窗口附近，不许把阈值往上削去救——"
        "窗口只有 0.24 宽，削一次就成了拟合；该换的是『近身开关由这个距离决定』这个假设本身"
        "（色14 那一侧已经因为同样的事换过两次量法，见 _lib 里 pounces 的注释块）。\n"
        "**assert_ 在全语料上真跑过两次**（runs/su15-0916-1554/probe_76x_concept_check.py + .out，ctx 按 SCOPE 说的拼）："
        "首跑 761 行 / 去重 580 条转移 → **TRUE 8 / FALSE 0 / NA 572**；"
        "复跑（语料又长了一条）762 行 / 去重 581 条 → **TRUE 8 / FALSE 0 / NA 573**；"
        "两次 TRUE 是同样那 8 个 tid，.out 里留的是复跑那一次。\n"
        "**零反例不等于说对了很多，四格摊开（复跑口径）**：说中 8（开口侧 8 只全中，转移粒度也是 8 条）；误报 0；"
        "漏报 1（95ccc0d875082bff 第 114 步 hdist 7.870，clamp 其实是对的，本条闭嘴）；"
        "对甩飞档里落空的 8 只一律闭嘴（那是它活下来的方式，不是它说对了）；其余 573 条转移全 NA。"
        "这条概念的价值只在『原先整档 17 只 52.9%（近掷硬币）里切出 8 只 100%』这一件事上，"
        "别把 FALSE=0 读成它覆盖面广。\n"
        "**同一刀在别的口径上的读数（一起记，别只报赢的，复跑那次）**：STRICT 非换关 15 只——开口侧 8/8，"
        "闭嘴侧 7 只中 1；POP_WIDE 97 只——开口侧 20 只中 16（80%，不达标），闭嘴侧 77 只中 1（1.3%）。\n"
        "**与两条已有 proposals 不重叠（只据影子概念 NOTE 里转述的它们的口径，没读它们的正文）**："
        "mover7_pressed_through_side_step 管 PRESS_GAP<=4.0 那一小片，本条开口的 8 只 gap 是"
        "6.403/8.0/7.810/7.810/6.708/7.0/7.0/8.0，全在 4.0 以外；mover7_leaps_through_fresh_target_when_noclip "
        "靠 NOCLIP 纯主轴落点筛、用的是 3×MOVER_STEP 平移公式，本条用的是 clamp 公式，主张的东西不是一回事。")
EVIDENCE = [
    # 开口且说中（assert_ 判 TRUE 的转移，逐条核对过 probe_76x_concept_check.out 的 (C) 段）
    "a0b94bd040a140f3", "8173635efdb4a09e", "473796f1865f6cac", "807f327c4355358b",
    "07397755741a313e", "385619732b6a23e2", "f8fef9b4af105660", "2016befd7889e1a5",
    # 甩飞档里 clamp 落空的那些：本条**判 NA**（被 hdist 闸或合成闸挡在开口之外），
    # 列在这里是为了把这条概念靠什么活下来说清楚——它们正是不收的那一侧。
    "77104a652ac235d8", "431e825fb86f2034", "f7f684ee17403e37", "b6b86a1426e76050",
    "040da1ea36b431e8", "6839e1036247ded5", "a6510b83e3280092", "a78e3030fe57a0d2",
    # 甩飞档里 clamp 命中、但落在阈值以下、本条同样闭嘴的那一只（漏报，照实列，assert_ 判 NA）
    "95ccc0d875082bff",
]

from _lib import (TOP_BAND_LAST_ROW, BUDGET_ROW, BG, COLOR_OF_TIER, MOVER_COLOR, OCT_COLOR,
                  POUNCE_HALF, REACH, after_click, capture_landing, click_xy, hunters, in_reach,
                  mover, movers, mover_target, mover_target_ambiguous, octagons, pieces,
                  piece_cells, piece_gap, pounce_hdist, will_level_up)

_NEAR = 2          # 抄自 movers_merge_on_immune_piece 的同名常量，不是本条自拟的阈值


def _board_click(action):
    xy = click_xy(action)
    return xy is not None and TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def _refused(prev, nxt):
    return all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW)


def _is_merge_click(prev, action):
    """这一 click 是不是两件同级并成高一级（pieces_merge_at_click 的那一档）。"""
    xy = click_xy(action)
    if xy is None:
        return False
    x, y = xy
    near = [p for p in pieces(prev) if in_reach(p, x, y)]
    return (len(near) == 2 and near[0][0] == near[1][0]
            and near[0][0] + 1 in COLOR_OF_TIER)


def _setup(prev, action):
    if not _board_click(action):
        return None
    a = mover(prev)
    if a is None:
        return None
    ps_prev = list(pieces(prev))
    if not ps_prev:
        return None
    ps = after_click(prev, action)
    if not ps:
        return None
    hs = hunters(prev)
    if hs is None:
        return None
    occupied = {cell for p in ps for cell in piece_cells(p)}
    shape = (len(prev), len(prev[0]))
    lands = {}
    for obj, colour, use_id in hs:
        _t, land = capture_landing(obj, ps, occupied, colour,
                                   ps_prev=ps_prev if use_id else None, shape=shape)
        if land & occupied:
            return None                                  # ANYCAP
        if colour == MOVER_COLOR:
            lands[obj] = land
    fresh = [p for p in ps if p not in ps_prev]
    if not fresh:
        return None
    return a, ps, ps_prev, occupied, fresh, lands


def _near_click(obj, action):
    x, y = click_xy(action)
    return min(((r - y) ** 2 + (c - x) ** 2) ** 0.5 for r, c in obj) <= REACH


def _merging(obj, lands):
    mine = lands.get(obj)
    if not mine:
        return False
    for other, land in lands.items():
        if other == obj or not land:
            continue
        if min(max(abs(r - rr), abs(c - cc)) for r, c in mine for rr, cc in land) <= _NEAR:
            return True
    return False


def _open(obj, ps, ps_prev, fresh, action, lands):
    if obj not in lands:
        return False
    if mover_target_ambiguous(obj, ps, ps_prev):
        return False                                     # AMBIG
    tgt = mover_target(obj, ps, ps_prev)
    if tgt is None or tgt not in fresh:
        return False                                     # 不是 FRESHTGT
    if tgt != mover_target(obj, ps, None):
        return False                                     # DOUBT
    if _near_click(obj, action):
        return False                                     # NEARCLK
    if min(piece_gap(obj, p) for p in fresh) > REACH:
        return False                                     # 不在甩飞档内：归那条姊妹概念管
    if _merging(obj, lands):
        return False                                     # MERGE
    if pounce_hdist(obj, tgt) <= POUNCE_HALF:
        return False                                     # 近身档：clamp 在这一侧只中 1/9，不主张
    return True


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _board_click(action):
        return "NA"
    if _refused(prev, nxt):
        return "NA"
    if _is_merge_click(prev, action):
        return "NA"
    s = _setup(prev, action)
    if s is None:
        return "NA"
    a, ps, ps_prev, occupied, fresh, lands = s
    b = mover(nxt)
    if b is None:
        return "NA"
    spoke = 0
    for obj in movers(a):
        if not _open(obj, ps, ps_prev, fresh, action, lands):
            continue
        spoke += 1
        if not (lands[obj] <= b):
            return "FALSE"
    return "TRUE" if spoke else "NA"


def apply(prev, action, ctx=None):
    if not _board_click(action) or _is_merge_click(prev, action) or will_level_up(prev, action):
        return None
    s = _setup(prev, action)
    if s is None:
        return None
    a, ps, ps_prev, occupied, fresh, lands = s
    keep = [obj for obj in movers(a) if _open(obj, ps, ps_prev, fresh, action, lands)]
    if not keep:
        return None
    out = {}
    for obj in keep:
        for cell in lands[obj]:
            out[cell] = MOVER_COLOR
    # v2：这里原先还顺手主张「它让出来的格子变回底色/八边形色」，第 746 步打死了那一句——
    # 让出来的两格在下一帧仍是色7。首行 docstring 只说「落点整块是色7」，没说过让出来的格子变什么；
    # assert_ 也只查 `lands[obj] <= mover(nxt)`（子集，不是等号），所以真落点比算出来的落点大一圈时
    # assert_ 照样判 TRUE，而 apply 那一句已经错了。两者差的正是「子集」和「等于」。
    # 不补一道「别的猎手会不会占这几格」的闸：占它的正是这一只自己，补不出来。整句删掉，只留落点。
    return out or None
