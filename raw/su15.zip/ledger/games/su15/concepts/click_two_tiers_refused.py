"""ACTION6 点棋盘区，REACH 内有两件而它们级别不同（合成规则说不出结果）时，世界整条驳回：除第 63 行预算条外全帧一格不变——件不搬、会动物件也不走。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6:x,y 且 10<=y<63；REACH 内不是恰好两件、或两件同级返回 NA；"
         "换关返回 NA；只断言『除第 63 行外整帧不变』这一件事，不管预算扣几格（那是 budget_step_cost 的事）")
NOTE = ("v1: 从第 106 步（18759a98b7574fbc）抽出来：ACTION6:30,16 时 REACH 里有 2 级件 (10,26) 距 5.83、"
        "3 级件 (14,35) 距 5.00，世界一格没搬、连两只追猎者都没走，只扣了 4 格预算。"
        "同一件事在 action7_undo_conserves 的 NOTE v3 里以旁注的形式记过（『无效点击不算一步，撤销跳过它』），"
        "但从来没被写成可判错的东西——现在补上。"
        "**全语料只有这一条正例**（105 次棋盘点击里，REACH 内两件的有 32 次，其中 31 次是同级、都正常合成执行了）。"
        "所以它的分母很薄，随时可能被推翻；写下来是因为规划器必须避开这类点击——它白扣预算。"
        "同一族里还有三条**没有解释的**驳回（第 165/166/167 步，REACH 内恰好一件、"
        "落点不压件不压物件不出界、离物件 4.0~6.4 格，全部被整条驳回，分别扣 2/6/8 格）："
        "已排掉的读法有『落点压在会动物件上』（第 124/155 步压了照常执行）、『点击点离物件比离件近』"
        "（第 124 步距 0.0 照常执行）、『盘上有认不出的第三件』（色格全被认领）、『时间流逝扣费』"
        "（第 163→164 步隔了 13 分钟只扣正常的 2 格）。这条概念不声称管那三步——它们在 SCOPE 外（REACH 内只有一件）。"
        "v2（只改 NOTE，断言一字未动）：把 SCOPE 外那一族**数清楚了**，结论是负的，落盘存档。"
        "全语料的驳回按『REACH 内几件』分栏（probe_refused）：点空 33 次——其中 33 次盘上一只会动物件都没有，"
        "不是驳回而是没东西可动；两件不同级 1 次，就是本条；**REACH 内恰好一件 103 次，驳回 12 次（12%）**，"
        "其中 2 次落点就是件的原位（第 14/20 步），另外 10 次集中在第 165~187 步，代价 2→6→8→11→14 一路涨。"
        "probe_refuse_feat 摊开 26 个候选特征（含件级、落点压件/压物件/出界/碰圈、盘上各色只数、"
        "点击点/件现位/落点离最近物件、件是不是某只追猎者的目标、落点压不压追猎者这一步的落点、搬的距离、件数、圈数、样板要的级），"
        "二值化成 264 条判据后穷举 1~3 元合取：**零条**能盖住全部 12 次驳回又不误伤 91 次执行。"
        "盖得最多的一条（盘上色7只数不超过 2 且 点击点离最近物件不超过 6）盖住 9/12、误伤 5/91——不够写成概念。"
        "同时也没有一对『特征全同、结论相反』的观测，所以答案未必在表外，只是这 26 个特征的 3 元以内合取说不出它。"
        "**这是负结果，不是待办**：册子现在说不出那 10 次驳回的判据，终局卡因此不靠判据躲它，"
        "改在规划器里记一条策略级的死边账（发出去键没动就绕开重算，见 runs/<run>/plan.py），那不是世界主张。")
EVIDENCE = ["18759a98b7574fbc"]

from _lib import pieces, in_reach, click_xy, BUDGET_ROW, TOP_BAND_LAST_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return "NA"
    near = [p for p in pieces(prev) if in_reach(p, xy[0], xy[1])]
    if len(near) != 2 or near[0][0] == near[1][0]:
        return "NA"
    same = all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW)
    return "TRUE" if same else "FALSE"


def apply(prev, action, ctx=None):
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return None
    near = [p for p in pieces(prev) if in_reach(p, xy[0], xy[1])]
    if len(near) != 2 or near[0][0] == near[1][0]:
        return None
    return {(r, c): prev[r][c]
            for r in range(len(prev)) if r != BUDGET_ROW
            for c in range(len(prev[0]))}
