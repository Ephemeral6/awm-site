"""预算归零时触发 GAME_OVER；预算还有余且这一步没打完最后一关时保持 NOT_FINISHED。"""
LEVEL = "L5"
SCOPE = ("所有转移；预算 = 第63行的色0格子数；"
         "**这一步 state 变成 WIN 返回 NA**——打完最后一关时预算还剩着，局面却已经结束，"
         "本概念的两条分支都管不到（见 NOTE v2）")
NOTE = ("v2: 死于 69db8a3038bbbe5e（第 214 步 ACTION6:11,42，过第 9 关，state=WIN）。"
        "那一步预算条还剩 42 格色0，v1 于是断言 state 仍是 NOT_FINISHED，而世界给的是 WIN。"
        "主张本身没错，是**漏了一种结局**：v1 写于第 0 关附近，那时局面只有「还在打」和「预算耗尽判死」两种，"
        "「打完了」从没出现过，于是被默默算进了 NOT_FINISHED 那一支。"
        "改法是把 WIN 划出去闭嘴，不是去猜 WIN 的条件——那是 levelup_when_samples_in_octagon 的活。"
        "**代价**：它对最后一步不再有话说，而全语料只有这一条 WIN。")
EVIDENCE = ["2c04ec89f25ea959", "003d82c836aaad3a", "008032f9ba32eaaf", "141122638f30e279",
            "233400a9fb5f744a", "2e1da12ac49d12f9", "2f168df85a5f3668", "363bfa92ce80ecff",
            "4194a8c545ec9ec9", "46911e79f6ffd09d", "46c865b3028f0f31", "4f18529d9285ed71",
            "5e93b02338defce0", "7622f4450dfeec33", "7735502d2f3888a1", "814f9425b33bd537",
            "8571ad9a47d3a9a1", "87ab0886ce4d836a", "88eda5856b6daf89", "99ac20eb16d1a3ef",
            "9ad1339205751f96", "9b50d95cf121f213", "9e91564de215ec53", "a3a03de0ed3fc2af",
            "a7f553e86386d836", "ab66d9603e9312f0", "b21b1eb9d2406569", "b77672f56e28278c",
            "b9701d7da52ee051", "c26e82b5de8d0df1", "c26e907db2e8d46d", "ca26a2621ef0b19d",
            "d216fa4736c23574", "d721b9982492084b", "de3bfef404d6cca5", "e6a418c8103cbc3c",
            "fda0470677afcd47", "69db8a3038bbbe5e"]

def _budget(frame):
    """返回第63行的色0格子数"""
    return sum(1 for c in frame[63] if c == 0)

def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"

    nxt_budget = _budget(nxt)
    state_next = ctx.get("state_next")

    if state_next == "WIN":
        return "NA"                 # 打完最后一关：预算还剩着，局面却结束了（v2）

    # 预算归零 → GAME_OVER
    if nxt_budget == 0:
        return "TRUE" if state_next == "GAME_OVER" else "FALSE"

    # 预算>0 → NOT_FINISHED
    if nxt_budget > 0:
        return "TRUE" if state_next == "NOT_FINISHED" else "FALSE"

    return "NA"

def apply(prev, action, ctx=None):
    """不生成帧差，只做断言"""
    return None
