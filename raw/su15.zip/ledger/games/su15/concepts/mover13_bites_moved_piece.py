"""棋盘上有色13 物件时，每一次棋盘点击都恰好有一件降一级——新件豁免不管用，空点也不例外。"""
LEVEL = "L6"
SCOPE = ("只看棋盘点击（click_xy 落在第 9 行与第 63 行之间）；换关返回 NA；"
         "after_click 算不出件返回 NA；"
         "prev 上棋盘区一只色13 都没有返回 NA（绝大多数步都是这一档——色13 只在梯子顶端出生）；"
         "世界整条驳回了这次点击（除第 63 行外整帧一格不变）返回 NA；"
         "**这一 click 有两只色14 并成色13（色13 这一步刚出生）返回 NA**——出生那一步它咬不咬没见过；"
         "只断言件的账：after_click 算出的件清单里恰好有一件不在 nxt 的件清单里，"
         "而 nxt 里恰好多出一件比它低整一级的。"
         "咬的是哪一件、被咬的落在哪、色13 自己走到哪，一概不断言。")
NOTE = ("v1: 由 48dc2920a0a03dd3（第 763 步）抽出，N=1，只敢说「这一 click 搬动的那件被咬」。"
        "现场：色13（13 格，6 格压在 5 级件底下）骑在 行34-38列19-23 那块 5 级件上，点 (12,39) 把它搬到 行37-41列10-14——"
        "按 mover_captures_piece 的新件豁免它该没事，可帧上 5 级 25 格没了，行35-38列5-8 冒出一块 4 级 16 格，"
        "容量 20 掉到 12、样板要 20，顶带样板与三个圈整体涂成色2（level_dead_when_capacity_short 判 TRUE）。"
        "当时分不清两种读法：(a) 色13 咬一切它够得着的件；(b) 骑在件上的色13 只在宿主被搬走时咬宿主。"
        "\n"
        "v2（第 765 步）：**分清了，是 (a) 的更强版本——连「被搬动」这个前提都不要。**"
        "59634597a4058787 点的是 (63,10)，右上角空地，谁都够不着，after_click 算出的件清单和点击前一模一样"
        "（capture_results 这一步返回 []、_alt_captures 与 _pounce_risk 都空）；"
        "可帧上那块 5 级件照样降成 4 级、被甩到 行24-27列19-22，色13 自己从 行36-39列22-25 挪到 行34-37列19-23，"
        "顶带样板与三个圈再次整体涂成色2。也就是说：**它在盘上，每一 click 都要咬一口**，"
        "而余量为 0 时每一口都等于本关判死——这一关从色13 出生在圈外那一刻起就已经输了，"
        "唯一的活路是 ACTION7 退回到它出生之前（免费，见 action7_undo_conserves）。"
        "v1 的断言（只认搬动的那件）在 765 这条上返回 NA，等于漏判，所以这一版改成只数件的账："
        "恰好一件降一级。N=2，两条观测都在 EVIDENCE 里。"
        "顺带记一条早有的负结果：mover_captures_piece 的 NOTE v7 记过第 197 步色7 咬了刚搬的 6 级件——豁免从来不是铁律。")
EVIDENCE = ["48dc2920a0a03dd3", "59634597a4058787"]

from _lib import (BUDGET_ROW, TOP_BAND_LAST_ROW, after_click, click_xy,
                  creatures, merging_movers, pieces)


def _board_frozen(prev, nxt):
    return all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return "NA"
    if not creatures(prev, 13):
        return "NA"
    ps = after_click(prev, action)
    if not ps:
        return "NA"
    if _board_frozen(prev, nxt):
        return "NA"
    try:
        if len(merging_movers(prev, action, 14)) == 2:
            return "NA"
    except Exception:                                  # noqa: BLE001
        return "NA"
    ps_next = pieces(nxt)
    gone = [p for p in ps if p not in ps_next]
    born = [p for p in ps_next if p not in ps]
    if len(gone) != 1 or len(born) != 1:
        return "FALSE"
    return "TRUE" if born[0][0] == gone[0][0] - 1 else "FALSE"
