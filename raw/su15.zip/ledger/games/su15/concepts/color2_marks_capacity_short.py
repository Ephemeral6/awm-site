"""一次棋盘点击之后，顶带样板条整片被涂成色2，当且仅当这一步走完之后棋盘上件的容量总和已经不够交出样板。"""
LEVEL = "L5"
SCOPE = ("只看棋盘点击（ACTION6 且 10<=y<63）；点顶带、非点击动作、换关（level_prev != level_next）返回 NA；"
         "**prev 顶带里已经有色2 的返回 NA**——那一帧本身就是失手帧，这条概念只管「这一步把它涂上」那一下，"
         "不管失手帧之间的来回（第 90 步就是那一档）；"
         "prev 顶带读不出样板（samples 为空）返回 NA。"
         "断言的是一个双条件：nxt 顶带（列超过 LEGEND_LAST_COL 那一段）里出现色2 "
         "⟺ nxt 上件的 capacity 总和小于 prev 顶带那份样板各级 capacity 的总和。")
NOTE = ("由来：终局卡第 487 步（76825a5272dc7552）。那一步圈3 里的五阶件被降成四阶，余量 0，"
        "按 `level_dead_when_capacity_short` 该当场判死，我几乎要去 RESET。逐格核帧才看见另一件事："
        "顶带样板条上的 50 格色12 与 8 格色14 整片变成了色2，棋盘上八边圈的 254 格色9 也变成色2，"
        "而图例那几格（行1-2 列1-22、行6-7 列1-11）一动不动——**色2 既不在 TIER_OF_COLOR 里也不在 "
        "CREATURE_COLORS 里**，它不是件也不是物件，是世界自己给这一步打的标记。\n"
        "全语料 10 次色2 出现，横跨第 3、4、7、8 关（probe_487color2.out）。"
        "双向核对见 probe_489bicond2.out：棋盘点击、prev 非失手帧、样板读得出的 411 条转移里——\n"
        "  有色2 且容量不够 8 条 · 没色2 且容量够 403 条 · 有色2 却容量够 0 条 · 没色2 却容量不够 0 条。\n"
        "**两个方向都零反例，411/411。**\n"
        "口径要点：比的是**容量总和**不是当下的级多重集。先按多重集覆盖试过一次，"
        "「没色2 却覆盖不住」有 162 条（probe_489biconditional.out）——那些是关卡早期还没合并起来的正常局面，"
        "不是失手。件只会合并或被咬，合并保容量、被咬掉容量，所以能不能交出样板看的是总和：不够就是**永远**不够。\n"
        "**这条概念的用处在于它拿两种读法互相核**：一边是帧上一个像素标记（色2 在不在），"
        "另一边是 `samples` + `pieces` + `capacity` 三个词算出来的一个数。settle 的词汇表审计一直在说"
        "「两条概念都从同一个词取值再互相核对，S=1 不等于这个词被检验过」——这三个词到现在为止正是那样，"
        "这条概念第一次把它们对到帧上另一种读法上。它们要是读错了，这条会当场判 FALSE。\n"
        "**顺带纠正一个我先前的误读**：色2 帧上 `samples` 和 `creature_samples` 都读空（样板被涂掉了），"
        "`octagons` 也读空（圈从色9 变成色2），于是我的枚举器在那一帧上报「样板要件 []、总容量 20」，"
        "看着像这一关彻底没救了。其实那只是**量具在失手帧上瞎了**。ACTION7 退回去之后（第 488 步 "
        "8717d6444dadce50）色2 归零、件一格不差地复原成两块五阶、样板读回 [5,5]、要物件读回 {14:1}。"
        "所以色2 不是终局，是可撤销的失手——这一点本身没写进断言里，因为 ACTION7 从不掉容量这件事"
        "在没有色2 的 36 条 ACTION7 上同样成立（probe_489color2ev.out），单写它就是一条恒真概念。")
EVIDENCE = ["76825a5272dc7552", "c548c82cee338146", "4048547f73854825", "ea35b8c4036c3abd",
            "766c3c0aee19eb7c", "831f48174bd3597f", "dd0ca11555d721f2", "a8573ce41bed5fd8"]

from _lib import (TOP_BAND_LAST_ROW, BUDGET_ROW, LEGEND_LAST_COL, click_xy,
                  samples, pieces, capacity)

MARK_COLOR = 2          # 世界给「这一步之后交不出样板了」打的标记色；不是件色也不是物件色


def _board_click(action):
    xy = click_xy(action)
    return xy is not None and TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def _mark_cells(g):
    """顶带样板条（列超过 LEGEND_LAST_COL）里被涂成 MARK_COLOR 的格子。图例那一段不算。"""
    return [(r, c)
            for r in range(0, TOP_BAND_LAST_ROW + 1)
            for c in range(LEGEND_LAST_COL + 1, len(g[r]))
            if g[r][c] == MARK_COLOR]


def _short(prev, nxt):
    """走完这一步，件的容量总和还够不够交出 prev 顶带那份样板。样板读不出返回 None。"""
    tpl = samples(prev)
    if not tpl:
        return None
    need = sum(capacity(t) for t, _r, _c in tpl)
    have = sum(capacity(p[0]) for p in pieces(nxt))
    return have < need


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _board_click(action):
        return "NA"
    if _mark_cells(prev):
        return "NA"                       # prev 已经是失手帧：本概念不管失手帧之间的来回
    short = _short(prev, nxt)
    if short is None:
        return "NA"                       # 顶带读不出样板
    marked = bool(_mark_cells(nxt))
    return "TRUE" if marked == short else "FALSE"


# 不写 apply：这是一条不变量式的双条件。**而且它写不出来**——要画 nxt 的顶带，
# 得先知道 nxt 的件，那正是 `pieces_merge_at_click` / `mover_captures_piece` 那几条的活；
# 用 prev 的件代算就成了另一条命题（「点之前就已经不够」），而按这条双条件本身，
# prev 没被涂色就说明 prev 不短缺，那一档**一次都不会发生**，写了也只是一段永不开口的死代码。
