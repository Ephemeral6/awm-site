"""色14 菱形盯上**这一 click 刚搬来的那件**、且自己的重心离那件的**边**（件心距减去件的半边长）不超过 POUNCE_HALF(8.14) 时，不走 clamp ±4，而是**整只一步扑到件上**：位移 = floor(件心 − 重心 + 0.5) 不截断、途中不停，落点正压在那件上（被件盖住的格子在帧上看不见）。"""
LEVEL = "L6"
SCOPE = ("只看棋盘点击（ACTION6 且 10<=y<63）；点顶带、非点击动作（ACTION7 是回退，不是走路）、换关返回 NA；"
         "**prev 棋盘区里恰好一块色14、且 creature_blocks 读得准（exact=True）**，否则返回 NA"
         "（读不准的块形状是瞎算的；两只以上没见过）；"
         "点击后的件清单算不出来（after_click 返回 None）或棋盘上一件都没有返回 NA；"
         "**目标件不是这一 click 刚搬来 / 刚合出来的那件返回 NA**——那一档归 mover14_hunts_like_mover7（见 NOTE v4）；"
         "**这一块的重心到目标件中心的距离、减去件的半边长之后超过 POUNCE_HALF(8.14) 返回 NA**——那是远档，也归 mover14_hunts_like_mover7；"
         "**nxt 上件的总容量比 prev 少返回 NA**（这一步有件被降级，件落哪没模型，遮挡也就算不准；"
         "第 158 步就是这样：菱形本来就压在一块没免疫的 3 级件上，那一步走完件从行35-37 列20-22 的 3 级"
         "变成行25-26 列20-21 的 2 级，降级的件还换了地方，谁降的它没查过）；"
         "**这一帧除第 63 行外一格不变（世界整条驳回了这次点击）返回 NA**；"
         "算出来的落点有格子出界或落在第 63 行返回 NA（撞边、压预算条都没见过）。"
         "断言的是：nxt 上**可见**的色14 格集合 = 扑的落点减去被遮挡物（件色格 + 第 63 行色0 格）盖住的那些。")
NOTE = ("v1: **只有一条观测**，但它是 clamp 读法交不出来的那一种。\n"
        "  第 168 步 8e63042609e70242：菱形（行37-40 列19-23）离刚搬到行47-49 列20-22 的 3 级件最近格 7.00，"
        "重心差 (+9.25, 0)。clamp 读法押 (+4,0)，实际整只走了 (+9,0)，压在件上，帧上只剩 (46,21)(48,19)(48,23) "
        "三格露在外面——正是 8 格模板被那块 3×3 盖掉 5 格该剩的样子。\n"
        "阈值只夹在 (7.00, 8.00] 之间：扑到的那次最近格距 7.00，没扑的最近一次是第 164 步的 8.00"
        "（16ec5df9f176d780，重心差 (+10.25,0)，实走 (+4,0)），再远的 11.4 / 15.8 / 24.4 也都是 clamp。"
        "取 <=7 —— 这道边界是本概念最该挨打的地方，下一次菱形落在 7~8 格外就能判。\n"
        "**差点记成两条**：第 152 步（8f1c13d6645341b9）菱形在 nxt 上一格不剩，我一度当成『整只扑进那块 5×5』"
        "的第二条证据——可那一步 level_prev=7、level=8，是**换关**，整屏重画，帧差 509 格，"
        "菱形消失与它往哪走毫无关系。教训：拿『某物件整块消失』当证据之前，先查这一步是不是换关。"
        "所以那条 tid 不在 EVIDENCE 里。\n"
        "**色7 追猎者不扑**：全语料里色7 在最近格距 <=7 时的 21 条观测全是 clamp，一条扑都没有（probe_move.py）。"
        "所以这不是『会动物件的通则』，是色14 自己的一档；写进 _lib 的是 POUNCE_COLORS=(14,)。\n"
        "为什么要紧：扑的射程比 clamp 的 4 远，围着件下饵时，菱形能从好几格外一步压上来——"
        "第 8 关要把两只色14 并成色13，靠的就是让它们同时扑上同一块免疫件。\n"
        "v2: **量错了距离**，死在第 213 步（0ba226dc5908a279）——但不是被这条概念自己的反例打死的，"
        "它那一步因为场上有两块色14 而返回 NA；打死它的是**押注落空**。"
        "那一步我押两只色14 同时扑上刚搬到 行39-43列11-15 的 5 级件、并成一只色13。"
        "实际只并没并：帧上色14 从 9 格变 8 格，一块在 行40-43列17-21，色13 一格没有。"
        "逐格读帧（probe_diff213.py）重建出来的是——"
        "老那只（行44-47列21-25，最近格距 6.71、重心距 11.07）走了 **clamp (-4,-4)**，"
        "新生那只（行35-38列16-20，最近格距 1.41、重心距 6.56）**扑了**，落点 行40-43列11-15 "
        "整块塞进件的 行39-43列11-15 里，帧上一格都看不见。"
        "v1 的判据（最近格距<=7）把老那只也算成扑，于是 merging_movers 数出「两只压上新鲜件」——"
        "**押注的那句话是从一个算错的落点推出来的**。"
        "换判据（probe_pounce_centroid.py）：重心到件心的欧氏距离，扑过的四次 9.25 / 9.06 / 8.78 / 7.04，"
        "没扑的 10.25 / 11.07 / 15.81 / 21.45 / 24.40 / 25.63，阈值夹在 (9.25, 10.25) 之间，取 10.0。"
        "全语料 11 条读得出实际位移的观测：重心距 11/11，最近格距 10/11。"
        "为什么是重心而不是最近格：扑的落点本来就按『重心对准件心』算，量重心距等于问『这一步够不够它一口气挪过去』——"
        "最近格距是外形的函数，同一个重心距下菱形转个身它就变了。"
        "**没换掉的东西**：扑的位移公式、色7 不扑、被件盖住的格子不比。阈值仍是夹出来的，仍是册子里最薄的一处。\n"
        "v4: **v2 的读法死了，而且不是阈值取高取低的问题**。"
        "第 329 步（52c92c40e3fdf3d5）是本概念自己的反例：菱形 行40-43列17-21、目标是停着没动的 5 级件 行40-44列8-12，"
        "重心到件心 9.01，**不超过** POUNCE_CDIST 10.0，本概念说扑、押 (42,17) 那一格空出来，"
        "世界走的是 clamp Δ(0,减4)，(42,17) 仍是色14。那一批只错这一格。"
        "9.01 比本概念 NOTE v2 里记的『扑过的最小一次 9.25』**还小**——"
        "所以按这个距离排序，扑和 clamp 的区间是**重叠**的，单看它分不开。"
        "第 327 步（4048547f73854825）是同样的两块、同样的 9.01、同样没扑，只是那一步有件被降级、本概念返回 NA，没算分。\n"
        "  重新摊开（probe_pounce2.out，全语料里『盘上恰好一块完整色14 的棋盘点击』25 条）："
        "扑的 5 条 gap [4.0, 4.0, 6.08, 6.4, 7.0]、**目标是新件 5/5**；"
        "clamp 的 9 条 gap [5.0, 5.0, 8.0, 9.0, 11.4, 13.6, 17.03, 20.0, 21.21]、目标是新件 4/9，"
        "而那 4 条新件的 gap 是 8.0 / 17.03 / 20.0 / 21.21，全在 7.5 以外。"
        "两个条件合起来把 5 条和 9 条切干净：**目标是这一 click 刚搬来的那件，且最近格距不超过 7.5**。"
        "少了『新件』这一条就判错第 327/329 步（gap 5.0，非新件）；少了 gap 这一条就判错第 164 步那一档。"
        "阈值取 7.5 而不是 7.0：边界夹在 7.0（扑）与 8.0（clamp）之间，钉在观测最大值上是把判据焊死。\n"
        "  **最近格距回来了，但不是 v1 那条**：v1 只有 gap<=7 一个条件，死在第 213 步那只 gap 6.71 的老菱形上；"
        "新读法里那一只正因为『目标不是新件』而被排掉。v1 缺的不是量法，是第二个条件。\n"
        "  **这一版最该挨打的地方**：『新件』这一条在重叠区（gap 5~7.5）只有两条反证，而它们是**同一对局面**"
        "（第 327、329 步，同样的菱形、同样的两块件）——算独立观测其实只有一次。"
        "下一次菱形在 7.5 格内盯着一块没被搬动的件，就能判它。\n"
        "  **_lib 里两条读法并存**：`pounces(…, fresh=None)` 仍走 v2 的老读法，只有传了 fresh 的调用处换到新读法。"
        "本概念与 mover14_hunts_like_mover7 都传了；别的调用处（level_dead_when_capacity_short、"
        "pieces_merge_at_click 等）这一批没重审，它们仍在用一条已知被打死的读法——这是明写的欠账。\n"
        "v5: **v4 的 gap 那一半死在第 507 步**（af26c16fca8a9323，ACTION6:6,27）："
        "菱形 行16-19列10-14、目标是这一 click 刚搬到 行25-29列4-8 的 5 级件——**是新件**，"
        "gap 6.71 **在 7.5 以内**，而且 6.71 就落在 v4 记的『扑过的 gap [3.61, 7.0]』区间里。"
        "世界走的是 clamp Δ(+4,-4)：菱形落在 行20-23列6-10，本概念押的落点 行25-28列4-8 一格没中。"
        "所以这不是阈值往下调一点的事——**gap 在两档里完全重叠，它分不开**。\n"
        "  重新摊开（probe_pounce2.py 重跑，语料从 25 条涨到 51 条『盘上恰好一块完整色14 的棋盘点击』）：\n"
        "    扑的 7 条          cdist [7.04, 7.32, 7.85, 8.0, 8.78, 9.06, 9.25]  gap [3.61, 4.0, 4.0, 4.0, 6.08, 6.4, 7.0]  新件 7/7\n"
        "    clamp 30 条里新件的 11 条 cdist [10.25, 11.03, 11.88, 12.0, 14.7, 15.1, 16.25, 17.67, 21.45, 24.4, 25.63]\n"
        "  **固定住『新件』这一条之后，cdist 切得干净**（扑的最大 9.25 / 新件 clamp 的最小 10.25），gap 切不开。\n"
        "  所以 v5 = **v2 的量法 + v4 的新件条件**，阈值还是 v2 那个 10.0。"
        "这两半各自都死过一次，死因正好互补：v2 死在第 327/329 步的 cdist 9.0，而那两步目标**不是**新件，"
        "加上新件这一条就排掉了；v4 死在第 507 步，是因为它把量法换了。"
        "把两次死因各自纠正的那一半拼回去，才是这一版——不是第三次调阈值。\n"
        "  **这一版最该挨打的地方**：(9.25, 10.25) 这条缝只由 7 条扑和 11 条新件 clamp 夹出来，"
        "而那 11 条里第 507 步的 11.03 是**离缝最近的一条**，缝只有 1.0 宽。"
        "另外『扑』的 7 条里有 4 条来自第 168~174 步那一段连着的局面，独立性存疑。"
        "下一次菱形以 cdist 落在 9.25~10.25 之间盯着一块新件，就能判它。\n"
        "  **gap 没有被证明无关，只是被证明单独不够**：扑过的 7 条 gap 全在 7.0 以内，这仍可能是个必要条件；"
        "但语料里没有一条『新件 + cdist 不超过 10.0 + gap 超过 7.0』的观测，所以加上它是加一条没被检验的话，不加。\n"
        "v6（第 509 步 625241b187536c74 打死 v5，量法第三次换）：**v5 预注册的那条缝当场被填进去了**。"
        "那一步 cdist 10.0778——**超过** 10.0，本概念判 NA、把它让给了 mover14_hunts_like_mover7 的 clamp 档；"
        "世界扑了。判它扑不是看落点看出来的（那一帧关当场死、整屏重画，落点读不出），是推出来的："
        "件A 是这一 click 刚搬的、点击后该在 (5,25,6)，实测 (4,25,0)——掉一级、列从 6-10 甩到 0，"
        "正是 mover_captures_piece + captured_piece_flung_ten 的签名；盘上够得着它的只有这一块色14，"
        "而 clamp 落点 行20-23 碰不到它，扑的落点 行25-28 整块压在它身上（probe_509cx.out / probe_511pounce.out）。\n"
        "  只把 10.0 抬到 10.0778 以上的话，缝只剩 (10.0778, 10.25]、0.17 宽——比 v5 那条 1.0 宽的缝还窄，"
        "那是在重演 gap 垮掉前的样子。所以这一次换的是量法本身，理由在数据里（probe_511norm.out）：\n"
        "    扑过的 5 条（新件这一侧）里 4 条目标是 3 级件、第 509 步那条是 5 级。"
        "cdist 量的是重心到件**心**，件越大件心埋得越深——同样贴着件的边，大件的读数天生更大。"
        "两档因此被**件的大小**拌在一起，而不是被距离分开。\n"
        "    把边长折掉（hdist = cdist − side/2）之后：\n"
        "      扑    [5.54, 7.28, 7.56, 7.58, 7.75]\n"
        "      clamp [8.53, 8.75, 9.38, 9.50, 12.20, 12.20, 12.60, 13.70, 13.75, 15.17, 18.95, 21.90, 23.13]\n"
        "    零重叠，缝 (7.75, 8.5255) 宽 0.7755——是 cdist 那条缝的 4.5 倍。阈值取缝的中点 8.14，不钉在端点上。\n"
        "    同一批数据里别的量法全有重叠：cdist−side 重叠 3 条、cdist/side 重叠 10 条、gap 重叠 2 条、"
        "切比雪夫 3 条、曼哈顿 4 条（probe_511metric.out）。hdist 是唯一零重叠且缝宽超过 0.5 的。\n"
        "  **预注册的薄处**：扑这一档总共只有 5 条观测，其中 5 级件**只有第 509 步这一条**，"
        "而它同时是定义这条缝下沿的那一条——用同一条观测既定阈值又当证据，这是明摆着的弱点。"
        "下一条 5 级件的扑（或不扑）只要 hdist 落在 7.75~8.53 之间，这个量法就当场垮。"
        "**垮了不要再削阈值**：gap 和 cdist 各被削垮过一次，第三次该换的是"
        "「扑不扑由一个距离标量决定」这个假设本身，而不是标量的刻度。")
EVIDENCE = ["8e63042609e70242", "16ec5df9f176d780", "0ba226dc5908a279", "52c92c40e3fdf3d5",
            "af26c16fca8a9323", "625241b187536c74"]

from _lib import (BG, BUDGET_ROW, DIAMOND_COLOR, OCT_COLOR, POUNCE_HALF, TIER_OF_COLOR,
                  TOP_BAND_LAST_ROW, after_click, capacity, click_xy, creature_blocks, mover_target,
                  octagons, piece_cells, piece_center, pounce_hdist, pieces, will_level_up,
                  _centroid, _round)


def _cells(g):
    return {(r, c) for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW + 1)
            for c in range(len(g[0])) if g[r][c] == DIAMOND_COLOR}


def _covered(g):
    """画在会动物件上面的东西：件色的格 + 第 63 行的色0 预算格。"""
    return {(r, c)
            for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW + 1)
            for c in range(len(g[0]))
            if g[r][c] in TIER_OF_COLOR or (r == BUDGET_ROW and g[r][c] == 0)}


def _cap(g):
    return sum(capacity(t) for t, _, _ in pieces(g))


def _board_click(action):
    xy = click_xy(action)
    return xy is not None and TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def _pounce(prev, action):
    """(落点, 点击后的件占的格)；说不出来 / 不是近档返回 None。"""
    blocks = creature_blocks(prev, DIAMOND_COLOR)
    if len(blocks) != 1 or not blocks[0][1]:
        return None
    cells = blocks[0][0]
    ps = after_click(prev, action)
    if not ps:
        return None
    ps_prev = pieces(prev)
    fresh = [p for p in ps if p not in ps_prev]
    tgt = mover_target(cells, ps)
    if tgt not in fresh:
        return None                                  # 盯的是老件：那一档不扑（v4）
    if pounce_hdist(cells, tgt) > POUNCE_HALF:
        return None                                  # 够不着：远档归 mover14_hunts_like_mover7
    tr, tc = piece_center(tgt)
    mr, mc = _centroid(cells)
    dr, dc = _round(tr - mr), _round(tc - mc)
    land = {(r + dr, c + dc) for r, c in cells}
    if any(not (TOP_BAND_LAST_ROW < r < BUDGET_ROW and 0 <= c < len(prev[0])) for r, c in land):
        return None
    return land, {cell for p in ps for cell in piece_cells(p)}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _board_click(action):
        return "NA"
    if all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW):
        return "NA"                                  # 世界整条驳回了这次点击
    if _cap(nxt) < _cap(prev):
        return "NA"                                  # 有件被降级，件落哪没模型
    got = _pounce(prev, action)
    if got is None:
        return "NA"
    land, _occ = got
    return "TRUE" if _cells(nxt) == land - _covered(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if not _board_click(action):
        return None
    if will_level_up(prev, action):
        return None                                  # 过关那一步整屏重画
    got = _pounce(prev, action)
    if got is None:
        return None
    land, occupied = got
    out = {cell: DIAMOND_COLOR for cell in land if cell not in occupied}
    known, unsure = octagons(prev)
    for cell in _cells(prev) - land:
        if cell in unsure or cell in occupied:
            continue                                 # 说不准底下是什么 / 被件盖住
        out[cell] = OCT_COLOR if cell in known else BG
    return out
