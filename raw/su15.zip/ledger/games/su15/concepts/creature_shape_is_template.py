"""棋盘区没被遮挡的每一块色7 / 色14，逐格就是那一色自己的 8 格模板——两色的模板不同（色14 中间多一格、底排少一格）。"""
LEVEL = "L6"
SCOPE = ("只看棋盘区（第 10 行以下、含第 63 行）的色7 与色14；顶带的图例与样板不算；"
         "prev 与 nxt 两帧都查，任一帧上有一块摆不出来就判 FALSE；"
         "**可见格数 > 8 的块跳过**——两只挨在一起会黏成一块，帧上切不开，这条概念不主张怎么切；"
         "**块的周围一个 4×5 模板够得着的范围内有遮挡物（件色格或第 63 行的色0 格）时跳过这一块**——"
         "被盖住的物件会碎成好几块，每一块单独看当然摆不出整只（见 NOTE v2）；"
         "没有一块可判返回 NA。"
         "所以本概念只断言一件事：**没被遮挡的那些块，逐格就是那一色的 8 格模板**。")
NOTE = ("v1: 词汇表审计逼出来的一条——SHAPE_OF_CREATURE 是 creature_blocks 的地基，"
        "而 creature_blocks 又是 movers_merge_on_immune_piece、empty_click_still_moves_movers、"
        "mover14_hunts_like_mover7 的地基，这个词却从来没被任何概念拿帧核对过。"
        "它一直是错的：册子从第 157 步起写『色7 与色14 同一个 8 格形状』，依据是那只刚出生的菱形"
        "露出的 5 格与追猎者逐格对得上——可那 5 格 ((0,2)(1,1)(1,3)(2,0)(2,4)) 恰好是两种形状**完全相同**的 5 格，"
        "被 3×3 件盖掉的 3 格才是区别所在。第 166 步之后帧上有一只完整的色14（行37-40 列19-23），"
        "逐格量出来是 ..#.. / .#.#. / #.#.# / .#.#.：中间多一格 (2,2)、底排少一格 (3,2)。"
        "**拿共有部分去确认形状等于没确认**，补全的那几格必须自己被另一帧看见过。"
        "本概念存在的意义就是让这种错下次自己冒头：它不调用 creature_blocks，"
        "而是直接在帧上找『模板减去被盖住的格』这种摆法。"
        "顺带记一个副作用：形状改对之后菱形的重心从 (1.875,2.0) 变成 (1.75,2.0)，"
        "movers_merge_on_immune_piece 的覆盖率从 0.311 升到 0.348（原先它在这只菱形上一直 exact=False 而闭嘴）。"
        "v2: v1 死于 762e9be83f6df642（第 111 步）与 ffd26052fe94d90d，死法一样也很干脆："
        "**被件盖住的物件在帧上是好几块**。第 111 步那只新生菱形只露出 (13,25)(15,23)(15,27) 三格，"
        "彼此连 8-邻接都不是，于是成了三个独立的单格块；一个单格块要摆成 8 格模板，"
        "得让另外 7 格全被遮挡物盖住，而那里只有一块 3×3，盖不下——判 FALSE，判得没错，"
        "错的是主张：v1 声称『每一块都是一只』，可一只会碎成几块。"
        "补法有两种：把同一色的所有可见格拿去做集合覆盖（几只模板能不能盖住），或者只管没被遮挡的块。"
        "选后者——前者要发明『几只』这个自由参数，一条概念只该断言一件事。"
        "缩完之后它检验的仍是要害：一只完整露着的物件的逐格形状。遮挡下的补全归 creature_blocks，"
        "那是另一条路（它自己会在补法不唯一时返回 exact=False，本概念管不着也不该管）。")
EVIDENCE = ["b6e4569d87727d29", "b503ce3bb31b876f", "762e9be83f6df642", "868bde228addb7ee",
            "ffd26052fe94d90d"]

from geo import components
from _lib import (BUDGET_ROW, CREATURE_BOX, DIAMOND_COLOR, MOVER_COLOR, SHAPE_OF_CREATURE,
                  TIER_OF_COLOR, TOP_BAND_LAST_ROW)


def _covered(g):
    """画在会动物件**上面**的东西：件色的格 + 第 63 行的色0 预算格。"""
    return {(r, c)
            for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW + 1)
            for c in range(len(g[0]))
            if g[r][c] in TIER_OF_COLOR or (r == BUDGET_ROW and g[r][c] == 0)}


def _blocks(g, colour):
    cs = [(r, c) for r in range(TOP_BAND_LAST_ROW + 1, BUDGET_ROW + 1)
          for c in range(len(g[0])) if g[r][c] == colour]
    return components(cs, diag=True)


def _fits(block, shape, ncol):
    """这一块可见格是不是恰好摆成一整只（没有遮挡，所以必须整只齐全）。"""
    nrow, ncolbox = CREATURE_BOX
    rs = [r for r, _ in block]
    cls = [c for _, c in block]
    b = set(block)
    for r0 in range(max(rs) - nrow + 1, min(rs) + 1):
        for c0 in range(max(cls) - ncolbox + 1, min(cls) + 1):
            if not (TOP_BAND_LAST_ROW < r0 and r0 + nrow - 1 <= BUDGET_ROW):
                continue
            if not (0 <= c0 and c0 + ncolbox - 1 < ncol):
                continue
            if b == {(r0 + dr, c0 + dc) for dr, dc in shape}:
                return True
    return False


def assert_(prev, action, nxt, ctx=None):
    nrow, ncolbox = CREATURE_BOX
    said = False
    for g in (prev, nxt):
        covered = None
        for colour in (MOVER_COLOR, DIAMOND_COLOR):
            shape = SHAPE_OF_CREATURE[colour]
            for block in _blocks(g, colour):
                if len(block) > len(shape):
                    continue                      # 两只黏成一块，切不开：不主张
                if covered is None:
                    covered = _covered(g)
                rs = [r for r, _ in block]
                cls = [c for _, c in block]
                near = {(r, c) for r in range(min(rs) - nrow + 1, max(rs) + nrow)
                        for c in range(min(cls) - ncolbox + 1, max(cls) + ncolbox)}
                if near & covered:
                    continue                      # 附近有遮挡物，这一块可能只是一只的一部分
                if not _fits(block, shape, len(g[0])):
                    return "FALSE"
                said = True
    return "TRUE" if said else "NA"
