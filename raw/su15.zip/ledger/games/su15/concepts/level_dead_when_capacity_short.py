"""棋盘点击后，若件的总容量（Σ 2^(级-1)）从「够得上顶带样板所需」掉到「不够」，顶带样板与色9 八边形整体变成色2（本关判死）；只要没发生这次掉落，这两处一格不变。"""
LEVEL = "L5"
SCOPE = ("只看棋盘点击（ACTION6 且 10<=y<63）；换关返回 NA；prev 里没有色9 格或没有样板返回 NA"
         "（判死之后样板和圈都已是色2，本概念看不出东西）；只断言 prev 里的色9 格与顶带样板格，"
         "件压上去露出件色的格子放过，**会动的物件（色7/色13/色14）压住的格子也放过**")
NOTE = ("v1: 第 89 步（a8573ce41bed5fd8）色7 追上一个 2×2 把它毁成 1×1，同一步顶带的 4×4 样板和棋盘上的色9 八边形全变成色2，"
        "关没换、也没 GAME_OVER。为什么是这一步：按 capacity=2^(级-1) 算，第 3 关开局 8 个 1×1 = 8 = 一个 4×4 所需，"
        "第 2 关 4 个 1×1 + 4 个 2×2 = 12 = 3×3 + 4×4 所需——每关给的恰好够、没有富余；毁掉任何一件就凑不齐，世界当场把目标涂成色2。"
        "样板与圈变色2 之后还能不能救回来没见过；预算条照常在走。"
        "v2: 死于 1e1d5afea4fe094c——件搬进圈里会盖住色9 格，那不是变色2；盖住的格子放过。"
        "v3: 死于 c4579d0cfc62d240——追猎者也会走进圈里，色9 变色7。同一个道理：盖住的放过。"
        "顺带记一条：圈不是禁区，追猎者照样进得去。"
        "v4: 死于 e81fd58cf7dbeb06——第 5 关开局棋盘上一个件都没有（容量 0 < 需求 8），世界并没有判死。"
        "v1-v3 把『容量不够』当判死条件，其实只见过『容量掉下去』：第 89 步是 8→7 掉破了线。"
        "改成押掉落沿：prev 够、nxt 不够才判死。第 5 关这种「本来就没有件」的开局因此落在主张之外——"
        "件要从哪儿来是这一关的新问题（棋盘上只有一块 7×7 的色8）。"
        "v5: 死于 2f8864ee29041099——那块 7×7 其实一直就是件（6 级、色8），第 121 步被追猎者压上后变成一块 5 级的"
        "5×5 色12，落在右下角压住了八边形的几格色9。主张一个字没改，是词汇表少认了色12 和色8 两种件色；"
        "认下之后这一步的容量是 32→16，需求 8，没掉破线，也确实没判死。"
        "v6: 主张与 assert_ 一个字没改，只把 apply 的『让给追猎者』那几格从落点改成整条路径（_lib.mover_path）。"
        "第 123 步意外 3 格：追猎者在捕获那一步停在了模型算出的落点前一格，被它压住的圈格我押成了色9。"
        "捕获那一步停在哪现在还说不准（四次捕获两次停在压上件的子步、两次停在挨着的前一子步），"
        "所以生成器该对它这一步走过的每一格闭嘴，而不是只让开一个落点。"
        "v7: 主张与 assert_ 又一个字没改，只让 apply 在**这一步要过关**时闭嘴。settle 报它认领 8998 格说错 276，"
        "错的全在过关那几步：新关的顶带样板和圈都换了位置，而『这两处一格不变』当然不成立。"
        "assert_ 早就在换关时返回 NA，apply 却看不见换关（预测时 ctx 里 level_next = level_prev），照旧开口。"
        "补上 _lib.will_level_up（由 levelup_when_samples_in_octagon 走闸）：它说这一步会过关，apply 就不认领。"
        "v8: 还是只改 apply 的折扣区。原来的写法是「所有色7 格的包围盒外扩 4 格里有任何一个件就整步闭嘴」——"
        "它是在还没有捕获模型的时候写的保险丝，两个追猎者一南一北时那个并集包围盒能盖住大半张棋盘，"
        "于是有件的关里它几乎步步哑（第 127 步就这样，全册只押出 51 格）。"
        "现在捕获有模型了（mover_captures_piece）：捕获发生在追猎者这一步走过的格子压上或挨着某个件的时候，"
        "折扣区就收成这一条——路径的 8-邻接晕圈碰到件才闭嘴，碰不到就照常认领，只把路径本身让出去。"
        "v9: 死于 b503ce3bb31b876f（第 157 步），错的不是主张是**读法**：那一步 6 级件被捕降成 5 级，"
        "5 级件落在行59-63 列41-45，第 63 行那 5 格被**预算条画在上面**，_lib.pieces 只看见 20 格、认不出这块 5×5，"
        "于是我算出的 nxt 容量少了 16（20 当成 4），掉破需求 20，本概念以为该判死，帧上却一格没变。"
        "同一条转移同时打掉 mover_captures_piece，两条的破口是同一个词（pieces），改在 _lib：缺角的件照八边形那条补全，"
        "缺的格必须正被预算条盖着且补法唯一。"
        "顺带把『放过』那一条从色7 推广到**所有会动色（色7/色13/色14）**：第 157 步场上多了一只色14 菱形，"
        "它和追猎者一样走得进圈里，机制同一个（画在圈上面），没道理只放过其中一种。"
        "这是把主张改弱，不是改强——代价是圈里被会动物件盖住的格子从此不再检验。"
        "v10: 主张与 assert_ 仍是一个字没改，第三次只动 apply 的折扣区，由 cd950387dad1e047（第 196 步）逼出来："
        "我押圈里的 (38,11)(39,10)(39,12)(40,9)(40,13)(41,10)(41,12)(42,11) 八格仍是色9，实际是色7——"
        "一只追猎者正落在那里。原因在这一行调用：`mover_path(mv, ps)` **没传 ps_prev**，"
        "于是它按『点击后最近的件』挑目标，而 _lib.mover_target 早就有区分性证据说该按『点击前最近、认身份不认位置』挑"
        "（逐只打分 88/89 对 86/89）。那一步我把 6 级件从行48-54列35-41 搬到行43-49列27-33，"
        "这只追猎者点击前最近的是 3 级件（行54-56列10-12）、点击后最近的是刚搬过去的 6 级件，两种读法算出两条不同的路，"
        "而世界走的是前一条。改法：把 ps_prev=pieces(prev) 传进去。"
        "同一版把折扣区推广到**所有**会动色：原来只让开色7 的路径，色14/色13 的落点一格没让。"
        "眼下棋盘上还没有色14，但这一关的路线就是要把四只色7 并成色14 再并成色13，"
        "不补这一条，它们一出生这条概念就会在圈里连错好几格。色14 近了会『扑』（走法和色7 不同），"
        "所以对非色7 的物件不用 mover_path，直接让出『原位 ∪ capture_landing 落点 ∪ 两者的包围盒』——"
        "宁可多让几格（少认领 = 少检验），也不押一个算不准的落点。")
EVIDENCE = ["a8573ce41bed5fd8", "2d285b1a57d37411", "1c3a9aa1bacfeea4", "04fc031a768f3ce1", "1e1d5afea4fe094c",
            "c4579d0cfc62d240", "e81fd58cf7dbeb06", "2f8864ee29041099", "b503ce3bb31b876f",
            "cd950387dad1e047"]

from geo import cells_of
from _lib import (click_xy, pieces, samples, capacity, after_click, piece_cells, mover_path, will_level_up,
                  creature_blocks, capture_landing,
                  TOP_BAND_LAST_ROW, BUDGET_ROW, LEGEND_LAST_COL, TIER_OF_COLOR, CREATURE_COLORS)

OCT_COLOR = 9
DEAD_COLOR = 2
MOVER_COLOR = 7


def _need(g):
    return sum(capacity(t) for t, _, _ in samples(g))


def _have(g):
    return sum(capacity(t) for t, _, _ in pieces(g))


def _watched(g):
    """prev 里该盯着的格子：棋盘区色9 格 + 顶带样板格。"""
    cells = [(r, c) for r, c in cells_of(g, OCT_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    for color in TIER_OF_COLOR:
        cells += [(r, c) for r, c in cells_of(g, color) if r <= TOP_BAND_LAST_ROW and c > LEGEND_LAST_COL]
    return cells


def _board_click(action):
    xy = click_xy(action)
    return xy is not None and TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _board_click(action):
        return "NA"
    need = _need(prev)
    oct_cells = [(r, c) for r, c in cells_of(prev, OCT_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    if need == 0 or not oct_cells:
        return "NA"
    dead = _have(prev) >= need > _have(nxt)
    for r, c in _watched(prev):
        want = DEAD_COLOR if dead else prev[r][c]
        if nxt[r][c] == want:
            continue
        if nxt[r][c] in TIER_OF_COLOR:      # 件压在圈上时露出的是件色
            continue
        if nxt[r][c] in CREATURE_COLORS:    # 会动的物件（色7/色13/色14）走进圈里压住的格子
            continue
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not _board_click(action):
        return None
    if will_level_up(prev, action):
        return None                     # 过关那一步顶带样板与圈整个换掉，本概念说不出
    need = _need(prev)
    watched = _watched(prev)
    if need == 0 or not watched:
        return None
    ps = after_click(prev, action)
    if ps is None:
        return None
    # 会动的物件这一步可能追上件把它降级（容量会掉、件会搬到说不准的地方），只在**真可能捕获**时闭嘴：
    # 按 mover_captures_piece，捕获发生在物件这一步走过的格子压上或挨着（8-邻接）某个件的时候。
    occupied = {cell for p in ps for cell in piece_cells(p)}
    ps_prev = pieces(prev)
    mv = [(r, c) for r, c in cells_of(prev, MOVER_COLOR) if TOP_BAND_LAST_ROW < r < BUDGET_ROW]
    hidden = set()
    if mv:
        hidden |= mover_path(frozenset(mv), ps, ps_prev=ps_prev) or set()   # 认身份不认位置（NOTE v10）
    for colour in CREATURE_COLORS:
        if colour == MOVER_COLOR:
            continue
        for b, _full in creature_blocks(prev, colour):
            _tgt, land = capture_landing(frozenset(b), ps, occupied, colour)
            swept = set(b) | set(land)
            r0 = min(r for r, _ in swept); r1 = max(r for r, _ in swept)
            c0 = min(c for _, c in swept); c1 = max(c for _, c in swept)
            hidden |= {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
    if hidden:
        halo = {(r + dr, c + dc) for r, c in hidden for dr in (-1, 0, 1) for dc in (-1, 0, 1)}
        if halo & occupied:
            return None
    have = sum(capacity(t) for t, _, _ in ps)
    dead = _have(prev) >= need > have
    covered = occupied | set(hidden)
    return {(r, c): (DEAD_COLOR if dead else prev[r][c]) for r, c in watched if (r, c) not in covered}
