"""一块**不是这一 click 搬动的**件被咬掉一级、而 prev 帧上它周围 REACH 之内一只会动物件都看不见时：
nxt 帧上有一只会动物件整只落在它原来占的格子里——那一只从头到尾就藏在这块件底下。"""
LEVEL = "L6"
SCOPE = ("只看棋盘点击（click_xy 落在第 9 行与第 63 行之间）；换关返回 NA；"
         "after_click 算不出件返回 NA；"
         "「被咬的件」= after_click 算出的件清单里、在 nxt 上找不到同级同位对应、**且不是这一 click 搬动的那块**；"
         "一块这样的件都没有返回 NA（绝大多数步都是这一档）。"
         "**v2 起只管「prev 帧 REACH 之内一只会动物件都看不见」那一档**：看得见的那一档整块跳过，"
         "一块该判的都没有返回 NA——看得见猎手时谁露在原格子里，这条一个字都不说了（由来见 NOTE v2）。"
         "断言的是一个单向蕴含，对每一块该判的件各判一次，有一块不成立就整条 FALSE。")
NOTE = ("由来：终局卡第 487 与 489 步，两次都是规划器挑了一条它算作「不掉件」的边，"
        "世界却把一块**离点击点很远、跟这一 click 毫无关系**的五阶件咬成了四阶，"
        "容量 32→24 掉破样板需求 32，顶带整片涂成色2（color2_marks_capacity_short）。"
        "我先以为是规划器的捕获模型算漏了，逐格核帧才看见真相：那块件在 prev 上占的 25 格**全是色12**，"
        "一格色14 都没有；而 nxt 上那只 8 格色14 **整只落在这 25 格之内**（probe_490hidden.out）。"
        "它一直在那儿——第 486 步那一 click 把件搬到 (15,3) 之后它就跳了上去，从此帧上读不出来。"
        "**可见不等于存在**：这一局第三次栽在同一类事上"
        "（前两次见 levelup_when_samples_in_octagon 的 NOTE v6 与 merged_creature_born_on_anvil 的 NOTE v3）。\n"
        "量法（probe_491bite.out）：全语料里「不是这一 click 搬的、却在 nxt 上对不上号」的件共 39 块——\n"
        "  prev 帧 REACH 内看得见猎手、nxt 上没有物件落在原格子里：37 块\n"
        "  prev 帧 REACH 内一只都看不见、nxt 上有物件整只落在原格子里：2 块\n"
        "**两档零交叉，39/39。**\n"
        "阈值不是钉在端点上的（probe_491gap.out）：看得见的那 37 块，prev 最近一只会动物件的距离谱是 "
        "0.0 ~ 6.4（中位 2.83）；藏着的那 2 块是 27.73。两档之间空着 6.4 到 27.73 这一整段，"
        "REACH=8 落在空档正中偏下，不是最小可分。上一次栽在把阈值取成观测极值（POUNCE_REACH=7），这次有 21 格的余量。\n"
        "**这条概念的用处在于它给规划器立了个规矩**：帧上数不出猎手，不等于场上没有猎手。"
        "规划器到此刻为止把帧当成全部状态，于是同一类死边连挑两条（第 487、489 步各赔两步预算）。\n"
        "**代价与已知的薄处**：A 档只有 2 条观测，而且是同一块件、同一只菱形、相隔两步——"
        "它随时可能被第三条打死。真被打死的样子多半是「看不见猎手、咬完也没有物件露在原格子里」"
        "（猎手咬完自己又走开了），那时候这条要缩成「露出来的落点没有模型」而不是接着放宽。"
        "另外它只管**被咬**那一档；一只藏着的物件在没咬人的步里去了哪，这条一个字都没说。\n"
        "\n"
        "v2（第 765 步，59634597a4058787）：**双条件的反向那一半死了，死法不是预想的那种。**"
        "预想的死法是「看不见猎手、咬完也没有物件露在原格子里」；真出事的是另一头——"
        "看得见猎手，咬完照样有一只整只落在原格子里。现场（probe_765hidden.out）："
        "受害件 25 格 bbox(34,38,19,23)，prev 帧上一只 7 格的顶端色物件**距离 1.00**（看得见，visible=True），"
        "咬完 nxt 上它长成 13 格 bbox(34,37,19,23)，**整只落在那 25 格之内**（revealed=True），"
        "双条件当场 FALSE。原因清楚：那只物件从头就**骑在这块件上**，大半身子压在件底下只露出 7 格，"
        "件被甩走之后剩下的部分原地露了出来。也就是说「露在原格子里」有两种来路——"
        "一直藏在底下的，和骑在上面被让开的——**帧上长得一模一样**，从落点分不出猎手当时看不看得见。"
        "所以 v2 缩成单向：只保留「看不见 → 会露出来」，看得见那一档返回 NA。\n"
        "反向那 37 条观测不作废也不删：它们是 v1 的依据，也是打死 v1 的那一条的对照——"
        "现在它们只说明「绝大多数看得见的猎手咬完不落在原格子里」，而这句话不再是本条概念的主张。"
        "规划器该拿的那一半没动：**帧上数不出猎手，不等于场上没有猎手。**\n"
        "顺带：这一步的咬本身由 mover13_bites_moved_piece v2 管（顶端色物件在盘上，每一 click 都要咬一口），"
        "本条只管「咬完谁露出来」。")
EVIDENCE = ["76825a5272dc7552", "b6b86a1426e76050",
            "a8573ce41bed5fd8", "ea35b8c4036c3abd", "4048547f73854825",
            "1e8e55a0a15b981b", "766c3c0aee19eb7c", "59634597a4058787"]

import math

from _lib import (BUDGET_ROW, CREATURE_COLORS, REACH, TOP_BAND_LAST_ROW,
                  after_click, click_xy, creature_blocks, piece_cells, pieces)


def _nearest(blocks, cells):
    """blocks 里离 cells 最近的一只有多远；一只都没有返回 None。"""
    best = None
    for blk in blocks:
        d = min(math.dist(x, y) for x in blk for y in cells)
        if best is None or d < best:
            best = d
    return best


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return "NA"
    ps = after_click(prev, action)
    if not ps:
        return "NA"
    ps_prev = pieces(prev)
    ps_next = pieces(nxt)
    moved = [p for p in ps if p not in ps_prev]
    victims = [p for p in ps if p not in ps_next and p not in moved]
    if not victims:
        return "NA"

    blocks_prev = [blk for colour in CREATURE_COLORS for blk, _f in creature_blocks(prev, colour)]
    blocks_next = [blk for colour in CREATURE_COLORS for blk, _f in creature_blocks(nxt, colour)]
    judged = 0
    for p in victims:
        cells = set(piece_cells(p))
        near = _nearest(blocks_prev, cells)
        if near is not None and near <= REACH:
            continue                       # v2：看得见猎手那一档本条不管了
        judged += 1
        if not any(set(blk) <= cells for blk in blocks_next):
            return "FALSE"
    return "TRUE" if judged else "NA"


# 不写 apply：它说的是「谁咬的」，不是「哪一格变成什么色」。
# 被咬那块件飞到哪由 captured_piece_flung_ten 管，露出来的那只画在哪几格
# 要先知道它的形状与落点——那是 mover14_hunts_like_mover7 那条的活，而它对
# 「从件底下钻出来」这一档一次观测都没有。这里只判，不生成。
