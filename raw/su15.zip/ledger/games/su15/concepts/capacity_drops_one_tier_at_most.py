"""棋盘点击后，帧上读出的件的容量总和（Σ 2^(级-1)）绝不增加；降幅只能是 0 或者恰好一件降一级的差额（2^(级-2)，即 1/2/4/8/16 之一）——一步里最多一件掉一级，而合成一格不改容量。"""
LEVEL = "L4"
SCOPE = ("只看棋盘点击（ACTION6 且 10<y<63）；换关返回 NA（整张棋盘换掉，件也换掉）；"
         "prev 上读不出任何件返回 NA；**两端的件清单一律从帧上读（_lib.pieces），不走 after_click，"
         "也不问任何捕获模型**——这条概念的可判错性不挂在别的假设上")
NOTE = ("v1: 接手 capacity_conserved_without_capture（撤册见 journal 第 301 步）。它押的是「没被捕获就容量守恒」，"
        "三条反例（第105、147、197 步）都是真有件被降级而 captured_pieces 没报出来——"
        "新件豁免吃掉两条（第197步是那条豁免自己公开的反例），色14 当捕获者吃掉一条。"
        "教训是**别把一条概念的 scope 挂在另一个带公开反例的假设上**：那等于把自己的可判错性外包出去。"
        "换成这一句之后不需要知道是谁降的级：三条反例在这里都判 TRUE（12→10 是一件3级降2级、"
        "48→32 和 36→20 都是一件6级降5级），而它仍然能被打脸——"
        "件凭空多出来、凭空消失、一步降两件、或者一步降两级，四种都会让它判 FALSE。"
        "它同时是 _lib.capacity 第一次被拿去和帧对：settle 的词汇表审计说这个词被 7 条概念引用却一次没走过闸，"
        "而「合成守恒容量」在 after_click 的口径下是恒真的（capacity(t)=2^(t-1) 与「两件 t 级并成一件 t+1 级」"
        "是同一个定义的两面），只有从帧上重读两端才问得出东西。"
        "策略上的用处：本关容量只减不增，所以容量一旦掉到顶带样板的需求以下，这一关就再也救不回来——"
        "只能 RESET。这半句由 level_dead_when_capacity_short 从另一侧（帧上变色2）盯着。"
        "**故意留在主张里的口子**：pieces 读漏一块就会判 FALSE（第 157 步预算条盖住件角那次就是这样）。"
        "那不是冤枉，读漏了就该在这儿响，补丁在 _lib.pieces 里。"
        "v2: 死于三条反例——第125步 [2,2,2,2,6]→[2,2,3,5]、第128步 [3,3,5]→[4,4]、第278步 [1,1,2,2,2]→[1,1,1,3]。"
        "三步都是**同一次点击里既合成又有件被捕获降级**，而 v1 要求「级多重集之差恰好换一件」，"
        "合成那一半把多重集改乱了，于是三步全判 FALSE。**容量这个数三次都是对的**："
        "40→24 降 16（一件6级降5级）、24→16 降 8（5降4）、8→7 降 1（2降1）。"
        "所以 v1 错在把主张写得比要说的事更细：我要说的是「一步最多丢一件的一级」，"
        "写出来的却是「级多重集只许动一件」，后者连合成都不许发生。"
        "v2 只看降幅落不落在允许集里，合成随便发生几次都不碍事。"
        "**v2 松掉的那一档写明**：一件 1 级件被整件抹掉也会让容量降 1，和「2 级降成 1 级」在这条概念眼里一模一样；"
        "要分开得数件数（件数只因合成而减，降级不改件数），那是另一条概念的事，这里不兼职。")
EVIDENCE = ["c94a4148ec6fa09d", "6c9b38473b305447", "b618e04c4015cd0f",
            "f69577c44363eda4", "868bde228addb7ee", "486b7e7f14c80576",
            "1daa73845b1d672d", "5051ca19350e3958", "dd0ca11555d721f2"]

from _lib import click_xy, pieces, capacity, TIER_OF_COLOR, TOP_BAND_LAST_ROW, BUDGET_ROW

# 允许的降幅：0，或者某一级降一级的差额 2^(t-1) - 2^(t-2)。级从本局词汇的件色表来，不另立一张表。
_TIERS = set(TIER_OF_COLOR.values())
_DROPS = {0} | {capacity(t) - capacity(t - 1) for t in _TIERS if t - 1 in _TIERS}


def _total(ps):
    return sum(capacity(t) for t, _, _ in ps)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return "NA"
    a = pieces(prev)
    if not a:
        return "NA"
    drop = _total(a) - _total(pieces(nxt))
    return "TRUE" if drop in _DROPS else "FALSE"
