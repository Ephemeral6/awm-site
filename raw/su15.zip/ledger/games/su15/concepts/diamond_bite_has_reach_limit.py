"""色14 与它的目标件的归一化距离超过 8.2 时，这件这一步不掉级。

也就是说：**咬是有射程的**，射程之外这件安全；射程之内册子分不出咬不咬（那一半在 SCOPE 里让出去）。

由来（probe_710sep.out，全语料里前后各恰好一只色14 的棋盘点击 99 条，
按「这只色14 的目标件在下一帧掉没掉级」分堆）：

  · 掉级的 10 条，归一化距离 pounce_hdist 从 -0.25 到 **8.18**；
  · 没掉级的 89 条，从 -1.25 到 23.13。

两堆在 8.18 以下完全重叠——**近了就咬这个形状是假的**，同一件同一只色14，
第 486/705/707 步距离 4.50 到 5.50 一次没咬，第 505/509/710 步 7.58 到 8.18 三次全咬，方向还是反的。
所以这里不碰「什么时候咬」，只认下半句：**8.18 之外一次都没咬过**。

这是一条明摆着的外推：8.18 是语料里咬得最远的那一次，下一次咬得更远就把它打死。
写成概念正是为了让它能被这么打死——现在它躲在 `pounces` 的阈值 8.14 里，
第 710 步的世界在 8.18 处咬了一口，而册子只是安静地说「不捕」。

SCOPE 让出去的三处：距离不超过 8.18（册子说不出）；帧上色14 不是恰好一只（归因说不清）；
色7 的落点压在同一件上（那一口可能是色7 咬的，这条概念不背）。

两条目标读法（`mover_target` 给不给 ps_prev）都要在射程之外才算安全——分不出读法的时候按会出事的那一读算，
这是 `mover14_hunts_like_mover7` 的 NOTE v7 立下的规矩。
"""
LEVEL = "L6"
SCOPE = ("只看世界接受的棋盘点击（ACTION6 且落在棋盘行内）；换关返回 NA；"
         "帧上色14 不是恰好一只、名册读不出、目标算不出来，返回 NA；"
         "两条目标读法里任一条的 pounce_hdist 不超过 BITE_REACH，返回 NA（那一半册子说不出）；"
         "有色7 的落点压在目标件上，返回 NA（归因说不清）")
NOTE = ("v2（第 711 步）：射程从 8.18 抬到 8.2。v1 被自己的 EVIDENCE 打脸——"
        "第 710 步那一口的 hdist 算出来是 8.180000…，浮点上严格大于写死的 8.18，"
        "于是它落进了「射程之外」那一半，被自己判 FALSE。"
        "但这条概念主张的从来是「比语料里咬得最远的那一口**更远**才安全」，"
        "8.18 是那一口本身的读数，不该算在安全的一边。取 8.2 这个整齐数把边界让出来，"
        "语料里 8.18 到 8.2 之间一条数据都没有，所以这一改不动任何一条判词，只把边界从口上挪开。"
        "射程还是可以被打死的：下一次咬得比 8.2 更远就是反例。")
EVIDENCE = [
    "eb6938351f25f968",   # 第 148 步 ACTION6:49,52
    "4c03f924d06b071c",   # 第 149 步 ACTION6:56,55
    "f821dbd68a208703",   # 第 150 步 ACTION6:56,57
    "a0b94bd040a140f3",   # 第 151 步 ACTION6:6,19
    "16ec5df9f176d780",   # 第 164 步 ACTION6:21,45
    "896e274a965f31be",   # 第 165 步 ACTION6:28,50
    "fcb6d6ef8dbe6d46",   # 第 710 步 ACTION6:7,27 催生它的那一口，hdist 8.180
]

from _lib import (BUDGET_ROW, DIAMOND_COLOR, MOVER_COLOR, TOP_BAND_LAST_ROW,
                  after_click, capture_landing, click_xy, creatures, mover_target,
                  piece_cells, pieces, pounce_hdist)

BITE_REACH = 8.2           # 语料里色14 咬得最远的那一口是 8.180；这条概念主张比它更远就咬不到


def _setup(prev, action):
    """返回 (色14 那一块, 两条读法下的目标集合, 点击后名册)；说不出返回 None。"""
    if not action.startswith("ACTION6"):
        return None
    xy = click_xy(action)
    if xy is None or not (TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW):
        return None
    objs = [frozenset(o) for o in creatures(prev, DIAMOND_COLOR)]
    if len(objs) != 1:
        return None
    ps_prev = pieces(prev)
    ps = after_click(prev, action)
    if not ps_prev or not ps:
        return None
    tgts = {mover_target(objs[0], ps, back) for back in (ps_prev, None)}
    tgts.discard(None)
    if not tgts:
        return None
    return objs[0], tgts, ps


def _out_of_reach(obj, tgts):
    """两条读法的目标都在射程之外才算安全。"""
    try:
        return min(pounce_hdist(obj, t) for t in tgts) > BITE_REACH
    except Exception:                                            # noqa: BLE001
        return None


def _mover7_covers(prev, tgts, ps):
    """有没有色7 的落点压在其中某个目标件上——有就归因说不清。"""
    occupied = {cell for p in ps for cell in piece_cells(p)}
    shape = (len(prev), len(prev[0]))
    for h in creatures(prev, MOVER_COLOR):
        h = frozenset(h)
        for back in (None,):
            try:
                t, land = capture_landing(h, ps, occupied, MOVER_COLOR,
                                          ps_prev=back, shape=shape)
            except Exception:                                    # noqa: BLE001
                return True
            if t in tgts and land and (land & piece_cells(t)):
                return True
    return False


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    st = _setup(prev, action)
    if st is None:
        return "NA"
    obj, tgts, ps = st
    far = _out_of_reach(obj, tgts)
    if far is None or not far:
        return "NA"
    if _mover7_covers(prev, tgts, ps):
        return "NA"
    ps_real = pieces(nxt)
    if not ps_real:
        return "NA"
    for t in tgts:
        if t in ps_real:
            continue
        if any(q[0] == t[0] - 1 for q in ps_real if q not in ps):
            return "FALSE"
    return "TRUE"
