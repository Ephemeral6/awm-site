"""ACTION6:x,y 的 y 落在顶部色4带（行0-9）内时点击不生效，整帧一格不动。"""
LEVEL = "L2"
SCOPE = "只看 ACTION6:x,y（x=列 y=行）；y>=10 返回 NA 交给别的概念；坐标解析不出来返回 NA"
NOTE = ""
EVIDENCE = ["9e91564de215ec53", "8571ad9a47d3a9a1", "4085788716e26f0a"]

TOP_BAND_LAST_ROW = 9


def _xy(action):
    """'ACTION6:59,4' -> (59, 4)，即 (列, 行)。解析不出来给 None。"""
    if not action.startswith("ACTION6:"):
        return None
    try:
        a, b = action.split(":", 1)[1].split(",")
        return int(a), int(b)
    except ValueError:
        return None


def assert_(prev, action, nxt, ctx=None):
    xy = _xy(action)
    if xy is None:
        return "NA"
    x, y = xy
    if y > TOP_BAND_LAST_ROW:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"


def apply(prev, action, ctx=None):
    xy = _xy(action)
    if xy is None:
        return None
    x, y = xy
    if y > TOP_BAND_LAST_ROW:
        return None
    return {}          # 明说：一格都不变
