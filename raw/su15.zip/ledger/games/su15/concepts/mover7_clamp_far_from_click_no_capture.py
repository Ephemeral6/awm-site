"""棋盘点击被世界接受、这一 click 没有任何捕猎者（色7 或色14）的 clamp 落点压在点击后的件上时，每一只离点击点超过 REACH、认身份目标不是这一 click 的新件、认身份目标与「点击后最近」目标同一件且不并列的色7，其 clamp 落点（逐轴 floor(diff+0.5) 夹到 ±MOVER_STEP、逐子步碰件即停、出帧整块塞回）整块出现在下一帧的色7 格里。"""
LEVEL = "L6"
SCOPE = ("只看世界接受了的棋盘点击（ACTION6 且 10<=y<63）。整条返回 NA 的情形：点顶带、非点击动作；"
         "换关（ctx.level_prev != level_next）；世界整条驳回（除第 63 行外整帧不变，只 assert_ 用得上）；"
         "prev 上没有色7、没有件、after_click 说不出或为空、nxt 上没有色7；hunters(prev) 说不出（色14 块读不准）；"
         "**这一 click 有任何捕猎者的 capture_landing 压在点击后的件上**（ANYCAP：这一步要发生捕获，落点模型的前提「件清单不变」不成立）。"
         "逐只闭嘴（不算这一只）的情形：mover_target_ambiguous 为真（AMBIG）；认身份目标 != 点击后最近目标（DOUBT）；"
         "认身份目标是这一 click 刚搬来/合出的新件（FRESHTGT）；这一只到点击点的最近格欧氏距离不超过 REACH(8)（NEARCLK）；"
         "**这一只的落点与另一只色7 的落点挨到 2 格以内（MERGE：它俩要并成色14，下一帧它不再是色7；"
         "闸抄自 movers_merge_on_immune_piece 的 _too_close/_NEAR，见 NOTE v2）**。"
         "一只都没开口返回 NA。开口的每一只落点整块不在 nxt 的色7 格里就 FALSE。")
NOTE = ("v1（子 agent 离线量出来的片，没读主 agent 的推理）。"
        "**怎么量的**：runs/su15-0916-1554/probe_clamp_scope.py（口径写死在头注）、probe_clamp_scope2/3/4.py（换 gate 池与目标函数）、"
        "probe_clamp_check.py（本文件在全语料上的 TRUE/FALSE/NA 与 apply 逐格账）。"
        "语料 470 行按 tid 去重 441 条转移，转移层入选 221 条（不换关、棋盘点击、前后都有色7、有件、after_click 说得出），"
        "逐只枚举 431 只色7；判据是包含式的 land <= mover(nxt)，**不要求前后只数相等、不排除合并、不配对**"
        "（和 probe_mover7_land.py 的 207 条 / 385 只不是一个分母，别混比）。"
        "clamp 在全部 431 只上命中 330、落空 101。把 101 只落空按 42 个可事前判定的特征分箱，"
        "以「片内落空 = 0」为硬约束、用分支限界求精确最优的 gate 组合："
        "允许事后 gate（读 nxt）时最优 {CAPDROP, AMBIG, DOUBT, ROWFREE, NEARCLK12} 片内 167 只；"
        "**只许事前 gate** 时，CAPDROP 的事前替身 ANYCAP（某捕猎者落点压件）只漏它 3 只，"
        "最优 {AMBIG, DOUBT, PRESS, NEARCLK20, ANYCAP} 片内 136 只——但 20 这个阈值是拟合出来的，词汇表里没有；"
        "本条用的是**只含词汇表常数**的次优 {FRESHTGT, AMBIG, DOUBT, NEARCLK(REACH=8), ANYCAP}："
        "probe_clamp_check：全语料 441 条上 TRUE 95 / FALSE 0 / NA 346，开口 128 只（全中）；"
        "TRUE 逐关 关3 11 / 关4 29 / 关5 12 / 关6 15 / 关7 15 / 关8 13 条转移（按只数：关7 24 只、关8 30 只）。"
        "片外 303 只（431 - 128）没人管：101 只是 clamp 真落空、202 只是 clamp 其实中了但被 gate 一并闭嘴的。"
        "**每道前提是谁逼出来的**（这只落空在最终 gate 组里只被这一道盖住，拿掉它片内就有反例；全表在 probe_clamp_check.out）："
        "AMBIG ← 692efadd54216427（第 270 步）、5ded0d99160d14ed（第 295 步），全语料只这 2 只，命中里 0 只。"
        "DOUBT ← cd950387dad1e047（196）、e4198aec65a3e257（199）、0ff48b6d48da537f（205）、c3a61c9ad1e453de（321：三只色7 盯同一件，押 (-4,-4) 实走 (+1,-4)）。"
        "FRESHTGT ← 11 只，含 868bde228addb7ee（147：目标是新件、gap 10、点击距 13、押 (0,+4) 实走 (-4,-2)）、"
        "896e274a965f31be（165）、b6e4569d87727d29（166）、77104a652ac235d8（177）、b36a92f8960d257a（187，两只）、f7a2712626fa5938（267）、"
        "a6510b83e3280092（314）、**49b0af89c3c91569（395）与 5decbc9ac0cd977a（405）——撤掉两条老概念的那两只反例，目标都是这一 click 的新件**、"
        "a78e3030fe57a0d2（396）。"
        "NEARCLK ← 单独逼出它的只有 d7bd73b60db1ad8e（第 403 步）；其余点击距不超过 8 的落空（第 133 步 47c0ea0adb89577f、"
        "终局卡第 446~458 步 00a784a0326b39b1 / f60c878a513a0c87 / 7c182c30366947d4 / d9a83418277fea77 / db63d14b62e2a700 / 180ea5b563c7456c，"
        "色7 被甩 8~12 格）同时也是 FRESHTGT。留它是因为它**不花钱**：330 只命中里最小点击距 8.54，点击距不超过 8 的 54 只全落空，8 = REACH 本来就在词汇表里。"
        "ANYCAP ← 13 只 / 9 条转移：cc66821f33a01c2e（123）、9f69a0fa4c7fe868（134）、766c3c0aee19eb7c（158）、4684c139bd72c11b（178）、"
        "c09968087b7b08e9（192）、6a06d57b280f31fc（200）、1e8e55a0a15b981b（211，三只）、bb58edd1c88b9f9d（324，两只）——"
        "这一 click 另一只捕猎者压件，被捕的件被甩，这只色7 的目标清单随之作废。"
        "**最可能在哪碎**：(1) 点击距 (8, 10] 这一档命中 20 落空 14（那 14 只都被 FRESHTGT 盖住了），界画在 8 是因为词汇表里有 REACH，"
        "不是因为 8 与 10 之间量清楚了——第一只「点击距 8~10、目标不是新件」的落空最先出现；"
        "(2) ANYCAP 依赖 capture_landing 对色14 的「扑」读法，那读法自己有反例（第 329 步）；"
        "(3) 世界的整条驳回（REACH 内恰好一件、原因未知的那 12 次，见 click_two_tiers_refused 的 NOTE）在 assert_ 里是 NA，"
        "在 apply 里挡不住——apply 只挡了 will_level_up。语料里片内 95 条转移没有一条是被驳回的、apply 开口的 87 条里换关 0 条、驳回 0 条"
        "（probe_clamp_check.out），但那是运气不是判据。"
        "apply 逐格账：TRUE 转移上落点格 936 对 0 错、腾出的旧格 914 对 0 错；全语料认领 1850 格 0 错。"
        "**两条撤册概念错在哪、这条为什么不重蹈**：mover7_lands_when_target_unique 用 ROWFREE/FLINGANY/DOUBT/AMBIG 四道闸，"
        "片内 235 只里落空 14（probe_clamp_scope.out 第四刀 I 行）——它的 SCOPE 是按「哪些档说得通」写的，不是按「哪些档零反例」量的；"
        "mover7_lands_when_step_not_clamped 取它的补集，同样没量；两条被打死的那两只，目标都是**这一 click 刚搬来的新件**，"
        "FLINGANY（离新件不超过 REACH）圈不住它们（gap 分别超过 REACH）。本条的每道前提都是从 101 只落空里逼出来的，"
        "并在全语料 431 只上验过片内 0 落空；代价是片只有 128 只，而且全是事前算得出的量。"
        "\n\nv2（第 460 步之后由主 agent 提拔进册子，断言与 apply 一个字没改）："
        "**EVIDENCE 从交来的 95 条收到 33 条**。交来的那 95 条正好是全语料上判 TRUE 的全部转移，"
        "抄全了的后果是 held-out 为空、settle 报 S=UNMEASURABLE —— 把全部确证抄进依据不是更强的证据，"
        "是把检验面积清零。留下的 33 条是：逼出五道前提的那 28 条（AMBIG 2 / DOUBT 4 / FRESHTGT 11 / "
        "NEARCLK 1 / ANYCAP 10，逐条见上）＋ 5 条正面读数。**拿掉的 62 条一条没删**，"
        "它们现在是 held-out，每一批结算照常考这条概念。"
        "\n提拔的用处写明：规划器的 `_model_silent` 从第 405 步起对每一只不参与合并的色7 整片闭嘴，"
        "因为两条 clamp 概念都撤了、`_lib` 那条公式再没概念背书。这一条把其中一片背了回来，"
        "规划器在这一片里可以照它画整帧——**取的是这个文件本身，不是重写一份公式**。"
        "\nv2（第 499 步）：加第五道逐只闸 MERGE，缩 scope，不动断言本体。"
        "由来 aaa9c5f96f2a77f0（第 498 步 ACTION6:0,62）判 FALSE：点击落在左下角，"
        "而右上方两只色7 自己并成了一只色14（帧差里 (22,26) 7→14、(21,25) 与 (20,26) 5→14）。"
        "clamp 算没算对它俩的落点，这条转移没资格说——并完它不再是色7，"
        "而本条主张的是落点整块出现在下一帧的**色7** 格里。"
        "v1 的 NOTE 自己写着当时量的口径「不要求前后只数相等、**不排除合并**、不配对」，"
        "碎在这儿是那一行早写明的敞口，不是意外。"
        "闸的读法整个抄 movers_merge_on_immune_piece 的 _too_close 与 _NEAR=2（它的 NOTE v12 与 SCOPE 末条："
        "落点互相挨到 2 格以内的那一类不压砧板也会并），**没有自己发明阈值**；"
        "只把那条概念的「整条 NA」改成逐只闭嘴：挨上的那两只不算数，同一 click 上离得远的其余色7 照旧受检。")
EVIDENCE = [
    # 正面读数（片内命中）
    "1c3a9aa1bacfeea4", "794f23e15d31c5a6", "2d285b1a57d37411", "aa3f94c86eff12cb", "ab2d69a7b53618e0",
    # MERGE 逼出来的（v2 的由来，本条 v1 在它上面判 FALSE）
    "aaa9c5f96f2a77f0",
    # AMBIG 逼出来的
    "692efadd54216427", "5ded0d99160d14ed",
    # DOUBT 逼出来的
    "cd950387dad1e047", "e4198aec65a3e257", "0ff48b6d48da537f", "c3a61c9ad1e453de",
    # FRESHTGT 逼出来的（含打死两条老 clamp 概念的那两只）
    "868bde228addb7ee", "896e274a965f31be", "b6e4569d87727d29", "77104a652ac235d8", "b36a92f8960d257a",
    "f7a2712626fa5938", "a6510b83e3280092", "49b0af89c3c91569", "5decbc9ac0cd977a", "a78e3030fe57a0d2",
    # NEARCLK 单独逼出来的
    "d7bd73b60db1ad8e",
    # ANYCAP 逼出来的
    "cc66821f33a01c2e", "9f69a0fa4c7fe868", "766c3c0aee19eb7c", "4684c139bd72c11b", "c09968087b7b08e9",
    "6a06d57b280f31fc", "1e8e55a0a15b981b", "bb58edd1c88b9f9d",
]

from _lib import (TOP_BAND_LAST_ROW, BUDGET_ROW, BG, MOVER_COLOR, MOVER_STEP, OCT_COLOR, REACH, click_xy,
                  after_click, capture_landing, hunters, mover, movers, mover_target, mover_target_ambiguous,
                  pieces, piece_cells, piece_gap, octagons, will_level_up)


def _board_click(action):
    xy = click_xy(action)
    return xy is not None and TOP_BAND_LAST_ROW < xy[1] < BUDGET_ROW


def _refused(prev, nxt):
    """世界整条驳回了这一 click：除第 63 行（预算条照样被吃）外整帧一格不变。事后量，只 assert_ 用。"""
    return all(prev[r] == nxt[r] for r in range(len(prev)) if r != BUDGET_ROW)


def _setup(prev, action):
    """整条前提。能开口时返回 (色7 并集, 点击后件清单, 点击前件清单, 件占的格, 新件清单, 各只落点)；否则 None。"""
    if not _board_click(action):
        return None
    a = mover(prev)
    if a is None:
        return None
    ps_prev = list(pieces(prev))
    if not ps_prev:
        return None
    ps = after_click(prev, action)
    if not ps:
        return None
    hs = hunters(prev)
    if hs is None:
        return None                                  # 色14 块读不准 → 压没压件说不出
    occupied = {cell for p in ps for cell in piece_cells(p)}
    shape = (len(prev), len(prev[0]))
    lands = {}
    for obj, colour, use_id in hs:
        _t, land = capture_landing(obj, ps, occupied, colour, ps_prev=ps_prev if use_id else None, shape=shape)
        if land & occupied:
            return None                              # ANYCAP：这一步要捕获，件清单会变，落点模型的前提不成立
        if colour == MOVER_COLOR:
            lands[obj] = land
    fresh = [p for p in ps if p not in ps_prev]
    return a, ps, ps_prev, occupied, fresh, lands


def _near_click(obj, action):
    x, y = click_xy(action)
    return min(((r - y) ** 2 + (c - x) ** 2) ** 0.5 for r, c in obj) <= REACH


# _NEAR 抄自 movers_merge_on_immune_piece 的同名常量（它的 NOTE v12 与 SCOPE 末条）：
# 两只同色物件的落点挨到 2 格以内，不压砧板也会并。这里不是新阈值，是搬它那一条已经走过闸的闸。
_NEAR = 2


def _merging(obj, lands):
    """MERGE：这一只的落点和另一只色7 的落点挨到 _NEAR 格以内——它俩要并成色14。

    由来是 aaa9c5f96f2a77f0（第 498 步 ACTION6:0,62），本条 v1 判 FALSE 的那一条：
    点击在左下角 (0,62)，而右上方两只色7 自己并了，帧上 (22,26) 7→14、(21,25) 与 (20,26) 5→14。
    clamp 把它俩的落点算对了没有，这条转移根本没资格说——**并完它不再是色7**，
    而本条主张的是「落点整块出现在下一帧的**色7** 格里」。v1 的 NOTE 自己写着当时量的时候
    「不要求前后只数相等、**不排除合并**、不配对」，碎在这儿不算意外，是那一行早写明的敞口。

    读法整个抄 movers_merge_on_immune_piece._too_close（同样的 capture_landing 落点、同样的
    切比雪夫最近距离、同样的 _NEAR），只把「整条 NA」改成**逐只闭嘴**：
    挨上的那两只不算数，同一 click 上离得远的其余色7 照旧开口受检。"""
    mine = lands.get(obj)
    if not mine:
        return False
    for other, land in lands.items():
        # `other == obj` 而不是 `other is obj`：`lands` 的键是 _setup 里从 hunters(prev) 取的那批
        # 物件，传进来的 obj 是 assert_/apply 里从 movers(a) 重新取的，两者相等但不是同一个对象。
        # 写成 is 的后果第 499 步当场量到了：每一只都和自己比、距离 0、于是全体闭嘴，
        # 这条概念 N 从三位数掉到 0（S=UNMEASURABLE）。缩 scope 缩到一句话都不说，等于删了它。
        if other == obj or not land:
            continue
        if min(max(abs(r - rr), abs(c - cc))
               for r, c in mine for rr, cc in land) <= _NEAR:
            return True
    return False


def _hushed(obj, ps, ps_prev, fresh, action, lands):
    """逐只前提。五道全是事前量。"""
    if mover_target_ambiguous(obj, ps, ps_prev):
        return True                                  # AMBIG：目标这个词没有定义
    tgt = mover_target(obj, ps, ps_prev)
    if tgt != mover_target(obj, ps, None):
        return True                                  # DOUBT：两种读法挑的不是同一件
    if tgt in fresh:
        return True                                  # FRESHTGT：盯着刚搬来/合出的件
    if _near_click(obj, action):
        return True                                  # NEARCLK：离点击点不超过 REACH
    if _merging(obj, lands):
        return True                                  # MERGE：要并成色14，下一帧它不再是色7
    return False


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if not _board_click(action):
        return "NA"
    if _refused(prev, nxt):
        return "NA"                                  # 世界驳回这一 click，不是运动学
    s = _setup(prev, action)
    if s is None:
        return "NA"
    a, ps, ps_prev, occupied, fresh, lands = s
    b = mover(nxt)
    if b is None:
        return "NA"
    spoke = 0
    for obj in movers(a):
        if obj not in lands or _hushed(obj, ps, ps_prev, fresh, action, lands):
            continue
        spoke += 1
        if not (lands[obj] <= b):
            return "FALSE"
    return "TRUE" if spoke else "NA"


def apply(prev, action, ctx=None):
    """逐只认领，和 assert_ 同一个粒度：开口的那些只认领落点（色7）与腾出的旧格（底色 / 已知色9）。
    闭嘴的那些只：旧格外扩 MOVER_STEP 一圈整片不认领（它去哪没模型，但位移两轴都夹在 ±MOVER_STEP 内）；
    其中离新件不超过 REACH 的那一档（甩飞档）能被扔到十几格外，整条不认领。
    能事前挡的只有换关（will_level_up）；世界整条驳回事前挡不住（见 NOTE 第 (3) 条）。"""
    if not _board_click(action) or will_level_up(prev, action):
        return None
    s = _setup(prev, action)
    if s is None:
        return None
    a, ps, ps_prev, occupied, fresh, lands = s
    objs = movers(a)
    keep, hush = [], set()
    for obj in objs:
        if obj not in lands:
            return None
        if fresh and min(piece_gap(obj, p) for p in fresh) <= REACH:
            return None                              # 甩飞档
        if _hushed(obj, ps, ps_prev, fresh, action, lands):
            r0 = min(r for r, _ in obj) - MOVER_STEP; r1 = max(r for r, _ in obj) + MOVER_STEP
            c0 = min(c for _, c in obj) - MOVER_STEP; c1 = max(c for _, c in obj) + MOVER_STEP
            hush |= {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
            continue
        keep.append(obj)
    if not keep:
        return None
    allland = set().union(*(lands[o] for o in keep))
    out = {}
    for obj in keep:
        for cell in lands[obj]:
            out[cell] = MOVER_COLOR
    known, unsure = octagons(prev)
    for obj in keep:
        for cell in obj - allland - occupied:
            if cell in unsure:
                continue
            out[cell] = OCT_COLOR if cell in known else BG
    return {cell: v for cell, v in out.items() if cell not in hush} or None
