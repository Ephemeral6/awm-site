/-
# Derived/VesselStill —— 容器只被倾倒和盖章改（对应 `rule/move/vessel_still.py`，身份：**推论**）

Python 那边它是一条要逐帧判的规则（pour / stamp 的上界）。在 Lean 里它**不是独立的一条**：
`act` 的分发里只有倾倒和盖章那两支写了 `vessel := …`，其余每一支都原样带着容器——
所以它是分发本身推出来的，写成定理。

    方向键       容器不变
    点中色环     容器不变
    什么都没点中  容器不变
-/

import Step

namespace Game

theorem vessel_still_keys (b : Board) (s : St) :
    (act b s .up).vessel = s.vessel ∧ (act b s .down).vessel = s.vessel ∧
    (act b s .left).vessel = s.vessel ∧ (act b s .right).vessel = s.vessel := by
  simp [act]

theorem vessel_still_swatch (b : Board) (s : St) (r c : Nat) (sw : Swatch)
    (h : swatchHit b.palette r c = some sw) :
    (act b s (.click r c)).vessel = s.vessel := by
  simp [act, h]

theorem vessel_still_miss (b : Board) (s : St) (r c : Nat)
    (h1 : swatchHit b.palette r c = none) (h2 : stampHit b s r c = false) :
    (act b s (.click r c)).vessel = s.vessel := by
  simp [act, h1, h2]

#print axioms vessel_still_keys
#print axioms vessel_still_swatch
#print axioms vessel_still_miss

end Game
