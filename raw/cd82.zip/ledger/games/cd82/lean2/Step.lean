/-
# Step —— 一步怎么走：**只做分发，0 条定理**

每一支都交给一条规则（`Rule/`），这里不加任何新说法：

    方向键            工位 := Turn.turnBy
    倾倒              容器 := Pour.pour
    点击              点中色环 → 颜料色 := PickPaint；点中在场小杯描边 → 容器 := Stamp.stamp；否则原样
    重来              局面 := BackToStart.start

算完这一步之后（重来除外）按顺序问两件事：

    容器 = 目标图？（LevelUp.isGoal）     → `won`
    钟走到这一步预算归零？（GameOver.overAt） → `over`
    都不是                                 → `ok`，钟 +1

「过关与归零同时发生时谁先」语料里没有这样一步；这里取过关在先，**这一句没被检验过**。
-/

import Rule.Move.Turn
import Rule.Move.PickPaint
import Rule.Move.SpoutFollows
import Rule.Move.Pour
import Rule.Move.Stamp
import Rule.Move.Budget
import Rule.Outcome.LevelUp
import Rule.Outcome.GameOver
import Rule.Respond.BackToStart

namespace Game

/-- 这一步之后的状态（钟不动）。 -/
def act (b : Board) (s : St) : Act → St
  | .click r c =>
      match swatchHit b.palette r c with
      | some _ => { s with paint := pickPaint b s.paint r c }
      | none   => if stampHit b s r c then { s with vessel := stamp s } else s
  | .pour  => { s with vessel := pour s }
  | .reset => start
  | a      => { s with pose := turnBy s.pose a }

def step (b : Board) (s : St) : Act → Res
  | .reset => .ok start
  | a =>
    if isGoal b (act b s a) then .won
    else if overAt (s.clock + 1) then .over
    else .ok { act b s a with clock := s.clock + 1 }

end Game
