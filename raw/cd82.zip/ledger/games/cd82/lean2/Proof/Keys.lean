/-
# Proof/Keys —— 两把「不可做」的钥匙，每把配一张**只差一处**的对照盘

语料里六关**全部走通了**（`Proof/Levels`），所以没有哪一关的真实开局要证「走不通」。
这一份证明的是：**这套模型会说「走不通」，而且说得出为什么**——不然「每关都走得通」也可能只是
一个什么都判成可做的模型。两把钥匙的理由真的不同：

    钥匙一（颜色守恒）  目标图里有一种颜色，既不是 0 也不在色板上 ⇒ 容器里永远涂不出它
    钥匙二（分不开的一对格）  没有小杯的盘上，四条分界线都分不开的两格永远同色；
                          目标图要它们不同 ⇒ 赢不了（盘上一个障碍都没有）

**两把钥匙的结论都是「不经过重来就赢不了」**（`Unsolvable` 只对合法的、不含重来的动作串说话）。

## 三条防线（每把钥匙各三条）

    _control_winnable      对照盘**确实赢得了**（真实那一关的走法，内核算）
    _control_closed        而且不是因为它一开局就赢了
    _control_not_key       而且那把钥匙的**前提在对照盘上真的不满足**——不是「没找到证明」

对照盘就是真实的那一关；钥匙盘只改了一处（钥匙一：拿掉一个色环；钥匙二：拿掉小杯）。
-/

import Proof.Levels

namespace Game
namespace Keys
open Replay Levels

set_option maxRecDepth 100000

/-! ## 通用的小引理 -/

theorem swatchHit_mem : ∀ (l : List Swatch) (r c : Nat) (sw : Swatch),
    swatchHit l r c = some sw → sw ∈ l := by
  intro l r c sw
  induction l with
  | nil => simp [swatchHit]
  | cons x xs ih =>
    simp only [swatchHit]
    split
    · intro h; injection h with h; subst h; exact List.mem_cons_self
    · intro h; exact List.mem_cons_of_mem _ (ih h)

theorem ofTab_mem (l A : List Nat) (h0 : 0 ∈ A) (hl : ∀ x ∈ l, x ∈ A) :
    ∀ r c, Vessel.ofTab l r c ∈ A := by
  intro r c
  simp only [Vessel.ofTab]
  cases h : l[r * SIZE + c]? with
  | none => exact h0
  | some x => exact hl x (List.mem_of_getElem? h)

/-! ## 钥匙一：颜色守恒 -/

/-- 容器里可能出现的颜色：开局的 0，和色板上每个环的芯色。 -/
def allowed (b : Board) : List Nat := 0 :: b.palette.map (·.color)

/-- Φ₁：颜料色和容器里每一格都在 `allowed` 里。 -/
def ColorKey (b : Board) (s : St) : Prop := s.paint ∈ allowed b ∧ ∀ r c, s.vessel r c ∈ allowed b

/-- 钥匙一的前提：目标图里有一格的颜色不在 `allowed` 里。 -/
def ColorPremise (b : Board) : Prop := ∃ r, r < 10 ∧ ∃ c, c < 10 ∧ b.target r c ∉ allowed b

instance (b : Board) : Decidable (ColorPremise b) := by unfold ColorPremise; infer_instance

theorem colorKey_act (b : Board) (s : St) (a : Act) (ha : legal a = true) (h : ColorKey b s) :
    ColorKey b (act b s a) := by
  obtain ⟨hp, hv⟩ := h
  cases a with
  | reset => simp [legal] at ha
  | pour =>
    refine ⟨hp, fun r c => ?_⟩
    show (if inHalf s.pose r c then s.paint else s.vessel r c) ∈ allowed b
    split
    · exact hp
    · exact hv r c
  | click r c =>
    simp only [act]
    split
    · rename_i sw hsw
      refine ⟨?_, hv⟩
      simp only [pickPaint, hsw]
      exact List.mem_cons_of_mem _ (List.mem_map.2 ⟨sw, swatchHit_mem _ _ _ _ hsw, rfl⟩)
    · split
      · refine ⟨hp, fun r' c' => ?_⟩
        show (if inBand s.pose r' c' then s.paint else s.vessel r' c') ∈ allowed b
        split
        · exact hp
        · exact hv r' c'
      · exact ⟨hp, hv⟩
  | up => exact ⟨hp, hv⟩
  | down => exact ⟨hp, hv⟩
  | left => exact ⟨hp, hv⟩
  | right => exact ⟨hp, hv⟩

theorem colorKey_keep (b : Board) :
    ∀ s s' a, legal a = true → ColorKey b s → step b s a = .ok s' → ColorKey b s' := by
  intro s s' a ha h hs
  rw [step_ok b s s' a ha hs]
  exact colorKey_act b s a ha h

theorem colorKey_no_win (b : Board) (hp : ColorPremise b) :
    ∀ s a, legal a = true → ColorKey b s → step b s a ≠ .won := by
  intro s a ha h hw
  obtain ⟨r0, hr, c0, hc, ht⟩ := hp
  have hg := step_won b s a ha hw
  have hk := colorKey_act b s a ha h
  have he := same_at (act b s a).vessel b.target hg r0 c0 hr hc
  exact ht (he ▸ hk.2 r0 c0)

/-- **钥匙一**：前提成立、开局满足 Φ₁ ⇒ 不经过重来就赢不了。 -/
theorem unsolvable_by_color (b : Board) (s : St) (hp : ColorPremise b) (h : ColorKey b s) :
    Unsolvable b s :=
  unsolvable_of_invariant b (ColorKey b) (colorKey_keep b) (colorKey_no_win b hp) s h

/-- 钥匙一的盘：第 2 关的真实版面，**只拿掉芯色 14 的那个色环**。 -/
def colorBoard : Board :=
  { L2_board with palette := L2_board.palette.filter (fun sw => sw.color != 14) }

theorem color_premise : ColorPremise colorBoard := by decide +kernel

theorem color_start : ColorKey colorBoard L2_start :=
  ⟨by decide +kernel,
   ofTab_mem _ _ (by decide +kernel) (by decide +kernel)⟩

/-- **第 2 关拿掉一个色环：不经过重来就赢不了。** -/
theorem color_unsolvable : Unsolvable colorBoard L2_start :=
  unsolvable_by_color colorBoard L2_start color_premise color_start

/-- 防线一：对照盘（真实第 2 关）赢得了。 -/
theorem color_control_winnable : Winnable L2_board L2_start := L2_winnable
/-- 防线二：而且不是一开局就赢了。 -/
theorem color_control_closed : isGoal L2_board L2_start = false := L2_closed_at_start
/-- 防线三：钥匙一的前提在对照盘上**不成立**。 -/
theorem color_control_not_key : ¬ ColorPremise L2_board := by decide +kernel

/-! ## 钥匙二：四条分界线都分不开的一对格 -/

/-- (2,1) 与 (3,1)：都在中线上方、竖中线左边、主对角线下方、副对角线上方——八个工位的倾倒要么都盖、要么都不盖。 -/
theorem inHalf_pair : ∀ p, inHalf p 2 1 = inHalf p 3 1 := by
  intro p
  match p with
  | 0 => rfl | 1 => rfl | 2 => rfl | 3 => rfl
  | 4 => rfl | 5 => rfl | 6 => rfl | 7 => rfl
  | _ + 8 => rfl

/-- Φ₂：那一对格同色。 -/
def PairKey (s : St) : Prop := s.vessel 2 1 = s.vessel 3 1

/-- 钥匙二的前提：盘上没有小杯，而目标图要那一对格不同色。 -/
def PairPremise (b : Board) : Prop := b.hasSpout = false ∧ b.target 2 1 ≠ b.target 3 1

instance (b : Board) : Decidable (PairPremise b) := by unfold PairPremise; infer_instance

theorem pairKey_act (b : Board) (hb : b.hasSpout = false) (s : St) (a : Act) (ha : legal a = true)
    (h : PairKey s) : PairKey (act b s a) := by
  cases a with
  | reset => simp [legal] at ha
  | pour =>
    show (if inHalf s.pose 2 1 then s.paint else s.vessel 2 1) =
         (if inHalf s.pose 3 1 then s.paint else s.vessel 3 1)
    rw [inHalf_pair]
    split
    · rfl
    · exact h
  | click r c =>
    simp only [act]
    split
    · exact h
    · have hs : stampHit b s r c = false := by simp [stampHit, spoutOn, hb]
      simp only [hs, Bool.false_eq_true, ↓reduceIte]
      exact h
  | up => exact h
  | down => exact h
  | left => exact h
  | right => exact h

theorem pairKey_keep (b : Board) (hb : b.hasSpout = false) :
    ∀ s s' a, legal a = true → PairKey s → step b s a = .ok s' → PairKey s' := by
  intro s s' a ha h hs
  rw [step_ok b s s' a ha hs]
  exact pairKey_act b hb s a ha h

theorem pairKey_no_win (b : Board) (hp : PairPremise b) :
    ∀ s a, legal a = true → PairKey s → step b s a ≠ .won := by
  intro s a ha h hw
  have hg := step_won b s a ha hw
  have hk := pairKey_act b hp.1 s a ha h
  have e1 := same_at (act b s a).vessel b.target hg 2 1 (by decide) (by decide)
  have e2 := same_at (act b s a).vessel b.target hg 3 1 (by decide) (by decide)
  exact hp.2 (e1 ▸ e2 ▸ hk)

/-- **钥匙二**：前提成立、开局满足 Φ₂ ⇒ 不经过重来就赢不了。 -/
theorem unsolvable_by_pair (b : Board) (s : St) (hp : PairPremise b) (h : PairKey s) :
    Unsolvable b s :=
  unsolvable_of_invariant b PairKey (pairKey_keep b hp.1) (pairKey_no_win b hp) s h

/-- 钥匙二的盘：第 3 关的真实版面，**只拿掉小杯**。 -/
def pairBoard : Board := { L3_board with hasSpout := false }

theorem pair_premise : PairPremise pairBoard := by decide +kernel

theorem pair_start : PairKey L3_start := by unfold PairKey; decide +kernel

/-- **第 3 关没有小杯：不经过重来就赢不了。** -/
theorem pair_unsolvable : Unsolvable pairBoard L3_start :=
  unsolvable_by_pair pairBoard L3_start pair_premise pair_start

theorem pair_control_winnable : Winnable L3_board L3_start := L3_winnable
theorem pair_control_closed : isGoal L3_board L3_start = false := L3_closed_at_start
/-- 防线三：钥匙二的前提在对照盘上**不成立**（真实第 3 关有小杯）。 -/
theorem pair_control_not_key : ¬ PairPremise L3_board := by decide +kernel

/-! ## 两句话不能同时成立：钥匙盘上 `Winnable` 是假的 -/

theorem color_not_winnable : ¬ Winnable colorBoard L2_start :=
  fun h => not_both _ _ h color_unsolvable
theorem pair_not_winnable : ¬ Winnable pairBoard L3_start :=
  fun h => not_both _ _ h pair_unsolvable

#print axioms swatchHit_mem
#print axioms ofTab_mem
#print axioms colorKey_act
#print axioms colorKey_keep
#print axioms colorKey_no_win
#print axioms unsolvable_by_color
#print axioms color_premise
#print axioms color_start
#print axioms color_unsolvable
#print axioms color_control_winnable
#print axioms color_control_closed
#print axioms color_control_not_key
#print axioms inHalf_pair
#print axioms pairKey_act
#print axioms pairKey_keep
#print axioms pairKey_no_win
#print axioms unsolvable_by_pair
#print axioms pair_premise
#print axioms pair_start
#print axioms pair_unsolvable
#print axioms pair_control_winnable
#print axioms pair_control_closed
#print axioms pair_control_not_key
#print axioms color_not_winnable
#print axioms pair_not_winnable

end Keys
end Game
