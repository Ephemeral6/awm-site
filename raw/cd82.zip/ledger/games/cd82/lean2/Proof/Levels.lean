/-
# Proof/Levels —— 每一关一条定理（自动生成，不要手改；生成器 `lean2/export_levels.py`）

    L<n>_trace      沿着认证那一段的真实走法，模型每一帧都和观测对上（**只有开局是观测给的**）
    L<n>_winnable   这一关走得通 —— 见证就是那条路，再加赢的那一脚
    L<n>_play_len / L<n>_acts_len   钉住段长：空表会让「一步不差」平凡为真

见证只取成绩单认证的那一局（guid 929c52bc-188c-416a-bac1-647dc00487f2）。每关核过的步数：第0关 4 / 第1关 5 / 第2关 15 / 第3关 13 / 第4关 12 / 第5关 15。
版面用**整关取并集**的那一张（`Replay.levelBoard`）。
-/

import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels
open Replay

set_option maxRecDepth 100000

/-- 开局预算满格 ⇔ 钟在 0：满格那个长度的纤维只有一个元素。 -/
theorem clock_of_full : clockFiber FULL = [0] := by decide +kernel

#print axioms clock_of_full

/-! ## 第 0 关（关号 0，认证那一段 seq 592..596，共 5 步） -/

def L0_board : Board := levelBoard 0

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L0_start : St := stOf (prevAt 592) 0

theorem L0_start_full : (prevAt 592).bar = FULL := by decide +kernel

/-- 开局到过关前一步，4 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L0_play : List (Act × Seen) := playFrom 592 4

theorem L0_play_len : L0_play.length = 4 := by decide +kernel

#eval match firstSplit L0_board L0_start L0_play 0 with
  | none   => "LEVEL 0 split=none steps=" ++ toString L0_play.length
  | some i => "LEVEL 0 split=" ++ toString i ++ " steps=" ++ toString L0_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L0_trace : traceOk L0_board L0_start L0_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，5 个。 -/
def L0_acts : List Act := actsFrom 592 5

theorem L0_acts_len : L0_acts.length = 5 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L0_closed_at_start : isGoal L0_board L0_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L0_winnable : Winnable L0_board L0_start :=
  ⟨L0_acts, by decide +kernel, by decide +kernel⟩

#print axioms L0_start_full
#print axioms L0_play_len
#print axioms L0_trace
#print axioms L0_acts_len
#print axioms L0_closed_at_start
#print axioms L0_winnable

/-! ## 第 1 关（关号 1，认证那一段 seq 597..602，共 6 步） -/

def L1_board : Board := levelBoard 1

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L1_start : St := stOf (prevAt 597) 0

theorem L1_start_full : (prevAt 597).bar = FULL := by decide +kernel

/-- 开局到过关前一步，5 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L1_play : List (Act × Seen) := playFrom 597 5

theorem L1_play_len : L1_play.length = 5 := by decide +kernel

#eval match firstSplit L1_board L1_start L1_play 0 with
  | none   => "LEVEL 1 split=none steps=" ++ toString L1_play.length
  | some i => "LEVEL 1 split=" ++ toString i ++ " steps=" ++ toString L1_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L1_trace : traceOk L1_board L1_start L1_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，6 个。 -/
def L1_acts : List Act := actsFrom 597 6

theorem L1_acts_len : L1_acts.length = 6 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L1_closed_at_start : isGoal L1_board L1_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L1_winnable : Winnable L1_board L1_start :=
  ⟨L1_acts, by decide +kernel, by decide +kernel⟩

#print axioms L1_start_full
#print axioms L1_play_len
#print axioms L1_trace
#print axioms L1_acts_len
#print axioms L1_closed_at_start
#print axioms L1_winnable

/-! ## 第 2 关（关号 2，认证那一段 seq 603..618，共 16 步） -/

def L2_board : Board := levelBoard 2

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L2_start : St := stOf (prevAt 603) 0

theorem L2_start_full : (prevAt 603).bar = FULL := by decide +kernel

/-- 开局到过关前一步，15 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L2_play : List (Act × Seen) := playFrom 603 15

theorem L2_play_len : L2_play.length = 15 := by decide +kernel

#eval match firstSplit L2_board L2_start L2_play 0 with
  | none   => "LEVEL 2 split=none steps=" ++ toString L2_play.length
  | some i => "LEVEL 2 split=" ++ toString i ++ " steps=" ++ toString L2_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L2_trace : traceOk L2_board L2_start L2_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，16 个。 -/
def L2_acts : List Act := actsFrom 603 16

theorem L2_acts_len : L2_acts.length = 16 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L2_closed_at_start : isGoal L2_board L2_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L2_winnable : Winnable L2_board L2_start :=
  ⟨L2_acts, by decide +kernel, by decide +kernel⟩

#print axioms L2_start_full
#print axioms L2_play_len
#print axioms L2_trace
#print axioms L2_acts_len
#print axioms L2_closed_at_start
#print axioms L2_winnable

/-! ## 第 3 关（关号 3，认证那一段 seq 619..632，共 14 步） -/

def L3_board : Board := levelBoard 3

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L3_start : St := stOf (prevAt 619) 0

theorem L3_start_full : (prevAt 619).bar = FULL := by decide +kernel

/-- 开局到过关前一步，13 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L3_play : List (Act × Seen) := playFrom 619 13

theorem L3_play_len : L3_play.length = 13 := by decide +kernel

#eval match firstSplit L3_board L3_start L3_play 0 with
  | none   => "LEVEL 3 split=none steps=" ++ toString L3_play.length
  | some i => "LEVEL 3 split=" ++ toString i ++ " steps=" ++ toString L3_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L3_trace : traceOk L3_board L3_start L3_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，14 个。 -/
def L3_acts : List Act := actsFrom 619 14

theorem L3_acts_len : L3_acts.length = 14 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L3_closed_at_start : isGoal L3_board L3_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L3_winnable : Winnable L3_board L3_start :=
  ⟨L3_acts, by decide +kernel, by decide +kernel⟩

#print axioms L3_start_full
#print axioms L3_play_len
#print axioms L3_trace
#print axioms L3_acts_len
#print axioms L3_closed_at_start
#print axioms L3_winnable

/-! ## 第 4 关（关号 4，认证那一段 seq 633..645，共 13 步） -/

def L4_board : Board := levelBoard 4

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L4_start : St := stOf (prevAt 633) 0

theorem L4_start_full : (prevAt 633).bar = FULL := by decide +kernel

/-- 开局到过关前一步，12 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L4_play : List (Act × Seen) := playFrom 633 12

theorem L4_play_len : L4_play.length = 12 := by decide +kernel

#eval match firstSplit L4_board L4_start L4_play 0 with
  | none   => "LEVEL 4 split=none steps=" ++ toString L4_play.length
  | some i => "LEVEL 4 split=" ++ toString i ++ " steps=" ++ toString L4_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L4_trace : traceOk L4_board L4_start L4_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，13 个。 -/
def L4_acts : List Act := actsFrom 633 13

theorem L4_acts_len : L4_acts.length = 13 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L4_closed_at_start : isGoal L4_board L4_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L4_winnable : Winnable L4_board L4_start :=
  ⟨L4_acts, by decide +kernel, by decide +kernel⟩

#print axioms L4_start_full
#print axioms L4_play_len
#print axioms L4_trace
#print axioms L4_acts_len
#print axioms L4_closed_at_start
#print axioms L4_winnable

/-! ## 第 5 关（关号 5，认证那一段 seq 646..661，共 16 步） -/

def L5_board : Board := levelBoard 5

/-- 开局：认证那一段这一关第一帧读出来的，钟 = 0。 -/
def L5_start : St := stOf (prevAt 646) 0

theorem L5_start_full : (prevAt 646).bar = FULL := by decide +kernel

/-- 开局到过关前一步，15 步（过关那一脚不在这里：它的下一帧是下一关的盘）。 -/
def L5_play : List (Act × Seen) := playFrom 646 15

theorem L5_play_len : L5_play.length = 15 := by decide +kernel

#eval match firstSplit L5_board L5_start L5_play 0 with
  | none   => "LEVEL 5 split=none steps=" ++ toString L5_play.length
  | some i => "LEVEL 5 split=" ++ toString i ++ " steps=" ++ toString L5_play.length

/-- **模型沿着这条路一步不差。** -/
theorem L5_trace : traceOk L5_board L5_start L5_play = true := by decide +kernel

/-- 那条路的全部动作，**加上赢的那一脚**，16 个。 -/
def L5_acts : List Act := actsFrom 646 16

theorem L5_acts_len : L5_acts.length = 16 := by decide +kernel

/-- 开局不是已经赢了的局面。 -/
theorem L5_closed_at_start : isGoal L5_board L5_start = false := by decide +kernel

/-- **这一关走得通。** 见证是认证那一段的真实走法（不含重来）。 -/
theorem L5_winnable : Winnable L5_board L5_start :=
  ⟨L5_acts, by decide +kernel, by decide +kernel⟩

#print axioms L5_start_full
#print axioms L5_play_len
#print axioms L5_trace
#print axioms L5_acts_len
#print axioms L5_closed_at_start
#print axioms L5_winnable

end Levels
end Game
