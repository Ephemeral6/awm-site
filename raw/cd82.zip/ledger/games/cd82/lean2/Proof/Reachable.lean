/-
# Proof/Reachable —— 这个**局面**做不做得了：定义与骨架

    Winnable   b s  :=  ∃ as，每一下合法，照着走中途赢过
    Unsolvable b s  :=  ∀ as，每一下合法 → 照着走从没赢过

## 合法的一步：**不含重来**

`everWon` 碰到重来那一支会把局面换回开局——那是另一件事。所以谈可不可做时把重来排除在外：
**`Unsolvable` 的准确意思是「不经过重来就赢不了」**。这半句写在这里、写在 `Proof/Keys`、写在页面上，三处。
（这一局的方向键、倾倒、点击在任何工位上都是良定义的，不需要再限死位移。）

## 骨架：不变量 ⇒ 不可做

找一个 Φ：每走一步都还成立，而且和「赢」直接矛盾。那么从满足 Φ 的局面出发，**任何动作串都赢不了**。
全文**唯一**做归纳的地方；不枚举状态、与盘面大小无关。钥匙在 `Proof/Keys`。
-/

import Step

namespace Game

/-- 合法的一步：除了重来都行。 -/
def legal (a : Act) : Bool := a != .reset

/-- 从 s 起照着 as 走，中途赢过没有。终局那一支是 `false`。 -/
def everWon (b : Board) : St → List Act → Bool
  | _, []      => false
  | s, a :: as =>
      match step b s a with
      | .won    => true
      | .over   => false
      | .ok s'  => everWon b s' as

def Winnable (b : Board) (s : St) : Prop :=
  ∃ as : List Act, (as.all legal = true) ∧ everWon b s as = true

def Unsolvable (b : Board) (s : St) : Prop :=
  ∀ as : List Act, as.all legal = true → everWon b s as = false

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (s : St) : Winnable b s → Unsolvable b s → False := by
  intro ⟨as, hl, hw⟩ hu
  rw [hu as hl] at hw
  exact Bool.false_ne_true hw

/-- 不是重来的一步走成了 `ok`：结果就是「这一步之后的状态，钟 +1」。 -/
theorem step_ok (b : Board) (s s' : St) (a : Act) (ha : legal a = true)
    (h : step b s a = .ok s') : s' = { act b s a with clock := s.clock + 1 } := by
  cases a with
  | reset => simp [legal] at ha
  | _ =>
    simp only [step] at h
    split at h
    · exact absurd h (by simp)
    · split at h
      · exact absurd h (by simp)
      · injection h with h; exact h.symm

/-- 不是重来的一步赢了：这一步之后的状态满足 `isGoal`。 -/
theorem step_won (b : Board) (s : St) (a : Act) (ha : legal a = true)
    (h : step b s a = .won) : isGoal b (act b s a) = true := by
  cases a with
  | reset => simp [legal] at ha
  | _ =>
    simp only [step] at h
    split at h
    · assumption
    · split at h <;> exact absurd h (by simp)

/-- **骨架**：Φ 每步保持、Φ 下这一步赢不了 ⇒ 不经过重来就赢不了。 -/
theorem unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, legal a = true → P s → step b s a = .ok s' → P s')
    (hwin : ∀ s a, legal a = true → P s → step b s a ≠ .won) :
    ∀ s, P s → Unsolvable b s := by
  intro s hp as hl
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    simp only [List.all_cons, Bool.and_eq_true] at hl
    simp only [everWon]
    cases hs : step b s a with
    | won => exact absurd hs (hwin s a hl.1 hp)
    | over => rfl
    | ok s' => exact ih s' (hkeep s s' a hl.1 hp hs) hl.2

/-- `Vessel.same` 为真 ⇒ 范围内逐格相等。 -/
theorem same_at (v t : Vessel) (h : Vessel.same v t = true) (r c : Nat) (hr : r < 10) (hc : c < 10) :
    v r c = t r c := by
  simp only [Vessel.same, SIZE, List.all_eq_true, List.mem_range, beq_iff_eq] at h
  exact h r hr c hc

#print axioms not_both
#print axioms step_ok
#print axioms step_won
#print axioms unsolvable_of_invariant
#print axioms same_at

end Game
