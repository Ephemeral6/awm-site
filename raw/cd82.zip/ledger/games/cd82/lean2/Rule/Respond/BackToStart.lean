/-
# Rule/Respond/BackToStart —— 重来放回开局（对应 `rule/respond/back_to_start.py`，身份：**定义**）

重来之后是一个**固定**的局面：工位 6、颜料色 15、容器全 0、钟归零。
（Python 那条规则还管「换关之后也是这个局面」；Lean 里换关那一步的结果是 `won`，**不带下一个状态**——
下一关的版面模型说不出来。所以换关那一半在这里只作为同一个开局的定义被复用，`step` 不用它。）

**两处分不开的地方**：「颜料色 15」与「第二个色环的芯色」、「容器清成 0」与「清成这一关开局的颜色」，
在全语料的每张盘上给出同一个值。这里取前者。
-/

import Obj.World

namespace Game

def START_PAINT : Color := 15

def start : St :=
  { vessel := fun _ _ => 0, pose := START_POSE, paint := START_PAINT, clock := 0 }

end Game
