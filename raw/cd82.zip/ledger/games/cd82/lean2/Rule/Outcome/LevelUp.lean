/-
# Rule/Outcome/LevelUp —— 过关（对应 `rule/outcome/level_up.py`，身份：**定义**）

`isGoal` 是一个**状态**性质：容器逐格等于目标图。
「这一步之后 isGoal ⇒ 过关」写在 `Step.lean` 的分发里（算完这一步先问 isGoal）。
-/

import Obj.World

namespace Game

def isGoal (b : Board) (s : St) : Bool := Vessel.same s.vessel b.target

end Game
