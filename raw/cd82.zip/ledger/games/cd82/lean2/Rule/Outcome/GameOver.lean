/-
# Rule/Outcome/GameOver —— 终局（对应 `rule/outcome/game_over.py`，身份：**定义**）

走到第 k 步时预算条长度为 0，这一步就是终局。
-/

import Rule.Move.Budget

namespace Game

def overAt (k : Nat) : Bool := barOf k == 0

end Game
