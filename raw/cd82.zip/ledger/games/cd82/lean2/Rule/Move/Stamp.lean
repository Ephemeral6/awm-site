/-
# Rule/Move/Stamp —— 盖章（对应 `rule/move/stamp.py`，身份：**定义**）

点中在场小杯的描边：容器靠小杯那条边上、和腔同宽的 3 行（或 3 列）涂成颜料色。
工位 6（小杯在上）是第 0..2 行 × 第 3..6 列；另三个正向工位是它绕容器中心转 90 度：

    p = 6 小杯在北   r ≤ 2 ∧ 3 ≤ c ≤ 6        p = 2 小杯在南   r ≥ 7 ∧ 3 ≤ c ≤ 6
    p = 0 小杯在西   c ≤ 2 ∧ 3 ≤ r ≤ 6        p = 4 小杯在东   c ≥ 7 ∧ 3 ≤ r ≤ 6
-/

import Obj.World
import Rule.Move.SpoutFollows

namespace Game

def inBand : Nat → Nat → Nat → Bool
  | 6, r, c => decide (r ≤ 2 ∧ 3 ≤ c ∧ c ≤ 6)
  | 0, r, c => decide (c ≤ 2 ∧ 3 ≤ r ∧ r ≤ 6)
  | 2, r, c => decide (7 ≤ r ∧ 3 ≤ c ∧ c ≤ 6)
  | 4, r, c => decide (7 ≤ c ∧ 3 ≤ r ∧ r ≤ 6)
  | _, _, _ => false

/-- 这一下点中的是不是在场小杯的描边。 -/
def stampHit (b : Board) (s : St) (r c : Nat) : Bool :=
  spoutOn b s.pose && rimHit s.pose r c

def stamp (s : St) : Vessel :=
  fun r c => if inBand s.pose r c then s.paint else s.vessel r c

end Game
