/-
# Rule/Move/SpoutFollows —— 小杯跟着工位（对应 `rule/move/spout_follows.py`，身份：**定义**）

小杯在场 ⇔ 这一关有小杯 且 大杯在正向工位上。
它不是状态的一位：在场与否由版面和工位**算**出来，于是「斜向工位上冒出一只小杯」写不出来。
-/

import Obj.World

namespace Game

def spoutOn (b : Board) (p : Pose) : Bool := b.hasSpout && cardinal p

end Game
