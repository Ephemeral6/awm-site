/-
# Rule/Move/Budget —— 预算曲线（对应 `rule/move/budget.py`，身份：**定义**）

自最近一次归零走了 k 步，预算条长 64 − round(64k/100)。
round 写成整数：round(x) = ⌊x + ½⌋，而 64k/100 永远不落在 .5 上，所以不用挑舍入规则。
k = 100 时长度为 0（那一步就是终局，见 `Rule/Outcome/GameOver`）。
-/

import Obj.World

namespace Game

def HORIZON : Nat := 100

def barOf (k : Nat) : Nat := FULL - (2 * FULL * k + HORIZON) / (2 * HORIZON)

end Game
