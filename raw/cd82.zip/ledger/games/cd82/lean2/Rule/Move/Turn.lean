/-
# Rule/Move/Turn —— 方向键转杯（对应 `rule/move/turn.py`，身份：**定义**）

四个键是屏幕的四个方向：上 = 北(2)、下 = 南(6)、左 = 西(4)、右 = 东(0)。
开口 p 与键 k 的有符号角差（单位 45 度）是 `((p − k + 4) mod 8) − 4`；
这里把它平移 4 写成自然数 `s = (p + 12 − k) mod 8`，于是

    角差 +1 / +2  ⇔ s = 5 / 6   →  开口转离键 45 度：p + 1
    角差 −1 / −2  ⇔ s = 3 / 2   →  p − 1（写成 p + 7 再取模）
    其余（0 / ±3 / 4）          →  按不动

这一份和 Python 那份（`derive/turn.py` 用有符号整数）是**各自独立写的**，
两边对不对得上由语料逐条核（`Obs/Corpus`）。
-/

import Obj.World

namespace Game

def turn (p k : Nat) : Nat :=
  if (p + 12 - k) % 8 == 5 || (p + 12 - k) % 8 == 6 then (p + 1) % 8
  else if (p + 12 - k) % 8 == 2 || (p + 12 - k) % 8 == 3 then (p + 7) % 8
  else p

/-- 按下动作 a 之后的工位。不是方向键，工位原样。 -/
def turnBy (p : Pose) : Act → Pose
  | .up    => turn p 2
  | .down  => turn p 6
  | .left  => turn p 4
  | .right => turn p 0
  | _      => p

end Game
