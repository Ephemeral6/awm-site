/-
# Rule/Move/PickPaint —— 点色环换颜料（对应 `rule/move/pick_paint.py`，身份：**定义**）

点中一个色环，颜料色变成它的芯色；没点中色环，颜料色不变。
-/

import Obj.World

namespace Game

def pickPaint (b : Board) (p : Color) (r c : Nat) : Color :=
  match swatchHit b.palette r c with
  | some sw => sw.color
  | none    => p

end Game
