/-
# Rule/Move/Pour —— 倾倒（对应 `rule/move/pour.py`，身份：**定义**）

ACTION5：容器里靠杯那一侧的半平面（分界线过中心 (4.5, 4.5)，线上的格算靠杯那侧）整片涂成颜料色。
杯在容器的「开口反方向」上，所以按开口 p 逐个写出那一半（全是自然数不等式，不用整数）：

    p = 0 东   杯在西   c ≤ 4          p = 4 西   杯在东   c ≥ 5
    p = 1 东北 杯在西南 c ≤ r          p = 5 西南 杯在东北 r ≤ c
    p = 2 北   杯在南   r ≥ 5          p = 6 南   杯在北   r ≤ 4
    p = 3 西北 杯在东南 r + c ≥ 9      p = 7 东南 杯在西北 r + c ≤ 9

Python 那份（`derive/pour.py`）用的是「单位向量点乘 ≥ 0」一个式子；这一份按工位逐个写，
**两份各自独立**，由语料逐条对账。
-/

import Obj.World

namespace Game

def inHalf : Nat → Nat → Nat → Bool
  | 0, _, c => decide (c ≤ 4)
  | 1, r, c => decide (c ≤ r)
  | 2, r, _ => decide (5 ≤ r)
  | 3, r, c => decide (9 ≤ r + c)
  | 4, _, c => decide (5 ≤ c)
  | 5, r, c => decide (r ≤ c)
  | 6, r, _ => decide (r ≤ 4)
  | 7, r, c => decide (r + c ≤ 9)
  | _, _, _ => false

def pour (s : St) : Vessel :=
  fun r c => if inHalf s.pose r c then s.paint else s.vessel r c

end Game
