/-
# Obs/Corpus —— 模型面对全部真实转移（自动生成，不要手改；生成器 `lean2/export_corpus.py`）

每一条都从**观测到的那一帧**重新起算一步，和现实比（`Obs/Check.verdict`，按纤维判）。

    agree     纤维里有一个世界算对了
    disagree  一个都没对上 —— **模型被这一帧证伪**
    na        模型不描述这一步（新开一局：下一帧是另一局第一关的盘）

读数那一行走的是 `#eval`（求值器，不进可信基）。下面每一类挑一条走内核（`decide +kernel`）。
-/

import Obs.Replay

namespace Game
namespace Corpus
open Replay

def stepAt (seq : Nat) : Replay.Step :=
  (steps.find? (fun s => s.seq == seq)).getD
    { seq := 0, lvl := 0, board := 0, act := .reset, prev := dummySeen, expect := .skip }

def verdictOf (s : Replay.Step) : Verdict := verdict (boardAt s.board) s.prev s.act s.expect

def count (v : Verdict) : Nat := (steps.filter (fun s => verdictOf s == v)).length

#eval "CORPUS agree=" ++ toString (count .agree) ++ " disagree=" ++ toString (count .disagree) ++
  " na=" ++ toString (count .na) ++ " total=" ++ toString steps.length

#eval "CORPUS_DISAGREE " ++ toString ((steps.filter (fun s => verdictOf s == .disagree)).map (·.seq))

/-- 逐条的判决码（a 对上 / d 判错 / n 不描述），按 `steps` 的顺序。`verify.py` 拿它和 Python 规则层**逐条对账**。 -/
def code (v : Verdict) : Char := match v with | .agree => 'a' | .disagree => 'd' | .na => 'n'

#eval "CORPUS_CODES " ++ String.ofList (steps.map (fun s => code (verdictOf s)))

set_option maxRecDepth 100000

/-- 一类：方向键按不动（seq 1，ACTION1）。 -/
theorem case_deadkey_1 : verdictOf (stepAt 1) = .agree := by decide +kernel

#print axioms case_deadkey_1

/-- 一类：方向键转杯（seq 3，ACTION3）。 -/
theorem case_turn_3 : verdictOf (stepAt 3) = .agree := by decide +kernel

#print axioms case_turn_3

/-- 一类：倾倒（seq 7，ACTION5）。 -/
theorem case_pour_7 : verdictOf (stepAt 7) = .agree := by decide +kernel

#print axioms case_pour_7

/-- 一类：点色环换颜料（seq 11，ACTION6:37,4）。 -/
theorem case_swatch_11 : verdictOf (stepAt 11) = .agree := by decide +kernel

#print axioms case_swatch_11

/-- 一类：什么都没点中（seq 12，ACTION6:36,43）。 -/
theorem case_deadclick_12 : verdictOf (stepAt 12) = .agree := by decide +kernel

#print axioms case_deadclick_12

/-- 一类：重来放回开局（seq 50，RESET）。 -/
theorem case_reset_50 : verdictOf (stepAt 50) = .agree := by decide +kernel

#print axioms case_reset_50

/-- 一类：预算归零、终局（seq 150，ACTION1）。 -/
theorem case_over_150 : verdictOf (stepAt 150) = .agree := by decide +kernel

#print axioms case_over_150

/-- 一类：过关（换盘）（seq 256，ACTION5）。 -/
theorem case_levelup_256 : verdictOf (stepAt 256) = .agree := by decide +kernel

#print axioms case_levelup_256

/-- 一类：新开一局（模型不描述）（seq 273，RESET）。 -/
theorem case_skip_273 : verdictOf (stepAt 273) = .na := by decide +kernel

#print axioms case_skip_273

/-- 一类：点小杯描边盖章（seq 368，ACTION6:29,20）。 -/
theorem case_stamp_368 : verdictOf (stepAt 368) = .agree := by decide +kernel

#print axioms case_stamp_368

/-- 一类：最后一关通关（seq 424，ACTION6:12,36）。 -/
theorem case_win_424 : verdictOf (stepAt 424) = .agree := by decide +kernel

#print axioms case_win_424

end Corpus
end Game
