/-
# Obs/Check —— **判据层**：两把尺子。**这一份里没有一条定理**（尺子不自证）。

    verdict     **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比
    traceOk     **一整条路**对不对：只有开局那一帧是观测给的，后面全是模型自己算的

## 纤维：一帧对应的不止一个世界

观测比世界少两位信息：

    clock      帧上只有预算条长度；一个长度可能对应两个相邻的 clock
    hasSpout   斜向工位上小杯不在场，「这一关有没有小杯」读不出来

所以逐条判按纤维判：纤维里**有一个**世界算对了 ⇒ 对上；一个都没对上 ⇒ 判错。
（每关那一层不用纤维：开局预算满格 ⇔ clock = 0，`hasSpout` 按整关取并集给。）

## 三值

    agree / disagree / na —— **na 不是 agree**。na 只给一种：这一步模型根本不描述
    （新开一局：下一帧是另一局第一关的盘）。
-/

import Step

namespace Game

/-- 模型的一个状态在帧上看得见的那一部分。 -/
def seen (b : Board) (s : St) : Seen :=
  { vessel := s.vessel.tab, pose := s.pose, paint := s.paint,
    spout := spoutOn b s.pose, bar := barOf s.clock }

/-- 这个预算长度可能对应的 clock。 -/
def clockFiber (bar : Nat) : List Nat :=
  (List.range (HORIZON + 1)).filter (fun k => barOf k == bar)

/-- 这一帧可能对应的 hasSpout。 -/
def spoutFiber (o : Seen) : List Bool :=
  if cardinal o.pose then [o.spout] else [false, true]

/-- 观测 + 一个 clock → 状态。 -/
def stOf (o : Seen) (k : Nat) : St :=
  { vessel := Vessel.ofTab o.vessel, pose := o.pose, paint := o.paint, clock := k }

/-- 现实那一侧这一步发生了什么（从上游 meta 读，**模型看不到它**，只拿来核对）。 -/
inductive Expect where
  | next (o : Seen)    -- 同一关之内：下一帧
  | won                -- 过关（含通关）
  | over               -- 预算归零，终局
  | skip               -- 模型不描述：新开一局
  deriving DecidableEq, Repr

inductive Verdict where
  | agree | disagree | na
  deriving DecidableEq, Repr

def matchesRes (b : Board) : Res → Expect → Bool
  | .ok s, .next o => seen b s == o
  | .won,  .won    => true
  | .over, .over   => true
  | _,     _       => false

/-- 板子的 hasSpout 换一个值。 -/
def Board.withSpout (b : Board) (hs : Bool) : Board := { b with hasSpout := hs }

/-- **逐条**：从观测到的 `prev` 起算一步。 -/
def verdict (b : Board) (prev : Seen) (a : Act) (e : Expect) : Verdict :=
  match e with
  | .skip => .na
  | _ =>
    if (spoutFiber prev).any (fun hs => (clockFiber prev.bar).any (fun k =>
          matchesRes (b.withSpout hs) (step (b.withSpout hs) (stOf prev k) a) e))
    then .agree else .disagree

/-- **每关**：从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。
    下一轮喂进去的是模型自己算出来的 `s'`，不是观测。 -/
def traceOk (b : Board) : St → List (Act × Seen) → Bool
  | _, []             => true
  | s, (a, o) :: rest =>
      match step b s a with
      | .ok s' => seen b s' == o && traceOk b s' rest
      | _      => false

/-- **只给读数用**：第一处分家在第几步。它是读数不是定理（`#eval` 走求值器）。 -/
def firstSplit (b : Board) : St → List (Act × Seen) → Nat → Option Nat
  | _, [],             _ => none
  | s, (a, o) :: rest, i =>
      match step b s a with
      | .ok s' => if seen b s' == o then firstSplit b s' rest (i + 1) else some i
      | _      => some i

end Game
