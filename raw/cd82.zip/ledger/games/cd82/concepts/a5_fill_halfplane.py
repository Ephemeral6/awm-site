"""ACTION5 把容器 bbox 里的一个半平面整片涂成**当前颜料色**，半平面之外的容器格原样不动。
半平面的分界线跟着杯的朝向 tilt 转 45°：tilt=0 分界线水平（上半 5 行），
tilt=-1 是容器的主对角线（右上三角，含线上那 10 格），tilt=+1 镜像（左上三角）。

三个版本的死法记在这里：
v1 断言「容器里的色15 恰好等于半平面」（覆盖式），被 tilt=0 那次推翻——容器下半原有的对角色15 一格没退。
v2 改成「新色15 = 旧色15 ∪ 半平面」，只涨不退。它在两次实测上都对，但它把颜色写死成 15，
而 ACTION6 之后杯里的液色变成了色0——「涂色15」这个说法本身就没了根。
v3 回到覆盖式，但覆盖的是**半平面**而不是整个容器，涂的是 paint_color(prev) 而不是常数 15。
在 paint=15 的两次实测上 v3 与 v2 逐格等价，所以它没有被这两次证伪；它和 v2 的分歧要等 paint=0 的那次 ACTION5 才结算。
"""
LEVEL = "L1"
SCOPE = "只看 ACTION5；其余动作返回 NA。vessel()、tilt() 或 paint_color() 认不出（返回 None）时返回 NA；tilt 不在 {-1,0,1} 时返回 NA。换关返回 NA。"
NOTE = "v3：把「涂色15」换成「涂当前颜料色」，并把覆盖范围从整个容器缩到半平面。理由不是反例，是 ACTION6 让颜料色变成了变量（见 a6_swatch_sets_paint），v2 的常数 15 已经无根。tilt=+1 这一支仍未撞过。"
EVIDENCE = ["a215d90877336853", "5d164e85e3b35523"]

from _lib import vessel, tilt, paint_color


def _halfplane(v, t_):
    """容器 bbox v 与朝向 t_ 下，会被这一次 ACTION5 涂到的那些格。"""
    top, bot, lef, rig = v
    out = set()
    mid = (top + bot) // 2
    for rr in range(top, bot + 1):
        for cc in range(lef, rig + 1):
            if t_ == 0:
                ok = rr <= mid
            elif t_ == -1:
                ok = (cc - lef) >= (rr - top)
            else:
                ok = (rig - cc) >= (rr - top)
            if ok:
                out.add((rr, cc))
    return out


def _predict(prev):
    if not prev:
        return None
    v = vessel(prev)
    t_ = tilt(prev)
    pc = paint_color(prev)
    if v is None or pc is None or t_ not in (-1, 0, 1):
        return None
    top, bot, lef, rig = v
    hp = _halfplane(v, t_)
    return {(rr, cc): (pc if (rr, cc) in hp else prev[rr][cc])
            for rr in range(top, bot + 1)
            for cc in range(lef, rig + 1)}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    pred = _predict(prev)
    if pred is None:
        return "NA"
    for (rr, cc), col in pred.items():
        if nxt[rr][cc] != col:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION5"):
        return None
    return _predict(prev)
