"""**在第 2 关**，只要大杯的开口指向四个正向之一（东 / 北 / 西 / 南），第二只小杯就一定在场。
不是「南才有」，也不是「哪一关都有」——是这一关的这四个工位上都有。

这是 secondcup_only_cardinal 的**反方向**，故意拆成两条，因为它们会以不同的方式坏：
那一条说「在场 ⟹ 正向」，斜向工位上冒出一只杯就判它错；
本条说「（这一关的）正向 ⟹ 在场」，去了北或西发现空空如也就判本条错，而那一条毫发无伤。

为什么必须把「关卡」写进主张里：前两关有 121 个去重帧开口朝南，第二只杯一格都没有
（runs/<run>/secondcup.py：第 0 关 116 帧、第 1 关 5 帧）。不带关卡的双条件会被这 121 帧当场推翻，
而那 121 帧我是看过的——拿它们去撞一条我明知会输的话，等于用旧语料伪造一次检验。

判错的方式：第 2 关任何一帧，开口是正向而 `_lib.spout` 为空。
"""
LEVEL = "L6"
SCOPE = ("所有动作。逐帧判：prev 只在 level_prev == 2 时查，nxt 只在 level_next == 2 时查；"
         "两帧都不是第 2 关就返回 NA。开口 open_dir 认不出、或开口是斜向的帧跳过"
         "（本条对斜向一个字不说，那归 secondcup_only_cardinal）。两帧都被跳过时返回 NA。"
         "ctx 缺失时返回 NA——不知道是第几关就没法判。"
         "**不写 apply**：它在场时长什么样、落在哪几格，本条说不出来，"
         "只说「有」。硬猜一个 bbox 就是一次观测拟合四个常数，正是词汇那次瞎掉的教训。")
NOTE = ("v1。与 secondcup_only_cardinal 同批写下，两条一起替掉撤册的 spout_south_only。\n"
        "**声明我看过什么，以及这条概念现在其实还没被考过**：第 2 关的正向帧我全看过"
        "（runs/<run>/secondcup.py 分组表：南 17/17 帧、东 3/3 帧，共 20 帧，全部在场），"
        "所以第一次结算它必然满分，而那个满分**一格证据都不值**。"
        "它真正的考卷是**北与西**：第 2 关这两个工位一次都没去过（runs/<run>/stations.out）。"
        "路线是现成的（runs/<run>/route2.out：从南出发 ACTION3 ACTION2 到东、ACTION4 ACTION2 到西），"
        "走过去看一眼就知道。走之前它是一条空头支票，这行字必须留着。\n"
        "**它为什么值得写下来而不是等考完再写**：如果四个正向都有，那么这只杯是「工位家具」，"
        "第九个算子多半是在正向工位上按某个键把它倒进容器；如果只有南和东有，那它更像"
        "「跟着大杯转到某些角度才画得出来」的渲染产物，第九个算子就得另找。"
        "两种世界给出的下一步不同，所以现在就得把话说死。")
EVIDENCE = ["56f8d3912a81bbdd",      # 第263步：换关进第 2 关，落在南，它出现
            "13fe0dfbaa54fe3f",      # 第268步：转回南，它在
            "8c092e00e3e3029e",      # 第339步：转到东，它在——「正向」这个词就是从这一条来的
            "39df052929b18f92"]      # 第340步：在东倾倒，它仍在

from _lib import open_dir, spout

LEVEL_HERE = 2


def _cardinal(d):
    return d is not None and d % 2 == 0


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    checked = False
    for g, lv in ((prev, ctx.get("level_prev")), (nxt, ctx.get("level_next"))):
        if lv != LEVEL_HERE:
            continue
        d = open_dir(g)
        if not _cardinal(d):
            continue
        checked = True
        if not spout(g):
            return "FALSE"
    return "TRUE" if checked else "NA"
