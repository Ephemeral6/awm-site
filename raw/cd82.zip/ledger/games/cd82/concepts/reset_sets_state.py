"""RESET 是一个「把状态设成固定值」的操作：档位设成 0、颜料设成色15、底行补满 64 格、容器整块设成色0。

这是 reset_clears_canvas 的换轴重立。那一条说 RESET **保留**档位、液色、下划线位置；
实测正好相反——它把这些量**设成**固定值。之所以会读反，是因为语料里第一次 RESET 发生时
档位已经是 0、颜料已经是色15，那一步是幂等的，「保留」和「设成」在那一步上完全分不开。
第二次 RESET（档位在 −1、颜料是色0）才把两者掰开：档位被拨回 0（杯重画 212 格）、
颜料被改成色15（下划线从一个环底下搬到另一个环底下 10 格）。

所以「重开」的粒度不是「画布 + 预算」，而是**这一关的整个可控状态**：
容器（唯一被评判的东西）、预算（唯一的代价）、档位与颜料（两个操作模式）。
唯一不被它重置的是面板上那张目标图（target_panel_static 管）与关卡本身。

判错点（四条独立的，任一条不成立即 FALSE）：
 - RESET 之后档位不是 0；
 - RESET 之后颜料不是色15；
 - RESET 之后底行不是满的 64 格；
 - RESET 之后容器那 10x10 里有任何一格（杯没盖住的）不是色0。

一个仍然没分开的问题（不许当成已知）：容器回到的是**开局那个颜色**，还是**色0 这个特定颜色**？
这一关的开局色恰好就是色0，两者在这一局里重合。同理，「颜料设成色15」也可能实为
「颜料设成右边那个环的芯色」——这一局里这两种说法给出同一个预测。要分开得等某一关的开局
容器不是色0、或者色板换了排列。
"""
LEVEL = "L1"
SCOPE = ("只看 action == 'RESET'，其余动作返回 NA。换关返回 NA。"
         "vessel(nxt) 认不出、nxt 的杯（描边/液体）认不出、或 start_cup() 画不出来时返回 NA "
         "—— 认不出就不表态。"
         "tilt(nxt) 返回 None 记为 FALSE 而不是 NA：None 的意思是「不是那三个档里的任何一个」"
         "（第四朝向就落在这里），既然本概念断言它是 0，None 就是判错，不是看不见。"
         "底行 63 由本概念断言「满 64 格」，与 bar_rule 在 k=0 处给出同一个数，不冲突。"
         "**apply 声明四块地**（v2 起）：底行整行、容器 bbox 里不被新杯占的格、新杯的描边与液体、"
         "旧杯腾出来的格。")
NOTE = ("v3：三处 `ink()` 换成 `cup_ink()`。**这是一个还没发作的错**，借来的一双眼睛"
        "（`runs/<run>/audit_startpose.md`）在它发作之前指出来的：`ink()` 取整幅画的描边，"
        "第 2 关舞台上那只第二只小杯的描边会被算成「旧杯」的一部分；本条唯一生效过的三次 RESET"
        "（第 49、149、207 步）全都早于小杯出现（第 263 步起），所以现有语料一格都测不出来。"
        "分歧的规模也量过了：14/558 个观测点上 `ink != cup_ink`，全部集中在第 263 步之后。\n"
        "  这一改不改任何主张，只把词汇口径对齐到「大杯」——但它把本条的**下一次考卷**变成真考卷："
        "在第 2 关（或任何有第二只杯的关）主动发一次 RESET，v2 会因为旧杯格集里混进小杯描边而"
        "多声明一批「腾空」的格，当场判错；v3 不会。已排进接下来的押注。\n"
        "v2：apply 从「只管底行 64 格」扩到「底行 + 容器 + 杯 + 旧杯腾空」，"
        "并把杯的落点收紧成「开局那一个绝对姿势，逐格」。\n"
        "  **主张没有新增，是把已有的主张变成生成。** v1 的 assert_ 早就断言了「容器那 10x10 里"
        "每一格都是色0」「颜料是色15」，但 apply 一格都没声明——于是规则图上 RESET 那几步"
        "大片留白（第 207 步残差 232/269 格，残差榜第三名）。判得出来却生成不出来，"
        "差的是「给定姿势返回格集」这个词，v1 的 NOTE 原话是「位置是什么的函数我还不知道」。\n"
        "  那个词现在有了。实测（`runs/<run>/startpose.py`）：**三次同关 RESET 之后的杯与开局帧的杯"
        "逐格相同**（各 114 格，对称差 0 格 ×3），换关后的两帧也是同一组；`_fit` 反解出的参数"
        "五处全同，`_lib.START_POSE` / `start_cup()` 由此入词汇表。所以 v1 那句"
        "「杯在同一档位下的绝对位置会变」是**错的**——会变的是别的档位，而 RESET 之后的档位只有一个。\n"
        "  **这一版新挨的打**：杯的落点从「tilt(nxt)==0」收紧成「就是这 114 格」。"
        "EVIDENCE 仍只有第 207 步，所以第 49、149 两步是它的 held-out 考卷，当场就考。\n"
        "  液体的颜色本条敢声明色15，是因为本条自己就断言「RESET 后颜料是色15」——"
        "这不是多押一句，是同一句话的两处后果。（换关那边不同：levelup_resets_stage 不敢声明液色，"
        "因为「颜料跨关归零」在那里只有一个非幂等样本，单独立成 levelup_sets_paint 去等考卷。）\n"
        "v1。前身 reset_clears_canvas 已撤册（轴反了），死因写在 journal 里。"
        "**声明我看过什么**：语料里只有两次 RESET，我写这条之前两次都看过了 —— "
        "第 49 步那次是幂等的（档位与颜料本来就是目标值），第 207 步那次是掰开两种说法的那一次。"
        "EVIDENCE 只放第 207 步这条，所以第 49 步会成为它的考卷；但那张考卷我已经看过答案，"
        "而且它是幂等的，必然通过 —— **所以第一次结算给出的 N=1 / S=1.000 不是独立检验，不许引用。**"
        "这条概念的分从下一次真正的 RESET（档位不在 0 或颜料不是色15 时发的那一次）起算，"
        "已经把它排进下一批押注（方法草稿「EVIDENCE 会吃掉自己的考卷」）。\n"
        "不断言的事：这一步装置的步数计数不增加，meta 里多出一个 reset 段。那是装置记的账，"
        "不是世界给的画面。另外本概念不预测杯重画到哪些格 —— 杯在同一档位下的**绝对位置会变**"
        "（档 +1 的杯出现在列 14..30 也出现在别处），位置是什么的函数我还不知道，所以 apply 只管底行。")
EVIDENCE = ["ca2058f1668862f2"]

from _lib import (BAR_COLOR, BAR_ROW, INK, STAGE_BG, bar, cup_ink, liquid,
                  paint_color, start_cup, tilt, vessel)

CLEAR = 0          # 重开后容器整块的颜色
PAINT_AFTER = 15   # 重开后选中的颜料
BAR_FULL = 64      # 重开后底行的格数


def _is_reset(action):
    return action.strip().upper() == "RESET"


def apply(prev, action, ctx=None):
    """底行整行、容器（新杯没占的格）、新杯的描边与液体、旧杯腾出来的格。"""
    if not _is_reset(action):
        return None
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    v = vessel(prev)
    s = start_cup()
    if v is None or s is None:
        return None
    new_ink, new_liq = s
    new_all = set(new_ink) | set(new_liq)
    old = set(cup_ink(prev) or ()) | set(liquid(prev) or ())
    if not old:
        return None

    out = {}
    for p in old - new_all:                     # 旧杯腾空，还给舞台背景
        out[p] = STAGE_BG
    t, b, l, r = v                              # 容器整块清成色0（新杯占着的格不声明）
    for rr in range(t, b + 1):
        for cc in range(l, r + 1):
            if (rr, cc) not in new_all:
                out[(rr, cc)] = CLEAR
    for c in range(BAR_FULL):                   # 底行填满
        out[(BAR_ROW, c)] = BAR_COLOR
    for p in new_ink:                           # 新杯描边
        out[p] = INK
    for p in new_liq:                           # 新杯液体：色15，与本条断言的颜料色同源
        out[p] = PAINT_AFTER
    return out


def assert_(prev, action, nxt, ctx=None):
    if not _is_reset(action):
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    v = vessel(nxt)
    s = start_cup()
    if v is None or s is None:
        return "NA"
    cup = set(cup_ink(nxt) or ()) | set(liquid(nxt) or ())
    if not cup:
        return "NA"

    if tilt(nxt) != 0:
        return "FALSE"
    if paint_color(nxt) != PAINT_AFTER:
        return "FALSE"
    if bar(nxt) != BAR_FULL:
        return "FALSE"

    # v2：杯回到开局那一个姿势，逐格
    new_ink, new_liq = s
    if set(cup_ink(nxt) or ()) != set(new_ink):
        return "FALSE"
    if set(liquid(nxt) or ()) != set(new_liq):
        return "FALSE"

    top, bot, lef, rig = v
    for r in range(top, bot + 1):
        for c in range(lef, rig + 1):
            if (r, c) in cup:
                continue
            if nxt[r][c] != CLEAR:
                return "FALSE"
    return "TRUE"
