"""四个键就是屏幕的四个方向：杯动了的那一步，杯质心位移的**主分量**恰好是这个键的方向（A1 上 / A2 下 / A3 左 / A4 右）。

这条只说键**是什么**，不说姿势怎么变、也不说什么时候动得了——那两件事分别由
orbit_turn_rule 和 key_dead_by_open_angle 说。三条挂在三个不同的轴上，各自能单独被推翻。

它替换掉的是 tilt_ladder 那套「A3 往 +1 推、A4 往 -1 推」的阶梯读法。阶梯读法在语料的那段弧上
和这条给出同样的预测，但它把 A1/A2 说成了两个无关的键（实为上和下），
而且在轨道绕过顶端以后会预测反——手算阶段我真的因此伪造出过一条「同一个键转反了」的异常，
后查明是我拿 bbox 中心当质心估歪了（斜姿势的 bbox 中心不等于刚体质心）。用真质心，四个键完全对称。

判错的方式：某一步杯动了，而位移的主分量不是这个键的方向；或者位移的两个分量绝对值相等
（根本没有主分量）——那也算假，因为「恰好是」这句话要求主分量存在。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1..ACTION4，且这一步杯真的动了（obj 变了）；杯没动返回 NA —— 那是 "
         "key_dead_by_open_angle 的定义域。换关返回 NA。杯质心在任一侧认不出返回 NA。"
         "位移两分量绝对值相等时判 FALSE 而不是 NA：没有主分量就是这句话说错了。")
NOTE = ("v1。**先声明验过什么**：这条是我在全语料上离线找出来的（runs/<run>/orbit.py 与 claim_check.py，"
        "一个动作没花）。claim_check 在已有的 243 条转移上跑过：59 条杯动了的转移全部对上，零平局，"
        "其余 184 条弃权。所以它在**声明之前**的转移上一分都不该算独立检验——"
        "它的 S 只从声明之后产生的新转移开始挣。这一点必须写在这里，否则等于自己烧掉了考卷。\n"
        "不写 apply：这条不生成像素，它只给键一个方向。生成整帧的是 rot 系概念。")
EVIDENCE = ["92bbb5725a3f2566",      # 旧 tilt 阶梯在这一步被推翻（斜姿势被误判成 -1）
            "e3d8aeb44d09af54",      # 「阶梯到头」在这一步被推翻：到头了照样动
            "f9c81dff6fd84905",      # A1/A2 被当成死键的那段弧之外，它们照样动
            "cef2f65cd9e2cf8f"]

from _lib import DIR_VEC, cup_cen, key_dir, obj


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    k = key_dir(action)
    if k is None:
        return "NA"
    if obj(prev) == obj(nxt):
        return "NA"                       # 没动，不归这条管
    a, b = cup_cen(prev), cup_cen(nxt)
    if a is None or b is None:
        return "NA"
    dr, dc = b[0] - a[0], b[1] - a[1]
    if abs(abs(dr) - abs(dc)) < 1e-9:
        return "FALSE"                    # 没有主分量
    if abs(dc) > abs(dr):
        got = (0, 1 if dc > 0 else -1)
    else:
        got = (1 if dr > 0 else -1, 0)
    return "TRUE" if got == DIR_VEC[k] else "FALSE"
