"""左上那个 18x18 的面板（rows 0..17 × cols 0..17）逐格不变，连 ACTION6 也改不了它。

它是这一局唯一一处「不参与任何交互」的图：色4 折角围着一张 10x10 的图（上半色0、下半色15）。
把它单独立一条，是因为 panel_static 已经被 ACTION6 推翻过一次——横带是控件，这块看着才是告示牌。
这条要是也被推翻，说明它会随进度重画（那它就是计分板或目标提示，归 L4/L5）。
"""
LEVEL = "L1"
SCOPE = "所有动作；只看 rows 0..17 × cols 0..17。换关返回 NA。"
NOTE = ("v3：自查出来的**地界不一致**（不是被反例逼的）：assert_ 换关返回 NA，apply 却一道 guard 都没有。"
        "settle 打分时喂给 apply 的是真 ctx，于是它在自己声明不表态的局面上照样被算 P，"
        "而它只会说「照旧」，换关时这块若重画就必错。这类错法只有 P 看得见，S/C/N 与反例都看不见。"
        "改的是代码不是 SCOPE——SCOPE 早就写着换关返回 NA。\n"
        "v2：LEVEL 从 L0 改成 L1（L0 是清点，不占规划器的槽；这条说的是「任何动作对这一带都没有效果」，属转移函数）。")
EVIDENCE = ["79ecfde154582b91", "e87598919a1f77c3"]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    for r in range(0, 18):
        for c in range(0, 18):
            if prev[r][c] != nxt[r][c]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    # v3：地界与 assert_ 对齐——换关不表态。
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    return {(r, c): prev[r][c] for r in range(0, 18) for c in range(0, 18)}
