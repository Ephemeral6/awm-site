"""关卡只在容器被摆成面板里那张图的那一步递进，且摆成了就一定递进：
`level_next > level_prev` **当且仅当**这一步之后容器逐格等于 `_lib.panel_pic(prev)`。

左上 18x18 面板整局一格没变过（panel_static / target_panel_static），它里面行3..12 列3..12
是一张 10x10 的两色图——上半 5 行色0、下半 5 行色15。容器也正好是 10x10 两色。
本条主张那张图就是**目标**：把容器涂成它，这一关就过。

**它空了很久，这段记录留着**：在最初的 252 条转移里，两边都恒为假——
过关 0/6（level 从没动过），而容器也从没等于那张图。所以它在那段语料上
拿到的每一个 TRUE 都是「假 ⇔ 假」，一分不值。**那时它的 N 是虚的，别拿去当「被检验过」。**
现在不空了：第 363 步点第二只小杯的描边，容器被印章补上最后 12 格、逐格等于目标图，
关卡当场从 2 递进到 3——前件第一次为真，而且判对（v1 在这一步判 FALSE，因为它的落点函数
还不认识印章这个算子；见 NOTE）。

判错的方式：过了关而这一步没把容器摆成那张图（那目标另有其物）；或摆成了那张图而关卡不动
（面板不是目标判据）。

不看 `state`：GAME_OVER / WIN 归 budget_zero_gameover 管，一件事只由一条概念挨打。
"""
LEVEL = "L5"
SCOPE = ("所有动作，但 RESET 返回 NA（重开对关卡计数做了什么没观测过）。ctx 为空、或 ctx 里没有 "
         "level_prev / level_next 时返回 NA。level_next < level_prev 返回 NA。"
         "vessel(prev) 认不出、bbox 不是正方形、或 ACTION5 时 after_pour(prev) 算不出，返回 NA。"
         "**点小杯描边（spout_rim_hit）时用 after_stamp(prev) 算落点**；算不出返回 NA。")
NOTE = ("v2：把「这一步之后容器长什么样」从只认倾倒改成也认印章。\n"
        "  第 363 步 ACTION6:31,18（tid 78d07f9b0f40be0e）点在第二只小杯的描边上，"
        "第 2 关当场递进——v1 判 FALSE，判得对：它算落点时把 ACTION6 一律当成不改容器，"
        "于是「摆成了」为假而「递进了」为真。**这不是本条的主张错了，是它的落点函数缺了一个算子。**"
        "补上 after_stamp 之后，前件重新为真，主张原样成立。\n"
        "  **这次修改扩了什么**：只扩了 after_stamp 认的那一支（点击落在 spout 的色2 描边格上），"
        "别的动作一个字没动。扩之前 ACTION6 那一支恒判「容器不变」，扩之后 14 格描边点击改判；"
        "语料里落进这 14 格的点击共 2 次，都在第 2、3 关。\n"
        "  这是它第一次前件为真而且判对——第 363 步之前，「摆成目标图」这件事在语料里从没发生过，"
        "所以在那之前它拿到的每个 TRUE 都是「假 ⇔ 假」。第 363 步之后 N 里终于有了一条真前件。\n"
        "v1。前件在旧语料上从没成立过，见 docstring 里那段声明——N 是虚的。"
        "配套的推广概念是 a5_paints_cup_side（八向倾倒），本条算「这一步之后容器长什么样」时用的就是它的式子；"
        "那条要是被推翻，本条算出来的落点也跟着不可信，两条要一起看。"
        "现在还多了一条 a6_spout_rim_stamps，同理。")
EVIDENCE = ["d65827ff6900f8d1",      # 第 225 步倾倒：容器变了但没变成那张图，关卡也没动（假 ⇔ 假）
            "2ceb60de47d193fb",      # GAME_OVER 之后那次重开：关卡也没递进
            "78d07f9b0f40be0e"]      # 第 363 步点描边：v1 在这里被推翻，前件第一次真

from _lib import after_pour, after_stamp, panel_pic, spout_rim_hit, vessel


def assert_(prev, action, nxt, ctx=None):
    if not ctx or "level_prev" not in ctx or "level_next" not in ctx:
        return "NA"
    if action.startswith("RESET"):
        return "NA"
    if ctx["level_next"] < ctx["level_prev"]:
        return "NA"
    b = vessel(prev)
    if b is None:
        return "NA"
    t, bo, l, r = b
    if bo - t != r - l:
        return "NA"
    if action.startswith("ACTION5"):
        pred = after_pour(prev)
        if pred is None:
            return "NA"
    elif spout_rim_hit(prev, action):
        pred = after_stamp(prev, action)
        if pred is None:
            return "NA"
    else:
        pred = {}
    after = tuple(tuple(pred.get((rr, cc), prev[rr][cc]) for cc in range(l, r + 1))
                  for rr in range(t, bo + 1))
    hits = after == panel_pic(prev)
    advanced = ctx["level_next"] > ctx["level_prev"]
    return "TRUE" if hits == advanced else "FALSE"
