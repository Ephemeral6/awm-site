"""最后一关达成（state 变成 WIN）那一步**不重绘**：帧差只落在容器 bbox 与底行里，别处一格不动。

前面每一关达成时，屏幕会整幅换成下一关的题面（面板里的目标图、右上的色板、舞台上的物件全换），
帧差因此是几百格，从动作前那一帧算不出来。这条断言**最后一关是例外**：没有下一关可换，
所以那一步的帧差就等于这个算子自己的落点加上底行掉的那一格——一个从当前帧算得出来的数。

判错点：state_next 是 WIN 的那一步，容器 bbox 与底行**之外**有任何一格变了。
（包括面板、右上横带、舞台背景、以及舞台上容器之外的任何物件。）

为什么它必须是一条概念而不是一句经验：上一轮我在最后一步押过「总数算不出来」，
理由是「这一步换场景」；实测总数恰好等于分解，我以保守为名放掉了一个本来押得中的数。
把它写成概念，是让「最后一关不重绘」这句话可以被现实推翻，而不是留在脑子里当习惯。
"""
LEVEL = "L5"
SCOPE = ("只看 ctx['state_next'] == 'WIN' 的那一步，其余一概返回 NA（包括 GAME_OVER 与普通过关）。"
         "ctx 缺失、或 vessel(prev) 认不出时返回 NA。"
         "不写 apply：它说的是「哪些格子不该动」，落点该长什么样归 a6_spout_rim_stamps / "
         "a5_pours_into_vessel 那几条管，这条不重复声明。")
NOTE = ("v1。EVIDENCE 只有一条（上一张卡打到 WIN 的那一步，帧差 13 格 = 盖章落点 12 + 底行 1）。"
        "**入册时我在这里写错过一句**：我说'全语料里 state_next==WIN 的转移就这一条，N 必然是 0'，"
        "结算打出来 N=1——语料里 state 为 WIN 的记录有 2 条，另一条是 held-out 的，它判 TRUE。"
        "错的原因是我没查就断言了一个数得出来的数（一条 lens.py ask 就能查）。原话留在这里不抹。"
        "它的第二张真考卷是这一局打到 WIN 的那一步——押注在动作之前就写了，兑现或落空都由那一步定。"
        "**样本只有个位数**这件事报的时候要带着说。")
EVIDENCE = ["56f51e20940dafb3"]

from _lib import BAR_ROW, vessel


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("state_next") != "WIN":
        return "NA"
    v = vessel(prev)
    if v is None:
        return "NA"
    t, b, l, r = v
    for rr in range(len(prev)):
        if rr == BAR_ROW:
            continue
        row_p, row_n = prev[rr], nxt[rr]
        inside_rows = t <= rr <= b
        for cc in range(len(row_p)):
            if row_p[cc] == row_n[cc]:
                continue
            if inside_rows and l <= cc <= r:
                continue
            return "FALSE"
    return "TRUE"
