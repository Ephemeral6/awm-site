"""底行（row 63）的色4 恒是从 col 0 起的一段连续前缀；普通动作每步让它减 0 或 1 格，绝不变长；只有 RESET 能让它变长，且一次补满整行。

它长得像一条从右往左耗尽的预算条：开局占满整行。
本概念只断言「前缀形状 + 普通动作单调不增且每步最多掉 1 + RESET 补满」，
不断言哪一步会掉——那是 bar_rule 的事。

v1 说「绝不变长」不带例外，被 tid 8ceb44fc3012dc9b 推翻：那一步是 RESET，条子从 33 格直接回到 64 格。
它不是「变长了一点」，是**满血**——所以补满这件事本身可以写成一句更强的话，而不是把「绝不变长」放宽成「可能变长」。
附带记一件 v1 时不知道的事：RESET 那一步装置的步数计数**没有增加**（前后都是第 49 步），
所以重开不花预算，也不花动作；这条概念因此把 RESET 单独列一支，而不是当成第 65 种动作。
被推翻的方式：某个 RESET 之后条子不是恰好 64 格（补一半、或者不补），
或者某个非 RESET 动作让它变长（那说明还有别的东西能回血，得再拆一条）。
"""
LEVEL = "L4"
SCOPE = ("所有动作；只看 row 63。换关返回 NA（新关可能把条补满，没观测过）。"
         "row 63 不是「色4 前缀 + 非色4 尾」时判 FALSE（那是形状主张的一部分）。")
NOTE = ("v2：反例 8ceb44fc3012dc9b（RESET 把条子从 33 格补回 64 格）。"
        "v1 的 scope 里写着「换关返回 NA（新关可能把条补满）」——我当时想到了「补满」这种事存在，"
        "但只把它挂在换关上，没想到同一关里也能补。教训写进了方法草稿："
        "**scope 里预留的例外，要连同「还有什么别的路径能触发它」一起想一遍**。")
EVIDENCE = ["46281d289ec9ea6b", "3c29bf6fbe446e56", "8ceb44fc3012dc9b"]

from _lib import bar, bar_is_prefix, BAR_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not bar_is_prefix(prev) or not bar_is_prefix(nxt):
        return "FALSE"
    if action.strip().upper() == "RESET":
        return "TRUE" if bar(nxt) == len(nxt[BAR_ROW]) else "FALSE"
    d = bar(prev) - bar(nxt)
    return "TRUE" if d in (0, 1) else "FALSE"


def apply(prev, action, ctx=None):
    """只有 RESET 那一支敢生成整条 row 63：补满就是整行都是色4。"""
    if action.strip().upper() != "RESET":
        return None
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    from _lib import BAR_COLOR
    return {(BAR_ROW, c): BAR_COLOR for c in range(len(prev[BAR_ROW]))}
