"""杯动了的那一步，新开口 = 旧开口朝**远离**键方向的一侧转 45 度（`_lib.turn`）。

轨道是闭合的：八个工位按 45 度均分角度，绕着容器排一圈。按键 K 时杯走到相邻的那个工位，
走的方向是 K，于是开口相对 K 转开 45 度。这条只管「转到哪」，不管「转不转得动」
（那是 key_dead_by_open_angle）、也不管「键是什么方向」（那是 keys_are_screen_dirs）。

它替换掉的是 tilt_ladder 的「A3 推 +1 / A4 推 -1」：那是把一条闭合轨道读成了一条有两端的阶梯。
阶梯读法说不出「转一圈会回到原处」，而这条说得出——只要世界肯把杯带到没走过的那两个工位。

判错的方式：某一步杯动了、判据说新开口该是 X，实际不是 X。八个工位里还有两个（西、西北）
一次都没到过，所以这条最脆的地方在轨道的那半边。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..ACTION4 且判据说这一步能动（turn 不返回 None）；"
         "判据说是空动作返回 NA —— 那归 key_dead_by_open_angle。"
         "换关返回 NA；任一侧开口方向认不出返回 NA；杯一格没动也返回 NA"
         "（「说能转却没转」由 key_dead_by_open_angle 的活支抓，同一个失败不让两条概念各挨一记）。"
         "只断言新开口的**方向**，不断言杯的格集——格集由 rot 系概念生成。")
NOTE = ("v1。**先声明验过什么**：turn() 的规则是在全语料上离线定出来的，"
        "runs/<run>/lib_check.py 在 133 条 A1..A4 转移上逐条比对，59 条说动的全部动对、0 条对不上。"
        "所以声明之前的转移不算独立检验，S 只从新转移开始挣。\n"
        "预注册（ORBIT.md 第 4 节）：还没按过的 6 个 (姿势, 键) 格里，这条对其中 3 个说话——"
        "开口西南按 A2 -> 开口西；开口北按 A3 -> 开口东北；开口北按 A4 -> 开口西北。"
        "西与西北是两个从没见过的姿势。")
EVIDENCE = ["92bbb5725a3f2566",      # 旧阶梯读法在这一步被推翻
            "e3d8aeb44d09af54",
            "79ecfde154582b91",      # 转档那几步：新旧读法在这段弧上一致
            "3c29bf6fbe446e56"]

from _lib import key_dir, obj, open_dir, turn


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    k = key_dir(action)
    if k is None:
        return "NA"
    d, nd = open_dir(prev), open_dir(nxt)
    if d is None or nd is None:
        return "NA"
    pred = turn(d, k)
    if pred is None:
        return "NA"                        # 空动作，不归这条管
    if obj(prev) == obj(nxt):
        return "NA"                        # 杯没动，这条的前件不成立；「该动却没动」由
                                           # key_dead_by_open_angle 的活支去抓，一件事只由一条概念挨打
    return "TRUE" if nd == pred else "FALSE"
