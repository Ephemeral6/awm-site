"""ACTION6 点中某个色板环、或 RESET，都会把横带里那条 1x5 的色0 下划线**搬到新选中的环正下方**：
旧位置那 5 格从色0 变回横带底色（色3），新位置那 5 格从横带底色变成色0；这一整行（乃至整条横带）
没有第三段格子会动。

这条补的是一个**生成**上的空槛，不是一个新的读数：`underline()` 早就认得下划线在哪，
`underline_marks_paint` 早就断言「下划线永远在当前颜料色那个环下面」这条不变量，
`a6_swatch_sets_paint` 也早就预测点环之后颜料色会变成谁——但把这三件事接起来、
在动作发出之前**把下划线要挪到的那 10 个格子写出来**，没有一条现有概念的 `apply` 做这件事：
`a6_swatch_sets_paint.apply` 只声明容器与杯（见其 SCOPE：「舞台上其余的格子…本概念不声明」）；
`panel_static.apply` 反过来专门把下划线所在的那一行**跳过**（见其 SCOPE 与 `_skip_rows`）；
`reset_sets_state.apply` 只声明底行/容器/杯，同样没提横带。三条概念划出的地盘刚好在下划线这
一行上都空着——不是谁判错了，是没人认领这块地。

判错的方式：旧位置的 5 格没有变回色3，或新位置的 5 格没有变成色0，或者除了这两段以外这一行
还有别的格子动了。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6（点击坐标落在 swatches() 认出的某个环的 5x5 bbox 内，且该环芯色可读）与 "
         "RESET；其余动作返回 NA。swatches(prev) 一个环都认不出、或 underline(prev) 认不出时返回 NA。"
         "RESET 的目标颜色按色15（沿用 reset_sets_state 的假设：这局还没把「重开后的颜料色」与"
         "「色15」这个具体颜色分开，见它的 NOTE）；算不出目标色、或找不到芯色等于目标色的环、"
         "或有不止一个环同芯色（颜色不足以定位选中项，见 underline_marks_paint 的 v3 教训）时返回 NA。"
         "换关（ctx 给出且 level_prev != level_next）返回 NA：换关时横带的环布局本身可能重排"
         "（实测换关那两步横带的分隔列也跟着变，那不是这条要管的动作），不在这条的地盘里。")
NOTE = ("v1。在全量语料（runs/cd82-0905-1311/transitions.jsonl，354 行、298 个去重 tid）上跑过"
        "本条的 assert_：51 个去重帧命中（TRUE 51 / FALSE 0 / NA 247），零反例。"
        "命中的既有 ACTION6 点环（如 e87598919a1f77c3：点 col37,row4，下划线 cols41-45 → cols35-39），"
        "也有非幂等的 RESET（ca2058f1668862f2：颜料 0→15，下划线 cols35-39 → cols41-45，10 格差），"
        "换关那两步 RESET（level 2→0，同一个 tid 79f85baf04e1324e）按 SCOPE 的换关守卫正确弃权——"
        "那两步横带的分隔列本身在变，套用「只搬 10 格」的模型会算错，弃权比硬猜诚实。"
        "没跑过的：这一局只观测到两种颜料色（0 与 15）在同一横带布局下切换，RESET 目标色=15 这条"
        "假设与 reset_sets_state 共享同一个未分开的缝——等某一关开局色不是色15，两条会一起挨打。")
EVIDENCE = ["e87598919a1f77c3",      # ACTION6:37,4：下划线从 cols41-45 搬到 cols35-39（10 格差）
            "ca2058f1668862f2"]     # RESET（非幂等）：颜料 0->15，下划线从 cols35-39 搬到 cols41-45

from _lib import swatches, underline

BAND_BG = 3          # 横带底色（实测：不属于任何环、也不是下划线的那些横带格全是这个颜色）
UNDERLINE_COLOR = 0  # 下划线本身的颜色


def _click(action):
    """ACTION6:x,y -> (行, 列)；解析不出返回 None。x 是列，y 是行。"""
    if ":" not in action:
        return None
    try:
        x, y = action.split(":", 1)[1].split(",")
        return (int(y), int(x))
    except (ValueError, IndexError):
        return None


def _new_color(prev, action):
    """这一步之后的目标颜料色；算不出返回 None。"""
    a = action.strip()
    if a.upper() == "RESET":
        return 15
    if not a.startswith("ACTION6"):
        return None
    p = _click(a)
    if p is None:
        return None
    r, c = p
    for (t, b, l, ri), core in swatches(prev):
        if core is not None and t <= r <= b and l <= c <= ri:
            return core
    return None


def _predict(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    color = _new_color(prev, action)
    if color is None:
        return None
    u = underline(prev)
    if u is None:
        return None
    row, old_l, old_r = u
    target = None
    for (t, b, l, ri), core in swatches(prev):
        if core == color:
            if target is not None:
                return None   # 不止一个环同芯色，颜色定位不到唯一的选中项
            target = (l, ri)
    if target is None:
        return None
    new_l, new_r = target
    out = {}
    for c in range(old_l, old_r + 1):
        out[(row, c)] = BAND_BG
    for c in range(new_l, new_r + 1):
        out[(row, c)] = UNDERLINE_COLOR
    return out


def assert_(prev, action, nxt, ctx=None):
    pred = _predict(prev, action, ctx)
    if pred is None:
        return "NA"
    for (r, c), col in pred.items():
        if nxt[r][c] != col:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    return _predict(prev, action, ctx)
