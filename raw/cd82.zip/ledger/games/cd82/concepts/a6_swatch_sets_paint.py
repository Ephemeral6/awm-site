"""点在横带某个色板环的 5x5 范围里（含色4 边框，不必是芯），**每一只杯**里**当前装着颜料的那些格**
（颜色等于 paint_color 的格）都整块换成那个环的芯色，格子一个不少不多；
杯里颜色不等于当前颜料色的格、杯的描边、容器，一格不动。

实测：杯里 84 格色15 在一次 ACTION6 之后整块变成色0，容器里的 65 格色15 一格没退，色2 描边没动。
所以颜料色是个可选的量，选它不花任何舞台上的代价——这是「ACTION5 到底涂什么颜色」这条链的上游。
注意坐标序：ACTION6:x,y 里 x 是列、y 是行（装置的 parse_action 如此），别读反。

v1 只认 3x3 的芯，因为头两次有效点击都恰好落在芯上。后来点环的色4 左/右边框（一次落在边框列上）
同样换了色，所以整个 5x5 环都是按钮，边框不是装饰。这不是被推翻——v1 对边框点击返回 NA、
不表态——但它把有效面积说小了 16/25，而「按钮有多大」正是要交的东西。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6，且点击坐标必须落在 swatches() 认出的某个环的 5x5 bbox 内（含色4 边框；否则返回 NA）；"
         "paint_color() 认不出、或 cup_liquid() 是空集时返回 NA。**只声明三块地**："
         "所有杯里颜色等于当前颜料色的格（换色）、所有杯里其余的格与杯的描边（不动）、"
         "容器 bbox 里的格（不动）。"
         "舞台上其余的格（背景、以及将来可能出现的别的物件）本概念不声明。换关返回 NA。")
NOTE = ("v4：**没有新反例，是我自己把 v3 的口径查出来错了。** v3 说「杯里颜色不是 0 的格才是液体」，"
        "那句话被语料直接推翻：第 24 步与第 252 步大杯那 84 格**全是色 0**，点色板之后 84 格全换了色"
        "（`runs/cd82-0905-1311/liqdef.py`）。v3 的 NOTE 里还写过一句"
        "「『色不是 0』与『颜色 == 旧颜料色』在已观测数据上分不开——两者只在一只杯同时装着两种非 0 色时"
        "才有分歧，而那种局面一次都没见过」，那句话也是错的：分歧根本不需要两种非 0 色，"
        "只要**当前颜料色本身就是 0** 就分开了，而第 0 关 39 次点色板全是这一类。\n"
        "        错法比错本身值钱：v3 并没有判 FALSE，它在那一整类步上**返回 NA、整条弃权**。"
        "弃权不报错、不关闸、S 照样 1.000——盘上唯一看得见它的地方是规则图完成度 E。"
        "代价实测 **1600/21779 格**（`runs/cd82-0905-1311/eblame2.py`：把本概念单独换回 v2，"
        "E 从 0.733 涨回 0.806；最伤的是第 184/190/196 步这一串，旧版各解释 85 格、v3 各解释 0 格）。"
        "我是在查「E 为什么从 0.796 掉到 0.733」时撞见它的，不是靠读代码看出来的。\n"
        "        v4 的口径是「颜色 == paint_color(prev) 的格」，全量核过（`runs/cd82-0905-1311/h4.py`："
        "82 条不同的 ACTION6 转移里，同关的部分说对 45 条、说错 0 条、弃权 37 条——37 条弃权全是"
        "点在环外，且逐条核过「弃权的那些步杯里一格没变」；命中帧差格 3634 格）。\n"
        "        这个口径没验到的缝，写清楚免得下次又当成已知：全语料 213 个去重帧里"
        "**没有一只杯装着既非色 0 又非当前颜料色的格**（`runs/cd82-0905-1311/cupcolors.py`：0 例），"
        "所以「颜色 == 当前颜料色」和「杯的几何内部整块」在大杯上逐格等价，两者只在第二只杯那 2 格色 0 上"
        "分歧（本概念说不换，实测不换）。要把两者彻底分开，需要一只装着「不是当前颜料色」的杯——"
        "这一局还没出现过这种局面。\n"
        "v3：反例 e8ea6c6dd4fb029b（第 2 关，ACTION6:41,4）。根因是词汇口径太窄，不是主张错了——"
        "新关舞台上多了第二只小杯，它肚里那 12 格液体**也跟着换了色**（15→11），"
        "而 `liquid()` 只认最大那一只，于是这 12 格被本概念预测为「不动」。"
        "换成 `cup_liquid()`（所有杯里的液体）之后，主张比 v2 **更强**："
        "它现在断言选色是个全局量，一次点击改的是场上每一只杯，不是被选中的那一只。\n"
        "同一版顺手把 v2 的一句过头话收回：v2 声明「舞台上液体之外的格子一格不动」，"
        "那是**替别的概念说话**——舞台上出现任何新东西都会算到它头上，而它对新东西一无所知。"
        "v3 只声明它真正管的三块地（杯的液体、杯的其余部分与描边、容器）。"
        "这一句收回不是为了躲反例：躲反例的改法是把那 12 格排除出去，那样能过闸但什么也没学到；"
        "v3 反过来把那 12 格**纳入**预测。"
        "（这一句收回本身是对的，代价另算：v4 的实测说明 v3 掉的 1600 格里，收窄不是主因，口径才是。）\n"
        "v2：有效区从 3x3 芯放宽到整个 5x5 环。由 tid 34670ba0ff24e4a3 定（点 col45,row4 = 右环的色4 右边框，"
        "杯里 84 格液体照样从色0 变色15、下划线照样搬家，帧差 95 格）。同一批里点面板、点空白舞台、"
        "点杯的描边、点横带的色3 底全是空点，所以「能选色的表面」恰好就是两个环，不多不少。")
EVIDENCE = ["e87598919a1f77c3", "34670ba0ff24e4a3", "e8ea6c6dd4fb029b"]

from _lib import cup_blobs, cup_liquid, ink, swatches, vessel



def _click(action):
    """ACTION6:x,y -> (行, 列)；解析不出返回 None。"""
    if ":" not in action:
        return None
    try:
        x, y = action.split(":", 1)[1].split(",")
        return (int(y), int(x))
    except (ValueError, IndexError):
        return None


def _target_color(prev, action):
    """被点的那个环的芯色；没点在环的 5x5 里返回 None。"""
    p = _click(action)
    if p is None:
        return None
    r, c = p
    for (t, b, l, ri), core in swatches(prev):
        if core is not None and t <= r <= b and l <= c <= ri:
            return core
    return None


def _predict(prev, action):
    col = _target_color(prev, action)
    if col is None:
        return None
    liq = cup_liquid(prev)
    if not liq:
        return None
    out = {}
    # 一、容器里的格：不动（选色不花舞台上的代价，这是本概念最贵的一半）。
    v = vessel(prev)
    if v is not None:
        t, b, l, r = v
        for rr in range(t, b + 1):
            for cc in range(l, r + 1):
                out[(rr, cc)] = prev[rr][cc]
    # 二、所有杯里颜色不等于当前颜料色的格（第二只杯颈部那 2 格色0）与杯的描边：不动。
    for (rr, cc) in ink(prev):
        out[(rr, cc)] = prev[rr][cc]
    for b2 in cup_blobs(prev):
        for (rr, cc) in b2:
            if (rr, cc) not in liq:
                out[(rr, cc)] = prev[rr][cc]
    # 三、所有杯里装着颜料的格：换成被点那个环的芯色。最后写，免得被上面两块的 bbox 盖掉。
    for q in liq:
        out[q] = col
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    pred = _predict(prev, action)
    if pred is None:
        return "NA"
    for (rr, cc), col in pred.items():
        if nxt[rr][cc] != col:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6"):
        return None
    return _predict(prev, action)
