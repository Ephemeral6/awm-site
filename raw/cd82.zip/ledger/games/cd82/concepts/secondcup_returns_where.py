# -*- coding: utf-8 -*-
"""大杯从斜工位转回正向工位那一步，第二只小杯的落点只由「容器 bbox 中心 + 目标工位」定死：一组固定的相对偏移绕容器中心转到目标工位，逐格、连颜色一起，跟这一关是哪一关无关。

拆成四句，四句都能单独判假：

一、**目标工位**：`nd = turn(open_dir(prev), key_dir(action))`。prev 停在斜工位时 nd 必是正向
    （四个键只走 ±45°），所以「斜工位起步 + turn 不返回 None」这一类就是「小杯要回来」那一类。
二、**落哪 28 格**：把 `HOPPER_REL` 里那 28 个「相对容器中心的双倍偏移」摊在容器中心上，
    再绕容器中心（`_lib.hub`）顺时针（`_lib.rot90(..., ccw=False)`）转 `(CANON - nd) / 2` 个直角，
    得到的就是下一帧小杯占的格；`spout(nxt)` 必须恰好等于这 28 格，不许多一格也不许少一格。
三、**每格什么色**：14 格描边色 `INK`，12 格腔是**当前颜料色** `paint_color(prev)`，2 格颈是色 `NECK_COLOR`。
    角色跟着格子一起转，不随关卡变。
四、**没有小杯的关也要表态**：单帧上「这一关有没有第二只小杯」的证人是横带上的色环数 ——
    环数 `< HOPPER_RINGS` 的关没有它，那 28 格在下一帧必须全是舞台背景色 `STAGE_BG`，且 `spout(nxt)` 为空。

它补的是「小杯不在 prev 上时它会回到哪」这个洞：prev 停在斜工位，小杯整块不在画上，
所以任何「记住上次的样子再转过去」的说法都不是概念（`assert_` / `apply` 只拿到 prev / action / ctx，没有历史）。
本条不看历史：`HOPPER_REL` 是一组量出来的常数，落点由 prev 上的容器几何 + 目标工位算出。
"""
LEVEL = "L6"
SCOPE = ("只看四个键 A1..A4（`key_dir` 认得出的动作），且 `open_dir(prev)` 是**斜**工位（下标为奇）、"
         "`turn` 不返回 None（这一步真的会转）。其余动作、prev 已在正向工位、死键，一律返回 NA —— "
         "prev 在正向工位时小杯就在画上，那是 secondcup_only_cardinal 的地界。"
         "换关（level_prev != level_next）返回 NA：新关的家具没观测过。"
         "`hub(prev)`（容器认不出）、`paint_color(prev)`、`swatches(prev)`（一个环都认不出）任一读不出时返回 NA。")
NOTE = ("常数怎么来的、在哪儿核过、哪一层是外推 —— 全写在这里，免得把外推当成推导：\n"
        "1. `HOPPER_REL` 的 28 个偏移与角色，是从 tid 56f8d3912a81bbdd 的 **next** 帧量的"
        "（那一帧开口朝南、颜料色 15、横带 7 个环），并在 tid e8ea6c6dd4fb029b 的 prev 帧上复量了一遍，两次一致。\n"
        "2. 「摊在容器中心 + 绕容器中心顺时针转到目标工位」这条摆法，在语料（去重后 380 条转移的两侧帧）里"
        "**14 个 (关卡, 正向工位) 组合、123 帧**上逐格 + 逐角色核过，全同 123/123。覆盖 5 个关卡、4 个正向工位；"
        "有 6 个 (关卡, 工位) 组合语料里从没出现过，那 6 格是外推。\n"
        "3. 角色→颜色那一句里，腔 = 当前颜料色这一条只在颜料色 != NECK_COLOR 的帧上核过（123 帧全部如此）。"
        "要是哪一关的颜料色恰好等于 NECK_COLOR，腔和颈就分不开，本条会说不清 —— 那种帧语料里没有。\n"
        "4. `HOPPER_RINGS = 7` 是**最弱、最可疑的一层**：语料里环数只出现过 2 / 3 / 7 三个值，"
        "环数 7 的关都有小杯（5 个关卡），环数 2 与 3 的关都没有（2 个关卡）。4/5/6 个环的关一次都没见过，"
        "所以这条阈值是拿两组观测硬劈出来的外推，不是从机制导出的；哪一关拿 5 个环配一只小杯，第四句就当场判假。\n"
        "5. 「相对容器中心」这一层在语料里**分不出真假**：容器从没挪过位置（vessel_frozen 就是说这个），"
        "所以「相对容器中心的偏移」和「一组绝对坐标」在已有观测上完全等价。选相对写法是因为它在容器一旦挪位时"
        "能被判错、而绝对坐标那版连错都错不出来；但这一层本身没被任何观测支持过。\n"
        "6. 本条不断言「小杯回来后能不能盖章」「它和大杯谁先画」这类事，那不在这条的地界里。\n"
        "7. **先验证声明（由收下它的人补写，不是原作者写的）**：这条概念是先在**全部 380 条去重转移**上"
        "核完（TRUE 58 / FALSE 0 / NA 322）才决定入册的，所以那 58 条 TRUE 里除 EVIDENCE 之外的部分"
        "**不是它的考卷**——写它之前答案已经被看过了。装置分不出先看后看，只能由这里声明：\n"
        "   **它的 S 只从本条声明之后新产生的转移起算。** 声明前那 58 条算「拟合得上」，不算「被独立检验」。\n"
        "   收下它仍然是对的：它补的那个洞（斜工位转回正向时小杯落在哪）是规划器现在唯一算不出的一步，"
        "   而「不写它、拿脑子里的规律去押数」是更坏的一种。")
EVIDENCE = ["56f8d3912a81bbdd",      # 常数量自这一条的 next（进到有小杯的关、落在南）
            "e8ea6c6dd4fb029b",      # 同一工位复量的那一帧
            "13fe0dfbaa54fe3f",      # 斜->正：东南->南，小杯回到常数算出的 28 格
            "8c092e00e3e3029e",      # 斜->正：东南->东，转 3 个直角那一支
            "d4f579781849e44d",      # 斜->正：西北->西，另一个关卡上同一组常数
            "3c29bf6fbe446e56",      # 环数 2 的关：斜->正，落点那 28 格在 next 上全是背景
            "c23ac2057eceb180"]      # 环数 3 的关：同上，第四句的另一侧

from _lib import (INK, STAGE_BG, hub, key_dir, open_dir, paint_color, rot90,
                  spout, swatches, turn)

CANON = 6            # 基准工位：开口朝南。偏移表就是在这个工位上量的
NECK_COLOR = 0       # 颈那两格的颜色
HOPPER_RINGS = 7     # 横带色环数 >= 这个数的关，才有第二只小杯（见 NOTE 第 4 条：这是外推）

# (2*(行 - 容器中心行), 2*(列 - 容器中心列), 角色)。乘 2 是为了让偏移是整数：
# 容器边长是偶数，中心落在半格上。
HOPPER_REL = (
    (-41, -3, "rim"),
    (-41, -1, "rim"),
    (-41, 1, "rim"),
    (-41, 3, "rim"),
    (-39, -5, "rim"),
    (-39, -3, "rim"),
    (-39, -1, "neck"),
    (-39, 1, "neck"),
    (-39, 3, "rim"),
    (-39, 5, "rim"),
    (-37, -5, "rim"),
    (-37, -3, "cav"),
    (-37, -1, "cav"),
    (-37, 1, "cav"),
    (-37, 3, "cav"),
    (-37, 5, "rim"),
    (-35, -5, "rim"),
    (-35, -3, "cav"),
    (-35, -1, "cav"),
    (-35, 1, "cav"),
    (-35, 3, "cav"),
    (-35, 5, "rim"),
    (-33, -5, "rim"),
    (-33, -3, "cav"),
    (-33, -1, "cav"),
    (-33, 1, "cav"),
    (-33, 3, "cav"),
    (-33, 5, "rim"),
)


def _cardinal(d):
    return d is not None and d % 2 == 0


def _target_station(prev, action):
    """这一步之后的工位；不在本条地界里就返回 None。"""
    k = key_dir(action)
    if k is None:
        return None
    d = open_dir(prev)
    if d is None or _cardinal(d):        # 只管「斜工位起步」
        return None
    nd = turn(d, k)
    if nd is None or not _cardinal(nd):  # 死键 / 没转到正向
        return None
    return nd


def _roles_at(prev, nd):
    """{格: 角色}：常数摊在容器中心上，再绕容器中心转到工位 nd。几何只借 _lib.hub / _lib.rot90。"""
    h = hub(prev)
    if h is None:
        return None
    quarters = ((CANON - nd) // 2) % 4
    out = {}
    for dr2, dc2, role in HOPPER_REL:
        q = (int(round(h[0] + dr2 / 2.0)), int(round(h[1] + dc2 / 2.0)))
        for _ in range(quarters):
            q = rot90(q, h, ccw=False)   # 顺时针
        out[q] = role
    return out


def _has_hopper(prev):
    """单帧证人：横带色环数。认不出环返回 None（不表态）。"""
    sw = swatches(prev)
    if not sw:
        return None
    return len(sw) >= HOPPER_RINGS


def apply(prev, action, ctx=None):
    nd = _target_station(prev, action)
    if nd is None:
        return None
    roles = _roles_at(prev, nd)
    if roles is None:
        return None
    has = _has_hopper(prev)
    if has is None:
        return None
    if not has:
        # 这一关没有第二只小杯：落点那 28 格下一帧仍是舞台背景
        return {q: STAGE_BG for q in roles}
    col = paint_color(prev)
    if col is None:
        return None
    out = {}
    for q, role in roles.items():
        out[q] = INK if role == "rim" else (col if role == "cav" else NECK_COLOR)
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    nd = _target_station(prev, action)
    if nd is None:
        return "NA"
    pred = apply(prev, action, ctx)
    if pred is None:
        return "NA"
    # 一、预测的每一格，颜色要逐格对上
    for q, col in pred.items():
        if nxt[q[0]][q[1]] != col:
            return "FALSE"
    # 二、小杯在场与否，也要对上：在场就恰好是这 28 格，不在场就一格都没有
    sn = set(spout(nxt))
    if _has_hopper(prev):
        if sn != set(pred):
            return "FALSE"
    elif sn:
        return "FALSE"
    return "TRUE"
