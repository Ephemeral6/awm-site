"""ACTION5 把容器里**靠杯那一侧的半平面**整片重涂成当前颜料色：界线过容器 bbox 中心、
垂直于「容器→杯」，取靠杯那半边（含界线上的格），另半边一格不动。

这条把旧的三档倾倒（a5_fill_halfplane，只认开口南 / 东南 / 西南）推广到八个开口方向，
用的是一个式子而不是三条写死的不等式：杯在容器的 `(open_dir+4)%8` 方向那一侧
（开口永远指着容器，见 open_faces_vessel），涂的就是那一侧。`_lib.side_halfplane / after_pour`。

**为什么这不是同一件事换个写法**：语料里倒过的 30 次全落在开口南 / 东南 / 西南，而那恰好是
杯**严格位于容器上方**的三个姿势。所以 30/30 同时被两种规律解释：
  (a) 涂靠杯那半边——本条主张，八个方向都能倒；
  (b) 涂靠杯那半边，**但只有杯在上方时倒得出来**（重力），杯在下方或侧面时 ACTION5 是空动作。
两者在旧语料上逐格无法分辨。本条选 (a)，于是它在开口北 / 东北 / 西北 / 东 / 西 这五个从没倒过的
工位上是**纯外推**：那里一旦倒出空动作（整帧不变），本条立刻假，而 (b) 活。这是它入册的理由——
它在还没发生的转移上说了一句会错的话。

判错的方式：靠杯那半边有一格没变成当前颜料色，或另半边有一格变了。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；其余动作返回 NA。after_pour(prev) 算不出（容器 / 开口方向 / 颜料色任一"
         "认不出，或容器 bbox 不是正方形）返回 NA。只看容器 bbox 之内——容器外归 "
         "a5_pours_into_vessel。换关返回 NA：新关的容器没观测过。")
NOTE = ("v2：**apply 补上 assert_ 早就有的那道换关守卫**（v1 只在 assert_ 里写了，apply 里漏了）。\n"
        "  这不是改主张，是修口不对心：SCOPE 里明写着「换关返回 NA：新关的容器没观测过」，"
        "而 v1 的 apply 在换关那两步（第 253、263 步，两次都是 ACTION5 顺手过关）照旧逐格声明了"
        "新容器的 100 格——正好说的是它自己声明不管的那块地。\n"
        "  **它是怎么被发现的**：不是靠反例，也不是靠 S/C/N——那三个数一格没动，因为 assert_ 弃权，"
        "本条在这两步上根本没被判过。看得见它的只有结算末尾的**打架表**："
        "`a5_paints_cup_side × levelup_resets_stage 90 格  例 56f8d3912a81bbdd`。"
        "换关重置概念一入册，两条对同一批格给出不同颜色，账才浮出来（`runs/<run>/settle_270e.txt`）。\n"
        "  读数：v1 预测 3300 格对 3160 格 P=0.958，那 140 格错的全在这两步里。"
        "预期 v2 少声明 200 格（两步各 100），E 不该跌——换关那两步的容器帧差格 v1 一格也没预测对"
        "（真值全是色 0，本条给的是颜料色或照抄 prev，都不是 0），跌了就说明我这段推理又错了，照实记。\n"
        "v1。**先声明一件会让 S 变得不干净的事**：入册前我已在全语料上跑过它"
        "（runs/<run>/pour8.py：30 次倾倒逐格核对 30 对 / 0 不对 / 0 弃权；"
        "并核对了 side_halfplane(10, 南/西南/东南) 与旧三档的格集逐格相同，各 50/55/55 格）。"
        "那 30 条对它不是考卷——我看过答案了。它的 S 只从声明之后新产生的转移起算才有意义。\n"
        "**预注册的三个预测**（写在动作发出之前，五个没倒过的工位里这三个先兑现）：\n"
        "  开口北（杯在容器正下方）→ 涂下半 5 行 50 格；\n"
        "  开口东（杯在容器正左）→ 涂左半 5 列 50 格；\n"
        "  开口西北（杯在容器右下）→ 涂右下三角 55 格（行+列 >= 9）。\n"
        "任一处倒出整帧不变，本条假、重力假设 (b) 活，那时该做的是 v2 加一条「杯须在上方」的守卫，"
        "而不是把主张改成事后可对的样子。\n"
        "和 a5_fill_halfplane 的关系：那条是本条在三档上的限制，逻辑上被本条蕴含。**暂时两条都留**——"
        "本条要是被推翻，那条还得继续管那三个工位；本条活过五个新工位之后再撤它。")
EVIDENCE = ["5d164e85e3b35523",      # 开口南：涂上半 5 行
            "a215d90877336853",      # 开口西南：涂右上三角
            "a470b4881bc761c4",      # 开口东南：涂左上三角
            "23cae6d2d149d836"]      # 同色同工位再倒一次：半边已是该色，整帧不变（幂等）

from _lib import after_pour, vessel


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    pred = after_pour(prev)
    if pred is None:
        return "NA"
    b = vessel(prev)
    t, bo, l, r = b
    for rr in range(t, bo + 1):
        for cc in range(l, r + 1):
            want = pred.get((rr, cc), prev[rr][cc])
            if nxt[rr][cc] != want:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """容器里的每一格：靠杯那半边给颜料色，另半边照抄。"""
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None                      # 与 assert_ 同源的守卫：换关后的容器不是本条管的容器
    if not action.startswith("ACTION5"):
        return None
    pred = after_pour(prev)
    if pred is None:
        return None
    b = vessel(prev)
    t, bo, l, r = b
    return {(rr, cc): pred.get((rr, cc), prev[rr][cc])
            for rr in range(t, bo + 1) for cc in range(l, r + 1)}
