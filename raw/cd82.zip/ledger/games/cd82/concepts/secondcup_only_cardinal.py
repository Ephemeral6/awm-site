"""舞台上除大杯以外还能有第二只小杯（`_lib.spout`），而**它在场时，大杯的开口一定指向四个正向之一**
（东 / 北 / 西 / 南，即 `open_dir` 的下标是偶数）；开口斜着的时候它一定不在场。
在场期间它跟着大杯一起转：同一个工位上它一格不移动，工位一换成斜向它那 28 格整块变成舞台背景。

这条替掉了被推翻的 spout_south_only（v1，撤册理由在 journal）。那条说的是「只在开口**南**」，
第 339 步（东南 -> 东）与第 340 步（在东倾倒）把它打死了：东工位上它也在。
现在的口径是「只在**正向**」，斜向那一半的证据没变，正向那一半从一个工位放宽到四个。

**为什么这只杯重要，以及后来怎么样了**：它是这一关第九个算子的容器——
点它的描边会把腔里的颜料整块盖进容器最靠近它的那条边（`a6_spout_rim_stamps`）。
写下本条的时候这还只是个悬念（`vessel_in_pour_orbit` 用存在性论证指出「一定还缺一个算子」，
而这只杯的腔尺寸正好对得上目标图里那块拼不出来的矩形），后来被证实了，
那条 vessel_in_pour_orbit 也因此被它自己预告的算子打死、撤了册。
本条只把这只杯**当作物件**钉住：它什么时候在、在哪、动不动；它**做什么**归 a6_spout_rim_stamps 管。

判错的方式：任何一帧里它非空而大杯开口是斜的；或者它在同一工位的相邻两帧里挪了位置；
或者它消失的那一步，它原先占的格里有一格没变成舞台背景色。
"""
LEVEL = "L6"
SCOPE = ("所有动作。换关（level_prev != level_next）返回 NA——新关的家具没观测过。"
         "prev 与 nxt 都没有第二只杯时返回 NA（那种帧上本条恒真，不该拿去充 N）。"
         "prev 或 nxt 上 open_dir 认不出（描边或液体缺失）时返回 NA。"
         "apply 只在四个键上出预测，且只出两种：空动作预测它照旧；"
         "转到斜向工位预测它那些格整块变舞台背景。**转到另一个正向工位不出预测**——"
         "它会转成什么样只有 prev 说不出来。ACTION5 / ACTION6 / RESET 一概不表态"
         "（选色会改它肚里的颜色，那归 a6_swatch_sets_paint 管）。")
NOTE = ("v2：只换读数与说明，代码、SCOPE、主张一个字没动。原因是 v1 的 NOTE 里写着"
        "「北与西这两个正向工位一次都没去过，四个正向里有两个是外推」——**这句现在不成立了**，"
        "四个正向全去过，那句话再留着就是把已经兑现的外推继续说成外推。\n"
        "**声明我看过什么**：写 v1 之前我把全语料按 (关卡, 开口方向) 数过它、把它在场/离场的每一条转移逐格看过；"
        "所以 v1 之前的语料对本条不是考卷。v2 的读数由一双独立的眼睛在全量语料上重量了一遍"
        "（runs/<run>/secondcup_recount.py / .out），我没有参与那次统计。\n"
        "**v2 的读数**（语料截至第 4 关中途，去重帧 281 条 / 帧出现 812 次 / 转移记录 406 条）：\n"
        "  · 在场而开口是斜向的帧：**0 例**（去重前后都是 0）。这是本条最容易死的那一面，仍然没死。\n"
        "  · 同一方向的相邻两帧里挪过位置：**0 条 / 406**。\n"
        "  · 消失的转移 19 条记录（18 个不同 tid，有一对 tid 重复）：每一次原先占的都是 **28 格**，"
        "而这 28 格在下一帧里非背景的有 **0 格**——即每次都是整块变背景，一次例外都没有。\n"
        "  · 出现的转移 20 条记录（18 个不同 tid）。\n"
        "  · 四个正向的首次在场：南 第 263 步（关 2/3/4 都有）、东 第 339 步（关 2/3）、"
        "北 第 342 步（关 2/3/4）、西 第 346 步（关 2/4）。**外推兑现了：北与西都去过，都在场。**\n"
        "  · 关 0 与关 1 一帧都没有它。所以它是从第 2 关起才有的家具，不是「工位正向就会长出来」的通则；"
        "「正向 ⟹ 在场」那一半仍在另一条 secondcup_at_level2_cardinals 上，那条的关卡守卫现在明显偏窄，"
        "但改它要另立一条，不在本条的职责里。\n"
        "  · 腔恒 **12 格**，形状随工位方向转：南 / 北 是 3 行 x 4 列，东 / 西 是 4 行 x 3 列"
        "（9 个 (关卡, 正向) 组合全部如此）。这一条 v1 里写成了固定的 3 行 x 4 列——"
        "那时只见过南，**是个错的概括，这里改正**；它没写进代码，所以没有反例，但也没有借口。\n"
        "**排除过一个更平淡的解释**：斜向工位上看不见它，会不会只是它的描边斜着挨上了大杯、"
        "被 diag=True 的连通块整块算进 cup_ink？用不依赖连通块的口径对照过（整幅画的色 2 总格数），"
        "正向比斜向恰好多出它那 14 格描边，而斜向的总数与前两关（那时根本没有这只杯）一模一样。"
        "它是真的不在，不是被吞并。\n"
        "**考虑过但没改的**：ctx 缺失时现在会继续往下判，严格说该返回 NA（没有 ctx 就分不出换没换关）。"
        "没改的理由是这是逻辑改动而不是文字改动，而语料里 ctx 从没缺过——"
        "没有反例逼着改代码时不改代码，否则这条的 N 会因为一次臆想的边界而缩水。\n"
        "v1，前身 spout_south_only v1 已撤册。")
EVIDENCE = ["56f8d3912a81bbdd",      # 第263步换关：它第一次出现在南（换关本身在 scope 外）
            "2db97ff8825eee4a",      # 第266步 A3 转出南：28 格整块变背景
            "13fe0dfbaa54fe3f",      # 第268步 A4 转回南：原地重现，逐格与消失前相同
            "8c092e00e3e3029e",      # 第339步 A2 东南->东：它在东也在，打死了「只在南」
            "39df052929b18f92"]      # 第340步 在东倾倒：它仍在场，与倾倒无关

from _lib import STAGE_BG, key_dir, open_dir, spout, turn


def _cardinal(d):
    """东(0) / 北(2) / 西(4) / 南(6) 是正向；下标为奇的四个是斜向。"""
    return d is not None and d % 2 == 0


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    sp, sn = spout(prev), spout(nxt)
    if not sp and not sn:
        return "NA"
    dp, dn = open_dir(prev), open_dir(nxt)
    if dp is None or dn is None:
        return "NA"
    # 一、在场 ⟹ 工位正向（两帧各查一次）。
    if sp and not _cardinal(dp):
        return "FALSE"
    if sn and not _cardinal(dn):
        return "FALSE"
    # 二、同一个工位上它不许挪位置。
    if sp and sn and dp == dn and sp != sn:
        return "FALSE"
    # 三、它消失的那一步，原先占的格必须全变成舞台背景。
    if sp and not sn:
        for (r, c) in sp:
            if nxt[r][c] != STAGE_BG:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    k = key_dir(action)
    if k is None:
        return None
    sp = spout(prev)
    if not sp:
        return None
    d = open_dir(prev)
    if d is None:
        return None
    nd = turn(d, k)
    if nd is None:
        return {q: prev[q[0]][q[1]] for q in sp}        # 空动作：它照旧
    if _cardinal(nd):
        return None                                     # 转到另一个正向：它会转成什么样，本条说不出
    return {q: STAGE_BG for q in sp}                    # 转去斜向：整块变背景
