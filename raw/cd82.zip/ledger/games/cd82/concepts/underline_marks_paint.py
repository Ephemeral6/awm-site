"""横带里那条 1x5 的色0 短线，永远落在「芯色 == 当前颜料色」的那个环的正下方。

也就是：横带上那些 5x5 色4 环是色板（芯色 = 可选的颜料），短线是「当前选中」的下划线，
而杯里液体的颜色就是当前颜料色。这条把两个互不相干的读数（横带里的下划线、舞台上杯里的液色）
绑成一个不变量：每一帧的 prev 和 nxt 都要成立，所以任何动作都在考它。

它被推翻的方式有三种，每种都是新东西：短线跟液色脱钩（那短线指别的意思）、
有环的芯色等于当前颜料色却不止一个（颜料色不足以定位选中项）、
短线的列区间不等于环的列区间（对齐方式另有讲究）。
"""
LEVEL = "L7"
SCOPE = ("所有动作；prev 与 nxt 各查一遍。swatches() 一个环都找不到、underline() 认不出短线、"
         "或 paint_color() 认不出液色时返回 NA。换关返回 NA。"
         "**环的个数不设限**——v1/v2 在这里写死了「恰好两个」，见 NOTE。")
NOTE = ("v3：把守卫里写死的环个数拿掉（`len(sw) != 2` → `not sw`），并据此改写 docstring 的第二条推翻路径。\n"
        "  **这一版修的是一处自我豁免。** v2 的 docstring 亲手预注册了三条推翻路径，第二条原文是"
        "「出现第三个环（颜料不止两种）」——而第 23 行的守卫写着 `len(sw) != 2` 就返回 None。"
        "也就是说：那条推翻路径一旦真的发生，本概念不会判假，它会**弃权**。"
        "预注册一条自己碰不到的反例路径，等于没预注册。\n"
        "  第三个环真的出现了：第 2 关横带上有 7 个环（`runs/<run>/spoutcells.py` 打出 7 个 bbox，"
        "芯色 0/15/12/11/14/8/9），而第 1、2 关那 60 多条转移本概念全程一言不发。\n"
        "  「出现第三个环」既然不再是推翻路径，就得说清它到底该证伪什么。改写后的第二条是"
        "「有环的芯色等于当前颜料色却不止一个」：那时颜料色不足以定位选中项，"
        "下划线指的一定是别的东西。这一条在 7 个环的关里是真能发生的（7 个芯色若有重复），"
        "而在两环的关里天然不会发生——这就是为什么写死「2」会让一条概念看着永远对。\n"
        "  同一个「2」还冻住了 a6_dead_outside_swatches（那条的代价是两条专门挑来打它的靶子白挑了）。\n"
        "v2：LEVEL 从 L0 改成 L7。这是个判断，写明理由：这一局有一个不在舞台上的状态量（当前颜料色），"
        "它在屏幕上有两处观测口（横带里的下划线、杯里的液色），这条概念断言两处读数一致——"
        "也就是「怎么把内部状态从屏幕上读出来」，属观测模型。它不是清点（L0 不占槽），"
        "也不是动作效果（它对每个动作都成立）。")
EVIDENCE = ["e87598919a1f77c3"]

from _lib import swatches, underline, paint_color


def _ok(g):
    """返回 True/False/None（None = 读不出来，交给 assert_ 报 NA）。"""
    sw = swatches(g)
    un = underline(g)
    pc = paint_color(g)
    if not sw or un is None or pc is None:
        return None
    hit = [b for b, core in sw if core == pc]
    if len(hit) != 1:
        return False
    _, _, l, r = hit[0]
    return (un[1], un[2]) == (l, r)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = _ok(prev), _ok(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if (a and b) else "FALSE"
