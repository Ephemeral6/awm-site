"""ACTION1 与 ACTION2 除底行外只改动**杯**所占的格：容器、面板、色板、下划线、舞台背景一格不动。
（「杯」是复数——舞台上不止一只，见下面 v2。）

这是 a1_only_bar 与 a2_noop 的换轴重立。那两条说这两个键是「只动底行」和「整帧空动作」，
错在自变量：它们实为**转档键**，在档 +1 上按会把杯转到第四朝向（描边 30 + 液体 84、bbox 14x9，
就是档 0 的杯转 90 度），一次 200 格。之前 51 次判它们为真，是因为那 51 次没有一次在档 +1 上按 ——
空动作构成不了「这不是个键」的证据。

这一条只说两个键**能碰到什么**，不说它们碰不碰：它们死的时候什么都不动（平凡成立），
活的时候动的恰好全是杯。所以它是一条关于**作用域**的概念，和 a12_flat_dead
（关于**什么时候生效**）分开写：两条会以不同的方式坏 —— 若哪天 A1 在某个档上动了容器，
本条判错而那一条不受影响；若哪天 A1 在档 0 上就动了杯，那一条判错而本条仍然成立。

「杯所占的格」取 prev 的杯与 nxt 的杯的并集：转档时旧位置要擦掉、新位置要画上，两边都算。
判错点：底行 63 以外有任何一格变了，而它既不在 prev 的杯里、也不在 nxt 的杯里。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1 与 ACTION2，其余动作返回 NA。换关返回 NA。"
         "不看底行 63（那是预算钟，归 bar_rule / bar_prefix_shrink）。"
         "prev 或 nxt 的杯认不出（描边与液体都空）时返回 NA。"
         "注意它对「杯变成什么样」一个字不说 —— 那是 rot_apply 与第四朝向的事，本条只划作用域。")
NOTE = ("v1。前身 a1_only_bar（v1, N=28）与 a2_noop（v2, N=23）已撤册，死因在 journal。\n"
        "**声明我看过什么**：写这条之前我把全语料里 ACTION1/ACTION2 的全部 63 次按键"
        "逐次算过帧差并按区域拆过（runs/<run>/a12_live.py、dissect.py），"
        "所以这 63 条转移对本概念不是考卷 —— **第一次结算给出的分不是独立检验，不许引用。**"
        "S 从这条概念写下之后新产生的 ACTION1/ACTION2 转移起算。\n"
        "拆分读数（分母 63 次按键）：活 4 次、死 59 次；4 次活的帧差按区域拆开是"
        "「杯 200 格 + 底行 0 或 1 格」，别的区域一格没动，「其他」那一栏是 0 格。\n"
        "v2：**被推翻过一次，是口径太窄，不是主张错了。** 反例 8c092e00e3e3029e（第 339 步 ACTION2）"
        "上，转档同时把第二只杯也搬走了，而 v1 的「杯」只认 `ink()|liquid()`——第二只杯"
        "**肚里**那些格两边都不算，于是被记成「杯以外的格变了」，14 格。"
        "口径改成 `ink|liquid|cup_liquid|spout`（实测 runs/<run>/a12_allowed.py：全语料 17 条非空"
        "ACTION1/ACTION2 转移，口径外的格数 v1 口径 14 格、新口径 0 格；口径本身只从 228 格涨到 242 格，"
        "**与容器的交集 0 格**——它没有大到把容器圈进来自动为真）。"
        "放宽口径本来就是「打不过就改判据」的高危动作，所以这条读数必须留在这里：涨的是 14 格，"
        "而这 14 格正是第二只杯的肚子。主张的字面也跟着改了——「杯」现在是复数。")
EVIDENCE = ["62fdb3f4702a4526", "08591fec75af0244",
            "8c092e00e3e3029e"]        # 第339步 A2：转档也搬走了第二只杯，推翻 v1 的窄口径

from _lib import BAR_ROW, cup_liquid, ink, liquid, spout

KEYS = ("ACTION1", "ACTION2")


def _cup(g):
    """舞台上**所有**杯所占的格：描边（含第二只杯的）+ 大杯液体 + 各杯里等于当前颜料色的格。"""
    return (set(ink(g) or ()) | set(liquid(g) or ())
            | set(cup_liquid(g) or ()) | set(spout(g) or ()))


def assert_(prev, action, nxt, ctx=None):
    if action.strip().upper() not in KEYS:
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cp, cn = _cup(prev), _cup(nxt)
    if not cp or not cn:
        return "NA"
    allowed = cp | cn
    for r in range(len(prev)):
        if r == BAR_ROW:
            continue
        if prev[r] == nxt[r]:
            continue
        for c in range(len(prev[r])):
            if prev[r][c] != nxt[r][c] and (r, c) not in allowed:
                return "FALSE"
    return "TRUE"
