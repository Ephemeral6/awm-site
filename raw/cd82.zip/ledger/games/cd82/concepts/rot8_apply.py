"""四个键（A1..A4）在全部 8 个工位上的通用旋转：把 rot_apply v2 的两个拟合枢轴换成
「一个拟合偏移 + 从帧上读到的容器中心」，因此扩大到全部四个键、全部 8 个工位。

沿用 v2 整套「开口矩形」机械（_fit 反解 / _shape 重画 / _edge 阶梯 / _line 数字线 / _corners 四角），
一字不改地照抄；本概念只换了三件事：

1. 作用域从 ACTION3/4 扩到 ACTION1..4：键往方向表 `_lib.KEY_DIR` 一查，动没动、往哪转，
   由 `_lib.turn(open_dir(prev), key_dir(action))` 给出（18 格全对上的判据，见 `_lib.turn` 注释）。
   `turn` 返回 None 时是这一姿势上这个键的空动作：rows 0..62 逐格照抄 prev，不碰 `_fit` / `_shape`。
2. 姿势的名字从 v2 的三档 `tilt()`（只认南/东南/西南）换成 8 向 `open_dir()`；
   两个相邻姿势之间的转移挂在**边**上——8 个工位排成一圈，恰好 8 条边，边 e 连接姿势 e 与 (e+1)%8。
3. 每条边一个枢轴，枢轴 = hub(prev)（容器 bbox 中心，帧上读，非常数）+ 一个固定偏移。
   两个已知偏移是 v2 的拟合常数相对 hub=(38.5,31.5) 的差：
     边6（南<->东南）P=(40,28)   -> 偏移 (1.5,-3.5)
     边5（西南<->南）P=(40,35)   -> 偏移 (1.5, 3.5)
   这两条边正好相邻（共享姿势 6），偏移互为「列取反」，与 v2 NOTE 里「两枢轴互为左右镜像」一致。
   本概念要验的假设：**相隔两步（90 度）的两条边互为绕 hub 的 90 度旋转**——把这两个偏移向量
   反复做纯几何 90 度旋转（不取整、不查表；旋转方向取 `_lib.rot90(ccw=True)` 的方向，
   即 (dr,dc) -> (-dc,dr)，与 _lib.rot90 的公式在实数域上完全一致），各转 4 次回到自身，
   分两条链盖满 8 条边：
     链A（偶数边，从边6出发）：边6 (1.5,-3.5) -> 边0 (3.5,1.5) -> 边2 (-1.5,3.5) -> 边4 (-3.5,-1.5) -> 回到边6
     链B（奇数边，从边5出发）：边5 (1.5,3.5) -> 边7 (-3.5,1.5) -> 边1 (-1.5,-3.5) -> 边3 (3.5,-1.5) -> 回到边5
   两条链各自闭合（第 4 次旋转精确落回种子值），是这个假设内部自洽的一个必要条件，但**不是**它为真的证据——
   真正的证据只能来自边 0/1/7（连接两个都被观测过的姿势：东/东北/北/东南）上的真实转移，
   边 2/3/4 涉及从没按出过的姿势（西、西北），在全语料里没有任何一条转移能检验，
   generated 出来的偏移对它们而言是**没走过的外推**，不是已验证的读数。

   旋转方向（ccw=True 对应边号 +2，而不是 -2）验证方式：给定 (dr,dc)=(1,0)（南，DIR_VEC[6]），
   按 _lib.rot90 的 ccw 公式变换得 (dr',dc')=(0,1)，其 dir8 是 0（东，DIR_VEC[0]），
   而边6(南-东南)按 +2 走到边0(东-东北)——与链A的步进方向一致；此为纯代数验证，不依赖任何一帧。

   旋转符号（rot45 的 +1/-1）沿用 v2 的约定并做了推广：v2 里 ACTION3（+1）对应姿势数字变大
   （南=0 -> 东南=+1），ACTION4（-1）对应变小（南=0 -> 西南=-1）；本概念把它写成
   「nd = (d+1) mod 8 时 sign=+1，边号取 e=d；nd = (d-1) mod 8 时 sign=-1，边号取 e=nd」，
   代入 v2 的两条已知转移（南->东南、南->西南）算出的 e 与 sign 与 v2 硬编码的完全一致（e=6/sign+1、
   e=5/sign-1），这是把 v2 收进本概念当特例的判据，不是新假设。

反解 / 重画 / 液色三件事与 v2 完全相同（见 `ledger/games/cd82/concepts/rot_apply.py` 的同名函数），
本文件直接 import 复用，不重写一行。
"""
LEVEL = "L1"
SCOPE = ("只看四个键 A1..A4（`_lib.key_dir(action)` 认得出的动作），其余动作返回 NA。"
         "只管 rows STAGE_R0..STAGE_R1，底行计数条不管，换关返回 NA。"
         "open_dir(prev) 认不出（描边或液体缺失）时返回 NA。"
         "turn(d,k) 是 None（这个键在这个姿势上该是空动作）时预测 = 原样照抄 prev，"
         "不依赖 hub / _fit，也不检查液色。"
         "turn(d,k) 有值时**只声明三组格**：杯的新描边、杯的新液体、以及杯原来占着而现在腾出来的格；"
         "舞台上其余的格一概不表态——那些格归别的概念管。"
         "hub(prev) 认不出、开口矩形反解不出（照参数重画 != 原帧）、"
         "液色认不出（paint_color 为 None）、或重画结果跑出舞台行区间，一律返回 NA / None。")
NOTE = ("v2：反例 13fe0dfbaa54fe3f（第 2 关，从开口东南转回开口南）。它推翻的不是旋转本身，"
        "而是 v1 顺手带着的一句过头话——v1 的 apply 给**整个舞台**每一格都出预测，"
        "杯之外的格全预测「照抄 prev」，等于替所有别的物件担保「这一步它们不动」。"
        "新关舞台上有第二只小杯，它在大杯转回开口南的那一帧出现了 28 格，v1 就此判 FALSE。"
        "同一批里从开口南转出去的两步（2db97ff8825eee4a / 3097c1da02ab0e32）v1 没挨打，"
        "但那是因为它在那两帧上**弃权**了：`_fit` 取的是整块 `ink()`，把小杯的描边一起算进 bbox，"
        "反解自然失败，于是 NA。一条概念在新关里既有假反例又有集体弃权，根因往往在词汇口径，不在主张。\n"
        "v2 做两件事，都不是缩到反例外面：\n"
        "  一、词汇 `_fit` 从 `ink()` 换成 `cup_ink()`（只取贴着大杯液体的那些描边连通块），"
        "于是有小杯的那些帧上反解成功、旋转概念**从弃权变成表态**——覆盖变大了，不是变小；"
        "行为保持已实测（runs/<run>/fitcheck.py：213 个去重帧里旧语料 206 帧 ink == cup_ink 逐格相等，"
        "只在第 2 关那 4 帧开口南上差 14 格，而那 14 格正好是小杯的描边）。\n"
        "  二、apply 只声明杯的新落点与它腾出来的格。\n"
        "  **v2 入册时我在这里写过一句「这一句收回不损失规则图完成度：E 只数帧差格，而『照抄 prev』"
        "这种预测在帧差格上只会是错的，从来不会是对的」——那句话是错的，改版当天就被实测打脸。**"
        "错在哪：v1 的整舞台预测并不全是「照抄 prev」，杯之外的格里有一部分预测的是 STAGE_BG，"
        "那是一个真的颜色变化，落在帧差格上**可以是对的**。它在小杯消失的那两步上就恰好蒙对了"
        "——蒙对的理由并不存在，v1 对小杯一无所知。\n"
        "  实测（`runs/cd82-0905-1311/eblame.py` / `eblame2.py`，同一批 272 条转移、帧差格总数 21779 恒定）："
        "把本概念单独换回 v1（代码与 EVIDENCE 一起换），E 从 15958/21779=0.733 变成 16168/21779=0.742，"
        "即 v2 这一版的账是 **-210 格**。拆开看：其中 200 格是新反例 tid 13fe0dfbaa54fe3f 进 EVIDENCE 之后"
        "本概念在那一步依规矩闭嘴（settle 的 apply 也走 held-out），是修反例的定价，不是收窄的代价；"
        "另外约 10 格 ×2（第 266、269 步）才是收窄真正丢掉的，正是上面说的「蒙对的 STAGE_BG」，"
        "而它们已被新概念 spout_south_only 以正当理由收回 28 格（eblame2：把它撤出册子 E 掉 28 格）。\n"
        "  那条推理本身没有错，只是我把适用范围说大了：它只对「整块照抄 prev」型的主张成立。"
        "同一批的 panel_static v4→v5 把区域从「rows 0..18 全宽」收成「舞台的补集」，"
        "单独换回旧版 E **一格不差（±0 格）**——那才是这条推理的干净证据。\n"

        "教训（已进方法册草稿）：一条 apply 把整块画布填满，看着像信息量大，实际是在替别人担保；"
        "画布上新长出任何一个东西，它就先挨打，而它对那个东西一无所知。\n"
        "以下 v1 的读数一律仍然成立（v2 未改旋转机械一行）：\n"
        "被推广、不是被推翻的：v2 的整套开口矩形反解 / 重画（_fit/_shape/_edge/_line/_corners）原样复用，"
        "一格没改；v2 的两个拟合枢轴被证明是「hub + 固定偏移」的两个特例（南<->东南、西南<->南），"
        "算法层面用同一套公式把它们收作 e=6/e=5 两条边。"
        "被推翻的：v2 NOTE 里「枢轴是拟合常数，物件换位置或换关就可能立刻失效」这句话所暗示的"
        "「枢轴与容器位置无关」——现在枢轴显式绑定 hub(prev)，容器换位置时枢轴跟着走，"
        "这是 v2 完全没有的预测能力，但**这条预测能力本身没有语料可验**（全语料 244 帧容器 bbox 恒定，"
        "见 ORBIT.md 第2节），只能验「同一容器位置下扩到 8 条边、4 个键」这一半。"
        ""
        "实测（`runs/cd82-0905-1311/rot8_check.py`，全语料 243 条转移 / 243 去重，本局这批无重复 tid）："
        "assert_ 在 243 条里给 TRUE 133、FALSE 0、NA 110（110 条 NA 全部是「不是 A1..A4」，"
        "没有一条落在 open_dir 认不出 / 换关 / 反解失败这几个分支——open_dir_none=0, level_change=0, "
        "other_apply_none=0）。133 条 TRUE 里 74 条是空动作（noop）、59 条是真转动。"
        "逐格命中（只数帧差格，口径同 v2）：74 条空动作帧差格数 0/0（这组转移本来就该整帧不变，"
        "验证了「turn 返回 None 就该零像素变化」这半句）；59 条转动合计帧差 11800 格，说对 11800 格（100%）。"
        "上一批 4 条「201 格全未解释」的转移（`08591fec75af0244` 第218步、`445521e5c83c9789` 第221步、"
        "`39770846c644b490` 第229步、`cef2f65cd9e2cf8f` 第235步）：本概念作用域内的帧差各 200 格"
        "（201 格里那多出的 1 格是底行计数条，本概念 SCOPE 明确不管，200+1=201 对得上），4 条现在各"
        "200/200 全对。这 4 条全部落在边7（东南<->东，3 条）与边0（东<->东北，1 条）——"
        "正是 v2 完全没碰过的两条边，是这次推广的全部意义所在。"
        "8 条边按真实转移检验的覆盖：边0（东<->东北）5 条全 TRUE；边1（东北<->北）1 条 TRUE；"
        "边5（西南<->南）21 条全 TRUE（v2 已验证过的那条边，本概念重新核了一遍）；"
        "边6（南<->东南）27 条全 TRUE（同上）；边7（东南<->东）5 条全 TRUE；"
        "边2（北<->西北）、边3（西北<->西）、边4（西<->西南）在写下上面那批读数时**没走过**——"
        "当时全语料里没有一条转移的开口落在姿势「西」或「西北」上，所以那三条边的枢轴是纯几何外推"
        "（绕 hub 转 90 度算出来的），我当时写「一次都没被真实转移检验过，不能算数」。\n"
        "        **这句话已经过期，而且是往好的方向过期的。** 后来第 246~251 步（第 0 关）与第 259~260 步"
        "（第 1 关）真把杯转了进去：北→西北→西→西南→西→西北→北 整条走通。实测"
        "（`runs/cd82-0905-1311/edgecheck.py`）：8 条转移 assert_ 全 TRUE，合计帧差 1605 格说对 1600 格"
        "（每条各 200/200，差的 5 格是底行计数条，本概念 SCOPE 明确不管）；"
        "边2 两条（881bf35ca47bdda6、20a8c7ca223d1e55）、边3 三条（cac7a3342eca9b71、4b29491b42598cc2、"
        "847d7f4345e9fcd0）、边4 三条（125b7812afd66f6c、bf01edbf8ca73044、bf1280ea2175fa3d）。"
        "**这 8 条一条都不在 EVIDENCE 里**，是入册之后在没见过的转移上挣到的——"
        "写进 EVIDENCE 等于把挣到的分退回去。至此 8 条边全部有真实转移支持，"
        "「相隔两步的两条边互为绕 hub 的 90 度旋转」这个假设是本概念最强的一条预测，也是被验证的那一条："
        "三个枢轴偏移在被观测之前就由纯几何算定，观测来了一格没差。"
        ""
        "最弱的一环因此从「两个拟合常数」变成「三条边（2/3/4）的枢轴完全没有观测支持」——"
        "**这一环后来被检验了，而且过了**（见上：8 条转移 1600/1605 格）。现在最弱的一环换成了"
        "hub(prev) 绑定容器位置这件事：全语料 244 帧容器 bbox 恒定，v2 的「枢轴是常数」和本概念的"
        "「枢轴是 hub+偏移」在已观测数据上逐条等价，样本里没有一条转移能把两者分开——"
        "这句话本身仍然没被检验过，要等一个容器换位置的关。"
        ""
        "入册时由我（玩家）补两句。其一，**这条是在全语料上离线验过才入册的**："
        "上面那些读数全部来自已有的 243 条转移，所以它在入册**之前**的转移上一分都不算独立检验，"
        "S 只从入册之后产生的新转移开始挣。其二，入册时它原来 `from rot_apply import` 那套重画机械，"
        "**结算直接报 ModuleNotFoundError 关了闸**——概念之间不能互相 import，只有 _lib 与 geo 在路径上。"
        "机械已经原样搬进 `_lib.py`，两条概念都从词汇表取；rot_apply 同步改版（只搬家不改行为）。"
        "rot_apply 没有被推翻，它是这条概念在边5/边6 上的特例，"
        "它那两个「拟合常数」(40,28)/(40,35) 现在被证明就是 hub(38.5,31.5) 加边偏移 (1.5,∓3.5)。"
        "**拟合出来的常数先去画面上找它**——这一局两次都找到了（枢轴、轨道中心）。")
EVIDENCE = [
    "79ecfde154582b91", "3c29bf6fbe446e56", "0b2656c6128bff24", "bd63aa0bf379ec18",  # v2 原 4 条（边6/边5）
    "08591fec75af0244", "445521e5c83c9789", "39770846c644b490",                      # 边7，上一批未解释
    "cef2f65cd9e2cf8f",                                                              # 边0，上一批未解释
    "e3d8aeb44d09af54",                                                              # 边1（全语料里边1唯一一条）
    "13fe0dfbaa54fe3f",                                                              # v2 反例：转回开口南，小杯出现 28 格
]

import math
from collections import deque

from _lib import (INK, STAGE_BG, STAGE_R0, STAGE_R1, _EPS, _S, _corners, _edge,
                  _fit, _line, _shape, _snap8, bbox, cup_ink, hub, key_dir,
                  liquid, open_dir, paint_color, turn)

_EDGE_SEED = {6: (1.5, -3.5), 5: (1.5, 3.5)}


def _rot90_vec(v):
    """v 绕原点转 90 度（纯几何、不取整），方向与 _lib.rot90(ccw=True) 在实数域上一致：
    (dr,dc) -> (-dc,dr)。代数验证见本文件顶部 NOTE。"""
    dr, dc = v
    return (-dc, dr)


def _build_edge_offset():
    out = {}
    for seed_e, seed_v in _EDGE_SEED.items():
        v, e = seed_v, seed_e
        for _ in range(4):
            out[e] = v
            v = _rot90_vec(v)
            e = (e + 2) % 8
    return out


EDGE_OFFSET = _build_edge_offset()   # 边号 0..7 -> (相对 hub 的行偏移, 列偏移)


def _rot45(u, d):
    """d=+1: (dr,dc) -> (s(dr-dc), s(dr+dc))；d=-1 是它的逆。与 rot_apply.py 同名函数完全相同。"""
    if d > 0:
        return (_S * (u[0] - u[1]), _S * (u[0] + u[1]))
    return (_S * (u[0] + u[1]), _S * (u[1] - u[0]))


def _edge_and_sign(d, nd):
    """姿势 d -> nd（相邻，差 1 mod 8）落在哪条边、旋转符号是什么。管不了返回 (None, None)。"""
    if (nd - d) % 8 == 1:
        return d, 1
    if (d - nd) % 8 == 1:
        return nd, -1
    return None, None


def _copy_prev(prev):
    out = {}
    for r in range(STAGE_R0, STAGE_R1 + 1):
        for c in range(len(prev[r])):
            out[(r, c)] = prev[r][c]
    return out


def _turned(prev, action):
    """返回 ('noop', None) / ('turn', (描边格集, 液体格集)) / (None, None)（管不了）。"""
    k = key_dir(action)
    if k is None:
        return None, None
    d = open_dir(prev)
    if d is None:
        return None, None
    nd = turn(d, k)
    if nd is None:
        return "noop", None
    e, sign = _edge_and_sign(d, nd)
    if e is None:
        return None, None            # turn() 保证相邻，理论上不会走到这
    h = hub(prev)
    if h is None:
        return None, None
    f = _fit(prev)
    if f is None:
        return None, None
    O, u, hl, hs, osign = f
    off = EDGE_OFFSET[e]
    P = (h[0] + off[0], h[1] + off[1])
    dv = _rot45((O[0] - P[0], O[1] - P[1]), sign)
    s = _shape((P[0] + dv[0], P[1] + dv[1]), _snap8(_rot45(u, sign)), hl, hs, osign)
    if s is None:
        return None, None
    for p in s[0] | s[1]:
        if not (STAGE_R0 <= p[0] <= STAGE_R1):
            return None, None        # 转出舞台了，没见过，不管
    return "turn", s


def apply(prev, action, ctx=None):
    if key_dir(action) is None:
        return None
    kind, s = _turned(prev, action)
    if kind is None:
        return None
    if kind == "noop":
        return _copy_prev(prev)
    ed, lq = s
    pc = paint_color(prev)
    if pc is None:
        return None
    old = cup_ink(prev) | liquid(prev)          # 大杯原来占的格；第二只杯不在其中
    out = {}
    for q in ed | lq | old:                     # **只声明杯的新落点与它腾出来的格**
        r, c = q
        if not (STAGE_R0 <= r <= STAGE_R1):
            continue
        if q in ed:
            out[q] = INK
        elif q in lq:
            out[q] = pc
        else:
            out[q] = STAGE_BG
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    pred = apply(prev, action, ctx)
    if pred is None:
        return "NA"
    for (r, c), v in pred.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"
