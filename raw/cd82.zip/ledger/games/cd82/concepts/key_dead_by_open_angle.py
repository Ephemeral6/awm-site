"""一个键动不动得了，只由**开口方向与键方向的夹角**决定：夹角 0/135/180 度 → 除底行外整帧一格不变；夹角 45/90 度 → 杯必动。

这是一条双条件，两边都能判错，所以它比「某几个键是死键」强得多。

它替换掉的是 tilt_end_blocks（「阶梯到头那一按是空动作」）和 a12_flat_dead（「A1/A2 在档 0 与档 -1 上一律空动作」）。
那两条在语料上都是对的，但都错在**定义域是按位置枚举出来的**：轨道没有「头」，A1/A2 也不是死键——
它们只是在语料走过的那段弧上恰好被挡。51 次 A1/A2 按压全落在那段弧里，这就是取样偏差长的样子：
一条概念的 S 很高，只因为世界还没带它去它会垮的地方。

按这条，a12_flat_dead 有一格是**错的**：开口西南（旧称档 -1）按 A2（下），夹角 45 度，这条说**动**，
新开口是西——一个还没见过的姿势。那一格从来没按过。下一批就按它，谁对谁错当场见分晓。

判错的方式：说死的那一步除底行外有任何一格变了；或说动的那一步杯一格没挪。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1..ACTION4；换关返回 NA；开口方向认不出返回 NA。"
         "不看底行（BAR_ROW）：那是计数条，每一步都在变，与挡不挡无关。"
         "说「动」的那一侧只要求杯的格集变了（obj 变），不要求变成哪样——变成哪样是 orbit_turn_rule 说的。")
NOTE = ("v1。**先声明验过什么**：判据是在全语料上离线定出来的（runs/<run>/lib_check.py 逐条比对了 "
        "133 条 A1..A4 转移：说动且动对 59 条、说死且没动 74 条、对不上 0 条）。"
        "所以它在**声明之前**的转移上不算独立检验，S 只从声明之后的新转移开始挣。\n"
        "apply 只在「说死」那一侧开口：整帧 rows 0..BAR_ROW-1 原样复制。"
        "这是从 a12_flat_dead 继承下来的覆盖面——空动作占了 A1..A4 的一多半，"
        "不生成它，规则图完成度 E 会白掉一大块。说活的那一侧不生成：那是 rot 系概念的活。")
EVIDENCE = ["e3d8aeb44d09af54",      # 「阶梯到头」在这一步被推翻
            "f9c81dff6fd84905",      # A1/A2 被当成死键的那两步
            "cef2f65cd9e2cf8f",
            "92bbb5725a3f2566"]

from _lib import BAR_ROW, key_dir, obj, open_dir, turn


def _dead(prev, action):
    """这一步按判据是不是空动作；判不了返回 None。"""
    k = key_dir(action)
    if k is None:
        return None
    d = open_dir(prev)
    if d is None:
        return None
    return turn(d, k) is None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dead = _dead(prev, action)
    if dead is None:
        return "NA"
    if dead:
        same = all(prev[r] == nxt[r] for r in range(len(prev)) if r != BAR_ROW)
        return "TRUE" if same else "FALSE"
    return "TRUE" if obj(prev) != obj(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    if _dead(prev, action) is not True:
        return None
    return {(r, c): prev[r][c]
            for r in range(len(prev)) if r != BAR_ROW
            for c in range(len(prev[r]))}
