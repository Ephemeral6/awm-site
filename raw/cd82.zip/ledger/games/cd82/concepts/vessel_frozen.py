"""容器是一件不动的家具：它的 bbox 在任何动作下前后一致，而且 bbox 里没有一格背景——
容器永远是实心的一片颜料，动作只换里面的颜色，不改它的形状、位置、大小。

「容器」= 舞台里那个不贴杯描边的最大颜料块的 bbox（见 _lib.vessel）。
取代 zero_block_static：那条按「色0 格集合不变」写，颜料色一变成变量就被 ACTION6 连坐推翻，
而它真正想说的是这件事——容器是靶子，不是可动件。
被推翻的方式：容器会挪/会变大（那它是可动件，归 L1/L6）、或者出现背景格（那涂色会「漏」，归 L1）。
"""
LEVEL = "L1"
SCOPE = "所有动作；vessel() 在 prev 或 nxt 上认不出（返回 None）时返回 NA。换关返回 NA。"
NOTE = ("v2：LEVEL 从 L0 改成 L1（L0 是清点，不占规划器的槽；这条说的是「没有动作能改容器的形状与位置」，属转移函数）。\n"
        "v3：**代码和它自己的 docstring 不是一回事，反例打的是代码。** docstring 写的是「bbox 里没有一格背景」，"
        "代码写的是「每一格都 ∈ PAINTS」——后者严格更强，还多挂了一张写死的两色清单。"
        "第 1 关横带里出现第三个色环（芯色 12），倒进容器的色12 让这条判假（8e9397abad707d76）。"
        "但容器并没有变得不实心、也没有挪动一格：它依旧是一整片颜料，只是那片颜料多了一种颜色。"
        "v3 把断言改回 docstring 说的那件事：容器格里不许出现背景色或描边色。这不需要颜料清单，"
        "和词汇表里 paint_cells 的新读法同源（舞台上非背景非描边即颜料）。\n"
        "**这不是缩 scope 躲反例**：新断言在旧语料上和 v2 逐格等价（第 0 关的颜料只有 0 和 15，"
        "「∈{0,15}」与「∉{背景,描边}」在那些帧上是同一个判据）；它只在第三种颜料出现的帧上分道扬镳，"
        "而那正是 v2 说错话的地方。要真推翻 v3，得让容器挪一格、变一格大小、或者容器里露出背景。")
EVIDENCE = ["79ecfde154582b91", "a215d90877336853", "e87598919a1f77c3",
            "8e9397abad707d76"]      # 色12 倒进容器：v2 判假，v3 判真（容器仍是实心一片颜料）

from _lib import INK, STAGE_BG, vessel


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = vessel(prev), vessel(nxt)
    if a is None or b is None:
        return "NA"
    if a != b:
        return "FALSE"
    t, bo, l, r = b
    for rr in range(t, bo + 1):
        for cc in range(l, r + 1):
            if nxt[rr][cc] in (STAGE_BG, INK):
                return "FALSE"
    return "TRUE"
