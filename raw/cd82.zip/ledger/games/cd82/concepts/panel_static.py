"""屏幕上部（rows 0..18 的面板与横带）只有下划线那一行会动；别的格在任何动作下逐格不变。

那一带里有：左上一个 18x18 面板（色4 折角 + 内部上下两半的色0/色15 矩形，看着像目标图），
右侧一条色3 背景带（内嵌两个 5x5 色4 环，芯分别是色0 与色15，另有一条 1x5 的色0 短线 = 下划线）。
v1 断言「任何动作下不变」，被 ACTION6 推翻：点在环芯上时那条色0 短线搬到了被点的环下方。
v2 把 ACTION6 排除出 scope。v4 又被 RESET 推翻，于是换了个更强也更窄的说法：
**动得了这一带的只有下划线那一行**，而下划线是「当前选中的颜料」这个状态的显示器，
所以凡是能改颜料的动作（ACTION6 点环、RESET）都能动它，别的动作一格都动不了。
这比 v2 的「把会动的动作一个个排除」信息量大：它不再需要我逐个动作去猜，
而是断言整条带子上除了那一行没有任何可变的东西。左上那个 18x18 面板归 target_panel_static 管。

判错点：面板或横带里**下划线那一行以外**有任何一格变了；或者下划线那一行里出现了
不属于「色0 短线搬家」的变化（比如环本身变色、带背景变色）——后者本概念不查，
它只查行号，所以那种变化会被它漏掉，这是它的已知盲区，记在 NOTE 里。
"""
LEVEL = "L1"
SCOPE = ("所有动作。只看**舞台之外**的格子：`not _in_stage(r, c)` 的那些格，也就是"
         "左边 行0..PANEL_R1 x 列0..BAND_C0-1 的面板，加右边 行0..STAGE_R0_BAND-1 x 列BAND_C0..63 的横带。"
         "**跳过 underline(prev) 与 underline(nxt) 所在的那一行（或两行）**——"
         "那一行归 underline_marks_paint / a6_swatch_sets_paint / reset_sets_state 管。"
         "underline() 在 prev 或 nxt 上认不出（返回 None）时返回 NA：认不出就不知道该跳哪一行，宁可不表态。"
         "换关（level_prev != level_next）返回 NA，因为新关的面板可能重画。")
NOTE = ("v6：不是被反例逼的，是自查出来的**地界不一致**：assert_ 换关返回 NA，apply 却照出预测。"
        "settle 打分时喂给 apply 的是真 ctx，于是它在自己声明不表态的局面上照样被算 P——"
        "而它只会说「照旧」，换关时面板重画，那些格必错。这类错法只有 P 看得见，"
        "S/C/N 和反例一概看不见：**生成的那一面敢说的话比检查的那一面敢挨的打多**，就是越权。"
        "改法是让 apply 抄 assert_ 那道 guard，SCOPE 一个字没动（它早就写着换关返回 NA）——"
        "是代码追上 scope，不是 scope 迁就代码。链里 ctx 的 level_next 按「不换关」钉死，"
        "所以规划时这道 guard 永不开火，规划器行为不变。\n"
        "v5：反例三条（2db97ff8825eee4a / 13fe0dfbaa54fe3f / 3097c1da02ab0e32，都是转杯），"
        "全是同一个根因——**这条概念的地盘划错了**。它按「行号 <= PANEL_R1」划，"
        "等于假设屏幕上部是一条水平横带；实际上上部是**两块**：左边的面板高到行 18，"
        "右边的横带只高到行 8，中间 行9..18 x 列18..63 是空着的舞台。"
        "新关有一只小杯的顶边正落在 行18 x 列30..33 —— 舞台里的东西，被这条概念圈进了「面板」，"
        "于是它一动，这条概念就判 FALSE。\n"
        "v5 的修法不是把行 18 挖掉（那是按反例修补），而是把地盘改成**舞台的补集**，"
        "直接引用词汇里的 `_in_stage`：舞台边界怎么量的，这条概念就跟着走。"
        "代价是 行9..18 x 列18..63 这块（实测两关 531 帧全空）不再被本概念声明——它现在没人管，"
        "但没人管的空白比划错的地盘诚实。\n"
        "v4：反例 ca2058f1668862f2（RESET 把 row 7 的色0 短线从 cols 35-39 搬到 cols 41-45，颜料随之 0→15）。"
        "v2 的修法是把会动的动作逐个排除出 scope，那条路要求我事先知道有哪些动作能改颜料——"
        "而我恰恰不知道（RESET 能改这件事就是这次才发现的，之前唯一那次 RESET 是幂等的，没露出来）。"
        "所以 v4 换成按**行**排除而不是按**动作**排除：不管谁改的颜料，动的都只有那一行。"
        "这样它对「还有第三个能改颜料的动作」这种情况仍然成立，不需要再改一版。\n"
        "已知盲区：跳过整行意味着这一行里任何别的变化（环变色、带背景变色）本概念都看不见。"
        "换行号排除换来的稳，代价就是这块盲区，不假装没有。\n"
        "v3：LEVEL 从 L0 改成 L1。L0 是清点，不占规划器的槽，标 L0 等于这条概念在地图上不存在；"
        "它说的其实是「动作对这一带没有效果」，属转移函数。"
        "v2：反例 e87598919a1f77c3（ACTION6:37,4 把 row 7 的色0 短线从 cols 41-45 搬到 cols 35-39）。")
EVIDENCE = ["79ecfde154582b91", "e87598919a1f77c3", "ca2058f1668862f2",
            "2db97ff8825eee4a", "13fe0dfbaa54fe3f", "3097c1da02ab0e32"]

from _lib import PANEL_R1, _in_stage, underline


def _cells(prev, skip):
    """本概念声明的格子：舞台之外、且不在要跳过的行里。"""
    for r in range(0, PANEL_R1 + 1):
        if r in skip:
            continue
        for c in range(len(prev[r])):
            if not _in_stage(r, c):
                yield (r, c)


def _skip_rows(prev, nxt=None):
    """下划线所在的行（prev 与 nxt 各一行，可能不同行）；认不出返回 None。"""
    a = underline(prev)
    if a is None:
        return None
    rows = {a[0]}
    if nxt is not None:
        b = underline(nxt)
        if b is None:
            return None
        rows.add(b[0])
    return rows


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    skip = _skip_rows(prev, nxt)
    if skip is None:
        return "NA"
    for r, c in _cells(prev, skip):
        if prev[r][c] != nxt[r][c]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    # v6：地界必须与 assert_ 一致。assert_ 在换关时返回 NA（新关面板会重画），
    # apply 就不许在换关时出预测——否则它敢说的话比它敢挨的打多。
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    # 生成时看不到 nxt，所以只能跳 prev 那一行；下划线搬走后原行也会变，
    # 因此对可能改颜料的动作（ACTION6 点在环上、RESET）连 prev 那一行的邻域一并不表态。
    skip = _skip_rows(prev)
    if skip is None:
        return None
    if action.startswith("ACTION6") or action.strip().upper() == "RESET":
        return {(r, c): prev[r][c] for r, c in _cells(prev, skip)}
    return {(r, c): prev[r][c] for r, c in _cells(prev, set())}
