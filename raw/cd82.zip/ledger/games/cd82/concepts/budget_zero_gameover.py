"""底行预算条走到 0 格那一步，游戏结束：state 从 NOT_FINISHED 变 GAME_OVER，当且仅当这一步
让底行的色4 前缀长度从正数变成 0。

也就是说底行不是进度表，是**预算**：它按 bar_rule 的闭式随「自最近一次重开以来的步数 k」单调缩短，
k=100 那一步缩到 0，那一步就是终局。整局 132 步里 state 一次没变过，第 149 步（k=100）变了。

配着 bar_rule 一起看，这一关的代价结构就闭合了：任何动作都花掉恰好 1 点预算（死键也花，端点上按不动的
那一按也花），一次重开给你 100 点，用完即死。所以「免费重试」是有条件的——RESET 本身不花预算
（reset_clears_canvas / bar_prefix_shrink），但它给的每一局都只有 100 步。

判错的方式有两个方向，各自都能一次掀翻：
- 正向：某一步把条子缩到 0 而 state 仍是 NOT_FINISHED（那 GAME_OVER 是别的东西触发的，条子只是巧合）；
- 反向：某一步 state 变成 GAME_OVER 而条子当时还有格（那存在第二种死法——掉命、踩到什么、或超时）。
反向这一支在语料里样本极多（下面 NOTE 说了分母），正向只有一次。
"""
LEVEL = "L5"
SCOPE = ("所有动作。ctx 为空、或 ctx 里没有 state_prev / state_next 时返回 NA（这条概念全靠上游给的 state，"
         "不从像素读终局）。只看 state 这一件事，画面变没变一概不管。换关（level_prev != level_next）返回 NA："
         "换关时新关可能把条子补满，那一支没观测过。")
NOTE = ("v1。**两个方向的样本量差得极远，报它的 S 时必须一起报**：\n"
        "反向（条子还有格 → state 不该变）：132 条转移里 131 条属于这一支，全部 state_prev == state_next == "
        "NOT_FINISHED，没有一次提前死。这一支被检验得很足。\n"
        "正向（条子缩到 0 → 必须 GAME_OVER）：**整局只发生过 1 次**，就是取证用的那一条（第 149 步，"
        "tid acde9b15996a17a9）。所以正向这一支的 held-out 样本数是 0——这条概念的 S 无论多高，"
        "都不代表「条子归零必死」被独立检验过，它只代表「没有第二种死法」被检验过。\n"
        "要给正向补考卷，唯一的办法是 RESET 之后再烧 100 步走到 0，成本是 100 个动作；"
        "本局是否再花一次由后面的判断决定，没花就一直是 N=0，不许拿 S 冒充。\n"
        "落空记录（我自己押错的）：第 131 步那批押注里我把清零那一刻的可能性排了序，排第一的是"
        "「什么都不发生，底行只是进度表，代价这个词是我读错了」，排第二的才是 GAME_OVER。实际是第二条。"
        "所以我对这个装置代价语义的理解在那之前是错的，死因见 journal 同一天那一条。")
EVIDENCE = ["acde9b15996a17a9"]      # 第 149 步：条子最后一格 (0,63) 翻掉，state 变 GAME_OVER

from _lib import bar


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    sp, sn = ctx.get("state_prev"), ctx.get("state_next")
    if sp is None or sn is None:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    emptied = bar(prev) > 0 and bar(nxt) == 0
    over = (sn == "GAME_OVER" and sp != "GAME_OVER")
    return "TRUE" if emptied == over else "FALSE"
