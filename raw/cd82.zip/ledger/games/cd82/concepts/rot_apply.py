"""ACTION3/ACTION4 把物件绕定点 (40,28)（或其左右镜像 (40,35)）整体转 45 度，形状照「开口矩形」重画：三条闭边是 4 连通阶梯、液体是被闭边围住的内部再去掉贴着开口那一层。

也就是说：这两个动作不是把格子搬来搬去，而是把一个**连续的刚体**（中心 O、长轴 u、外半长 7、外半宽 4.5、开口朝 v 的哪一侧）
转 45 度以后**重新光栅化**。三件事各自可判错：

1. 形状规则（从帧上反解，不查表）：
   - 四个角格 = round(O ± (半长-0.1)·u ± (半宽-0.1)·v)，往里收 0.1 是为了让「外边界」落回格心；
   - 三条闭边各画成两角格之间的 4 连通阶梯（45 度斜边因此每行两格，轴对齐边每行一格 —— 这解释了
     为什么描边格数在斜档比轴对齐档多出约 √2 倍）；缺角处补的那一格取**离 O 近**的那个；
   - 开口那条长边只留理想数字线（不加补角），它同时是液体的挡板；
   - 液体 = 从 round(O) 起四连通泛洪，撞到「闭边描边 ∪ 开口线」为止。开口线本身不是液体，
     所以物件里总有贴着开口的一层空格。
2. 参数反解：轴对齐档的外半长半宽就是 bbox 半边长；斜档取四个极值格当角，半长半宽在候选里挑
   「可行 O 的面积最大」的那一组。反解完必须**照参数重画等于原帧**，不等就返回 NA / None。
3. 位移：O' = P + R^d(O - P)，R = 45 度旋转，d = +1（ACTION3）/ -1（ACTION4）；
   长轴 u' = R^d(u)，半长半宽与开口侧不变。P 取哪一个由这次动作牵涉的两档决定：
   涉及 +1 档用 (40,28)，涉及 -1 档用它的左右镜像 (40,35)。

判错点最集中的是 P 这两个数：它是拟合出来的两个常数，不是从帧上算出来的。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3 / ACTION4，其余动作返回 NA。只管 rows STAGE_R0..STAGE_R1，底行计数条不管。"
         "**只声明三组格**：物件的新描边、新液体、以及它原来占着而现在腾出来的格；舞台上其余的格不表态。"
         "tilt(prev) 不在 {-1,0,+1} 里、开口矩形反解不出（照参数重画 != 原帧）、"
         "动作后的档位会走出 {-1,0,+1}（端点空动作）、或预测形状会跑出舞台行区间时，一律返回 NA / None。"
         "液色认不出（paint_color 为 None）也返回 NA。换关返回 NA。")
NOTE = ("v5：反例 13fe0dfbaa54fe3f，与 rot8_apply v2 同一条、同一个根因，改法也同一套（详见那边的 NOTE）："
        "apply 从「给整个舞台每一格出预测」收成「只声明物件的新落点与腾出来的格」，"
        "词汇 `_fit` 从 `ink()` 换成 `cup_ink()`。这条概念是 rot8_apply 在边5/边6 上的特例，"
        "它挨的打也是同一种：**替舞台上别的物件担保「这一步它们不动」**，而新关多了一只小杯。"
        "行为保持实测见 runs/<run>/fitcheck.py。\n"
        "v4（只搬家不改行为）与以下 v3 及更早的读数一律仍然成立：\n"
        "量的过程里被推翻的：(a)「单一枢轴 + 45 度反向映射光栅化」——反向映射（把目标格逆旋转回去取源格色）"
        "最好只做到全舞台错 30 格（4 条合计），错的格子成规律的一整条斜线，说明真渲染器画的斜描边比"
        "重采样出来的**更厚**：轴对齐档描边 30 格，斜档 43 格，比值 ≈ √2，是「45 度线要画成 4 连通才没缝」"
        "的厚度，不是重采样能给出的；(b)「一个枢轴管两个方向」——两个斜档互为左右镜像（整张舞台逐格相等），"
        "所以两个方向的枢轴必然互为镜像、不可能是同一个点，早先「两方向拟合出的枢轴不同」是对的，不是拟合没收敛；"
        "(c)「角格逆旋转后取整就能得到新角格」——四个角格给出的枢轴约束区间是空的（差约 0.15 格），"
        "必须换成「中心 + 外半长半宽」这一套连续参数再取整才自洽；(d)「液体格数守恒」——轴对齐档 84 格、"
        "斜档 85 格，不守恒，所以液体只能靠泛洪重算，不能靠搬运。"
        "实测解释率：4 条转移合计 803 格帧差里说对 800 格（帧差全部落在舞台里的 800 格，逐格颜色全中）；"
        "剩下 3 格是底行计数条（3 条转移各 1 格），本概念按 SCOPE 不管它。"
        "样本外（抽它时还没采到的 12 条非空转 ACTION3/4）：2411 格帧差里说对 2400 格、apply 一格没猜错，"
        "11 格未说对全是底行计数条；16 条非空转上 assert_ 全 TRUE，2 条端点空动作返回 NA。"
        "这一段读数由写它的那双眼睛在文件被提拔进 concepts/ 之后量的，它此后只读不写，所以由我代记。"
        "最弱的一环是枢轴的两个数 (40,28)：在 0.25 步长的网格上它是搜索范围内唯一让四条全对的取值，"
        "但它是拟合常数，物件换位置或换关就可能立刻失效——而已观察到的每一次旋转里物件 bbox 都一模一样，"
        "所以「物件换了位置枢轴还成不成立」一次都没被检验过。\n"
        "v3（只改注释与 EVIDENCE，代码一行没动）：反例 92bbb5725a3f2566 的根因**不在这条概念里**，"
        "在词汇。旧 tilt() 按 bbox 形状分档，把一个 17x17 的斜姿势误判成 -1（实测 4 帧）、"
        "把一个 9x14 的扁姿势误判成 0（1 帧），于是这条概念在它本该弃权的地方开了口。"
        "词汇改成按开口方向分档以后，这些帧的 tilt() 老实返回 None，SCOPE 第一句就把它们挡在外面。"
        "**教训记在这里**：一条概念被推翻，先看它挂着的词汇是不是在说谎——词汇里的一个误判，"
        "会让挂在它上面的一批概念同时挨打，而每一条看上去都像是自己错了。"
        "顺带：枢轴 (40,28) 与它的镜像 (40,35)，中点列是 31.5，正好是容器 bbox 的中心列（实测 244 帧恒定）。"
        "也就是说这个「拟合常数」很可能是画面上读得出来的东西——这条线索交给 rot8 系概念去接。")
EVIDENCE = ["79ecfde154582b91", "3c29bf6fbe446e56", "0b2656c6128bff24", "bd63aa0bf379ec18",
            "92bbb5725a3f2566",      # 反例：旧词汇在这一步认错姿势，改词汇后这一步归 NA
            "13fe0dfbaa54fe3f"]      # v5 反例：转回开口南，小杯出现 28 格，而它替小杯担保过「不动」

from _lib import (INK, STAGE_BG, STAGE_R0, STAGE_R1, _fit, _rot45, _shape,
                  _snap8, cup_ink, liquid, paint_color, tilt)

_W = 64                        # 帧宽，用于左右镜像
_PIVOT = (40.0, 28.0)          # 拟合常数：涉及 +1 斜档的那一对用它，涉及 -1 斜档的用它的镜像
_TILTS = (-1, 0, 1)
# _fit / _shape / _rot45 / _snap8 原本定义在本文件里，rot8_apply 也要用同一套，
# 而结算时概念之间不能互相 import，所以它们已经搬进 _lib.py（代码一字未改）。
# 这次改版只搬家、不改行为：预期 S / C / N 与预测格数全部与 v3 相同，不同就是搬错了。


def _dir(action):
    if action.startswith("ACTION3"):
        return 1
    if action.startswith("ACTION4"):
        return -1
    return None


def _turned(prev, action):
    """返回转完以后的 (描边格集, 液体格集)；管不了返回 None。"""
    d = _dir(action)
    if d is None:
        return None
    t = tilt(prev)
    if t not in _TILTS or (t + d) not in _TILTS:
        return None
    f = _fit(prev)
    if f is None:
        return None
    O, u, hl, hs, osign = f
    P = _PIVOT if 1 in (t, t + d) else (_PIVOT[0], _W - 1 - _PIVOT[1])
    dv = _rot45((O[0] - P[0], O[1] - P[1]), d)
    s = _shape((P[0] + dv[0], P[1] + dv[1]), _snap8(_rot45(u, d)), hl, hs, osign)
    if s is None:
        return None
    for p in s[0] | s[1]:
        if not (STAGE_R0 <= p[0] <= STAGE_R1):
            return None            # 转出舞台了，没见过，不管
    return s


def apply(prev, action, ctx=None):
    s = _turned(prev, action)
    if s is None:
        return None
    pc = paint_color(prev)
    if pc is None:
        return None
    ed, lq = s
    old = cup_ink(prev) | liquid(prev)          # 大杯原来占的格；第二只杯不在其中
    out = {}
    for q in ed | lq | old:                     # **只声明杯的新落点与它腾出来的格**
        r, c = q
        if not (STAGE_R0 <= r <= STAGE_R1):
            continue
        if q in ed:
            out[q] = INK
        elif q in lq:
            out[q] = pc
        else:
            out[q] = STAGE_BG
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    pred = apply(prev, action, ctx)
    if pred is None:
        return "NA"
    for (r, c), v in pred.items():
        if nxt[r][c] != v:
            return "FALSE"
    return "TRUE"
