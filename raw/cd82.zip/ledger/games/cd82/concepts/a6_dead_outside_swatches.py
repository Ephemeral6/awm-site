"""ACTION6 点在横带上**任何一个**色板环的 5x5 之外、**且不落在第二只小杯的描边上**的地方
都是死键：rows 0..62 一格不动。

也就是说这一关可点的表面有两种：横带上的色板环（含它们的色4 边框），有几个环就有几个表面；
以及第二只小杯的描边（那一支归 a6_spout_rim_stamps）。
屏幕上其余每一样东西——面板、面板里那张目标图（两半都点过）、面板外侧那圈色4 投影、
横带的色3 底、色板下划线本身、舞台的空白、杯的描边、杯里的液体、容器（涂过的那半和没涂的那半都点过）、
第二只小杯的**内部**（装颜料的腔与色0 的颈都点过）、
底行那条预算条本身——点下去只花 1 点预算（而且不是每次都花），画面一格不动。

这条概念是从「点在舞台里是死键」推广来的：那一版把 scope 限在舞台行区间内，
于是点面板、点横带、点底行的那些转移它一律返回 NA，而那些格子在规则图上没人管。
推广之后它对每一次 ACTION6 都表态，只有落在环里那几次交给 a6_swatch_sets_paint、
落在小杯描边上那几次交给 a6_spout_rim_stamps。

判错的方式：某个环外、小杯描边外的点击改动了 rows 0..62 里的任何一格。那会是这一关的第四种交互表面。
第三种表面已经被这样掀翻过一次（v2 -> v3，见 NOTE）——这条概念写成通则而不是列表就是为了这个。
（附带：其中 7 次死点击是在容器与目标图**逐格镜像全中**的局面上点的，见 NOTE。
所以它同时否掉了「摆好之后点某个表面算交卷」这一族假设，不只是「无条件死键」。）
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6；其余动作返回 NA。坐标解析不出、或 swatches() 一个环都认不出时返回 NA。"
         "点击落在某个环的 5x5 bbox 内时返回 NA（那一支归 a6_swatch_sets_paint）。"
         "**点击落在 spout() 的描边格（色 INK）上时返回 NA**（那一支归 a6_spout_rim_stamps）；"
         "落在 spout 的腔或颈上仍归本条管——那两处实测是死的。"
         "只管 rows 0..62，底行 63 归 bar_rule / bar_prefix_shrink。换关返回 NA。"
         "**环的个数不设限**——v1 在这里写死了「恰好两个」，见 NOTE。")
NOTE = ("v3：让出第二只小杯的**描边**那一支。这是一次真的被推翻，不是收缩措辞。\n"
        "  第 364 步 ACTION6:29,20（tid 27a1f4944f467bf4）点在小杯描边的左壁上，"
        "容器 rows 34..36 x cols 30..33 那 12 格整块变色——v2 判 FALSE，判对了。"
        "这正是 v1/v2 的 docstring 预注册的那条推翻路径：「那会是这一关的第三种交互表面，"
        "比又一条死键证据重要得多」。它兑现了。\n"
        "  **让出的口径有多宽，说清楚**：让出的是 spout 里颜色等于 INK 的那 14 格，"
        "不是整只小杯的 30 格 bbox，也不是它的 28 格。腔的 12 格与颈的 2 格仍归本条，"
        "而那两处正是第 335、336 步实测过的死格——所以这次收缩没有把已有的 TRUE 证据一起让掉，"
        "反而是拿它们当边界：两活两死，分界线就画在色2 与非色2 之间。允许集只涨了 14 格，"
        "而这 14 格里已经有 2 格是实测的活格。\n"
        "v2：把守卫里写死的环个数拿掉（`len(rings) != 2` → `not rings`）。\n"
        "  **这是一次静默弃权，代价是两条专门挑来打它的转移白挑了。** 「横带上只有两个环」是"
        "第 0 关的事实，v1 把它写进了守卫。第 2 关的横带上有 7 个环（`runs/<run>/spoutcells.py`"
        "逐个打出 bbox 与芯色），于是 v1 对第 1、2 关的每一次 A6 点击一律返回 NA。\n"
        "  怎么发现的：第 335、336 步我按预注册去点那个只在开口南出现的壶嘴"
        "（tid 15a27761e3654737 点它内部装颜料的色11 格、83c8ddf741b68389 点它内部空着的色0 格），"
        "两格都在全部 7 个环的 5x5 之外、都逐个核过 bbox，正是冲着「第三种交互表面」来的靶子。"
        "结果舞台一格没动——本该是本概念两条最硬的 TRUE。而结算后 **N 还是 35，一格没涨**"
        "（`runs/<run>/settle_336.txt`），它压根没表态。S 仍 1.000，C 只因分母变大从 0.129 掉到 0.126，"
        "三个数都不会告诉你概念瞎了；露马脚的是「专门去撞它却撞不动」这件事本身。\n"
        "  **补一句 v3 时才看清的**：那两次「撞不动」撞对了地方也撞对了动机，只是撞偏了 1~2 格——"
        "第三种表面就在同一只小杯上，隔着一层描边。找到它的不是记分卡，是 ACTION6 的区域覆盖表"
        "（runs/<run>/a6regions.out）：它把「点过哪些区域」列成表，第 2 关的描边那一格是空的。\n"
        "  同一个「2」还冻住了 underline_marks_paint（那条更刺眼：它的 docstring 自己预注册了"
        "「出现第三个环」这条推翻路径，而守卫把推翻变成了弃权）。两条一起改。\n"
        "  主张没有变弱也没有变强，只是把作用域从「两环的关」扩到「任意环数的关」。"
        "第 1、2 关那些环外点击本来就一次也没改过舞台（`runs/<run>/act316.out` / `act331.out` / "
        "`act334.out` 里每一条 A6 都能看），所以我预期 v2 只是把已经发生的事补进 N；"
        "要是补进去反而出反例，那说明高关的环外点击真有第三种表面，那比多几条 TRUE 值钱得多。\n"
        "v1。取代 a6_stage_click_dead（同一条律的舞台限定版，已撤册）：主张更强——它对每一次环外点击都表态，"
        "旧版只对落在舞台行区间里的点击表态。\n"
        "语料里 ACTION6 共 19 次：6 次落在环里（都改了液色），13 次落在环外（rows 0..62 全都一格不动）。"
        "13 次覆盖 8 种表面，坐标按 ACTION6:x,y = 列,行 记：容器 (36,43)(31,41)(31,36)、杯里液体 (31,30)、"
        "杯的描边 (31,24)、空白舞台 (31,52)、面板里的目标图 (8,8)(8,10)(8,5)、横带的色3 底 (55,4)、"
        "色板下划线本身 (43,7)、底行预算条本身 (31,63)、面板外侧色4 投影 (17,5)。\n"
        "其中第 51~57 步那 7 次（tid 51ee75d7e603ff5c、0ba7e6f0e671fff8、1176be658ec69872、"
        "b96fe6eef129d9eb、56486e768ace680e、6c67c3ce043adf1f、e4eb4f07d9a088ec）是**故意**在"
        "「容器与面板目标图逐格镜像全中」的局面上点的。这一点是方法上的要害："
        "在任意局面上点出来的死键只能否掉「无条件生效」，否不掉「答案对了才响」；"
        "要否掉后者必须先把局面摆到满足条件再点。摆好之后这 7 个表面照样全死，过关仍 0/6。")
EVIDENCE = ["acee82c956d4f66b",      # 点容器（最早发现「环外点击不改画面」的那一次）
            "215077008e5d52ef",      # 点横带的色3 底（另一种表面，定下「不是只有舞台是死的」）
            "27a1f4944f467bf4"]      # 第364步 点小杯描边：v2 在这里被推翻，v3 让出这一支

from _lib import BAR_ROW, INK, spout, swatches


def _click(action):
    """ACTION6:x,y -> (行, 列)；解析不出返回 None。"""
    if ":" not in action:
        return None
    try:
        x, y = action.split(":", 1)[1].split(",")
        return (int(y), int(x))
    except (ValueError, IndexError):
        return None


def _outside(prev, action):
    """点击落在环外、且不在小杯描边上，返回 True；否则 / 认不出返回 None。"""
    p = _click(action)
    if p is None:
        return None
    rings = swatches(prev)
    if not rings:
        return None
    r, c = p
    for (t, b, l, ri), _core in rings:
        if t <= r <= b and l <= c <= ri:
            return None
    sp = spout(prev)
    if sp and (r, c) in set(sp) and prev[r][c] == INK:
        return None                     # 小杯的描边：归 a6_spout_rim_stamps
    return True


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6"):
        return None
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    if _outside(prev, action) is None:
        return None
    return {(r, c): prev[r][c]
            for r in range(0, BAR_ROW)
            for c in range(len(prev[r]))}


def assert_(prev, action, nxt, ctx=None):
    pred = apply(prev, action, ctx)
    if pred is None:
        return "NA"
    for r in range(0, BAR_ROW):
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"
