"""RESET 之后，舞台上只剩三样东西——都能从 prev 单帧 + 词汇表常数直接算出来，不看这一步是不是换关、
也不看是不是连着换了张卡（session 的 guid 变了）：容器（清成色0，新杯占的格除外）、
新杯（回到词汇表里那组固定 114 格的姿势 `_lib.start_cup()`，颜色是描边色2 + 颜料色15）、
以及舞台上除容器与新杯之外的**一切**（比如第二只小杯那种额外物件）全部变回舞台背景色5。
底行同一步补满 64 格。这条不管左上面板（10x10 目标图）与右上横带（色板），
那是关卡的题面内容，本条从 prev 单帧读不出来，故意不声明——见 NOTE 的量化。
"""
LEVEL = "L1"
SCOPE = ("只看 action == 'RESET'，其余动作返回 NA。**不设 level_prev == level_next 的守卫，"
         "也不看 guid 是否变了**——这正是它和 `reset_sets_state` 的分工：那条守着「同一关内重开」"
         "这一支（并且额外断言 state 字段），这条守着「舞台+底行这几块像素，不管是哪一种重开」。"
         "vessel(prev) 认不出、或 start_cup() 画不出来时返回 NA——词汇瞎了不表态，不代表主张错了。"
         "**apply 与 assert_ 共用同一份预测**（`_predict`）：declared 的格子只有底行整行、"
         "容器 bbox、舞台上其余格子、新杯描边与液体，一格不多。")
NOTE = ("**这是 `reset_sets_state` 未认领的最大残差**：结算过的两次 RESET（第 269、420 步，"
        "tid 79f85baf04e1324e / 9a832d01617f0f77）分别有 533/533 与 622/622 格未解释——"
        "根因是那条概念的守卫写着「level_prev != level_next 就返回 NA」，而这两次 RESET 恰好"
        "都伴随着 guid 换卡（会话被回收），关卡号跟着从 2/6 跳回 0，守卫一碰就弹权。\n"
        "  量过之后发现：那条守卫挡住的不是「像素会不一样」，是「像素**不会**不一样」——"
        "舞台与底行这几块像素在这两次事件上和其它 3 次同卡重开的 RESET（第 49、149、207 步）"
        "遵守**同一条**规则（`runs/cd82-0905-1311/reset_probe.py` 第 3/5 节，去重后 423 条转移里"
        "全部 5 条 RESET 逐条核过）：\n"
        "    - 底行补满 64 格：5/5；\n"
        "    - 容器 bbox 除新杯占格外全清成色0：5/5，每次坏格数都是 0；\n"
        "    - 杯（描边+液体）逐格回到 `_lib.start_cup()` 那组固定 114 格：5/5，颜料色\n"
        "      （`paint_color(nxt)`）与朝向档（`tilt(nxt)`）也都是 5/5 == 15 / == 0；\n"
        "    - 把「舞台上除容器/新杯外全部清成背景色5」也验了一遍（`strong_claim_ok`）：5/5 TRUE，"
        "  这一条额外吃下了第 420 步里第二只小杯（spout）腾空的 28 格——那 28 格在只按"
        "「旧杯腾空」算账的窄口径下（`reset_sets_state` 的口径）会漏记。\n"
        "  按这份预测把 `assert_` 逐条跑一遍（`_predict` 与 apply 共用同一份逻辑）：**5/5 TRUE**，"
        "0 FALSE，0 NA（全部转移的分母是去重后 423 条，本条只在 5 条 RESET 上表态，其余 418 条 NA）。\n"
        "  帧差覆盖率（本条声明地盘 ∩ 实际帧差 / 实际帧差）：\n"
        "    第 49 步 81/81、第 149 步 114/114、第 207 步 259/269、\n"
        "    第 269 步 281/533、第 420 步 355/622。\n"
        "  剩下没覆盖的部分，第 207 步是 10 格（bbox 行7 列35-45），那是下划线随颜料换环挪位——"
        "不是这条的地盘，`panel_static`/`underline_marks_paint` 已经在管；第 269、420 步剩下"
        "252/533 与 267/622 格，bbox 都落在左上面板（rows0-17×cols0-17）与右上横带"
        "（rows0-8×cols18-63）里，颜色变化的直方图（`reset_probe.out` 第4节）看着是整张目标图"
        "和整条色板都换了内容，不是局部小改。**这部分故意不写进本条**：`_predict` 只拿得到 prev"
        "（这一关**换关前**的画面）和词汇表常数，读不出「换到的这一关目标图/色板长什么样」——"
        "prev 上根本没有那张图的任何像素，不是词汇瞎了，是这个信息在 prev 里不存在。\n"
        "  **一个测过、但故意没敢用的发现**：这 5 次 RESET 之后的帧，和全语料里 seq 最早那一条"
        "记录的 prev 帧相比，逐格差都是 0/4096（`reset_probe.out` 第2节，5/5）——包括两次换卡"
        "的那两条。这似乎说明「level 0 的题面」是这局唯一的一份、不随 session 变化的常数，"
        "而不是每次重开都重新抽一份新题面。但这句话**没有资格写进本条的判据**：`assert_`/`apply`"
        "的函数签名只给 `prev, action, nxt, ctx`，拿不到「全语料最早一帧」这个东西——"
        "要用上它就得让概念去翻语料史或者把那张图的像素硬编码进代码，前者是查表、后者是记忆，"
        "两条路都在禁止的范围内。所以这不是「还没来得及验证」，是**这个 API 形状下永远验证不了**："
        "留一句话交代这个边界，好过悄悄绕过去。\n"
        "v1。EVIDENCE 收了全部 5 条 RESET（`reset_sets_state` 只收了 1 条），"
        "所以本条没有 held-out 考卷——这是缺点，不是优点，下一次真正的新 RESET 才是它的第一张真考卷。")
EVIDENCE = [
    "8ceb44fc3012dc9b",   # 第 49 步：同卡内重开
    "2ceb60de47d193fb",   # 第 149 步：同卡内重开（前一步 GAME_OVER）
    "ca2058f1668862f2",   # 第 207 步：同卡内重开，唯一带 10 格未解释残差（下划线，非本条地盘）
    "79f85baf04e1324e",   # 第 269 步：guid 换了（会话被回收），level 2 -> 0
    "9a832d01617f0f77",   # 第 420 步：guid 换了（会话被回收），level 6 -> 0（WIN 之后）
]

from _lib import BAR_COLOR, BAR_ROW, INK, STAGE_BG, _in_stage, start_cup, vessel

PAINT_AFTER = 15   # 重开后杯里的颜料色（沿用 reset_sets_state 的口径，5/5 样本都是这个值）
CLEAR = 0          # 重开后容器整块的颜色


def _is_reset(action):
    return str(action).strip().upper() == "RESET"


def _predict(prev):
    """RESET 之后底行整行 + 容器 bbox + 舞台其余部分该长什么样：{(行,列): 色}。

    vessel(prev) 或 start_cup() 认不出返回 None——这两样都只从 prev 与词汇表常数取，
    不看 nxt、不看 ctx、不看这局历史上任何别的帧。
    """
    v = vessel(prev)
    s = start_cup()
    if v is None or s is None:
        return None
    new_ink, new_liq = s
    new_all = set(new_ink) | set(new_liq)
    t, b, l, r = v

    out = {}
    for c in range(len(prev[BAR_ROW])):                      # 底行整行补满
        out[(BAR_ROW, c)] = BAR_COLOR
    for rr in range(t, b + 1):                                # 容器整块清零（新杯占的格除外）
        for cc in range(l, r + 1):
            if (rr, cc) in new_all:
                continue
            out[(rr, cc)] = CLEAR
    for rr in range(64):                                      # 舞台上其余格子清成背景
        for cc in range(64):
            if not _in_stage(rr, cc):
                continue
            if (t <= rr <= b and l <= cc <= r) or (rr, cc) in new_all:
                continue
            out[(rr, cc)] = STAGE_BG
    for pos in new_ink:                                       # 新杯描边
        out[pos] = INK
    for pos in new_liq:                                       # 新杯液体
        out[pos] = PAINT_AFTER
    return out


def apply(prev, action, ctx=None):
    if not _is_reset(action):
        return None
    return _predict(prev)


def assert_(prev, action, nxt, ctx=None):
    if not _is_reset(action):
        return "NA"
    pred = _predict(prev)
    if pred is None:
        return "NA"
    for (r, c), col in pred.items():
        if nxt[r][c] != col:
            return "FALSE"
    return "TRUE"
