"""ACTION5 的作用域只有容器：舞台上容器 bbox 之外一格不动，容器里变了的格子一律变成当前颜料色。

「容器」= 舞台里那个不贴杯描边的最大颜料块的 bbox（见 _lib.vessel）。
这条不管涂成什么形状（那是 a5_fill_halfplane 的事），只断言作用域与「只往一个方向涂」。
v1 写的是「只把 0 涂成 15」，颜料色变成变量以后这话不成立了；v2 改成「只涂成 paint_color(prev)」，
这才是它想说的那件事：一次 ACTION5 只上一种颜色，不会连带把别处改回去。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；其余动作返回 NA。vessel() 或 paint_color() 认不出时返回 NA。"
         "只看 rows STAGE_R0..STAGE_R1。换关返回 NA——**assert_ 与 apply 两处都要有这道守卫**，"
         "v2 只在 assert_ 里写了（见 NOTE）。")
NOTE = ("v3：apply 补上 assert_ 早就有的那道换关守卫。**这不是改主张，是修口不对心。**\n"
        "  第 253、263 步是两次「ACTION5 顺手过关」的转移：这一步既是倾倒又是换关。"
        "SCOPE 明写着换关返回 NA，可 v2 的 apply 没有那道守卫，照旧声明了容器之外整个舞台"
        "「照抄 prev」——而换关那一刻整个舞台都被重置了，杯从旧工位传送回开局姿势，"
        "照抄 prev 的那片声明大部分是错的。\n"
        "  发现它靠的是打架表，不是反例：assert_ 弃权，所以本条在这两步上从没被判过，"
        "S/C/N 三个数一格不动。换关重置那两条概念（levelup_resets_stage、levelup_sets_paint）"
        "一带上 apply，账立刻浮出来——`a5_pours_into_vessel × levelup_resets_stage 158 格`、"
        "`× levelup_sets_paint 84 格`（`runs/<run>/settle_336c.txt`）。\n"
        "  这是本册第二次踩同一个坑（第一次是 a5_paints_cup_side v1→v2，同一批换关步、同一种漏）。"
        "两次的形状完全一样：**守卫写在 assert_ 里，忘在 apply 里**。\n"
        "v2：把「只 0->15」换成「只 ->paint_color(prev)」。理由不是反例，是 ACTION6 让颜料色变成了变量。")
EVIDENCE = ["a215d90877336853", "5d164e85e3b35523"]

from _lib import vessel, paint_color, STAGE_R0, STAGE_R1


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    v = vessel(prev)
    pc = paint_color(prev)
    if v is None or pc is None:
        return "NA"
    t, b, l, r = v
    for rr in range(STAGE_R0, STAGE_R1 + 1):
        for cc in range(len(prev[rr])):
            inside = t <= rr <= b and l <= cc <= r
            if prev[rr][cc] == nxt[rr][cc]:
                continue
            if not inside:
                return "FALSE"
            if nxt[rr][cc] != pc:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """容器外的舞台格子照抄——ACTION5 不碰它们。"""
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None                      # 与 assert_ / SCOPE 同源的守卫：换关那一步整个舞台都被重置
    if not action.startswith("ACTION5"):
        return None
    v = vessel(prev)
    if v is None:
        return None
    t, b, l, r = v
    out = {}
    for rr in range(STAGE_R0, STAGE_R1 + 1):
        for cc in range(len(prev[rr])):
            if not (t <= rr <= b and l <= cc <= r):
                out[(rr, cc)] = prev[rr][cc]
    return out
