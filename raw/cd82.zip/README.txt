Files of cd82 as the agent and the bench wrote them, paths relative to the bench repository.
Lean: leanprover/lean4:v4.34.0 (lean-toolchain). To re-check, copy archive/cd82-20260912/formal/Game.lean to Check.lean, append
'#print axioms consistent' and '#print axioms faithful', and run: lean +<toolchain> -M60000 Check.lean
VERIFY.json is the record made at sealing; VERIFY-recheck.json and VERIFY-recheck.lean.out are our later kernel check (2026-10-23).
The readings inside Game.lean were generated from runs/*/transitions.jsonl by the bench's world/formalize.py build
(not included), called through meta/repair-20260928/gen_run.py with --lib meta/repair-20260928/lib/cd82-20260912/_lib.py;
that per-game reading library and the geo.py it imports are included.
