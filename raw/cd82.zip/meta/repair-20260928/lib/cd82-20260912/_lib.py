"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来源（帧与帧差，非推测）：
- 屏幕分三块：上部 rows 0..18 是静止面板/HUD（左上一个 18x18 的色4 块 + 右上一条色3 带，
  带里嵌着两个 5x5 的色4 环和一条 1x5 的色0 短线）；rows 19..62 是舞台；row 63 单独一行，
  从 col0 起是一条色4 前缀条。
- 舞台上有两块东西：一个色2 描边的**杯**（描边里灌着一种「液色」），和一块 10x10 的**容器**。
- **液色不是常数。** 它原本是色15；点了横带里左边那个环的芯之后，杯里 84 格整块变成色0，
  容器一格没动。所以「色15 = 填充色」是错的：颜色是个可选的量，见 paint_color / swatches。
- 两种「颜料色」目前只见过 0 和 15（PAINTS）；舞台背景是色5。

还没量出来的一律留 None / 返回 None。
"""
from __future__ import annotations

import math
from collections import Counter, deque

from geo import cells_of  # noqa: F401

# 模板里的 CELL/PHASE/DELTA 预设了「格子+步长」的世界，这一局的动作不是平移，用不上。
CELL = None            # 未实测：本局未观察到平移步长
PHASE = None           # 未实测
DELTA = {}             # 未实测：本局动作不是平移

STAGE_R0, STAGE_R1 = 19, 62   # 舞台行区间（含）；上边界只对**面板那一侧**成立，见 _in_stage
STAGE_R0_BAND = 9             # 横带那一侧（列 >= BAND_C0）的舞台上边界：横带占 行0..8
PANEL_R1 = 18                 # 面板末行（含）
BAND_C0 = 18                  # 上方横带的起始列（左边 0..17 是那个 18x18 面板）
BAR_ROW = 63                  # 底行
BAR_COLOR = 4                 # 底行条的颜色，也是横带里那两个环的颜色
INK = 2                       # 杯的描边色
FILL = 15                     # 曾以为是「填充色」；实为两种颜料之一，留着给旧概念引用
PAINTS = (0, 15)              # 见过的颜料色
STAGE_BG = 5                  # 舞台背景色


def _in_stage(r, c=None):
    """这一格算不算舞台。

    舞台的上边界**不是一条水平线**：左边挡着 18x18 的面板（占 行0..17 x 列0..17），
    右边挡着上方横带（占 行0..8 x 列18..63），中间那块 行9..18 x 列18..63 是空的舞台。
    旧版写成单一常数 `STAGE_R0 = 19`，在第 0 关一路都对——那一关没有任何东西上到行 19 以上，
    所以两种读法逐格无法分辨。这是「一致覆盖可能是采样的形状」的又一例。
    实测（runs/<run>/stagetop.py，531 帧）：行9..18 x 列18..63 在旧语料里 0 个非背景格，
    所以放宽这条边界对旧语料**行为不变**；放宽之后才看得见新关里那个上到行 18 的物件。
    """
    if r > STAGE_R1 or r < 0:
        return False
    if c is not None and c >= BAND_C0:
        return r >= STAGE_R0_BAND
    return r >= STAGE_R0


def _stage_cells(g):
    """舞台上所有格的 (行, 列)，按 _in_stage 的分段边界。"""
    for r in range(STAGE_R0_BAND, STAGE_R1 + 1):
        row = g[r]
        for c in range(len(row)):
            if _in_stage(r, c):
                yield r, c


def cells(g, color, r0, r1):
    """g 里 rows r0..r1（含）内颜色为 color 的格子集合。"""
    out = set()
    for r in range(r0, r1 + 1):
        row = g[r]
        for c in range(len(row)):
            if row[c] == color:
                out.add((r, c))
    return frozenset(out)


def bbox(pts):
    """点集的 (上, 下, 左, 右)；空集返回 None。"""
    if not pts:
        return None
    rs = [p[0] for p in pts]
    cs = [p[1] for p in pts]
    return (min(rs), max(rs), min(cs), max(cs))


def ink(g):
    """舞台上的描边格（色2）。注意它不一定只属于一个物件，见 cup_ink。"""
    return frozenset((r, c) for r, c in _stage_cells(g) if g[r][c] == INK)


def fill(g):
    """舞台上的色15 格。注意：不再等于「杯里的液体」，色15 只是众多颜料之一。"""
    return frozenset((r, c) for r, c in _stage_cells(g) if g[r][c] == FILL)


def paints(g):
    """当前可用的颜料色 = 横带里那些色环的芯色。**从帧上读，不是写死的清单。**

    第 0 关只有两个环（芯色 0 与 15），于是 PAINTS=(0,15) 一路都对；换关之后横带里出现了
    第三个环（芯色 12），那个常数立刻变成「第 0 关的采样」而不是「世界的颜料集」。
    """
    return frozenset(c for _, c in swatches(g) if c is not None)


def paint_cells(g):
    """舞台上所有颜料格 = 既不是背景色也不是描边色的舞台格。

    旧版是「颜色 ∈ PAINTS」，即靠一张写死的两色清单。那张清单在第三种颜料出现的那一帧会让
    liquid() 返回空集，于是 paint_color / open_dir / vessel 一起返回 None——整册不是被推翻，
    是**瞎掉**（集体弃权），而集体弃权不会有任何东西报错。
    改成「非背景、非描边」之后不再需要颜料清单：舞台上只有这三类东西（实测第 0 关与第 1 关的
    舞台格集合减去色5 与色2 之后，剩下的恰好是容器与杯里的液体）。
    """
    out = set()
    for r, c in _stage_cells(g):
        if g[r][c] not in (STAGE_BG, INK):
            out.add((r, c))
    return frozenset(out)


def _touches(s, other):
    """s 里有没有格子与 other 里的格子八邻接。"""
    for (r, c) in s:
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if (dr or dc) and (r + dr, c + dc) in other:
                    return True
    return False


def _blobs(g):
    """舞台颜料格的八连通块，切成 (贴着杯描边的, 不贴的) 两堆。"""
    from geo import components
    ik = ink(g)
    near, far = [], []
    for comp in components(sorted(paint_cells(g)), diag=True):
        s = frozenset(comp)
        (near if _touches(s, ik) else far).append(s)
    return near, far


def cup_blobs(g):
    """所有「贴着色2 描边的颜料块」，按格数从大到小。

    第 0 关与第 1 关舞台上只有一个（实测 531/531 帧：描边 1 个连通块、贴描边的颜料块 1 块）；
    新关的舞台上不止一个——多出来的那个小物件也有描边、也贴着颜料。
    """
    near, _ = _blobs(g)
    return sorted(near, key=len, reverse=True)


def liquid(g):
    """杯里的液体 = **最大的**那个贴描边颜料块；一个都没有时返回空集。

    旧版是「不是恰好一个就返回空集」。那在只有一个杯的关里和现在逐格等价（实测 531/531 帧），
    但在舞台上出现第二个带描边物件的那一刻，它让 liquid 返回空集，
    于是 open_dir / paint_color / tilt / sig 一起 None，整册在那一关**集体弃权**——不报错的瞎。
    「最大的那个是杯」不是猜：新关里最大的那块与旧关开口南那个姿势**逐项相同**
    （描边 30 格、液体 84 格、bbox 行24..32 列25..38）。它要是错的，
    挂在 open_dir 上的那一串概念会一起挨打，那正是想要的判错方式。
    """
    b = cup_blobs(g)
    return b[0] if b else frozenset()


def cup_ink(g):
    """杯的描边 = 与杯里液体八邻接的那些描边连通块。

    不能拿整块 ink()：舞台上第二个物件的描边会一起算进来，把杯的质心拽偏，open_dir 就错了。
    旧语料里 ink() 只有一个连通块且它贴着液体，所以 cup_ink == ink，逐格等价。
    """
    from geo import components
    lq = liquid(g)
    if not lq:
        return frozenset()
    out = set()
    for comp in components(sorted(ink(g)), diag=True):
        s = frozenset(comp)
        if _touches(s, lq):
            out |= s
    return frozenset(out)


def spout(g):
    """除大杯以外的那些「杯」：贴描边颜料块里不是最大的那些，连同贴着它们的描边一起。

    为什么要有它：`ink()` 把这些描边一起算进去，`_fit` 的「照参数重画 == 原帧」就永远不成立，
    于是挂在 _fit 上的整批旋转概念在**有第二只杯的那些帧上集体弃权**——不是被推翻，是瞎掉。
    大杯归 cup_ink / liquid，第二只杯归这里，两边不重叠。
    """
    from geo import components
    bl = cup_blobs(g)
    if len(bl) <= 1:
        return frozenset()
    rest = frozenset().union(*bl[1:])
    out = set(rest)
    for comp in components(sorted(ink(g)), diag=True):
        s = frozenset(comp)
        if _touches(s, rest):
            out |= s
    return frozenset(out)


def cup_liquid(g):
    """**所有**杯里的液体：每个贴描边颜料块里、颜色**等于当前颜料色**的那些格。

    `liquid()` 只给最大那一只，而选色那一下改的是每一只——按 liquid() 写的选色概念
    会在第二只杯出现的那一帧挨打。

    口径改过一次，前一版是「颜色不是 0 的格」，**被数据直接推翻**
    （`runs/<run>/liqdef.py`）：第 24 步与第 252 步大杯那 84 格**全是色 0**，
    点色板之后 84 格全换了色；而第 264 步第二只杯的 2 格色 0 一格没换。
    所以分界不是「是不是色 0」。真正的分界是「是不是等于当前颜料色」：
    第 24 步 paint_color=0（下划线停在色 0 那个环下面），那 84 格色 0 正是它装着的颜料；
    第 264 步 paint_color=15，第二只杯那 2 格色 0 不等于 15，于是不换。
    全语料 213 个去重帧里，**没有一只杯装着既非色 0 又非当前颜料色的格**
    （`runs/<run>/cupcolors.py`：0 例），所以这个口径在大杯上与 `liquid()` 逐格相同，
    差别只在第二只杯。

    前一版那个口径造成的损失是可测的：它让选色概念在「杯里现在是空的」那一整类步上
    **整条弃权**（第 0 关 39 次点色板全属这一类），规则图完成度掉 1600/21779 格
    （`runs/<run>/eblame2.py`）。弃权不报错、不关闸、S 照样满分——只有 E 看得见。
    """
    pc = paint_color(g)
    if pc is None:
        return frozenset()
    out = set()
    for b in cup_blobs(g):
        out |= {(r, c) for (r, c) in b if g[r][c] == pc}
    return frozenset(out)


def paint_color(g):
    """当前颜料色 = 杯里液体的颜色。液体不是单色或认不出时返回 None。

    这是这一局最贵的一个发现：它是**可变的**，由横带里的色板选出来（见 swatches）。
    """
    liq = liquid(g)
    if not liq:
        return None
    cs = {g[r][c] for (r, c) in liq}
    return next(iter(cs)) if len(cs) == 1 else None


def vessel(g):
    """容器的 bbox = 舞台里**不贴杯描边**的那个最大颜料块的 bbox；认不出返回 None。

    旧版按「含色0 的 {0,15} 块」找，颜料色能变以后那样会误抓成杯里的液体。
    假设：三个朝向下杯与容器之间都隔着背景（实测如此）。
    """
    _, far = _blobs(g)
    if not far:
        return None
    return bbox(max(far, key=len))


def obj(g):
    """杯 = 杯的描边 ∪ 液体。"""
    return cup_ink(g) | liquid(g)


def sig(g):
    """杯的朝向签名：(描边格数, 液体格数, bbox)。同一朝向应给同一签名。"""
    i, l = cup_ink(g), liquid(g)
    return (len(i), len(l), bbox(i | l))


def bar(g):
    """底行色4 的格数。"""
    return sum(1 for c in range(len(g[BAR_ROW])) if g[BAR_ROW][c] == BAR_COLOR)


def bar_is_prefix(g):
    """底行色4 是否恰好占据 col0 起的一段连续前缀。"""
    row = g[BAR_ROW]
    n = bar(g)
    return all(row[c] == BAR_COLOR for c in range(n)) and \
        all(row[c] != BAR_COLOR for c in range(n, len(row)))


def swatches(g):
    """上方横带里的色板：每个 5x5 色4 环一项 (bbox, 芯色)，按列从左到右。

    环 = 横带（rows 0..PANEL_R1, cols >= BAND_C0）里 16 格的 5x5 色4 空心方；
    芯 = 它内部 3x3 的颜色（不是单色就记 None）。
    """
    from geo import components
    pool = {(r, c)
            for r in range(0, PANEL_R1 + 1)
            for c in range(BAND_C0, len(g[r]))
            if g[r][c] == BAR_COLOR}
    out = []
    for comp in components(sorted(pool), diag=True):
        b = bbox(set(comp))
        t, bo, l, ri = b
        if bo - t == 4 and ri - l == 4 and len(comp) == 16:
            core = {g[r][c] for r in range(t + 1, bo) for c in range(l + 1, ri)}
            out.append((b, next(iter(core)) if len(core) == 1 else None))
    out.sort(key=lambda x: x[0][2])
    return out


def underline(g):
    """横带里那条不属于任何环的色0 水平短线：返回 (行, 左列, 右列)；认不出返回 None。"""
    rings = [b for b, _ in swatches(g)]
    zs = {(r, c)
          for r in range(0, PANEL_R1 + 1)
          for c in range(BAND_C0, len(g[r]))
          if g[r][c] == 0}
    zs = {p for p in zs
          if not any(t <= p[0] <= bo and l <= p[1] <= ri for (t, bo, l, ri) in rings)}
    if not zs:
        return None
    b = bbox(zs)
    if b[0] != b[1]:
        return None
    return (b[0], b[2], b[3])


# ---------------------------------------------------------------------------
# 杯的姿势 = 开口方向
#
# 旧版 tilt() 只用 bbox 形状分三档（矮胖 -> 0，正方看最上排偏左右 -> ±1）。实测它**认错**：
# 姿势不止三个，而形状会重复——有一个 17x17 的斜姿势被它判成 -1、一个 9x14 的扁姿势被它判成 0，
# 于是四条挂在 tilt() 上的概念同时挨打。误判比返回 None 坏得多：None 让概念老实地弃权，
# 误判让概念在它管不着的地方开口。
#
# 换成开口方向，理由是它**不查表、不用常数、也不用绝对坐标**：
#   开口方向 = 从描边质心指向液体质心。杯壁在三面，描边质心被拉向闭合那侧；液体在内部中央；
#   所以这个向量指着缺口。八方向取整。
# 实测（全语料 244 帧）：同一个开口方向的杯格集**逐格唯一**，六个不同姿势给出六个不同方向，
# 所以开口方向足以当姿势的名字。
DIR_NAMES = ("东", "东北", "北", "西北", "西", "西南", "南", "东南")   # 下标 0..7，屏幕上逆时针
DIR_VEC = ((0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1), (1, 0), (1, 1))
# 四个键就是屏幕四方向（实测：杯动了的那一步，质心位移的主分量恰好是这个方向）
KEY_DIR = {"ACTION1": 2, "ACTION2": 6, "ACTION3": 4, "ACTION4": 0}   # 上 / 下 / 左 / 右


def _cen(pts):
    n = len(pts)
    if not n:
        return None
    return (sum(p[0] for p in pts) / float(n), sum(p[1] for p in pts) / float(n))


def dir8(dr, dc):
    """(行增量, 列增量) -> 八方向下标；零向量返回 None。屏幕上行往下增，所以取 -dr 当 y。"""
    import math
    if abs(dr) < 1e-9 and abs(dc) < 1e-9:
        return None
    return int(round(math.degrees(math.atan2(-dr, dc)) % 360.0 / 45.0)) % 8


def cup_cen(g):
    """杯（描边 ∪ 液体）的质心；认不出返回 None。"""
    o = obj(g)
    return _cen(sorted(o)) if o else None


def open_dir(g):
    """杯的开口方向下标（0..7，见 DIR_NAMES）；描边或液体认不出时返回 None。"""
    ik, lq = cup_ink(g), liquid(g)
    if not ik or not lq:
        return None
    ci, cl = _cen(sorted(ik)), _cen(sorted(lq))
    return dir8(cl[0] - ci[0], cl[1] - ci[1])


def open_name(d):
    return "认不出" if d is None else DIR_NAMES[d]


def key_dir(action):
    """动作串 -> 方向下标；不是这四个键返回 None。"""
    return KEY_DIR.get(action.strip().upper().split(":")[0])


def offset8(a, b):
    """a 相对 b 的有符号角差，单位 45 度，取值 -3..4。"""
    return ((a - b + 4) % 8) - 4


def turn(d, k):
    """开口在 d、按下方向为 k 的键：返回新的开口下标；这个键在这个姿势上是空动作则返回 None。

    实测规则（18 个 (姿势, 键) 格全对上，零异常）：开口**转离**键的方向 45 度；
    可转的条件是开口与键的夹角是 45 度或 90 度。夹角 0 度、135 度、180 度时整帧不动。
    """
    if d is None or k is None:
        return None
    s = offset8(d, k)
    if s in (1, 2):
        return (d + 1) % 8
    if s in (-1, -2):
        return (d - 1) % 8
    return None


def hub(g):
    """轨道中心 = 容器 bbox 的中心（行, 列）。**从帧上读出来的，不是拟合常数。**

    实测：容器在全语料 244 帧里恒为 rows 34..43 x cols 27..36，中心 (38.5, 31.5)；
    六个杯姿势的位置角绕这个点是 45 度的整数倍，且每个姿势的开口都指着它。
    """
    b = vessel(g)
    if b is None:
        return None
    t, bo, l, r = b
    return ((t + bo) / 2.0, (l + r) / 2.0)


def rot90(p, h, ccw=True):
    """把格 p 绕 h 转 90 度（整格，精确）。实测：绕容器中心转 90 度把一个姿势逐格映到另一个。"""
    r, c = p
    hr, hc = h
    if ccw:
        return (int(round(hr - (c - hc))), int(round(hc + (r - hr))))
    return (int(round(hr + (c - hc))), int(round(hc - (r - hr))))


def tilt(g):
    """杯的朝向档，只给「开口朝南 / 东南 / 西南」这三个姿势命名，其余一律 None。

    沿用旧的符号约定（开口南 = 0、东南 = +1、西南 = -1），这样挂在它上面的旧概念含义不变；
    变的是**定义域**：旧版按 bbox 形状分档，会把开口朝东北的斜姿势误判成 -1、开口朝北的扁姿势
    误判成 0（实测各 4 帧与 1 帧）；现在按开口方向分，认不出的姿势老实返回 None。
    """
    return {6: 0, 7: 1, 5: -1}.get(open_dir(g))


def me(g):
    """本局没有'玩家格'这种东西：可动的是整个杯，不是一个小块。留 None。"""
    return None


# ---------------------------------------------------------------------------
# 倾倒：靠杯那一侧的半平面
#
# 为什么在这里：两条以上的概念要用它（a5_paints_cup_side 与 levelup_needs_target_pic），
# 而结算时概念之间不能互相 import。
#
# 旧的 _halfplane（写在 vessel_16_states 与 wedge_never_painted 里）只认三档，用的是三条写死的
# 不等式（rr<=mid / cc>=rr / 9-cc>=rr）。那三档不是世界的三个档，是**语料里只出现过三个工位**：
# 倒过的 30 次全落在开口南 / 东南 / 西南，而那恰好是杯严格位于容器上方的三个姿势。
# 八工位打通之后，同一条几何写成一个式子就够：
#   杯在容器的 (d+4)%8 方向那一侧（d = 开口方向，开口指着容器）；
#   界线过容器 bbox 中心、垂直于「容器→杯」；靠杯那半边整片重涂成当前颜料色。
# 实测三档就是这个式子的 d=6 / 7 / 5 三个特例（runs/<run>/pour8.py 逐格核对）。
# ---------------------------------------------------------------------------

PANEL_TGT = (3, 12, 3, 12)     # 左上面板里那张 10x10 图的 bbox（面板整局一格没变）


def panel_pic(g):
    """面板里那张 10x10 图，逐格。"""
    t, bo, l, r = PANEL_TGT
    return tuple(tuple(g[rr][cc] for cc in range(l, r + 1)) for rr in range(t, bo + 1))


def side_halfplane(h, d):
    """边长 h 的正方容器里，开口方向 d 那一次倾倒覆盖的相对格集（靠杯那半边，含界线上的格）。"""
    mid = (h - 1) / 2.0
    ur, uc = DIR_VEC[(d + 4) % 8]
    return frozenset((rr, cc)
                     for rr in range(h) for cc in range(h)
                     if ur * (rr - mid) + uc * (cc - mid) >= 0)


def after_pour(g):
    """这一步 ACTION5 之后容器该长什么样：{(绝对行, 绝对列): 色}。

    容器 / 开口方向 / 颜料色任一认不出，或容器 bbox 不是正方形，返回 None。
    """
    b = vessel(g)
    d = open_dir(g)
    col = paint_color(g)
    if b is None or d is None or col is None:
        return None
    t, bo, l, r = b
    hh, ww = bo - t + 1, r - l + 1
    if hh != ww:
        return None
    return {(t + rr, l + cc): col for rr, cc in side_halfplane(hh, d)}


def click_rc(action):
    """ACTION6:x,y -> (行, 列)；不是带坐标的 ACTION6 或解析不出返回 None。"""
    if not action.startswith("ACTION6") or ":" not in action:
        return None
    try:
        x, y = action.split(":", 1)[1].split(",")
        return (int(y), int(x))
    except (ValueError, IndexError):
        return None


def spout_rim_hit(g, action):
    """这一次 ACTION6 是不是点在第二只小杯的描边（色 INK）上。"""
    p = click_rc(action)
    if p is None:
        return False
    sp = spout(g)
    if not sp or p not in set(sp):
        return False
    return g[p[0]][p[1]] == INK


def after_stamp(g, action):
    """点小杯描边这一步之后容器该长什么样：{(绝对行, 绝对列): 色}。

    小杯腔里那块颜料整块盖到容器最靠近小杯的那条边上：深度 = 腔在开口轴上的跨度，
    垂直于开口轴的那些坐标与腔完全相同。不该触发、或几何算不出，返回 None。
    """
    if not spout_rim_hit(g, action):
        return None
    d = open_dir(g)
    b = vessel(g)
    col = paint_color(g)
    if d is None or d % 2 != 0 or b is None or col is None:
        return None
    sp = spout(g)
    cav = [q for q in sp if g[q[0]][q[1]] == col]
    if not cav:
        return None
    t, bo, l, r = b
    dr, dc = DIR_VEC[d]                 # 从小杯指向容器
    rows = sorted({rr for rr, _ in cav})
    cols = sorted({cc for _, cc in cav})
    if dr:
        band = range(t, t + len(rows)) if dr > 0 else range(bo - len(rows) + 1, bo + 1)
        cells = [(rr, cc) for rr in band for cc in cols]
    else:
        band = range(l, l + len(cols)) if dc > 0 else range(r - len(cols) + 1, r + 1)
        cells = [(rr, cc) for rr in rows for cc in band]
    if any(not (t <= rr <= bo and l <= cc <= r) for rr, cc in cells):
        return None
    return {q: col for q in cells}


def walls(g):
    """阻挡集合未实测（本局动作不是平移，先不定义）。"""
    return None


# ---------------------------------------------------------------------------
# 「开口矩形」的反解与重画 —— 从 rot_apply 提上来的共用机械
#
# 为什么在这里：两条以上的概念要用它（rot_apply 与 rot8_apply），而结算时概念之间**不能互相 import**
# （只有 _lib 与 geo 在路径上）。第一次把 rot8_apply 挪进 concepts/ 就是这么关了闸的：
# `ModuleNotFoundError: No module named 'rot_apply'`，概念跑不起来等于没被检验，闸直接关。
# 教训：共用的判据不落词汇表，就会长成概念之间的暗依赖，而那种依赖只在结算那一刻才暴露。
#
# 这套机械本身是**假设**，和这个文件里其他东西一样：
# 杯不是一堆搬来搬去的格子，而是一个连续的刚体——中心 O、长轴 u、外半长 hl、外半宽 hs、
# 开口朝 v 的 osign 那一侧——转完角度以后**重新光栅化**。三条闭边画成 4 连通阶梯
# （所以 45 度斜边每行两格、轴对齐边每行一格，这就是描边格数在斜姿势比轴向多出约 √2 倍的原因）；
# 开口那条长边只留理想数字线，它同时是液体的挡板；液体从 round(O) 起四连通泛洪，撞到挡板为止。
# 代码从 rot_apply v3 原样搬过来，一个字没改，函数名连下划线一起保留，好让 git 看出是搬迁不是重写。
_S = math.sqrt(0.5)
_EPS = 0.1                     # 角点往里收的量，让「外边界」取整回格心
_DIRS8 = [(0.0, 1.0), (_S, _S), (1.0, 0.0), (_S, -_S),
          (0.0, -1.0), (-_S, -_S), (-1.0, 0.0), (-_S, _S)]


def _perp(u):
    return (u[1], -u[0])


def _rot45(u, d):
    """d=+1: (dr,dc) -> (s(dr-dc), s(dr+dc))；d=-1 是它的逆。"""
    if d > 0:
        return (_S * (u[0] - u[1]), _S * (u[0] + u[1]))
    return (_S * (u[0] + u[1]), _S * (u[1] - u[0]))


def _rnd(x):
    return int(math.floor(x + 0.5))


def _snap8(u):
    return min(_DIRS8, key=lambda d: (d[0] - u[0]) ** 2 + (d[1] - u[1]) ** 2)


def _corners(O, u, hl, hs):
    """四个角格：(沿长轴的符号, 沿短轴的符号) -> 格。"""
    v = _perp(u)
    out = {}
    for su in (1, -1):
        for sv in (1, -1):
            out[(su, sv)] = (_rnd(O[0] + (hl - _EPS) * su * u[0] + (hs - _EPS) * sv * v[0]),
                             _rnd(O[1] + (hl - _EPS) * su * u[1] + (hs - _EPS) * sv * v[1]))
    return out


def _line(x, y):
    """两格之间的理想数字线段；只认轴对齐与 45 度，别的返回 None。"""
    dr, dc = y[0] - x[0], y[1] - x[1]
    n = max(abs(dr), abs(dc))
    if n == 0:
        return [x]
    if abs(dr) not in (0, n) or abs(dc) not in (0, n):
        return None
    sr = (dr > 0) - (dr < 0)
    sc = (dc > 0) - (dc < 0)
    return [(x[0] + i * sr, x[1] + i * sc) for i in range(n + 1)]


def _edge(x, y, O):
    """闭边：理想数字线 + 每处对角缝补一格（补离 O 近的那个），结果 4 连通。"""
    ln = _line(x, y)
    if ln is None:
        return None
    out = list(ln)
    for a, b in zip(ln, ln[1:]):
        if a[0] != b[0] and a[1] != b[1]:
            c1, c2 = (b[0], a[1]), (a[0], b[1])
            d1 = (c1[0] - O[0]) ** 2 + (c1[1] - O[1]) ** 2
            d2 = (c2[0] - O[0]) ** 2 + (c2[1] - O[1]) ** 2
            out.append(c1 if d1 <= d2 else c2)
    return out


def _shape(O, u, hl, hs, osign):
    """照参数画出 (描边格集, 液体格集)；画不出或围不住返回 None。"""
    cn = _corners(O, u, hl, hs)
    if len(set(cn.values())) != 4:
        return None
    ed = set()
    for a, b in (((1, -osign), (-1, -osign)),
                 ((1, -osign), (1, osign)),
                 ((-1, -osign), (-1, osign))):
        cc = _edge(cn[a], cn[b], O)
        if cc is None:
            return None
        ed |= set(cc)
    mouth = _line(cn[(1, osign)], cn[(-1, osign)])
    if mouth is None:
        return None
    barrier = ed | set(mouth)
    start = (_rnd(O[0]), _rnd(O[1]))
    if start in barrier:
        return None
    rs = [p[0] for p in barrier]
    cs = [p[1] for p in barrier]
    r0, r1 = min(rs) - 2, max(rs) + 2
    c0, c1 = min(cs) - 2, max(cs) + 2
    seen = {start}
    q = deque([start])
    while q:
        r, c = q.popleft()
        if r <= r0 or r >= r1 or c <= c0 or c >= c1:
            return None            # 泛洪漏出去了，说明这组参数没围成闭合物件
        for p in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
            if p in seen or p in barrier:
                continue
            seen.add(p)
            q.append(p)
    return frozenset(ed), frozenset(seen)


def _fit(g):
    """从帧上反解开口矩形 (O, u, hl, hs, osign)；要求照参数重画 == 帧上的 ink/liquid，否则 None。"""
    ik, lq = cup_ink(g), liquid(g)
    if not ik or not lq:
        return None
    b = bbox(ik)
    if b is None:
        return None
    t, bo, l, r = b
    h, w = bo - t + 1, r - l + 1
    if h != w:
        O0 = ((t + bo) / 2.0, (l + r) / 2.0)
        us = [(0.0, 1.0)] if w >= h else [(1.0, 0.0)]
        cand = [(max(w, h) / 2.0, min(w, h) / 2.0)]
    else:
        top = min(ik, key=lambda p: (p[0], p[1]))
        bot = max(ik, key=lambda p: (p[0], p[1]))
        lef = min(ik, key=lambda p: (p[1], p[0]))
        rig = max(ik, key=lambda p: (p[1], p[0]))
        four = (top, bot, lef, rig)
        if len(set(four)) != 4:
            return None
        O0 = (sum(p[0] for p in four) / 4.0, sum(p[1] for p in four) / 4.0)
        dl = math.hypot(lef[0] - top[0], lef[1] - top[1])
        dr = math.hypot(rig[0] - top[0], rig[1] - top[1])
        if dl <= 0 or dr <= 0:
            return None
        if dl >= dr:
            u = _snap8(((lef[0] - top[0]) / dl, (lef[1] - top[1]) / dl))
            e_l, e_s = dl / 2.0, dr / 2.0
        else:
            u = _snap8(((rig[0] - top[0]) / dr, (rig[1] - top[1]) / dr))
            e_l, e_s = dr / 2.0, dl / 2.0
        us = [u, (-u[0], -u[1])]
        cand = [(hl, hs)
                for hl in sorted({round(e_l * 2) / 2.0 + k * 0.5 for k in (-1, 0, 1)})
                for hs in sorted({round(e_s * 2) / 2.0 + k * 0.5 for k in (-1, 0, 1)})
                if hl > 0 and hs > 0]
    hits = []
    for u in us:
        for osign in (1, -1):
            for hl, hs in cand:
                for i in range(-2, 3):
                    for j in range(-2, 3):
                        O = (O0[0] + i * 0.25, O0[1] + j * 0.25)
                        s = _shape(O, u, hl, hs, osign)
                        if s is not None and s[0] == ik and s[1] == lq:
                            hits.append((O, u, hl, hs, osign))
    if not hits:
        return None
    key = Counter((x[1], x[2], x[3], x[4]) for x in hits).most_common(1)[0][0]
    sel = [x for x in hits if (x[1], x[2], x[3], x[4]) == key]
    O = (sum(x[0][0] for x in sel) / len(sel), sum(x[0][1] for x in sel) / len(sel))
    return (O, key[0], key[1], key[2], key[3])


# ---------------------------------------------------------------------------
# 开局姿势：一个实测常数，配上面那个本来就有的正解构造器 `_shape`。
#
# 以前只有反解（`_fit`：从帧上认出当前姿势），概念要说「杯回到某个姿势」时说不出格集，
# 只能退到「open_dir(nxt) == 6」这种弱得多的话。旋转概念绕开这个缺口的办法是
# 「从当前姿势绕枢轴转 45 度」——那条路子在重置事件上用不了，重置是传送不是转一格。
#
# 实测（runs/<run>/startpose.py）：**五个事件把杯放回的是同一组 114 格**——
# 三次同关 RESET 之后的帧、两次换关之后的帧，与整局开局帧逐格相同（对称差 0 格 ×5），
# `_fit` 反解出的参数五处全同，照参数 `_shape` 重画与帧上的 ink/liquid 逐格无差。
# 所以「重置 → 这一个绝对姿势」够写成一个常数；它是假设，靠引用它的概念挨打。
START_POSE = ((28.0, 31.5), (0.0, 1.0), 7.0, 4.5, 1)     # (O, u, hl, hs, osign)


def start_cup():
    """开局姿势的 (描边格集, 液体格集)；参数围不成闭合物件时返回 None。"""
    return _shape(*START_POSE)


# ---------------------------------------------------------------------------
# 修复（meta/repair-20260928）补的读数与隐藏状态。以上原有读数一个未删、一个未改。
#
# 为什么补：原抽象把 swatches() 压成了计数 swatches_n，「点横带上的 (x,y) 换成什么颜料、
# 下划线挪到哪」在原状态上写不出来（原 Lean 只好靠一张 (下划线列 -> 颜料) 的实测反解表，
# 且假定点击恰好落在环的中列）。ring_code 把每个环的位置与芯色按定长整数元组留下来。
RING_SLOTS = 7          # 全语料横带上最多 7 个环（环数只出现过 2 / 3 / 7）


def ring_code(g):
    """横带色环的定长编码：按左列从左到右，每个环 (上边行, 左边列, 芯色) 三个整数，
    不足 RING_SLOTS 个环的空槽填 -1；芯色不是单色记 -1。只从这一帧的像素算（经 swatches）。"""
    out = []
    for (t, _bo, l, _ri), core in swatches(g)[:RING_SLOTS]:
        out += [t, l, -1 if core is None else core]
    out += [-1] * (3 * RING_SLOTS - len(out))
    return tuple(out)


PANEL_SIZE = 18         # 左上面板 rows 0..17 x cols 0..17（target_panel_static 的地界）


def panel_cells(g):
    """左上 18x18 面板逐格的颜色 {(行, 列): 色}。原抽象只留了 panel_pic 的计数（恒为 10），
    「面板逐格不变」（target_panel_static）在原状态上说不出任何话；生成器会把它按颜色拆成位掩码。"""
    return {(r, c): g[r][c] for r in range(PANEL_SIZE) for c in range(PANEL_SIZE)}


def vessel_cells(g):
    """容器 bbox 里逐格的颜色 {(行, 列): 色}；容器认不出返回 None。原抽象只留了色 15 的格（fill），
    其余颜料涂进容器后状态里看不出涂成了什么色，「容器 == 面板目标图」（levelup_needs_target_pic）也就说不出来。
    只读这一帧的像素（经 vessel 找 bbox）；生成器会把它按颜色拆成位掩码。"""
    b = vessel(g)
    if b is None:
        return None
    t, bo, l, r = b
    return {(rr, cc): g[rr][cc] for rr in range(t, bo + 1) for cc in range(l, r + 1)}


# 隐藏状态（修订 R1.1）：预算条的钟。bar_rule 的闭式 bar = 64 - round(64k/100) 里，
# k = 「自最近一次归零（RESET 或换关）以来的步数」。单看一帧的条长读不出 k：0.64 格/步，
# 相邻两步常常同长（例如 k=1 与 k=2 都是 63），下一步是 63 还是 62 取决于 k。
# 生成器在 run 开头、RESET 之后、换关之后把它归零；这里只做「每走一步加一」，
# 只用传进来的四个参数中的上一步隐藏量，不查 tid、步序、关卡号。
HIDDEN_INIT = {"k": 0}


def hidden_step(h, prev, action, nxt):
    return {"k": h["k"] + 1}
