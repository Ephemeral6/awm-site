/-
# BoardStatic —— 版面一关之内不变（**推论，由架构**）
（对应 `rule/世界怎么回应/board_static.py`）

Python 那边这是一条每步去测的规则（全语料 0 反例）。在模型里它**表示不出来会变**：
`step` 只拿到 `St`，`Board` 是只读的参数，于是整个世界（`World = Board × St`）走一步之后
那一半 `Board` 一定原样——下面这条定理就是这句话，证明只是把定义摊开。

**这条定理没有内容上的风险**，它的全部价值是把「版面不变」从一句每帧要测的话
换成一句「说都说不出来」的话。它在语料上站不站得住，归 Python 的 `board_static` 管。
-/
import Obj.World
import Step


/-- 整个世界走一步（没赢、没输时）。 -/
def stepWorld (w : World) (a : Act) : Option World :=
  match step w.1 w.2 a with
  | .ok s' => some (w.1, s')
  | _ => none

/-- **推论（由架构）**：整个世界走一步之后，版面那一半原样。 -/
theorem board_static (w w' : World) (a : Act) (h : stepWorld w a = some w') : w'.1 = w.1 := by
  unfold stepWorld at h
  split at h
  · cases h; rfl
  · cases h

#print axioms board_static

