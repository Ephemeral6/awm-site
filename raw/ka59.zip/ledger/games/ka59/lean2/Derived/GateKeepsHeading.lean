/-
# GateKeepsHeading —— 门带朝哪头长，走一步不变（**推论**）
（对应 `rule/世界怎么回应/gate_keeps_heading.py`）

Python 那边这是一条每步去测的规则。在模型里它**推得出来**：
点击不碰门带；方向动作只挪门带的位置（`moveTo` 只改 `r c`）、只数拍子（`tick` 只改 `count`）。
所以它不是一条独立的规则，是另外几条规则的写法推出来的——身份：推论。

它比 Python 那条说得多：Python 只能在两帧都读得出朝向时比，
这里连「数到 0、朝向藏起来」的那几拍也一起说了（模型带着隐藏的朝向）。
那半句在语料上有没有被驳倒，由每关的逐帧核对管：归零之后下一拍长出来的那一层要对得上。
-/
import Obj.World
import Step


/-- **推论**：走一步之后（没赢、没输），每一条门带朝哪头长和走之前一样。 -/
theorem gate_keeps_heading (b : Board) (s s' : St) (a : Act) (h : step b s a = .ok s') :
    s'.gates.map (·.dir) = s.gates.map (·.dir) := by
  have hclick : ∀ x y, (clickSelect b s x y).gates = s.gates := by
    intro x y
    unfold clickSelect
    split
    · split <;> rfl
    · rfl
  have hzip : ∀ {α β : Type} (l : List α) (f : α → β),
      ((List.range l.length).zip l).map (fun p => f p.2) = l.map f := by
    intro α β l f
    have h2 : ((List.range l.length).zip l).map Prod.snd = l := List.map_snd_zip (by simp)
    calc ((List.range l.length).zip l).map (fun p => f p.2)
        = (((List.range l.length).zip l).map Prod.snd).map f := by rw [List.map_map]; rfl
      _ = l.map f := by rw [h2]
  have hmove : ∀ (g : Gate) (l : List Cell), (g.moveTo l).dir = g.dir := by
    intro g l; cases l <;> rfl
  have hadv : (advance b s a).gates.map (·.dir) = s.gates.map (·.dir) := by
    cases a with
    | click x y => simp only [advance, St.tock, hclick]
    | dir d =>
      simp only [advance, St.tock, tickGates, List.map_map]
      have : ∀ (jg : Nat × Gate) (pos : List (List Cell)) (n : Nat),
          ((Gate.tick (jg.2.moveTo (pos.getD (n + jg.1) []))).dir) = jg.2.dir := by
        intro jg pos n; exact hmove _ _
      simp only [Function.comp_def, this]
      exact hzip s.gates (·.dir)
  unfold step finish at h
  split at h
  · cases h
  · split at h
    · cases h
    · cases h
      exact hadv

#print axioms gate_keeps_heading

