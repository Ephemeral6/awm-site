/-
# Levels/L0 —— 第 0 关（`lean2/export_levels.py` 生成，不要手改）

    L0_steps_len    这一关的路正好 14 步（切歪了会是空表，空表让下一条平凡为真）
    L0_trace        沿着真人走过的这条路，模型**每一帧都和观测对上**
                       ——只有开局那一帧是观测给的，后面 14 步全是模型自己算的
    L0_winnable     这一关走得通：见证就是这条路，再加上过关那一脚（row 3654）

路：被成绩单认证的那一段（第 11 段），row 3640 .. 3653；过关那一脚 row 3654。
这一关中间没有 RESET、条一次都没往回涨（导出时核过），所以**没用上**「重来放回开局」那条假设。
开局的门带（如果有）朝向都读得出，没有用整关口径补任何一位。
核过的步数：14（逐帧）+ 1（过关那一脚，只核「赢了」）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable


def L0_board : Board := board0

/-- 第 0 关的真实开局：**从语料第 3640 行那一帧读出来的**，不是手写的盘。已走 0 步。 -/
def L0_startWorld : World := (L0_board, startAt 3640 0)

/-- 开局到过关前一步，14 步。 -/
def L0_steps : List (Act × Seen) := playFrom 3640 14

theorem L0_steps_len : L0_steps.length = 14 := by
  decide +kernel

#eval match firstSplit L0_startWorld.1 L0_startWorld.2 L0_steps 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_steps.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L0_trace : traceOk L0_startWorld.1 L0_startWorld.2 L0_steps = true := by
  decide +kernel

/-- 这条路的动作，再加上过关那一脚。 -/
def L0_winSteps : List Act := L0_steps.map Prod.fst ++ [actAt 3654]

/-- **这一关走得通。** -/
theorem L0_winnable : Winnable L0_startWorld := ⟨L0_winSteps, by decide +kernel⟩

#print axioms L0_steps_len
#print axioms L0_trace
#print axioms L0_winnable

