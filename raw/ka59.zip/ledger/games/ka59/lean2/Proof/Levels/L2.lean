/-
# Levels/L2 —— 第 2 关（`lean2/export_levels.py` 生成，不要手改）

    L2_steps_len    这一关的路正好 46 步（切歪了会是空表，空表让下一条平凡为真）
    L2_trace        沿着真人走过的这条路，模型**每一帧都和观测对上**
                       ——只有开局那一帧是观测给的，后面 46 步全是模型自己算的
    L2_winnable     这一关走得通：见证就是这条路，再加上过关那一脚（row 3772）

路：被成绩单认证的那一段（第 11 段），row 3726 .. 3771；过关那一脚 row 3772。
这一关中间没有 RESET、条一次都没往回涨（导出时核过），所以**没用上**「重来放回开局」那条假设。
开局的门带（如果有）朝向都读得出，没有用整关口径补任何一位。
核过的步数：46（逐帧）+ 1（过关那一脚，只核「赢了」）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable


def L2_board : Board := board2

/-- 第 2 关的真实开局：**从语料第 3726 行那一帧读出来的**，不是手写的盘。已走 0 步。 -/
def L2_startWorld : World := (L2_board, startAt 3726 2)

/-- 开局到过关前一步，46 步。 -/
def L2_steps : List (Act × Seen) := playFrom 3726 46

theorem L2_steps_len : L2_steps.length = 46 := by
  decide +kernel

#eval match firstSplit L2_startWorld.1 L2_startWorld.2 L2_steps 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_steps.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L2_trace : traceOk L2_startWorld.1 L2_startWorld.2 L2_steps = true := by
  decide +kernel

/-- 这条路的动作，再加上过关那一脚。 -/
def L2_winSteps : List Act := L2_steps.map Prod.fst ++ [actAt 3772]

/-- **这一关走得通。** -/
theorem L2_winnable : Winnable L2_startWorld := ⟨L2_winSteps, by decide +kernel⟩

#print axioms L2_steps_len
#print axioms L2_trace
#print axioms L2_winnable

