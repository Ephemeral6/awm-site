/-
# Levels/L6 —— 第 6 关（`lean2/export_levels.py` 生成，不要手改）

    L6_steps_len    这一关的路正好 128 步（切歪了会是空表，空表让下一条平凡为真）
    L6_trace        沿着真人走过的这条路，模型**每一帧都和观测对上**
                       ——只有开局那一帧是观测给的，后面 128 步全是模型自己算的
    L6_winnable     这一关走得通：见证就是这条路，再加上过关那一脚（row 4060）

路：被成绩单认证的那一段（第 11 段），row 3932 .. 4059；过关那一脚 row 4060。
这一关中间没有 RESET、条一次都没往回涨（导出时核过），所以**没用上**「重来放回开局」那条假设。
开局有门带数到 0，朝向取**整关口径**（比玩家在开局那一帧多知道一位）：
    第 6 关开局第 0 条门带（数到 0）：朝向取第 3932 行之后那一帧，some (true, true)
    第 6 关开局第 1 条门带（数到 0）：朝向取第 3932 行之后那一帧，some (true, false)
核过的步数：128（逐帧）+ 1（过关那一脚，只核「赢了」）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable


def L6_board : Board := board6

/-- 第 6 关的真实开局：**从语料第 3932 行那一帧读出来的**，不是手写的盘。已走 0 步。 -/
def L6_startWorld : World := (L6_board, startAt 3932 6)

/-- 开局到过关前一步，128 步。 -/
def L6_steps : List (Act × Seen) := playFrom 3932 128

theorem L6_steps_len : L6_steps.length = 128 := by
  decide +kernel

#eval match firstSplit L6_startWorld.1 L6_startWorld.2 L6_steps 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_steps.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L6_trace : traceOk L6_startWorld.1 L6_startWorld.2 L6_steps = true := by
  decide +kernel

/-- 这条路的动作，再加上过关那一脚。 -/
def L6_winSteps : List Act := L6_steps.map Prod.fst ++ [actAt 4060]

/-- **这一关走得通。** -/
theorem L6_winnable : Winnable L6_startWorld := ⟨L6_winSteps, by decide +kernel⟩

#print axioms L6_steps_len
#print axioms L6_trace
#print axioms L6_winnable

