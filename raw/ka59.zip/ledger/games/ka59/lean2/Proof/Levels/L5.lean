/-
# Levels/L5 —— 第 5 关（`lean2/export_levels.py` 生成，不要手改）

    L5_steps_len    这一关的路正好 50 步（切歪了会是空表，空表让下一条平凡为真）
    L5_trace        沿着真人走过的这条路，模型**每一帧都和观测对上**
                       ——只有开局那一帧是观测给的，后面 50 步全是模型自己算的
    L5_winnable     这一关走得通：见证就是这条路，再加上过关那一脚（row 3931）

路：被成绩单认证的那一段（第 11 段），row 3881 .. 3930；过关那一脚 row 3931。
这一关中间没有 RESET、条一次都没往回涨（导出时核过），所以**没用上**「重来放回开局」那条假设。
开局有门带数到 0，朝向取**整关口径**（比玩家在开局那一帧多知道一位）：
    第 5 关开局第 0 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, true)
    第 5 关开局第 1 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, true)
    第 5 关开局第 2 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, false)
核过的步数：50（逐帧）+ 1（过关那一脚，只核「赢了」）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable


def L5_board : Board := board5

/-- 第 5 关的真实开局：**从语料第 3881 行那一帧读出来的**，不是手写的盘。已走 0 步。 -/
def L5_startWorld : World := (L5_board, startAt 3881 5)

/-- 开局到过关前一步，50 步。 -/
def L5_steps : List (Act × Seen) := playFrom 3881 50

theorem L5_steps_len : L5_steps.length = 50 := by
  decide +kernel

#eval match firstSplit L5_startWorld.1 L5_startWorld.2 L5_steps 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_steps.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是观测给的，后面全是它自己算的。 -/
theorem L5_trace : traceOk L5_startWorld.1 L5_startWorld.2 L5_steps = true := by
  decide +kernel

/-- 这条路的动作，再加上过关那一脚。 -/
def L5_winSteps : List Act := L5_steps.map Prod.fst ++ [actAt 3931]

/-- **这一关走得通。** -/
theorem L5_winnable : Winnable L5_startWorld := ⟨L5_winSteps, by decide +kernel⟩

#print axioms L5_steps_len
#print axioms L5_trace
#print axioms L5_winnable

