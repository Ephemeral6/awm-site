/-
# CountKey —— 一把「不可做」的钥匙：块和框不一样多

这一局七关全都走得通（每关都有 `_winnable`），没有一关要宣告不可做。
这一份是**钥匙本身**加它的三条防线，用来说明「不可做」在这套模型里是怎么证的，
以及骨架确实能证出东西——而不是一个对谁都说「不可做」的判据。

## 钥匙

    Φ(s) := 块的件数 ≠ 框的个数

    每步保持：走一步块的件数不变（推、扫、点击都只改位置和标记，不增不减）
    与赢矛盾：赢的定义（`LevelSolved`）要求块和框一样多

没有枚举、没有搜索、和盘面多大无关。

## 三条防线（用第 0 关的真盘）

    drop_unsolvable    第 0 关的盘**拿掉一个框** ⇒ 不经过 RESET 赢不了（钥匙套得上）
    real_winnable      第 0 关的真盘（只差那一个框）**走得通**（`L0_winnable`）
    real_closed_at_start 真盘开局不是一上来就已经嵌好了
    real_not_key       真盘上钥匙的前提**不满足**（块和框一样多）——套不上是「前提不成立」，不是「没找到证明」

## 「不经过 RESET」

`Unsolvable` 的意思是不经过 RESET 赢不了（见 `Proof/Reachable.lean`）。RESET 在这里也救不了：
它只会把局面放回开局，而开局的块数一样——但这半句**没有进模型**，只写在这里。
-/
import Obj.World
import Proof.Reachable
import Proof.Levels.L0


/-- 走一步块的件数不变（推、扫、点击都只改位置和标记）。 -/
theorem step_advance_count (b : Board) (s : St) (a : Act) :
    (advance b s a).pieces.length = s.pieces.length ∧ (∀ s', step b s a = .ok s' → s' = advance b s a)
      ∧ (step b s a = .won → solved b (advance b s a) = true) := by
  refine ⟨?_, ?_, ?_⟩
  · cases a with
    | click x y =>
      simp only [advance, St.tock]
      unfold clickSelect
      split
      · split
        · simp
        · rfl
      · rfl
    | dir d => simp [advance, St.tock]
  · intro s' h
    unfold step finish at h
    split at h
    · cases h
    · split at h
      · cases h
      · cases h; rfl
  · intro h
    unfold step finish at h
    split at h
    · assumption
    · split at h <;> cases h

/-- 钥匙：块的件数和框的个数不一样。 -/
abbrev Key (b : Board) (s : St) : Prop := s.pieces.length ≠ b.slots.length

theorem key_keep (b : Board) : ∀ s s' a, Key b s → step b s a = .ok s' → Key b s' := by
  intro s s' a hk h
  obtain ⟨hlen, hok, _⟩ := step_advance_count b s a
  rw [hok s' h, Key, hlen]
  exact hk

theorem key_no_win (b : Board) : ∀ s a, Key b s → step b s a ≠ .won := by
  intro s a hk h
  obtain ⟨hlen, _, hwon⟩ := step_advance_count b s a
  have hs := hwon h
  simp only [solved, allSeated, Bool.and_eq_true, beq_iff_eq] at hs
  rw [hlen] at hs
  exact hk hs.1

/-- 挂上骨架：块和框不一样多的局面，不经过 RESET 赢不了。 -/
theorem unsolvable_by_count (b : Board) (s : St) (h : Key b s) : Unsolvable ((b, s) : World) :=
  unsolvable_of_invariant b (Key b) (key_keep b) (key_no_win b) s h

-- ---------------------------------------------------------------- 防线：第 0 关的真盘 vs 拿掉一个框

def dropBoard : Board := { L0_board with slots := L0_board.slots.drop 1 }
def dropWorld : World := (dropBoard, L0_startWorld.2)

theorem drop_unsolvable : Unsolvable dropWorld :=
  unsolvable_by_count dropBoard L0_startWorld.2 (by decide +kernel)

theorem real_winnable : Winnable L0_startWorld := L0_winnable

theorem real_closed_at_start : solved L0_startWorld.1 L0_startWorld.2 = false := by
  decide +kernel

theorem real_not_key : ¬ Key L0_startWorld.1 L0_startWorld.2 := by
  decide +kernel

#print axioms step_advance_count
#print axioms key_keep
#print axioms key_no_win
#print axioms unsolvable_by_count
#print axioms drop_unsolvable
#print axioms real_winnable
#print axioms real_closed_at_start
#print axioms real_not_key

