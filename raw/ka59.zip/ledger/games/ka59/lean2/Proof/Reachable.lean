/-
# Reachable —— 这个**局面**做不做得了

    Winnable   w  :=  ∃ as, 照着走中途赢过
    Unsolvable w  :=  ∀ as, 照着走从没赢过

## 「不经过 RESET」这半句写在明处

`Act` 里没有 RESET（模型不描述它：重来之后是哪一帧，是历史，帧上读不出来）。
所以 `Unsolvable w` 的准确意思是**「不经过 RESET，任何动作串都赢不了」**。
`∀ as` 这个形状一个字都看不出这一点——所以写在这里，也写在页面上。

动作已经限死：`Dir` 只有这一局的四个方向，一步只挪一格；点击的坐标是任意的，
而点不中带壳块的点击什么也不改（`ClickSelects`）。

## 唯一的骨架

找一个性质 Φ：每走一步都还成立，而且和「赢」直接矛盾 ⇒ 从满足 Φ 的局面出发，任何动作串都赢不了。
**全文唯一一处归纳**，与盘面多大、动作串多长都无关，不枚举任何状态。
-/
import Obj.World
import Obs.Check


def Winnable (w : World) : Prop := ∃ as : List Act, everWon w.1 w.2 as = true

/-- **不经过 RESET**，任何动作串都赢不了。 -/
def Unsolvable (w : World) : Prop := ∀ as : List Act, everWon w.1 w.2 as = false

theorem not_both (w : World) (h1 : Winnable w) (h2 : Unsolvable w) : False := by
  obtain ⟨as, h⟩ := h1
  rw [h2 as] at h
  exact Bool.false_ne_true h

/-- 骨架：Φ 每步保持（`hkeep`），满足 Φ 的局面这一步赢不了（`hwin`）⇒ 不经过 RESET 赢不了。 -/
theorem unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, P s → step b s a = .ok s' → P s')
    (hwin : ∀ s a, P s → step b s a ≠ .won) :
    ∀ s : St, P s → Unsolvable ((b, s) : World) := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    show everWon b s (a :: t) = false
    unfold everWon
    cases hs : step b s a with
    | won => exact absurd hs (hwin s a hp)
    | over => rfl
    | ok s' => exact ih s' (hkeep s s' a hp hs)

#print axioms not_both
#print axioms unsolvable_of_invariant

