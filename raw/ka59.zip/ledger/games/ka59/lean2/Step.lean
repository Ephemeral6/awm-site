/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    点击          clickSelect，然后走一步预算
    方向动作      前面贴着东西 ? pushShove : moverStep
                  → 这一拍归零的门带扫人（strikeAll，按动作之前的拍数判归零）
                  → 门带数一拍（tickGates）→ 走一步预算
    之后          嵌好了 ⇒ won；否则条空了 ⇒ over；否则 ok

RESET 不在这里：「重来之后是哪一帧」模型说不出（开局是历史），
结果类型里也**不编一个出来**。它在 `Proof/Levels` 里是一条明写的假设。
-/
import Rule.Move.MoverSteps
import Rule.Move.PushShoves
import Rule.Move.ClickSelects
import Rule.World.GateStrikes
import Rule.World.GateTicks
import Rule.Outcome.LevelSolved
import Rule.Outcome.BarTicks
import Rule.Outcome.BarEmptyEnds


inductive Act where
  | dir (d : Dir)
  | click (x y : Nat)
deriving DecidableEq, Repr

inductive Res where
  | ok (s : St)
  | won
  | over
deriving DecidableEq, Repr

def Gate.moveTo (g : Gate) : List Cell → Gate
  | x :: _ => { g with r := x.r, c := x.c }
  | []     => g

def advance (b : Board) (s : St) : Act → St
  | .click x y => (clickSelect b s x y).tock
  | .dir d =>
      let pos := if (touched s d).isEmpty then moverStep b s d else pushShove b s d
      let pos := strikeAll b s.pieces.length s.gates pos
      let n := s.pieces.length
      { s with
        pieces := ((List.range n).zip s.pieces).map
                    (fun (ip : Nat × Piece) => { ip.2 with cells := pos.getD ip.1 ip.2.cells })
        gates := tickGates (((List.range s.gates.length).zip s.gates).map
                    (fun (jg : Nat × Gate) => jg.2.moveTo (pos.getD (n + jg.1) []))) }.tock

/-- 一步之后先问赢、再问输。（写成单独一个函数而不是 `let`：`let` 会让 `split` 进不去。） -/
def finish (b : Board) (s' : St) : Res :=
  if solved b s' then .won else if barEmpty b s' then .over else .ok s'

def step (b : Board) (s : St) (a : Act) : Res := finish b (advance b s a)

