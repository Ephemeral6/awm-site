/-
# GateTicks —— 门带数拍子（对应 `rule/世界怎么回应/gate_ticks.py`）

**这是定义。** 每个方向动作，每一条门带数一拍：(原来 + 1) mod 一圈的层数。
点击不数拍——`Step.lean` 里点击那一支根本不调它。
只改拍数，不改朝向、不改位置。
-/
import Obj.Derive.GateClock


def Gate.tick (g : Gate) : Gate := { g with count := (g.count + 1) % g.layers }

def tickGates (gs : List Gate) : List Gate := gs.map Gate.tick

