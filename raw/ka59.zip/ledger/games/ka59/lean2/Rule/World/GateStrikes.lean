/-
# GateStrikes —— 门带归零那一拍扫人（对应 `rule/世界怎么回应/gate_strikes.py`）

**这是定义。** 这一拍归零的每一条门带（按表里的顺序），在动作生效之后的位置上，
把它正前方 `REACH` 格以内、中间没有墙和带的块，朝它长的方向各按 `slide STRIKE` 扫走；
落点压到谁谁让开（带子自己不让）。

`STRIKE = 3`、`REACH = 3` 是这条规则的主张；语料里扫中人的带子全是 6 层的，
「3」「一格」「层数 ÷ 2」在这批语料上分不开——3 层的带子扫到人的那一步会把它们分开。
-/
import Obj.Derive.Slide
import Obj.Derive.Strike
import Obj.Derive.GateClock


def STRIKE : Nat := 3
def REACH : Nat := 3

/-- 第 j 条门带（在表里是第 np + j 样）这一拍扫不扫、扫谁。`np` = 块的件数。 -/
def strikeOne (b : Board) (np j : Nat) (g : Gate) (pos : List (List Cell)) : List (List Cell) :=
  if g.wraps then
    match g.growth, pos.getD (np + j) [] with
    | some D, top :: _ =>
        let hit := (List.range np).filter (fun i => inFront b top g.h g.w D (pos.getD i []) REACH)
        if hit.isEmpty then pos
        else cascade b D (np + j) (hit.foldl (fun p i => p.set i (slide b D STRIKE (p.getD i []))) pos) hit
    | _, _ => pos
  else pos

def strikeAll (b : Board) (np : Nat) (gates : List Gate) (pos : List (List Cell)) : List (List Cell) :=
  ((List.range gates.length).zip gates).foldl (fun p jg => strikeOne b np jg.1 jg.2 p) pos

