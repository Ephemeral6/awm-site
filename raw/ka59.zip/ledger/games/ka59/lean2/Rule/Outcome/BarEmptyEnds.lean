/-
# BarEmptyEnds —— 条走空判负（对应 `rule/什么算赢什么算砸/bar_empty_ends.py`）

**这是输的定义。** 一步之后条上一格不剩 ⇒ `over`。
`Step.lean` 先问赢、再问输：同一步里又赢又输的局面语料里没有，这个先后是一个没被检验过的选择，写在这里。
-/
import Obj.World
import Rule.Outcome.BarTicks


def barEmpty (b : Board) (s : St) : Bool := barOf b.budget s.used == 0

