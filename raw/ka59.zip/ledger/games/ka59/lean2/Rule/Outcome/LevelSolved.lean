/-
# LevelSolved —— 过关（对应 `rule/什么算赢什么算砸/level_solved.py`）

**这是赢的定义，不是一条要证的话。** 一步之后每一块都正好嵌进一个框、块和框一样多。
`Step.lean` 在这一步之后先问它：成立就是 `won`。
-/
import Obj.Derive.Seated


def solved (b : Board) (s : St) : Bool := allSeated b s

