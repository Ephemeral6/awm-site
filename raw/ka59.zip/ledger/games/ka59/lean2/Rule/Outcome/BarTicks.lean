/-
# BarTicks —— 预算条（对应 `rule/什么算赢什么算砸/bar_ticks.py`）

**这是定义。** 这一关总共 B 步，走了 u 步时条上剩 64·(B−u)/B 格，
四舍五入、恰好一半往下舍：`(2·64·(B−u) + B − 1) / (2B)`。
每个动作（点击也算）走一步：`tock`。

B 帧上读不出，是拟合的常数，住在 `Board.budget`（导出器写进去，出处在 `Obs/Replay.lean` 文件头）。
-/
import Obj.World


def barOf (B u : Nat) : Nat := (2 * (64 * (B - u)) + B - 1) / (2 * B)

def St.tock (s : St) : St := { s with used := s.used + 1 }

