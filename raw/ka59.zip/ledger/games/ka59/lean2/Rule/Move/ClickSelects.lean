/-
# ClickSelects —— 点击换操纵对象（对应 `rule/一步怎么走/click_selects.py`）

**这是定义。** `ACTION6:x,y`（x 列、y 行，像素）点中的那一格属于一块带壳的、
而且不是正被操纵的那一块 ⇒ 换成它；原来那一块卸任（`retired`），新的那一块不再算卸任。
否则什么都不变。点击不挪任何东西。

像素 → 格：`(y − pr) / 3`，再加上整体的 2（见 `Obj/Geometry/Cell.lean`）；
写成 `(y + 6 − pr) / 3` 免得自然数减法截断。
-/
import Obj.World


def clickCell (b : Board) (x y : Nat) : Cell := ⟨(y + 6 - b.pr) / 3, (x + 6 - b.pc) / 3⟩

def pieceAt (s : St) (x : Cell) : Option Nat :=
  (List.range s.pieces.length).find? (fun i => (s.pieces.getD i ⟨[], false, false⟩).cells.contains x)

def clickSelect (b : Board) (s : St) (x y : Nat) : St :=
  match pieceAt s (clickCell b x y) with
  | some i =>
      if (s.pieces.getD i ⟨[], false, false⟩).shelled && i != s.sel then
        { s with
          sel := i
          pieces := ((List.range s.pieces.length).zip s.pieces).map (fun (jp : Nat × Piece) =>
            if jp.1 == s.sel then { jp.2 with retired := true }
            else if jp.1 == i then { jp.2 with retired := false }
            else jp.2) }
      else s
  | none => s

