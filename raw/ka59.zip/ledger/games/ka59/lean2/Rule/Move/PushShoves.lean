/-
# PushShoves —— 推（对应 `rule/一步怎么走/push_shoves.py`）

**这是定义。** 被操纵那一块前面紧贴的那一排里有东西（块或门带）：它自己不动；
贴着的那几样各按 `slide KICK` 走，落点压到谁谁让开（`cascade`，推手自己不让）。

`KICK = 5` 是这条规则的主张（Python 那边写在 `derive/advance.py`，变异测试从那里下手）。
-/
import Rule.Move.MoverSteps
import Obj.Derive.Slide


def KICK : Nat := 5

/-- 被操纵那一块前面紧贴的那几样（表里的下标）。空表 = 这一步不是推。 -/
def touched (s : St) (d : Dir) : List Nat :=
  let strip := front s.mine d
  (List.range s.bodies.length).filter (fun i => i != s.sel && overlaps (s.bodies.getD i []) strip)

def pushShove (b : Board) (s : St) (d : Dir) : List (List Cell) :=
  let t := touched s d
  let pos := t.foldl (fun p i => p.set i (slide b d KICK (p.getD i []))) s.bodies
  cascade b d s.sel pos t

