/-
# MoverSteps —— 被操纵的那一块挪一格（对应 `rule/一步怎么走/mover_steps.py`）

**这是定义，不是定理。** 方向动作、前面那一排没贴着东西时：
那一排里有墙或带 ⇒ 不动；否则整块挪一格。别的东西一格不动。

贴着东西那一种归 `PushShoves`；两条的分界由 `Step.lean` 的分发定（`touched` 空不空）。
-/
import Obj.Derive.Things
import Obj.Derive.Space


/-- 被操纵那一块占的格。 -/
def St.mine (s : St) : List Cell := (s.pieces.getD s.sel ⟨[], false, false⟩).cells

def moverStep (b : Board) (s : St) (d : Dir) : List (List Cell) :=
  if (front s.mine d).any (fun y => b.isWall y || b.isBand y) then s.bodies
  else s.bodies.set s.sel (shiftAll s.mine d)

