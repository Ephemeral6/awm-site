/-
# Corpus/C10 —— 逐条：row 2500 .. 2749（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 243 条（其余 7 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 242, 'reset': 7, 'over': 1}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c10_stepCount : ((rowsIn 2500 2750).filter stepDescribed).length = 243 := by
  decide +kernel

theorem c10_stepAgrees : ((rowsIn 2500 2750).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C10 disagree=" ++ toString (disagreeRows 2500 2750)

#print axioms c10_stepCount
#print axioms c10_stepAgrees

