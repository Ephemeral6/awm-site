/-
# Corpus/C08 —— 逐条：row 2000 .. 2249（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 243 条（其余 7 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 243, 'reset': 7}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c08_stepCount : ((rowsIn 2000 2250).filter stepDescribed).length = 243 := by
  decide +kernel

theorem c08_stepAgrees : ((rowsIn 2000 2250).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C08 disagree=" ++ toString (disagreeRows 2000 2250)

#print axioms c08_stepCount
#print axioms c08_stepAgrees

