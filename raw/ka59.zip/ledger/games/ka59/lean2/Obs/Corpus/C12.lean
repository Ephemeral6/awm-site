/-
# Corpus/C12 —— 逐条：row 3000 .. 3249（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 240 条（其余 10 条是 RESET：模型不描述，不在这一层）。
标记：{'reset': 10, 'ok': 238, 'over': 1, 'levelup': 1}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c12_stepCount : ((rowsIn 3000 3250).filter stepDescribed).length = 240 := by
  decide +kernel

theorem c12_stepAgrees : ((rowsIn 3000 3250).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C12 disagree=" ++ toString (disagreeRows 3000 3250)

#print axioms c12_stepCount
#print axioms c12_stepAgrees

