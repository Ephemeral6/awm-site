/-
# Corpus/C01 —— 逐条：row 250 .. 499（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 242 条（其余 8 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 240, 'reset': 8, 'levelup': 2}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c01_stepCount : ((rowsIn 250 500).filter stepDescribed).length = 242 := by
  decide +kernel

theorem c01_stepAgrees : ((rowsIn 250 500).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C01 disagree=" ++ toString (disagreeRows 250 500)

#print axioms c01_stepCount
#print axioms c01_stepAgrees

