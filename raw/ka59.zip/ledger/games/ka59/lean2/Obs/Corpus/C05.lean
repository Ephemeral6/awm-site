/-
# Corpus/C05 —— 逐条：row 1250 .. 1499（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 240 条（其余 10 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 239, 'reset': 10, 'levelup': 1}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c05_stepCount : ((rowsIn 1250 1500).filter stepDescribed).length = 240 := by
  decide +kernel

theorem c05_stepAgrees : ((rowsIn 1250 1500).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C05 disagree=" ++ toString (disagreeRows 1250 1500)

#print axioms c05_stepCount
#print axioms c05_stepAgrees

