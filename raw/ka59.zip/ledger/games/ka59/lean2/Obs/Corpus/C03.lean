/-
# Corpus/C03 —— 逐条：row 750 .. 999（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 248 条（其余 2 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 242, 'over': 1, 'reset': 2, 'levelup': 5}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c03_stepCount : ((rowsIn 750 1000).filter stepDescribed).length = 248 := by
  decide +kernel

theorem c03_stepAgrees : ((rowsIn 750 1000).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C03 disagree=" ++ toString (disagreeRows 750 1000)

#print axioms c03_stepCount
#print axioms c03_stepAgrees

