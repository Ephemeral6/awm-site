/-
# Corpus/C16 —— 逐条：row 4000 .. 4060（`lean2/export_corpus.py` 生成，不要手改）

这一段 61 行，其中模型描述的 61 条（其余 0 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 60, 'levelup': 1}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c16_stepCount : ((rowsIn 4000 4061).filter stepDescribed).length = 61 := by
  decide +kernel

theorem c16_stepAgrees : ((rowsIn 4000 4061).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C16 disagree=" ++ toString (disagreeRows 4000 4061)

#print axioms c16_stepCount
#print axioms c16_stepAgrees

