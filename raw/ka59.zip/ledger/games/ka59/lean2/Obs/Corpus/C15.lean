/-
# Corpus/C15 —— 逐条：row 3750 .. 3999（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 250 条（其余 0 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 246, 'levelup': 4}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c15_stepCount : ((rowsIn 3750 4000).filter stepDescribed).length = 250 := by
  decide +kernel

theorem c15_stepAgrees : ((rowsIn 3750 4000).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C15 disagree=" ++ toString (disagreeRows 3750 4000)

#print axioms c15_stepCount
#print axioms c15_stepAgrees

