/-
# Corpus/C06 —— 逐条：row 1500 .. 1749（`lean2/export_corpus.py` 生成，不要手改）

这一段 250 行，其中模型描述的 241 条（其余 9 条是 RESET：模型不描述，不在这一层）。
标记：{'ok': 241, 'reset': 9}。

每一条都从**观测到的那一帧**起算（`Obs/Agree.lean` 的 `stepAgrees`）。
这一层是「每步都被拉回正轨」的那一把尺子；「只给开局、后面全靠自己算」的那一把在 `Proof/Levels/`。
-/
import Obj.World
import Obs.Agree


theorem c06_stepCount : ((rowsIn 1500 1750).filter stepDescribed).length = 241 := by
  decide +kernel

theorem c06_stepAgrees : ((rowsIn 1500 1750).filter stepDescribed).all stepAgrees = true := by
  decide +kernel

#eval "C06 disagree=" ++ toString (disagreeRows 1500 1750)

#print axioms c06_stepCount
#print axioms c06_stepAgrees

