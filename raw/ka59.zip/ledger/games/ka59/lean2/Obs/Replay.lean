/-
# Replay —— 整条轨迹，**只存这一份**（`lean2/export_replay.py` 生成，不要手改）

逐条那一层（`Obs/Corpus.lean`）和每关那一层（`Proof/Levels/*.lean`）都从这里切。

## 来源

    封存局 ka59-20260917，run ka59-0915-1722，原始轨迹 4061 行（去重转移 1698 条）
    被成绩单认证的是第 11 段；每关的见证路线**只从那一段取**

## 键

切片按 `row`（原始轨迹里第几行）。`step` 有 97 个重号、`seq` 有 1 个重号，
都不能当键；`row` 唯一（导出时数过）。

## 两个口径

    逐条口径   `frames` 里每一帧就是那一帧真正读到的：数到 0 的门带，朝向是 `none`
    整关口径   `headings` 给每关开局那几条门带的朝向——数到 0 的那几条取同一关后面
               第一次读得出朝向的那一帧（出处见下），这是**比玩家在开局那一帧多知道的一位**

    第 5 关开局第 0 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, true)
    第 5 关开局第 1 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, true)
    第 5 关开局第 2 条门带（数到 0）：朝向取第 3881 行之后那一帧，some (true, false)
    第 6 关开局第 0 条门带（数到 0）：朝向取第 3932 行之后那一帧，some (true, true)
    第 6 关开局第 1 条门带（数到 0）：朝向取第 3932 行之后那一帧，some (true, false)

## 一处拟合的常数

`Board.budget`（每关预算总步数）帧上读不出，取 `bar_ticks.py` 的表：{0: 100, 1: 128, 2: 100, 3: 128, 4: 100, 5: 150, 6: 200}。
-/
import Obs.Check



/-- 轨迹上一步的动作：模型描述的动作，或者 RESET（模型不描述它）。 -/
inductive RowAct where
  | act (a : Act)
  | reset
deriving DecidableEq, Repr

/-- 这一步不接手的那几类要**带标记留在语料里**，不删。 -/
inductive Tag where
  | ok | reset | levelup | over
deriving DecidableEq, Repr

structure Row where
  row : Nat
  lvl : Nat
  lvlNext : Nat
  seg : Nat
  prev : Seen
  act : RowAct
  next : Seen
  tag : Tag


-- ---------------------------------------------------------------- 每关的盘面（整关，一关之内不变）

def board0 : Board := { walls := [0, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430, 32513054, 32513054, 32513054, 32505886, 32513054, 32513054, 32513054, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430, 33554430], bands := [0, 0, 0, 0, 0, 0, 0, 0, 0, 24576, 24576, 24576, 24576, 24576, 24576, 24576], slots := [⟨[⟨11, 17⟩]⟩, ⟨[⟨13, 6⟩]⟩], pr := 0, pc := 0, budget := 100 }

def board1 : Board := { walls := [0, 33554430, 25166338, 25166338, 25166338, 25166338, 25166338, 25166338, 25166338, 25166338, 25165826, 33550338, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 33554430], bands := [0, 0, 8387584, 8387584, 8387584, 8387584, 8387584, 8387584, 8387584, 8387584, 8388604, 4092, 3584, 3584, 3584, 3584, 3584, 3584, 3584, 3584, 3584, 3584, 3584], slots := [⟨[⟨5, 5⟩, ⟨6, 5⟩]⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩]⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩]⟩, ⟨[⟨19, 19⟩]⟩], pr := 0, pc := 0, budget := 128 }

def board2 : Board := { walls := [16777215, 16777215, 16777215, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 16777215, 16777215, 16777215], bands := [], slots := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩]⟩, ⟨[⟨11, 13⟩]⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩]⟩], pr := 2, pc := 2, budget := 100 }

def board3 : Board := { walls := [16777215, 16777215, 16777215, 16777215, 14688255, 14688255, 14688255, 14688255, 14680071, 14680071, 14680071, 14680071, 14680071, 14680071, 16711687, 16711687, 16711687, 16711687, 16711687, 16711687, 16711687, 16777215, 16777215, 16777215], bands := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65528, 65528], slots := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩]⟩, ⟨[⟨11, 18⟩]⟩, ⟨[⟨19, 14⟩]⟩], pr := 2, pc := 2, budget := 128 }

def board4 : Board := { walls := [0, 33554430, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 25165826, 33554430], bands := [0, 0, 0, 0, 0, 16128, 16128, 16128, 16128, 0, 0, 4608, 4608, 4608, 4608, 4608, 4608, 4608, 4608, 4608, 7680], slots := [⟨[⟨11, 18⟩]⟩], pr := 0, pc := 0, budget := 100 }

def board5 : Board := { walls := [0, 33554430, 33554430, 25169926, 25169926, 25169926, 25230854, 25203206, 25203206, 25169926, 25169926, 25169926, 25169922, 25169922, 25165826, 25165826, 25165826, 27262986, 25165826, 29360122, 25165826, 25165826, 25165826, 33554430], bands := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8384508, 8384508], slots := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩]⟩, ⟨[⟨9, 18⟩]⟩], pr := 0, pc := 0, budget := 150 }

def board6 : Board := { walls := [0, 33554430, 25165826, 33553922, 25165826, 25165826, 25165826, 25165826, 25681666, 25428738, 25428738, 25166594, 25427970, 25428738, 33293058, 25166594, 25166594, 25166846, 25428990, 25427970, 25624578, 25165826, 25165826, 33554430], bands := [0, 0, 0, 0, 33280, 33280, 33280, 33280, 252, 0, 0, 0, 0, 0, 261120], slots := [⟨[⟨10, 10⟩, ⟨10, 11⟩]⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩]⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩]⟩], pr := 0, pc := 0, budget := 200 }

def boardOf : Nat → Board
  | 0 => board0
  | 1 => board1
  | 2 => board2
  | 3 => board3
  | 4 => board4
  | 5 => board5
  | 6 => board6
  | _ => board0

-- ---------------------------------------------------------------- 每一帧（逐条口径，去重）

def f0 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 64 }
def f1 : Seen := { pieces := [⟨[⟨11, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 63 }
def f2 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 63 }
def f3 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 62 }
def f4 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 61 }
def f5 : Seen := { pieces := [⟨[⟨11, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 61 }
def f6 : Seen := { pieces := [⟨[⟨10, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 60 }
def f7 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 60 }
def f8 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 59 }
def f9 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 58 }
def f10 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 57 }
def f11 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 56 }
def f12 : Seen := { pieces := [⟨[⟨9, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 55 }
def f13 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 54 }
def f14 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 53 }
def f15 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 52 }
def f16 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 51 }
def f17 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 50 }
def f18 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 49 }
def f19 : Seen := { pieces := [⟨[⟨10, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 48 }
def f20 : Seen := { pieces := [⟨[⟨11, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 47 }
def f21 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 47 }
def f22 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 46 }
def f23 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 45 }
def f24 : Seen := { pieces := [⟨[⟨12, 6⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 45 }
def f25 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 44 }
def f26 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 43 }
def f27 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 42 }
def f28 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 41 }
def f29 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 40 }
def f30 : Seen := { pieces := [⟨[⟨12, 6⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 40 }
def f31 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 39 }
def f32 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 38 }
def f33 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 38 }
def f34 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 37 }
def f35 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 36 }
def f36 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 36 }
def f37 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 35 }
def f38 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 34 }
def f39 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 33 }
def f40 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 32 }
def f41 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 31 }
def f42 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 30 }
def f43 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 29 }
def f44 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 28 }
def f45 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 27 }
def f46 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 26 }
def f47 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 25 }
def f48 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 24 }
def f49 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 63 }
def f50 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 63 }
def f51 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 62 }
def f52 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 61 }
def f53 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 61 }
def f54 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 60 }
def f55 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 59 }
def f56 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 58 }
def f57 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 57 }
def f58 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 56 }
def f59 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 61 }
def f60 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 16⟩], true, true, false⟩], gates := [], bar := 61 }
def f61 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, true⟩], gates := [], bar := 60 }
def f62 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 16⟩], true, true, false⟩], gates := [], bar := 60 }
def f63 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 16⟩], true, true, false⟩], gates := [], bar := 59 }
def f64 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 16⟩], true, true, false⟩], gates := [], bar := 58 }
def f65 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 15⟩], true, true, false⟩], gates := [], bar := 60 }
def f66 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 15⟩], true, true, false⟩], gates := [], bar := 59 }
def f67 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨13, 15⟩], true, true, false⟩], gates := [], bar := 58 }
def f68 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 15⟩], true, true, false⟩], gates := [], bar := 57 }
def f69 : Seen := { pieces := [⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨12, 10⟩], true, false, true⟩], gates := [], bar := 56 }
def f70 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨12, 10⟩], true, false, true⟩], gates := [], bar := 56 }
def f71 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 10⟩], true, false, true⟩], gates := [], bar := 55 }
def f72 : Seen := { pieces := [⟨[⟨12, 10⟩], true, false, true⟩, ⟨[⟨12, 17⟩], true, true, false⟩], gates := [], bar := 54 }
def f73 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 61 }
def f74 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 60 }
def f75 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 60 }
def f76 : Seen := { pieces := [⟨[⟨12, 6⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 59 }
def f77 : Seen := { pieces := [⟨[⟨12, 6⟩], true, false, true⟩, ⟨[⟨12, 16⟩], true, true, false⟩], gates := [], bar := 58 }
def f78 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨12, 6⟩], true, false, true⟩], gates := [], bar := 58 }
def f79 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 6⟩], true, false, true⟩], gates := [], bar := 57 }
def f80 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 6⟩], true, false, true⟩], gates := [], bar := 56 }
def f81 : Seen := { pieces := [⟨[⟨11, 17⟩], true, false, true⟩, ⟨[⟨12, 6⟩], true, true, false⟩], gates := [], bar := 56 }
def f82 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 64 }
def f83 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 63 }
def f84 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 63 }
def f85 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 62 }
def f86 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 62 }
def f87 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 61 }
def f88 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 61 }
def f89 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [], bar := 60 }
def f90 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f91 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f92 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f93 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 16⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f94 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f95 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f96 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f97 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f98 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 48 }
def f99 : Seen := { pieces := [⟨[⟨9, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 47 }
def f100 : Seen := { pieces := [⟨[⟨10, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 47 }
def f101 : Seen := { pieces := [⟨[⟨11, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 46 }
def f102 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 45 }
def f103 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 45 }
def f104 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 44 }
def f105 : Seen := { pieces := [⟨[⟨12, 6⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 44 }
def f106 : Seen := { pieces := [⟨[⟨12, 5⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 39 }
def f107 : Seen := { pieces := [⟨[⟨12, 6⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 38 }
def f108 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 38 }
def f109 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 37 }
def f110 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 36 }
def f111 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩], gates := [], bar := 36 }
def f112 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 35 }
def f113 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 35 }
def f114 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩], gates := [], bar := 23 }
def f115 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f116 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f117 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f118 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f119 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f120 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f121 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f122 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f123 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 12⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f124 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f125 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f126 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f127 : Seen := { pieces := [⟨[⟨12, 13⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f128 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f129 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f130 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f131 : Seen := { pieces := [⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f132 : Seen := { pieces := [⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f133 : Seen := { pieces := [⟨[⟨12, 18⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f134 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f135 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f136 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f137 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f138 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f139 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f140 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 63 }
def f141 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 63 }
def f142 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f143 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f144 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩, ⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f145 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f146 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f147 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f148 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f149 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩, ⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f150 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f151 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f152 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f153 : Seen := { pieces := [⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f154 : Seen := { pieces := [⟨[⟨15, 15⟩, ⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f155 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f156 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f157 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f158 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 17⟩, ⟨16, 18⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f159 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f160 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f161 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f162 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f163 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f164 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f165 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f166 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f167 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f168 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f169 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f170 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f171 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f172 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f173 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f174 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f175 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f176 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f177 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f178 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f179 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 39 }
def f180 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 38 }
def f181 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 37 }
def f182 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 36 }
def f183 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 35 }
def f184 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f185 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 33 }
def f186 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 32 }
def f187 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 31 }
def f188 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 30 }
def f189 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 29 }
def f190 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 28 }
def f191 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 27 }
def f192 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 26 }
def f193 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 25 }
def f194 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 24 }
def f195 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 23 }
def f196 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 22 }
def f197 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 21 }
def f198 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 20 }
def f199 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 19 }
def f200 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 18 }
def f201 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 17 }
def f202 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 16 }
def f203 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 15 }
def f204 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 14 }
def f205 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 13 }
def f206 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 12 }
def f207 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 11 }
def f208 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 10 }
def f209 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 9 }
def f210 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 8 }
def f211 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 7 }
def f212 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 6 }
def f213 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 5 }
def f214 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 4 }
def f215 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 3 }
def f216 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 2 }
def f217 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 1 }
def f218 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 0 }
def f219 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩, ⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f220 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f221 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f222 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f223 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f224 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f225 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f226 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f227 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 55 }
def f228 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 54 }
def f229 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f230 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f231 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f232 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 17⟩, ⟨17, 18⟩, ⟨18, 17⟩, ⟨18, 18⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f233 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f234 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f235 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f236 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩, ⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f237 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f238 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f239 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f240 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f241 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 55 }
def f242 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 54 }
def f243 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 53 }
def f244 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 52 }
def f245 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f246 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f247 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f248 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, true⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f249 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f250 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f251 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f252 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f253 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, true⟩, ⟨[⟨19, 16⟩, ⟨19, 17⟩, ⟨20, 16⟩, ⟨20, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f254 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 63 }
def f255 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩, ⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 63 }
def f256 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩, ⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f257 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f258 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f259 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f260 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩, ⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f261 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f262 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 59 }
def f263 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 58 }
def f264 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 57 }
def f265 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, true, false⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f266 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f267 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩, ⟨14, 16⟩, ⟨14, 17⟩], true, false, true⟩, ⟨[⟨17, 13⟩, ⟨18, 13⟩], true, true, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 55 }
def f268 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 13⟩], true, true, false⟩], gates := [], bar := 63 }
def f269 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 62 }
def f270 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [], bar := 62 }
def f271 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 61 }
def f272 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 61 }
def f273 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f274 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f275 : Seen := { pieces := [⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f276 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f277 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f278 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f279 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f280 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f281 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f282 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f283 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f284 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f285 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f286 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f287 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f288 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f289 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f290 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f291 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f292 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f293 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f294 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f295 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f296 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 39 }
def f297 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 38 }
def f298 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 37 }
def f299 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 36 }
def f300 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 35 }
def f301 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f302 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 33 }
def f303 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 32 }
def f304 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 31 }
def f305 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 30 }
def f306 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 29 }
def f307 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 28 }
def f308 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 27 }
def f309 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 26 }
def f310 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 25 }
def f311 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 24 }
def f312 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 23 }
def f313 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 22 }
def f314 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 21 }
def f315 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 20 }
def f316 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 19 }
def f317 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 18 }
def f318 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 17 }
def f319 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 16 }
def f320 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 15 }
def f321 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 14 }
def f322 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 13 }
def f323 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 12 }
def f324 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 11 }
def f325 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 10 }
def f326 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 9 }
def f327 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 8 }
def f328 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 7 }
def f329 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 6 }
def f330 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 5 }
def f331 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 4 }
def f332 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 3 }
def f333 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 2 }
def f334 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 1 }
def f335 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 0 }
def f336 : Seen := { pieces := [⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 9⟩], true, true, false⟩], gates := [], bar := 61 }
def f337 : Seen := { pieces := [⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 8⟩], true, true, false⟩], gates := [], bar := 60 }
def f338 : Seen := { pieces := [⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 7⟩], true, true, false⟩], gates := [], bar := 60 }
def f339 : Seen := { pieces := [⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 6⟩], true, true, false⟩], gates := [], bar := 59 }
def f340 : Seen := { pieces := [⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨13, 6⟩], true, false, true⟩], gates := [], bar := 58 }
def f341 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨13, 6⟩], true, false, true⟩], gates := [], bar := 58 }
def f342 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [], bar := 63 }
def f343 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 62 }
def f344 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 62 }
def f345 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 61 }
def f346 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 61 }
def f347 : Seen := { pieces := [⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f348 : Seen := { pieces := [⟨[⟨15, 15⟩, ⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f349 : Seen := { pieces := [⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, false, true⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f350 : Seen := { pieces := [⟨[⟨16, 7⟩, ⟨17, 7⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f351 : Seen := { pieces := [⟨[⟨16, 7⟩, ⟨17, 7⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f352 : Seen := { pieces := [⟨[⟨16, 7⟩, ⟨17, 7⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 17⟩, ⟨16, 18⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f353 : Seen := { pieces := [⟨[⟨16, 7⟩, ⟨17, 7⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f354 : Seen := { pieces := [⟨[⟨16, 7⟩, ⟨17, 7⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨17, 18⟩, ⟨17, 19⟩], true, true, false⟩], gates := [], bar := 57 }
def f355 : Seen := { pieces := [⟨[⟨16, 6⟩, ⟨17, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨17, 7⟩, ⟨17, 8⟩, ⟨18, 7⟩, ⟨18, 8⟩], true, false, false⟩, ⟨[⟨17, 18⟩, ⟨17, 19⟩], true, true, false⟩], gates := [], bar := 56 }
def f356 : Seen := { pieces := [⟨[⟨16, 6⟩, ⟨17, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, true, false⟩, ⟨[⟨17, 7⟩, ⟨17, 8⟩, ⟨18, 7⟩, ⟨18, 8⟩], true, false, false⟩], gates := [], bar := 56 }
def f357 : Seen := { pieces := [⟨[⟨16, 6⟩, ⟨17, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩, ⟨[⟨17, 7⟩, ⟨17, 8⟩, ⟨18, 7⟩, ⟨18, 8⟩], true, true, false⟩], gates := [], bar := 55 }
def f358 : Seen := { pieces := [⟨[⟨16, 6⟩, ⟨17, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩, ⟨[⟨18, 7⟩, ⟨18, 8⟩, ⟨19, 7⟩, ⟨19, 8⟩], true, true, false⟩], gates := [], bar := 55 }
def f359 : Seen := { pieces := [⟨[⟨16, 6⟩, ⟨17, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩, ⟨[⟨18, 6⟩, ⟨18, 7⟩, ⟨19, 6⟩, ⟨19, 7⟩], true, true, false⟩], gates := [], bar := 54 }
def f360 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩, ⟨[⟨18, 6⟩, ⟨18, 7⟩, ⟨19, 6⟩, ⟨19, 7⟩], true, true, false⟩], gates := [], bar := 54 }
def f361 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩, ⟨[⟨17, 6⟩, ⟨17, 7⟩, ⟨18, 6⟩, ⟨18, 7⟩], true, true, false⟩], gates := [], bar := 53 }
def f362 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 6⟩, ⟨16, 7⟩, ⟨17, 6⟩, ⟨17, 7⟩], true, true, false⟩, ⟨[⟨16, 8⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩], gates := [], bar := 53 }
def f363 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 6⟩, ⟨16, 7⟩, ⟨17, 6⟩, ⟨17, 7⟩], true, true, false⟩, ⟨[⟨16, 13⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩], gates := [], bar := 52 }
def f364 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 5⟩, ⟨16, 6⟩, ⟨17, 5⟩, ⟨17, 6⟩], true, true, false⟩, ⟨[⟨16, 13⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩], gates := [], bar := 52 }
def f365 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, true, false⟩, ⟨[⟨16, 13⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, false, true⟩], gates := [], bar := 51 }
def f366 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, true, false⟩], gates := [], bar := 51 }
def f367 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨15, 18⟩, ⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 50 }
def f368 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨15, 19⟩, ⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 50 }
def f369 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, false, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 49 }
def f370 : Seen := { pieces := [⟨[⟨8, 6⟩, ⟨9, 6⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 49 }
def f371 : Seen := { pieces := [⟨[⟨7, 6⟩, ⟨8, 6⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 48 }
def f372 : Seen := { pieces := [⟨[⟨6, 6⟩, ⟨7, 6⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 48 }
def f373 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 6⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 47 }
def f374 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, false, true⟩], gates := [], bar := 47 }
def f375 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨16, 13⟩], true, true, false⟩], gates := [], bar := 46 }
def f376 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨17, 13⟩], true, true, false⟩], gates := [], bar := 46 }
def f377 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨18, 13⟩], true, true, false⟩], gates := [], bar := 45 }
def f378 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 13⟩], true, true, false⟩], gates := [], bar := 45 }
def f379 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 44 }
def f380 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 15⟩], true, true, false⟩], gates := [], bar := 44 }
def f381 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 16⟩], true, true, false⟩], gates := [], bar := 43 }
def f382 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 17⟩], true, true, false⟩], gates := [], bar := 43 }
def f383 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 18⟩], true, true, false⟩], gates := [], bar := 42 }
def f384 : Seen := { pieces := [⟨[⟨6, 16⟩], true, true, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 64 }
def f385 : Seen := { pieces := [⟨[⟨7, 16⟩], true, true, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f386 : Seen := { pieces := [⟨[⟨8, 16⟩], true, true, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f387 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨9, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 62 }
def f388 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨10, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f389 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f390 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f391 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 14⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f392 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 13⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 59 }
def f393 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 14⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 58 }
def f394 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 58 }
def f395 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 57 }
def f396 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 56 }
def f397 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 56 }
def f398 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 19⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 55 }
def f399 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 20⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 54 }
def f400 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨10, 20⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 54 }
def f401 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 20⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 53 }
def f402 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 19⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 52 }
def f403 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 18⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 52 }
def f404 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 17⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 51 }
def f405 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 51 }
def f406 : Seen := { pieces := [⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 15⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 50 }
def f407 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 15⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 49 }
def f408 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 14⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 49 }
def f409 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 13⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 48 }
def f410 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 12⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 47 }
def f411 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 11⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 47 }
def f412 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 10⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 46 }
def f413 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨11, 10⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 45 }
def f414 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨11, 9⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 45 }
def f415 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨11, 8⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 44 }
def f416 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 44 }
def f417 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 8⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 43 }
def f418 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 8⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 42 }
def f419 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 9⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 42 }
def f420 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 10⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 41 }
def f421 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 11⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 40 }
def f422 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨13, 12⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 40 }
def f423 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 39 }
def f424 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨11, 12⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 38 }
def f425 : Seen := { pieces := [⟨[⟨11, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 64 }
def f426 : Seen := { pieces := [⟨[⟨11, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f427 : Seen := { pieces := [⟨[⟨11, 10⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f428 : Seen := { pieces := [⟨[⟨11, 11⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 62 }
def f429 : Seen := { pieces := [⟨[⟨11, 11⟩], true, true, false⟩, ⟨[⟨17, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 62 }
def f430 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨17, 11⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f431 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨17, 10⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f432 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨17, 9⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f433 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨17, 8⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f434 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 8⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 59 }
def f435 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 8⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 59 }
def f436 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 9⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 58 }
def f437 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 10⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 58 }
def f438 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 11⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 57 }
def f439 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 12⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 57 }
def f440 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨19, 12⟩], true, true, false⟩], gates := [], bar := 56 }
def f441 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 12⟩], true, true, false⟩], gates := [], bar := 56 }
def f442 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 55 }
def f443 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 55 }
def f444 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨19, 13⟩], true, true, false⟩], gates := [], bar := 54 }
def f445 : Seen := { pieces := [⟨[⟨11, 11⟩], true, false, true⟩, ⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 54 }
def f446 : Seen := { pieces := [⟨[⟨11, 11⟩], true, true, false⟩, ⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 53 }
def f447 : Seen := { pieces := [⟨[⟨11, 12⟩], true, true, false⟩, ⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 53 }
def f448 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 52 }
def f449 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨13, 12⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 52 }
def f450 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 51 }
def f451 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 51 }
def f452 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨12, 13⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 50 }
def f453 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨11, 13⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 50 }
def f454 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨11, 14⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 49 }
def f455 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨10, 14⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 49 }
def f456 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨9, 14⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 48 }
def f457 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨9, 14⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 48 }
def f458 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨9, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 47 }
def f459 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨9, 16⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 47 }
def f460 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨9, 17⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 46 }
def f461 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨10, 17⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 46 }
def f462 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 45 }
def f463 : Seen := { pieces := [⟨[⟨18, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 2⟩], bar := 64 }
def f464 : Seen := { pieces := [⟨[⟨17, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, none, 0⟩, ⟨12, 10, 2, 2, some (true, true), 3⟩], bar := 63 }
def f465 : Seen := { pieces := [⟨[⟨16, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 1⟩, ⟨12, 10, 2, 2, some (true, true), 4⟩], bar := 63 }
def f466 : Seen := { pieces := [⟨[⟨15, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 5⟩], bar := 62 }
def f467 : Seen := { pieces := [⟨[⟨17, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, none, 0⟩, ⟨12, 10, 2, 2, none, 0⟩], bar := 61 }
def f468 : Seen := { pieces := [⟨[⟨16, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 1⟩, ⟨12, 10, 2, 2, some (true, true), 1⟩], bar := 61 }
def f469 : Seen := { pieces := [⟨[⟨15, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 2⟩], bar := 60 }
def f470 : Seen := { pieces := [⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, none, 0⟩, ⟨12, 10, 2, 2, some (true, true), 3⟩], bar := 60 }
def f471 : Seen := { pieces := [⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 59 }
def f472 : Seen := { pieces := [⟨[⟨13, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 58 }
def f473 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 58 }
def f474 : Seen := { pieces := [⟨[⟨11, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 57 }
def f475 : Seen := { pieces := [⟨[⟨10, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 56 }
def f476 : Seen := { pieces := [⟨[⟨10, 12⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 56 }
def f477 : Seen := { pieces := [⟨[⟨10, 13⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 55 }
def f478 : Seen := { pieces := [⟨[⟨10, 14⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 54 }
def f479 : Seen := { pieces := [⟨[⟨10, 15⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 54 }
def f480 : Seen := { pieces := [⟨[⟨10, 16⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 53 }
def f481 : Seen := { pieces := [⟨[⟨10, 17⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 52 }
def f482 : Seen := { pieces := [⟨[⟨10, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 52 }
def f483 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 19⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 16, 2, 2, none, 0⟩], bar := 64 }
def f484 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 64 }
def f485 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 63 }
def f486 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 63 }
def f487 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 16⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 62 }
def f488 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 15⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 62 }
def f489 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 61 }
def f490 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 61 }
def f491 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 61 }
def f492 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 60 }
def f493 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 13⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 60 }
def f494 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 12⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 59 }
def f495 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨14, 12⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 59 }
def f496 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨14, 12⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 58 }
def f497 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 58 }
def f498 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨14, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 58 }
def f499 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 57 }
def f500 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨15, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 57 }
def f501 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 56 }
def f502 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 56 }
def f503 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 55 }
def f504 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 9⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 55 }
def f505 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 8⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 55 }
def f506 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 54 }
def f507 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨10, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 54 }
def f508 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 53 }
def f509 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 53 }
def f510 : Seen := { pieces := [⟨[⟨7, 4⟩, ⟨8, 3⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨9, 4⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 52 }
def f511 : Seen := { pieces := [⟨[⟨7, 4⟩, ⟨8, 3⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨9, 4⟩], false, false, false⟩, ⟨[⟨9, 5⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 52 }
def f512 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 5⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 52 }
def f513 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 51 }
def f514 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 51 }
def f515 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 8⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 50 }
def f516 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 9⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 50 }
def f517 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 49 }
def f518 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 49 }
def f519 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨14, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 49 }
def f520 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨14, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 48 }
def f521 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨15, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 48 }
def f522 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 47 }
def f523 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨17, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 47 }
def f524 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨17, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 16, 2, 2, some (true, false), 5⟩], bar := 47 }
def f525 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨17, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 16, 2, 2, none, 0⟩], bar := 46 }
def f526 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 46 }
def f527 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 12⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 16, 2, 2, some (true, false), 2⟩], bar := 45 }
def f528 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 13⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 16, 2, 2, some (true, false), 3⟩], bar := 45 }
def f529 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 16, 2, 2, some (true, false), 4⟩], bar := 44 }
def f530 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 16, 2, 2, some (true, false), 5⟩], bar := 44 }
def f531 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 16, 2, 2, none, 0⟩], bar := 44 }
def f532 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 43 }
def f533 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 16, 2, 2, some (true, false), 2⟩], bar := 43 }
def f534 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 16, 2, 2, some (true, false), 3⟩], bar := 42 }
def f535 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨16, 20⟩, ⟨17, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 64 }
def f536 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [], bar := 61 }
def f537 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 60 }
def f538 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f539 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f540 : Seen := { pieces := [⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f541 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f542 : Seen := { pieces := [⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f543 : Seen := { pieces := [⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f544 : Seen := { pieces := [⟨[⟨12, 18⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f545 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f546 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f547 : Seen := { pieces := [⟨[⟨12, 21⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f548 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f549 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f550 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f551 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨13, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f552 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f553 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f554 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f555 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f556 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f557 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f558 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f559 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f560 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f561 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f562 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f563 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 12⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f564 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f565 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f566 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f567 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f568 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f569 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f570 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f571 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f572 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f573 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 39 }
def f574 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 38 }
def f575 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 37 }
def f576 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 36 }
def f577 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 35 }
def f578 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f579 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨13, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f580 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 33 }
def f581 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 32 }
def f582 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 15⟩], true, true, false⟩], gates := [], bar := 63 }
def f583 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 16⟩], true, true, false⟩], gates := [], bar := 63 }
def f584 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 17⟩], true, true, false⟩], gates := [], bar := 62 }
def f585 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 18⟩], true, true, false⟩], gates := [], bar := 62 }
def f586 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 19⟩], true, true, false⟩], gates := [], bar := 61 }
def f587 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 20⟩], true, true, false⟩], gates := [], bar := 61 }
def f588 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 20⟩], true, true, false⟩], gates := [], bar := 60 }
def f589 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 20⟩], true, true, false⟩], gates := [], bar := 60 }
def f590 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨17, 20⟩], true, true, false⟩], gates := [], bar := 59 }
def f591 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 20⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f592 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f593 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f594 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 17⟩], true, true, false⟩], gates := [], bar := 61 }
def f595 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 17⟩], true, true, false⟩], gates := [], bar := 60 }
def f596 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 17⟩], true, true, false⟩], gates := [], bar := 61 }
def f597 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 17⟩], true, true, false⟩], gates := [], bar := 60 }
def f598 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 17⟩], true, true, false⟩], gates := [], bar := 59 }
def f599 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 16⟩], true, true, false⟩], gates := [], bar := 60 }
def f600 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 15⟩], true, true, false⟩], gates := [], bar := 60 }
def f601 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 15⟩], true, true, false⟩], gates := [], bar := 59 }
def f602 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 59 }
def f603 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 58 }
def f604 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 58 }
def f605 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 15⟩], true, true, false⟩], gates := [], bar := 57 }
def f606 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 16⟩], true, true, false⟩], gates := [], bar := 57 }
def f607 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 16⟩], true, true, false⟩], gates := [], bar := 56 }
def f608 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 17⟩], true, true, false⟩], gates := [], bar := 62 }
def f609 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 16⟩], true, true, false⟩], gates := [], bar := 61 }
def f610 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 15⟩], true, true, false⟩], gates := [], bar := 61 }
def f611 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 60 }
def f612 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 13⟩], true, true, false⟩], gates := [], bar := 60 }
def f613 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 13⟩], true, true, false⟩], gates := [], bar := 59 }
def f614 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 59 }
def f615 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 57 }
def f616 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 57 }
def f617 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 56 }
def f618 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 56 }
def f619 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 55 }
def f620 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 13⟩], true, true, false⟩], gates := [], bar := 55 }
def f621 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 54 }
def f622 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 54 }
def f623 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 53 }
def f624 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨18, 14⟩], true, true, false⟩], gates := [], bar := 53 }
def f625 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f626 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 15⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f627 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 15⟩], true, true, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 51 }
def f628 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 51 }
def f629 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 50 }
def f630 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 50 }
def f631 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 49 }
def f632 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 49 }
def f633 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 48 }
def f634 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 48 }
def f635 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 47 }
def f636 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 47 }
def f637 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 46 }
def f638 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 46 }
def f639 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 45 }
def f640 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 12⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 45 }
def f641 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 12⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 44 }
def f642 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 43 }
def f643 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 43 }
def f644 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 42 }
def f645 : Seen := { pieces := [⟨[⟨12, 13⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 41 }
def f646 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 41 }
def f647 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 40 }
def f648 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 40 }
def f649 : Seen := { pieces := [⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 39 }
def f650 : Seen := { pieces := [⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 39 }
def f651 : Seen := { pieces := [⟨[⟨12, 18⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 38 }
def f652 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩, ⟨[⟨12, 20⟩, ⟨12, 21⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 38 }
def f653 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 37 }
def f654 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 37 }
def f655 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 36 }
def f656 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 35 }
def f657 : Seen := { pieces := [⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨12, 21⟩, ⟨12, 22⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 21⟩, ⟨17, 22⟩, ⟨18, 21⟩, ⟨18, 22⟩], true, false, false⟩], gates := [], bar := 34 }
def f658 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨13, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f659 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f660 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f661 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f662 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f663 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f664 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f665 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f666 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f667 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f668 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f669 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 13⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f670 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 12⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f671 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f672 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f673 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f674 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f675 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f676 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f677 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f678 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f679 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f680 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 22⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 35 }
def f681 : Seen := { pieces := [⟨[⟨12, 22⟩], true, true, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f682 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩], gates := [], bar := 56 }
def f683 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩], gates := [], bar := 55 }
def f684 : Seen := { pieces := [⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩], gates := [], bar := 54 }
def f685 : Seen := { pieces := [⟨[⟨15, 15⟩, ⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩], gates := [], bar := 54 }
def f686 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩], gates := [], bar := 53 }
def f687 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 15⟩, ⟨16, 16⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f688 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 16⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f689 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 17⟩, ⟨16, 18⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f690 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 18⟩, ⟨16, 19⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f691 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 51 }
def f692 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 50 }
def f693 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 49 }
def f694 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 48 }
def f695 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 47 }
def f696 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 46 }
def f697 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 45 }
def f698 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 44 }
def f699 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 43 }
def f700 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 42 }
def f701 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 41 }
def f702 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 40 }
def f703 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 39 }
def f704 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 38 }
def f705 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 37 }
def f706 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 36 }
def f707 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 35 }
def f708 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 34 }
def f709 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 33 }
def f710 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 32 }
def f711 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 31 }
def f712 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 30 }
def f713 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 29 }
def f714 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 28 }
def f715 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 27 }
def f716 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 26 }
def f717 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 25 }
def f718 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 24 }
def f719 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 23 }
def f720 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 22 }
def f721 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 21 }
def f722 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 20 }
def f723 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 19 }
def f724 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 18 }
def f725 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 17 }
def f726 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 16 }
def f727 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 15 }
def f728 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 14 }
def f729 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 13 }
def f730 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 12 }
def f731 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 11 }
def f732 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 10 }
def f733 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 9 }
def f734 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 8 }
def f735 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 7 }
def f736 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 6 }
def f737 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 5 }
def f738 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 4 }
def f739 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 3 }
def f740 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 2 }
def f741 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 1 }
def f742 : Seen := { pieces := [⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨16, 19⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨21, 14⟩], true, false, true⟩, ⟨[⟨21, 16⟩, ⟨21, 17⟩, ⟨22, 16⟩, ⟨22, 17⟩], true, false, false⟩], gates := [], bar := 0 }
def f743 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨21, 14⟩], true, true, false⟩], gates := [], bar := 63 }
def f744 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 59 }
def f745 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f746 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 15⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 58 }
def f747 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f748 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 57 }
def f749 : Seen := { pieces := [⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f750 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 15⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 56 }
def f751 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f752 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 55 }
def f753 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨13, 17⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f754 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 54 }
def f755 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 53 }
def f756 : Seen := { pieces := [⟨[⟨12, 15⟩, ⟨12, 16⟩], true, false, false⟩, ⟨[⟨12, 17⟩], true, true, false⟩, ⟨[⟨16, 8⟩, ⟨17, 8⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩], gates := [], bar := 52 }
def f757 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 64 }
def f758 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨16, 20⟩, ⟨17, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 63 }
def f759 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨16, 19⟩, ⟨17, 19⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 63 }
def f760 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨16, 20⟩, ⟨17, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 63 }
def f761 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 62 }
def f762 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 62 }
def f763 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 62 }
def f764 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 61 }
def f765 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨16, 20⟩, ⟨17, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 61 }
def f766 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨17, 20⟩, ⟨18, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 61 }
def f767 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 20⟩, ⟨19, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 60 }
def f768 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 20⟩, ⟨20, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 60 }
def f769 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 19⟩, ⟨20, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 60 }
def f770 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 19⟩, ⟨20, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 60 }
def f771 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 19⟩, ⟨20, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 59 }
def f772 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 19⟩, ⟨20, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 59 }
def f773 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 20⟩, ⟨20, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 59 }
def f774 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 58 }
def f775 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 58 }
def f776 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 58 }
def f777 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 57 }
def f778 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨17, 22⟩, ⟨18, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 57 }
def f779 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 57 }
def f780 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 56 }
def f781 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 56 }
def f782 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 20⟩, ⟨20, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 56 }
def f783 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 55 }
def f784 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 55 }
def f785 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 55 }
def f786 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 54 }
def f787 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 54 }
def f788 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 54 }
def f789 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 53 }
def f790 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 53 }
def f791 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 53 }
def f792 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 52 }
def f793 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 52 }
def f794 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 52 }
def f795 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 52 }
def f796 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 51 }
def f797 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 51 }
def f798 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 51 }
def f799 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 50 }
def f800 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 50 }
def f801 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 50 }
def f802 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 49 }
def f803 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 49 }
def f804 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 49 }
def f805 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 48 }
def f806 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 48 }
def f807 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 48 }
def f808 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 47 }
def f809 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 46 }
def f810 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 45 }
def f811 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 45 }
def f812 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 45 }
def f813 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 44 }
def f814 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 44 }
def f815 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 44 }
def f816 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 44 }
def f817 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 43 }
def f818 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 43 }
def f819 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 43 }
def f820 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 42 }
def f821 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 42 }
def f822 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 42 }
def f823 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 41 }
def f824 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 41 }
def f825 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 41 }
def f826 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 40 }
def f827 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 40 }
def f828 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 40 }
def f829 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 39 }
def f830 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 39 }
def f831 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 39 }
def f832 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 38 }
def f833 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 38 }
def f834 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 38 }
def f835 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 37 }
def f836 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 37 }
def f837 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 37 }
def f838 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 36 }
def f839 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 36 }
def f840 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 36 }
def f841 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 36 }
def f842 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 35 }
def f843 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 35 }
def f844 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 35 }
def f845 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 34 }
def f846 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 34 }
def f847 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 34 }
def f848 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 33 }
def f849 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 33 }
def f850 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 33 }
def f851 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 32 }
def f852 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 32 }
def f853 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 32 }
def f854 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨18, 22⟩, ⟨19, 22⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 31 }
def f855 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 31 }
def f856 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 21⟩, ⟨20, 21⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 31 }
def f857 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩, ⟨[⟨19, 22⟩, ⟨20, 22⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 30 }
def f858 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨17, 20⟩, ⟨18, 20⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 64 }
def f859 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 19⟩, ⟨16, 19⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 61 }
def f860 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 18⟩, ⟨16, 18⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 61 }
def f861 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 17⟩, ⟨16, 17⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 60 }
def f862 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨12, 16⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 60 }
def f863 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨12, 15⟩, ⟨13, 15⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 60 }
def f864 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨12, 14⟩, ⟨13, 14⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 60 }
def f865 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 59 }
def f866 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨12, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 59 }
def f867 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 13⟩, ⟨11, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 59 }
def f868 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 13⟩, ⟨10, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 58 }
def f869 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨8, 13⟩, ⟨9, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 58 }
def f870 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨7, 13⟩, ⟨8, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 58 }
def f871 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, true, false⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, false, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 57 }
def f872 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 57 }
def f873 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨18, 13⟩, ⟨18, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 57 }
def f874 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 13⟩, ⟨17, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 56 }
def f875 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 14⟩, ⟨17, 15⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 56 }
def f876 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 15⟩, ⟨17, 16⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 56 }
def f877 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 55 }
def f878 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 15⟩, ⟨17, 16⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 55 }
def f879 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 55 }
def f880 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨17, 15⟩, ⟨17, 16⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 54 }
def f881 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨13, 16⟩, ⟨13, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 54 }
def f882 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨12, 16⟩, ⟨12, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 54 }
def f883 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨11, 16⟩, ⟨11, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 53 }
def f884 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨11, 17⟩, ⟨11, 18⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 53 }
def f885 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨11, 18⟩, ⟨11, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 53 }
def f886 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨11, 19⟩, ⟨11, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 52 }
def f887 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨10, 19⟩, ⟨10, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 52 }
def f888 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨9, 19⟩, ⟨9, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 52 }
def f889 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨8, 19⟩, ⟨8, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 52 }
def f890 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨7, 19⟩, ⟨7, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 51 }
def f891 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩, ⟨[⟨6, 19⟩, ⟨6, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 51 }
def f892 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨5, 19⟩, ⟨5, 20⟩], true, true, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 51 }
def f893 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, true, false⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 50 }
def f894 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, true, false⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 50 }
def f895 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 50 }
def f896 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 14⟩, ⟨7, 14⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 49 }
def f897 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨5, 14⟩, ⟨6, 14⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 49 }
def f898 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 14⟩], true, true, false⟩, ⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 49 }
def f899 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 14⟩], true, true, false⟩, ⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 48 }
def f900 : Seen := { pieces := [⟨[⟨4, 13⟩, ⟨5, 13⟩], true, true, false⟩, ⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 48 }
def f901 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨5, 13⟩, ⟨6, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 48 }
def f902 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 47 }
def f903 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨7, 13⟩, ⟨8, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 47 }
def f904 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨8, 13⟩, ⟨9, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 47 }
def f905 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨9, 13⟩, ⟨10, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 46 }
def f906 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 13⟩, ⟨11, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 46 }
def f907 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨12, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 45 }
def f908 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 45 }
def f909 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, false, true⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 45 }
def f910 : Seen := { pieces := [⟨[⟨4, 19⟩, ⟨4, 20⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 44 }
def f911 : Seen := { pieces := [⟨[⟨5, 19⟩, ⟨5, 20⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 44 }
def f912 : Seen := { pieces := [⟨[⟨6, 19⟩, ⟨6, 20⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 44 }
def f913 : Seen := { pieces := [⟨[⟨7, 19⟩, ⟨7, 20⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 44 }
def f914 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨8, 20⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 43 }
def f915 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨9, 19⟩, ⟨9, 20⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 43 }
def f916 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 19⟩, ⟨10, 20⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 43 }
def f917 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 19⟩, ⟨11, 20⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 42 }
def f918 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 18⟩, ⟨11, 19⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 42 }
def f919 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 17⟩, ⟨11, 18⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 42 }
def f920 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 16⟩, ⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 41 }
def f921 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 15⟩, ⟨11, 16⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 41 }
def f922 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 14⟩, ⟨11, 15⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 41 }
def f923 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, true, false⟩, ⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 40 }
def f924 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, true, false⟩, ⟨[⟨17, 13⟩, ⟨18, 13⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 40 }
def f925 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, false, true⟩, ⟨[⟨17, 13⟩, ⟨18, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 40 }
def f926 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, false, true⟩, ⟨[⟨17, 12⟩, ⟨18, 12⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 39 }
def f927 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, false, true⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 39 }
def f928 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 13⟩, ⟨11, 14⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 39 }
def f929 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 13⟩, ⟨12, 14⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 38 }
def f930 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 12⟩, ⟨12, 13⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 38 }
def f931 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 11⟩, ⟨12, 12⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 38 }
def f932 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 10⟩, ⟨12, 11⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 37 }
def f933 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 37 }
def f934 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 8⟩, ⟨12, 9⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 37 }
def f935 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 7⟩, ⟨12, 8⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 36 }
def f936 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 6⟩, ⟨12, 7⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 36 }
def f937 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 5⟩, ⟨12, 6⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 36 }
def f938 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 4⟩, ⟨12, 5⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 36 }
def f939 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 3⟩, ⟨12, 4⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 35 }
def f940 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨12, 2⟩, ⟨12, 3⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 35 }
def f941 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨11, 2⟩, ⟨11, 3⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 35 }
def f942 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 2⟩, ⟨10, 3⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 34 }
def f943 : Seen := { pieces := [⟨[⟨9, 2⟩, ⟨9, 3⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 34 }
def f944 : Seen := { pieces := [⟨[⟨9, 3⟩, ⟨9, 4⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 34 }
def f945 : Seen := { pieces := [⟨[⟨9, 4⟩, ⟨9, 5⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 33 }
def f946 : Seen := { pieces := [⟨[⟨9, 4⟩, ⟨9, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 33 }
def f947 : Seen := { pieces := [⟨[⟨10, 4⟩, ⟨10, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 33 }
def f948 : Seen := { pieces := [⟨[⟨11, 4⟩, ⟨11, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 32 }
def f949 : Seen := { pieces := [⟨[⟨12, 4⟩, ⟨12, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 32 }
def f950 : Seen := { pieces := [⟨[⟨12, 5⟩, ⟨12, 6⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 32 }
def f951 : Seen := { pieces := [⟨[⟨12, 6⟩, ⟨12, 7⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 31 }
def f952 : Seen := { pieces := [⟨[⟨12, 7⟩, ⟨12, 8⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 31 }
def f953 : Seen := { pieces := [⟨[⟨12, 8⟩, ⟨12, 9⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 31 }
def f954 : Seen := { pieces := [⟨[⟨12, 9⟩, ⟨12, 10⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 30 }
def f955 : Seen := { pieces := [⟨[⟨12, 10⟩, ⟨12, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 30 }
def f956 : Seen := { pieces := [⟨[⟨11, 10⟩, ⟨11, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 30 }
def f957 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨10, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 29 }
def f958 : Seen := { pieces := [⟨[⟨12, 8⟩], true, false, true⟩, ⟨[⟨12, 11⟩], true, true, false⟩], gates := [], bar := 63 }
def f959 : Seen := { pieces := [⟨[⟨12, 8⟩], true, false, true⟩, ⟨[⟨12, 10⟩], true, true, false⟩], gates := [], bar := 63 }
def f960 : Seen := { pieces := [⟨[⟨12, 8⟩], true, false, true⟩, ⟨[⟨12, 9⟩], true, true, false⟩], gates := [], bar := 62 }
def f961 : Seen := { pieces := [⟨[⟨11, 9⟩], true, true, false⟩, ⟨[⟨12, 8⟩], true, false, true⟩], gates := [], bar := 61 }
def f962 : Seen := { pieces := [⟨[⟨11, 8⟩], true, true, false⟩, ⟨[⟨12, 8⟩], true, false, true⟩], gates := [], bar := 61 }
def f963 : Seen := { pieces := [⟨[⟨11, 7⟩], true, true, false⟩, ⟨[⟨12, 8⟩], true, false, true⟩], gates := [], bar := 60 }
def f964 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 8⟩], true, false, true⟩], gates := [], bar := 60 }
def f965 : Seen := { pieces := [⟨[⟨12, 7⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩], gates := [], bar := 59 }
def f966 : Seen := { pieces := [⟨[⟨12, 7⟩], true, false, true⟩, ⟨[⟨12, 15⟩], true, true, false⟩], gates := [], bar := 58 }
def f967 : Seen := { pieces := [⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨12, 7⟩], true, false, true⟩], gates := [], bar := 58 }
def f968 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨12, 7⟩], true, false, true⟩], gates := [], bar := 57 }
def f969 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 7⟩], true, false, true⟩], gates := [], bar := 56 }
def f970 : Seen := { pieces := [⟨[⟨11, 17⟩], true, false, true⟩, ⟨[⟨12, 7⟩], true, true, false⟩], gates := [], bar := 56 }
def f971 : Seen := { pieces := [⟨[⟨11, 17⟩], true, false, true⟩, ⟨[⟨13, 7⟩], true, true, false⟩], gates := [], bar := 55 }
def f972 : Seen := { pieces := [⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 63 }
def f973 : Seen := { pieces := [⟨[⟨15, 15⟩, ⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f974 : Seen := { pieces := [⟨[⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 62 }
def f975 : Seen := { pieces := [⟨[⟨15, 17⟩, ⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f976 : Seen := { pieces := [⟨[⟨15, 18⟩, ⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 61 }
def f977 : Seen := { pieces := [⟨[⟨15, 19⟩, ⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f978 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, false, true⟩], gates := [], bar := 60 }
def f979 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨20, 14⟩], true, true, false⟩], gates := [], bar := 59 }
def f980 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 59 }
def f981 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 15⟩], true, true, false⟩], gates := [], bar := 58 }
def f982 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 16⟩], true, true, false⟩], gates := [], bar := 58 }
def f983 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 17⟩], true, true, false⟩], gates := [], bar := 57 }
def f984 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 18⟩], true, true, false⟩], gates := [], bar := 57 }
def f985 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, false, false⟩, ⟨[⟨19, 19⟩], true, true, false⟩], gates := [], bar := 56 }
def f986 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨17, 16⟩, ⟨17, 17⟩, ⟨18, 16⟩, ⟨18, 17⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 56 }
def f987 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨18, 16⟩, ⟨18, 17⟩, ⟨19, 16⟩, ⟨19, 17⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 55 }
def f988 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨18, 15⟩, ⟨18, 16⟩, ⟨19, 15⟩, ⟨19, 16⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 55 }
def f989 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨18, 14⟩, ⟨18, 15⟩, ⟨19, 14⟩, ⟨19, 15⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 54 }
def f990 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨18, 13⟩, ⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 54 }
def f991 : Seen := { pieces := [⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨17, 13⟩], true, false, false⟩, ⟨[⟨18, 12⟩, ⟨18, 13⟩, ⟨19, 12⟩, ⟨19, 13⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 53 }
def f992 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨18, 12⟩, ⟨18, 13⟩, ⟨19, 12⟩, ⟨19, 13⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 53 }
def f993 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨17, 12⟩, ⟨17, 13⟩, ⟨18, 12⟩, ⟨18, 13⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 52 }
def f994 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 12⟩, ⟨16, 13⟩, ⟨17, 12⟩, ⟨17, 13⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 52 }
def f995 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨15, 12⟩, ⟨15, 13⟩, ⟨16, 12⟩, ⟨16, 13⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 51 }
def f996 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨14, 12⟩, ⟨14, 13⟩, ⟨15, 12⟩, ⟨15, 13⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 51 }
def f997 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, false, false⟩, ⟨[⟨14, 12⟩, ⟨14, 13⟩, ⟨15, 12⟩, ⟨15, 13⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 50 }
def f998 : Seen := { pieces := [⟨[⟨12, 13⟩, ⟨13, 13⟩], true, true, false⟩, ⟨[⟨14, 12⟩, ⟨14, 13⟩, ⟨15, 12⟩, ⟨15, 13⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 50 }
def f999 : Seen := { pieces := [⟨[⟨12, 14⟩, ⟨13, 14⟩], true, true, false⟩, ⟨[⟨14, 12⟩, ⟨14, 13⟩, ⟨15, 12⟩, ⟨15, 13⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 49 }
def f1000 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, true, false⟩, ⟨[⟨14, 12⟩, ⟨14, 13⟩, ⟨15, 12⟩, ⟨15, 13⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 49 }
def f1001 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, true, false⟩, ⟨[⟨14, 7⟩, ⟨14, 8⟩, ⟨15, 7⟩, ⟨15, 8⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 48 }
def f1002 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 7⟩, ⟨14, 8⟩, ⟨15, 7⟩, ⟨15, 8⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 48 }
def f1003 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 47 }
def f1004 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 47 }
def f1005 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 6⟩, ⟨16, 7⟩, ⟨17, 6⟩, ⟨17, 7⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 46 }
def f1006 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 5⟩, ⟨16, 6⟩, ⟨17, 5⟩, ⟨17, 6⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 46 }
def f1007 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 45 }
def f1008 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 45 }
def f1009 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 20⟩, ⟨14, 21⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 44 }
def f1010 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 19⟩, ⟨14, 20⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 44 }
def f1011 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 18⟩, ⟨14, 19⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 43 }
def f1012 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 17⟩, ⟨14, 18⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 43 }
def f1013 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 16⟩, ⟨14, 17⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 42 }
def f1014 : Seen := { pieces := [⟨[⟨13, 14⟩, ⟨14, 14⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 42 }
def f1015 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 41 }
def f1016 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨16, 4⟩, ⟨16, 5⟩, ⟨17, 4⟩, ⟨17, 5⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 41 }
def f1017 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 4⟩, ⟨15, 5⟩, ⟨16, 4⟩, ⟨16, 5⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 40 }
def f1018 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 5⟩, ⟨15, 6⟩, ⟨16, 5⟩, ⟨16, 6⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 40 }
def f1019 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩, ⟨16, 7⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 39 }
def f1020 : Seen := { pieces := [⟨[⟨13, 8⟩, ⟨14, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 39 }
def f1021 : Seen := { pieces := [⟨[⟨8, 8⟩, ⟨9, 8⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 38 }
def f1022 : Seen := { pieces := [⟨[⟨8, 8⟩, ⟨9, 8⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 38 }
def f1023 : Seen := { pieces := [⟨[⟨7, 8⟩, ⟨8, 8⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 37 }
def f1024 : Seen := { pieces := [⟨[⟨6, 8⟩, ⟨7, 8⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 37 }
def f1025 : Seen := { pieces := [⟨[⟨5, 8⟩, ⟨6, 8⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 36 }
def f1026 : Seen := { pieces := [⟨[⟨5, 7⟩, ⟨6, 7⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 36 }
def f1027 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 6⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 35 }
def f1028 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, true, false⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 35 }
def f1029 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨15, 7⟩, ⟨15, 8⟩, ⟨16, 7⟩, ⟨16, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 34 }
def f1030 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, false, true⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 34 }
def f1031 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨14, 15⟩, ⟨14, 16⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 33 }
def f1032 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 15⟩, ⟨15, 16⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 33 }
def f1033 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 16⟩, ⟨15, 17⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 32 }
def f1034 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 17⟩, ⟨15, 18⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 32 }
def f1035 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 18⟩, ⟨15, 19⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 31 }
def f1036 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 19⟩, ⟨15, 20⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 31 }
def f1037 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, true, false⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, false, true⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 30 }
def f1038 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 7⟩, ⟨16, 8⟩, ⟨17, 7⟩, ⟨17, 8⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 30 }
def f1039 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 6⟩, ⟨16, 7⟩, ⟨17, 6⟩, ⟨17, 7⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 29 }
def f1040 : Seen := { pieces := [⟨[⟨5, 5⟩, ⟨6, 5⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨15, 21⟩], true, false, true⟩, ⟨[⟨16, 5⟩, ⟨16, 6⟩, ⟨17, 5⟩, ⟨17, 6⟩], true, true, false⟩, ⟨[⟨19, 19⟩], true, false, true⟩], gates := [], bar := 29 }
def f1041 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f1042 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨13, 16⟩], true, true, false⟩], gates := [], bar := 60 }
def f1043 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨14, 16⟩], true, true, false⟩], gates := [], bar := 59 }
def f1044 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 16⟩], true, true, false⟩], gates := [], bar := 58 }
def f1045 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 15⟩], true, true, false⟩], gates := [], bar := 58 }
def f1046 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 14⟩], true, true, false⟩], gates := [], bar := 57 }
def f1047 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 13⟩], true, true, false⟩], gates := [], bar := 56 }
def f1048 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 12⟩], true, true, false⟩], gates := [], bar := 56 }
def f1049 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 11⟩], true, true, false⟩], gates := [], bar := 55 }
def f1050 : Seen := { pieces := [⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 9⟩, ⟨14, 8⟩, ⟨14, 9⟩, ⟨14, 10⟩, ⟨15, 9⟩], false, false, false⟩, ⟨[⟨15, 10⟩], true, true, false⟩], gates := [], bar := 54 }
def f1051 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨15, 10⟩], true, true, false⟩], gates := [], bar := 54 }
def f1052 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨14, 10⟩], true, true, false⟩], gates := [], bar := 53 }
def f1053 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨13, 10⟩], true, true, false⟩], gates := [], bar := 52 }
def f1054 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨12, 10⟩], true, true, false⟩], gates := [], bar := 52 }
def f1055 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 10⟩], true, true, false⟩], gates := [], bar := 51 }
def f1056 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 11⟩], true, true, false⟩], gates := [], bar := 51 }
def f1057 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 12⟩], true, true, false⟩], gates := [], bar := 50 }
def f1058 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 13⟩], true, true, false⟩], gates := [], bar := 49 }
def f1059 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 14⟩], true, true, false⟩], gates := [], bar := 49 }
def f1060 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩], gates := [], bar := 48 }
def f1061 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩], gates := [], bar := 47 }
def f1062 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩], gates := [], bar := 47 }
def f1063 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, true, false⟩], gates := [], bar := 46 }
def f1064 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 19⟩], true, true, false⟩], gates := [], bar := 45 }
def f1065 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨11, 20⟩], true, true, false⟩], gates := [], bar := 45 }
def f1066 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨9, 18⟩, ⟨9, 19⟩, ⟨9, 20⟩, ⟨10, 19⟩], false, false, false⟩, ⟨[⟨10, 20⟩], true, true, false⟩], gates := [], bar := 44 }
def f1067 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨10, 20⟩], true, true, false⟩], gates := [], bar := 44 }
def f1068 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨9, 20⟩], true, true, false⟩], gates := [], bar := 43 }
def f1069 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩, ⟨[⟨8, 20⟩], true, true, false⟩], gates := [], bar := 42 }
def f1070 : Seen := { pieces := [⟨[⟨7, 20⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 42 }
def f1071 : Seen := { pieces := [⟨[⟨7, 19⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 41 }
def f1072 : Seen := { pieces := [⟨[⟨7, 18⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 40 }
def f1073 : Seen := { pieces := [⟨[⟨7, 17⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 40 }
def f1074 : Seen := { pieces := [⟨[⟨7, 16⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 39 }
def f1075 : Seen := { pieces := [⟨[⟨7, 15⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 38 }
def f1076 : Seen := { pieces := [⟨[⟨7, 14⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 38 }
def f1077 : Seen := { pieces := [⟨[⟨7, 13⟩], true, true, false⟩, ⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 37 }
def f1078 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 13⟩], true, true, false⟩, ⟨[⟨8, 14⟩, ⟨9, 13⟩, ⟨9, 14⟩, ⟨9, 15⟩, ⟨10, 14⟩], false, false, false⟩], gates := [], bar := 36 }
def f1079 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨8, 13⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 36 }
def f1080 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨9, 13⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 35 }
def f1081 : Seen := { pieces := [⟨[⟨8, 9⟩, ⟨9, 8⟩, ⟨9, 9⟩, ⟨9, 10⟩, ⟨10, 9⟩], false, false, false⟩, ⟨[⟨10, 13⟩], true, true, false⟩, ⟨[⟨13, 14⟩, ⟨14, 13⟩, ⟨14, 14⟩, ⟨14, 15⟩, ⟨15, 14⟩], false, false, false⟩], gates := [], bar := 35 }
def f1082 : Seen := { pieces := [⟨[⟨12, 8⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f1083 : Seen := { pieces := [⟨[⟨12, 9⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 63 }
def f1084 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 11⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 62 }
def f1085 : Seen := { pieces := [⟨[⟨12, 10⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 62 }
def f1086 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f1087 : Seen := { pieces := [⟨[⟨12, 12⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 61 }
def f1088 : Seen := { pieces := [⟨[⟨12, 13⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f1089 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 60 }
def f1090 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨12, 16⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 59 }
def f1091 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨12, 20⟩], true, false, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 59 }
def f1092 : Seen := { pieces := [⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨12, 20⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 58 }
def f1093 : Seen := { pieces := [⟨[⟨11, 20⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 58 }
def f1094 : Seen := { pieces := [⟨[⟨11, 19⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 57 }
def f1095 : Seen := { pieces := [⟨[⟨11, 18⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 57 }
def f1096 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 56 }
def f1097 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 56 }
def f1098 : Seen := { pieces := [⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨12, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 55 }
def f1099 : Seen := { pieces := [⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨17, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 55 }
def f1100 : Seen := { pieces := [⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨17, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 54 }
def f1101 : Seen := { pieces := [⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨17, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 54 }
def f1102 : Seen := { pieces := [⟨[⟨11, 18⟩], true, true, false⟩, ⟨[⟨17, 15⟩], true, false, true⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 53 }
def f1103 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 15⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 53 }
def f1104 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 14⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 52 }
def f1105 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 13⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 52 }
def f1106 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 12⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 51 }
def f1107 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 11⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 51 }
def f1108 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 10⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 50 }
def f1109 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 9⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 50 }
def f1110 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨17, 8⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 49 }
def f1111 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 8⟩], true, true, false⟩, ⟨[⟨18, 9⟩, ⟨19, 8⟩, ⟨19, 9⟩, ⟨19, 10⟩, ⟨20, 9⟩], false, false, false⟩], gates := [], bar := 49 }
def f1112 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 8⟩], true, true, false⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩], gates := [], bar := 48 }
def f1113 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨19, 8⟩], true, true, false⟩], gates := [], bar := 48 }
def f1114 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 8⟩], true, true, false⟩], gates := [], bar := 47 }
def f1115 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 9⟩], true, true, false⟩], gates := [], bar := 47 }
def f1116 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 10⟩], true, true, false⟩], gates := [], bar := 46 }
def f1117 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 11⟩], true, true, false⟩], gates := [], bar := 46 }
def f1118 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 12⟩], true, true, false⟩], gates := [], bar := 45 }
def f1119 : Seen := { pieces := [⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨18, 14⟩, ⟨19, 13⟩, ⟨19, 14⟩, ⟨19, 15⟩, ⟨20, 14⟩], false, false, false⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 45 }
def f1120 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨20, 13⟩], true, true, false⟩], gates := [], bar := 44 }
def f1121 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, false, true⟩, ⟨[⟨19, 13⟩], true, true, false⟩], gates := [], bar := 44 }
def f1122 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 18⟩], true, true, false⟩, ⟨[⟨19, 13⟩], true, false, true⟩], gates := [], bar := 43 }
def f1123 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨19, 13⟩], true, false, true⟩], gates := [], bar := 43 }
def f1124 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨19, 13⟩], true, false, true⟩], gates := [], bar := 42 }
def f1125 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨19, 13⟩], true, false, true⟩], gates := [], bar := 42 }
def f1126 : Seen := { pieces := [⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨16, 14⟩, ⟨17, 13⟩, ⟨17, 14⟩, ⟨17, 15⟩, ⟨18, 14⟩], false, false, false⟩, ⟨[⟨19, 13⟩], true, false, true⟩], gates := [], bar := 41 }
def f1127 : Seen := { pieces := [⟨[⟨11, 15⟩], true, false, true⟩, ⟨[⟨16, 14⟩, ⟨17, 13⟩, ⟨17, 14⟩, ⟨17, 15⟩, ⟨18, 14⟩], false, false, false⟩, ⟨[⟨19, 13⟩], true, true, false⟩], gates := [], bar := 41 }
def f1128 : Seen := { pieces := [⟨[⟨11, 15⟩], true, false, true⟩, ⟨[⟨16, 14⟩, ⟨17, 13⟩, ⟨17, 14⟩, ⟨17, 15⟩, ⟨18, 14⟩], false, false, false⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 40 }
def f1129 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, false, true⟩, ⟨[⟨19, 14⟩], true, true, false⟩], gates := [], bar := 40 }
def f1130 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 39 }
def f1131 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 39 }
def f1132 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨12, 16⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 38 }
def f1133 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨13, 16⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 38 }
def f1134 : Seen := { pieces := [⟨[⟨11, 14⟩, ⟨12, 13⟩, ⟨12, 14⟩, ⟨12, 15⟩, ⟨13, 14⟩], false, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 37 }
def f1135 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨13, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 37 }
def f1136 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨12, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 36 }
def f1137 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 36 }
def f1138 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨10, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 35 }
def f1139 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨9, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 35 }
def f1140 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 13⟩, ⟨7, 14⟩, ⟨7, 15⟩, ⟨8, 14⟩], false, false, false⟩, ⟨[⟨8, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 34 }
def f1141 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨8, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 34 }
def f1142 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨9, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 33 }
def f1143 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨10, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 33 }
def f1144 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨11, 15⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 32 }
def f1145 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨11, 16⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 32 }
def f1146 : Seen := { pieces := [⟨[⟨4, 14⟩, ⟨5, 13⟩, ⟨5, 14⟩, ⟨5, 15⟩, ⟨6, 14⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩, ⟨[⟨19, 14⟩], true, false, true⟩], gates := [], bar := 31 }
def f1147 : Seen := { pieces := [⟨[⟨17, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 5⟩], bar := 62 }
def f1148 : Seen := { pieces := [⟨[⟨18, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, none, 0⟩, ⟨12, 10, 2, 2, none, 0⟩], bar := 61 }
def f1149 : Seen := { pieces := [⟨[⟨18, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 1⟩, ⟨12, 10, 2, 2, some (true, true), 1⟩], bar := 61 }
def f1150 : Seen := { pieces := [⟨[⟨17, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 2⟩], bar := 60 }
def f1151 : Seen := { pieces := [⟨[⟨16, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, none, 0⟩, ⟨12, 10, 2, 2, some (true, true), 3⟩], bar := 60 }
def f1152 : Seen := { pieces := [⟨[⟨15, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 1⟩, ⟨12, 10, 2, 2, some (true, true), 4⟩], bar := 59 }
def f1153 : Seen := { pieces := [⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨11, 19, 1, 1, some (false, false), 2⟩, ⟨12, 10, 2, 2, some (true, true), 5⟩], bar := 58 }
def f1154 : Seen := { pieces := [⟨[⟨14, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 58 }
def f1155 : Seen := { pieces := [⟨[⟨13, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 57 }
def f1156 : Seen := { pieces := [⟨[⟨12, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 56 }
def f1157 : Seen := { pieces := [⟨[⟨11, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 56 }
def f1158 : Seen := { pieces := [⟨[⟨10, 11⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 55 }
def f1159 : Seen := { pieces := [⟨[⟨10, 12⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 54 }
def f1160 : Seen := { pieces := [⟨[⟨10, 13⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 54 }
def f1161 : Seen := { pieces := [⟨[⟨11, 13⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 53 }
def f1162 : Seen := { pieces := [⟨[⟨12, 13⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 52 }
def f1163 : Seen := { pieces := [⟨[⟨12, 14⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 52 }
def f1164 : Seen := { pieces := [⟨[⟨12, 15⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 51 }
def f1165 : Seen := { pieces := [⟨[⟨12, 16⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 51 }
def f1166 : Seen := { pieces := [⟨[⟨12, 17⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 50 }
def f1167 : Seen := { pieces := [⟨[⟨12, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 49 }
def f1168 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 49 }
def f1169 : Seen := { pieces := [⟨[⟨12, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨6, 19, 1, 1, none, 0⟩], bar := 48 }
def f1170 : Seen := { pieces := [⟨[⟨11, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨6, 19, 1, 1, some (false, false), 1⟩], bar := 47 }
def f1171 : Seen := { pieces := [⟨[⟨10, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨6, 19, 1, 1, some (false, false), 2⟩], bar := 47 }
def f1172 : Seen := { pieces := [⟨[⟨9, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨6, 19, 1, 1, none, 0⟩], bar := 46 }
def f1173 : Seen := { pieces := [⟨[⟨8, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨6, 19, 1, 1, some (false, false), 1⟩], bar := 45 }
def f1174 : Seen := { pieces := [⟨[⟨7, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨6, 19, 1, 1, some (false, false), 2⟩], bar := 45 }
def f1175 : Seen := { pieces := [⟨[⟨7, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨6, 19, 1, 1, none, 0⟩], bar := 44 }
def f1176 : Seen := { pieces := [⟨[⟨6, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨6, 19, 1, 1, some (false, false), 1⟩], bar := 44 }
def f1177 : Seen := { pieces := [⟨[⟨5, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨6, 19, 1, 1, some (false, false), 2⟩], bar := 43 }
def f1178 : Seen := { pieces := [⟨[⟨5, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨6, 19, 1, 1, none, 0⟩], bar := 42 }
def f1179 : Seen := { pieces := [⟨[⟨5, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 42 }
def f1180 : Seen := { pieces := [⟨[⟨6, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 2⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 41 }
def f1181 : Seen := { pieces := [⟨[⟨7, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 3⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 40 }
def f1182 : Seen := { pieces := [⟨[⟨8, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 4⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 40 }
def f1183 : Seen := { pieces := [⟨[⟨9, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 5⟩, ⟨11, 19, 1, 1, some (false, false), 2⟩], bar := 39 }
def f1184 : Seen := { pieces := [⟨[⟨10, 19⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, none, 0⟩, ⟨11, 19, 1, 1, none, 0⟩], bar := 38 }
def f1185 : Seen := { pieces := [⟨[⟨10, 18⟩], true, true, false⟩], gates := [⟨3, 10, 2, 2, some (true, true), 1⟩, ⟨11, 19, 1, 1, some (false, false), 1⟩], bar := 38 }
def f1186 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 19⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 64 }
def f1187 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 16, 2, 2, some (true, false), 2⟩], bar := 63 }
def f1188 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨18, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 63 }
def f1189 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨17, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 62 }
def f1190 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 18⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 62 }
def f1191 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 61 }
def f1192 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 16⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 61 }
def f1193 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 61 }
def f1194 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨11, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 59 }
def f1195 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨10, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 58 }
def f1196 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 58 }
def f1197 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 58 }
def f1198 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 9⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 57 }
def f1199 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 8⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 57 }
def f1200 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 56 }
def f1201 : Seen := { pieces := [⟨[⟨7, 5⟩, ⟨8, 4⟩, ⟨8, 5⟩, ⟨8, 6⟩, ⟨9, 5⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 56 }
def f1202 : Seen := { pieces := [⟨[⟨3, 5⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨5, 5⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 55 }
def f1203 : Seen := { pieces := [⟨[⟨3, 5⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨5, 5⟩], false, false, false⟩, ⟨[⟨8, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 55 }
def f1204 : Seen := { pieces := [⟨[⟨3, 5⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨5, 5⟩], false, false, false⟩, ⟨[⟨7, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 55 }
def f1205 : Seen := { pieces := [⟨[⟨3, 5⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨5, 5⟩], false, false, false⟩, ⟨[⟨6, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 54 }
def f1206 : Seen := { pieces := [⟨[⟨3, 5⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨4, 6⟩, ⟨5, 5⟩], false, false, false⟩, ⟨[⟨5, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 54 }
def f1207 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨5, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 53 }
def f1208 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨4, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 53 }
def f1209 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨5, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 52 }
def f1210 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨6, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 52 }
def f1211 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨7, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 52 }
def f1212 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨8, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 11, 2, 2, none, 0⟩], bar := 51 }
def f1213 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 51 }
def f1214 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 6⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 50 }
def f1215 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 7⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 50 }
def f1216 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 8⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 11, 2, 2, some (true, false), 4⟩], bar := 49 }
def f1217 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 9⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 11, 2, 2, some (true, false), 5⟩], bar := 49 }
def f1218 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨15, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 11, 2, 2, some (true, false), 1⟩], bar := 48 }
def f1219 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 11, 2, 2, some (true, false), 2⟩], bar := 48 }
def f1220 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨17, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 11, 2, 2, some (true, false), 3⟩], bar := 47 }
def f1221 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨17, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 16, 2, 2, some (true, false), 4⟩], bar := 47 }
def f1222 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 10⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 16, 2, 2, some (true, false), 5⟩], bar := 47 }
def f1223 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 11⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 16, 2, 2, none, 0⟩], bar := 46 }
def f1224 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 12⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 46 }
def f1225 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 13⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 16, 2, 2, some (true, false), 2⟩], bar := 45 }
def f1226 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 14⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 3⟩, ⟨7, 13, 2, 2, some (true, true), 3⟩, ⟨17, 16, 2, 2, some (true, false), 3⟩], bar := 45 }
def f1227 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 15⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 4⟩, ⟨7, 13, 2, 2, some (true, true), 4⟩, ⟨17, 16, 2, 2, some (true, false), 4⟩], bar := 44 }
def f1228 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨16, 16⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 5⟩, ⟨7, 13, 2, 2, some (true, true), 5⟩, ⟨17, 16, 2, 2, some (true, false), 5⟩], bar := 44 }
def f1229 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨11, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, none, 0⟩, ⟨7, 13, 2, 2, none, 0⟩, ⟨17, 16, 2, 2, none, 0⟩], bar := 44 }
def f1230 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨10, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 1⟩, ⟨7, 13, 2, 2, some (true, true), 1⟩, ⟨17, 16, 2, 2, some (true, false), 1⟩], bar := 43 }
def f1231 : Seen := { pieces := [⟨[⟨3, 4⟩, ⟨4, 3⟩, ⟨4, 4⟩, ⟨4, 5⟩, ⟨5, 4⟩], false, false, false⟩, ⟨[⟨9, 17⟩], true, true, false⟩], gates := [⟨7, 10, 2, 2, some (true, true), 2⟩, ⟨7, 13, 2, 2, some (true, true), 2⟩, ⟨17, 16, 2, 2, some (true, false), 2⟩], bar := 43 }
def f1232 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩, ⟨[⟨19, 13⟩, ⟨19, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 63 }
def f1233 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩, ⟨[⟨18, 13⟩, ⟨18, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 63 }
def f1234 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩, ⟨[⟨17, 13⟩, ⟨17, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 63 }
def f1235 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩, ⟨[⟨16, 13⟩, ⟨16, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 62 }
def f1236 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩, ⟨[⟨16, 14⟩, ⟨16, 15⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 62 }
def f1237 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 62 }
def f1238 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨15, 20⟩, ⟨16, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 61 }
def f1239 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 20⟩, ⟨17, 20⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 61 }
def f1240 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 19⟩, ⟨17, 19⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 61 }
def f1241 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 18⟩, ⟨17, 18⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 60 }
def f1242 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 17⟩, ⟨17, 17⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 60 }
def f1243 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 16⟩, ⟨17, 16⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 60 }
def f1244 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨16, 15⟩, ⟨17, 15⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 60 }
def f1245 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨17, 15⟩, ⟨18, 15⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 59 }
def f1246 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨17, 14⟩, ⟨18, 14⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 59 }
def f1247 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨17, 13⟩, ⟨18, 13⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 59 }
def f1248 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨17, 12⟩, ⟨18, 12⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 58 }
def f1249 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, false, true⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, true, false⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 58 }
def f1250 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨13, 15⟩, ⟨13, 16⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 58 }
def f1251 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨12, 15⟩, ⟨12, 16⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 57 }
def f1252 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 15⟩, ⟨11, 16⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 57 }
def f1253 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 16⟩, ⟨11, 17⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 57 }
def f1254 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 17⟩, ⟨11, 18⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 56 }
def f1255 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 18⟩, ⟨11, 19⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 56 }
def f1256 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 19⟩, ⟨11, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 56 }
def f1257 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 19⟩, ⟨10, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 55 }
def f1258 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 19⟩, ⟨9, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 55 }
def f1259 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨8, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 55 }
def f1260 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨7, 19⟩, ⟨7, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 54 }
def f1261 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 19⟩, ⟨6, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 54 }
def f1262 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨5, 19⟩, ⟨5, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 17, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 54 }
def f1263 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨5, 19⟩, ⟨5, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 53 }
def f1264 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 19⟩, ⟨6, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 53 }
def f1265 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨7, 19⟩, ⟨7, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 53 }
def f1266 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨8, 19⟩, ⟨8, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 52 }
def f1267 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 19⟩, ⟨9, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 52 }
def f1268 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 19⟩, ⟨10, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 52 }
def f1269 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 19⟩, ⟨11, 20⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 52 }
def f1270 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 18⟩, ⟨11, 19⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 51 }
def f1271 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 17⟩, ⟨11, 18⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 51 }
def f1272 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨11, 16⟩, ⟨11, 17⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 51 }
def f1273 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 16⟩, ⟨10, 17⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 50 }
def f1274 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 15⟩, ⟨10, 16⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 50 }
def f1275 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 14⟩, ⟨10, 15⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 50 }
def f1276 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 13⟩, ⟨10, 14⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 49 }
def f1277 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨10, 13⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 49 }
def f1278 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 11⟩, ⟨10, 12⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 49 }
def f1279 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, true, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 48 }
def f1280 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 48 }
def f1281 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨16, 11⟩, ⟨17, 11⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 48 }
def f1282 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 11⟩, ⟨16, 11⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 47 }
def f1283 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 11⟩, ⟨16, 11⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 47 }
def f1284 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 12⟩, ⟨16, 12⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 47 }
def f1285 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 13⟩, ⟨16, 13⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 46 }
def f1286 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 14⟩, ⟨16, 14⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 46 }
def f1287 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨15, 15⟩, ⟨16, 15⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 46 }
def f1288 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨12, 16⟩, ⟨13, 16⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 45 }
def f1289 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨11, 16⟩, ⟨12, 16⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 45 }
def f1290 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨10, 16⟩, ⟨11, 16⟩], true, true, false⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 45 }
def f1291 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 16⟩, ⟨10, 16⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 44 }
def f1292 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 15⟩, ⟨10, 15⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 44 }
def f1293 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 14⟩, ⟨10, 14⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 44 }
def f1294 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨9, 13⟩, ⟨10, 13⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 44 }
def f1295 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨8, 13⟩, ⟨9, 13⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 43 }
def f1296 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨7, 13⟩, ⟨8, 13⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 43 }
def f1297 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 13⟩, ⟨7, 13⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 43 }
def f1298 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨6, 14⟩, ⟨7, 14⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 42 }
def f1299 : Seen := { pieces := [⟨[⟨5, 6⟩, ⟨6, 5⟩, ⟨6, 6⟩, ⟨6, 7⟩, ⟨7, 6⟩], false, false, false⟩, ⟨[⟨5, 14⟩, ⟨6, 14⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 12, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 42 }
def f1300 : Seen := { pieces := [⟨[⟨5, 14⟩, ⟨6, 14⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 42 }
def f1301 : Seen := { pieces := [⟨[⟨6, 14⟩, ⟨7, 14⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 41 }
def f1302 : Seen := { pieces := [⟨[⟨6, 13⟩, ⟨7, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 41 }
def f1303 : Seen := { pieces := [⟨[⟨7, 13⟩, ⟨8, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 41 }
def f1304 : Seen := { pieces := [⟨[⟨8, 13⟩, ⟨9, 13⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 40 }
def f1305 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨9, 13⟩, ⟨10, 13⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 40 }
def f1306 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨10, 13⟩, ⟨11, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 40 }
def f1307 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 39 }
def f1308 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, false, true⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 39 }
def f1309 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 10⟩, ⟨10, 11⟩], true, true, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 39 }
def f1310 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨11, 10⟩, ⟨11, 11⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 38 }
def f1311 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 10⟩, ⟨12, 11⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 38 }
def f1312 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 38 }
def f1313 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 8⟩, ⟨12, 9⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 37 }
def f1314 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 7⟩, ⟨12, 8⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 37 }
def f1315 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 6⟩, ⟨12, 7⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 37 }
def f1316 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 5⟩, ⟨12, 6⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 36 }
def f1317 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 4⟩, ⟨12, 5⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 36 }
def f1318 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨11, 4⟩, ⟨11, 5⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 36 }
def f1319 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨11, 3⟩, ⟨11, 4⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 36 }
def f1320 : Seen := { pieces := [⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 3⟩, ⟨10, 4⟩], true, true, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 35 }
def f1321 : Seen := { pieces := [⟨[⟨9, 3⟩, ⟨9, 4⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 35 }
def f1322 : Seen := { pieces := [⟨[⟨9, 4⟩, ⟨9, 5⟩], true, true, false⟩, ⟨[⟨9, 6⟩, ⟨10, 5⟩, ⟨10, 6⟩, ⟨10, 7⟩, ⟨11, 6⟩], false, false, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 35 }
def f1323 : Seen := { pieces := [⟨[⟨9, 4⟩, ⟨9, 5⟩], true, true, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 34 }
def f1324 : Seen := { pieces := [⟨[⟨10, 4⟩, ⟨10, 5⟩], true, true, false⟩, ⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 34 }
def f1325 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨11, 4⟩, ⟨11, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 34 }
def f1326 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 4⟩, ⟨12, 5⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 33 }
def f1327 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 5⟩, ⟨12, 6⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 33 }
def f1328 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 6⟩, ⟨12, 7⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 33 }
def f1329 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 7⟩, ⟨12, 8⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 32 }
def f1330 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 8⟩, ⟨12, 9⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 32 }
def f1331 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, false, true⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 32 }
def f1332 : Seen := { pieces := [⟨[⟨10, 12⟩, ⟨11, 12⟩], true, true, false⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 31 }
def f1333 : Seen := { pieces := [⟨[⟨10, 11⟩, ⟨11, 11⟩], true, true, false⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 31 }
def f1334 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, true, false⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 31 }
def f1335 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, true, false⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 30 }
def f1336 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨12, 9⟩, ⟨12, 10⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 30 }
def f1337 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨12, 10⟩, ⟨12, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 30 }
def f1338 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨12, 11⟩, ⟨12, 12⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 29 }
def f1339 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨11, 11⟩, ⟨11, 12⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 29 }
def f1340 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨10, 11⟩, ⟨10, 12⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 29 }
def f1341 : Seen := { pieces := [⟨[⟨9, 11⟩, ⟨9, 12⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 28 }
def f1342 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, true, false⟩, ⟨[⟨10, 10⟩, ⟨11, 10⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 28 }
def f1343 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 10⟩, ⟨16, 10⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 28 }
def f1344 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 10⟩, ⟨16, 10⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 28 }
def f1345 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨16, 10⟩, ⟨17, 10⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 27 }
def f1346 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 10⟩, ⟨16, 10⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 27 }
def f1347 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 11⟩, ⟨16, 11⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 27 }
def f1348 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 12⟩, ⟨16, 12⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 26 }
def f1349 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 13⟩, ⟨16, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 26 }
def f1350 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 14⟩, ⟨16, 14⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 26 }
def f1351 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨15, 15⟩, ⟨16, 15⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 25 }
def f1352 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨16, 15⟩, ⟨17, 15⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 25 }
def f1353 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 15⟩, ⟨18, 15⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 1⟩, ⟨18, 16, 2, 2, some (true, false), 1⟩], bar := 25 }
def f1354 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 14⟩, ⟨18, 14⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 2⟩, ⟨18, 16, 2, 2, some (true, false), 2⟩], bar := 24 }
def f1355 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 13⟩, ⟨18, 13⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 3⟩, ⟨18, 16, 2, 2, some (true, false), 3⟩], bar := 24 }
def f1356 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 12⟩, ⟨18, 12⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 4⟩, ⟨18, 16, 2, 2, some (true, false), 4⟩], bar := 24 }
def f1357 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, false, true⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, true, false⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 23 }
def f1358 : Seen := { pieces := [⟨[⟨9, 10⟩, ⟨9, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, some (true, true), 5⟩, ⟨18, 16, 2, 2, some (true, false), 5⟩], bar := 23 }
def f1359 : Seen := { pieces := [⟨[⟨10, 10⟩, ⟨10, 11⟩], true, true, false⟩, ⟨[⟨14, 6⟩, ⟨15, 5⟩, ⟨15, 6⟩, ⟨15, 7⟩, ⟨16, 6⟩], false, false, false⟩, ⟨[⟨17, 11⟩, ⟨18, 11⟩], true, false, true⟩], gates := [⟨4, 7, 2, 2, none, 0⟩, ⟨18, 16, 2, 2, none, 0⟩], bar := 23 }

-- ---------------------------------------------------------------- 整条轨迹，按 row 排

def rows00 : List Row := [
  ⟨0, 0, 0, 0, f0, .act (.dir .up), f1, .ok⟩,
  ⟨1, 0, 0, 0, f1, .act (.dir .down), f2, .ok⟩,
  ⟨2, 0, 0, 0, f2, .act (.dir .left), f3, .ok⟩,
  ⟨3, 0, 0, 0, f3, .act (.dir .right), f4, .ok⟩,
  ⟨4, 0, 0, 0, f4, .act (.dir .up), f5, .ok⟩,
  ⟨5, 0, 0, 0, f5, .act (.dir .up), f6, .ok⟩,
  ⟨6, 0, 0, 0, f6, .act (.dir .up), f7, .ok⟩,
  ⟨7, 0, 0, 0, f7, .act (.dir .up), f8, .ok⟩,
  ⟨8, 0, 0, 0, f8, .act (.dir .up), f9, .ok⟩,
  ⟨9, 0, 0, 0, f9, .act (.dir .up), f9, .ok⟩,
  ⟨10, 0, 0, 0, f9, .act (.dir .up), f10, .ok⟩,
  ⟨11, 0, 0, 0, f10, .act (.dir .up), f11, .ok⟩,
  ⟨12, 0, 0, 0, f11, .act (.dir .up), f11, .ok⟩,
  ⟨13, 0, 0, 0, f11, .act (.dir .up), f12, .ok⟩,
  ⟨14, 0, 0, 0, f12, .act (.dir .right), f13, .ok⟩,
  ⟨15, 0, 0, 0, f13, .act (.dir .right), f13, .ok⟩,
  ⟨16, 0, 0, 0, f13, .act (.dir .right), f14, .ok⟩,
  ⟨17, 0, 0, 0, f14, .act (.dir .right), f15, .ok⟩,
  ⟨18, 0, 0, 0, f15, .act (.dir .right), f15, .ok⟩,
  ⟨19, 0, 0, 0, f15, .act (.dir .right), f16, .ok⟩,
  ⟨20, 0, 0, 0, f16, .act (.dir .right), f16, .ok⟩,
  ⟨21, 0, 0, 0, f16, .act (.dir .right), f17, .ok⟩,
  ⟨22, 0, 0, 0, f17, .act (.dir .right), f18, .ok⟩,
  ⟨23, 0, 0, 0, f18, .act (.dir .right), f18, .ok⟩,
  ⟨24, 0, 0, 0, f18, .act (.dir .down), f19, .ok⟩,
  ⟨25, 0, 0, 0, f19, .act (.dir .down), f20, .ok⟩,
  ⟨26, 0, 0, 0, f20, .act (.dir .down), f21, .ok⟩,
  ⟨27, 0, 0, 0, f21, .act (.dir .left), f22, .ok⟩,
  ⟨28, 0, 0, 0, f22, .act (.dir .left), f23, .ok⟩,
  ⟨29, 0, 0, 0, f23, .act (.dir .left), f24, .ok⟩,
  ⟨30, 0, 0, 0, f24, .act (.dir .left), f25, .ok⟩,
  ⟨31, 0, 0, 0, f25, .act (.dir .left), f25, .ok⟩,
  ⟨32, 0, 0, 0, f25, .act (.dir .left), f26, .ok⟩,
  ⟨33, 0, 0, 0, f26, .act (.dir .left), f27, .ok⟩,
  ⟨34, 0, 0, 0, f27, .act (.dir .left), f27, .ok⟩,
  ⟨35, 0, 0, 0, f27, .act (.dir .left), f28, .ok⟩,
  ⟨36, 0, 0, 0, f28, .act (.dir .left), f29, .ok⟩,
  ⟨37, 0, 0, 0, f29, .act (.dir .right), f30, .ok⟩,
  ⟨38, 0, 0, 0, f30, .act (.dir .right), f31, .ok⟩,
  ⟨39, 0, 0, 0, f31, .act (.dir .right), f32, .ok⟩,
  ⟨40, 0, 0, 0, f32, .act (.dir .right), f33, .ok⟩,
  ⟨41, 0, 0, 0, f33, .act (.dir .right), f34, .ok⟩,
  ⟨42, 0, 0, 0, f34, .act (.dir .right), f35, .ok⟩,
  ⟨43, 0, 0, 0, f35, .act (.dir .right), f36, .ok⟩,
  ⟨44, 0, 0, 0, f36, .act (.dir .right), f37, .ok⟩,
  ⟨45, 0, 0, 0, f37, .act (.dir .right), f37, .ok⟩,
  ⟨46, 0, 0, 0, f37, .act (.dir .right), f38, .ok⟩,
  ⟨47, 0, 0, 0, f38, .act (.dir .right), f39, .ok⟩,
  ⟨48, 0, 0, 0, f39, .act (.dir .right), f39, .ok⟩,
  ⟨49, 0, 0, 0, f39, .act (.dir .right), f40, .ok⟩,
  ⟨50, 0, 0, 0, f40, .act (.dir .right), f41, .ok⟩,
  ⟨51, 0, 0, 0, f41, .act (.dir .right), f41, .ok⟩,
  ⟨52, 0, 0, 0, f41, .act (.dir .right), f42, .ok⟩,
  ⟨53, 0, 0, 0, f42, .act (.dir .right), f43, .ok⟩,
  ⟨54, 0, 0, 0, f43, .act (.dir .right), f43, .ok⟩,
  ⟨55, 0, 0, 0, f43, .act (.dir .right), f44, .ok⟩,
  ⟨56, 0, 0, 0, f44, .act (.dir .right), f44, .ok⟩,
  ⟨57, 0, 0, 0, f44, .act (.dir .up), f45, .ok⟩,
  ⟨58, 0, 0, 0, f45, .act (.dir .up), f46, .ok⟩,
  ⟨59, 0, 0, 0, f46, .act (.dir .up), f46, .ok⟩,
  ⟨60, 0, 0, 0, f46, .act (.dir .up), f47, .ok⟩,
  ⟨61, 0, 0, 0, f47, .act (.dir .up), f48, .ok⟩,
  ⟨62, 0, 0, 0, f48, .act (.dir .up), f48, .ok⟩,
  ⟨63, 0, 0, 0, f48, .reset, f0, .reset⟩,
  ⟨64, 0, 0, 0, f0, .act (.dir .right), f49, .ok⟩,
  ⟨65, 0, 0, 0, f49, .act (.dir .right), f50, .ok⟩,
  ⟨66, 0, 0, 0, f50, .act (.dir .right), f51, .ok⟩,
  ⟨67, 0, 0, 0, f51, .act (.dir .right), f52, .ok⟩,
  ⟨68, 0, 0, 0, f52, .act (.dir .right), f53, .ok⟩,
  ⟨69, 0, 0, 0, f53, .act (.dir .right), f54, .ok⟩,
  ⟨70, 0, 0, 0, f54, .act (.dir .up), f54, .ok⟩,
  ⟨71, 0, 0, 0, f54, .act (.dir .up), f55, .ok⟩,
  ⟨72, 0, 0, 0, f55, .act (.dir .up), f56, .ok⟩,
  ⟨73, 0, 0, 0, f56, .act (.dir .up), f56, .ok⟩,
  ⟨74, 0, 0, 0, f56, .act (.dir .up), f57, .ok⟩,
  ⟨75, 0, 0, 0, f57, .act (.dir .up), f58, .ok⟩,
  ⟨76, 0, 0, 0, f58, .reset, f0, .reset⟩,
  ⟨77, 0, 0, 0, f0, .act (.dir .right), f49, .ok⟩,
  ⟨78, 0, 0, 0, f49, .act (.dir .right), f50, .ok⟩,
  ⟨79, 0, 0, 0, f50, .act (.dir .right), f51, .ok⟩,
  ⟨80, 0, 0, 0, f51, .act (.click 34 13), f59, .ok⟩,
  ⟨81, 0, 0, 0, f59, .act (.click 43 31), f60, .ok⟩,
  ⟨82, 0, 0, 0, f60, .act (.click 25 31), f61, .ok⟩,
  ⟨83, 0, 0, 0, f61, .act (.click 46 28), f61, .ok⟩,
  ⟨84, 0, 0, 0, f61, .reset, f0, .reset⟩,
  ⟨85, 0, 0, 0, f0, .act (.dir .right), f49, .ok⟩,
  ⟨86, 0, 0, 0, f49, .act (.dir .right), f50, .ok⟩,
  ⟨87, 0, 0, 0, f50, .act (.dir .right), f51, .ok⟩,
  ⟨88, 0, 0, 0, f51, .act (.click 46 28), f59, .ok⟩,
  ⟨89, 0, 0, 0, f59, .act (.dir .up), f59, .ok⟩,
  ⟨90, 0, 0, 0, f59, .act (.click 44 30), f62, .ok⟩,
  ⟨91, 0, 0, 0, f62, .act (.click 44 30), f62, .ok⟩,
  ⟨92, 0, 0, 0, f62, .act (.click 43 31), f63, .ok⟩,
  ⟨93, 0, 0, 0, f63, .act (.click 44 30), f64, .ok⟩,
  ⟨94, 0, 0, 0, f64, .reset, f0, .reset⟩,
  ⟨95, 0, 0, 0, f0, .act (.dir .right), f49, .ok⟩,
  ⟨96, 0, 0, 0, f49, .act (.dir .right), f50, .ok⟩,
  ⟨97, 0, 0, 0, f50, .act (.dir .right), f51, .ok⟩,
  ⟨98, 0, 0, 0, f51, .act (.click 44 30), f60, .ok⟩,
  ⟨99, 0, 0, 0, f60, .act (.click 44 30), f60, .ok⟩,
  ⟨100, 0, 0, 0, f60, .act (.click 45 30), f62, .ok⟩,
  ⟨101, 0, 0, 0, f62, .act (.dir .left), f65, .ok⟩,
  ⟨102, 0, 0, 0, f65, .act (.dir .left), f66, .ok⟩,
  ⟨103, 0, 0, 0, f66, .act (.dir .down), f67, .ok⟩,
  ⟨104, 0, 0, 0, f67, .act (.dir .left), f67, .ok⟩,
  ⟨105, 0, 0, 0, f67, .act (.dir .up), f68, .ok⟩,
  ⟨106, 0, 0, 0, f68, .act (.dir .up), f69, .ok⟩,
  ⟨107, 0, 0, 0, f69, .act (.dir .right), f70, .ok⟩,
  ⟨108, 0, 0, 0, f70, .act (.dir .right), f71, .ok⟩,
  ⟨109, 0, 0, 0, f71, .act (.dir .down), f72, .ok⟩,
  ⟨110, 0, 0, 0, f72, .act (.click 44 30), f72, .ok⟩,
  ⟨111, 0, 0, 0, f72, .reset, f0, .reset⟩,
  ⟨112, 0, 0, 0, f0, .act (.dir .right), f49, .ok⟩,
  ⟨113, 0, 0, 0, f49, .act (.dir .right), f50, .ok⟩,
  ⟨114, 0, 0, 0, f50, .act (.dir .right), f51, .ok⟩,
  ⟨115, 0, 0, 0, f51, .act (.dir .down), f59, .ok⟩,
  ⟨116, 0, 0, 0, f59, .act (.dir .left), f73, .ok⟩,
  ⟨117, 0, 0, 0, f73, .act (.dir .left), f74, .ok⟩,
  ⟨118, 0, 0, 0, f74, .act (.dir .left), f75, .ok⟩,
  ⟨119, 0, 0, 0, f75, .act (.dir .left), f76, .ok⟩,
  ⟨120, 0, 0, 0, f76, .act (.click 43 31), f77, .ok⟩,
  ⟨121, 0, 0, 0, f77, .act (.dir .up), f78, .ok⟩,
  ⟨122, 0, 0, 0, f78, .act (.dir .right), f79, .ok⟩,
  ⟨123, 0, 0, 0, f79, .act (.click 13 34), f80, .ok⟩,
  ⟨124, 0, 0, 0, f80, .act (.click 13 31), f81, .ok⟩,
  ⟨125, 0, 1, 0, f81, .act (.dir .down), f82, .levelup⟩,
  ⟨126, 1, 1, 0, f82, .act (.click 46 28), f83, .ok⟩,
  ⟨127, 1, 1, 0, f83, .act (.dir .up), f84, .ok⟩,
  ⟨128, 1, 1, 0, f84, .act (.dir .down), f85, .ok⟩,
  ⟨129, 1, 1, 0, f85, .act (.dir .left), f86, .ok⟩,
  ⟨130, 1, 1, 0, f86, .act (.dir .right), f87, .ok⟩,
  ⟨131, 1, 1, 0, f87, .act (.dir .up), f88, .ok⟩,
  ⟨132, 1, 1, 0, f88, .act (.dir .up), f89, .ok⟩,
  ⟨133, 1, 1, 0, f89, .act (.dir .up), f90, .ok⟩,
  ⟨134, 1, 1, 0, f90, .act (.dir .up), f91, .ok⟩,
  ⟨135, 1, 1, 0, f91, .act (.dir .right), f92, .ok⟩,
  ⟨136, 1, 1, 0, f92, .act (.dir .right), f93, .ok⟩,
  ⟨137, 1, 1, 0, f93, .act (.dir .up), f94, .ok⟩,
  ⟨138, 1, 1, 0, f94, .act (.dir .up), f95, .ok⟩,
  ⟨139, 1, 1, 0, f95, .act (.dir .up), f96, .ok⟩,
  ⟨140, 1, 1, 0, f96, .act (.dir .up), f97, .ok⟩,
  ⟨141, 1, 1, 0, f97, .act (.click 41 34), f97, .ok⟩,
  ⟨142, 1, 0, 1, f97, .reset, f0, .reset⟩,
  ⟨143, 0, 0, 1, f0, .act (.dir .up), f1, .ok⟩,
  ⟨144, 0, 0, 1, f1, .act (.dir .down), f2, .ok⟩,
  ⟨145, 0, 0, 1, f2, .act (.dir .left), f3, .ok⟩,
  ⟨146, 0, 0, 1, f3, .act (.dir .right), f4, .ok⟩,
  ⟨147, 0, 0, 1, f4, .act (.dir .up), f5, .ok⟩,
  ⟨148, 0, 0, 1, f5, .act (.dir .up), f6, .ok⟩,
  ⟨149, 0, 0, 1, f6, .act (.dir .up), f7, .ok⟩,
  ⟨150, 0, 0, 1, f7, .act (.dir .up), f8, .ok⟩,
  ⟨151, 0, 0, 1, f8, .act (.dir .up), f9, .ok⟩,
  ⟨152, 0, 0, 1, f9, .act (.dir .up), f9, .ok⟩,
  ⟨153, 0, 0, 1, f9, .act (.dir .up), f10, .ok⟩,
  ⟨154, 0, 0, 1, f10, .act (.dir .up), f11, .ok⟩,
  ⟨155, 0, 0, 1, f11, .act (.dir .up), f11, .ok⟩,
  ⟨156, 0, 0, 1, f11, .act (.dir .up), f12, .ok⟩,
  ⟨157, 0, 0, 1, f12, .act (.dir .right), f13, .ok⟩,
  ⟨158, 0, 0, 1, f13, .act (.dir .right), f13, .ok⟩,
  ⟨159, 0, 0, 1, f13, .act (.dir .right), f14, .ok⟩,
  ⟨160, 0, 0, 1, f14, .act (.dir .right), f15, .ok⟩,
  ⟨161, 0, 0, 1, f15, .act (.dir .right), f15, .ok⟩,
  ⟨162, 0, 0, 1, f15, .act (.dir .right), f16, .ok⟩,
  ⟨163, 0, 0, 1, f16, .act (.dir .right), f16, .ok⟩,
  ⟨164, 0, 0, 1, f16, .act (.dir .right), f17, .ok⟩,
  ⟨165, 0, 0, 1, f17, .act (.dir .right), f18, .ok⟩,
  ⟨166, 0, 0, 1, f18, .act (.dir .right), f18, .ok⟩,
  ⟨167, 0, 0, 1, f18, .act (.dir .right), f98, .ok⟩,
  ⟨168, 0, 0, 1, f98, .act (.dir .right), f99, .ok⟩,
  ⟨169, 0, 0, 1, f99, .act (.dir .down), f100, .ok⟩,
  ⟨170, 0, 0, 1, f100, .act (.dir .down), f101, .ok⟩,
  ⟨171, 0, 0, 1, f101, .act (.dir .down), f102, .ok⟩,
  ⟨172, 0, 0, 1, f102, .act (.dir .left), f103, .ok⟩,
  ⟨173, 0, 0, 1, f103, .act (.dir .left), f104, .ok⟩,
  ⟨174, 0, 0, 1, f104, .act (.dir .left), f105, .ok⟩,
  ⟨175, 0, 0, 1, f105, .act (.dir .left), f26, .ok⟩,
  ⟨176, 0, 0, 1, f26, .act (.dir .left), f27, .ok⟩,
  ⟨177, 0, 0, 1, f27, .act (.dir .left), f27, .ok⟩,
  ⟨178, 0, 0, 1, f27, .act (.dir .left), f28, .ok⟩,
  ⟨179, 0, 0, 1, f28, .act (.dir .left), f29, .ok⟩,
  ⟨180, 0, 0, 1, f29, .act (.dir .left), f29, .ok⟩,
  ⟨181, 0, 0, 1, f29, .act (.dir .left), f106, .ok⟩,
  ⟨182, 0, 0, 1, f106, .act (.dir .right), f107, .ok⟩,
  ⟨183, 0, 0, 1, f107, .act (.dir .right), f108, .ok⟩,
  ⟨184, 0, 0, 1, f108, .act (.dir .right), f109, .ok⟩,
  ⟨185, 0, 0, 1, f109, .act (.dir .right), f110, .ok⟩,
  ⟨186, 0, 0, 1, f110, .act (.dir .right), f111, .ok⟩,
  ⟨187, 0, 0, 1, f111, .act (.dir .right), f112, .ok⟩,
  ⟨188, 0, 0, 1, f112, .act (.dir .right), f113, .ok⟩,
  ⟨189, 0, 0, 1, f113, .act (.dir .right), f38, .ok⟩,
  ⟨190, 0, 0, 1, f38, .act (.dir .right), f39, .ok⟩,
  ⟨191, 0, 0, 1, f39, .act (.dir .right), f39, .ok⟩,
  ⟨192, 0, 0, 1, f39, .act (.dir .right), f40, .ok⟩,
  ⟨193, 0, 0, 1, f40, .act (.dir .right), f41, .ok⟩,
  ⟨194, 0, 0, 1, f41, .act (.dir .right), f41, .ok⟩,
  ⟨195, 0, 0, 1, f41, .act (.dir .right), f42, .ok⟩,
  ⟨196, 0, 0, 1, f42, .act (.dir .right), f43, .ok⟩,
  ⟨197, 0, 0, 1, f43, .act (.dir .right), f43, .ok⟩,
  ⟨198, 0, 0, 1, f43, .act (.dir .right), f44, .ok⟩,
  ⟨199, 0, 0, 1, f44, .act (.dir .right), f44, .ok⟩,
  ⟨200, 0, 0, 1, f44, .act (.dir .right), f45, .ok⟩,
  ⟨201, 0, 0, 1, f45, .act (.dir .up), f46, .ok⟩,
  ⟨202, 0, 0, 1, f46, .act (.dir .up), f46, .ok⟩,
  ⟨203, 0, 0, 1, f46, .act (.dir .up), f47, .ok⟩,
  ⟨204, 0, 0, 1, f47, .act (.dir .up), f48, .ok⟩,
  ⟨205, 0, 0, 1, f48, .act (.dir .up), f48, .ok⟩,
  ⟨206, 0, 0, 1, f48, .act (.dir .up), f114, .ok⟩,
  ⟨207, 0, 0, 1, f114, .reset, f0, .reset⟩,
  ⟨208, 0, 0, 1, f0, .act (.dir .right), f49, .ok⟩,
  ⟨209, 0, 0, 1, f49, .act (.dir .right), f50, .ok⟩,
  ⟨210, 0, 0, 1, f50, .act (.dir .right), f51, .ok⟩,
  ⟨211, 0, 0, 1, f51, .act (.dir .right), f52, .ok⟩,
  ⟨212, 0, 0, 1, f52, .act (.dir .right), f53, .ok⟩,
  ⟨213, 0, 0, 1, f53, .act (.dir .right), f54, .ok⟩,
  ⟨214, 0, 0, 1, f54, .act (.dir .up), f54, .ok⟩,
  ⟨215, 0, 0, 1, f54, .act (.dir .up), f55, .ok⟩,
  ⟨216, 0, 0, 1, f55, .act (.dir .up), f56, .ok⟩,
  ⟨217, 0, 0, 1, f56, .act (.dir .up), f56, .ok⟩,
  ⟨218, 0, 0, 1, f56, .act (.dir .up), f57, .ok⟩,
  ⟨219, 0, 0, 1, f57, .act (.dir .up), f58, .ok⟩,
  ⟨220, 0, 0, 1, f58, .reset, f0, .reset⟩,
  ⟨221, 0, 0, 1, f0, .act (.dir .right), f49, .ok⟩,
  ⟨222, 0, 0, 1, f49, .act (.dir .right), f50, .ok⟩,
  ⟨223, 0, 0, 1, f50, .act (.dir .right), f51, .ok⟩,
  ⟨224, 0, 0, 1, f51, .act (.click 34 13), f59, .ok⟩,
  ⟨225, 0, 0, 1, f59, .act (.click 43 31), f60, .ok⟩,
  ⟨226, 0, 0, 1, f60, .act (.click 25 31), f61, .ok⟩,
  ⟨227, 0, 0, 1, f61, .act (.click 46 28), f61, .ok⟩,
  ⟨228, 0, 0, 1, f61, .reset, f0, .reset⟩,
  ⟨229, 0, 0, 1, f0, .act (.dir .right), f49, .ok⟩,
  ⟨230, 0, 0, 1, f49, .act (.dir .right), f50, .ok⟩,
  ⟨231, 0, 0, 1, f50, .act (.dir .right), f51, .ok⟩,
  ⟨232, 0, 0, 1, f51, .act (.click 46 28), f59, .ok⟩,
  ⟨233, 0, 0, 1, f59, .act (.dir .up), f59, .ok⟩,
  ⟨234, 0, 0, 1, f59, .act (.click 44 30), f62, .ok⟩,
  ⟨235, 0, 0, 1, f62, .act (.click 44 30), f62, .ok⟩,
  ⟨236, 0, 0, 1, f62, .act (.click 43 31), f63, .ok⟩,
  ⟨237, 0, 0, 1, f63, .act (.click 44 30), f64, .ok⟩,
  ⟨238, 0, 0, 1, f64, .reset, f0, .reset⟩,
  ⟨239, 0, 0, 1, f0, .act (.dir .right), f49, .ok⟩,
  ⟨240, 0, 0, 1, f49, .act (.dir .right), f50, .ok⟩,
  ⟨241, 0, 0, 1, f50, .act (.dir .right), f51, .ok⟩,
  ⟨242, 0, 0, 1, f51, .act (.click 44 30), f60, .ok⟩,
  ⟨243, 0, 0, 1, f60, .act (.click 44 30), f60, .ok⟩,
  ⟨244, 0, 0, 1, f60, .act (.click 45 30), f62, .ok⟩,
  ⟨245, 0, 0, 1, f62, .act (.dir .left), f65, .ok⟩,
  ⟨246, 0, 0, 1, f65, .act (.dir .left), f66, .ok⟩,
  ⟨247, 0, 0, 1, f66, .act (.dir .down), f67, .ok⟩,
  ⟨248, 0, 0, 1, f67, .act (.dir .left), f67, .ok⟩,
  ⟨249, 0, 0, 1, f67, .act (.dir .up), f68, .ok⟩]

def rows01 : List Row := [
  ⟨250, 0, 0, 1, f68, .act (.dir .up), f69, .ok⟩,
  ⟨251, 0, 0, 1, f69, .act (.dir .right), f70, .ok⟩,
  ⟨252, 0, 0, 1, f70, .act (.dir .right), f71, .ok⟩,
  ⟨253, 0, 0, 1, f71, .act (.dir .down), f72, .ok⟩,
  ⟨254, 0, 0, 1, f72, .act (.click 44 30), f72, .ok⟩,
  ⟨255, 0, 0, 1, f72, .reset, f0, .reset⟩,
  ⟨256, 0, 0, 1, f0, .act (.dir .right), f49, .ok⟩,
  ⟨257, 0, 0, 1, f49, .act (.dir .right), f50, .ok⟩,
  ⟨258, 0, 0, 1, f50, .act (.dir .right), f51, .ok⟩,
  ⟨259, 0, 0, 1, f51, .act (.dir .down), f59, .ok⟩,
  ⟨260, 0, 0, 1, f59, .act (.dir .left), f73, .ok⟩,
  ⟨261, 0, 0, 1, f73, .act (.dir .left), f74, .ok⟩,
  ⟨262, 0, 0, 1, f74, .act (.dir .left), f75, .ok⟩,
  ⟨263, 0, 0, 1, f75, .act (.dir .left), f76, .ok⟩,
  ⟨264, 0, 0, 1, f76, .act (.click 43 31), f77, .ok⟩,
  ⟨265, 0, 0, 1, f77, .act (.dir .up), f78, .ok⟩,
  ⟨266, 0, 0, 1, f78, .act (.dir .right), f79, .ok⟩,
  ⟨267, 0, 0, 1, f79, .act (.click 13 34), f80, .ok⟩,
  ⟨268, 0, 0, 1, f80, .act (.click 13 31), f81, .ok⟩,
  ⟨269, 0, 1, 1, f81, .act (.dir .down), f82, .levelup⟩,
  ⟨270, 1, 1, 1, f82, .act (.click 46 28), f83, .ok⟩,
  ⟨271, 1, 1, 1, f83, .act (.dir .up), f84, .ok⟩,
  ⟨272, 1, 1, 1, f84, .act (.dir .down), f85, .ok⟩,
  ⟨273, 1, 1, 1, f85, .act (.dir .left), f86, .ok⟩,
  ⟨274, 1, 1, 1, f86, .act (.dir .right), f87, .ok⟩,
  ⟨275, 1, 1, 1, f87, .act (.dir .up), f88, .ok⟩,
  ⟨276, 1, 1, 1, f88, .act (.dir .up), f89, .ok⟩,
  ⟨277, 1, 1, 1, f89, .act (.dir .up), f90, .ok⟩,
  ⟨278, 1, 1, 1, f90, .act (.dir .up), f91, .ok⟩,
  ⟨279, 1, 1, 1, f91, .act (.dir .right), f92, .ok⟩,
  ⟨280, 1, 1, 1, f92, .act (.dir .right), f93, .ok⟩,
  ⟨281, 1, 1, 1, f93, .act (.dir .up), f94, .ok⟩,
  ⟨282, 1, 1, 1, f94, .act (.dir .up), f95, .ok⟩,
  ⟨283, 1, 1, 1, f95, .act (.dir .up), f96, .ok⟩,
  ⟨284, 1, 1, 1, f96, .act (.dir .up), f97, .ok⟩,
  ⟨285, 1, 1, 1, f97, .act (.dir .up), f97, .ok⟩,
  ⟨286, 1, 1, 1, f97, .act (.dir .up), f115, .ok⟩,
  ⟨287, 1, 1, 1, f115, .act (.dir .down), f116, .ok⟩,
  ⟨288, 1, 1, 1, f116, .act (.dir .left), f117, .ok⟩,
  ⟨289, 1, 1, 1, f117, .act (.dir .right), f118, .ok⟩,
  ⟨290, 1, 1, 1, f118, .act (.dir .up), f119, .ok⟩,
  ⟨291, 1, 1, 1, f119, .act (.dir .left), f120, .ok⟩,
  ⟨292, 1, 1, 1, f120, .act (.dir .left), f121, .ok⟩,
  ⟨293, 1, 1, 1, f121, .act (.dir .left), f122, .ok⟩,
  ⟨294, 1, 1, 1, f122, .act (.dir .left), f123, .ok⟩,
  ⟨295, 1, 1, 1, f123, .act (.click 42 44), f123, .ok⟩,
  ⟨296, 1, 1, 1, f123, .act (.dir .right), f124, .ok⟩,
  ⟨297, 1, 1, 1, f124, .act (.dir .right), f125, .ok⟩,
  ⟨298, 1, 1, 1, f125, .act (.dir .up), f126, .ok⟩,
  ⟨299, 1, 1, 1, f126, .act (.dir .up), f126, .ok⟩,
  ⟨300, 1, 1, 1, f126, .act (.dir .left), f127, .ok⟩,
  ⟨301, 1, 1, 1, f127, .act (.dir .right), f128, .ok⟩,
  ⟨302, 1, 1, 1, f128, .act (.dir .right), f129, .ok⟩,
  ⟨303, 1, 1, 1, f129, .act (.dir .right), f130, .ok⟩,
  ⟨304, 1, 1, 1, f130, .act (.dir .right), f131, .ok⟩,
  ⟨305, 1, 1, 1, f131, .act (.dir .right), f132, .ok⟩,
  ⟨306, 1, 1, 1, f132, .act (.dir .right), f133, .ok⟩,
  ⟨307, 1, 1, 1, f133, .act (.dir .right), f134, .ok⟩,
  ⟨308, 1, 1, 1, f134, .act (.dir .right), f135, .ok⟩,
  ⟨309, 1, 1, 1, f135, .act (.dir .right), f136, .ok⟩,
  ⟨310, 1, 1, 1, f136, .act (.dir .right), f137, .ok⟩,
  ⟨311, 1, 1, 1, f137, .act (.dir .right), f137, .ok⟩,
  ⟨312, 1, 1, 1, f137, .act (.dir .right), f138, .ok⟩,
  ⟨313, 1, 1, 1, f138, .act (.dir .right), f138, .ok⟩,
  ⟨314, 1, 1, 1, f138, .act (.dir .right), f139, .ok⟩,
  ⟨315, 1, 1, 1, f139, .act (.dir .right), f139, .ok⟩,
  ⟨316, 1, 1, 1, f139, .reset, f82, .reset⟩,
  ⟨317, 1, 1, 1, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨318, 1, 1, 1, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨319, 1, 1, 1, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨320, 1, 1, 1, f142, .act (.click 42 45), f142, .ok⟩,
  ⟨321, 1, 1, 1, f142, .act (.click 47 44), f143, .ok⟩,
  ⟨322, 1, 1, 1, f143, .act (.click 33 39), f143, .ok⟩,
  ⟨323, 1, 1, 1, f143, .act (.dir .up), f144, .ok⟩,
  ⟨324, 1, 1, 1, f144, .act (.click 42 42), f144, .ok⟩,
  ⟨325, 1, 1, 1, f144, .act (.dir .up), f145, .ok⟩,
  ⟨326, 1, 1, 1, f145, .act (.dir .up), f146, .ok⟩,
  ⟨327, 1, 1, 1, f146, .act (.dir .up), f147, .ok⟩,
  ⟨328, 1, 1, 1, f147, .act (.dir .down), f148, .ok⟩,
  ⟨329, 1, 1, 1, f148, .act (.dir .down), f149, .ok⟩,
  ⟨330, 1, 1, 1, f149, .act (.dir .down), f150, .ok⟩,
  ⟨331, 1, 1, 1, f150, .act (.click 47 44), f151, .ok⟩,
  ⟨332, 1, 0, 2, f151, .reset, f0, .reset⟩,
  ⟨333, 0, 0, 2, f0, .act (.dir .up), f1, .ok⟩,
  ⟨334, 0, 0, 2, f1, .act (.dir .down), f2, .ok⟩,
  ⟨335, 0, 0, 2, f2, .act (.dir .left), f3, .ok⟩,
  ⟨336, 0, 0, 2, f3, .act (.dir .right), f4, .ok⟩,
  ⟨337, 0, 0, 2, f4, .act (.dir .up), f5, .ok⟩,
  ⟨338, 0, 0, 2, f5, .act (.dir .up), f6, .ok⟩,
  ⟨339, 0, 0, 2, f6, .act (.dir .up), f7, .ok⟩,
  ⟨340, 0, 0, 2, f7, .act (.dir .up), f8, .ok⟩,
  ⟨341, 0, 0, 2, f8, .act (.dir .up), f9, .ok⟩,
  ⟨342, 0, 0, 2, f9, .act (.dir .up), f9, .ok⟩,
  ⟨343, 0, 0, 2, f9, .act (.dir .up), f10, .ok⟩,
  ⟨344, 0, 0, 2, f10, .act (.dir .up), f11, .ok⟩,
  ⟨345, 0, 0, 2, f11, .act (.dir .up), f11, .ok⟩,
  ⟨346, 0, 0, 2, f11, .act (.dir .up), f12, .ok⟩,
  ⟨347, 0, 0, 2, f12, .act (.dir .right), f13, .ok⟩,
  ⟨348, 0, 0, 2, f13, .act (.dir .right), f13, .ok⟩,
  ⟨349, 0, 0, 2, f13, .act (.dir .right), f14, .ok⟩,
  ⟨350, 0, 0, 2, f14, .act (.dir .right), f15, .ok⟩,
  ⟨351, 0, 0, 2, f15, .act (.dir .right), f15, .ok⟩,
  ⟨352, 0, 0, 2, f15, .act (.dir .right), f16, .ok⟩,
  ⟨353, 0, 0, 2, f16, .act (.dir .right), f16, .ok⟩,
  ⟨354, 0, 0, 2, f16, .act (.dir .right), f17, .ok⟩,
  ⟨355, 0, 0, 2, f17, .act (.dir .right), f18, .ok⟩,
  ⟨356, 0, 0, 2, f18, .act (.dir .right), f18, .ok⟩,
  ⟨357, 0, 0, 2, f18, .act (.dir .down), f19, .ok⟩,
  ⟨358, 0, 0, 2, f19, .act (.dir .down), f20, .ok⟩,
  ⟨359, 0, 0, 2, f20, .act (.dir .down), f21, .ok⟩,
  ⟨360, 0, 0, 2, f21, .act (.dir .left), f22, .ok⟩,
  ⟨361, 0, 0, 2, f22, .act (.dir .left), f23, .ok⟩,
  ⟨362, 0, 0, 2, f23, .act (.dir .left), f24, .ok⟩,
  ⟨363, 0, 0, 2, f24, .act (.dir .left), f25, .ok⟩,
  ⟨364, 0, 0, 2, f25, .act (.dir .left), f25, .ok⟩,
  ⟨365, 0, 0, 2, f25, .act (.dir .left), f26, .ok⟩,
  ⟨366, 0, 0, 2, f26, .act (.dir .left), f27, .ok⟩,
  ⟨367, 0, 0, 2, f27, .act (.dir .left), f27, .ok⟩,
  ⟨368, 0, 0, 2, f27, .act (.dir .left), f28, .ok⟩,
  ⟨369, 0, 0, 2, f28, .act (.dir .left), f29, .ok⟩,
  ⟨370, 0, 0, 2, f29, .act (.dir .right), f30, .ok⟩,
  ⟨371, 0, 0, 2, f30, .act (.dir .right), f31, .ok⟩,
  ⟨372, 0, 0, 2, f31, .act (.dir .right), f32, .ok⟩,
  ⟨373, 0, 0, 2, f32, .act (.dir .right), f33, .ok⟩,
  ⟨374, 0, 0, 2, f33, .act (.dir .right), f34, .ok⟩,
  ⟨375, 0, 0, 2, f34, .act (.dir .right), f35, .ok⟩,
  ⟨376, 0, 0, 2, f35, .act (.dir .right), f36, .ok⟩,
  ⟨377, 0, 0, 2, f36, .act (.dir .right), f37, .ok⟩,
  ⟨378, 0, 0, 2, f37, .act (.dir .right), f37, .ok⟩,
  ⟨379, 0, 0, 2, f37, .act (.dir .right), f38, .ok⟩,
  ⟨380, 0, 0, 2, f38, .act (.dir .right), f39, .ok⟩,
  ⟨381, 0, 0, 2, f39, .act (.dir .right), f39, .ok⟩,
  ⟨382, 0, 0, 2, f39, .act (.dir .right), f40, .ok⟩,
  ⟨383, 0, 0, 2, f40, .act (.dir .right), f41, .ok⟩,
  ⟨384, 0, 0, 2, f41, .act (.dir .right), f41, .ok⟩,
  ⟨385, 0, 0, 2, f41, .act (.dir .right), f42, .ok⟩,
  ⟨386, 0, 0, 2, f42, .act (.dir .right), f43, .ok⟩,
  ⟨387, 0, 0, 2, f43, .act (.dir .right), f43, .ok⟩,
  ⟨388, 0, 0, 2, f43, .act (.dir .right), f44, .ok⟩,
  ⟨389, 0, 0, 2, f44, .act (.dir .right), f44, .ok⟩,
  ⟨390, 0, 0, 2, f44, .act (.dir .up), f45, .ok⟩,
  ⟨391, 0, 0, 2, f45, .act (.dir .up), f46, .ok⟩,
  ⟨392, 0, 0, 2, f46, .act (.dir .up), f46, .ok⟩,
  ⟨393, 0, 0, 2, f46, .act (.dir .up), f47, .ok⟩,
  ⟨394, 0, 0, 2, f47, .act (.dir .up), f48, .ok⟩,
  ⟨395, 0, 0, 2, f48, .act (.dir .up), f48, .ok⟩,
  ⟨396, 0, 0, 2, f48, .reset, f0, .reset⟩,
  ⟨397, 0, 0, 2, f0, .act (.dir .right), f49, .ok⟩,
  ⟨398, 0, 0, 2, f49, .act (.dir .right), f50, .ok⟩,
  ⟨399, 0, 0, 2, f50, .act (.dir .right), f51, .ok⟩,
  ⟨400, 0, 0, 2, f51, .act (.dir .right), f52, .ok⟩,
  ⟨401, 0, 0, 2, f52, .act (.dir .right), f53, .ok⟩,
  ⟨402, 0, 0, 2, f53, .act (.dir .right), f54, .ok⟩,
  ⟨403, 0, 0, 2, f54, .act (.dir .up), f54, .ok⟩,
  ⟨404, 0, 0, 2, f54, .act (.dir .up), f55, .ok⟩,
  ⟨405, 0, 0, 2, f55, .act (.dir .up), f56, .ok⟩,
  ⟨406, 0, 0, 2, f56, .act (.dir .up), f56, .ok⟩,
  ⟨407, 0, 0, 2, f56, .act (.dir .up), f57, .ok⟩,
  ⟨408, 0, 0, 2, f57, .act (.dir .up), f58, .ok⟩,
  ⟨409, 0, 0, 2, f58, .reset, f0, .reset⟩,
  ⟨410, 0, 0, 2, f0, .act (.dir .right), f49, .ok⟩,
  ⟨411, 0, 0, 2, f49, .act (.dir .right), f50, .ok⟩,
  ⟨412, 0, 0, 2, f50, .act (.dir .right), f51, .ok⟩,
  ⟨413, 0, 0, 2, f51, .act (.click 34 13), f59, .ok⟩,
  ⟨414, 0, 0, 2, f59, .act (.click 43 31), f60, .ok⟩,
  ⟨415, 0, 0, 2, f60, .act (.click 25 31), f61, .ok⟩,
  ⟨416, 0, 0, 2, f61, .act (.click 46 28), f61, .ok⟩,
  ⟨417, 0, 0, 2, f61, .reset, f0, .reset⟩,
  ⟨418, 0, 0, 2, f0, .act (.dir .right), f49, .ok⟩,
  ⟨419, 0, 0, 2, f49, .act (.dir .right), f50, .ok⟩,
  ⟨420, 0, 0, 2, f50, .act (.dir .right), f51, .ok⟩,
  ⟨421, 0, 0, 2, f51, .act (.click 46 28), f59, .ok⟩,
  ⟨422, 0, 0, 2, f59, .act (.dir .up), f59, .ok⟩,
  ⟨423, 0, 0, 2, f59, .act (.click 44 30), f62, .ok⟩,
  ⟨424, 0, 0, 2, f62, .act (.click 44 30), f62, .ok⟩,
  ⟨425, 0, 0, 2, f62, .act (.click 43 31), f63, .ok⟩,
  ⟨426, 0, 0, 2, f63, .act (.click 44 30), f64, .ok⟩,
  ⟨427, 0, 0, 2, f64, .reset, f0, .reset⟩,
  ⟨428, 0, 0, 2, f0, .act (.dir .right), f49, .ok⟩,
  ⟨429, 0, 0, 2, f49, .act (.dir .right), f50, .ok⟩,
  ⟨430, 0, 0, 2, f50, .act (.dir .right), f51, .ok⟩,
  ⟨431, 0, 0, 2, f51, .act (.click 44 30), f60, .ok⟩,
  ⟨432, 0, 0, 2, f60, .act (.click 44 30), f60, .ok⟩,
  ⟨433, 0, 0, 2, f60, .act (.click 45 30), f62, .ok⟩,
  ⟨434, 0, 0, 2, f62, .act (.dir .left), f65, .ok⟩,
  ⟨435, 0, 0, 2, f65, .act (.dir .left), f66, .ok⟩,
  ⟨436, 0, 0, 2, f66, .act (.dir .down), f67, .ok⟩,
  ⟨437, 0, 0, 2, f67, .act (.dir .left), f67, .ok⟩,
  ⟨438, 0, 0, 2, f67, .act (.dir .up), f68, .ok⟩,
  ⟨439, 0, 0, 2, f68, .act (.dir .up), f69, .ok⟩,
  ⟨440, 0, 0, 2, f69, .act (.dir .right), f70, .ok⟩,
  ⟨441, 0, 0, 2, f70, .act (.dir .right), f71, .ok⟩,
  ⟨442, 0, 0, 2, f71, .act (.dir .down), f72, .ok⟩,
  ⟨443, 0, 0, 2, f72, .act (.click 44 30), f72, .ok⟩,
  ⟨444, 0, 0, 2, f72, .reset, f0, .reset⟩,
  ⟨445, 0, 0, 2, f0, .act (.dir .right), f49, .ok⟩,
  ⟨446, 0, 0, 2, f49, .act (.dir .right), f50, .ok⟩,
  ⟨447, 0, 0, 2, f50, .act (.dir .right), f51, .ok⟩,
  ⟨448, 0, 0, 2, f51, .act (.dir .down), f59, .ok⟩,
  ⟨449, 0, 0, 2, f59, .act (.dir .left), f73, .ok⟩,
  ⟨450, 0, 0, 2, f73, .act (.dir .left), f74, .ok⟩,
  ⟨451, 0, 0, 2, f74, .act (.dir .left), f75, .ok⟩,
  ⟨452, 0, 0, 2, f75, .act (.dir .left), f76, .ok⟩,
  ⟨453, 0, 0, 2, f76, .act (.click 43 31), f77, .ok⟩,
  ⟨454, 0, 0, 2, f77, .act (.dir .up), f78, .ok⟩,
  ⟨455, 0, 0, 2, f78, .act (.dir .right), f79, .ok⟩,
  ⟨456, 0, 0, 2, f79, .act (.click 13 34), f80, .ok⟩,
  ⟨457, 0, 0, 2, f80, .act (.click 13 31), f81, .ok⟩,
  ⟨458, 0, 1, 2, f81, .act (.dir .down), f82, .levelup⟩,
  ⟨459, 1, 1, 2, f82, .act (.click 44 34), f140, .ok⟩,
  ⟨460, 1, 1, 2, f140, .act (.click 45 34), f140, .ok⟩,
  ⟨461, 1, 1, 2, f140, .act (.click 47 44), f152, .ok⟩,
  ⟨462, 1, 1, 2, f152, .act (.click 55 37), f152, .ok⟩,
  ⟨463, 1, 1, 2, f152, .act (.dir .down), f153, .ok⟩,
  ⟨464, 1, 1, 2, f153, .act (.dir .down), f154, .ok⟩,
  ⟨465, 1, 1, 2, f154, .act (.dir .down), f155, .ok⟩,
  ⟨466, 1, 1, 2, f155, .act (.dir .down), f156, .ok⟩,
  ⟨467, 1, 1, 2, f156, .act (.dir .right), f157, .ok⟩,
  ⟨468, 1, 1, 2, f157, .act (.dir .right), f158, .ok⟩,
  ⟨469, 1, 1, 2, f158, .act (.dir .right), f159, .ok⟩,
  ⟨470, 1, 1, 2, f159, .act (.dir .right), f160, .ok⟩,
  ⟨471, 1, 1, 2, f160, .act (.click 44 34), f161, .ok⟩,
  ⟨472, 1, 1, 2, f161, .act (.click 44 34), f161, .ok⟩,
  ⟨473, 1, 1, 2, f161, .act (.click 44 34), f162, .ok⟩,
  ⟨474, 1, 1, 2, f162, .act (.click 44 34), f162, .ok⟩,
  ⟨475, 1, 1, 2, f162, .act (.click 44 34), f163, .ok⟩,
  ⟨476, 1, 1, 2, f163, .act (.click 44 34), f163, .ok⟩,
  ⟨477, 1, 1, 2, f163, .act (.click 44 34), f164, .ok⟩,
  ⟨478, 1, 1, 2, f164, .act (.click 44 34), f164, .ok⟩,
  ⟨479, 1, 1, 2, f164, .act (.click 44 34), f165, .ok⟩,
  ⟨480, 1, 1, 2, f165, .act (.click 44 34), f165, .ok⟩,
  ⟨481, 1, 1, 2, f165, .act (.click 44 34), f166, .ok⟩,
  ⟨482, 1, 1, 2, f166, .act (.click 44 34), f166, .ok⟩,
  ⟨483, 1, 1, 2, f166, .act (.click 44 34), f167, .ok⟩,
  ⟨484, 1, 1, 2, f167, .act (.click 44 34), f167, .ok⟩,
  ⟨485, 1, 1, 2, f167, .act (.click 44 34), f168, .ok⟩,
  ⟨486, 1, 1, 2, f168, .act (.click 44 34), f168, .ok⟩,
  ⟨487, 1, 1, 2, f168, .act (.click 44 34), f169, .ok⟩,
  ⟨488, 1, 1, 2, f169, .act (.click 44 34), f169, .ok⟩,
  ⟨489, 1, 1, 2, f169, .act (.click 44 34), f170, .ok⟩,
  ⟨490, 1, 1, 2, f170, .act (.click 44 34), f170, .ok⟩,
  ⟨491, 1, 1, 2, f170, .act (.click 44 34), f171, .ok⟩,
  ⟨492, 1, 1, 2, f171, .act (.click 44 34), f171, .ok⟩,
  ⟨493, 1, 1, 2, f171, .act (.click 44 34), f172, .ok⟩,
  ⟨494, 1, 1, 2, f172, .act (.click 44 34), f172, .ok⟩,
  ⟨495, 1, 1, 2, f172, .act (.click 44 34), f173, .ok⟩,
  ⟨496, 1, 1, 2, f173, .act (.click 44 34), f173, .ok⟩,
  ⟨497, 1, 1, 2, f173, .act (.click 44 34), f174, .ok⟩,
  ⟨498, 1, 1, 2, f174, .act (.click 44 34), f174, .ok⟩,
  ⟨499, 1, 1, 2, f174, .act (.click 44 34), f175, .ok⟩]

def rows02 : List Row := [
  ⟨500, 1, 1, 2, f175, .act (.click 44 34), f175, .ok⟩,
  ⟨501, 1, 1, 2, f175, .act (.click 44 34), f176, .ok⟩,
  ⟨502, 1, 1, 2, f176, .act (.click 44 34), f176, .ok⟩,
  ⟨503, 1, 1, 2, f176, .act (.click 44 34), f177, .ok⟩,
  ⟨504, 1, 1, 2, f177, .act (.click 44 34), f177, .ok⟩,
  ⟨505, 1, 1, 2, f177, .act (.click 44 34), f178, .ok⟩,
  ⟨506, 1, 1, 2, f178, .act (.click 44 34), f178, .ok⟩,
  ⟨507, 1, 1, 2, f178, .act (.click 44 34), f179, .ok⟩,
  ⟨508, 1, 1, 2, f179, .act (.click 44 34), f179, .ok⟩,
  ⟨509, 1, 1, 2, f179, .act (.click 44 34), f180, .ok⟩,
  ⟨510, 1, 1, 2, f180, .act (.click 44 34), f180, .ok⟩,
  ⟨511, 1, 1, 2, f180, .act (.click 44 34), f181, .ok⟩,
  ⟨512, 1, 1, 2, f181, .act (.click 44 34), f181, .ok⟩,
  ⟨513, 1, 1, 2, f181, .act (.click 44 34), f182, .ok⟩,
  ⟨514, 1, 1, 2, f182, .act (.click 44 34), f182, .ok⟩,
  ⟨515, 1, 1, 2, f182, .act (.click 44 34), f183, .ok⟩,
  ⟨516, 1, 1, 2, f183, .act (.click 44 34), f183, .ok⟩,
  ⟨517, 1, 1, 2, f183, .act (.click 44 34), f184, .ok⟩,
  ⟨518, 1, 1, 2, f184, .act (.click 44 34), f184, .ok⟩,
  ⟨519, 1, 1, 2, f184, .act (.click 44 34), f185, .ok⟩,
  ⟨520, 1, 1, 2, f185, .act (.click 44 34), f185, .ok⟩,
  ⟨521, 1, 1, 2, f185, .act (.click 44 34), f186, .ok⟩,
  ⟨522, 1, 1, 2, f186, .act (.click 44 34), f186, .ok⟩,
  ⟨523, 1, 1, 2, f186, .act (.click 44 34), f187, .ok⟩,
  ⟨524, 1, 1, 2, f187, .act (.click 44 34), f187, .ok⟩,
  ⟨525, 1, 1, 2, f187, .act (.click 44 34), f188, .ok⟩,
  ⟨526, 1, 1, 2, f188, .act (.click 44 34), f188, .ok⟩,
  ⟨527, 1, 1, 2, f188, .act (.click 44 34), f189, .ok⟩,
  ⟨528, 1, 1, 2, f189, .act (.click 44 34), f189, .ok⟩,
  ⟨529, 1, 1, 2, f189, .act (.click 44 34), f190, .ok⟩,
  ⟨530, 1, 1, 2, f190, .act (.click 44 34), f190, .ok⟩,
  ⟨531, 1, 1, 2, f190, .act (.click 44 34), f191, .ok⟩,
  ⟨532, 1, 1, 2, f191, .act (.click 44 34), f191, .ok⟩,
  ⟨533, 1, 1, 2, f191, .act (.click 44 34), f192, .ok⟩,
  ⟨534, 1, 1, 2, f192, .act (.click 44 34), f192, .ok⟩,
  ⟨535, 1, 1, 2, f192, .act (.click 44 34), f193, .ok⟩,
  ⟨536, 1, 1, 2, f193, .act (.click 44 34), f193, .ok⟩,
  ⟨537, 1, 1, 2, f193, .act (.click 44 34), f194, .ok⟩,
  ⟨538, 1, 1, 2, f194, .act (.click 44 34), f194, .ok⟩,
  ⟨539, 1, 1, 2, f194, .act (.click 44 34), f195, .ok⟩,
  ⟨540, 1, 1, 2, f195, .act (.click 44 34), f195, .ok⟩,
  ⟨541, 1, 1, 2, f195, .act (.click 44 34), f196, .ok⟩,
  ⟨542, 1, 1, 2, f196, .act (.click 44 34), f196, .ok⟩,
  ⟨543, 1, 1, 2, f196, .act (.click 44 34), f197, .ok⟩,
  ⟨544, 1, 1, 2, f197, .act (.click 44 34), f197, .ok⟩,
  ⟨545, 1, 1, 2, f197, .act (.click 44 34), f198, .ok⟩,
  ⟨546, 1, 1, 2, f198, .act (.click 44 34), f198, .ok⟩,
  ⟨547, 1, 1, 2, f198, .act (.click 44 34), f199, .ok⟩,
  ⟨548, 1, 1, 2, f199, .act (.click 44 34), f199, .ok⟩,
  ⟨549, 1, 1, 2, f199, .act (.click 44 34), f200, .ok⟩,
  ⟨550, 1, 1, 2, f200, .act (.click 44 34), f200, .ok⟩,
  ⟨551, 1, 1, 2, f200, .act (.click 44 34), f201, .ok⟩,
  ⟨552, 1, 1, 2, f201, .act (.click 44 34), f201, .ok⟩,
  ⟨553, 1, 1, 2, f201, .act (.click 44 34), f202, .ok⟩,
  ⟨554, 1, 1, 2, f202, .act (.click 44 34), f202, .ok⟩,
  ⟨555, 1, 1, 2, f202, .act (.click 44 34), f203, .ok⟩,
  ⟨556, 1, 1, 2, f203, .act (.click 44 34), f203, .ok⟩,
  ⟨557, 1, 1, 2, f203, .act (.click 44 34), f204, .ok⟩,
  ⟨558, 1, 1, 2, f204, .act (.click 44 34), f204, .ok⟩,
  ⟨559, 1, 1, 2, f204, .act (.click 44 34), f205, .ok⟩,
  ⟨560, 1, 1, 2, f205, .act (.click 44 34), f205, .ok⟩,
  ⟨561, 1, 1, 2, f205, .act (.click 44 34), f206, .ok⟩,
  ⟨562, 1, 1, 2, f206, .act (.click 44 34), f206, .ok⟩,
  ⟨563, 1, 1, 2, f206, .act (.click 44 34), f207, .ok⟩,
  ⟨564, 1, 1, 2, f207, .act (.click 44 34), f207, .ok⟩,
  ⟨565, 1, 1, 2, f207, .act (.click 44 34), f208, .ok⟩,
  ⟨566, 1, 1, 2, f208, .act (.click 44 34), f208, .ok⟩,
  ⟨567, 1, 1, 2, f208, .act (.click 44 34), f209, .ok⟩,
  ⟨568, 1, 1, 2, f209, .act (.click 44 34), f209, .ok⟩,
  ⟨569, 1, 1, 2, f209, .act (.click 44 34), f210, .ok⟩,
  ⟨570, 1, 1, 2, f210, .act (.click 44 34), f210, .ok⟩,
  ⟨571, 1, 1, 2, f210, .act (.click 44 34), f211, .ok⟩,
  ⟨572, 1, 1, 2, f211, .act (.click 44 34), f211, .ok⟩,
  ⟨573, 1, 1, 2, f211, .act (.click 44 34), f212, .ok⟩,
  ⟨574, 1, 1, 2, f212, .act (.click 44 34), f212, .ok⟩,
  ⟨575, 1, 1, 2, f212, .act (.click 44 34), f213, .ok⟩,
  ⟨576, 1, 1, 2, f213, .act (.click 44 34), f213, .ok⟩,
  ⟨577, 1, 1, 2, f213, .act (.click 44 34), f214, .ok⟩,
  ⟨578, 1, 1, 2, f214, .act (.click 44 34), f214, .ok⟩,
  ⟨579, 1, 1, 2, f214, .act (.click 44 34), f215, .ok⟩,
  ⟨580, 1, 1, 2, f215, .act (.click 44 34), f215, .ok⟩,
  ⟨581, 1, 1, 2, f215, .act (.click 44 34), f216, .ok⟩,
  ⟨582, 1, 1, 2, f216, .act (.click 44 34), f216, .ok⟩,
  ⟨583, 1, 1, 2, f216, .act (.click 44 34), f217, .ok⟩,
  ⟨584, 1, 1, 2, f217, .act (.click 44 34), f217, .ok⟩,
  ⟨585, 1, 1, 2, f217, .act (.click 44 34), f218, .over⟩,
  ⟨586, 1, 1, 2, f218, .reset, f82, .reset⟩,
  ⟨587, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨588, 1, 1, 2, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨589, 1, 1, 2, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨590, 1, 1, 2, f142, .act (.click 47 44), f142, .ok⟩,
  ⟨591, 1, 1, 2, f142, .act (.dir .up), f219, .ok⟩,
  ⟨592, 1, 1, 2, f219, .act (.dir .up), f220, .ok⟩,
  ⟨593, 1, 1, 2, f220, .act (.dir .up), f221, .ok⟩,
  ⟨594, 1, 1, 2, f221, .act (.dir .up), f222, .ok⟩,
  ⟨595, 1, 1, 2, f222, .act (.dir .up), f223, .ok⟩,
  ⟨596, 1, 1, 2, f223, .act (.dir .up), f223, .ok⟩,
  ⟨597, 1, 1, 2, f223, .act (.dir .up), f224, .ok⟩,
  ⟨598, 1, 1, 2, f224, .act (.dir .up), f224, .ok⟩,
  ⟨599, 1, 1, 2, f224, .act (.dir .up), f225, .ok⟩,
  ⟨600, 1, 1, 2, f225, .act (.dir .up), f225, .ok⟩,
  ⟨601, 1, 1, 2, f225, .act (.dir .up), f226, .ok⟩,
  ⟨602, 1, 1, 2, f226, .act (.dir .up), f226, .ok⟩,
  ⟨603, 1, 1, 2, f226, .act (.dir .up), f227, .ok⟩,
  ⟨604, 1, 1, 2, f227, .act (.dir .up), f227, .ok⟩,
  ⟨605, 1, 1, 2, f227, .act (.dir .up), f228, .ok⟩,
  ⟨606, 1, 1, 2, f228, .act (.click 36 44), f228, .ok⟩,
  ⟨607, 1, 1, 2, f228, .reset, f82, .reset⟩,
  ⟨608, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨609, 1, 1, 2, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨610, 1, 1, 2, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨611, 1, 1, 2, f142, .reset, f82, .reset⟩,
  ⟨612, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨613, 1, 1, 2, f140, .act (.click 41 37), f140, .ok⟩,
  ⟨614, 1, 1, 2, f140, .act (.click 34 44), f229, .ok⟩,
  ⟨615, 1, 1, 2, f229, .act (.click 37 44), f229, .ok⟩,
  ⟨616, 1, 1, 2, f229, .act (.click 44 47), f143, .ok⟩,
  ⟨617, 1, 1, 2, f143, .act (.dir .down), f230, .ok⟩,
  ⟨618, 1, 1, 2, f230, .act (.dir .up), f231, .ok⟩,
  ⟨619, 1, 1, 2, f231, .act (.dir .right), f232, .ok⟩,
  ⟨620, 1, 1, 2, f232, .act (.dir .left), f233, .ok⟩,
  ⟨621, 1, 1, 2, f233, .act (.click 13 34), f233, .ok⟩,
  ⟨622, 1, 1, 2, f233, .act (.dir .down), f234, .ok⟩,
  ⟨623, 1, 1, 2, f234, .act (.click 48 45), f234, .ok⟩,
  ⟨624, 1, 1, 2, f234, .reset, f82, .reset⟩,
  ⟨625, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨626, 1, 1, 2, f140, .act (.click 42 34), f140, .ok⟩,
  ⟨627, 1, 1, 2, f140, .act (.click 34 44), f229, .ok⟩,
  ⟨628, 1, 1, 2, f229, .act (.click 34 45), f229, .ok⟩,
  ⟨629, 1, 1, 2, f229, .act (.click 44 47), f143, .ok⟩,
  ⟨630, 1, 1, 2, f143, .act (.click 44 48), f143, .ok⟩,
  ⟨631, 1, 1, 2, f143, .act (.click 47 44), f231, .ok⟩,
  ⟨632, 1, 1, 2, f231, .act (.click 48 45), f231, .ok⟩,
  ⟨633, 1, 1, 2, f231, .act (.dir .down), f235, .ok⟩,
  ⟨634, 1, 1, 2, f235, .act (.dir .up), f233, .ok⟩,
  ⟨635, 1, 1, 2, f233, .act (.dir .up), f236, .ok⟩,
  ⟨636, 1, 1, 2, f236, .act (.dir .up), f237, .ok⟩,
  ⟨637, 1, 1, 2, f237, .act (.dir .up), f238, .ok⟩,
  ⟨638, 1, 1, 2, f238, .act (.dir .up), f239, .ok⟩,
  ⟨639, 1, 1, 2, f239, .act (.dir .down), f240, .ok⟩,
  ⟨640, 1, 1, 2, f240, .act (.click 41 44), f240, .ok⟩,
  ⟨641, 1, 1, 2, f240, .act (.click 42 42), f241, .ok⟩,
  ⟨642, 1, 1, 2, f241, .act (.click 42 42), f241, .ok⟩,
  ⟨643, 1, 1, 2, f241, .act (.click 42 42), f242, .ok⟩,
  ⟨644, 1, 1, 2, f242, .act (.click 42 42), f242, .ok⟩,
  ⟨645, 1, 1, 2, f242, .act (.click 42 42), f243, .ok⟩,
  ⟨646, 1, 1, 2, f243, .act (.click 42 42), f243, .ok⟩,
  ⟨647, 1, 1, 2, f243, .act (.click 18 63), f244, .ok⟩,
  ⟨648, 1, 1, 2, f244, .reset, f82, .reset⟩,
  ⟨649, 1, 1, 2, f82, .act (.click 34 41), f83, .ok⟩,
  ⟨650, 1, 1, 2, f83, .act (.click 44 34), f140, .ok⟩,
  ⟨651, 1, 1, 2, f140, .act (.click 45 34), f152, .ok⟩,
  ⟨652, 1, 1, 2, f152, .act (.click 44 47), f245, .ok⟩,
  ⟨653, 1, 1, 2, f245, .act (.click 45 47), f246, .ok⟩,
  ⟨654, 1, 1, 2, f246, .act (.click 34 44), f247, .ok⟩,
  ⟨655, 1, 1, 2, f247, .act (.click 34 45), f248, .ok⟩,
  ⟨656, 1, 1, 2, f248, .act (.click 44 48), f231, .ok⟩,
  ⟨657, 1, 1, 2, f231, .act (.click 45 48), f233, .ok⟩,
  ⟨658, 1, 1, 2, f233, .act (.click 45 45), f233, .ok⟩,
  ⟨659, 1, 1, 2, f233, .act (.click 46 45), f249, .ok⟩,
  ⟨660, 1, 1, 2, f249, .act (.click 47 45), f249, .ok⟩,
  ⟨661, 1, 1, 2, f249, .act (.click 48 45), f250, .ok⟩,
  ⟨662, 1, 1, 2, f250, .act (.dir .down), f251, .ok⟩,
  ⟨663, 1, 1, 2, f251, .act (.click 45 45), f252, .ok⟩,
  ⟨664, 1, 1, 2, f252, .act (.dir .down), f253, .ok⟩,
  ⟨665, 1, 1, 2, f253, .reset, f82, .reset⟩,
  ⟨666, 1, 1, 2, f82, .act (.click 45 45), f254, .ok⟩,
  ⟨667, 1, 1, 2, f254, .act (.dir .up), f255, .ok⟩,
  ⟨668, 1, 1, 2, f255, .act (.dir .up), f256, .ok⟩,
  ⟨669, 1, 1, 2, f256, .act (.dir .up), f257, .ok⟩,
  ⟨670, 1, 1, 2, f257, .act (.dir .up), f258, .ok⟩,
  ⟨671, 1, 1, 2, f258, .act (.dir .up), f259, .ok⟩,
  ⟨672, 1, 1, 2, f259, .act (.dir .down), f260, .ok⟩,
  ⟨673, 1, 1, 2, f260, .act (.dir .up), f261, .ok⟩,
  ⟨674, 1, 1, 2, f261, .act (.dir .up), f262, .ok⟩,
  ⟨675, 1, 1, 2, f262, .act (.dir .up), f262, .ok⟩,
  ⟨676, 1, 1, 2, f262, .act (.dir .up), f263, .ok⟩,
  ⟨677, 1, 1, 2, f263, .act (.click 31 41), f263, .ok⟩,
  ⟨678, 1, 1, 2, f263, .act (.click 38 34), f264, .ok⟩,
  ⟨679, 1, 1, 2, f264, .act (.click 34 38), f264, .ok⟩,
  ⟨680, 1, 1, 2, f264, .act (.click 41 31), f265, .ok⟩,
  ⟨681, 1, 1, 2, f265, .act (.click 34 44), f266, .ok⟩,
  ⟨682, 1, 1, 2, f266, .act (.dir .down), f267, .ok⟩,
  ⟨683, 1, 1, 2, f267, .reset, f82, .reset⟩,
  ⟨684, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨685, 1, 1, 2, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨686, 1, 1, 2, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨687, 1, 1, 2, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨688, 1, 1, 2, f142, .act (.dir .down), f230, .ok⟩,
  ⟨689, 1, 1, 2, f230, .reset, f82, .reset⟩,
  ⟨690, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨691, 1, 1, 2, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨692, 1, 1, 2, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨693, 1, 1, 2, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨694, 1, 1, 2, f142, .reset, f82, .reset⟩,
  ⟨695, 1, 1, 2, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨696, 1, 1, 2, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨697, 1, 1, 2, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨698, 1, 1, 2, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨699, 1, 1, 2, f142, .act (.dir .down), f230, .ok⟩,
  ⟨700, 1, 1, 2, f230, .reset, f82, .reset⟩,
  ⟨701, 1, 1, 2, f82, .act (.dir .up), f84, .ok⟩,
  ⟨702, 1, 1, 2, f84, .act (.dir .left), f268, .ok⟩,
  ⟨703, 1, 1, 2, f268, .act (.dir .right), f269, .ok⟩,
  ⟨704, 1, 1, 2, f269, .act (.dir .up), f270, .ok⟩,
  ⟨705, 1, 1, 2, f270, .act (.dir .up), f271, .ok⟩,
  ⟨706, 1, 1, 2, f271, .act (.dir .up), f272, .ok⟩,
  ⟨707, 1, 1, 2, f272, .act (.dir .up), f273, .ok⟩,
  ⟨708, 1, 1, 2, f273, .act (.dir .up), f274, .ok⟩,
  ⟨709, 1, 1, 2, f274, .act (.dir .up), f275, .ok⟩,
  ⟨710, 1, 1, 2, f275, .act (.dir .up), f276, .ok⟩,
  ⟨711, 1, 1, 2, f276, .act (.dir .up), f277, .ok⟩,
  ⟨712, 1, 1, 2, f277, .act (.dir .up), f277, .ok⟩,
  ⟨713, 1, 1, 2, f277, .act (.dir .up), f278, .ok⟩,
  ⟨714, 1, 1, 2, f278, .act (.dir .up), f278, .ok⟩,
  ⟨715, 1, 1, 2, f278, .act (.dir .up), f279, .ok⟩,
  ⟨716, 1, 1, 2, f279, .act (.dir .up), f279, .ok⟩,
  ⟨717, 1, 1, 2, f279, .act (.dir .up), f280, .ok⟩,
  ⟨718, 1, 1, 2, f280, .act (.dir .up), f280, .ok⟩,
  ⟨719, 1, 1, 2, f280, .act (.dir .up), f281, .ok⟩,
  ⟨720, 1, 1, 2, f281, .act (.dir .up), f281, .ok⟩,
  ⟨721, 1, 1, 2, f281, .act (.dir .up), f282, .ok⟩,
  ⟨722, 1, 1, 2, f282, .act (.dir .up), f282, .ok⟩,
  ⟨723, 1, 1, 2, f282, .act (.dir .up), f283, .ok⟩,
  ⟨724, 1, 1, 2, f283, .act (.dir .up), f283, .ok⟩,
  ⟨725, 1, 1, 2, f283, .act (.dir .up), f284, .ok⟩,
  ⟨726, 1, 1, 2, f284, .act (.dir .up), f284, .ok⟩,
  ⟨727, 1, 1, 2, f284, .act (.dir .up), f285, .ok⟩,
  ⟨728, 1, 1, 2, f285, .act (.dir .up), f285, .ok⟩,
  ⟨729, 1, 1, 2, f285, .act (.dir .up), f286, .ok⟩,
  ⟨730, 1, 1, 2, f286, .act (.dir .up), f286, .ok⟩,
  ⟨731, 1, 1, 2, f286, .act (.dir .up), f287, .ok⟩,
  ⟨732, 1, 1, 2, f287, .act (.dir .up), f287, .ok⟩,
  ⟨733, 1, 1, 2, f287, .act (.dir .up), f288, .ok⟩,
  ⟨734, 1, 1, 2, f288, .act (.dir .up), f288, .ok⟩,
  ⟨735, 1, 1, 2, f288, .act (.dir .up), f289, .ok⟩,
  ⟨736, 1, 1, 2, f289, .act (.dir .up), f289, .ok⟩,
  ⟨737, 1, 1, 2, f289, .act (.dir .up), f290, .ok⟩,
  ⟨738, 1, 1, 2, f290, .act (.dir .up), f290, .ok⟩,
  ⟨739, 1, 1, 2, f290, .act (.dir .up), f291, .ok⟩,
  ⟨740, 1, 1, 2, f291, .act (.dir .up), f291, .ok⟩,
  ⟨741, 1, 1, 2, f291, .act (.dir .up), f292, .ok⟩,
  ⟨742, 1, 1, 2, f292, .act (.dir .up), f292, .ok⟩,
  ⟨743, 1, 1, 2, f292, .act (.dir .up), f293, .ok⟩,
  ⟨744, 1, 1, 2, f293, .act (.dir .up), f293, .ok⟩,
  ⟨745, 1, 1, 2, f293, .act (.dir .up), f294, .ok⟩,
  ⟨746, 1, 1, 2, f294, .act (.dir .up), f294, .ok⟩,
  ⟨747, 1, 1, 2, f294, .act (.dir .up), f295, .ok⟩,
  ⟨748, 1, 1, 2, f295, .act (.dir .up), f295, .ok⟩,
  ⟨749, 1, 1, 2, f295, .act (.dir .up), f296, .ok⟩]

def rows03 : List Row := [
  ⟨750, 1, 1, 2, f296, .act (.dir .up), f296, .ok⟩,
  ⟨751, 1, 1, 2, f296, .act (.dir .up), f297, .ok⟩,
  ⟨752, 1, 1, 2, f297, .act (.dir .up), f297, .ok⟩,
  ⟨753, 1, 1, 2, f297, .act (.dir .up), f298, .ok⟩,
  ⟨754, 1, 1, 2, f298, .act (.dir .up), f298, .ok⟩,
  ⟨755, 1, 1, 2, f298, .act (.dir .up), f299, .ok⟩,
  ⟨756, 1, 1, 2, f299, .act (.dir .up), f299, .ok⟩,
  ⟨757, 1, 1, 2, f299, .act (.dir .up), f300, .ok⟩,
  ⟨758, 1, 1, 2, f300, .act (.dir .up), f300, .ok⟩,
  ⟨759, 1, 1, 2, f300, .act (.dir .up), f301, .ok⟩,
  ⟨760, 1, 1, 2, f301, .act (.dir .up), f301, .ok⟩,
  ⟨761, 1, 1, 2, f301, .act (.dir .up), f302, .ok⟩,
  ⟨762, 1, 1, 2, f302, .act (.dir .up), f302, .ok⟩,
  ⟨763, 1, 1, 2, f302, .act (.dir .up), f303, .ok⟩,
  ⟨764, 1, 1, 2, f303, .act (.dir .up), f303, .ok⟩,
  ⟨765, 1, 1, 2, f303, .act (.dir .up), f304, .ok⟩,
  ⟨766, 1, 1, 2, f304, .act (.dir .up), f304, .ok⟩,
  ⟨767, 1, 1, 2, f304, .act (.dir .up), f305, .ok⟩,
  ⟨768, 1, 1, 2, f305, .act (.dir .up), f305, .ok⟩,
  ⟨769, 1, 1, 2, f305, .act (.dir .up), f306, .ok⟩,
  ⟨770, 1, 1, 2, f306, .act (.dir .up), f306, .ok⟩,
  ⟨771, 1, 1, 2, f306, .act (.dir .up), f307, .ok⟩,
  ⟨772, 1, 1, 2, f307, .act (.dir .up), f307, .ok⟩,
  ⟨773, 1, 1, 2, f307, .act (.dir .up), f308, .ok⟩,
  ⟨774, 1, 1, 2, f308, .act (.dir .up), f308, .ok⟩,
  ⟨775, 1, 1, 2, f308, .act (.dir .up), f309, .ok⟩,
  ⟨776, 1, 1, 2, f309, .act (.dir .up), f309, .ok⟩,
  ⟨777, 1, 1, 2, f309, .act (.dir .up), f310, .ok⟩,
  ⟨778, 1, 1, 2, f310, .act (.dir .up), f310, .ok⟩,
  ⟨779, 1, 1, 2, f310, .act (.dir .up), f311, .ok⟩,
  ⟨780, 1, 1, 2, f311, .act (.dir .up), f311, .ok⟩,
  ⟨781, 1, 1, 2, f311, .act (.dir .up), f312, .ok⟩,
  ⟨782, 1, 1, 2, f312, .act (.dir .up), f312, .ok⟩,
  ⟨783, 1, 1, 2, f312, .act (.dir .up), f313, .ok⟩,
  ⟨784, 1, 1, 2, f313, .act (.dir .up), f313, .ok⟩,
  ⟨785, 1, 1, 2, f313, .act (.dir .up), f314, .ok⟩,
  ⟨786, 1, 1, 2, f314, .act (.dir .up), f314, .ok⟩,
  ⟨787, 1, 1, 2, f314, .act (.dir .up), f315, .ok⟩,
  ⟨788, 1, 1, 2, f315, .act (.dir .up), f315, .ok⟩,
  ⟨789, 1, 1, 2, f315, .act (.dir .up), f316, .ok⟩,
  ⟨790, 1, 1, 2, f316, .act (.dir .up), f316, .ok⟩,
  ⟨791, 1, 1, 2, f316, .act (.dir .up), f317, .ok⟩,
  ⟨792, 1, 1, 2, f317, .act (.dir .up), f317, .ok⟩,
  ⟨793, 1, 1, 2, f317, .act (.dir .up), f318, .ok⟩,
  ⟨794, 1, 1, 2, f318, .act (.dir .up), f318, .ok⟩,
  ⟨795, 1, 1, 2, f318, .act (.dir .up), f319, .ok⟩,
  ⟨796, 1, 1, 2, f319, .act (.dir .up), f319, .ok⟩,
  ⟨797, 1, 1, 2, f319, .act (.dir .up), f320, .ok⟩,
  ⟨798, 1, 1, 2, f320, .act (.dir .up), f320, .ok⟩,
  ⟨799, 1, 1, 2, f320, .act (.dir .up), f321, .ok⟩,
  ⟨800, 1, 1, 2, f321, .act (.dir .up), f321, .ok⟩,
  ⟨801, 1, 1, 2, f321, .act (.dir .up), f322, .ok⟩,
  ⟨802, 1, 1, 2, f322, .act (.dir .up), f322, .ok⟩,
  ⟨803, 1, 1, 2, f322, .act (.dir .up), f323, .ok⟩,
  ⟨804, 1, 1, 2, f323, .act (.dir .up), f323, .ok⟩,
  ⟨805, 1, 1, 2, f323, .act (.dir .up), f324, .ok⟩,
  ⟨806, 1, 1, 2, f324, .act (.dir .up), f324, .ok⟩,
  ⟨807, 1, 1, 2, f324, .act (.dir .up), f325, .ok⟩,
  ⟨808, 1, 1, 2, f325, .act (.dir .up), f325, .ok⟩,
  ⟨809, 1, 1, 2, f325, .act (.dir .up), f326, .ok⟩,
  ⟨810, 1, 1, 2, f326, .act (.dir .up), f326, .ok⟩,
  ⟨811, 1, 1, 2, f326, .act (.dir .up), f327, .ok⟩,
  ⟨812, 1, 1, 2, f327, .act (.dir .up), f327, .ok⟩,
  ⟨813, 1, 1, 2, f327, .act (.dir .up), f328, .ok⟩,
  ⟨814, 1, 1, 2, f328, .act (.dir .up), f328, .ok⟩,
  ⟨815, 1, 1, 2, f328, .act (.dir .up), f329, .ok⟩,
  ⟨816, 1, 1, 2, f329, .act (.dir .up), f329, .ok⟩,
  ⟨817, 1, 1, 2, f329, .act (.dir .up), f330, .ok⟩,
  ⟨818, 1, 1, 2, f330, .act (.dir .up), f330, .ok⟩,
  ⟨819, 1, 1, 2, f330, .act (.dir .up), f331, .ok⟩,
  ⟨820, 1, 1, 2, f331, .act (.dir .up), f331, .ok⟩,
  ⟨821, 1, 1, 2, f331, .act (.dir .up), f332, .ok⟩,
  ⟨822, 1, 1, 2, f332, .act (.dir .up), f332, .ok⟩,
  ⟨823, 1, 1, 2, f332, .act (.dir .up), f333, .ok⟩,
  ⟨824, 1, 1, 2, f333, .act (.dir .up), f333, .ok⟩,
  ⟨825, 1, 1, 2, f333, .act (.dir .up), f334, .ok⟩,
  ⟨826, 1, 1, 2, f334, .act (.dir .up), f334, .ok⟩,
  ⟨827, 1, 1, 2, f334, .act (.dir .up), f335, .over⟩,
  ⟨828, 1, 1, 2, f335, .reset, f82, .reset⟩,
  ⟨829, 1, 0, 3, f82, .reset, f0, .reset⟩,
  ⟨830, 0, 0, 3, f0, .act (.dir .right), f49, .ok⟩,
  ⟨831, 0, 0, 3, f49, .act (.dir .right), f50, .ok⟩,
  ⟨832, 0, 0, 3, f50, .act (.dir .right), f51, .ok⟩,
  ⟨833, 0, 0, 3, f51, .act (.dir .left), f73, .ok⟩,
  ⟨834, 0, 0, 3, f73, .act (.dir .down), f336, .ok⟩,
  ⟨835, 0, 0, 3, f336, .act (.dir .left), f337, .ok⟩,
  ⟨836, 0, 0, 3, f337, .act (.dir .left), f338, .ok⟩,
  ⟨837, 0, 0, 3, f338, .act (.dir .left), f339, .ok⟩,
  ⟨838, 0, 0, 3, f339, .act (.click 42 30), f340, .ok⟩,
  ⟨839, 0, 0, 3, f340, .act (.dir .up), f341, .ok⟩,
  ⟨840, 0, 1, 3, f341, .act (.dir .right), f82, .levelup⟩,
  ⟨841, 1, 1, 3, f82, .act (.dir .up), f84, .ok⟩,
  ⟨842, 1, 1, 3, f84, .act (.dir .up), f342, .ok⟩,
  ⟨843, 1, 1, 3, f342, .act (.dir .up), f343, .ok⟩,
  ⟨844, 1, 1, 3, f343, .act (.dir .up), f344, .ok⟩,
  ⟨845, 1, 1, 3, f344, .act (.dir .left), f345, .ok⟩,
  ⟨846, 1, 1, 3, f345, .act (.click 39 33), f346, .ok⟩,
  ⟨847, 1, 1, 3, f346, .act (.dir .down), f347, .ok⟩,
  ⟨848, 1, 1, 3, f347, .act (.dir .down), f348, .ok⟩,
  ⟨849, 1, 1, 3, f348, .act (.dir .down), f349, .ok⟩,
  ⟨850, 1, 1, 3, f349, .act (.dir .left), f350, .ok⟩,
  ⟨851, 1, 1, 3, f350, .act (.dir .right), f351, .ok⟩,
  ⟨852, 1, 1, 3, f351, .act (.dir .right), f352, .ok⟩,
  ⟨853, 1, 1, 3, f352, .act (.dir .right), f353, .ok⟩,
  ⟨854, 1, 1, 3, f353, .act (.dir .down), f354, .ok⟩,
  ⟨855, 1, 1, 3, f354, .act (.dir .left), f355, .ok⟩,
  ⟨856, 1, 1, 3, f355, .act (.dir .up), f356, .ok⟩,
  ⟨857, 1, 1, 3, f356, .act (.click 15 45), f357, .ok⟩,
  ⟨858, 1, 1, 3, f357, .act (.dir .down), f358, .ok⟩,
  ⟨859, 1, 1, 3, f358, .act (.dir .left), f359, .ok⟩,
  ⟨860, 1, 1, 3, f359, .act (.dir .up), f360, .ok⟩,
  ⟨861, 1, 1, 3, f360, .act (.dir .up), f361, .ok⟩,
  ⟨862, 1, 1, 3, f361, .act (.dir .up), f362, .ok⟩,
  ⟨863, 1, 1, 3, f362, .act (.dir .right), f363, .ok⟩,
  ⟨864, 1, 1, 3, f363, .act (.dir .left), f364, .ok⟩,
  ⟨865, 1, 1, 3, f364, .act (.dir .left), f365, .ok⟩,
  ⟨866, 1, 1, 3, f365, .act (.click 48 42), f366, .ok⟩,
  ⟨867, 1, 1, 3, f366, .act (.dir .up), f367, .ok⟩,
  ⟨868, 1, 1, 3, f367, .act (.dir .right), f368, .ok⟩,
  ⟨869, 1, 1, 3, f368, .act (.dir .right), f369, .ok⟩,
  ⟨870, 1, 1, 3, f369, .act (.click 12 18), f370, .ok⟩,
  ⟨871, 1, 1, 3, f370, .act (.dir .up), f371, .ok⟩,
  ⟨872, 1, 1, 3, f371, .act (.dir .up), f372, .ok⟩,
  ⟨873, 1, 1, 3, f372, .act (.dir .up), f373, .ok⟩,
  ⟨874, 1, 1, 3, f373, .act (.dir .left), f374, .ok⟩,
  ⟨875, 1, 1, 3, f374, .act (.click 33 42), f375, .ok⟩,
  ⟨876, 1, 1, 3, f375, .act (.dir .down), f376, .ok⟩,
  ⟨877, 1, 1, 3, f376, .act (.dir .down), f377, .ok⟩,
  ⟨878, 1, 1, 3, f377, .act (.dir .down), f378, .ok⟩,
  ⟨879, 1, 1, 3, f378, .act (.dir .right), f379, .ok⟩,
  ⟨880, 1, 1, 3, f379, .act (.dir .right), f380, .ok⟩,
  ⟨881, 1, 1, 3, f380, .act (.dir .right), f381, .ok⟩,
  ⟨882, 1, 1, 3, f381, .act (.dir .right), f382, .ok⟩,
  ⟨883, 1, 1, 3, f382, .act (.dir .right), f383, .ok⟩,
  ⟨884, 1, 2, 3, f383, .act (.dir .right), f384, .levelup⟩,
  ⟨885, 2, 2, 3, f384, .act (.dir .down), f385, .ok⟩,
  ⟨886, 2, 2, 3, f385, .act (.dir .down), f386, .ok⟩,
  ⟨887, 2, 2, 3, f386, .act (.dir .down), f387, .ok⟩,
  ⟨888, 2, 2, 3, f387, .act (.dir .down), f388, .ok⟩,
  ⟨889, 2, 2, 3, f388, .act (.dir .down), f389, .ok⟩,
  ⟨890, 2, 2, 3, f389, .act (.dir .left), f390, .ok⟩,
  ⟨891, 2, 2, 3, f390, .act (.dir .left), f391, .ok⟩,
  ⟨892, 2, 2, 3, f391, .act (.dir .left), f392, .ok⟩,
  ⟨893, 2, 2, 3, f392, .act (.dir .right), f393, .ok⟩,
  ⟨894, 2, 2, 3, f393, .act (.dir .right), f394, .ok⟩,
  ⟨895, 2, 2, 3, f394, .act (.dir .right), f395, .ok⟩,
  ⟨896, 2, 2, 3, f395, .act (.dir .right), f396, .ok⟩,
  ⟨897, 2, 2, 3, f396, .act (.dir .right), f397, .ok⟩,
  ⟨898, 2, 2, 3, f397, .act (.dir .right), f398, .ok⟩,
  ⟨899, 2, 2, 3, f398, .act (.dir .right), f399, .ok⟩,
  ⟨900, 2, 2, 3, f399, .act (.dir .up), f400, .ok⟩,
  ⟨901, 2, 2, 3, f400, .act (.dir .left), f401, .ok⟩,
  ⟨902, 2, 2, 3, f401, .act (.dir .left), f402, .ok⟩,
  ⟨903, 2, 2, 3, f402, .act (.dir .left), f403, .ok⟩,
  ⟨904, 2, 2, 3, f403, .act (.dir .left), f404, .ok⟩,
  ⟨905, 2, 2, 3, f404, .act (.dir .left), f405, .ok⟩,
  ⟨906, 2, 2, 3, f405, .act (.dir .left), f406, .ok⟩,
  ⟨907, 2, 2, 3, f406, .act (.dir .left), f407, .ok⟩,
  ⟨908, 2, 2, 3, f407, .act (.dir .left), f408, .ok⟩,
  ⟨909, 2, 2, 3, f408, .act (.dir .left), f409, .ok⟩,
  ⟨910, 2, 2, 3, f409, .act (.dir .left), f410, .ok⟩,
  ⟨911, 2, 2, 3, f410, .act (.dir .left), f411, .ok⟩,
  ⟨912, 2, 2, 3, f411, .act (.dir .left), f412, .ok⟩,
  ⟨913, 2, 2, 3, f412, .act (.dir .down), f413, .ok⟩,
  ⟨914, 2, 2, 3, f413, .act (.dir .left), f414, .ok⟩,
  ⟨915, 2, 2, 3, f414, .act (.dir .left), f415, .ok⟩,
  ⟨916, 2, 2, 3, f415, .act (.dir .down), f416, .ok⟩,
  ⟨917, 2, 2, 3, f416, .act (.dir .down), f417, .ok⟩,
  ⟨918, 2, 2, 3, f417, .act (.dir .right), f418, .ok⟩,
  ⟨919, 2, 2, 3, f418, .act (.dir .right), f419, .ok⟩,
  ⟨920, 2, 2, 3, f419, .act (.dir .right), f420, .ok⟩,
  ⟨921, 2, 2, 3, f420, .act (.dir .right), f421, .ok⟩,
  ⟨922, 2, 2, 3, f421, .act (.dir .right), f422, .ok⟩,
  ⟨923, 2, 2, 3, f422, .act (.dir .up), f423, .ok⟩,
  ⟨924, 2, 2, 3, f423, .act (.dir .up), f424, .ok⟩,
  ⟨925, 2, 3, 3, f424, .act (.dir .right), f425, .levelup⟩,
  ⟨926, 3, 3, 3, f425, .act (.dir .right), f426, .ok⟩,
  ⟨927, 3, 3, 3, f426, .act (.dir .right), f427, .ok⟩,
  ⟨928, 3, 3, 3, f427, .act (.dir .right), f428, .ok⟩,
  ⟨929, 3, 3, 3, f428, .act (.dir .down), f429, .ok⟩,
  ⟨930, 3, 3, 3, f429, .act (.click 29 47), f430, .ok⟩,
  ⟨931, 3, 3, 3, f430, .act (.dir .left), f431, .ok⟩,
  ⟨932, 3, 3, 3, f431, .act (.dir .left), f432, .ok⟩,
  ⟨933, 3, 3, 3, f432, .act (.dir .left), f433, .ok⟩,
  ⟨934, 3, 3, 3, f433, .act (.dir .down), f434, .ok⟩,
  ⟨935, 3, 3, 3, f434, .act (.dir .right), f435, .ok⟩,
  ⟨936, 3, 3, 3, f435, .act (.dir .right), f436, .ok⟩,
  ⟨937, 3, 3, 3, f436, .act (.dir .right), f437, .ok⟩,
  ⟨938, 3, 3, 3, f437, .act (.dir .right), f438, .ok⟩,
  ⟨939, 3, 3, 3, f438, .act (.dir .right), f439, .ok⟩,
  ⟨940, 3, 3, 3, f439, .act (.dir .down), f440, .ok⟩,
  ⟨941, 3, 3, 3, f440, .act (.dir .down), f441, .ok⟩,
  ⟨942, 3, 3, 3, f441, .act (.dir .right), f442, .ok⟩,
  ⟨943, 3, 3, 3, f442, .act (.dir .up), f443, .ok⟩,
  ⟨944, 3, 3, 3, f443, .act (.dir .up), f444, .ok⟩,
  ⟨945, 3, 3, 3, f444, .act (.dir .right), f445, .ok⟩,
  ⟨946, 3, 3, 3, f445, .act (.click 29 29), f446, .ok⟩,
  ⟨947, 3, 3, 3, f446, .act (.dir .right), f447, .ok⟩,
  ⟨948, 3, 3, 3, f447, .act (.dir .down), f448, .ok⟩,
  ⟨949, 3, 3, 3, f448, .act (.dir .down), f449, .ok⟩,
  ⟨950, 3, 3, 3, f449, .act (.dir .right), f450, .ok⟩,
  ⟨951, 3, 3, 3, f450, .act (.dir .up), f451, .ok⟩,
  ⟨952, 3, 3, 3, f451, .act (.dir .up), f452, .ok⟩,
  ⟨953, 3, 3, 3, f452, .act (.dir .up), f453, .ok⟩,
  ⟨954, 3, 3, 3, f453, .act (.dir .right), f454, .ok⟩,
  ⟨955, 3, 3, 3, f454, .act (.dir .up), f455, .ok⟩,
  ⟨956, 3, 3, 3, f455, .act (.dir .up), f456, .ok⟩,
  ⟨957, 3, 3, 3, f456, .act (.dir .up), f457, .ok⟩,
  ⟨958, 3, 3, 3, f457, .act (.dir .right), f458, .ok⟩,
  ⟨959, 3, 3, 3, f458, .act (.dir .right), f459, .ok⟩,
  ⟨960, 3, 3, 3, f459, .act (.dir .right), f460, .ok⟩,
  ⟨961, 3, 3, 3, f460, .act (.dir .down), f461, .ok⟩,
  ⟨962, 3, 3, 3, f461, .act (.dir .down), f462, .ok⟩,
  ⟨963, 3, 4, 3, f462, .act (.dir .right), f463, .levelup⟩,
  ⟨964, 4, 4, 3, f463, .act (.dir .up), f464, .ok⟩,
  ⟨965, 4, 4, 3, f464, .act (.dir .up), f465, .ok⟩,
  ⟨966, 4, 4, 3, f465, .act (.dir .up), f466, .ok⟩,
  ⟨967, 4, 4, 3, f466, .act (.dir .up), f467, .ok⟩,
  ⟨968, 4, 4, 3, f467, .act (.dir .up), f468, .ok⟩,
  ⟨969, 4, 4, 3, f468, .act (.dir .up), f469, .ok⟩,
  ⟨970, 4, 4, 3, f469, .act (.dir .up), f470, .ok⟩,
  ⟨971, 4, 4, 3, f470, .act (.dir .up), f471, .ok⟩,
  ⟨972, 4, 4, 3, f471, .act (.dir .up), f472, .ok⟩,
  ⟨973, 4, 4, 3, f472, .act (.dir .up), f473, .ok⟩,
  ⟨974, 4, 4, 3, f473, .act (.dir .up), f474, .ok⟩,
  ⟨975, 4, 4, 3, f474, .act (.dir .up), f475, .ok⟩,
  ⟨976, 4, 4, 3, f475, .act (.dir .right), f476, .ok⟩,
  ⟨977, 4, 4, 3, f476, .act (.dir .right), f477, .ok⟩,
  ⟨978, 4, 4, 3, f477, .act (.dir .right), f478, .ok⟩,
  ⟨979, 4, 4, 3, f478, .act (.dir .right), f479, .ok⟩,
  ⟨980, 4, 4, 3, f479, .act (.dir .right), f480, .ok⟩,
  ⟨981, 4, 4, 3, f480, .act (.dir .right), f481, .ok⟩,
  ⟨982, 4, 4, 3, f481, .act (.dir .right), f482, .ok⟩,
  ⟨983, 4, 5, 3, f482, .act (.dir .down), f483, .levelup⟩,
  ⟨984, 5, 5, 3, f483, .act (.dir .left), f484, .ok⟩,
  ⟨985, 5, 5, 3, f484, .act (.dir .left), f485, .ok⟩,
  ⟨986, 5, 5, 3, f485, .act (.dir .left), f486, .ok⟩,
  ⟨987, 5, 5, 3, f486, .act (.dir .left), f487, .ok⟩,
  ⟨988, 5, 5, 3, f487, .act (.dir .left), f488, .ok⟩,
  ⟨989, 5, 5, 3, f488, .act (.dir .left), f489, .ok⟩,
  ⟨990, 5, 5, 3, f489, .act (.dir .down), f490, .ok⟩,
  ⟨991, 5, 5, 3, f490, .act (.dir .up), f491, .ok⟩,
  ⟨992, 5, 5, 3, f491, .act (.dir .up), f492, .ok⟩,
  ⟨993, 5, 5, 3, f492, .act (.dir .left), f493, .ok⟩,
  ⟨994, 5, 5, 3, f493, .act (.dir .left), f494, .ok⟩,
  ⟨995, 5, 5, 3, f494, .act (.dir .up), f495, .ok⟩,
  ⟨996, 5, 5, 3, f495, .act (.dir .up), f496, .ok⟩,
  ⟨997, 5, 5, 3, f496, .act (.dir .left), f497, .ok⟩,
  ⟨998, 5, 5, 3, f497, .act (.dir .left), f498, .ok⟩,
  ⟨999, 5, 5, 3, f498, .act (.dir .right), f499, .ok⟩]

def rows04 : List Row := [
  ⟨1000, 5, 5, 3, f499, .act (.dir .down), f500, .ok⟩,
  ⟨1001, 5, 5, 3, f500, .act (.dir .up), f501, .ok⟩,
  ⟨1002, 5, 5, 3, f501, .act (.dir .down), f502, .ok⟩,
  ⟨1003, 5, 5, 3, f502, .act (.dir .left), f503, .ok⟩,
  ⟨1004, 5, 5, 3, f503, .act (.dir .left), f504, .ok⟩,
  ⟨1005, 5, 5, 3, f504, .act (.dir .left), f505, .ok⟩,
  ⟨1006, 5, 5, 3, f505, .act (.dir .left), f506, .ok⟩,
  ⟨1007, 5, 5, 3, f506, .act (.dir .up), f507, .ok⟩,
  ⟨1008, 5, 5, 3, f507, .act (.dir .up), f508, .ok⟩,
  ⟨1009, 5, 5, 3, f508, .act (.dir .left), f509, .ok⟩,
  ⟨1010, 5, 5, 3, f509, .act (.dir .left), f510, .ok⟩,
  ⟨1011, 5, 5, 3, f510, .act (.dir .left), f511, .ok⟩,
  ⟨1012, 5, 5, 3, f511, .act (.dir .up), f512, .ok⟩,
  ⟨1013, 5, 5, 3, f512, .act (.dir .right), f513, .ok⟩,
  ⟨1014, 5, 5, 3, f513, .act (.dir .right), f514, .ok⟩,
  ⟨1015, 5, 5, 3, f514, .act (.dir .right), f515, .ok⟩,
  ⟨1016, 5, 5, 3, f515, .act (.dir .right), f516, .ok⟩,
  ⟨1017, 5, 5, 3, f516, .act (.dir .right), f517, .ok⟩,
  ⟨1018, 5, 5, 3, f517, .act (.dir .down), f518, .ok⟩,
  ⟨1019, 5, 5, 3, f518, .act (.dir .up), f519, .ok⟩,
  ⟨1020, 5, 5, 3, f519, .act (.dir .up), f520, .ok⟩,
  ⟨1021, 5, 5, 3, f520, .act (.dir .down), f521, .ok⟩,
  ⟨1022, 5, 5, 3, f521, .act (.dir .down), f522, .ok⟩,
  ⟨1023, 5, 5, 3, f522, .act (.dir .down), f523, .ok⟩,
  ⟨1024, 5, 5, 3, f523, .act (.dir .right), f524, .ok⟩,
  ⟨1025, 5, 5, 3, f524, .act (.dir .right), f525, .ok⟩,
  ⟨1026, 5, 5, 3, f525, .act (.dir .up), f526, .ok⟩,
  ⟨1027, 5, 5, 3, f526, .act (.dir .right), f527, .ok⟩,
  ⟨1028, 5, 5, 3, f527, .act (.dir .right), f528, .ok⟩,
  ⟨1029, 5, 5, 3, f528, .act (.dir .right), f529, .ok⟩,
  ⟨1030, 5, 5, 3, f529, .act (.dir .right), f530, .ok⟩,
  ⟨1031, 5, 5, 3, f530, .act (.dir .right), f531, .ok⟩,
  ⟨1032, 5, 5, 3, f531, .act (.dir .right), f532, .ok⟩,
  ⟨1033, 5, 5, 3, f532, .act (.dir .right), f533, .ok⟩,
  ⟨1034, 5, 5, 3, f533, .act (.dir .up), f534, .ok⟩,
  ⟨1035, 5, 6, 3, f534, .act (.dir .up), f535, .levelup⟩,
  ⟨1036, 6, 0, 4, f535, .reset, f0, .reset⟩,
  ⟨1037, 0, 0, 4, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1038, 0, 0, 4, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1039, 0, 0, 4, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1040, 0, 0, 4, f51, .act (.dir .left), f73, .ok⟩,
  ⟨1041, 0, 0, 4, f73, .act (.dir .down), f336, .ok⟩,
  ⟨1042, 0, 0, 4, f336, .act (.dir .left), f337, .ok⟩,
  ⟨1043, 0, 0, 4, f337, .act (.dir .left), f338, .ok⟩,
  ⟨1044, 0, 0, 4, f338, .act (.dir .left), f339, .ok⟩,
  ⟨1045, 0, 0, 4, f339, .act (.click 42 30), f340, .ok⟩,
  ⟨1046, 0, 0, 4, f340, .act (.dir .up), f341, .ok⟩,
  ⟨1047, 0, 1, 4, f341, .act (.dir .right), f82, .levelup⟩,
  ⟨1048, 1, 1, 4, f82, .act (.dir .up), f84, .ok⟩,
  ⟨1049, 1, 1, 4, f84, .act (.dir .up), f342, .ok⟩,
  ⟨1050, 1, 1, 4, f342, .act (.dir .up), f343, .ok⟩,
  ⟨1051, 1, 1, 4, f343, .act (.dir .up), f344, .ok⟩,
  ⟨1052, 1, 1, 4, f344, .act (.dir .left), f345, .ok⟩,
  ⟨1053, 1, 1, 4, f345, .act (.click 39 33), f346, .ok⟩,
  ⟨1054, 1, 1, 4, f346, .act (.dir .down), f347, .ok⟩,
  ⟨1055, 1, 1, 4, f347, .act (.dir .down), f348, .ok⟩,
  ⟨1056, 1, 1, 4, f348, .act (.dir .down), f349, .ok⟩,
  ⟨1057, 1, 1, 4, f349, .act (.dir .left), f350, .ok⟩,
  ⟨1058, 1, 1, 4, f350, .act (.dir .right), f351, .ok⟩,
  ⟨1059, 1, 1, 4, f351, .act (.dir .right), f352, .ok⟩,
  ⟨1060, 1, 1, 4, f352, .act (.dir .right), f353, .ok⟩,
  ⟨1061, 1, 1, 4, f353, .act (.dir .down), f354, .ok⟩,
  ⟨1062, 1, 1, 4, f354, .act (.dir .left), f355, .ok⟩,
  ⟨1063, 1, 1, 4, f355, .act (.dir .up), f356, .ok⟩,
  ⟨1064, 1, 1, 4, f356, .act (.click 15 45), f357, .ok⟩,
  ⟨1065, 1, 1, 4, f357, .act (.dir .down), f358, .ok⟩,
  ⟨1066, 1, 1, 4, f358, .act (.dir .left), f359, .ok⟩,
  ⟨1067, 1, 1, 4, f359, .act (.dir .up), f360, .ok⟩,
  ⟨1068, 1, 1, 4, f360, .act (.dir .up), f361, .ok⟩,
  ⟨1069, 1, 1, 4, f361, .act (.dir .up), f362, .ok⟩,
  ⟨1070, 1, 1, 4, f362, .act (.dir .right), f363, .ok⟩,
  ⟨1071, 1, 1, 4, f363, .act (.dir .left), f364, .ok⟩,
  ⟨1072, 1, 1, 4, f364, .act (.dir .left), f365, .ok⟩,
  ⟨1073, 1, 1, 4, f365, .act (.click 48 42), f366, .ok⟩,
  ⟨1074, 1, 1, 4, f366, .act (.dir .up), f367, .ok⟩,
  ⟨1075, 1, 1, 4, f367, .act (.dir .right), f368, .ok⟩,
  ⟨1076, 1, 1, 4, f368, .act (.dir .right), f369, .ok⟩,
  ⟨1077, 1, 1, 4, f369, .act (.click 12 18), f370, .ok⟩,
  ⟨1078, 1, 1, 4, f370, .act (.dir .up), f371, .ok⟩,
  ⟨1079, 1, 1, 4, f371, .act (.dir .up), f372, .ok⟩,
  ⟨1080, 1, 1, 4, f372, .act (.dir .up), f373, .ok⟩,
  ⟨1081, 1, 1, 4, f373, .act (.dir .left), f374, .ok⟩,
  ⟨1082, 1, 1, 4, f374, .act (.click 33 42), f375, .ok⟩,
  ⟨1083, 1, 1, 4, f375, .act (.dir .down), f376, .ok⟩,
  ⟨1084, 1, 1, 4, f376, .act (.dir .down), f377, .ok⟩,
  ⟨1085, 1, 1, 4, f377, .act (.dir .down), f378, .ok⟩,
  ⟨1086, 1, 1, 4, f378, .act (.dir .right), f379, .ok⟩,
  ⟨1087, 1, 1, 4, f379, .act (.dir .right), f380, .ok⟩,
  ⟨1088, 1, 1, 4, f380, .act (.dir .right), f381, .ok⟩,
  ⟨1089, 1, 1, 4, f381, .act (.dir .right), f382, .ok⟩,
  ⟨1090, 1, 1, 4, f382, .act (.dir .right), f383, .ok⟩,
  ⟨1091, 1, 2, 4, f383, .act (.dir .right), f384, .levelup⟩,
  ⟨1092, 2, 2, 4, f384, .act (.dir .down), f385, .ok⟩,
  ⟨1093, 2, 2, 4, f385, .act (.dir .down), f386, .ok⟩,
  ⟨1094, 2, 2, 4, f386, .act (.dir .down), f387, .ok⟩,
  ⟨1095, 2, 2, 4, f387, .act (.dir .down), f388, .ok⟩,
  ⟨1096, 2, 2, 4, f388, .act (.dir .down), f389, .ok⟩,
  ⟨1097, 2, 2, 4, f389, .act (.dir .left), f390, .ok⟩,
  ⟨1098, 2, 2, 4, f390, .act (.dir .left), f391, .ok⟩,
  ⟨1099, 2, 2, 4, f391, .act (.dir .left), f392, .ok⟩,
  ⟨1100, 2, 2, 4, f392, .act (.dir .right), f393, .ok⟩,
  ⟨1101, 2, 2, 4, f393, .act (.dir .right), f394, .ok⟩,
  ⟨1102, 2, 2, 4, f394, .act (.dir .right), f395, .ok⟩,
  ⟨1103, 2, 2, 4, f395, .act (.dir .right), f396, .ok⟩,
  ⟨1104, 2, 2, 4, f396, .act (.dir .right), f397, .ok⟩,
  ⟨1105, 2, 2, 4, f397, .act (.dir .right), f398, .ok⟩,
  ⟨1106, 2, 2, 4, f398, .act (.dir .right), f399, .ok⟩,
  ⟨1107, 2, 2, 4, f399, .act (.dir .up), f400, .ok⟩,
  ⟨1108, 2, 2, 4, f400, .act (.dir .left), f401, .ok⟩,
  ⟨1109, 2, 2, 4, f401, .act (.dir .left), f402, .ok⟩,
  ⟨1110, 2, 2, 4, f402, .act (.dir .left), f403, .ok⟩,
  ⟨1111, 2, 2, 4, f403, .act (.dir .left), f404, .ok⟩,
  ⟨1112, 2, 2, 4, f404, .act (.dir .left), f405, .ok⟩,
  ⟨1113, 2, 2, 4, f405, .act (.dir .left), f406, .ok⟩,
  ⟨1114, 2, 2, 4, f406, .act (.dir .left), f407, .ok⟩,
  ⟨1115, 2, 2, 4, f407, .act (.dir .left), f408, .ok⟩,
  ⟨1116, 2, 2, 4, f408, .act (.dir .left), f409, .ok⟩,
  ⟨1117, 2, 2, 4, f409, .act (.dir .left), f410, .ok⟩,
  ⟨1118, 2, 2, 4, f410, .act (.dir .left), f411, .ok⟩,
  ⟨1119, 2, 2, 4, f411, .act (.dir .left), f412, .ok⟩,
  ⟨1120, 2, 2, 4, f412, .act (.dir .down), f413, .ok⟩,
  ⟨1121, 2, 2, 4, f413, .act (.dir .left), f414, .ok⟩,
  ⟨1122, 2, 2, 4, f414, .act (.dir .left), f415, .ok⟩,
  ⟨1123, 2, 2, 4, f415, .act (.dir .down), f416, .ok⟩,
  ⟨1124, 2, 2, 4, f416, .act (.dir .down), f417, .ok⟩,
  ⟨1125, 2, 2, 4, f417, .act (.dir .right), f418, .ok⟩,
  ⟨1126, 2, 2, 4, f418, .act (.dir .right), f419, .ok⟩,
  ⟨1127, 2, 2, 4, f419, .act (.dir .right), f420, .ok⟩,
  ⟨1128, 2, 2, 4, f420, .act (.dir .right), f421, .ok⟩,
  ⟨1129, 2, 2, 4, f421, .act (.dir .right), f422, .ok⟩,
  ⟨1130, 2, 2, 4, f422, .act (.dir .up), f423, .ok⟩,
  ⟨1131, 2, 2, 4, f423, .act (.dir .up), f424, .ok⟩,
  ⟨1132, 2, 3, 4, f424, .act (.dir .right), f425, .levelup⟩,
  ⟨1133, 3, 3, 4, f425, .act (.dir .right), f426, .ok⟩,
  ⟨1134, 3, 3, 4, f426, .act (.dir .right), f427, .ok⟩,
  ⟨1135, 3, 3, 4, f427, .act (.dir .right), f428, .ok⟩,
  ⟨1136, 3, 3, 4, f428, .act (.dir .down), f429, .ok⟩,
  ⟨1137, 3, 3, 4, f429, .act (.click 29 47), f430, .ok⟩,
  ⟨1138, 3, 3, 4, f430, .act (.dir .left), f431, .ok⟩,
  ⟨1139, 3, 3, 4, f431, .act (.dir .left), f432, .ok⟩,
  ⟨1140, 3, 3, 4, f432, .act (.dir .left), f433, .ok⟩,
  ⟨1141, 3, 3, 4, f433, .act (.dir .down), f434, .ok⟩,
  ⟨1142, 3, 3, 4, f434, .act (.dir .right), f435, .ok⟩,
  ⟨1143, 3, 3, 4, f435, .act (.dir .right), f436, .ok⟩,
  ⟨1144, 3, 3, 4, f436, .act (.dir .right), f437, .ok⟩,
  ⟨1145, 3, 3, 4, f437, .act (.dir .right), f438, .ok⟩,
  ⟨1146, 3, 3, 4, f438, .act (.dir .right), f439, .ok⟩,
  ⟨1147, 3, 3, 4, f439, .act (.dir .down), f440, .ok⟩,
  ⟨1148, 3, 3, 4, f440, .act (.dir .down), f441, .ok⟩,
  ⟨1149, 3, 3, 4, f441, .act (.dir .right), f442, .ok⟩,
  ⟨1150, 3, 3, 4, f442, .act (.dir .up), f443, .ok⟩,
  ⟨1151, 3, 3, 4, f443, .act (.dir .up), f444, .ok⟩,
  ⟨1152, 3, 3, 4, f444, .act (.dir .right), f445, .ok⟩,
  ⟨1153, 3, 3, 4, f445, .act (.click 29 29), f446, .ok⟩,
  ⟨1154, 3, 3, 4, f446, .act (.dir .right), f447, .ok⟩,
  ⟨1155, 3, 3, 4, f447, .act (.dir .down), f448, .ok⟩,
  ⟨1156, 3, 3, 4, f448, .act (.dir .down), f449, .ok⟩,
  ⟨1157, 3, 3, 4, f449, .act (.dir .right), f450, .ok⟩,
  ⟨1158, 3, 3, 4, f450, .act (.dir .up), f451, .ok⟩,
  ⟨1159, 3, 3, 4, f451, .act (.dir .up), f452, .ok⟩,
  ⟨1160, 3, 3, 4, f452, .act (.dir .up), f453, .ok⟩,
  ⟨1161, 3, 3, 4, f453, .act (.dir .right), f454, .ok⟩,
  ⟨1162, 3, 3, 4, f454, .act (.dir .up), f455, .ok⟩,
  ⟨1163, 3, 3, 4, f455, .act (.dir .up), f456, .ok⟩,
  ⟨1164, 3, 3, 4, f456, .act (.dir .up), f457, .ok⟩,
  ⟨1165, 3, 3, 4, f457, .act (.dir .right), f458, .ok⟩,
  ⟨1166, 3, 3, 4, f458, .act (.dir .right), f459, .ok⟩,
  ⟨1167, 3, 3, 4, f459, .act (.dir .right), f460, .ok⟩,
  ⟨1168, 3, 3, 4, f460, .act (.dir .down), f461, .ok⟩,
  ⟨1169, 3, 3, 4, f461, .act (.dir .down), f462, .ok⟩,
  ⟨1170, 3, 4, 4, f462, .act (.dir .right), f463, .levelup⟩,
  ⟨1171, 4, 4, 4, f463, .act (.dir .up), f464, .ok⟩,
  ⟨1172, 4, 4, 4, f464, .act (.dir .up), f465, .ok⟩,
  ⟨1173, 4, 4, 4, f465, .act (.dir .up), f466, .ok⟩,
  ⟨1174, 4, 4, 4, f466, .act (.dir .up), f467, .ok⟩,
  ⟨1175, 4, 4, 4, f467, .act (.dir .up), f468, .ok⟩,
  ⟨1176, 4, 4, 4, f468, .act (.dir .up), f469, .ok⟩,
  ⟨1177, 4, 4, 4, f469, .act (.dir .up), f470, .ok⟩,
  ⟨1178, 4, 4, 4, f470, .act (.dir .up), f471, .ok⟩,
  ⟨1179, 4, 4, 4, f471, .act (.dir .up), f472, .ok⟩,
  ⟨1180, 4, 4, 4, f472, .act (.dir .up), f473, .ok⟩,
  ⟨1181, 4, 4, 4, f473, .act (.dir .up), f474, .ok⟩,
  ⟨1182, 4, 4, 4, f474, .act (.dir .up), f475, .ok⟩,
  ⟨1183, 4, 4, 4, f475, .act (.dir .right), f476, .ok⟩,
  ⟨1184, 4, 4, 4, f476, .act (.dir .right), f477, .ok⟩,
  ⟨1185, 4, 4, 4, f477, .act (.dir .right), f478, .ok⟩,
  ⟨1186, 4, 4, 4, f478, .act (.dir .right), f479, .ok⟩,
  ⟨1187, 4, 4, 4, f479, .act (.dir .right), f480, .ok⟩,
  ⟨1188, 4, 4, 4, f480, .act (.dir .right), f481, .ok⟩,
  ⟨1189, 4, 4, 4, f481, .act (.dir .right), f482, .ok⟩,
  ⟨1190, 4, 5, 4, f482, .act (.dir .down), f483, .levelup⟩,
  ⟨1191, 5, 5, 4, f483, .act (.dir .left), f484, .ok⟩,
  ⟨1192, 5, 5, 4, f484, .act (.dir .left), f485, .ok⟩,
  ⟨1193, 5, 5, 4, f485, .act (.dir .left), f486, .ok⟩,
  ⟨1194, 5, 5, 4, f486, .act (.dir .left), f487, .ok⟩,
  ⟨1195, 5, 5, 4, f487, .act (.dir .left), f488, .ok⟩,
  ⟨1196, 5, 5, 4, f488, .act (.dir .left), f489, .ok⟩,
  ⟨1197, 5, 5, 4, f489, .act (.dir .down), f490, .ok⟩,
  ⟨1198, 5, 5, 4, f490, .act (.dir .up), f491, .ok⟩,
  ⟨1199, 5, 5, 4, f491, .act (.dir .up), f492, .ok⟩,
  ⟨1200, 5, 5, 4, f492, .act (.dir .left), f493, .ok⟩,
  ⟨1201, 5, 5, 4, f493, .act (.dir .left), f494, .ok⟩,
  ⟨1202, 5, 5, 4, f494, .act (.dir .up), f495, .ok⟩,
  ⟨1203, 5, 5, 4, f495, .act (.dir .up), f496, .ok⟩,
  ⟨1204, 5, 5, 4, f496, .act (.dir .left), f497, .ok⟩,
  ⟨1205, 5, 5, 4, f497, .act (.dir .left), f498, .ok⟩,
  ⟨1206, 5, 5, 4, f498, .act (.dir .right), f499, .ok⟩,
  ⟨1207, 5, 5, 4, f499, .act (.dir .down), f500, .ok⟩,
  ⟨1208, 5, 5, 4, f500, .act (.dir .up), f501, .ok⟩,
  ⟨1209, 5, 5, 4, f501, .act (.dir .down), f502, .ok⟩,
  ⟨1210, 5, 5, 4, f502, .act (.dir .left), f503, .ok⟩,
  ⟨1211, 5, 5, 4, f503, .act (.dir .left), f504, .ok⟩,
  ⟨1212, 5, 5, 4, f504, .act (.dir .left), f505, .ok⟩,
  ⟨1213, 5, 5, 4, f505, .act (.dir .left), f506, .ok⟩,
  ⟨1214, 5, 5, 4, f506, .act (.dir .up), f507, .ok⟩,
  ⟨1215, 5, 5, 4, f507, .act (.dir .up), f508, .ok⟩,
  ⟨1216, 5, 5, 4, f508, .act (.dir .left), f509, .ok⟩,
  ⟨1217, 5, 5, 4, f509, .act (.dir .left), f510, .ok⟩,
  ⟨1218, 5, 5, 4, f510, .act (.dir .left), f511, .ok⟩,
  ⟨1219, 5, 5, 4, f511, .act (.dir .up), f512, .ok⟩,
  ⟨1220, 5, 5, 4, f512, .act (.dir .right), f513, .ok⟩,
  ⟨1221, 5, 5, 4, f513, .act (.dir .right), f514, .ok⟩,
  ⟨1222, 5, 5, 4, f514, .act (.dir .right), f515, .ok⟩,
  ⟨1223, 5, 5, 4, f515, .act (.dir .right), f516, .ok⟩,
  ⟨1224, 5, 5, 4, f516, .act (.dir .right), f517, .ok⟩,
  ⟨1225, 5, 5, 4, f517, .act (.dir .down), f518, .ok⟩,
  ⟨1226, 5, 5, 4, f518, .act (.dir .up), f519, .ok⟩,
  ⟨1227, 5, 5, 4, f519, .act (.dir .up), f520, .ok⟩,
  ⟨1228, 5, 5, 4, f520, .act (.dir .down), f521, .ok⟩,
  ⟨1229, 5, 5, 4, f521, .act (.dir .down), f522, .ok⟩,
  ⟨1230, 5, 5, 4, f522, .act (.dir .down), f523, .ok⟩,
  ⟨1231, 5, 5, 4, f523, .act (.dir .right), f524, .ok⟩,
  ⟨1232, 5, 5, 4, f524, .act (.dir .right), f525, .ok⟩,
  ⟨1233, 5, 5, 4, f525, .act (.dir .up), f526, .ok⟩,
  ⟨1234, 5, 5, 4, f526, .act (.dir .right), f527, .ok⟩,
  ⟨1235, 5, 5, 4, f527, .act (.dir .right), f528, .ok⟩,
  ⟨1236, 5, 5, 4, f528, .act (.dir .right), f529, .ok⟩,
  ⟨1237, 5, 5, 4, f529, .act (.dir .right), f530, .ok⟩,
  ⟨1238, 5, 5, 4, f530, .act (.dir .right), f531, .ok⟩,
  ⟨1239, 5, 5, 4, f531, .act (.dir .right), f532, .ok⟩,
  ⟨1240, 5, 5, 4, f532, .act (.dir .right), f533, .ok⟩,
  ⟨1241, 5, 5, 4, f533, .act (.dir .up), f534, .ok⟩,
  ⟨1242, 5, 6, 4, f534, .act (.dir .up), f535, .levelup⟩,
  ⟨1243, 6, 0, 5, f535, .reset, f0, .reset⟩,
  ⟨1244, 0, 0, 6, f0, .reset, f0, .reset⟩,
  ⟨1245, 0, 0, 7, f0, .reset, f0, .reset⟩,
  ⟨1246, 0, 0, 7, f0, .act (.dir .up), f1, .ok⟩,
  ⟨1247, 0, 0, 7, f1, .act (.dir .down), f2, .ok⟩,
  ⟨1248, 0, 0, 7, f2, .act (.dir .left), f3, .ok⟩,
  ⟨1249, 0, 0, 7, f3, .act (.dir .right), f4, .ok⟩]

def rows05 : List Row := [
  ⟨1250, 0, 0, 7, f4, .act (.dir .up), f5, .ok⟩,
  ⟨1251, 0, 0, 7, f5, .act (.dir .up), f6, .ok⟩,
  ⟨1252, 0, 0, 7, f6, .act (.dir .up), f7, .ok⟩,
  ⟨1253, 0, 0, 7, f7, .act (.dir .up), f8, .ok⟩,
  ⟨1254, 0, 0, 7, f8, .act (.dir .up), f9, .ok⟩,
  ⟨1255, 0, 0, 7, f9, .act (.dir .up), f9, .ok⟩,
  ⟨1256, 0, 0, 7, f9, .act (.dir .up), f10, .ok⟩,
  ⟨1257, 0, 0, 7, f10, .act (.dir .up), f11, .ok⟩,
  ⟨1258, 0, 0, 7, f11, .act (.dir .up), f11, .ok⟩,
  ⟨1259, 0, 0, 7, f11, .act (.dir .up), f12, .ok⟩,
  ⟨1260, 0, 0, 7, f12, .act (.dir .right), f13, .ok⟩,
  ⟨1261, 0, 0, 7, f13, .act (.dir .right), f13, .ok⟩,
  ⟨1262, 0, 0, 7, f13, .act (.dir .right), f14, .ok⟩,
  ⟨1263, 0, 0, 7, f14, .act (.dir .right), f15, .ok⟩,
  ⟨1264, 0, 0, 7, f15, .act (.dir .right), f15, .ok⟩,
  ⟨1265, 0, 0, 7, f15, .act (.dir .right), f16, .ok⟩,
  ⟨1266, 0, 0, 7, f16, .act (.dir .right), f16, .ok⟩,
  ⟨1267, 0, 0, 7, f16, .act (.dir .right), f17, .ok⟩,
  ⟨1268, 0, 0, 7, f17, .act (.dir .right), f18, .ok⟩,
  ⟨1269, 0, 0, 7, f18, .act (.dir .right), f18, .ok⟩,
  ⟨1270, 0, 0, 7, f18, .act (.dir .down), f19, .ok⟩,
  ⟨1271, 0, 0, 7, f19, .act (.dir .down), f20, .ok⟩,
  ⟨1272, 0, 0, 7, f20, .act (.dir .down), f21, .ok⟩,
  ⟨1273, 0, 0, 7, f21, .act (.dir .left), f22, .ok⟩,
  ⟨1274, 0, 0, 7, f22, .act (.dir .left), f23, .ok⟩,
  ⟨1275, 0, 0, 7, f23, .act (.dir .left), f24, .ok⟩,
  ⟨1276, 0, 0, 7, f24, .act (.dir .left), f25, .ok⟩,
  ⟨1277, 0, 0, 7, f25, .act (.dir .left), f25, .ok⟩,
  ⟨1278, 0, 0, 7, f25, .act (.dir .left), f26, .ok⟩,
  ⟨1279, 0, 0, 7, f26, .act (.dir .left), f27, .ok⟩,
  ⟨1280, 0, 0, 7, f27, .act (.dir .left), f27, .ok⟩,
  ⟨1281, 0, 0, 7, f27, .act (.dir .left), f28, .ok⟩,
  ⟨1282, 0, 0, 7, f28, .act (.dir .left), f29, .ok⟩,
  ⟨1283, 0, 0, 7, f29, .act (.dir .right), f30, .ok⟩,
  ⟨1284, 0, 0, 7, f30, .act (.dir .right), f31, .ok⟩,
  ⟨1285, 0, 0, 7, f31, .act (.dir .right), f32, .ok⟩,
  ⟨1286, 0, 0, 7, f32, .act (.dir .right), f33, .ok⟩,
  ⟨1287, 0, 0, 7, f33, .act (.dir .right), f34, .ok⟩,
  ⟨1288, 0, 0, 7, f34, .act (.dir .right), f35, .ok⟩,
  ⟨1289, 0, 0, 7, f35, .act (.dir .right), f36, .ok⟩,
  ⟨1290, 0, 0, 7, f36, .act (.dir .right), f37, .ok⟩,
  ⟨1291, 0, 0, 7, f37, .act (.dir .right), f37, .ok⟩,
  ⟨1292, 0, 0, 7, f37, .act (.dir .right), f38, .ok⟩,
  ⟨1293, 0, 0, 7, f38, .act (.dir .right), f39, .ok⟩,
  ⟨1294, 0, 0, 7, f39, .act (.dir .right), f39, .ok⟩,
  ⟨1295, 0, 0, 7, f39, .act (.dir .right), f40, .ok⟩,
  ⟨1296, 0, 0, 7, f40, .act (.dir .right), f41, .ok⟩,
  ⟨1297, 0, 0, 7, f41, .act (.dir .right), f41, .ok⟩,
  ⟨1298, 0, 0, 7, f41, .act (.dir .right), f42, .ok⟩,
  ⟨1299, 0, 0, 7, f42, .act (.dir .right), f43, .ok⟩,
  ⟨1300, 0, 0, 7, f43, .act (.dir .right), f43, .ok⟩,
  ⟨1301, 0, 0, 7, f43, .act (.dir .right), f44, .ok⟩,
  ⟨1302, 0, 0, 7, f44, .act (.dir .right), f44, .ok⟩,
  ⟨1303, 0, 0, 7, f44, .act (.dir .up), f45, .ok⟩,
  ⟨1304, 0, 0, 7, f45, .act (.dir .up), f46, .ok⟩,
  ⟨1305, 0, 0, 7, f46, .act (.dir .up), f46, .ok⟩,
  ⟨1306, 0, 0, 7, f46, .act (.dir .up), f47, .ok⟩,
  ⟨1307, 0, 0, 7, f47, .act (.dir .up), f48, .ok⟩,
  ⟨1308, 0, 0, 7, f48, .act (.dir .up), f48, .ok⟩,
  ⟨1309, 0, 0, 7, f48, .reset, f0, .reset⟩,
  ⟨1310, 0, 0, 7, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1311, 0, 0, 7, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1312, 0, 0, 7, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1313, 0, 0, 7, f51, .act (.dir .right), f52, .ok⟩,
  ⟨1314, 0, 0, 7, f52, .act (.dir .right), f53, .ok⟩,
  ⟨1315, 0, 0, 7, f53, .act (.dir .right), f54, .ok⟩,
  ⟨1316, 0, 0, 7, f54, .act (.dir .up), f54, .ok⟩,
  ⟨1317, 0, 0, 7, f54, .act (.dir .up), f55, .ok⟩,
  ⟨1318, 0, 0, 7, f55, .act (.dir .up), f56, .ok⟩,
  ⟨1319, 0, 0, 7, f56, .act (.dir .up), f56, .ok⟩,
  ⟨1320, 0, 0, 7, f56, .act (.dir .up), f57, .ok⟩,
  ⟨1321, 0, 0, 7, f57, .act (.dir .up), f58, .ok⟩,
  ⟨1322, 0, 0, 7, f58, .reset, f0, .reset⟩,
  ⟨1323, 0, 0, 7, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1324, 0, 0, 7, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1325, 0, 0, 7, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1326, 0, 0, 7, f51, .act (.click 34 13), f59, .ok⟩,
  ⟨1327, 0, 0, 7, f59, .act (.click 43 31), f60, .ok⟩,
  ⟨1328, 0, 0, 7, f60, .act (.click 25 31), f61, .ok⟩,
  ⟨1329, 0, 0, 7, f61, .act (.click 46 28), f61, .ok⟩,
  ⟨1330, 0, 0, 7, f61, .reset, f0, .reset⟩,
  ⟨1331, 0, 0, 7, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1332, 0, 0, 7, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1333, 0, 0, 7, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1334, 0, 0, 7, f51, .act (.click 46 28), f59, .ok⟩,
  ⟨1335, 0, 0, 7, f59, .act (.dir .up), f59, .ok⟩,
  ⟨1336, 0, 0, 7, f59, .act (.click 44 30), f62, .ok⟩,
  ⟨1337, 0, 0, 7, f62, .act (.click 44 30), f62, .ok⟩,
  ⟨1338, 0, 0, 7, f62, .act (.click 43 31), f63, .ok⟩,
  ⟨1339, 0, 0, 7, f63, .act (.click 44 30), f64, .ok⟩,
  ⟨1340, 0, 0, 7, f64, .reset, f0, .reset⟩,
  ⟨1341, 0, 0, 7, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1342, 0, 0, 7, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1343, 0, 0, 7, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1344, 0, 0, 7, f51, .act (.click 44 30), f60, .ok⟩,
  ⟨1345, 0, 0, 7, f60, .act (.click 44 30), f60, .ok⟩,
  ⟨1346, 0, 0, 7, f60, .act (.click 45 30), f62, .ok⟩,
  ⟨1347, 0, 0, 7, f62, .act (.dir .left), f65, .ok⟩,
  ⟨1348, 0, 0, 7, f65, .act (.dir .left), f66, .ok⟩,
  ⟨1349, 0, 0, 7, f66, .act (.dir .down), f67, .ok⟩,
  ⟨1350, 0, 0, 7, f67, .act (.dir .left), f67, .ok⟩,
  ⟨1351, 0, 0, 7, f67, .act (.dir .up), f68, .ok⟩,
  ⟨1352, 0, 0, 7, f68, .act (.dir .up), f69, .ok⟩,
  ⟨1353, 0, 0, 7, f69, .act (.dir .right), f70, .ok⟩,
  ⟨1354, 0, 0, 7, f70, .act (.dir .right), f71, .ok⟩,
  ⟨1355, 0, 0, 7, f71, .act (.dir .down), f72, .ok⟩,
  ⟨1356, 0, 0, 7, f72, .act (.click 44 30), f72, .ok⟩,
  ⟨1357, 0, 0, 7, f72, .reset, f0, .reset⟩,
  ⟨1358, 0, 0, 7, f0, .act (.dir .right), f49, .ok⟩,
  ⟨1359, 0, 0, 7, f49, .act (.dir .right), f50, .ok⟩,
  ⟨1360, 0, 0, 7, f50, .act (.dir .right), f51, .ok⟩,
  ⟨1361, 0, 0, 7, f51, .act (.dir .down), f59, .ok⟩,
  ⟨1362, 0, 0, 7, f59, .act (.dir .left), f73, .ok⟩,
  ⟨1363, 0, 0, 7, f73, .act (.dir .left), f74, .ok⟩,
  ⟨1364, 0, 0, 7, f74, .act (.dir .left), f75, .ok⟩,
  ⟨1365, 0, 0, 7, f75, .act (.dir .left), f76, .ok⟩,
  ⟨1366, 0, 0, 7, f76, .act (.click 43 31), f77, .ok⟩,
  ⟨1367, 0, 0, 7, f77, .act (.dir .up), f78, .ok⟩,
  ⟨1368, 0, 0, 7, f78, .act (.dir .right), f79, .ok⟩,
  ⟨1369, 0, 0, 7, f79, .act (.click 13 34), f80, .ok⟩,
  ⟨1370, 0, 0, 7, f80, .act (.click 13 31), f81, .ok⟩,
  ⟨1371, 0, 1, 7, f81, .act (.dir .down), f82, .levelup⟩,
  ⟨1372, 1, 1, 7, f82, .act (.click 46 28), f83, .ok⟩,
  ⟨1373, 1, 1, 7, f83, .act (.dir .up), f84, .ok⟩,
  ⟨1374, 1, 1, 7, f84, .act (.dir .down), f85, .ok⟩,
  ⟨1375, 1, 1, 7, f85, .act (.dir .left), f86, .ok⟩,
  ⟨1376, 1, 1, 7, f86, .act (.dir .right), f87, .ok⟩,
  ⟨1377, 1, 1, 7, f87, .act (.dir .up), f88, .ok⟩,
  ⟨1378, 1, 1, 7, f88, .act (.dir .up), f89, .ok⟩,
  ⟨1379, 1, 1, 7, f89, .act (.dir .up), f90, .ok⟩,
  ⟨1380, 1, 1, 7, f90, .act (.dir .up), f91, .ok⟩,
  ⟨1381, 1, 1, 7, f91, .act (.dir .right), f92, .ok⟩,
  ⟨1382, 1, 1, 7, f92, .act (.dir .right), f93, .ok⟩,
  ⟨1383, 1, 1, 7, f93, .act (.dir .up), f94, .ok⟩,
  ⟨1384, 1, 1, 7, f94, .act (.dir .up), f95, .ok⟩,
  ⟨1385, 1, 1, 7, f95, .act (.dir .up), f96, .ok⟩,
  ⟨1386, 1, 1, 7, f96, .act (.dir .up), f97, .ok⟩,
  ⟨1387, 1, 1, 7, f97, .act (.click 41 34), f97, .ok⟩,
  ⟨1388, 1, 1, 7, f97, .reset, f82, .reset⟩,
  ⟨1389, 1, 1, 7, f82, .act (.dir .up), f84, .ok⟩,
  ⟨1390, 1, 1, 7, f84, .act (.dir .down), f83, .ok⟩,
  ⟨1391, 1, 1, 7, f83, .act (.dir .left), f86, .ok⟩,
  ⟨1392, 1, 1, 7, f86, .act (.dir .right), f85, .ok⟩,
  ⟨1393, 1, 1, 7, f85, .act (.dir .up), f88, .ok⟩,
  ⟨1394, 1, 1, 7, f88, .act (.dir .up), f536, .ok⟩,
  ⟨1395, 1, 1, 7, f536, .act (.dir .up), f90, .ok⟩,
  ⟨1396, 1, 1, 7, f90, .act (.dir .up), f537, .ok⟩,
  ⟨1397, 1, 1, 7, f537, .act (.dir .up), f538, .ok⟩,
  ⟨1398, 1, 1, 7, f538, .act (.dir .up), f539, .ok⟩,
  ⟨1399, 1, 1, 7, f539, .act (.dir .up), f540, .ok⟩,
  ⟨1400, 1, 1, 7, f540, .act (.dir .up), f277, .ok⟩,
  ⟨1401, 1, 1, 7, f277, .act (.dir .up), f278, .ok⟩,
  ⟨1402, 1, 1, 7, f278, .act (.dir .up), f278, .ok⟩,
  ⟨1403, 1, 1, 7, f278, .act (.dir .right), f541, .ok⟩,
  ⟨1404, 1, 1, 7, f541, .act (.dir .right), f542, .ok⟩,
  ⟨1405, 1, 1, 7, f542, .act (.dir .right), f543, .ok⟩,
  ⟨1406, 1, 1, 7, f543, .act (.dir .right), f544, .ok⟩,
  ⟨1407, 1, 1, 7, f544, .act (.dir .right), f545, .ok⟩,
  ⟨1408, 1, 1, 7, f545, .act (.dir .right), f546, .ok⟩,
  ⟨1409, 1, 1, 7, f546, .act (.dir .right), f547, .ok⟩,
  ⟨1410, 1, 1, 7, f547, .act (.dir .right), f548, .ok⟩,
  ⟨1411, 1, 1, 7, f548, .act (.dir .right), f549, .ok⟩,
  ⟨1412, 1, 1, 7, f549, .act (.dir .right), f549, .ok⟩,
  ⟨1413, 1, 1, 7, f549, .act (.dir .right), f550, .ok⟩,
  ⟨1414, 1, 1, 7, f550, .act (.dir .right), f550, .ok⟩,
  ⟨1415, 1, 1, 7, f550, .act (.dir .down), f551, .ok⟩,
  ⟨1416, 1, 1, 7, f551, .act (.dir .down), f552, .ok⟩,
  ⟨1417, 1, 1, 7, f552, .act (.dir .down), f553, .ok⟩,
  ⟨1418, 1, 1, 7, f553, .act (.dir .left), f554, .ok⟩,
  ⟨1419, 1, 1, 7, f554, .act (.dir .left), f555, .ok⟩,
  ⟨1420, 1, 1, 7, f555, .act (.dir .left), f556, .ok⟩,
  ⟨1421, 1, 1, 7, f556, .act (.dir .left), f557, .ok⟩,
  ⟨1422, 1, 1, 7, f557, .act (.dir .left), f558, .ok⟩,
  ⟨1423, 1, 1, 7, f558, .act (.dir .left), f559, .ok⟩,
  ⟨1424, 1, 1, 7, f559, .act (.dir .left), f560, .ok⟩,
  ⟨1425, 1, 1, 7, f560, .act (.dir .left), f561, .ok⟩,
  ⟨1426, 1, 1, 7, f561, .act (.dir .left), f562, .ok⟩,
  ⟨1427, 1, 1, 7, f562, .act (.dir .left), f563, .ok⟩,
  ⟨1428, 1, 1, 7, f563, .act (.dir .right), f564, .ok⟩,
  ⟨1429, 1, 1, 7, f564, .act (.dir .right), f565, .ok⟩,
  ⟨1430, 1, 1, 7, f565, .act (.dir .right), f566, .ok⟩,
  ⟨1431, 1, 1, 7, f566, .act (.dir .right), f567, .ok⟩,
  ⟨1432, 1, 1, 7, f567, .act (.dir .right), f568, .ok⟩,
  ⟨1433, 1, 1, 7, f568, .act (.dir .right), f569, .ok⟩,
  ⟨1434, 1, 1, 7, f569, .act (.dir .right), f570, .ok⟩,
  ⟨1435, 1, 1, 7, f570, .act (.dir .right), f571, .ok⟩,
  ⟨1436, 1, 1, 7, f571, .act (.dir .right), f572, .ok⟩,
  ⟨1437, 1, 1, 7, f572, .act (.dir .right), f573, .ok⟩,
  ⟨1438, 1, 1, 7, f573, .act (.dir .right), f573, .ok⟩,
  ⟨1439, 1, 1, 7, f573, .act (.dir .right), f574, .ok⟩,
  ⟨1440, 1, 1, 7, f574, .act (.dir .right), f574, .ok⟩,
  ⟨1441, 1, 1, 7, f574, .act (.dir .right), f575, .ok⟩,
  ⟨1442, 1, 1, 7, f575, .act (.dir .right), f575, .ok⟩,
  ⟨1443, 1, 1, 7, f575, .act (.dir .right), f576, .ok⟩,
  ⟨1444, 1, 1, 7, f576, .act (.dir .right), f576, .ok⟩,
  ⟨1445, 1, 1, 7, f576, .act (.dir .right), f577, .ok⟩,
  ⟨1446, 1, 1, 7, f577, .act (.dir .right), f577, .ok⟩,
  ⟨1447, 1, 1, 7, f577, .act (.dir .up), f578, .ok⟩,
  ⟨1448, 1, 1, 7, f578, .act (.dir .up), f579, .ok⟩,
  ⟨1449, 1, 1, 7, f579, .act (.dir .up), f580, .ok⟩,
  ⟨1450, 1, 1, 7, f580, .act (.dir .up), f580, .ok⟩,
  ⟨1451, 1, 1, 7, f580, .act (.dir .up), f581, .ok⟩,
  ⟨1452, 1, 1, 7, f581, .act (.dir .up), f581, .ok⟩,
  ⟨1453, 1, 1, 7, f581, .reset, f82, .reset⟩,
  ⟨1454, 1, 1, 7, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1455, 1, 1, 7, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1456, 1, 1, 7, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1457, 1, 1, 7, f584, .act (.dir .right), f585, .ok⟩,
  ⟨1458, 1, 1, 7, f585, .act (.dir .right), f586, .ok⟩,
  ⟨1459, 1, 1, 7, f586, .act (.dir .right), f587, .ok⟩,
  ⟨1460, 1, 1, 7, f587, .act (.dir .up), f588, .ok⟩,
  ⟨1461, 1, 1, 7, f588, .act (.dir .up), f589, .ok⟩,
  ⟨1462, 1, 1, 7, f589, .act (.dir .up), f590, .ok⟩,
  ⟨1463, 1, 1, 7, f590, .act (.dir .up), f591, .ok⟩,
  ⟨1464, 1, 1, 7, f591, .act (.dir .up), f592, .ok⟩,
  ⟨1465, 1, 1, 7, f592, .act (.dir .up), f593, .ok⟩,
  ⟨1466, 1, 1, 7, f593, .reset, f82, .reset⟩,
  ⟨1467, 1, 1, 7, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1468, 1, 1, 7, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1469, 1, 1, 7, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1470, 1, 1, 7, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨1471, 1, 1, 7, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨1472, 1, 1, 7, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨1473, 1, 1, 7, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨1474, 1, 1, 7, f595, .reset, f82, .reset⟩,
  ⟨1475, 1, 1, 7, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1476, 1, 1, 7, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1477, 1, 1, 7, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1478, 1, 1, 7, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨1479, 1, 1, 7, f584, .act (.dir .up), f596, .ok⟩,
  ⟨1480, 1, 1, 7, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨1481, 1, 1, 7, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨1482, 1, 1, 7, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨1483, 1, 1, 7, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨1484, 1, 1, 7, f598, .reset, f82, .reset⟩,
  ⟨1485, 1, 1, 7, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1486, 1, 1, 7, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1487, 1, 1, 7, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1488, 1, 1, 7, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨1489, 1, 1, 7, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨1490, 1, 1, 7, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨1491, 1, 1, 7, f594, .act (.dir .left), f599, .ok⟩,
  ⟨1492, 1, 1, 7, f599, .act (.dir .left), f600, .ok⟩,
  ⟨1493, 1, 1, 7, f600, .act (.dir .down), f601, .ok⟩,
  ⟨1494, 1, 1, 7, f601, .act (.dir .left), f602, .ok⟩,
  ⟨1495, 1, 1, 7, f602, .act (.dir .up), f603, .ok⟩,
  ⟨1496, 1, 1, 7, f603, .act (.dir .up), f604, .ok⟩,
  ⟨1497, 1, 1, 7, f604, .act (.dir .right), f605, .ok⟩,
  ⟨1498, 1, 1, 7, f605, .act (.dir .right), f606, .ok⟩,
  ⟨1499, 1, 1, 7, f606, .act (.dir .down), f607, .ok⟩]

def rows06 : List Row := [
  ⟨1500, 1, 1, 7, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨1501, 1, 1, 7, f607, .reset, f82, .reset⟩,
  ⟨1502, 1, 1, 7, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1503, 1, 1, 7, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1504, 1, 1, 7, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1505, 1, 1, 7, f584, .act (.dir .down), f608, .ok⟩,
  ⟨1506, 1, 1, 7, f608, .act (.dir .left), f609, .ok⟩,
  ⟨1507, 1, 1, 7, f609, .act (.dir .left), f610, .ok⟩,
  ⟨1508, 1, 1, 7, f610, .act (.dir .left), f611, .ok⟩,
  ⟨1509, 1, 1, 7, f611, .act (.dir .left), f612, .ok⟩,
  ⟨1510, 1, 1, 7, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨1511, 1, 1, 7, f613, .act (.dir .up), f614, .ok⟩,
  ⟨1512, 1, 1, 7, f614, .act (.dir .right), f603, .ok⟩,
  ⟨1513, 1, 1, 7, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨1514, 1, 1, 7, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨1515, 1, 1, 7, f615, .act (.dir .down), f616, .ok⟩,
  ⟨1516, 1, 1, 7, f616, .act (.click 46 28), f617, .ok⟩,
  ⟨1517, 1, 1, 7, f617, .act (.dir .up), f618, .ok⟩,
  ⟨1518, 1, 1, 7, f618, .act (.dir .down), f619, .ok⟩,
  ⟨1519, 1, 1, 7, f619, .act (.dir .left), f620, .ok⟩,
  ⟨1520, 1, 1, 7, f620, .act (.dir .right), f621, .ok⟩,
  ⟨1521, 1, 0, 8, f621, .reset, f0, .reset⟩,
  ⟨1522, 1, 1, 9, f621, .act (.dir .up), f622, .ok⟩,
  ⟨1523, 1, 1, 9, f622, .act (.dir .up), f623, .ok⟩,
  ⟨1524, 1, 1, 9, f623, .act (.dir .up), f624, .ok⟩,
  ⟨1525, 1, 1, 9, f624, .act (.dir .up), f625, .ok⟩,
  ⟨1526, 1, 1, 9, f625, .act (.dir .right), f626, .ok⟩,
  ⟨1527, 1, 1, 9, f626, .act (.dir .right), f627, .ok⟩,
  ⟨1528, 1, 1, 9, f627, .act (.dir .up), f628, .ok⟩,
  ⟨1529, 1, 1, 9, f628, .act (.dir .up), f629, .ok⟩,
  ⟨1530, 1, 1, 9, f629, .act (.dir .up), f630, .ok⟩,
  ⟨1531, 1, 1, 9, f630, .act (.dir .up), f631, .ok⟩,
  ⟨1532, 1, 1, 9, f631, .act (.dir .up), f632, .ok⟩,
  ⟨1533, 1, 1, 9, f632, .act (.dir .up), f633, .ok⟩,
  ⟨1534, 1, 1, 9, f633, .act (.dir .down), f634, .ok⟩,
  ⟨1535, 1, 1, 9, f634, .act (.dir .left), f635, .ok⟩,
  ⟨1536, 1, 1, 9, f635, .act (.dir .right), f636, .ok⟩,
  ⟨1537, 1, 1, 9, f636, .act (.dir .up), f637, .ok⟩,
  ⟨1538, 1, 1, 9, f637, .act (.dir .left), f638, .ok⟩,
  ⟨1539, 1, 1, 9, f638, .act (.dir .left), f639, .ok⟩,
  ⟨1540, 1, 1, 9, f639, .act (.dir .left), f640, .ok⟩,
  ⟨1541, 1, 1, 9, f640, .act (.dir .left), f641, .ok⟩,
  ⟨1542, 1, 1, 9, f641, .act (.click 42 44), f641, .ok⟩,
  ⟨1543, 1, 1, 9, f641, .act (.dir .right), f642, .ok⟩,
  ⟨1544, 1, 1, 9, f642, .act (.dir .right), f643, .ok⟩,
  ⟨1545, 1, 1, 9, f643, .act (.dir .up), f644, .ok⟩,
  ⟨1546, 1, 1, 9, f644, .act (.dir .up), f644, .ok⟩,
  ⟨1547, 1, 1, 9, f644, .act (.dir .left), f645, .ok⟩,
  ⟨1548, 1, 1, 9, f645, .act (.dir .right), f646, .ok⟩,
  ⟨1549, 1, 1, 9, f646, .act (.dir .right), f647, .ok⟩,
  ⟨1550, 1, 1, 9, f647, .act (.dir .right), f648, .ok⟩,
  ⟨1551, 1, 1, 9, f648, .act (.dir .right), f649, .ok⟩,
  ⟨1552, 1, 1, 9, f649, .act (.dir .right), f650, .ok⟩,
  ⟨1553, 1, 1, 9, f650, .act (.dir .right), f651, .ok⟩,
  ⟨1554, 1, 1, 9, f651, .act (.dir .right), f652, .ok⟩,
  ⟨1555, 1, 1, 9, f652, .act (.dir .right), f653, .ok⟩,
  ⟨1556, 1, 1, 9, f653, .act (.dir .right), f654, .ok⟩,
  ⟨1557, 1, 1, 9, f654, .act (.dir .right), f655, .ok⟩,
  ⟨1558, 1, 1, 9, f655, .act (.dir .right), f655, .ok⟩,
  ⟨1559, 1, 1, 9, f655, .act (.dir .right), f656, .ok⟩,
  ⟨1560, 1, 1, 9, f656, .act (.dir .right), f656, .ok⟩,
  ⟨1561, 1, 1, 9, f656, .act (.dir .right), f657, .ok⟩,
  ⟨1562, 1, 1, 9, f657, .act (.dir .right), f657, .ok⟩,
  ⟨1563, 1, 1, 9, f657, .reset, f82, .reset⟩,
  ⟨1564, 1, 1, 9, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨1565, 1, 1, 9, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨1566, 1, 1, 9, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨1567, 1, 1, 9, f142, .act (.click 42 45), f142, .ok⟩,
  ⟨1568, 1, 1, 9, f142, .act (.click 47 44), f143, .ok⟩,
  ⟨1569, 1, 1, 9, f143, .act (.click 33 39), f143, .ok⟩,
  ⟨1570, 1, 1, 9, f143, .act (.dir .up), f144, .ok⟩,
  ⟨1571, 1, 1, 9, f144, .act (.click 42 42), f144, .ok⟩,
  ⟨1572, 1, 1, 9, f144, .act (.dir .up), f145, .ok⟩,
  ⟨1573, 1, 1, 9, f145, .act (.dir .up), f146, .ok⟩,
  ⟨1574, 1, 1, 9, f146, .act (.dir .up), f147, .ok⟩,
  ⟨1575, 1, 1, 9, f147, .act (.dir .down), f148, .ok⟩,
  ⟨1576, 1, 1, 9, f148, .act (.dir .down), f149, .ok⟩,
  ⟨1577, 1, 1, 9, f149, .act (.dir .down), f150, .ok⟩,
  ⟨1578, 1, 1, 9, f150, .act (.click 47 44), f151, .ok⟩,
  ⟨1579, 1, 1, 9, f151, .reset, f82, .reset⟩,
  ⟨1580, 1, 1, 9, f82, .act (.dir .up), f84, .ok⟩,
  ⟨1581, 1, 1, 9, f84, .act (.dir .down), f83, .ok⟩,
  ⟨1582, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨1583, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨1584, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨1585, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨1586, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨1587, 1, 1, 9, f90, .act (.dir .up), f537, .ok⟩,
  ⟨1588, 1, 1, 9, f537, .act (.dir .up), f538, .ok⟩,
  ⟨1589, 1, 1, 9, f538, .act (.dir .up), f539, .ok⟩,
  ⟨1590, 1, 1, 9, f539, .act (.dir .up), f540, .ok⟩,
  ⟨1591, 1, 1, 9, f540, .act (.dir .up), f277, .ok⟩,
  ⟨1592, 1, 1, 9, f277, .act (.dir .up), f278, .ok⟩,
  ⟨1593, 1, 1, 9, f278, .act (.dir .up), f278, .ok⟩,
  ⟨1594, 1, 1, 9, f278, .act (.dir .right), f541, .ok⟩,
  ⟨1595, 1, 1, 9, f541, .act (.dir .right), f542, .ok⟩,
  ⟨1596, 1, 1, 9, f542, .act (.dir .right), f543, .ok⟩,
  ⟨1597, 1, 1, 9, f543, .act (.dir .right), f544, .ok⟩,
  ⟨1598, 1, 1, 9, f544, .act (.dir .right), f545, .ok⟩,
  ⟨1599, 1, 1, 9, f545, .act (.dir .right), f546, .ok⟩,
  ⟨1600, 1, 1, 9, f546, .act (.dir .right), f547, .ok⟩,
  ⟨1601, 1, 1, 9, f547, .act (.dir .right), f548, .ok⟩,
  ⟨1602, 1, 1, 9, f548, .act (.dir .right), f549, .ok⟩,
  ⟨1603, 1, 1, 9, f549, .act (.dir .right), f549, .ok⟩,
  ⟨1604, 1, 1, 9, f549, .act (.dir .down), f658, .ok⟩,
  ⟨1605, 1, 1, 9, f658, .act (.dir .down), f659, .ok⟩,
  ⟨1606, 1, 1, 9, f659, .act (.dir .down), f660, .ok⟩,
  ⟨1607, 1, 1, 9, f660, .act (.dir .left), f661, .ok⟩,
  ⟨1608, 1, 1, 9, f661, .act (.dir .left), f662, .ok⟩,
  ⟨1609, 1, 1, 9, f662, .act (.dir .left), f663, .ok⟩,
  ⟨1610, 1, 1, 9, f663, .act (.dir .left), f664, .ok⟩,
  ⟨1611, 1, 1, 9, f664, .act (.dir .left), f665, .ok⟩,
  ⟨1612, 1, 1, 9, f665, .act (.dir .left), f666, .ok⟩,
  ⟨1613, 1, 1, 9, f666, .act (.dir .left), f667, .ok⟩,
  ⟨1614, 1, 1, 9, f667, .act (.dir .left), f668, .ok⟩,
  ⟨1615, 1, 1, 9, f668, .act (.dir .left), f669, .ok⟩,
  ⟨1616, 1, 1, 9, f669, .act (.dir .left), f670, .ok⟩,
  ⟨1617, 1, 1, 9, f670, .act (.dir .right), f562, .ok⟩,
  ⟨1618, 1, 1, 9, f562, .act (.dir .right), f671, .ok⟩,
  ⟨1619, 1, 1, 9, f671, .act (.dir .right), f672, .ok⟩,
  ⟨1620, 1, 1, 9, f672, .act (.dir .right), f673, .ok⟩,
  ⟨1621, 1, 1, 9, f673, .act (.dir .right), f674, .ok⟩,
  ⟨1622, 1, 1, 9, f674, .act (.dir .right), f675, .ok⟩,
  ⟨1623, 1, 1, 9, f675, .act (.dir .right), f676, .ok⟩,
  ⟨1624, 1, 1, 9, f676, .act (.dir .right), f677, .ok⟩,
  ⟨1625, 1, 1, 9, f677, .act (.dir .right), f678, .ok⟩,
  ⟨1626, 1, 1, 9, f678, .act (.dir .right), f679, .ok⟩,
  ⟨1627, 1, 1, 9, f679, .act (.dir .right), f679, .ok⟩,
  ⟨1628, 1, 1, 9, f679, .act (.dir .right), f573, .ok⟩,
  ⟨1629, 1, 1, 9, f573, .act (.dir .right), f573, .ok⟩,
  ⟨1630, 1, 1, 9, f573, .act (.dir .right), f574, .ok⟩,
  ⟨1631, 1, 1, 9, f574, .act (.dir .right), f574, .ok⟩,
  ⟨1632, 1, 1, 9, f574, .act (.dir .right), f575, .ok⟩,
  ⟨1633, 1, 1, 9, f575, .act (.dir .right), f575, .ok⟩,
  ⟨1634, 1, 1, 9, f575, .act (.dir .right), f576, .ok⟩,
  ⟨1635, 1, 1, 9, f576, .act (.dir .right), f576, .ok⟩,
  ⟨1636, 1, 1, 9, f576, .act (.dir .right), f577, .ok⟩,
  ⟨1637, 1, 1, 9, f577, .act (.dir .up), f680, .ok⟩,
  ⟨1638, 1, 1, 9, f680, .act (.dir .up), f579, .ok⟩,
  ⟨1639, 1, 1, 9, f579, .act (.dir .up), f681, .ok⟩,
  ⟨1640, 1, 1, 9, f681, .act (.dir .up), f580, .ok⟩,
  ⟨1641, 1, 1, 9, f580, .act (.dir .up), f580, .ok⟩,
  ⟨1642, 1, 1, 9, f580, .act (.dir .up), f581, .ok⟩,
  ⟨1643, 1, 1, 9, f581, .reset, f82, .reset⟩,
  ⟨1644, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1645, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1646, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1647, 1, 1, 9, f584, .act (.dir .right), f585, .ok⟩,
  ⟨1648, 1, 1, 9, f585, .act (.dir .right), f586, .ok⟩,
  ⟨1649, 1, 1, 9, f586, .act (.dir .right), f587, .ok⟩,
  ⟨1650, 1, 1, 9, f587, .act (.dir .up), f588, .ok⟩,
  ⟨1651, 1, 1, 9, f588, .act (.dir .up), f589, .ok⟩,
  ⟨1652, 1, 1, 9, f589, .act (.dir .up), f590, .ok⟩,
  ⟨1653, 1, 1, 9, f590, .act (.dir .up), f591, .ok⟩,
  ⟨1654, 1, 1, 9, f591, .act (.dir .up), f592, .ok⟩,
  ⟨1655, 1, 1, 9, f592, .act (.dir .up), f593, .ok⟩,
  ⟨1656, 1, 1, 9, f593, .reset, f82, .reset⟩,
  ⟨1657, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1658, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1659, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1660, 1, 1, 9, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨1661, 1, 1, 9, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨1662, 1, 1, 9, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨1663, 1, 1, 9, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨1664, 1, 1, 9, f595, .reset, f82, .reset⟩,
  ⟨1665, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1666, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1667, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1668, 1, 1, 9, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨1669, 1, 1, 9, f584, .act (.dir .up), f596, .ok⟩,
  ⟨1670, 1, 1, 9, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨1671, 1, 1, 9, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨1672, 1, 1, 9, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨1673, 1, 1, 9, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨1674, 1, 1, 9, f598, .reset, f82, .reset⟩,
  ⟨1675, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1676, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1677, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1678, 1, 1, 9, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨1679, 1, 1, 9, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨1680, 1, 1, 9, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨1681, 1, 1, 9, f594, .act (.dir .left), f599, .ok⟩,
  ⟨1682, 1, 1, 9, f599, .act (.dir .left), f600, .ok⟩,
  ⟨1683, 1, 1, 9, f600, .act (.dir .down), f601, .ok⟩,
  ⟨1684, 1, 1, 9, f601, .act (.dir .left), f602, .ok⟩,
  ⟨1685, 1, 1, 9, f602, .act (.dir .up), f603, .ok⟩,
  ⟨1686, 1, 1, 9, f603, .act (.dir .up), f604, .ok⟩,
  ⟨1687, 1, 1, 9, f604, .act (.dir .right), f605, .ok⟩,
  ⟨1688, 1, 1, 9, f605, .act (.dir .right), f606, .ok⟩,
  ⟨1689, 1, 1, 9, f606, .act (.dir .down), f607, .ok⟩,
  ⟨1690, 1, 1, 9, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨1691, 1, 1, 9, f607, .reset, f82, .reset⟩,
  ⟨1692, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1693, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1694, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1695, 1, 1, 9, f584, .act (.dir .down), f608, .ok⟩,
  ⟨1696, 1, 1, 9, f608, .act (.dir .left), f609, .ok⟩,
  ⟨1697, 1, 1, 9, f609, .act (.dir .left), f610, .ok⟩,
  ⟨1698, 1, 1, 9, f610, .act (.dir .left), f611, .ok⟩,
  ⟨1699, 1, 1, 9, f611, .act (.dir .left), f612, .ok⟩,
  ⟨1700, 1, 1, 9, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨1701, 1, 1, 9, f613, .act (.dir .up), f614, .ok⟩,
  ⟨1702, 1, 1, 9, f614, .act (.dir .right), f603, .ok⟩,
  ⟨1703, 1, 1, 9, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨1704, 1, 1, 9, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨1705, 1, 1, 9, f615, .act (.dir .down), f616, .ok⟩,
  ⟨1706, 1, 1, 9, f616, .act (.click 44 34), f682, .ok⟩,
  ⟨1707, 1, 1, 9, f682, .act (.click 45 34), f682, .ok⟩,
  ⟨1708, 1, 1, 9, f682, .act (.click 47 44), f683, .ok⟩,
  ⟨1709, 1, 1, 9, f683, .act (.click 55 37), f683, .ok⟩,
  ⟨1710, 1, 1, 9, f683, .act (.dir .down), f684, .ok⟩,
  ⟨1711, 1, 1, 9, f684, .act (.dir .down), f685, .ok⟩,
  ⟨1712, 1, 1, 9, f685, .act (.dir .down), f686, .ok⟩,
  ⟨1713, 1, 1, 9, f686, .act (.dir .down), f687, .ok⟩,
  ⟨1714, 1, 1, 9, f687, .act (.dir .right), f688, .ok⟩,
  ⟨1715, 1, 1, 9, f688, .act (.dir .right), f689, .ok⟩,
  ⟨1716, 1, 1, 9, f689, .act (.dir .right), f690, .ok⟩,
  ⟨1717, 1, 1, 9, f690, .act (.dir .right), f691, .ok⟩,
  ⟨1718, 1, 1, 9, f691, .act (.click 44 34), f692, .ok⟩,
  ⟨1719, 1, 1, 9, f692, .act (.click 44 34), f692, .ok⟩,
  ⟨1720, 1, 1, 9, f692, .act (.click 44 34), f693, .ok⟩,
  ⟨1721, 1, 1, 9, f693, .act (.click 44 34), f693, .ok⟩,
  ⟨1722, 1, 1, 9, f693, .act (.click 44 34), f694, .ok⟩,
  ⟨1723, 1, 1, 9, f694, .act (.click 44 34), f694, .ok⟩,
  ⟨1724, 1, 1, 9, f694, .act (.click 44 34), f695, .ok⟩,
  ⟨1725, 1, 1, 9, f695, .act (.click 44 34), f695, .ok⟩,
  ⟨1726, 1, 1, 9, f695, .act (.click 44 34), f696, .ok⟩,
  ⟨1727, 1, 1, 9, f696, .act (.click 44 34), f696, .ok⟩,
  ⟨1728, 1, 1, 9, f696, .act (.click 44 34), f697, .ok⟩,
  ⟨1729, 1, 1, 9, f697, .act (.click 44 34), f697, .ok⟩,
  ⟨1730, 1, 1, 9, f697, .act (.click 44 34), f698, .ok⟩,
  ⟨1731, 1, 1, 9, f698, .act (.click 44 34), f698, .ok⟩,
  ⟨1732, 1, 1, 9, f698, .act (.click 44 34), f699, .ok⟩,
  ⟨1733, 1, 1, 9, f699, .act (.click 44 34), f699, .ok⟩,
  ⟨1734, 1, 1, 9, f699, .act (.click 44 34), f700, .ok⟩,
  ⟨1735, 1, 1, 9, f700, .act (.click 44 34), f700, .ok⟩,
  ⟨1736, 1, 1, 9, f700, .act (.click 44 34), f701, .ok⟩,
  ⟨1737, 1, 1, 9, f701, .act (.click 44 34), f701, .ok⟩,
  ⟨1738, 1, 1, 9, f701, .act (.click 44 34), f702, .ok⟩,
  ⟨1739, 1, 1, 9, f702, .act (.click 44 34), f702, .ok⟩,
  ⟨1740, 1, 1, 9, f702, .act (.click 44 34), f703, .ok⟩,
  ⟨1741, 1, 1, 9, f703, .act (.click 44 34), f703, .ok⟩,
  ⟨1742, 1, 1, 9, f703, .act (.click 44 34), f704, .ok⟩,
  ⟨1743, 1, 1, 9, f704, .act (.click 44 34), f704, .ok⟩,
  ⟨1744, 1, 1, 9, f704, .act (.click 44 34), f705, .ok⟩,
  ⟨1745, 1, 1, 9, f705, .act (.click 44 34), f705, .ok⟩,
  ⟨1746, 1, 1, 9, f705, .act (.click 44 34), f706, .ok⟩,
  ⟨1747, 1, 1, 9, f706, .act (.click 44 34), f706, .ok⟩,
  ⟨1748, 1, 1, 9, f706, .act (.click 44 34), f707, .ok⟩,
  ⟨1749, 1, 1, 9, f707, .act (.click 44 34), f707, .ok⟩]

def rows07 : List Row := [
  ⟨1750, 1, 1, 9, f707, .act (.click 44 34), f708, .ok⟩,
  ⟨1751, 1, 1, 9, f708, .act (.click 44 34), f708, .ok⟩,
  ⟨1752, 1, 1, 9, f708, .act (.click 44 34), f709, .ok⟩,
  ⟨1753, 1, 1, 9, f709, .act (.click 44 34), f709, .ok⟩,
  ⟨1754, 1, 1, 9, f709, .act (.click 44 34), f710, .ok⟩,
  ⟨1755, 1, 1, 9, f710, .act (.click 44 34), f710, .ok⟩,
  ⟨1756, 1, 1, 9, f710, .act (.click 44 34), f711, .ok⟩,
  ⟨1757, 1, 1, 9, f711, .act (.click 44 34), f711, .ok⟩,
  ⟨1758, 1, 1, 9, f711, .act (.click 44 34), f712, .ok⟩,
  ⟨1759, 1, 1, 9, f712, .act (.click 44 34), f712, .ok⟩,
  ⟨1760, 1, 1, 9, f712, .act (.click 44 34), f713, .ok⟩,
  ⟨1761, 1, 1, 9, f713, .act (.click 44 34), f713, .ok⟩,
  ⟨1762, 1, 1, 9, f713, .act (.click 44 34), f714, .ok⟩,
  ⟨1763, 1, 1, 9, f714, .act (.click 44 34), f714, .ok⟩,
  ⟨1764, 1, 1, 9, f714, .act (.click 44 34), f715, .ok⟩,
  ⟨1765, 1, 1, 9, f715, .act (.click 44 34), f715, .ok⟩,
  ⟨1766, 1, 1, 9, f715, .act (.click 44 34), f716, .ok⟩,
  ⟨1767, 1, 1, 9, f716, .act (.click 44 34), f716, .ok⟩,
  ⟨1768, 1, 1, 9, f716, .act (.click 44 34), f717, .ok⟩,
  ⟨1769, 1, 1, 9, f717, .act (.click 44 34), f717, .ok⟩,
  ⟨1770, 1, 1, 9, f717, .act (.click 44 34), f718, .ok⟩,
  ⟨1771, 1, 1, 9, f718, .act (.click 44 34), f718, .ok⟩,
  ⟨1772, 1, 1, 9, f718, .act (.click 44 34), f719, .ok⟩,
  ⟨1773, 1, 1, 9, f719, .act (.click 44 34), f719, .ok⟩,
  ⟨1774, 1, 1, 9, f719, .act (.click 44 34), f720, .ok⟩,
  ⟨1775, 1, 1, 9, f720, .act (.click 44 34), f720, .ok⟩,
  ⟨1776, 1, 1, 9, f720, .act (.click 44 34), f721, .ok⟩,
  ⟨1777, 1, 1, 9, f721, .act (.click 44 34), f721, .ok⟩,
  ⟨1778, 1, 1, 9, f721, .act (.click 44 34), f722, .ok⟩,
  ⟨1779, 1, 1, 9, f722, .act (.click 44 34), f722, .ok⟩,
  ⟨1780, 1, 1, 9, f722, .act (.click 44 34), f723, .ok⟩,
  ⟨1781, 1, 1, 9, f723, .act (.click 44 34), f723, .ok⟩,
  ⟨1782, 1, 1, 9, f723, .act (.click 44 34), f724, .ok⟩,
  ⟨1783, 1, 1, 9, f724, .act (.click 44 34), f724, .ok⟩,
  ⟨1784, 1, 1, 9, f724, .act (.click 44 34), f725, .ok⟩,
  ⟨1785, 1, 1, 9, f725, .act (.click 44 34), f725, .ok⟩,
  ⟨1786, 1, 1, 9, f725, .act (.click 44 34), f726, .ok⟩,
  ⟨1787, 1, 1, 9, f726, .act (.click 44 34), f726, .ok⟩,
  ⟨1788, 1, 1, 9, f726, .act (.click 44 34), f727, .ok⟩,
  ⟨1789, 1, 1, 9, f727, .act (.click 44 34), f727, .ok⟩,
  ⟨1790, 1, 1, 9, f727, .act (.click 44 34), f728, .ok⟩,
  ⟨1791, 1, 1, 9, f728, .act (.click 44 34), f728, .ok⟩,
  ⟨1792, 1, 1, 9, f728, .act (.click 44 34), f729, .ok⟩,
  ⟨1793, 1, 1, 9, f729, .act (.click 44 34), f729, .ok⟩,
  ⟨1794, 1, 1, 9, f729, .act (.click 44 34), f730, .ok⟩,
  ⟨1795, 1, 1, 9, f730, .act (.click 44 34), f730, .ok⟩,
  ⟨1796, 1, 1, 9, f730, .act (.click 44 34), f731, .ok⟩,
  ⟨1797, 1, 1, 9, f731, .act (.click 44 34), f731, .ok⟩,
  ⟨1798, 1, 1, 9, f731, .act (.click 44 34), f732, .ok⟩,
  ⟨1799, 1, 1, 9, f732, .act (.click 44 34), f732, .ok⟩,
  ⟨1800, 1, 1, 9, f732, .act (.click 44 34), f733, .ok⟩,
  ⟨1801, 1, 1, 9, f733, .act (.click 44 34), f733, .ok⟩,
  ⟨1802, 1, 1, 9, f733, .act (.click 44 34), f734, .ok⟩,
  ⟨1803, 1, 1, 9, f734, .act (.click 44 34), f734, .ok⟩,
  ⟨1804, 1, 1, 9, f734, .act (.click 44 34), f735, .ok⟩,
  ⟨1805, 1, 1, 9, f735, .act (.click 44 34), f735, .ok⟩,
  ⟨1806, 1, 1, 9, f735, .act (.click 44 34), f736, .ok⟩,
  ⟨1807, 1, 1, 9, f736, .act (.click 44 34), f736, .ok⟩,
  ⟨1808, 1, 1, 9, f736, .act (.click 44 34), f737, .ok⟩,
  ⟨1809, 1, 1, 9, f737, .act (.click 44 34), f737, .ok⟩,
  ⟨1810, 1, 1, 9, f737, .act (.click 44 34), f738, .ok⟩,
  ⟨1811, 1, 1, 9, f738, .act (.click 44 34), f738, .ok⟩,
  ⟨1812, 1, 1, 9, f738, .act (.click 44 34), f739, .ok⟩,
  ⟨1813, 1, 1, 9, f739, .act (.click 44 34), f739, .ok⟩,
  ⟨1814, 1, 1, 9, f739, .act (.click 44 34), f740, .ok⟩,
  ⟨1815, 1, 1, 9, f740, .act (.click 44 34), f740, .ok⟩,
  ⟨1816, 1, 1, 9, f740, .act (.click 44 34), f741, .ok⟩,
  ⟨1817, 1, 1, 9, f741, .act (.click 44 34), f741, .ok⟩,
  ⟨1818, 1, 1, 9, f741, .act (.click 44 34), f742, .over⟩,
  ⟨1819, 1, 1, 9, f742, .reset, f82, .reset⟩,
  ⟨1820, 1, 1, 9, f82, .act (.click 46 28), f83, .ok⟩,
  ⟨1821, 1, 1, 9, f83, .act (.dir .up), f84, .ok⟩,
  ⟨1822, 1, 1, 9, f84, .act (.dir .down), f85, .ok⟩,
  ⟨1823, 1, 1, 9, f85, .act (.dir .left), f86, .ok⟩,
  ⟨1824, 1, 1, 9, f86, .act (.dir .right), f87, .ok⟩,
  ⟨1825, 1, 1, 9, f87, .act (.dir .up), f88, .ok⟩,
  ⟨1826, 1, 1, 9, f88, .act (.dir .up), f89, .ok⟩,
  ⟨1827, 1, 1, 9, f89, .act (.dir .up), f90, .ok⟩,
  ⟨1828, 1, 1, 9, f90, .act (.dir .up), f91, .ok⟩,
  ⟨1829, 1, 1, 9, f91, .act (.dir .right), f92, .ok⟩,
  ⟨1830, 1, 1, 9, f92, .act (.dir .right), f93, .ok⟩,
  ⟨1831, 1, 1, 9, f93, .act (.dir .up), f94, .ok⟩,
  ⟨1832, 1, 1, 9, f94, .act (.dir .up), f95, .ok⟩,
  ⟨1833, 1, 1, 9, f95, .act (.dir .up), f96, .ok⟩,
  ⟨1834, 1, 1, 9, f96, .act (.dir .up), f97, .ok⟩,
  ⟨1835, 1, 1, 9, f97, .act (.click 41 34), f97, .ok⟩,
  ⟨1836, 1, 1, 9, f97, .reset, f82, .reset⟩,
  ⟨1837, 1, 1, 9, f82, .act (.dir .up), f84, .ok⟩,
  ⟨1838, 1, 1, 9, f84, .act (.dir .down), f83, .ok⟩,
  ⟨1839, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨1840, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨1841, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨1842, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨1843, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨1844, 1, 1, 9, f90, .act (.dir .up), f537, .ok⟩,
  ⟨1845, 1, 1, 9, f537, .act (.dir .up), f538, .ok⟩,
  ⟨1846, 1, 1, 9, f538, .act (.dir .up), f539, .ok⟩,
  ⟨1847, 1, 1, 9, f539, .act (.dir .up), f540, .ok⟩,
  ⟨1848, 1, 1, 9, f540, .act (.dir .up), f277, .ok⟩,
  ⟨1849, 1, 1, 9, f277, .act (.dir .up), f278, .ok⟩,
  ⟨1850, 1, 1, 9, f278, .act (.dir .up), f278, .ok⟩,
  ⟨1851, 1, 1, 9, f278, .act (.dir .right), f541, .ok⟩,
  ⟨1852, 1, 1, 9, f541, .act (.dir .right), f542, .ok⟩,
  ⟨1853, 1, 1, 9, f542, .act (.dir .right), f543, .ok⟩,
  ⟨1854, 1, 1, 9, f543, .act (.dir .right), f544, .ok⟩,
  ⟨1855, 1, 1, 9, f544, .act (.dir .right), f545, .ok⟩,
  ⟨1856, 1, 1, 9, f545, .act (.dir .right), f546, .ok⟩,
  ⟨1857, 1, 1, 9, f546, .act (.dir .right), f547, .ok⟩,
  ⟨1858, 1, 1, 9, f547, .act (.dir .right), f548, .ok⟩,
  ⟨1859, 1, 1, 9, f548, .act (.dir .right), f549, .ok⟩,
  ⟨1860, 1, 1, 9, f549, .act (.dir .right), f549, .ok⟩,
  ⟨1861, 1, 1, 9, f549, .act (.dir .right), f550, .ok⟩,
  ⟨1862, 1, 1, 9, f550, .act (.dir .right), f550, .ok⟩,
  ⟨1863, 1, 1, 9, f550, .act (.dir .down), f551, .ok⟩,
  ⟨1864, 1, 1, 9, f551, .act (.dir .down), f552, .ok⟩,
  ⟨1865, 1, 1, 9, f552, .act (.dir .down), f553, .ok⟩,
  ⟨1866, 1, 1, 9, f553, .act (.dir .left), f554, .ok⟩,
  ⟨1867, 1, 1, 9, f554, .act (.dir .left), f555, .ok⟩,
  ⟨1868, 1, 1, 9, f555, .act (.dir .left), f556, .ok⟩,
  ⟨1869, 1, 1, 9, f556, .act (.dir .left), f557, .ok⟩,
  ⟨1870, 1, 1, 9, f557, .act (.dir .left), f558, .ok⟩,
  ⟨1871, 1, 1, 9, f558, .act (.dir .left), f559, .ok⟩,
  ⟨1872, 1, 1, 9, f559, .act (.dir .left), f560, .ok⟩,
  ⟨1873, 1, 1, 9, f560, .act (.dir .left), f561, .ok⟩,
  ⟨1874, 1, 1, 9, f561, .act (.dir .left), f562, .ok⟩,
  ⟨1875, 1, 1, 9, f562, .act (.dir .left), f563, .ok⟩,
  ⟨1876, 1, 1, 9, f563, .act (.dir .right), f564, .ok⟩,
  ⟨1877, 1, 1, 9, f564, .act (.dir .right), f565, .ok⟩,
  ⟨1878, 1, 1, 9, f565, .act (.dir .right), f566, .ok⟩,
  ⟨1879, 1, 1, 9, f566, .act (.dir .right), f567, .ok⟩,
  ⟨1880, 1, 1, 9, f567, .act (.dir .right), f568, .ok⟩,
  ⟨1881, 1, 1, 9, f568, .act (.dir .right), f569, .ok⟩,
  ⟨1882, 1, 1, 9, f569, .act (.dir .right), f570, .ok⟩,
  ⟨1883, 1, 1, 9, f570, .act (.dir .right), f571, .ok⟩,
  ⟨1884, 1, 1, 9, f571, .act (.dir .right), f572, .ok⟩,
  ⟨1885, 1, 1, 9, f572, .act (.dir .right), f573, .ok⟩,
  ⟨1886, 1, 1, 9, f573, .act (.dir .right), f573, .ok⟩,
  ⟨1887, 1, 1, 9, f573, .act (.dir .right), f574, .ok⟩,
  ⟨1888, 1, 1, 9, f574, .act (.dir .right), f574, .ok⟩,
  ⟨1889, 1, 1, 9, f574, .act (.dir .right), f575, .ok⟩,
  ⟨1890, 1, 1, 9, f575, .act (.dir .right), f575, .ok⟩,
  ⟨1891, 1, 1, 9, f575, .act (.dir .right), f576, .ok⟩,
  ⟨1892, 1, 1, 9, f576, .act (.dir .right), f576, .ok⟩,
  ⟨1893, 1, 1, 9, f576, .act (.dir .right), f577, .ok⟩,
  ⟨1894, 1, 1, 9, f577, .act (.dir .right), f577, .ok⟩,
  ⟨1895, 1, 1, 9, f577, .act (.dir .up), f578, .ok⟩,
  ⟨1896, 1, 1, 9, f578, .act (.dir .up), f579, .ok⟩,
  ⟨1897, 1, 1, 9, f579, .act (.dir .up), f580, .ok⟩,
  ⟨1898, 1, 1, 9, f580, .act (.dir .up), f580, .ok⟩,
  ⟨1899, 1, 1, 9, f580, .act (.dir .up), f581, .ok⟩,
  ⟨1900, 1, 1, 9, f581, .act (.dir .up), f581, .ok⟩,
  ⟨1901, 1, 1, 9, f581, .reset, f82, .reset⟩,
  ⟨1902, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1903, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1904, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1905, 1, 1, 9, f584, .act (.dir .right), f585, .ok⟩,
  ⟨1906, 1, 1, 9, f585, .act (.dir .right), f586, .ok⟩,
  ⟨1907, 1, 1, 9, f586, .act (.dir .right), f587, .ok⟩,
  ⟨1908, 1, 1, 9, f587, .act (.dir .up), f588, .ok⟩,
  ⟨1909, 1, 1, 9, f588, .act (.dir .up), f589, .ok⟩,
  ⟨1910, 1, 1, 9, f589, .act (.dir .up), f590, .ok⟩,
  ⟨1911, 1, 1, 9, f590, .act (.dir .up), f591, .ok⟩,
  ⟨1912, 1, 1, 9, f591, .act (.dir .up), f592, .ok⟩,
  ⟨1913, 1, 1, 9, f592, .act (.dir .up), f593, .ok⟩,
  ⟨1914, 1, 1, 9, f593, .reset, f82, .reset⟩,
  ⟨1915, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1916, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1917, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1918, 1, 1, 9, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨1919, 1, 1, 9, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨1920, 1, 1, 9, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨1921, 1, 1, 9, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨1922, 1, 1, 9, f595, .reset, f82, .reset⟩,
  ⟨1923, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1924, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1925, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1926, 1, 1, 9, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨1927, 1, 1, 9, f584, .act (.dir .up), f596, .ok⟩,
  ⟨1928, 1, 1, 9, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨1929, 1, 1, 9, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨1930, 1, 1, 9, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨1931, 1, 1, 9, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨1932, 1, 1, 9, f598, .reset, f82, .reset⟩,
  ⟨1933, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1934, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1935, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1936, 1, 1, 9, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨1937, 1, 1, 9, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨1938, 1, 1, 9, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨1939, 1, 1, 9, f594, .act (.dir .left), f599, .ok⟩,
  ⟨1940, 1, 1, 9, f599, .act (.dir .left), f600, .ok⟩,
  ⟨1941, 1, 1, 9, f600, .act (.dir .down), f601, .ok⟩,
  ⟨1942, 1, 1, 9, f601, .act (.dir .left), f602, .ok⟩,
  ⟨1943, 1, 1, 9, f602, .act (.dir .up), f603, .ok⟩,
  ⟨1944, 1, 1, 9, f603, .act (.dir .up), f604, .ok⟩,
  ⟨1945, 1, 1, 9, f604, .act (.dir .right), f605, .ok⟩,
  ⟨1946, 1, 1, 9, f605, .act (.dir .right), f606, .ok⟩,
  ⟨1947, 1, 1, 9, f606, .act (.dir .down), f607, .ok⟩,
  ⟨1948, 1, 1, 9, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨1949, 1, 1, 9, f607, .reset, f82, .reset⟩,
  ⟨1950, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨1951, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨1952, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨1953, 1, 1, 9, f584, .act (.dir .down), f608, .ok⟩,
  ⟨1954, 1, 1, 9, f608, .act (.dir .left), f609, .ok⟩,
  ⟨1955, 1, 1, 9, f609, .act (.dir .left), f610, .ok⟩,
  ⟨1956, 1, 1, 9, f610, .act (.dir .left), f611, .ok⟩,
  ⟨1957, 1, 1, 9, f611, .act (.dir .left), f612, .ok⟩,
  ⟨1958, 1, 1, 9, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨1959, 1, 1, 9, f613, .act (.dir .up), f614, .ok⟩,
  ⟨1960, 1, 1, 9, f614, .act (.dir .right), f603, .ok⟩,
  ⟨1961, 1, 1, 9, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨1962, 1, 1, 9, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨1963, 1, 1, 9, f615, .act (.dir .down), f616, .ok⟩,
  ⟨1964, 1, 1, 9, f616, .act (.click 46 28), f617, .ok⟩,
  ⟨1965, 1, 1, 9, f617, .act (.dir .up), f618, .ok⟩,
  ⟨1966, 1, 1, 9, f618, .act (.dir .down), f619, .ok⟩,
  ⟨1967, 1, 1, 9, f619, .act (.dir .left), f620, .ok⟩,
  ⟨1968, 1, 1, 9, f620, .act (.dir .right), f621, .ok⟩,
  ⟨1969, 1, 1, 9, f621, .act (.dir .up), f622, .ok⟩,
  ⟨1970, 1, 1, 9, f622, .act (.dir .up), f623, .ok⟩,
  ⟨1971, 1, 1, 9, f623, .act (.dir .up), f624, .ok⟩,
  ⟨1972, 1, 1, 9, f624, .act (.dir .up), f625, .ok⟩,
  ⟨1973, 1, 1, 9, f625, .act (.dir .right), f626, .ok⟩,
  ⟨1974, 1, 1, 9, f626, .act (.dir .right), f627, .ok⟩,
  ⟨1975, 1, 1, 9, f627, .act (.dir .up), f628, .ok⟩,
  ⟨1976, 1, 1, 9, f628, .act (.dir .up), f629, .ok⟩,
  ⟨1977, 1, 1, 9, f629, .act (.dir .up), f630, .ok⟩,
  ⟨1978, 1, 1, 9, f630, .act (.dir .up), f631, .ok⟩,
  ⟨1979, 1, 1, 9, f631, .act (.dir .up), f632, .ok⟩,
  ⟨1980, 1, 1, 9, f632, .act (.dir .up), f633, .ok⟩,
  ⟨1981, 1, 1, 9, f633, .act (.dir .down), f634, .ok⟩,
  ⟨1982, 1, 1, 9, f634, .act (.dir .left), f635, .ok⟩,
  ⟨1983, 1, 1, 9, f635, .act (.dir .right), f636, .ok⟩,
  ⟨1984, 1, 1, 9, f636, .act (.dir .up), f637, .ok⟩,
  ⟨1985, 1, 1, 9, f637, .act (.dir .left), f638, .ok⟩,
  ⟨1986, 1, 1, 9, f638, .act (.dir .left), f639, .ok⟩,
  ⟨1987, 1, 1, 9, f639, .act (.dir .left), f640, .ok⟩,
  ⟨1988, 1, 1, 9, f640, .act (.dir .left), f641, .ok⟩,
  ⟨1989, 1, 1, 9, f641, .act (.click 42 44), f641, .ok⟩,
  ⟨1990, 1, 1, 9, f641, .act (.dir .right), f642, .ok⟩,
  ⟨1991, 1, 1, 9, f642, .act (.dir .right), f643, .ok⟩,
  ⟨1992, 1, 1, 9, f643, .act (.dir .up), f644, .ok⟩,
  ⟨1993, 1, 1, 9, f644, .act (.dir .up), f644, .ok⟩,
  ⟨1994, 1, 1, 9, f644, .act (.dir .left), f645, .ok⟩,
  ⟨1995, 1, 1, 9, f645, .act (.dir .right), f646, .ok⟩,
  ⟨1996, 1, 1, 9, f646, .act (.dir .right), f647, .ok⟩,
  ⟨1997, 1, 1, 9, f647, .act (.dir .right), f648, .ok⟩,
  ⟨1998, 1, 1, 9, f648, .act (.dir .right), f649, .ok⟩,
  ⟨1999, 1, 1, 9, f649, .act (.dir .right), f650, .ok⟩]

def rows08 : List Row := [
  ⟨2000, 1, 1, 9, f650, .act (.dir .right), f651, .ok⟩,
  ⟨2001, 1, 1, 9, f651, .act (.dir .right), f652, .ok⟩,
  ⟨2002, 1, 1, 9, f652, .act (.dir .right), f653, .ok⟩,
  ⟨2003, 1, 1, 9, f653, .act (.dir .right), f654, .ok⟩,
  ⟨2004, 1, 1, 9, f654, .act (.dir .right), f655, .ok⟩,
  ⟨2005, 1, 1, 9, f655, .act (.dir .right), f655, .ok⟩,
  ⟨2006, 1, 1, 9, f655, .act (.dir .right), f656, .ok⟩,
  ⟨2007, 1, 1, 9, f656, .act (.dir .right), f656, .ok⟩,
  ⟨2008, 1, 1, 9, f656, .act (.dir .right), f657, .ok⟩,
  ⟨2009, 1, 1, 9, f657, .act (.dir .right), f657, .ok⟩,
  ⟨2010, 1, 1, 9, f657, .reset, f82, .reset⟩,
  ⟨2011, 1, 1, 9, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨2012, 1, 1, 9, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨2013, 1, 1, 9, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨2014, 1, 1, 9, f142, .act (.click 42 45), f142, .ok⟩,
  ⟨2015, 1, 1, 9, f142, .act (.click 47 44), f143, .ok⟩,
  ⟨2016, 1, 1, 9, f143, .act (.click 33 39), f143, .ok⟩,
  ⟨2017, 1, 1, 9, f143, .act (.dir .up), f144, .ok⟩,
  ⟨2018, 1, 1, 9, f144, .act (.click 42 42), f144, .ok⟩,
  ⟨2019, 1, 1, 9, f144, .act (.dir .up), f145, .ok⟩,
  ⟨2020, 1, 1, 9, f145, .act (.dir .up), f146, .ok⟩,
  ⟨2021, 1, 1, 9, f146, .act (.dir .up), f147, .ok⟩,
  ⟨2022, 1, 1, 9, f147, .act (.dir .down), f148, .ok⟩,
  ⟨2023, 1, 1, 9, f148, .act (.dir .down), f149, .ok⟩,
  ⟨2024, 1, 1, 9, f149, .act (.dir .down), f150, .ok⟩,
  ⟨2025, 1, 1, 9, f150, .act (.click 47 44), f151, .ok⟩,
  ⟨2026, 1, 1, 9, f151, .reset, f82, .reset⟩,
  ⟨2027, 1, 1, 9, f82, .act (.dir .up), f84, .ok⟩,
  ⟨2028, 1, 1, 9, f84, .act (.dir .down), f83, .ok⟩,
  ⟨2029, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨2030, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨2031, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨2032, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨2033, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨2034, 1, 1, 9, f90, .act (.dir .up), f537, .ok⟩,
  ⟨2035, 1, 1, 9, f537, .act (.dir .up), f538, .ok⟩,
  ⟨2036, 1, 1, 9, f538, .act (.dir .up), f539, .ok⟩,
  ⟨2037, 1, 1, 9, f539, .act (.dir .up), f540, .ok⟩,
  ⟨2038, 1, 1, 9, f540, .act (.dir .up), f277, .ok⟩,
  ⟨2039, 1, 1, 9, f277, .act (.dir .up), f278, .ok⟩,
  ⟨2040, 1, 1, 9, f278, .act (.dir .up), f278, .ok⟩,
  ⟨2041, 1, 1, 9, f278, .act (.dir .right), f541, .ok⟩,
  ⟨2042, 1, 1, 9, f541, .act (.dir .right), f542, .ok⟩,
  ⟨2043, 1, 1, 9, f542, .act (.dir .right), f543, .ok⟩,
  ⟨2044, 1, 1, 9, f543, .act (.dir .right), f544, .ok⟩,
  ⟨2045, 1, 1, 9, f544, .act (.dir .right), f545, .ok⟩,
  ⟨2046, 1, 1, 9, f545, .act (.dir .right), f546, .ok⟩,
  ⟨2047, 1, 1, 9, f546, .act (.dir .right), f547, .ok⟩,
  ⟨2048, 1, 1, 9, f547, .act (.dir .right), f548, .ok⟩,
  ⟨2049, 1, 1, 9, f548, .act (.dir .right), f549, .ok⟩,
  ⟨2050, 1, 1, 9, f549, .act (.dir .right), f549, .ok⟩,
  ⟨2051, 1, 1, 9, f549, .act (.dir .down), f658, .ok⟩,
  ⟨2052, 1, 1, 9, f658, .act (.dir .down), f659, .ok⟩,
  ⟨2053, 1, 1, 9, f659, .act (.dir .down), f660, .ok⟩,
  ⟨2054, 1, 1, 9, f660, .act (.dir .left), f661, .ok⟩,
  ⟨2055, 1, 1, 9, f661, .act (.dir .left), f662, .ok⟩,
  ⟨2056, 1, 1, 9, f662, .act (.dir .left), f663, .ok⟩,
  ⟨2057, 1, 1, 9, f663, .act (.dir .left), f664, .ok⟩,
  ⟨2058, 1, 1, 9, f664, .act (.dir .left), f665, .ok⟩,
  ⟨2059, 1, 1, 9, f665, .act (.dir .left), f666, .ok⟩,
  ⟨2060, 1, 1, 9, f666, .act (.dir .left), f667, .ok⟩,
  ⟨2061, 1, 1, 9, f667, .act (.dir .left), f668, .ok⟩,
  ⟨2062, 1, 1, 9, f668, .act (.dir .left), f669, .ok⟩,
  ⟨2063, 1, 1, 9, f669, .act (.dir .left), f670, .ok⟩,
  ⟨2064, 1, 1, 9, f670, .act (.dir .right), f562, .ok⟩,
  ⟨2065, 1, 1, 9, f562, .act (.dir .right), f671, .ok⟩,
  ⟨2066, 1, 1, 9, f671, .act (.dir .right), f672, .ok⟩,
  ⟨2067, 1, 1, 9, f672, .act (.dir .right), f673, .ok⟩,
  ⟨2068, 1, 1, 9, f673, .act (.dir .right), f674, .ok⟩,
  ⟨2069, 1, 1, 9, f674, .act (.dir .right), f675, .ok⟩,
  ⟨2070, 1, 1, 9, f675, .act (.dir .right), f676, .ok⟩,
  ⟨2071, 1, 1, 9, f676, .act (.dir .right), f677, .ok⟩,
  ⟨2072, 1, 1, 9, f677, .act (.dir .right), f678, .ok⟩,
  ⟨2073, 1, 1, 9, f678, .act (.dir .right), f679, .ok⟩,
  ⟨2074, 1, 1, 9, f679, .act (.dir .right), f679, .ok⟩,
  ⟨2075, 1, 1, 9, f679, .act (.dir .right), f573, .ok⟩,
  ⟨2076, 1, 1, 9, f573, .act (.dir .right), f573, .ok⟩,
  ⟨2077, 1, 1, 9, f573, .act (.dir .right), f574, .ok⟩,
  ⟨2078, 1, 1, 9, f574, .act (.dir .right), f574, .ok⟩,
  ⟨2079, 1, 1, 9, f574, .act (.dir .right), f575, .ok⟩,
  ⟨2080, 1, 1, 9, f575, .act (.dir .right), f575, .ok⟩,
  ⟨2081, 1, 1, 9, f575, .act (.dir .right), f576, .ok⟩,
  ⟨2082, 1, 1, 9, f576, .act (.dir .right), f576, .ok⟩,
  ⟨2083, 1, 1, 9, f576, .act (.dir .right), f577, .ok⟩,
  ⟨2084, 1, 1, 9, f577, .act (.dir .up), f680, .ok⟩,
  ⟨2085, 1, 1, 9, f680, .act (.dir .up), f579, .ok⟩,
  ⟨2086, 1, 1, 9, f579, .act (.dir .up), f681, .ok⟩,
  ⟨2087, 1, 1, 9, f681, .act (.dir .up), f580, .ok⟩,
  ⟨2088, 1, 1, 9, f580, .act (.dir .up), f580, .ok⟩,
  ⟨2089, 1, 1, 9, f580, .act (.dir .up), f581, .ok⟩,
  ⟨2090, 1, 1, 9, f581, .reset, f82, .reset⟩,
  ⟨2091, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2092, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2093, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2094, 1, 1, 9, f584, .act (.dir .right), f585, .ok⟩,
  ⟨2095, 1, 1, 9, f585, .act (.dir .right), f586, .ok⟩,
  ⟨2096, 1, 1, 9, f586, .act (.dir .right), f587, .ok⟩,
  ⟨2097, 1, 1, 9, f587, .act (.dir .up), f588, .ok⟩,
  ⟨2098, 1, 1, 9, f588, .act (.dir .up), f589, .ok⟩,
  ⟨2099, 1, 1, 9, f589, .act (.dir .up), f590, .ok⟩,
  ⟨2100, 1, 1, 9, f590, .act (.dir .up), f591, .ok⟩,
  ⟨2101, 1, 1, 9, f591, .act (.dir .up), f592, .ok⟩,
  ⟨2102, 1, 1, 9, f592, .act (.dir .up), f593, .ok⟩,
  ⟨2103, 1, 1, 9, f593, .reset, f82, .reset⟩,
  ⟨2104, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2105, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2106, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2107, 1, 1, 9, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨2108, 1, 1, 9, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨2109, 1, 1, 9, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨2110, 1, 1, 9, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨2111, 1, 1, 9, f595, .reset, f82, .reset⟩,
  ⟨2112, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2113, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2114, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2115, 1, 1, 9, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨2116, 1, 1, 9, f584, .act (.dir .up), f596, .ok⟩,
  ⟨2117, 1, 1, 9, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨2118, 1, 1, 9, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨2119, 1, 1, 9, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨2120, 1, 1, 9, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨2121, 1, 1, 9, f598, .reset, f82, .reset⟩,
  ⟨2122, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2123, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2124, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2125, 1, 1, 9, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨2126, 1, 1, 9, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨2127, 1, 1, 9, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨2128, 1, 1, 9, f594, .act (.dir .left), f599, .ok⟩,
  ⟨2129, 1, 1, 9, f599, .act (.dir .left), f600, .ok⟩,
  ⟨2130, 1, 1, 9, f600, .act (.dir .down), f601, .ok⟩,
  ⟨2131, 1, 1, 9, f601, .act (.dir .left), f602, .ok⟩,
  ⟨2132, 1, 1, 9, f602, .act (.dir .up), f603, .ok⟩,
  ⟨2133, 1, 1, 9, f603, .act (.dir .up), f604, .ok⟩,
  ⟨2134, 1, 1, 9, f604, .act (.dir .right), f605, .ok⟩,
  ⟨2135, 1, 1, 9, f605, .act (.dir .right), f606, .ok⟩,
  ⟨2136, 1, 1, 9, f606, .act (.dir .down), f607, .ok⟩,
  ⟨2137, 1, 1, 9, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨2138, 1, 1, 9, f607, .reset, f82, .reset⟩,
  ⟨2139, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2140, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2141, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2142, 1, 1, 9, f584, .act (.dir .down), f608, .ok⟩,
  ⟨2143, 1, 1, 9, f608, .act (.dir .left), f609, .ok⟩,
  ⟨2144, 1, 1, 9, f609, .act (.dir .left), f610, .ok⟩,
  ⟨2145, 1, 1, 9, f610, .act (.dir .left), f611, .ok⟩,
  ⟨2146, 1, 1, 9, f611, .act (.dir .left), f612, .ok⟩,
  ⟨2147, 1, 1, 9, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨2148, 1, 1, 9, f613, .act (.dir .up), f614, .ok⟩,
  ⟨2149, 1, 1, 9, f614, .act (.dir .right), f603, .ok⟩,
  ⟨2150, 1, 1, 9, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨2151, 1, 1, 9, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨2152, 1, 1, 9, f615, .act (.dir .down), f616, .ok⟩,
  ⟨2153, 1, 1, 9, f616, .act (.click 44 34), f682, .ok⟩,
  ⟨2154, 1, 1, 9, f682, .act (.click 45 34), f682, .ok⟩,
  ⟨2155, 1, 1, 9, f682, .act (.click 47 44), f683, .ok⟩,
  ⟨2156, 1, 1, 9, f683, .act (.click 55 37), f683, .ok⟩,
  ⟨2157, 1, 1, 9, f683, .act (.dir .down), f684, .ok⟩,
  ⟨2158, 1, 1, 9, f684, .act (.dir .down), f685, .ok⟩,
  ⟨2159, 1, 1, 9, f685, .act (.dir .down), f686, .ok⟩,
  ⟨2160, 1, 1, 9, f686, .act (.dir .down), f687, .ok⟩,
  ⟨2161, 1, 1, 9, f687, .act (.dir .right), f688, .ok⟩,
  ⟨2162, 1, 1, 9, f688, .act (.dir .right), f689, .ok⟩,
  ⟨2163, 1, 1, 9, f689, .act (.dir .right), f690, .ok⟩,
  ⟨2164, 1, 1, 9, f690, .act (.dir .right), f691, .ok⟩,
  ⟨2165, 1, 1, 9, f691, .act (.click 44 34), f692, .ok⟩,
  ⟨2166, 1, 1, 9, f692, .act (.click 44 34), f692, .ok⟩,
  ⟨2167, 1, 1, 9, f692, .act (.click 44 34), f693, .ok⟩,
  ⟨2168, 1, 1, 9, f693, .act (.click 44 34), f693, .ok⟩,
  ⟨2169, 1, 1, 9, f693, .act (.click 44 34), f694, .ok⟩,
  ⟨2170, 1, 1, 9, f694, .act (.click 44 34), f694, .ok⟩,
  ⟨2171, 1, 1, 9, f694, .act (.click 44 34), f695, .ok⟩,
  ⟨2172, 1, 1, 9, f695, .act (.click 44 34), f695, .ok⟩,
  ⟨2173, 1, 1, 9, f695, .act (.click 44 34), f696, .ok⟩,
  ⟨2174, 1, 1, 9, f696, .act (.click 44 34), f696, .ok⟩,
  ⟨2175, 1, 1, 9, f696, .act (.click 44 34), f697, .ok⟩,
  ⟨2176, 1, 1, 9, f697, .act (.click 44 34), f697, .ok⟩,
  ⟨2177, 1, 1, 9, f697, .act (.click 44 34), f698, .ok⟩,
  ⟨2178, 1, 1, 9, f698, .act (.click 44 34), f698, .ok⟩,
  ⟨2179, 1, 1, 9, f698, .act (.click 44 34), f699, .ok⟩,
  ⟨2180, 1, 1, 9, f699, .act (.click 44 34), f699, .ok⟩,
  ⟨2181, 1, 1, 9, f699, .act (.click 44 34), f700, .ok⟩,
  ⟨2182, 1, 1, 9, f700, .act (.click 44 34), f700, .ok⟩,
  ⟨2183, 1, 1, 9, f700, .act (.click 44 34), f701, .ok⟩,
  ⟨2184, 1, 1, 9, f701, .act (.click 44 34), f701, .ok⟩,
  ⟨2185, 1, 1, 9, f701, .act (.click 44 34), f702, .ok⟩,
  ⟨2186, 1, 1, 9, f702, .act (.click 44 34), f702, .ok⟩,
  ⟨2187, 1, 1, 9, f702, .act (.click 44 34), f703, .ok⟩,
  ⟨2188, 1, 1, 9, f703, .act (.click 44 34), f703, .ok⟩,
  ⟨2189, 1, 1, 9, f703, .act (.click 44 34), f704, .ok⟩,
  ⟨2190, 1, 1, 9, f704, .act (.click 44 34), f704, .ok⟩,
  ⟨2191, 1, 1, 9, f704, .act (.click 44 34), f705, .ok⟩,
  ⟨2192, 1, 1, 9, f705, .act (.click 44 34), f705, .ok⟩,
  ⟨2193, 1, 1, 9, f705, .act (.click 44 34), f706, .ok⟩,
  ⟨2194, 1, 1, 9, f706, .act (.click 44 34), f706, .ok⟩,
  ⟨2195, 1, 1, 9, f706, .act (.click 44 34), f707, .ok⟩,
  ⟨2196, 1, 1, 9, f707, .act (.click 44 34), f707, .ok⟩,
  ⟨2197, 1, 1, 9, f707, .act (.click 44 34), f708, .ok⟩,
  ⟨2198, 1, 1, 9, f708, .act (.click 44 34), f708, .ok⟩,
  ⟨2199, 1, 1, 9, f708, .act (.click 44 34), f709, .ok⟩,
  ⟨2200, 1, 1, 9, f709, .act (.click 44 34), f709, .ok⟩,
  ⟨2201, 1, 1, 9, f709, .act (.click 44 34), f710, .ok⟩,
  ⟨2202, 1, 1, 9, f710, .act (.click 44 34), f710, .ok⟩,
  ⟨2203, 1, 1, 9, f710, .act (.click 44 34), f711, .ok⟩,
  ⟨2204, 1, 1, 9, f711, .act (.click 44 34), f711, .ok⟩,
  ⟨2205, 1, 1, 9, f711, .act (.click 44 34), f712, .ok⟩,
  ⟨2206, 1, 1, 9, f712, .act (.click 44 34), f712, .ok⟩,
  ⟨2207, 1, 1, 9, f712, .act (.click 44 34), f713, .ok⟩,
  ⟨2208, 1, 1, 9, f713, .act (.click 44 34), f713, .ok⟩,
  ⟨2209, 1, 1, 9, f713, .act (.click 44 34), f714, .ok⟩,
  ⟨2210, 1, 1, 9, f714, .act (.click 44 34), f714, .ok⟩,
  ⟨2211, 1, 1, 9, f714, .act (.click 44 34), f715, .ok⟩,
  ⟨2212, 1, 1, 9, f715, .act (.click 44 34), f715, .ok⟩,
  ⟨2213, 1, 1, 9, f715, .act (.click 44 34), f716, .ok⟩,
  ⟨2214, 1, 1, 9, f716, .act (.click 44 34), f716, .ok⟩,
  ⟨2215, 1, 1, 9, f716, .act (.click 44 34), f717, .ok⟩,
  ⟨2216, 1, 1, 9, f717, .act (.click 44 34), f717, .ok⟩,
  ⟨2217, 1, 1, 9, f717, .act (.click 44 34), f718, .ok⟩,
  ⟨2218, 1, 1, 9, f718, .act (.click 44 34), f718, .ok⟩,
  ⟨2219, 1, 1, 9, f718, .act (.click 44 34), f719, .ok⟩,
  ⟨2220, 1, 1, 9, f719, .act (.click 44 34), f719, .ok⟩,
  ⟨2221, 1, 1, 9, f719, .act (.click 44 34), f720, .ok⟩,
  ⟨2222, 1, 1, 9, f720, .act (.click 44 34), f720, .ok⟩,
  ⟨2223, 1, 1, 9, f720, .act (.click 44 34), f721, .ok⟩,
  ⟨2224, 1, 1, 9, f721, .act (.click 44 34), f721, .ok⟩,
  ⟨2225, 1, 1, 9, f721, .act (.click 44 34), f722, .ok⟩,
  ⟨2226, 1, 1, 9, f722, .act (.click 44 34), f722, .ok⟩,
  ⟨2227, 1, 1, 9, f722, .act (.click 44 34), f723, .ok⟩,
  ⟨2228, 1, 1, 9, f723, .act (.click 44 34), f723, .ok⟩,
  ⟨2229, 1, 1, 9, f723, .act (.click 44 34), f724, .ok⟩,
  ⟨2230, 1, 1, 9, f724, .act (.click 44 34), f724, .ok⟩,
  ⟨2231, 1, 1, 9, f724, .act (.click 44 34), f725, .ok⟩,
  ⟨2232, 1, 1, 9, f725, .act (.click 44 34), f725, .ok⟩,
  ⟨2233, 1, 1, 9, f725, .act (.click 44 34), f726, .ok⟩,
  ⟨2234, 1, 1, 9, f726, .act (.click 44 34), f726, .ok⟩,
  ⟨2235, 1, 1, 9, f726, .act (.click 44 34), f727, .ok⟩,
  ⟨2236, 1, 1, 9, f727, .act (.click 44 34), f727, .ok⟩,
  ⟨2237, 1, 1, 9, f727, .act (.click 44 34), f728, .ok⟩,
  ⟨2238, 1, 1, 9, f728, .act (.click 44 34), f728, .ok⟩,
  ⟨2239, 1, 1, 9, f728, .act (.click 44 34), f729, .ok⟩,
  ⟨2240, 1, 1, 9, f729, .act (.click 44 34), f729, .ok⟩,
  ⟨2241, 1, 1, 9, f729, .act (.click 44 34), f730, .ok⟩,
  ⟨2242, 1, 1, 9, f730, .act (.click 44 34), f730, .ok⟩,
  ⟨2243, 1, 1, 9, f730, .act (.click 44 34), f731, .ok⟩,
  ⟨2244, 1, 1, 9, f731, .act (.click 44 34), f731, .ok⟩,
  ⟨2245, 1, 1, 9, f731, .act (.click 44 34), f732, .ok⟩,
  ⟨2246, 1, 1, 9, f732, .act (.click 44 34), f732, .ok⟩,
  ⟨2247, 1, 1, 9, f732, .act (.click 44 34), f733, .ok⟩,
  ⟨2248, 1, 1, 9, f733, .act (.click 44 34), f733, .ok⟩,
  ⟨2249, 1, 1, 9, f733, .act (.click 44 34), f734, .ok⟩]

def rows09 : List Row := [
  ⟨2250, 1, 1, 9, f734, .act (.click 44 34), f734, .ok⟩,
  ⟨2251, 1, 1, 9, f734, .act (.click 44 34), f735, .ok⟩,
  ⟨2252, 1, 1, 9, f735, .act (.click 44 34), f735, .ok⟩,
  ⟨2253, 1, 1, 9, f735, .act (.click 44 34), f736, .ok⟩,
  ⟨2254, 1, 1, 9, f736, .act (.click 44 34), f736, .ok⟩,
  ⟨2255, 1, 1, 9, f736, .act (.click 44 34), f737, .ok⟩,
  ⟨2256, 1, 1, 9, f737, .act (.click 44 34), f737, .ok⟩,
  ⟨2257, 1, 1, 9, f737, .act (.click 44 34), f738, .ok⟩,
  ⟨2258, 1, 1, 9, f738, .act (.click 44 34), f738, .ok⟩,
  ⟨2259, 1, 1, 9, f738, .act (.click 44 34), f739, .ok⟩,
  ⟨2260, 1, 1, 9, f739, .act (.click 44 34), f739, .ok⟩,
  ⟨2261, 1, 1, 9, f739, .act (.click 44 34), f740, .ok⟩,
  ⟨2262, 1, 1, 9, f740, .act (.click 44 34), f740, .ok⟩,
  ⟨2263, 1, 1, 9, f740, .act (.click 44 34), f741, .ok⟩,
  ⟨2264, 1, 1, 9, f741, .act (.click 44 34), f741, .ok⟩,
  ⟨2265, 1, 1, 9, f741, .act (.click 44 34), f742, .over⟩,
  ⟨2266, 1, 1, 9, f742, .reset, f82, .reset⟩,
  ⟨2267, 1, 1, 9, f82, .act (.dir .down), f743, .ok⟩,
  ⟨2268, 1, 1, 9, f743, .act (.dir .up), f83, .ok⟩,
  ⟨2269, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨2270, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨2271, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨2272, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨2273, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨2274, 1, 1, 9, f90, .act (.click 46 28), f90, .ok⟩,
  ⟨2275, 1, 1, 9, f90, .act (.dir .up), f91, .ok⟩,
  ⟨2276, 1, 1, 9, f91, .act (.dir .down), f744, .ok⟩,
  ⟨2277, 1, 1, 9, f744, .act (.dir .left), f745, .ok⟩,
  ⟨2278, 1, 1, 9, f745, .act (.dir .right), f746, .ok⟩,
  ⟨2279, 1, 1, 9, f746, .act (.dir .up), f747, .ok⟩,
  ⟨2280, 1, 1, 9, f747, .act (.dir .up), f748, .ok⟩,
  ⟨2281, 1, 1, 9, f748, .act (.dir .up), f749, .ok⟩,
  ⟨2282, 1, 1, 9, f749, .act (.dir .up), f750, .ok⟩,
  ⟨2283, 1, 1, 9, f750, .act (.dir .right), f751, .ok⟩,
  ⟨2284, 1, 1, 9, f751, .act (.dir .right), f752, .ok⟩,
  ⟨2285, 1, 1, 9, f752, .act (.dir .up), f753, .ok⟩,
  ⟨2286, 1, 1, 9, f753, .act (.dir .up), f754, .ok⟩,
  ⟨2287, 1, 1, 9, f754, .act (.dir .up), f755, .ok⟩,
  ⟨2288, 1, 1, 9, f755, .act (.dir .up), f755, .ok⟩,
  ⟨2289, 1, 1, 9, f755, .act (.click 41 34), f756, .ok⟩,
  ⟨2290, 1, 1, 9, f756, .reset, f82, .reset⟩,
  ⟨2291, 1, 1, 9, f82, .act (.dir .up), f84, .ok⟩,
  ⟨2292, 1, 1, 9, f84, .act (.dir .down), f83, .ok⟩,
  ⟨2293, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨2294, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨2295, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨2296, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨2297, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨2298, 1, 1, 9, f90, .act (.dir .up), f537, .ok⟩,
  ⟨2299, 1, 1, 9, f537, .act (.dir .up), f538, .ok⟩,
  ⟨2300, 1, 1, 9, f538, .act (.dir .up), f539, .ok⟩,
  ⟨2301, 1, 1, 9, f539, .act (.dir .up), f540, .ok⟩,
  ⟨2302, 1, 1, 9, f540, .act (.dir .up), f277, .ok⟩,
  ⟨2303, 1, 1, 9, f277, .act (.dir .up), f278, .ok⟩,
  ⟨2304, 1, 1, 9, f278, .act (.dir .up), f278, .ok⟩,
  ⟨2305, 1, 1, 9, f278, .act (.dir .right), f541, .ok⟩,
  ⟨2306, 1, 1, 9, f541, .act (.dir .right), f542, .ok⟩,
  ⟨2307, 1, 1, 9, f542, .act (.dir .right), f543, .ok⟩,
  ⟨2308, 1, 1, 9, f543, .act (.dir .right), f544, .ok⟩,
  ⟨2309, 1, 1, 9, f544, .act (.dir .right), f545, .ok⟩,
  ⟨2310, 1, 1, 9, f545, .act (.dir .right), f546, .ok⟩,
  ⟨2311, 1, 1, 9, f546, .act (.dir .right), f547, .ok⟩,
  ⟨2312, 1, 1, 9, f547, .act (.dir .right), f548, .ok⟩,
  ⟨2313, 1, 1, 9, f548, .act (.dir .right), f549, .ok⟩,
  ⟨2314, 1, 1, 9, f549, .act (.dir .right), f549, .ok⟩,
  ⟨2315, 1, 1, 9, f549, .act (.dir .right), f550, .ok⟩,
  ⟨2316, 1, 1, 9, f550, .act (.dir .right), f550, .ok⟩,
  ⟨2317, 1, 1, 9, f550, .act (.dir .down), f551, .ok⟩,
  ⟨2318, 1, 1, 9, f551, .act (.dir .down), f552, .ok⟩,
  ⟨2319, 1, 1, 9, f552, .act (.dir .down), f553, .ok⟩,
  ⟨2320, 1, 1, 9, f553, .act (.dir .left), f554, .ok⟩,
  ⟨2321, 1, 1, 9, f554, .act (.dir .left), f555, .ok⟩,
  ⟨2322, 1, 1, 9, f555, .act (.dir .left), f556, .ok⟩,
  ⟨2323, 1, 1, 9, f556, .act (.dir .left), f557, .ok⟩,
  ⟨2324, 1, 1, 9, f557, .act (.dir .left), f558, .ok⟩,
  ⟨2325, 1, 1, 9, f558, .act (.dir .left), f559, .ok⟩,
  ⟨2326, 1, 1, 9, f559, .act (.dir .left), f560, .ok⟩,
  ⟨2327, 1, 1, 9, f560, .act (.dir .left), f561, .ok⟩,
  ⟨2328, 1, 1, 9, f561, .act (.dir .left), f562, .ok⟩,
  ⟨2329, 1, 1, 9, f562, .act (.dir .left), f563, .ok⟩,
  ⟨2330, 1, 1, 9, f563, .act (.dir .right), f564, .ok⟩,
  ⟨2331, 1, 1, 9, f564, .act (.dir .right), f565, .ok⟩,
  ⟨2332, 1, 1, 9, f565, .act (.dir .right), f566, .ok⟩,
  ⟨2333, 1, 1, 9, f566, .act (.dir .right), f567, .ok⟩,
  ⟨2334, 1, 1, 9, f567, .act (.dir .right), f568, .ok⟩,
  ⟨2335, 1, 1, 9, f568, .act (.dir .right), f569, .ok⟩,
  ⟨2336, 1, 1, 9, f569, .act (.dir .right), f570, .ok⟩,
  ⟨2337, 1, 1, 9, f570, .act (.dir .right), f571, .ok⟩,
  ⟨2338, 1, 1, 9, f571, .act (.dir .right), f572, .ok⟩,
  ⟨2339, 1, 1, 9, f572, .act (.dir .right), f573, .ok⟩,
  ⟨2340, 1, 1, 9, f573, .act (.dir .right), f573, .ok⟩,
  ⟨2341, 1, 1, 9, f573, .act (.dir .right), f574, .ok⟩,
  ⟨2342, 1, 1, 9, f574, .act (.dir .right), f574, .ok⟩,
  ⟨2343, 1, 1, 9, f574, .act (.dir .right), f575, .ok⟩,
  ⟨2344, 1, 1, 9, f575, .act (.dir .right), f575, .ok⟩,
  ⟨2345, 1, 1, 9, f575, .act (.dir .right), f576, .ok⟩,
  ⟨2346, 1, 1, 9, f576, .act (.dir .right), f576, .ok⟩,
  ⟨2347, 1, 1, 9, f576, .act (.dir .right), f577, .ok⟩,
  ⟨2348, 1, 1, 9, f577, .act (.dir .right), f577, .ok⟩,
  ⟨2349, 1, 1, 9, f577, .act (.dir .up), f578, .ok⟩,
  ⟨2350, 1, 1, 9, f578, .act (.dir .up), f579, .ok⟩,
  ⟨2351, 1, 1, 9, f579, .act (.dir .up), f580, .ok⟩,
  ⟨2352, 1, 1, 9, f580, .act (.dir .up), f580, .ok⟩,
  ⟨2353, 1, 1, 9, f580, .act (.dir .up), f581, .ok⟩,
  ⟨2354, 1, 1, 9, f581, .act (.dir .up), f581, .ok⟩,
  ⟨2355, 1, 1, 9, f581, .reset, f82, .reset⟩,
  ⟨2356, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2357, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2358, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2359, 1, 1, 9, f584, .act (.dir .right), f585, .ok⟩,
  ⟨2360, 1, 1, 9, f585, .act (.dir .right), f586, .ok⟩,
  ⟨2361, 1, 1, 9, f586, .act (.dir .right), f587, .ok⟩,
  ⟨2362, 1, 1, 9, f587, .act (.dir .up), f588, .ok⟩,
  ⟨2363, 1, 1, 9, f588, .act (.dir .up), f589, .ok⟩,
  ⟨2364, 1, 1, 9, f589, .act (.dir .up), f590, .ok⟩,
  ⟨2365, 1, 1, 9, f590, .act (.dir .up), f591, .ok⟩,
  ⟨2366, 1, 1, 9, f591, .act (.dir .up), f592, .ok⟩,
  ⟨2367, 1, 1, 9, f592, .act (.dir .up), f593, .ok⟩,
  ⟨2368, 1, 1, 9, f593, .reset, f82, .reset⟩,
  ⟨2369, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2370, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2371, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2372, 1, 1, 9, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨2373, 1, 1, 9, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨2374, 1, 1, 9, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨2375, 1, 1, 9, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨2376, 1, 1, 9, f595, .reset, f82, .reset⟩,
  ⟨2377, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2378, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2379, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2380, 1, 1, 9, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨2381, 1, 1, 9, f584, .act (.dir .up), f596, .ok⟩,
  ⟨2382, 1, 1, 9, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨2383, 1, 1, 9, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨2384, 1, 1, 9, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨2385, 1, 1, 9, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨2386, 1, 1, 9, f598, .reset, f82, .reset⟩,
  ⟨2387, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2388, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2389, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2390, 1, 1, 9, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨2391, 1, 1, 9, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨2392, 1, 1, 9, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨2393, 1, 1, 9, f594, .act (.dir .left), f599, .ok⟩,
  ⟨2394, 1, 1, 9, f599, .act (.dir .left), f600, .ok⟩,
  ⟨2395, 1, 1, 9, f600, .act (.dir .down), f601, .ok⟩,
  ⟨2396, 1, 1, 9, f601, .act (.dir .left), f602, .ok⟩,
  ⟨2397, 1, 1, 9, f602, .act (.dir .up), f603, .ok⟩,
  ⟨2398, 1, 1, 9, f603, .act (.dir .up), f604, .ok⟩,
  ⟨2399, 1, 1, 9, f604, .act (.dir .right), f605, .ok⟩,
  ⟨2400, 1, 1, 9, f605, .act (.dir .right), f606, .ok⟩,
  ⟨2401, 1, 1, 9, f606, .act (.dir .down), f607, .ok⟩,
  ⟨2402, 1, 1, 9, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨2403, 1, 1, 9, f607, .reset, f82, .reset⟩,
  ⟨2404, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2405, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2406, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2407, 1, 1, 9, f584, .act (.dir .down), f608, .ok⟩,
  ⟨2408, 1, 1, 9, f608, .act (.dir .left), f609, .ok⟩,
  ⟨2409, 1, 1, 9, f609, .act (.dir .left), f610, .ok⟩,
  ⟨2410, 1, 1, 9, f610, .act (.dir .left), f611, .ok⟩,
  ⟨2411, 1, 1, 9, f611, .act (.dir .left), f612, .ok⟩,
  ⟨2412, 1, 1, 9, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨2413, 1, 1, 9, f613, .act (.dir .up), f614, .ok⟩,
  ⟨2414, 1, 1, 9, f614, .act (.dir .right), f603, .ok⟩,
  ⟨2415, 1, 1, 9, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨2416, 1, 1, 9, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨2417, 1, 1, 9, f615, .act (.dir .down), f616, .ok⟩,
  ⟨2418, 1, 1, 9, f616, .act (.click 46 28), f617, .ok⟩,
  ⟨2419, 1, 1, 9, f617, .act (.dir .up), f618, .ok⟩,
  ⟨2420, 1, 1, 9, f618, .act (.dir .down), f619, .ok⟩,
  ⟨2421, 1, 1, 9, f619, .act (.dir .left), f620, .ok⟩,
  ⟨2422, 1, 1, 9, f620, .act (.dir .right), f621, .ok⟩,
  ⟨2423, 1, 1, 9, f621, .act (.dir .up), f622, .ok⟩,
  ⟨2424, 1, 1, 9, f622, .act (.dir .up), f623, .ok⟩,
  ⟨2425, 1, 1, 9, f623, .act (.dir .up), f624, .ok⟩,
  ⟨2426, 1, 1, 9, f624, .act (.dir .up), f625, .ok⟩,
  ⟨2427, 1, 1, 9, f625, .act (.dir .right), f626, .ok⟩,
  ⟨2428, 1, 1, 9, f626, .act (.dir .right), f627, .ok⟩,
  ⟨2429, 1, 1, 9, f627, .act (.dir .up), f628, .ok⟩,
  ⟨2430, 1, 1, 9, f628, .act (.dir .up), f629, .ok⟩,
  ⟨2431, 1, 1, 9, f629, .act (.dir .up), f630, .ok⟩,
  ⟨2432, 1, 1, 9, f630, .act (.dir .up), f631, .ok⟩,
  ⟨2433, 1, 1, 9, f631, .act (.dir .up), f632, .ok⟩,
  ⟨2434, 1, 1, 9, f632, .act (.dir .up), f633, .ok⟩,
  ⟨2435, 1, 1, 9, f633, .act (.dir .down), f634, .ok⟩,
  ⟨2436, 1, 1, 9, f634, .act (.dir .left), f635, .ok⟩,
  ⟨2437, 1, 1, 9, f635, .act (.dir .right), f636, .ok⟩,
  ⟨2438, 1, 1, 9, f636, .act (.dir .up), f637, .ok⟩,
  ⟨2439, 1, 1, 9, f637, .act (.dir .left), f638, .ok⟩,
  ⟨2440, 1, 1, 9, f638, .act (.dir .left), f639, .ok⟩,
  ⟨2441, 1, 1, 9, f639, .act (.dir .left), f640, .ok⟩,
  ⟨2442, 1, 1, 9, f640, .act (.dir .left), f641, .ok⟩,
  ⟨2443, 1, 1, 9, f641, .act (.click 42 44), f641, .ok⟩,
  ⟨2444, 1, 1, 9, f641, .act (.dir .right), f642, .ok⟩,
  ⟨2445, 1, 1, 9, f642, .act (.dir .right), f643, .ok⟩,
  ⟨2446, 1, 1, 9, f643, .act (.dir .up), f644, .ok⟩,
  ⟨2447, 1, 1, 9, f644, .act (.dir .up), f644, .ok⟩,
  ⟨2448, 1, 1, 9, f644, .act (.dir .left), f645, .ok⟩,
  ⟨2449, 1, 1, 9, f645, .act (.dir .right), f646, .ok⟩,
  ⟨2450, 1, 1, 9, f646, .act (.dir .right), f647, .ok⟩,
  ⟨2451, 1, 1, 9, f647, .act (.dir .right), f648, .ok⟩,
  ⟨2452, 1, 1, 9, f648, .act (.dir .right), f649, .ok⟩,
  ⟨2453, 1, 1, 9, f649, .act (.dir .right), f650, .ok⟩,
  ⟨2454, 1, 1, 9, f650, .act (.dir .right), f651, .ok⟩,
  ⟨2455, 1, 1, 9, f651, .act (.dir .right), f652, .ok⟩,
  ⟨2456, 1, 1, 9, f652, .act (.dir .right), f653, .ok⟩,
  ⟨2457, 1, 1, 9, f653, .act (.dir .right), f654, .ok⟩,
  ⟨2458, 1, 1, 9, f654, .act (.dir .right), f655, .ok⟩,
  ⟨2459, 1, 1, 9, f655, .act (.dir .right), f655, .ok⟩,
  ⟨2460, 1, 1, 9, f655, .act (.dir .right), f656, .ok⟩,
  ⟨2461, 1, 1, 9, f656, .act (.dir .right), f656, .ok⟩,
  ⟨2462, 1, 1, 9, f656, .act (.dir .right), f657, .ok⟩,
  ⟨2463, 1, 1, 9, f657, .act (.dir .right), f657, .ok⟩,
  ⟨2464, 1, 1, 9, f657, .reset, f82, .reset⟩,
  ⟨2465, 1, 1, 9, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨2466, 1, 1, 9, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨2467, 1, 1, 9, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨2468, 1, 1, 9, f142, .act (.click 42 45), f142, .ok⟩,
  ⟨2469, 1, 1, 9, f142, .act (.click 47 44), f143, .ok⟩,
  ⟨2470, 1, 1, 9, f143, .act (.click 33 39), f143, .ok⟩,
  ⟨2471, 1, 1, 9, f143, .act (.dir .up), f144, .ok⟩,
  ⟨2472, 1, 1, 9, f144, .act (.click 42 42), f144, .ok⟩,
  ⟨2473, 1, 1, 9, f144, .act (.dir .up), f145, .ok⟩,
  ⟨2474, 1, 1, 9, f145, .act (.dir .up), f146, .ok⟩,
  ⟨2475, 1, 1, 9, f146, .act (.dir .up), f147, .ok⟩,
  ⟨2476, 1, 1, 9, f147, .act (.dir .down), f148, .ok⟩,
  ⟨2477, 1, 1, 9, f148, .act (.dir .down), f149, .ok⟩,
  ⟨2478, 1, 1, 9, f149, .act (.dir .down), f150, .ok⟩,
  ⟨2479, 1, 1, 9, f150, .act (.click 47 44), f151, .ok⟩,
  ⟨2480, 1, 1, 9, f151, .reset, f82, .reset⟩,
  ⟨2481, 1, 1, 9, f82, .act (.dir .up), f84, .ok⟩,
  ⟨2482, 1, 1, 9, f84, .act (.dir .down), f83, .ok⟩,
  ⟨2483, 1, 1, 9, f83, .act (.dir .left), f86, .ok⟩,
  ⟨2484, 1, 1, 9, f86, .act (.dir .right), f85, .ok⟩,
  ⟨2485, 1, 1, 9, f85, .act (.dir .up), f88, .ok⟩,
  ⟨2486, 1, 1, 9, f88, .act (.dir .up), f536, .ok⟩,
  ⟨2487, 1, 1, 9, f536, .act (.dir .up), f90, .ok⟩,
  ⟨2488, 1, 1, 9, f90, .act (.dir .up), f537, .ok⟩,
  ⟨2489, 1, 1, 9, f537, .act (.dir .up), f538, .ok⟩,
  ⟨2490, 1, 1, 9, f538, .act (.dir .up), f539, .ok⟩,
  ⟨2491, 1, 1, 9, f539, .act (.dir .up), f540, .ok⟩,
  ⟨2492, 1, 1, 9, f540, .act (.dir .up), f277, .ok⟩,
  ⟨2493, 1, 1, 9, f277, .act (.dir .up), f278, .ok⟩,
  ⟨2494, 1, 1, 9, f278, .act (.dir .up), f278, .ok⟩,
  ⟨2495, 1, 1, 9, f278, .act (.dir .right), f541, .ok⟩,
  ⟨2496, 1, 1, 9, f541, .act (.dir .right), f542, .ok⟩,
  ⟨2497, 1, 1, 9, f542, .act (.dir .right), f543, .ok⟩,
  ⟨2498, 1, 1, 9, f543, .act (.dir .right), f544, .ok⟩,
  ⟨2499, 1, 1, 9, f544, .act (.dir .right), f545, .ok⟩]

def rows10 : List Row := [
  ⟨2500, 1, 1, 9, f545, .act (.dir .right), f546, .ok⟩,
  ⟨2501, 1, 1, 9, f546, .act (.dir .right), f547, .ok⟩,
  ⟨2502, 1, 1, 9, f547, .act (.dir .right), f548, .ok⟩,
  ⟨2503, 1, 1, 9, f548, .act (.dir .right), f549, .ok⟩,
  ⟨2504, 1, 1, 9, f549, .act (.dir .right), f549, .ok⟩,
  ⟨2505, 1, 1, 9, f549, .act (.dir .down), f658, .ok⟩,
  ⟨2506, 1, 1, 9, f658, .act (.dir .down), f659, .ok⟩,
  ⟨2507, 1, 1, 9, f659, .act (.dir .down), f660, .ok⟩,
  ⟨2508, 1, 1, 9, f660, .act (.dir .left), f661, .ok⟩,
  ⟨2509, 1, 1, 9, f661, .act (.dir .left), f662, .ok⟩,
  ⟨2510, 1, 1, 9, f662, .act (.dir .left), f663, .ok⟩,
  ⟨2511, 1, 1, 9, f663, .act (.dir .left), f664, .ok⟩,
  ⟨2512, 1, 1, 9, f664, .act (.dir .left), f665, .ok⟩,
  ⟨2513, 1, 1, 9, f665, .act (.dir .left), f666, .ok⟩,
  ⟨2514, 1, 1, 9, f666, .act (.dir .left), f667, .ok⟩,
  ⟨2515, 1, 1, 9, f667, .act (.dir .left), f668, .ok⟩,
  ⟨2516, 1, 1, 9, f668, .act (.dir .left), f669, .ok⟩,
  ⟨2517, 1, 1, 9, f669, .act (.dir .left), f670, .ok⟩,
  ⟨2518, 1, 1, 9, f670, .act (.dir .right), f562, .ok⟩,
  ⟨2519, 1, 1, 9, f562, .act (.dir .right), f671, .ok⟩,
  ⟨2520, 1, 1, 9, f671, .act (.dir .right), f672, .ok⟩,
  ⟨2521, 1, 1, 9, f672, .act (.dir .right), f673, .ok⟩,
  ⟨2522, 1, 1, 9, f673, .act (.dir .right), f674, .ok⟩,
  ⟨2523, 1, 1, 9, f674, .act (.dir .right), f675, .ok⟩,
  ⟨2524, 1, 1, 9, f675, .act (.dir .right), f676, .ok⟩,
  ⟨2525, 1, 1, 9, f676, .act (.dir .right), f677, .ok⟩,
  ⟨2526, 1, 1, 9, f677, .act (.dir .right), f678, .ok⟩,
  ⟨2527, 1, 1, 9, f678, .act (.dir .right), f679, .ok⟩,
  ⟨2528, 1, 1, 9, f679, .act (.dir .right), f679, .ok⟩,
  ⟨2529, 1, 1, 9, f679, .act (.dir .right), f573, .ok⟩,
  ⟨2530, 1, 1, 9, f573, .act (.dir .right), f573, .ok⟩,
  ⟨2531, 1, 1, 9, f573, .act (.dir .right), f574, .ok⟩,
  ⟨2532, 1, 1, 9, f574, .act (.dir .right), f574, .ok⟩,
  ⟨2533, 1, 1, 9, f574, .act (.dir .right), f575, .ok⟩,
  ⟨2534, 1, 1, 9, f575, .act (.dir .right), f575, .ok⟩,
  ⟨2535, 1, 1, 9, f575, .act (.dir .right), f576, .ok⟩,
  ⟨2536, 1, 1, 9, f576, .act (.dir .right), f576, .ok⟩,
  ⟨2537, 1, 1, 9, f576, .act (.dir .right), f577, .ok⟩,
  ⟨2538, 1, 1, 9, f577, .act (.dir .up), f680, .ok⟩,
  ⟨2539, 1, 1, 9, f680, .act (.dir .up), f579, .ok⟩,
  ⟨2540, 1, 1, 9, f579, .act (.dir .up), f681, .ok⟩,
  ⟨2541, 1, 1, 9, f681, .act (.dir .up), f580, .ok⟩,
  ⟨2542, 1, 1, 9, f580, .act (.dir .up), f580, .ok⟩,
  ⟨2543, 1, 1, 9, f580, .act (.dir .up), f581, .ok⟩,
  ⟨2544, 1, 1, 9, f581, .reset, f82, .reset⟩,
  ⟨2545, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2546, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2547, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2548, 1, 1, 9, f584, .act (.dir .right), f585, .ok⟩,
  ⟨2549, 1, 1, 9, f585, .act (.dir .right), f586, .ok⟩,
  ⟨2550, 1, 1, 9, f586, .act (.dir .right), f587, .ok⟩,
  ⟨2551, 1, 1, 9, f587, .act (.dir .up), f588, .ok⟩,
  ⟨2552, 1, 1, 9, f588, .act (.dir .up), f589, .ok⟩,
  ⟨2553, 1, 1, 9, f589, .act (.dir .up), f590, .ok⟩,
  ⟨2554, 1, 1, 9, f590, .act (.dir .up), f591, .ok⟩,
  ⟨2555, 1, 1, 9, f591, .act (.dir .up), f592, .ok⟩,
  ⟨2556, 1, 1, 9, f592, .act (.dir .up), f593, .ok⟩,
  ⟨2557, 1, 1, 9, f593, .reset, f82, .reset⟩,
  ⟨2558, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2559, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2560, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2561, 1, 1, 9, f584, .act (.click 34 13), f584, .ok⟩,
  ⟨2562, 1, 1, 9, f584, .act (.click 43 31), f594, .ok⟩,
  ⟨2563, 1, 1, 9, f594, .act (.click 25 31), f594, .ok⟩,
  ⟨2564, 1, 1, 9, f594, .act (.click 46 28), f595, .ok⟩,
  ⟨2565, 1, 1, 9, f595, .reset, f82, .reset⟩,
  ⟨2566, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2567, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2568, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2569, 1, 1, 9, f584, .act (.click 46 28), f584, .ok⟩,
  ⟨2570, 1, 1, 9, f584, .act (.dir .up), f596, .ok⟩,
  ⟨2571, 1, 1, 9, f596, .act (.click 44 30), f596, .ok⟩,
  ⟨2572, 1, 1, 9, f596, .act (.click 44 30), f597, .ok⟩,
  ⟨2573, 1, 1, 9, f597, .act (.click 43 31), f597, .ok⟩,
  ⟨2574, 1, 1, 9, f597, .act (.click 44 30), f598, .ok⟩,
  ⟨2575, 1, 1, 9, f598, .reset, f82, .reset⟩,
  ⟨2576, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2577, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2578, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2579, 1, 1, 9, f584, .act (.click 44 30), f584, .ok⟩,
  ⟨2580, 1, 1, 9, f584, .act (.click 44 30), f594, .ok⟩,
  ⟨2581, 1, 1, 9, f594, .act (.click 45 30), f594, .ok⟩,
  ⟨2582, 1, 1, 9, f594, .act (.dir .left), f599, .ok⟩,
  ⟨2583, 1, 1, 9, f599, .act (.dir .left), f600, .ok⟩,
  ⟨2584, 1, 1, 9, f600, .act (.dir .down), f601, .ok⟩,
  ⟨2585, 1, 1, 9, f601, .act (.dir .left), f602, .ok⟩,
  ⟨2586, 1, 1, 9, f602, .act (.dir .up), f603, .ok⟩,
  ⟨2587, 1, 1, 9, f603, .act (.dir .up), f604, .ok⟩,
  ⟨2588, 1, 1, 9, f604, .act (.dir .right), f605, .ok⟩,
  ⟨2589, 1, 1, 9, f605, .act (.dir .right), f606, .ok⟩,
  ⟨2590, 1, 1, 9, f606, .act (.dir .down), f607, .ok⟩,
  ⟨2591, 1, 1, 9, f607, .act (.click 44 30), f607, .ok⟩,
  ⟨2592, 1, 1, 9, f607, .reset, f82, .reset⟩,
  ⟨2593, 1, 1, 9, f82, .act (.dir .right), f582, .ok⟩,
  ⟨2594, 1, 1, 9, f582, .act (.dir .right), f583, .ok⟩,
  ⟨2595, 1, 1, 9, f583, .act (.dir .right), f584, .ok⟩,
  ⟨2596, 1, 1, 9, f584, .act (.dir .down), f608, .ok⟩,
  ⟨2597, 1, 1, 9, f608, .act (.dir .left), f609, .ok⟩,
  ⟨2598, 1, 1, 9, f609, .act (.dir .left), f610, .ok⟩,
  ⟨2599, 1, 1, 9, f610, .act (.dir .left), f611, .ok⟩,
  ⟨2600, 1, 1, 9, f611, .act (.dir .left), f612, .ok⟩,
  ⟨2601, 1, 1, 9, f612, .act (.click 43 31), f613, .ok⟩,
  ⟨2602, 1, 1, 9, f613, .act (.dir .up), f614, .ok⟩,
  ⟨2603, 1, 1, 9, f614, .act (.dir .right), f603, .ok⟩,
  ⟨2604, 1, 1, 9, f603, .act (.click 13 34), f603, .ok⟩,
  ⟨2605, 1, 1, 9, f603, .act (.click 13 31), f615, .ok⟩,
  ⟨2606, 1, 1, 9, f615, .act (.dir .down), f616, .ok⟩,
  ⟨2607, 1, 1, 9, f616, .act (.click 44 34), f682, .ok⟩,
  ⟨2608, 1, 1, 9, f682, .act (.click 45 34), f682, .ok⟩,
  ⟨2609, 1, 1, 9, f682, .act (.click 47 44), f683, .ok⟩,
  ⟨2610, 1, 1, 9, f683, .act (.click 55 37), f683, .ok⟩,
  ⟨2611, 1, 1, 9, f683, .act (.dir .down), f684, .ok⟩,
  ⟨2612, 1, 1, 9, f684, .act (.dir .down), f685, .ok⟩,
  ⟨2613, 1, 1, 9, f685, .act (.dir .down), f686, .ok⟩,
  ⟨2614, 1, 1, 9, f686, .act (.dir .down), f687, .ok⟩,
  ⟨2615, 1, 1, 9, f687, .act (.dir .right), f688, .ok⟩,
  ⟨2616, 1, 1, 9, f688, .act (.dir .right), f689, .ok⟩,
  ⟨2617, 1, 1, 9, f689, .act (.dir .right), f690, .ok⟩,
  ⟨2618, 1, 1, 9, f690, .act (.dir .right), f691, .ok⟩,
  ⟨2619, 1, 1, 9, f691, .act (.click 44 34), f692, .ok⟩,
  ⟨2620, 1, 1, 9, f692, .act (.click 44 34), f692, .ok⟩,
  ⟨2621, 1, 1, 9, f692, .act (.click 44 34), f693, .ok⟩,
  ⟨2622, 1, 1, 9, f693, .act (.click 44 34), f693, .ok⟩,
  ⟨2623, 1, 1, 9, f693, .act (.click 44 34), f694, .ok⟩,
  ⟨2624, 1, 1, 9, f694, .act (.click 44 34), f694, .ok⟩,
  ⟨2625, 1, 1, 9, f694, .act (.click 44 34), f695, .ok⟩,
  ⟨2626, 1, 1, 9, f695, .act (.click 44 34), f695, .ok⟩,
  ⟨2627, 1, 1, 9, f695, .act (.click 44 34), f696, .ok⟩,
  ⟨2628, 1, 1, 9, f696, .act (.click 44 34), f696, .ok⟩,
  ⟨2629, 1, 1, 9, f696, .act (.click 44 34), f697, .ok⟩,
  ⟨2630, 1, 1, 9, f697, .act (.click 44 34), f697, .ok⟩,
  ⟨2631, 1, 1, 9, f697, .act (.click 44 34), f698, .ok⟩,
  ⟨2632, 1, 1, 9, f698, .act (.click 44 34), f698, .ok⟩,
  ⟨2633, 1, 1, 9, f698, .act (.click 44 34), f699, .ok⟩,
  ⟨2634, 1, 1, 9, f699, .act (.click 44 34), f699, .ok⟩,
  ⟨2635, 1, 1, 9, f699, .act (.click 44 34), f700, .ok⟩,
  ⟨2636, 1, 1, 9, f700, .act (.click 44 34), f700, .ok⟩,
  ⟨2637, 1, 1, 9, f700, .act (.click 44 34), f701, .ok⟩,
  ⟨2638, 1, 1, 9, f701, .act (.click 44 34), f701, .ok⟩,
  ⟨2639, 1, 1, 9, f701, .act (.click 44 34), f702, .ok⟩,
  ⟨2640, 1, 1, 9, f702, .act (.click 44 34), f702, .ok⟩,
  ⟨2641, 1, 1, 9, f702, .act (.click 44 34), f703, .ok⟩,
  ⟨2642, 1, 1, 9, f703, .act (.click 44 34), f703, .ok⟩,
  ⟨2643, 1, 1, 9, f703, .act (.click 44 34), f704, .ok⟩,
  ⟨2644, 1, 1, 9, f704, .act (.click 44 34), f704, .ok⟩,
  ⟨2645, 1, 1, 9, f704, .act (.click 44 34), f705, .ok⟩,
  ⟨2646, 1, 1, 9, f705, .act (.click 44 34), f705, .ok⟩,
  ⟨2647, 1, 1, 9, f705, .act (.click 44 34), f706, .ok⟩,
  ⟨2648, 1, 1, 9, f706, .act (.click 44 34), f706, .ok⟩,
  ⟨2649, 1, 1, 9, f706, .act (.click 44 34), f707, .ok⟩,
  ⟨2650, 1, 1, 9, f707, .act (.click 44 34), f707, .ok⟩,
  ⟨2651, 1, 1, 9, f707, .act (.click 44 34), f708, .ok⟩,
  ⟨2652, 1, 1, 9, f708, .act (.click 44 34), f708, .ok⟩,
  ⟨2653, 1, 1, 9, f708, .act (.click 44 34), f709, .ok⟩,
  ⟨2654, 1, 1, 9, f709, .act (.click 44 34), f709, .ok⟩,
  ⟨2655, 1, 1, 9, f709, .act (.click 44 34), f710, .ok⟩,
  ⟨2656, 1, 1, 9, f710, .act (.click 44 34), f710, .ok⟩,
  ⟨2657, 1, 1, 9, f710, .act (.click 44 34), f711, .ok⟩,
  ⟨2658, 1, 1, 9, f711, .act (.click 44 34), f711, .ok⟩,
  ⟨2659, 1, 1, 9, f711, .act (.click 44 34), f712, .ok⟩,
  ⟨2660, 1, 1, 9, f712, .act (.click 44 34), f712, .ok⟩,
  ⟨2661, 1, 1, 9, f712, .act (.click 44 34), f713, .ok⟩,
  ⟨2662, 1, 1, 9, f713, .act (.click 44 34), f713, .ok⟩,
  ⟨2663, 1, 1, 9, f713, .act (.click 44 34), f714, .ok⟩,
  ⟨2664, 1, 1, 9, f714, .act (.click 44 34), f714, .ok⟩,
  ⟨2665, 1, 1, 9, f714, .act (.click 44 34), f715, .ok⟩,
  ⟨2666, 1, 1, 9, f715, .act (.click 44 34), f715, .ok⟩,
  ⟨2667, 1, 1, 9, f715, .act (.click 44 34), f716, .ok⟩,
  ⟨2668, 1, 1, 9, f716, .act (.click 44 34), f716, .ok⟩,
  ⟨2669, 1, 1, 9, f716, .act (.click 44 34), f717, .ok⟩,
  ⟨2670, 1, 1, 9, f717, .act (.click 44 34), f717, .ok⟩,
  ⟨2671, 1, 1, 9, f717, .act (.click 44 34), f718, .ok⟩,
  ⟨2672, 1, 1, 9, f718, .act (.click 44 34), f718, .ok⟩,
  ⟨2673, 1, 1, 9, f718, .act (.click 44 34), f719, .ok⟩,
  ⟨2674, 1, 1, 9, f719, .act (.click 44 34), f719, .ok⟩,
  ⟨2675, 1, 1, 9, f719, .act (.click 44 34), f720, .ok⟩,
  ⟨2676, 1, 1, 9, f720, .act (.click 44 34), f720, .ok⟩,
  ⟨2677, 1, 1, 9, f720, .act (.click 44 34), f721, .ok⟩,
  ⟨2678, 1, 1, 9, f721, .act (.click 44 34), f721, .ok⟩,
  ⟨2679, 1, 1, 9, f721, .act (.click 44 34), f722, .ok⟩,
  ⟨2680, 1, 1, 9, f722, .act (.click 44 34), f722, .ok⟩,
  ⟨2681, 1, 1, 9, f722, .act (.click 44 34), f723, .ok⟩,
  ⟨2682, 1, 1, 9, f723, .act (.click 44 34), f723, .ok⟩,
  ⟨2683, 1, 1, 9, f723, .act (.click 44 34), f724, .ok⟩,
  ⟨2684, 1, 1, 9, f724, .act (.click 44 34), f724, .ok⟩,
  ⟨2685, 1, 1, 9, f724, .act (.click 44 34), f725, .ok⟩,
  ⟨2686, 1, 1, 9, f725, .act (.click 44 34), f725, .ok⟩,
  ⟨2687, 1, 1, 9, f725, .act (.click 44 34), f726, .ok⟩,
  ⟨2688, 1, 1, 9, f726, .act (.click 44 34), f726, .ok⟩,
  ⟨2689, 1, 1, 9, f726, .act (.click 44 34), f727, .ok⟩,
  ⟨2690, 1, 1, 9, f727, .act (.click 44 34), f727, .ok⟩,
  ⟨2691, 1, 1, 9, f727, .act (.click 44 34), f728, .ok⟩,
  ⟨2692, 1, 1, 9, f728, .act (.click 44 34), f728, .ok⟩,
  ⟨2693, 1, 1, 9, f728, .act (.click 44 34), f729, .ok⟩,
  ⟨2694, 1, 1, 9, f729, .act (.click 44 34), f729, .ok⟩,
  ⟨2695, 1, 1, 9, f729, .act (.click 44 34), f730, .ok⟩,
  ⟨2696, 1, 1, 9, f730, .act (.click 44 34), f730, .ok⟩,
  ⟨2697, 1, 1, 9, f730, .act (.click 44 34), f731, .ok⟩,
  ⟨2698, 1, 1, 9, f731, .act (.click 44 34), f731, .ok⟩,
  ⟨2699, 1, 1, 9, f731, .act (.click 44 34), f732, .ok⟩,
  ⟨2700, 1, 1, 9, f732, .act (.click 44 34), f732, .ok⟩,
  ⟨2701, 1, 1, 9, f732, .act (.click 44 34), f733, .ok⟩,
  ⟨2702, 1, 1, 9, f733, .act (.click 44 34), f733, .ok⟩,
  ⟨2703, 1, 1, 9, f733, .act (.click 44 34), f734, .ok⟩,
  ⟨2704, 1, 1, 9, f734, .act (.click 44 34), f734, .ok⟩,
  ⟨2705, 1, 1, 9, f734, .act (.click 44 34), f735, .ok⟩,
  ⟨2706, 1, 1, 9, f735, .act (.click 44 34), f735, .ok⟩,
  ⟨2707, 1, 1, 9, f735, .act (.click 44 34), f736, .ok⟩,
  ⟨2708, 1, 1, 9, f736, .act (.click 44 34), f736, .ok⟩,
  ⟨2709, 1, 1, 9, f736, .act (.click 44 34), f737, .ok⟩,
  ⟨2710, 1, 1, 9, f737, .act (.click 44 34), f737, .ok⟩,
  ⟨2711, 1, 1, 9, f737, .act (.click 44 34), f738, .ok⟩,
  ⟨2712, 1, 1, 9, f738, .act (.click 44 34), f738, .ok⟩,
  ⟨2713, 1, 1, 9, f738, .act (.click 44 34), f739, .ok⟩,
  ⟨2714, 1, 1, 9, f739, .act (.click 44 34), f739, .ok⟩,
  ⟨2715, 1, 1, 9, f739, .act (.click 44 34), f740, .ok⟩,
  ⟨2716, 1, 1, 9, f740, .act (.click 44 34), f740, .ok⟩,
  ⟨2717, 1, 1, 9, f740, .act (.click 44 34), f741, .ok⟩,
  ⟨2718, 1, 1, 9, f741, .act (.click 44 34), f741, .ok⟩,
  ⟨2719, 1, 1, 9, f741, .act (.click 44 34), f742, .over⟩,
  ⟨2720, 1, 1, 9, f742, .reset, f82, .reset⟩,
  ⟨2721, 1, 0, 10, f82, .reset, f0, .reset⟩,
  ⟨2722, 0, 0, 10, f0, .act (.dir .up), f1, .ok⟩,
  ⟨2723, 0, 0, 10, f1, .act (.dir .down), f2, .ok⟩,
  ⟨2724, 0, 0, 10, f2, .act (.dir .left), f3, .ok⟩,
  ⟨2725, 0, 0, 10, f3, .act (.dir .right), f4, .ok⟩,
  ⟨2726, 0, 0, 10, f4, .act (.dir .up), f5, .ok⟩,
  ⟨2727, 0, 0, 10, f5, .act (.dir .up), f6, .ok⟩,
  ⟨2728, 0, 0, 10, f6, .act (.dir .up), f7, .ok⟩,
  ⟨2729, 0, 0, 10, f7, .act (.dir .up), f8, .ok⟩,
  ⟨2730, 0, 0, 10, f8, .act (.dir .up), f9, .ok⟩,
  ⟨2731, 0, 0, 10, f9, .act (.dir .up), f9, .ok⟩,
  ⟨2732, 0, 0, 10, f9, .act (.dir .up), f10, .ok⟩,
  ⟨2733, 0, 0, 10, f10, .act (.dir .up), f11, .ok⟩,
  ⟨2734, 0, 0, 10, f11, .act (.dir .up), f11, .ok⟩,
  ⟨2735, 0, 0, 10, f11, .act (.dir .up), f12, .ok⟩,
  ⟨2736, 0, 0, 10, f12, .act (.dir .right), f13, .ok⟩,
  ⟨2737, 0, 0, 10, f13, .act (.dir .right), f13, .ok⟩,
  ⟨2738, 0, 0, 10, f13, .act (.dir .right), f14, .ok⟩,
  ⟨2739, 0, 0, 10, f14, .act (.dir .right), f15, .ok⟩,
  ⟨2740, 0, 0, 10, f15, .act (.dir .right), f15, .ok⟩,
  ⟨2741, 0, 0, 10, f15, .act (.dir .right), f16, .ok⟩,
  ⟨2742, 0, 0, 10, f16, .act (.dir .right), f16, .ok⟩,
  ⟨2743, 0, 0, 10, f16, .act (.dir .right), f17, .ok⟩,
  ⟨2744, 0, 0, 10, f17, .act (.dir .right), f18, .ok⟩,
  ⟨2745, 0, 0, 10, f18, .act (.dir .right), f18, .ok⟩,
  ⟨2746, 0, 0, 10, f18, .act (.dir .down), f19, .ok⟩,
  ⟨2747, 0, 0, 10, f19, .act (.dir .down), f20, .ok⟩,
  ⟨2748, 0, 0, 10, f20, .act (.dir .down), f21, .ok⟩,
  ⟨2749, 0, 0, 10, f21, .act (.dir .left), f22, .ok⟩]

def rows11 : List Row := [
  ⟨2750, 0, 0, 10, f22, .act (.dir .left), f23, .ok⟩,
  ⟨2751, 0, 0, 10, f23, .act (.dir .left), f24, .ok⟩,
  ⟨2752, 0, 0, 10, f24, .act (.dir .left), f25, .ok⟩,
  ⟨2753, 0, 0, 10, f25, .act (.dir .left), f25, .ok⟩,
  ⟨2754, 0, 0, 10, f25, .act (.dir .left), f26, .ok⟩,
  ⟨2755, 0, 0, 10, f26, .act (.dir .left), f27, .ok⟩,
  ⟨2756, 0, 0, 10, f27, .act (.dir .left), f27, .ok⟩,
  ⟨2757, 0, 0, 10, f27, .act (.dir .left), f28, .ok⟩,
  ⟨2758, 0, 0, 10, f28, .act (.dir .left), f29, .ok⟩,
  ⟨2759, 0, 0, 10, f29, .act (.dir .right), f30, .ok⟩,
  ⟨2760, 0, 0, 10, f30, .act (.dir .right), f31, .ok⟩,
  ⟨2761, 0, 0, 10, f31, .act (.dir .right), f32, .ok⟩,
  ⟨2762, 0, 0, 10, f32, .act (.dir .right), f33, .ok⟩,
  ⟨2763, 0, 0, 10, f33, .act (.dir .right), f34, .ok⟩,
  ⟨2764, 0, 0, 10, f34, .act (.dir .right), f35, .ok⟩,
  ⟨2765, 0, 0, 10, f35, .act (.dir .right), f36, .ok⟩,
  ⟨2766, 0, 0, 10, f36, .act (.dir .right), f37, .ok⟩,
  ⟨2767, 0, 0, 10, f37, .act (.dir .right), f37, .ok⟩,
  ⟨2768, 0, 0, 10, f37, .act (.dir .right), f38, .ok⟩,
  ⟨2769, 0, 0, 10, f38, .act (.dir .right), f39, .ok⟩,
  ⟨2770, 0, 0, 10, f39, .act (.dir .right), f39, .ok⟩,
  ⟨2771, 0, 0, 10, f39, .act (.dir .right), f40, .ok⟩,
  ⟨2772, 0, 0, 10, f40, .act (.dir .right), f41, .ok⟩,
  ⟨2773, 0, 0, 10, f41, .act (.dir .right), f41, .ok⟩,
  ⟨2774, 0, 0, 10, f41, .act (.dir .right), f42, .ok⟩,
  ⟨2775, 0, 0, 10, f42, .act (.dir .right), f43, .ok⟩,
  ⟨2776, 0, 0, 10, f43, .act (.dir .right), f43, .ok⟩,
  ⟨2777, 0, 0, 10, f43, .act (.dir .right), f44, .ok⟩,
  ⟨2778, 0, 0, 10, f44, .act (.dir .right), f44, .ok⟩,
  ⟨2779, 0, 0, 10, f44, .act (.dir .up), f45, .ok⟩,
  ⟨2780, 0, 0, 10, f45, .act (.dir .up), f46, .ok⟩,
  ⟨2781, 0, 0, 10, f46, .act (.dir .up), f46, .ok⟩,
  ⟨2782, 0, 0, 10, f46, .act (.dir .up), f47, .ok⟩,
  ⟨2783, 0, 0, 10, f47, .act (.dir .up), f48, .ok⟩,
  ⟨2784, 0, 0, 10, f48, .act (.dir .up), f48, .ok⟩,
  ⟨2785, 0, 0, 10, f48, .reset, f0, .reset⟩,
  ⟨2786, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨2787, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨2788, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨2789, 0, 0, 10, f51, .act (.dir .right), f52, .ok⟩,
  ⟨2790, 0, 0, 10, f52, .act (.dir .right), f53, .ok⟩,
  ⟨2791, 0, 0, 10, f53, .act (.dir .right), f54, .ok⟩,
  ⟨2792, 0, 0, 10, f54, .act (.dir .up), f54, .ok⟩,
  ⟨2793, 0, 0, 10, f54, .act (.dir .up), f55, .ok⟩,
  ⟨2794, 0, 0, 10, f55, .act (.dir .up), f56, .ok⟩,
  ⟨2795, 0, 0, 10, f56, .act (.dir .up), f56, .ok⟩,
  ⟨2796, 0, 0, 10, f56, .act (.dir .up), f57, .ok⟩,
  ⟨2797, 0, 0, 10, f57, .act (.dir .up), f58, .ok⟩,
  ⟨2798, 0, 0, 10, f58, .reset, f0, .reset⟩,
  ⟨2799, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨2800, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨2801, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨2802, 0, 0, 10, f51, .act (.click 34 13), f59, .ok⟩,
  ⟨2803, 0, 0, 10, f59, .act (.click 43 31), f60, .ok⟩,
  ⟨2804, 0, 0, 10, f60, .act (.click 25 31), f61, .ok⟩,
  ⟨2805, 0, 0, 10, f61, .act (.click 46 28), f61, .ok⟩,
  ⟨2806, 0, 0, 10, f61, .reset, f0, .reset⟩,
  ⟨2807, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨2808, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨2809, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨2810, 0, 0, 10, f51, .act (.click 46 28), f59, .ok⟩,
  ⟨2811, 0, 0, 10, f59, .act (.dir .up), f59, .ok⟩,
  ⟨2812, 0, 0, 10, f59, .act (.click 44 30), f62, .ok⟩,
  ⟨2813, 0, 0, 10, f62, .act (.click 44 30), f62, .ok⟩,
  ⟨2814, 0, 0, 10, f62, .act (.click 43 31), f63, .ok⟩,
  ⟨2815, 0, 0, 10, f63, .act (.click 44 30), f64, .ok⟩,
  ⟨2816, 0, 0, 10, f64, .reset, f0, .reset⟩,
  ⟨2817, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨2818, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨2819, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨2820, 0, 0, 10, f51, .act (.click 44 30), f60, .ok⟩,
  ⟨2821, 0, 0, 10, f60, .act (.click 44 30), f60, .ok⟩,
  ⟨2822, 0, 0, 10, f60, .act (.click 45 30), f62, .ok⟩,
  ⟨2823, 0, 0, 10, f62, .act (.dir .left), f65, .ok⟩,
  ⟨2824, 0, 0, 10, f65, .act (.dir .left), f66, .ok⟩,
  ⟨2825, 0, 0, 10, f66, .act (.dir .down), f67, .ok⟩,
  ⟨2826, 0, 0, 10, f67, .act (.dir .left), f67, .ok⟩,
  ⟨2827, 0, 0, 10, f67, .act (.dir .up), f68, .ok⟩,
  ⟨2828, 0, 0, 10, f68, .act (.dir .up), f69, .ok⟩,
  ⟨2829, 0, 0, 10, f69, .act (.dir .right), f70, .ok⟩,
  ⟨2830, 0, 0, 10, f70, .act (.dir .right), f71, .ok⟩,
  ⟨2831, 0, 0, 10, f71, .act (.dir .down), f72, .ok⟩,
  ⟨2832, 0, 0, 10, f72, .act (.click 44 30), f72, .ok⟩,
  ⟨2833, 0, 0, 10, f72, .reset, f0, .reset⟩,
  ⟨2834, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨2835, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨2836, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨2837, 0, 0, 10, f51, .act (.dir .down), f59, .ok⟩,
  ⟨2838, 0, 0, 10, f59, .act (.dir .left), f73, .ok⟩,
  ⟨2839, 0, 0, 10, f73, .act (.dir .left), f74, .ok⟩,
  ⟨2840, 0, 0, 10, f74, .act (.dir .left), f75, .ok⟩,
  ⟨2841, 0, 0, 10, f75, .act (.dir .left), f76, .ok⟩,
  ⟨2842, 0, 0, 10, f76, .act (.click 43 31), f77, .ok⟩,
  ⟨2843, 0, 0, 10, f77, .act (.dir .up), f78, .ok⟩,
  ⟨2844, 0, 0, 10, f78, .act (.dir .right), f79, .ok⟩,
  ⟨2845, 0, 0, 10, f79, .act (.click 13 34), f80, .ok⟩,
  ⟨2846, 0, 0, 10, f80, .act (.click 13 31), f81, .ok⟩,
  ⟨2847, 0, 1, 10, f81, .act (.dir .down), f82, .levelup⟩,
  ⟨2848, 1, 1, 10, f82, .act (.click 44 34), f140, .ok⟩,
  ⟨2849, 1, 1, 10, f140, .act (.click 45 34), f140, .ok⟩,
  ⟨2850, 1, 1, 10, f140, .act (.click 47 44), f152, .ok⟩,
  ⟨2851, 1, 1, 10, f152, .act (.click 55 37), f152, .ok⟩,
  ⟨2852, 1, 1, 10, f152, .act (.dir .down), f153, .ok⟩,
  ⟨2853, 1, 1, 10, f153, .act (.dir .down), f154, .ok⟩,
  ⟨2854, 1, 1, 10, f154, .act (.dir .down), f155, .ok⟩,
  ⟨2855, 1, 1, 10, f155, .act (.dir .down), f156, .ok⟩,
  ⟨2856, 1, 1, 10, f156, .act (.dir .right), f157, .ok⟩,
  ⟨2857, 1, 1, 10, f157, .act (.dir .right), f158, .ok⟩,
  ⟨2858, 1, 1, 10, f158, .act (.dir .right), f159, .ok⟩,
  ⟨2859, 1, 1, 10, f159, .act (.dir .right), f160, .ok⟩,
  ⟨2860, 1, 1, 10, f160, .act (.click 44 34), f161, .ok⟩,
  ⟨2861, 1, 1, 10, f161, .act (.click 44 34), f161, .ok⟩,
  ⟨2862, 1, 1, 10, f161, .act (.click 44 34), f162, .ok⟩,
  ⟨2863, 1, 1, 10, f162, .act (.click 44 34), f162, .ok⟩,
  ⟨2864, 1, 1, 10, f162, .act (.click 44 34), f163, .ok⟩,
  ⟨2865, 1, 1, 10, f163, .act (.click 44 34), f163, .ok⟩,
  ⟨2866, 1, 1, 10, f163, .act (.click 44 34), f164, .ok⟩,
  ⟨2867, 1, 1, 10, f164, .act (.click 44 34), f164, .ok⟩,
  ⟨2868, 1, 1, 10, f164, .act (.click 44 34), f165, .ok⟩,
  ⟨2869, 1, 1, 10, f165, .act (.click 44 34), f165, .ok⟩,
  ⟨2870, 1, 1, 10, f165, .act (.click 44 34), f166, .ok⟩,
  ⟨2871, 1, 1, 10, f166, .act (.click 44 34), f166, .ok⟩,
  ⟨2872, 1, 1, 10, f166, .act (.click 44 34), f167, .ok⟩,
  ⟨2873, 1, 1, 10, f167, .act (.click 44 34), f167, .ok⟩,
  ⟨2874, 1, 1, 10, f167, .act (.click 44 34), f168, .ok⟩,
  ⟨2875, 1, 1, 10, f168, .act (.click 44 34), f168, .ok⟩,
  ⟨2876, 1, 1, 10, f168, .act (.click 44 34), f169, .ok⟩,
  ⟨2877, 1, 1, 10, f169, .act (.click 44 34), f169, .ok⟩,
  ⟨2878, 1, 1, 10, f169, .act (.click 44 34), f170, .ok⟩,
  ⟨2879, 1, 1, 10, f170, .act (.click 44 34), f170, .ok⟩,
  ⟨2880, 1, 1, 10, f170, .act (.click 44 34), f171, .ok⟩,
  ⟨2881, 1, 1, 10, f171, .act (.click 44 34), f171, .ok⟩,
  ⟨2882, 1, 1, 10, f171, .act (.click 44 34), f172, .ok⟩,
  ⟨2883, 1, 1, 10, f172, .act (.click 44 34), f172, .ok⟩,
  ⟨2884, 1, 1, 10, f172, .act (.click 44 34), f173, .ok⟩,
  ⟨2885, 1, 1, 10, f173, .act (.click 44 34), f173, .ok⟩,
  ⟨2886, 1, 1, 10, f173, .act (.click 44 34), f174, .ok⟩,
  ⟨2887, 1, 1, 10, f174, .act (.click 44 34), f174, .ok⟩,
  ⟨2888, 1, 1, 10, f174, .act (.click 44 34), f175, .ok⟩,
  ⟨2889, 1, 1, 10, f175, .act (.click 44 34), f175, .ok⟩,
  ⟨2890, 1, 1, 10, f175, .act (.click 44 34), f176, .ok⟩,
  ⟨2891, 1, 1, 10, f176, .act (.click 44 34), f176, .ok⟩,
  ⟨2892, 1, 1, 10, f176, .act (.click 44 34), f177, .ok⟩,
  ⟨2893, 1, 1, 10, f177, .act (.click 44 34), f177, .ok⟩,
  ⟨2894, 1, 1, 10, f177, .act (.click 44 34), f178, .ok⟩,
  ⟨2895, 1, 1, 10, f178, .act (.click 44 34), f178, .ok⟩,
  ⟨2896, 1, 1, 10, f178, .act (.click 44 34), f179, .ok⟩,
  ⟨2897, 1, 1, 10, f179, .act (.click 44 34), f179, .ok⟩,
  ⟨2898, 1, 1, 10, f179, .act (.click 44 34), f180, .ok⟩,
  ⟨2899, 1, 1, 10, f180, .act (.click 44 34), f180, .ok⟩,
  ⟨2900, 1, 1, 10, f180, .act (.click 44 34), f181, .ok⟩,
  ⟨2901, 1, 1, 10, f181, .act (.click 44 34), f181, .ok⟩,
  ⟨2902, 1, 1, 10, f181, .act (.click 44 34), f182, .ok⟩,
  ⟨2903, 1, 1, 10, f182, .act (.click 44 34), f182, .ok⟩,
  ⟨2904, 1, 1, 10, f182, .act (.click 44 34), f183, .ok⟩,
  ⟨2905, 1, 1, 10, f183, .act (.click 44 34), f183, .ok⟩,
  ⟨2906, 1, 1, 10, f183, .act (.click 44 34), f184, .ok⟩,
  ⟨2907, 1, 1, 10, f184, .act (.click 44 34), f184, .ok⟩,
  ⟨2908, 1, 1, 10, f184, .act (.click 44 34), f185, .ok⟩,
  ⟨2909, 1, 1, 10, f185, .act (.click 44 34), f185, .ok⟩,
  ⟨2910, 1, 1, 10, f185, .act (.click 44 34), f186, .ok⟩,
  ⟨2911, 1, 1, 10, f186, .act (.click 44 34), f186, .ok⟩,
  ⟨2912, 1, 1, 10, f186, .act (.click 44 34), f187, .ok⟩,
  ⟨2913, 1, 1, 10, f187, .act (.click 44 34), f187, .ok⟩,
  ⟨2914, 1, 1, 10, f187, .act (.click 44 34), f188, .ok⟩,
  ⟨2915, 1, 1, 10, f188, .act (.click 44 34), f188, .ok⟩,
  ⟨2916, 1, 1, 10, f188, .act (.click 44 34), f189, .ok⟩,
  ⟨2917, 1, 1, 10, f189, .act (.click 44 34), f189, .ok⟩,
  ⟨2918, 1, 1, 10, f189, .act (.click 44 34), f190, .ok⟩,
  ⟨2919, 1, 1, 10, f190, .act (.click 44 34), f190, .ok⟩,
  ⟨2920, 1, 1, 10, f190, .act (.click 44 34), f191, .ok⟩,
  ⟨2921, 1, 1, 10, f191, .act (.click 44 34), f191, .ok⟩,
  ⟨2922, 1, 1, 10, f191, .act (.click 44 34), f192, .ok⟩,
  ⟨2923, 1, 1, 10, f192, .act (.click 44 34), f192, .ok⟩,
  ⟨2924, 1, 1, 10, f192, .act (.click 44 34), f193, .ok⟩,
  ⟨2925, 1, 1, 10, f193, .act (.click 44 34), f193, .ok⟩,
  ⟨2926, 1, 1, 10, f193, .act (.click 44 34), f194, .ok⟩,
  ⟨2927, 1, 1, 10, f194, .act (.click 44 34), f194, .ok⟩,
  ⟨2928, 1, 1, 10, f194, .act (.click 44 34), f195, .ok⟩,
  ⟨2929, 1, 1, 10, f195, .act (.click 44 34), f195, .ok⟩,
  ⟨2930, 1, 1, 10, f195, .act (.click 44 34), f196, .ok⟩,
  ⟨2931, 1, 1, 10, f196, .act (.click 44 34), f196, .ok⟩,
  ⟨2932, 1, 1, 10, f196, .act (.click 44 34), f197, .ok⟩,
  ⟨2933, 1, 1, 10, f197, .act (.click 44 34), f197, .ok⟩,
  ⟨2934, 1, 1, 10, f197, .act (.click 44 34), f198, .ok⟩,
  ⟨2935, 1, 1, 10, f198, .act (.click 44 34), f198, .ok⟩,
  ⟨2936, 1, 1, 10, f198, .act (.click 44 34), f199, .ok⟩,
  ⟨2937, 1, 1, 10, f199, .act (.click 44 34), f199, .ok⟩,
  ⟨2938, 1, 1, 10, f199, .act (.click 44 34), f200, .ok⟩,
  ⟨2939, 1, 1, 10, f200, .act (.click 44 34), f200, .ok⟩,
  ⟨2940, 1, 1, 10, f200, .act (.click 44 34), f201, .ok⟩,
  ⟨2941, 1, 1, 10, f201, .act (.click 44 34), f201, .ok⟩,
  ⟨2942, 1, 1, 10, f201, .act (.click 44 34), f202, .ok⟩,
  ⟨2943, 1, 1, 10, f202, .act (.click 44 34), f202, .ok⟩,
  ⟨2944, 1, 1, 10, f202, .act (.click 44 34), f203, .ok⟩,
  ⟨2945, 1, 1, 10, f203, .act (.click 44 34), f203, .ok⟩,
  ⟨2946, 1, 1, 10, f203, .act (.click 44 34), f204, .ok⟩,
  ⟨2947, 1, 1, 10, f204, .act (.click 44 34), f204, .ok⟩,
  ⟨2948, 1, 1, 10, f204, .act (.click 44 34), f205, .ok⟩,
  ⟨2949, 1, 1, 10, f205, .act (.click 44 34), f205, .ok⟩,
  ⟨2950, 1, 1, 10, f205, .act (.click 44 34), f206, .ok⟩,
  ⟨2951, 1, 1, 10, f206, .act (.click 44 34), f206, .ok⟩,
  ⟨2952, 1, 1, 10, f206, .act (.click 44 34), f207, .ok⟩,
  ⟨2953, 1, 1, 10, f207, .act (.click 44 34), f207, .ok⟩,
  ⟨2954, 1, 1, 10, f207, .act (.click 44 34), f208, .ok⟩,
  ⟨2955, 1, 1, 10, f208, .act (.click 44 34), f208, .ok⟩,
  ⟨2956, 1, 1, 10, f208, .act (.click 44 34), f209, .ok⟩,
  ⟨2957, 1, 1, 10, f209, .act (.click 44 34), f209, .ok⟩,
  ⟨2958, 1, 1, 10, f209, .act (.click 44 34), f210, .ok⟩,
  ⟨2959, 1, 1, 10, f210, .act (.click 44 34), f210, .ok⟩,
  ⟨2960, 1, 1, 10, f210, .act (.click 44 34), f211, .ok⟩,
  ⟨2961, 1, 1, 10, f211, .act (.click 44 34), f211, .ok⟩,
  ⟨2962, 1, 1, 10, f211, .act (.click 44 34), f212, .ok⟩,
  ⟨2963, 1, 1, 10, f212, .act (.click 44 34), f212, .ok⟩,
  ⟨2964, 1, 1, 10, f212, .act (.click 44 34), f213, .ok⟩,
  ⟨2965, 1, 1, 10, f213, .act (.click 44 34), f213, .ok⟩,
  ⟨2966, 1, 1, 10, f213, .act (.click 44 34), f214, .ok⟩,
  ⟨2967, 1, 1, 10, f214, .act (.click 44 34), f214, .ok⟩,
  ⟨2968, 1, 1, 10, f214, .act (.click 44 34), f215, .ok⟩,
  ⟨2969, 1, 1, 10, f215, .act (.click 44 34), f215, .ok⟩,
  ⟨2970, 1, 1, 10, f215, .act (.click 44 34), f216, .ok⟩,
  ⟨2971, 1, 1, 10, f216, .act (.click 44 34), f216, .ok⟩,
  ⟨2972, 1, 1, 10, f216, .act (.click 44 34), f217, .ok⟩,
  ⟨2973, 1, 1, 10, f217, .act (.click 44 34), f217, .ok⟩,
  ⟨2974, 1, 1, 10, f217, .act (.click 44 34), f218, .over⟩,
  ⟨2975, 1, 1, 10, f218, .reset, f82, .reset⟩,
  ⟨2976, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨2977, 1, 1, 10, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨2978, 1, 1, 10, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨2979, 1, 1, 10, f142, .act (.click 47 44), f142, .ok⟩,
  ⟨2980, 1, 1, 10, f142, .act (.dir .up), f219, .ok⟩,
  ⟨2981, 1, 1, 10, f219, .act (.dir .up), f220, .ok⟩,
  ⟨2982, 1, 1, 10, f220, .act (.dir .up), f221, .ok⟩,
  ⟨2983, 1, 1, 10, f221, .act (.dir .up), f222, .ok⟩,
  ⟨2984, 1, 1, 10, f222, .act (.dir .up), f223, .ok⟩,
  ⟨2985, 1, 1, 10, f223, .act (.dir .up), f223, .ok⟩,
  ⟨2986, 1, 1, 10, f223, .act (.dir .up), f224, .ok⟩,
  ⟨2987, 1, 1, 10, f224, .act (.dir .up), f224, .ok⟩,
  ⟨2988, 1, 1, 10, f224, .act (.dir .up), f225, .ok⟩,
  ⟨2989, 1, 1, 10, f225, .act (.dir .up), f225, .ok⟩,
  ⟨2990, 1, 1, 10, f225, .act (.dir .up), f226, .ok⟩,
  ⟨2991, 1, 1, 10, f226, .act (.dir .up), f226, .ok⟩,
  ⟨2992, 1, 1, 10, f226, .act (.dir .up), f227, .ok⟩,
  ⟨2993, 1, 1, 10, f227, .act (.dir .up), f227, .ok⟩,
  ⟨2994, 1, 1, 10, f227, .act (.dir .up), f228, .ok⟩,
  ⟨2995, 1, 1, 10, f228, .act (.click 36 44), f228, .ok⟩,
  ⟨2996, 1, 1, 10, f228, .reset, f82, .reset⟩,
  ⟨2997, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨2998, 1, 1, 10, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨2999, 1, 1, 10, f141, .act (.click 44 47), f142, .ok⟩]

def rows12 : List Row := [
  ⟨3000, 1, 1, 10, f142, .reset, f82, .reset⟩,
  ⟨3001, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3002, 1, 1, 10, f140, .act (.click 41 37), f140, .ok⟩,
  ⟨3003, 1, 1, 10, f140, .act (.click 34 44), f229, .ok⟩,
  ⟨3004, 1, 1, 10, f229, .act (.click 37 44), f229, .ok⟩,
  ⟨3005, 1, 1, 10, f229, .act (.click 44 47), f143, .ok⟩,
  ⟨3006, 1, 1, 10, f143, .act (.dir .down), f230, .ok⟩,
  ⟨3007, 1, 1, 10, f230, .act (.dir .up), f231, .ok⟩,
  ⟨3008, 1, 1, 10, f231, .act (.dir .right), f232, .ok⟩,
  ⟨3009, 1, 1, 10, f232, .act (.dir .left), f233, .ok⟩,
  ⟨3010, 1, 1, 10, f233, .act (.click 13 34), f233, .ok⟩,
  ⟨3011, 1, 1, 10, f233, .act (.dir .down), f234, .ok⟩,
  ⟨3012, 1, 1, 10, f234, .act (.click 48 45), f234, .ok⟩,
  ⟨3013, 1, 1, 10, f234, .reset, f82, .reset⟩,
  ⟨3014, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3015, 1, 1, 10, f140, .act (.click 42 34), f140, .ok⟩,
  ⟨3016, 1, 1, 10, f140, .act (.click 34 44), f229, .ok⟩,
  ⟨3017, 1, 1, 10, f229, .act (.click 34 45), f229, .ok⟩,
  ⟨3018, 1, 1, 10, f229, .act (.click 44 47), f143, .ok⟩,
  ⟨3019, 1, 1, 10, f143, .act (.click 44 48), f143, .ok⟩,
  ⟨3020, 1, 1, 10, f143, .act (.click 47 44), f231, .ok⟩,
  ⟨3021, 1, 1, 10, f231, .act (.click 48 45), f231, .ok⟩,
  ⟨3022, 1, 1, 10, f231, .act (.dir .down), f235, .ok⟩,
  ⟨3023, 1, 1, 10, f235, .act (.dir .up), f233, .ok⟩,
  ⟨3024, 1, 1, 10, f233, .act (.dir .up), f236, .ok⟩,
  ⟨3025, 1, 1, 10, f236, .act (.dir .up), f237, .ok⟩,
  ⟨3026, 1, 1, 10, f237, .act (.dir .up), f238, .ok⟩,
  ⟨3027, 1, 1, 10, f238, .act (.dir .up), f239, .ok⟩,
  ⟨3028, 1, 1, 10, f239, .act (.dir .down), f240, .ok⟩,
  ⟨3029, 1, 1, 10, f240, .act (.click 41 44), f240, .ok⟩,
  ⟨3030, 1, 1, 10, f240, .act (.click 42 42), f241, .ok⟩,
  ⟨3031, 1, 1, 10, f241, .act (.click 42 42), f241, .ok⟩,
  ⟨3032, 1, 1, 10, f241, .act (.click 42 42), f242, .ok⟩,
  ⟨3033, 1, 1, 10, f242, .act (.click 42 42), f242, .ok⟩,
  ⟨3034, 1, 1, 10, f242, .act (.click 42 42), f243, .ok⟩,
  ⟨3035, 1, 1, 10, f243, .act (.click 42 42), f243, .ok⟩,
  ⟨3036, 1, 1, 10, f243, .act (.click 18 63), f244, .ok⟩,
  ⟨3037, 1, 1, 10, f244, .reset, f82, .reset⟩,
  ⟨3038, 1, 1, 10, f82, .act (.click 34 41), f83, .ok⟩,
  ⟨3039, 1, 1, 10, f83, .act (.click 44 34), f140, .ok⟩,
  ⟨3040, 1, 1, 10, f140, .act (.click 45 34), f152, .ok⟩,
  ⟨3041, 1, 1, 10, f152, .act (.click 44 47), f245, .ok⟩,
  ⟨3042, 1, 1, 10, f245, .act (.click 45 47), f246, .ok⟩,
  ⟨3043, 1, 1, 10, f246, .act (.click 34 44), f247, .ok⟩,
  ⟨3044, 1, 1, 10, f247, .act (.click 34 45), f248, .ok⟩,
  ⟨3045, 1, 1, 10, f248, .act (.click 44 48), f231, .ok⟩,
  ⟨3046, 1, 1, 10, f231, .act (.click 45 48), f233, .ok⟩,
  ⟨3047, 1, 1, 10, f233, .act (.click 45 45), f233, .ok⟩,
  ⟨3048, 1, 1, 10, f233, .act (.click 46 45), f249, .ok⟩,
  ⟨3049, 1, 1, 10, f249, .act (.click 47 45), f249, .ok⟩,
  ⟨3050, 1, 1, 10, f249, .act (.click 48 45), f250, .ok⟩,
  ⟨3051, 1, 1, 10, f250, .act (.dir .down), f251, .ok⟩,
  ⟨3052, 1, 1, 10, f251, .act (.click 45 45), f252, .ok⟩,
  ⟨3053, 1, 1, 10, f252, .act (.dir .down), f253, .ok⟩,
  ⟨3054, 1, 1, 10, f253, .reset, f82, .reset⟩,
  ⟨3055, 1, 1, 10, f82, .act (.click 45 45), f254, .ok⟩,
  ⟨3056, 1, 1, 10, f254, .act (.dir .up), f255, .ok⟩,
  ⟨3057, 1, 1, 10, f255, .act (.dir .up), f256, .ok⟩,
  ⟨3058, 1, 1, 10, f256, .act (.dir .up), f257, .ok⟩,
  ⟨3059, 1, 1, 10, f257, .act (.dir .up), f258, .ok⟩,
  ⟨3060, 1, 1, 10, f258, .act (.dir .up), f259, .ok⟩,
  ⟨3061, 1, 1, 10, f259, .act (.dir .down), f260, .ok⟩,
  ⟨3062, 1, 1, 10, f260, .act (.dir .up), f261, .ok⟩,
  ⟨3063, 1, 1, 10, f261, .act (.dir .up), f262, .ok⟩,
  ⟨3064, 1, 1, 10, f262, .act (.dir .up), f262, .ok⟩,
  ⟨3065, 1, 1, 10, f262, .act (.dir .up), f263, .ok⟩,
  ⟨3066, 1, 1, 10, f263, .act (.click 31 41), f263, .ok⟩,
  ⟨3067, 1, 1, 10, f263, .act (.click 38 34), f264, .ok⟩,
  ⟨3068, 1, 1, 10, f264, .act (.click 34 38), f264, .ok⟩,
  ⟨3069, 1, 1, 10, f264, .act (.click 41 31), f265, .ok⟩,
  ⟨3070, 1, 1, 10, f265, .act (.click 34 44), f266, .ok⟩,
  ⟨3071, 1, 1, 10, f266, .act (.dir .down), f267, .ok⟩,
  ⟨3072, 1, 1, 10, f267, .reset, f82, .reset⟩,
  ⟨3073, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3074, 1, 1, 10, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨3075, 1, 1, 10, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨3076, 1, 1, 10, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨3077, 1, 1, 10, f142, .act (.dir .down), f230, .ok⟩,
  ⟨3078, 1, 1, 10, f230, .reset, f82, .reset⟩,
  ⟨3079, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3080, 1, 1, 10, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨3081, 1, 1, 10, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨3082, 1, 1, 10, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨3083, 1, 1, 10, f142, .reset, f82, .reset⟩,
  ⟨3084, 1, 1, 10, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3085, 1, 1, 10, f140, .act (.click 34 44), f141, .ok⟩,
  ⟨3086, 1, 1, 10, f141, .act (.click 44 47), f142, .ok⟩,
  ⟨3087, 1, 1, 10, f142, .act (.click 45 48), f142, .ok⟩,
  ⟨3088, 1, 1, 10, f142, .act (.dir .down), f230, .ok⟩,
  ⟨3089, 1, 1, 10, f230, .reset, f82, .reset⟩,
  ⟨3090, 1, 1, 10, f82, .act (.dir .up), f84, .ok⟩,
  ⟨3091, 1, 1, 10, f84, .act (.dir .left), f268, .ok⟩,
  ⟨3092, 1, 1, 10, f268, .act (.dir .right), f269, .ok⟩,
  ⟨3093, 1, 1, 10, f269, .act (.dir .up), f270, .ok⟩,
  ⟨3094, 1, 1, 10, f270, .act (.dir .up), f271, .ok⟩,
  ⟨3095, 1, 1, 10, f271, .act (.dir .up), f272, .ok⟩,
  ⟨3096, 1, 1, 10, f272, .act (.dir .up), f273, .ok⟩,
  ⟨3097, 1, 1, 10, f273, .act (.dir .up), f274, .ok⟩,
  ⟨3098, 1, 1, 10, f274, .act (.dir .up), f275, .ok⟩,
  ⟨3099, 1, 1, 10, f275, .act (.dir .up), f276, .ok⟩,
  ⟨3100, 1, 1, 10, f276, .act (.dir .up), f277, .ok⟩,
  ⟨3101, 1, 1, 10, f277, .act (.dir .up), f277, .ok⟩,
  ⟨3102, 1, 1, 10, f277, .act (.dir .up), f278, .ok⟩,
  ⟨3103, 1, 1, 10, f278, .act (.dir .up), f278, .ok⟩,
  ⟨3104, 1, 1, 10, f278, .act (.dir .up), f279, .ok⟩,
  ⟨3105, 1, 1, 10, f279, .act (.dir .up), f279, .ok⟩,
  ⟨3106, 1, 1, 10, f279, .act (.dir .up), f280, .ok⟩,
  ⟨3107, 1, 1, 10, f280, .act (.dir .up), f280, .ok⟩,
  ⟨3108, 1, 1, 10, f280, .act (.dir .up), f281, .ok⟩,
  ⟨3109, 1, 1, 10, f281, .act (.dir .up), f281, .ok⟩,
  ⟨3110, 1, 1, 10, f281, .act (.dir .up), f282, .ok⟩,
  ⟨3111, 1, 1, 10, f282, .act (.dir .up), f282, .ok⟩,
  ⟨3112, 1, 1, 10, f282, .act (.dir .up), f283, .ok⟩,
  ⟨3113, 1, 1, 10, f283, .act (.dir .up), f283, .ok⟩,
  ⟨3114, 1, 1, 10, f283, .act (.dir .up), f284, .ok⟩,
  ⟨3115, 1, 1, 10, f284, .act (.dir .up), f284, .ok⟩,
  ⟨3116, 1, 1, 10, f284, .act (.dir .up), f285, .ok⟩,
  ⟨3117, 1, 1, 10, f285, .act (.dir .up), f285, .ok⟩,
  ⟨3118, 1, 1, 10, f285, .act (.dir .up), f286, .ok⟩,
  ⟨3119, 1, 1, 10, f286, .act (.dir .up), f286, .ok⟩,
  ⟨3120, 1, 1, 10, f286, .act (.dir .up), f287, .ok⟩,
  ⟨3121, 1, 1, 10, f287, .act (.dir .up), f287, .ok⟩,
  ⟨3122, 1, 1, 10, f287, .act (.dir .up), f288, .ok⟩,
  ⟨3123, 1, 1, 10, f288, .act (.dir .up), f288, .ok⟩,
  ⟨3124, 1, 1, 10, f288, .act (.dir .up), f289, .ok⟩,
  ⟨3125, 1, 1, 10, f289, .act (.dir .up), f289, .ok⟩,
  ⟨3126, 1, 1, 10, f289, .act (.dir .up), f290, .ok⟩,
  ⟨3127, 1, 1, 10, f290, .act (.dir .up), f290, .ok⟩,
  ⟨3128, 1, 1, 10, f290, .act (.dir .up), f291, .ok⟩,
  ⟨3129, 1, 1, 10, f291, .act (.dir .up), f291, .ok⟩,
  ⟨3130, 1, 1, 10, f291, .act (.dir .up), f292, .ok⟩,
  ⟨3131, 1, 1, 10, f292, .act (.dir .up), f292, .ok⟩,
  ⟨3132, 1, 1, 10, f292, .act (.dir .up), f293, .ok⟩,
  ⟨3133, 1, 1, 10, f293, .act (.dir .up), f293, .ok⟩,
  ⟨3134, 1, 1, 10, f293, .act (.dir .up), f294, .ok⟩,
  ⟨3135, 1, 1, 10, f294, .act (.dir .up), f294, .ok⟩,
  ⟨3136, 1, 1, 10, f294, .act (.dir .up), f295, .ok⟩,
  ⟨3137, 1, 1, 10, f295, .act (.dir .up), f295, .ok⟩,
  ⟨3138, 1, 1, 10, f295, .act (.dir .up), f296, .ok⟩,
  ⟨3139, 1, 1, 10, f296, .act (.dir .up), f296, .ok⟩,
  ⟨3140, 1, 1, 10, f296, .act (.dir .up), f297, .ok⟩,
  ⟨3141, 1, 1, 10, f297, .act (.dir .up), f297, .ok⟩,
  ⟨3142, 1, 1, 10, f297, .act (.dir .up), f298, .ok⟩,
  ⟨3143, 1, 1, 10, f298, .act (.dir .up), f298, .ok⟩,
  ⟨3144, 1, 1, 10, f298, .act (.dir .up), f299, .ok⟩,
  ⟨3145, 1, 1, 10, f299, .act (.dir .up), f299, .ok⟩,
  ⟨3146, 1, 1, 10, f299, .act (.dir .up), f300, .ok⟩,
  ⟨3147, 1, 1, 10, f300, .act (.dir .up), f300, .ok⟩,
  ⟨3148, 1, 1, 10, f300, .act (.dir .up), f301, .ok⟩,
  ⟨3149, 1, 1, 10, f301, .act (.dir .up), f301, .ok⟩,
  ⟨3150, 1, 1, 10, f301, .act (.dir .up), f302, .ok⟩,
  ⟨3151, 1, 1, 10, f302, .act (.dir .up), f302, .ok⟩,
  ⟨3152, 1, 1, 10, f302, .act (.dir .up), f303, .ok⟩,
  ⟨3153, 1, 1, 10, f303, .act (.dir .up), f303, .ok⟩,
  ⟨3154, 1, 1, 10, f303, .act (.dir .up), f304, .ok⟩,
  ⟨3155, 1, 1, 10, f304, .act (.dir .up), f304, .ok⟩,
  ⟨3156, 1, 1, 10, f304, .act (.dir .up), f305, .ok⟩,
  ⟨3157, 1, 1, 10, f305, .act (.dir .up), f305, .ok⟩,
  ⟨3158, 1, 1, 10, f305, .act (.dir .up), f306, .ok⟩,
  ⟨3159, 1, 1, 10, f306, .act (.dir .up), f306, .ok⟩,
  ⟨3160, 1, 1, 10, f306, .act (.dir .up), f307, .ok⟩,
  ⟨3161, 1, 1, 10, f307, .act (.dir .up), f307, .ok⟩,
  ⟨3162, 1, 1, 10, f307, .act (.dir .up), f308, .ok⟩,
  ⟨3163, 1, 1, 10, f308, .act (.dir .up), f308, .ok⟩,
  ⟨3164, 1, 1, 10, f308, .act (.dir .up), f309, .ok⟩,
  ⟨3165, 1, 1, 10, f309, .act (.dir .up), f309, .ok⟩,
  ⟨3166, 1, 1, 10, f309, .act (.dir .up), f310, .ok⟩,
  ⟨3167, 1, 1, 10, f310, .act (.dir .up), f310, .ok⟩,
  ⟨3168, 1, 1, 10, f310, .act (.dir .up), f311, .ok⟩,
  ⟨3169, 1, 1, 10, f311, .act (.dir .up), f311, .ok⟩,
  ⟨3170, 1, 1, 10, f311, .act (.dir .up), f312, .ok⟩,
  ⟨3171, 1, 1, 10, f312, .act (.dir .up), f312, .ok⟩,
  ⟨3172, 1, 1, 10, f312, .act (.dir .up), f313, .ok⟩,
  ⟨3173, 1, 1, 10, f313, .act (.dir .up), f313, .ok⟩,
  ⟨3174, 1, 1, 10, f313, .act (.dir .up), f314, .ok⟩,
  ⟨3175, 1, 1, 10, f314, .act (.dir .up), f314, .ok⟩,
  ⟨3176, 1, 1, 10, f314, .act (.dir .up), f315, .ok⟩,
  ⟨3177, 1, 1, 10, f315, .act (.dir .up), f315, .ok⟩,
  ⟨3178, 1, 1, 10, f315, .act (.dir .up), f316, .ok⟩,
  ⟨3179, 1, 1, 10, f316, .act (.dir .up), f316, .ok⟩,
  ⟨3180, 1, 1, 10, f316, .act (.dir .up), f317, .ok⟩,
  ⟨3181, 1, 1, 10, f317, .act (.dir .up), f317, .ok⟩,
  ⟨3182, 1, 1, 10, f317, .act (.dir .up), f318, .ok⟩,
  ⟨3183, 1, 1, 10, f318, .act (.dir .up), f318, .ok⟩,
  ⟨3184, 1, 1, 10, f318, .act (.dir .up), f319, .ok⟩,
  ⟨3185, 1, 1, 10, f319, .act (.dir .up), f319, .ok⟩,
  ⟨3186, 1, 1, 10, f319, .act (.dir .up), f320, .ok⟩,
  ⟨3187, 1, 1, 10, f320, .act (.dir .up), f320, .ok⟩,
  ⟨3188, 1, 1, 10, f320, .act (.dir .up), f321, .ok⟩,
  ⟨3189, 1, 1, 10, f321, .act (.dir .up), f321, .ok⟩,
  ⟨3190, 1, 1, 10, f321, .act (.dir .up), f322, .ok⟩,
  ⟨3191, 1, 1, 10, f322, .act (.dir .up), f322, .ok⟩,
  ⟨3192, 1, 1, 10, f322, .act (.dir .up), f323, .ok⟩,
  ⟨3193, 1, 1, 10, f323, .act (.dir .up), f323, .ok⟩,
  ⟨3194, 1, 1, 10, f323, .act (.dir .up), f324, .ok⟩,
  ⟨3195, 1, 1, 10, f324, .act (.dir .up), f324, .ok⟩,
  ⟨3196, 1, 1, 10, f324, .act (.dir .up), f325, .ok⟩,
  ⟨3197, 1, 1, 10, f325, .act (.dir .up), f325, .ok⟩,
  ⟨3198, 1, 1, 10, f325, .act (.dir .up), f326, .ok⟩,
  ⟨3199, 1, 1, 10, f326, .act (.dir .up), f326, .ok⟩,
  ⟨3200, 1, 1, 10, f326, .act (.dir .up), f327, .ok⟩,
  ⟨3201, 1, 1, 10, f327, .act (.dir .up), f327, .ok⟩,
  ⟨3202, 1, 1, 10, f327, .act (.dir .up), f328, .ok⟩,
  ⟨3203, 1, 1, 10, f328, .act (.dir .up), f328, .ok⟩,
  ⟨3204, 1, 1, 10, f328, .act (.dir .up), f329, .ok⟩,
  ⟨3205, 1, 1, 10, f329, .act (.dir .up), f329, .ok⟩,
  ⟨3206, 1, 1, 10, f329, .act (.dir .up), f330, .ok⟩,
  ⟨3207, 1, 1, 10, f330, .act (.dir .up), f330, .ok⟩,
  ⟨3208, 1, 1, 10, f330, .act (.dir .up), f331, .ok⟩,
  ⟨3209, 1, 1, 10, f331, .act (.dir .up), f331, .ok⟩,
  ⟨3210, 1, 1, 10, f331, .act (.dir .up), f332, .ok⟩,
  ⟨3211, 1, 1, 10, f332, .act (.dir .up), f332, .ok⟩,
  ⟨3212, 1, 1, 10, f332, .act (.dir .up), f333, .ok⟩,
  ⟨3213, 1, 1, 10, f333, .act (.dir .up), f333, .ok⟩,
  ⟨3214, 1, 1, 10, f333, .act (.dir .up), f334, .ok⟩,
  ⟨3215, 1, 1, 10, f334, .act (.dir .up), f334, .ok⟩,
  ⟨3216, 1, 1, 10, f334, .act (.dir .up), f335, .over⟩,
  ⟨3217, 1, 1, 10, f335, .reset, f82, .reset⟩,
  ⟨3218, 1, 0, 10, f82, .reset, f0, .reset⟩,
  ⟨3219, 0, 0, 10, f0, .act (.dir .right), f49, .ok⟩,
  ⟨3220, 0, 0, 10, f49, .act (.dir .right), f50, .ok⟩,
  ⟨3221, 0, 0, 10, f50, .act (.dir .right), f51, .ok⟩,
  ⟨3222, 0, 0, 10, f51, .act (.dir .left), f73, .ok⟩,
  ⟨3223, 0, 0, 10, f73, .act (.dir .down), f336, .ok⟩,
  ⟨3224, 0, 0, 10, f336, .act (.dir .left), f337, .ok⟩,
  ⟨3225, 0, 0, 10, f337, .act (.dir .left), f338, .ok⟩,
  ⟨3226, 0, 0, 10, f338, .act (.dir .left), f339, .ok⟩,
  ⟨3227, 0, 0, 10, f339, .act (.click 42 30), f340, .ok⟩,
  ⟨3228, 0, 0, 10, f340, .act (.dir .up), f341, .ok⟩,
  ⟨3229, 0, 1, 10, f341, .act (.dir .right), f82, .levelup⟩,
  ⟨3230, 1, 1, 10, f82, .act (.dir .up), f84, .ok⟩,
  ⟨3231, 1, 1, 10, f84, .act (.dir .up), f342, .ok⟩,
  ⟨3232, 1, 1, 10, f342, .act (.dir .up), f343, .ok⟩,
  ⟨3233, 1, 1, 10, f343, .act (.dir .up), f344, .ok⟩,
  ⟨3234, 1, 1, 10, f344, .act (.dir .left), f345, .ok⟩,
  ⟨3235, 1, 1, 10, f345, .act (.click 39 33), f346, .ok⟩,
  ⟨3236, 1, 1, 10, f346, .act (.dir .down), f347, .ok⟩,
  ⟨3237, 1, 1, 10, f347, .act (.dir .down), f348, .ok⟩,
  ⟨3238, 1, 1, 10, f348, .act (.dir .down), f349, .ok⟩,
  ⟨3239, 1, 1, 10, f349, .act (.dir .left), f350, .ok⟩,
  ⟨3240, 1, 1, 10, f350, .act (.dir .right), f351, .ok⟩,
  ⟨3241, 1, 1, 10, f351, .act (.dir .right), f352, .ok⟩,
  ⟨3242, 1, 1, 10, f352, .act (.dir .right), f353, .ok⟩,
  ⟨3243, 1, 1, 10, f353, .act (.dir .down), f354, .ok⟩,
  ⟨3244, 1, 1, 10, f354, .act (.dir .left), f355, .ok⟩,
  ⟨3245, 1, 1, 10, f355, .act (.dir .up), f356, .ok⟩,
  ⟨3246, 1, 1, 10, f356, .act (.click 15 45), f357, .ok⟩,
  ⟨3247, 1, 1, 10, f357, .act (.dir .down), f358, .ok⟩,
  ⟨3248, 1, 1, 10, f358, .act (.dir .left), f359, .ok⟩,
  ⟨3249, 1, 1, 10, f359, .act (.dir .up), f360, .ok⟩]

def rows13 : List Row := [
  ⟨3250, 1, 1, 10, f360, .act (.dir .up), f361, .ok⟩,
  ⟨3251, 1, 1, 10, f361, .act (.dir .up), f362, .ok⟩,
  ⟨3252, 1, 1, 10, f362, .act (.dir .right), f363, .ok⟩,
  ⟨3253, 1, 1, 10, f363, .act (.dir .left), f364, .ok⟩,
  ⟨3254, 1, 1, 10, f364, .act (.dir .left), f365, .ok⟩,
  ⟨3255, 1, 1, 10, f365, .act (.click 48 42), f366, .ok⟩,
  ⟨3256, 1, 1, 10, f366, .act (.dir .up), f367, .ok⟩,
  ⟨3257, 1, 1, 10, f367, .act (.dir .right), f368, .ok⟩,
  ⟨3258, 1, 1, 10, f368, .act (.dir .right), f369, .ok⟩,
  ⟨3259, 1, 1, 10, f369, .act (.click 12 18), f370, .ok⟩,
  ⟨3260, 1, 1, 10, f370, .act (.dir .up), f371, .ok⟩,
  ⟨3261, 1, 1, 10, f371, .act (.dir .up), f372, .ok⟩,
  ⟨3262, 1, 1, 10, f372, .act (.dir .up), f373, .ok⟩,
  ⟨3263, 1, 1, 10, f373, .act (.dir .left), f374, .ok⟩,
  ⟨3264, 1, 1, 10, f374, .act (.click 33 42), f375, .ok⟩,
  ⟨3265, 1, 1, 10, f375, .act (.dir .down), f376, .ok⟩,
  ⟨3266, 1, 1, 10, f376, .act (.dir .down), f377, .ok⟩,
  ⟨3267, 1, 1, 10, f377, .act (.dir .down), f378, .ok⟩,
  ⟨3268, 1, 1, 10, f378, .act (.dir .right), f379, .ok⟩,
  ⟨3269, 1, 1, 10, f379, .act (.dir .right), f380, .ok⟩,
  ⟨3270, 1, 1, 10, f380, .act (.dir .right), f381, .ok⟩,
  ⟨3271, 1, 1, 10, f381, .act (.dir .right), f382, .ok⟩,
  ⟨3272, 1, 1, 10, f382, .act (.dir .right), f383, .ok⟩,
  ⟨3273, 1, 2, 10, f383, .act (.dir .right), f384, .levelup⟩,
  ⟨3274, 2, 2, 10, f384, .act (.dir .down), f385, .ok⟩,
  ⟨3275, 2, 2, 10, f385, .act (.dir .down), f386, .ok⟩,
  ⟨3276, 2, 2, 10, f386, .act (.dir .down), f387, .ok⟩,
  ⟨3277, 2, 2, 10, f387, .act (.dir .down), f388, .ok⟩,
  ⟨3278, 2, 2, 10, f388, .act (.dir .down), f389, .ok⟩,
  ⟨3279, 2, 2, 10, f389, .act (.dir .left), f390, .ok⟩,
  ⟨3280, 2, 2, 10, f390, .act (.dir .left), f391, .ok⟩,
  ⟨3281, 2, 2, 10, f391, .act (.dir .left), f392, .ok⟩,
  ⟨3282, 2, 2, 10, f392, .act (.dir .right), f393, .ok⟩,
  ⟨3283, 2, 2, 10, f393, .act (.dir .right), f394, .ok⟩,
  ⟨3284, 2, 2, 10, f394, .act (.dir .right), f395, .ok⟩,
  ⟨3285, 2, 2, 10, f395, .act (.dir .right), f396, .ok⟩,
  ⟨3286, 2, 2, 10, f396, .act (.dir .right), f397, .ok⟩,
  ⟨3287, 2, 2, 10, f397, .act (.dir .right), f398, .ok⟩,
  ⟨3288, 2, 2, 10, f398, .act (.dir .right), f399, .ok⟩,
  ⟨3289, 2, 2, 10, f399, .act (.dir .up), f400, .ok⟩,
  ⟨3290, 2, 2, 10, f400, .act (.dir .left), f401, .ok⟩,
  ⟨3291, 2, 2, 10, f401, .act (.dir .left), f402, .ok⟩,
  ⟨3292, 2, 2, 10, f402, .act (.dir .left), f403, .ok⟩,
  ⟨3293, 2, 2, 10, f403, .act (.dir .left), f404, .ok⟩,
  ⟨3294, 2, 2, 10, f404, .act (.dir .left), f405, .ok⟩,
  ⟨3295, 2, 2, 10, f405, .act (.dir .left), f406, .ok⟩,
  ⟨3296, 2, 2, 10, f406, .act (.dir .left), f407, .ok⟩,
  ⟨3297, 2, 2, 10, f407, .act (.dir .left), f408, .ok⟩,
  ⟨3298, 2, 2, 10, f408, .act (.dir .left), f409, .ok⟩,
  ⟨3299, 2, 2, 10, f409, .act (.dir .left), f410, .ok⟩,
  ⟨3300, 2, 2, 10, f410, .act (.dir .left), f411, .ok⟩,
  ⟨3301, 2, 2, 10, f411, .act (.dir .left), f412, .ok⟩,
  ⟨3302, 2, 2, 10, f412, .act (.dir .down), f413, .ok⟩,
  ⟨3303, 2, 2, 10, f413, .act (.dir .left), f414, .ok⟩,
  ⟨3304, 2, 2, 10, f414, .act (.dir .left), f415, .ok⟩,
  ⟨3305, 2, 2, 10, f415, .act (.dir .down), f416, .ok⟩,
  ⟨3306, 2, 2, 10, f416, .act (.dir .down), f417, .ok⟩,
  ⟨3307, 2, 2, 10, f417, .act (.dir .right), f418, .ok⟩,
  ⟨3308, 2, 2, 10, f418, .act (.dir .right), f419, .ok⟩,
  ⟨3309, 2, 2, 10, f419, .act (.dir .right), f420, .ok⟩,
  ⟨3310, 2, 2, 10, f420, .act (.dir .right), f421, .ok⟩,
  ⟨3311, 2, 2, 10, f421, .act (.dir .right), f422, .ok⟩,
  ⟨3312, 2, 2, 10, f422, .act (.dir .up), f423, .ok⟩,
  ⟨3313, 2, 2, 10, f423, .act (.dir .up), f424, .ok⟩,
  ⟨3314, 2, 3, 10, f424, .act (.dir .right), f425, .levelup⟩,
  ⟨3315, 3, 3, 10, f425, .act (.dir .right), f426, .ok⟩,
  ⟨3316, 3, 3, 10, f426, .act (.dir .right), f427, .ok⟩,
  ⟨3317, 3, 3, 10, f427, .act (.dir .right), f428, .ok⟩,
  ⟨3318, 3, 3, 10, f428, .act (.dir .down), f429, .ok⟩,
  ⟨3319, 3, 3, 10, f429, .act (.click 29 47), f430, .ok⟩,
  ⟨3320, 3, 3, 10, f430, .act (.dir .left), f431, .ok⟩,
  ⟨3321, 3, 3, 10, f431, .act (.dir .left), f432, .ok⟩,
  ⟨3322, 3, 3, 10, f432, .act (.dir .left), f433, .ok⟩,
  ⟨3323, 3, 3, 10, f433, .act (.dir .down), f434, .ok⟩,
  ⟨3324, 3, 3, 10, f434, .act (.dir .right), f435, .ok⟩,
  ⟨3325, 3, 3, 10, f435, .act (.dir .right), f436, .ok⟩,
  ⟨3326, 3, 3, 10, f436, .act (.dir .right), f437, .ok⟩,
  ⟨3327, 3, 3, 10, f437, .act (.dir .right), f438, .ok⟩,
  ⟨3328, 3, 3, 10, f438, .act (.dir .right), f439, .ok⟩,
  ⟨3329, 3, 3, 10, f439, .act (.dir .down), f440, .ok⟩,
  ⟨3330, 3, 3, 10, f440, .act (.dir .down), f441, .ok⟩,
  ⟨3331, 3, 3, 10, f441, .act (.dir .right), f442, .ok⟩,
  ⟨3332, 3, 3, 10, f442, .act (.dir .up), f443, .ok⟩,
  ⟨3333, 3, 3, 10, f443, .act (.dir .up), f444, .ok⟩,
  ⟨3334, 3, 3, 10, f444, .act (.dir .right), f445, .ok⟩,
  ⟨3335, 3, 3, 10, f445, .act (.click 29 29), f446, .ok⟩,
  ⟨3336, 3, 3, 10, f446, .act (.dir .right), f447, .ok⟩,
  ⟨3337, 3, 3, 10, f447, .act (.dir .down), f448, .ok⟩,
  ⟨3338, 3, 3, 10, f448, .act (.dir .down), f449, .ok⟩,
  ⟨3339, 3, 3, 10, f449, .act (.dir .right), f450, .ok⟩,
  ⟨3340, 3, 3, 10, f450, .act (.dir .up), f451, .ok⟩,
  ⟨3341, 3, 3, 10, f451, .act (.dir .up), f452, .ok⟩,
  ⟨3342, 3, 3, 10, f452, .act (.dir .up), f453, .ok⟩,
  ⟨3343, 3, 3, 10, f453, .act (.dir .right), f454, .ok⟩,
  ⟨3344, 3, 3, 10, f454, .act (.dir .up), f455, .ok⟩,
  ⟨3345, 3, 3, 10, f455, .act (.dir .up), f456, .ok⟩,
  ⟨3346, 3, 3, 10, f456, .act (.dir .up), f457, .ok⟩,
  ⟨3347, 3, 3, 10, f457, .act (.dir .right), f458, .ok⟩,
  ⟨3348, 3, 3, 10, f458, .act (.dir .right), f459, .ok⟩,
  ⟨3349, 3, 3, 10, f459, .act (.dir .right), f460, .ok⟩,
  ⟨3350, 3, 3, 10, f460, .act (.dir .down), f461, .ok⟩,
  ⟨3351, 3, 3, 10, f461, .act (.dir .down), f462, .ok⟩,
  ⟨3352, 3, 4, 10, f462, .act (.dir .right), f463, .levelup⟩,
  ⟨3353, 4, 4, 10, f463, .act (.dir .up), f464, .ok⟩,
  ⟨3354, 4, 4, 10, f464, .act (.dir .up), f465, .ok⟩,
  ⟨3355, 4, 4, 10, f465, .act (.dir .up), f466, .ok⟩,
  ⟨3356, 4, 4, 10, f466, .act (.dir .up), f467, .ok⟩,
  ⟨3357, 4, 4, 10, f467, .act (.dir .up), f468, .ok⟩,
  ⟨3358, 4, 4, 10, f468, .act (.dir .up), f469, .ok⟩,
  ⟨3359, 4, 4, 10, f469, .act (.dir .up), f470, .ok⟩,
  ⟨3360, 4, 4, 10, f470, .act (.dir .up), f471, .ok⟩,
  ⟨3361, 4, 4, 10, f471, .act (.dir .up), f472, .ok⟩,
  ⟨3362, 4, 4, 10, f472, .act (.dir .up), f473, .ok⟩,
  ⟨3363, 4, 4, 10, f473, .act (.dir .up), f474, .ok⟩,
  ⟨3364, 4, 4, 10, f474, .act (.dir .up), f475, .ok⟩,
  ⟨3365, 4, 4, 10, f475, .act (.dir .right), f476, .ok⟩,
  ⟨3366, 4, 4, 10, f476, .act (.dir .right), f477, .ok⟩,
  ⟨3367, 4, 4, 10, f477, .act (.dir .right), f478, .ok⟩,
  ⟨3368, 4, 4, 10, f478, .act (.dir .right), f479, .ok⟩,
  ⟨3369, 4, 4, 10, f479, .act (.dir .right), f480, .ok⟩,
  ⟨3370, 4, 4, 10, f480, .act (.dir .right), f481, .ok⟩,
  ⟨3371, 4, 4, 10, f481, .act (.dir .right), f482, .ok⟩,
  ⟨3372, 4, 5, 10, f482, .act (.dir .down), f483, .levelup⟩,
  ⟨3373, 5, 5, 10, f483, .act (.dir .left), f484, .ok⟩,
  ⟨3374, 5, 5, 10, f484, .act (.dir .left), f485, .ok⟩,
  ⟨3375, 5, 5, 10, f485, .act (.dir .left), f486, .ok⟩,
  ⟨3376, 5, 5, 10, f486, .act (.dir .left), f487, .ok⟩,
  ⟨3377, 5, 5, 10, f487, .act (.dir .left), f488, .ok⟩,
  ⟨3378, 5, 5, 10, f488, .act (.dir .left), f489, .ok⟩,
  ⟨3379, 5, 5, 10, f489, .act (.dir .down), f490, .ok⟩,
  ⟨3380, 5, 5, 10, f490, .act (.dir .up), f491, .ok⟩,
  ⟨3381, 5, 5, 10, f491, .act (.dir .up), f492, .ok⟩,
  ⟨3382, 5, 5, 10, f492, .act (.dir .left), f493, .ok⟩,
  ⟨3383, 5, 5, 10, f493, .act (.dir .left), f494, .ok⟩,
  ⟨3384, 5, 5, 10, f494, .act (.dir .up), f495, .ok⟩,
  ⟨3385, 5, 5, 10, f495, .act (.dir .up), f496, .ok⟩,
  ⟨3386, 5, 5, 10, f496, .act (.dir .left), f497, .ok⟩,
  ⟨3387, 5, 5, 10, f497, .act (.dir .left), f498, .ok⟩,
  ⟨3388, 5, 5, 10, f498, .act (.dir .right), f499, .ok⟩,
  ⟨3389, 5, 5, 10, f499, .act (.dir .down), f500, .ok⟩,
  ⟨3390, 5, 5, 10, f500, .act (.dir .up), f501, .ok⟩,
  ⟨3391, 5, 5, 10, f501, .act (.dir .down), f502, .ok⟩,
  ⟨3392, 5, 5, 10, f502, .act (.dir .left), f503, .ok⟩,
  ⟨3393, 5, 5, 10, f503, .act (.dir .left), f504, .ok⟩,
  ⟨3394, 5, 5, 10, f504, .act (.dir .left), f505, .ok⟩,
  ⟨3395, 5, 5, 10, f505, .act (.dir .left), f506, .ok⟩,
  ⟨3396, 5, 5, 10, f506, .act (.dir .up), f507, .ok⟩,
  ⟨3397, 5, 5, 10, f507, .act (.dir .up), f508, .ok⟩,
  ⟨3398, 5, 5, 10, f508, .act (.dir .left), f509, .ok⟩,
  ⟨3399, 5, 5, 10, f509, .act (.dir .left), f510, .ok⟩,
  ⟨3400, 5, 5, 10, f510, .act (.dir .left), f511, .ok⟩,
  ⟨3401, 5, 5, 10, f511, .act (.dir .up), f512, .ok⟩,
  ⟨3402, 5, 5, 10, f512, .act (.dir .right), f513, .ok⟩,
  ⟨3403, 5, 5, 10, f513, .act (.dir .right), f514, .ok⟩,
  ⟨3404, 5, 5, 10, f514, .act (.dir .right), f515, .ok⟩,
  ⟨3405, 5, 5, 10, f515, .act (.dir .right), f516, .ok⟩,
  ⟨3406, 5, 5, 10, f516, .act (.dir .right), f517, .ok⟩,
  ⟨3407, 5, 5, 10, f517, .act (.dir .down), f518, .ok⟩,
  ⟨3408, 5, 5, 10, f518, .act (.dir .up), f519, .ok⟩,
  ⟨3409, 5, 5, 10, f519, .act (.dir .up), f520, .ok⟩,
  ⟨3410, 5, 5, 10, f520, .act (.dir .down), f521, .ok⟩,
  ⟨3411, 5, 5, 10, f521, .act (.dir .down), f522, .ok⟩,
  ⟨3412, 5, 5, 10, f522, .act (.dir .down), f523, .ok⟩,
  ⟨3413, 5, 5, 10, f523, .act (.dir .right), f524, .ok⟩,
  ⟨3414, 5, 5, 10, f524, .act (.dir .right), f525, .ok⟩,
  ⟨3415, 5, 5, 10, f525, .act (.dir .up), f526, .ok⟩,
  ⟨3416, 5, 5, 10, f526, .act (.dir .right), f527, .ok⟩,
  ⟨3417, 5, 5, 10, f527, .act (.dir .right), f528, .ok⟩,
  ⟨3418, 5, 5, 10, f528, .act (.dir .right), f529, .ok⟩,
  ⟨3419, 5, 5, 10, f529, .act (.dir .right), f530, .ok⟩,
  ⟨3420, 5, 5, 10, f530, .act (.dir .right), f531, .ok⟩,
  ⟨3421, 5, 5, 10, f531, .act (.dir .right), f532, .ok⟩,
  ⟨3422, 5, 5, 10, f532, .act (.dir .right), f533, .ok⟩,
  ⟨3423, 5, 5, 10, f533, .act (.dir .up), f534, .ok⟩,
  ⟨3424, 5, 6, 10, f534, .act (.dir .up), f535, .levelup⟩,
  ⟨3425, 6, 6, 10, f535, .act (.dir .up), f757, .ok⟩,
  ⟨3426, 6, 6, 10, f757, .act (.dir .down), f758, .ok⟩,
  ⟨3427, 6, 6, 10, f758, .act (.dir .left), f759, .ok⟩,
  ⟨3428, 6, 6, 10, f759, .act (.dir .right), f760, .ok⟩,
  ⟨3429, 6, 6, 10, f760, .act (.dir .up), f761, .ok⟩,
  ⟨3430, 6, 6, 10, f761, .act (.dir .up), f762, .ok⟩,
  ⟨3431, 6, 6, 10, f762, .act (.dir .up), f763, .ok⟩,
  ⟨3432, 6, 6, 10, f763, .act (.dir .up), f764, .ok⟩,
  ⟨3433, 6, 6, 10, f764, .act (.dir .down), f765, .ok⟩,
  ⟨3434, 6, 6, 10, f765, .act (.dir .down), f766, .ok⟩,
  ⟨3435, 6, 6, 10, f766, .act (.dir .down), f767, .ok⟩,
  ⟨3436, 6, 6, 10, f767, .act (.dir .down), f768, .ok⟩,
  ⟨3437, 6, 6, 10, f768, .act (.dir .left), f769, .ok⟩,
  ⟨3438, 6, 6, 10, f769, .act (.dir .left), f770, .ok⟩,
  ⟨3439, 6, 6, 10, f770, .act (.dir .left), f771, .ok⟩,
  ⟨3440, 6, 6, 10, f771, .act (.dir .left), f772, .ok⟩,
  ⟨3441, 6, 6, 10, f772, .act (.dir .right), f773, .ok⟩,
  ⟨3442, 6, 6, 10, f773, .act (.dir .right), f774, .ok⟩,
  ⟨3443, 6, 6, 10, f774, .act (.dir .right), f775, .ok⟩,
  ⟨3444, 6, 6, 10, f775, .act (.dir .right), f776, .ok⟩,
  ⟨3445, 6, 6, 10, f776, .act (.dir .up), f777, .ok⟩,
  ⟨3446, 6, 6, 10, f777, .act (.dir .up), f778, .ok⟩,
  ⟨3447, 6, 6, 10, f778, .act (.dir .down), f779, .ok⟩,
  ⟨3448, 6, 6, 10, f779, .act (.dir .down), f780, .ok⟩,
  ⟨3449, 6, 6, 10, f780, .act (.dir .left), f781, .ok⟩,
  ⟨3450, 6, 6, 10, f781, .act (.dir .left), f782, .ok⟩,
  ⟨3451, 6, 6, 10, f782, .act (.dir .right), f783, .ok⟩,
  ⟨3452, 6, 6, 10, f783, .act (.dir .right), f784, .ok⟩,
  ⟨3453, 6, 6, 10, f784, .act (.dir .up), f785, .ok⟩,
  ⟨3454, 6, 6, 10, f785, .act (.dir .down), f786, .ok⟩,
  ⟨3455, 6, 6, 10, f786, .act (.dir .left), f787, .ok⟩,
  ⟨3456, 6, 6, 10, f787, .act (.dir .right), f788, .ok⟩,
  ⟨3457, 6, 6, 10, f788, .act (.dir .up), f789, .ok⟩,
  ⟨3458, 6, 6, 10, f789, .act (.dir .down), f790, .ok⟩,
  ⟨3459, 6, 6, 10, f790, .act (.dir .left), f791, .ok⟩,
  ⟨3460, 6, 6, 10, f791, .act (.dir .right), f792, .ok⟩,
  ⟨3461, 6, 6, 10, f792, .act (.dir .up), f793, .ok⟩,
  ⟨3462, 6, 6, 10, f793, .act (.dir .down), f794, .ok⟩,
  ⟨3463, 6, 6, 10, f794, .act (.dir .left), f795, .ok⟩,
  ⟨3464, 6, 6, 10, f795, .act (.dir .right), f796, .ok⟩,
  ⟨3465, 6, 6, 10, f796, .act (.dir .up), f797, .ok⟩,
  ⟨3466, 6, 6, 10, f797, .act (.dir .down), f798, .ok⟩,
  ⟨3467, 6, 6, 10, f798, .act (.dir .left), f799, .ok⟩,
  ⟨3468, 6, 6, 10, f799, .act (.dir .right), f800, .ok⟩,
  ⟨3469, 6, 6, 10, f800, .act (.dir .up), f801, .ok⟩,
  ⟨3470, 6, 6, 10, f801, .act (.dir .down), f802, .ok⟩,
  ⟨3471, 6, 6, 10, f802, .act (.dir .left), f803, .ok⟩,
  ⟨3472, 6, 6, 10, f803, .act (.dir .right), f804, .ok⟩,
  ⟨3473, 6, 6, 10, f804, .act (.dir .up), f805, .ok⟩,
  ⟨3474, 6, 6, 10, f805, .act (.dir .down), f806, .ok⟩,
  ⟨3475, 6, 6, 10, f806, .act (.dir .left), f807, .ok⟩,
  ⟨3476, 6, 6, 10, f807, .act (.dir .right), f808, .ok⟩,
  ⟨3477, 6, 6, 10, f808, .act (.click 52 35), f808, .ok⟩,
  ⟨3478, 6, 6, 10, f808, .act (.click 52 36), f808, .ok⟩,
  ⟨3479, 6, 6, 10, f808, .act (.click 13 13), f809, .ok⟩,
  ⟨3480, 6, 6, 10, f809, .act (.click 10 47), f809, .ok⟩,
  ⟨3481, 6, 6, 10, f809, .act (.click 48 44), f809, .ok⟩,
  ⟨3482, 6, 6, 10, f809, .act (.dir .up), f810, .ok⟩,
  ⟨3483, 6, 6, 10, f810, .act (.dir .down), f811, .ok⟩,
  ⟨3484, 6, 6, 10, f811, .act (.dir .left), f812, .ok⟩,
  ⟨3485, 6, 6, 10, f812, .act (.dir .right), f813, .ok⟩,
  ⟨3486, 6, 6, 10, f813, .act (.dir .up), f814, .ok⟩,
  ⟨3487, 6, 6, 10, f814, .act (.dir .down), f815, .ok⟩,
  ⟨3488, 6, 6, 10, f815, .act (.dir .left), f816, .ok⟩,
  ⟨3489, 6, 6, 10, f816, .act (.dir .right), f817, .ok⟩,
  ⟨3490, 6, 6, 10, f817, .act (.dir .up), f818, .ok⟩,
  ⟨3491, 6, 6, 10, f818, .act (.dir .down), f819, .ok⟩,
  ⟨3492, 6, 6, 10, f819, .act (.dir .left), f820, .ok⟩,
  ⟨3493, 6, 6, 10, f820, .act (.dir .right), f821, .ok⟩,
  ⟨3494, 6, 6, 10, f821, .act (.dir .up), f822, .ok⟩,
  ⟨3495, 6, 6, 10, f822, .act (.dir .down), f823, .ok⟩,
  ⟨3496, 6, 6, 10, f823, .act (.dir .left), f824, .ok⟩,
  ⟨3497, 6, 6, 10, f824, .act (.dir .right), f825, .ok⟩,
  ⟨3498, 6, 6, 10, f825, .act (.dir .up), f826, .ok⟩,
  ⟨3499, 6, 6, 10, f826, .act (.dir .down), f827, .ok⟩]

def rows14 : List Row := [
  ⟨3500, 6, 6, 10, f827, .act (.dir .left), f828, .ok⟩,
  ⟨3501, 6, 6, 10, f828, .act (.dir .right), f829, .ok⟩,
  ⟨3502, 6, 6, 10, f829, .act (.dir .up), f830, .ok⟩,
  ⟨3503, 6, 6, 10, f830, .act (.dir .down), f831, .ok⟩,
  ⟨3504, 6, 6, 10, f831, .act (.dir .left), f832, .ok⟩,
  ⟨3505, 6, 6, 10, f832, .act (.dir .right), f833, .ok⟩,
  ⟨3506, 6, 6, 10, f833, .act (.dir .up), f834, .ok⟩,
  ⟨3507, 6, 6, 10, f834, .act (.dir .down), f835, .ok⟩,
  ⟨3508, 6, 6, 10, f835, .act (.dir .left), f836, .ok⟩,
  ⟨3509, 6, 6, 10, f836, .act (.dir .right), f837, .ok⟩,
  ⟨3510, 6, 6, 10, f837, .act (.dir .up), f838, .ok⟩,
  ⟨3511, 6, 6, 10, f838, .act (.dir .down), f839, .ok⟩,
  ⟨3512, 6, 6, 10, f839, .act (.dir .left), f840, .ok⟩,
  ⟨3513, 6, 6, 10, f840, .act (.dir .right), f841, .ok⟩,
  ⟨3514, 6, 6, 10, f841, .act (.dir .up), f842, .ok⟩,
  ⟨3515, 6, 6, 10, f842, .act (.dir .down), f843, .ok⟩,
  ⟨3516, 6, 6, 10, f843, .act (.dir .left), f844, .ok⟩,
  ⟨3517, 6, 6, 10, f844, .act (.dir .right), f845, .ok⟩,
  ⟨3518, 6, 6, 10, f845, .act (.dir .up), f846, .ok⟩,
  ⟨3519, 6, 6, 10, f846, .act (.dir .down), f847, .ok⟩,
  ⟨3520, 6, 6, 10, f847, .act (.dir .left), f848, .ok⟩,
  ⟨3521, 6, 6, 10, f848, .act (.dir .right), f849, .ok⟩,
  ⟨3522, 6, 6, 10, f849, .act (.dir .up), f850, .ok⟩,
  ⟨3523, 6, 6, 10, f850, .act (.dir .down), f851, .ok⟩,
  ⟨3524, 6, 6, 10, f851, .act (.dir .left), f852, .ok⟩,
  ⟨3525, 6, 6, 10, f852, .act (.dir .right), f853, .ok⟩,
  ⟨3526, 6, 6, 10, f853, .act (.dir .up), f854, .ok⟩,
  ⟨3527, 6, 6, 10, f854, .act (.dir .down), f855, .ok⟩,
  ⟨3528, 6, 6, 10, f855, .act (.dir .left), f856, .ok⟩,
  ⟨3529, 6, 6, 10, f856, .act (.dir .right), f857, .ok⟩,
  ⟨3530, 6, 6, 10, f857, .reset, f535, .reset⟩,
  ⟨3531, 6, 6, 10, f535, .act (.dir .down), f858, .ok⟩,
  ⟨3532, 6, 6, 10, f858, .act (.dir .up), f758, .ok⟩,
  ⟨3533, 6, 6, 10, f758, .act (.dir .left), f759, .ok⟩,
  ⟨3534, 6, 6, 10, f759, .act (.dir .right), f760, .ok⟩,
  ⟨3535, 6, 6, 10, f760, .act (.dir .up), f761, .ok⟩,
  ⟨3536, 6, 6, 10, f761, .act (.dir .up), f762, .ok⟩,
  ⟨3537, 6, 6, 10, f762, .act (.dir .up), f763, .ok⟩,
  ⟨3538, 6, 6, 10, f763, .act (.dir .up), f764, .ok⟩,
  ⟨3539, 6, 6, 10, f764, .act (.dir .left), f859, .ok⟩,
  ⟨3540, 6, 6, 10, f859, .act (.dir .left), f860, .ok⟩,
  ⟨3541, 6, 6, 10, f860, .act (.dir .left), f861, .ok⟩,
  ⟨3542, 6, 6, 10, f861, .act (.dir .left), f862, .ok⟩,
  ⟨3543, 6, 6, 10, f862, .act (.dir .left), f863, .ok⟩,
  ⟨3544, 6, 6, 10, f863, .act (.dir .left), f864, .ok⟩,
  ⟨3545, 6, 6, 10, f864, .act (.dir .left), f865, .ok⟩,
  ⟨3546, 6, 6, 10, f865, .act (.dir .up), f866, .ok⟩,
  ⟨3547, 6, 6, 10, f866, .act (.dir .up), f867, .ok⟩,
  ⟨3548, 6, 6, 10, f867, .act (.dir .up), f868, .ok⟩,
  ⟨3549, 6, 6, 10, f868, .act (.dir .up), f869, .ok⟩,
  ⟨3550, 6, 6, 10, f869, .act (.dir .up), f870, .ok⟩,
  ⟨3551, 6, 6, 10, f870, .act (.dir .up), f871, .ok⟩,
  ⟨3552, 6, 6, 10, f871, .act (.click 35 52), f872, .ok⟩,
  ⟨3553, 6, 6, 10, f872, .act (.dir .up), f873, .ok⟩,
  ⟨3554, 6, 6, 10, f873, .act (.dir .up), f874, .ok⟩,
  ⟨3555, 6, 6, 10, f874, .act (.dir .right), f875, .ok⟩,
  ⟨3556, 6, 6, 10, f875, .act (.dir .right), f876, .ok⟩,
  ⟨3557, 6, 6, 10, f876, .act (.dir .right), f877, .ok⟩,
  ⟨3558, 6, 6, 10, f877, .act (.dir .left), f878, .ok⟩,
  ⟨3559, 6, 6, 10, f878, .act (.dir .right), f879, .ok⟩,
  ⟨3560, 6, 6, 10, f879, .act (.dir .left), f880, .ok⟩,
  ⟨3561, 6, 6, 10, f880, .act (.dir .right), f881, .ok⟩,
  ⟨3562, 6, 6, 10, f881, .act (.dir .up), f882, .ok⟩,
  ⟨3563, 6, 6, 10, f882, .act (.dir .up), f883, .ok⟩,
  ⟨3564, 6, 6, 10, f883, .act (.dir .right), f884, .ok⟩,
  ⟨3565, 6, 6, 10, f884, .act (.dir .right), f885, .ok⟩,
  ⟨3566, 6, 6, 10, f885, .act (.dir .right), f886, .ok⟩,
  ⟨3567, 6, 6, 10, f886, .act (.dir .up), f887, .ok⟩,
  ⟨3568, 6, 6, 10, f887, .act (.dir .up), f888, .ok⟩,
  ⟨3569, 6, 6, 10, f888, .act (.dir .up), f889, .ok⟩,
  ⟨3570, 6, 6, 10, f889, .act (.dir .up), f890, .ok⟩,
  ⟨3571, 6, 6, 10, f890, .act (.dir .up), f891, .ok⟩,
  ⟨3572, 6, 6, 10, f891, .act (.dir .up), f892, .ok⟩,
  ⟨3573, 6, 6, 10, f892, .act (.dir .up), f893, .ok⟩,
  ⟨3574, 6, 6, 10, f893, .act (.dir .left), f894, .ok⟩,
  ⟨3575, 6, 6, 10, f894, .act (.click 34 14), f895, .ok⟩,
  ⟨3576, 6, 6, 10, f895, .act (.dir .right), f896, .ok⟩,
  ⟨3577, 6, 6, 10, f896, .act (.dir .up), f897, .ok⟩,
  ⟨3578, 6, 6, 10, f897, .act (.dir .up), f898, .ok⟩,
  ⟨3579, 6, 6, 10, f898, .act (.dir .left), f899, .ok⟩,
  ⟨3580, 6, 6, 10, f899, .act (.dir .left), f900, .ok⟩,
  ⟨3581, 6, 6, 10, f900, .act (.dir .down), f901, .ok⟩,
  ⟨3582, 6, 6, 10, f901, .act (.dir .down), f902, .ok⟩,
  ⟨3583, 6, 6, 10, f902, .act (.dir .down), f903, .ok⟩,
  ⟨3584, 6, 6, 10, f903, .act (.dir .down), f904, .ok⟩,
  ⟨3585, 6, 6, 10, f904, .act (.dir .down), f905, .ok⟩,
  ⟨3586, 6, 6, 10, f905, .act (.dir .down), f906, .ok⟩,
  ⟨3587, 6, 6, 10, f906, .act (.click 13 25), f906, .ok⟩,
  ⟨3588, 6, 6, 10, f906, .act (.dir .down), f907, .ok⟩,
  ⟨3589, 6, 6, 10, f907, .act (.dir .down), f908, .ok⟩,
  ⟨3590, 6, 6, 10, f908, .act (.dir .down), f909, .ok⟩,
  ⟨3591, 6, 6, 10, f909, .act (.click 53 7), f910, .ok⟩,
  ⟨3592, 6, 6, 10, f910, .act (.dir .down), f911, .ok⟩,
  ⟨3593, 6, 6, 10, f911, .act (.dir .down), f912, .ok⟩,
  ⟨3594, 6, 6, 10, f912, .act (.dir .down), f913, .ok⟩,
  ⟨3595, 6, 6, 10, f913, .act (.dir .down), f914, .ok⟩,
  ⟨3596, 6, 6, 10, f914, .act (.dir .down), f915, .ok⟩,
  ⟨3597, 6, 6, 10, f915, .act (.dir .down), f916, .ok⟩,
  ⟨3598, 6, 6, 10, f916, .act (.dir .down), f917, .ok⟩,
  ⟨3599, 6, 6, 10, f917, .act (.dir .left), f918, .ok⟩,
  ⟨3600, 6, 6, 10, f918, .act (.dir .left), f919, .ok⟩,
  ⟨3601, 6, 6, 10, f919, .act (.dir .left), f920, .ok⟩,
  ⟨3602, 6, 6, 10, f920, .act (.dir .left), f921, .ok⟩,
  ⟨3603, 6, 6, 10, f921, .act (.dir .left), f922, .ok⟩,
  ⟨3604, 6, 6, 10, f922, .act (.dir .left), f923, .ok⟩,
  ⟨3605, 6, 6, 10, f923, .act (.dir .down), f924, .ok⟩,
  ⟨3606, 6, 6, 10, f924, .act (.click 34 47), f925, .ok⟩,
  ⟨3607, 6, 6, 10, f925, .act (.dir .left), f926, .ok⟩,
  ⟨3608, 6, 6, 10, f926, .act (.dir .left), f927, .ok⟩,
  ⟨3609, 6, 6, 10, f927, .act (.click 35 28), f928, .ok⟩,
  ⟨3610, 6, 6, 10, f928, .act (.dir .down), f929, .ok⟩,
  ⟨3611, 6, 6, 10, f929, .act (.dir .left), f930, .ok⟩,
  ⟨3612, 6, 6, 10, f930, .act (.dir .left), f931, .ok⟩,
  ⟨3613, 6, 6, 10, f931, .act (.dir .left), f932, .ok⟩,
  ⟨3614, 6, 6, 10, f932, .act (.dir .left), f933, .ok⟩,
  ⟨3615, 6, 6, 10, f933, .act (.dir .left), f934, .ok⟩,
  ⟨3616, 6, 6, 10, f934, .act (.dir .left), f935, .ok⟩,
  ⟨3617, 6, 6, 10, f935, .act (.dir .left), f936, .ok⟩,
  ⟨3618, 6, 6, 10, f936, .act (.dir .left), f937, .ok⟩,
  ⟨3619, 6, 6, 10, f937, .act (.dir .left), f938, .ok⟩,
  ⟨3620, 6, 6, 10, f938, .act (.dir .left), f939, .ok⟩,
  ⟨3621, 6, 6, 10, f939, .act (.dir .left), f940, .ok⟩,
  ⟨3622, 6, 6, 10, f940, .act (.dir .up), f941, .ok⟩,
  ⟨3623, 6, 6, 10, f941, .act (.dir .up), f942, .ok⟩,
  ⟨3624, 6, 6, 10, f942, .act (.dir .up), f943, .ok⟩,
  ⟨3625, 6, 6, 10, f943, .act (.dir .right), f944, .ok⟩,
  ⟨3626, 6, 6, 10, f944, .act (.dir .right), f945, .ok⟩,
  ⟨3627, 6, 6, 10, f945, .act (.dir .down), f946, .ok⟩,
  ⟨3628, 6, 6, 10, f946, .act (.dir .down), f947, .ok⟩,
  ⟨3629, 6, 6, 10, f947, .act (.dir .down), f948, .ok⟩,
  ⟨3630, 6, 6, 10, f948, .act (.dir .down), f949, .ok⟩,
  ⟨3631, 6, 6, 10, f949, .act (.dir .right), f950, .ok⟩,
  ⟨3632, 6, 6, 10, f950, .act (.dir .right), f951, .ok⟩,
  ⟨3633, 6, 6, 10, f951, .act (.dir .right), f952, .ok⟩,
  ⟨3634, 6, 6, 10, f952, .act (.dir .right), f953, .ok⟩,
  ⟨3635, 6, 6, 10, f953, .act (.dir .right), f954, .ok⟩,
  ⟨3636, 6, 6, 10, f954, .act (.dir .right), f955, .ok⟩,
  ⟨3637, 6, 6, 10, f955, .act (.dir .up), f956, .ok⟩,
  ⟨3638, 6, 7, 10, f956, .act (.dir .up), f957, .levelup⟩,
  ⟨3639, 7, 0, 11, f957, .reset, f0, .reset⟩,
  ⟨3640, 0, 0, 11, f0, .act (.click 28 31), f958, .ok⟩,
  ⟨3641, 0, 0, 11, f958, .act (.dir .left), f959, .ok⟩,
  ⟨3642, 0, 0, 11, f959, .act (.dir .left), f960, .ok⟩,
  ⟨3643, 0, 0, 11, f960, .act (.dir .up), f961, .ok⟩,
  ⟨3644, 0, 0, 11, f961, .act (.dir .left), f962, .ok⟩,
  ⟨3645, 0, 0, 11, f962, .act (.dir .left), f963, .ok⟩,
  ⟨3646, 0, 0, 11, f963, .act (.dir .down), f964, .ok⟩,
  ⟨3647, 0, 0, 11, f964, .act (.dir .right), f965, .ok⟩,
  ⟨3648, 0, 0, 11, f965, .act (.click 40 31), f966, .ok⟩,
  ⟨3649, 0, 0, 11, f966, .act (.dir .up), f967, .ok⟩,
  ⟨3650, 0, 0, 11, f967, .act (.dir .right), f968, .ok⟩,
  ⟨3651, 0, 0, 11, f968, .act (.dir .right), f969, .ok⟩,
  ⟨3652, 0, 0, 11, f969, .act (.click 16 31), f970, .ok⟩,
  ⟨3653, 0, 0, 11, f970, .act (.dir .down), f971, .ok⟩,
  ⟨3654, 0, 1, 11, f971, .act (.dir .left), f82, .levelup⟩,
  ⟨3655, 1, 1, 11, f82, .act (.click 41 34), f140, .ok⟩,
  ⟨3656, 1, 1, 11, f140, .act (.dir .down), f972, .ok⟩,
  ⟨3657, 1, 1, 11, f972, .act (.dir .down), f973, .ok⟩,
  ⟨3658, 1, 1, 11, f973, .act (.dir .right), f974, .ok⟩,
  ⟨3659, 1, 1, 11, f974, .act (.dir .right), f975, .ok⟩,
  ⟨3660, 1, 1, 11, f975, .act (.dir .right), f976, .ok⟩,
  ⟨3661, 1, 1, 11, f976, .act (.dir .right), f977, .ok⟩,
  ⟨3662, 1, 1, 11, f977, .act (.dir .right), f978, .ok⟩,
  ⟨3663, 1, 1, 11, f978, .act (.click 37 55), f979, .ok⟩,
  ⟨3664, 1, 1, 11, f979, .act (.dir .up), f980, .ok⟩,
  ⟨3665, 1, 1, 11, f980, .act (.dir .right), f981, .ok⟩,
  ⟨3666, 1, 1, 11, f981, .act (.dir .right), f982, .ok⟩,
  ⟨3667, 1, 1, 11, f982, .act (.dir .right), f983, .ok⟩,
  ⟨3668, 1, 1, 11, f983, .act (.dir .right), f984, .ok⟩,
  ⟨3669, 1, 1, 11, f984, .act (.dir .right), f985, .ok⟩,
  ⟨3670, 1, 1, 11, f985, .act (.click 44 47), f986, .ok⟩,
  ⟨3671, 1, 1, 11, f986, .act (.dir .down), f987, .ok⟩,
  ⟨3672, 1, 1, 11, f987, .act (.dir .left), f988, .ok⟩,
  ⟨3673, 1, 1, 11, f988, .act (.dir .left), f989, .ok⟩,
  ⟨3674, 1, 1, 11, f989, .act (.dir .left), f990, .ok⟩,
  ⟨3675, 1, 1, 11, f990, .act (.dir .left), f991, .ok⟩,
  ⟨3676, 1, 1, 11, f991, .act (.dir .up), f992, .ok⟩,
  ⟨3677, 1, 1, 11, f992, .act (.dir .up), f993, .ok⟩,
  ⟨3678, 1, 1, 11, f993, .act (.dir .up), f994, .ok⟩,
  ⟨3679, 1, 1, 11, f994, .act (.dir .up), f995, .ok⟩,
  ⟨3680, 1, 1, 11, f995, .act (.dir .up), f996, .ok⟩,
  ⟨3681, 1, 1, 11, f996, .act (.dir .up), f997, .ok⟩,
  ⟨3682, 1, 1, 11, f997, .act (.click 34 32), f998, .ok⟩,
  ⟨3683, 1, 1, 11, f998, .act (.dir .right), f999, .ok⟩,
  ⟨3684, 1, 1, 11, f999, .act (.dir .down), f1000, .ok⟩,
  ⟨3685, 1, 1, 11, f1000, .act (.dir .left), f1001, .ok⟩,
  ⟨3686, 1, 1, 11, f1001, .act (.click 17 38), f1002, .ok⟩,
  ⟨3687, 1, 1, 11, f1002, .act (.dir .down), f1003, .ok⟩,
  ⟨3688, 1, 1, 11, f1003, .act (.dir .down), f1004, .ok⟩,
  ⟨3689, 1, 1, 11, f1004, .act (.dir .left), f1005, .ok⟩,
  ⟨3690, 1, 1, 11, f1005, .act (.dir .left), f1006, .ok⟩,
  ⟨3691, 1, 1, 11, f1006, .act (.dir .left), f1007, .ok⟩,
  ⟨3692, 1, 1, 11, f1007, .act (.click 56 40), f1008, .ok⟩,
  ⟨3693, 1, 1, 11, f1008, .act (.dir .up), f1009, .ok⟩,
  ⟨3694, 1, 1, 11, f1009, .act (.dir .left), f1010, .ok⟩,
  ⟨3695, 1, 1, 11, f1010, .act (.dir .left), f1011, .ok⟩,
  ⟨3696, 1, 1, 11, f1011, .act (.dir .left), f1012, .ok⟩,
  ⟨3697, 1, 1, 11, f1012, .act (.dir .left), f1013, .ok⟩,
  ⟨3698, 1, 1, 11, f1013, .act (.dir .left), f1014, .ok⟩,
  ⟨3699, 1, 1, 11, f1014, .act (.dir .left), f1015, .ok⟩,
  ⟨3700, 1, 1, 11, f1015, .act (.click 8 44), f1016, .ok⟩,
  ⟨3701, 1, 1, 11, f1016, .act (.dir .up), f1017, .ok⟩,
  ⟨3702, 1, 1, 11, f1017, .act (.dir .right), f1018, .ok⟩,
  ⟨3703, 1, 1, 11, f1018, .act (.dir .right), f1019, .ok⟩,
  ⟨3704, 1, 1, 11, f1019, .act (.dir .right), f1020, .ok⟩,
  ⟨3705, 1, 1, 11, f1020, .act (.dir .up), f1021, .ok⟩,
  ⟨3706, 1, 1, 11, f1021, .act (.click 19 20), f1022, .ok⟩,
  ⟨3707, 1, 1, 11, f1022, .act (.dir .up), f1023, .ok⟩,
  ⟨3708, 1, 1, 11, f1023, .act (.dir .up), f1024, .ok⟩,
  ⟨3709, 1, 1, 11, f1024, .act (.dir .up), f1025, .ok⟩,
  ⟨3710, 1, 1, 11, f1025, .act (.dir .left), f1026, .ok⟩,
  ⟨3711, 1, 1, 11, f1026, .act (.dir .left), f1027, .ok⟩,
  ⟨3712, 1, 1, 11, f1027, .act (.dir .left), f1028, .ok⟩,
  ⟨3713, 1, 1, 11, f1028, .act (.click 17 41), f1029, .ok⟩,
  ⟨3714, 1, 1, 11, f1029, .act (.dir .down), f1030, .ok⟩,
  ⟨3715, 1, 1, 11, f1030, .act (.click 41 37), f1031, .ok⟩,
  ⟨3716, 1, 1, 11, f1031, .act (.dir .down), f1032, .ok⟩,
  ⟨3717, 1, 1, 11, f1032, .act (.dir .right), f1033, .ok⟩,
  ⟨3718, 1, 1, 11, f1033, .act (.dir .right), f1034, .ok⟩,
  ⟨3719, 1, 1, 11, f1034, .act (.dir .right), f1035, .ok⟩,
  ⟨3720, 1, 1, 11, f1035, .act (.dir .right), f1036, .ok⟩,
  ⟨3721, 1, 1, 11, f1036, .act (.dir .right), f1037, .ok⟩,
  ⟨3722, 1, 1, 11, f1037, .act (.click 17 44), f1038, .ok⟩,
  ⟨3723, 1, 1, 11, f1038, .act (.dir .left), f1039, .ok⟩,
  ⟨3724, 1, 1, 11, f1039, .act (.dir .left), f1040, .ok⟩,
  ⟨3725, 1, 2, 11, f1040, .act (.dir .left), f384, .levelup⟩,
  ⟨3726, 2, 2, 11, f384, .act (.dir .down), f385, .ok⟩,
  ⟨3727, 2, 2, 11, f385, .act (.dir .down), f386, .ok⟩,
  ⟨3728, 2, 2, 11, f386, .act (.dir .down), f387, .ok⟩,
  ⟨3729, 2, 2, 11, f387, .act (.dir .down), f388, .ok⟩,
  ⟨3730, 2, 2, 11, f388, .act (.dir .down), f389, .ok⟩,
  ⟨3731, 2, 2, 11, f389, .act (.dir .down), f1041, .ok⟩,
  ⟨3732, 2, 2, 11, f1041, .act (.dir .down), f1042, .ok⟩,
  ⟨3733, 2, 2, 11, f1042, .act (.dir .down), f1043, .ok⟩,
  ⟨3734, 2, 2, 11, f1043, .act (.dir .down), f1044, .ok⟩,
  ⟨3735, 2, 2, 11, f1044, .act (.dir .left), f1045, .ok⟩,
  ⟨3736, 2, 2, 11, f1045, .act (.dir .left), f1046, .ok⟩,
  ⟨3737, 2, 2, 11, f1046, .act (.dir .left), f1047, .ok⟩,
  ⟨3738, 2, 2, 11, f1047, .act (.dir .left), f1048, .ok⟩,
  ⟨3739, 2, 2, 11, f1048, .act (.dir .left), f1049, .ok⟩,
  ⟨3740, 2, 2, 11, f1049, .act (.dir .left), f1050, .ok⟩,
  ⟨3741, 2, 2, 11, f1050, .act (.dir .up), f1051, .ok⟩,
  ⟨3742, 2, 2, 11, f1051, .act (.dir .up), f1052, .ok⟩,
  ⟨3743, 2, 2, 11, f1052, .act (.dir .up), f1053, .ok⟩,
  ⟨3744, 2, 2, 11, f1053, .act (.dir .up), f1054, .ok⟩,
  ⟨3745, 2, 2, 11, f1054, .act (.dir .up), f1055, .ok⟩,
  ⟨3746, 2, 2, 11, f1055, .act (.dir .right), f1056, .ok⟩,
  ⟨3747, 2, 2, 11, f1056, .act (.dir .right), f1057, .ok⟩,
  ⟨3748, 2, 2, 11, f1057, .act (.dir .right), f1058, .ok⟩,
  ⟨3749, 2, 2, 11, f1058, .act (.dir .right), f1059, .ok⟩]

def rows15 : List Row := [
  ⟨3750, 2, 2, 11, f1059, .act (.dir .right), f1060, .ok⟩,
  ⟨3751, 2, 2, 11, f1060, .act (.dir .right), f1061, .ok⟩,
  ⟨3752, 2, 2, 11, f1061, .act (.dir .right), f1062, .ok⟩,
  ⟨3753, 2, 2, 11, f1062, .act (.dir .right), f1063, .ok⟩,
  ⟨3754, 2, 2, 11, f1063, .act (.dir .right), f1064, .ok⟩,
  ⟨3755, 2, 2, 11, f1064, .act (.dir .right), f1065, .ok⟩,
  ⟨3756, 2, 2, 11, f1065, .act (.dir .up), f1066, .ok⟩,
  ⟨3757, 2, 2, 11, f1066, .act (.dir .left), f1067, .ok⟩,
  ⟨3758, 2, 2, 11, f1067, .act (.dir .up), f1068, .ok⟩,
  ⟨3759, 2, 2, 11, f1068, .act (.dir .up), f1069, .ok⟩,
  ⟨3760, 2, 2, 11, f1069, .act (.dir .up), f1070, .ok⟩,
  ⟨3761, 2, 2, 11, f1070, .act (.dir .left), f1071, .ok⟩,
  ⟨3762, 2, 2, 11, f1071, .act (.dir .left), f1072, .ok⟩,
  ⟨3763, 2, 2, 11, f1072, .act (.dir .left), f1073, .ok⟩,
  ⟨3764, 2, 2, 11, f1073, .act (.dir .left), f1074, .ok⟩,
  ⟨3765, 2, 2, 11, f1074, .act (.dir .left), f1075, .ok⟩,
  ⟨3766, 2, 2, 11, f1075, .act (.dir .left), f1076, .ok⟩,
  ⟨3767, 2, 2, 11, f1076, .act (.dir .left), f1077, .ok⟩,
  ⟨3768, 2, 2, 11, f1077, .act (.dir .down), f1078, .ok⟩,
  ⟨3769, 2, 2, 11, f1078, .act (.dir .down), f1079, .ok⟩,
  ⟨3770, 2, 2, 11, f1079, .act (.dir .down), f1080, .ok⟩,
  ⟨3771, 2, 2, 11, f1080, .act (.dir .down), f1081, .ok⟩,
  ⟨3772, 2, 3, 11, f1081, .act (.dir .down), f425, .levelup⟩,
  ⟨3773, 3, 3, 11, f425, .act (.dir .down), f1082, .ok⟩,
  ⟨3774, 3, 3, 11, f1082, .act (.dir .right), f1083, .ok⟩,
  ⟨3775, 3, 3, 11, f1083, .act (.dir .right), f1084, .ok⟩,
  ⟨3776, 3, 3, 11, f1084, .act (.dir .right), f1085, .ok⟩,
  ⟨3777, 3, 3, 11, f1085, .act (.dir .right), f1086, .ok⟩,
  ⟨3778, 3, 3, 11, f1086, .act (.dir .right), f1087, .ok⟩,
  ⟨3779, 3, 3, 11, f1087, .act (.dir .right), f1088, .ok⟩,
  ⟨3780, 3, 3, 11, f1088, .act (.dir .right), f1089, .ok⟩,
  ⟨3781, 3, 3, 11, f1089, .act (.dir .right), f1090, .ok⟩,
  ⟨3782, 3, 3, 11, f1090, .act (.dir .right), f1091, .ok⟩,
  ⟨3783, 3, 3, 11, f1091, .act (.click 57 33), f1092, .ok⟩,
  ⟨3784, 3, 3, 11, f1092, .act (.dir .up), f1093, .ok⟩,
  ⟨3785, 3, 3, 11, f1093, .act (.dir .left), f1094, .ok⟩,
  ⟨3786, 3, 3, 11, f1094, .act (.dir .left), f1095, .ok⟩,
  ⟨3787, 3, 3, 11, f1095, .act (.dir .left), f1096, .ok⟩,
  ⟨3788, 3, 3, 11, f1096, .act (.dir .left), f1097, .ok⟩,
  ⟨3789, 3, 3, 11, f1097, .act (.dir .left), f1098, .ok⟩,
  ⟨3790, 3, 3, 11, f1098, .act (.dir .down), f1099, .ok⟩,
  ⟨3791, 3, 3, 11, f1099, .act (.dir .right), f1100, .ok⟩,
  ⟨3792, 3, 3, 11, f1100, .act (.dir .right), f1101, .ok⟩,
  ⟨3793, 3, 3, 11, f1101, .act (.dir .right), f1102, .ok⟩,
  ⟨3794, 3, 3, 11, f1102, .act (.click 42 48), f1103, .ok⟩,
  ⟨3795, 3, 3, 11, f1103, .act (.dir .left), f1104, .ok⟩,
  ⟨3796, 3, 3, 11, f1104, .act (.dir .left), f1105, .ok⟩,
  ⟨3797, 3, 3, 11, f1105, .act (.dir .left), f1106, .ok⟩,
  ⟨3798, 3, 3, 11, f1106, .act (.dir .left), f1107, .ok⟩,
  ⟨3799, 3, 3, 11, f1107, .act (.dir .left), f1108, .ok⟩,
  ⟨3800, 3, 3, 11, f1108, .act (.dir .left), f1109, .ok⟩,
  ⟨3801, 3, 3, 11, f1109, .act (.dir .left), f1110, .ok⟩,
  ⟨3802, 3, 3, 11, f1110, .act (.dir .down), f1111, .ok⟩,
  ⟨3803, 3, 3, 11, f1111, .act (.dir .right), f1112, .ok⟩,
  ⟨3804, 3, 3, 11, f1112, .act (.dir .down), f1113, .ok⟩,
  ⟨3805, 3, 3, 11, f1113, .act (.dir .down), f1114, .ok⟩,
  ⟨3806, 3, 3, 11, f1114, .act (.dir .right), f1115, .ok⟩,
  ⟨3807, 3, 3, 11, f1115, .act (.dir .right), f1116, .ok⟩,
  ⟨3808, 3, 3, 11, f1116, .act (.dir .right), f1117, .ok⟩,
  ⟨3809, 3, 3, 11, f1117, .act (.dir .right), f1118, .ok⟩,
  ⟨3810, 3, 3, 11, f1118, .act (.dir .right), f1119, .ok⟩,
  ⟨3811, 3, 3, 11, f1119, .act (.dir .up), f1120, .ok⟩,
  ⟨3812, 3, 3, 11, f1120, .act (.dir .up), f1121, .ok⟩,
  ⟨3813, 3, 3, 11, f1121, .act (.click 51 30), f1122, .ok⟩,
  ⟨3814, 3, 3, 11, f1122, .act (.dir .left), f1123, .ok⟩,
  ⟨3815, 3, 3, 11, f1123, .act (.dir .left), f1124, .ok⟩,
  ⟨3816, 3, 3, 11, f1124, .act (.dir .left), f1125, .ok⟩,
  ⟨3817, 3, 3, 11, f1125, .act (.dir .down), f1126, .ok⟩,
  ⟨3818, 3, 3, 11, f1126, .act (.click 36 54), f1127, .ok⟩,
  ⟨3819, 3, 3, 11, f1127, .act (.dir .right), f1128, .ok⟩,
  ⟨3820, 3, 3, 11, f1128, .act (.dir .up), f1129, .ok⟩,
  ⟨3821, 3, 3, 11, f1129, .act (.click 42 30), f1130, .ok⟩,
  ⟨3822, 3, 3, 11, f1130, .act (.dir .right), f1131, .ok⟩,
  ⟨3823, 3, 3, 11, f1131, .act (.dir .down), f1132, .ok⟩,
  ⟨3824, 3, 3, 11, f1132, .act (.dir .down), f1133, .ok⟩,
  ⟨3825, 3, 3, 11, f1133, .act (.dir .left), f1134, .ok⟩,
  ⟨3826, 3, 3, 11, f1134, .act (.dir .up), f1135, .ok⟩,
  ⟨3827, 3, 3, 11, f1135, .act (.dir .up), f1136, .ok⟩,
  ⟨3828, 3, 3, 11, f1136, .act (.dir .up), f1137, .ok⟩,
  ⟨3829, 3, 3, 11, f1137, .act (.dir .up), f1138, .ok⟩,
  ⟨3830, 3, 3, 11, f1138, .act (.dir .up), f1139, .ok⟩,
  ⟨3831, 3, 3, 11, f1139, .act (.dir .up), f1140, .ok⟩,
  ⟨3832, 3, 3, 11, f1140, .act (.dir .up), f1141, .ok⟩,
  ⟨3833, 3, 3, 11, f1141, .act (.dir .down), f1142, .ok⟩,
  ⟨3834, 3, 3, 11, f1142, .act (.dir .down), f1143, .ok⟩,
  ⟨3835, 3, 3, 11, f1143, .act (.dir .down), f1144, .ok⟩,
  ⟨3836, 3, 3, 11, f1144, .act (.dir .right), f1145, .ok⟩,
  ⟨3837, 3, 3, 11, f1145, .act (.dir .right), f1146, .ok⟩,
  ⟨3838, 3, 4, 11, f1146, .act (.dir .right), f463, .levelup⟩,
  ⟨3839, 4, 4, 11, f463, .act (.dir .up), f464, .ok⟩,
  ⟨3840, 4, 4, 11, f464, .act (.dir .up), f465, .ok⟩,
  ⟨3841, 4, 4, 11, f465, .act (.dir .down), f1147, .ok⟩,
  ⟨3842, 4, 4, 11, f1147, .act (.dir .down), f1148, .ok⟩,
  ⟨3843, 4, 4, 11, f1148, .act (.dir .right), f1149, .ok⟩,
  ⟨3844, 4, 4, 11, f1149, .act (.dir .up), f1150, .ok⟩,
  ⟨3845, 4, 4, 11, f1150, .act (.dir .up), f1151, .ok⟩,
  ⟨3846, 4, 4, 11, f1151, .act (.dir .up), f1152, .ok⟩,
  ⟨3847, 4, 4, 11, f1152, .act (.dir .up), f1153, .ok⟩,
  ⟨3848, 4, 4, 11, f1153, .act (.dir .up), f1154, .ok⟩,
  ⟨3849, 4, 4, 11, f1154, .act (.dir .up), f1155, .ok⟩,
  ⟨3850, 4, 4, 11, f1155, .act (.dir .up), f1156, .ok⟩,
  ⟨3851, 4, 4, 11, f1156, .act (.dir .up), f1157, .ok⟩,
  ⟨3852, 4, 4, 11, f1157, .act (.dir .up), f1158, .ok⟩,
  ⟨3853, 4, 4, 11, f1158, .act (.dir .right), f1159, .ok⟩,
  ⟨3854, 4, 4, 11, f1159, .act (.dir .right), f1160, .ok⟩,
  ⟨3855, 4, 4, 11, f1160, .act (.dir .down), f1161, .ok⟩,
  ⟨3856, 4, 4, 11, f1161, .act (.dir .down), f1162, .ok⟩,
  ⟨3857, 4, 4, 11, f1162, .act (.dir .right), f1163, .ok⟩,
  ⟨3858, 4, 4, 11, f1163, .act (.dir .right), f1164, .ok⟩,
  ⟨3859, 4, 4, 11, f1164, .act (.dir .right), f1165, .ok⟩,
  ⟨3860, 4, 4, 11, f1165, .act (.dir .right), f1166, .ok⟩,
  ⟨3861, 4, 4, 11, f1166, .act (.dir .right), f1167, .ok⟩,
  ⟨3862, 4, 4, 11, f1167, .act (.dir .right), f1168, .ok⟩,
  ⟨3863, 4, 4, 11, f1168, .act (.dir .up), f1169, .ok⟩,
  ⟨3864, 4, 4, 11, f1169, .act (.dir .up), f1170, .ok⟩,
  ⟨3865, 4, 4, 11, f1170, .act (.dir .up), f1171, .ok⟩,
  ⟨3866, 4, 4, 11, f1171, .act (.dir .up), f1172, .ok⟩,
  ⟨3867, 4, 4, 11, f1172, .act (.dir .up), f1173, .ok⟩,
  ⟨3868, 4, 4, 11, f1173, .act (.dir .up), f1174, .ok⟩,
  ⟨3869, 4, 4, 11, f1174, .act (.dir .left), f1175, .ok⟩,
  ⟨3870, 4, 4, 11, f1175, .act (.dir .up), f1176, .ok⟩,
  ⟨3871, 4, 4, 11, f1176, .act (.dir .up), f1177, .ok⟩,
  ⟨3872, 4, 4, 11, f1177, .act (.dir .right), f1178, .ok⟩,
  ⟨3873, 4, 4, 11, f1178, .act (.dir .down), f1179, .ok⟩,
  ⟨3874, 4, 4, 11, f1179, .act (.dir .down), f1180, .ok⟩,
  ⟨3875, 4, 4, 11, f1180, .act (.dir .down), f1181, .ok⟩,
  ⟨3876, 4, 4, 11, f1181, .act (.dir .down), f1182, .ok⟩,
  ⟨3877, 4, 4, 11, f1182, .act (.dir .down), f1183, .ok⟩,
  ⟨3878, 4, 4, 11, f1183, .act (.dir .down), f1184, .ok⟩,
  ⟨3879, 4, 4, 11, f1184, .act (.dir .left), f1185, .ok⟩,
  ⟨3880, 4, 5, 11, f1185, .act (.dir .down), f483, .levelup⟩,
  ⟨3881, 5, 5, 11, f483, .act (.dir .down), f1186, .ok⟩,
  ⟨3882, 5, 5, 11, f1186, .act (.dir .left), f1187, .ok⟩,
  ⟨3883, 5, 5, 11, f1187, .act (.dir .left), f1188, .ok⟩,
  ⟨3884, 5, 5, 11, f1188, .act (.dir .up), f1189, .ok⟩,
  ⟨3885, 5, 5, 11, f1189, .act (.dir .up), f1190, .ok⟩,
  ⟨3886, 5, 5, 11, f1190, .act (.dir .left), f1191, .ok⟩,
  ⟨3887, 5, 5, 11, f1191, .act (.dir .left), f1192, .ok⟩,
  ⟨3888, 5, 5, 11, f1192, .act (.dir .left), f1193, .ok⟩,
  ⟨3889, 5, 5, 11, f1193, .act (.dir .left), f492, .ok⟩,
  ⟨3890, 5, 5, 11, f492, .act (.dir .left), f493, .ok⟩,
  ⟨3891, 5, 5, 11, f493, .act (.dir .left), f494, .ok⟩,
  ⟨3892, 5, 5, 11, f494, .act (.dir .left), f1194, .ok⟩,
  ⟨3893, 5, 5, 11, f1194, .act (.dir .up), f1195, .ok⟩,
  ⟨3894, 5, 5, 11, f1195, .act (.dir .up), f1196, .ok⟩,
  ⟨3895, 5, 5, 11, f1196, .act (.dir .left), f1197, .ok⟩,
  ⟨3896, 5, 5, 11, f1197, .act (.dir .left), f1198, .ok⟩,
  ⟨3897, 5, 5, 11, f1198, .act (.dir .left), f1199, .ok⟩,
  ⟨3898, 5, 5, 11, f1199, .act (.dir .left), f1200, .ok⟩,
  ⟨3899, 5, 5, 11, f1200, .act (.dir .left), f1201, .ok⟩,
  ⟨3900, 5, 5, 11, f1201, .act (.dir .up), f1202, .ok⟩,
  ⟨3901, 5, 5, 11, f1202, .act (.dir .up), f1203, .ok⟩,
  ⟨3902, 5, 5, 11, f1203, .act (.dir .up), f1204, .ok⟩,
  ⟨3903, 5, 5, 11, f1204, .act (.dir .up), f1205, .ok⟩,
  ⟨3904, 5, 5, 11, f1205, .act (.dir .up), f1206, .ok⟩,
  ⟨3905, 5, 5, 11, f1206, .act (.dir .left), f1207, .ok⟩,
  ⟨3906, 5, 5, 11, f1207, .act (.dir .up), f1208, .ok⟩,
  ⟨3907, 5, 5, 11, f1208, .act (.dir .down), f1209, .ok⟩,
  ⟨3908, 5, 5, 11, f1209, .act (.dir .down), f1210, .ok⟩,
  ⟨3909, 5, 5, 11, f1210, .act (.dir .down), f1211, .ok⟩,
  ⟨3910, 5, 5, 11, f1211, .act (.dir .down), f1212, .ok⟩,
  ⟨3911, 5, 5, 11, f1212, .act (.dir .down), f1213, .ok⟩,
  ⟨3912, 5, 5, 11, f1213, .act (.dir .down), f1214, .ok⟩,
  ⟨3913, 5, 5, 11, f1214, .act (.dir .right), f1215, .ok⟩,
  ⟨3914, 5, 5, 11, f1215, .act (.dir .right), f1216, .ok⟩,
  ⟨3915, 5, 5, 11, f1216, .act (.dir .right), f1217, .ok⟩,
  ⟨3916, 5, 5, 11, f1217, .act (.dir .right), f519, .ok⟩,
  ⟨3917, 5, 5, 11, f519, .act (.dir .down), f1218, .ok⟩,
  ⟨3918, 5, 5, 11, f1218, .act (.dir .down), f1219, .ok⟩,
  ⟨3919, 5, 5, 11, f1219, .act (.dir .down), f1220, .ok⟩,
  ⟨3920, 5, 5, 11, f1220, .act (.dir .right), f1221, .ok⟩,
  ⟨3921, 5, 5, 11, f1221, .act (.dir .up), f1222, .ok⟩,
  ⟨3922, 5, 5, 11, f1222, .act (.dir .right), f1223, .ok⟩,
  ⟨3923, 5, 5, 11, f1223, .act (.dir .right), f1224, .ok⟩,
  ⟨3924, 5, 5, 11, f1224, .act (.dir .right), f1225, .ok⟩,
  ⟨3925, 5, 5, 11, f1225, .act (.dir .right), f1226, .ok⟩,
  ⟨3926, 5, 5, 11, f1226, .act (.dir .right), f1227, .ok⟩,
  ⟨3927, 5, 5, 11, f1227, .act (.dir .right), f1228, .ok⟩,
  ⟨3928, 5, 5, 11, f1228, .act (.dir .right), f1229, .ok⟩,
  ⟨3929, 5, 5, 11, f1229, .act (.dir .up), f1230, .ok⟩,
  ⟨3930, 5, 5, 11, f1230, .act (.dir .up), f1231, .ok⟩,
  ⟨3931, 5, 6, 11, f1231, .act (.dir .right), f535, .levelup⟩,
  ⟨3932, 6, 6, 11, f535, .act (.dir .up), f757, .ok⟩,
  ⟨3933, 6, 6, 11, f757, .act (.click 35 52), f1232, .ok⟩,
  ⟨3934, 6, 6, 11, f1232, .act (.dir .up), f1233, .ok⟩,
  ⟨3935, 6, 6, 11, f1233, .act (.dir .up), f1234, .ok⟩,
  ⟨3936, 6, 6, 11, f1234, .act (.dir .up), f1235, .ok⟩,
  ⟨3937, 6, 6, 11, f1235, .act (.dir .right), f1236, .ok⟩,
  ⟨3938, 6, 6, 11, f1236, .act (.dir .right), f1237, .ok⟩,
  ⟨3939, 6, 6, 11, f1237, .act (.click 55 41), f1238, .ok⟩,
  ⟨3940, 6, 6, 11, f1238, .act (.dir .down), f1239, .ok⟩,
  ⟨3941, 6, 6, 11, f1239, .act (.dir .left), f1240, .ok⟩,
  ⟨3942, 6, 6, 11, f1240, .act (.dir .left), f1241, .ok⟩,
  ⟨3943, 6, 6, 11, f1241, .act (.dir .left), f1242, .ok⟩,
  ⟨3944, 6, 6, 11, f1242, .act (.dir .left), f1243, .ok⟩,
  ⟨3945, 6, 6, 11, f1243, .act (.dir .left), f1244, .ok⟩,
  ⟨3946, 6, 6, 11, f1244, .act (.dir .down), f1245, .ok⟩,
  ⟨3947, 6, 6, 11, f1245, .act (.dir .left), f1246, .ok⟩,
  ⟨3948, 6, 6, 11, f1246, .act (.dir .left), f1247, .ok⟩,
  ⟨3949, 6, 6, 11, f1247, .act (.dir .left), f1248, .ok⟩,
  ⟨3950, 6, 6, 11, f1248, .act (.dir .left), f1249, .ok⟩,
  ⟨3951, 6, 6, 11, f1249, .act (.click 41 34), f1250, .ok⟩,
  ⟨3952, 6, 6, 11, f1250, .act (.dir .up), f1251, .ok⟩,
  ⟨3953, 6, 6, 11, f1251, .act (.dir .up), f1252, .ok⟩,
  ⟨3954, 6, 6, 11, f1252, .act (.dir .right), f1253, .ok⟩,
  ⟨3955, 6, 6, 11, f1253, .act (.dir .right), f1254, .ok⟩,
  ⟨3956, 6, 6, 11, f1254, .act (.dir .right), f1255, .ok⟩,
  ⟨3957, 6, 6, 11, f1255, .act (.dir .right), f1256, .ok⟩,
  ⟨3958, 6, 6, 11, f1256, .act (.dir .up), f1257, .ok⟩,
  ⟨3959, 6, 6, 11, f1257, .act (.dir .up), f1258, .ok⟩,
  ⟨3960, 6, 6, 11, f1258, .act (.dir .up), f1259, .ok⟩,
  ⟨3961, 6, 6, 11, f1259, .act (.dir .up), f1260, .ok⟩,
  ⟨3962, 6, 6, 11, f1260, .act (.dir .up), f1261, .ok⟩,
  ⟨3963, 6, 6, 11, f1261, .act (.dir .up), f1262, .ok⟩,
  ⟨3964, 6, 6, 11, f1262, .act (.dir .left), f1263, .ok⟩,
  ⟨3965, 6, 6, 11, f1263, .act (.dir .down), f1264, .ok⟩,
  ⟨3966, 6, 6, 11, f1264, .act (.dir .down), f1265, .ok⟩,
  ⟨3967, 6, 6, 11, f1265, .act (.dir .down), f1266, .ok⟩,
  ⟨3968, 6, 6, 11, f1266, .act (.dir .down), f1267, .ok⟩,
  ⟨3969, 6, 6, 11, f1267, .act (.dir .down), f1268, .ok⟩,
  ⟨3970, 6, 6, 11, f1268, .act (.dir .down), f1269, .ok⟩,
  ⟨3971, 6, 6, 11, f1269, .act (.dir .left), f1270, .ok⟩,
  ⟨3972, 6, 6, 11, f1270, .act (.dir .left), f1271, .ok⟩,
  ⟨3973, 6, 6, 11, f1271, .act (.dir .left), f1272, .ok⟩,
  ⟨3974, 6, 6, 11, f1272, .act (.dir .up), f1273, .ok⟩,
  ⟨3975, 6, 6, 11, f1273, .act (.dir .left), f1274, .ok⟩,
  ⟨3976, 6, 6, 11, f1274, .act (.dir .left), f1275, .ok⟩,
  ⟨3977, 6, 6, 11, f1275, .act (.dir .left), f1276, .ok⟩,
  ⟨3978, 6, 6, 11, f1276, .act (.dir .left), f1277, .ok⟩,
  ⟨3979, 6, 6, 11, f1277, .act (.dir .left), f1278, .ok⟩,
  ⟨3980, 6, 6, 11, f1278, .act (.dir .left), f1279, .ok⟩,
  ⟨3981, 6, 6, 11, f1279, .act (.click 28 47), f1280, .ok⟩,
  ⟨3982, 6, 6, 11, f1280, .act (.dir .up), f1281, .ok⟩,
  ⟨3983, 6, 6, 11, f1281, .act (.dir .up), f1282, .ok⟩,
  ⟨3984, 6, 6, 11, f1282, .act (.dir .up), f1283, .ok⟩,
  ⟨3985, 6, 6, 11, f1283, .act (.dir .right), f1284, .ok⟩,
  ⟨3986, 6, 6, 11, f1284, .act (.dir .right), f1285, .ok⟩,
  ⟨3987, 6, 6, 11, f1285, .act (.dir .right), f1286, .ok⟩,
  ⟨3988, 6, 6, 11, f1286, .act (.dir .right), f1287, .ok⟩,
  ⟨3989, 6, 6, 11, f1287, .act (.dir .right), f1288, .ok⟩,
  ⟨3990, 6, 6, 11, f1288, .act (.dir .up), f1289, .ok⟩,
  ⟨3991, 6, 6, 11, f1289, .act (.dir .up), f1290, .ok⟩,
  ⟨3992, 6, 6, 11, f1290, .act (.dir .up), f1291, .ok⟩,
  ⟨3993, 6, 6, 11, f1291, .act (.dir .left), f1292, .ok⟩,
  ⟨3994, 6, 6, 11, f1292, .act (.dir .left), f1293, .ok⟩,
  ⟨3995, 6, 6, 11, f1293, .act (.dir .left), f1294, .ok⟩,
  ⟨3996, 6, 6, 11, f1294, .act (.dir .up), f1295, .ok⟩,
  ⟨3997, 6, 6, 11, f1295, .act (.dir .up), f1296, .ok⟩,
  ⟨3998, 6, 6, 11, f1296, .act (.dir .up), f1297, .ok⟩,
  ⟨3999, 6, 6, 11, f1297, .act (.dir .right), f1298, .ok⟩]

def rows16 : List Row := [
  ⟨4000, 6, 6, 11, f1298, .act (.dir .up), f1299, .ok⟩,
  ⟨4001, 6, 6, 11, f1299, .act (.dir .left), f1300, .ok⟩,
  ⟨4002, 6, 6, 11, f1300, .act (.dir .down), f1301, .ok⟩,
  ⟨4003, 6, 6, 11, f1301, .act (.dir .left), f1302, .ok⟩,
  ⟨4004, 6, 6, 11, f1302, .act (.dir .down), f1303, .ok⟩,
  ⟨4005, 6, 6, 11, f1303, .act (.dir .down), f1304, .ok⟩,
  ⟨4006, 6, 6, 11, f1304, .act (.dir .down), f1305, .ok⟩,
  ⟨4007, 6, 6, 11, f1305, .act (.dir .down), f1306, .ok⟩,
  ⟨4008, 6, 6, 11, f1306, .act (.dir .left), f1307, .ok⟩,
  ⟨4009, 6, 6, 11, f1307, .act (.dir .left), f1308, .ok⟩,
  ⟨4010, 6, 6, 11, f1308, .act (.click 26 25), f1309, .ok⟩,
  ⟨4011, 6, 6, 11, f1309, .act (.dir .down), f1310, .ok⟩,
  ⟨4012, 6, 6, 11, f1310, .act (.dir .down), f1311, .ok⟩,
  ⟨4013, 6, 6, 11, f1311, .act (.dir .left), f1312, .ok⟩,
  ⟨4014, 6, 6, 11, f1312, .act (.dir .left), f1313, .ok⟩,
  ⟨4015, 6, 6, 11, f1313, .act (.dir .left), f1314, .ok⟩,
  ⟨4016, 6, 6, 11, f1314, .act (.dir .left), f1315, .ok⟩,
  ⟨4017, 6, 6, 11, f1315, .act (.dir .left), f1316, .ok⟩,
  ⟨4018, 6, 6, 11, f1316, .act (.dir .left), f1317, .ok⟩,
  ⟨4019, 6, 6, 11, f1317, .act (.dir .up), f1318, .ok⟩,
  ⟨4020, 6, 6, 11, f1318, .act (.dir .left), f1319, .ok⟩,
  ⟨4021, 6, 6, 11, f1319, .act (.dir .up), f1320, .ok⟩,
  ⟨4022, 6, 6, 11, f1320, .act (.dir .up), f1321, .ok⟩,
  ⟨4023, 6, 6, 11, f1321, .act (.dir .right), f1322, .ok⟩,
  ⟨4024, 6, 6, 11, f1322, .act (.dir .down), f1323, .ok⟩,
  ⟨4025, 6, 6, 11, f1323, .act (.dir .down), f1324, .ok⟩,
  ⟨4026, 6, 6, 11, f1324, .act (.dir .down), f1325, .ok⟩,
  ⟨4027, 6, 6, 11, f1325, .act (.dir .down), f1326, .ok⟩,
  ⟨4028, 6, 6, 11, f1326, .act (.dir .right), f1327, .ok⟩,
  ⟨4029, 6, 6, 11, f1327, .act (.dir .right), f1328, .ok⟩,
  ⟨4030, 6, 6, 11, f1328, .act (.dir .right), f1329, .ok⟩,
  ⟨4031, 6, 6, 11, f1329, .act (.dir .right), f1330, .ok⟩,
  ⟨4032, 6, 6, 11, f1330, .act (.dir .right), f1331, .ok⟩,
  ⟨4033, 6, 6, 11, f1331, .act (.click 31 26), f1332, .ok⟩,
  ⟨4034, 6, 6, 11, f1332, .act (.dir .left), f1333, .ok⟩,
  ⟨4035, 6, 6, 11, f1333, .act (.dir .left), f1334, .ok⟩,
  ⟨4036, 6, 6, 11, f1334, .act (.dir .down), f1335, .ok⟩,
  ⟨4037, 6, 6, 11, f1335, .act (.click 23 31), f1336, .ok⟩,
  ⟨4038, 6, 6, 11, f1336, .act (.dir .right), f1337, .ok⟩,
  ⟨4039, 6, 6, 11, f1337, .act (.dir .right), f1338, .ok⟩,
  ⟨4040, 6, 6, 11, f1338, .act (.dir .up), f1339, .ok⟩,
  ⟨4041, 6, 6, 11, f1339, .act (.dir .up), f1340, .ok⟩,
  ⟨4042, 6, 6, 11, f1340, .act (.dir .up), f1341, .ok⟩,
  ⟨4043, 6, 6, 11, f1341, .act (.dir .left), f1342, .ok⟩,
  ⟨4044, 6, 6, 11, f1342, .act (.dir .down), f1343, .ok⟩,
  ⟨4045, 6, 6, 11, f1343, .act (.click 25 41), f1344, .ok⟩,
  ⟨4046, 6, 6, 11, f1344, .act (.dir .down), f1345, .ok⟩,
  ⟨4047, 6, 6, 11, f1345, .act (.dir .up), f1346, .ok⟩,
  ⟨4048, 6, 6, 11, f1346, .act (.dir .right), f1347, .ok⟩,
  ⟨4049, 6, 6, 11, f1347, .act (.dir .right), f1348, .ok⟩,
  ⟨4050, 6, 6, 11, f1348, .act (.dir .right), f1349, .ok⟩,
  ⟨4051, 6, 6, 11, f1349, .act (.dir .right), f1350, .ok⟩,
  ⟨4052, 6, 6, 11, f1350, .act (.dir .right), f1351, .ok⟩,
  ⟨4053, 6, 6, 11, f1351, .act (.dir .down), f1352, .ok⟩,
  ⟨4054, 6, 6, 11, f1352, .act (.dir .down), f1353, .ok⟩,
  ⟨4055, 6, 6, 11, f1353, .act (.dir .left), f1354, .ok⟩,
  ⟨4056, 6, 6, 11, f1354, .act (.dir .left), f1355, .ok⟩,
  ⟨4057, 6, 6, 11, f1355, .act (.dir .left), f1356, .ok⟩,
  ⟨4058, 6, 6, 11, f1356, .act (.dir .left), f1357, .ok⟩,
  ⟨4059, 6, 6, 11, f1357, .act (.click 26 22), f1358, .ok⟩,
  ⟨4060, 6, 7, 11, f1358, .act (.dir .down), f1359, .levelup⟩]

/-- 整条轨迹，共 4061 行。 -/
def rows : List Row := rows00 ++ rows01 ++ rows02 ++ rows03 ++ rows04 ++ rows05 ++ rows06 ++ rows07 ++ rows08 ++ rows09 ++ rows10 ++ rows11 ++ rows12 ++ rows13 ++ rows14 ++ rows15 ++ rows16

-- ---------------------------------------------------------------- 整关口径：每关开局的门带朝向

def headings : Nat → List (Option (Bool × Bool))
  | 0 => []
  | 1 => []
  | 2 => []
  | 3 => []
  | 4 => [some (false, false), some (true, true)]
  | 5 => [some (true, true), some (true, true), some (true, false)]
  | 6 => [some (true, true), some (true, false)]
  | _ => []


def dummy : Row := ⟨0, 0, 0, 0, ⟨[], [], 0⟩, .reset, ⟨[], [], 0⟩, .reset⟩

/-- 按 **row** 取一行（不按下标）。越界给空行，空行在任何判据下都会立刻露馅。 -/
def rowAt (n : Nat) : Row := (rows.find? (fun r => r.row == n)).getD dummy

/-- 从 row `want` 起连着取 `len` 行，只留模型描述的动作。取不到就是空表——所以每一段另配 `_len` 定理。 -/
def playFrom (want len : Nat) : List (Act × Seen) :=
  ((rows.dropWhile (fun r => r.row != want)).take len).filterMap (fun r =>
    match r.act with
    | .act a => some (a, r.next)
    | .reset => none)

/-- 某一行的动作（RESET 给一个点空白的点击；`_len` 与逐帧核对会让这种错位当场露馅）。 -/
def actAt (n : Nat) : Act :=
  match (rowAt n).act with
  | .act a => a
  | .reset => .click 0 0

/-- 一帧 + 隐藏的两位 → 模型的状态。`u` = 这一关已经走了几步；`hs` = 门带朝向（整关口径），
    给空表就用帧上读到的（逐条口径）。 -/
def stOf (o : Seen) (u : Nat) (hs : List (Option (Bool × Bool))) : St :=
  { pieces := o.pieces.map (fun p => ⟨p.cells, p.shelled, p.retired⟩)
    sel := ((List.range o.pieces.length).find? (fun i => (o.pieces.getD i ⟨[], false, false, false⟩).sel)).getD 0
    gates := ((List.range o.gates.length).zip o.gates).map (fun (ig : Nat × OGate) =>
      ⟨ig.2.r, ig.2.c, ig.2.h, ig.2.w, (hs.getD ig.1 none).orElse (fun _ => ig.2.dir), ig.2.count⟩)
    used := u }

/-- 第 `lv` 关、从 row `n` 那一帧开局（已走 0 步，门带朝向取整关口径）。 -/
def startAt (n lv : Nat) : St := stOf (rowAt n).prev 0 (headings lv)

#eval "REPLAY rows=" ++ toString rows.length

