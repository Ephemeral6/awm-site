/-
# Agree —— 逐条那一把尺子：模型面对**一条**真实转移站不站得住

每一条都从**观测到的那一帧**起算（和每关那一层相反：那里只有开局是观测给的）。

## 从一帧起算，缺的两位怎么补

    门带朝向    帧上读到什么就是什么：数到 0 的是 `none`，判据对它不比朝向（逐条口径）
    已走几步    帧上只有条的格数。取**纤维**：满足「走 u 步时条 = 前一帧、走 u+1 步时条 = 后一帧」
                的第一个 u；一个都没有 ⇒ 判错（条的走法对不上）

## 三种结果对三种标记

    ok        模型给出下一个局面，**看得见的那部分和下一帧一样**
    levelup   模型说这一步赢了（下一帧是下一关的盘，不比）
    over      模型说这一步条走空了（下一帧是终局画面，不比）
    reset     不在这一层：模型不描述 RESET（`stepDescribed` 把它筛掉，条数打在读数里）
-/
import Obj.World
import Obs.Replay


/-- 这一关预算 B，前一帧条 pb、后一帧条 nb：第一个说得通的「已走步数」。 -/
def fiber (B pb nb : Nat) : Option Nat :=
  (List.range (B + 1)).find? (fun u => barOf B u == pb && barOf B (u + 1) == nb)

/-- 只看前一帧的条：第一个说得通的「已走步数」（换关那一步用：后一帧是下一关的条）。 -/
def fiber1 (B pb : Nat) : Nat := ((List.range (B + 1)).find? (fun u => barOf B u == pb)).getD 0

def stepDescribed (r : Row) : Bool :=
  match r.act with
  | .act _ => true
  | .reset => false

/-- **逐条**：模型走这一步，和看到的对不对得上。 -/
def stepAgrees (r : Row) : Bool :=
  let b := boardOf r.lvl
  match r.act with
  | .reset => false
  | .act a =>
    match r.tag with
    | .levelup => step b (stOf r.prev (fiber1 b.budget r.prev.bar) []) a == .won
    | .ok =>
        match fiber b.budget r.prev.bar r.next.bar with
        | some u =>
            match step b (stOf r.prev u []) a with
            | .ok s' => fits (proj b s') r.next
            | _ => false
        | none => false
    | .over =>
        match fiber b.budget r.prev.bar r.next.bar with
        | some u => step b (stOf r.prev u []) a == .over
        | none => false
    | .reset => false

/-- 按 **row** 取一段：`lo ≤ row < hi`。 -/
def rowsIn (lo hi : Nat) : List Row := rows.filter (fun r => lo ≤ r.row && r.row < hi)

/-- **只给读数用**：这一段里判错的那几行（`#eval` 走求值器，不是定理）。 -/
def disagreeRows (lo hi : Nat) : List Nat :=
  ((rowsIn lo hi).filter (fun r => stepDescribed r && !stepAgrees r)).map (·.row)

