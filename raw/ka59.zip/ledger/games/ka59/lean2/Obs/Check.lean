/-
# Check —— 判据层：模型面对一帧观测（**0 条定理**，尺子不自证）

    Seen       一帧上**看得见**的那部分：块（格、带不带壳、是不是被操纵的、卸没卸任）、
               门带（位置、数到几、朝向——数到 0 时 none）、预算条剩几格
    proj       模型的状态 → 它该让人看见什么（隐藏的 `used` 折成条的格数，数到 0 的门带藏起朝向）
    fits       模型的样子和看到的一样吗。块和门带按**集合**比（帧上的顺序是按位置排的，
               模型的顺序是按身份排的，两者不是一回事）；模型不知道朝向的门带不比朝向
    traceOk    一整条路：**带着模型自己算出来的状态**往下走，逐帧比
    everWon    一串动作之中有没有哪一步赢了

两把尺子（逐条 / 整条）都只在这里定义一次，`Obs/Corpus` 和 `Proof/Levels` 都从这里拿。
-/
import Step


structure OPiece where
  cells   : List Cell
  shelled : Bool
  sel     : Bool
  retired : Bool
deriving DecidableEq, Repr

structure OGate where
  r : Nat
  c : Nat
  h : Nat
  w : Nat
  dir : Option (Bool × Bool)
  count : Nat
deriving DecidableEq, Repr

structure Seen where
  pieces : List OPiece
  gates  : List OGate
  bar    : Nat
deriving DecidableEq, Repr

def proj (b : Board) (s : St) : Seen :=
  { pieces := ((List.range s.pieces.length).zip s.pieces).map (fun (ip : Nat × Piece) =>
      (⟨ip.2.cells, ip.2.shelled, ip.1 == s.sel, ip.2.retired⟩ : OPiece))
    gates := s.gates.map (fun g => ⟨g.r, g.c, g.h, g.w, if g.count == 0 then none else g.dir, g.count⟩)
    bar := barOf b.budget s.used }

/-- 一条门带：模型不知道朝向（`none`）时不比朝向，其余逐位比。 -/
def OGate.fits (m o : OGate) : Bool :=
  m.r == o.r && m.c == o.c && m.h == o.h && m.w == o.w && m.count == o.count &&
  (m.dir.isNone || m.dir == o.dir)

def fits (m o : Seen) : Bool :=
  sameSet m.pieces o.pieces && m.bar == o.bar &&
  m.gates.length == o.gates.length && m.gates.all (fun g => o.gates.any (OGate.fits g))

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。下一轮喂进去的是**模型自己算出来的** `s'`。 -/
def traceOk (b : Board) : St → List (Act × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
      match step b s a with
      | .ok s' => fits (proj b s') o && traceOk b s' rest
      | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它走求值器，不是定理。 -/
def firstSplit (b : Board) : St → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
      match step b s a with
      | .ok s' => if fits (proj b s') o then firstSplit b s' rest (i + 1) else some i
      | _ => some i

/-- 一串动作之中有没有哪一步赢了。输了（`over`）就停，算没赢。 -/
def everWon (b : Board) : St → List Act → Bool
  | _, [] => false
  | s, a :: rest =>
      match step b s a with
      | .won => true
      | .ok s' => everWon b s' rest
      | .over => false

