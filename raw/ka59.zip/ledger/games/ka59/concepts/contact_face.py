"""被操纵物体的一条边整条被涂成色0，当且仅当那条边紧靠着另一个物体——带壳的外壳（色14）、裸物体本身（色11），
或者门带（色12/色13）。"""
LEVEL = "L2"
SCOPE = ("只看棋盘上判得出被操纵物体的帧（me_box 为 None 返回 NA）；"
         "包围盒贴到 HUD 行时返回 NA（没见过，不猜）；prev 和 next 都要成立")
NOTE = ("v4: 贴着**画面边**（行/列越出这张帧）那条边从 NA 改成正面断言「不亮」。"
        "由来是关6 第 3521-3525 步，一个物体贴着第 0 列一路朝上走，左边整条 8 次读出来全是色14。"
        "这不是凑巧：亮=贴着可推的东西，画面外没有东西可推。"
        "代价是 piece_paint 从此敢写那条边——不改这一条，链式预测里那 3 格永远没人认领，"
        "两步之后整个物体的读数都跟着歪（关6 那条链就是这么断的）。"
        "HUD 行那一头仍是 NA：一次都没见过，不猜。\n"
        "v3: 关4 第 941 步物体上移到贴住门带的下沿，顶边整条亮了；v2 说门色不算物体，当场判 FALSE。"
        "把门色加进「物体色」——代价是它顺带说出了一件更大的事：亮=贴着**可推的东西**，"
        "而下一步（第 942 步）那条门带确实被推走了（gate_pushed）。色4 框壁、色2 墙贴着仍不亮，那一半还是没动。"
        "v2: 关2 第 870 步推手贴到裸十字块（色11）的下臂，那一面照样亮了——「只有色14 才亮」是关0/关1 里"
        "只有带壳物体时的窄读法。改成「贴着任何物体色（SHELL 或 BARE）都亮」；色4 框壁、色2 墙贴着仍不亮，那一半没动。"
        "v1: 这条高亮就是 me() 早先读错核心的原因（37 条反例）。"
        "试过更宽的写法「外侧不是背景就亮」，全语料 747/1102 判 FALSE —— "
        "色4（框壁）和色2 都贴着不亮，只有色14（别的物体的壳）才亮。"
        "收窄成色14 后 1102/1102 判 TRUE。")
EVIDENCE = ["1b83f42620278fdf", "57401bd25dbc910f", "76dbbad7a9cb69f8",
            "6d902194ce254233", "05e56c377dcb1f7f",
            "3f65adbdc5a1b366",   # step 870 反例：推手顶面贴到色11 下臂，整条亮
            "b92f6450c5e96d8f",   # step 871 反例：同上（prev 亮着，走开后灭）
            "d4ddb412b8719fca",   # step 872-1 反例：推手左面贴到色11 下臂右侧，亮
            "04a17eaca0763b61",   # step 872 反例：贴着色11 推它，prev 亮
            "70e55644a2fd5e00",   # step 941 反例：顶边贴住门带（色13）下沿，整条亮
            "c6f792f462acd677",   # step 942 反例：贴着门带推它，prev 亮
            # v4 立论的那 5 条：物体贴着第 0 列一路朝上走，左边整条 8 次全是色14（不亮）
            "174bb34f29e42e25", "4c969207c5c8875b", "f19b32ea57719229",
            "230305c1d32ffddb", "3acdd5d597a17b1a"]

from _lib import me_box, SHELL, SELECTED, HUD_ROW, BARE, GATE

_OBJECT = (SHELL,) + tuple(BARE) + tuple(GATE)


def _sides(box):
    r0, r1, c0, c1 = box
    yield [(r0, c) for c in range(c0, c1 + 1)], [(r0 - 1, c) for c in range(c0, c1 + 1)]
    yield [(r1, c) for c in range(c0, c1 + 1)], [(r1 + 1, c) for c in range(c0, c1 + 1)]
    yield [(r, c0) for r in range(r0, r1 + 1)], [(r, c0 - 1) for r in range(r0, r1 + 1)]
    yield [(r, c1) for r in range(r0, r1 + 1)], [(r, c1 + 1) for r in range(r0, r1 + 1)]


def _verdict(g):
    box = me_box(g)
    if box is None:
        return "NA"
    R, C = len(g), len(g[0])
    for inner, outer in _sides(box):
        if any(r == HUD_ROW for r, _ in outer):
            return "NA"                              # HUD 那一头没见过，不猜
        lit = all(g[r][c] == SELECTED for r, c in inner)
        near = any(0 <= r < R and 0 <= c < C and g[r][c] in _OBJECT for r, c in outer)
        if lit != near:                              # 越出画面的格子算「没东西」：不亮
            return "FALSE"
    return "TRUE"


def assert_(prev, action, nxt, ctx=None):
    a, b = _verdict(prev), _verdict(nxt)
    if "FALSE" in (a, b):
        return "FALSE"
    if "TRUE" in (a, b):
        return "TRUE"
    return "NA"
