"""门带归零的那一步，正对着它、中间没有挡路色隔着的被操纵物体，动作**照常生效**；
紧接着它被那条带子朝「带子长过去的那个方向」再推 3 个格位，途中撞上色2 就停、停在色15 上就接着滑到离开它 ——
和被推的物体同一条走法，只换射程。"""
LEVEL = "L6"
STRIKE = 3                                  # 射程：从量表上拟合出来的常数，见 NOTE
SCOPE = ("只看 ACTION1/2/3/4；换关那一帧 NA；me_box() 判不出来 NA；"
         "_lib.gate_strike_hit(prev, d) 挑不出带子时 NA —— 即没有「这一步归零 + "
         "**动作生效之后**物体正在它前方 + 中间没有色2/色15 隔着」的带子；"
         "那种步由 core_step 管（core_step 正好在这里让位）；"
         "同时有两条这样的带子时也 NA（没见过，不猜）；动作生效后的落点算不出来时 NA")
NOTE = ("v6：加射程。终局卡第 3741 步：带子归零、物体在它正前方、中间干净，可空隙有 4 个格位，物体只按自己的动作走了一步。"
        "把语料里「归零 + 前方有物体」的每一步列成表（runs/…/dbg_reach.py）：空隙 0/1/2 格位的 7 次全被扫走，"
        "空隙 4 格位的这 1 次没动；空隙 3 格位一次没见过。射程放在 _lib.REACH（= 3 个格位，和 STRIKE 同数，"
        "理由只是少一个常数），_clear_between 顺带查它，所以 gate_strike_hit、core_step 的让位、gate_idle_strike 同时改口径。"
        "这条概念自己的源码只加了这一段话和一条 EVIDENCE；那一步现在判 NA，由 core_step 说话。\n"
        "v5：**两句都改了**，而且不是在反例上改参数改出来的。第 1002 步给了一条反例（物体按右，"
        "列按自己的动作走了，行却被朝上挪了 5 个格位），按方法册「把同类事件列成量表，再拟合」，"
        "先把语料里所有同类事件（动作之后落点不等于 core_next 算的那个、换关帧排除）列成一张 5 行的表"
        "（runs/…/try_strike_table.py），五种读法各算一遍落点：\n"
        "  A 动作作废 + 层数÷CELL（= v4）  4/5    B 动作生效 + KICK      3/5\n"
        "  C 动作生效 + 层数÷CELL          2/5    D 动作作废 + KICK      1/5\n"
        "  E 动作生效 + 3 个格位                  5/5\n"
        "A 和 B 各自解释一半，恰好在第 938 步和第 1002 步上互相排斥；E 一条不漏。"
        "把走廊沿带子朝向铺开来看（try_strike_strip.py）就明白 A 为什么能撑那么久："
        "第 990、972、1002 三步的落点全是「推 3 个格位正好压在色15 大带上、于是接着滑」，"
        "滑完的位置和「推 2 个格位」的位置在那三步上碰巧同一个；第 966 步则是被色2 拦住，推 2 推 3 都停在同一格。"
        "五次里只有第 938 步（沿途和落点都干净）和第 1002 步（动作垂直于带子的朝向，列上的位移把动作有没有生效"
        "写在了脸上）说得出话，而它们说的是同一件事：动作先算，再推 3 格。\n"
        "**射程 3 是个拟合出来的裸常数，而且它的来路一点没被约束住**：语料里这五次归零扫人，带子全是 6 层的，"
        "所以 3、CELL、层数÷2 在数据上完全分不开。框壁那条 3 层的带（关4 的 (27,29,51,53)）哪天扫到人，"
        "这三种来路给的是 3 / 3 / 1，当场分家。在那之前这条概念里的 3 只是「量出来是 3」。\n"
        "v4 死于它自己 NOTE 里那句话：v1 就写过「另一种同样能解释第 938 步的读法是『动作照常生效，再被推 3 个格位』，"
        "……现在还分不开，先赌层数这条，因为它不用凭空多一个常数」。赌输了。"
        "「少一个常数」是个好理由，但它挑的是两条都没被检验的读法里的一条，不是证据。\n"
        "v3：落点改用 _lib.struck_cells —— 被扫的物体走的是和被推的物体同一条走法（撞色2 即停、"
        "落点压着色15 就接着滑到离开带子），只把射程换掉。"
        "v2 的落点是「包围盒 + k 个格位」，不认沿途的色2 也不认色15，"
        "所以它在「扫出去正好落在色15 带上」的局面上说得出一个这一局别处都不许出现的结果：物体停在带子上。"
        "推法那两条停/滑的子句是量出来的（push_kick），这里宣称它们不是「推」专有的，而是「物体被挪动」共有的。"
        "v2：加上「中间没有挡路色隔着」。v1 的『正前方』没有距离上限，"
        "而第 942 步之后那条带被推到了色15 大带的另一侧（行3-8），物体还在行36-38 —— "
        "按 v1 它隔着一整条色15 还要挨推，整关会变成死循环（规划器直接判不可达）。"
        "这一局里别的东西都拦得住色2/色15：推、走、落点全认它们。所以按同一个口径收窄。"
        "v1：只有一条转移撑着它（第 938 步）。那一步发的是 ACTION1（上），而物体从 39-41 行掉到 45-47 行 —— "
        "跟它自己的动作正好相反，也不是被别的物体推的（那一步没有任何别的物体动）。")
EVIDENCE = ["b634045d2dea4796",   # 第 938 步 ACTION1：39-41 → 45-47。沿途干净，唯一一次「推 3」和「推 2」分得开且 A 也中的
            "e405d49a30e16e97",   # 第 972 步 ACTION1：落点本压在色15 带上，接着滑到离开
            "e9d6f70e54feac58",   # 第 990 步 ACTION1：同上，滑出来的位置和 A 碰巧同一个
            "786b86758b20b531",   # 第 966 步 ACTION1：被色2 拦住，推 2 推 3 停在同一格
            "969c79e9319a0eb1",   # 第 1002 步 ACTION4：v4 的反例。动作垂直于带子朝向，列上的位移证明动作生效了
            "39349cefe418e2c8"]   # 第 3741 步 ACTION2：v5 的反例。空隙 4 个格位，归零了没扫到 —— 射程的来处
# 上面五条是语料里**全部**同类事件，一条不剩地进了拟合，所以这条概念此刻的 N（留出检验数）是 0。
# 它的第一次真检验是下一次「归零 + 我在带子前方」的那一步。这不是分数问题，是这条概念还没被考过。

from _lib import (DELTA, me_box, box_cells, gate_strike_hit, gate_dir, act_id,
                  struck_cells, moved_cells, objects, object_cells, piece_paint, seated, pieces, under)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = act_id(action)
    if d not in DELTA:
        return "NA"
    box = me_box(prev)
    if box is None:
        return "NA"
    bar = gate_strike_hit(prev, d)
    if bar is None:
        return "NA"
    plain = moved_cells(prev, d)
    if plain is None:
        return "NA"
    land = struck_cells(prev, plain, gate_dir(bar), STRIKE)
    rs = [r for r, _ in land]
    cs = [c for _, c in land]
    want = (min(rs), max(rs), min(cs), max(cs))
    got = me_box(nxt)
    if got is None:
        return "NA"
    return "TRUE" if got == want else "FALSE"


def apply(prev, action, ctx=None):
    """落点定死了，物体长什么样就也定死了：把它整个画到被扫到的位置上，
    腾出来的那片按 under 还原成框壁或背景。
    接触高亮按**新位置**重算，不是照抄旧位置那几格：飞出去之后贴着谁是另一回事。
    这一步之后就换关的不画：换关那一帧整屏重画。"""
    d = act_id(action)
    if d not in DELTA:
        return None
    box = me_box(prev)
    if box is None:
        return None
    bar = gate_strike_hit(prev, d)
    if bar is None:
        return None
    plain = moved_cells(prev, d)
    if plain is None:
        return None
    land = struck_cells(prev, plain, gate_dir(bar), STRIKE)
    rs = [r for r, _ in land]
    cs = [c for _, c in land]
    nb = (min(rs), max(rs), min(cs), max(cs))
    here = objects(prev)
    if box not in here:
        return None
    after = tuple(nb if b == box else b for b in here)
    covered = set().union(*pieces(prev))
    if all(seated(prev, box_cells(b), covered) for b in after):
        return None                       # 这一步过关
    occ = object_cells(prev, after) - box_cells(nb)
    out = under(prev, box_cells(box) - box_cells(nb))
    out.update(piece_paint(prev, nb, True, occ))
    return out
