"""方向动作之后被操纵物体核心的位置，由 core_next 完全定死：贴着别人不动、扫到色2/色15 不动、否则挪一个格位。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1/2/3/4；换关那一帧 NA；me()/me_box() 判不出来 NA；"
         "物体会扫出画面或扫进 HUD 行时 NA（没见过，不猜）；"
         "_lib.gate_strike_hit(prev, 动作) 挑得出带子时 NA —— 那种步归 gate_strike 管")
NOTE = (
    "v7 只动了一行：让位线从「prev 上正对着带子」改成「**动作生效之后**正对着带子」，"
    "跟着 gate_strike v5 走（那一版把射程和「动作作不作废」两句一起改了，依据是 5 条同类事件的量表）。"
    "由来是第 1002 步的反例：物体在 prev 上还不在带子前方（所以 v6 照旧开口），"
    "按右走进带子前方之后被扫，落点差了 5 个格位，v6 当场判 FALSE。"
    "反例 tid 记在 gate_strike v5 的 EVIDENCE 里 —— 那一步的落点是它说的，不是这条说的。\n"
    "v1: 取代早先按色5写的四条 move_*。色0 才是被操纵的核心，色5 是没选中的物体。"
    "v1 的 37 条反例来自 me() 取「第一个色0 格」，读到的是**接触高亮**而不是核心。"
    "v2 的 2 条反例来自取核判据「四方向都能撞到外壳」——接触边会挡在核心和背景之间（第448步）。"
    "v5 缩了一处 scope：关4 的门带归零那一步（第 938 步），物体正对着带子，"
    "发的是上、却往下掉了两个格位 —— core_next 完全定死落点这句话在那儿不成立。"
    "缩的是「正对着一条这一步会归零的门带」这一类，交给 gate_strike 去说；"
    "缩了就不再声称管那一片，别的门带（物体不在它前方的）照旧由这条管。"
    "v4 从「挪一格或不动」收紧成「完全定死落点」：全语料统计，贴边的 32 次核心全没动；"
    "不贴边时，目标带扫到色2 的 159 次、色15 的 16 次全没动，只有色1 的 114 次、"
    "色1+色4 的 19 次全动了。唯一的例外是第121 步那条换关转移，已被 scope 排除。"
)
EVIDENCE = [
    "01f71cca86876ed3", "0ade1b584d523c25", "b9fb111aa6adca48",
    "037ecc0ac8486af6", "05e56c377dcb1f7f", "0bbe9948d57e65e4",
    "191a057c7cc89d9c", "1b83f42620278fdf", "1d5ce9a9ffd1c2cc",
    "24d664e9f5d3511a", "40c4c03fa0d0cc00", "469c4a8daa8f9982",
    "4f220d5f0f3f3805", "4fb416771f15f46e", "528ad0e163d6f395",
    "57401bd25dbc910f", "5f5037768908e353", "5fdb96feb5068a95",
    "6057496d4be081a1", "61afe230fef77c21", "6225207842ca77db",
    "6273a5e0343b4ce8", "666ec4faeb5fff6f", "694121af932447af",
    "79430c8bf286e1d4", "7963b5db9cadeec0", "7bf336438c208362",
    "7c0c5f44577a2899", "7c581f180a3d9425", "8d47cdd9c93d41f6",
    "8d82d012044b8e4c", "9b0a24689361b1ba", "a99c721af98a794b",
    "aa29045a5646916a", "b7e028fed2ed4da6", "c25ca9d02802e20d",
    "c9a307d3314cdae1", "d8f516c905adfb4e", "dda350459b0a6ce5",
    "f6c3ba7d81bebf8c",
    # v2 的两条：取核判据「四方向都能撞到外壳」不够 —— 接触边会挡在核心和背景之间
    "76dbbad7a9cb69f8", "6d902194ce254233",
    # v4 收紧后拿来立论的：贴边不动 / 色2 挡 / 色15 挡 / 穿过色4 框壁
    "d0be6445d77a2332", "df42148a577e5945", "09770cf41480716e", "654b267c69176256",
    # v5 缩 scope 的由来：门带归零那一步，物体正对着带子，落点不由 core_next 定
    "b634045d2dea4796",
    # v7 缩 scope 的由来：prev 上还不在带子前方、动作把自己送进去的那一步（缩了之后这条在这儿判 NA）
    "969c79e9319a0eb1",
]

from _lib import (me, me_box, core_next, DELTA, gate_strike_hit,
                  boxes_next, face_lit, object_cells, piece_paint, box_cells, solving, under)


def _act_id(action):
    if isinstance(action, int):
        return action
    if isinstance(action, str) and action.startswith("ACTION"):
        head = action[6:].split(":")[0]
        if head.isdigit():
            return int(head)
    return None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a = _act_id(action)
    if a not in DELTA:
        return "NA"
    box = me_box(prev)
    if box is not None and gate_strike_hit(prev, a) is not None:
        return "NA"                 # 门带归零、动作生效后正对着物体那一步：归 gate_strike 管
    want = core_next(prev, a)
    if want is None:
        return "NA"
    got = me(nxt)
    if got is None:
        return "NA"
    return "TRUE" if got == want else "FALSE"


def apply(prev, action, ctx=None):
    """落点定死了，物体长什么样就也定死了：把被操纵物体整个画到新位置上，
    腾出来的那片按 under 还原成框壁或背景（这一局里物体压得住的只有这两样）。
    贴着别人那一步（推）不画：那一步动的是别人，归 push_shove 说。
    这一步之后就换关的也不画：换关那一帧整屏重画，落点再对也没用。"""
    a = _act_id(action)
    if a not in DELTA:
        return None
    box = me_box(prev)
    if box is None or gate_strike_hit(prev, a) is not None:
        return None
    if face_lit(prev, box, a) or solving(prev, action):
        return None
    after, nb = boxes_next(prev, action)
    if after is None or nb is None:
        return None
    occ = object_cells(prev, [b for b in after if b != nb]) - box_cells(nb)
    out = under(prev, box_cells(box) - box_cells(nb), [box_cells(nb)])
    out.update(piece_paint(prev, nb, True, occ))
    return out
