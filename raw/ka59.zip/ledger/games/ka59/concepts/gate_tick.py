"""门带是个计数器：每发一个**方向动作**，它就多一层色12（从它已有的那一头往前长）；
差一层就长满时，这一步改为整条变回色13（归零），不是长满。ACTION6 点击不算拍子：点完带子一格不变。"""
LEVEL = "L4"
SCOPE = ("只看非 RESET 的转移；换关那一帧 NA；prev 上一条门带都没有时 NA（关0-关3 全程如此）；"
         "被物体（色14 壳、色0 核、色11 裸块）压住的带子整条跳过——压着的那几格读出来是物体色，数不准；"
         "prev 和 nxt 上带子的格子集合对不上（带子自己挪了位置）时 NA：那是另一回事，这条不管；"
         "整条同色、看不出往哪头长的带子只对「多了一层」这个格数，不对具体是哪一层；"
         "ACTION6 那一步只断言「带子原样不动」，不管点中没点中")
NOTE = ("v2：第 3452 步一次**点中了**的 ACTION6（对象真的换了，帧差 4 格）门带一层没长——v1 只给「帧差 ≤1 的无效点击」留了 NA，"
        "点中的那种就判成 FALSE 了。连同第 3378-3382 步那 5 次没点中的，6 次 ACTION6 门带全都原地不动，"
        "所以改成正面断言：拍子只数方向动作，点击那一步带子必须一格不变。顺带一提，那一步 HUD 预算条也没扣。\n"
        "v1：接替被打死的 gate_static。零假设说「门自己不会变」，5 步里被打了 5 次，"
        "把 5 条转移逐条列成量表（runs/…/try_gate.py）之后读出来的是这个："
        "竖井那条 6 行的带，色12 的行数走 2→3→4→5→0→1；框壁那条 3 列的带，色12 的列数走 2→0→1→2→0→1。"
        "两条都是一个动作长一层、差一层就长满时归零，周期正好是它自己的层数。"
        "写成「长一层」而不是「长几格」是有代价的：万一哪天它一步长两层、或者只在某些动作上长，"
        "这条当场判 FALSE —— 那正是要问出来的。")
EVIDENCE = [
    "0a4c3a9ad5affeed", "865731f63e00506b", "72e5db38ff1101f0",
    "b634045d2dea4796", "6c14d1b6b5e9c8bd",   # 第 935-939 步：打死 gate_static 的那 5 条
    "08c44672a1bf61c9", "7a0839559126d105", "b6e0671b8a0027b7",
    "c2c47e271c5fe088", "d5f25de749ecf7c8",   # 第 3378-3382 步：level 6 探索时的 5 条反例
    "ff70d8d31d981d89",                       # 第 3452 步：点中了的 ACTION6（换了对象），门带一层没长
]

from _lib import (gate_bars, gate_slice, pieces, boxes_next, box_cells, bare_pieces,
                  solving, act_id, DELTA, me_box, strip)


def _covered(g):
    ps = pieces(g)
    return set().union(*ps) if ps else set()


def assert_(prev, action, nxt, ctx=None):
    if action == "RESET" or action == 0:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    # 点击不算拍子：ACTION6 那一步门带必须一格不变（点中没点中都一样）
    if isinstance(action, str) and action.startswith("ACTION6:"):
        a0 = gate_bars(prev)
        if not a0:
            return "NA"
        b0 = {bar["cells"]: bar for bar in gate_bars(nxt)}
        skip0 = _covered(prev) | _covered(nxt)
        seen = "NA"
        for bar in a0:
            if bar["cells"] & skip0 or bar["cells"] not in b0:
                continue
            if b0[bar["cells"]]["filled"] != bar["filled"]:
                return "FALSE"
            seen = "TRUE"
        return seen
    a = gate_bars(prev)
    if not a:
        return "NA"
    b = {bar["cells"]: bar for bar in gate_bars(nxt)}
    skip = _covered(prev) | _covered(nxt)
    verdict = "NA"
    for bar in a:
        if bar["cells"] & skip or bar["cells"] not in b:
            continue
        after = b[bar["cells"]]
        want = 0 if bar["wrap"] else bar["filled"] + 1
        if after["filled"] != want:
            return "FALSE"
        if want and bar["axis"] is not None:
            hot = {(r, c) for (r, c) in after["cells"] if nxt[r][c] == 12}
            if hot != set().union(*(gate_slice(bar, k) for k in range(want))):
                return "FALSE"
        verdict = "TRUE"
    return verdict


def apply(prev, action, ctx=None):
    """拍子定死了，带子逐格长什么样也就定死了：从起点数前 want 层涂色12，其余涂色13
    （want = 归零那一步 0，否则现有层数 +1；ACTION6 那一步照旧，不长）。
    三种带子不画：被物体压着的（读出来就不准）、整条同色看不出往哪头长的（说得出层数说不出是哪一层）、
    以及这一步会被物体挪过去盖住的（盖住那几格显示的是物体，不是带子）。
    这一步正被推的那条也不画：它整条要搬家，搬到哪归 gate_pushed 说。
    换关那一帧整屏重画，一句都不说。"""
    if action == "RESET" or action == 0:
        return None
    bars = gate_bars(prev)
    if not bars:
        return None
    click = isinstance(action, str) and action.startswith("ACTION6:")
    d = act_id(action)
    if not click:
        if d not in DELTA or solving(prev, action):
            return None
    after, _ = boxes_next(prev, action)
    if after is None:
        return None
    blocked = _covered(prev)
    for b in after:
        blocked |= box_cells(b)
    for p in bare_pieces(prev):
        blocked |= set(p)
    box = me_box(prev)
    if box is not None and not click:
        blocked |= frozenset(strip(box, d))      # 正被推的那条带子躲开
    out = {}
    for bar in bars:
        if bar["axis"] is None or bar["cells"] & blocked:
            continue
        want = bar["filled"] if click else (0 if bar["wrap"] else bar["filled"] + 1)
        hot = set().union(*(gate_slice(bar, k) for k in range(want))) if want else set()
        for (r, c) in bar["cells"]:
            out[(r, c)] = 12 if (r, c) in hot else 13
    return out
