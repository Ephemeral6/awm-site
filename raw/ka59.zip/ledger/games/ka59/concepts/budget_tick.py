"""每发一个动作，行63 的预算条就少一格色4（最右边那格变色0），除非条已空。"""
LEVEL = "L4"
SCOPE = "只看非 RESET 的动作；换关那一帧返回 NA；预算条已空返回 NA"
NOTE = "实测：关0 从 64 格递减，关1 连发 ACTION1 把它从 64 一路扣到 0"
EVIDENCE = ["30917df59a6a20da", "9cc0d75ff7bef5d9", "f2c85b339cda9988"]

from _lib import budget, HUD_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action == "RESET" or action == 0:
        return "NA"
    b0 = budget(prev)
    if b0 == 0:
        return "NA"
    b1 = budget(nxt)
    if b1 == b0:
        return "TRUE"          # 有些动作不收费（被驳回的点击、重复选中）
    if b1 != b0 - 1:
        return "FALSE"
    # 扣的必须是最右边那格
    rightmost = max(c for c in range(len(prev[HUD_ROW])) if prev[HUD_ROW][c] == 4)
    return "TRUE" if nxt[HUD_ROW][rightmost] != 4 else "FALSE"
