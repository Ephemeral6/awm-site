"""裸物体（色11，没有外壳）只在被操纵物体贴着它推的那一步才动，落点按和带壳物体同一条推法算
（走 5 个格位、撞硬墙即停、压带就滑出带子、落到谁头上谁让开）；没被推的那一步一格不动。"""
LEVEL = "L6"
SCOPE = ("只看方向动作；换关那一帧 NA；棋盘上一个裸物体都没有时 NA；me_box 判不出来 NA；"
         "**prev 上有门带这一步要归零时 NA**——那一步物体还会被扫，归 gate_idle_strike 管，这条不管")
NOTE = ("v3：v2 的「语料里还是一次真推都没有」是错的——第 872/878/889 步（关2）被操纵物体整面贴着十字块推，"
        "物体自己没动、十字块各飞了 5 个格位，pushed_pieces 算出来的落点和帧一致；这条在那三步上本来就判 TRUE。"
        "改的只是说明，断言不动。仍没验过的是**半面**贴着推（推手只压住十字的一条臂）会不会同样飞 5 格。\n"
        "v2：第 3480 步打死了 v1 的「没被推的那一步一格不动」：那一步上门带归零，"
        "正下方一个谁也没碰的裸十字自己朝下走了 3 个格位又滑了 1 个。"
        "推法本身没被推翻，被推翻的是「只有推能让它动」这个独占句。"
        "所以缩到「归零步不管」，把那一类交给新写的 gate_idle_strike；"
        "代价是这条从此对每 6 步里的 1 步闭嘴，而那正是裸物体唯一动过的那种步——"
        "换句话说，v2 之后这条依然一次真推都没验过，分数再高也只说明「没被推的时候确实没动」。\n"
        "v1：和 bare_static 是一对打架的主张——那条说裸物体永远不动，这条说它们被推就走。"
        "写这条的理由是几何：关2 两个十字块离各自的十字框正好都是 5 个格位（一个只差一个方向，"
        "另一个差两个方向），而 5 正是 push_kick 量出来的 KICK。语料里还没有一步真的推过裸物体，"
        "所以 EVIDENCE 里只有「没推就没动」的那一条；第一次推下去，这条和 bare_static 必死一个。")
EVIDENCE = [
    "ac27959e3f03be4a",   # step 863 ACTION3 带壳物体进小方框，没贴着任何十字块，两个十字块都没动
    "a31b31fc4b9a3a60",   # 第 3480 步 ACTION3 打死 v1 的那一条：没人推它，门带归零把它扫走了
]

from _lib import (act_id, bare_pieces, me_box, pushed_pieces, gate_bars, solving, BARE,
                  under, pieces, boxes_next, box_cells, gate_cells, piece_paint)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = act_id(action)
    if d is None:
        return "NA"
    if any(bar["wrap"] for bar in gate_bars(prev)):
        return "NA"                      # 归零步：还会有扫击，落点不归这条管
    a, b = bare_pieces(prev), bare_pieces(nxt)
    if not a and not b:
        return "NA"
    if me_box(prev) is None:
        return "NA"
    moved = pushed_pieces(prev, d)
    want = {moved.get(p, p) for p in a}
    return "TRUE" if want == set(b) else "FALSE"


def apply(prev, action, ctx=None):
    """裸物体的落点定死了，它长什么样也就定死了：整片都是色11，没有外壳也没有核心，
    所以把新占的那些格子一律涂色11；腾出来的那片按 under 还原成框壁或背景
    （落点也交给 under：它落进框里时，那个框的壁有整条压在它自己身子底下，
      只有从落点那一圈才看得见 —— 关3 第 928 步的十字框下沿就是这么找回来的）。
    推手原地不动，但它刚才贴着的裸物体跑了，接触高亮要跟着灭 —— 按新的邻居重画它一遍
    （第 889、914 步：不画这一下就留 5 格鬼影，两步之后整个物体都读不出来了）。
    归零步不画（那一步的落点不归这条管），换关那一帧也不画。"""
    d = act_id(action)
    if d is None:
        return None
    if any(bar["wrap"] for bar in gate_bars(prev)):
        return None
    box = me_box(prev)
    if box is None or solving(prev, action):
        return None
    moved = pushed_pieces(prev, d)
    if not moved:
        return None
    bare = bare_pieces(prev)
    vacated, landed = set(), set()
    for p, q in moved.items():
        if p not in bare:
            continue
        vacated |= set(p)
        landed |= set(q)
    if not landed:
        return None
    for p in pieces(prev):                    # 没动的物体压着的格子不算腾出来
        if p not in moved:
            vacated -= set(p)
    out = under(prev, vacated - landed, [landed])
    for (r, c) in landed:
        out[(r, c)] = BARE[0]
    after, nb = boxes_next(prev, action)
    if after is not None and nb == box:
        occ = set(gate_cells(prev))
        for b in after:
            if b != nb:
                occ |= box_cells(b)
        for p in bare:
            occ |= set(moved.get(p, p))
        occ -= box_cells(nb)
        out.update(piece_paint(prev, nb, True, occ))
    return out
