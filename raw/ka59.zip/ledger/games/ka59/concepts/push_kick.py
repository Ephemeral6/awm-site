"""贴边那一步被顶出去的物体，朝同向走 min(5, 撞硬墙/画面边之前还剩几个格位) 个格位；
落点若压着色15 带，就接着同向滑到完全离开带子为止 —— 那个落点必定出现在下一帧的物体表里。

v1 读成「恰好走 5 个格位，撞上色2/色4/别的物体/边才提前停」，19/19；第 821、826 步戳穿了它：
两次左推分别走了 6 和 9 个格位，停的地方都是「刚好整体离开色15 带的第一个格位」，
而 v1 眼里色4 早该在第 5、第 10 个格位挡住它们。重新把语料里全部 31 次推列成表（runs/…/push_table.txt）
量出来：色4 从没挡住过谁（第 43 步那一列色4 就在第 5 个格位上，物体照走不误），
挡住过的只有色2 和画面边；而带子不挡路、只是停不住。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1/2/3/4，且这一步被操纵物体确实贴着别人（face_lit）；"
         "换关那一帧 NA；prev 或 next 的 me_box 判不出来 NA；"
         "两帧数出来的物体个数不一致 NA（有物体被读丢了，不拿它当反例）。"
         "只断言**紧贴推手**那个物体的落点，被它压到的第三者让到哪里由 push_shove 管。")
NOTE = ("v2：三处改动 —— 挡块集合从 (色2,色4) 缩成 (色2)；判挡看前方一整个格位（深3）而不是紧贴的一排；"
        "新增「落点不许压带、压了就接着滑」。31 次推全对。"
        "仍未被检验的两件事：(a) 5 个格位之内从没有别的物体挡在路上，所以「物体不挡、只让开」是从"
        "第 821/826 步两次连锁外推的，不是直接量到的；(b) 从没见过滑不出带子就先撞墙的局面，"
        "此时本条按「停在撞墙前那一格」算，纯属猜。"
        "另有一个同样拟合 31 次的读法：「路上有别的物体就正好走到它跟前，否则 min(5, 撞墙前)」。"
        "两者在现有语料上不可分辨；选了前者是因为它把带子和物体分别归因，而后者要靠两个巧合。")
EVIDENCE = [
    "d8f516c905adfb4e",   # step 43  ACTION4 推 5 格位，穿过色15 带；色4 就在第 5 个格位上却没挡住
    "79430c8bf286e1d4",   # step 66  ACTION4 同上
    "191a057c7cc89d9c",   # step 182 ACTION4 同上
    "57401bd25dbc910f",   # step 135 ACTION1 只走 1 个格位，被色2 挡住
    "61afe230fef77c21",   # step 292 ACTION4 走 5 格位后停在空地 —— 推翻「滑到底」
    "1d5ce9a9ffd1c2cc",   # step 298 ACTION4 接着把最后 1 个格位走完
    "db5a3e575269f0b8",   # step 300 ACTION4 已贴画面边，0 格位
    "6d902194ce254233",   # step 449 ACTION2 6×6 朝下 4 个格位到底
    "6225207842ca77db",   # step 647 ACTION1 1 个格位
    "f4d1726ab66a09ee",   # step 651 ACTION1 0 格位
    "afb58209e8afe78f",   # step 275 ACTION1 0 格位
    "c1a5db5c670ae8bf",   # step 816 ACTION3 走 5 格位，落在带子左边刚好不压带
    "becb972500097816",   # step 821 反例：走 6 个格位 —— 第 5 个格位压着带，滑到第 6 个才离开
    "50bccf136fd563f8",   # step 826 反例：走 9 个格位 —— 2×2 的物体要滑到第 9 个格位才整体离开带
]

from _lib import me_box, face_lit, objects, kick, strip, act_id, DELTA


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = act_id(action)
    if d not in DELTA:
        return "NA"
    box = me_box(prev)
    if box is None or me_box(nxt) is None:
        return "NA"
    if not face_lit(prev, box, d):
        return "NA"
    before, after = objects(prev), objects(nxt)
    if len(before) != len(after):
        return "NA"
    outer = strip(box, d)
    victims = [b for b in before
               if b != box and any(b[0] <= r <= b[1] and b[2] <= c <= b[3] for r, c in outer)]
    if not victims:
        return "NA"
    for v in victims:
        if kick(prev, v, d) not in set(after):
            return "FALSE"
    return "TRUE"
