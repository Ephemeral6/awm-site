"""门带也是被推的：被操纵物体贴着一条门带发方向动作时，自己不动，门带按跟别的物体一样的推法走
——同向最多 5 个格位、撞硬墙（色2）或画面边就停，落点压着色15 带就接着同向滑到完全离开带子。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1/2/3/4；换关那一帧 NA；me_box() 判不出来 NA；"
         "prev 上被操纵物体朝这个方向紧贴的那一排格里没有门色时 NA；"
         "prev 上同时贴着两条门带、或者同时贴着门带和别的物体时 NA（没见过，不猜）；"
         "被推的带子在 nxt 上认不出来（被物体压住、或者拆成了两块）时 NA")
NOTE = ("v3：断言一个字没改，改的是 `_lib.under`——这条概念的 apply 靠它回答「带子搬走之后那几格露出什么色」。"
        "终局卡第 3762 步：一个空着的十字框，右壁整条（3 格）压在门带底下，带子被推走后露出的是壁色，"
        "而 under 收尾时有一句「门带不算壁」把全部门格从壁集合里减掉，于是一律答背景，说错 3 格。"
        "under 的五头本来就把「门色」和「被物体压着」并列当成壁的证据，只是收尾那一减把这条路堵死了；"
        "现在只减**没在挪的**门格。全语料 1504 条转移重跑，八条有 apply 的概念说错仍然全是 0。\n"
        "v2：认带子的办法从「按格数认」换成「按排除法认」。v1 写的是"
        "「在 nxt 里找格数和被推那条一样多的带子，只有一条才算数」——那是关4 的写法，那一关同时在场的带子格数各不相同。"
        "关5 同时有三条 6×6 的带子，格数全是 36，`len(after) != 1` 当场成立，于是这条概念对整个关5 一律 NA。"
        "**这个洞是在第 995 步的动作已经发出去、结果还没读到的时候发现并补上的**——"
        "补的是「哪条带子是我推的那条」这个识别环节，不是落点那个判据：v2 的做法是"
        "先把 prev 里除被推那条以外的带子记下来，nxt 里凡是原封不动还在原处的都排掉，剩下那条就是它。"
        "这不循环：被推的带子要是压根没动，剩下的那条就是它自己，照样拿去和 kick_cells 的落点比，照样判 FALSE。\n"
        "v1：第 942 步。物体贴住竖井那条 6 行 6 列的门带下沿再按上，物体一格没动，"
        "而整条带从行30-35 搬到了行3-8 —— 正好是 push_kick 的两段：先同向 5 个格位到行15-20，"
        "落点压着色15 带（行9-20）于是接着滑，滑到行3-8 才完全离开。一条没改过参数的老规律，"
        "在一个全新的物件上原样兑现。所以门带不是地形，是个可推的东西；"
        "它同时还在数拍子（gate_tick），两件事互不干涉：搬了家照样一步长一层。"
        "没跟着做的是：把门带放进 pieces()。那样写更省事，但 level_solved 会连带要求门带也嵌进框里，"
        "而关4 的框本来就少一段壁、缺口正由一条门带占着——先分开写，等有证据再合并。")
EVIDENCE = ["c6f792f462acd677",   # 第 942 步 ACTION1：物体不动，带子从行30-35 飞到行3-8
            "bf3d9a07f11c31a5",   # 第 995 步 ACTION4：关5 三条同尺寸带子里，被推的那条 (45,50,27,32) → (45,50,42,47)，推手一格没动
            "882db55268860257"]   # 第 3762 步 ACTION1：带子被推走，底下露出十字框的右壁——v2 的 apply 在这三格上答了背景

from _lib import (me_box, box_cells, strip, act_id, DELTA, GATE,
                  gate_bars, kick_cells, pieces, gate_slice, objects, bare_pieces,
                  piece_paint, solving, under)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = act_id(action)
    if d not in DELTA:
        return "NA"
    box = me_box(prev)
    if box is None:
        return "NA"
    outer = frozenset(strip(box, d))
    bars = [b for b in gate_bars(prev) if b["cells"] & outer]
    if len(bars) != 1:
        return "NA"
    mine = box_cells(box)
    if any(p & outer for p in pieces(prev) if p != mine):
        return "NA"                                  # 同时还贴着别的物体：连锁的推，这条不管
    bar = bars[0]
    want = kick_cells(prev, bar["cells"], d)
    others = {b["cells"] for b in gate_bars(prev)} - {bar["cells"]}
    after = [b for b in gate_bars(nxt) if b["cells"] not in others]
    if len(after) != 1:
        return "NA"
    if me_box(nxt) != box:
        return "FALSE"                               # 推手自己也动了：这条说的是「自己不动」
    return "TRUE" if after[0]["cells"] == want else "FALSE"


def _shoved(prev, d):
    """这一步被推的那条带子，以及它整体平移的位移。推不动 / 认不出来 / 不是整体平移就返回 None。"""
    box = me_box(prev)
    if box is None:
        return None
    outer = frozenset(strip(box, d))
    bars = [b for b in gate_bars(prev) if b["cells"] & outer]
    if len(bars) != 1:
        return None
    mine = box_cells(box)
    if any(p & outer for p in pieces(prev) if p != mine):
        return None
    bar = bars[0]
    want = kick_cells(prev, bar["cells"], d)
    if want == bar["cells"]:
        return None                                  # 一格没挪：这一步照旧归 gate_tick 说
    src, dst = sorted(bar["cells"]), sorted(want)
    if len(src) != len(dst):
        return None
    dr, dc = dst[0][0] - src[0][0], dst[0][1] - src[0][1]
    if any((r + dr, c + dc) != q for (r, c), q in zip(src, dst)):
        return None                                  # 不是整体平移：没见过，不画
    return bar, want, dr, dc


def apply(prev, action, ctx=None):
    """落点定死了，带子逐格长什么样也就定死了：整条搬到新位置，层数照长一层
    （搬家和数拍子互不干涉，见 NOTE），起点跟着一起平移；腾出来的那片按 under 还原。
    推手原地不动，但它刚才贴着的带子跑了，接触高亮要跟着灭 —— 按新的邻居重画它一遍。
    带子读不出朝哪头长时只说腾出来的那片：层数说得出，哪一层是哪一层说不出。
    换关那一帧整屏重画，一句都不说。"""
    d = act_id(action)
    if d not in DELTA:
        return None
    box = me_box(prev)
    if box is None or solving(prev, action):
        return None
    got = _shoved(prev, d)
    if got is None:
        return None
    bar, want, dr, dc = got
    out = under(prev, set(bar["cells"]) - set(want))
    if bar["axis"] is not None:
        filled = 0 if bar["wrap"] else bar["filled"] + 1
        hot = set()
        for k in range(filled):
            hot |= {(r + dr, c + dc) for (r, c) in gate_slice(bar, k)}
        for (r, c) in want:
            out[(r, c)] = GATE[0] if (r, c) in hot else GATE[1]
    occ = set()
    for b in objects(prev):
        if b != box:
            occ |= box_cells(b)
    for p in bare_pieces(prev):
        occ |= set(p)
    for b in gate_bars(prev):
        occ |= set(want) if b["cells"] == bar["cells"] else set(b["cells"])
    occ -= box_cells(box)
    out.update(piece_paint(prev, box, True, occ))
    return out
