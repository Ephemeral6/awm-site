"""预算条空掉的那一步，世界判负：行63 上一格色4 都不剩时 state 变成 GAME_OVER；条上还有色4 时 state 不是 GAME_OVER。

也就是说预算条就是命：策略的整条路线必须在它走完之前完成，否则这一关白打。
（关卡往前走一格时条会补满，那一帧不算数——补满和判负在同一帧里读不出先后。）
"""
LEVEL = "L5"
SCOPE = ("只看非 RESET 的转移；换关那一帧 NA（条补满）；ctx 里没有 state 时 NA；"
         "nxt 上读不到行63（帧不完整）时 NA")
NOTE = ("v1。语料里 7 次预算读到 0，7 次 state 都从 NOT_FINISHED 变成 GAME_OVER，没有例外；"
        "反过来 3500+ 条转移里预算 >0 时一次 GAME_OVER 都没有。"
        "这条是策略的硬约束：路线长度必须放得进预算条，所以它得走闸，不能只写在规划器里。")
EVIDENCE = [
    "78984b9d5a39878d",   # step 568 ACTION6 —— 预算 1->0，state 转 GAME_OVER
    "f2c85b339cda9988",   # step 800 ACTION1 —— 同上
    "2c361fc4edc382d2",   # step 1766 ACTION6 —— 同上
    "30917df59a6a20da",   # 预算还有余额、state 没变的那一类
]

from _lib import budget, HUD_ROW


def assert_(prev, action, nxt, ctx=None):
    if action == "RESET" or action == 0:
        return "NA"
    if not ctx or ctx.get("state_next") is None:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if len(nxt) <= HUD_ROW:
        return "NA"
    empty = budget(nxt) == 0
    over = ctx.get("state_next") == "GAME_OVER"
    return "TRUE" if empty == over else "FALSE"
