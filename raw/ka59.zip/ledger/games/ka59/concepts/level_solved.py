"""关卡号往前走一格，当且仅当这一步之后每一个物体都正好嵌在一个框里
——即它紧贴外侧的那一圈格子全是色4 或门色（色12/色13）。

v1 说的是「每个空框内部都被物体占满」，靠 slots() 数矩形框；关2 一进去就被打脸：
那一关的框和物体是十字形的，矩形的词根本数不出来，于是「框都填满了」在只填了一个小方框时就成立，
而世界没换关。改成从物体这一侧看：不数框，只问每个物体是不是四周一圈都被框壁围住。
两种写法在关0/关1 上等价（那两关物体数=框数），关2 上只有后一种说得对。
"""
LEVEL = "L5"
SCOPE = ("只看方向动作和 ACTION6；RESET 那一帧 NA；"
         "ctx 里没有 level_prev/level_next 时 NA；boxes_next 判不出来 NA；"
         "prev 上一个物体都数不出来时 NA")
NOTE = ("v4：关4 的框缺了一段壁，缺口上长着一条色12/色13 的长条（门）。这一版把「框壁」从只认色4 放宽到"
        "「色4 或门色」（改在 _lib.seated 里）。这是个能落空的读法：物体坐进那个缺一段壁的框、"
        "而世界不换关，这条当场变反例。关0-关3 一格门色都没有，放宽对旧语料完全无影响。"
        "v3：落点改用 pieces_next（格子集合版）算，裸物体不再按「不动」硬编：它们被推时怎么走由 bare_pushed 说，"
        "没被推就不动——两种读法在语料上都还没分出胜负，这条只是不再偏向其中一个。判据本身没改。"
        "v2：判据仍在 prev 上算 —— 通关那一帧的 next 已经是下一关的盘面，看不到终局，"
        "所以得靠转移函数把物体的落点先算出来。"
        "「一圈全是色4」放宽了一点：prev 上被物体盖住的格子算通过，因为物体压在框壁上时那几格读出来是外壳色。"
        "放宽的代价是可能judge成 TRUE 而世界没换关 —— 那会当场变成这条概念的反例。")
EVIDENCE = [
    "3a69142ca144349d",   # step 121 ACTION2 —— 关0→关1，最后一个核心落进框心
    "6d902194ce254233",   # step 449 ACTION2 —— 推了个 6×6 但没填满框，关卡不动
    "61afe230fef77c21",   # step 292 ACTION4 —— 同上，推完还差三个框
    "b77511dd4fb95236",   # step 80  ACTION6 —— 只换选中对象，关卡不动
    "ac27959e3f03be4a",   # step 863 反例：关2 唯一的矩形框填满了，两个十字块还在外面，关卡不动
]

from _lib import pieces_next, pieces, seated, act_id, click_rc


def assert_(prev, action, nxt, ctx=None):
    if not ctx or "level_prev" not in ctx or "level_next" not in ctx:
        return "NA"
    if act_id(action) is None and click_rc(action) is None:
        return "NA"
    here = pieces(prev)
    if not here:
        return "NA"
    after, _ = pieces_next(prev, action)
    if after is None:
        return "NA"
    covered = set().union(*here)
    want = all(seated(prev, f, covered) for f in after)
    got = ctx["level_next"] > ctx["level_prev"]
    return "TRUE" if want == got else "FALSE"
