"""一条门带往哪头长，是它自己的固有属性：只要它没归零、也没搬家，读出来的 (axis, dir) 一步都不会变。
（归零那一步把方向藏进色13 里，这条概念对那一步闭嘴——「藏起来之后还是不是同一头」它不敢说。）"""
LEVEL = "L4"
SCOPE = ("只看非 RESET 的转移；换关那一帧 NA；"
         "一条带子只在 prev 和 nxt 上**都**读得出方向、且格子集合一模一样（没搬家）时才算数；"
         "任何一端整条同色（刚归零或刚长满）一律 NA；被物体压住的带子整条跳过（读出来缺格，方向不可信）；"
         "**归零前后是不是同一头，这条不管** —— 那要两条转移才看得见，单条转移判不了，见 NOTE")
NOTE = ("v1：从规划器的一个欠账里长出来的。规划器算路线时跨过归零那一步，直接沿用观测时的方向；"
        "而 gate_tick 的断言里写着 prev 整条同色时只对格数、不对哪一头 —— 也就是说"
        "「归零之后还从同一头长」被规划器当成已知在用，册子却一次都没说过。\n"
        "补这个洞试过两条路：\n"
        "  (1) 找帧上读得出来的锚。看了两条带子，色12 那一头外侧正好是色2，像是「从抵死的那头开始长」。"
        "      全语料 78 次显形核下来 48 对 30 错（runs/…/try_gate_anchor.py）：有三条带子两头都是色1，悬在空中，"
        "      规则根本无从说起。锚这条当场作废，没进册子。\n"
        "  (2) 退到单条转移判得了的那一半，就是这条概念：没归零的时候方向不变。全语料 53 对「两端都读得出」全部相同。\n"
        "剩下那一半（跨归零）量到 17 对、17 对都没换头（runs/…/try_gate_end.py），但它依赖历史，"
        "**单条转移判不了，所以不写进断言，也不许被当成册子说过的话**。规划器里它只用来挑路线；"
        "真正押出去的每一步都断在归零那一步之前（_cut），用的是当场观测到的方向。")
EVIDENCE = [
    "0a4c3a9ad5affeed", "865731f63e00506b", "72e5db38ff1101f0",
    "0731b68bf23f3eb7", "5cc693ddee72cfbe", "daefa3cfa49d905c",
]

from _lib import gate_bars, pieces


def _covered(g):
    ps = pieces(g)
    return set().union(*ps) if ps else set()


def assert_(prev, action, nxt, ctx=None):
    if action == "RESET" or action == 0:
        return "NA"
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    skip = _covered(prev) | _covered(nxt)
    after = {bar["cells"]: bar for bar in gate_bars(nxt)}
    verdict = "NA"
    for bar in gate_bars(prev):
        if bar["cells"] & skip or bar["axis"] is None:
            continue
        b = after.get(bar["cells"])
        if b is None or b["axis"] is None:
            continue
        if (b["axis"], b["dir"]) != (bar["axis"], bar["dir"]):
            return "FALSE"
        verdict = "TRUE"
    return verdict
