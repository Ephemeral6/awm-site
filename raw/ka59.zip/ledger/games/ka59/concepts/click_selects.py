"""ACTION6:A,B 把被操纵的对象换成包围盒含 (行B, 列A) 的那个物体；点在空处则不换。

坐标序是 (列, 行)：全语料 242 次 ACTION6 里有 50 次真的换了对象，
读成 (列,行) 命中 50 次，读成 (行,列) 只命中 1 次。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6；换关那一帧 NA；prev 或 next 的 me_box 判不出来 NA；"
         "两帧数出来的物体个数不一致 NA")
NOTE = ("v1：另一半（点在空处 → 选中不变）也一起断言了，全语料里这一半占 192 次。"
        "点在物体的哪个部位都算数 —— 见过点在包围盒角上的（step 80 点 (行30,列43)，"
        "而那个物体的包围盒是 行30-32 列42-44，角格也生效），所以判据取「落在包围盒里」"
        "而不是「落在核心上」。")
EVIDENCE = [
    "b77511dd4fb95236",   # step 80 ACTION6:43,31 选中从 列24-26 换到 列42-44
    "6f99f5e15b2cfa94",   # step 81 ACTION6:25,31 又换回去
]

from _lib import me_box, objects, object_cells, piece_paint, box_cells, PLACED


def _xy(action):
    if not (isinstance(action, str) and action.startswith("ACTION6:")):
        return None
    try:
        a, b = (int(v) for v in action.split(":")[1].split(","))
    except ValueError:
        return None
    return (b, a)                      # (行, 列)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    rc = _xy(action)
    if rc is None:
        return "NA"
    r, c = rc
    before, after = me_box(prev), me_box(nxt)
    if before is None or after is None:
        return "NA"
    boxes = objects(prev)
    if len(boxes) != len(objects(nxt)):
        return "NA"
    hit = [b for b in boxes if b[0] <= r <= b[1] and b[2] <= c <= b[3]]
    want = hit[0] if hit else before
    return "TRUE" if after == want else "FALSE"


def apply(prev, action, ctx=None):
    """换对象这一步物体一个都没挪，变的只是两个物体的外观：
    新选中的整个画出来（核心色0，外壳色14，贴着谁就按 contact_face 点亮哪条边）；
    原先那个卸任，接触高亮跟着灭 —— 除核心外整圈都回到外壳色14，**核心变色4**
    （语料里 209 次卸任，核心一次不落全变成色4，不管它嵌没嵌进框里；
      色5 因此是「还没被选中过」，不是「此刻没被选中」）。
    点在空处（选中不变）时一句不说：那一步什么都没变，说了也不解释任何东西。"""
    rc = _xy(action)
    if rc is None:
        return None
    r, c = rc
    old = me_box(prev)
    if old is None:
        return None
    boxes = objects(prev)
    hit = [b for b in boxes if b[0] <= r <= b[1] and b[2] <= c <= b[3]]
    if not hit or hit[0] == old:
        return None
    new = hit[0]
    out = dict(piece_paint(prev, old, False, set(), PLACED))
    occ = object_cells(prev, boxes) - box_cells(new)
    out.update(piece_paint(prev, new, True, occ))
    return out
