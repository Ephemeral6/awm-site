"""被顶出去的物体落到谁头上，谁就朝同向让开——让到刚好不重叠、且自己也不压色15 带为止；
所以一次推之后整张物体表就是：贴边那个走 kick，被压到的挨个让开，其余原地不动。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1/2/3/4，且这一步被操纵物体确实贴着别人（face_lit）；"
         "换关那一帧 NA；prev 或 next 的 me_box 判不出来 NA；"
         "两帧数出来的物体个数不一致 NA。这条断言的是整张表，比 push_kick 强。")
NOTE = ("v1：语料里只有第 821、826 步两次真的发生了连锁，两次让开的都是 1 个格位，"
        "「最少的格位」因此只在 1 上验过；让开的那个再撞墙/再压带的局面一次都没见过。"
        "连锁用的是先到先服务的队列，没见过一次推带动三个以上的物体。")
EVIDENCE = [
    "becb972500097816",   # step 821 被推的 1×1 走 6 个格位，压到 2×1，后者朝左让 1 个格位
    "50bccf136fd563f8",   # step 826 被推的 2×2 走 9 个格位，压到 2×1，后者朝左让 1 个格位
    "d8f516c905adfb4e",   # step 43  没有连锁：推完只有被推那个动了
    "6d902194ce254233",   # step 449 没有连锁
]

from _lib import (me_box, face_lit, objects, pushed_next, act_id, DELTA,
                  box_cells, gate_strike_hit, object_cells, piece_paint, solving,
                  boxes_next, under, core_travel)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d = act_id(action)
    if d not in DELTA:
        return "NA"
    box = me_box(prev)
    if box is None or me_box(nxt) is None:
        return "NA"
    if not face_lit(prev, box, d):
        return "NA"
    before, after = objects(prev), objects(nxt)
    if len(before) != len(after):
        return "NA"
    moved = pushed_next(prev, d)
    if not moved:
        return "NA"
    want = {moved.get(b, b) for b in before}
    return "TRUE" if want == set(after) else "FALSE"


def apply(prev, action, ctx=None):
    """整张表定死了，被带动的那几个物体长什么样就也定死了：把它们画到各自的落点上，
    核心色照抄它挪动之前那几格（核心色是物体身上的东西，挪动不改它）；
    再把原地不动的推手按新的邻居重画一遍（它贴着的人跑了，接触高亮要跟着灭）。
    动了的物体腾出来的格子按 under 还原成框壁或背景。
    没被带动的物体不画：它们本来就没变，说了也不解释任何东西。
    换关那一帧整屏重画，一句都不说。"""
    d = act_id(action)
    if d not in DELTA:
        return None
    box = me_box(prev)
    if box is None or gate_strike_hit(prev, d) is not None:
        return None
    if not face_lit(prev, box, d):
        return None                      # 没贴着别人：这一步没人被推，归 core_step 说
    if solving(prev, action):
        return None
    moved = pushed_next(prev, d)
    if not moved:
        return None
    after, nb = boxes_next(prev, action)
    if after is None or nb != box:
        return None
    vacated = set()
    for b in moved:
        vacated |= box_cells(b)
    for b in after:
        vacated -= box_cells(b)
    out = under(prev, vacated, [box_cells(b) for b in moved.values()])
    for old, new in list(moved.items()) + [(nb, nb)]:
        occ = object_cells(prev, [x for x in after if x != new]) - box_cells(new)
        core = None if new == nb else core_travel(prev, old, new)
        out.update(piece_paint(prev, new, new == nb, occ, core))
    return out
