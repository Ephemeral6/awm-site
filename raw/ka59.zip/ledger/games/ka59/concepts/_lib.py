"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测记录：
    棋盘背景 色1，物体外壳 色14，HUD 在行63（色4=剩余预算，用掉的格变色0）。
    每个物体是一个**放大 3 倍**的基础形状：核心 a×b 的物体占 3a×3b，核心居中。
    实测过的：核心 1×1 → 物体 3×3；核心 1×2 → 3×6；核心 2×1 → 6×3；核心 2×2 → 6×6。
    核心颜色：色0 = 当前被操纵的那个物体，色5 = 从没被选中过，色4 = 之前选过又被放开。
    （早先读成「色4 = 已归位」是错的：关0 通关那一帧两个核心一个色0 一个色4，
      而色4 那个是第 80 步点过、第 81 步又点回去的那一个，跟它在不在框里无关。）

    **色0 不只出现在核心上**：被操纵物体贴住另一个物体的那一面，整条边会被涂成 色0
    （第133步底边贴下方物体→底行 000；第134步移上去贴上方物体→顶行 000；
     第135步把上方物体推走后顶行立刻变回 色14）。没被选中的物体不出现这种高亮。
    早先把 me() 写成「第一个色0 格」，读到的是接触高亮而不是核心 —— 那是 37 条反例的来源。
    再往后「四个方向都能撞到外壳」也不够：接触边会挡在核心和背景之间（第448步）。

    现在的取核判据（见 _selected_core）：候选核心是一块全色0 的矩形 R(a×b)，
    把它朝四周各扩 a 行 / b 列得到物体包围盒 B(3a×3b)，要求
      (1) B 整块只有 色0 和 色14；
      (2) 全帧的 色0 格都落在 B 里（同一时刻只有一个物体被选中）；
      (3) B 不和任何 色5 物体的包围盒相交。
    满足的候选取面积最大的那个。

几何工具从 geo 拿(`from geo import components, diff_sum, fold, moved`)，那里没有世界断言。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 3               # 实测：物体尺寸都是核心尺寸的 3 倍
PHASE = None           # 待实测:(行相位, 列相位)
DELTA = {              # 实测：四个方向动作各挪一个格位
    1: (-3, 0),        # 上
    2: (3, 0),         # 下
    3: (0, -3),        # 左
    4: (0, 3),         # 右
}

HUD_ROW = 63           # 实测：最后一行是预算条，不属于棋盘
BG = 1                 # 实测：棋盘背景
SHELL = 14             # 实测：物体外壳
SELECTED = 0           # 实测：被操纵物体的核心色（接触高亮也借用它）
IDLE = 5               # 实测：没被选中的物体的核心色
PLACED = 4             # 实测：归位后的核心色 / 也是空框与预算条的颜色

MAX_CORE = 3           # 假设：核心边长不超过 3（见过 1 和 2）
BLOCK = (2, 15)        # 实测：挡住**被操纵**物体的颜色
KICK = 5               # 实测 31/31：被推的物体最多朝同向走 5 个格位
STOP = (2,)            # 实测 31/31：只有硬墙（和画面边）挡得住被推的物体；色4 不挡（走满 5 格位穿过去过）
BAND = 15              # 实测：物体停不住在带子上 —— 落点压着带就接着同向滑到完全离开

_CACHE = {}


def _key(g):
    return tuple(tuple(row) for row in g)


def _cells(g, color):
    return [(r, c)
            for r in range(len(g)) if r != HUD_ROW
            for c in range(len(g[r])) if g[r][c] == color]


def _components(cells):
    """4-连通分量。"""
    todo, out = set(cells), []
    while todo:
        seed = todo.pop()
        comp, stack = {seed}, [seed]
        while stack:
            r, c = stack.pop()
            for nb in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if nb in todo:
                    todo.discard(nb)
                    comp.add(nb)
                    stack.append(nb)
        out.append(comp)
    return out


def _bbox_of_core(r0, r1, c0, c1):
    """核心矩形 → 物体包围盒（各方向扩出核心自身的边长）。"""
    a, b = r1 - r0 + 1, c1 - c0 + 1
    return r0 - a, r1 + a, c0 - b, c1 + b


def _idle_boxes(g):
    """每个色5 物体的包围盒。"""
    out = []
    for comp in _components(_cells(g, IDLE)):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        out.append(_bbox_of_core(min(rs), max(rs), min(cs), max(cs)))
    return out


def _overlap(a, b):
    return not (a[1] < b[0] or b[1] < a[0] or a[3] < b[2] or b[3] < a[2])


def _ring_lit_ok(g, B):
    """壳的**外圈**上出现的色0，只许整条边地出现 —— contact_face 的形状那一半。

    用来在「同一片色0 有好几种读法」时定夺。终局卡第 3542 步就栽在这里：
    一个 1x1 核的物体左边整条被接触高亮，于是核心那一格和高亮那一条里的中间那格
    都能当核心读，两种读法的包围盒都满足「盒内只有色0/色14」，面积又一样大，
    旧写法按扫描序取了左边那个 —— 整个物体读偏一列，落点跟着偏一列。
    真核心那一读里，壳上的色0 正好铺满左边一整条；假核心那一读里，色0 东一格西一格，
    没有任何一条边是整条的。全语料 962 个帧加这条只改了这一帧，没有一帧因此变成读不出来。

    只管外圈，不管壳的里层：contact_face 也只说外圈那四条边。"""
    r0, r1, c0, c1 = B
    sides = ([(r0, c) for c in range(c0, c1 + 1)],
             [(r1, c) for c in range(c0, c1 + 1)],
             [(r, c0) for r in range(r0, r1 + 1)],
             [(r, c1) for r in range(r0, r1 + 1)])
    ring, lit = set(), set()
    for s in sides:
        ring |= set(s)
        if all(g[r][c] == SELECTED for (r, c) in s):
            lit |= set(s)
    return all((r, c) in lit for (r, c) in ring if g[r][c] == SELECTED)


def _selected_core(g):
    """被操纵物体的核心矩形 (r0, r1, c0, c1)；判不出来返回 None。"""
    k = _key(g)
    if k in _CACHE:
        return _CACHE[k]
    ans = None
    zeros = _cells(g, SELECTED)
    if zeros:
        zset = set(zeros)
        idle = _idle_boxes(g)
        R, C = len(g), len(g[0])
        best_area = 0
        for (r0, c0) in zeros:
            for a in range(1, MAX_CORE + 1):
                r1 = r0 + a - 1
                for b in range(1, MAX_CORE + 1):
                    c1 = c0 + b - 1
                    if a * b <= best_area:
                        continue
                    if any((r, c) not in zset
                           for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)):
                        continue
                    B = _bbox_of_core(r0, r1, c0, c1)
                    if B[0] < 0 or B[2] < 0 or B[1] >= min(R, HUD_ROW) or B[3] >= C:
                        continue
                    if any(g[r][c] not in (SELECTED, SHELL)
                           for r in range(B[0], B[1] + 1) for c in range(B[2], B[3] + 1)):
                        continue
                    if any(not (B[0] <= r <= B[1] and B[2] <= c <= B[3]) for r, c in zeros):
                        continue
                    if any(_overlap(B, ib) for ib in idle):
                        continue
                    if not _ring_lit_ok(g, B):
                        continue
                    best_area = a * b
                    ans = (r0, r1, c0, c1)
    _CACHE[k] = ans
    return ans


def me(g):
    """被操纵物体的核心左上角。判不出来返回 None。"""
    core = _selected_core(g)
    return None if core is None else (core[0], core[2])


def me_box(g):
    """被操纵物体的包围盒 (r0, r1, c0, c1)。判不出来返回 None。"""
    core = _selected_core(g)
    return None if core is None else _bbox_of_core(*core)


def me_shape(g):
    """被操纵物体的核心尺寸 (行数, 列数)。判不出来返回 None。"""
    core = _selected_core(g)
    return None if core is None else (core[1] - core[0] + 1, core[3] - core[2] + 1)


def cores(g):
    """未被操纵物体的核心格集合（色5）。"""
    return frozenset(_cells(g, IDLE))


def touching(g):
    """被操纵物体正贴着别人的那些边：色0 里**不是**核心的格。"""
    core = _selected_core(g)
    if core is None:
        return frozenset()
    r0, r1, c0, c1 = core
    return frozenset((r, c) for r, c in _cells(g, SELECTED)
                     if not (r0 <= r <= r1 and c0 <= c <= c1))


def budget(g):
    """行63 里还剩几格色4 —— 步数预算。"""
    return sum(1 for c in range(len(g[HUD_ROW])) if g[HUD_ROW][c] == PLACED)


def walls(g):
    """阻挡格：色2（边框）与色15（带状区）。全语料实测——不贴边的方向动作里，
    目标带扫到色2 的 159 次、扫到色15 的 16 次全都没动；只扫到色1 的 114 次、
    扫到色1+色4（框壁）的 19 次全都动了。所以色4 的空框不挡路，物体能走进去。"""
    return frozenset((r, c)
                     for r in range(len(g)) if r != HUD_ROW
                     for c in range(len(g[r])) if g[r][c] in BLOCK)


def face(box, d):
    """包围盒朝 d 方向的那一条边上的格子。"""
    r0, r1, c0, c1 = box
    if d == 1:
        return [(r0, c) for c in range(c0, c1 + 1)]
    if d == 2:
        return [(r1, c) for c in range(c0, c1 + 1)]
    if d == 3:
        return [(r, c0) for r in range(r0, r1 + 1)]
    return [(r, c1) for r in range(r0, r1 + 1)]


def face_lit(g, box, d):
    """朝 d 那一面整条是色0 —— 即贴着另一个物体。"""
    return all(g[r][c] == SELECTED for r, c in face(box, d))


def sweep(g, box, d):
    """物体朝 d 挪一个格位时扫过的 3 排格子的坐标；越界/进 HUD 的用 None 占位。"""
    dr, dc = DELTA[d]
    sr, sc = dr // CELL, dc // CELL
    out = []
    for (r, c) in face(box, d):
        for k in range(1, CELL + 1):
            rr, cc = r + sr * k, c + sc * k
            if 0 <= rr < len(g) and rr != HUD_ROW and 0 <= cc < len(g[rr]):
                out.append((rr, cc))
            else:
                out.append(None)
    return out


def core_next(g, d):
    """被操纵物体的核心在动作 d 之后应该在哪。判不出来返回 None。"""
    box = me_box(g)
    cur = me(g)
    if box is None or cur is None or d not in DELTA:
        return None
    if face_lit(g, box, d):
        return cur                      # 贴着别人 —— 推的是别人，自己不动
    cells = sweep(g, box, d)
    if any(p is None for p in cells):
        return None                     # 扫出画面，没见过，不猜
    if any(g[r][c] in BLOCK for r, c in cells):
        return cur                      # 被色2/色15 挡住
    dr, dc = DELTA[d]
    return (cur[0] + dr, cur[1] + dc)


# ---- 整盘：所有物体、所有空框、被推物体的落点、什么算摆好 ----

def _solid_cores(g, color):
    """某个核心色的所有物体：核心是实心矩形，且 3 倍包围盒里除核心外全是外壳。
    空框的色4 轮廓是空心的，过不了「实心」这关；HUD 行本来就不看。"""
    out = []
    for comp in _components(_cells(g, color)):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        a, b = r1 - r0 + 1, c1 - c0 + 1
        if len(comp) != a * b or a > MAX_CORE or b > MAX_CORE:
            continue
        B = _bbox_of_core(r0, r1, c0, c1)
        if B[0] < 0 or B[2] < 0 or B[1] >= HUD_ROW or B[3] >= len(g[0]):
            continue
        if any(g[r][c] != SHELL
               for r in range(B[0], B[1] + 1) for c in range(B[2], B[3] + 1)
               if not (r0 <= r <= r1 and c0 <= c <= c1)):
            continue
        out.append(B)
    return out


def objects(g):
    """棋盘上所有物体的包围盒，被操纵的那个排在最前。判不出被操纵物体时它不在表里。"""
    out = []
    box = me_box(g)
    if box is not None:
        out.append(box)
    for color in (IDLE, PLACED):
        out.extend(_solid_cores(g, color))
    return tuple(out)


def _scan_slots(g, strict):
    """框的**内部**矩形。框是一圈色4，内部边长是 CELL 的整数倍；
    被物体盖住的边框格算数（物体压在框上时轮廓会缺口）；
    门色（色12/13）占着的那一段也算壁。
    strict=True：真色4 要占到整圈壁的一半以上 —— slots() 用这一档。
    strict=False：只要求**露在外面**的那些壁格全是真色4（门色除外），而且**四条边各自**（含四个角）
      至少露出一格真色4 —— 四条边都要有见证，是为了挡掉「整条边全被物体盖住」的赝品：
      关3 第 928 步一个裸十字压在十字框上，按矩形去凑，下沿全在它身子底下的那个 5×5 也能凑出来，
      而它的下沿其实是背景。四角算进相邻两条边（关3 第 914 步真框的左壁只有角上那一格露着）。
      而且裸物体（色11）压住的壁格也算「被盖住」—— 它不在 objects() 里，strict 那一档看不见它。
      框被物体几乎盖满时用这一档，见 buried_slots。

    写法：判据一个字没改，只是把「逐格走一圈边」换成**前缀和 + 行/列可用长度**，每个候选矩形 O(1)。
    起因是 settle 的 20s 批次预算：这个函数占了 core_step 结算耗时的 95%，闸因此关着。
    正确性靠全语料逐位对照（958 个不同的帧 × 两档，摘要一致）保住，见 runs/<run>/dbg_slots.py。"""
    covered = set()
    for B in objects(g):
        for r in range(B[0], B[1] + 1):
            for c in range(B[2], B[3] + 1):
                covered.add((r, c))
    if not strict:
        for p in bare_pieces(g):
            covered |= set(p)
    R, C = HUD_ROW, len(g[0])
    # 三张前缀和：ok=这一格当得起一段壁（真色4／门色／被盖住），pl=真色4，bad=真色4 而且没被盖住。
    # 再加两张「从这里往右／往下连着多少格 ok」，用来把绝大多数候选矩形一眼掐掉。
    okp = [[0] * (C + 1) for _ in range(R + 1)]
    plp = [[0] * (C + 1) for _ in range(R + 1)]
    bdp = [[0] * (C + 1) for _ in range(R + 1)]
    runr = [[0] * (C + 1) for _ in range(R)]
    okg = []
    for r in range(R):
        row = g[r]
        o = [0] * C
        rr = runr[r]
        so = sp = sb = 0
        okp0, okp1 = okp[r], okp[r + 1]
        plp0, plp1 = plp[r], plp[r + 1]
        bdp0, bdp1 = bdp[r], bdp[r + 1]
        for c in range(C):
            v = row[c]
            pl = 1 if v == PLACED else 0
            cov = (r, c) in covered
            ok = 1 if (pl or v in GATE or cov) else 0
            o[c] = ok
            so += ok
            sp += pl
            sb += 1 if (pl and not cov) else 0
            okp1[c + 1] = okp0[c + 1] + so
            plp1[c + 1] = plp0[c + 1] + sp
            bdp1[c + 1] = bdp0[c + 1] + sb
        for c in range(C - 1, -1, -1):
            rr[c] = rr[c + 1] + 1 if o[c] else 0
        okg.append(o)
    rund = [[0] * C for _ in range(R + 1)]
    for r in range(R - 1, -1, -1):
        o, cur, nxt = okg[r], rund[r], rund[r + 1]
        for c in range(C):
            cur[c] = nxt[c] + 1 if o[c] else 0

    def _sum(p, r0, r1, c0, c1):
        return p[r1 + 1][c1 + 1] - p[r0][c1 + 1] - p[r1 + 1][c0] + p[r0][c0]

    found = []
    sides = [CELL * k + 2 for k in range(1, MAX_CORE + 1)]
    starts = [[c for c in range(C) if runr[r][c] >= sides[0]] for r in range(R)]
    for h in sides:
        for w in sides:
            ring = 2 * w + 2 * (h - 2)
            for r0 in range(R - h + 1):
                r1 = r0 + h - 1
                top, bot = runr[r0], runr[r1]
                dn = rund[r0]
                for c0 in starts[r0]:
                    if c0 + w > C or top[c0] < w or bot[c0] < w:
                        continue
                    c1 = c0 + w - 1
                    if dn[c0] < h or dn[c1] < h:
                        continue            # 四条边都连得起来 = 整圈壁都当得起壁
                    ir0, ir1, ic0, ic1 = r0 + 1, r1 - 1, c0 + 1, c1 - 1
                    if _sum(okp, r0, r1, c0, c1) - _sum(okp, ir0, ir1, ic0, ic1) != ring:
                        continue
                    real = _sum(plp, r0, r1, c0, c1) - _sum(plp, ir0, ir1, ic0, ic1)
                    if strict:
                        if real * 2 < ring:
                            continue
                    else:
                        if not (_sum(plp, r0, r0, c0, c1) and _sum(plp, r1, r1, c0, c1)
                                and _sum(plp, r0, r1, c0, c0) and _sum(plp, r0, r1, c1, c1)):
                            continue
                    if _sum(bdp, ir0, ir1, ic0, ic1):
                        continue
                    found.append((ir0, ir1, ic0, ic1))
    # 只留极大的那些。物体摆进框里之后，它自己的格子会把一堆子矩形也撑成「合法的框」——
    # 壁上一半是真色4（真框的边），另一半被物体盖住，逐条看都合格。这些假框全都包在真框里面，
    # 不删它们的话，同一关的「空框集合」会随着摆进去几个物体而变大，all_placed 再也满足不了。
    uniq = set(found)
    return tuple(sorted(h for h in uniq
                        if not any(o != h and o[0] <= h[0] and h[1] <= o[1]
                                   and o[2] <= h[2] and h[3] <= o[3] for o in uniq)))


def slots(g):
    """空框的**内部**矩形：真色4 占到壁的一半以上的那一档，免得三条门带自己围出一堆假框。
    all_placed / level_solved 用的是这一个，读法一个字没动。"""
    return _scan_slots(g, True)


def buried_slots(g):
    """几乎被物体盖满的框：露在外面的壁格全是真色4（门色不算），至少露两格。
    只给 under 用 —— 一个物体压在框上时，它挪走之后露出来的是壁的色4，
    而这种框在 slots() 那一档里因为真色4 不够一半被判掉（关3 第 914 步：
    一个裸十字盖住了 16 格壁里的 13 格）。
    **不拿它当「空框」**：这一档松，赝品会多，而 all_placed 是过关判据，宁可漏不可错。"""
    return _scan_slots(g, False)


def strip(box, d, k=1):
    """包围盒朝 d 外侧第 k 层的那一排格（k=1 就是紧贴的一排）。"""
    r0, r1, c0, c1 = box
    if d == 1:
        return [(r0 - k, c) for c in range(c0, c1 + 1)]
    if d == 2:
        return [(r1 + k, c) for c in range(c0, c1 + 1)]
    if d == 3:
        return [(r, c0 - k) for r in range(r0, r1 + 1)]
    return [(r, c1 + k) for r in range(r0, r1 + 1)]


def _blocked(g, cells, colors, others):
    for (r, c) in cells:
        if not (0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r])):
            return True
        if g[r][c] in colors:
            return True
        if any(o[0] <= r <= o[1] and o[2] <= c <= o[3] for o in others):
            return True
    return False


def _shift(box, d, k=1):
    dr, dc = DELTA[d]
    return (box[0] + dr * k, box[1] + dr * k, box[2] + dc * k, box[3] + dc * k)


def _overlap(a, b):
    return not (a[1] < b[0] or a[0] > b[1] or a[3] < b[2] or a[2] > b[3])


def ahead(g, box, d):
    """box 朝 d 迈一个格位要占的那一片格子（深 CELL）；出界/进 HUD 的用 None 占位。"""
    out = []
    for k in range(1, CELL + 1):
        for (r, c) in strip(box, d, k):
            out.append((r, c) if (0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r])) else None)
    return out


def _wall_ahead(g, box, d):
    """朝 d 迈这一步会撞墙或出界吗。"""
    cells = ahead(g, box, d)
    return any(p is None or g[p[0]][p[1]] in STOP for p in cells)


def on_band(g, box):
    """包围盒压着色15 带子吗。"""
    for r in range(box[0], box[1] + 1):
        for c in range(box[2], box[3] + 1):
            if 0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r]) and g[r][c] == BAND:
                return True
    return False


def kick(g, box, d, others=()):
    """被推物体的落点，两段：
    1) 先朝 d 走 KICK 个格位，中途要撞硬墙/出界就停在那儿（色4、别的物体都不挡 ——
       31 次推里色4 挡在第 5 格位上仍然走满了，被压上的物体是让开而不是挡住）；
    2) 落点若压着色15 带，接着同向滑，直到完全离开带子（物体停不住在带上）。
    `others` 留着只为兼容老签名，不参与判断。"""
    b = box
    for _ in range(KICK):
        if _wall_ahead(g, b, d):
            return b
        b = _shift(b, d)
    for _ in range(len(g)):                        # 滑出带子；滑不出去又撞墙：没见过，就停在那儿
        if not on_band(g, b):
            break
        if _wall_ahead(g, b, d):
            break
        b = _shift(b, d)
    return b


def _make_way(g, box, land, d):
    """落点压到了 box：box 朝同向让开最少的格位，让完还压着带就再滑出带子。"""
    b = box
    for _ in range(len(g)):
        if not _overlap(b, land) and not on_band(g, b):
            break
        if _wall_ahead(g, b, d):
            break
        b = _shift(b, d)
    return b


def pushed_next(g, d):
    """动作 d 之后，被带动的那些物体各自的落点：{原包围盒: 新包围盒}。没推着谁就是空表。
    贴着推手的那个按 kick 走；落到谁头上，谁就朝同向让开（可以连锁）。"""
    box = me_box(g)
    if box is None:
        return {}
    outer = strip(box, d)
    all_boxes = objects(g)
    pos = {b: b for b in all_boxes}                # 原包围盒 → 现在在哪
    queue = []
    for b in all_boxes:
        if b == box:
            continue
        if any(b[0] <= r <= b[1] and b[2] <= c <= b[3] for r, c in outer):
            pos[b] = kick(g, b, d)
            queue.append(b)
    seen = 0
    while queue and seen < 4 * len(all_boxes) + 4:
        seen += 1
        src = queue.pop(0)
        land = pos[src]
        for other in all_boxes:
            if other is src or other == src or other == box:
                continue
            if _overlap(pos[other], land):
                pos[other] = _make_way(g, pos[other], land, d)
                queue.append(other)
    return {b: pos[b] for b in all_boxes if pos[b] != b}


def all_placed(boxes, holes):
    """每个空框内部都被某个物体正好占满 —— 物体和框可以互换，只看占没占上。"""
    return set(holes) <= set(boxes)


# ---- 不是矩形的物体：关2 起出现没有外壳的色11 十字块 ----

BARE = (11,)           # 实测（第 855 步进关2 才第一次出现）：没有外壳的物体色


def bare_pieces(g):
    """裸物体（没有色14 外壳的那种）：每个是它占的格子集合。"""
    out = []
    for color in BARE:
        for comp in _components(_cells(g, color)):
            out.append(frozenset(comp))
    return tuple(out)


def box_cells(box):
    return frozenset((r, c) for r in range(box[0], box[1] + 1) for c in range(box[2], box[3] + 1))


def pieces(g):
    """棋盘上所有物体，一律用「占了哪些格」表示：带壳的就是整个包围盒，裸的就是那一片连通格。
    十字形的框和物体用包围盒是描述不了的，所以摆没摆好这件事只能按格子集合算。"""
    return tuple([box_cells(b) for b in objects(g)] + list(bare_pieces(g)))


def rim(cells):
    """一片格子紧贴外侧的一圈（4-邻域）。"""
    s = set(cells)
    out = set()
    for (r, c) in s:
        for p in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
            if p not in s:
                out.add(p)
    return out


GATE = (12, 13)        # 实测（第 934 步进关4 才第一次出现）：两色拼成的长条，长在框壁该在的位置上


def gate_cells(g):
    """帧上所有门格（色12 或色13）。"""
    out = set()
    for color in GATE:
        out |= set(_cells(g, color))
    return out


def gate_bars(g):
    """帧上每一条门带（色12 和色13 连通成的一整块）拆开看：
        cells   它占的格子
        box     包围盒
        axis    'row' = 色12 按整行一层层长；'col' = 按整列。整条同色时判不出来，为 None
        dir     +1 = 朝行/列号大的那头长，-1 = 反过来（色12 现在占着的那一头是起点）
        unit    一层有几格（axis='row' 时是带宽，'col' 时是带高）
        slices  整条一共几层
        filled  现在有几层是色12
        wrap    再长一层就长满了 —— 下一个动作会归零的意思
    这里只是把像素拆成数，「一个动作长一层、长满归零」那句话是 gate_tick 在断言。
    被物体压住的带子读出来会缺格，用它的概念要自己把那种帧排掉。"""
    cells = gate_cells(g)
    out = []
    for comp in _components(cells):
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        H, W = r1 - r0 + 1, c1 - c0 + 1
        if len(comp) != H * W:                      # 不是实心长方块：没见过，不拆
            continue
        hot = {(r, c) for (r, c) in comp if g[r][c] == 12}
        axis = dir_ = None
        rows12 = {r for r, _ in hot}
        cols12 = {c for _, c in hot}
        if hot and len(hot) == len(rows12) * W and len(hot) != len(comp):
            axis, unit, slices = "row", W, H
            dir_ = 1 if min(rows12) == r0 else -1
        elif hot and len(hot) == H * len(cols12) and len(hot) != len(comp):
            axis, unit, slices = "col", H, W
            dir_ = 1 if min(cols12) == c0 else -1
        else:
            unit, slices = (W, H) if H >= W else (H, W)
        out.append({"cells": frozenset(comp), "box": (r0, r1, c0, c1),
                    "axis": axis, "dir": dir_, "unit": unit, "slices": slices,
                    "filled": len(hot) // unit if unit else 0,
                    "wrap": unit > 0 and len(hot) + unit == len(comp)})
    return sorted(out, key=lambda b: b["box"])


def gate_slice(bar, k):
    """带子从起点数第 k 层（k 从 0 起）的那些格子。判不出朝向时返回空集。"""
    r0, r1, c0, c1 = bar["box"]
    if bar["axis"] == "row":
        r = r0 + k if bar["dir"] == 1 else r1 - k
        return frozenset((r, c) for c in range(c0, c1 + 1))
    if bar["axis"] == "col":
        c = c0 + k if bar["dir"] == 1 else c1 - k
        return frozenset((r, c) for r in range(r0, r1 + 1))
    return frozenset()


def gate_dir(bar):
    """带子长的方向写成方向动作号（1上 2下 3左 4右）。判不出来返回 None。"""
    if bar["axis"] == "row":
        return 2 if bar["dir"] == 1 else 1
    if bar["axis"] == "col":
        return 4 if bar["dir"] == 1 else 3
    return None


def gate_front(bar, cells):
    """这片格子在不在带子「长过去的那一头」的前面：
    横跨了带子的宽度，而且整片都在带子那一端之外。判不出朝向时一律 False。"""
    r0, r1, c0, c1 = bar["box"]
    d = gate_dir(bar)
    if d is None or not cells:
        return False
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    if d in (1, 2):
        if max(cs) < c0 or min(cs) > c1:
            return False
        return min(rs) > r1 if d == 2 else max(rs) < r0
    if max(rs) < r0 or min(rs) > r1:
        return False
    return min(cs) > c1 if d == 4 else max(cs) < c0


def gate_faces(bar, cells):
    """比 gate_front 松一档：只看和带子重叠的那几列（横带则那几行），
    物体落在这些列上的格子是否全在带子长过去那一头之外；物体别的部分伸到带子旁边不算挡。
    十字形物体的横臂比带子高时 gate_front 判不在前面，而带子照样扫得到它——所以要这一档。"""
    r0, r1, c0, c1 = bar["box"]
    d = gate_dir(bar)
    if d is None or not cells:
        return False
    if d in (1, 2):
        sel = [r for r, c in cells if c0 <= c <= c1]
        if not sel:
            return False
        return min(sel) > r1 if d == 2 else max(sel) < r0
    sel = [c for r, c in cells if r0 <= r <= r1]
    if not sel:
        return False
    return min(sel) > c1 if d == 4 else max(sel) < c0


REACH = 3              # 实测：归零扫击只够到带子前方 3 个格位以内的物体（空隙 0/1/2 格位的 7 次全被扫走，
                       # 空隙 4 格位的那次纹丝不动——终局卡第 3741 步）。空隙 3 格位一次没见过：
                       # 「够到 3 个格位」和「够到 4 个格位」在语料上分不开，这里取和射程 STRIKE 同一个数，
                       # 理由只是少一个常数——空隙正好 3 格位的那一步会判它对不对。


def gate_gap(bar, box):
    """带子朝它长的那一头，到这个包围盒之间空着几行/几列（不含两头）。物体在带子后面或平齐时为负。"""
    r0, r1, c0, c1 = bar["box"]
    pr0, pr1, pc0, pc1 = box
    d = gate_dir(bar)
    if d == 2:
        return pr0 - r1 - 1
    if d == 1:
        return r0 - pr1 - 1
    if d == 4:
        return pc0 - c1 - 1
    return c0 - pc1 - 1


def _clear_between(g, bar, box):
    """带子朝它长的那一头，到这个包围盒之间，有没有挡路色（色2/色15）隔着；**而且物体在射程之内**
    （空隙不到 REACH 个格位）。两条都满足才 True —— 扫击的「正对着」就是这一条线，
    gate_strike_hit 和 gate_idle_strike 都从这里取。射程那一条是终局卡第 3741 步加的：
    空隙 4 个格位、中间干净，带子归零了物体却没动。"""
    if gate_gap(bar, box) >= REACH * CELL:
        return False
    r0, r1, c0, c1 = bar["box"]
    pr0, pr1, pc0, pc1 = box
    d = gate_dir(bar)
    if d in (1, 2):
        lo, hi = (r1 + 1, pr0 - 1) if d == 2 else (pr1 + 1, r0 - 1)
        cs = range(max(c0, pc0), min(c1, pc1) + 1)
        rs = range(lo, hi + 1)
    else:
        lo, hi = (c1 + 1, pc0 - 1) if d == 4 else (pc1 + 1, c0 - 1)
        rs = range(max(r0, pr0), min(r1, pr1) + 1)
        cs = range(lo, hi + 1)
    for r in rs:
        for c in cs:
            if not (0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r])):
                return False
            if g[r][c] in BLOCK:
                return False
    return True


def moved_cells(g, d):
    """动作 d 照常生效之后，被操纵物体占的那片格子；判不出来返回 None。
    就是 core_next 那条走法的格子集合版：核心没挪就是原地那片，挪了就是整片跟着挪一个格位。"""
    box = me_box(g)
    cur = me(g)
    if box is None or cur is None or d not in DELTA:
        return None
    nxt = core_next(g, d)
    if nxt is None:
        return None
    mine = box_cells(box)
    return mine if nxt == cur else shift_cells(mine, d)


def gate_strike_hit(g, d):
    """这一帧上「这一步就要归零、而且正对着被操纵物体」的那条门带；没有就 None。
    正对着 = 物体横跨带子的宽度、整片都在带子长过去的那一头，**而且中间没有挡路色隔着**。
    两条带同时对着它时也返回 None（没见过，不猜）。

    **量的是动作 d 照常生效之后的那片格子，不是 prev 上的那片**：第 1002 步物体在 prev 上还不在带子前方，
    按右走进去之后才在，而世界照样扫了它。d 判不出落点时退回 prev 上那片。
    这是个假设，不是事实：core_step 在这种步上让位、gate_strike 在这种步上开口，两条概念共用同一条线。"""
    box = me_box(g)
    if box is None:
        return None
    cells = moved_cells(g, d)
    if cells is None:
        cells = box_cells(box)
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    probe = (min(rs), max(rs), min(cs), max(cs))
    hit = [bar for bar in bars_after_push(g, d)
           if bar["wrap"] and gate_dir(bar) is not None
           and gate_front(bar, cells) and _clear_between(g, bar, probe)]
    return hit[0] if len(hit) == 1 else None


def bars_after_push(g, d):
    """动作 d 生效之后每条门带在哪：被操纵物体贴着推的那条按 kick_cells 搬家（gate_pushed 的走法），
    其余原地。返回的还是 gate_bars 那种字典，只换了 cells/box。
    给 gate_strike_hit 用：扫击「正对着谁」按带子**动作生效之后**的位置量 —— 这是 gate_strike v5
    「动作先算、再扫」那句话推到底：被推走的带子归零时，它扫的是它新位置前方的那片，不是老位置。
    语料里没有「推带子的那一步它正好归零」的转移（第 942 步推的那次带子才长到第 4 层），
    这是个假设：终局卡第 3747 步会考它。gate_idle_strike 仍按老位置量（它的证据里带子没被推过）。"""
    bars = gate_bars(g)
    box = me_box(g)
    if box is None or d not in DELTA:
        return bars
    outer = frozenset(strip(box, d))
    out = []
    for bar in bars:
        if bar["cells"] & outer:
            want = kick_cells(g, bar["cells"], d)
            if want != bar["cells"] and len(want) == len(bar["cells"]):
                rs = [r for r, _ in want]
                cs = [c for _, c in want]
                bar = dict(bar, cells=frozenset(want), box=(min(rs), max(rs), min(cs), max(cs)))
        out.append(bar)
    return out


def seated(g, cells, covered=()):
    """这一片格子外面紧贴的一圈全是色4 或门色（色12/色13）—— 也就是它正好嵌在一个框里。
    `covered` 里的格子（prev 上被别的物体盖着的）算通过：框壁被物体压住时读出来是外壳色。
    门色算框壁是关4 才提出的读法：那一关的框少了一段壁，缺口正好被一条色12/色13 的长条占着。"""
    for (r, c) in rim(cells):
        if not (0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r])):
            return False
        if g[r][c] == PLACED or g[r][c] in GATE or (r, c) in covered:
            continue
        return False
    return True


# ---- 同一条推法，改在「格子集合」上算：带壳的矩形和裸的十字走同一套 ----
# 对矩形物体，下面每个函数和上面按包围盒算的那一套逐格等价（挪一个格位新占的格子正好就是深 CELL 的那一片）；
# 区别只在非矩形物体：撞墙看的是它真会占到的格子，不看包围盒的空角。

def shift_cells(cells, d, k=1):
    dr, dc = DELTA[d]
    return frozenset((r + dr * k, c + dc * k) for (r, c) in cells)


def _in_board(g, r, c):
    return 0 <= r < len(g) and r != HUD_ROW and 0 <= c < len(g[r])


def wall_ahead_cells(g, cells, d):
    """这片格子朝 d 迈一个格位，新占的格子里有硬墙/出界吗。"""
    for (r, c) in shift_cells(cells, d) - frozenset(cells):
        if not _in_board(g, r, c) or g[r][c] in STOP:
            return True
    return False


def on_band_cells(g, cells):
    return any(_in_board(g, r, c) and g[r][c] == BAND for (r, c) in cells)


def kick_cells(g, cells, d):
    """被推物体的落点（格子集合版）：走 KICK 个格位，撞墙即停；落点压带就接着滑到离开带子。"""
    b = frozenset(cells)
    for _ in range(KICK):
        if wall_ahead_cells(g, b, d):
            return b
        b = shift_cells(b, d)
    for _ in range(len(g)):
        if not on_band_cells(g, b):
            break
        if wall_ahead_cells(g, b, d):
            break
        b = shift_cells(b, d)
    return b


def struck_cells(g, cells, d, k):
    """被闸带扫中的物体的落点：和 kick_cells 同一条走法，只把射程 KICK 换成 k。

    「同一条走法」是主张不是定义：撞色2 即停、落点压着色15 就接着滑到离开带子，这两条都是从推法上量出来的，
    这里宣称它们对「被带子扫」也成立。射程 k 由 gate_strike 给（它量出来的是「层数÷CELL」）。
    要推翻它，只需一条转移：被扫的物体停在了带子上，或者穿过了色2。"""
    b = frozenset(cells)
    for _ in range(k):
        if wall_ahead_cells(g, b, d):
            return b
        b = shift_cells(b, d)
    for _ in range(len(g)):
        if not on_band_cells(g, b):
            break
        if wall_ahead_cells(g, b, d):
            break
        b = shift_cells(b, d)
    return b


def make_way_cells(g, cells, land, d):
    b = frozenset(cells)
    for _ in range(len(g)):
        if not (b & land) and not on_band_cells(g, b):
            break
        if wall_ahead_cells(g, b, d):
            break
        b = shift_cells(b, d)
    return b


def pushed_pieces(g, d):
    """动作 d 之后所有物体（带壳的 + 裸的）各在哪：{原格子集合: 新格子集合}，只列动了的。
    贴着推手（被操纵物体朝 d 那一侧紧邻的一排格）的物体按 kick 走；落到谁头上谁让开，可连锁。
    裸物体也走这一套——这是 bare_pushed 的主张，被推翻了这里要跟着改。"""
    box = me_box(g)
    if box is None:
        return {}
    outer = frozenset(strip(box, d))
    mine = box_cells(box)
    allp = pieces(g)
    pos = {p: p for p in allp}
    queue = []
    for p in allp:
        if p == mine:
            continue
        if p & outer:
            pos[p] = kick_cells(g, p, d)
            queue.append(p)
    seen = 0
    while queue and seen < 4 * len(allp) + 4:
        seen += 1
        src = queue.pop(0)
        land = pos[src]
        for other in allp:
            if other == src or other == mine:
                continue
            if pos[other] & land:
                pos[other] = make_way_cells(g, pos[other], land, d)
                queue.append(other)
    return {p: pos[p] for p in allp if pos[p] != p}


def pieces_next(g, action):
    """动作之后所有物体的格子集合（无序）与被操纵的那个。判不出来返回 (None, None)。
    boxes_next 的格子集合版：裸物体也在表里，落点按 pushed_pieces 算。"""
    box = me_box(g)
    if box is None:
        return None, None
    mine = box_cells(box)
    before = pieces(g)
    if mine not in before:
        return None, None
    rc = click_rc(action)
    if rc is not None:
        hit = [p for p in before if rc in p]
        return before, (hit[0] if hit else mine)
    d = act_id(action)
    if d is None:
        return None, None
    moved = pushed_pieces(g, d)
    if moved:
        return tuple(moved.get(p, p) for p in before), mine
    cur = core_next(g, d)
    if cur is None:
        return None, None
    if cur == me(g):
        return before, mine
    nm = shift_cells(mine, d)
    return tuple(nm if p == mine else p for p in before), nm


# ---- 把上面几条合成一个转移函数：动作 → 下一帧的物体位置与选中对象 ----

def act_id(action):
    """动作记号 → 方向号 1-4；不是方向动作返回 None。
    语料里早期几步记的是裸数字串（装置后来才把记号归一成 ACTIONn），两种都认。"""
    if isinstance(action, int):
        return action if action in DELTA else None
    if isinstance(action, str):
        head = action[6:].split(":")[0] if action.startswith("ACTION") else action.strip()
        if head.isdigit() and int(head) in DELTA:
            return int(head)
    return None


def click_rc(action):
    """ACTION6:A,B → (行B, 列A)；不是点击返回 None。"""
    if not (isinstance(action, str) and action.startswith("ACTION6:")):
        return None
    try:
        a, b = (int(v) for v in action.split(":")[1].split(","))
    except ValueError:
        return None
    return (b, a)


def boxes_next(g, action):
    """动作之后所有物体的包围盒（无序）与被操纵的那个。判不出来返回 (None, None)。"""
    box = me_box(g)
    if box is None:
        return None, None
    before = objects(g)
    if box not in before:
        return None, None
    rc = click_rc(action)
    if rc is not None:
        hit = [b for b in before if b[0] <= rc[0] <= b[1] and b[2] <= rc[1] <= b[3]]
        return before, (hit[0] if hit else box)
    d = act_id(action)
    if d is None:
        return None, None                        # RESET 一类的记号：没见过它怎么动，不猜
    moved = pushed_next(g, d)
    if moved:                                    # 贴着别人：推别人，自己不动
        return tuple(moved.get(b, b) for b in before), box
    cur = core_next(g, d)
    if cur is None:
        return None, None
    a, b = core_shape(box)
    nb = _bbox_of_core(cur[0], cur[0] + a - 1, cur[1], cur[1] + b - 1)
    return tuple(nb if x == box else x for x in before), nb


def core_shape(box):
    """包围盒 → 核心尺寸（行,列）。"""
    return (box[1] - box[0] + 1) // CELL, (box[3] - box[2] + 1) // CELL


# ---- 把物体画回帧上：概念的 apply 靠它出逐格预测 ----

def solving(g, action):
    """这一步之后关卡就要往前走了吗 —— 判据同 level_solved：动作之后每个物体都嵌进了框里。
    换关那一帧整屏重画，谁都说不准，apply 在那儿一句都不该说。"""
    here = pieces(g)
    if not here:
        return False
    after, _ = pieces_next(g, action)
    if after is None:
        return False
    covered = set().union(*here)
    return all(seated(g, f, covered) for f in after)


def piece_sides(box):
    """包围盒的四条边：(边上的格子, 紧贴外侧的格子)。判「贴着谁」用它。"""
    r0, r1, c0, c1 = box
    yield [(r0, c) for c in range(c0, c1 + 1)], [(r0 - 1, c) for c in range(c0, c1 + 1)]
    yield [(r1, c) for c in range(c0, c1 + 1)], [(r1 + 1, c) for c in range(c0, c1 + 1)]
    yield [(r, c0) for r in range(r0, r1 + 1)], [(r, c0 - 1) for r in range(r0, r1 + 1)]
    yield [(r, c1) for r in range(r0, r1 + 1)], [(r, c1 + 1) for r in range(r0, r1 + 1)]


def core_cells(box):
    """物体的核心块。包围盒是核心各方向扩出核心边长（_bbox_of_core），所以核心就是居中的 (H/3)×(W/3)。"""
    a, b = core_shape(box)
    r0, c0 = box[0], box[2]
    return frozenset((r, c) for r in range(r0 + a, r0 + 2 * a) for c in range(c0 + b, c0 + 2 * b))


def object_cells(g, boxes=None):
    """「算物体」的格子：带壳物体的包围盒、裸物体、门带 —— contact_face 说贴着这三类才亮。
    boxes 给定时用它代替帧上读到的包围盒：动作之后物体挪了位置，贴着谁要按新位置算。"""
    out = set()
    for b in (objects(g) if boxes is None else boxes):
        out |= box_cells(b)
    for p in bare_pieces(g):
        out |= set(p)
    return out | gate_cells(g)


def _ring8(cells):
    """一片格子紧贴外侧的一圈，连四个角一起算。框壁就长成这样。"""
    s = set(cells)
    out = set()
    for (r, c) in s:
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                p = (r + dr, c + dc)
                if p not in s:
                    out.add(p)
    return out


def under(g, cells, landings=()):
    """物体从这些格子上挪走之后，露出来的是什么色。
    这一局里物体只压得住两样东西：框壁的色4，和背景色1 ——
    色2 边框和色15 带都挡路，物体走不上去。
    框壁从四头还原，因为一个物体正压在壁上时那几格读出来是物体色：
      · 空框走 slots()，它本来就把「被物体盖住的边框格」算进框里；
      · 快被盖满的框走 buried_slots()（松一档：露在外面的壁格全是真色4、四条边各有一格见证）——
        关3 第 914 步那个裸十字盖住了 16 格壁里的 13 格，slots() 那一档够不着；
      · 已经嵌进框里的物体（含裸的十字块），它紧贴的那一圈就是它那个框的壁 ——
        十字形的框前两档都找不到（那两个函数只找矩形），这一头补的正是它；
      · `landings`：这一步某个物体**要落到**的那片格子。它紧贴的一圈要是全是色4/门色/
        或者此刻正被物体压着，那它落的就是一个框，那一圈就是壁 —— 关3 第 928 步的十字框下沿
        整条压在十字自己身子底下，物体形状又不是矩形，前三档全够不着，只有从落点这一头看得见。
        **但这一圈不许穿过已经认出来的框肚子**：认出来的框肚子是已知的空地，
        一条壁不会长在空地上。不设这道卡，一个 3×6 的空框会被劈成两个 3×3 的框，
        物体在框里挪半格就把自己让出来的那半格说成壁（第 1380 步就是这么错的）。
      · **空着的、形状随便的框**（open_hollows）：一片露在外面的背景，紧贴的一圈全是色4/门色/被物体压着，
        那这片就是一个框的肚子、那一圈就是它的壁 —— 十字框空着、一个物体只是**从外面**靠在它拐角上时，
        前四头都够不着（终局卡第 3632 步：物体压着十字框的一个角，挪走后那一格露出色4，被说成了背景）。
        被压着的那几格是壁还是肚子，从一帧上分不开的只有一种情形：压着它的物体其实**坐在肚子里**
        （物体连同这片背景合起来正好嵌在一圈壁里）—— 那它压着的是肚子不是壁，这头就不认领它压的格。
    壁要连四个角一起算：框的角是斜着接上去的（关0 第 30 步、关2 第 884 步都是这么错的）。
    **门带压着的格子和物体压着的格子一样，底下也可能是壁**：上面五头本来就把「门色」和「被物体压着」
    并列当成壁的证据（ring 那道 all(...) 里两者同列），只是收尾时又被一句「门带不算壁」整体减掉了，
    于是「一条带子从框壁上被推走」这类步一律答背景 —— 终局卡第 3762 步就是这么错的：
    一个空着的十字框，右壁整条（3 格）压在门带底下，带子被推走后露出色4，被说成了背景。
    现在只减**没在挪的**门格（它们自己会被推走，那时再问）；正在腾出来的这条带子（就是 `cells`）
    底下露什么，照五头判。"""
    wall = set()
    hollow = set()
    for (r0, r1, c0, c1) in set(slots(g)) | set(buried_slots(g)):
        body = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
        wall |= _ring8(body)
        hollow |= body
    here = pieces(g)
    covered = set().union(*here) if here else set()
    for p in here:
        if seated(g, p, covered):
            wall |= _ring8(p)
    for land in landings:
        ring = _ring8(land)
        if not ring or ring & hollow:
            continue
        if all(_in_board(g, r, c) and (g[r][c] == PLACED or g[r][c] in GATE or (r, c) in covered)
               for (r, c) in ring):
            wall |= ring
    wall |= open_hollow_walls(g, here, hollow)
    wall -= gate_cells(g) - set(cells)
    return {(r, c): (PLACED if (r, c) in wall else BG) for (r, c) in cells}


def open_hollow_walls(g, here=None, hollow=()):
    """under 的第五头：空着的框（形状不限）的壁。
    帧上每一片 4-连通的背景（至少一个格位大），紧贴的一圈（连角）全是色4/门色/被物体压着，
    这一圈就是壁；但这一圈不许穿过已经认出来的框肚子（同 landings 那道卡），
    而且压在这一圈上的物体若和这片背景**合起来**正好嵌在一圈壁里（它坐在肚子里，压的是肚子），
    它压着的那几格不认领。返回认领的壁格集合。"""
    if here is None:
        here = pieces(g)
    covered = set().union(*here) if here else set()
    hollow = set(hollow)
    out = set()
    for comp in _components(_cells(g, BG)):
        if len(comp) < CELL * CELL:
            continue
        ring = _ring8(comp)
        if ring & hollow:
            continue
        if not all(_in_board(g, r, c) and (g[r][c] == PLACED or g[r][c] in GATE or (r, c) in covered)
                   for (r, c) in ring):
            continue
        claim = set(ring)
        for p in here:
            if p & ring and seated(g, comp | set(p), covered):
                claim -= set(p)
        out |= claim
    return out


def piece_paint(g, box, selected, occupied, core=None):
    """物体占的每一格该是什么色，**只写说得准的格**：
      · 核心：被操纵的是色0；没被操纵的看 `core` —— 给了就照着涂，没给就不写。
        （`core` 可以是一个色号，也可以是 {格: 色号}；调用方从别处知道这个核心该是什么色时才给，
        比如「核心色跟着物体走」或者「卸任就变色4」。）
      · 其余是外壳色14；边上的格子按 contact_face 改写：整条边紧贴着 occupied 里的东西就整条涂色0。
      · 越出画面那条边**不亮**（画面外没有可推的东西，contact_face v4 量的 8/8）；
        进 HUD 行那条边 contact_face 判 NA（没见过），所以它盖到的格子不写。
    occupied 里不该含这个物体自己。"""
    cc = core_cells(box)
    out = {}
    for (r, c) in box_cells(box):
        if (r, c) not in cc:
            out[(r, c)] = SHELL
        elif selected:
            out[(r, c)] = SELECTED
        elif isinstance(core, dict):
            if (r, c) in core:
                out[(r, c)] = core[(r, c)]
        elif core is not None:
            out[(r, c)] = core
    if not selected:
        return out
    lit, unknown = set(), set()
    for inner, outer in piece_sides(box):
        if any(r == HUD_ROW for (r, _) in outer):
            unknown |= set(inner)
        elif any((r, c) in occupied for (r, c) in outer):
            lit |= set(inner)
    for p in lit:
        out[p] = SELECTED
    for p in unknown:
        out.pop(p, None)
    return out


def core_travel(g, old, new):
    """物体从 old 挪到 new，新核心那几格该是什么色：照抄它在 old 上核心那几格的色。
    核心色是这个物体身上的东西（色5 没被选中过 / 色4 被选中过又卸任了），挪动不改它 ——
    语料里 166 次「非选中物体被推走」，核心色一次没变过。
    两头核心格数不一样（读歪了）时返回 None，调用方就别写核心那几格。"""
    a, b = sorted(core_cells(old)), sorted(core_cells(new))
    if len(a) != len(b):
        return None
    return {q: g[p[0]][p[1]] for p, q in zip(a, b)}


