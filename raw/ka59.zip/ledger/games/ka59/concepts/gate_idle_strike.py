"""门带归零的那一步，正对着它、中间没有挡路色隔着的**没被操纵**的物体，也被那条带子朝
「带子长过去的那个方向」推 3 个格位——和被操纵物体挨扫时同一条走法：撞色2 就停、
停在色15 上就接着滑到完全离开它。也就是说，扫击不挑对象，只挑位置。"""
LEVEL = "L6"
STRIKE = 3                                  # 和 gate_strike 同一个射程常数，来路同样没被约束住（见那条的 NOTE）
SCOPE = ("只看 ACTION1/2/3/4；换关那一帧 NA；me_box() 判不出来 NA；"
         "prev 上没有「这一步就要归零」的门带时 NA；"
         "归零的门带正前方（中间不隔色2/色15）一个非操纵物体都没有时 NA——那一步这条什么都不说；"
         "这样的物体不止一个时 NA（没见过，不猜）；"
         "只断言这一个物体的落点在不在 nxt 的物体表里；被操纵物体自己怎么动归 core_step/gate_strike，"
         "门带自己怎么变归 gate_tick")
NOTE = ("v2：v1 是空转的——_targets 用 gate_front 判「正前方」，而 gate_front 要求物体**整片**都在带子那一头之外；"
        "第 3480 步那个十字的横臂（行9-11）和带子（行6-11）平齐，min(rs)=9 不大于 r1=11，于是 v1 在自己唯一的"
        "证据上判 NA，settle 从没真考过它。换成 _lib.gate_faces：只看和带子重叠的那几列上的格子是否都在前方，"
        "横臂伸到带子旁边不算挡。gate_strike 那条照旧用 gate_front，它的五条证据都是矩形物体，两种读法一致。\n"
        "v1：这条是被第 3480 步逼出来的，在那之前册子里只有 gate_strike，而它从头到尾只量**被操纵**的物体"
        "（_lib.gate_strike_hit 拿的是 me_box/moved_cells）。第 3480 步上门带归零，正下方站着一个"
        "既没被操纵、也没被任何人推的裸十字，它照样朝下走了 3 个格位、落点压在色15 带上又滑了 1 个格位。"
        "bare_pushed 说「裸物体只在被推的那一步才动」，当场被同一条转移打死，那条因此缩到「归零步不管」。\n"
        "这条和 gate_strike 是同一句话的两半：扫击按位置生效，不按谁被选中。合成一条更省，"
        "但那样会把 gate_strike 已经积下的五条量表证据和这条全新的主张搅在一起，"
        "一旦其中半句错了就分不清是哪半句——所以分开写，各自挨打。\n"
        "只有一条转移撑着它。要推翻它，一步就够：归零那一步正前方的非操纵物体没动，或者没走满 3 个格位。")
EVIDENCE = ["a31b31fc4b9a3a60"]   # 第 3480 步 ACTION3：上门带归零，正下方的裸十字行9-17 → 行21-29（3 格位 + 滑出色15 带 1 格位）

from _lib import (DELTA, act_id, me_box, box_cells, pieces, gate_bars, gate_dir,
                  gate_faces, struck_cells, _clear_between, under)


def _targets(g):
    """这一帧上「这一步就要归零」的每条带子，正前方那些不是被操纵物体的物体。"""
    box = me_box(g)
    if box is None:
        return None
    mine = box_cells(box)
    out = []
    for bar in gate_bars(g):
        d = gate_dir(bar)
        if not bar["wrap"] or d is None:
            continue
        for p in pieces(g):
            if p == mine or not gate_faces(bar, p):
                continue
            rs = [r for r, _ in p]
            cs = [c for _, c in p]
            if not _clear_between(g, bar, (min(rs), max(rs), min(cs), max(cs))):
                continue
            out.append((p, d))
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    d0 = act_id(action)
    if d0 not in DELTA:
        return "NA"
    hits = _targets(prev)
    if hits is None or len(hits) != 1:
        return "NA"
    p, d = hits[0]
    want = struck_cells(prev, p, d, STRIKE)
    return "TRUE" if want in pieces(nxt) else "FALSE"


def apply(prev, action, ctx=None):
    d0 = act_id(action)
    if d0 not in DELTA:
        return None
    hits = _targets(prev)
    if hits is None or len(hits) != 1:
        return None
    p, d = hits[0]
    want = struck_cells(prev, p, d, STRIKE)
    if want == p:
        return None
    out = under(prev, p - want)             # 腾出来的格子：按 under 还原成框壁或背景
    src = sorted(p)
    dst = sorted(want)
    for (r0, c0), (r1, c1) in zip(src, dst):
        out[(r1, c1)] = prev[r0][c0]
    return out
