"""点面板按钮时，该色的每一团**各自**裁决：落点撞上**面板**的团原地不动，落点让得开的团照旧沿自己的长轴走 GROW 格——
世界**不**因为其中一团被面板挡住就整步拒绝。"""
LEVEL = "L2"
SCOPE = ("只看点中面板图标、且该色**至少有一团落点撞上面板、同时至少有一团让得开**的那些步；"
         "全部团都让得开返回 NA（那是 [every_blob_moves_on_its_own_axis] 的地盘）；"
         "全部团都被面板挡住也返回 NA（那时该问的是世界拒不拒，是 [refused] 的事）；"
         "**落点撞上「别的条」（另一色的身体或帽）一律返回 NA**——条撞条是推，不是挡，"
         "那是 [blocking_seg_is_pushed] / [chain_drags_downstream] 的地盘（见 NOTE 第 195 步）；"
         "换关返回 NA；blob_moves / click_panel 算不出来返回 NA；"
         "盘上有死物（obstacles 非空）返回 NA——推墙是另一套机构；"
         "**任何一处「谁动谁不动」读不唯一的局面返回 NA**："
         "同一团既撞面板又撞条、两团落点相交、两团移动前就叠着、"
         "或某团的落点压到另一团**不动**的身位上；"
         "被面板挡住的团里有正在缩的、或动的团有下游条要滑进来（bar_downstream 非空），一律 NA。")
NOTE = ("**这条概念是被一次押错逼出来的，而押错的方式很值钱：我押世界会整步拒绝，世界照做了大半。**\n"
        "第 509 步 3d0f607df0a5eb43（ACTION6:34,54）。事先押注写明：色11 的第五根条 D (48,50,19,47) "
        "右沿贴着面板边框，落点那 9 格是 2/4/9 面板色，而 [panels_static]（S=1.000 C=0.970 N=197）说面板格从不变，"
        "所以世界会整步拒绝，帧差只剩计数条那一格；并且据此推断 [refused_says_it_exactly] 会第一次说错。\n"
        "**实测帧差 37 格，逐格归属零剩余**：四根各长 GROW 到 长32（其中带尖那根另有旧尖位 1 格，"
        "9+9+9+10=37），D 原地不动、长仍 29，面板一格没变。\n"
        "所以那一注**两条主张都落空**：世界没整步拒绝；refused 说「不会拒」是对的，它没有说错，"
        "[refused_says_it_exactly] 也没有挨打。落空的是我，不是册子里那条最漂亮的概念。\n"
        "**真正被打翻的是一条我从来没写下来、因而从来没被打过分的话**："
        "「一个按钮驱动整色，所以世界要么让这一色全动、要么整步不动」。它藏在 "
        "[every_blob_moves_on_its_own_axis] 的 `_landing_clear` 里：那个函数只要**任何一团**的落点上有异色，"
        "就整个返回 False，于是 `_claim_boxes` 返回 None，assert_ 和 apply 一起 NA。"
        "**它不是判错，是闭嘴**——所以这一整片地盘至今零反例、零扣分，也零检验。"
        "这一步全册对 37 格帧差一句话说不出来，是 209 条转移里「一句没说」的 3 条之一。\n"
        "**同一条假话还花过一次真钱**：我据它算过一条路线的死刑判决（`runs/<run>/project5.py`），"
        "论证是「一个按钮驱动整色 → 五根永远等长 → 根条长到 35 就逼着 D 进列53 → 撞面板 → 几何上不可能」，"
        "于是改走一条要多按三下的替代路线。实测四根 32 / D 29，**不等长**，D 卡死后永远进不了面板，"
        "那条死刑判决的前提当场作废。**一条没走过闸的世界事实，先让册子瞎了一步，又让规划多绕了三下。**\n"
        "**它是怎么躲过检验的**：它不在任何一条概念的首行主张里，只在一个辅助函数的一处 `return False` 里。"
        "这正是技能里那句「藏在本局词汇里的假设从来没被评过分」的实例，只不过这次藏得更浅——"
        "藏在概念自己的私有 helper 里，比 `_lib` 还私密，连「词汇改了要重审」那条规矩都够不着它。\n"
        "**为什么单立一条而不是去改 v8**：那条概念的主张是「每一团各自动一次」，本来就没错；"
        "错的是它的闸门形状。但「有团被挡时其余照走」是一句**独立的、能被单独判错**的话，"
        "而且它现在只在一片全新的地盘上开口（至少一团被挡），和 v8 的地盘不交叠。"
        "先让它在影子册里吃满语料，再谈要不要动 v8 的 `_landing_clear`。\n"
        "**这条概念还欠一个更大的问题**：如果「被挡的团不动、其余照走」是完整的法则，"
        "那么第 349 步 bdf9e287ce42c227 那次**整步拒绝**（当时落点全干净）就得另有拒因，"
        "[refused] 的六种机构里那一条依然必要，per-bar 并不吞掉整步拒绝。"
        "所以这条概念的 SCOPE 明确把「全部团都让得开」排除在外——**不去声称我还没有证据的那一半**。\n"
        "\n**第一版当场被语料打成 26 条 FALSE，而打它的正是「被挡」这个词太宽。**\n"
        "第一版把「落点上有异色」一律算成被挡、那一团就不动。全去重语料 208 条 held-out 上"
        "TRUE 1 / FALSE 26 / NA 181，C=0.037（`runs/<run>/score_perbar.py`）。逐条看（`perbar_falses.out`）"
        "26 条分成两个原型：\n"
        "  · **25 条是 movers 0 / stayers 1**：单团色被判成「全体不动」，而世界动了。\n"
        "  · **1 条是 4 movers / 1 stayer**（第 350 步 483e4161735d64c1）：我判四团动一团停，"
        "而世界**整步没动**（实际帧差 1 格，只有计数条）。\n"
        "**解剖第 195 步 4956b524f70c86c1 定的性**（`perbar_frame.out`）：色8 那根条向上长，"
        "落点 (18~20, 45~47) 上摆着一根色11 条的身体和它的色3 帽。世界的回答不是「色8 被挡住」——"
        "而是**把那根色11 条整体顶上 3 行**（帧差 36 格：5→11 十五格、11→5 九格、11→8 六格、"
        "5→3 三格、3→8 三格）。\n"
        "**于是「挡」和「撞」是两回事，而且世界对它们的裁决相反**：\n"
        "  · 条撞条 = **推**，被撞的条让路（这是册子里 [blocking_seg_is_pushed] / "
        "[chain_drags_downstream] 早就管着的地盘，它们合起来认领 9660 格、P=1.000）；\n"
        "  · 条撞**面板** = **停**，撞的那一团自己不动，别的团照走（第 509 步）。\n"
        "第一版把两者混成一个词，于是在第一种情形上说了 26 次「不动」，每一次世界都动了。\n"
        "**这一版的改法是把「被挡」窄到面板**：落点格必须 `in_any(panel_boxes(g), rc)` 才算挡；"
        "只要有任何一团是撞在别的条上，整条概念返回 NA，把话让给推的那两条。"
        "**窄的代价明说**：地盘从「任何一团被挡」缩到「至少一团撞面板、且至少一团让得开」，"
        "检验面会小很多——但那 26 条本来就不是它的地盘，是它抢了别人的话又说错。\n"
        "**最该记的一句**：我拿一条**新观测**（第 509 步 D 不动）去推一条**普遍规则**（被挡就不动），"
        "而语料里早有 25 条反例在等着。**先问「这个词在全语料上判过没有」，再问「它是不是一条新规矩」**——"
        "这次是影子册替我问的，代价只是一次记分；要是直接进了 concepts/，它会当场关闸。")
EVIDENCE = ["3d0f607df0a5eb43"]

from _lib import (BG, GROW, TIP, bar_downstream, blob_moves, cells_in, cells_of,  # noqa: F401
                  click_panel, diamond_centers, diamond_dots, in_any, moved_box,
                  obstacles, panel_boxes)


def _split(g, action):
    """把该色的每一团分成「让得开」和「被面板挡住」两拨；读不唯一或算不出来返回 None。

    「被面板挡住」= 它新占的格子（new - old）里有既不是底色、也不是本色、也不是菱形四点、
    且**落在一个面板框里**的东西。口径上的三条边界都事先写明：
      · 落点被**别的条**挡住（另一色的身体或帽）→ 这不是本条概念的地盘，那是「条-条相撞 = 推」
        （blocking_seg_is_pushed / chain_drags_downstream 的事），这里整体返回 None，把话让给它们。
        实测第 195 步 4956b524f70c86c1：色8 长进色11 条，色11 被顶上 3 行——世界不是把色8 挡住，
        是把那头条推走。所以「被挡」必须窄到**面板**才成立。
      · 同一步里既撞面板又撞条 → 裁决顺序说不出来，返回 None。
      · 被面板挡住的那一团在缩（new < old）→ 语料里没见过，返回 None 不猜。
    """
    mv = blob_moves(g, action)
    cp = click_panel(g, action)
    if mv is None or cp is None:
        return None
    if obstacles(g):
        return None
    color = cp[0]
    dots = diamond_dots(g)
    boxes = panel_boxes(g)
    movers, stayers, bar_blocked = [], [], []
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        old = set(cells_in(box))
        new = set(cells_in(nb))
        blocked_panel = False
        blocked_bar = False
        for rc in new - old:
            if rc in dots:
                continue
            v = g[rc[0]][rc[1]]
            if v == BG or v == color:
                continue
            if in_any(boxes, rc):
                blocked_panel = True
            else:
                blocked_bar = True
        if blocked_panel and blocked_bar:
            return None           # 同时撞面板和条：这步谁让谁，说不出来
        if blocked_panel:
            if len(new) < len(old) or not (old <= new):
                return None       # 被面板挡住的那一团在缩：语料里没见过，不猜
            stayers.append((box, side, d))
        elif blocked_bar:
            bar_blocked.append((box, side, d))
        else:
            movers.append((box, side, d))
    if bar_blocked:
        return None               # 有条-条相撞：那是 push 概念的地盘，这条不开口
    if not stayers or not movers:
        return None               # 全让得开（v8 的地盘）或全被面板挡住（refused 的事），都不归这条
    # 「谁动谁不动」必须读得唯一：任何一处相交都说明这一步的裁决顺序我说不出来。
    news = [set(cells_in(moved_box(b, s, d))) for b, s, d in movers]
    olds = [set(cells_in(b)) for b, s, d in movers]
    stay_cells = [set(cells_in(b)) for b, s, d in stayers]
    for i in range(len(news)):
        for j in range(i + 1, len(news)):
            if news[i] & news[j] or olds[i] & olds[j]:
                return None
    for i, nw in enumerate(news):
        for sc in stay_cells:
            if (nw - olds[i]) & sc:
                return None       # 动的团要压到不动的团身上：这一步谁让谁，说不出来
    for b, s, d in movers:
        ds = bar_downstream(g, color, b)
        if ds is None or ds:
            return None           # 有下游要滑进来：那些格子填什么不归这条概念说（照 v7 的分工）
    return movers, stayers


def _claim(g, action):
    """这一步之后这条概念敢逐格说出颜色的那些格子；算不出来返回 None。"""
    sp = _split(g, action)
    cp = click_panel(g, action)
    if sp is None or cp is None:
        return None
    movers, _stayers = sp
    color = cp[0]
    dots = diamond_dots(g)
    centers = set(diamond_centers(g))
    out = {}
    for box, side, d in movers:
        nb = moved_box(box, side, d)
        old = set(cells_in(box))
        new = set(cells_in(nb))
        tps = [rc for rc in old if g[rc[0]][rc[1]] == TIP and rc not in dots]
        if len(tps) > 1:
            return None           # 一团两个尖：没见过的构型上闭嘴，照 v4 的规矩
        ntp = (tps[0][0] + d[0], tps[0][1] + d[1]) if len(tps) == 1 else None
        if ntp in centers:
            return None           # 尖落到菱形中心：那一步换关、整盘会变，这条概念不画
        for rc in new:
            if rc in dots:
                continue
            out[rc] = TIP if rc == ntp else color
        for rc in old - new:
            out[rc] = BG
        if len(tps) == 1 and tps[0] in new:
            out[tps[0]] = color
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cp = click_panel(prev, action)
    if cp is None:
        return "NA"
    sp = _split(prev, action)
    if sp is None:
        return "NA"
    claim = _claim(prev, action)
    if claim is None:
        return "NA"
    color = cp[0]
    dots = set(diamond_dots(prev))
    # 一、认领的每一格都得对上。
    for rc, v in claim.items():
        if nxt[rc[0]][rc[1]] != v:
            return "FALSE"
    # 二、本色格与尖格的**整个集合**都得对上——被挡那几团原样留着，别处不许多出一格本色。
    #     不动的团不在 claim 里，它们的格子从 prev 直接继承，所以「原地不动」这半句
    #     是被这个集合等式检验的，不是被假设掉的。
    pred_color = ({rc for rc in cells_of(prev, color) if rc not in claim}
                  | {rc for rc, v in claim.items() if v == color})
    pred_tip = ({rc for rc in cells_of(prev, TIP) if rc not in dots and rc not in claim}
                | {rc for rc, v in claim.items() if v == TIP})
    if set(cells_of(nxt, color)) != pred_color:
        return "FALSE"
    if {rc for rc in cells_of(nxt, TIP) if rc not in dots} != pred_tip:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    # 这条概念不借 refused() 当闸：它主张的正是「有团被挡时世界照样动」，
    # 而 refused() 的六种拒因里没有「面板挡路」这一种（第 509 步实测它说「不会拒」且说对了）。
    # 敢画就得敢错——画错了 settle 会逐格扣，这正是这条概念要买的检验面。
    return _claim(prev, action)
