"""这一步之后还有尖没落在菱形中心上，这一步就绝不换关。"""
LEVEL = "L5"
SCOPE = ("用 prev 与动作算出这一步之后各个尖的落点（只有被点那一节的尖动，位移 = 自由端位移）；"
         "算不出落点、盘上没有菱形中心，返回 NA；落点正好铺满所有菱形中心时返回 NA（正向那半条另写）。"
         "这条概念故意不因为换关而 NA——它要的就是换关那一刻。")
NOTE = ("v1 看的是动作**前**那一帧的尖，死于 228810ee4f309efd：换关就发生在最后一个尖到位的那一步上，"
        "那一步的 prev 本来就还有尖没到位，而 nxt 已经是新关的帧、无从查起。"
        "v2 改成看**这一步之后**的落点，靠 _lib.tips_after 从 prev+动作推。")
EVIDENCE = ["c9bf233145fe4d48", "228810ee4f309efd"]

from _lib import all_home, diamond_centers, tips_after


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    t_map = tips_after(prev, action)
    if t_map is None:
        return "NA"
    h = all_home(t_map, diamond_centers(prev))
    if h is None or h is True:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] else "FALSE"
