"""推不动那种死物（_lib.FIXED_OBS，本局是色 15）的格子集一格不变——不改色、不移位、不长不缩。"""
LEVEL = "L2"
SCOPE = ("任何动作都查；prev 里一个推不动的死物格也没有（第 0、1 关的色 15 有，第 0 关没有）返回 NA；换关返回 NA")
NOTE = ("v1 说的是「盘上**所有**死物一格都不改色，也不长不缩」，第 2 关当场双双挨打："
        "3c79fccbc0893691 与 e0f459332e57406b 上，被顶的色 1 死物整块平移了 3 格。"
        "所以 v2 缩到「推不动的那一种」。缩掉的那一半不是没人管了："
        "「被顶到的块整块平移、没被顶到的一格不动」由 pushable_obstacle_shifts 承担，"
        "「死物永远是刚体（同色、同形、块数格数不变）」由 obstacle_blobs_rigid 承担——"
        "一条概念死了，换成两条更细的，不是把地图上那一块抹掉。"
        "这条剩下的部分照样可判错：哪天一片色 15 被推走或被啃掉，它当场变反例；"
        "而 FIXED_OBS 是按颜色划的，颜色是眼下唯一手上有的判别量，所以这个划法本身也在受审。")
EVIDENCE = ["64e2bc30cd0e77bc", "3c79fccbc0893691", "e0f459332e57406b"]

from _lib import FIXED_OBS, obstacles


def _fixed(g):
    return {(r, c) for r, c in obstacles(g) if g[r][c] in FIXED_OBS}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a = _fixed(prev)
    if not a:
        return "NA"
    for r, c in a:
        if nxt[r][c] != prev[r][c]:
            return "FALSE"
    return "TRUE" if a == _fixed(nxt) else "FALSE"
