"""push_target 判定「让得开」时，贴在被推那一节自由端上、不是推不动死物（FIXED_OBS）的死物带子，
跟着被推那一节挪同一个位移；带子沿位移轴能长成的最长同色段（菱形四点算透明）整段一起走——
遇到另一根同色死物矩形十字交叉时，按厚度轴touch 的形状拆归属：两侧都探出算被贯穿，让给对方；
一侧探出但自己的纹理越过touch 区还在继续，算自己的；一侧探出、自己也在同一点耗尽（单帧看不出
归属的歧义角），再问一句——对方那条支臂顺着自己的方向追到远端尖，尖上钩没钩着真正的帽（CAP）：
钩着，对方是独立刚体，让给它；没钩着，按语料默认，算自己的，一起走。"""
LEVEL = "L6"
SCOPE = ("只看 push_target 非 None 且 push_target_block 判「让得开」（返回 {}）的步；"
         "push_target_block 为 None（算不出让不开）或非空（连环没到底）都返回 NA——那两片是"
         "[push_target] 自己和 [push_chain_blocked_refuses] 的地盘。"
         "被推那节自由端（free_face）上没贴着死物、或贴着的是 FIXED_OBS 里的颜色：返回 NA——"
         "这条概念不断言「不会被带走」，那句话没人验证过。"
         "自由端贴着的死物长不出一条 3 格厚、同色、菱形点透明的带子（_anchor_run 失败）："
         "返回 NA。换关返回 NA。\n"
         "**十字交叉的仲裁，明说仲裁不到的那一小片**：长带子时遇到另一根同色死物矩形垂直交叉，"
         "按 touch 的形状分四种情况：两侧都探出（crossed_both）——对方贯穿了自己，让给对方；"
         "一侧探出、自己的纹理越过 touch 区之后还在继续（passes_through）——那一段还是自己的；"
         "一侧探出、自己和 touch 同时在同一点耗尽——这一点在纯几何上是歧义角，_lib.rigid_unit 的"
         "文档里记过同一类『镜像歧义』（同一局部几何，世界一次判给横的一次判给竖的），单帧真的"
         "分不出来；这条概念在这一点上没有认输，而是多问一句：对方那条支臂顺着自己延伸的方向"
         "追到真正的远端尖，尖上有没有真正的帽（_lib.CAP，不是认某个具体颜色）——钩着真帽，"
         "对方是自己的独立刚体（自己有帽、自己的节），这一点让给对方；没钩着（悬空到背景），"
         "没有独立锚点，按语料里已验证过的默认，这一点算自己的，跟着走。"
         "**这道仲裁只在语料的 2 个歧义角样本上验证过**（bda3e01059155890 第175步、"
         "曾经因为 v1/v2 判据误判过的 b6f0ef03af8176dd 第143步），没有第三个独立样本；"
         "如果某一局出现『远端尖附近凑巧有一个不相关的帽，但那根支臂其实是悬空的』，这道仲裁"
         "会误判——这是明知的假阳来源，没有被 SCOPE 摘掉。")
NOTE = ("起因：`chain_drags_downstream` 在 b6f0ef03af8176dd（第 143 步）与 bda3e01059155890"
        "（第 175 步）上都判 NA——点色 9 的伸，`push_target` 说色 8 被推了，同时色 1 的死物带子也跟着挪了，"
        "但账本上没有一条概念开口。查下去发现这不是 `chain_drags_downstream` 的关系定义有一处能调的螺丝，"
        "是它结构性够不着：它的下游关系 `_lib.chain`/`downstream` 只在 `_lib.seg_colors` 枚举出的"
        "『节』之间建边，死物（`obstacles`）从一开始就不在这张图里，调关系式救不了，只能另写一条。\n"
        "**三轮判据，逐条留痕，不删**：\n"
        "  第一轮（denom 32）：只按『同色、菱形点透明』一路长到头，不做十字交叉仲裁——"
        "10 真阳 / 2 假阳（f4c051250f10554f 第171步、bda3e01059155890 第175步）/ 2 漏报 / 1 NA。\n"
        "  第二轮 v1（候选修法，没有留下来）：厚度轴任一侧探出同色就算贯穿——2 条假阳清零，"
        "但把 3 条真阳带成了假阳（a340269ae057f793、b6f0ef03af8176dd、49f951051932cc49），"
        "因为它们的touch 是『单侧touch、语料里观测到跟着一起被拖走』，不是『被贯穿』。\n"
        "  第二轮 v2（候选修法，没有留下来）：改成两侧都探出才算贯穿——3 条误伤的真阳救回来了，"
        "denom 32 到了 11 真阳 / 1 假阳 / 2 漏报 / 1 NA，但 bda3e01059155890 仍是假阳：它撞上的"
        "十字交叉在这一步这一帧只剩单侧touch（中间插了一次垂直推动 39a999d55cb87a2a 把同一根"
        "死物往上挪了 3 格，touch 的另一侧背景化了），『两侧都探出』看不到这种情况。\n"
        "  第二轮最终版（这条概念现在的写法）：单侧touch 且自己和touch 同时耗尽时，不直接认输，"
        "查对方支臂远端尖有没有真正的帽——钩着帽就排除，没钩着就按默认带走。"
        "这一步踩过一次轴写反的坑（拿自己带子的厚度当成了对方支臂的厚度）和一次窗口开太宽的坑"
        "（扫了对方支臂整条路径，被路径中段路过的一个固定装饰误判成『钩着帽』，"
        "改成只看真正的远端尖才对），都已经修掉。\n"
        "**最终三个数（denom 见下）**：语料是外部会话在同步追加的活文件——写这条概念时"
        "`transitions.jsonl` 冻结在前 335 行原始记录（这是产生 32 这个分母时的行数界限，"
        "之后追加的新记录不算），按 tid 去重后 156 条，关内转移 151 条；`push_target` 命中 "
        "43/151，其中『让得开』32 条、『连环没到底』11 条、算不出来 0 条——这条概念的分母是 32。\n"
        "  在这 32 条上：真阳 12/32（第一轮 10/32）、假阳 0/32（第一轮 2/32）、"
        "漏报 0/32（第一轮 2/32）、NA 1/32。\n"
        "**假阳怎么变成了 0，而不是缩 scope 躲开**：2 条假阳里，f4c051250f10554f 撞上的是"
        "两侧都探出的贯穿（crossed_both 直接判清楚，没有歧义），bda3e01059155890 撞上的是单侧"
        "touch 歧义角，靠上面『查对方支臂远端尖有没有真帽』这道新仲裁解开——它对方那条支臂"
        "（钩在rows18-20 一根有色12 躯干、色3 帽的真节上）远端尖有真帽，判定排除，"
        "预测框从 (33,35,18,44) 收窄成 (33,35,18,41)，变成真阳。第一轮的 10 条真阳一条没丢，"
        "还多收进了这一条，denom 32 上真阳从 10 涨到了 12——**没有靠缩 scope 躲开原来那两条假阳，"
        "两条都在 32 条的分母里被正面解开了**。\n"
        "**漏报怎么变成了 0，说清楚这不是这条概念的功劳**：b69538b54695cee2（第40步）、"
        "f466378a781eb4e4（第41步）这两条第一轮判『不贴死物/长不出带子，不开口』，残差各 9 格；"
        "这一轮重跑，残差算出来是 0 格——但这条概念在这两步上仍然是『不开口』（pred=[]），"
        "残差归零是 `blocking_seg_is_pushed` 与 `chain_drags_downstream` 两条已有概念的 apply() "
        "自己覆盖到了这 9 格，不是这条草稿新写的十字交叉仲裁起的作用。"
        "语料是活文件，这两条旧概念的覆盖范围会不会是在这段时间因为别的会话继续游玩而变了，"
        "没有查，也不在这条概念的职责范围内——**没有查这两条漏报的根因，这句话仍然成立，"
        "只是『漏报』这个标签目前摘掉了**，摘掉的原因写在这里，不是这条概念自己修复的。\n"
        "**推链长度**：`push_through` 32 条里最长链 = 3 环（click 被点节 -> push 被推节 -> drag 死物），"
        "达到 3 环的有 12 条（含上面 12 条真阳全部）；剩下 19 条是 2 环（click -> push，没有第三环，"
        "包括这条概念判 NA 或判『不贴死物』的步，加上这一轮两条漏报腾出来的名额）。"
        "没有观测到 4 环——待跑：语料里目前没有『死物再拖死物』的证据，不代表不存在，只是没找到。\n"
        "**反向核对**：`push_through` 这 32 条里，残差非空的转移这一轮是 12/32 条"
        "（第一轮是 14/32，少了的 2 条正是上面归零的两条旧漏报，两条已有概念自己覆盖到了）。"
        "在全部 `push_target` 非 None 的 43 条里，残差非空同样是 12/43（另外 11 条『连环没到底』"
        "里没有新增）。12 条 tid：4ec2a7843a686c1c、946cbe14eb9d9d3f、a340269ae057f793、"
        "b6f0ef03af8176dd、a682b09c2a243720、49f951051932cc49、f4c051250f10554f、"
        "39a999d55cb87a2a、bda3e01059155890、51e6aebc203c620d、a130d57773da985c、"
        "79c09378b0104b96——和上面 12 条真阳明细完全对上，残差全部归零。\n"
        "**不是新概念一说站得住吗**：站得住——不是因为改一处关系式救不了 `chain_drags_downstream`"
        "（上面已经说明这是结构性的，downstream 图里没有死物这一类对象），"
        "不是往它身上加一个 if 分支的量级。\n"
        "**没检验过的情形，明说**：菱形点落在带子中段以外（比如带子端点正好是菱形点）没有样本；"
        "自由端同时贴着两种以上颜色的死物只在语料里见过一种颜色的组合；带尖的节推死物没有样本"
        "（比照 blocking_seg_is_pushed 的处理，理论上该判 NA，但没在这条概念的代码里显式判过，"
        "因为 32 条语料里没撞到过）；**十字交叉的『远端尖钩真帽』这道仲裁只在 2 个歧义角样本上"
        "验证过，样本量太小**，没有第三个独立样本能确认它不是只是恰好对这两个样本都答对——"
        "SCOPE 里已经写明这是明知的假阳来源；第 3 关（195 步那一条）落在这条概念的 scope 之外"
        "还是之内没有单独验证——195 步在 push_through 32 条里，但没有把它单独拎出来核对是"
        "真阳、假阳、还是不贴死物。\n"
        "**EVIDENCE 收窄说明（settle 反馈后补记）**：原先把开口的全部 12 条真阳都塞进了 EVIDENCE，"
        "等于把这条概念的检验样本和依据样本合并成同一堆——held_out = 全部去重转移 − EVIDENCE，"
        "抄满 12 条会让这条概念在自己开口的地方全部被排除在检验之外，构造上就打不出分。"
        "现在只留下**真正撑起这条判据的样本**，按角色标注：\n"
        "  - `f4c051250f10554f`（第171步）：上一轮结算认定的首个反例——第一轮判据在这一步判了假阳，"
        "settle 已经把它记成这条概念的反例，无论后续判据怎么改都留着。\n"
        "  - `bda3e01059155890`（第175步）：反例 + 歧义角样本——第一轮假阳、v2（两侧都探出）仍是"
        "假阳，逼出了最终版的『远端尖钩帽』仲裁；同时是 SCOPE 里明说『仲裁只在 2 个歧义角样本上"
        "验证过』的样本之一。\n"
        "  - `b6f0ef03af8176dd`（第143步）：反例 + 歧义角样本——v1（任一侧探出就算贯穿）把它从"
        "真阳误判成假阳，逼出了 v2 的两侧夹击判据；也是 SCOPE 里那两个歧义角样本的另一个，"
        "验证了『远端尖没钩帽就按默认带走』这一半不会反过来误伤它。\n"
        "  - `a340269ae057f793`（第141步）：反例——同样被 v1 误伤成假阳，逼出 v2 的修正。\n"
        "  - `49f951051932cc49`（第162步）：反例——同样被 v1 误伤成假阳，逼出 v2 的修正。\n"
        "被拿掉的是其余 7 条纯确认样本（`4ec2a7843a686c1c`、`946cbe14eb9d9d3f`、`a682b09c2a243720`、"
        "`39a999d55cb87a2a`、`51e6aebc203c620d`、`a130d57773da985c`、`79c09378b0104b96`）——"
        "**拿掉不是因为它们判错，是因为确认样本进依据会让概念不可打分**：这几条在写判据的整个"
        "过程里从没逼着改过一次判断，判据不管走到哪一版都一直判对，它们是这条概念该去接受检验"
        "的地方，不是它依据的地方。\n"
        "**v2：终局卡上记了一次意外改的（第 2105 步 tid 1abf133f0f360214）。** 第 4 关的收口击 "
        "`ACTION6:42,57` 换了关，整盘重画 1224 格，本条的 apply 照常画了它那一片，押 1 实 5，错 54 格——"
        "这 54 格是这条概念一生说错的全部（P=0.982，认领 2951 格，说错 54）。"
        "**assert_ 那一侧本来就查 ctx 换关判 NA，SCOPE 里也白纸黑字写着「换关返回 NA」，"
        "生成器这一侧却查不到——押注的时候这一步还没走，ctx 里没有 level_next**，"
        "所以那道闸在 apply 上从来没生效过；也就是说 apply 一直在声称一片 assert_ 明确拒绝断言的地方。"
        "这已经是同一课第五次落地（bar_free_end_moves、bar_tip_follows、move_counter_row63、"
        "blocking_seg_is_pushed 各栽过一次），而且是**上一次留下的判据脚本 "
        "runs/<run>/levelup_gag.py 自己点的名**：它在 17 条真换关转移上跑全册 apply，"
        "改之前 12 条有 apply 的概念里只有本条开口（1/17 条，错 54 格），其余十一条 0/17。"
        "改法一行：apply 开头 `will_levelup(prev, action) is True` 就闭嘴。改完这条应当归零。"
        "**这一击不是反例**（这次结算 0 条反例，assert_ 在换关步判 NA），所以不进 EVIDENCE——"
        "它逼着改的是生成器的 scope，不是判据的对错。\n"
        "**顺带量到、没有动的**：那 12 条里还有 6 条不查 will_levelup"
        "（every_blob_moves_on_its_own_axis、legend_rotates_bar_about_joint、per_bar_adjudication、"
        "shrink_drags_cap_contact、wall_sticks_to_free_end、wedge_refuses_click），"
        "只是它们在这 17 条上都是 0/17 不开口，是潜在的同一个坑，判据脚本会在它们开口那天点名。")
EVIDENCE = ["f4c051250f10554f", "bda3e01059155890", "b6f0ef03af8176dd",
            "a340269ae057f793", "49f951051932cc49"]

from _lib import (BG, CAP, FIXED_OBS, SEG_W, cells_in, diamond_dots, free_face,  # noqa: F401
                   obstacles, push_target, push_target_block, will_levelup)


def _seed_groups(g, oc):
    """oc 自由端外面贴着的死物格，按颜色分组；没贴着返回 {}；free_face 算不出来返回 None。"""
    face = free_face(g, oc)
    if face is None:
        return None
    obs = set(obstacles(g))
    out = {}
    for rc in face:
        if rc in obs:
            out.setdefault(g[rc[0]][rc[1]], []).append(rc)
    return out


def _anchor_run(g, seeds, axis):
    """过 seeds 的同色带子，按运动轴取同色 run，3 格厚才算数——和 _lib.rigid_unit 的第一步一样。"""
    v = g[seeds[0][0]][seeds[0][1]]
    if any(g[r][c] != v for r, c in seeds):
        return None
    n, m = len(g), len(g[0])

    def run1(r, c):
        if axis == 0:
            lo = hi = r
            while lo - 1 >= 0 and g[lo - 1][c] == v:
                lo -= 1
            while hi + 1 < n and g[hi + 1][c] == v:
                hi += 1
        else:
            lo = hi = c
            while lo - 1 >= 0 and g[r][lo - 1] == v:
                lo -= 1
            while hi + 1 < m and g[r][hi + 1] == v:
                hi += 1
        return lo, hi

    runs = {run1(r, c) for r, c in seeds}
    if len(runs) != 1:
        return None
    lo, hi = runs.pop()
    if hi - lo + 1 != SEG_W:
        return None
    return lo, hi, v


def _grow(g, seeds, axis):
    """长带子：整条同色（菱形点透明）才能长；遇到厚度轴touch 按形状拆归属——
    两侧都探出让给对方；一侧探出但自己纹理越过touch 区还在继续，算自己的；
    一侧探出、自己也在同一点耗尽（单帧歧义角）：查对方支臂远端尖有没有真帽，
    钩着让给对方，没钩着按语料默认算自己的。"""
    a = _anchor_run(g, seeds, axis)
    if a is None:
        return None
    lo, hi, v = a
    n, m = len(g), len(g[0])
    dots = diamond_dots(g)
    perp = 1 - axis
    limit = n if perp == 0 else m
    thick_limit = n if axis == 0 else m

    def eff(r, c):
        if not (0 <= r < n and 0 <= c < m):
            return None
        return v if (r, c) in dots else g[r][c]

    def cells_at(p):
        return [((x, p) if axis == 0 else (p, x)) for x in range(lo, hi + 1)]

    def band_ok_raw(p):
        if not (0 <= p < limit):
            return False
        return all(eff(rr, cc) == v for rr, cc in cells_at(p))

    def touches_perp(p):
        if axis == 0:
            return eff(lo - 1, p) == v or eff(hi + 1, p) == v
        return eff(p, lo - 1) == v or eff(p, hi + 1) == v

    def crossed_both(p):
        if axis == 0:
            return eff(lo - 1, p) == v and eff(hi + 1, p) == v
        return eff(p, lo - 1) == v and eff(p, hi + 1) == v

    def passes_through(p, step):
        q = p
        while band_ok_raw(q) and touches_perp(q):
            q += step
        return band_ok_raw(q)

    def one_sided_side(p):
        if axis == 0:
            if eff(lo - 1, p) == v:
                return "lo"
            if eff(hi + 1, p) == v:
                return "hi"
        else:
            if eff(p, lo - 1) == v:
                return "lo"
            if eff(p, hi + 1) == v:
                return "hi"
        return None

    def anchored_to_real_cap(p, side):
        """歧义角仲裁：touching 支臂在 touch_line 上先探出它自己的厚度 run（不是自己
        band 的厚度），再顺着远离 band 的方向追到头，只在真正的远端尖（最后 SEG_W 个
        位置，不看路径中段）附近开窗口找 CAP。"""
        touch_line = lo - 1 if side == "lo" else hi + 1
        step = -1 if side == "lo" else 1

        if axis == 0:
            r0, c0 = touch_line, p
            t_lo = t_hi = c0
            while t_lo - 1 >= 0 and eff(r0, t_lo - 1) == v:
                t_lo -= 1
            while t_hi + 1 < m and eff(r0, t_hi + 1) == v:
                t_hi += 1

            def cells_thick(q):
                return [(q, x) for x in range(t_lo, t_hi + 1)]
        else:
            r0, c0 = p, touch_line
            t_lo = t_hi = r0
            while t_lo - 1 >= 0 and eff(t_lo - 1, c0) == v:
                t_lo -= 1
            while t_hi + 1 < n and eff(t_hi + 1, c0) == v:
                t_hi += 1

            def cells_thick(q):
                return [(x, q) for x in range(t_lo, t_hi + 1)]

        q = touch_line
        visited = []
        while 0 <= q < thick_limit and all(eff(rr, cc) == v for rr, cc in cells_thick(q)):
            visited.append(q)
            q += step
        if not visited:
            return False

        tip = visited[-SEG_W:]
        win = 20
        for q2 in tip:
            for rr, cc in cells_thick(q2):
                if axis == 0:
                    lo_c, hi_c = max(0, cc - win), min(m, cc + win + 1)
                    if CAP in g[rr][lo_c:hi_c]:
                        return True
                else:
                    lo_r, hi_r = max(0, rr - win), min(n, rr + win + 1)
                    if CAP in [g[x][cc] for x in range(lo_r, hi_r)]:
                        return True
        return False

    def grow_ok(p, step):
        if not band_ok_raw(p):
            return False
        if not touches_perp(p):
            return True
        if passes_through(p, step):
            return True
        if crossed_both(p):
            return False
        side = one_sided_side(p)
        if side is not None and anchored_to_real_cap(p, side):
            return False
        return True

    lo_p = min(rc[perp] for rc in seeds)
    hi_p = max(rc[perp] for rc in seeds)
    while grow_ok(lo_p - 1, -1):
        lo_p -= 1
    while grow_ok(hi_p + 1, +1):
        hi_p += 1
    if axis == 0:
        return (lo, hi, lo_p, hi_p), v
    return (lo_p, hi_p, lo, hi), v


def _plan(prev, action):
    p = push_target(prev, action)
    if p is None:
        return None
    _color, _box, d, oc, _ob, _ocap = p
    blk = push_target_block(prev, action)
    if blk is None or blk:
        return None                      # 连环没到底：那一片不是这条概念的
    groups = _seed_groups(prev, oc)
    if groups is None:
        return None
    out = []
    for wcolor, seeds in groups.items():
        if wcolor in FIXED_OBS:
            continue                      # 推不动那种死物贴着自由端：没见过，不猜
        ax = 0 if d[0] else 1
        res = _grow(prev, seeds, ax)
        if res is None:
            res = _grow(prev, seeds, 1 - ax)
        if res is None:
            continue                      # 连自己的带子都长不出来：不猜
        box2, v = res
        out.append((v, box2, d))
    if not out:
        return None                       # 没有贴身死物可猜：这条概念对这一步没有主张
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    plan = _plan(prev, action)
    if plan is None:
        return "NA"
    n, m = len(nxt), len(nxt[0])
    dots = diamond_dots(prev)
    for (wcolor, box2, d) in plan:
        old_cells = set(cells_in(box2))
        new_cells = {(r + d[0], c + d[1]) for r, c in old_cells}
        for (r, c) in new_cells:
            if (r, c) in dots:
                continue
            if not (0 <= r < n and 0 <= c < m) or nxt[r][c] != wcolor:
                return "FALSE"
        for (r, c) in old_cells - new_cells:
            if (r, c) in dots:
                continue
            if nxt[r][c] == wcolor:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_levelup(prev, action) is True:   # 换关那一步整盘重画，带子挪没挪在那一帧上看不见
        return None
    plan = _plan(prev, action)
    if plan is None:
        return None
    n, m = len(prev), len(prev[0])
    dots = diamond_dots(prev)
    out = {}
    for (wcolor, box2, d) in plan:
        old_cells = set(cells_in(box2))
        new_cells = {(r + d[0], c + d[1]) for r, c in old_cells}
        for (r, c) in new_cells:
            if not (0 <= r < n and 0 <= c < m):
                return None
            if (r, c) not in dots:
                out[(r, c)] = wcolor
        for rc in old_cells - new_cells:
            if rc not in dots:
                out[rc] = BG
    return out or None
