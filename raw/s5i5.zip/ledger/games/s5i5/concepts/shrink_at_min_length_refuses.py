"""点某色的「缩」时，如果那一色每一根条沿自己的轴都只剩 2 格、退不出一整段，世界整步拒绝：除计费条外一格不动。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点在面板图标中心上、且 `_lib.click_panel` 读出来的增量**为负**（缩）；"
         "增量为正（伸）返回 NA —— 伸是另一件事；"
         "`_lib.bar_units_all` 读不出全盘的条、或被点那一色在盘上一根条都没有，返回 NA；"
         "**被点那一色只要有任意一根条沿轴长度 ≥ 2 + SEG_W（也就是退得出一整段），返回 NA** —— "
         "这条概念只管「一根都退不动」这一片，「退得动就照做」是另一半主张，还没人立；"
         "换关（level_prev != level_next）返回 NA；"
         "判「世界拒了没有」用 `_lib.same_off_counter`（除计费条那一排外逐格相同），不用 prev == nxt："
         "被拒照样占一步，而计费条是量化的，跨过整数才跳一格——实测里有一条被拒的转移"
         "连计费条都没跳（089c1008124e0dfe，帧差 0 格），所以拿 prev == nxt 当判据会把它读成「没拒」。")
NOTE = ("**由来，以及为什么它不是事后编的**：第 3 关开局帧上把装置认得出的面板坐标全列了一遍"
        "（`runs/<run>/panels3.py`），10 个坐标里 5 个册子判「说不出」，其中 4 个是缩方向、"
        "连落点都算不出。这一批只发那四步，押注**在发之前**就写明「这四步至少有一步世界整步拒绝，"
        "理由是四根被点的条现在都在最短状态」。结果四步全拒。\n"
        "**所以这条主张是从帧读出来的，不是从那四条转移读出来的**：帧上量到（`runs/<run>/shrink3.py`）"
        "九根条里八根沿轴长 2、只有一根长 26，而每一次伸缩的位移都是 ±SEG_W=3——"
        "长 2 再退一整段就是负数，退不出去。EVIDENCE 因此只抄两条，不抄四条：\n"
        "  · c400e131d27c4ced：色 11 的缩。色 11 在这一关有**五根**条，五根全长 2，"
        "所以它是「每一根都退不动」这个量词的唯一实例；而且这个动作在这一局**从来没发过**，"
        "上一次想发它正好撞上装置边界（记分卡丢了）。\n"
        "  · 089c1008124e0dfe：色 8 的缩，帧差 **0 格**——连计费条都没动。它撑着 SCOPE 里"
        "「不许用 prev == nxt 判拒」那一句：用 prev == nxt 这条会被读成「没拒」。\n"
        "剩下两条（ea1580759779b4a9 色 9 的缩、e8da4062cee97547 色 14 的缩）**故意留在考场上**："
        "held_out(X) = 全部转移 − X 自己声明的 EVIDENCE，四条全抄进来这条概念就在构造上不可被打分"
        "（S=UNMEASURABLE、N=0）。这一局已经在这上面栽过三次。\n"
        "**它是怎么被看见的**：`_lib.blob_moves` 对这四个动作直接返回 None，于是下游"
        "`bar_footprints_after` → `refused` 顺着全 None，**整片闭嘴**。闭嘴是对的（宁可说不出，"
        "也别填一个默认值），但闭嘴不等于没有规律；册子对这一片一句话没说，而世界的答案很整齐。"
        "这正是「地图的空白」和「哪条概念没被考」不是一回事的例子：这四步上有概念在开口"
        "（计费条、静止色那几条都判 TRUE），可通关路线上要用的那一句没人说。\n"
        "**故意不写 apply**：它说的是「什么都没发生」，而这件事在计费条上并不成立（被拒照样占一步，"
        "有时跳一格有时不跳）。要生成那一格得先反推本关已用步数，那是 move_counter_row63 的活；"
        "在这里再写一遍只会制造打架格。\n"
        "**留宽的地方，公示两处**："
        "① 它说「每一根都退不动就拒」，而实测的四个实例里三个是「那一色只有一根条」，"
        "只有色 11 一个是真的多根；哪天出现「多根里有的能退有的不能」的局面，"
        "这条概念按 SCOPE 会让位（有一根 ≥ 5 就返回 NA），那一片是空的，谁都没说。"
        "② 逆命题（退得动就照做）**一次都没验**：同一帧上色 12 的缩被册子判「不会拒」，但这一批没发它。"
        "规划器只许拿这条概念剪掉「一定被拒」的动作，剩下的仍然是「说不准」——"
        "**说不准的步只能真发出去问世界，不许在搜索里当成会成功。**")
EVIDENCE = ["c400e131d27c4ced", "089c1008124e0dfe"]

from _lib import SEG_W, bar_units_all, click_panel, same_off_counter


def _axis_len(box, side):
    r0, r1, c0, c1 = box
    return (r1 - r0 + 1) if side in ("top", "bottom") else (c1 - c0 + 1)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cp = click_panel(prev, action)
    if cp is None:
        return "NA"
    color, delta = cp
    if delta >= 0:
        return "NA"                       # 伸是另一件事
    allu = bar_units_all(prev)
    if not allu:
        return "NA"
    units = allu.get(color)
    if not units:
        return "NA"                       # 那一色盘上没有条，说不出
    for box, side, _caps in units:
        if _axis_len(box, side) >= 2 + SEG_W:
            return "NA"                   # 有一根退得动 —— 那是另一半的地盘，让出去
    return "TRUE" if same_off_counter(prev, nxt) else "FALSE"
