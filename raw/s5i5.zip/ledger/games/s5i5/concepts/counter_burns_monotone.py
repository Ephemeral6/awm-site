"""计数条（第 63 行）只会从右往左单调地烧：未烧格(色3)永远是一段以第 0 列为左端的前缀，已烧格(色4)是它右边的后缀，且从不回退。"""
LEVEL = "L4"
SCOPE = ("只看普通动作；**RESET 返回 NA**；换关返回 NA。只断言形状与单调性，不断言这一步烧几格。")
NOTE = ("v2 把 RESET 划出去。死于 b9eafde30475b7ff：重开本关那一步，计数条整条退回未烧，"
        "前缀从 60 长回 64——单调性只对「花代价的动作」成立，重开是把代价一起退掉。"
        "这不是修补，是这条概念本来就只该管「烧」，而 RESET 是「还」。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "b9eafde30475b7ff"]

from _lib import CAP, COUNTER_ROW, USED


def _prefix_len(g):
    """未烧前缀的长度；不是「色3前缀 + 色4后缀」这种形状就返回 None。"""
    row = g[COUNTER_ROW]
    k = 0
    while k < len(row) and row[k] == CAP:
        k += 1
    if any(v != USED for v in row[k:]):
        return None
    return k


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.startswith("RESET"):
        return "NA"
    a = _prefix_len(prev)
    if a is None:
        return "NA"
    b = _prefix_len(nxt)
    if b is None:
        return "FALSE"
    return "TRUE" if b <= a else "FALSE"
