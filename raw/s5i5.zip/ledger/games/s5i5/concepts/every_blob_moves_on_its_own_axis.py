"""点一个面板的按钮，该颜色在盘上的**每一团**都各自动一次：自由端沿自己的长轴走 3 格、帽不动，
方向由每一团自己的帽决定——五团朝五个不同方向也各自算；**要么如此，要么整步无事发生**（计费条那一行不算）。"""
LEVEL = "L1"
SCOPE = ("只看点中了面板图标的那些步（click_panel 非 None）；换关返回 NA；"
         "**整步无事发生（除计费条那一行外逐格相同）判 TRUE**——世界整步拒绝时这条概念不主张谁动了；"
         "**apply 比 assert_ 窄一档：refused() 不是断定「不拒绝」时 apply 一格不画**（v6，见 NOTE）；"
         "有任何一团认不出帽或缩过头（blob_moves 为 None）返回 NA；"
         "**帧上有无主帽指认某根会动的条其实是两根贴死的条（merged_pair_suspect）返回 NA**（v9）——"
         "「团」的数目本身就点错了，这条概念的主语不存在，它没有资格开口；"
         "**这道闸 apply 也守**（v10）——只加进 assert_ 的那一版，生成器在同一类局面上说错了 27 格；"
         "**盘上有死物（obstacles 非空）返回 NA**——推墙是另一套机构，这条不管；"
         "**被点那根条有下游条时，它缩回去腾出来的格子这条概念不认领**（v7）——"
         "那里填的是什么是 [chain_drags_downstream] 的事，这条只说它们不再是本色；"
         "任何一团的落点压到底色与菱形四点以外的东西、或两团落点相交、或落点里有别色的格子，"
         "一律返回 NA：那种局面世界会不会拒绝是 seg_landing_collides / blocked_push_refuses 的事，"
         "这条只在「路上什么都没有」时开口。")
NOTE = ("v1：第 3 关第 1 步 7020e8e73bf8692d 立的，它是这一关的第一次点击。\n"
        "**为什么要有这条**：第 0~2 关每个节色在盘上恰好只有一团，于是 bar_cells + bar_box + capped_side "
        "这一串词汇一直读得出唯一答案，「一色一节」这句话从来没有被写成主张、也从来没有被打分。"
        "第 3 关色 11 在盘上有五团，bar_box 变成五团的并集 (12,43,10,52)、capped_side 不唯一、"
        "button 当场返回 None——整册对色 11 的两个按钮一句话说不出来（第 194 步的模型逐格预测是 0 格）。"
        "那一步真帧差 47 格：五团各新占 9 格共 45 格，带尖那团另有旧尖位 (43,31) 由色 13 变本色，"
        "剩下 1 格在计数条上。事先押的 46 格（不含计数条）一格不差。\n"
        "**同时被证伪的是我的一条外推**：押注里我单列了一句「前三关预算 50/150/200 递增，所以倾向这一步"
        "计数条烧 0 格」，实测烧了 1 格 —— burn_at(1,B)=1 要求 B<=128，第 3 关的预算比第 2 关**小**。"
        "那句话当时标了「这是外推不是读数」并单列，没有并进 46 格里，所以它落空只花了一句话。\n"
        "**这条概念的边界画在哪、为什么**：它只在「路上什么都没有」时开口。原因是「一团动」和"
        "「一团被挡住」是两件事，而第 3 关盘上一个死物都没有（obstacles 读 0 格），"
        "所以这一关暂时不需要回答第二件事。哪天某一团的落点上有东西，这条概念自动闭嘴，"
        "那一步就是新证据的产地——不是这条概念兜底猜一个答案。\n"
        "**入册当场就挨了一记，而挨打的又是词汇**：第 2 关第 83 步 c9bf233145fe4d48 判 FALSE 关闸。"
        "一根色 14 的尖压上菱形中心，菱形那四个色 13 点把这根节从中间切断，"
        "color_blobs 于是读出三团、和预测的一团对不上。错在 color_blobs 第一版把菱形四点"
        "**从可通行标记里剔掉了**——而那四格恰恰是唯一会切断节的东西，bar_cells 的 docstring "
        "早就写着这句话，我照抄了它的结论却把它的理由用反了。改成「全部色 13 格都可通行」后两条都判 TRUE。\n"
        "这是同一件事第二次发生：这条概念本身是为了「一色一节」那个藏在词汇里的假设才立的，"
        "而它的第一版又立刻栽在自己新写的那句词汇上。**新写的词汇和老词汇一样免检**，"
        "唯一的区别是它还没走过一次全量语料——所以词汇改完必须立刻 settle 一次，别等下一批动作。\n"
        "v3：apply 说错 75 格改到 0 格，两处，都不是断言错、是生成器错，而 assert_ 一处都没察觉。\n"
        "一处 74 格是换关那一步 228810ee4f309efd：assert_ 有 ctx 能看见 level_prev != level_next 直接 NA，"
        "apply 拿不到那个 ctx（装置调 apply 时 ctx 为 None），于是照常画了一整根节，而那一帧整盘换了 875 格。"
        "现在的挡法是**从册子里借判据**：预测的新尖位落在菱形中心上就整条不画（levelup_when_all_home 说的就是"
        "「尖铺满中心就换关」）。这挡法比它该挡的宽——只有一根尖落位、别的尖还没到家时也闭嘴了，"
        "第 2 关有这样的步。代价认了：**换关那一帧全册没有任何概念敢说**，三条换关转移的残差 1276/1071/875 格"
        "是这张地图上最大的三块空白，与其在那儿猜一根节，不如让空白显形。\n"
        "另一处 1 格是 1e5c6990b6e3714b（一根色 14 在缩）：我把旧尖位无条件涂回本色，"
        "而这一步节缩了 3 格、旧尖位 (10,34) 落在新 bbox **外面**，实测是底色。那行代码是照「伸」的情形写的，"
        "伸的时候旧尖位一定还在身体里，缩的时候不一定——一个只在半边情形成立的赋值，写的时候没分情形。\n"
        "**这两处的共同点值得单记**：它们的 assert_ 全判 TRUE（bbox 预测一格不差），是 settle 的逐格对答案"
        "把它们抓出来的。**同一条概念的检查器看不见它的生成器画了什么**——检查器只比 bbox，"
        "生成器要填每一格颜色，后者说的话严格多于前者。所以「S=1.000」从来不等于「这条概念说对了」，"
        "它只等于「这条概念的 assert_ 问的那个问题没被答错」。\n"
        "\nv4：**上一版 NOTE 最后那段话第二天就变成了一条反例，而且是它自己招来的。**"
        "第 196 步 86f7ada89eb10459（连点两次色 11 的伸，第一次）判 FALSE 关闸——"
        "而同一条转移上 apply 认领 120 格、逐格全对。检查器判错、生成器判对，"
        "正是「检查器问的是另一个问题」的极端形态：那个问题**问错了**。\n"
        "原因是这一步**同一个节的两团长到一起去了**：(12,14,48,52) 长成 (12,14,45,52)、"
        "(15,17,42,46) 长成 (15,17,39,46)，两者在行 14/15、列 45~46 处四连通，"
        "于是 color_blobs 读出的团数从 5 掉到 4、bbox 变成两团的并集，"
        "和 blob_boxes_after 预测的 5 个 bbox 对不上。**像素一格没错，连通块的数目错了**。\n"
        "**世界的回答比反例本身重要**：合并没有被拒绝、没有换关、没有任何异常——"
        "每一团照旧各长各的 3 格，合并只是我这边的读法产物。所以「一色多团」不是世界的结构，"
        "是 color_blobs 这个词的分辨率；团数会随局面变，拿它当断言的锚点就是拿自己的读法当世界。\n"
        "**改法是把断言从 bbox 换成逐格集合**：认领的每一格都要对上，而且本色格与尖格的**整个集合**"
        "都要对上（没认领的原样留着、别处不许多出一格本色）。这比原来的 bbox 相等**严格更强**，"
        "同时对合并免疫——因为它压根不问「有几团」。\n"
        "**这一改顺手关掉了独立复核找出的三个口子**（子 agent 审 v3，语料里现成反例 0 条、"
        "构造反例 4 条，产物与可重跑脚本在 runs/<run>/audit_blob.md）：\n"
        "  · 它的第 4 条正是「assert_ 只比 bbox，看不见尖在框内落在哪一格」——"
        "它把一条真 TRUE 转移的尖和身体格互换一位，bbox 不变、assert_ 照判 TRUE，而 apply 逐格两处不符。"
        "换成逐格集合后这条构造反例当场判 FALSE。**世界和复核者指着的是同一个缺陷，从两侧**。\n"
        "  · 它的第 1 条：_landing_clear 里那个 TIP 豁免，因为菱形四点上一行已经单独排掉了，"
        "实际放过的只剩**别的节的尖**——而那一定是「路上有东西」。语料里 0 次撞上，口子一直开着。已删掉豁免。\n"
        "  · 它的第 2 条：len(tps) != 1 时静默丢掉全部尖信息、整团涂本色。"
        "语料里 len(tps)!=1 的 80 次全是 len==0（短节没长尖，是干净的），len==2 从没走到过。"
        "改成 len(tps) > 1 直接返回 None：**没见过的构型上闭嘴，不猜**。\n"
        "  · 它的第 3 条：团间冲突只比移动后的 new-vs-new，不查两团移动前是否本来就叠着"
        "（都做「缩」时 new-old 为空，逐格检查被绕开）。加了 olds 的两两相交检查。\n"
        "这四条里三条**语料至今撞不上**，是构造出来的；照方法册「构造反例和真反例一样是反例」收下——"
        "它们此刻不花预算，等语料撞上就要花。\n"
        "**最该记的一句**：v3 的 NOTE 已经把病因写清楚了（「检查器只比 bbox，说的话比生成器少」），"
        "我却只把它当成一条教训记下来，没有回头去改那个检查器。"
        "**写下诊断不等于治疗**——那一段自我批评在盘上躺了一整轮，然后世界拿同一个缺陷打了我一次。\n"
        "**附一条口径，免得下次把它读成退步**：v4 结算后 apply 认领从 702 格掉到 582 格、"
        "E 从 0.536 掉到 0.531。我第一反应是收紧收多了，去查（`runs/<run>/whyclosed.py`）——"
        "第 196 步上 `_landing_clear` 仍判 True、`_claim` 仍认领 120 格，一道闸都没多关。"
        "掉的 120 格正是把 86f7ada89eb10459 抄进 EVIDENCE 的代价："
        "按 CRITERIA 的定义 held_out(X) = 全部转移 − X 自己的 EVIDENCE，而 P 和 E 都只在 held-out 上算。"
        "**所以「引用一条转移作依据」这个动作本身就会让 E 下降**，E 不是随册子变好而单调上升的数。"
        "掉的 46 格帧差正是那一步 47 格里的非计数条部分——数字对得上，不是退步，是记账。\n"
        "\nv6：**第 349 步 bdf9e287ce42c227 判 FALSE 关闸——世界整步拒绝了，而这条概念说五团各走了 3 格。**\n"
        "落点上什么都没有（_landing_clear 判 True，obstacles 读 0 格），所以它照常认领；世界却一格没动。\n"
        "**追下去发现缺的不是一条新机构，是词汇数不到 5**：册子里早有一个只看 prev 的拒绝谓词 "
        "`_lib.refused`，交叉核对（`runs/<run>/absent.py`）它在全去重语料上**开口的 146 条全对**——"
        "说会拒的 25 条全真拒了，说不会拒的 121 条全真没拒，零漏报零假报；它的毛病只有闭嘴，27 条弃权。"
        "逐环定位（`runs/<run>/whyna.py`）：25 条弃权卡在 `footprints_after` 返回 None，其中 **23 条在本关**，"
        "因为那个函数按**色**取 bar_box / cap_block，而本关有一色五条。"
        "**关闸的这条转移正是落在那片盲区里的第一次拒绝**——不是判别式说错了，是判别式在这一关整关没上场。\n"
        "**这一版的改法把 assert_ 和 apply 分成两个 scope，理由是它们的活不一样**：\n"
        "  · `assert_` 的活是尽量宽地可被判错，所以走**析取**（要么各走 3 格、要么整步无事发生），"
        "这正是技能里模板概念自己的写法（`要么让 me 上移恰好 CELL 格…要么整帧不动`）。"
        "这样本关那 23 条转移照旧逐格全量检验，一条检验面都没丢——"
        "**为了躲一条反例去把检验面缩掉，等于拿这个台架的本金去换一次好看的结算。**\n"
        "  · `apply` 的活是不许说出自己背不动的格子，所以它比 assert_ 窄一档："
        "`refused()` 不是断定「不拒绝」时（True 或 None）一格不画。"
        "代价是本关这条概念的逐格预测暂时归零（原来每步认领约 120 格），"
        "而这个代价**会自己长回来**：`footprints_after` 一旦算得动一色多条，refused() 在本关开口，apply 自动复活，"
        "这条概念不用再改一行。依赖的方向是对的——先有「世界会不会动」，才谈得上「谁动了」。\n"
        "**顺带记一句口径**：这一版之后本关的残差会变大、E 会掉。那不是退步，是本关真的没人能预测拒绝——"
        "与其画 120 格「大多数时候对」的身体，不如让这块空白显形，好让下一步知道该去撞哪儿。"
        "这条概念自己 v3 的 NOTE 已经立过同样的规矩（换关那一帧宁可全册失语也不猜一根节），这里照办。\n"
        "**最该记的一件事**：为了这一条反例我连杀了三个假说（跨轴推、自由端拖拽同色相撞、自由端顶帽），"
        "每一个都在语料上量过、都两个方向不为 0。三个假说全是在**重新发明** `refused()` 里已经写着的六种机构之一。"
        "**先问「册子里已经有的那句话在这一关上说得出话吗」，再问「世界是不是还有一条我没见过的规矩」**——"
        "顺序反了就要花三个假说的钱。\n"
        "\nv7：**第 479 步 f45790b57c82e9d1（`ACTION6:6,57`，语料里这个动作的第一条转移）判 FALSE 关闸。**\n"
        "被点的色 12 自己一点没错：那根条 (27,52,18,20) 缩到 (30,52,18,20)，沿自己的轴走了整整 3 格。"
        "错的是**腾出来的那 9 格**——`_claim_boxes` 把 `old - new` 无条件涂底色，"
        "而 `bar_chain` 里认作色 12 儿子的色 11 条 (24,26,19,20) 连同帽整体下移 3 行，**正好填满它们**。"
        "帧差 18 格 = 儿子旧位 9 格回底色 + 儿子新位 9 格，一格不多。\n"
        "**这条概念的主张（「每一团各自动一次」）没有错，错的是它顺手多说了一句**："
        "「我走了以后那里是空的」。这句话从来不在首行的主张里，是生成器为了填满格子添的，"
        "而 v3 的 NOTE 早就为它写过一次分情形的教训（伸的时候旧尖位还在身体里，缩的时候不一定）——"
        "**同一个位置，同一种错法：一个只在半边情形成立的赋值，第二次没分情形。**\n"
        "**v7 改法**：被点那根条**有下游条**时（`bar_downstream` 非空），它缩回去腾出的格子一律不认领，"
        "assert_ 也把这些格子从「本色格整个集合」里排掉——这条概念只说它们**不再是我的色**，"
        "填进去的是什么交给 [chain_drags_downstream]。伸的时候 `old - new` 是空集，这一改碰不到。\n"
        "**改之前先影子记分**（`runs/<run>/shadow6.py`，全去重语料 182 条）：FALSE 1→0、TRUE 25→26、NA 156→156，"
        "**判法变了的只有这一条转移**，且事先写好的「只该碰缩 + 有下游」逐条核过（缩=True 有下游=True）。\n"
        "**一句要记的**：同一批里派出去查第 3 关路线的那双眼睛，独立地撞上了同一处——"
        "它的仿真在全关 33 条转移上 28 条一致，唯一一条**真说错**（而不是闭嘴）的正是这一条 `ACTION6:6,57`，"
        "它给的诊断也是「chain-drag 没算进去」。**两条互不相通的路指到同一个缺陷，比任何一条自己的置信度都值钱。**\n"
        "\n**v8 这条概念一个字没改，改的是它脚下的词汇——它是这一次唯一开口挨打的那条。**\n"
        "反例 10b0af80ddf633ce（第 503 步）、5b4e28a395937c1c（第 504 步），同一个坐标 ACTION6:34,54。\n"
        "起因是 `_bar_units` 会**整根丢条**：一根同色横条长到正好停在某根竖条那顶帽子的正下方，"
        "帽的上下两侧于是都贴着该色可通行格，`top_ok == bottom_ok == True`，帽被跳过；"
        "那根竖条只有这一顶帽子能锚它，于是从清单里消失，而 `bar_units_all` 照旧返回一个列表、不是 None。"
        "清单里少了一团，这条概念就主张那一团动的格子不该变，世界动了 → FALSE。\n"
        "**这条概念是这个盲区唯一的检测器，而它只在世界替它开口时才响。** 第 502 步同一个盲区已经成立"
        "（那一帧清单里就少了那根条），这条概念却判 TRUE、说错 0 格——因为 `apply` 和 `assert_` 拿的是 "
        "**prev** 帧，而 prev 上那根条还看得见。**瞎的是 next，考的是 prev，于是错了一帧没人扣分。**"
        "隔一步才挨打不是它反应慢，是记分的取样点和出错的取样点差了一帧。\n"
        "止损放在 `_bar_units`：两侧都贴的帽 → 整色返回 None（原来是跳过这顶帽子、让那根条消失）。"
        "这个处置写在它 docstring 的「已知的粗糙处」里已经很久了，**当时选的是让条消失**，现在证明选错了。\n"
        "**为什么上一次的止损拦不住这一次**：上一次（同色两根条呈直角相交）丢的是**边界**，"
        "留下两个重叠的框，`bar_units_all` 的重叠检查抓得住；这一次丢的是**整根条**，"
        "不留下任何重叠的框——重叠检查在构造上就抓不到。同一个「一色一条」盲区，第八次露面，"
        "第二次不在「按色取值」上。\n"
        "**改之前影子记分**（`runs/<run>/shadowcap.py`，全去重语料 204 条，判据跑之前写好，"
        "由一个没参与写它的 agent 跑）：反例帧上现行 4 根 → 影子 None；apply 说错 0→0 格；"
        "新增 FALSE 0 条；丢判据的转移 2 条（就是这两条反例自己，各丢 4 条判据）；少认领 444 格。"
        "覆盖面只报数：全语料里存在这种隐藏帽的转移 3/204。**这个构型是我自己的路线造出来的。**\n"
        "抄这两条进 EVIDENCE 的代价照旧明说：held_out 少 2 条，N 掉 2 格。\n"
        "\n**v9 又是同一个盲区，第九次，而这次它是被我自己安排的一击打出来的。**\n"
        "反例 a197d1d59397e644（第 1086 步 ACTION6:28,54）。那一击是策略专门发出去打 `_lib.stranded_cap` 的"
        "探测击：该词汇断定「世界会整步拒」，世界照做了，帧差 47 格。它倒下的同时把这条概念一起带倒。\n"
        "**真因不是位移读错了，是「团」点错了数**：`shrinkdir.py` 量到色 11 的 unit 数 prev 4 → next 5，"
        "prev 上那根 28 列长的条在 next 上裂成 (12,14,19,29) 与 (12,14,36,46) 两根。"
        "它从来没有「消失」过——是两根条贴死在一起，连通块把它们并成了一根。"
        "于是这条概念主张的「每一团各自动一次」里，团的清单从一开始就少一项，判 FALSE 是必然的。\n"
        "**处置是弃权，不是修断言**：这条概念的主语（团）不成立时它没有资格开口。"
        "闸放在 `_whole_step_noop` **之后**——整步什么都没发生时，析取的另一半照样成立，"
        "和分解读得对不对无关；放前面等于白扔读数。\n"
        "**代价先量后改**（`runs/<run>/blobna.py`，全去重语料 608 条，四条判据跑之前写死）："
        "现行 TRUE 77 / FALSE 1 / NA 530；加闸后改判的**只有这一条**（FALSE → NA），"
        "TRUE → NA **0 条**（分母 = 现在开口的 78 条）。写死的阈值是 TRUE→NA ≤ 3。\n"
        "**判据 2 按字面是红的，照实记**：它要求第 1084 步（世界整步拒了那条）仍判 TRUE，实测是 NA → NA。"
        "原因是那一帧 `_claim_boxes` 本来就返回 None（落点算不出来），noop 那一支根本走不到。"
        "判据的意图（别白丢读数）满足了，但它写的话是错的——**写判据时我以为 noop 优先，其实 claim 优先**。\n"
        "**为什么这次的止损和 v8 那次形状相反**：v8 的盲区（整根丢条）止损在词汇里，让整色返回 None；"
        "这次的盲区（两根并成一根）在像素上**根本没有任何东西能让 `_bar_units` 察觉**——"
        "两根贴死的同色条和一根长条逐格一模一样。唯一的破绽在帧的别处：那根被并掉的条的帽还留在原地，"
        "没人认领。所以判据只能是**外部的**（`merged_pair_suspect`：无主帽 + 朝向相配 + 贴着会动的条），"
        "不可能是 `_bar_units` 内部的自查。这是「物件的消失/合并不是零证据，是另一种证据，"
        "只是不在原来那个读法里」的第二次落地。\n"
        "\n**v10：v9 那道闸我只加进了 `assert_`，`apply` 没跟上——四步之后世界当场收账。**\n"
        "第 1090 步 ACTION6:28,54（终局卡 --strict 停批）：`assert_` 判 NA（闸生效），"
        "而 `apply` 照旧认领 210 格、说错 27 格。**settle 报零反例**——检查器闭了嘴，生成器还在说话，"
        "而生成器说错不产生反例，只进残差。要不是终局卡上 `--strict` 逐格对答案，这 27 格会静静地进下一步的输入。\n"
        "**它错成什么样，正好把 v9 的诊断坐实了**：prev 上色 11 的第三根读成 `(15,17,19,46)` 一根、帽在右边 47 列；"
        "next 上它是两根——`(15,17,19,29)` 帽在**左边 18 列**（那正是那顶「无主」的帽）与 `(15,17,36,46)` 帽在右边 47 列，"
        "中间开出 6 格空隙。两根各自从**自己的**自由端缩了 3 格；"
        "并成一根的读法只认得右边那顶帽，于是把整段当成一根往左缩，左边 3 格与右边 6 格全画反。\n"
        "**代价**（`runs/<run>/blobapply.py`，全去重语料 612 条，四条判据跑之前写死）："
        "apply 认领 12045 → 11625（少 420 格），说错 **54 → 0**。\n"
        "**该记的一条**：改 scope 是**成对**的手术，`assert_` 和 `apply` 必须一起改。"
        "漏掉哪一个，装置都不会关闸——检查器漏了会多出反例（看得见），"
        "**生成器漏了只会多出残差（看不见）**，而残差会传播。"
        "同一批里 [bar_free_end_moves] v15 我两处都改了，这一条只改了一处，两条概念同一天同一个闸，"
        "说明这不是「忘了」能解释的，是没有任何东西在提醒。")
EVIDENCE = ["7020e8e73bf8692d", "c9bf233145fe4d48", "86f7ada89eb10459", "bdf9e287ce42c227",
            "f45790b57c82e9d1",
            # v8：_bar_units 整根丢条（两侧都贴的帽被跳过）→ 清单少一团 → 判 FALSE
            "10b0af80ddf633ce", "5b4e28a395937c1c",
            # v9：两根贴死的条被连通块并成一根 → 团数点错 → 判 FALSE（改成弃权）
            "a197d1d59397e644",
            # v10：同一道闸只加进了 assert_，apply 在这一步说错 27 格（没产生反例，只进残差）
            "86eeda6f7590b9ce"]

from _lib import (BG, COUNTER_ROW, GROW, TIP, bar_downstream, blob_boxes_after,  # noqa: F401
                  blob_moves, cells_in, cells_of, click_panel, color_blobs, diamond_centers,
                  diamond_dots, merged_pair_suspect, moved_box, obstacles, refused)


def _whole_step_noop(prev, nxt):
    """整步无事发生：除计费条那一行外逐格相同。计费条照样烧，被拒的步也占一步预算。"""
    return all(prev[r] == nxt[r] for r in range(len(prev)) if r != COUNTER_ROW)


def _landing_clear(g, action):
    """每一团的落点是不是「路上什么都没有」；算不出来返回 None。"""
    mv = blob_moves(g, action)
    cp = click_panel(g, action)
    if mv is None or cp is None:
        return None
    if obstacles(g):
        return False
    color = cp[0]
    dots = diamond_dots(g)
    olds, news = [], []
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        t, bo, l, r = box
        old = {(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)}
        new = {(rr, cc) for rr in range(nb[0], nb[1] + 1) for cc in range(nb[2], nb[3] + 1)}
        for rc in new - old:
            v = g[rc[0]][rc[1]]
            if rc in dots:
                continue
            if v != BG and v != color:
                return False      # 尖不再豁免：new-old 里的尖只可能是别的节的尖，见 v4 NOTE
        olds.append(old)
        news.append(new)
    for i in range(len(news)):
        for j in range(i + 1, len(news)):
            if news[i] & news[j] or olds[i] & olds[j]:
                return False      # 落点相交、或者两团本来就叠着（后者是构造出来的，见 v4 NOTE）
    return True


def _ceded(g, action):
    """有下游条的那根条缩回去时腾出来的格子；算不出来返回 None。

    这条概念对这些格子只说一句「不再是本色」，不说填的是什么——下游会不会滑进来
    是 [chain_drags_downstream] 的事（v7 NOTE）。伸的时候 old-new 是空集，这里返回空。
    """
    mv = blob_moves(g, action)
    cp = click_panel(g, action)
    if mv is None or cp is None:
        return None
    out = set()
    for box, side, d in mv:
        ds = bar_downstream(g, cp[0], box)
        if ds is None:
            return None
        if not ds:
            continue
        nb = moved_box(box, side, d)
        out |= set(cells_in(box)) - set(cells_in(nb))
    return out


def _claim_boxes(g, action):
    """这一步之后，这条概念**几何上**敢说出颜色的那些格子；算不出来返回 None。

    它只算「如果世界让这一步发生，落点长什么样」，**不问世界会不会让它发生**——
    「会不会」由 refused() 回答，而那是 apply 的闸，不是 assert_ 的闸（v6 NOTE）。
    """
    mv = blob_moves(g, action)
    cp = click_panel(g, action)
    if mv is None or cp is None or _landing_clear(g, action) is not True:
        return None
    ceded = _ceded(g, action)
    if ceded is None:
        return None
    color = cp[0]
    dots = diamond_dots(g)
    centers = set(diamond_centers(g))
    out = {}
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        t, bo, l, r = box
        old = {(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)}
        new = {(rr, cc) for rr in range(nb[0], nb[1] + 1) for cc in range(nb[2], nb[3] + 1)}
        tps = [rc for rc in old if g[rc[0]][rc[1]] == TIP and rc not in dots]
        if len(tps) > 1:
            return None          # 一团上两个尖：语料里没有过，别静默把尖吞掉，见 v4 NOTE
        ntp = (tps[0][0] + d[0], tps[0][1] + d[1]) if len(tps) == 1 else None
        if ntp in centers:
            return None          # 尖落到菱形中心：这一步可能换关，整盘会变，这条概念不画
        for rc in new:
            if rc in dots:
                continue
            out[rc] = TIP if rc == ntp else color
        for rc in old - new:
            if rc in ceded:
                continue          # 下游要滑进来，这里填什么这条概念不说（v7）
            out[rc] = BG
        if len(tps) == 1 and tps[0] in new:
            out[tps[0]] = color   # 旧尖位只在它还留在新 bbox 里时才涂本色；缩出去了就是底色
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    cp = click_panel(prev, action)
    if cp is None:
        return "NA"
    claim = _claim_boxes(prev, action)
    if claim is None:
        return "NA"
    ceded = _ceded(prev, action)
    if ceded is None:
        return "NA"
    # 世界整步拒绝时这条概念不主张谁动了——析取的另一半，写法照技能里的模板概念。
    # 放在 claim 算出来**之后**：算不出落点的步照旧 NA，别让它捡一个空洞的 TRUE。
    if _whole_step_noop(prev, nxt):
        return "TRUE"
    # 团的清单本身不可信时闭嘴：帧上那顶无主帽指认「这一击会动的条里有一根其实是两根贴死的」，
    # 这条概念的主语（团）就不成立，判什么都是碰运气（v9）。
    if merged_pair_suspect(prev, action) is True:
        return "NA"
    color = cp[0]
    dots = set(diamond_dots(prev))
    # 一、认领的每一格都得对上
    for rc, v in claim.items():
        if nxt[rc[0]][rc[1]] != v:
            return "FALSE"
    # 二、本色格与尖格的**整个集合**都得对上：没认领的格子必须原样留着，
    #     别处也不许多出一格本色。比只比 bbox 强，且不受两团合并的影响。
    #     让给下游的那些格子从两侧都排掉——这条概念只说它们不再是本色（v7）。
    pred_color = ({rc for rc in cells_of(prev, color) if rc not in claim and rc not in ceded}
                  | {rc for rc, v in claim.items() if v == color})
    pred_tip = ({rc for rc in cells_of(prev, TIP)
                 if rc not in dots and rc not in claim and rc not in ceded}
                | {rc for rc, v in claim.items() if v == TIP})
    if set(cells_of(nxt, color)) != pred_color:
        return "FALSE"
    if {rc for rc in cells_of(nxt, TIP) if rc not in dots} != pred_tip:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    # 生成器比检查器窄一档：世界会不会整步拒绝，册子说不出来（None）或说会拒（True）时，
    # 一格都不画。画出来的每一格都得背得动，背不动就让空白显形。
    if refused(prev, action) is not False:
        return None
    if merged_pair_suspect(prev, action) is True:
        return None                        # 生成器守 assert_ 同一个 scope（v10）
    return _claim_boxes(prev, action)
