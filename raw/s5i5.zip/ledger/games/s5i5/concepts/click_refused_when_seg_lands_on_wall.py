"""正在动的某一节的落点压住死物格时，世界拒不拒整步，只看那些格子这一步会不会腾空：有一格不腾空就拒，全都腾空就照做——和谁顶的、死物什么颜色都无关。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上（_lib.button 认得出）；"
         "落点或跟着走的墙算不出来（footprints_after / attach_plan 返回 None）返回 NA；"
         "**正在动的那几节的落点一格死物也不压，返回 NA** —— 那一步该怎么动由 "
         "bar_free_end_moves 与 chain_drags_downstream 说，这条没话讲；"
         "盘上一个死物也没有返回 NA；换关返回 NA。"
         "**另外两种已知的拒绝原因不许混进来**：贴着的刚体没地方去（attach_block 非 None）、"
         "两节落点相撞（seg_overlap 为真），这两种任一成立就返回 NA —— "
         "那一步确实被拒，但拒它的不是这条概念说的原因，算进来等于蹭分。"
         "「腾空」= 跟着自由端走的刚体离开的那些格子（attach_plan 里 cells - nc）。"
         "判的是双向的：不腾空⇒拒，全腾空⇒不拒；任一边错都判 FALSE。")
NOTE = ("**它是拿一次落空的押注换来的，取代两条按颜色写的判据。**"
        "此前这件事分给了两个按颜色分的读法：[blocked_click_is_noop] 说「压到推不动那色才拒」，"
        "`_lib.would_refuse` 也照颜色分；而 [drag_into_obstacle_refuses] 说「看是谁顶的」。"
        "第 129 步（b929ced9b42319f5）把两种都绕过去了：一块 126 格的死物是个 T 字，"
        "横臂 72 格贴在正在动的自由端上跟着走，竖干 54 格原地不动"
        "（`_lib.rigid_unit` 只取得出一个矩形，接头归谁是那个函数 docstring 里公示的选择）。"
        "被拖着走的那一节的落点正好压住竖干那 54 格 —— 颜色是推得动的那种，"
        "所以按颜色的读法说没事，册子预测 207 格运动，世界整步拒绝。"
        "**同一块死物，同一个颜色，一半跟着走一半不动**：颜色分不开的东西，占位分得开。"
        "（方法册「让位规则要按语义写，不按颜色写」——按颜色永远更宽，宽出去的那片就是罕见构型。）"
        "\n\n**它顺手统一了三次此前各自解释的观测**：4605a0c4a215b03e 压到的是推不动那一色，"
        "而那一色关内一步也不动（[fixed_color_never_moves]，全量 68 条零反例），所以一格也不腾空 → 拒；"
        "3c79fccbc0893691 与 e0f459332e57406b 顶进去的死物整块贴在自由端上、按 d 平移，"
        "压住的格子全部腾空 → 照做；第 129 步压住的是同一块死物里不动的那一半 → 拒。"
        "所以「推得动 / 推不动」不是死物的属性，是**这一步这几格的属性**。"
        "\n\n**这是 [segments_never_on_walls] 缺的后半截**：那条只说节压不上墙（S=1.000、N=69），"
        "没说「点了会怎样」。现在补上了，而且补的方式让两条互为镜像——"
        "一条说结果不会出现，一条说世界用拒绝来保证它不出现。"
        "\n\n**故意留宽三处**："
        "① 说「有一格不腾空就拒」，而观测里不腾空的格数是 54 和 18，"
        "没验过只压住 1~2 格会不会被允许（比如世界只是把节停在墙边）；"
        "② 「腾空」只认跟着自由端走的刚体腾出来的格子，不认别的腾空方式（还没见过别的）；"
        "③ 双向断言里「全腾空⇒不拒」那一半只有两次观测（都在第 2 关、都是被点那一节自己顶的），"
        "被**拖着走的**节顶住会腾空的墙格这一格局一次也没走过——那正是它和 "
        "[drag_into_obstacle_refuses] 现在唯一的分歧处，留着让世界杀一个。"
        "\n\n**没写 apply**：它断言的是「什么都没发生」和「照常发生」，前者生成不了格子，"
        "后者该由 bar_free_end_moves / chain_drags_downstream / wall_sticks_to_free_end 生成。"
        "规划器通过 `_lib.refused` 听得见它（第四个拒绝判据），全量语料上 refused 对 84 错 0。"
        "\n\n**b2f1b087ef082fee 上判过一次 FALSE，而这条主张一个字没改。**"
        "那一步压住的墙格全部腾空，所以这条说「照做」，世界却整步拒绝——"
        "上面 ③ 号留宽（「全腾空⇒不拒」只有两次观测）被兑现了。"
        "但拒它的原因是个当时册子里根本不存在的第五种：刚体的落点**新压**到菱形目标点上"
        "（现在单独走闸，见 [wall_push_onto_target_dot_refuses]）。"
        "**这条概念的 scope 其实早写对了**——它说「attach_block 非 None 就返回 NA，"
        "那一步确实被拒，但拒它的不是这条说的原因」。错的是 `attach_block` 当时不认识这个原因，"
        "它在词汇里，而词汇不打分。所以这次挨打的不是主张也不是 scope，是 scope 依赖的那个谓词："
        "**一条概念的 scope 再精确，也只精确到它引用的词汇为止**。"
        "现在 attach_block 认了「撞菱形点」，这条概念在那一步自动判 NA。")
EVIDENCE = ["4605a0c4a215b03e", "b929ced9b42319f5",
            "3c79fccbc0893691", "e0f459332e57406b",
            "b2f1b087ef082fee"]

from _lib import (attach_block, attach_plan, button, downstream, footprints_after,
                  obstacles, same_off_counter, seg_overlap)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    b = button(prev, action)
    fps = footprints_after(prev, action)
    ap = attach_plan(prev, action)
    if b is None or fps is None or ap is None:
        return "NA"
    obs = set(obstacles(prev))
    if not obs:
        return "NA"
    movers = [b[0]] + sorted(downstream(prev, b[0]))
    land = set().union(*[fps[k] for k in movers if k in fps]) if movers else set()
    hit = land & obs
    if not hit:
        return "NA"                        # 一格死物也不压，这条没话讲
    # 别的已知拒绝原因在场时闭嘴：那一步被拒不是因为这条说的事
    if attach_block(prev, action) is not None:
        return "NA"
    if seg_overlap(prev, action) is not False:
        return "NA"
    vacated = set()
    for _v, cells, nc in ap:
        vacated |= set(cells) - set(nc)
    predict_refuse = bool(hit - vacated)
    really_refused = same_off_counter(prev, nxt)
    return "TRUE" if predict_refuse == really_refused else "FALSE"
