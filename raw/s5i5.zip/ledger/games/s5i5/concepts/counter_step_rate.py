"""一步烧掉的计数条格数只能是 floor(64/本关预算) 或 ceil(64/本关预算)。"""
LEVEL = "L4"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上；换关返回 NA；"
         "**本关的候选预算（_lib.BUDGET_CANDIDATES）在「一步烧几格」这个问题上有分歧，返回 NA**"
         "——`_lib.burn_step_range_by_level` 返回 None 就是分歧。任何一步都查，不需要反推步数。")
NOTE = ("move_counter_row63 要先从计数条反推「已用步数」才敢说下一帧长什么样，"
        "而预算一旦大于 64（第 1 关 = 150），每步烧不到一格、同一个格数对应好几个步数，它就只能闭嘴。"
        "这条概念不反推步数，只查步进量，所以在两关上都开口：第 0 关预算 50 → 每步烧 1~2 格；"
        "第 1 关预算 150 → 每步烧 0~1 格。预算量错了它会当场变反例。"
        "\n\n**v2 只换取数口，主张一个字没改**：原先读 `_lib.BUDGET_BY_LEVEL`，那张表只收唯一解，"
        "于是第 2 关（拟合交出 [200, 201] 两个候选）整关查不到预算，这条概念**在 47 条关内转移上一句话没说**。"
        "那是把「一个常数说不准」放大成了「整关放弃断言」，而这两件事不一样："
        "这条概念要的不是预算本身，是 floor/ceil(64/预算) 那一对整数，而 200 和 201 **给出同一对 (0, 1)**。"
        "换成 `burn_step_range_by_level`（全体候选同意才给答案）之后，它在第 2 关照常开口，"
        "而哪天候选真在这个量上分岔，取数口返回 None，它自动闭嘴——不靠谁记得。"
        "**入册前先拿现成语料撞过一次**（不花预算，方法册「语料本身就是免费的反例发生器」）："
        "第 2 关烧格步进不落在 0~1 的关内转移有 **0 条**；唯一一条越界的是 1→2 换关那一步"
        "（26c0b1510bdb91ca，计数条清零），而换关本来就在 scope 外。所以这次放宽在现有语料上不产生反例，"
        "**它买的是往后 47+ 条转移上的可判错性**：第 2 关哪一步烧了 2 格，这条概念当场变反例。"
        "\n**同一处放宽对 move_counter_row63 无效，说清楚免得下次白试**：那条要的是唯一的已用步数，"
        "而预算 ≥ 64 时每步烧不满一格、`moves_used` 恒返回 None（本关烧格 7 对应步数 21~23 三个），"
        "和候选不唯一无关。它在第 2 关的沉默是**原理性的**，不是这张表的锅。")
EVIDENCE = ["df97f80daf9ccb1c", "64e2bc30cd0e77bc"]

from _lib import burn_step_range_by_level, burned, button


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    rng = burn_step_range_by_level(ctx["level_prev"])
    if rng is None:
        return "NA"
    if button(prev, action) is None:
        return "NA"
    lo, hi = rng
    return "TRUE" if lo <= burned(nxt) - burned(prev) <= hi else "FALSE"
