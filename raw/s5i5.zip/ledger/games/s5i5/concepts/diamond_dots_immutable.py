"""色13四点菱形的那四个点，任何一步都不改色——条从它上面长过去也盖不住它（条身在它下面）。"""
LEVEL = "L6"
SCOPE = "任何动作都查；prev 里认不出任何菱形（没有四邻全是色13的格）返回 NA；换关返回 NA"
NOTE = ""
EVIDENCE = ["c9bf233145fe4d48"]

from _lib import TIP, diamond_dots


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dots = diamond_dots(prev)
    if not dots:
        return "NA"
    for r, c in dots:
        if nxt[r][c] != TIP:
            return "FALSE"
    return "TRUE"
