"""一节的落点碰到另一节原来占的格子时，世界拒不拒整步，只看那一节这一步搬不搬得走：两家的落点还相交就拒，错开了就照做。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上（_lib.button 认得出）；"
         "按钮认不出、落点表算不出来（_lib.footprints_after 返回 None）返回 NA；"
         "**没有任何一节的落点碰到别节的原位**返回 NA —— 这条概念对「八竿子打不着」的步没话讲，"
         "把它们算进来只会让分母虚胖；"
         "**另外三种已知拒因中的任何一种成立或算不出来，都返回 NA**"
         "（贴着的刚体没地方去 _lib.attach_block、落点压住不腾空的死物 _lib.seg_hits_static_obstacle、"
         "节压到推不动那色 _lib.would_refuse）—— 那几步是别人的地盘，蹭进来等于白拿分；"
         "_lib.seg_overlap 算不出来返回 NA；换关返回 NA。"
         "判「世界拒了没有」用 _lib.same_off_counter（除计费条那一排外逐格相同），不用 prev == nxt。")
NOTE = ("**它补的是 _lib.refused 四支拒因里唯一没人计分的那一支。** 全量去重语料里 16 条整步被拒的关内转移，"
        "按拒因分：贴着的刚体没处去 9 条、落点压不腾空的死物 3 条、压到推不动那色 1 条、"
        "**两节撞一起 5 条**。前三支各有概念开口，第四支上四条阻挡类概念（blocked_click_is_noop、"
        "drag_into_obstacle_refuses、click_refused_when_seg_lands_on_wall、blocked_push_refuses）"
        "全判 NA —— 一句话没说（runs 里的 branches.py 逐条打出来）。"
        "**这正是第 129 步栽跟头的同一个形状**：一个世界事实待在本局词汇 `_lib.py` 里，"
        "改 `_lib` 不算改版、从来不被单独评分，于是规划器按它算路线、押注按它押数字，"
        "而账上没有任何东西能推翻它。那一次的代价是一步真预算加一条走空的路线。"
        "现在盘上 12 个按钮里有 2 个（ACTION6:16,57、ACTION6:35,48）正是因为这一支被判拒，"
        "规划器已经在拿它剪枝了，所以它必须先过闸。"
        "\n\n**主张写成两个方向，不是只写「撞了就拒」**：单向的那句话在语料上永远为真而永不冒险，"
        "而本册已经吃过一次「只按一个方向写的守卫对同一机制的另一半全盲」的亏。"
        "这里的另一半是具体的：落点压住的可能是另一节**原来**占的格子，而那一节这一步也在动——"
        "两家一起走开，谁也没撞上，点击照常生效。所以开口条件用的是「碰到别节的**原位**」，"
        "而判据用的是「两家的**落点**还相不相交」；两者不同，正是这条概念说的东西。"
        "\n\n**故意留宽的地方，公示两处**："
        "① 说的是「任何两节」，而语料里的 5 次全是被点那一节或它的下游撞上不动的那一节，"
        "没见过两节都在动却撞在一起的（那要求一条链的两段相向而行，这一关的接头摆法未必做得到）；"
        "② 说「错开了就照做」，而这一半在语料里只由「没碰到」的那些步间接支持，"
        "**「碰到原位、两家都搬走、于是照做」这个正面例子一次都没有**。哪天出现而世界仍然拒绝，"
        "这条概念当场变反例——留宽的价值就在这儿。"
        "\n\n**没写 apply**：这条只说「拒不拒」，拒了盘面除计费条外一格不动，"
        "而那一格归 move_counter_row63 / counter_step_rate 管；替它认领等于抢分。")
EVIDENCE = ["ffa316f279ef6183", "a7b3ba348f90e477", "68c852990e7808a2", "fb7351572f2b1599"]

from _lib import (attach_block, button, footprints_after, same_off_counter,
                  seg_footprint, seg_hits_static_obstacle, seg_overlap, would_refuse)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    b = button(prev, action)
    fps = footprints_after(prev, action)
    if b is None or fps is None:
        return "NA"

    # 开口条件：有没有哪一节的**落点**碰到**另一节原来占的格子**。
    # 用原位而不是落点来定开口范围，是为了让「碰到了、但那一节也搬走了」这一类落进断言里——
    # 那正是这条概念另一半说的事。
    olds = {}
    for k in fps:
        f = seg_footprint(prev, k)
        if f is None:
            return "NA"                       # 有一节定位不到，谁碰谁就说不准
        olds[k] = set(f)
    contact = any(set(fps[i]) & olds[j] for i in fps for j in olds if i != j)
    if not contact:
        return "NA"

    # 别人的地盘一律让出去：只留「纯粹因为两节撞一起」这一片
    if attach_block(prev, action) is not None:
        return "NA"
    if seg_hits_static_obstacle(prev, action) is not False:
        return "NA"
    if would_refuse(prev, action) is not False:
        return "NA"

    ov = seg_overlap(prev, action)
    if ov is None:
        return "NA"
    return "TRUE" if bool(ov) == same_off_counter(prev, nxt) else "FALSE"
