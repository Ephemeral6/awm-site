"""点图例时，被转的这批条转 1 档的落点只要压上一格**推不动的死物**，整击作废：
盘面除了计数条那一格之外一格不变——世界不会像躲开另一根条那样跳到下一档去。"""

LEVEL = "L2"
SCOPE = ("只看落在图例框里的点击；不是就返回 NA。"
         "legend_rot 说不出话（一色多根条、链成环、条被盘边裁着、关节格算不出）返回 NA。"
         "**转 1 档的落点里没有一格压在 FIXED_OBS 上，也返回 NA**——那一片归 "
         "[legend_rotates_bar_about_joint] 管，这一条只管「压上死物」这一种局面。"
         "换关返回 NA。")
NOTE = ("这一条是第 1697 步逼出来的：那一击算出来档 1 压到 9 格色 15，"
        "旋转那条概念照「跳到第一个放得下的档」跳到档 2，预测转了 99 格；世界一格没转。\n"
        "全去重语料里「档 1 压到东西」的图例点击只有 3 条，压到的是**另一根条**的 2 条世界确实跳了档，"
        "压到**死物**的这 1 条世界整击作废。**2 比 1，薄**——所以它单独立一条，"
        "而不是混进旋转那条的分数里：那一条的 S 已经背着二十几条证据，"
        "把一条只有单证的新主张塞进去，它挨打时分数不会掉在该掉的地方。\n"
        "它也不靠 legend_rot 的 steps 判对错——那正是被改的东西，拿它核自己等于没核。"
        "这里只用 legend_rot 圈定「哪批条、绕哪个点」，然后自己算档 1 落点、"
        "自己拿**帧差落在哪几格**去判：整击作废意味着帧差只许出现在计数条那一行。\n"
        "「推不动」这个分类是平移那边量出来的（`_lib.FIXED_OBS`，第 1 关顶上去被整步拒绝的那一片）。"
        "这一条把它借到旋转上，同时也就把那个分类押上了：哪天出现一片色 15 被转走，两边一起垮。\n"
        "\n**v2 一个字没改主张，改的是我对它那个 100% NA 的读法——它不是主张窄，是构造上不可被打分。**\n"
        "起因：settle 每批都点名本条全语料 TRUE 0 / FALSE 0 / NA 全部；"
        "而在真的发生了一次图例转动、全册逐格说中 243/243 的那一批之后，它**仍然**一个字没说，"
        "于是我读成「取数口错位、该改」。逐环计数（`runs/<run>/probe_na2.py`，"
        "三条判据写在跑之前：卡在取数口=错位该改／卡在末环=主张窄不该改）把这个读法打掉了：\n"
        "  全去重语料 1159 条：换关 0 ／ legend_click 说不出 1091 ／ legend_rot 说不出 3 ／"
        "**档 1 落点没压死物 64** ／ 开口 **1** ／ 抛异常 0。\n"
        "取数口没坏——它在 65 条算得动的图例转上都醒着，只是其中 64 条不满足「压到死物」。\n"
        "**真正的病在这里**：那唯一 1 条开口就是 8f8e7e910a916b4e，本条自己的 EVIDENCE。"
        "held_out(X) = 全部转移 − X 自己的依据，所以**它的考场里一条开口都不剩，N 永远是 0**，"
        "不是「还没考」，是**这本语料再怎么长它都考不到**。\n"
        "**这两种病在 settle 的读数上长得一模一样**（都报 TRUE 0 / FALSE 0 / NA 全部），"
        "只有逐环计数分得开；我差一点就按「错位」去改一条其实没坏的取数口。\n"
        "**要给它评分只有一条路：去造一步那样的局面**——找一个档 1 会压到死物的图例点击发出去，"
        "那一条新转移不在它依据里，是它的第一次真考试。语料里现成的 64 条都不满足，等不来。\n"
        "**故意不改主张、不缩 scope、不撤册**：它没有说错任何话，撤它等于因为「考不到」而删掉一条对的话。")
EVIDENCE = ["8f8e7e910a916b4e"]      # 第 1697 步：档1 压 9 格色 15，世界只烧了计数器那一格

from _lib import legend_click, legend_rot, rot_cell, FIXED_OBS, COUNTER_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    try:
        if legend_click(prev, action) is None:
            return "NA"
        plan = legend_rot(prev, action)
    except Exception:
        return "NA"
    if plan is None:
        return "NA"

    n, m = len(prev), len(prev[0])
    src = set(plan["src"])
    p = plan["pivot"]
    # 档 1 的落点里有没有压在推不动的死物上
    压死物 = False
    for rc in src:
        d = rot_cell(rc, p, 1)
        if (0 <= d[0] < n and 0 <= d[1] < m and d not in src
                and prev[d[0]][d[1]] in FIXED_OBS):
            压死物 = True
            break
    if not 压死物:
        return "NA"

    # 独立读法：整击作废 = 帧差只许落在计数条那一行
    for rr in range(n):
        for cc in range(m):
            if prev[rr][cc] != nxt[rr][cc] and rr != COUNTER_ROW:
                return "FALSE"
    return "TRUE"
