"""点「缩」图标时，只要该色**有任意一根条**沿长轴的长度 ≤ GROW（再缩 3 格身体就没了），
世界整步拒绝：除计费行 63 外一格不变——连那些还缩得动的同色条也一起不动。"""
LEVEL = "L2"
SCOPE = ("只看 click_panel 判「点中了某个面板的缩图标」（sign = -1）的步；点的是伸、没点中图标、"
         "bar_units 读不出这一色的条（返回 None/空）：一律 NA。\n"
         "**开口的条件**：该色的条里存在长度 ≤ GROW 的（长度 = 帽在上下侧时的行数、帽在左右侧时的列数）。"
         "一根都不到这个长度：返回 NA——这条概念不断言「缩得动就一定动」，那一半是别人的地盘。\n"
         "换关（ctx 里 level_prev != level_next）返回 NA。\n"
         "**明说没有样本能区分的那一点**：语料里开口的每一步，该色**所有**条都同时缩过头"
         "（第 475 步是 5 根全部，其余三步各只有 1 根条），所以「整步拒」与「每根条各自拒、"
         "恰好这次全部都拒」在现有样本上读数相同。docstring 写的是前者（更强的那一句），"
         "它要被推翻只需要一个『一根缩过头、另一根还缩得动』的构型，语料里没找到——不是不存在。\n"
         "**为什么没有 apply**：被拒的步帧差是 0~1 格（只可能是计费行 63），写 apply 只能去断言"
         "「其余 4032 格不变」——那会把一大堆非帧差格算进 claimed/hit，把 P 和 E 撑虚。"
         "计费行怎么烧是 [move_counter_row63] 的地盘，这条不碰。")
NOTE = ("起因：`_lib.refused()` 在这四步上弃权（返回 None）。弃权发生在 `blob_moves()` 的 "
        "`if nb is None or nb[0] > nb[1] or nb[2] > nb[3]: return None`——有一根条的位移会把 bbox "
        "缩成非法，于是**整个** blob_moves 返回 None，`bar_footprints_after` → `footprints_after` "
        "→ `refused` 一路 None，全册对这四步失语；而世界那边四次的回答一样：整步拒绝。"
        "弃权不算错，但这一片是能开口的，所以另写一条。**这条概念没有改 _lib，refused() 在这四步上"
        "至今仍返回 None**（已复核，见下面的跑法）。\n"
        "**三个数（全去重语料，真跑过）**：跑法 `python runs/s5i5-0907-0046/run_proposal.py`，"
        "输出留在 `runs/s5i5-0907-0046/run_proposal.out`。语料是活文件——出这组数时 "
        "`transitions.jsonl` 是 505 行原始记录，按 tid 去重 202 条（tid 是内容哈希，同一构型撞多次只算一条），"
        "其中换关 6 条（assert_ 自己判 NA）。\n"
        "  **TRUE 4/202 · FALSE 0/202 · NA 198/202 · ERROR 0/202**（分母是去重后的条数）。\n"
        "  开口面有多窄：去重语料里 click_panel 判「点中缩图标」的步共 53 条，这条概念在其中 4 条上开口，"
        "另外 49 条判 NA（没有一根条缩过头）。四条开口的步全部落在关 3，第 475~478 步，四种不同的节色"
        "（11、8、9、14），世界四次都拒。\n"
        "  按判据册算：`held_out` = 202 − EVIDENCE(1) = 201 条，**N = 3、S = 3/3、C = 3/201**，"
        "held_out 上 0 反例；R8 自查（在自己 EVIDENCE 上判 FALSE 的条数）= 0；"
        "硬要求 4 自查：这四条 tid 在 `runs/<run>/disclosed.json` 里一条都没有，没有被披露过的反例要收。\n"
        "**EVIDENCE 为什么只放 1 条**：四条同类样本，全塞进 EVIDENCE 会让 held_out 里 N = 0、"
        "S 记 UNMEASURABLE，构造上就打不出分。只留 `c400e131d27c4ced`（第 475 步）——它是最先"
        "暴露这一类弃权的那条，也是唯一一条「同色 5 根条全部缩过头」的多条样本，判据是照着它写的；"
        "另外三条（476/477/478 步，各只有 1 根条）是纯确认样本，留在考场里受检验。\n"
        "**阈值有多少证据（跑法 `run_proposal_edge.py`，输出 `run_proposal_edge.out`）**："
        "把 53 次点缩按「该色最短那根条的长度」分档，实测长度只取 2、5、8、11、14、17、20、23、26 —— "
        "**全是 2 + 3k**，本局根本不存在长度 3 的条。所以判据写成 `≤ GROW` 与写成 `== 2` 在本局语料上"
        "完全等价；写成前者是因为它不依赖「2 + 3k」这条格点规律，但**格点之外那一档（长度恰为 3）"
        "没有任何样本**，明说。\n"
        "  阈值不是「短了就不许」：最短长度 5 的 6 步里世界动了 4 步（第 160/170/174/186 步），"
        "另 2 步被拒（第 129/132 步）是别的原因；也就是说 5 → 2 允许，2 → 缩没不允许，"
        "分界就在「身体会不会归零」，不在「条太短」。\n"
        "**没检验过的，明说**：① 伸的方向一句没断言（sign = +1 一律 NA）；"
        "② 「一根缩过头、另一根还缩得动」的构型在这 202 条里没找到，所以 docstring 里"
        "『连还缩得动的同色条也一起不动』这半句是没有独立证据的那一半；"
        "③ 长度 2 的条被别的条推着走（不是被点）会怎样，不在这条概念的 scope 里，也没看；"
        "④ 计费行 63 在这四步里变了 3 次、没变 1 次（全帧差 1/0/1/1 格），这条概念用 "
        "`same_off_counter` 判，所以对计费行的行为不发表意见。")
EVIDENCE = ["c400e131d27c4ced"]

from _lib import GROW, bar_units, click_panel, same_off_counter  # noqa: F401


def _overshrink(g, action):
    """点的是「缩」时，该色沿长轴长度 ≤ GROW 的那些条：[(bbox, 帽侧, 长度), …]；
    不是缩、没点中图标、读不出条 → None（不开口）。"""
    cp = click_panel(g, action)
    if cp is None:
        return None
    color, sign = cp
    if sign != -1:
        return None
    units = bar_units(g, color)
    if not units:
        return None
    bad = []
    for box, side, _caps in units:
        t, bo, l, r = box
        ln = (bo - t + 1) if side in ("top", "bottom") else (r - l + 1)
        if ln <= GROW:
            bad.append((box, side, ln))
    return bad


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    bad = _overshrink(prev, action)
    if not bad:
        return "NA"
    return "TRUE" if same_off_counter(prev, nxt) else "FALSE"
