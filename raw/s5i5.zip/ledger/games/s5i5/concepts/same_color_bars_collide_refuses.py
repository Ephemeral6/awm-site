"""同一个节色的两根条抢同一格时，世界整步拒绝：一格不动，只有计费条照走。"""
# ---------------------------------------------------------------------------
# 影子册候选：same_color_bars_collide_refuses 的加宽版（v1 -> candidate）。
# 不进闸。由一个只看盘面、没看过调用方推理的会话写出，读数来自
# runs/s5i5-0907-0046/deadfour.snap 这份冻结快照（transitions.jsonl 504 行 / 去重 201 条）。
#
# 改了什么：**只改谓词，不改断言**。
#   v1 用 _lib.same_bar_collide，它只看 blob_moves 报出来的那几根条——也就是**被点那一色自己**
#   直接被催动的条。被别的颜色拖着走（bar_chain 认父）的同色条，在它眼里是不动的，
#   于是「一根条被拖过来压在同色另一根条身上」这一类整个看不见。
#   候选把「正在动的条」从『被点那一色』扩到『bar_chain 传播下来所有位移非零的条』，
#   互抢的口径照抄 same_bar_collide（新占的身体格 vs 同色另一根条的落点身体格，帽不算）。
# 断言、NA 的方向、不立逆命题，全部沿用 v1。
# ---------------------------------------------------------------------------
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上（_lib.click_panel 认得出）；换关返回 NA；"
         "blob_moves / bar_units_all / bar_chain 任一算不出来（含 bar_units_all 因两根同色条的"
         "**原框**就重叠而闭嘴、bar_chain 出现 AMBIGUOUS）返回 NA；"
         "位移传播后同色两根条没有互抢返回 NA —— 这条概念对「不抢」的步没话讲，"
         "「不抢就照做」是另一条主张，它要先排掉全部别的拒因才站得住（异色相撞就是其中一支，"
         "见 NOTE 里 483e4161735d64c1）；"
         "判「世界拒了没有」用 _lib.same_off_counter（除计费条那一排外逐格相同），不用 prev == nxt。")
NOTE = ("**为什么加宽**：v1 在 held-out 上 N=0（TRUE 0 / FALSE 0 / NA 199），也就是"
        "「两根同色条撞上会被整步拒绝」这条规律**除了立册用的那两条以外，从没被现实检验过**。"
        "尸检（runs/s5i5-0907-0046/deadfour.py，全去重语料 201 条）定位到 NA 的去向："
        "第 41-43 行的 same_bar_collide=False 吃掉 189 条、换关 6 条、same_bar_collide=None 4 条，"
        "表态只有 2 条（735a4af36f9f33bb、12020123f0011f44），而这 2 条正是它自己的 EVIDENCE——"
        "**EVIDENCE 永久退出 held-out，所以 N=0 不是「没被推翻」，是「它管的那一类全被自己吃掉了」**。\n"
        "**加宽捞回来的是哪一条**：bdf9e287ce42c227（第 349 步，关 3，ACTION6:51,57）。"
        "那一步点的是色 8 的图标，blob_moves 只报了色 8 那一团往下 3 格；"
        "色 11 的条 (9,11,21,46) 认色 8 (12,22,45,47) 作父，被拖着一起往下 3 格，"
        "落点 (12,14,21,46) 压在同色静止条 (12,14,19,44) 身上 **72 格**。"
        "世界整步拒绝（same_off_counter 为真）。v1 的 same_bar_collide 在这一步返回 False，"
        "因为色 11 不是被点那一色。这条 tid 不在任何概念的 EVIDENCE 里，是真正的 held-out。\n"
        "**这条判据被检验了多少**（deadfour.snap，全去重语料 201 条）："
        "加宽谓词命中 3 条、不命中 187 条、算不出来 11 条；"
        "命中的 3 条世界全拒（735a4af36f9f33bb、12020123f0011f44、bdf9e287ce42c227），"
        "命中而世界照做的 0 条。三条真阳里两条是同一处几何连着两帧（第 200、201 步），"
        "所以真正独立的真阳是 **2 处几何**，撑着它的仍旧是 187 条零假阳。"
        "不命中的 187 条里世界照样拒了 24 条——那些是别的拒因，不是这条的反例。\n"
        "**assert_ 在全去重语料 201 条上的四数**（deadfour.py 第 ⑧ 节实跑）："
        "TRUE 3 / FALSE 0 / NA 198；扣掉 EVIDENCE 2 条后 held-out 199 条上 "
        "TRUE 1 / FALSE 0 / NA 198。**N 从 0 变成 1**。\n"
        "**11 条算不出来是诚实的空白，不是安全**：其中 ffff19fe80376f17 一度看着像反例"
        "（同色落点重叠 9 格而世界照做），后来查明是 bar_units 把交叉的同色条并进了一个框；"
        "bar_units_all 现在遇到「两根同色条的原框就重叠」直接返回 None，"
        "所以这一类局面**这条概念不表态**。要靠它挡动作的规划器必须记住："
        "返回 NA 的步不等于安全，只等于说不准。\n"
        "**逆命题仍旧没有立**：这条只说「抢了就拒」。想要「不抢就照做」的那一半，"
        "至少还得排掉异色相撞——483e4161735d64c1（第 350 步，关 3）就是同色不抢、"
        "却因色 8 (12,22,45,47) 与色 11 (12,14,19,44) 的落点重叠 9 格而被整步拒绝。")
EVIDENCE = ["735a4af36f9f33bb", "12020123f0011f44"]

from _lib import (bar_chain, bar_units_all, blob_moves, cells_in, click_panel,  # noqa: F401
                  moved_box, same_off_counter)


def _after_boxes(g, action):
    """逐条算落点框与位移：{(色, 原框): (落点框, 位移)}；算不出来返回 None。

    口径抄 _lib.bar_footprints_after，只有一处不同：**身体框与帽分开留着**。
    帽必须分开，因为一根条的帽本来就压在父条的身上，把帽算进「相撞」会把每一次
    正常的连环拖动都误判成撞车。
    """
    cp = click_panel(g, action)
    if cp is None:
        return None
    color, _sign = cp
    mv = blob_moves(g, action)
    if mv is None:
        return None
    allu = bar_units_all(g)
    if allu is None:
        return None
    ch = bar_chain(g)
    if ch is None or any(v == "AMBIGUOUS" for v in ch.values()):
        return None
    moves_by_box = {tuple(box): d for box, _s, d in mv}
    newbox, give = {}, {}
    for box, side, _caps in allu.get(color, ()):
        d = moves_by_box.get(tuple(box))
        if d is None:
            return None
        nb = moved_box(box, side, d)
        if nb is None or not (0 <= nb[0] <= nb[1] <= 63 and 0 <= nb[2] <= nb[3] <= 63):
            return None
        key = (color, tuple(box))
        newbox[key], give[key] = nb, d
    changed = True
    while changed:                       # 沿 bar_chain 把位移传给被拖着走的条
        changed = False
        for k, units in allu.items():
            for box, _side, _caps in units:
                key = (k, tuple(box))
                if key in newbox:
                    continue
                par = ch.get(key)
                if par is None or par == "AMBIGUOUS" or par not in give:
                    continue
                d = give[par]
                nb = (box[0] + d[0], box[1] + d[0], box[2] + d[1], box[3] + d[1])
                if not (0 <= nb[0] <= nb[1] <= 63 and 0 <= nb[2] <= nb[3] <= 63):
                    return None
                newbox[key], give[key] = nb, d
                changed = True
    out = {}
    for k, units in allu.items():
        for box, _side, _caps in units:
            key = (k, tuple(box))
            out[key] = (newbox.get(key, tuple(box)), give.get(key, (0, 0)))
    return out


def same_color_grab(g, action):
    """同色两根条**新抢**同一格：返回 [(条A, 条B, 抢了几格)]；算不出来返回 None。

    新抢 = 甲的落点身体里**原来不属于甲**的那些格，落在乙的落点身体上（或反过来）。
    「原来不属于甲」这一步是从 _lib.same_bar_collide 抄的：两根条本来就贴着不算撞，
    有一根**挪进**另一根占的地方才算。
    """
    ab = _after_boxes(g, action)
    if ab is None:
        return None
    before = {k: set(cells_in(k[1])) for k in ab}
    after = {k: set(cells_in(ab[k][0])) for k in ab}
    keys = sorted(ab, key=lambda k: (k[0], k[1]))
    out = []
    for i, k1 in enumerate(keys):
        for k2 in keys[i + 1:]:
            if k1[0] != k2[0]:
                continue
            grab = ((after[k1] - before[k1]) & after[k2]) | ((after[k2] - before[k2]) & after[k1])
            if grab:
                out.append((k1, k2, len(grab)))
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    c = same_color_grab(prev, action)
    if c is None or not c:
        return "NA"
    return "TRUE" if same_off_counter(prev, nxt) else "FALSE"
