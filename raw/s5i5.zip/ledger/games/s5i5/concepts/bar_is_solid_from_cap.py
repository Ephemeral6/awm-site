"""每一根条都是从它自己那排帽往外的一整块实心矩形：帽和自由端之间没有洞、没有断口。

具体地：对盘上每一根条，它的 bbox 里的每一格，要么是这一色，要么是尖或菱形四点（色 13，
它们盖在条身上，算透明）。等价的说法是「条不会被掏空、也不会分成两截」。

为什么单写一条：这句话一直躺在 _lib.bar_units 的读法里当地基——改 _lib 不算改版，
所以它从来没有单独被打过分。而任何一条「尖到不了某处」的论证都踩着它：
论证说「条身必须铺满帽到自由端之间的每一行，所以躲不开中间那道墙」，
如果条可以中间空一段，那道墙就躲得开，论证当场作废。地基要么走闸，要么不许拿来撑论证。
"""
LEVEL = "L1"
SCOPE = ("看动作后那一帧 nxt；换关（ctx.level_prev != level_next）返回 NA；"
         "bar_units_all 读不出任何一根条返回 NA。")
NOTE = ""
EVIDENCE = ["210e3ed61809845b", "f813b5c58d51be34", "2396868b81112543"]

from _lib import TIP, bar_units_all, cells_in


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    allu = bar_units_all(nxt)
    if not allu:
        return "NA"
    for color, units in allu.items():
        for box, _side, _caps in units:
            for r, c in cells_in(box):
                v = nxt[r][c]
                if v != color and v != TIP:
                    return "FALSE"
    return "TRUE"
