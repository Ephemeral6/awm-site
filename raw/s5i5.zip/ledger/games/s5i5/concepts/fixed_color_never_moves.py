"""推不动那一色（_lib.FIXED_OBS）占的格子集，在同一关内一步也不变：既不被顶着走，也不被拖着走。"""
LEVEL = "L2"
SCOPE = ("不限动作——这一关内的**每一条**转移都在断言里，这是它比 wall_sticks_to_free_end 更硬的地方。"
         "三处返回 NA：换关（ctx.level_prev != level_next）——那一色是随关出现和消失的，"
         "跨关比格子集没有意义；`action == 'RESET'`——整个盘重建，不是关内的一步；"
         "prev 里那一色一格也没有——无可断言。ctx 缺失时不敢判换关，也返回 NA。")
NOTE = ("**它是拿语料补 wall_sticks_to_free_end 公示的那个洞补出来的，零动作。**"
        "那条概念 v2 为了让一次观测判对，在 `_lib.attached` 里加了一句「种子是 FIXED_OBS 那色就跳过」，"
        "并在自己的 NOTE 里如实标成洞：「这里只是照着颜色分，没有机制」。"
        "全量语料（78 条去重转移，runs 里的 fixed.py）给出的答案是：那一色的格子集只在三条转移上变过，"
        "而这三条全是**换关或 RESET**（0→207、207→9、9→0，都不是平移）；关内一次也没动过。"
        "所以「不跟着走」不是一条关于搬运的特例，是「它压根不动」的推论。"
        "\n\n**同一个属性的另一面由 refused 管，不重复断言**：语料里有一步某一节的落点压住那一色 18 格，"
        "世界整步拒绝、真帧一格没变（4605a0c4a215b03e）。也就是说要它动的那一步会被拒，"
        "所以「顶着走」这一支在 attached 里根本够不着——`refused` 先响。"
        "这解释了为什么 attached 里那句跳过只在**缩回去**那一半用得上，"
        "而语料里唯一一次它贴着正在动的自由端（c8cabd8816d74ec0）也正是缩的方向。"
        "**仍然是洞的部分**：为什么这一色钉死、别的墙推得动，帧上看不出区别（同是矩形、同在障碍集里）；"
        "这里只断言「它不动」这个事实，不声称知道原因。"
        "\n\n**故意不写 apply。** 它能生成的是「那 207 格保持原色」——一句真话，"
        "但它整片落在帧差之外，只会把 P 的分母灌满不变格、把 P 稀释着抬高，对 E 一格贡献都没有"
        "（方法册「认领对了几格的分母里含着不变格」）。不变量式的概念只写 assert_。")
EVIDENCE = ["c8cabd8816d74ec0", "4605a0c4a215b03e"]

from _lib import FIXED_OBS


def _cells(g):
    return frozenset((r, c) for r, row in enumerate(g)
                     for c, v in enumerate(row) if v in FIXED_OBS)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action == "RESET" or action.startswith("RESET"):
        return "NA"
    a = _cells(prev)
    if not a:
        return "NA"
    return "TRUE" if _cells(nxt) == a else "FALSE"
