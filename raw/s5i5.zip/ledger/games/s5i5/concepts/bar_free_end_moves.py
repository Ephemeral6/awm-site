"""点面板图标，那根条的自由端（帽的对端）沿图标方向恰好走 3 格，帽那一端和短边宽度都不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点在某块面板的图标上（_lib.click_panel 认得出）；"
         "该色的条一根也分不出来、帽端认不出、按钮方向与条长轴不符，都返回 NA；"
         "**换关返回 NA，且这道判据是前推算的（_lib.will_levelup），不查 ctx 里的 level_next**——"
         "押注时那个量还不存在；"
         "落点框整个在画得出来的那一块之外、或缩过头返回 NA"
         "（长出盘外/长进计数条那一排的，按裁到画得出来那一截算）；"
         "**有任何一根条会长进面板或图例那种框，整条返回 NA** —— 实测那种条会顶在框边停住，"
         "而同一击里别的条照走，单帧上分不出它是停了还是长到框底下去了；"
         "**世界会整步拒绝这一次点击（_lib.refused）返回 NA** —— 那一次条一格不动，"
         "由 blocked_click_is_noop / blocked_push_refuses 管；`refused` 算不出来也返回 NA。"
         "被拒之外一律开口，包括贴着的死物被拖着走或被顶着走的那些步（死物去哪由 wall_sticks_to_free_end 管）；"
         "**帧上那顶无主帽指认这一击会动的条里有一根其实是两根贴死的条"
         "（_lib.merged_pair_suspect）返回 NA**（v15）—— 计划里的框数从一开始就少一个，"
         "拿它和 next 的框集合比是在比两份不同口径的清单。")
NOTE = ("v1 只允许「+3 或不变」，被缩短那一步（1e5c6990b6e3714b）打脸；改成自由端沿按钮方向 ±3。"
        "v2 不改主张，只改 apply 与 _lib：条走到菱形上时菱形四点(色13)不被覆盖，"
        "所以条身不再认领 prev 已经是色13的格子（c9bf233145fe4d48）。"
        "v3 死于 4605a0c4a215b03e：撞墙那一步世界整帧不动，而这条概念照算「自由端走了 3 格」，"
        "还替它认领了 13 格。缩 scope 把撞墙那一步让出去——它不是「条怎么动」的事，是「点击有没有生效」的事。"
        "v4 只改 apply，主张没动，两处都是离线拿规划器走假想路线试出来的（没花预算）："
        "(1) v2 那条「prev 是色13就不认领」写宽了——它想护的是菱形四点，却连手臂自己的尖也放过，"
        "于是上游长进下游尖原来那一格时，那一格留着旧的色13不擦，下一帧凭空多出一个尖。改成只放过 diamond_dots。"
        "(2)「腾出来的格子回底色」漏了一句前提：这一步之后有别的东西占着它就不该回底色。"
        "缩短一节时下游正好落进腾出来的格子，v3 在那里写底色、chain_drags_downstream 在那里写下游，"
        "两条概念对同一格打架，合起来算不出下一帧——凡是带下游的缩短动作都算不出来。"
        "现在按 _lib 的落点表让位。"
        "v5 是**把 v3 缩掉的一半要回来**，主张仍没动：v3 那次缩得太狠，把「压到死物」整类让给了"
        "blocked_click_is_noop，而第 2 关证明压到色 1 那种死物时点击照常生效、条照样走 3 格"
        "（3c79fccbc0893691、e0f459332e57406b 上这条概念当时判 NA，一句没说，"
        "而这两步里条确实各走了 3 格——**闭嘴不算说对**）。判据从 would_block 换成 would_refuse。"
        "让位查的表也从 footprints_after 换成 occupied_after：这一步之后占着格子的不只有各节，"
        "还有搬过来的死物块，漏掉它就会把死物的新位置写成底色，和推挤那条打架。"
        "**v6 挨了 10 个反例，全是同一个洞**（18d2fe07cdd8390a 等）：v5 的「会不会被拒」只查两件事——"
        "节自己压到推不动那种死物、以及顶着死物往前推的落点算不算得出来。它漏掉的是**拖**："
        "条缩回去时，贴在自由端外面的那面墙跟着一起退，而那面墙退过去的地方可能没空；"
        "世界于是整步拒绝，条一格不动，这条概念却照算「走了 3 格」，还认领了 100 多格。"
        "为什么会漏：v5 的守卫（hit_blobs / push_plan）判的是**落点踩到谁**，而缩回去时落点是变小的，"
        "所以整个「拖着走」那一半机制在守卫眼里根本不存在——"
        "一个只按一个方向写的守卫，对同一机制的另一半是全盲的，而它不会报错，只会理直气壮地算错。"
        "判据换成 _lib.refused（贴着的刚体没地方去 / 节压到推不动的 / 两节落点撞一起，三合一），"
        "在全量 64 条同关转移上核过：对 64、错 0、算不出来 0。主张本身一个字没动。"
        "\n\n**b2f1b087ef082fee 上又判过一次 FALSE，主张仍然一个字没动，仍然是 `_lib.refused` 漏了一种拒绝。**"
        "这一次漏的是第五种：跟着走的刚体**新压**到菱形目标点上，世界整步拒绝"
        "（现在单独走闸，见 [wall_push_onto_target_dot_refuses]）。"
        "**值得记的是这条概念第三次因为同一个位置挨打**——v6 那次漏「拖」，这次漏「新压目标点」，"
        "两次都不是主张错，是 `refused` 不够全。一条概念把「什么时候闭嘴」外包给一个谓词，"
        "它的分数就等于那个谓词的完备性；而那个谓词在词汇里，**改它不算改版、也从来不单独打分**。"
        "所以这条概念的 S 会反复被别人的洞拉低，而拉低它的东西不出现在任何一条概念的成绩里。"
        "\n\n**v10 换读法，主张一个字没动：从按色读换成按条读。**"
        "v9 的取值路径是 button → bar_box → capped_side，三样都建在「一色一条」上。"
        "一色两根条时 bar_box 给的是两根的并集，那是个跨半个盘的假条。"
        "它一直没挨打，只因为假条上 capped_side 找不到唯一的帽边、整色被跳过——"
        "又是**靠一个副作用蒙混过关**。直到词汇里的落点表学会把伸出盘外的条裁到盘内，"
        "refused() 从「算不出」变成「不会被拒」，这条概念第一次在一色多条的盘上开口，当场判错三次。"
        "现在走 click_panel + blob_moves（本来就按条），逐根条各自算落点；"
        "单条色上两条路径给出逐字相同的读数，所以原来能开口的那些步一条不变。"
        "留一条已知的窄处：自由端伸出盘外的条，落点框被裁短，读回来的 bbox 也是短的——"
        "两边同样短，所以对得上；但如果哪天世界不是「照走只画一截」而是别的做法，这条会判错，"
        "**照样开口，错了就是反例**。"
        "v10 一进门就挨了两下，两下都是「盘」的边界读错了，主张仍没动："
        "一是**计数条那一排也画不下条**（条长到第 63 行看不见，读回来停在 62）；"
        "二是**条长进面板会停在框边**，而同一击里别的条照走——这一类还不知道机制，先让出去。"
        "\n\n**v12 是在终局卡上被打的，主张仍然一个字没动，改的是「换关」那道 scope 怎么算。**"
        "ec8ffe6775dff87f 那一步过关，整盘重画 872 格，而这条概念交出了一套「条挪了 3 格」的预测，"
        "错 8 格。scope 里「换关返回 NA」一直写着，`assert_` 也一直守着——"
        "**但它查的是 `ctx[\"level_next\"]`，而押注发生在这一步走之前，那时候没有 level_next**。"
        "于是同一道 scope，检查器守得住、生成器守不住，而且不是因为忘了写，"
        "是因为**那道判据本身要等结果才算得出来**。换成前推的 `_lib.will_levelup`"
        "（主张走 [levelup_when_all_home]：尖铺满菱形中心就换关）。"
        "教训比这条概念大：**一道 scope 只有在动作发生之前算得出来，生成器才守得住它**——"
        "拿事后才知道的量写 scope，检查器的分是干净的，规划器照着算的下一帧却是脏的。"
        "\n\n**v13 和 [bar_tip_follows] v7 第六次成对挨打，同一条 tid（42341047045cf7fd，"
        "终局卡第 3 关第 1084 步）。主张一个字没动，改的是 `_lib.refused` 里的一个洞。**"
        "这两条的 scope 都写着「世界会整步拒绝就返回 NA」，而那一步世界确实拒了，`refused` 说不拒——"
        "**它在全去重语料 595 条上唯一的一次漏报，也是头一条反方向的漏（此前 41 条全是假警报）。**"
        "病根与修法记在 [refused_says_it_exactly] v5 的 NOTE 里：手臂有一节缩到了零长，"
        "帽还留在原地贴着邻节，而旧的六种机制问的全是「落点上有什么」——落点九格全是底色。"
        "新增 `_lib.stranded_cap` 之后这两条都回到弃权。"
        "**这一步是本条 apply 在全语料上唯一说错的地方：35 格，改后 0 格。**"
        "成对挨打这件事第三次记：反例数 2，独立证据仍然只有 1。"
        "\n\n**v15：v13 那次的修法本身是错的，两天不到被自己的探测击打掉，这一条又跟着挨了一次。**"
        "反例 a197d1d59397e644（第 1086 步 ACTION6:28,54）。`_lib.stranded_cap` v13 版断定这一击会被拒，"
        "策略专门发出去打它，世界照做（帧差 47 格）。`refused` 修好之后这条概念不再弃权、开口判 FALSE。\n"
        "**真因和 [every_blob_moves_on_its_own_axis] v9 是同一个**：孤帽不是「某一节缩到零长」的墓碑，"
        "是**两根条贴死在一起被连通块并成了一根**（色 11 的 unit 数 prev 4 → next 5，"
        "prev 上一根 28 列长的条在 next 上裂成两根）。这条概念的 `_plan` 只排得出 4 个框，"
        "而 `assert_` 拿它和 next 上该色的框集合比——**两份清单的口径从一开始就不同**，判 FALSE 是必然的。\n"
        "**处置**：`merged_pair_suspect` 为 True 时 assert_ 与 apply 一起弃权（生成器守同一个 scope）。\n"
        "**代价先量后改**（`runs/<run>/barfreena.py`，全去重语料 608 条，四条判据跑之前写死）："
        "TRUE 514 / FALSE 1 / NA 93；加闸后改判的只有这一条（FALSE → NA），TRUE → NA **0 条**"
        "（分母 = 现在开口的 515 条）；apply 少认领 35 格（分母 5110），说错 9 → 0。\n"
        "**巧的是这 35 格和 v13 记的那 35 格一样多**，但不是同一批格子——v13 那 35 格在第 1084 步，"
        "这 35 格在第 1086 步。数字撞车，别当成同一件事。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "1e5c6990b6e3714b", "c9bf233145fe4d48",
            "4605a0c4a215b03e", "3c79fccbc0893691", "e0f459332e57406b",
            "18d2fe07cdd8390a", "755bd691d870dc30", "ff6406e7f7a778ad", "6b7dfafde6cd2977",
            "e9d7089d391590de", "5036b062c56885d6", "ffa316f279ef6183", "a7b3ba348f90e477",
            "68c852990e7808a2", "fb7351572f2b1599", "b929ced9b42319f5",
            "b2f1b087ef082fee",
            # v10：一色两根条，按色读的假条把落点算歪
            "4012e7320d323009", "298f886fec8e32fe", "b6893fd9b900d4c5",
            # v11：条长进面板会停在框边（同一击里别的条照走）；计数条那一排也画不下条
            "3d0f607df0a5eb43", "cd787353d6bd4130",
            # v12：换关那一步整盘重画，而「换关」原先只有事后才算得出来
            "ec8ffe6775dff87f",
            # v13：手臂有一节缩到零长（像素上一格不剩、只剩一顶没人认领的帽），
            #      世界整步拒绝，而 _lib.refused 的六种机制全说「不拒」——它在全语料上唯一的漏报
            "42341047045cf7fd",
            # v15：上面那条的读法被推翻——孤帽不是墓碑，是两根条贴死被并成了一根；
            #      计划 4 个框，next 上裂成 5 个 → 判 FALSE
            "a197d1d59397e644",
            # 第八种拒绝形态（楔住）逼出来的：这一步 refused() 原先说「不会拒」，
            # 本条信了它，一击预测错 18 格；_lib 补上 wedged_grow_and_still 后本条在这条上判 NA
            "99bd12bdb9dc06d9"]

from _lib import (BG, _clip_box, bar_units_all, blob_moves, click_panel,
                  diamond_dots, draw_rows, landing_in_deco, merged_pair_suspect, moved_box,
                  occupied_after, refused, tips, will_levelup)


def _plan(prev, action):
    """[(这根条原来的 bbox, 帽侧, 位移, 裁到画得出来那一块的新 bbox)]，以及被点的色。"""
    cp = click_panel(prev, action)
    if cp is None:
        return None
    color = cp[0]
    if will_levelup(prev, action) is True:     # 换关那一步整盘重画，条挪没挪在那一帧上看不见
        return None
    mv = blob_moves(prev, action)
    if mv is None:
        return None
    if refused(prev, action) is not False:     # 会被整步拒 / 算不出来会不会被拒 —— 都不开口
        return None
    if landing_in_deco(prev, action) is not False:   # 长进面板/图例：还不知道会怎样
        return None
    rmax = draw_rows(prev)
    out = []
    for box, side, d in mv:
        nb = _clip_box(moved_box(box, side, d), rmax)
        if nb is None:
            return None
        out.append((tuple(box), side, d, nb))
    return color, out



def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    # 计划里的框数不可信就闭嘴：两根贴死的条被并成一根时，这份清单和 next 的清单口径不同（v15）。
    if merged_pair_suspect(prev, action) is True:
        return "NA"
    color, plan = p
    allu = bar_units_all(nxt)
    if allu is None:
        return "NA"
    got = sorted(tuple(box) for box, _s, _c in allu.get(color, []))
    want = sorted(tuple(nb) for _b, _s, _d, nb in plan)
    return "TRUE" if got == want else "FALSE"


def _cells(box):
    t, bo, l, r = box
    return {(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)}


def apply(prev, action, ctx=None):
    """条身的增减；尖那两格让给 bar_tip_follows。

    两条让位规则：菱形四点条身盖不住；腾出来的格子只有在这一步之后没人占时才回底色。
    """
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None                        # SCOPE 里换关就返回 NA，生成器要守同一个 scope
    p = _plan(prev, action)
    if p is None:
        return None
    if merged_pair_suspect(prev, action) is True:
        return None                        # 生成器守 assert_ 同一个 scope（v15）
    color, plan = p
    dots = diamond_dots(prev)
    occupied = occupied_after(prev, action)
    if occupied is None:
        return None
    tp = tips(prev)
    if tp is None:
        return None

    out = {}
    for box, _side, d, nb in plan:
        old, new = _cells(box), _cells(nb)
        for rc in new - old:
            if rc in dots:                     # 菱形的点，条身盖不住它
                continue
            out[rc] = color
        for rc in old - new:
            if rc in dots or rc in occupied:   # 这一步之后还有东西占着，就不是底色
                continue
            out[rc] = BG
        t = tp.get((color, box))
        if t is not None:
            out.pop(t, None)
            out.pop((t[0] + d[0], t[1] + d[1]), None)
    return out or None
