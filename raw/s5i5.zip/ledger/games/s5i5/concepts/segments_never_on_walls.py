"""每一**根条**（身体加它自己那一排帽）占的格子，永远不和死物格重叠——墙是条进不去的地方。"""
LEVEL = "L2"
SCOPE = ("看转移后那一帧 nxt：**逐根条**查一次（bar_units_all 分出来的条）；"
         "死物一格也没有（第 0 关就是）返回 NA；条一根也分不出来返回 NA；换关返回 NA")
NOTE = ("这一关的路线是靠这条主张算出来的：尖的落点 = (37-b+d, 12+a+c)（a/b/c/d 为四节长度，"
        "每次点击 ±3），光看这个式子到菱形中心有很多组解；是「节压不上墙」把 b 夹死在 26、"
        "从而把 d 定成 20。所以这条主张必须走闸——它错了，整条路线的依据就跟着错。"
        "注意它只说「压不上」，没说「点了会怎样」：会被拒、还是节自己停住，得等真撞一次才知道。"
        " || v2：主张的**读法**错了，不是主张错了。v1 用 seg_footprint 按**色**读："
        "一色一个 bbox。一色只有一根条时这没问题，一色两根条（比如一根在盘的左上、"
        "一根在中枢上挂着）时，那个 bbox 是两根的并集，横跨大半个盘，里面自然裹着墙。"
        "它一直没炸，是因为同色两个帽让 cap_block 返回 None，整色被跳过——**靠一个副作用蒙混过关**。"
        "真打脸的那一击是：一根条的自由端长到了最后一行，而最后一行整排是计数条（也是色 3），"
        "于是那一整排被读成了这一色的帽，cap_block 有值了，跳过没了，"
        "153 格墙一次性算进了「这一节的占地」。"
        "教训：**读法藏在共享词汇里，改词汇不算改版，从来没进过评分**——"
        "一条概念可以靠「读不出来所以跳过」拿满分拿几百局。改成逐根条读之后，"
        "它才第一次真的在一色多条的关卡上开口。")
EVIDENCE = ["64e2bc30cd0e77bc",
            # v2：一色两根条 + 计数条冒充帽，把 153 格墙算进占地
            "cd787353d6bd4130", "4012e7320d323009",
            "298f886fec8e32fe", "b6893fd9b900d4c5"]

from _lib import bar_units_all, cells_in, obstacles


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    obs = set(obstacles(nxt))
    if not obs:
        return "NA"
    allu = bar_units_all(nxt)
    if not allu:
        return "NA"
    seen = False
    for _color, units in allu.items():
        for box, _side, caps in units:
            seen = True
            if (set(cells_in(box)) | set(caps)) & obs:
                return "FALSE"
    return "TRUE" if seen else "NA"
