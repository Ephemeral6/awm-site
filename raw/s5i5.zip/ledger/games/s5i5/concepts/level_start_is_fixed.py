"""每次换关，世界给出的那一帧只由**新关的关号**决定：同一关的开局帧在每个场次上逐格相同。"""
LEVEL = "L5"
SCOPE = ("只看换关那一步（ctx.level_prev != ctx.level_next，整局 RESET 回第 0 关也算）；"
         "新关的关号不在下面这张表里返回 NA；不换关返回 NA。"
         "**它只断言这一帧是什么，不断言换关的条件**（那是 levelup_when_all_home 和 no_levelup_unless_home 的事）。")
NOTE = ("这条是路线册那套架构的前提，此前一次都没走过闸。册子按帧指纹索引：开卡之前离线把每一关的整条路线搜好，"
        "卡上拿真帧的指纹去册子里找。**指纹对不上就退回现搜**——安全，但现搜的墙钟一累计就超过会话闲置窗口，"
        "而那正是上一张终局卡的死因。所以「同一关的开局帧跨场次相同」不是锦上添花，是这一版架构成立的条件；"
        "按元知识第七条，路线推理里的每个前提都是主张，不写成概念就等于没被检验过。"
        "\n\n**表是怎么来的、held-out 为什么是空的**：拿探针 runs/<run>/startsame.py 把语料里每一关出现过的"
        "开局帧全捞出来按内容分组（按 tid 去重，同一条转移在未去重的语料里会出现好几行，"
        "抄五遍读成「五个场次」是假证据）。结果：第 0 关 6 个场次逐格相同，第 1 关 2 个场次逐格相同"
        "（其中一个来自另一张卡），其余七关各只有 1 个场次、没得比。"
        "**我是看完全部场次才写下这张表的，所以 EVIDENCE 收全部 14 条，留出去的是空集**——"
        "此刻它 S=UNMEASURABLE，是如实描述，不是欠账。它会在下一张卡上变成可判错的："
        "那张卡每过一关就给一条新的换关转移，表里那一关对不上就是反例，闸当场关。"
        "换句话说，这条概念把「册子在新卡上接不接得上」从一个静默的性能问题变成一个会响的判据。")
EVIDENCE = [
    # 第 0 关：整局 RESET 回第 0 关那几次，外加语料第一条转移的 prev（不是换关步，在它上面判 NA）
    "218a829f43e66580", "653254b0e5cd014a", "bbbbef266d5b20f1", "f28c8e1d6c3dada9",
    "e1f04a3622560b20", "b22bb55193700bef",
    # 第 1 关：两个场次，后一个是上一张终局卡过第 0 关那一击
    "228810ee4f309efd", "ec8ffe6775dff87f",
    # 第 2~8 关：各一个场次
    "26c0b1510bdb91ca", "40d20c42b8a028aa", "ffc61a8739fdc936", "4aa2c01de0cbf219",
    "c9c712282fea1d52", "64a52ca9d82faf1d", "d84a5c77c586083f",
]

import hashlib

# 关号 → 那一关开局帧的指纹。只存指纹不存整帧：这条概念只断言「是不是同一帧」，
# 不声称算得出那一帧长什么样，所以它没有 apply——存了整帧就是拿背下来的答案冒充规则。
START_FINGERPRINT = {
    0: "faba16d4b9a2e9c2",
    1: "6179804ce88f8643",
    2: "6dd7b2dcd187ee3e",
    3: "ca461f88e94d4f9a",
    4: "cb8c7a0620957a28",
    5: "1df85bd6d205b30b",
    6: "1127f49db9b9ffcb",
    7: "d787c21d2785ef83",
    8: "f433b15556bb3a43",
}


def _fingerprint(g):
    """逐格的指纹。行统一成 list 再取 repr：语料是 json 读出来的 list，
    而模拟出来的帧有可能是 tuple，两者 repr 不同——那种差别不是世界的差别。"""
    return hashlib.sha256(repr([list(r) for r in g]).encode("utf-8")).hexdigest()[:16]


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    lp, ln = ctx.get("level_prev"), ctx.get("level_next")
    if lp is None or ln is None or lp == ln:
        return "NA"
    want = START_FINGERPRINT.get(ln)
    if want is None:
        return "NA"
    return "TRUE" if _fingerprint(nxt) == want else "FALSE"
