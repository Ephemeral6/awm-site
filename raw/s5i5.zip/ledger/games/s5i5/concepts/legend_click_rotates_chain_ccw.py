"""点图例框里的图标，被点那一色的条连同挂在它下游的整条链，各绕自己的关节逆时针转，
长度一格不变、上游一格不动；但一次不一定只转 90 度——转到的那一档只要有条
压上别的条，就接着往下转，停在第一个放得下的档上；**压上推不动的死物那一档不是往下试，
是整击作废**；伸出盘外不算放不下，照转。"""

LEVEL = "L1"
SCOPE = ("只看落在图例框里的点击；不是就返回 NA。"
         "prev 或 nxt 上 chain_layout 读不干净（帽面凑不出唯一的一套父子关系）返回 NA；"
         "两帧读出来的条色集合不一致返回 NA；被点的那一色不在链上返回 NA；rot_steps 算不出来返回 NA。"
         "自由端顶着盘边又没有尖的那根条（chain_layout 标 clipped），长度是读少了的——"
         "对这一根**不查长度不变**，其余照查。"
         "只断言帽的朝向、长度、以及转了几档；不断言关节块落在哪 —— 下游的关节块本来就跟着上游的自由端走。"
         "上游与别的链只断言帽面和关节块都不动。"
         "**落点有格子转到盘外的那一击返回 NA**（走 [legend_rot_offboard_skip]）：见 NOTE 末段。")
NOTE = ("v3：v2 说「一次转 90 度」，被一次点击当场打掉——那一击把条转了两档。"
        "看回去：中间那一档会让下游的关节块正落在它上游那根条的身子上，放不下。"
        "所以世界不是拒绝这一击，也不是只转一档，而是**跳过放不下的档**。"
        "这条改动不只是补一个例外：v2 让我以为「每个关节的拐角只能单向递增、走到某一档就永远回不来了」，"
        "并据此算出这一关根本没有解。跳档意味着拐角能绕回去，这一关是有解的。"
        "放得下与否现在由词汇里的 rot_fits 算——正推关节链的落点，再查死物/互相压——"
        "所以这条主张连同它的前提一起可判错：算错了哪一档放得下，下一次点击就会打脸。"
        " || v3 一进门就该被打脸而没有：我押「整根伸出盘外那一档会被跳过」，实测世界照转不误，"
        "只把露在盘上的一截画出来。这一击本该是反例，结果判了 NA——"
        "因为转完那根条被盘边裁了，chain_layout 拒读裁过的条。"
        "**概念在世界干了新鲜事的那一帧上闭了嘴**，正是最该开口的一帧。"
        "所以 rot_fits 里「出界算放不下」这一条是我自己改掉的，不是被反例逼的；"
        "证据是那条转移（902585cb93d5dd50）的帧差，不是这条概念的判定。"
        " || v4 修的是「闭嘴」本身：原先 chain_layout 一见条被盘边裁过就整帧作废，"
        "于是一根无关的条一贴边，全册子跟着哑掉——而哑掉的那几帧正是世界在做不常见的事的那几帧。"
        "现在照读，只把读不准的那一根标出来（clipped），本概念对它不查长度、其余照查。"
        "代价说清楚：clipped 的条长度是读少了的，rot_steps 拿这个短了的长度去试放，"
        "可能把本该被跳过的一档算成放得下——所以这条主张在贴边的帧上仍然可能算错，"
        "**它照样开口，错了就是反例**，这比继续闭嘴强。"
        " || v5 是终局卡第 1803 步逼出来的，和 [legend_rotates_bar_about_joint] 同一步一起挨打："
        "世界把那一击**整步拒绝**（prev 与 nxt 逐格相同，连计数条都没烧），这一条算出 want=2、实测 got=4，判 FALSE。"
        "取证见那一条的 NOTE：全语料 54 条图例点击里世界拒的只有这 1 条，分界线是「跳了档 + 落档有盘外格」的合取，"
        "n=1，**只够写成弃权，不够写成正面主张**。"
        "闸做成 `_lib` 里一个独立函数 [legend_rot_offboard_skip]，这一条和那一条都去问它——"
        "这一族主张有两个身体（这一条按色读链走 rot_steps，那一条按条读走 legend_rot），"
        "第一次修只盖住了走 legend_rot 的那个身体，判据当场把这一条还是 FALSE 报了出来。"
        "**同一个判据有几个副本就要改几处，而漏掉的那个副本不报警。**"
        " || v6：v5 那个合取是漏的，终局卡第 2511 步把它打穿，这一条又和那一条同一步一起挨打。"
        "色11 带三根后代绕 (13,49) 转，**steps=1、根本没跳档**，落点 111/207 出盘，世界整步拒绝。"
        "重新取证后分母变了：94 次图例点击 / 78 条不同转移里世界拒 4 条，plan 算得出的 3 条全部有盘外落点，"
        "88 条「世界照走」里有盘外落点的只有 1 条；当年 n=1 才选合取，现在 n=3 而合取只掐得住 1 条。"
        "所以闸缩回单条「有盘外落点」，代价见那一条的 NOTE 与 accept_offboard_widen.py。"
        "**这一次两个身体是同时挨打的**——共用函数按设计工作了，v5 末尾那句教训这回没有再重演。"
        "顺带一个分母上的教训：另外两条拒绝（第 2488、2490 步）此前一次都没挨过打，"
        "因为它们的返回值本来就是 None、概念闭着嘴。**「没被推翻」在那两条上等于「没被检验」。**")
EVIDENCE = ["bfd5b4421c8bebcc", "f8c11e0861d96fbc", "2159e3f9794b9bd5",
            "d7ea18af58a4d9f4",
            "902585cb93d5dd50",   # 曾经的「转出盘外，世界照转」；放宽弃权闸后变 NA，见那一条的 NOTE
            "8f8e7e910a916b4e",   # 压死物那一档不是跳过，是整击作废（rot_steps 随之改）
            "22ba7672a4a7a179",   # 逼出「跳档+盘外落点」闭嘴的那一步：世界整步拒绝
            "7a53a8d2817694d3"]   # 打穿那个合取的那一步：没跳档、盘外 111/207，世界照样整步拒绝

from _lib import (ccw_side, ccw_steps, chain_layout, legend_click,
                  legend_rot_offboard_skip, rot_steps)


def assert_(prev, action, nxt, ctx=None):
    k = legend_click(prev, action)
    if k is None:
        return "NA"
    if legend_rot_offboard_skip(prev, action) is not False:
        return "NA"
    a, b = chain_layout(prev), chain_layout(nxt)
    if a is None or b is None:
        return "NA"
    A = {x["color"]: x for x in a}
    B = {x["color"]: x for x in b}
    if set(A) != set(B):
        return "NA"
    if k not in A:
        return "NA"
    want = rot_steps(prev, k)
    if want is None:
        return "NA"
    got = ccw_steps(A[k]["side"], B[k]["side"])
    if got is None:
        return "FALSE"
    if got == 0:
        got = 4                       # 一档没转 = 转满一圈回到原样
    if got != want:
        return "FALSE"
    hit = A[k]
    for c, x in A.items():
        y = B[c]
        if x["len"] != y["len"] and not (x.get("clipped") or y.get("clipped")):
            return "FALSE"
        if x["chain"] == hit["chain"] and x["pos"] >= hit["pos"]:
            s = x["side"]
            for _ in range(want % 4):
                s = ccw_side(s)
            if y["side"] != s:
                return "FALSE"
        elif x["side"] != y["side"] or x["box"] != y["box"]:
            return "FALSE"
    return "TRUE"
