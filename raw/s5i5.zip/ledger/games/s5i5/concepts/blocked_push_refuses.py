"""紧贴在被点那一节自由端外面的那面墙，按位移搬过去的地方没空（出界 / 撞上别的墙 / 撞上某一节的落点），这一次点击世界整个拒绝——除了计数条那一格，前后两帧逐格相同。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上；按钮或自由端认不出返回 NA；"
         "自由端外面没贴着墙、或那面墙认不出（_lib.rigid_unit 返回 None）返回 NA；"
         "那面墙搬过去的地方**有空**返回 NA（那是 wall_sticks_to_free_end 管的正常情形）；"
         "节自己压到推不动那种死物返回 NA（归 blocked_click_is_noop，别两条抢同一片地）；换关返回 NA")
NOTE = ("这条填的是「墙被堵住会怎样」那个洞。"
        "买法：第 2 关按册子无解，而当时全册对 ACTION6:54,48 一致返回 NA、预测 0 格——"
        "点色12 的伸会把一面墙按 d=(0,-3) 顶过去，而另一节的身体正好占着那儿的 9 格。"
        "押注押的是「整步被拒」，兑现了（2a2c78dd57e3d978）。"
        "**主张比观测宽，宽在两处，都是故意的**："
        "① 只见过「撞节」这一种堵法，这条把「越界」和「撞墙」也一并断言了；"
        "② 只见过被顶的墙是横条、位移是横向的那一次。"
        "**v2 改了两处，主张本身没动**："
        "(a) 判据从 push_block 换成 _lib.attach_block。push_block 建在「落点踩到谁」上，"
        "只看得见伸出去顶，看不见缩回去拖；换判据之后这条概念一下多管了 5 步"
        "（18d2fe07cdd8390a、755bd691d870dc30、ff6406e7f7a778ad、6b7dfafde6cd2977 等），"
        "全是缩回去把墙拖进死角、世界整步拒绝的那种，v1 对它们一句话没说。"
        "(b) **「整帧相同」不能真的整帧比**——第 63 行是计数条，被拒的那一步照样烧预算。"
        "v1 拿 prev == nxt 比，是审查（auditor）指出来的漏：语料里确实有「整帧只差第 63 行」的步，"
        "唯一那次真实的撞节恰好烧格没跨整数，所以 v1 蒙对了，是运气不是必然。"
        "现在按 _lib.COUNTER_ROW 排除那一行再比。"
        "**还有一处必须说清：「撞墙」那一支正踩在第 2 关的通关路线上。**"
        "路线要靠一节往右伸把墙一路顶过去，再顶一次就撞上推不动那种死物。"
        "这条说那一次会被整步拒绝；要是世界其实让推挤**连锁**（墙把那块推不动的一起顶走），"
        "这条当场吃反例，而第 2 关重新有解。也就是说：这条概念活着 = 第 2 关无解。"
        "所以它必须先被真正走一遍，才轮得到写阻断主张——"
        "拿一条没验过的过度断言去论证「明确无法推进」，那是自己给自己签字。"
        "顺带说明它**不**解释第 1 关那次被拒（4605a0c4a215b03e）："
        "那一次贴着的墙按 d 搬过去出界 0 格、压别的墙 0 格、压节落点 0 格，地方大得很，世界照样拒了。"
        "所以「没空才拒」不是唯一的拒绝原因，那一次仍由 blocked_click_is_noop（按颜色）"
        "与 drag_into_obstacle_refuses（按谁顶的）两条对手争着解释，这条不插手。"
        "没写 apply：它断言的是「什么都没发生」，生成不了格子。")
EVIDENCE = ["2a2c78dd57e3d978"]

from _lib import COUNTER_ROW, attach_block, would_refuse


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if would_refuse(prev, action) is not False:
        return "NA"                 # 节自己压到推不动的那种 —— 让给 blocked_click_is_noop
    if attach_block(prev, action) is None:
        return "NA"
    same = all(prev[r] == nxt[r] for r in range(len(prev)) if r != COUNTER_ROW)
    return "TRUE" if same else "FALSE"

