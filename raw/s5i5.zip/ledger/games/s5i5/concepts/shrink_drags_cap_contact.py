"""缩键把自由端拉回来时，压在那张脸上的若是**另一根条的帽**，那根条整根（身子加帽）跟着退同一个位移；
压在脸上的若只是**另一根条的身子**，那根条纹丝不动。"""
LEVEL = "L6"
SCOPE = ("只看 click_panel 判为**缩**（sign=-1）的步；伸（sign=+1）返回 NA——伸是推，推的归属"
         "已经有 blocking_seg_is_pushed / chain_drags_downstream 在管，这条只说拖。\n"
         "blob_moves 算不出（认不出帽、缩过头把 bbox 变非法）返回 NA；bar_units_all 返回 None"
         "（同色两根条的框重叠，那一帧全册闭嘴）返回 NA；换关返回 NA。\n"
         "**整步被拒（prev 与 nxt 逐格相同）返回 NA**：这条概念断言的是「缩真的发生了之后，"
         "贴着自由端的东西怎么动」，拒不拒是 refused 那一族的地盘。\n"
         "**被点的条自己没退**（自由端该腾出来的那 GROW 格里还留着本色）也返回 NA：那说明世界"
         "做的不是 blob_moves 描述的那件事，落点该由 bar_free_end_moves 去判，不该在这里算成反例。\n"
         "自由端脸上一根别的条都不沾（既没帽也没身子）返回 NA——**这条概念不断言「没人跟着动」**，"
         "那句更强的话没有单独验证过。\n"
         "同一根条既被帽接触又被身子接触时（帽和身子都探进那张脸），按**帽优先**判「被拖」；"
         "这个优先级来自实测的那一步（一根条的帽占脸上一格、身子占另外两格，世界把它整根拖走了），"
         "不是从别处推出来的。\n"
         "菱形四点（diamond_dots）在源格和落格两侧都跳过：尖压在菱心上时那一格的颜色不归条管。")
NOTE = ("由来：一次押注落空逼出来的。当时押『某根条被缩键抬起来之后会跟着走』，理由是"
        "它贴着那根条的自由端；世界只把**另一根**条拖走了，押中的那根一格没动。"
        "两根的差别在同一帧里看得见——跟着走的那根，**帽**正压在自由端的脸上；"
        "没动的那根，压在脸上的是**身子**。\n"
        "这条写成影子册而不是直接入册：方法册里记着，一次新观测被推广成普遍规律之前先影子记分，"
        "因为『一个样本上成立』和『语料里没有反例』是两回事，而后者只有 settle 能替我说。\n"
        "**已知的没检验处，明说**：(1) 被拖的那根条如果自己又顶着第三根，这条概念不说话——"
        "它只断言直接接触的那一根，链式没有样本；(2) 被拖的条身上挂着的死物（墙）跟不跟着，"
        "不在这条概念的主张里，那是 wall_sticks_to_free_end 的地盘；"
        "(3) 『身子接触就不动』这一半，目前只有一个样本，它比『帽接触就被拖』脆弱得多。")
EVIDENCE = ["fde6cca2dacfcf9f"]

from _lib import GROW, blob_moves, bar_units_all, cells_in, click_panel, diamond_dots, refused


def _face(box, away):
    """自由端外面紧贴的那一排格子（短边那么宽）。away 是从帽指向自由端的单位向量。"""
    t, b, l, r = box
    ar, ac = away
    if ar == 1:
        return {(b + 1, c) for c in range(l, r + 1)}
    if ar == -1:
        return {(t - 1, c) for c in range(l, r + 1)}
    if ac == 1:
        return {(rr, r + 1) for rr in range(t, b + 1)}
    return {(rr, l - 1) for rr in range(t, b + 1)}


def _vacated(box, away):
    """缩之后被点那根条该腾出来的 GROW 格宽的一条：自由端最靠外的那 GROW 排。"""
    t, b, l, r = box
    ar, ac = away
    if ar == 1:
        return {(rr, c) for rr in range(b - GROW + 1, b + 1) for c in range(l, r + 1)}
    if ar == -1:
        return {(rr, c) for rr in range(t, t + GROW) for c in range(l, r + 1)}
    if ac == 1:
        return {(rr, c) for rr in range(t, b + 1) for c in range(r - GROW + 1, r + 1)}
    return {(rr, c) for rr in range(t, b + 1) for c in range(l, l + GROW)}


def _plan(prev, action):
    """返回 (被拖的, 该不动的)，两张表都是 (色, 全部格子, 位移)；算不出来返回 None。"""
    cp = click_panel(prev, action)
    if cp is None:
        return None
    color, sign = cp
    if sign != -1:
        return None
    mv = blob_moves(prev, action)
    if mv is None:
        return None
    allu = bar_units_all(prev)
    if allu is None:
        return None

    clicked_boxes = {box for box, _side, _d in mv}
    dragged, frozen = [], []
    for box, _side, d in mv:
        if not d[0] and not d[1]:
            return None
        away = (-d[0] // GROW, -d[1] // GROW)      # 缩时 d 指向帽，自由端方向取反
        face = _face(box, away)
        for k, units in allu.items():
            for ubox, _uside, ucaps in units:
                if k == color and ubox in clicked_boxes:
                    continue
                capset = set(ucaps)
                body = set(cells_in(ubox))
                if capset & face:
                    dragged.append((k, body | capset, d))
                elif body & face:
                    frozen.append((k, body | capset, (0, 0)))
    if not dragged and not frozen:
        return None
    return dragged, frozen, mv, color


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if prev == nxt:
        return "NA"
    plan = _plan(prev, action)
    if plan is None:
        return "NA"
    dragged, frozen, mv, color = plan

    # 被点那根条自己没退 → 世界做的不是这件事，交给别人判
    for box, _side, d in mv:
        away = (-d[0] // GROW, -d[1] // GROW)
        if any(nxt[r][c] == color for r, c in _vacated(box, away)):
            return "NA"

    dots = diamond_dots(prev)
    n, m = len(nxt), len(nxt[0])
    for k, cells, d in dragged:
        moved = {(r + d[0], c + d[1]) for r, c in cells}
        for (r, c) in cells:
            if (r, c) in dots:
                continue
            tr, tc = r + d[0], c + d[1]
            if (tr, tc) in dots:
                continue
            if not (0 <= tr < n and 0 <= tc < m) or nxt[tr][tc] != prev[r][c]:
                return "FALSE"
        for (r, c) in cells - moved:
            if (r, c) in dots:
                continue
            if nxt[r][c] == k:
                return "FALSE"
    for k, cells, _d in frozen:
        for (r, c) in cells:
            if (r, c) in dots:
                continue
            if nxt[r][c] != prev[r][c]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    # assert_ 靠 prev == nxt 把「整步被拒」摘出去，apply 看不到 nxt，只能问 refused：
    # 拿不准会不会被拒就不猜，否则被拒的那些步会整份预测算成说错。
    if refused(prev, action) is not False:
        return None
    plan = _plan(prev, action)
    if plan is None:
        return None
    dragged, _frozen, _mv, _color = plan
    if not dragged:
        return None
    dots = diamond_dots(prev)
    n, m = len(prev), len(prev[0])
    out = {}
    for _k, cells, d in dragged:
        for (r, c) in cells:
            if (r, c) in dots:
                continue
            tr, tc = r + d[0], c + d[1]
            if not (0 <= tr < n and 0 <= tc < m):
                return None
            if (tr, tc) not in dots:
                out[(tr, tc)] = prev[r][c]
    return out or None
