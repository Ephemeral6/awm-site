"""这一步之后所有的尖都落在菱形中心上，这一步就必定换关。"""
LEVEL = "L5"
SCOPE = ("用 prev 与动作算出这一步之后各个尖的落点；算不出落点、盘上没有菱形中心、"
         "或落点没有铺满所有菱形中心，都返回 NA。故意不因为换关而 NA。"
         "**世界会不会收这一击也算在「算不算得出落点」里**：`tips_after` 先问 `refused`——"
         "说会拒就答此刻的尖（被拒 = 整步无事），说不出就答 None。所以被拒的一击、"
         "以及拒不拒判不出来的一击，这条一律 NA，不再声称管那一片。")
NOTE = ("no_levelup_unless_home 的正向那半条：那条说「没到位就不换关」，这条说「到位就换关」。"
        "\n\n**v2，终局卡上被打脸改的**：终局卡第 1 关第 104 击 `ACTION6:12,57` 世界整步拒绝（前后帧逐格相同），"
        "而这条判 FALSE 关了闸——它从 prev+动作算尖的落点时**默认这一击会生效**。"
        "祸首不在这条概念的断言，在它借的那个词：`_lib.tips_after` 的名字是「这一步之后尖在哪」，"
        "世界拒绝了这一步，尖就还在原地，答落点上的尖是答错。而 `_lib.refused` 当时就说得出 True——"
        "**没人问它**。规划器的 `will_levelup` 踩的是同一个词，所以它也把这次被拒读成了收口击。"
        "\n\n这正是每批结算那节「词汇表审计」点名的东西：`_lib` 里的词不打分、不走闸，"
        "两条概念都从同一个词取值再互相核对，S=1 不等于这个词被检验过。这次是这句话第一次兑现成真反例。"
        "\n\n**改法与量出来的代价**（runs/<run>/tipsafter_check.py，判据跑之前写死）："
        "`tips_after` 先问 `refused`（说会拒→答此刻的尖；说不出→None，不填默认值）。"
        "判据一，反例那条上本概念判 NA：通过。判据二，`will_levelup` 全语料**假阳 0 条**：通过"
        "（假阳才是规划器的死因，它只信 `is True`）。判据三，真阳 9 条、一条没丢——"
        "语料里 9 次换关它全认得出：通过。判据四，弃权面的代价：`will_levelup` 说不出的从更少涨到 41/510 条。"
        "`refused` 自己的四格表（去重、去 RESET、去换关步）：说会拒&真被拒 21 / 假警报 16 / **漏报 0** / 说不拒&真动 416 / 说不出 41——"
        "漏报为 0 正是这个改法能把假阳清零的原因；代价落在那 16 条假警报上，本概念在那些步上闭嘴。")
EVIDENCE = ["228810ee4f309efd", "881aa0f79807c000"]

from _lib import all_home, diamond_centers, tips_after


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    t_map = tips_after(prev, action)
    if t_map is None:
        return "NA"
    if all_home(t_map, diamond_centers(prev)) is not True:
        return "NA"
    return "TRUE" if ctx["level_next"] != ctx["level_prev"] else "FALSE"
