"""点一个节的按钮，挡在它落点上的那一节要是**让得开**，两团一起动：被点那团走满 3 格，
被挡那团整体（身体连帽）沿**推力方向**平移 3 格——不是沿它自己的长轴；
**要么如此，要么整步无事发生**（计费条那一行不算）。
菱形四点画在节**上面**：节从底下过去只是被挡住，走开就复原，四点自己一格不动。"""
LEVEL = "L6"
SCOPE = ("只看 push_target 归得出「谁挡在路上」的步（被点那色恰好一团的落点压着东西、"
         "且压住的格子归到别的某一节的唯一一团）；换关返回 NA；push_target 为 None 返回 NA；"
         "**整步无事发生（除计费条那一行外逐格相同）判 TRUE**——世界整步拒绝时这条概念不主张谁被推了；"
         "**apply 比 assert_ 窄一档：refused() 不是断定「不拒绝」时 apply 一格不画**（v7，见 NOTE）；"
         "**被挡那团自己让开时的落点上还压着东西（push_target_block 非空）返回 NA** —— "
         "那一片是 [push_chain_blocked_refuses] 的，世界在那儿整步拒绝；"
         "**被点那团的落点或帽区压着尖时 apply 闭嘴**（尖怎么走没观测过）；"
         "**被推那团自己带尖时 apply 不再整步闭嘴，只画身体、不认领尖那一格**——"
         "尖怎么走仍旧没人说，只是不再因此把整步的身体也放弃掉（v6 的由来，见 NOTE）；"
         "**换关那一步 apply 闭嘴，而且这道闸是前推算的（_lib.will_levelup），不查 ctx 里的 level_next**——"
         "押注的时候这一步还没走，ctx 里根本没有 level_next，查它等于这道闸在生成器这一侧从不生效（v8，见 NOTE）。")
NOTE = ("v1：第 3 关第 195 步 4956b524f70c86c1 立的，`ACTION6:57,57` 点色 8 的伸。\n"
        "**它回答的是这一关的核心机构，而立它之前整册对此一句话都说不出来**：第 3 关五个节两两相咬，"
        "五个伸按钮里有四个的落点压在另一团色 11 的身体连帽上。而 `obstacles` 按定义排除了"
        "「属于任何一节的颜色」，所以第 3 关盘上死物读 0 格——第 1~2 关那整套推墙概念"
        "（blocked_click_is_noop / click_refused_when_seg_lands_on_wall / blocked_push_refuses / "
        "wall_sticks_to_free_end / drag_into_obstacle_refuses / wall_size_constant_in_level）"
        "在这一关从定义上就够不着，全部判 NA。「一节挡住另一节会怎样」在那之前是 149 条转移里"
        "**一条都没检验过**的空白。\n"
        "**押注押了三种读法，三种全落空，答案是第四种**：我押的是整步被拒（几何帧差 0 格），"
        "依据是第 2 关见过「落点压到东西就整步拒绝」那套机构；备选押了「节推节、帧差 20 格以上」"
        "和「色 8 停在边上只伸不满 3 格」。实测帧差 36 格，而真相是**前两种同时成立**："
        "色 8 伸满 3 格 (21,22,45,47)→(18,22,45,47)（这一段册子早就预测对了），"
        "同时被压那团色 11 整体上移 3 格 (18,20,42,46)→(15,17,42,46)，连它列 47 那一排帽一起走。"
        "36 = 新占 18（身体 15 + 帽 3）+ 回底色 9 + 被色 8 吃掉 9，这条概念的 apply 算出来一格不差。\n"
        "**为什么这比押中更值**：我押「拒绝」是拿第 2 关的机构去套，而第 2 关被推的是死物；"
        "这一步证明**被推的东西不必是死物**，wall_sticks_to_free_end 那句「贴着自由端的墙被顶着走」"
        "的主语可以是另一个节。三种读法都错在同一个共同前提上——它们都假设「节」和「被推的东西」"
        "是两类互斥的对象（方法册「两个对手都按物件的属性分类而都不倒」的又一次兑现）。\n"
        "**位移方向这一句是这条概念最要紧的断言**：被顶那团色 11 自己的帽在右侧（列 47），"
        "它自己的长轴是水平的，可它被**垂直**顶走了。所以被推的节沿推力方向平移，和它自己的轴无关。"
        "这一句只有一次观测撑着，是故意留宽的那种宽：哪天有一团被顶得沿自己的轴走，它当场挨打。\n"
        "\n**v1 的 scope 立刻被语料削了一刀，而削的方式恰好是我预告过的**："
        "v1 的 SCOPE 里写着「故意不排除连环推（被顶那团让开之后落点上又有东西），"
        "让 assert_ 照常开口去挨打」。它当场在 **11 条旧关转移**上判 FALSE，"
        "而 11 条无一例外都是**连环没到底**：被顶那团自己的落点上压着死物色 15（第 1 关）、"
        "死物色 1、或者第三个节（色 9 / 色 14），世界的做法是**整步无事发生**"
        "（真帧差 0~1 格，same_off_counter 全为 True；那 1 格是计数条跨了整数）。"
        "头一条 4605a0c4a215b03e 正是 blocked_click_is_noop 立册时花一格预算撞出来的那一步。\n"
        "**所以世界不是「有时顶走、有时拒绝」两种做法，是一条递归规则**：一节要动，"
        "它前面每一环都得能让开；任何一环让不开，整步无事发生。"
        "这一片让给 [push_chain_blocked_refuses]，那条断言的正是拒绝分支，"
        "11 条 tid 是它的依据。两条概念共用 `_lib.push_target` 与 `_lib.push_target_block`，"
        "判别量就是后者返回的字典空不空——**同一个读数，两条概念在它的两侧各说一句**。\n"
        "**11 条 tid 留在这条的 EVIDENCE 里**（它们在这里判 NA），"
        "因为「这一片不是我管的」也是这条概念挨打挨出来的边界，抹掉出处就看不出它为什么只管半边。\n"
        "\n**入册前独立复核，撞出这条概念最要紧的一个读数改正**："
        "我原本以为这是第 3 关才出现的新机构，NOTE 上半段就是那么写的。"
        "拆成两条概念之后逐格核对 apply，它在全量语料上认领了 2430 格——"
        "而按「语料里 12 条命中、其中 1 条让得开」的说法，一条约 54 格，最多也就几十格。"
        "数字对不上就停下重数（`runs/<run>/pushcount.py`），结果是："
        "**全去重语料 149 条里 push_target 命中 43 条，32 条让得开、11 条连环挡住，**"
        "而这 32 条**第 1 关就开始了**（第 16~33 步点色 12 顶色 10、点色 10 顶色 11 那一串），"
        "第 2 关又有一大片（第 120~181 步），第 3 关只占最后一条。"
        "「12 条」是我从早先那份私有 `_push_plan` 抄来的数，没在新写法上重数——**一个假读数**，"
        "已在 `_lib.push_target` 的 docstring 里改正并留了由来。\n"
        "**所以这条概念的真正体量，比它自己 NOTE 上半段吹的小得多，而这也是量出来的**："
        "入册后逐格说对 2388 格，可全册 E 一格没涨（5761/10749 前后一字不差）。"
        "我先写下的解释是「这一片此前整册没人认领」——E 当场证伪了它，"
        "因为 E 只数「被至少一条概念预测对」的格子，不涨就说明早有人盖住。"
        "逐条量（`runs/<run>/whocovers.py`）：这 32 条里被顶那团真正变色的格子中，"
        "**774 格 [chain_drags_downstream] 早就预测对了**，"
        "只有 **90 格**（第 143、175、195 三步）是全册只有这条概念说对的。"
        "chain_drags_downstream 用的是另一套词（下游被拖着走），说的其实是同一件事的一大半——"
        "所以这条概念**不是填了一片空白，是给一片已有的覆盖换了个更直接的说法，外加 90 格**。\n"
        "**留着它而不撤，理由只有一条**：那 90 格所在的三步正是 chain_drags_downstream 闭嘴的地方"
        "（其中 b6f0ef03af8176dd 就是被独立复核指出 `_lib.rigid_unit` 过于保守的那一步）。"
        "哪天 rigid_unit 放宽到能盖住那三步，这条概念就该按方法册「两条概念说同一件事」并掉或撤掉，"
        "**这一句就是它的到期条件**，写在这里以免下次又靠印象判断它值不值。\n"
        "**教训不在概念上，在读数上**：我连着写下两个没量过的断言（「语料 12 条」、「此前无人认领」），"
        "两个都被装置自己的数当场推翻——一个被 apply 认领格数推翻，一个被 E 不涨推翻。"
        "共同的毛病是**拿「我刚发现了新机构」的兴奋当读数用**：新机构确实新，"
        "但「册子此前说不出它」和「册子此前盖不住它的格子」是两件事，前者真、后者假。\n"
        "assert_ 在这 32 条上全判 TRUE，逐格核对 2388 格说错 0 格。\n"
        "**apply 比 assert_ 窄一处**：两团里有一团带尖时 apply 闭嘴、assert_ 照常开口。"
        "理由是 apply 说错会被规划器照着算下一帧，而 assert_ 说错只会挨一次打——"
        "两个出口的粒度本来就不同（方法册「检查器问的问题比生成器说的话弱」），"
        "所以窄的那个应该是会传播的那个。带尖那片现在是公示的白纸：走到那儿去，这条概念只判不画。\n"
        "\n**v4：这一次的 FALSE 打的是检查器，不是主张**。"
        "第 3 关第 335 步 b1079f5f4a7f484e（`ACTION6:12,57`，点色 12 顶色 11）判 FALSE，"
        "而同一步 apply 逐格说错 **0 格**——世界改的 108 格，docstring 那句"
        "「被挡那团沿推力方向平移 3 格」一格不差地兑现了。分歧不在世界上，在这条概念自己的两套词汇之间：\n"
        "`push_target` 交回来的 `ob` 是 **bar 词汇**里的一根条 (24,26,19,35)，"
        "而 assert_ 拿 `color_blobs` 的 **4 邻接连通团**表去比。第 3 关色 11 的那根条底下"
        "挂着一根竖条 (27,43,30,32) 与它相接，在团表里两根合成一项 (24,43,19,35)。"
        "于是 `if b == ob else b` 那一行**一次都没匹配上**，`pred_other` 原样等于 `was_other`——"
        "**断言实际预测的是「被推那节纹丝不动」**，然后世界把它推走了，当然判 FALSE。"
        "这不是断言写松了或写紧了，是断言在这类局面上**说的根本不是它以为在说的那句话**。\n"
        "**为什么第 0~2 关一次没撞出来**：那三关每个节色恰好一团，bar 与团一一对应，两套词汇偶然重合。"
        "`color_blobs` 的 docstring 里早写着「一色一节不是几何事实，是那三关的巧合」——"
        "**同一个巧合在这里第二次收账**，第一次收在 bar_box / capped_side 失语上，这次收在这条断言上。\n"
        "**改法**：被推那一节改用 `bar_cells` 比**格子集合**（老集合 − 被推那根条的格子 + 平移后的格子），"
        "和 apply 同一套词汇；计费条那一行排除在外（那是别的机构）。"
        "这比原来的 bbox 表比对**更严不更松**：格子集合决定团的分解，反过来不成立。"
        "自己这一色仍比 `blob_boxes_after` 的团表——那一侧两边同源，没有混词的毛病。\n"
        "**改完在全去重语料 159 条上重跑**（`runs/<run>/checkassert.py`）："
        "TRUE 34 / FALSE 0 / NA 125，v3 判 TRUE 的 32 条一条没掉，新增的两条正是第 3 关这两步。\n"
        "\n**v5：菱形四点是画在节上面的，不是把节切断的。** 这一版由两条反例逼出来，"
        "而它们说的是**同一件事的两个方向**，所以这一次是真打在主张上，不是打在量具上"
        "（判别法见方法册：看 apply 逐格说错几格——这两条各说错 4 格，前几版都是 0 格）：\n"
        "- 第 340 步 58de39b190db076f：被推那根条从四点上面**挪开**，"
        "世界多给了 4 格色 11（(6,31)(7,30)(7,32)(8,31)），断言少算了；\n"
        "- 第 341 步 2d6e35351546dcff：另一根条**挪上**四点，"
        "世界少给了 4 格（恰是四点 (9,31)(10,30)(10,32)(11,31)），断言多算了。\n"
        "多的那 4 格和少的那 4 格是同一批位置的两次相遇，合起来只有一个读法："
        "**节的真身是完整的矩形，四点画在它上面把那几格挡住**；"
        "节走过去时被挡住的位置换人，四点自己一格不动——这正是 [diamond_dots_immutable] 说的话，"
        "它在这两步上都判 TRUE。**册子里早就有一条概念在说这件事，只是这一条没听。**\n"
        "以前的写法把「看不见的格子」当成「不存在的格子」：`bar_cells` 交回来的是**可见**格子，"
        "拿它当条的真身，条底下压着四点时就少 4 格。第 0~2 关没撞出来，"
        "是因为没有一根**被推的**条从菱形上面经过。\n"
        "**改法**：新增 `_body()`——条的真身 = 框内可见的该色格子 **∪ 框内的菱形四点**；"
        "assert_ 与 apply **共用这一个定义**（上一版的教训就是两个出口用了两套词，这次不再犯）；"
        "落点压在四点上的那几格从预测里减掉，让开的格子里凡是四点也不刷成底色。\n"
        "**全去重语料 167 条重跑**：TRUE 40 / FALSE 0 / NA 127。\n"
        "**四版病史连起来看**：v3 死于混词（bar 词汇 vs 连通团词汇），v4 死于把遮挡当切断。"
        "两次都不是「世界不讲理」，都是**我给物件划边界的方式和世界的不一样**；"
        "而推的力学本身，从 v1 起一次没被推翻过。\n"
        "\n**v6：把 v5 无意中改宽的 scope 如实写下来，并顺手核对了一个对不上的数。**\n"
        "v5 settle 之后 E 掉了 280 格，而这条概念的「说对」只少 59 格——两个数对不上，"
        "于是停下重数（`runs/<run>/cmpapply.py`，把 v4 的 apply 复刻出来逐格对比）。"
        "**两个发现**：\n"
        "1. **E 掉的 280 格不是退步，是记账**：settle 的 P/E 都算在 held-out 上，"
        "而 held-out = 全语料 − 这条概念自己的 EVIDENCE。v5 把两条反例记进 EVIDENCE，"
        "那两步各约 140 格帧差就此退出分母。在**全语料**上量，v5 反而**多说对 212 格帧差、"
        "说错从 8 降到 0**。「引用一条转移当依据会让 E 变小」是装置写明的规矩，"
        "我却把它读成了退步——**看见 E 掉先查 EVIDENCE 是不是刚加过**。\n"
        "2. **v5 顺带把 scope 改宽了，而我没打算这么改**：带尖那道闸查的是 `obcells`，"
        "而 `_body()` 把尖那一格排除在外（尖是色 13，既不是该节的可见色也不是菱形四点），"
        "于是被推那团自己带尖时闸不再响。后果是它在 **b69538b54695cee2（第 40 步）与 "
        "f466378a781eb4e4（第 41 步）** 这两条上开了口——v4 在那儿一格不说——"
        "各认领 121/130 格、说对帧差 106 格、**说错 0 格**。"
        "这两条正是独立复核（`runs/<run>/chain.out`）点名的那两条有残差的转移。\n"
        "**这个宽是保留还是收回：保留，但要写进 SCOPE。** 保留的理由是它有读数撑着"
        "（两条转移 251 格说错 0），而且它并没有对尖多说一句话——尖那一格不在认领里，"
        "「尖怎么走」依旧是公示的白纸。"
        "**但 v5 的 SCOPE 当时还写着「两团里有一团带着尖返回 NA」，那句话已经不成立了**："
        "代码悄悄比声明宽，是比说错更难查的一种错，因为没有任何反例会指着它。"
        "所以 v6 只改文字不改代码，把实际行为如实写下来。\n"
        "\nv7：**第 350 步 483e4161735d64c1 判 FALSE 关闸——世界整步拒绝，而这条概念说两团一起动了。**\n"
        "被推的那一节正是上一步（第 349 步）自己被点、也被整步拒绝的那一根；"
        "两次拒绝的共同对象是同一根条。**病因不在这条概念，在词汇的分辨率**："
        "册子里那个只看 prev 的拒绝谓词 `_lib.refused` 在全去重语料上**开口的 146 条全对**"
        "（`runs/<run>/absent.py`：说会拒 25 条全真拒、说不会拒 121 条全真没拒，零漏报零假报），"
        "毛病只有闭嘴；而它的 27 条弃权里 25 条卡在 `footprints_after` 返回 None，其中 23 条在本关，"
        "因为那个函数按**色**取 bar_box / cap_block，本关却有一色五条（`runs/<run>/whyna.py`）。"
        "**关闸的两条转移就是落在这片盲区里的头两次拒绝**——判别式没说错，它在这一关整关没上场。\n"
        "改法和 [every_blob_moves_on_its_own_axis] v6 同一套，两条概念一起改："
        "`assert_` 走**析取**（要么两团按 v1 的说法一起动、要么整步无事发生），"
        "本关那批转移的逐格检验一条不丢；`apply` 比 assert_ 窄一档，`refused()` 不是断定「不拒绝」时一格不画。"
        "**检查器要尽量宽地可被判错，生成器不许说出自己背不动的格子——两件不同的活，就该有两个不同的 scope。**"
        "这条概念是全册认领格子最多的一条，apply 这一收在本关代价不小；"
        "代价会自己长回来：`footprints_after` 算得动一色多条那天，refused() 在本关开口，apply 自动复活，不用再改一行。"
        "\n\n**v8：终局卡上记了一次意外改的。** 第 1 关的收口击 `ACTION6:42,57` 换了关，整盘重画，"
        "而本条的 apply 照常画了它那一片，押 11 实 5，错 113 格。assert_ 那一侧本来就查 ctx 换关 NA，"
        "生成器这一侧却查不到——**押注的时候这一步还没走，ctx 里没有 level_next**，"
        "所以那道闸在 apply 上从来没生效过。这已经是同一课第三次落地了"
        "（bar_free_end_moves、bar_tip_follows、move_counter_row63 各栽过一次，"
        "它们的 NOTE 里都写着「换成前推的 _lib.will_levelup」），这次是它自己。"
        "改法一行：apply 开头先 `will_levelup(prev, action) is True` 就闭嘴。"
        "\n\n**改完的点名**（runs/<run>/levelup_gag.py，判据跑之前写死：一条概念只要在真换关的转移上 apply 还开口，"
        "它就是下一个收口击的意外来源）：改之前全册 11 条有 apply 的概念里只有本条在换关步开口"
        "（1/10 条，错 113 格），其余十条都是 0/10。这条改完应当归零。")

EVIDENCE = ["4956b524f70c86c1", "4605a0c4a215b03e", "689974eca1c5e87d", "68c852990e7808a2",
            "74fb0c74c11dbd52", "7bd15a5deaf0c404", "94bd53ce16a740d4", "a752d9151916abf2",
            "a7b3ba348f90e477", "e00372dfcc110131", "fb7351572f2b1599", "ffa316f279ef6183",
            "b1079f5f4a7f484e", "58de39b190db076f", "2d6e35351546dcff",
            "483e4161735d64c1"]

from _lib import (BG, CAP, COUNTER_ROW, TIP, bar_cells, blob_boxes_after,  # noqa: F401
                  capped_side, cells_in, cells_of, color_blobs, diamond_dots, moved_box,
                  push_target, push_target_block, refused, will_levelup)


def _body(g, ob, oc):
    """被推那一节在 `ob` 框里的**真身**：看得见的该色格子，**加上**框里的菱形四点。

    菱形四点是画在节**上面**的，节从底下过去只是被挡住，不是被切断（v5 的由来，见 NOTE）。
    两个出口都用这一个定义——检查器和生成器指同一个物件就得用同一套词（方法册）。
    """
    cs = bar_cells(g, oc)
    if cs is None:
        return None
    return set(cells_in(ob)) & (set(cs) | set(diamond_dots(g)))


def _plan(g, action):
    """两个出口共用的那一半：算不出来、或者不在这条概念的 scope 里，一律返回 None。

    scope 判据全部落在这里（方法册「检查器守了 scope 不等于生成器也守了」），
    唯一的例外是「带尖」——那一条只 apply 守，assert_ 故意不守，理由写在 NOTE。
    """
    p = push_target(g, action)
    if p is None:
        return None
    blk = push_target_block(g, action)
    if blk is None or blk:
        return None                  # 连环没到底：那一片是 push_chain_blocked_refuses 的
    color, box, d, oc, ob, ocap = p
    side = capped_side(g, box)
    if side is None:
        return None
    nb = moved_box(box, side, d)
    if nb is None or nb[0] > nb[1] or nb[2] > nb[3]:
        return None
    return color, box, d, nb, oc, ob, ocap


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    # 世界整步拒绝时这条概念不主张谁被推了——析取的另一半（v7，见 NOTE）。
    # 放在 _plan 之后：归不出「谁挡在路上」的步照旧 NA，别让它捡一个空洞的 TRUE。
    if all(prev[r] == nxt[r] for r in range(len(prev)) if r != COUNTER_ROW):
        return "TRUE"
    color, box, d, nb, oc, ob, ocap = p
    pred_mine = blob_boxes_after(prev, action)
    got_mine = color_blobs(nxt, color)
    was_other = bar_cells(prev, oc)
    got_other = bar_cells(nxt, oc)
    body = _body(prev, ob, oc)
    if pred_mine is None or got_mine is None or was_other is None or got_other is None \
            or body is None:
        return "NA"
    # 被推那一节：拿**格子**说，别拿连通团说——`ob` 是 bar 词汇里的一根条，
    # 它在 color_blobs 的团表里可能根本不作为一项存在（v4 的由来，见 NOTE）。
    # 落点压在菱形四点上的那几格看不见（被挡住），所以从预测里减掉。
    dots = set(diamond_dots(prev))
    pred_other = ((set(was_other) - body)
                  | ({(r + d[0], c + d[1]) for r, c in body} - dots))
    off = {rc for rc in pred_other if rc[0] != COUNTER_ROW}
    got = {rc for rc in got_other if rc[0] != COUNTER_ROW}
    return "TRUE" if (pred_mine == got_mine and off == got) else "FALSE"


def apply(prev, action, ctx=None):
    # 生成器比检查器窄一档：世界会不会整步拒绝，册子说不出来（None）或说会拒（True）时，
    # 一格都不画。画出来的每一格都得背得动，背不动就让空白显形（v7，见 NOTE）。
    if will_levelup(prev, action) is True:
        return None                  # 换关那一步整盘重画，谁被推了在那一帧上看不见（v8，见 NOTE）
    if refused(prev, action) is not False:
        return None
    p = _plan(prev, action)
    if p is None:
        return None
    color, box, d, nb, oc, ob, ocap = p
    dots = set(diamond_dots(prev))
    tips = {rc for rc in cells_of(prev, TIP) if rc not in dots}
    body = _body(prev, ob, oc)
    if body is None:
        return None
    myold, mynew = set(cells_in(box)), set(cells_in(nb))
    obcells = body | set(ocap)
    ncells = {(rc[0] + d[0], rc[1] + d[1]) for rc in body}
    ncap = {(rc[0] + d[0], rc[1] + d[1]) for rc in ocap}
    if (myold | mynew | obcells | ncells | ncap) & tips:
        return None                  # 带尖：尖怎么走没观测过，只判不画
    out = {}
    # 四点是画在节上面的：让开的格子里凡是四点，仍旧是四点，不刷成底色。
    for rc in (obcells - (ncells | ncap)) | (myold - mynew):
        if rc not in dots:
            out[rc] = BG
    for rc in ncells:
        if rc not in dots:
            out[rc] = oc
    for rc in ncap:
        if rc not in dots:
            out[rc] = CAP
    for rc in mynew:
        if rc not in dots:
            out[rc] = color
    return out
