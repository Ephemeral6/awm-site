"""点一个图标，既不在被点那一节下游链上、又不是被它顶走的那一节的节（上游与旁支），
每一根条的 box 和尖都一格不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上；被点那一节和它的下游后代都不查；"
         "**push_target 指为受推的那一节也不查**——它怎么动是 [blocking_seg_is_pushed] 的事；"
         "剩下的节一个都定不到位置（含被点的是根节、整条链都是它的下游）返回 NA；换关返回 NA")
NOTE = ("v2：BTN 换成 {(行,列): (条色, 位移)}，改用 _lib.button 取归属。"
        "v3「其余每一节都不动」死于 64e2bc30cd0e77bc：这一关的节串成一条关节手臂，"
        "点根节把下游三节整个拽着走了。v4 只保留还站得住的那一半：**下游之外**的节不动；"
        "下游会怎么动交给 chain_drags_downstream。\n"
        "\n**v5 死于 aacbc8d93a2218f5（第 337 步 `ACTION6:12,48`，点色 14）。"
        "表面上是「色 11 动了而它不在 downstream(14) 里」，真正的病有两个，都不在主张上，在量具上。**\n"
        "**一、它一直在用一把量不准的尺。** `bar_box` 是同色**全部条**的并集边框。"
        "第 3 关色 11 有多根条，被推的那根在并集**内部**移动时，并集纹丝不动。"
        "同一个按钮在第 334 步 826ee2bb7a747ae5 就已经顶走了色 11，这条概念判 TRUE——"
        "**判对是碰巧**：并集 (12,43,10,52) 前后一模一样。到第 337 步那根条越过了上边沿"
        "（12→9），并集才第一次变，概念才第一次开得了口说错。"
        "所以这条反例推翻的不只是这一步，是 **v4 在第 3 关判过的每一个 TRUE 的含金量**。\n"
        "**二、册子里两个词互相矛盾。** `push_target` 看得见「点色 14 会顶走色 11」"
        "（blocking_seg_is_pushed 据此逐格说对 2856 格一格没错），而 `downstream(14)` 返回 `[]`。"
        "原因是 `downstream` 是**不带方向**的节间图，而「顶得到谁」取决于按的是哪个方向的按钮——"
        "同一节的两个按钮下游不同。这不是那个词写错了，是它的表达力不够，"
        "**而两个词说的话不一致这件事，是靠一条反例才暴露出来的，不是靠读代码**。\n"
        "**v5 改法**：frozen 再减掉 `push_target` 指出的受推那一节（它怎么动是 "
        "blocking_seg_is_pushed 的事，这里不重复断言），并且改用 `color_blobs` 的"
        "**逐条 box 表**比对，不再比并集。\n"
        "**全去重语料 162 条重跑**（`runs/<run>/checkassert.py`）：TRUE 139 / FALSE 0 / NA 23。"
        "**尺更细了而一条没垮**——这说明那 139 条是真站住的，不是被并集糊过去的。\n"
        "**教训**：一条概念长期 S=1.000，不等于它在量它声称在量的那件事。"
        "该问的不是「它有没有挨过打」，是「**如果它说的那件事错了，这把尺量得出来吗**」。\n"
        "\n**v6 死于 f45790b57c82e9d1（第 479 步 `ACTION6:6,57`，点色 12 缩）——"
        "而它正是 v5 的 NOTE 里已经点名过的那个词，第二次来收账。**\n"
        "色 12 那根条 (27,52,18,20) 缩了 3 行，`bar_chain` 里认作它儿子的色 11 条 (24,26,19,20) "
        "连同帽整体下移 3 行，**正好填满腾出来的 9 格**。这一步动的东西一格都没超出「被点那节的下游」。"
        "可 `downstream(12)` 返回 `[]`，于是整个色 11 被算进 frozen，概念判 FALSE。\n"
        "**病还是在量具，还是同一处色/条分辨率**：v5 已经把「比哪个 box」从并集改成逐条，"
        "却没动「谁算下游」——那一半仍是按**色**的 `chain`/`downstream`，"
        "而 `bar_chain` 的 docstring 早就写着按色取链的后果是「**不是闭嘴，是自信地说错**」。"
        "**我读过那句话，还在 v5 的 NOTE 里引用了它，然后只修了它指出的两处里的一处。**\n"
        "**v7 改法**：frozen 的单位整个换成「条」——被点色的**每一根**条、"
        "以及每根条各自的 `bar_downstream` 后代，都不查；剩下的条逐格比 `prev` 与 `nxt`（身体格 + 帽格）。"
        "逐格比而不是比 box：box 相等挡不住尖在框内挪位，也会被同色两条长到一起的合并搞乱（见 every_blob v4）。\n"
        "**改之前先影子记分**（`runs/<run>/shadow6.py`，全去重语料 182 条）："
        "FALSE 1→0、TRUE 151→152、NA 30→30。**检验面没缩，多认下一条**。\n"
        "影子第一版被自己事先写的判据否掉过一次：我拿 `blob_moves` 取被点色的条，"
        "而它在「缩到底会被拒」的步上返回 None，三条真拒的转移 TRUE→NA。"
        "这条概念问的是「**别人**动没动」，和被点那根能不能动无关，取条该走 `bar_units_all`。"
        "**判据把它当场拦下了，代价是重跑一次脚本**——如果当时没写「TRUE 数不许比现在少」这一句，"
        "我会拿着一个少检验三条转移的版本去开闸，而闸照样会开。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "1e5c6990b6e3714b", "64e2bc30cd0e77bc",
            "aacbc8d93a2218f5", "f45790b57c82e9d1"]

from _lib import bar_downstream, bar_units_all, button, cells_in, push_target


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    b = button(prev, action)
    if b is None:
        return "NA"
    allu = bar_units_all(prev)
    if allu is None:
        return "NA"
    # 不查的那些**条**：被点色的每一根条，以及每根条按条的后代。
    # 用 bar_units_all 取被点色的条而不是 blob_moves——后者在「缩到底会被拒」的步上闭嘴，
    # 而这条概念问的是别人动没动，和被点那根能不能动无关（v7 NOTE）。
    movers = set()
    for box, _side, _c in allu.get(b[0], ()):
        movers.add((b[0], tuple(box)))
        ds = bar_downstream(prev, b[0], box)
        if ds is None:
            return "NA"
        movers |= set(ds)
    # 受推的那一节仍整色让出去：push_target 只报到色，指不到具体是哪一根条。
    pt = push_target(prev, action)
    if pt is not None:
        for box, _side, _c in allu.get(pt[3], ()):
            movers.add((pt[3], tuple(box)))
            ds = bar_downstream(prev, pt[3], box)
            if ds is None:
                return "NA"
            movers |= set(ds)

    seen = False
    for k, units in allu.items():
        for box, _side, caps in units:
            if (k, tuple(box)) in movers:
                continue
            seen = True
            # 逐格比，不比 box：box 相等挡不住尖在框内挪位，也会被同色两条合并搞乱。
            for rc in list(cells_in(box)) + list(caps):
                if prev[rc[0]][rc[1]] != nxt[rc[0]][rc[1]]:
                    return "FALSE"
    return "TRUE" if seen else "NA"
