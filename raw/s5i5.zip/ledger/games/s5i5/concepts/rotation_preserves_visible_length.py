"""一次图例转弯，只要参与转的那几根条转前转后都没被盘边裁着，每一根条的**可见长度一格不变**。"""

LEVEL = "L6"
SCOPE = ("只看落在图例框里的点击；不是就返回 NA。换关返回 NA。"
         "条读不出（bar_units_all 返回 None）返回 NA。"
         "**参与转的那一色在转前或转后不是恰好一根条**返回 NA——"
         "两根同色条谁转成了谁，单帧上认不出来，长度也就没法配对比。"
         "**转前或转后有条自由端抵着盘边**返回 NA（bar_clipped）：那正是这条主张管不了的那一半。"
         "只比可见长度这一个数（框的长边格数），不比位置、不比朝向、不比颜色——那几件别的概念在管。")
NOTE = ("**这一条是为了把一句原本只活在词汇里的世界事实拎出来挨打。**\n"
        "由来：`legend_rot` 现在会在「要转的条被盘边裁着」时返回 None，"
        "于是 [legend_rotates_bar_about_joint] 在那种局面上闭嘴。那道守卫背后有一句世界事实——"
        "「没被裁的时候，转弯保长」——它当时只写在 `_lib.bar_clipped` 的 docstring 里。"
        "**藏在 `_lib` 里的世界事实是没走过闸的**：改 `_lib` 不算改版，settle 只记一条「词汇」行，"
        "它永远不会有自己的 S/C/N，也永远不会因为哪一条转移被推翻。所以单独立一条。\n"
        "\n实测（`runs/<run>/rotlen.py`，全去重语料里 25 次图例点击）："
        "可见长度守恒 23 次，**这 23 次的条全部自由端不抵边**；"
        "长度变了的只有 2 次，是同一根条连着两步——"
        "先横着 14 长转成朝上、顶到第 0 行被裁成 8（`902585cb93d5dd50`），"
        "下一步再转回横着，14 格又整整齐齐地露回来（`1a4e2a971e025771`）。"
        "**裁剪是可逆的：世界一直记着那 14，盘上只是画不下。**\n"
        "「两头都不抵边、长度还变了」一条都没有——所以被推翻的不是「转弯保长」，"
        "是「可见长度 = 真长度」。这两句话此前一直被当成同一句用。\n"
        "\n**这条主张分数上不会好看，也不该好看**：它管的那 23 条转移，"
        "[legend_rotates_bar_about_joint] 也在管，而且管得更细（逐格对色）。"
        "它的价值全在**边界**上——它是唯一一条明说「抵边那一类我不管」的，"
        "于是「为什么那一类要闭嘴」这件事有了一个能被现实检验的落点，"
        "而不是一句写在守卫旁边、谁也不会去考它的注释。")
EVIDENCE = ["902585cb93d5dd50",      # 14 长转朝上，顶到第 0 行被裁成 8
            "1a4e2a971e025771",      # 再转回横着，14 格露回来——裁剪可逆
            "dcf9ece7e2affaaa"]      # 一击转五根条，五根的长度全没变

from _lib import bar_clipped, bar_units_all, legend_click


def _lengths(g):
    """{色: 可见长度}；只收「这一色恰好一根条」的色。读不出返回 None。

    顺手把「有没有条抵着盘边」一起带出来：抵边的那一色直接不收，
    因为它的可见长度只是真长度的一个下界，拿它去比等于拿没读到的东西当读到了。
    """
    allu = bar_units_all(g)
    if allu is None:
        return None
    out = {}
    for k, units in allu.items():
        if len(units) != 1:
            continue
        box = units[0][0]
        clip = bar_clipped(g, box)
        if clip is None or clip:
            continue
        out[k] = max(box[1] - box[0], box[3] - box[2]) + 1
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if legend_click(prev, action) is None:
        return "NA"
    a, b = _lengths(prev), _lengths(nxt)
    if a is None or b is None:
        return "NA"
    shared = set(a) & set(b)
    if not shared:
        return "NA"
    for k in shared:
        if a[k] != b[k]:
            return "FALSE"
    return "TRUE"
