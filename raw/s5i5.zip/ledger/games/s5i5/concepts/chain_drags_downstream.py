"""点一个图标，被点那一节拖在后面的每一个下游节都整体平移，位移和被点那一节自由端的位移完全相同。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上；被点那一节的**每一根条**都没有下游条返回 NA；"
         "任何一根条的身体格或帽格读不出来返回 NA；平移后越出 0..63 返回 NA（没撞过）；换关返回 NA。"
         "**世界会整步拒绝这一次点击（_lib.refused）返回 NA**，算不出来会不会被拒也返回 NA。"
         "**菱形那四个点只在落点一侧排掉，源头一侧留着**：它们压在条的 box 里、看不见，"
         "但那几格是条的真身，条走了它们跟着走；四个点自己一格不动（[diamond_dots_immutable]）。"
         "后代条的真身 = 框里**看得见的该色格子** ∪ 框里的菱形四点，和 [blocking_seg_is_pushed] 同一个定义。"
         "下游 = 沿「帽贴在谁身上」这条关系往下的全部后代**条**（_lib.bar_chain / bar_downstream）。"
         "**父指针成环的帧 bar_downstream 返回 `None`**，因而本条返回 NA："
         "三根条首尾互贴时谁都是别人的孩子、没有根，「后代」在那一帧上不指向任何东西；"
         "**这里返回 NA 说的是「我算不出来」，不是「世界不拖」**——曾经把它翻成正面主张"
         "（原 [ring_has_no_downstream]：成环帧上一根后代都不拖），下一步就被世界打死撤册。"
         "真正的病根是环本身读错了，见 [tip_bar_carries_nothing]：带尖的那根是手臂的自由端，"
         "谁也不许挂在它后面；掐掉那类边之后全语料成环帧归零，这一道守卫留着防真出现别的环。"
         "**某根后代条本身就是被点色的另一根条返回 NA**（它既自己伸缩又被拖，两份位移叠不出来）；"
         "**同一根后代条被两根父条各拖一次也返回 NA**。这两条都是「算不出」，不是「不会发生」。")
NOTE = ("这一关的四节不是四根独立的条，是一条关节手臂：每一节的帽（色 3）紧贴上一节的自由端，"
        "所以伸缩上游会把整条下游拽着走。button_owns_one_bar v3「点一个图标只动那一节」"
        "就是死在 64e2bc30cd0e77bc 上，这条概念是替它站出来的那一半。"
        "v1 死于 4605a0c4a215b03e：撞墙那一步整帧不动，而这条概念照算下游平移了 3 格，"
        "还替它认领了 27 格。缩 scope 把撞墙那一步让出去。"
        "值得留意的是那一次压上墙的正是这条概念管的下游（色11），不是被点的那一节自己——"
        "「拖着走的那一段也要过墙这道检查」是这条概念和 blocked_click_is_noop 共同的赌注。"
        "v3 只改 apply，主张没动：原来「腾出来的格子回底色，但让给被点那一节新长出来的身体」"
        "把「谁占着」这件事写成了两个特例（landed、grown），漏掉了不动的节和各家的帽。"
        "改成统一按落点表让位——这一步之后有人占着的格子就不写底色。"
        "v4 和 bar_free_end_moves v5 是同一处改动：v1 把「压到死物」整类都让出去了，缩得太狠，"
        "第 2 关证明压到推得动那种死物时点击照常生效，判据换成 would_refuse；"
        "落点表换成 occupied_after，把搬过来的死物块也算成占着，否则会和推挤那条抢同一格。"
        "**v5 是替它挡下一次挨打，判据来自别人的反例**：bar_free_end_moves 与 bar_tip_follows "
        "在同一批里各挨了 10 个和 4 个反例，病根是 v4 这套守卫（would_refuse + hit_blobs/push_plan）"
        "只看「落点踩到谁」，因此看不见条**缩回去时把贴着的墙一起拖走**、而墙退无可退、世界整步拒绝。"
        "这条概念用的是同一套守卫，只是这一批里恰好没在那几步开口（所以没进反例），"
        "但它的洞和那两条一模一样。判据统一换成 _lib.refused，主张一个字没动。"
        "没把那几个 tid 抄进 EVIDENCE：这条概念不是从它们推出来的，抄进去等于骗自己有独立验证，"
        "而且会白白把它们从留出评分里划掉。\n"
        "\n**v6 不是被反例逼的，是被一次「零分不等于没错」逼的：这条概念在第 3 关整整 35 条转移上"
        "一个字都没说过，而它管的正是这一关的主机构。**\n"
        "起因是别人的反例 f45790b57c82e9d1（色 12 缩，儿子色 11 条整体下移 3 行填满腾出来的格子）。"
        "修那一条时把「腾出来的格子填什么」让给了这条概念——一让才发现它接不住："
        "`downstream` / `bar_box` / `cap_block` 三个词全是按**色**取的，"
        "一色五条时 `bar_box` 并成一个跨全盘的假框，`downstream(12)` 返回 `[]`，`_plan` 一律 None。\n"
        "**它的 S=1.000 和 P=1.000 从来没在这一关上被考过**，因为它在这一关只会弃权。"
        "这是「只在真值为真时开口的判据会把上游的错吸收成弃权」的同一族——"
        "分数满不等于没错，可能是没人在问。\n"
        "**v6 改法**：单位整个换成条。被点色的每一根条各自取 `bar_downstream`，"
        "每一根后代条连同自己的帽按 `button` 给的 d 整体平移。\n"
        "**为什么这一改值得花**：这一关唯一推得动尖的动作会卡住（两根迎面横条空档只剩一整段），"
        "要把横条挪开只能按它们各自的**父按钮**——六个合法动作里有四个的效果全靠这条概念预测。"
        "所以修它是为了路线算得出来，不是为了 E 好看。\n"
        "**改之前先影子记分**（`runs/<run>/shadowchain.py`，全去重语料 182 条，"
        "apply 在**全量**语料上逐格对答案，比 settle 的 held-out 更严）："
        "FALSE 0、apply 说错 0 格、TRUE 34→48、NA 148→134、**第 3 关开口 TRUE 0→14**。\n"
        "**影子被自己事先写的判据否掉了两次，两次都是同一个东西：菱形那四个点。**\n"
        "第一次：`cells_in(box)` 会把压在条 box 里的四个色 13 点一起收进来，影子把它们跟着条平移，"
        "apply 说错 24 格。第二次：源头排掉了，落点没排——条从菱形**底下**滑过去时，"
        "落点上那四个点仍是 13，assert_ 判 FALSE 2 条。两侧都排掉才干净。\n"
        "`every_blob_moves_on_its_own_axis._claim_boxes` 里早就写着 `if rc in dots: continue`，"
        "**我照抄了它的结构，没照抄它这一行**——和它 v1 栽在 color_blobs 上是同一种错："
        "抄结论不抄理由。写「apply 说错哪怕 1 格就否掉」那一条判据，是这次唯一拦住我的东西。"
        "\n\n**这一版又是同一处内伤，第四条中招，主张仍然一个字没动：取数口还是按色的。**"
        "v6 把单位换成了条，却漏掉了入口——`button(prev, action)` 内部仍走 `bar_box` + `capped_side`，"
        "一色多条时并成跨全盘的假框、当场返回 None，于是**整条概念在一色多条的盘上从不开口**。"
        "v6 的 NOTE 里写着「单位整个换成条」，那句话对里面对，对门口不对："
        "**换读法只换了循环体，没换取数口，而分数上看不出区别——因为闭嘴不扣分。**"
        "改法和 [bar_free_end_moves] v10、[bar_tip_follows] v5 逐字相同："
        "`click_panel` 出被点色，`blob_moves` 出每一根条各自的位移，各自的下游按各自的 d 平移。"
        "由来是整帧模拟器（`runs/<run>/simcheck.py`）：它把全册 apply 叠成一帧去对答案，"
        "报出「上游那一截说中了、挂在它自由端的下游整块没人说」这一类缺口 48 步——"
        "**这类洞不产生反例，所以结算永远发现不了它**，只有拿整帧去对才看得见。"
        "改之前影子记分（`runs/<run>/shadowchain2.py`，全去重语料 393 条，四条判据跑之前写死）："
        "FALSE 0→0、apply 认领 8244 格说错 0 格、原来开口的判词不同 0 条、TRUE 92→141；"
        "新开口全在一色多条的那几关。"
        "新增两处闭嘴，都是「算不出」不是「不会发生」：后代条本身就是被点色的另一根（它既自己伸缩又被拖）、"
        "同一根后代被两根父条各拖一次。\n"
        "\n**v10：终局卡上记了一次意外，而 v6 那句「两侧都排掉才干净」正是病根。**\n"
        "第 3 关第 1062 步 `ACTION6:51,57`，一根色 11 的横条从菱形底下下移 3 行，"
        "落点上有 4 格该变成 11 而全册没人说得出——(12,31)(13,30)(13,32)(14,31)，"
        "恰是 prev 的四个点整体下移 3 行。**四点是画在条上面的，不是把条切断的**："
        "源头把那几格排掉，等于宣称条少了 4 格身体，落点自然缺 4 格。该排的只有落点一侧。\n"
        "**这一课 [blocking_seg_is_pushed] v5 上过一次**（它当时新增 `_body()`），"
        "我在 v6 里照抄了 `every_blob_moves_on_its_own_axis` 的 `if rc in dots: continue`，"
        "又一次抄结论不抄理由——那一行的理由是「落点上的四点不归你」，不是「源头的四点不是你」。\n"
        "**这 4 格不产生反例，却是整批的死因**：assert_ 在那一步判 TRUE（它根本没主张那几格），"
        "settle 报 0 反例，可模拟帧从那 4 格起就不是真帧了；"
        "下一步 apply 照着错帧算，到第 1064 步炸成 9 格意外、批停退出码 5。"
        "**链式预测的分母不是批长，是「到第一格无人认领的真实变化为止」**"
        "（runs/<run>/chaindrift.py 逐步量出来：第 1058 步计费条 1 格 → 第 1062 步这 4 格 → "
        "第 1063 步 68 格 → 第 1064 步炸）。\n"
        "**改法与点名**（runs/<run>/dotshadow.py，四条判据跑之前写死）："
        "残差里凡出现与菱形四点同形的簇就算这一类，点名周边说对最多格子的那条概念。"
        "改前全去重语料 593 条里 2 处，都点在本条头上，全册别的 10 条 apply 概念一处没有；改后 0 处。\n"
        "**中间还被自己的判据四否掉一次，如实记下**：第一版改法把真身写成 `cells_in(box)` 整个框，"
        "名单确实清空了，但本条 apply 在全语料上说错从 0 涨到 **152 格**——框里还压着别的东西。"
        "判据四写的是「不许用多认领换错认领」，它当场生效。第二版换成"
        "「框里看得见的该色格子 ∪ 框里的四点」，和 blocking_seg_is_pushed 逐字同一个定义："
        "名单 0 处、全册 11 条 apply 概念说错各 0 格。\n"
        "\n**v11：下游条的尖是真身，而按色收格子收不到它。**\n"
        "由来不是反例——assert_ 从来没主张过尖的落点，错了也不记账——而是终局卡上批停的直接死因："
        "重放第 1 关的收缩序列时，每一步下游色 14 条的尖跟着退 3 格，apply 把落点按身子色填、"
        "世界给的是尖色，链式预测必错一格，终局卡一格就停批。"
        "同一步里 bar_tip_follows 帮不上：它的单位是「被点那一色」的条，被拖的下游条不在它名下。"
        "修法是把 tp.get(key) 收进 body（读不出尖就当没有，身子照旧算）："
        "assert_ 从此主张尖的落点，apply 从此画得出它。"
        "改前先在 runs/<run>/accept_tipfix.py 上跑四条判据（写死在改之前）："
        "全去重语料 639 条 FALSE 0→0、apply 说错 0 格→0 格、"
        "三个尖落点（tid 2e7583114d4b86e8 / 9dc2beec80a1a3af / 9955d0b340a67eb4）"
        "apply 认领 False→True。\n"
        "\n**v13：换关判据换成前推的 will_levelup——ctx 那道在押注时是假的。**\n"
        "由来：终局卡重放第 1272 步（= 语料第 981 步，1→2 升关，tid c43efd1ba8f96023）批停退出码 5，"
        "81 格预测错，全是本条认领的——升关整盘重画，它却照常算了下游平移。"
        "病根和 [bar_tip_follows] v6 一字不差：`ctx[\"level_next\"]` 那道判据在 settle 时是对的，"
        "**押注算链式预测时它还不存在**，只能拿 level_prev 冒充，判永远相等，守卫形同虚设。"
        "全册在升关步会开口的 apply 概念只有本条一条（runs/<run>/probe_levelup_apply.py 实测："
        "语料全部 25 个升关步里，876 / 1025 等步无人认领，唯独 981 本条认领 113 格）。"
        "修法：_plan 加一道 `will_levelup(prev, action) is True → None`，"
        "它查的是帧和动作，押注时也判得出来。改前先跑 runs/<run>/accept_wl.py："
        "全去重语料 639 条上零漏报（25 个升关步全 True）、零误报（其余 614 条全不 True）。\n"
        "\n**v18 主张一个字没改，改的又是脚下那个词**：反例 d4b9966af478b81c（一击预测错 139 格）。"
        "本条的 scope 早就把「世界会整步拒」让给了 `_lib.refused`，而 refused() 在那一步漏报了——"
        "**这是同一个洞第二次开在同一处**（上一次是 99bd12bdb9dc06d9，楔住）。"
        "补第九种机制 `joint_grow_into_child` 之后本条在那一条上判 NA。"
        "值得记的是这个洞的形状：本条把「会不会被拒」整个外包出去，所以它的 apply 有多准，"
        "上限就是那个词有多准；**词错一次，本条就替它挨一次打**，而那个词从来不被打分。")
EVIDENCE = ["64e2bc30cd0e77bc", "4605a0c4a215b03e", "b929ced9b42319f5",
            "f1d3acb18c30658a", "a5d85a4cb666620d",
            # v11：下游条的尖跟着走，落点该是尖色——三条重放停批转移
            "2e7583114d4b86e8", "9dc2beec80a1a3af", "9955d0b340a67eb4",
            # v13：升关那一步整盘重画，押注时 ctx 里没有 level_next
            "c43efd1ba8f96023",
            # 楔住：refused() 原先漏报这一步，本条信了它，一击预测错 27 格
            "99bd12bdb9dc06d9",
            # 链成环：三根条首尾互贴，「后代」定不出来，本条顺着环把不该拖的条拖了 30 格
            "e74b319dc32f4de7",
            # v18：和 99bd12bdb9dc06d9 同一个病——refused() 第二次漏报（挡住的是父子共用的关节），
            # 本条信了它，一击预测错 139 格。补 _lib.joint_grow_into_child 后本条在这条上判 NA
            "d4b9966af478b81c"]

from _lib import (BG, CAP, TIP, bar_cells, bar_downstream, bar_units_all, blob_moves, cells_in,
                  click_panel, diamond_dots, occupied_after, refused, tips, will_levelup)


def _plan(prev, action, ctx=None):
    """[({这根后代条的旧格: 该格的真色}, 位移)]；算不出返回 None。

    位移**按父条各取各的**：`blob_moves` 已经按条给出每一根的自由端位移，
    所以一色多条时每一支下游跟着自己那根父条走，不再共用一个按色算出来的 d。

    **菱形四点压着的那几格留在真身里**（v10，见 NOTE）：四点是画在条**上面**的，
    条从底下过去只是被挡住，不是被切断。源头把它们排掉，落点上那几格就没人认领——
    这正是 v6 那句「两侧都排掉才干净」错的地方：该排的只有落点一侧。
    所以格集换成「格 → 真色」的字典：框里的格子是这根条的色（不管眼下被什么盖着），帽格是帽色。

    换关那道 NA 也放在这里：SCOPE 写着换关返回 NA，v6 只有 `assert_` 守着、`apply` 没守——
    和 [move_counter_row63] v5、[bar_tip_follows] v2 是同一个错，那两条都栽过。
    判据放进两边共用的 `_plan`，检查器和生成器从此不可能各守一套。
    """
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None
    if will_levelup(prev, action) is True:
        # 换关那一步整盘重画，下游平移无从谈起（v13，同 [bar_tip_follows] v6 的洞）：
        # 这道判据查的是**帧和动作**，押注算链式预测时也判得出来——
        # ctx["level_next"] 那道判据在 settle 时是真的，押注时是假的（level_next 还不存在，
        # 只能拿 level_prev 冒充），所以第 1272 步升关那一下 81 格全错、批停退出码 5。
        return None
    cp = click_panel(prev, action)
    if cp is None:
        return None
    color = cp[0]
    if refused(prev, action) is not False:
        return None
    mv = blob_moves(prev, action)
    if mv is None:
        return None
    allu = bar_units_all(prev)
    if allu is None:
        return None
    caps_of = {}
    for k, units in allu.items():
        for box, _side, caps in units:
            caps_of[(k, tuple(box))] = tuple(caps)
    tp = tips(prev) or {}     # 读不出尖就当没有：身子照旧算，尖那一格不认领

    clicked = {(color, tuple(box)) for box, _s, _d in mv}
    dots = set(diamond_dots(prev))
    visible = {}
    out, seen = [], set()
    for box, _side, d in mv:
        ds = bar_downstream(prev, color, box)
        if ds is None:
            return None
        for key in ds:
            if key in clicked or key in seen:
                return None      # 既自己伸缩又被拖 / 被两根父条各拖一次：位移叠不出来
            seen.add(key)
            caps = caps_of.get(key)
            if caps is None:
                return None
            k = key[0]
            if k not in visible:
                cs = bar_cells(prev, k)
                if cs is None:
                    return None
                visible[k] = set(cs)
            # 真身 = 框里**看得见的该色格子** ∪ 框里的菱形四点。整个框不行：框里还可能压着别的东西
            # （第一次改成整框，全语料 apply 说错从 0 涨到 152 格，当场被 dotshadow 的判据四否掉）。
            body = {rc: k for rc in cells_in(key[1]) if rc in visible[k] or rc in dots}
            for rc in caps:
                body[rc] = CAP
            # 尖也是这根条的真身，而它的色不是 k —— 所以上面那句按色收格子的写法收不到它。
            # 少收一格的后果不是「少说一格」而是「说错一格」：尖走后的那个落点被上面按 k
            # 填成了身子色，世界给的是 TIP。这一格不产生反例（assert_ 原来根本没主张它），
            # 但它是终局卡上批停的直接死因，见 NOTE v11。
            t = tp.get(key)
            if t is not None:
                body[t] = TIP
            for r, c in body:
                if not (0 <= r + d[0] <= 63 and 0 <= c + d[1] <= 63):
                    return None
            out.append((body, d))
    return out or None


def assert_(prev, action, nxt, ctx=None):
    p = _plan(prev, action, ctx)
    if p is None:
        return "NA"
    dots = set(diamond_dots(prev))
    for body, d in p:
        for (r, c), col in body.items():
            rr, cc = r + d[0], c + d[1]
            if (rr, cc) in dots:
                continue     # 条从菱形底下滑过去，那四个点不归它
            if nxt[rr][cc] != col:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """整条下游连同各自的帽一起平移；腾出来的格子回底色，但这一步之后有人占着的不算。"""
    p = _plan(prev, action, ctx)
    if p is None:
        return None
    moving = set()
    out = {}
    for body, d in p:
        moving |= set(body)
        for (r, c), col in body.items():
            out[(r + d[0], c + d[1])] = col
    occ = occupied_after(prev, action)
    if occ is None:
        return None
    dots = set(diamond_dots(prev))
    for rc in moving - set(occ):
        if rc in dots:
            continue
        out[rc] = BG
    for rc in dots:
        out.pop(rc, None)      # 菱形四点身上一个字都不写
    return out or None
