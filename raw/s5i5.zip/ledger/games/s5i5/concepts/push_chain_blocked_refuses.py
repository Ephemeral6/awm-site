"""伸缩顶到下游那一节时，那一节的落点上压着死物就整步无事发生、压着的只是更下游的条就照走；
挡在落点上的要不是被点那根条的下游（外人），世界一律整步拒绝——它只搬自己的下游。"""
LEVEL = "L2"
SCOPE = ("只看 push_target 归得出「谁挡在路上」的步；换关、push_target 为 None、"
         "bar_downstream 算不出来返回 NA。"
         "挡路那根条不在被点那根条的下游（外人）时断言整步被拒。"
         "在下游时沿落点往下走：碰到死物断言整步被拒；一路只碰到更下游的条、"
         "最后落点干净，断言整步照做。"
         "落点越出盘面、压着的格子归不到唯一一根条、连环转圈、超过 8 层，一律返回 NA。"
         "判「世界拒了没有」用 _lib.same_off_counter，不用 prev == nxt。")
NOTE = ("**v2 错在哪**：v2 的判别量是「挡路那节的落点上压着东西没有」，压着就断言被拒。"
        "连点 12 下伸把它一次打掉 12 条：那 12 步压着的是**更下游的另一根条**，世界一路推了过去。"
        "把全去重语料按「挡路那节是不是下游」重切一刀，四格表干净得出奇"
        "（runs/s5i5-0907-0046/blkprobe2.py 实跑，读数在同名 .out）：\n"
        "  下游 / 落点干净        → 世界照做 93 条，拒 0 条\n"
        "  下游 / 落点压着别的条  → 世界照做 12 条，拒 0 条（v2 在这里全判错）\n"
        "  下游 / 落点压着死物    → 世界拒 5 条，照做 0 条\n"
        "  外人 / 落点干净        → 世界拒 1 条，照做 0 条\n"
        "  外人 / 落点压着东西    → 世界拒 8 条，照做 0 条\n"
        "所以真正的判别量有两个，而 v2 只有一个：**亲缘**（下游还是外人）在前，"
        "**落点上压的是死物还是条**在后。v2 把这两件事挤进「压着东西」一个格子里，"
        "于是必然在其中一半上说错——它 17 条「让不开」里 12 条是错的，只是那 12 条当时还没发生。\n"
        "**v2 的两道 guard 一并撤掉**：seg_overlap / same_bar_collide 是为了躲 483e4161735d64c1"
        "（第 350 步，push_target_block 为空却被拒）而加的。现在那一条有了正解——挡路的色8 是外人，"
        "**外人一律拒**，不是什么异色相撞。guard 撤掉之后这条概念在那 105 条「照做」上一条不漏地表态，"
        "代价是：将来若有一步因为别的拒因被拒，它会直接判 FALSE 而不是闭嘴。这是有意换的——"
        "已知拒因在场就闭嘴，正是 v2 把自己养成 N=0 的那条路。\n"
        "**没检验过的那一片**：push_target 归不出谁挡路的步（语料里占大头）这条概念一句话没有；"
        "连环走到外人身上（下游 → 更下游 → 外人）语料里一次没出现过，这里按「不推外人」断言拒，"
        "是从亲缘那一刀外推的，没有观测撑着。")
EVIDENCE = ["4605a0c4a215b03e", "689974eca1c5e87d", "68c852990e7808a2", "74fb0c74c11dbd52",
            "7bd15a5deaf0c404", "94bd53ce16a740d4", "a752d9151916abf2", "a7b3ba348f90e477",
            "e00372dfcc110131", "fb7351572f2b1599", "ffa316f279ef6183",
            "1b010d0faf3aaff4", "ab317a0d38c43a13", "a6dea07e39b4a0a1", "0c0b05e372baee45",
            "453bd3afab7fb571", "f31e8cbde2bf8d94", "f5e20758a3d0cf4f", "9b7612f1e0daba11",
            "ed5ea26acbb1b1b0", "9c6835f07f136413", "8f0dcc1d171dc938", "4917fa36f00ea310"]

from _lib import (BG, CAP, bar_downstream, bar_units, cells_in, diamond_dots,
                  obstacles, push_target, same_off_counter, seg_colors)


def _owner(g, cells, segs):
    """这几格归到哪一根条：(色, bbox, 占地集)；归不到唯一一根返回 None。"""
    cand = set(cells.values()) & segs
    if len(cand) != 1:
        return None
    oc = cand.pop()
    units = bar_units(g, oc)
    if not units:
        return None
    owners = []
    for ob, _side, ocap in units:
        cs = set(ocap)
        t, bo, l, r = ob
        ok = True
        for rc, v in cells.items():
            if v == CAP:
                if rc not in cs:
                    ok = False
                    break
            elif not (t <= rc[0] <= bo and l <= rc[1] <= r):
                ok = False
                break
        if ok:
            owners.append((oc, tuple(ob), frozenset(cells_in(ob)) | frozenset(cs)))
    return owners[0] if len(owners) == 1 else None


def _walk(prev, action):
    """把「谁挡谁」推到底：'拒' / '走' / None（说不准）。"""
    p = push_target(prev, action)
    if p is None:
        return None
    color, box, d, oc, ob, ocap = p
    down = bar_downstream(prev, color, tuple(box))
    if down is None:
        return None
    if (oc, tuple(ob)) not in down:
        return "拒"                                  # 挡路的是外人
    dots = diamond_dots(prev)
    obs = set(obstacles(prev))
    segs = set(seg_colors(prev))
    n = len(prev)
    cur = frozenset(cells_in(ob)) | frozenset(ocap)
    seen = {cur}
    for _ in range(8):
        bad = {}
        for rc in sorted({(r + d[0], c + d[1]) for r, c in cur} - cur):
            if not (0 <= rc[0] < n and 0 <= rc[1] < len(prev[rc[0]])):
                return None                          # 落点出界：没见过
            v = prev[rc[0]][rc[1]]
            if rc in dots or v == BG:
                continue
            if rc in obs:
                return "拒"                          # 顶到死物
            bad[rc] = v
        if not bad:
            return "走"
        own = _owner(prev, bad, segs)
        if own is None:
            return None
        oc2, ob2, cells2 = own
        if (oc2, ob2) not in down:
            return "拒"                              # 连环走到外人身上
        if cells2 in seen:
            return None
        seen.add(cells2)
        cur = cells2
    return None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    v = _walk(prev, action)
    if v is None:
        return "NA"
    ref = same_off_counter(prev, nxt)
    if v == "拒":
        return "TRUE" if ref else "FALSE"
    return "TRUE" if not ref else "FALSE"
