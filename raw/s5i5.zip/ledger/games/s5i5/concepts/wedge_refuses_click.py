"""刚体一头被伸长的条顶着、另一头抵着不动的条的自由端时，世界整步拒绝：除计数器那一行外全帧不动。

这一条是拿来核 `_lib.refused()` 的：refused() 是共用词汇，改它不算改版、从来没被单独评过分，
而三条概念都拿它当闸门（`refused(...) is not False` 才开口）。所以这里**不引用 refused()**，
只引用它新加的那一支 wedged_grow_and_still，然后拿帧上另一种读法（帧差落在哪几行）去对。
"""
LEVEL = "L2"
SCOPE = ("只看 wedged_grow_and_still 说真的那些点击；说假或算不出来返回 NA。"
         "换关（level_prev != level_next）返回 NA。")
NOTE = ("由第 1414 步逼出来：那一步 refused() 说不会拒，三条概念信了它，一击预测错 54 格。"
        "全去重语料 673 条里这个构型命中 3 条，3 条全是世界整步拒绝；"
        "同样贴着不动的条的自由端、但驱动方式是「拖着走」的有 22 条，全部照走——分家的是伸长，不是接触。")
EVIDENCE = ["99bd12bdb9dc06d9", "0cb8a42a960f7e17", "b2f1b087ef082fee"]

from _lib import wedged_grow_and_still, COUNTER_ROW


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action == "RESET":
        return "NA"
    try:
        if wedged_grow_and_still(prev, action) is not True:
            return "NA"
    except Exception:
        return "NA"
    for r in range(len(prev)):
        if r == COUNTER_ROW:
            continue
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """它敢生成的那部分：计数器那一行之外，每一格都和上一帧一样。"""
    if action == "RESET":
        return None
    try:
        if wedged_grow_and_still(prev, action) is not True:
            return None
    except Exception:
        return None
    return {(r, c): prev[r][c]
            for r in range(len(prev)) if r != COUNTER_ROW
            for c in range(len(prev[r]))}
