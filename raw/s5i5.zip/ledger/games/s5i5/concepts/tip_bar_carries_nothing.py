"""带尖（TIP）的那根条是手臂的自由端：直接驱动它的那一击，别的条一格都不动。
它后面没有挂任何东西——所以「手」永远是链的末端，不可能当谁的父亲。"""

LEVEL = "L6"
SCOPE = ("只看**被直接驱动的那根条正好带着尖**的那一击；不是就返回 NA。"
         "tips / bar_units_all 读不出来返回 NA。"
         "**这一击没让驱动者自己动起来就返回 NA**（它自己占的格子一格没变）"
         "——整击被拒或落空时谁都没动，说明不了什么；"
         "这道判据只看帧，不走 `refused`：`refused` 在图例点击上返回 None，用它当门等于整类闭嘴。"
         "算不出这一击直接驱动的是哪一根条就返回 NA："
         "图例点击看 legend_click，按钮点击看 blob_moves 里动了的那个框；两样都指不到唯一一根就 NA。"
         "**和驱动者同色的条一并让出去**（图例点一次会把同色的每一根都转，它们不是「被拖」）。"
         "**别的条身上属于驱动者的那些格子也让出去**：两根条可以共用同一排帽格，"
         "`bar_units_all` 把同一条帽带同时算给两边，那几格变了是驱动者自己在动，不是别人被拖走。"
         "换关返回 NA。")
NOTE = ("这一条是替一条被打死的概念站出来的那一半。原来的 [ring_has_no_downstream] 说"
        "「父指针成环的帧上一根后代都不拖」，靠两条证据；下一步世界就把它打死了——"
        "又一条成环帧，被点的那根转了 180°，**挂在它后面的那根条被按同一个 180° 结结实实地转走了**"
        "（旧框逐格映射到新框，帽从左翻到右，对得上绕同一个中心的 180°）。撤册，不改判据。\n"
        "真正的病根不在「环上世界怎么做」，在**环本身是读错了**：`bar_chain` 拿"
        "「谁的帽贴住谁的身体」认父子，于是给带尖的那根也认了一个孩子——而尖是手臂的自由端，"
        "它后面本来就不该再挂东西。三根条首尾相接看着像环，其实是一条链被一条假边接上了首尾。\n"
        "掐掉那类边的代价实测为零：这种边只在 **3/730** 帧出现，正好就是那 3 条「成环」帧；"
        "掐掉之后成环帧归零，别处每一根条的后代集合一个都没变"
        "（runs/<run>/accept_tiproot.py 的 H1/H2/H3，改代码之前写死）。\n"
        "这句话是**世界事实不是几何**，所以它不能只躺在 `_lib.bar_chain` 里——"
        "改 `_lib` 不算改版、不打分，藏在那里等于一次闸都不走。"
        "这条概念就是让它挨打的地方：用「别的条的格子有没有变」这条独立读法核，"
        "哪天手后面真拖动了什么，当场是反例。\n"
        "两次弯路（先闭嘴、再立错主张）都错在同一处："
        "**拿「结构算不出来」当成了「世界不做这件事」**。结构算不出来时该先问结构是不是读错了。\n"
        "\n**v2 是它入册当批就挨的两个反例（held-out，都在同一个图例动作上）：**"
        "两根条可以**共用同一排帽格**——`bar_units_all` 把同一条帽带同时算给两边，"
        "于是驱动者的帽一动，另一根条名下的格子就跟着「变了」，v1 当场判别人被拖走。"
        "两处帧差合起来 5 格与 22 格，逐格看全落在那条共用帽带和驱动者自己的落点上，"
        "别人的**身体**一格没动。改法：判别人之前先把属于驱动者的格子（它的框 + 它的帽）减掉。"
        "主张一个字没动，减的是读法里分不清归属的那几格。")
EVIDENCE = ["f4081a0902758f1f",   # 图例点击带尖那根：只转了它自己，另两根一格没动
            "e74b319dc32f4de7",   # 按钮驱动带尖那根：只动了它自己，另一根一格没动
            # v2 的两个反例：两根条共用同一排帽格，v1 把驱动者自己的帽算成了别人被拖走
            "e9a2bdee293d1ba9", "46ab4b3395610904"]

from _lib import bar_units_all, blob_moves, cells_in, legend_click, tips


def _driver(g, action):
    """这一击直接驱动的是哪一根条：(色, 框)。指不到唯一一根返回 None。"""
    allu = bar_units_all(g)
    if allu is None:
        return None
    k = legend_click(g, action)
    if k is not None:
        units = allu.get(k, [])
        if len(units) != 1:
            return None
        return (k, tuple(units[0][0]))
    bm = blob_moves(g, action)
    if not bm or len(bm) != 1:
        return None
    box = tuple(bm[0][0])
    hit = [(c, tuple(b)) for c, units in allu.items() for b, _s, _caps in units
           if tuple(b) == box]
    if len(hit) != 1:
        return None
    return hit[0]


def _cells(allu, color, box=None):
    """一根条（或一色的全部条）现在占的格子：身体框 + 帽格。"""
    out = []
    for box_, _side, caps in allu.get(color, ()):
        if box is not None and tuple(box_) != tuple(box):
            continue
        out.extend(cells_in(box_))
        out.extend(caps)
    return out


def _moved(prev, nxt, cells):
    return any(prev[r][c] != nxt[r][c] for r, c in cells
               if 0 <= r < len(prev) and 0 <= c < len(prev[0]))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    try:
        tp = tips(prev)
        allu = bar_units_all(prev)
        if tp is None or allu is None:
            return "NA"
        drv = _driver(prev, action)
    except Exception:
        return "NA"
    if drv is None:
        return "NA"
    tipbars = {(k[0], tuple(k[1])) for k in tp}
    if drv not in tipbars:
        return "NA"          # 被驱动的不是「手」，这一条不管
    if not _moved(prev, nxt, _cells(allu, drv[0], drv[1])):
        return "NA"          # 驱动者自己都没动：整击被拒或落空，说明不了什么

    # 独立读法：除驱动者（及与它同色的条）之外，每一根条现在占的格子一格都不许变。
    # 先把属于驱动者的格子减掉——两根条会共用同一排帽格，那几格变了是它自己在动。
    own = set(_cells(allu, drv[0], drv[1]))
    for c in allu:
        if c == drv[0]:
            continue
        if _moved(prev, nxt, [rc for rc in _cells(allu, c) if rc not in own]):
            return "FALSE"
    return "TRUE"
