"""每根**条**里那个色 13 的尖，永远停在「离没帽的那一端 1 格」的位置上（帽色 3 贴在另一端）。"""
LEVEL = "L1"
SCOPE = ("对这一帧上分出来的每一**根条**各查一次，看的是转移后的那一帧 nxt；"
         "条分不出来、尖读不清（tips 返回 None）返回 NA；"
         "没有尖的条跳过；全跳过就返回 NA；换关返回 NA")
NOTE = ("v2：把 _capped_side 挪进 _lib.capped_side，本体逻辑不变。"
        "v3：条色不再写死，改成每帧现认（_lib.seg_colors）；没有尖的节自然跳过。"
        " || v4：和 segments_never_on_walls 同一处内伤——按**色**读框。一色两根条时"
        "bar_box 给的是两根的并集，尖在这个大框里的相对位置当然不对。"
        "v3 一直没被打脸，只因为同色两个帽让 capped_side 返回 None、整色被跳过；"
        "直到一根条的自由端顶到最后一行，那一整排计数条（色 3）被读成了帽，"
        "跳过没了，主张才第一次在一色多条的盘上开口，当场判错。"
        "现在改成逐根条读（bar_units_all 给框和帽面、tips 给这一根的尖）。"
        "留一条已知的窄处：自由端已经伸出盘外的条，盘上读到的框是短的，"
        "它若还带着尖，这条主张会按短框去算，可能判错——**照样开口，错了就是反例**。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "1e5c6990b6e3714b",
            # v4：计数条冒充帽，整色大框把尖的相对位置算歪
            "cd787353d6bd4130", "4012e7320d323009",
            "298f886fec8e32fe", "b6893fd9b900d4c5"]

from _lib import bar_units_all, tips


def _expected_tip(box, side):
    t, bo, l, r = box
    mid_r, mid_c = (t + bo) // 2, (l + r) // 2
    return {"left": (mid_r, r - 1), "right": (mid_r, l + 1),
            "top": (bo - 1, mid_c), "bottom": (t + 1, mid_c)}[side]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    allu = bar_units_all(nxt)
    tp = tips(nxt)
    if not allu or tp is None:
        return "NA"
    seen = False
    for color, units in allu.items():
        for box, side, _caps in units:
            got = tp.get((color, tuple(box)))
            if got is None or side is None:
                continue
            seen = True
            if got != _expected_tip(box, side):
                return "FALSE"
    return "TRUE" if seen else "NA"
