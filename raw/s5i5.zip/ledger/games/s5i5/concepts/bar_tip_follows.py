"""点面板图标，那根条里的色13尖跟着自由端走同一个位移；原来那格留在条里就变条色、落到条外就变底色。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION6 点在某块面板的图标上（_lib.click_panel 认得出）；"
         "该色的条分不出来、这一帧的尖读不清（tips 返回 None）、帽端认不出返回 NA；"
         "换关返回 NA（前推算，_lib.will_levelup，不查 ctx 里的 level_next）；落点框整个在画得出来的那一块之外、或缩过头返回 NA；"
         "**有任何一根条会长进面板或图例那种框，整条返回 NA**（同 bar_free_end_moves 的窄处）；"
         "**世界会整步拒绝这一次点击（_lib.refused）返回 NA**，算不出来会不会被拒也返回 NA。"
         "**只查带尖的那些条**，一根都没有就返回 NA；"
         "**尖会落到画得出来的那一块之外时，只让出「尖的新位置」那一格**（那一格不在盘上，"
         "既对不了答案也当不了反例）——尖**原来**那一格照常认领、照常检验，它就在盘上")
NOTE = ("v2 挨了 4 个反例（ffa316f279ef6183 等），和 bar_free_end_moves 是同一个洞、同一批步："
        "v1 根本没查「这一步会不会被世界整步拒绝」，只查了越界。"
        "被拒的那几步里尖一格不动，它却照算尖走了 3 格。"
        "加一道 _lib.refused 的守卫，主张没动——「尖跟着自由端走」说的一直是**点击生效时**的事。"
        "v2 同时补上一处 assert_ 和 apply 不一致的地方：SCOPE 写着换关返回 NA，`assert_` 守了，"
        "`apply` 却没看 ctx，于是在两次换关的转移上照样认领格子、全部说错"
        "（228810ee4f309efd 2 格、26c0b1510bdb91ca 2 格，加上 bar_free_end_moves 的 8 格，"
        "就是册子当时说错的全部 12 格）。**检查器守了 scope 不等于生成器守了 scope**，"
        "而说错的格子比没说的格子严重——规划器会照着它算下一步。"
        "\n\n**b2f1b087ef082fee：第三次挨打，第三次都是 `_lib.refused` 漏了一种拒绝，主张仍没动。**"
        "这次漏的是刚体新压到菱形目标点上（见 [wall_push_onto_target_dot_refuses]）。"
        "和 [bar_free_end_moves] 同步挨打、同步恢复——两条概念共用一个守卫谓词，"
        "所以它们的反例永远成对出现，**看起来像两个独立的证据，其实是同一个洞被数了两遍**。"
        "报「几条概念挨了打」的时候要记得这一点：条数不是独立性。"
        "\n\n**v5 第四次挨打，第四次仍然不是主张错：这次是读法。**"
        "和 [bar_free_end_moves] v10 同一处内伤、同一批 tid——button/bar_box/tip 全是按**色**取的，"
        "一色两根条时那是个跨半个盘的假条，尖的位移当然算歪。"
        "改成按条读（click_panel 出被点色、blob_moves 出每根条的位移、tips 出这一根的尖）。"
        "第四次成对挨打这件事本身要记住：两条概念的反例数看着是 2，独立证据只有 1。"
        "\n\n**这一版缩 scope，主张一个字没动，而且在全量语料上一条转移的判词都不变。**"
        "由来不是反例，是一个**语料照不到的**读数：拿册子接成的规划器离线搜路时，"
        "这条概念交出过 56 次**盘外**的落点——`t + d` 从来没裁过，条的自由端一伸出盘外，"
        "尖就跟着被算到第 -1 行或第 64 列去了。那种格子和世界对不了答案："
        "它既不算说对也不算说错，所以**永远不会变成反例**，settle 也就永远不会因为它扣分。"
        "（`assert_` 那边其实会判 FALSE——`nt not in have`——只是语料里一次都没走到过这种局面。）"
        "现在把它明说成 NA：尖出了画面就不是「我说错了」，是「我看不见了」，"
        "而看不见的东西不该由这条概念替它作答。"
        "**值得记的是这个洞是怎么被发现的**：不是被世界打的，是被一个只报不拦的计数器数出来的——"
        "规划器每收到一个盘外落点就记一笔它是谁交的。不记名字的话，这 56 次会被规划器当成"
        "「这步走不通」默默绕过去，而绕过去和修好在盘面上长得一模一样。"
        "\n\n**v6 和 [bar_free_end_moves] v12 第五次成对挨打，同一个位置、同一条 tid**"
        "（ec8ffe6775dff87f，终局卡第 0 关过关那一步）。主张没动：换关整盘重画，"
        "尖走到哪在那一帧上看不见，scope 里也一直写着换关返回 NA——"
        "**但那道判据查的是 `ctx[\"level_next\"]`，押注时它还不存在**，所以生成器守不住。"
        "换成前推的 `_lib.will_levelup`。成对挨打这件事第二次记：反例数 2，独立证据仍然只有 1。"
        "\n\n**v7 和 [bar_free_end_moves] v13 第六次成对挨打，同一条 tid（42341047045cf7fd）。**"
        "主张没动：那一步世界整步拒了，而两条的 scope 都靠 `_lib.refused` 让路，`refused` 说不拒——"
        "它在全语料上唯一的漏报。病根与修法见 [refused_says_it_exactly] v5 的 NOTE"
        "（手臂有一节缩到零长，只剩一顶没人认领的帽；新增 `_lib.stranded_cap`）。"
        "**这一步也是本条 apply 在全语料上唯一说错的地方：2 格，改后 0 格。**"
        "成对挨打第三次记：反例数 2，独立证据仍然只有 1。"
        "\n\n**v8 把 v5 缩过头的那一道收回来一半，主张一个字没动。**"
        "v5 说「尖落到画面外就整条返回 NA」，理由是那一格对不了答案。理由只对**一半**："
        "对不了答案的是尖的**新**位置，尖**原来**那一格明明还在盘上，颜色也完全定得出来"
        "（留在新框里就变条色，否则变底色）。v5 把两格一起让了出去。"
        "代价不是反例，是一个**结算永远看不见**的洞：第 1710 步真实帧差 4 格，"
        "全册只有 [bar_free_end_moves] 开口认领 3 格，`(25,61) 13→9`——尖原来那一格变回条色——"
        "一条概念都没认领。押注是**链式**的：每一步的预测叠进模拟帧再算下一步，"
        "于是模拟帧从这一格起就不是真帧，模型以为尖还留在原处，"
        "下一步（第 1711 步）照着错帧算收缩，10 格全错、批停。"
        "**闭嘴不产生反例，所以 S 一直满分，而错在别处爆开。**"
        "这和 [chain_drags_downstream] NOTE 里那一条是同一族："
        "链式预测的分母不是批长，是「到第一格无人认领的真实变化为止」。"
        "教训：缩 scope 的时候要问的不是「这一整击我看得清吗」，而是**逐格**问「这一格我看得清吗」——"
        "让出去的应该是看不见的那一格，不是包含它的那一整步。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "1e5c6990b6e3714b",
            "ffa316f279ef6183", "a7b3ba348f90e477", "68c852990e7808a2", "fb7351572f2b1599",
            "b2f1b087ef082fee",
            # v5：一色两根条，按色读的假条把尖的位移算歪
            "4012e7320d323009", "298f886fec8e32fe", "b6893fd9b900d4c5",
            # v6：换关那一步整盘重画，而「换关」原先只有事后才算得出来
            "ec8ffe6775dff87f",
            # v7：手臂有一节缩到零长（只剩一顶没人认领的帽），世界整步拒绝，
            #     而 _lib.refused 的六种机制全说「不拒」——它在全语料上唯一的漏报
            "42341047045cf7fd",
            # v8：尖走到盘外，v5 连尖**原来**那一格也一起闭嘴，
            #     那一格无人认领 → 模拟帧带着一个不存在的尖走进下一步
            "76502c091a5069f5"]

from _lib import (BG, TIP, _clip_box, blob_moves, click_panel, draw_rows,
                  in_box, landing_in_deco, moved_box, refused, tips, will_levelup)


def _plan(prev, action):
    """[(尖原来在哪, 尖走到哪或 None, 这根条裁到画得出来那一块的新 bbox)]；一根带尖的都没有返回 None。

    第二项为 None = 尖按位移走到了画面外：那一格没有像素，对不了答案；
    但尖**原来**那一格还在盘上，照常认领、照常检验。
    """
    cp = click_panel(prev, action)
    if cp is None:
        return None
    color = cp[0]
    if will_levelup(prev, action) is True:     # 换关那一步整盘重画，尖挪到哪在那一帧上看不见
        return None
    mv = blob_moves(prev, action)
    if mv is None:
        return None
    tp = tips(prev)
    if tp is None:
        return None
    if refused(prev, action) is not False:
        return None
    if landing_in_deco(prev, action) is not False:
        return None
    rmax = draw_rows(prev)
    ncol = len(prev[0])
    out = []
    for box, side, d in mv:
        nb = _clip_box(moved_box(box, side, d), rmax)
        if nb is None:
            return None
        t = tp.get((color, tuple(box)))
        if t is None:
            continue
        nt = (t[0] + d[0], t[1] + d[1])
        if not (0 <= nt[0] <= rmax and 0 <= nt[1] < ncol):
            nt = None                      # 尖落到画面外：只让出这一格，不让出旧那一格
        out.append((t, nt, nb))
    if not out:
        return None
    return color, out



def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    color, plan = p
    got = tips(nxt)
    if got is None:
        return "NA"
    have = set(got.values())
    for t, nt, nb in plan:
        if nt is not None and nt not in have:
            return "FALSE"
        want_old = color if in_box(nb, t) else BG
        if nxt[t[0]][t[1]] != want_old:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return None                        # SCOPE 里换关就返回 NA，生成器要守同一个 scope
    p = _plan(prev, action)
    if p is None:
        return None
    color, plan = p
    out = {}
    for t, nt, nb in plan:
        out[t] = color if in_box(nb, t) else BG
        if nt is not None:
            out[nt] = TIP
    return out or None
