"""色 2 面板（连同里面的图标与分隔线）在任何一步里都一格不变。"""
LEVEL = "L0"
SCOPE = "看这一帧上认出来的所有面板 bbox；一块也认不出来返回 NA；换关返回 NA。任何动作都查。"
NOTE = "v2：不再看写死的两块 bbox，改成每帧现认（_lib.panel_boxes）。"
EVIDENCE = ["218a829f43e66580"]

from _lib import panel_boxes


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    boxes = panel_boxes(prev)
    if not boxes:
        return "NA"
    for t, bo, l, r in boxes:
        for rr in range(t, bo + 1):
            for cc in range(l, r + 1):
                if prev[rr][cc] != nxt[rr][cc]:
                    return "FALSE"
    return "TRUE"
