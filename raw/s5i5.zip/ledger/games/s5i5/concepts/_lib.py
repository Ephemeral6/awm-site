"""这一局的词汇表 —— 每个定义都是假设，不是装置给的事实。

实测（第 1–15 步，第 0 关打通）：动作只有 ACTION6 带坐标，`ACTION6:x,y` 里 **x 是列、y 是行**。

世界的骨架（第 0 关量出来、第 1 关按同一套读）：
  * **面板**：色 2 画的矩形边框，内部色 4 填充，正中一条色 3 的分隔线（竖的或横的），
    分隔线两侧各一个 3x3 的「括号」图标，图标是同一种颜色 K —— K 就是这块面板管的**节**的颜色。
  * **节**（segment）：颜色 K 在所有面板之外的那些格子，是一根 3 格宽的长条；
    一端贴着一段色 3 的「帽」（不动的那头），另一端是**自由端**。
  * 分隔线**前面**那个图标（左边 / 上边）= 自由端朝帽缩 3 格；**后面**那个（右边 / 下边）= 自由端离帽伸 3 格。
  * **尖**：某节内部的一个色 13 格，永远在自由端往里 1 格。
  * **菱形**：四个色 13 的点围出的十字，中心是目标位；尖压上去时中心那格自己变成 13，四个点不变色。
  * 第 63 行是计数条：色 3 = 未用、色 4 = 已用，已烧格数 = round(64 × 已用步数 / 预算)。

没量出来的留 None，别猜着填。
"""
from __future__ import annotations

from geo import bbox, cells_of, components  # noqa: F401

BG = 5                 # 底色
CAP = 3                # 帽 / 分隔线 / 计数条未用格
FILL = 4               # 面板内部填充 / 计数条已用格
BORDER = 2             # 面板边框
TIP = 13               # 尖 + 菱形四点
USED = 4
COUNTER_ROW = 63
COUNTER_CELLS = 64
BUDGET = 50            # 第 0 关实测：预算 50 步（13 步的烧格序列唯一钉死 64/预算∈[1.2778,1.2917)）
# 第 0 关的 50 是**唯一解**（budget2.py 交出 1 个候选）。
# **第 1 关的 150 不是**：同一个拟合交出 [149, 150] 两个候选，这里挑了一个。
# 挑得起是因为它至今不可观测——budcheck.py 把 149 塞进去重跑全量语料，
# counter_step_rate 与 move_counter_row63 逐条判得和 150 完全一样（各 88 条，一条不差）。
# 两者第一次分岔在本关第 41 步，而语料里第 1 关最远只走到第 26 步。
# **欠的账**：真走到第 41 步时，这里必须先重跑 budget2.py 把它钉死；
# 在那之前谁都不许拿这个数当实测值引用，尤其不许拿它去论证「还剩几步」。
# 第 2 关**已经钉死**：2026-09-07 第 150 步走到本关第 36 步，那正是 200 与 201 第一次分岔的地方
# （burnpred.py 事先打出「B=200→12 / B=201→11」），实测读到 12，budget2.py 随后交出唯一解 200。
# 这笔欠账是这么还的：不是等它自己变清楚，而是**拿候选的分岔点当靶子挑了一批动作**。
# 第 3 关**已经钉死**：2026-09-07 第 350 步，本关第 15 步与第 18 步分别打掉 102 与 101，唯一解 100
# （budgetfit2.py，本关两段共 66 个 prev+next 读数）。还账的方式和第 2 关同一套：靶子事先写在注释里。
BUDGET_BY_LEVEL = {0: 50, 1: 150, 2: 200, 3: 100, 4: 150, 6: 200, 7: 200}
# ---- 候选表：拟合交出几个整数就写几个，一个都不挑 ----
# 上面那张表只收**唯一解**（第 0、2 关）或**挑了一个并公示了欠账**（第 1 关）。
# 这张表存候选集合，配一个「全体候选同意才给答案，有分歧就返回 None」的取数口：
# 概念只在候选无分歧处开口，在分歧处照旧闭嘴。这样常数不确定的代价被收窄到它真正影响的那一片，
# 而不是整关放弃断言——第 2 关钉死之前，正是靠这个取数口让 counter_step_rate 在本关开的口
# （N 38→84）。**这两件事不是一回事**：候选虽然不唯一，但在很多问题上几个候选给出同一个答案，
# 那种地方的断言是无条件成立的，闭嘴纯属浪费可判错性。
# （对应方法册「拟合交出区间、册子里写单值，那个单值是硬币」列出的三种合法写法里的第二种。）
# **第 1 关的 150 仍是硬币**：[149, 150] 两个候选，两者第一次分岔在本关第 41 步，
# 而语料里第 1 关最远只走到第 26 步；budcheck.py 把 149 塞进去重跑全量语料，逐条判得完全一样。
# 真走到第 41 步之前，谁都不许拿这个数当实测值引用，尤其不许拿它去论证「还剩几步」。
BUDGET_CANDIDATES = {0: [50], 1: [149, 150], 2: [200], 3: [100],
                     4: [150], 5: [149, 150], 6: [200], 7: [200]}
# **第 4~7 关：2026-09-08，runs/<run>/budgetfit4.py**，一次把剩下几关都夹了。
# 唯一解：第 4 关 150、第 6 关 200、第 7 关 200（关内分别走到 n=50 / 48 / 40，各 51 / 49 / 41 个读数）。
# 第 5 关是**和第 1 关一模一样的那枚硬币** [149, 150]：两个候选第一次分岔仍在关内第 41 步
# （149 烧 18 格、150 烧 17 格），而本关最远只走到 n=29。所以第 5 关不进上面那张单值表。
# 「预算按关递增」这条外推第二次被打掉：第 4 关 150 比第 3 关 100 大，但第 5 关又不比第 4 关大。
# 这一批拟合还暴露了分段判据的一个洞，改法记在 budgetfit4.py 里，教训进了 METHOD.proposals：
#   原来的分段只查「这一条的 prev 比上一条的 next 少」，抓不住**在一条转移里头归零**的 RESET
#   （prev 烧 4 格、next 烧 0 格）。那一条的 next 于是被当成关内第 n+1 步的读数，
#   要求「走了 11 步烧 0 格」，任何 B 都不相容 —— 第 5 关头一次跑出来的空集就是这么来的。
#   **空集连着出现第二次，仍然是编号错，不是模型错**；两次的编号错还不是同一个。
BUDGET_UNIT_COLORS = (CAP, USED)
# 计费条那一行只有两种颜色，永远是「一段满 + 一段空」，边界那一格没有中间色
# （2026-09-08，runs/<run>/row63colors.py：全量 1710 帧 × 64 格，只出现过这两个色；
#  段序列 1633 帧是 (满,空)、77 帧是 (满,) 一色到底，没有第三种）。
# 这不是细节，是一条**观测极限**：预算 ≥ 64 时一步烧 0 格或 1 格，同一个烧格数对应好几个关内步数，
# 而这一行又不提供任何更细的刻度 —— 于是「下一帧的计费条」**不是当前帧的函数**，
# 只有走过这一关的人自己数着才知道。除第 0 关（预算 50 < 64）外每一关都如此。
# 所以 move_counter_row63 在别的关整关闭嘴不是它写得保守，是这一行真的问不出来；
# 要补这个洞得让策略自己记步数，不能指望从帧上读回来。
# **第 3 关：[100, 101, 102]**（2026-09-07，runs/<run>/budgetfit.py，本关 8 条转移的 prev+next 共 16 个读数）。
# 这一关的预算**比第 2 关小**，所以「50/150/200 递增」那条外推是错的，它当场就被第一步的烧格数打了
# （见 every_blob_moves_on_its_own_axis 的 NOTE）。不唯一，所以上面那张表不收它。
# 拟合第一次跑出来是**空集**，而空集是真读数、不是「拟合失败」：查出来的原因是**关卡边界对错了位**。
#   换关那一步（第 193 步，level_prev=2 → level=3）的 prev 帧仍带着上一关的余额（烧 26 格），
#   把它当成本关第 0 步就等于拿上一关的读数去约束这一关的预算，任何 B 都不相容。
#   剔掉的判据是 meta 里的 `level_prev == level`——上游给的事实，不是从像素猜的。
#   **教训（已进 METHOD.proposals）：拟合交出空集时，先怀疑自己给它的编号，再怀疑模型。**
# 同一批读数还把「被拒的一步不占预算」又证伪了一次，而且这次是机械证伪的：
#   按「不算拒绝步」重编号后，prev+next 一起夹交出**空集**；按「算上拒绝步」交出 [100,101,102]。
#   （第 1 关那次证伪见上面的注释，同一结论；`same_off_counter` 的 docstring 也早写着「被拒照样占一步」。
#    这里不是新发现，是第三次独立确认——记下来是因为它是**这一关**的读数在说话。）
# **这笔账已经还了（2026-09-07，第 350 步，runs/<run>/budgetfit2.py）：唯一解 B=100。**
#   靶子是事先写在这里的：三个候选在本关第 15 步第一次分岔（B=100/101 → 烧 10 格，B=102 → 烧 9 格）。
#   路线往下走到本关第 15 步，**实测烧 10 格，102 当场出局**；第 18 步实测 12 格而 101 算 11 格，101 出局。
#   两个分岔点都是预告过的，没有事后挑判据。剩下 [100]，两段共 66 个 prev+next 读数无一不相容。
# **而它先交出的是空集，这一段值得单记**：同一个拟合在第 350 步重跑，两种口径都返回空集。
#   注释上一行早写着「拟合交出空集时，先怀疑自己给它的编号」——这一次真是编号：
#   budgetfit.py 拿 `n = 步号 − 本关最小步号` 编号，而本关中途 `act RESET` 重开过一次，
#   计费条归零而上游给的 `level` 一直是 3。于是第 326 步那个「烧 0 格」的帧被编成关内第 132 步，
#   任何 B 都不相容。**关卡边界不等于计费条边界**：前者读 meta，后者只能读计费条自己。
#   改法是不信步号信读数——烧格数比上一条的 next 少就是新开一段，段边界由读数机械划出（budgetfit2.py）。
#   budgetfit.py 原样留着不改，那个空集是真读数。
# 每关一个常数。第 0 关 50（13 步序列钉死）。第 1 关拿本关 26 步的烧格序列机械拟合
# （runs/<run>/budget.py，Fraction 精确算，b=round(64n/预算)）：
#   下界 148.211 < 预算   来自 本关第22步烧 9 格
#   上界 预算 <= 150.588  来自 本关第20步烧 9 格
# 整数解只剩 {149, 150}，取 150。**还没唯一钉死**，149 也对得上这 26 步。
# 同一段拟合还证伪了「被拒的点击不占预算」：把被拒那一步剔出编号后区间为空（147.7 < 预算 <= 143.1）。
# 所以本关步号 n = 装置的本关步号，撞墙那一步照样花钱，帧不变只是没跨整数。
# 没量出来的关不许猜，查不到就返回 NA。
GROW = 3               # 一次生效，自由端沿长轴走 3 格
SEG_W = 3              # 节的短边

_AWAY = {"left": (0, 1), "right": (0, -1), "top": (1, 0), "bottom": (-1, 0)}


def click(g, action):
    """把动作串解析成 (行, 列)；不是带坐标的 ACTION6 就返回 None。"""
    if not action.upper().startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except Exception:
        return None
    return (y, x)


def _center(cells):
    """图标的中心 = bbox 的中心，不是重心：「括号」是空心的，重心会被拉偏一格。"""
    t, bo, l, r = bbox(cells)
    return ((t + bo) // 2, (l + r) // 2)


_PANEL_CACHE = {}
_FRAME_CACHE = {}


def _memo(g, key, make):
    """一帧一份的备忘。**语义一个字不改**，纯粹为了让规划器搜得动。

    键必须按**帧的内容**取，不能按帧对象的身份（`id`）取。我先写成 id 版的，
    图的是省掉那一遍全盘扫描——结果它当场错了，而且错得没有任何报警：
    装置的链式预测是造一个帧、然后**原地**把每一步的预测写进同一个对象
    （`g[r][c] = v`，帧对象从头到尾是同一个），于是 id 不变而内容步步在变，
    备忘就一路返回第一步的旧答案。表现不是异常，是「越往后越没有概念开口」——
    我的两套全量检验（逐格对答案、整步被拒判据）一条都没响，因为它们从 json 读新帧、从不改帧。

    所以这里付一次全盘的哈希（65 个 C 层的 tuple + 一次 hash），换的是**在原地改帧下也成立**。
    它仍然划算：被缓存的那几个函数是 Python 层的双重循环加逐格 `in_any`，
    单次成本比这个哈希高一个量级。`panels` 早就是这么写的，这里只是照同一个规矩来。
    """
    kk = hash(tuple(map(tuple, g)))
    ent = _FRAME_CACHE.get(kk)
    if ent is None:
        if len(_FRAME_CACHE) > 3000:
            _FRAME_CACHE.clear()
        ent = {}
        _FRAME_CACHE[kk] = ent
    if key not in ent:
        ent[key] = make()
    return ent[key]


def panels(g):
    """认出所有面板：[{box, color, icons: [(行,列), (行,列)]}]，icons 按「先缩后伸」排。

    带一层按整帧内容做键的缓存：纯函数，只为了让规划器能反复问而不重算连通块。
    """
    key = hash(tuple(map(tuple, g)))
    hit = _PANEL_CACHE.get(key)
    if hit is not None:
        return hit
    out = _panels(g)
    if len(_PANEL_CACHE) > 4096:
        _PANEL_CACHE.clear()
    _PANEL_CACHE[key] = out
    return out


def _panels(g):
    out = []
    for comp in components(cells_of(g, BORDER)):
        if len(comp) < 12:
            continue
        t, bo, l, r = bbox(comp)
        if bo - t < 4 or r - l < 4:
            continue
        inside = [(rr, cc) for rr in range(t + 1, bo) for cc in range(l + 1, r)]
        colors = {g[rr][cc] for rr, cc in inside} - {CAP, FILL, BORDER}
        if len(colors) != 1:
            continue
        k = colors.pop()
        blobs = components([(rr, cc) for rr, cc in inside if g[rr][cc] == k])
        if len(blobs) != 2:
            continue
        out.append({"box": (t, bo, l, r), "color": k,
                    "icons": sorted(_center(b) for b in blobs)})
    return out


def panel_boxes(g):
    return [p["box"] for p in panels(g)]


def deco_boxes(g):
    """盘面下方那些「色 2 描边、里面铺着色 4」的方框的 bbox：面板是其中一种，图例是另一种。

    由来：面板认得出来（框里两团同色图标），图例认不出来（框里只有一团），
    于是图例里那一小块同色格子被 bar_cells 当成了「节的格子」，
    bar_box 把它和真正的条框在一起，capped_side 找不到唯一的帽 → button 返回 None
    → 所有靠 button 的 apply 一起闭嘴，而 refused / tips_after（锚在帽上）照常开口。
    **失明不报错**：册子对整整一关的每一个按钮都预测 0 格，没有任何东西变红。

    判据比 _panels 松一档：只要求「色 2 的连通块围出的框里有色 4」，不管里面几团图标。
    条不会被色 2 围起来，所以框里的同色格子一律不算条身。
    """
    out = []
    for comp in components(cells_of(g, BORDER)):
        t, bo, l, r = bbox(comp)
        if bo - t < 2 or r - l < 2:
            continue
        inside = [(rr, cc) for rr in range(t + 1, bo) for cc in range(l + 1, r)]
        if not any(g[rr][cc] == FILL for rr, cc in inside):
            continue
        out.append((t, bo, l, r))
    return out


def in_any(boxes, rc):
    return any(t <= rc[0] <= bo and l <= rc[1] <= r for t, bo, l, r in boxes)


def seg_colors(g):
    """盘上有哪些节颜色（= 面板图标的颜色 ∪ 图例框图标的颜色）。

    v2 加上图例色。原先只数面板：面板管伸缩、图例管转向，本来以为凡是条都两样齐全，
    直到遇上一根**只有图例没有面板**的条 —— 它转得动、伸不动，于是整根条在册子眼里不存在，
    既不进链，也不算挡路的东西。**失明不报错**：没有任何概念会因为少看见一根条而变红。
    """
    out = [p["color"] for p in panels(g)]
    for _, k in legend_boxes(g):
        if k not in out:
            out.append(k)
    return out


def bar_cells(g, color):
    """节的格子：该色在所有面板之外的全部格子。空则 None。

    不能用「最大连通块」：节走到菱形上时，菱形的四个色13点会把它从中间切开。
    """
    cs = _memo(g, ("bar_cells", color), lambda: _bar_cells(g, color))
    return list(cs) if cs else None      # 交出去的是副本：调用方改了不能污染备忘


def _bar_cells(g, color):
    boxes = panel_boxes(g) + deco_boxes(g)
    return [rc for rc in cells_of(g, color) if not in_any(boxes, rc)]


def bar_box(g, color):
    return _memo(g, ("bar_box", color), lambda: _bar_box(g, color))


def _bar_box(g, color):
    cs = bar_cells(g, color)
    return bbox(cs) if cs else None


def capped_side(g, box):
    """色 3 的帽贴在节的哪一端：'top'/'bottom'/'left'/'right'；不唯一返回 None。"""
    t, bo, l, r = box
    n, m = len(g), len(g[0])
    sides = []
    if t - 1 >= 0 and all(g[t - 1][c] == CAP for c in range(l, r + 1)):
        sides.append("top")
    if bo + 1 < n and all(g[bo + 1][c] == CAP for c in range(l, r + 1)):
        sides.append("bottom")
    if l - 1 >= 0 and all(g[rr][l - 1] == CAP for rr in range(t, bo + 1)):
        sides.append("left")
    if r + 1 < m and all(g[rr][r + 1] == CAP for rr in range(t, bo + 1)):
        sides.append("right")
    return sides[0] if len(sides) == 1 else None


def color_blobs(g, color):
    """这个节色在面板外的格子按 4 邻接分团，每团一个 bbox，按左上角排序；一格都没有返回 None。

    分团时把**全部**色 13 格（菱形四点 + 各节自己的尖）都当成可通行的格子：
    节压到菱形上时那四个色 13 点会把节从中间切开（bar_cells 的 docstring 记着这件事），
    团内自己的尖同理。第一版把菱形四点从标记里剔掉了，那恰好剔掉了真正会切断节的那四格——
    第 2 关第 83 步 c9bf233145fe4d48 一根色 14 的尖压上菱形中心，实测被切成三团，
    every_blob_moves_on_its_own_axis 当场判 FALSE 关闸。

    **为什么要有它**：bar_cells 只说「这个颜色在面板外的全部格子」，而 bar_box / capped_side
    都当那是一团。第 0~2 关每个节色恰好只有一团，这条假设一路成立，又因为它住在词汇里从没被单独打分；
    第 3 关色 11 在盘上有五团，bar_box 变成五团的并集 (12,43,10,52)、capped_side 不唯一、
    button 当场返回 None，整册对那两个按钮失语。所以「一色一节」不是几何事实，是那三关的巧合。
    这个函数只做几何，不断言世界会拿这些团做什么——那件事由概念走闸。

    **已知的粗糙处**：可通行的色 13 格不分归属，所以两团同色若各自贴上同一个菱形，
    会被那个菱形粘成一团。语料里没出现过这种构型，是留白不是结论。
    """
    cs = bar_cells(g, color)
    if not cs:
        return None
    marks = set(cells_of(g, TIP))
    out = []
    for comp in components(list(set(cs) | marks)):
        own = [rc for rc in comp if g[rc[0]][rc[1]] == color]
        if own:
            out.append(bbox(own))
    return sorted(out) if out else None


# box 元组下标：0=t, 1=bo, 2=l, 3=r。裁自由端时用来找「对面那条边是帽边」。
_OPPOSITE_EDGE = {0: 1, 1: 0, 2: 3, 3: 2}


def _clip_by_tip(g, box, free_edge_idx, direction, dots):
    """box 内有几个「属于节」的色 13 格，按 tip_at_open_end 的主张裁自由端。

    free_edge_idx 指出 box 元组里哪个下标是（裁剪前）自由端那条边；
    direction 是从帽边指向自由端的方向（+1 / -1），沿 free_edge_idx 所在的那根轴。
    """
    t, bo, l, r = box
    tip_cells = [(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)
                 if g[rr][cc] == TIP and (rr, cc) not in dots]
    axis_is_row = free_edge_idx in (0, 1)
    coords = [rr if axis_is_row else cc for rr, cc in tip_cells]
    if not coords:
        return box                     # 没长尖的短节：照 tip_at_open_end 的 SCOPE 跳过，不裁
    if len(coords) == 1:
        chosen = coords[0]
    else:
        cap_coord = box[_OPPOSITE_EDGE[free_edge_idx]]
        chosen = min(coords, key=lambda x: (x - cap_coord) * direction)
    out = list(box)
    out[free_edge_idx] = chosen + direction
    t2, bo2, l2, r2 = out
    if t2 > bo2 or l2 > r2:
        return box                     # 裁穿了：不该发生，退回不裁的版本
    return (t2, bo2, l2, r2)


def _cap_cells(g):
    """这一帧上所有的帽格（面板外、不在计费条那一行的色 CAP 格），一帧一份。

    **语义一个字不改**：判据和原来 `_bar_units` 里的 `is_cap` 逐字相同。
    搬出来只为两件事：一是它和节色无关，原先每个节色都把全盘重问一遍；
    二是逐格调一个 Python 闭包换成一次带 `enumerate` 的行扫描。
    """
    boxes = panel_boxes(g)
    n = len(g)
    m = len(g[0]) if n else 0
    out = set()
    for r in range(n):
        if r == COUNTER_ROW:
            continue
        for c, v in enumerate(g[r]):
            if c >= m:
                break
            if v == CAP and not in_any(boxes, (r, c)):
                out.add((r, c))
    return frozenset(out)


def bar_units(g, color):
    """`_bar_units` 的一帧一份备忘。**语义一个字不改**，纯粹为了让它跑得完 settle 的预算。

    由来：它是 Python 层的双重全盘循环加逐格 `in_any`，而 footprints_after 对**每一色**都调它一次，
    每条概念对每一条转移又调 footprints_after 若干次。换成按条口径之后，`bar_free_end_moves` 与
    `wall_sticks_to_free_end` 双双「断言太慢，超过 20s 预算，已中止结算」，闸因此关着——
    **那不是判它们错，是它们跑不完**，而跑不完和被推翻在账面上长得不一样，得分开处理。
    """
    u = _memo(g, ("bar_units", color), lambda: _bar_units(g, color))
    return [tuple(x) for x in u] if u else None


def _bar_units(g, color):
    """这个节色在面板外的**每一根条**：[(bbox, 帽在哪一侧, 帽格坐标表), …]；一根都读不出返回 None。

    一根条 = 以它自己那排帽（色 3、宽 SEG_W、贴在条的一端外侧）为锚，从帽往外沿长轴延伸的最长矩形，
    矩形每一格都属于「该色可通行格」= bar_cells(g, color) ∪ 全部色 13 格（口径抄 color_blobs，
    理由同：节自己的尖和菱形四点会把一根条从中间切开，通行判定要把它们当透明）。
    `side` 与帽格表的格式和 capped_side / blob_cap 一致，好让下游直接换过来。

    **为什么不用 color_blobs**：连通块把「贴在一起的两根同色条」读成一团。世界那边什么都没变
    （两根照旧各长各的 3 格，没有拒绝、没有异常），变的只有读法的分辨率；而代价是一串失语——
    capped_side 认不出唯一的帽 → blob_moves 返回 None → 依赖它的主张闭嘴 → 连**别色**的
    push_target 也归不到唯一一团，于是不相干的概念一起闭嘴。**失明不报错，它报 NA。**
    第 196 步 86f7ada89eb10459 上 every_blob_moves_on_its_own_axis 就是这么判 FALSE 的：
    像素一格没错，连通块的数目错了。所以部件的身份不该由它此刻的形状决定，要锚在不变的东西上——
    每根条自己那排帽：宽度固定、位置唯一、两根贴不贴在一起都还在。

    **裁自由端那一步的判据是从册子里借的，不是这里新发明的**：tip_at_open_end 的主张是
    「尖永远停在离没帽那一端 1 格」。两根同色条呈直角相交时，被穿过的那根在它的生长方向上
    看到的仍是「可通行格」（那是另一根同色条的身体），于是会一路长过交叉口、钻进别人的地界；
    用尖把自由端钉回来，交叉口就归穿过去的那一根。对普通条这一裁是空操作（它的最长矩形本就
    停在正确的自由端上），回归判据验证的正是这件事。

    **实测（runs/<run>/bar_units_check.py，去重语料 155 条转移 / (tid,色) 组合 808 条）**：
      · 回归：未粘连情形下与 color_blobs 可比较 588 条，一致 588 / 不一致 0；
      · 粘连情形（color_blobs 某个 bbox 短边 ≠ SEG_W）220 条，正是它失语的那一片；
      · 不多读：格子越界 0 次、bbox 重复 0 次、两根条互相重叠 0 次。
    **↑「两根条互相重叠 0 次」这一条后来被推翻了，原文留着不改，因为它是这个函数当时真实的读数。**
    推翻它的是同色两根条**呈直角相交**的构型：横着那根从帽往外走，走过自己的自由端之后
    看到的仍是「该色可通行格」（那是竖着那根的身体），于是长过交叉口，框吞掉竖那根的三列。
    上面那 155 条语料里没有这种构型，所以那个 0 不是错的，是**没被考到**。
    现在的止损在 `bar_units_all`：发现同色两框重叠就整张返回 None。
    这里不改，因为该在哪一层闭嘴是调用方的事，而「这个函数会多吞」是它自己的实情，得写明。
    **裁剪三个分支的命中次数（840 次里）：无尖不裁 565、恰好一个尖裁一次 275、两个及以上尖裁到最近 0。**
    最后那一支**在这批语料上一次都没走到**——它不是「验过了」，是「没检验过」。撞上第三根条穿过
    交叉口的构型时，它是第一个该被怀疑的地方。
    **↑ 这一句押中了。** 真出事的时候就是交叉口，而且「该被怀疑的地方」写在这里的代价是零——
    它没能拦住任何事，因为它只是一句提醒，不是判据。要拦住，得是 `bar_units_all` 里那四行
    重叠检查那样**装置能自己核**的东西。散文写得再准也拦不住自己。

    **已知的粗糙处**（都是没在语料里见过的构型，留白不是结论）：
      · 一顶帽子两侧都贴着该色可通行格 → 跳过这顶帽子，不猜；若某根条只有这顶帽子能锚它，
        那根条会从结果里消失（而不是整色返回 None）。
        **↑ 这一条后来真的发生了，而且上面这个处置是错的，现在已改成整色返回 None。原文留着不改。**
        构型：一根同色横条长到正好停在某根竖条那顶帽子的**正下方**，于是帽的上下两侧都贴着
        该色可通行格，`top_ok == bottom_ok == True`，帽被跳过；竖条只有这一顶帽子，整根消失，
        而 `bar_units_all` 照旧返回一个列表（不是 None）—— **少一整根条，册子还在开口说话**。
        后果是 `every_blob_moves_on_its_own_axis` 连判两条 FALSE：它主张「每一团都各自动一次」，
        而清单里少了一团，那一团动的格子它主张不该变。
        **这一次和上一次（交叉口、框重叠）在构造上不是同一个洞**：交叉口丢的是边界，
        留下两个重叠的框，`bar_units_all` 的重叠检查抓得住；这一次丢的是整根条，
        **不留下任何重叠的框，重叠检查在构造上就抓不到**。所以止损只能落在这里。
        改动前影子记分（`runs/<run>/shadowcap.py`，全去重语料 204 条，判据跑之前写好）：
        反例帧上现行 4 根 → 影子 None；apply 说错 0→0 格；新增 FALSE 0 条；
        丢判据的转移 2 条（就是那两条反例自己，各丢 4 条判据）；少认领 444 格。
        覆盖面（只报数）：全语料里存在这种「两侧都贴」隐藏帽的转移 3/204，
        因此丢了条的帧 5，`(tid, 色)` 组合 3 —— **这个构型是我自己的路线造出来的，语料没考过它。**
        · **这两条留白教的同一件事**：一个函数已知会在某构型下给出**不完整**的答案时，
        「返回不完整」和「返回 None」不是风格之争。不完整会被下游当完整用，
        错误于是从失语变成自信地说错，而失语记 NA、说错不记——除非恰好有概念在问同一件事。
        写留白的时候要顺手问一句：这个粗糙处是「我不知道」还是「我知道会漏」。后者一律闭嘴。
      · 某根条真的两端都有帽（不符合「一端帽一端自由」这条前提）→ 从两端各锚一次会长出同一个矩形，
        side 由后写入的那次覆盖，这个函数不断言那种构型下「帽在哪端」有唯一答案。
    """
    own_list = bar_cells(g, color)
    if not own_list:
        return None
    own = set(own_list)
    passable = own | set(cells_of(g, TIP))
    dots = diamond_dots(g)
    n = len(g)
    m = len(g[0]) if n else 0

    capset = _memo(g, "cap_cells", lambda: _cap_cells(g))

    def band_ok(cells):
        return all(0 <= r < n and 0 <= c < m and (r, c) in passable for r, c in cells)

    def band_has_own(cells):
        return any(rc in own for rc in cells)

    def own_in_box(box):
        t, bo, l, r = box
        return band_has_own([(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)])

    found = {}

    # ---- 竖着的一段帽（同一列、连续 SEG_W 行）→ 锚出一根横着长的条 ----
    # 帽格在哪和节色无关，所以整帧的帽格表 `_cap_cells` 一帧只扫一遍、全色共用；
    # 这里只在**帽格**上找连续 SEG_W 段，不再逐格问 is_cap。
    # 枚举顺序照旧（竖段按行优先、横段按列优先），因为 `found` 是字典、
    # 「两侧都贴」那一支会当场 return None ——顺序变了结果就可能变。
    for r, c in sorted(rc for rc in capset
                       if rc[0] <= n - SEG_W
                       and all((rc[0] + i, rc[1]) in capset for i in range(1, SEG_W))):
        cap_cells = [(r + i, c) for i in range(SEG_W)]
        left_band = [(r + i, c - 1) for i in range(SEG_W)]
        right_band = [(r + i, c + 1) for i in range(SEG_W)]
        left_ok = c - 1 >= 0 and band_ok(left_band) and band_has_own(left_band)
        right_ok = c + 1 < m and band_ok(right_band) and band_has_own(right_band)
        if left_ok and right_ok:
            return None            # 两侧都贴：这顶帽子锚哪一根读不准，整色闭嘴（见 docstring）
        if left_ok == right_ok:
            continue               # 两侧都不贴：这顶帽子不是这一色的，跳过
        if left_ok:
            side = "right"         # 帽在条右边（capped_side 的口径）
            lo = c - 1
            while lo - 1 >= 0 and band_ok([(r + i, lo - 1) for i in range(SEG_W)]):
                lo -= 1
            box = _clip_by_tip(g, (r, r + SEG_W - 1, lo, c - 1), 2, -1, dots)
        else:
            side = "left"
            hi = c + 1
            while hi + 1 < m and band_ok([(r + i, hi + 1) for i in range(SEG_W)]):
                hi += 1
            box = _clip_by_tip(g, (r, r + SEG_W - 1, c + 1, hi), 3, 1, dots)
        if own_in_box(box):
            found[box] = (side, sorted(cap_cells))

    # ---- 横着的一段帽（同一行、连续 SEG_W 列）→ 锚出一根竖着长的条 ----
    for r, c in sorted((rc for rc in capset
                        if rc[1] <= m - SEG_W
                        and all((rc[0], rc[1] + i) in capset for i in range(1, SEG_W))),
                       key=lambda rc: (rc[1], rc[0])):     # 列优先：照抄原来的枚举顺序
        cap_cells = [(r, c + i) for i in range(SEG_W)]
        top_band = [(r - 1, c + i) for i in range(SEG_W)]
        bottom_band = [(r + 1, c + i) for i in range(SEG_W)]
        top_ok = r - 1 >= 0 and band_ok(top_band) and band_has_own(top_band)
        bottom_ok = r + 1 < n and band_ok(bottom_band) and band_has_own(bottom_band)
        if top_ok and bottom_ok:
            return None            # 两侧都贴：这顶帽子锚哪一根读不准，整色闭嘴（见 docstring）
        if top_ok == bottom_ok:
            continue               # 两侧都不贴：这顶帽子不是这一色的，跳过
        if top_ok:
            side = "bottom"        # 帽在条下边
            lo = r - 1
            while lo - 1 >= 0 and band_ok([(lo - 1, c + i) for i in range(SEG_W)]):
                lo -= 1
            box = _clip_by_tip(g, (lo, r - 1, c, c + SEG_W - 1), 0, -1, dots)
        else:
            side = "top"
            hi = r + 1
            while hi + 1 < n and band_ok([(hi + 1, c + i) for i in range(SEG_W)]):
                hi += 1
            box = _clip_by_tip(g, (r + 1, hi, c, c + SEG_W - 1), 1, 1, dots)
        if own_in_box(box):
            found[box] = (side, sorted(cap_cells))

    if not found:
        return None
    # 帽格返回**元组**而不是列表：这个函数的结果进了一帧一份的备忘，几个调用方共享同一份，
    # 返回可变对象等于把缓存的内容交给调用方去改，而那种错不会报警。
    return [(box, side, tuple(caps)) for box, (side, caps) in sorted(found.items())]


def click_panel(g, action):
    """点中了哪个面板的哪个图标：返回 (面板色, sign)，sign = -1 缩 / +1 伸；没点中返回 None。

    button() 要的也是这两个数，但它紧接着要 bar_box + capped_side，一色多团时当场返回 None。
    这里把「点中了谁」和「那一色在盘上摆成什么形状」拆开，好让按团的主张也能开口。
    """
    pos = click(g, action)
    if pos is None:
        return None
    for p in panels(g):
        if pos in p["icons"]:
            return p["color"], (-1 if p["icons"].index(pos) == 0 else 1)
    return None


def blob_moves(g, action):
    """点这个按钮时，该色**每一根条**各自的 (原 bbox, 帽在哪一侧, 自由端位移)；算不出来返回 None。

    有任何一根条认不出帽、或位移把 bbox 变非法（缩过头），**整体**返回 None —— 不猜，也不只报能算的那几根。

    **口径换过一次**：原来用 color_blobs + capped_side（按 4 邻接分团，再替每团找帽），
    现在用 bar_units（按帽锚定）。换的理由写在 bar_units 的 docstring 里，一句话是：
    两根同色条贴在一起时连通块把它们读成一团，capped_side 于是认不出唯一的帽、这里返回 None，
    整册对那个按钮失语——而世界那边什么都没发生。名字里的「团」保留没改，因为它已经被一堆
    概念引用着；**读的其实是「条」**，两者只在贴一起时才不同。
    """
    cp = click_panel(g, action)
    if cp is None:
        return None
    color, sign = cp
    units = bar_units(g, color)
    if not units:
        return None
    out = []
    for box, side, _caps in units:
        ar, ac = _AWAY[side]
        d = (ar * GROW * sign, ac * GROW * sign)
        nb = moved_box(box, side, d)
        if nb is None or nb[0] > nb[1] or nb[2] > nb[3]:
            return None
        out.append((box, side, d))
    return out


def blob_boxes_after(g, action):
    """点这个按钮之后该色每一团的 bbox，按左上角排序；算不出来返回 None。"""
    mv = blob_moves(g, action)
    if mv is None:
        return None
    return sorted(moved_box(box, side, d) for box, side, d in mv)


def blob_cap(g, box):
    """这一团的帽格：贴在有帽那一端外侧的那一排（坐标表）；认不出帽返回 None。

    和 cap_block 的区别只在入口：cap_block 按**颜色**取（走 bar_box，一色多团时返回 None），
    这个按**团的 bbox** 取。几何算法逐字相同——所以 _cap_block 现在直接调它，
    别让同一段坐标算术存两份。
    """
    side = capped_side(g, box)
    if side is None:
        return None
    t, bo, l, r = box
    if side == "top":
        return [(t - 1, c) for c in range(l, r + 1)]
    if side == "bottom":
        return [(bo + 1, c) for c in range(l, r + 1)]
    if side == "left":
        return [(rr, l - 1) for rr in range(t, bo + 1)]
    return [(rr, r + 1) for rr in range(t, bo + 1)]


def landing_hits(g, action):
    """点这个按钮时，被点那色每一团**新占的**格子里压着什么：[(团 bbox, 位移, {格: 色})]。

    只报读数：新占格里凡是不是底色、不是本色、不是菱形四点的，连同它现在的颜色列出来。
    压着东西之后世界会怎么办（整步拒绝 / 被压的东西让开 / 压过去），是概念的事——这里一个字不断言。
    算不出来（blob_moves 为 None）返回 None。

    **落到盘外的那些格一律跳过**：条能长到盘外去，世界照做，只把露在盘上的一截画出来
    （实测：连长十二次，最后五次自由端已越过最后一行，每一次照走不误）。
    盘外没有格子，也就没有「压着什么」可言。原先这里直接 g[r][c]，自由端一出界就 IndexError，
    而抛异常的概念**没进结算**——世界头一回做没见过的事，四条概念同时闭嘴，
    正是最该开口的那一帧。

    **和 every_blob_moves_on_its_own_axis 里那个 _landing_clear 有一处故意的差别**：
    那里放过了 `v == TIP`，这里不放（菱形四点已另用 diamond_dots 排掉，剩下的色 13 格
    是某个节自己的尖）。落点压住**别的节的尖**是「压住了那个节」，不是「路上什么都没有」；
    那个豁免在语料里至今没被兑现过（第 3 关盘上只有一个尖，且它在被点那团自己身上），
    所以两种写法目前给出同样的答案。差别记在这里，等哪一步把它们分开。
    """
    mv = blob_moves(g, action)
    cp = click_panel(g, action)
    if mv is None or cp is None:
        return None
    color = cp[0]
    dots = diamond_dots(g)
    out = []
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        t, bo, l, r = box
        old = {(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)}
        new = {(rr, cc) for rr in range(nb[0], nb[1] + 1) for cc in range(nb[2], nb[3] + 1)}
        hits = {}
        for rc in sorted(new - old):
            if not (0 <= rc[0] < len(g) and 0 <= rc[1] < len(g[0])):
                continue
            v = g[rc[0]][rc[1]]
            if rc in dots or v == BG or v == color:
                continue
            hits[rc] = v
        out.append((box, d, hits))
    return out


def push_target(g, action):
    """点这个按钮时谁挡在路上：(被点色, 被点团 bbox, 位移, 被挡色, 被挡团 bbox, 被挡团帽格)。

    纯几何归属：把「被点那色恰好一团的落点上压着的格子」归到别的某一节的某一团上去。
    归不到唯一一团（没有团压着东西、两团都压着、压到两种节色、压到死物、
    压住的本色格分不清属于哪一团、压住的格子里有既非那节本色又非帽色的东西、
    被挡那团平移后越出盘面）一律返回 None。

    **它一个字都不断言世界会怎么办**——顶走、拒绝、还是压过去，由概念走闸：
    [blocking_seg_is_pushed] 说让得开时两团一起动，[push_chain_blocked_refuses] 说让不开时整步无事。
    位移取被点那团的自由端位移，「被挡那团沿同一个位移平移」是那两条概念的断言，不是这里的。

    **实测：全去重语料 149 条里它在 43 条上返回非 None**（第 1、2、3 关都有）。
    第一版 docstring 里写的是「12 条」，那是个假读数——我拿早先那份私有 `_push_plan`
    数出来的数直接抄了过来，没在这个写法上重数一遍。43 与 12 的差不是措辞问题：
    它意味着「一节挡住另一节」不是第 3 关才出现的新机构，而是**从第 1 关起就一直在跑**、
    册子直到现在才有词说它的那一片。数字对不上就停下重数，别让抄来的读数替新代码作证。
    """
    lh = landing_hits(g, action)
    cp = click_panel(g, action)
    if lh is None or cp is None:
        return None
    color = cp[0]
    pressing = [(box, d, hits) for box, d, hits in lh if hits]
    if len(pressing) != 1:
        return None
    box, d, hits = pressing[0]
    segs = set(seg_colors(g))
    other = {v for v in hits.values() if v in segs and v != color}
    if len(other) != 1:
        return None
    oc = other.pop()
    if any(v != oc and v != CAP for v in hits.values()):
        return None
    obs = bar_units(g, oc)
    if not obs:
        return None
    owners = []
    for ob, _oside, ocap in obs:
        cs = set(ocap)
        t, bo, l, r = ob
        if all((t <= rc[0] <= bo and l <= rc[1] <= r) if v == oc else (rc in cs)
               for rc, v in hits.items()):
            owners.append((ob, ocap))
    if len(owners) != 1:
        return None
    ob, ocap = owners[0]
    n = len(g)
    for rc in set(cells_in(ob)) | set(ocap):
        rr, cc = rc[0] + d[0], rc[1] + d[1]
        if not (0 <= rr < n and 0 <= cc < len(g[rr])):
            return None
    return color, box, d, oc, ob, ocap


def cells_in(box):
    """一个 bbox 覆盖的全部格子。"""
    t, bo, l, r = box
    return [(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)]


def push_target_block(g, action):
    """被挡那一团自己让开时，它的落点上压着什么：{格: 色}；push_target 算不出来返回 None。

    空字典 = 它让得开（这一环是链的尽头）。非空 = 连环还没到底，那几格是谁。
    判别量就是这个字典空不空——**全去重语料 149 条里 push_target 命中 43 条，
    其中 11 条非空（世界整步拒绝）、32 条空（两团一起动），返回 None 的 0 条**。

    落点里只放过底色和菱形四点，**不放过同色格、也不放过帽色**：
    第一版把这两样都放过了，理由是「那是它自己的身体和帽」——可它自己的身体和帽都在 old 里，
    已经被 `- old` 减掉了，所以放过的其实是**同色的另一团**和**第三个节的帽**，
    那两样恰恰是「还没让开」。43 条上两种写法给出同样的答案，所以这一收紧至今不可观测；
    收紧的理由不是观测，是让依赖它的那条拒绝概念断言得更多（方法册「两种读法相容时选断言更多的」）。
    """
    p = push_target(g, action)
    if p is None:
        return None
    _color, _box, d, oc, ob, ocap = p
    dots = set(diamond_dots(g))
    old = set(cells_in(ob)) | set(ocap)
    out = {}
    for rc in sorted({(r + d[0], c + d[1]) for r, c in old} - old):
        v = g[rc[0]][rc[1]]
        if rc in dots or v == BG:
            continue
        out[rc] = v
    return out


def button(g, action):
    """点中了哪个图标：返回 (节色, 自由端位移 (d行, d列))；没点中返回 None。"""
    pos = click(g, action)
    if pos is None:
        return None
    for p in panels(g):
        if pos not in p["icons"]:
            continue
        sign = -1 if p["icons"].index(pos) == 0 else 1     # 先缩后伸
        box = bar_box(g, p["color"])
        if box is None:
            return None
        side = capped_side(g, box)
        if side is None:
            return None
        ar, ac = _AWAY[side]
        return p["color"], (ar * GROW * sign, ac * GROW * sign)
    return None


def moved_box(box, side, d):
    """自由端（帽的对端）按位移 d 走一步之后的 bbox；方向与长轴不符返回 None。"""
    t, bo, l, r = box
    dr, dc = d
    if side == "left" and dr == 0:
        return (t, bo, l, r + dc)
    if side == "right" and dr == 0:
        return (t, bo, l + dc, r)
    if side == "top" and dc == 0:
        return (t, bo + dr, l, r)
    if side == "bottom" and dc == 0:
        return (t + dr, bo, l, r)
    return None


def in_box(box, rc):
    t, bo, l, r = box
    return t <= rc[0] <= bo and l <= rc[1] <= r


def cap_block(g, color):
    """这一节的帽：贴在有帽那一端外侧的那一排色 3 格（坐标表）；认不出返回 None。"""
    cs = _memo(g, ("cap_block", color), lambda: _cap_block(g, color))
    return list(cs) if cs else None


def _cap_block(g, color):
    box = bar_box(g, color)
    if box is None:
        return None
    return blob_cap(g, box)


def parent_of(g, color):
    """这一节的帽贴在哪一节的身上（= 上游那一节的颜色）；贴在空处（根节）返回 None。"""
    cap = cap_block(g, color)
    if cap is None:
        return None
    ks = set(seg_colors(g))
    boxes = panel_boxes(g)
    n = len(g)
    for r, c in cap:
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            a, b = r + dr, c + dc
            if not (0 <= a < n and 0 <= b < len(g[a])):
                continue
            if in_any(boxes, (a, b)):
                continue
            v = g[a][b]
            if v != color and v in ks:
                return v
    return None


def chain(g):
    """{节色: 上游节色 or None}。根节的帽贴在空处，其余每节的帽贴在上游那一节身上。"""
    return dict(_memo(g, "chain", lambda: {k: parent_of(g, k) for k in seg_colors(g)}))


def downstream(g, color):
    """沿帽的贴附关系，被 color 拖在后面的全部后代节（不含 color 自己）。"""
    par = chain(g)
    out, frontier = [], [color]
    while frontier:
        cur = frontier.pop()
        kids = [k for k, p in par.items() if p == cur and k not in out and k != color]
        out.extend(kids)
        frontier.extend(kids)
    return out


def bar_units_all(g):
    """{节色: (每一根条, …)}；有任何一色读不出就返回 None。一帧一份备忘。

    **同色两根条的框一旦重叠，整张图返回 None（闭嘴）。** `_bar_units` 从帽往外走时，
    看到的「该色可通行格」里可能是**另一根同色条的身体**，于是一路长过交叉口、把别人的格子
    吞进自己的框。两根呈直角相交时就是这样：横着那根被报成长 14（含竖那根的三列），
    竖那根被报成长 11（这个是对的），两个框在交叉口上重叠。

    后果不是失语而是**自信地说错**：seg_overlap 拿并错的框算落点，撞上那根其实不在路上的条，
    断定「会拒」，而世界照旧动了 —— refused 至今唯一的误报就是这么来的。
    所以这里选闭嘴：`bar_chain` 已经把理由写在自己的 docstring 里——
    「分辨率不够时最贵的错法不是失语，是把说不出的地方填上一个默认值」。

    为什么不改成「裁掉多吞的那一段」：横着那根截到交叉口之前是对的，但同一条规则对称地
    套到竖那根上会把它截短，那是错的；非对称的裁剪规则没有依据可写，就不写。
    闭嘴是止损，代价是这几帧全册失语，好处是保住 0 误报。

    改之前影子记分（`runs/<run>/shadowmerge.py`，全去重语料 198 条，判据跑之前写好）：
    apply 说错 0→0 格、新增 FALSE 0 条、丢判据的转移 1 条（就是那条反例自己）、
    全语料里存在框重叠的转移 2/198。
    """
    def make():
        out = {}
        for k in seg_colors(g):
            u = bar_units(g, k)
            if u is None:
                return None
            out[k] = tuple(u)
        for units in out.values():
            for i in range(len(units)):
                for j in range(i + 1, len(units)):
                    a, b = units[i][0], units[j][0]
                    if not (a[1] < b[0] or b[1] < a[0] or a[3] < b[2] or b[3] < a[2]):
                        return None      # 两根同色条的框重叠：分不清谁的身体，不猜
        return out
    r = _memo(g, "bar_units_all", make)
    return dict(r) if r else None


def cap_faces(g, box):
    """这个框四条边上，贴着一整排色 3 的有几条：返回边名列表（'top'/'bottom'/'left'/'right'）。

    `capped_side` 只在唯一时开口，这里要的是**数目**——数目大于 1 的那种框，
    「哪一排是它自己的帽」在单帧上读不出来。
    """
    t, bo, l, r = box
    n, m = len(g), len(g[0])
    sides = []
    if t - 1 >= 0 and all(g[t - 1][c] == CAP for c in range(l, r + 1)):
        sides.append("top")
    if bo + 1 < n and all(g[bo + 1][c] == CAP for c in range(l, r + 1)):
        sides.append("bottom")
    if l - 1 >= 0 and all(g[rr][l - 1] == CAP for rr in range(t, bo + 1)):
        sides.append("left")
    if r + 1 < m and all(g[rr][r + 1] == CAP for rr in range(t, bo + 1)):
        sides.append("right")
    return sides


def bar_chain(g):
    """{(色, box): (父色, 父box) or None or "AMBIGUOUS"} —— 父子关系**按条**，不按色。

    一根条的父亲 = 它自己那排帽压在谁的身上。帽是不动的锚，所以这个问法在
    「一色好几根条」下照旧有唯一答案；算不出返回 None（整张图）。

    **为什么要有这一版**：`chain()` / `parent_of()` 按色取 `cap_block(g,k)` → `bar_box(g,k)`。
    一色多条时 `bar_box` 把互不相邻的几根条并成一个跨全盘的假 bbox，`cap_block` 在那个假条上
    找不到唯一的帽边，返回 None，于是 `parent_of` 返回 None，`chain()` 把那一色当成**根节点**。
    这不是闭嘴，是**自信地说错**：footprints_after 随后把它当静止算进落点，`seg_overlap`
    看到落点撞上一个其实会让开的身体，断定「会拒」，而世界照旧动了。
    实测这么来的假警报 13 条（全部出自 seg_overlap 这一支），外加 1 条方向相反的漏报——
    被拖动的那一节挡住了，而拖动从没被算进去，所以真被拒的那一步反被判成「不会拒」。
    分辨率不够时最贵的错法不是失语，是**把说不出的地方填上一个默认值**。

    "AMBIGUOUS"：一顶帽子同时压在两根不同的条上。单帧分不出该认哪一个，照实标出来，
    调用方自己决定闭嘴还是往下走；这一支在本局语料里出现几次由验收脚本报。

    **四面都是帽的 3x3 框当根节点**（`cap_faces` 数出 4 条边）：这种框上「哪一排是它自己的帽」
    读不出来，随手认一排就等于随手认一个父亲，而它一旦被认成孩子，父亲一动它就被算着跟着动。
    实测：一关的中枢是个 3x3、四面各接一条胳膊，它被认成了南边那条胳膊的孩子；
    南边那条一生长，落点就把中枢连同另外三条胳膊整体平移，而世界里它们一格没动
    （那一步模型预测 45 格只对 9 格）。3x3 也不是合法条长（条长恒 ≡ 2 mod 3），
    这是「它根本不是一根条」的第二个迹象。认成根节点 = 断言它不动，这条断言由概念去挨打。
    """
    def make():
        allu = bar_units_all(g)
        if allu is None:
            return None
        owner = {}
        for k, units in allu.items():
            for box, _side, _caps in units:
                for rc in cells_in(box):
                    owner[rc] = (k, tuple(box))
        # 带尖的那根条是手臂的**自由端**，谁也不许挂在它后面：`tips` 认出来的那根就是「手」。
        # 少了这一道，「谁的帽贴住谁的身体」会给手也认一个孩子，父指针首尾相接成环，
        # 「后代」在那种帧上不指向任何东西。实测这类边只在 3/730 帧出现，正好就是那 3 条成环帧；
        # 去掉之后成环帧归零，别处一根条的后代集合都没变（accept_tiproot.py H1/H2/H3）。
        # 这是一句世界事实，不是几何——所以它同时由 [tip_bar_carries_nothing] 拿帧差去挨打。
        leaves = {(kk[0], tuple(kk[1])) for kk in (tips(g) or {})}
        boxes = panel_boxes(g)
        n = len(g)
        out = {}
        for k, units in allu.items():
            for box, _side, caps in units:
                if len(cap_faces(g, box)) > 1:
                    out[(k, tuple(box))] = None      # 四面（或多面）都是帽：中枢，当根节点
                    continue
                found = set()
                for r, c in caps:
                    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        a, b = r + dr, c + dc
                        if not (0 <= a < n and 0 <= b < len(g[a])):
                            continue
                        if a == COUNTER_ROW or in_any(boxes, (a, b)):
                            continue
                        hit = owner.get((a, b))
                        if hit is not None and hit[0] != k and hit not in leaves:
                            found.add(hit)
                if len(found) > 1:
                    out[(k, tuple(box))] = "AMBIGUOUS"
                elif found:
                    out[(k, tuple(box))] = found.pop()
                else:
                    out[(k, tuple(box))] = None
        return tuple(sorted(out.items(), key=lambda t: (t[0][0], t[0][1])))
    r = _memo(g, "bar_chain", make)
    return dict(r) if r is not None else None


def bar_downstream(g, color, box):
    """沿**按条**的帽贴附关系，被 (color, box) 这根条拖在后面的全部后代条（不含自己）；
    算不出返回 None。碰到 "AMBIGUOUS" 的条就不往它那一支走，也不把它算进后代。

    **父指针成环的帧一律返回 None（闭嘴）**：父子靠「孩子的帽格贴住父的身体」定，
    三根条首尾相接时每根都是别人的孩子、谁都不是根，「谁挂在谁后面」没有答案。

    这一道现在**打不着**：环的唯一来源是「给带尖那根也认了孩子」，`bar_chain` 已经把那类边掐掉，
    全去重语料 730 帧成环数归零。留着它是防真出现别的环——那时闭嘴才是诚实的。
    中间走过两版弯路，都记在这里：
      先返回 None（闭嘴）——闸开了，可当时当前帧正是「成环」帧，册子说不出下一帧，
        规划器当场给不出动作串；
      再返回 [] 并把「环上一根后代都不拖」立成正面主张——**下一步就被世界打脸**：
        那一帧里孩子被结结实实地按同一个 180° 转走了，主张撤册。
    两次都错在同一处：**拿「结构算不出来」当成了「世界不做这件事」**。
    结构算不出来时该问的是「这个结构本身是不是读错了」，而这里正是读错了。
    """
    if bar_chain_has_ring(g):
        return None
    ch = bar_chain(g)
    if ch is None:
        return None
    out, frontier = [], [(color, tuple(box))]
    while frontier:
        cur = frontier.pop()
        for key, par in ch.items():
            if par == "AMBIGUOUS" or par is None:
                continue
            if par == cur and key not in out and key != (color, tuple(box)):
                out.append(key)
                frontier.append(key)
    return out


def diamond_dots(g):
    """菱形的四个点：某格上下左右四邻都是色 13，则那四邻都是「点」。"""
    return set(_diamond_scan(g)[0])


def diamond_centers(g):
    """菱形中心 (行, 列)：上下左右四格都是色 13（中心自己什么色不管）。"""
    return list(_diamond_scan(g)[1])


def _diamond_scan(g):
    """点和中心一起扫，一帧一份：(frozenset 四点, tuple 中心)。

    **语义一个字不改**，只换了扫哪些格。原来两个函数各自把 64×64 全盘走一遍，
    每格问一次「四邻是不是都是色 13」；那是个纯 Python 的双重循环加四次取值，
    量出来占一次结点展开的一成半，而规划器的结点预算本来就只有几百个。
    中心的定义只可能落在**某个色 13 格的四邻**上，所以候选从色 13 格反推就够，
    盘上色 13 只有寥寥几十格。候选按 (行, 列) 排序后再判，产出的顺序和原来的
    行优先全盘扫描逐字一致——`diamond_centers` 的返回是有序列表，下游拿它做
    「尖铺满中心」的比对，顺序变了不报错只会悄悄变答案，所以这里排序不是装饰。
    """
    return _memo(g, "diamond_scan", lambda: _diamond_scan_raw(g))


def _diamond_scan_raw(g):
    n = len(g)
    cand = set()
    for a, b in cells_of(g, TIP):
        cand.add((a - 1, b))
        cand.add((a + 1, b))
        cand.add((a, b - 1))
        cand.add((a, b + 1))
    dots, centers = set(), []
    for r, c in sorted(cand):
        if not (1 <= r <= n - 2) or not (1 <= c <= len(g[r]) - 2):
            continue
        nbs = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
        if all(g[a][b] == TIP for a, b in nbs):
            centers.append((r, c))
            dots.update(nbs)
    return frozenset(dots), tuple(centers)


def tip(g, color):
    """这一节里的尖 (行, 列)：节 bbox 内、不属于菱形四点的那个色 13；不唯一或没有则 None。"""
    b = bar_box(g, color)
    if b is None:
        return None
    t, bo, l, r = b
    dots = diamond_dots(g)
    hits = [(rr, cc) for (rr, cc) in cells_of(g, TIP)
            if t <= rr <= bo and l <= cc <= r and (rr, cc) not in dots]
    return hits[0] if len(hits) == 1 else None


def tips(g):
    """{(节色, 这一根条的 bbox): 尖}，只收有尖的那些**条**；分不清返回 None。

    **按条存，不按色存。** 原先这里是 {节色: 尖}，一色一个位置。两处代价都是量出来的：
      ① 一色多条的关卡里它结构上装不下第二个尖。而 `all_home` 判的是
         「尖的位置集合正好铺满全部菱形中心」，中心有两个而尖只报得出一个，
         这一关的 `levelup_when_all_home` 就**永远**不可能开口——不是判错，是闭嘴。
      ② `tip(g, color)` 拿的是整色 bbox。一色多条时那个 bbox 横跨大半个盘，
         **别的条的尖**落进来就让它数出两个，于是返回 None，连本来读得出的那一个也丢了。

    这两处都不扣分，这是最该记住的部分：错藏在共享词汇里，而改词汇不算改版，
    从来没进过评分；一份残缺的尖位置图只会让下游概念沉默，S 照样满分。
    真值是可观测的（帧里不属于菱形四点的色 13 格），所以这一处直接对答案。

    分不清就整张返回 None，不猜：一根条框里读出两个尖、或同一个尖被两根条认领，
    都说明分辨率不够，而分辨率不够时最贵的错法不是失语，是把说不出的地方填上一个默认值。
    """
    allu = bar_units_all(g)
    if not allu:
        return None
    dots = diamond_dots(g)
    cand = [rc for rc in cells_of(g, TIP) if rc not in dots]
    out, owner = {}, set()
    for k, units in allu.items():
        for box, _side, _caps in units:
            t, bo, l, r = box
            hits = [rc for rc in cand if t <= rc[0] <= bo and l <= rc[1] <= r]
            if len(hits) > 1:
                return None                  # 一根条框里两个尖，分不清
            if len(hits) == 1:
                rc = hits[0]
                if rc in owner:
                    return None              # 同一个尖被两根条认领，分不清
                owner.add(rc)
                out[(k, tuple(box))] = rc
    return out


def tip_of_footprint(cells, side):
    """给一根条的落点格子集和帽在哪一侧，算它的尖：**自由端往里 1 格、轴上居中**。

    这条前提单独考过，因为整个 `tips_after` 都架在它上面：
    全去重语料的每一张 prev 与 next（430 张帧）上，凡是读得出的条，
    实际的尖与这个算法给的位置——**对 669 根条 / 错 0 根条**（12 张帧整帧读不出）。
    """
    if not cells:
        return None
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    t, bo, l, r = min(rs), max(rs), min(cs), max(cs)
    if side == "bottom":                     # 帽在下，自由端在上
        return (t + 1, (l + r) // 2)
    if side == "top":
        return (bo - 1, (l + r) // 2)
    if side == "right":                      # 帽在右，自由端在左
        return ((t + bo) // 2, l + 1)
    if side == "left":
        return ((t + bo) // 2, r - 1)
    return None


def tips_after(g, action):
    """这一步之后各个尖在哪：{(节色, 这一步之前的 bbox): 尖}；算不出来返回 None。

    **不再用位移推尖。** 旧版分两支：被点那一色的条跟着 `blob_moves` 的 d 走，
    其余的条跟着自己落点的整体平移走。伸缩的时候「整块位移」根本不成立——
    帽不动、自由端动，那不是平移；旧版于是把伸缩量当成了尖的位移。

    现在改成：`bar_footprints_after` 已经算出每根条这一步之后占哪些格，
    直接从**新落点**读自由端，尖就在自由端往里 1 格（`tip_of_footprint`，前提单独考过）。
    这样尖的位置只依赖落点，不依赖「这一步是伸是缩是被推」。

    **改动前的影子记分**（`runs/<run>/shadowtips2.py`、`shadowtips3.py`，判据跑之前写死）：
    普通一步 207 条上，旧版 对 181 / 错 18 / 弃权 8，新版 对 182 / 错 14 / 弃权 11；
    新版的错例集合是旧版的**真子集**，独有的新错法 0 条；`all_home` 两版都是真阳 4/4、假阳 0。
    剩下那 14 条错不在这里：它们全是 `bar_footprints_after` 预测了一次**世界其实拒绝了**
    的移动，每条的落点都整整差一段（3 格）——那是 `refused` 那一片空白，不是尖的问题。

    **补上那一片（终局卡上的反例逼出来的）**：上面那句「不是尖的问题」只在解释误差来源时成立，
    当成免责就错了——这个函数的名字是「这一步**之后**尖在哪」，世界拒绝了这一步，
    尖就还在原地，答「落点上的尖」是答错，不是答不全。终局卡上正是这么栽的：
    一次被拒的点击被 `will_levelup` 读成收口击（refused 那时说的是 True，只是没人问它），
    `levelup_when_all_home` 当场判 FALSE 关闸。
    所以现在先问 `refused`：
      · 说会拒 → 尖不动，返回**此刻**的尖。它依据的是概念 refused_says_it_exactly
        （被拒的一步前后帧逐格相同）；那条 S=1.000 / C=0.855 / N=331。
      · 说不出 → 返回 None。不填默认值：`refused` 自己的记载里写着，
        把「说不出」换成「按默认值算」会让错误从弃权变成假警报，而假警报会一路传到策略上。
    代价是 `refused` 那 16 条假警报上这个函数会说「尖没动」，于是靠它的概念在那些步上闭嘴（NA）——
    弃权不是错，说错才是错。
    """
    cur = tips(g)
    if not cur:
        return None
    ref = refused(g, action)
    if ref is None:
        return None                # 不知道世界收不收这一击，就不知道尖会在哪
    if ref:
        return dict(cur)           # 被拒 = 整步无事，尖留在原地
    allu = bar_units_all(g)
    bf = bar_footprints_after(g, action)
    if not allu or bf is None:
        return None
    side_of = {}
    for k, units in allu.items():
        for box, side, _caps in units:
            side_of[(k, tuple(box))] = side
    out = {}
    for key in cur:
        new = bf.get(key)
        side = side_of.get(key)
        if new is None or side is None:
            return None
        tp = tip_of_footprint(new, side)
        if tp is None:
            return None
        out[key] = tp
    return out



def all_home(t_map, centers):
    """尖的位置集合是不是正好铺满所有菱形中心。"""
    if not t_map or not centers:
        return None
    return set(t_map.values()) == set(centers)


def will_levelup(g, action):
    """**只看 prev 和动作**算这一步会不会换关：尖铺满所有菱形中心就会。算不出来返回 None。

    主张不在这里，在概念 levelup_when_all_home——这个函数只是把它前推的那一半提出来共用。
    为什么要有它：概念的 scope 里「换关返回 NA」一直是查 `ctx["level_next"]`，
    而**押注的时候还没走这一步，ctx 里没有 level_next**——于是生成器在换关那一步照旧开口。
    换关时整盘重画，任何「这根条挪了 3 格」之类的局部主张在那一帧上都看不见。
    """
    t_map = tips_after(g, action)
    if t_map is None:
        return None
    return all_home(t_map, diamond_centers(g))


def obstacles(g):
    """盘上的死物：颜色既不是底色/帽/面板填充/面板边框/尖，也不属于任何一节。

    第 0 关一个也没有；第 1 关是色 15 那两片。它们不是「墙」——「墙会挡住节」是一条要走闸的主张，
    这个函数只负责把「不属于已知机构的颜色」认出来。
    """
    return list(_memo(g, "obstacles", lambda: tuple(_obstacles(g))))


def _obstacles(g):
    known = {BG, CAP, FILL, BORDER, TIP} | set(seg_colors(g))
    return [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v not in known]


def seg_footprint(g, color):
    """这一节占的全部格子：身体 bbox 里的每一格 + 帽那一排。认不出返回 None。"""
    box = bar_box(g, color)
    cap = cap_block(g, color)
    if box is None or cap is None:
        return None
    t, bo, l, r = box
    return {(rr, cc) for rr in range(t, bo + 1) for cc in range(l, r + 1)} | set(cap)


def draw_rows(g):
    """条画得出来的最后一行：计数条那一排画在最上面，条长到那儿也看不见。

    实测：一根条连长十二次，最后几次自由端已经越过盘底，读回来的框停在第 62 行，
    而第 63 行整排是计数条。所以「盘」对条来说只有 0..62 行——除非这一帧的第 63 行
    不是计数条（那就照旧到 63）。
    """
    row = g[COUNTER_ROW]
    return COUNTER_ROW - 1 if all(v in (CAP, USED) for v in row) else COUNTER_ROW


def _clip_box(nb, rmax=63):
    """把落点框裁到画得出来的那一块：条能长到盘外去，世界照做，只把露出来的一截画出来
    （实测：连长十二次，最后五次自由端已越过最后一行，每一次照走不误）。
    整个框都在外面、或者框本身就非法（缩过头）返回 None。

    原先这里是「越界就整个返回 None」，代价是：世界头一回把条长出盘外的那几帧，
    册子里所有走这条路的概念一起闭嘴——**最该开口的那几帧一句话没有**。
    裁掉之后读回来的框会比真实长度短，这是已知的窄处，由用它的概念自己声明。
    """
    if nb is None:
        return None
    t, bo, l, r = max(0, nb[0]), min(rmax, nb[1]), max(0, nb[2]), min(63, nb[3])
    if t > bo or l > r:
        return None
    return (t, bo, l, r)


def landing_in_deco(g, action):
    """被点这一色的条，新占的格子里有没有落进面板/图例那种框；算不出来返回 None。

    为什么单拎出来：实测有一根条的自由端顶到面板边上就停住了，**而同一击里别的条照走**——
    既不是整步拒绝，也不是照长（长到面板底下）。单帧上分不出是哪一种，
    所以凡是会长进那种框的点击，说条怎么动的那几条概念一律闭嘴。
    """
    mv = blob_moves(g, action)
    if mv is None:
        return None
    boxes = deco_boxes(g)
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        if nb is None:
            return None
        old = set(cells_in(box))
        for rc in cells_in(nb):
            if rc in old or not (0 <= rc[0] < 64 and 0 <= rc[1] < 64):
                continue
            if in_any(boxes, rc):
                return True
    return False


def bar_parts_after(g, action):
    """算出这一步之后**每一根条**占的格子，身体与帽**分开**：
    {(节色, 这一步之前的 bbox): (身体格子集, 帽格子集)}；算不出来返回 None。

    分开是必须的：一排帽可以**同时是两根条的帽**（一块 3 色横排，上面压一根、下面压一根，
    两根都把它算进自己的占地），所以「帽 ∩ 帽」不是相撞，是共用接头。合并了就分不出来。
    要合起来的那份用 `bar_footprints_after`。

    **口径按「条」不按「色」**：被点那一色的**每一根条**各自按 `blob_moves` 给的
    (box, side, d) 走——自由端移 d、帽不动，帽锚住这根条的身份；某一色若真的
    被别的节的帽贴着（`downstream(g,color)` 非空）**且被点色与那个孩子色都恰好
    只有一根条**，孩子那一节连帽整体平移同一个 d；其余节的每一根条原地不动。

    **换过的口径，为什么**：旧版按颜色取整体——`box = bar_box(g,k)`、
    `side = capped_side(g, box)`——这两者都建在「一色一条」上：一色多条时
    `bar_box` 把互不相邻的几根条并成一个跨越全盘的假 bbox，`capped_side`
    在这个假条上找不到唯一的帽边，返回 None，于是**整关**失语（第 3 关色 11
    有 5 根条，实测 23 条转移卡在这里，另 2 条弃权是 RESET 动作、和多条无关，
    `click_panel` 本就认不出 RESET，仍照实返回 None）。`bar_units` 已经按
    帽锚定把每一根条分开认（见它的 docstring），这里改成逐条调用它：
    对只有一根条的颜色，`bar_units` 给出的 box/side/cap 与旧的
    `bar_box`/`capped_side`/`cap_block` 逐字相同——tip 裁剪对不交叉的单条
    是空操作，这是 `bar_units` 自己的 docstring 里写明、且在本局全去重语料
    872 个 (tid, 单条色) 组合上验过 0 处不一致的事，所以这次换口径对原来
    能开口的那 146 条转移不改变任何一条的答案。

    **一色多条时的下游语义，从「按色」换成「按条」**：旧版这里问 `downstream(g, color)`，
    那是**颜色级**的父子关系，不知道孩子的帽具体贴在父色哪一根条上；父或子有多根条时它返回
    None（不猜）。可它上游的 `chain()` 有个更糟的毛病：一色多条时 `parent_of` 归不出父亲，
    那一色被当成**根节点**，于是它压根不在 `kids` 里，这里就走进 `else` 分支把它**当成静止**——
    从「说不出」变成了「自信地说错」。实测代价：13 条假警报（全部经 `seg_overlap`）
    加 1 条方向相反的漏报，全在第 3 关（那一关色 11 有 5 根条，每一根的帽各压在别的一根条身上）。
    现在改成 `bar_chain` / 逐条传播：被点那一色的每一根条自由端移 d、帽不动；
    帽压在**已经动过**的某根条身上的条，连帽整体平移同一个 d，一直传到不动点为止。
    判据和旧版逐字相同（「帽贴在父条身上」而不是「帽贴在父条的自由端上」），
    换的只有分辨率——单条色上两者给出同一个父亲，所以原来能开口的那 146 条一条不变。
    "AMBIGUOUS"（一顶帽子同时压在两根条上）照实返回 None，不猜。

    这只是**算**落点，不管世界会不会让它发生 —— 「会不会」由 would_block 问。
    """
    cp = click_panel(g, action)
    if cp is None:
        return None
    color, _sign = cp
    mv = blob_moves(g, action)
    if mv is None:
        return None
    allu = bar_units_all(g)
    if allu is None:
        return None
    ch = bar_chain(g)
    if ch is None:
        return None
    if any(v == "AMBIGUOUS" for v in ch.values()):
        return None

    moves_by_box = {tuple(box): d for box, _side, d in mv}
    newbox, newcaps, give = {}, {}, {}
    rmax = draw_rows(g)

    # 被点那一色：每根条自由端移 d，帽不动（帽锚住这根条的身份）
    for box, side, caps in allu[color]:
        d = moves_by_box.get(tuple(box))
        if d is None:
            return None      # 理论上不会发生：与 blob_moves 用同一份 bar_units 读数
        nb = _clip_box(moved_box(box, side, d), rmax)
        if nb is None:
            return None
        key = (color, tuple(box))
        newbox[key], newcaps[key], give[key] = nb, tuple(caps), d

    # 逐条往下传：帽压在已经动过的某根条身上的条，连帽整体平移同一个 d
    changed = True
    while changed:
        changed = False
        for k, units in allu.items():
            for box, _side, caps in units:
                key = (k, tuple(box))
                if key in newbox:
                    continue
                par = ch.get(key)
                if par is None or par == "AMBIGUOUS" or par not in give:
                    continue
                d = give[par]
                nb = _clip_box((box[0] + d[0], box[1] + d[0],
                                box[2] + d[1], box[3] + d[1]), rmax)
                if nb is None:
                    return None
                newbox[key] = nb
                newcaps[key] = tuple((r + d[0], c + d[1]) for r, c in caps
                                     if 0 <= r + d[0] <= rmax and 0 <= c + d[1] <= 63)
                give[key] = d
                changed = True

    out = {}
    for k, units in allu.items():
        for box, _side, caps in units:
            key = (k, tuple(box))
            if key in newbox:
                out[key] = (set(cells_in(newbox[key])), set(newcaps[key]))
            else:
                out[key] = (set(cells_in(box)), set(caps))
    return out


def bar_footprints_after(g, action):
    """`bar_parts_after` 的合并版：{(节色, 这一步之前的 bbox): 身体格 | 帽格}；算不出来返回 None。

    合并会把「两根条共用一排帽」变成「两根条重叠」，问相撞的别用这个（用 bar_parts_after）。
    """
    p = bar_parts_after(g, action)
    if p is None:
        return None
    return {k: (body | caps) for k, (body, caps) in p.items()}


def footprints_after(g, action):
    """按**色**合并的落点：{节色: 这一步之后这一色占的全部格子}；算不出返回 None。

    合并这一步会丢掉「同色两根条撞在一起」——两根都进同一个集合，撞上等于被自己吸收掉。
    要问那件事就别用这个函数，用 `bar_footprints_after`（按条）。
    实测代价：第 349 步色 8 缩，把挂在它身上的一根色 11 条往下拖 3 格，正好压在**另一根**
    色 11 条身上，世界整步拒绝，而按色合并的 seg_overlap 说「不撞」，refused() 于是漏报。
    """
    bf = bar_footprints_after(g, action)
    if bf is None:
        return None
    out = {}
    for (k, _box), cells in bf.items():
        out.setdefault(k, set()).update(cells)
    return out


def would_block(g, action):
    """按算出来的落点，有没有哪一节会压到死物格上；算不出来返回 None，盘上没死物返回 False。

    注意它只回答「几何上撞不撞」，不回答「世界会怎么办」——撞上以后是整步被拒还是把死物推走，
    取决于撞的是哪一种死物，问 would_refuse / push_plan。
    """
    fps = footprints_after(g, action)
    if fps is None:
        return None
    obs = set(obstacles(g))
    if not obs:
        return False
    return any(fp & obs for fp in fps.values())


# ---- 死物的两种：推得动的、推不动的 ----------------------------------------
# 这是**观测出来的**分类，不是推理：第 1 关顶上去被整步拒绝的那一片是色 15；
# 第 2 关顶上去整块平移的那两片是色 1。眼下只能按颜色分，因为颜色是唯一手上有的判别量。
# 按颜色分永远比按语义分宽（方法册「让位规则要按语义写」），所以这里留着被打脸的余地：
# 哪天出现一片色 1 顶不动、或一片色 15 被推走，认出它的概念当场变反例。
FIXED_OBS = frozenset({15})


def obstacle_blobs(g):
    """死物按「同色 4 邻连通」分块：[(色号, frozenset(格子))]，按最小格排序。

    分块是有讲究的：观测到的是**整块**一起平移（顶的是块的一角，动的是整条），
    所以「块」这个单位本身是主张的一部分，由 pushable_obstacle_shifts 承担。
    """
    obs = set(obstacles(g))
    seen, out = set(), []
    for start in sorted(obs):
        if start in seen:
            continue
        v = g[start[0]][start[1]]
        stack, blob = [start], set()
        seen.add(start)
        while stack:
            r, c = stack.pop()
            blob.add((r, c))
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (r + dr, c + dc)
                if n in obs and n not in seen and g[n[0]][n[1]] == v:
                    seen.add(n)
                    stack.append(n)
        out.append((v, frozenset(blob)))
    return sorted(out, key=lambda x: min(x[1]))


def hit_blobs(g, action):
    """这一步算出来的落点压到了哪些死物块：[(色号, 格子集)]；算不出来返回 None。"""
    fps = footprints_after(g, action)
    if fps is None:
        return None
    land = set().union(*fps.values()) if fps else set()
    return [(v, cells) for v, cells in obstacle_blobs(g) if cells & land]


def would_refuse(g, action):
    """会不会整步被拒：压到了推不动的那种死物。算不出来返回 None。"""
    hit = hit_blobs(g, action)
    if hit is None:
        return None
    return any(v in FIXED_OBS for v, _ in hit)


def push_plan(g, action):
    """这一步之后每个死物块占的格子：{(色号, 原格子集): 新格子集}。

    压到的块整体平移 d，没压到的一格不动。返回 None 表示**算不出来**，有三种：
    落点本身算不出来、压到了推不动的死物、或者推出去的块会越界 / 撞上别的死物 / 撞上不动的节。
    后一种是诚实的「没见过」：语料里还没有一次推挤是被别的东西堵住的，所以不猜。
    """
    b = button(g, action)
    fps = footprints_after(g, action)
    if b is None or fps is None:
        return None
    d = b[1]
    hit = hit_blobs(g, action)
    if hit is None or any(v in FIXED_OBS for v, _ in hit):
        return None
    hitset = {cells for _v, cells in hit}
    out = {}
    for v, cells in obstacle_blobs(g):
        if cells in hitset:
            nc = frozenset((r + d[0], c + d[1]) for r, c in cells)
            if any(not (0 <= r <= 63 and 0 <= c <= 63) for r, c in nc):
                return None
            out[(v, cells)] = nc
        else:
            out[(v, cells)] = cells
    moved = [nc for (v, cells), nc in out.items() if cells in hitset]
    others = [nc for (v, cells), nc in out.items() if cells not in hitset]
    segland = set().union(*fps.values()) if fps else set()
    for nc in moved:
        if any(nc & o for o in others):        # 推到别的死物上了 —— 没见过
            return None
        if nc & segland:                       # 推到某一节的落点上了 —— 没见过
            return None
    return out


def push_block(g, action):
    """推挤被什么堵住了：'越界' / '撞死物' / '撞节'；没被堵或不适用返回 None。

    push_plan 把「算不出来」和「被堵住」混成同一个 None，这个函数把后者单独摘出来，
    好让概念只对**确实被堵住**的那一类开口，不至于顺手把「落点算不出来」也一并断言了。
    """
    b = button(g, action)
    fps = footprints_after(g, action)
    if b is None or fps is None:
        return None
    hit = hit_blobs(g, action)
    if not hit or any(v in FIXED_OBS for v, _ in hit):
        return None                            # 不顶死物 / 顶到推不动的那种，都不是这里管的事
    d = b[1]
    hitset = {cells for _v, cells in hit}
    moved, others = [], []
    for _v, cells in obstacle_blobs(g):
        if cells in hitset:
            moved.append(frozenset((r + d[0], c + d[1]) for r, c in cells))
        else:
            others.append(cells)
    segland = set().union(*fps.values()) if fps else set()
    for nc in moved:
        if any(not (0 <= r <= 63 and 0 <= c <= 63) for r, c in nc):
            return "越界"
        if any(nc & o for o in others):
            return "撞死物"
        if nc & segland:
            return "撞节"
    return None


# ---- 贴在自由端上的刚体（第 46~69 步改写：原来那套只覆盖「伸」，是盲的） -------------
# 观测：点色8 的**缩**（自由端朝下走 3 格），墙A 从行12..14 整块跟着下移到行15..17（144 格）；
# 点色12 的**缩**（自由端朝右走 3 格），墙B 从列33..35 一路跟着右移（每次 108 格）。
# 缩的时候落点在收缩，「落点压到死物」永远判不到，所以 hit_blobs 那一套看不见这半边现象。
# 同一批还打掉了「按颜色 4 邻连通 = 一个物体」：墙A 下移到行18..20 后与墙B 在列33..35 上相接，
# 分块把两者并成一块，可世界只搬动了墙B 那 54 格。所以刚体的身份要用**横截面**认，不用连通认。


def free_side(g, color):
    """自由端在哪一侧（帽的对端）：'top'/'bottom'/'left'/'right'；认不出返回 None。"""
    box = bar_box(g, color)
    if box is None:
        return None
    side = capped_side(g, box)
    if side is None:
        return None
    return {"top": "bottom", "bottom": "top", "left": "right", "right": "left"}[side]


def free_face(g, color):
    """自由端**外面**紧贴着的那一排格子（短边那么宽，长轴方向外侧一格）；认不出返回 None。

    伸的时候节要长进这一排，缩的时候节从这一排退开 —— 两种情形里贴着自由端的东西都在这儿。
    """
    box = bar_box(g, color)
    fs = free_side(g, color)
    if box is None or fs is None:
        return None
    t, bo, l, r = box
    n, m = len(g), len(g[0])
    if fs == "top":
        return [(t - 1, c) for c in range(l, r + 1)] if t - 1 >= 0 else None
    if fs == "bottom":
        return [(bo + 1, c) for c in range(l, r + 1)] if bo + 1 < n else None
    if fs == "left":
        return [(rr, l - 1) for rr in range(t, bo + 1)] if l - 1 >= 0 else None
    return [(rr, r + 1) for rr in range(t, bo + 1)] if r + 1 < m else None


def bar_free_face(g, box, side):
    """按**条**取自由端外侧紧贴的那一排格子：box 是这根条的 bbox，side 是帽在哪一侧。越出盘面返回 None。

    和 free_face 的区别只在入口：free_face 按**颜色**取（走 bar_box，一色多条时返回 None），
    这个按 (bbox, 帽侧) 取。几何逐字相同。
    """
    t, bo, l, r = box
    n, m = len(g), len(g[0])
    ar, ac = _AWAY[side]
    if ar == 1:
        return [(bo + 1, c) for c in range(l, r + 1)] if bo + 1 < n else None
    if ar == -1:
        return [(t - 1, c) for c in range(l, r + 1)] if t - 1 >= 0 else None
    if ac == 1:
        return [(rr, r + 1) for rr in range(t, bo + 1)] if r + 1 < m else None
    return [(rr, l - 1) for rr in range(t, bo + 1)] if l - 1 >= 0 else None


def _run(g, r, c, axis):
    """过 (r,c) 的同色极大直线段：axis=0 沿行走（竖直），axis=1 沿列走（水平）。返回 (低, 高)。"""
    v = g[r][c]
    if axis == 0:
        lo = hi = r
        while lo - 1 >= 0 and g[lo - 1][c] == v:
            lo -= 1
        while hi + 1 < len(g) and g[hi + 1][c] == v:
            hi += 1
    else:
        lo = hi = c
        while lo - 1 >= 0 and g[r][lo - 1] == v:
            lo -= 1
        while hi + 1 < len(g[r]) and g[r][hi + 1] == v:
            hi += 1
    return lo, hi


def rigid_unit(g, seeds, axis):
    """从贴着自由端的那几格出发认出一个刚体矩形（返回整个矩形的格子，含被菱形点盖住的）。

    axis 是**这根条自己 3 格厚的那个方向**（0 = 上下 3 格厚即横条，1 = 左右 3 格厚即竖条），
    不是运动轴。刚体是一根 3 格厚的条：沿 axis 恰好 3 格厚，垂直 axis 方向长。
    所以先从种子取沿 axis 的同色 run 当「带子」（不是 3 格厚就返回 None，那说明认错了东西），
    再把带子沿垂直方向一格一格往外推，每一格都要求整条带子同色。

    **为什么参数不是运动轴**：原先这里写的是运动轴，等于断言「墙总是 3 格厚地正对着推力」。
    那只是手上四次观测里墙的摆法——被横着推的都是竖条。第 2 关后段出现一根横条被横着推
    （沿运动轴 24 格长、垂直方向 3 格厚），run 取出 24 格，这里返回 None，
    于是整条概念判 NA、一格不认领，而 obstacles_after 照旧交出「墙没动」这个**错**答案。
    条的摆法是条自己的属性，和谁来推它无关，所以由调用方（attached）两个方向都试。

    两处要小心，都是拿观测顶出来的：
    ① **菱形的四个点不换色**（diamond_dots_immutable），墙滑过去时那四格仍是色 13，
       在墙身上留下四个洞。所以同色判断要把菱形点当**透明**，否则 run 会被洞截断。
    ② 两根同色的条碰在一起时，交界那几格归谁——**其中有一类在单帧里没有答案，这里不猜。**

       走过的五条单帧判据，全部在语料上留下读数（都不是「想清楚了」，都是语料挑出来的）：
         · 按**条的摆法**一刀切（横条穿过接头、竖条停在接头前，`strict = (axis == 1)`）。
           当时 docstring 里明写着「哪天出现一根竖条占住接头，这里就当场算错」——它兑现了：
           一根竖条穿过一根横条，世界把整条竖条连同交界一起平移，而这里在交界前停住
           （少算 5 格、多算 9 格）。
         · 「归**从种子长出来**的那根」（按这一步的角色分类，方法册推荐的那种写法）
           → 全量当场从 1 个错变成 11 个错。竖条把横条的身子一起吞掉，
           落点撞上没跟着走的那半截，于是 refused 反而误报整步被拒。
           **这条最值得记**：它听起来比正确答案更像好写法，所以一定会被再想到一次。
         · 「只有**我穿过它**才算我的，否则归横着长的那根」→ 修好一步、打坏另一步，净收益零。
           而催生「归横的」那两次观测里有一次方向正好相反——我把两次巧合读成了规律。
         · 判「两侧是否同色」时看**原色**而不是有效色 → 少算 6 格、多算 6 格。
           菱形点是条身上的洞，而洞可以落在**别人**身上：紧邻那一行正好是个点时，
           看原色就会认为「那边没有条」，于是把别人的身体吃进来。点对谁都是洞。
         · 「**挨上就停**，除非我穿过它」→ 又在另一处少算 9 格、多算 9 格。

       **五次之后得到的是一个否定结论**：交界处**两个端头齐口顶在一起**时（只有一侧挨着、
       谁都不穿过谁），那 3×3 归谁在单帧里**没有信息**。语料里有一对镜像：
       同一个按钮、同一个动作、局部几何完全同构，而世界一次把它判给横的、一次判给竖的。
       两种拆法都是合法的 3×k 矩形对，格数还一样多。
       所以那不是判据没找准，是那一帧里不存在能区分它们的量。

       现在的判据见 grow()：能定的四支照定，齐口拐角**返回 None**——
       概念判 NA，规划器也就不会拿这类局面排路线（refused → None → legal → None）。
       **为什么宁可算不出来也不猜**：猜出来的那一半以「说错 9 格」的形式进规划器，
       而说错的格子不拦任何人，它只是安静地把路线带偏，然后每一步都花真预算。

       **接着往下问什么**（是另一条主张，要单独走闸）：这一关两块可推墙每次能确定地量出来时
       都是同一个尺寸。若「墙的尺寸在一关之内不变」成立，齐口拐角就能靠尺寸唯一拆开；
       但那条主张得说清尺寸是从哪一帧观测来的——`apply` 只看得见 prev，看不见历史。
    """
    seeds = list(seeds)
    if not seeds:
        return None
    n, m = len(g), len(g[0])
    dots = diamond_dots(g)
    v = g[seeds[0][0]][seeds[0][1]]
    if any(g[r][c] != v for r, c in seeds):
        return None

    def eff(r, c):
        """(r,c) 的有效颜色：菱形点透明（返回 v，谁都能穿）。越界返回 None。"""
        if not (0 <= r < n and 0 <= c < m):
            return None
        return v if (r, c) in dots else g[r][c]

    def run(r, c):
        """过 (r,c) 沿运动轴的同色 run（菱形点透明）。"""
        lo = hi = (r if axis == 0 else c)
        while True:
            x = lo - 1
            rr, cc = (x, c) if axis == 0 else (r, x)
            if eff(rr, cc) != v:
                break
            lo = x
        while True:
            x = hi + 1
            rr, cc = (x, c) if axis == 0 else (r, x)
            if eff(rr, cc) != v:
                break
            hi = x
        return lo, hi

    runs = {run(r, c) for r, c in seeds}
    if len(runs) != 1:
        return None
    lo, hi = runs.pop()
    if hi - lo + 1 != SEG_W:            # 不是 3 格厚 —— 认错了，不猜
        return None
    perp = 1 - axis
    limit = n if perp == 0 else m

    def cells_at(p):
        return [((x, p) if axis == 0 else (p, x)) for x in range(lo, hi + 1)]

    def band_ok(p):
        """整条带子在 p 这一列/行上都是有效同色（菱形点透明）。"""
        if not (0 <= p < limit):
            return False
        return all(eff(rr, cc) == v for rr, cc in cells_at(p))

    def touches_perp(p):
        """p 这里有一根垂直于我的同色条挨着我的带子：带子**任一侧**紧邻是有效同色。

        用有效色（菱形点透明）：点是条身上的洞，而洞可以落在**别人**身上而不是我身上，
        紧邻那一行正好是个点时看原色就会认为「那边没有条」，于是把别人的身体吃进来。
        """
        for x in (lo - 1, hi + 1):
            rr, cc = (x, p) if axis == 0 else (p, x)
            if 0 <= rr < n and 0 <= cc < m and eff(rr, cc) == v:
                return True
        return False

    def crossed_both(p):
        """带子**两侧**紧邻都是有效同色 = 那根条从我这一头进、那一头出，p 这一格是它的身体。"""
        for x in (lo - 1, hi + 1):
            rr, cc = (x, p) if axis == 0 else (p, x)
            if not (0 <= rr < n and 0 <= cc < m) or eff(rr, cc) != v:
                return False
        return True

    def passes_through(p, step):
        """挨上了；那我是**穿过**它还是**顶在**它上面？

        判据只有一句：**我的带子在它那一段的另一侧还接着长吗**。
        接着长 = 我穿过它，这一段是我身体的一部分；不接着长 = 我这一端到此为止。
        """
        q = p
        while band_ok(q) and touches_perp(q):
            q += step
        return band_ok(q)

    ambiguous = []

    def grow(p, step):
        """往 step 方向能不能吃下 p 这一格；分不出来时记一笔，让整次测量作废。

        ① 没有垂直于我的同色条挨着 → 是我的。
        ② 我穿过它（我的带子在它那一段的另一侧还接着长）→ 是我的。
        ③ 它两侧都挨着我 = 它穿过我，而我不穿过它 → 是它的，我到此为止。
        ④ **只有一侧挨着、谁都不穿过谁（两个端头齐口顶在一起）→ 单帧分不出来。**
           这一支是拿两次打脸买来的，而且是一对**镜像**：同一个按钮、同一个动作，
           一次世界把齐口那 9 格判给横的、一次判给竖的，而两帧的**局部几何完全同构**
           （都是一侧挨着、两个端头齐口）。所以这不是判据还没找准，
           是**这 9 格的归属在单帧里没有信息**——两种拆法都是合法的 3×k 矩形对，
           格数还一样多。记一笔让 rigid_unit 返回 None（概念判 NA），
           不猜；猜出来的那一半会以「说错 9 格」的形式进规划器，而它每次看起来都像顺手修个 bug。
        """
        if not band_ok(p):
            return False
        if not touches_perp(p):
            return True
        if passes_through(p, step):
            return True
        if crossed_both(p):
            return False
        ambiguous.append(p)
        return False
    lo_p = min(rc[perp] for rc in seeds)
    hi_p = max(rc[perp] for rc in seeds)
    while lo_p - 1 >= 0 and grow(lo_p - 1, -1):
        lo_p -= 1
    while hi_p + 1 < limit and grow(hi_p + 1, +1):
        hi_p += 1
    if ambiguous:
        return None                    # 齐口拐角：单帧分不出来，不猜（见 grow 的 ④）
    if axis == 0:
        return frozenset((r, c) for r in range(lo, hi + 1) for c in range(lo_p, hi_p + 1))
    return frozenset((r, c) for r in range(lo_p, hi_p + 1) for c in range(lo, hi + 1))


def attached_moves(g, action):
    """贴在**任何一根正在动的条**自由端外侧的刚体，各自跟着走多少：[(色号, 整个矩形的格子, 位移)]。

    一个都没贴着返回 []；算不出来（点中的图标认不出、某根条的自由端认不出、贴着了却认不出那根条、
    同一块刚体被两根条推向两个不同的位移）返回 None。

    **口径按「条」不按「色」**：`attached` 原先的取值路径是 `button()`，而 `button()` 对一色多条
    必然返回 None（一个按钮催动多根条、多个不同位移，它只能给一个 d，所以保守弃权——那是对的，
    返回一个错的 d 才是事故）。于是这一支在一色多条的关卡上整关闭嘴，
    而它闭嘴会顺着 attach_plan → dots_case_undecided / seg_hits_static_obstacle 把 refused() 堵死两次，
    整册对那几个按钮一句话说不出来。这里改走 click_panel + blob_moves + bar_downstream：
    每根条各自有 (bbox, 帽侧, 位移)，自由端按 bar_free_face 取，被它拖在后面的下游条继承同一个位移。
    这不是新的世界主张，是把已有的那条主张按条重述一遍——按色说得出来的每一步，按条也说同样的话。

    **死物为零时不许说不出来**：唯一的取种子处是 `[rc for rc in face if rc in obs]`，
    obs 空则种子必空、答案只能是 []，所以早退排在最前面。
    """
    obs = set(obstacles(g))
    if not obs:
        return []                       # 一格死物都没有 —— 贴不上任何东西
    cp = click_panel(g, action)
    mv = blob_moves(g, action)
    if cp is None or mv is None:
        return None
    color = cp[0]
    movers = []                         # [(色, bbox, 帽侧, 位移)]
    for box, side, d in mv:
        movers.append((color, tuple(box), side, d))
        ds = bar_downstream(g, color, box)
        if ds is None:
            return None                 # 链认不清 —— 不猜下游跟不跟着走
        for k, kbox in ds:
            kside = capped_side(g, kbox)
            if kside is None:
                return None
            movers.append((k, tuple(kbox), kside, d))
    found = {}
    for _k, box, side, d in movers:
        face = bar_free_face(g, box, side)
        if face is None:
            return None                     # 这一节的自由端认不出，贴没贴着都说不准
        seeds = [rc for rc in face if rc in obs]
        if not seeds:
            continue
        seed_colors = {g[r][c] for (r, c) in seeds}
        if seed_colors <= FIXED_OBS:
            continue                        # 全是推不动那种：贴上了也不跟着走（c8cabd8816d74ec0）
        if seed_colors & FIXED_OBS:
            # 混色的自由端：一半是推不动那色、一半是推得动的。原先这里只看 seeds[0] 一格的
            # 颜色，于是列号最小的那一格是推不动那色时，**整节**（连同贴着的那块推得动的）
            # 被静默跳过——那不是「说不准」，是**没被问过**：推得动那块真动了的话，
            # 上层交出来的是一个错答案而不是 None，而 assert_ 恰好也在同一处判 NA，两头都不掉分。
            # 语料里混色自由端出现 0 次，所以这一改在现有语料上一格不动；它买的是
            # 「哪天真出现时，装置会闭嘴而不是撒谎」。
            return None
        # 条的摆法是条自己的属性，和推它的方向无关：先按「3 格厚正对推力」试
        # （竖条被横推、横条被竖推，这是早先四次观测里的摆法），
        # 不认就按另一个摆法再试一次（横条被横推——第 2 关后段就是这一种）。
        ax = 0 if d[0] else 1
        unit = rigid_unit(g, seeds, ax)
        if unit is None:
            unit = rigid_unit(g, seeds, 1 - ax)
        if unit is None:
            return None                     # 贴着墙却认不出那根条 —— 不猜
        key = frozenset(unit)
        v = g[seeds[0][0]][seeds[0][1]]
        if key in found and found[key][1] != d:
            return None                     # 两根条把同一块刚体推向不同位移 —— 单帧里没有答案，不猜
        found[key] = (v, d)
    return [(v, cells, d) for cells, (v, d) in found.items()]


def attached(g, action):
    """贴在**任何一节正在动的**自由端外侧的刚体：[(色号, 整个矩形的格子)]。

    一个都没贴着返回 []；算不出来返回 None。位移那一份走 attached_moves，这里只丢掉位移。

    **为什么不只看被点那一节**：被点那一节会拖动整条链（chain_drags_downstream），
    下游那几节整体平移同一个 d，它们自由端外面贴着的墙照样跟着走。
    原先这里只问被点那一节的自由端，于是一面压在**下游**某一节自由端上的墙整体挪了 3 列，
    而这里一句话也说不出来——更糟的是 obstacles_after 在「说不出来」时照旧交出「墙没动」，
    一个不会被评分的错答案（assert_ 恰好在同一处返回 NA，所以它永远不掉分）。
    """
    am = attached_moves(g, action)
    if am is None:
        return None
    return [(v, cells) for v, cells, _d in am]


def attach_plan(g, action):
    """每个跟着自由端走的刚体各走自己那根条的 d：[(色号, 原矩形, 新矩形)]；都没贴着返回 []；算不出来返回 None。

    **位移是按条的，不是按色的**：一个按钮催动的几根条位移可以互不相同（方向甚至相反），
    所以刚体的 d 必须从推它的那根条上取——原先这里统一取 `button()` 给的那一个 d，
    在一色多条的关卡上既取不到（button 返回 None）、就算取到也会给错。
    """
    am = attached_moves(g, action)
    if am is None:
        return None
    return [(v, cells, frozenset((r + d[0], c + d[1]) for r, c in cells))
            for v, cells, d in am]


_SIDE_DIR = {"top": (-1, 0), "bottom": (1, 0), "left": (0, -1), "right": (0, 1)}


def dots_newly_covered(g, action):
    """跟着走的刚体这一步**新压**到的菱形点；一格也没新压返回空集；算不出来返回 None。

    「新压」= 落点减掉这一块自己原来占的格子。墙**已经**盖在菱形点上、再沿着它滑走是合法的
    （51e6aebc203c620d、a130d57773da985c 世界都照做），所以判据是「新压」不是「压住」。
    按「压住」写过一版，全量语料当场 8 个错——墙确实会从菱形点上滑过去，
    那四格只是渲染在墙上面（diamond_dots_immutable），并不是墙不在那儿。
    """
    ap = attach_plan(g, action)
    if ap is None:
        return None
    dots = diamond_dots(g)
    out = set()
    for _v, cells, nc in ap:
        out |= (set(nc) - set(cells)) & dots
    return out


def dots_push_readings(g, action):
    """新压菱形点这件事上，两种都合语料的读法各自的判决：(沿长轴, 伸出去)；算不出来返回 None。

    三条已观测的「新压 4 格菱形点」转移：b2f1b087ef082fee 世界**拒了**，
    714f1a1f92f29a83 与 2a2c3ef4e6b80157 世界**照做**。差别有两处，
    而这两处在语料上完全同步、一次也没分开过：

      ① 位移是沿着这面墙自己的长轴，还是垂直于长轴（拒的那次沿长轴，照做的两次垂直）；
      ② 被点那一节是伸出去（自由端朝外走、把墙顶着走），还是缩回来（自由端朝里走、把墙拖着走）
         （拒的那次伸，照做的两次缩）。

    两种读法对这三条转移给出一模一样的答案，所以**语料选不出哪一条是真的**。
    它们只在两种没走过的构型上分歧：沿长轴地拖、垂直地推。
    那两种构型走 dots_case_undecided，refused 返回 None ——这里不猜。

    **「伸」不必问 button**：位移恒等于自由端方向乘 sign，所以「自由端朝外走」就是 sign == +1，
    click_panel 一个人就答得出来；原先绕道 button + free_side 取同一个数，
    代价是一色多条的关卡里整条读法闭嘴。「沿不沿长轴」按**每一块刚体各自的位移**算，
    因为一个按钮催动的几根条位移可以互不相同。
    """
    am = attached_moves(g, action)
    cp = click_panel(g, action)
    if am is None or cp is None or not am:
        return None
    ext = cp[1] == 1
    along = None
    for _v, cells, d in am:
        rs = {r for r, _c in cells}
        cs = {c for _r, c in cells}
        long_axis = 0 if len(rs) >= len(cs) else 1      # 0 = 竖着长，1 = 横着长
        this = (d[0] != 0) if long_axis == 0 else (d[1] != 0)
        along = this if along is None else (along and this)
    if along is None:
        return None
    return (along, ext)


def dots_case_undecided(g, action):
    """这一步是不是落在「新压菱形点、而两种读法打架」的那两种没走过的构型上。"""
    nd = dots_newly_covered(g, action)
    if nd is None:
        return None
    if not nd:
        return False
    rd = dots_push_readings(g, action)
    if rd is None:
        return None
    return rd[0] != rd[1]


def attach_block(g, action):
    """刚体跟着走的落点被什么占住了：'越界' / '撞死物' / '撞节' / '撞菱形点'；没被占或不适用返回 None。

    **菱形的四个点算占住：墙推到它们身上，世界整步拒绝。**
    这里原先写的是反话——「那四格不算占住，墙从它们底下滑过去，仍是色 13」——
    b2f1b087ef082fee 把它判死：一面 54 格竖墙往下推 3 行，落点 9 格里有 4 格是菱形点，
    别的什么都没有（没有推不动那色、没有别的墙、没有节，落点下方全是底色），
    而世界整步拒绝，真帧差 1 格、只有计费条跳了一格。
    册子当时预测 60 格运动、其中 45 格还预测对了——**说对 45 格的那一步是整步没发生**，
    因为那 45 格是「墙原地不动」和它重合的部分。

    这条假设从来没被评分过：它藏在词汇里，而改词汇不算改版。
    语料查过，它也从来没被检验过——全 139 条转移里，
    「墙占住了菱形点、而菱形点自己没搬家」的转移有 0 条
    （唯一一条交集非空的转移里菱形点自己换了位置，那是盘面重排，不是墙滑过去）。
    所以它不是被推翻的归纳，是一句**一次都没兑现过的措辞**，写下来就直接进了规划器。
    真正该问的是「墙能不能盖住目标点」，而世界的回答是不能，连试都不许试。
    """
    ap = attach_plan(g, action)
    fps = footprints_after(g, action)
    if ap is None or fps is None:
        return None
    dots = diamond_dots(g)
    obs = set(obstacles(g))
    seg_land = set().union(*fps.values()) if fps else set()
    allcells = set().union(*[set(c) for _v, c, _n in ap]) if ap else set()
    for _v, cells, nc in ap:
        if any(not (0 <= r < len(g) and 0 <= c < len(g[0])) for r, c in nc):
            return "越界"
        if (nc - set(cells)) & dots:
            rd = dots_push_readings(g, action)
            if rd is not None and rd[0] and rd[1]:
                return "撞菱形点"      # 新压菱形点，且两种读法都判拒（b2f1b087ef082fee）
        if nc & (obs - allcells):      # 别的刚体也在动，撞的得是没跟着走的那些
            return "撞死物"
        if nc & seg_land:
            return "撞节"
    return None



def seg_overlap(g, action):
    """这一步之后有没有**两根条**的落点撞在一起；算不出来返回 None。

    **按条两两比，不按色合并**：按色合并的话，同色两根条撞在一起会被自己吸收掉，看不见。
    实测代价就是第 349 步那条漏报——色 8 缩把挂在它身上的一根色 11 条往下拖 3 格，
    正好压在另一根色 11 条身上（落点 (12,14,21,46) 与静止的 (12,14,19,44) 逐格重叠 72 格），
    世界整步拒绝，而按色合并的读法说「不撞」，于是 refused() 说「不会拒」。
    部件的身份不该由它此刻的颜色决定——和 bar_units 不用 color_blobs 是同一个理由，
    这是同一个盲点在同一条链上的第三处，前两处是 footprints_after 与 bar_chain。

    **帽和帽压在一起不算撞**：一排 3 色横排可以同时是两根条的帽（上面压一根、下面压一根），
    这是盘上现成的合法构型，不是这一步撞出来的。用合并占地（身体|帽）两两比，这种共用接头
    每一帧都读成「相撞」——两根条一动不动也照样报，于是 refused() 在整整一关里句句说「会拒」，
    而世界句句照走。实测代价：第 7 关一开局就有一对共用帽的条，那一关头两步全被误判。
    所以判据改成**身体对身体、身体对帽**，只放过帽对帽。
    """
    parts = bar_parts_after(g, action)
    if parts is None:
        return None
    keys = sorted(parts, key=lambda t: (t[0], t[1]))
    for i, a in enumerate(keys):
        ba, ca = parts[a]
        for b2 in keys[i + 1:]:
            bb, cb = parts[b2]
            if (ba & bb) or (ba & cb) or (ca & bb):
                return True
    return False


def seg_hits_static_obstacle(g, action):
    """有没有哪一节的落点压住这一步**不会腾空**的死物格：True / False / None（算不出来）。

    这是 segments_never_on_walls 缺的后半截的**按占位写法**。原先这件事分给了两个
    按颜色写的判据（would_refuse 只看推不动那色、blocked_click_is_noop 也照颜色分），
    而按颜色分永远比按占位分宽，宽出去的那片正是语料里罕见的构型：

    一块 126 格的死物是个 T 字——横臂 72 格贴在正在动的自由端上、跟着走，
    竖干 54 格原地不动（rigid_unit 只取得出一个矩形，这是那个函数 docstring 里
    公示的接头归属选择）。被拖着走的那一节的落点正好压住竖干那 54 格。
    三个老判据一个都没查：would_refuse 只看颜色（那块是推得动的那种，所以说没事）、
    attach_block 查的是**墙的**落点不是节的落点、seg_overlap 只管两节相撞。
    于是世界整步拒绝，而册子预测 207 格运动（b929ced9b42319f5）。

    **只看正在动的那几节**：不动的节坐在原地，而 segments_never_on_walls 已经保证
    它们不在墙上，拿它们的原位去比会全是假阳性。
    **腾空的定义是「跟着走的墙离开的那些格子」**：墙搬走了，那几格这一步之后是空的，
    压上去不算撞——这正是 3c79fccbc0893691 与 e0f459332e57406b 那两次「顶进去、
    死物整块平移、点击照常生效」为什么合法。

    **死物为零时同样不许说不出来**：最后一行比的是 `land & (obstacles - vacated)`，
    obstacles 空则这个交集必然空，答案只能是 False。

    **正在动的那几节按「条」点名，不按「色」**：原先 `movers` 走 `button()` + `downstream()`，
    于是一色多条的关卡上 button 弃权、整条判据在整关闭嘴。改成从 bar_footprints_after
    逐条比「这一步之后的占位和现在的占位一不一样」——不一样就是正在动的那一根。
    这比按色取还更贴 docstring 上面那句「只看正在动的那几节」：同色里没动的那几根
    原先也被 `fps[k]` 一并算进 land，而它们坐在原地。
    """
    if not set(obstacles(g)):
        return False               # 静止死物格集合为空，落点压不到东西
    bf = bar_footprints_after(g, action)
    allu = bar_units_all(g)
    ap = attach_plan(g, action)
    if bf is None or allu is None or ap is None:
        return None
    land = set()
    for k, units in allu.items():
        for box, _side, caps in units:
            after = bf.get((k, tuple(box)))
            if after is None:
                return None
            if after != (set(cells_in(box)) | set(caps)):
                land |= after
    if not land:
        return None
    vacated = set()
    for _v, cells, nc in ap:
        vacated |= set(cells) - set(nc)
    return bool(land & (set(obstacles(g)) - vacated))


def same_off_counter(prev, nxt):
    """除计费条那一排之外，两帧逐格相同吗。

    「被拒的点击整帧不动」是过强的措辞：被拒照样占一步，而已烧格数是量化读数
    （burn_at），台阶比一步宽，所以**大多数**被拒的步像素确实一格没变，
    但只要这一步恰好跨过一个整数，计费条就会跳一格。语料里第一次跨过整数的
    被拒步（b929ced9b42319f5，烧格 5→6）把两条按 `prev == nxt` 写的概念一起判错，
    而它们说的机制是对的。所以判「什么都没发生」要绕开那一排。
    """
    for r in range(len(prev)):
        if r == COUNTER_ROW:
            continue
        if prev[r] != nxt[r]:
            return False
    return True


def same_bar_collide(g, action):
    """点这个按钮，**同一个节色的两根条**会不会抢同一格：True / False / None（算不出来）。

    「抢同一格」= 某根条这一步新占的格子里，有一格是同色另一根条这一步之后仍然占着的。
    只看同色条之间；异色两节撞在一起是 seg_overlap / seg_landing_collides 的地盘。

    **为什么要单独有它**：refused() 那一串判据全都建在 button() + bar_box() 上，
    也就是建在「一色一条」上——一色多条时 button 返回 None，footprints_after 返回 None，
    于是 attach_block / seg_overlap / refused 在这种关卡上**整关返回 None**。
    None 不是「不会被拒」，是「册子说不出」；规划器要是把它当成「不会被拒」，
    就是替概念兜底猜答案。这个函数只补一件事：同色条互抢这一支，它不依赖 button / bar_box。

    **实测（runs/<run>/samecolor.py，去重语料的关内转移）**：谓词命中 2 条、不命中 149 条、
    算不出来 0 条；命中的 2 条世界**都**整步拒了，命中而世界照做的 **0 条**。
    命中的两条是同一处几何连着两帧（一根朝上长的条的落点压在同色一根横条不腾空的身体上）。
    换句话说这条判据此刻只被 2 条转移检验过，而且是同一个构型——**它的把握来自 149 条零假阳，
    不是来自 2 条真阳**。断言它的概念是 same_color_bars_collide_refuses。
    """
    mv = blob_moves(g, action)
    if mv is None:
        return None
    olds, news = [], []
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        if nb is None:
            return None
        olds.append(set(cells_in(box)))
        news.append(set(cells_in(nb)))
    k = len(mv)
    for i in range(k):
        gained = news[i] - olds[i]
        for j in range(k):
            if i != j and gained & news[j]:
                return True
    return False


def merged_pair_suspect(g, action):
    """这一击会动的条里，有没有一根**其实是两根贴死的条被连通块并成了一根**：True / False / None。

    证据是帧上一顶**没人认领的帽**：3 格直线的色 CAP 块，不是 bar_units_all 里任何一个单元的帽，
    朝向和那根条相配（`side` 是 left/right 的条配竖帽，top/bottom 配横帽），而且紧贴着它的身体。
    一顶帽只可能是一根条的短边，所以它必须属于某根条；这根条在 units 里读不出来，
    只可能是它和邻节贴死、被并进了同一个连通块。

    **这个读法本身是被打出来的**：第 1086 步 a197d1d59397e644 实测色 11 的 unit 数 4 → 5，
    prev 上那根 28 列长的条在 next 上裂成 (12,14,19,29) 与 (12,14,36,46) 两根——
    并起来的那一根从来没有「消失」过，只是读不出边界。（同一件事第七次露面，
    v3 NOTE 里叫「同色两根条在几何上碰在一起时，按条也认不出边界在哪」。）

    两个下游用它，问的是同一件事的两面：
      · stranded_cap：贴死了还要往前伸 → 世界整步拒；
      · every_blob_moves_on_its_own_axis：贴死了，「每一团各自动一次」的团数就是错的 → 弃权。
    """
    allu = bar_units_all(g)
    if allu is None:
        return None
    if click_panel(g, action) is None:
        return None
    mv = blob_moves(g, action)
    if mv is None:
        return None

    claimed = set()
    for units in allu.values():
        for _box, _side, caps in units:
            claimed |= {tuple(rc) for rc in caps}
    # 这一击会动的每一根条：(它的帽该是竖的吗, 它的身体)
    targets = [(side in ("left", "right"), {tuple(rc) for rc in cells_in(box)})
               for box, side, _d in mv]

    n, m = len(g), len(g[0])
    seen = set()
    for r in range(n):
        if r == COUNTER_ROW:
            continue                      # 计费条那一行整行是色 CAP，不是帽
        for c in range(m):
            if g[r][c] != CAP or (r, c) in seen:
                continue
            stack, comp = [(r, c)], []
            seen.add((r, c))
            while stack:
                rr, cc = stack.pop()
                comp.append((rr, cc))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p = (rr + dr, cc + dc)
                    if (0 <= p[0] < n and p[0] != COUNTER_ROW and 0 <= p[1] < m
                            and g[p[0]][p[1]] == CAP and p not in seen):
                        seen.add(p)
                        stack.append(p)
            if len(comp) != 3:
                continue                  # 面板上的花纹是 5 格；帽正好是条的宽度
            rs, cs = {x[0] for x in comp}, {x[1] for x in comp}
            if len(rs) != 1 and len(cs) != 1:
                continue                  # 帽是一条直线
            if set(comp) & claimed:
                continue
            cap_vertical = len(cs) == 1        # 3 格同列 = 竖帽，只配 left/right 那种横条
            for want_vertical, body in targets:
                if want_vertical != cap_vertical:
                    continue                   # 朝向对不上：这顶帽不是这根条的
                if any((x[0] + dr, x[1] + dc) in body
                       for x in comp for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                    return True
    return False


def stranded_cap(g, action):
    """这一击会动的条里，有没有一根**已经和邻节贴死**（帽没主）而这一击还要往前伸：True / False / None。

    下面这一大段按时间顺序留着三个版本的读法，**前两个都是错的**，留着是因为
    「这段是怎么错的」比「现在怎么写」更值钱。当前语义看最后一段。

    （v1 的读法，已被推翻）「没人认领的帽」= 一个 3 格直线的色 CAP 块，不是 bar_units_all 里任何一个单元的帽，
    而它又紧贴着被点那一色某一节的身体。它的物理含义是**某一节已经缩到零长**：
    节在像素上一格不剩，它的帽却还留在原地贴着邻节。

    由来是 refused() 在全去重语料上**唯一**的一次漏报（第 1084 步 42341047045cf7fd，
    ACTION6:34,54）：六种旧机制全说「不拒」，四根条的落点九格全是底色，世界却整步拒了。
    同一个按钮走成了的 7 步 blob_moves 都给 5 根条，这一步只给 4 根——少的那一节缩没了，
    帽留在行 12..14 列 18，贴着相邻那一节的左端。

    **实测（runs/<run>/doublecap.py，全去重语料 595 条关内转移，四条判据跑之前写死）**：
    谓词命中 1 条、不命中 560 条、算不出 34 条；命中的那 1 条世界**确实**整步拒了，
    命中而世界照做的 **0 条**。46 条真被拒里它只开口 1 条，和旧六种机制不重叠——
    它补的是旧机制一条也没管住的那一条。
    **它的把握来自 518 条零假阳，不是来自 1 条真阳**：单点支持，随时可能被新构型推翻，
    推翻了就该在这里加一行，而不是把它悄悄放宽。断言它的概念仍是 refused_says_it_exactly。

    **第一版说宽了，当天就被自己的探针打回（runs/<run>/capsurvey.py + capowner.py）。**
    那一版问的是「被点**那一色**的任意一节贴着孤帽没有」。同一顶孤帽（行 12..14 列 18）
    同时贴着色 11 的一节和色 12 的一节，于是它在唯一那条真阳所在的帧上，
    把 4 个按钮判成「会拒」，而世界那一帧只拒了其中 1 个（ACTION6:34,54）——
    **它在自己唯一的证据上就已经说宽了 3 倍**，只是语料里没有别人去点那 3 个按钮，
    所以既没变成反例、也没扣过分。后果在规划器上是可见的：合法动作 6→3，束搜索第 3 轮走死。

    收窄用的是帧上现成的两条事实，不是为了让路：
      1. **一顶帽只可能是一根条的墓碑**，而帽是条的短边——`side` 是 left/right 的条，
         帽必然是竖的（3 格同列）；top/bottom 的条，帽必然是横的（3 格同行）。
         孤帽的朝向对不上的那根条，它就不是那根条的墓碑。（这一帧上 8 个 unit 逐个核过，无一例外。）
      2. 只看**这一击会动的那些条**（blob_moves），不是该色的全部节。
    收窄后色 12 的两个按钮放行，而唯一那条真阳仍判「会拒」——救不回它的收窄是把证据也扔了。

    **收窄之后仍然说宽，被世界当场打掉；连带整个物理读法都是错的。**
    收窄版把 ACTION6:28,54 判成「会拒」，策略专门发了这一击去打它（runs/<run>/policy.py
    的 `_stranded_probe`），世界照做，帧差 47 格（a197d1d59397e644）。
    跟着量出来的三件事（runs/<run>/shrinkdir.py）把原来的诊断整个推翻：
      · **方向反了**：被拒的那一击（第 1084 步）是**伸**，照做的那一击（第 1086 步）是**缩**；
      · **那一节根本没消失**：第 1086 步色 11 的 unit 数 **4 → 5**，
        prev 上那根 28 列长的条在 next 上裂成 (12,14,19,29) 和 (12,14,36,46) 两根；
      · 于是孤帽不是墓碑——**是两节贴死在一起、被连通块并成了一根**，
        被并掉那一节的帽因此没人认领。（这正是 v3 的 NOTE 里点过名的
        「同色两根条在几何上碰在一起时，按条也认不出边界在哪」，第七次露面。）
    **函数名 `stranded_cap` 是第一版那个错诊断的化石**，留着不改，因为改了就看不出这段是怎么错的；
    它现在问的是：**这一击会动的条里，有没有一根已经和邻节贴死（帽没主），而这一击还要往前伸**。
    物理读法：贴死之后「伸」把两节进一步压在一起，世界整步拒；「缩」把它们拉开，世界照做。
    加上方向之后全语料命中 1 条（第 1084 步，真被拒）、命中而世界照做 **0** 条。
    **支持仍然是单点的**：伸这一侧 1 条真阳，缩那一侧 1 条真阴。下次被打的时候先看这一行。

    「贴死了没有」这半边现在由 [merged_pair_suspect] 回答（两个下游共用，见那里的说明）；
    这里只加「而且这一击是伸」这一个条件。
    """
    mv = blob_moves(g, action)
    if mv is None:
        return None
    # 只管「伸」：贴死的两节再往前压才拒，往回缩是把它们拉开（第 1086 步实测照做）
    spans = []
    for box, side, d in mv:
        nb = moved_box(box, side, d)
        if nb is None:
            return None
        spans.append(max(nb[1] - nb[0], nb[3] - nb[2]) - max(box[1] - box[0], box[3] - box[2]))
    if not spans or not all(x > 0 for x in spans):
        return False
    return merged_pair_suspect(g, action)


def wedged_grow_and_still(g, action):
    """楔住：这一击要挪的刚体，一头被正在**伸长**的条顶着、另一头抵着某根**不动**的条的自由端。

    两端都是自由端接触，一端在推、一端不让，世界整步拒绝。
    「不动」按 bar_footprints_after 的落点和当前占位比：一格不差才算不动。
    「伸长」按落点格数比当前多；等长平移（被上游拖着走）和缩短都不算——
    实测就是这里分的家：拖着走的刚体照样能从不动的条的端头擦过去，被顶的不行。
    算不出来（attached_moves / bar_units_all / bar_footprints_after 任一说不出）一律返回 False，
    只做加法不做减法：这一支排在 refused 链子最末尾，它只把「不会拒」翻成「会拒」。
    """
    am = attached_moves(g, action)
    allu = bar_units_all(g)
    bf = bar_footprints_after(g, action)
    if am is None or allu is None or bf is None or not am:
        return False
    for _v, cells, _d in am:
        cs = set(cells)
        still = grow = False
        for k, units in allu.items():
            for box, side, caps in units:
                face = bar_free_face(g, box, side)
                if not face or not (cs & set(face)):
                    continue
                after = bf.get((k, tuple(box)))
                now = set(cells_in(box)) | set(caps)
                if after is None:
                    return False
                if after == now:
                    still = True
                elif len(after) > len(now):
                    grow = True
        if still and grow:
            return True
    return False


def joint_grow_into_child(g, action):
    """第九种：被点那根条**朝着自己和某根后代条共用的那个关节**伸长。

    构型：条 A 伸长的那一侧紧贴着一排帽（色 3），而这同一排帽同时被 A 的某根**后代**条
    认领为它自己的帽（`bar_units` 的 caps）。也就是说 A 要长进去的那一格，正是它和儿子之间的关节。
    世界整步拒。物理读法：关节是儿子挂在 A 身上的锚，A 往锚里长等于顶着锚推。

    **它和第八种（wedged_grow_and_still）不是同一件事**：那一条问的是「刚体两端一推一挡」，
    要有一块刚体夹在中间；这一条里一块刚体也没有，挡住伸长的是关节本身。

    **凭据是单点的，和第七、第八种一样，照实写在这里**：
    逼出它的是终局卡第 6 关的一次整步拒（`refused` 的第二次漏报，
    见 [refused_says_it_exactly] v7）。全去重语料 1158 条、关内 1158 条上量的四格表
    （`runs/<run>/probe_joint.py`，四条判据在跑之前写死在 docstring 里）：
      世界真拒 50 条：命中 1 / 不命中 27 / 说不出 22
      世界真动 1108 条：命中 **0** / 不命中 854 / 说不出 254
      与 refused() 原本就说 True 的步重叠 0 条 —— 所以它是**纯加法**，不动任何已有的 True/None。
    **1 条真阳、0 条假阳（分母 1108）**：说服力全部来自假阳那一侧，随时可能被新构型推翻。

    同一批里被自己的判据打死的三个候选，死因留在这里，免得再猜一次：
      「链子要求某根后代条沿短轴平移」——命中而世界照做 **409/1108**。
        垂直于自己长轴的整体平移在这个世界里是家常便饭，不是拒绝的理由
        （[every_blob_moves_on_its_own_axis] 管的是自由端怎么长，不是整块怎么被拖）。
      「往自己的帽那一头伸」——命中而世界照做 **854/1108**。帽那一头本来就是伸长的那一头。
      「两头都压着帽」——命中而世界照做 **12/1108**。
    三条都在那条转移上命中，**光看「它解释得了这一条」筛不掉任何一个**；筛掉它们的全是假阳那一列。
    """
    mv = blob_moves(g, action)
    if not mv or len(mv) != 1:
        return None
    box, side, _d = mv[0]
    allu = bar_units_all(g)
    if allu is None:
        return None
    cnt = {}
    for r in range(box[0], box[1] + 1):
        for c in range(box[2], box[3] + 1):
            cnt[g[r][c]] = cnt.get(g[r][c], 0) + 1
    if not cnt:
        return None
    col = max(cnt, key=cnt.get)
    down = bar_downstream(g, col, tuple(box))
    if down is None:
        return None
    t, bo, lf, rt = box
    if side == "top":
        face = {(t - 1, c) for c in range(lf, rt + 1)}
    elif side == "bottom":
        face = {(bo + 1, c) for c in range(lf, rt + 1)}
    elif side == "left":
        face = {(r, lf - 1) for r in range(t, bo + 1)}
    elif side == "right":
        face = {(r, rt + 1) for r in range(t, bo + 1)}
    else:
        return None
    for c2, b2 in down:
        for u in allu.get(c2, ()):
            if tuple(u[0]) == tuple(b2) and face & set(u[2]):
                return True
    return False


def refused(g, action):
    """世界会不会整步拒绝这一次点击：True / False / None（算不出来）。

    六种已观测的拒绝：贴着的刚体没地方去（attach_block 的 '越界' / '撞死物' / '撞节'）、
    **刚体的落点盖住菱形目标点（attach_block 的 '撞菱形点'）**、
    **正在动的节的落点压住不会腾空的死物格（seg_hits_static_obstacle）**、
    节压到推不动那种死物（would_refuse，已被上一条涵盖，留着当冗余）、
    两节的落点撞在一起（seg_overlap）、**同色两根条互抢同一格（same_bar_collide）**。
    任一判据算不出来就返回 None，不猜。

    **第七种（stranded_cap）**：手臂上有一节已经缩到零长，帽还留在原地贴着邻节。
    它和前六种都不一样——前六种问的都是「落点上有什么」，它问的是「盘上还剩几节」。
    它排在 same_bar_collide 后面、其余全部前面，理由和那一条相同：**它不依赖落点**，
    所以在那些 footprints_after 说不出的局面上它仍然开得了口。
    它是被 refused() 在全语料上唯一一次漏报逼出来的，单点支持，读数见 stranded_cap 的记载。

    **第八种（wedged_grow_and_still）**：刚体一头被伸长的条顶着、另一头抵着不动的条的自由端。
    它排在链子**最末尾**，只把 False 翻成 True，不动任何已有的 True/None——
    因为它是拿「唯一一条漏报」逼出来的，凭据薄（全语料命中 3 条，3 条全是世界拒），
    薄凭据只许做加法。同样的构型换成「拖着走」世界照走 22 条，所以分家的是伸长不是接触。

    **第九种（joint_grow_into_child）**：被点的条朝着自己和某根后代条共用的那个关节伸长。
    和第八种并排放在链子最末尾，理由相同：单点凭据（1 真阳 / 0 假阳，分母 1108），只许做加法。
    读数与三个被打死的候选写在那个函数的 docstring 里。

    **同色互抢这一支放在最前面查**，因为它是唯一不依赖 button() / bar_box() 的一支。
    下面那几支原先全都建在「一色一条」上，一色多条的关卡里它们**整关**返回 None
    （footprints_after 第一个说不出，其余顺着继承），所以先查这一支，至少让「会被拒」这半边
    在那种关卡上说得出话。**这段限制已经不成立了**：footprints_after 换成按条口径 + bar_chain
    按条传播之后，多条关卡也开得了口。留着这一支的顺序不动，是因为它仍然是唯一不依赖落点的一支。

    **换口径那一次的教训，记在这里因为它是这条链上最贵的一次错**：把「说不出」换成
    「按默认值算」会让错误从 NA 变成假警报，而假警报会一路传到策略上。
    实测四格表的变化：按色 → 开口(True) 里有 13 条实测根本没拒绝；改成按条 → 那 13 条归零，
    并且它们变成了正确的「不会拒」（开口正确数 118 → 131），不是变回弃权。
    弃权面本身是地图的一部分，别用默认值把它填掉。
    """
    sbc = same_bar_collide(g, action)
    if sbc:
        return True
    sc = stranded_cap(g, action)
    if sc:
        return True
    fps = footprints_after(g, action)
    if fps is None:
        return None
    und = dots_case_undecided(g, action)
    if und is None or und:
        return None                # 新压菱形点、而两种读法打架的构型：不猜（dots_push_readings）
    if attach_block(g, action) is not None:
        return True
    h = seg_hits_static_obstacle(g, action)
    if h is None:
        return None
    if h:
        return True
    if would_refuse(g, action) is True:
        return True
    ov = seg_overlap(g, action)
    if ov is None:
        return None
    if ov:
        return True
    return True if (wedged_grow_and_still(g, action)
                    or joint_grow_into_child(g, action)) else False


def obstacles_after(g, action):
    """这一步之后死物占的全部格子：贴着的刚体搬走，其余原地。算不出来返回 None。

    刚体是个完整矩形。落点这里仍然减掉菱形点，但**理由变了**：不是「墙滑到它们身上、那四格仍是色 13」
    ——那句话是错的，墙推到菱形点上世界会整步拒绝（attach_block 返回「撞菱形点」，见那里的记载）。
    减掉它是**防御**：这个函数自己不查拒绝，万一有人在一个会被拒的局面上调它，
    减掉之后至少不会把一个目标点算成墙格。凡是真的走成了的步，落点里一格菱形点也没有，
    所以这一减在实际发生过的转移上等于没减——它是个不该被兑现的分支，留着当护栏。
    腾出来的格子也不还给底色（它本来就不是墙的颜色）。
    """
    obs = set(obstacles(g))
    ap = attach_plan(g, action)
    if ap is None:
        return None            # 说不准就说不准：从前这里返回 obs（「墙没动」），
                               # 那是个不会被评分的猜——assert_ 恰好在同一处判 NA。
    if not ap:
        return obs             # 确实一面墙也没贴着，原地不动是算出来的，不是猜的
    dots = diamond_dots(g)
    out = obs
    for _v, cells, nc in ap:
        out = (out - set(cells)) | (set(nc) - dots)
    return out


def occupied_after(g, action):
    """这一步之后被占住的全部格子 = 所有节的落点 ∪ 所有死物块的落点。算不出来返回 None。

    三条带 apply 的概念都查这同一张表来决定「腾出来的格子回不回底色」。
    每条概念各写一个特例，漏一类就会让两条概念对同一格给不同颜色，
    于是那一整类动作在规划里变成非法 —— 看起来像世界不允许，其实是册子内部打架。
    """
    fps = footprints_after(g, action)
    if fps is None:
        return None
    out = set().union(*fps.values()) if fps else set()
    # 死物的落点走 obstacles_after（贴着自由端的刚体跟着走，缩和伸都算），
    # 不再走 push_plan —— 那张表只看落点踩到谁，缩回去时落点是变小的，整个「拖着走」它看不见。
    obs = obstacles_after(g, action)
    if obs is None:
        return None
    return out | obs


def counter_left(g):    return [c for c in range(len(g[COUNTER_ROW])) if g[COUNTER_ROW][c] == CAP]


def burned(g):
    return sum(1 for c in range(len(g[COUNTER_ROW])) if g[COUNTER_ROW][c] == USED)


def burn_at(n, budget=BUDGET):
    """走了 n 步之后计数条应该烧掉几格 = round(COUNTER_CELLS * n / budget)。"""
    return (2 * COUNTER_CELLS * n + budget) // (2 * budget)


def moves_used(g, budget=BUDGET):
    """从计数条反推本关已用步数；**对不上或对上多个都返回 None**。

    预算 ≥ 64 时每步烧不到一格，同一个已烧格数对应好几个步数，这时计数条就是问不出步数来的。
    """
    b = burned(g)
    hits = [n for n in range(budget + 1) if burn_at(n, budget) == b]
    return hits[0] if len(hits) == 1 else None


def burn_step_range(budget):
    """一步能烧掉的格数只可能是这两个整数之间：floor(64/预算) .. ceil(64/预算)。"""
    return COUNTER_CELLS // budget, -(-COUNTER_CELLS // budget)


def burn_step_range_by_level(level):
    """本关一步能烧几格。**全体候选预算同意才给答案，有一个不同就返回 None。**

    返回 None 的意思是「说不准」，不是「不动」——上层必须跟着闭嘴（判 NA），
    不许自己兜一个答案（方法册「概念在它的词汇猜错的地方恰好判 NA」说的正是这种兜底）。
    第 2 关的 [200, 201] 在这个问题上是同意的（两者都给 (0, 1)），所以这一关能开口；
    哪天某个量上两个候选分了岔，这里自动返回 None，概念自动闭嘴，不需要谁记得。
    """
    cands = BUDGET_CANDIDATES.get(level)
    if not cands:
        return None
    ranges = {burn_step_range(b) for b in cands}
    return ranges.pop() if len(ranges) == 1 else None


# ---------------- 关节链：条不只会伸缩，还会拐弯 ----------------
#
# 由来：一直只点面板按钮，于是「条只沿自己的长轴动、方向定死」看上去永远成立。
# 点了一次面板以外的格子才发现方向可以转，上面那套读法只覆盖了构型空间的一个切片。
# 下面这套读法是从「转之前 + 转之后」两两对照量出来的，和上面那套并存，不改上面任何一个函数。
#
#   * 每根条落在一个 3x3 的**关节块**里：块的一面是色 3 的帽，条从帽对面那一面往外长 L 格。
#   * 根条的关节块钉死在盘上；下一根条的关节块 = 上一根条自由端外面紧挨着的那个 3x3。
#   * 帽**不一定**冲着上一根条 —— 所以链能拐直角，这正是能转出来的自由度。

_CCW_SIDE = {"top": "left", "left": "bottom", "bottom": "right", "right": "top"}


def ccw_side(side):
    """帽绕关节逆时针转 90 度之后贴在哪一面。"""
    return _CCW_SIDE.get(side)


def legend_boxes(g):
    """图例框：色 2 描边、色 4 填充、里面**只有一团**同色图标的方框 → [(box, 色)]。

    面板里是两团图标（缩 / 伸），图例框里只有一团 —— 这一条就是它和面板的分界。
    """
    pb = set(panel_boxes(g))
    out = []
    for box in deco_boxes(g):
        if box in pb:
            continue
        t, bo, l, r = box
        inside = [(rr, cc) for rr in range(t + 1, bo) for cc in range(l + 1, r)]
        ks = {g[rr][cc] for rr, cc in inside} - {FILL, CAP, BORDER}
        if len(ks) != 1:
            continue
        k = ks.pop()
        if len(components([rc for rc in inside if g[rc[0]][rc[1]] == k])) != 1:
            continue
        out.append((box, k))
    return out


def legend_click(g, action):
    """这一击落在哪个图例框里 → 那一色；不在任何图例框里返回 None。"""
    rc = click(g, action)
    if rc is None:
        return None
    for box, k in legend_boxes(g):
        if in_box(box, rc):
            return k
    return None


def _geom(bb, side):
    """给定条的 bbox 和帽贴在哪一面，算关节块 / 方向 / 长度 / 自由端那条线。"""
    t, bo, l, r = bb
    if side == "top":
        return {"side": side, "dir": (1, 0), "box": (t - 1, t + 1, l, r),
                "len": bo - t + 1, "free": bo, "far": (bo + 1, bo + 3, l, r)}
    if side == "bottom":
        return {"side": side, "dir": (-1, 0), "box": (bo - 1, bo + 1, l, r),
                "len": bo - t + 1, "free": t, "far": (t - 3, t - 1, l, r)}
    if side == "left":
        return {"side": side, "dir": (0, 1), "box": (t, bo, l - 1, l + 1),
                "len": r - l + 1, "free": r, "far": (t, bo, r + 1, r + 3)}
    return {"side": side, "dir": (0, -1), "box": (t, bo, r - 1, r + 1),
            "len": r - l + 1, "free": l, "far": (t, bo, l - 3, l - 1)}


def chain_layout(g):
    """把盘上的机构读成若干条从根到梢的关节链，摊平成一张表；读不干净就返回 None（不兜底）。

    每一项 {'color','side','dir','box','len','free','far','bb','chain','pos'}：
    side 是帽贴在关节块的哪一面，dir 是条往外长的方向，box 是 3x3 关节块，
    far 是自由端外面那个 3x3（= 下一根条的关节块）；chain 是它属于第几条链（按根的色号排序），
    pos 是它在链上从根数起第几根。

    读不干净一律返回 None：认不出节色；某一色的格子不是一个 3 宽的矩形；
    帽面凑不出唯一自洽的一套父子关系；**条的自由端顶在盘边上**（可能被裁掉了，长度不可信）。

    v2 改成森林：一盘上可以有好几条互不相连的链，各有各的根。
    v1 硬性要求「一条链覆盖全部条」，在多链的盘面上一律 None —— 那不是读不干净，是我写窄了。
    """
    return _memo(g, ("chain_layout",), lambda: _chain_layout(g))


def chains(g):
    """chain_layout 的分组视图：[[根, 子, 孙…], [另一条链…]]；读不干净返回 None。"""
    flat = chain_layout(g)
    if flat is None:
        return None
    out = []
    for it in flat:
        while len(out) <= it["chain"]:
            out.append([])
        out[it["chain"]].append(it)
    return out


def _chain_layout(g):
    segs = [k for k in seg_colors(g)]
    if not segs:
        return None
    n, m = len(g), len(g[0])
    bb, cand = {}, {}
    for k in segs:
        cs = bar_cells(g, k)
        if not cs:
            return None
        t, bo, l, r = bbox(cs)
        h, w = bo - t + 1, r - l + 1
        if h != SEG_W and w != SEG_W:
            return None
        if len(cs) != h * w:                     # 不是实心矩形（尖 / 菱点被挖掉的除外）
            for rr, cc in cells_in((t, bo, l, r)):
                if g[rr][cc] != k and g[rr][cc] != TIP:
                    return None
        bb[k] = (t, bo, l, r)
        sides = []
        for side, strip in (("top", [(t - 1, c) for c in range(l, r + 1)]),
                            ("bottom", [(bo + 1, c) for c in range(l, r + 1)]),
                            ("left", [(rr, l - 1) for rr in range(t, bo + 1)]),
                            ("right", [(rr, r + 1) for rr in range(t, bo + 1)])):
            if all(0 <= p[0] < n and 0 <= p[1] < m and g[p[0]][p[1]] == CAP for p in strip):
                sides.append(side)
        if not sides:
            return None
        cand[k] = sides

    def occupant(box):
        """这个 3x3 里坐着哪一色的条：没有返回 None，不止一色返回 False（读不干净）。"""
        t, bo, l, r = box
        if t < 0 or l < 0 or bo >= n or r >= m:
            return None
        hit = {g[rr][cc] for rr, cc in cells_in(box)} & set(segs)
        if not hit:
            return None
        return hit.pop() if len(hit) == 1 else False

    order = sorted(bb)
    total = 1
    for k in order:
        total *= len(cand[k])
    if total > 256:
        return None

    good = []
    has_tip = {k: any(g[rr][cc] == TIP for rr, cc in cells_in(bb[k])) for k in order}
    for combo in _product([cand[k] for k in order]):
        geo, ok = {}, True
        for k, s in zip(order, combo):
            it = _geom(bb[k], s)
            # 自由端顶在盘边：可能是正好齐着边，也可能是伸出去被裁了一截，光看 bbox 分不出来。
            # 尖那一格贴着自由端，条被裁了它就看不见——但**不是每根条都有尖**（只有该去占菱心的那几根有），
            # 没尖的条就真的分不出来。
            # 先前的做法是整帧作废，于是一根无关的条一贴边，整个册子就全哑了——
            # 而哑掉的那几帧，正是世界在做不常见的事的那几帧。改成**照读，但把不确定标出来**：
            # 谁在乎长度，谁自己看 clipped。
            clipped = False
            if not has_tip[k]:
                if it["dir"][0] and it["free"] in (0, n - 1):
                    clipped = True
                if it["dir"][1] and it["free"] in (0, m - 1):
                    clipped = True
            it["clipped"] = clipped
            it["color"], it["bb"] = k, bb[k]
            geo[k] = it
        if not ok:
            continue
        parent = {}
        for k in order:
            # 子条的帽贴在它自己关节块的哪一面都行，包括正冲着上一根条的那一面。
            # （先写成「不许冲着上一根条」，当场被转过一次的那一帧打掉。）
            # 认亲只看一件事：谁的关节块正好是我的外块。
            kids = [c for c in order if c != k and geo[c]["box"] == geo[k]["far"]]
            if len(kids) > 1 or (kids and kids[0] in parent):
                ok = False
                break
            if kids:
                parent[kids[0]] = k
        if not ok:
            continue
        kid = {}
        for c, p in parent.items():
            kid[p] = c
        roots = [k for k in order if k not in parent]
        seen, forest = set(), []
        for root in roots:
            ch, k = [], root
            while k is not None and k not in seen:
                seen.add(k)
                ch.append(k)
                k = kid.get(k)
            forest.append(ch)
        if len(seen) != len(order):              # 有环：剩下的条谁也够不着
            continue
        # 「自由端外面坐着的那根条，必定是我的子条」——这一条不是几何真理：
        # 两根不相干的条完全可以恰好挨着。但它在多数帧上把假的帽面组合杀干净，
        # 所以留着当**平局的裁判**：先按几何认亲，认出不止一套读法时，再拿它来挑。
        tight = True
        for k in order:
            c = occupant(geo[k]["far"])
            if c is None:
                continue
            if c is False or geo[c]["box"] != geo[k]["far"]:
                tight = False
                break
        good.append((geo, forest, tight))

    if len(good) != 1:
        picked = [x for x in good if x[2]]
        if len(picked) != 1:
            return None
        good = picked
    geo, forest, _ = good[0]
    out = []
    for ci, ch in enumerate(forest):
        for pi, k in enumerate(ch):
            it = dict(geo[k])
            it["chain"], it["pos"] = ci, pi
            out.append(it)
    return out


def _product(pools):
    out = [[]]
    for pool in pools:
        out = [row + [x] for row in out for x in pool]
    return out


def _forward(J, side, ln):
    """关节块 J=(t,b,l,r) + 帽贴哪一面 + 长度 → 这一根条的身体 / 帽 / 外块 / 占地。

    这是 _geom 的反向：_geom 从盘上读出来的 bbox 倒推关节块，这个从关节块正推 bbox。
    有了它才能问「假如它转过去，会落在哪」——盘上没有的局面，只能算。
    """
    jt, jb, jl, jr = J
    if side == "top":
        bb = (jt + 1, jt + ln, jl, jr)
        far = (jt + ln + 1, jt + ln + 3, jl, jr)
        cap = (jt, jt, jl, jr)
    elif side == "bottom":
        bb = (jb - ln, jb - 1, jl, jr)
        far = (jb - ln - 3, jb - ln - 1, jl, jr)
        cap = (jb, jb, jl, jr)
    elif side == "left":
        bb = (jt, jb, jl + 1, jl + ln)
        far = (jt, jb, jl + ln + 1, jl + ln + 3)
        cap = (jt, jb, jl, jl)
    else:
        bb = (jt, jb, jr - ln, jr - 1)
        far = (jt, jb, jr - ln - 3, jr - ln - 1)
        cap = (jt, jb, jr, jr)
    return {"side": side, "len": ln, "box": J, "bb": bb, "cap": cap, "far": far,
            "foot": frozenset(cells_in(bb)) | frozenset(cells_in(cap))}


def place_chain(root_box, bars):
    """根的关节块 + 一串 (色, 帽面, 长度) → 从根往梢推一遍，每根条落在哪。

    下游的关节块 = 上游自由端外面那个 3x3，所以整条链只要给了根的关节块就定死了。
    只算落点，不判合不合法。
    """
    out, J = [], root_box
    for k, side, ln in bars:
        it = _forward(J, side, ln)
        it["color"] = k
        out.append(it)
        J = it["far"]
    return out


def rot_layout(g, k, n):
    """假如点 k 的图例、k 连同下游各转 n 档逆时针：全盘每一根条会落在哪。读不干净返回 None。"""
    fl = chains(g)
    if fl is None:
        return None
    tgt = [i for i, ch in enumerate(fl) if any(x["color"] == k for x in ch)]
    if len(tgt) != 1:
        return None
    out = []
    for i, ch in enumerate(fl):
        hit = [j for j, x in enumerate(ch) if x["color"] == k]
        start = hit[0] if i == tgt[0] else len(ch)
        bars = []
        for j, x in enumerate(ch):
            s = x["side"]
            if j >= start:
                for _ in range(n):
                    s = ccw_side(s)
            bars.append((x["color"], s, x["len"]))
        out += place_chain(ch[0]["box"], bars)
    return out


def rot_fits(g, k, n):
    """转 n 档之后，条放得下吗：压死物、压别的条，算放不下。读不干净返回 None。

    **伸出盘外不算放不下**：实测过一次，转过去整根条有一多半在盘外，世界照转不误，
    只把露在盘上的那一截画出来。所以这里只查盘内的格子。
    """
    lay = rot_layout(g, k, n)
    if lay is None:
        return None
    nr, nc = len(g), len(g[0])
    dead = set(obstacles(g))
    for box in deco_boxes(g):
        dead |= set(cells_in(box))
    taken = set()
    for it in lay:
        for rc in it["foot"]:
            if not (0 <= rc[0] < nr and 0 <= rc[1] < nc):
                continue
            if rc in dead or rc in taken:
                return False
            taken.add(rc)
    return True


def rot_hits_fixed(g, k, n):
    """转 n 档之后，条压到**推不动的死物**（`FIXED_OBS`）了吗。读不干净返回 None。

    和 `rot_fits` 分开问，因为世界对这两种「放不下」的反应不一样：
    压到另一根条会往下试档，压到推不动的死物是整击作废。
    """
    lay = rot_layout(g, k, n)
    if lay is None:
        return None
    nr, nc = len(g), len(g[0])
    for it in lay:
        for rc in it["foot"]:
            if not (0 <= rc[0] < nr and 0 <= rc[1] < nc):
                continue
            if g[rc[0]][rc[1]] in FIXED_OBS:
                return True
    return False


def rot_steps(g, k):
    """点一次 k 的图例，实际会转几档：从 1 试到 4，取第一个放得下的。

    4 档就是原样不动，所以只要读得干净，总有一个答案。读不干净返回 None。

    **但「放不下」有两种，世界只对其中一种往下试档**：压到另一根条会跳档，
    压到推不动的死物（`FIXED_OBS`）是**整击作废**——那一档一撞上死物就直接判 4，不再往下试。
    这条判据在按条读的那一套（`legend_rot`）里是同一句话，两边一起改的；
    证据薄（压条 2 条、压死物 1 条），承担它的主张单独立在
    [fixed_obstacle_blocks_rotation]，那里用帧上另一种读法核。
    """
    for n in range(1, 5):
        hit = rot_hits_fixed(g, k, n)
        if hit is None:
            return None
        if hit:
            return 4
        ok = rot_fits(g, k, n)
        if ok is None:
            return None
        if ok:
            return n
    return None


def ccw_steps(a, b):
    """从帽面 a 逆时针转到帽面 b 要几档（0~3）；不是四个面之一返回 None。"""
    s, n = a, 0
    while n < 4:
        if s == b:
            return n
        s = ccw_side(s)
        n += 1
    return None


# ---- 图例点击：按条读的转法 ----------------------------------------------
# 上面那一套（chain_layout / rot_fits / rot_steps）按**色**读链，一色两根条就整帧拒读；
# 下面这一套按**条**读（bar_units_all + bar_chain），并且把定点、档数都算到格子上，
# 所以能生成下一帧而不只是判对错。两套并存：旧的那条概念还挂在旧的上面。


def bar_joint(g, box):
    """这根条转起来的定点：**帽那一排的正中那一格**。

    帽在 top 就是 (t, 中列)，帽在 left 就是 (中行, l)——注意是身体贴着帽的那一排，
    不是身体的中心，也不是帽自己那一排。四面都是帽的 3x3 枢纽没有唯一的帽面，
    取它自己的中心。读不出返回 None。

    **帽边数出来不止一条时，先去问 `bar_units_all`，但只在那段帽没被人抢的时候信它。**
    数目大于 1 往往不是「这根条真有两顶帽」，而是**邻条的帽排恰好贴在这根条的自由端那一头**——
    `cap_faces` 只数「框的这条边外面是不是整排色 3」，它分不出那排帽是谁的；
    而 `bar_units_all` 从帽往外走时记下了这根条自己的那三格帽和它在哪一侧。
    所以先用走出来的那一侧。

    **例外，也是这条的要害**：两根条可能把**同样那三格**记成各自的帽
    （一根说它在自己右边，另一根说它在自己左边）。这时走出来的那一侧不比数出来的更可信，
    `bar_chain` 的 docstring 早把这种局面记成单帧分不出的那一类。这里照旧返回 None。

    **为什么这件事值一条注释**：同一个几何量在这份词汇里有两处各算各的，
    一处（走出来的）比另一处（数邻接的）知道得多，而少知道的那处在下游把闸关上了。
    表现出来不是报错，是**通关路线上那几条边在规划器眼里不存在**：
    束搜索在那一关怎么搜都差着几步，看上去像启发式不好，其实是图缺了边。
    实测：一关三十九步的真路线上有三步这么被判成非法，改后两步开口且落点逐格全对，
    第三步正是抢帽的那种局面，仍然闭嘴。
    **「让它开口」和「让它说对」是两件事**：头一版只改了前者，第三步当场说错 48 格。
    """
    faces = cap_faces(g, box)
    t, bo, l, r = box
    if len(faces) != 1:
        if len(faces) >= 2 and bo - t == 2 and r - l == 2:
            return (t + 1, l + 1)
        if not faces:
            return None
        allu = bar_units_all(g)
        if allu is None:
            return None
        hit = [u for us in allu.values() for u in us if tuple(u[0]) == tuple(box)]
        if len(hit) != 1 or hit[0][1] not in faces:
            return None      # 走出来的那一侧和数出来的对不上：两处口径打架，不猜
        mine = frozenset(map(tuple, hit[0][2]))
        for us in allu.values():
            for b2, _s2, caps2 in us:
                if tuple(b2) != tuple(box) and frozenset(map(tuple, caps2)) & mine:
                    return None      # 这段帽同时被别的条认领着：谁的都说得通，闭嘴
        side = hit[0][1]
    else:
        side = faces[0]
    if side == "top":
        return (t, (l + r) // 2)
    if side == "bottom":
        return (bo, (l + r) // 2)
    if side == "left":
        return ((t + bo) // 2, l)
    return ((t + bo) // 2, r)


def rot_cell(rc, p, k):
    """绕定点 p 逆时针转 k 档。行往下增，所以一档是 (dr, dc) -> (-dc, dr)。"""
    dr, dc = rc[0] - p[0], rc[1] - p[1]
    for _ in range(k % 4):
        dr, dc = -dc, dr
    return (p[0] + dr, p[1] + dc)


def bar_group_cells(g, keys):
    """这一批条（[(色, box)]）占的全部格子：身体加自己那排帽，**菱形四点不算**——
    点不属于任何条，条只是从它们身上画过去。读不出返回 None。"""
    allu = bar_units_all(g)
    if allu is None:
        return None
    dots = diamond_dots(g)
    out = set()
    for k, box in keys:
        hit = [u for u in allu.get(k, []) if tuple(u[0]) == tuple(box)]
        if len(hit) != 1:
            return None
        b, _side, caps = hit[0]
        out |= (set(cells_in(b)) | set(caps)) - dots
    return out


def bar_clipped(g, box):
    """这根条的**自由端**是不是正压在盘边上；压着就说明它的真长度从这一帧读不出来。

    帽那一端是锚，自由端是对面那一端（帽在 'bottom' 则自由端在上，如此类推）。
    自由端那条边正好落在第 0 行 / 第 63 行 / 第 0 列 / 第 63 列时返回 True。

    **为什么这是一条观测极限，不是一个边界情况**：条能长到盘外，世界照做，
    只把露在盘上的一截画出来（`legend_rot` 的 docstring 早就写着这句，但只用在落点上）。
    于是自由端顶到盘边的那一刻起，「还有多长藏在外面」这件事在当前帧上**没有任何像素**对应，
    可见长度成了真长度的下界而已。和计数条那一行是同一族：不是模型不够细，是这一帧问不出来。

    实测（2026-09-08，`runs/<run>/rotlen.py`，全去重语料里 25 次转弯）：
    可见长度守恒的 23 次**全部**自由端不抵边；变了长度的只有 2 次，是同一根条连着两步——
    先横着 14 长转成朝上、被顶边裁成 8（`902585cb93d5dd50`），
    下一步再转回横着又露出全部 14（`1a4e2a971e025771`）。**裁剪是可逆的，世界一直记着那 14。**
    「两头都不抵边、长度还变了」一条都没有——所以转弯保长这件事本身没被推翻，
    被推翻的是「可见长度 = 真长度」。

    读不出这根条返回 None。
    """
    allu = bar_units_all(g)
    if allu is None:
        return None
    n, m = len(g), len(g[0])
    for units in allu.values():
        for b, side, _caps in units:
            if tuple(b) == tuple(box):
                t, bo, l, r = b
                return bool((side == "bottom" and t == 0)
                            or (side == "top" and bo == n - 1)
                            or (side == "right" and l == 0)
                            or (side == "left" and r == m - 1))
    return None


def bar_chain_has_ring(g):
    """`bar_chain` 的父指针里有没有环（顺着父往上走会回到自己）。

    父子靠「孩子的帽格贴住父的身体」定。三根条首尾相接时三个人互相当爹，
    没有根节点，「后代」这个词在这一帧上没有意义。说不出来（bar_chain 是 None）当没环。
    """
    ch = bar_chain(g)
    if ch is None:
        return False
    for node in ch:
        seen, cur, hops = set(), node, 0
        while True:
            par = ch.get(cur)
            if par is None or par == "AMBIGUOUS":
                break
            par = (par[0], tuple(par[1]))
            if par == node or par in seen:
                return True
            seen.add(par)
            cur = par
            hops += 1
            if hops > 40:
                return True
    return False


def _legend_rot_raw(g, action):
    """点图例这一击的完整算法（按条）：返回

        {"color", "box", "keys", "pivot", "steps", "src", "paint", "clear"}

    keys 是要转的那批条（被点的那根 + 它的全部后代）；steps 是实际转的档数：
    从 1 试到 3，第一个「转过去不压到东西」的就是它，都压得上就是 4（原地不动）。
    「东西」= 这一帧上除了这批条以外的所有非底色格，**菱点不算**（条从点上画过去），
    **盘外也不算**（条能长到盘外，世界照做，只把露在盘上的一截画出来）。

    **跳档只在压到别的条时发生。压到推不动的死物（`FIXED_OBS`）时整击作废**——
    steps 直接判 4，不再往下试档。这两种「压到」在语料里各只有几条：
    压到另一根条 2 条（世界跳到下一档），压到死物 1 条（世界一格没转，只烧了计数器）。
    「推不动」这个分类不是这里发明的，是平移那边早就量出来的（见 `FIXED_OBS` 注释），
    这里只是把它用到旋转上；哪天出现压着死物照转的一击，认它的概念当场变反例。

    **还有一档是弃权而不是判断：落点有格子转到盘外时返回 None。**
    这一条原来是「跳档 ∧ 盘外」的合取，第 2511 步证明合取漏；现在只看盘外。
    刻意写成「我算不出来」而不是「世界不转」——详见 `legend_rot_offboard_skip` 的 docstring
    与 `runs/*/accept_legend_offboard.py`、`runs/*/accept_offboard_widen.py` 里预注册的判据。


    paint 是盘内落点 → 该填的色；clear 是让出来的格子 → 该填的色（菱点仍是点）。
    读不出返回 None。**要转的这批条里只要有一根自由端抵着盘边（`bar_clipped`）也返回 None**：
    那根条有多长藏在盘外读不出来，转过去露出多少自然也算不出来。

    **`bar_chain` 在这一帧上成环时整个返回 None（闭嘴）**：`bar_downstream` 返回 None，
    链的方向靠「帽贴谁的身体」定，三根条首尾相接时谁都是别人的孩子、没有根，转谁算不出来。
    **这是「算不出」，不是「世界不转」**——曾经把它翻成正面主张（成环帧上只转被点的那一根），
    下一步就被世界打死撤册。病根是环本身读错了，见 `bar_chain` 里那一道 leaves 守卫
    与概念 [tip_bar_carries_nothing]；掐掉之后全语料成环帧归零，这一道留着防真出现别的环。
    """
    color = legend_click(g, action)
    if color is None:
        return None
    allu = bar_units_all(g)
    if allu is None:
        return None
    units = allu.get(color, [])
    if len(units) != 1:
        return None
    box = tuple(units[0][0])
    p = bar_joint(g, box)
    if p is None:
        return None
    down = bar_downstream(g, color, box)
    if down is None:
        return None
    keys = [(color, box)] + [(c, tuple(b)) for c, b in down]
    for _c, b in keys:
        clip = bar_clipped(g, b)
        if clip is None or clip:
            return None      # 要转的这批条里有一根被盘边裁着：它的真长度读不出来，转过去有多长就算不出来
    src = bar_group_cells(g, keys)
    if src is None:
        return None
    n, m = len(g), len(g[0])
    dots = diamond_dots(g)
    blockers = {(rr, cc) for rr in range(n) for cc in range(m)
                if g[rr][cc] != BG and g[rr][cc] != TIP and (rr, cc) not in src}

    def landed(steps):
        return {rc: rot_cell(rc, p, steps) for rc in src}

    steps = 4
    for cand in (1, 2, 3):
        put = landed(cand)
        hits = [d for d in put.values()
                if 0 <= d[0] < n and 0 <= d[1] < m and d in blockers]
        if any(g[d[0]][d[1]] in FIXED_OBS for d in hits):
            steps = 4        # 压到推不动的死物：整击作废，不往下试档（见 docstring）
            break
        if not hits:
            steps = cand
            break
    put = landed(steps)
    paint = {}
    for s, d in put.items():
        if not (0 <= d[0] < n and 0 <= d[1] < m):
            continue
        paint[d] = TIP if d in dots else g[s[0]][s[1]]
    clear = {rc: (TIP if rc in dots else BG)
             for rc in src if rc not in paint}
    return {"color": color, "box": box, "keys": keys, "pivot": p,
            "steps": steps, "src": src, "paint": paint, "clear": clear}


def legend_rot_offboard_skip(g, action):
    """这一击的落点里**有没有格子转到盘外**——**弃权闸唯一的定义处**。

    True = 是这种局面（算不出来，谁引用谁弃权）；False = 不是；None = 连档数都算不出来。

    **原来这里写的是合取「跳过了档 1 ∧ 落档有格子转到盘外」，那个分界线被证明是漏的。**
    原文与当时的理由整段留在下面，不删——它是这个闸为什么长这样的死因。

    > 由来是一次整步拒绝：世界 prev 与 nxt 逐格相同（连计数条都没烧），
    > 而 `_legend_rot_raw` 说 steps=2 转得动，靠它开口的概念判错六十格。
    > 分界线只有一条证据撑着——全语料 54 条图例点击里，有盘外落点的只有 2 条：
    > 一条 steps=1、盘外 14/41，世界照走；一条 steps=2、盘外 18/45，世界拒；
    > 而 steps=2 却落点全在盘内的 6 条，世界全部照走。
    > 单看「有盘外落点」分不开，单看「跳了档」也分不开，只有两者的合取分得开，
    > 而合取是最容易过拟合的形状，一条证据更谈不上确证。

    **推翻它的是终局卡第 2511 步**：色11 带着三根后代绕 (13,49) 转，steps=**1**（没跳档），
    落点 111/207 出盘，世界整步拒绝；合取闸放它过去，两条概念同时判 FALSE、说错 289 格。
    重新取证（`runs/*/probe_refuse2.py`、`probe_refuse3.py`，判据跑前写死）：
    全语料 94 次图例点击 / 78 条不同转移里，世界整步拒绝 4 条，plan 算得出的 3 条**全部**有盘外落点；
    88 条算得出的「世界照走」里有盘外落点的只有 1 条。当年选合取是因为拒的样本只有 1 条，
    现在拒的样本是 3 条，而合取只掐得住其中 1 条——**它漏，且漏的方式不报警**。

    所以判据从合取缩回单条「有盘外落点」。代价跑之前写死判据量过
    （`runs/*/accept_offboard_widen.py`，A1-A5）：现在给得出 plan 而放宽后弃权的只有 2 条
    （第 2511 步世界拒、第 768 步世界走），说错的 289 格全部消失；
    没有盘外落点的 74 条图例点击返回值一个字没变。

    **说对丢多少格，取决于用哪把尺，两个数都在这里，别只报一个**
    （`runs/*/probe_sweep_gates.py`、`probe_heldout.py` 对了三轮才对上）：
    · 全语料口径：丢 64 格 = 第 768 步 59 格 + 第 2511 步 5 格。
    · 记分牌口径：只丢 5 格（说对 6908→6903）。
    差在第 768 步的 59 格上——**它是这条概念自己的 EVIDENCE，结算的 apply 记分跑在 held-out 上，
    概念自己引用的转移根本不进分母。** 第一次报代价时只算了全语料那把尺，
    和结算的读数差 59 格对不上，查了三轮才知道差的是尺不是数。

    **A5 摊开的数是这样的**：盘外占比 0.34（世界走）/ 0.40 / 0.40 / 0.54（世界拒）。
    一个 0.37 上下的阈值能把四条全分开——**但那是在 0.34 和 0.40 之间的空隙上拟合一条线，n=4**，
    验收判据里预先写死了「无论分不分得开都不据此定阈值」，所以不定。
    哪天盘外占比低的那一侧再多几条证据，这个闸该收窄成阈值还是别的形状，到时候再说。

    **这仍然只说「我算不出来」，不说「世界不转」**——后者是正面断言，
    它得单独立一条概念去挨打，不能藏在词汇里蹭一个不打分的位置。

    写成一个独立的函数而不是抄两遍，是因为这一族主张有**两个身体**：
    一条概念按「条」读（走 `legend_rot`），另一条按「色」读链（走 `rot_steps`），
    抄两遍就一定会漏掉其中一个，而漏掉的那个不报警——它只是继续在该闭嘴的地方开口。
    第 2511 步两条概念**同时**判 FALSE，正是这个共用点在按设计工作。
    """
    p = _legend_rot_raw(g, action)
    if p is None:
        return None
    n, m = len(g), len(g[0])
    return any(not (0 <= d[0] < n and 0 <= d[1] < m)
               for d in (rot_cell(rc, p["pivot"], p["steps"]) for rc in p["src"]))


def legend_rot(g, action):
    """`_legend_rot_raw` 加上 [legend_rot_offboard_skip] 那道弃权闸。见两者的 docstring。"""
    p = _legend_rot_raw(g, action)
    if p is None:
        return None
    if legend_rot_offboard_skip(g, action) is not False:
        return None
    return p

