"""计数条显示的是「本关已用步数 / 本关预算」，已烧格数 = round(64 × 已用步数 / 预算)。"""
LEVEL = "L4"
SCOPE = ("只看 ACTION6 点在某块面板的图标中心上；"
         "换关返回 NA（两道：查 ctx，以及前推的 _lib.will_levelup——押注时 ctx 里没有 level_next）；"
         "**本关的预算没量出来（不在 _lib.BUDGET_BY_LEVEL 里）返回 NA**；"
         "**计数条反推不出唯一的已用步数返回 NA**（预算 ≥ 64 时每步烧不到一格，"
         "同一个已烧格数对应好几个步数——第 1 关预算 150，所以这条概念在那一关整关闭嘴）；"
         "已用步数已到预算返回 NA")
NOTE = ("v1「每步 1 格」死于 df97f80daf9ccb1c；v2「按面板计价」死于 ef152a513aa814a4、85d47bb3a3b2ad9d、"
        "f3ce3bd0fb651bb3、194ff8f124e2a4d9、de05a589d602e3bd（两个面板都出现过 1 格和 2 格）。"
        "v3 的定量式对了，但把预算 50 当成了世界常数，死于 64e2bc30cd0e77bc：第 1 关走第一步，"
        "计数条一格没烧，而 round(64/50)=1。v4 把预算改成**每关一个常数**，只在量出来的关上开口。"
        "v4 起还多一层沉默：预算大到每步烧不满一格时，计数条问不出步数，这条概念给不出预测——"
        "那一段由 counter_step_rate 顶上（它只查步进量，不反推步数）。"
        "v5 只改代码不改主张：换关那道 NA 原先只写在 `assert_` 里，`apply` 没查，"
        "于是在换关那一步照样认领一格、说「再烧一格」——而换关时计数条是**清零**的"
        "（那一步实测 18 格 → 0 格），方向都反了。这是本册第三条犯同一个错的概念"
        "（另两条是 bar_free_end_moves、bar_tip_follows），所以这次不是补一句 if，"
        "而是把 scope 判据挪进两边共用的 `_plan`：检查器和生成器从此不可能各守一套。"
        "**说错比不说严重**：不说只是地图空白，说错会被人照着算下一帧。"
        "\n\n**v6 在终局卡上被打，主张没动，改的还是同一处，而且正是 v5 那句话的下半段。**"
        "v5 把换关那道 scope 挪进了共用的 `_plan`，检查器和生成器从此守同一套——"
        "**但那一套查的是 `ctx[\"level_next\"]`，押注发生在这一步走之前，那时候它还不存在**。"
        "于是 ec8ffe6775dff87f 那一步（过关，计数条清零）生成器照旧说「再烧一格」，方向又反了。"
        "加一道前推的 `_lib.will_levelup`。"
        "**v5 学到的是「两边共用一道判据」，没学到的是「那道判据得在动作之前算得出来」**——"
        "共用一个事后才知道的量，等于两边都没守。")
EVIDENCE = ["218a829f43e66580", "df97f80daf9ccb1c", "1e5c6990b6e3714b",
            "ef152a513aa814a4", "85d47bb3a3b2ad9d",
            "f3ce3bd0fb651bb3", "194ff8f124e2a4d9", "de05a589d602e3bd",
            "64e2bc30cd0e77bc",
            # v6：换关那一步计数条清零，而「换关」原先只有事后才算得出来
            "ec8ffe6775dff87f"]

from _lib import (BUDGET_BY_LEVEL, CAP, COUNTER_CELLS, COUNTER_ROW, USED,
                  burn_at, burned, button, moves_used, will_levelup)


def _plan(prev, action, ctx):
    if ctx is None:
        return None
    if ctx["level_prev"] != ctx["level_next"]:
        return None                        # 换关：SCOPE 里就写着 NA，检查器和生成器共用这一道
    if will_levelup(prev, action) is True:
        return None                        # 同一道 scope 的前推版：押注时 ctx 里还没有 level_next
    budget = BUDGET_BY_LEVEL.get(ctx["level_prev"])
    if budget is None:
        return None
    if button(prev, action) is None:
        return None
    n = moves_used(prev, budget)
    if n is None or n >= budget:
        return None
    return burned(prev), burn_at(n + 1, budget)


def assert_(prev, action, nxt, ctx=None):
    p = _plan(prev, action, ctx)
    if p is None:
        return "NA"
    _b0, b1 = p
    for c in range(COUNTER_CELLS):
        want = USED if c >= COUNTER_CELLS - b1 else CAP
        if nxt[COUNTER_ROW][c] != want:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    p = _plan(prev, action, ctx)
    if p is None:
        return None
    b0, b1 = p
    return {(COUNTER_ROW, c): USED for c in range(COUNTER_CELLS - b1, COUNTER_CELLS - b0)} or None
