"""每一面「可推墙」（_lib.obstacles 里颜色不属于 _lib.FIXED_OBS 的那些死物格）的尺寸
——3 格厚、k 格长的那个 k——推它一下之后不变，只挪位置：同一次转移里，
prev 里各条墙的『k 值多重集』和 nxt 里各条墙的『k 值多重集』，至少有一种合法拆法能对上。"""
LEVEL = "L2"
SCOPE = ("换关返回 NA；prev、nxt 任意一边没有『非 FIXED_OBS 的死物格』（没有可推墙）返回 NA；"
         "任意一色的死物格穷举后仍有格子拆不进任何 3 格厚矩形条（残余格）返回 NA——"
         "这是算不出这个量，不是这个量被证伪；"
         "两条同色条**齐口顶在一起、谁都不穿过谁**时单帧可能有不止一种合法拆法，"
         "prev 的某一种合法读法和 nxt 的某一种合法读法只要有一组『各条 k 值排序后的元组』相同就判 TRUE，"
         "两边全部读法两两都对不上才判 FALSE。判的是**同一次转移前后**，不看这一关别的帧、不查历史。")
NOTE = ("这条主张是 wall_sticks_to_free_end 的 NOTE 里留的那个『下一步该问什么』：**若尺寸在一关之内不变，"
        "齐口拐角能不能靠尺寸唯一拆开**——但原话也警告『得说清尺寸是从哪一帧观测来的，apply 只看得见 prev，"
        "看不见历史』。这里给出的是把警告当真之后能写出来的最强版本：不做『这一关的墙一般是几』这种"
        "跨帧统计（那需要历史），只做『这一次推墙前后，长度对不对得上』这个单次转移内就能判的量——"
        "assert_ 同时看得见 prev 和 nxt，两帧都在这一次调用里，不是历史。\n"
        "在 runs/s5i5-0907-0046/transitions.jsonl 上核过（wallsize.py，去重后 tid 数 147，"
        "level_prev==2 的 105 条里，色 1（本局唯一出现过的『非 FIXED_OBS 死物』颜色）在 92 个不同帧上"
        "出现过；level_prev∈{0,1} 的 42 条、level_prev==3 的 0 条语料里色 1 从没出现过，"
        "这两关和第 3 关对这条主张『语料不足以判』，不是『不适用』）："
        "91/92 帧唯一拆解，逐条统一给出 {k=18, k=24} 两根（如 26c0b1510bdb91ca、3c79fccbc0893691）；"
        "剩下 1/92 帧（10aa75d6276bfffa 等触发的『两根贴上』瞬间）网络合并成一整块，"
        "但**仍然唯一**拆成 24+18（因为一根穿过接头，见 _lib.rigid_unit 的『穿过即唯一』分支）。\n"
        "真正的硬例是 b6f0ef03af8176dd（第 143 步）：这一帧 `_lib.refused` 判 None——"
        "`rigid_unit` 自己在这一类齐口拐角上放弃了（宁可算不出来也不猜）。"
        "但这条概念不靠 rigid_unit，靠穷举全部 3xk 矩形拆法：这一帧唯一能拆成 24+18，"
        "把 9 格接头判给横的还是竖的**在这一帧里其实有答案**，只是 rigid_unit 的判据比穷举保守。"
        "另一处硬例 bda3e01059155890（第 175 步，同一个按钮 ACTION6:16,57）是真正的两可：这一帧本身"
        "能唯一拆成 {15,27} 或 {18,24} 两种合法读法，单看这一帧真的定不下来——"
        "但它的 nxt（这次推墙推开之后）把两截墙分成了两个不再相邻的网络，各自唯一拆出 18 和 24。"
        "于是『prev 的某一种读法和 nxt 对得上』这一句在这里判 TRUE：{18,24} 同时是 prev 的一种合法"
        "读法、也是 nxt 唯一的读法。**没有用到历史，只用了这一次转移自己的 nxt**——"
        "这正是这条概念相对『再加一条单帧判据』（wall_sticks_to_free_end 里试过五次、全部失败）"
        "能往前挪的那一步：不猜单帧内选哪个，改问『这次推完之后长度保没保住』。\n"
        "**没验过的**：这一关只出现过 2 根墙、1 种真正的齐口两可局面，样本单薄；"
        "多于 2 根墙互相齐口、或者 3 根墙在一处打结的局面语料里 0 条，这条概念在那种局面下"
        "会不会漏判成 TRUE（凑巧多重集撞上）没有证据，是留白不是结论。")
EVIDENCE = ["26c0b1510bdb91ca", "3c79fccbc0893691", "10aa75d6276bfffa",
            "b6f0ef03af8176dd", "bda3e01059155890"]

from _lib import FIXED_OBS, SEG_W, TIP, diamond_centers, diamond_dots, obstacles
from geo import cells_of


def _markers(g):
    """透明格子：菱形四点 + 未压中的菱形中心（本色可能恰好等于某个墙色，不算墙）。"""
    dots = set(diamond_dots(g))
    centers = {rc for rc in diamond_centers(g) if g[rc[0]][rc[1]] != TIP}
    return dots | centers


def _components(cells_v, markers, n, m):
    """把某色的『墙候选格』（不含 markers）按『同色，或隔着 marker 相连』分成若干网络。"""
    seen, out = set(), []
    for start in sorted(cells_v):
        if start in seen:
            continue
        stack, comp = [start], set()
        seen.add(start)
        while stack:
            r, c = stack.pop()
            comp.add((r, c))
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nr, nc = r + dr, c + dc
                if not (0 <= nr < n and 0 <= nc < m) or (nr, nc) in seen:
                    continue
                if (nr, nc) in cells_v:
                    seen.add((nr, nc))
                    stack.append((nr, nc))
                elif (nr, nc) in markers:
                    for dr2, dc2 in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nr2, nc2 = nr + dr2, nc + dc2
                        if (nr2, nc2) in cells_v and (nr2, nc2) not in seen:
                            seen.add((nr2, nc2))
                            stack.append((nr2, nc2))
        out.append(comp)
    return out


def _decompose(g, v, markers, network_cells, n, m):
    """把一个网络穷举拆成若干根 3 格厚矩形条的全部合法拆法，返回 [(k1, k2, ...), ...]；
    拆不干净（有残余格）返回 []——调用方把 [] 读成『算不出来』。"""
    def eff(r, c):
        if not (0 <= r < n and 0 <= c < m):
            return None
        return v if (r, c) in markers else g[r][c]

    def run_thick(r, c, axis):
        lo = hi = (r if axis == 0 else c)
        while True:
            x = lo - 1
            rr, cc = (x, c) if axis == 0 else (r, x)
            if eff(rr, cc) != v:
                break
            lo = x
        while True:
            x = hi + 1
            rr, cc = (x, c) if axis == 0 else (r, x)
            if eff(rr, cc) != v:
                break
            hi = x
        return lo, hi

    def band_funcs(axis, lo, hi):
        def cells_at(p):
            return [((x, p) if axis == 0 else (p, x)) for x in range(lo, hi + 1)]

        def band_ok(p):
            return all(eff(rr, cc) == v for rr, cc in cells_at(p))

        def touches_perp(p):
            for x in (lo - 1, hi + 1):
                rr, cc = (x, p) if axis == 0 else (p, x)
                if 0 <= rr < n and 0 <= cc < m and eff(rr, cc) == v:
                    return True
            return False

        def crossed_both(p):
            for x in (lo - 1, hi + 1):
                rr, cc = (x, p) if axis == 0 else (p, x)
                if not (0 <= rr < n and 0 <= cc < m) or eff(rr, cc) != v:
                    return False
            return True

        def passes_through(p, step):
            q = p
            while band_ok(q) and touches_perp(q):
                q += step
            return band_ok(q)

        return band_ok, touches_perp, crossed_both, passes_through

    def grow_ends(seed_p, axis, lo, hi):
        band_ok, touches_perp, crossed_both, passes_through = band_funcs(axis, lo, hi)

        def rec(p, step):
            if not band_ok(p):
                return [p - step]
            if not touches_perp(p):
                return rec(p + step, step)
            if passes_through(p, step):
                return rec(p + step, step)
            if crossed_both(p):
                return [p - step]
            return [p - step] + rec(p + step, step)   # 齐口拐角：两支都留，不猜

        return rec(seed_p - 1, -1), rec(seed_p + 1, +1)

    def candidates(anchor, remaining):
        r, c = anchor
        out = []
        for axis in (0, 1):
            lo, hi = run_thick(r, c, axis)
            if hi - lo + 1 != SEG_W:
                continue
            seed_p = c if axis == 0 else r
            lo_opts, hi_opts = grow_ends(seed_p, axis, lo, hi)
            for lo_p in lo_opts:
                for hi_p in hi_opts:
                    if lo_p > hi_p:
                        continue
                    if axis == 0:
                        cov = {(rr, cc) for rr in range(lo, hi + 1) for cc in range(lo_p, hi_p + 1)
                               if g[rr][cc] == v and (rr, cc) not in markers}
                    else:
                        cov = {(rr, cc) for rr in range(lo_p, hi_p + 1) for cc in range(lo, hi + 1)
                               if g[rr][cc] == v and (rr, cc) not in markers}
                    if not cov <= remaining:
                        continue
                    out.append((hi_p - lo_p + 1, frozenset(cov)))
        return out

    results = []

    def search(remaining, acc):
        if not remaining:
            results.append(tuple(sorted(acc)))
            return
        anchor = min(remaining)
        cs = candidates(anchor, remaining)
        if not cs:
            return
        for k, cov in cs:
            search(remaining - cov, acc + [k])

    search(frozenset(network_cells), [])
    return sorted(set(results))


def _frame_k_multisets(g):
    """这一帧全部『可推墙』（非 FIXED_OBS 的死物色）的 k 多重集，每种合法拆法读法各一份；
    某个网络怎么拆都剩残余格时返回 None（算不出来，不是没有可推墙）。"""
    n, m = len(g), len(g[0])
    obs = obstacles(g)
    colors = sorted({g[r][c] for r, c in obs if g[r][c] not in FIXED_OBS})
    if not colors:
        return set()
    markers = _markers(g)
    combined_all = [()]
    for v in colors:
        cells_v = set(cells_of(g, v)) - markers
        nets = _components(cells_v, markers, n, m)
        combined_color = [()]
        for net in nets:
            decs = _decompose(g, v, markers, net, n, m)
            if not decs:
                return None
            combined_color = [c + d for c in combined_color for d in decs]
        combined_all = [a + b for a in combined_all for b in combined_color]
    return {tuple(sorted(x)) for x in combined_all}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    pv = _frame_k_multisets(prev)
    nx = _frame_k_multisets(nxt)
    if pv is None or nx is None:
        return "NA"
    if not pv or not nx:
        return "NA"
    return "TRUE" if (pv & nx) else "FALSE"
