/-
# Obs/Corpus/Verdict —— 逐条那一层的判决（**自动生成**；生成器 `lean2/export_corpus.py`）

每条都从**观测到的那一帧**起算一步（模型每步被拉回正轨——三条腿里较弱的那一半；
较强的那一半是 `Proof/Levels.lean`：从开局起一路带着自己算出来的状态走）。
-/

import Obs.Replay

namespace Game
namespace Corpus

open Replay

/-- 1 对上 · 2 判错 · 0 说不出话。 -/
def verdictRow (r : Row) : Nat :=
  if r.mark == 2 || !r.prev.clean then 0 else
  match after (r.prev.toWorld r.board) r.act with
  | none => 0
  | some w' =>
    if r.mark == 1 then (if isGoal w' then 1 else 2)
    else if r.next.unsure then 0
    else if agrees w' r.next && !isGoal w' then 1 else 2

/-- 一块：按 seq 挑出来的行，各自的 (seq, 判决)。 -/
def judge (seqs : List Nat) : List (Nat × Nat) :=
  (rows.filter (fun r => seqs.contains r.seq)).map (fun r => (r.seq, verdictRow r))

end Corpus
end Game
