/-
# Obs/Check —— **判据层**：模型面对现实的两把尺子（0 条定理，尺子不自证）

    agrees    一帧对不对：模型算出来的世界，和这一帧读出来的对不对得上
    traceOk   一整条路：从开局起**带着模型自己算出来的状态**往下走，逐帧比

## 观测比世界少一位信息，比法写在明处

帧上读出来的条可能 `clipped`（自由端出了盘，长度只知道下界）。那时只比盘上看得见的那一截：
**看得见的长度相等、模型的长度不短于它、帧上有尖则模型也有尖**。
这和 Python 那一份（`rule/_common.py` 的 `same_bar`）是同一个口径，两份各自独立写，
由 `lean2/verify.py` 逐条对账。

计费行不比（不进模型）。盘面在「每关」那一层取自开局，在「逐条」那一层取自这一帧。
-/

import Step

namespace Game

/-- 帧上读出来的一根条。 -/
structure ObsBar where
  color   : Nat
  r       : Nat
  c       : Nat
  dir     : Dir
  len     : Nat
  tip     : Bool
  clipped : Bool
  deriving DecidableEq, Repr

/-- 帧上读出来的会动的那一组。`unsure` = 这一帧读法说不清（同色两根首尾相顶）。 -/
structure Obs where
  bars   : List ObsBar
  walls  : List Wall
  unsure : Bool
  deriving DecidableEq, Repr

/-- 盘上看得见的身体有几条（从帽往外连续整条落在盘上的）。 -/
def visLen (b : Bar) : Nat :=
  match b.dir with
  | .D => if Nat.ble O b.c && Nat.ble (b.c + 2) (O + 62 + 1) then min b.len ((O + 62) - b.r) else 0
  | .U => if Nat.ble O b.c && Nat.ble (b.c + 2) (O + 62 + 1) then min b.len (b.r - O) else 0
  | .R => if Nat.ble O b.r && Nat.ble (b.r + 2) (O + 62) then min b.len ((O + 63) - b.c) else 0
  | .L => if Nat.ble O b.r && Nat.ble (b.r + 2) (O + 62) then min b.len (b.c - O) else 0

def barAgrees (m : Bar) (o : ObsBar) : Bool :=
  m.color == o.color && m.r == o.r && m.c == o.c && m.dir == o.dir &&
  (if o.clipped then visLen m == o.len && Nat.ble o.len m.len && (m.tip || !o.tip)
   else m.len == o.len && m.tip == o.tip)

def wallsSame (a b : List Wall) : Bool :=
  a.length == b.length && a.all (fun x => b.contains x) && b.all (fun x => a.contains x)

/-- 模型的世界 `w` 和这一帧 `o` 对得上吗。 -/
def agrees (w : World) (o : Obs) : Bool :=
  w.bars.length == o.bars.length &&
  o.bars.all (fun ob => w.bars.any (fun m => barAgrees m ob)) &&
  wallsSame w.walls o.walls

/-- 帧上读出来的当成模型的输入（丢掉 `clipped`：这就是它只在没有 `clipped` 时才用的原因）。 -/
def Obs.toWorld (o : Obs) (bd : Board) : World :=
  { board := bd, bars := o.bars.map (fun b => ⟨b.color, b.r, b.c, b.dir, b.len, b.tip⟩), walls := o.walls }

def Obs.clean (o : Obs) : Bool := !o.unsure && o.bars.all (fun b => !b.clipped)

/-- 一步之后应当是哪一帧：作废 = 原样。 -/
def after (w : World) (a : Act) : Option World :=
  match step w a with
  | .ok w' => some w'
  | .refused => some w
  | .silent => none

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**喂进下一轮的是模型自己算出来的状态。** -/
def traceOk : World → List (Act × Obs) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match after s a with
    | some s' => agrees s' o && traceOk s' rest
    | none => false

/-- 只给读数用：第一处分家在第几步（`none` = 一处都没分家）。读数不是定理。 -/
def firstSplit : World → List (Act × Obs) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match after s a with
    | some s' => if agrees s' o then firstSplit s' rest (i + 1) else some i
    | none => some i

/-- 沿一串动作走，中途有没有哪一刻是赢面。遇到模型说不出话（RESET）的一支就停下算没赢——
    所以「赢不了」的准确意思是「不经过 RESET 就赢不了」。 -/
def everGoal : World → List Act → Bool
  | w, [] => isGoal w
  | w, a :: as => isGoal w ||
    match after w a with
    | some w' => everGoal w' as
    | none => false

/-- 这一关走得通：存在一串动作，照着走中途赢过。 -/
def Winnable (w : World) : Prop := ∃ as : List Act, everGoal w as = true

/-- 这一关走不通：任何一串动作照着走都没赢过（不经过 RESET）。 -/
def Unsolvable (w : World) : Prop := ∀ as : List Act, everGoal w as = false

end Game
