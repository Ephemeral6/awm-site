/-
# Obs/Replay —— 整条轨迹，**只存这一份**（自动生成，不要手改；生成器 `lean2/export_replay.py`）

逐条那一层（`Obs/Corpus.lean`）和每关那一层（`Proof/Levels.lean`）都从这里切。

    rows      全部 2618 行语料（含 RESET、换关、不在认证段里的），按 `seq` 排
    键        `seq`（唯一，已数过；`step` 有 16 处重号，不用它）
    盘面      只有一个口径：每一帧真正读到的那张（解析往返逐格还原，没有被遮住的盘面格）
    标记      0 关内一步 · 1 过关（下一帧是下一关的盘）· 2 RESET · 3 读不成（本批 0 行）
-/

import Obs.Check

namespace Game
namespace Replay

structure Row where
  seq   : Nat
  lvl   : Nat
  mark  : Nat
  cert  : Bool
  act   : Act
  board : Board
  prev  : Obs
  next  : Obs


def bd0 : Board := { panels := [⟨14, ⟨118, 136, 124, 148⟩, (121, 139), (121, 145)⟩, ⟨11, ⟨135, 121, 147, 127⟩, (138, 124), (144, 124)⟩], legends := [], diamonds := [⟨110, 152⟩, ⟨152, 110⟩], hubs := [], fixed := [] }
def bd1 : Board := { panels := [⟨12, ⟨154, 103, 160, 115⟩, (157, 106), (157, 112)⟩, ⟨10, ⟨154, 118, 160, 130⟩, (157, 121), (157, 127)⟩, ⟨11, ⟨154, 133, 160, 145⟩, (157, 136), (157, 142)⟩, ⟨14, ⟨154, 148, 160, 160⟩, (157, 151), (157, 157)⟩], legends := [], diamonds := [⟨131, 152⟩], hubs := [], fixed := [⟨109, 133, 111, 156⟩, ⟨112, 133, 126, 135⟩, ⟨115, 142, 144, 144⟩] }
def bd2 : Board := { panels := [⟨8, ⟨145, 107, 151, 119⟩, (148, 110), (148, 116)⟩, ⟨10, ⟨145, 126, 151, 138⟩, (148, 129), (148, 135)⟩, ⟨12, ⟨145, 145, 151, 157⟩, (148, 148), (148, 154)⟩, ⟨9, ⟨154, 107, 160, 119⟩, (157, 110), (157, 116)⟩, ⟨7, ⟨154, 126, 160, 138⟩, (157, 129), (157, 135)⟩, ⟨14, ⟨154, 145, 160, 157⟩, (157, 148), (157, 154)⟩], legends := [], diamonds := [⟨128, 143⟩, ⟨128, 149⟩], hubs := [], fixed := [⟨127, 145, 129, 147⟩] }
def bd3 : Board := { panels := [⟨14, ⟨145, 103, 151, 115⟩, (148, 106), (148, 112)⟩, ⟨9, ⟨145, 148, 151, 160⟩, (148, 151), (148, 157)⟩, ⟨11, ⟨151, 125, 157, 137⟩, (154, 128), (154, 134)⟩, ⟨12, ⟨154, 103, 160, 115⟩, (157, 106), (157, 112)⟩, ⟨8, ⟨154, 148, 160, 160⟩, (157, 151), (157, 157)⟩], legends := [], diamonds := [⟨110, 131⟩], hubs := [], fixed := [] }
def bd4 : Board := { panels := [⟨9, ⟨155, 104, 159, 114⟩, (157, 106), (157, 112)⟩, ⟨12, ⟨155, 119, 159, 129⟩, (157, 121), (157, 127)⟩, ⟨14, ⟨155, 134, 159, 144⟩, (157, 136), (157, 142)⟩, ⟨10, ⟨155, 149, 159, 159⟩, (157, 151), (157, 157)⟩], legends := [], diamonds := [⟨125, 137⟩, ⟨137, 122⟩], hubs := [], fixed := [⟨109, 115, 117, 117⟩, ⟨121, 115, 126, 117⟩, ⟨136, 136, 138, 138⟩] }
def bd5 : Board := { panels := [⟨9, ⟨154, 106, 160, 118⟩, (157, 109), (157, 115)⟩, ⟨11, ⟨154, 125, 160, 137⟩, (157, 128), (157, 134)⟩, ⟨14, ⟨154, 144, 160, 156⟩, (157, 147), (157, 153)⟩], legends := [⟨9, ⟨145, 109, 151, 115⟩⟩, ⟨11, ⟨145, 128, 151, 134⟩⟩, ⟨14, ⟨145, 147, 151, 153⟩⟩], diamonds := [⟨134, 152⟩], hubs := [], fixed := [⟨127, 103, 129, 108⟩, ⟨127, 118, 129, 159⟩, ⟨130, 103, 141, 105⟩, ⟨130, 157, 138, 159⟩, ⟨139, 145, 141, 159⟩] }
def bd6 : Board := { panels := [⟨11, ⟨149, 102, 153, 112⟩, (151, 104), (151, 110)⟩, ⟨9, ⟨149, 124, 153, 134⟩, (151, 126), (151, 132)⟩, ⟨10, ⟨149, 152, 153, 162⟩, (151, 154), (151, 160)⟩, ⟨14, ⟨156, 102, 160, 112⟩, (158, 104), (158, 110)⟩, ⟨12, ⟨156, 124, 160, 134⟩, (158, 126), (158, 132)⟩], legends := [⟨11, ⟨149, 115, 153, 119⟩⟩, ⟨9, ⟨149, 137, 153, 141⟩⟩, ⟨14, ⟨156, 115, 160, 119⟩⟩, ⟨8, ⟨156, 158, 160, 162⟩⟩], diamonds := [⟨107, 122⟩, ⟨116, 125⟩], hubs := [], fixed := [⟨100, 139, 126, 141⟩, ⟨127, 100, 129, 105⟩, ⟨127, 109, 129, 129⟩, ⟨127, 133, 129, 141⟩, ⟨130, 115, 138, 117⟩, ⟨142, 115, 144, 117⟩, ⟨145, 100, 147, 163⟩] }
def bd7 : Board := { panels := [⟨9, ⟨102, 137, 106, 147⟩, (104, 139), (104, 145)⟩, ⟨12, ⟨102, 151, 106, 161⟩, (104, 153), (104, 159)⟩, ⟨8, ⟨109, 137, 113, 147⟩, (111, 139), (111, 145)⟩, ⟨14, ⟨109, 151, 113, 161⟩, (111, 153), (111, 159)⟩, ⟨10, ⟨154, 106, 158, 116⟩, (156, 108), (156, 114)⟩, ⟨7, ⟨154, 120, 158, 130⟩, (156, 122), (156, 128)⟩], legends := [⟨11, ⟨115, 146, 121, 152⟩⟩], diamonds := [⟨143, 119⟩], hubs := [⟨11, 132, 148⟩], fixed := [⟨121, 112, 123, 114⟩, ⟨123, 139, 125, 159⟩, ⟨126, 139, 140, 141⟩, ⟨126, 157, 140, 159⟩, ⟨141, 139, 143, 147⟩, ⟨141, 151, 143, 159⟩, ⟨142, 124, 144, 126⟩] }

def o0 : Obs := { bars := [⟨14, 109, 127, .R, 5, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o1 : Obs := { bars := [⟨14, 109, 127, .R, 8, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o2 : Obs := { bars := [⟨14, 109, 127, .R, 8, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o3 : Obs := { bars := [⟨14, 109, 127, .R, 5, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o4 : Obs := { bars := [⟨14, 109, 127, .R, 11, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o5 : Obs := { bars := [⟨14, 109, 127, .R, 14, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o6 : Obs := { bars := [⟨14, 109, 127, .R, 17, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o7 : Obs := { bars := [⟨14, 109, 127, .R, 20, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o8 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o9 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 14, true, false⟩], walls := [], unsure := false }
def o10 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 17, true, false⟩], walls := [], unsure := false }
def o11 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 20, true, false⟩], walls := [], unsure := false }
def o12 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 23, true, false⟩], walls := [], unsure := false }
def o13 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 23, true, false⟩], walls := [], unsure := false }
def o14 : Obs := { bars := [⟨11, 136, 112, .R, 2, false, false⟩, ⟨14, 136, 115, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 2, false, false⟩, ⟨10, 141, 112, .U, 2, false, false⟩], walls := [], unsure := false }
def o15 : Obs := { bars := [⟨11, 136, 115, .R, 2, false, false⟩, ⟨14, 136, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 2, false, false⟩], walls := [], unsure := false }
def o16 : Obs := { bars := [⟨11, 136, 118, .R, 2, false, false⟩, ⟨14, 136, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o17 : Obs := { bars := [⟨11, 136, 121, .R, 2, false, false⟩, ⟨14, 136, 124, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 2, false, false⟩], walls := [], unsure := false }
def o18 : Obs := { bars := [⟨11, 136, 124, .R, 2, false, false⟩, ⟨14, 136, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 2, false, false⟩], walls := [], unsure := false }
def o19 : Obs := { bars := [⟨11, 136, 127, .R, 2, false, false⟩, ⟨14, 136, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 2, false, false⟩], walls := [], unsure := false }
def o20 : Obs := { bars := [⟨11, 136, 130, .R, 2, false, false⟩, ⟨14, 136, 133, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 2, false, false⟩], walls := [], unsure := false }
def o21 : Obs := { bars := [⟨11, 136, 133, .R, 2, false, false⟩, ⟨14, 136, 136, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 23, false, false⟩, ⟨10, 141, 133, .U, 2, false, false⟩], walls := [], unsure := false }
def o22 : Obs := { bars := [⟨11, 136, 136, .R, 2, false, false⟩, ⟨14, 136, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 2, false, false⟩], walls := [], unsure := false }
def o23 : Obs := { bars := [⟨11, 133, 136, .R, 2, false, false⟩, ⟨14, 133, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 5, false, false⟩], walls := [], unsure := false }
def o24 : Obs := { bars := [⟨11, 130, 136, .R, 2, false, false⟩, ⟨14, 130, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 8, false, false⟩], walls := [], unsure := false }
def o25 : Obs := { bars := [⟨11, 127, 136, .R, 2, false, false⟩, ⟨14, 127, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 11, false, false⟩], walls := [], unsure := false }
def o26 : Obs := { bars := [⟨11, 124, 136, .R, 2, false, false⟩, ⟨14, 124, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 14, false, false⟩], walls := [], unsure := false }
def o27 : Obs := { bars := [⟨11, 121, 136, .R, 2, false, false⟩, ⟨14, 121, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 17, false, false⟩], walls := [], unsure := false }
def o28 : Obs := { bars := [⟨11, 118, 136, .R, 2, false, false⟩, ⟨14, 118, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 20, false, false⟩], walls := [], unsure := false }
def o29 : Obs := { bars := [⟨11, 115, 136, .R, 2, false, false⟩, ⟨14, 115, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 23, false, false⟩], walls := [], unsure := false }
def o30 : Obs := { bars := [⟨11, 112, 136, .R, 2, false, false⟩, ⟨14, 112, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 26, false, false⟩, ⟨10, 141, 136, .U, 26, false, false⟩], walls := [], unsure := false }
def o31 : Obs := { bars := [⟨11, 112, 139, .R, 2, false, false⟩, ⟨14, 112, 142, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o32 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o33 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o34 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o35 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o36 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o37 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o38 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o39 : Obs := { bars := [⟨11, 112, 139, .R, 11, false, false⟩, ⟨14, 112, 151, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o40 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o41 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 23, false, false⟩], walls := [⟨1, ⟨112, 127, 114, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o42 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 20, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 23, false, false⟩], walls := [⟨1, ⟨112, 127, 114, 150⟩⟩, ⟨1, ⟨121, 133, 138, 135⟩⟩], unsure := false }
def o43 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 20, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 133, 138, 135⟩⟩], unsure := false }
def o44 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 20, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 133, 138, 135⟩⟩], unsure := false }
def o45 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o46 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 14, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 139, 138, 141⟩⟩], unsure := false }
def o47 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o48 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 5, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o49 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o50 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o51 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o52 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o53 : Obs := { bars := [⟨7, 103, 148, .D, 2, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 20, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 127, 120, 150⟩⟩, ⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o54 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o55 : Obs := { bars := [⟨7, 103, 148, .D, 8, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o56 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o57 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 5, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o58 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o59 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o60 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o61 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o62 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o63 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o64 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 121, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 124, 120, 147⟩⟩, ⟨1, ⟨121, 136, 138, 138⟩⟩], unsure := false }
def o65 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 136, 135, 138⟩⟩], unsure := false }
def o66 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 20, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 133, 135, 135⟩⟩], unsure := false }
def o67 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 23, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 130, 135, 132⟩⟩], unsure := false }
def o68 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 26, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 127, 135, 129⟩⟩], unsure := false }
def o69 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 118, 156, .L, 26, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 127, 135, 129⟩⟩], unsure := false }
def o70 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 14, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o71 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o72 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 124, 117, 147⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o73 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 8, false, false⟩, ⟨8, 138, 121, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 121, 117, 144⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o74 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 8, false, false⟩, ⟨8, 138, 121, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 121, 117, 144⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o75 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 118, 117, 141⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o76 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 118, 117, 141⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o77 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 115, 117, 138⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o78 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 17, false, false⟩], walls := [⟨1, ⟨118, 115, 120, 138⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o79 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨121, 115, 123, 138⟩⟩], unsure := false }
def o80 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 11, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨124, 115, 126, 138⟩⟩], unsure := false }
def o81 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 8, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨127, 115, 129, 138⟩⟩], unsure := false }
def o82 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o83 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o84 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o85 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o86 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 20, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o87 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 23, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o88 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 26, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o89 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 29, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o90 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 32, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o91 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o92 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 5, false, false⟩], walls := [⟨1, ⟨121, 142, 138, 144⟩⟩, ⟨1, ⟨130, 115, 132, 138⟩⟩], unsure := false }
def o93 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 121, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 2, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 5, false, false⟩], walls := [⟨1, ⟨121, 142, 138, 144⟩⟩, ⟨1, ⟨130, 118, 132, 141⟩⟩], unsure := false }
def o94 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 5, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨130, 118, 132, 141⟩⟩], unsure := false }
def o95 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 2, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨133, 118, 135, 141⟩⟩], unsure := false }
def o96 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o97 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o98 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 115, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 8, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨115, 142, 132, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o99 : Obs := { bars := [⟨7, 103, 148, .D, 8, true, false⟩, ⟨12, 115, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 8, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨115, 142, 132, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o100 : Obs := { bars := [⟨7, 103, 148, .D, 8, true, false⟩, ⟨12, 112, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 11, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 142, 129, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o101 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 112, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 11, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 142, 129, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o102 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 142, 126, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o103 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 142, 126, 144⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o104 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 145, 126, 147⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o105 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 5, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 148, 126, 150⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o106 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o107 : Obs := { bars := [⟨7, 103, 148, .D, 8, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o108 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o109 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o110 : Obs := { bars := [⟨7, 103, 148, .D, 17, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o111 : Obs := { bars := [⟨7, 103, 148, .D, 20, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o112 : Obs := { bars := [⟨7, 103, 148, .D, 23, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 38, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨133, 115, 135, 138⟩⟩], unsure := false }
def o113 : Obs := { bars := [⟨11, 112, 153, .L, 2, false, false⟩, ⟨11, 115, 109, .R, 2, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 124, 118, .R, 2, false, false⟩, ⟨11, 144, 130, .U, 2, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o114 : Obs := { bars := [⟨11, 112, 153, .L, 5, false, false⟩, ⟨11, 115, 109, .R, 5, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 5, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 124, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o115 : Obs := { bars := [⟨11, 112, 153, .L, 5, false, false⟩, ⟨11, 115, 109, .R, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o116 : Obs := { bars := [⟨11, 112, 153, .L, 8, false, false⟩, ⟨11, 115, 109, .R, 8, false, false⟩, ⟨11, 115, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 8, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o117 : Obs := { bars := [⟨11, 112, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o118 : Obs := { bars := [⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 109, .R, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 14, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o119 : Obs := { bars := [⟨11, 112, 153, .L, 17, false, false⟩, ⟨11, 115, 109, .R, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 17, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o120 : Obs := { bars := [⟨11, 112, 109, .R, 17, false, false⟩, ⟨11, 112, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 5, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 17, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o121 : Obs := { bars := [⟨11, 112, 109, .R, 17, false, false⟩, ⟨11, 112, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 5, false, false⟩, ⟨11, 121, 118, .R, 17, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o122 : Obs := { bars := [⟨11, 112, 109, .R, 20, false, false⟩, ⟨11, 112, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 5, false, false⟩, ⟨11, 121, 118, .R, 20, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o123 : Obs := { bars := [⟨11, 109, 109, .R, 20, false, false⟩, ⟨11, 112, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨11, 121, 118, .R, 20, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o124 : Obs := { bars := [⟨11, 109, 109, .R, 20, false, false⟩, ⟨11, 112, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o125 : Obs := { bars := [⟨11, 109, 109, .R, 23, false, false⟩, ⟨11, 112, 153, .L, 23, false, false⟩, ⟨11, 115, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o126 : Obs := { bars := [⟨11, 106, 109, .R, 23, false, false⟩, ⟨11, 112, 153, .L, 23, false, false⟩, ⟨11, 115, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o127 : Obs := { bars := [⟨11, 106, 109, .R, 23, false, false⟩, ⟨11, 109, 153, .L, 23, false, false⟩, ⟨11, 115, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o128 : Obs := { bars := [⟨11, 106, 109, .R, 23, false, false⟩, ⟨11, 109, 153, .L, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o129 : Obs := { bars := [⟨11, 106, 109, .R, 23, false, false⟩, ⟨11, 109, 153, .L, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨11, 115, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o130 : Obs := { bars := [⟨11, 106, 109, .R, 26, false, false⟩, ⟨11, 109, 153, .L, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o131 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 109, 153, .L, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o132 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o133 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o134 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o135 : Obs := { bars := [⟨11, 112, 153, .L, 2, false, false⟩, ⟨11, 115, 109, .R, 2, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 2, false, false⟩, ⟨11, 144, 130, .U, 2, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o136 : Obs := { bars := [⟨11, 112, 153, .L, 5, false, false⟩, ⟨11, 115, 109, .R, 5, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 5, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o137 : Obs := { bars := [⟨11, 112, 153, .L, 8, false, false⟩, ⟨11, 115, 109, .R, 8, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 8, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 8, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o138 : Obs := { bars := [⟨11, 112, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o139 : Obs := { bars := [⟨11, 109, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o140 : Obs := { bars := [⟨11, 106, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o141 : Obs := { bars := [⟨11, 103, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o142 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o143 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 112, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 5, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o144 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 109, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o145 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 106, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o146 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨11, 118, 147, .L, 11, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 2, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o147 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o148 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 112, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o149 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 109, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o150 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 127, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o151 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 130, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 20, false, false⟩], walls := [], unsure := false }
def o152 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 133, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 17, false, false⟩], walls := [], unsure := true }
def o153 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 136, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o154 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 139, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o155 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 142, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o156 : Obs := { bars := [⟨11, 100, 153, .L, 11, false, false⟩, ⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨11, 145, 118, .R, 11, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o157 : Obs := { bars := [⟨11, 100, 153, .L, 14, false, false⟩, ⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨11, 145, 118, .R, 14, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o158 : Obs := { bars := [⟨11, 100, 153, .L, 17, false, false⟩, ⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨11, 145, 118, .R, 17, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o159 : Obs := { bars := [⟨11, 100, 153, .L, 20, false, false⟩, ⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨11, 145, 118, .R, 20, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o160 : Obs := { bars := [⟨11, 100, 153, .L, 20, false, false⟩, ⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨11, 148, 118, .R, 20, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o161 : Obs := { bars := [⟨11, 100, 153, .L, 23, false, false⟩, ⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨11, 148, 118, .R, 23, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o162 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 147, .L, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨11, 148, 118, .R, 26, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o163 : Obs := { bars := [⟨11, 100, 153, .L, 29, false, false⟩, ⟨11, 103, 109, .R, 29, false, false⟩, ⟨11, 106, 147, .L, 29, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 29, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o164 : Obs := { bars := [⟨11, 100, 153, .L, 32, false, false⟩, ⟨11, 103, 109, .R, 32, false, false⟩, ⟨11, 106, 147, .L, 32, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 32, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o165 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 130, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 130, 147, 132⟩⟩], unsure := false }
def o166 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o167 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o168 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o169 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o170 : Obs := { bars := [⟨12, 106, 109, .D, 8, false, false⟩, ⟨12, 106, 142, .D, 8, false, false⟩, ⟨14, 115, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o171 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o172 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o173 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o174 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o175 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨14, 127, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o176 : Obs := { bars := [⟨12, 106, 109, .D, 23, false, false⟩, ⟨12, 106, 142, .D, 23, false, false⟩, ⟨10, 124, 121, .R, 20, true, false⟩, ⟨14, 130, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o177 : Obs := { bars := [⟨12, 106, 109, .D, 23, false, false⟩, ⟨12, 106, 142, .D, 23, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 130, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o178 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 127, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o179 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 127, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 130, 147, 132⟩⟩], unsure := false }
def o180 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o181 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o182 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o183 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o184 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o185 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o186 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o187 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 124, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 130, 141, 132⟩⟩], unsure := false }
def o188 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 23, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 130, 138, 132⟩⟩], unsure := false }
def o189 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 23, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 130, 135, 132⟩⟩], unsure := false }
def o190 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 20, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 133, 135, 135⟩⟩], unsure := false }
def o191 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 17, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 136, 135, 138⟩⟩], unsure := false }
def o192 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 14, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o193 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 11, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o194 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o195 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o196 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o197 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o198 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o199 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o200 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o201 : Obs := { bars := [⟨12, 106, 109, .D, 23, false, false⟩, ⟨12, 106, 142, .D, 23, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 130, 109, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o202 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 133, 109, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o203 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩, ⟨14, 136, 109, .R, 5, true, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o204 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩, ⟨14, 136, 109, .R, 8, true, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o205 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩, ⟨14, 136, 109, .R, 11, true, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o206 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩, ⟨14, 136, 109, .R, 14, true, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o207 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩, ⟨14, 136, 109, .R, 14, true, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o208 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩, ⟨14, 136, 109, .R, 14, true, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o209 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .D, 5, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o210 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .D, 8, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o211 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .D, 11, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o212 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .D, 14, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o213 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o214 : Obs := { bars := [⟨11, 109, 139, .R, 11, false, false⟩, ⟨9, 109, 151, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o215 : Obs := { bars := [⟨11, 109, 139, .R, 14, false, false⟩, ⟨9, 109, 154, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o216 : Obs := { bars := [⟨11, 109, 139, .R, 17, false, false⟩, ⟨9, 109, 157, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o217 : Obs := { bars := [⟨11, 109, 139, .R, 20, false, false⟩, ⟨9, 109, 160, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o218 : Obs := { bars := [⟨11, 109, 139, .R, 20, false, false⟩, ⟨9, 109, 160, .D, 20, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o219 : Obs := { bars := [⟨11, 109, 139, .R, 8, false, false⟩, ⟨9, 109, 148, .R, 5, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o220 : Obs := { bars := [⟨9, 102, 139, .U, 2, false, true⟩, ⟨11, 111, 139, .U, 8, false, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o221 : Obs := { bars := [⟨9, 115, 126, .L, 5, true, false⟩, ⟨11, 115, 135, .L, 8, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩], walls := [], unsure := false }
def o222 : Obs := { bars := [⟨9, 115, 126, .L, 2, true, false⟩, ⟨11, 115, 135, .L, 8, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩], walls := [], unsure := false }
def o223 : Obs := { bars := [⟨11, 115, 133, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 124, 133, .D, 2, true, false⟩], walls := [], unsure := false }
def o224 : Obs := { bars := [⟨11, 115, 133, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 124, 133, .R, 2, true, false⟩], walls := [], unsure := false }
def o225 : Obs := { bars := [⟨11, 115, 130, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩, ⟨9, 124, 130, .R, 2, true, false⟩], walls := [], unsure := false }
def o226 : Obs := { bars := [⟨11, 115, 127, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨9, 124, 127, .R, 2, true, false⟩], walls := [], unsure := false }
def o227 : Obs := { bars := [⟨11, 115, 124, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨9, 124, 124, .R, 2, true, false⟩], walls := [], unsure := false }
def o228 : Obs := { bars := [⟨11, 115, 121, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 17, false, false⟩, ⟨9, 124, 121, .R, 2, true, false⟩], walls := [], unsure := false }
def o229 : Obs := { bars := [⟨11, 115, 118, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 20, false, false⟩, ⟨9, 124, 118, .R, 2, true, false⟩], walls := [], unsure := false }
def o230 : Obs := { bars := [⟨11, 115, 115, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 124, 115, .R, 2, true, false⟩], walls := [], unsure := false }
def o231 : Obs := { bars := [⟨11, 115, 115, .D, 11, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 127, 115, .R, 2, true, false⟩], walls := [], unsure := false }
def o232 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 2, true, false⟩], walls := [], unsure := false }
def o233 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 2, true, false⟩], walls := [], unsure := false }
def o234 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 5, true, false⟩], walls := [], unsure := false }
def o235 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 8, true, false⟩], walls := [], unsure := false }
def o236 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 11, true, false⟩], walls := [], unsure := false }
def o237 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 14, true, false⟩], walls := [], unsure := false }
def o238 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 17, true, false⟩], walls := [], unsure := false }
def o239 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 20, true, false⟩], walls := [], unsure := false }
def o240 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 23, true, false⟩], walls := [], unsure := false }
def o241 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 26, true, false⟩], walls := [], unsure := false }
def o242 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 29, true, false⟩], walls := [], unsure := false }
def o243 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 32, true, false⟩], walls := [], unsure := false }
def o244 : Obs := { bars := [⟨11, 115, 115, .D, 17, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 133, 115, .R, 35, true, false⟩], walls := [], unsure := false }
def o245 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 5, false, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩, ⟨12, 115, 156, .L, 2, true, false⟩], walls := [], unsure := false }
def o246 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o247 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .R, 2, false, false⟩, ⟨12, 109, 157, .D, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o248 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 106, 154, .R, 2, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 111, 154, .U, 2, false, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o249 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 11, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o250 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 8, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o251 : Obs := { bars := [⟨8, 106, 112, .R, 14, false, false⟩, ⟨10, 106, 135, .L, 8, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o252 : Obs := { bars := [⟨10, 106, 135, .L, 8, true, false⟩, ⟨8, 108, 112, .U, 8, false, true⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o253 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 8, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o254 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 11, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o255 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨14, 109, 148, .R, 5, false, false⟩, ⟨9, 109, 154, .D, 2, false, false⟩, ⟨12, 112, 156, .L, 2, true, false⟩, ⟨11, 114, 148, .U, 2, false, false⟩], walls := [], unsure := false }
def o256 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨9, 106, 145, .R, 2, false, false⟩, ⟨12, 106, 148, .D, 2, true, false⟩, ⟨11, 112, 150, .L, 2, false, false⟩, ⟨14, 114, 145, .U, 5, false, false⟩], walls := [], unsure := false }
def o257 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 112, 142, .R, 2, true, false⟩, ⟨11, 112, 148, .D, 2, false, false⟩, ⟨14, 115, 150, .L, 5, false, false⟩, ⟨9, 117, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o258 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 5, false, false⟩, ⟨12, 115, 142, .R, 2, true, false⟩, ⟨14, 118, 150, .L, 5, false, false⟩, ⟨9, 120, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o259 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 8, false, false⟩, ⟨12, 118, 142, .R, 2, true, false⟩, ⟨14, 121, 150, .L, 5, false, false⟩, ⟨9, 123, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o260 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨12, 121, 142, .R, 2, true, false⟩, ⟨14, 124, 150, .L, 5, false, false⟩, ⟨9, 126, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o261 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 14, false, false⟩, ⟨12, 124, 142, .R, 2, true, false⟩, ⟨14, 127, 150, .L, 5, false, false⟩, ⟨9, 129, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o262 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 17, false, false⟩, ⟨12, 127, 142, .R, 2, true, false⟩, ⟨14, 130, 150, .L, 5, false, false⟩, ⟨9, 132, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o263 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 142, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 5, false, false⟩, ⟨9, 135, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o264 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 133, 142, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 5, false, false⟩, ⟨9, 138, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o265 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 136, 142, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 5, false, false⟩, ⟨9, 141, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o266 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 144, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 5, false, false⟩, ⟨12, 141, 139, .U, 2, true, false⟩], walls := [], unsure := false }
def o267 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 141, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 8, false, false⟩, ⟨12, 141, 136, .U, 2, true, false⟩], walls := [], unsure := false }
def o268 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 138, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 11, false, false⟩, ⟨12, 141, 133, .U, 2, true, false⟩], walls := [], unsure := false }
def o269 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 135, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 14, false, false⟩, ⟨12, 141, 130, .U, 2, true, false⟩], walls := [], unsure := false }
def o270 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 132, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 17, false, false⟩, ⟨12, 141, 127, .U, 2, true, false⟩], walls := [], unsure := false }
def o271 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 129, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 20, false, false⟩, ⟨12, 141, 124, .U, 2, true, false⟩], walls := [], unsure := false }
def o272 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 126, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 23, false, false⟩, ⟨12, 141, 121, .U, 2, true, false⟩], walls := [], unsure := false }
def o273 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 123, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 26, false, false⟩, ⟨12, 141, 118, .U, 2, true, false⟩], walls := [], unsure := false }
def o274 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 120, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 29, false, false⟩, ⟨12, 141, 115, .U, 2, true, false⟩], walls := [], unsure := false }
def o275 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 117, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 32, false, false⟩, ⟨12, 141, 112, .U, 2, true, false⟩], walls := [], unsure := false }
def o276 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 114, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 35, false, false⟩, ⟨12, 141, 109, .U, 2, true, false⟩], walls := [], unsure := false }
def o277 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 111, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 38, false, false⟩, ⟨12, 141, 106, .U, 2, true, false⟩], walls := [], unsure := false }
def o278 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 108, .L, 2, false, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨12, 141, 103, .U, 2, true, false⟩], walls := [], unsure := false }
def o279 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨9, 139, 106, .D, 2, false, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨12, 142, 108, .L, 2, true, false⟩], walls := [], unsure := false }
def o280 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 136, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 2, false, false⟩], walls := [], unsure := false }
def o281 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 133, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 5, false, false⟩], walls := [], unsure := false }
def o282 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 130, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 8, false, false⟩], walls := [], unsure := false }
def o283 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 127, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 11, false, false⟩], walls := [], unsure := false }
def o284 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 124, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 14, false, false⟩], walls := [], unsure := false }
def o285 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 121, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 17, false, false⟩], walls := [], unsure := false }
def o286 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 118, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 20, false, false⟩], walls := [], unsure := false }
def o287 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 2, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o288 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 5, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o289 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 8, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o290 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 11, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o291 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 14, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o292 : Obs := { bars := [⟨8, 106, 114, .L, 14, false, true⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 26, false, false⟩, ⟨12, 115, 106, .R, 17, true, false⟩, ⟨14, 139, 150, .L, 41, false, false⟩, ⟨9, 141, 106, .U, 23, false, false⟩], walls := [], unsure := false }
def o293 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 115, 129, .L, 20, false, false⟩, ⟨9, 120, 127, .U, 2, false, false⟩, ⟨8, 131, 148, .U, 2, false, false⟩, ⟨14, 132, 147, .L, 2, false, false⟩, ⟨9, 132, 151, .R, 2, false, false⟩, ⟨12, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨115, 106, 126, 108⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o294 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 115, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 2, false, false⟩, ⟨8, 131, 148, .U, 2, false, false⟩, ⟨14, 132, 147, .L, 2, false, false⟩, ⟨9, 132, 151, .R, 2, false, false⟩, ⟨12, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨115, 109, 126, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o295 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨8, 131, 148, .U, 2, false, false⟩, ⟨14, 132, 147, .L, 2, false, false⟩, ⟨9, 132, 151, .R, 5, false, false⟩, ⟨12, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 109, 123, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o296 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 2, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨14, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 109, 123, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o297 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 109, 123, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o298 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 5, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 109, 123, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o299 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 109, 129, .L, 17, false, false⟩, ⟨9, 120, 127, .U, 8, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 8, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 109, 120, 111⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o300 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 109, 129, .L, 14, false, false⟩, ⟨9, 120, 127, .U, 8, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 8, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 112, 120, 114⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o301 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 109, 129, .L, 11, false, false⟩, ⟨9, 120, 127, .U, 8, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 8, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 115, 120, 117⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o302 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 109, 129, .L, 8, false, false⟩, ⟨9, 120, 127, .U, 8, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 8, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 118, 120, 120⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o303 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 109, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 8, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 8, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨109, 121, 120, 123⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o304 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨14, 131, 148, .U, 2, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 2, false, false⟩, ⟨9, 135, 148, .D, 5, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o305 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨8, 131, 148, .U, 2, false, false⟩, ⟨14, 132, 147, .L, 2, false, false⟩, ⟨9, 132, 151, .R, 5, false, false⟩, ⟨12, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o306 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 2, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨14, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o307 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 2, false, false⟩, ⟨10, 136, 109, .R, 20, false, false⟩, ⟨8, 141, 109, .U, 2, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨136, 130, 150, 132⟩⟩], unsure := false }
def o308 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 20, false, false⟩, ⟨8, 135, 148, .D, 5, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 130, 147, 132⟩⟩], unsure := false }
def o309 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 130, 109, .R, 20, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 8, false, false⟩, ⟨8, 141, 109, .U, 8, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨130, 130, 144, 132⟩⟩], unsure := false }
def o310 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 20, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 130, 141, 132⟩⟩], unsure := false }
def o311 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 17, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 127, 141, 129⟩⟩], unsure := false }
def o312 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 14, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 124, 141, 126⟩⟩], unsure := false }
def o313 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 11, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 121, 141, 123⟩⟩], unsure := false }
def o314 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 8, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 118, 141, 120⟩⟩], unsure := false }
def o315 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 127, 109, .R, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨127, 115, 141, 117⟩⟩], unsure := false }
def o316 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨10, 130, 109, .R, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨8, 135, 148, .D, 8, false, false⟩, ⟨8, 141, 109, .U, 8, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨130, 115, 144, 117⟩⟩], unsure := false }
def o317 : Obs := { bars := [⟨14, 103, 118, .D, 2, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨8, 135, 148, .D, 5, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o318 : Obs := { bars := [⟨14, 103, 118, .D, 5, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨12, 131, 148, .U, 2, false, false⟩, ⟨9, 132, 147, .L, 5, false, false⟩, ⟨14, 132, 151, .R, 5, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨8, 135, 148, .D, 5, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o319 : Obs := { bars := [⟨14, 103, 118, .D, 5, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨14, 131, 148, .U, 5, false, false⟩, ⟨12, 132, 147, .L, 2, false, false⟩, ⟨8, 132, 151, .R, 5, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨9, 135, 148, .D, 5, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o320 : Obs := { bars := [⟨14, 103, 118, .D, 5, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨8, 131, 148, .U, 5, false, false⟩, ⟨14, 132, 147, .L, 5, false, false⟩, ⟨9, 132, 151, .R, 5, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨12, 135, 148, .D, 2, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o321 : Obs := { bars := [⟨14, 103, 118, .D, 5, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 5, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o322 : Obs := { bars := [⟨14, 103, 118, .D, 8, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 8, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o323 : Obs := { bars := [⟨14, 103, 118, .D, 11, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 11, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o324 : Obs := { bars := [⟨14, 103, 118, .D, 14, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 14, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o325 : Obs := { bars := [⟨14, 103, 118, .D, 17, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 17, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o326 : Obs := { bars := [⟨14, 103, 118, .D, 20, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 20, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o327 : Obs := { bars := [⟨14, 103, 118, .D, 23, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 23, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o328 : Obs := { bars := [⟨14, 103, 118, .D, 26, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 26, false, false⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o329 : Obs := { bars := [⟨14, 103, 118, .D, 29, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 27, false, true⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o330 : Obs := { bars := [⟨14, 103, 118, .D, 32, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 27, false, true⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o331 : Obs := { bars := [⟨14, 103, 118, .D, 35, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 27, false, true⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o332 : Obs := { bars := [⟨14, 103, 118, .D, 38, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 27, false, true⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o333 : Obs := { bars := [⟨14, 103, 118, .D, 41, true, false⟩, ⟨7, 112, 129, .L, 5, false, false⟩, ⟨9, 120, 127, .U, 5, false, false⟩, ⟨9, 131, 148, .U, 5, false, false⟩, ⟨8, 132, 147, .L, 5, false, false⟩, ⟨12, 132, 151, .R, 2, false, false⟩, ⟨10, 133, 109, .R, 5, false, false⟩, ⟨14, 135, 148, .D, 27, false, true⟩, ⟨8, 141, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨112, 121, 123, 123⟩⟩, ⟨1, ⟨133, 115, 147, 117⟩⟩], unsure := false }
def o334 : Obs := { bars := [⟨14, 109, 127, .R, 11, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o335 : Obs := { bars := [⟨14, 109, 127, .R, 14, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o336 : Obs := { bars := [⟨14, 109, 127, .R, 17, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o337 : Obs := { bars := [⟨14, 109, 127, .R, 20, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o338 : Obs := { bars := [⟨14, 109, 127, .R, 23, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o339 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 8, true, false⟩], walls := [], unsure := false }
def o340 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 11, true, false⟩], walls := [], unsure := false }
def o341 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 14, true, false⟩], walls := [], unsure := false }
def o342 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 17, true, false⟩], walls := [], unsure := false }
def o343 : Obs := { bars := [⟨14, 109, 127, .R, 26, true, false⟩, ⟨11, 127, 109, .D, 20, true, false⟩], walls := [], unsure := false }
def o344 : Obs := { bars := [⟨11, 133, 115, .R, 2, false, false⟩, ⟨14, 133, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o345 : Obs := { bars := [⟨11, 130, 115, .R, 2, false, false⟩, ⟨14, 130, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 8, false, false⟩], walls := [], unsure := false }
def o346 : Obs := { bars := [⟨11, 127, 115, .R, 2, false, false⟩, ⟨14, 127, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 11, false, false⟩], walls := [], unsure := false }
def o347 : Obs := { bars := [⟨11, 127, 115, .R, 5, false, false⟩, ⟨14, 127, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 11, false, false⟩], walls := [], unsure := false }
def o348 : Obs := { bars := [⟨11, 127, 115, .R, 8, false, false⟩, ⟨14, 127, 124, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 11, false, false⟩], walls := [], unsure := false }
def o349 : Obs := { bars := [⟨11, 127, 118, .R, 8, false, false⟩, ⟨14, 127, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o350 : Obs := { bars := [⟨11, 127, 118, .R, 8, false, false⟩, ⟨14, 127, 127, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o351 : Obs := { bars := [⟨11, 124, 118, .R, 8, false, false⟩, ⟨14, 124, 127, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o352 : Obs := { bars := [⟨11, 124, 121, .R, 8, false, false⟩, ⟨14, 124, 130, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 14, false, false⟩], walls := [], unsure := false }
def o353 : Obs := { bars := [⟨11, 124, 121, .R, 8, false, false⟩, ⟨14, 124, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 14, false, false⟩], walls := [], unsure := false }
def o354 : Obs := { bars := [⟨11, 124, 121, .R, 5, false, false⟩, ⟨14, 124, 127, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 14, false, false⟩], walls := [], unsure := false }
def o355 : Obs := { bars := [⟨11, 121, 121, .R, 5, false, false⟩, ⟨14, 121, 127, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 17, false, false⟩], walls := [], unsure := false }
def o356 : Obs := { bars := [⟨11, 121, 118, .R, 5, false, false⟩, ⟨14, 121, 124, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o357 : Obs := { bars := [⟨11, 121, 118, .R, 8, false, false⟩, ⟨14, 121, 127, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o358 : Obs := { bars := [⟨11, 121, 118, .R, 11, false, false⟩, ⟨14, 121, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o359 : Obs := { bars := [⟨11, 121, 118, .R, 11, false, false⟩, ⟨14, 121, 130, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o360 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o361 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o362 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o363 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o364 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 23, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o365 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 26, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o366 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o367 : Obs := { bars := [⟨11, 121, 115, .R, 11, false, false⟩, ⟨14, 121, 127, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o368 : Obs := { bars := [⟨11, 121, 115, .R, 8, false, false⟩, ⟨14, 121, 124, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o369 : Obs := { bars := [⟨11, 121, 118, .R, 8, false, false⟩, ⟨14, 121, 127, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o370 : Obs := { bars := [⟨11, 121, 121, .R, 8, false, false⟩, ⟨14, 121, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 17, false, false⟩], walls := [], unsure := false }
def o371 : Obs := { bars := [⟨11, 118, 121, .R, 8, false, false⟩, ⟨14, 118, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 20, false, false⟩], walls := [], unsure := false }
def o372 : Obs := { bars := [⟨11, 115, 121, .R, 8, false, false⟩, ⟨14, 115, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 23, false, false⟩], walls := [], unsure := false }
def o373 : Obs := { bars := [⟨11, 112, 121, .R, 8, false, false⟩, ⟨14, 112, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 26, false, false⟩], walls := [], unsure := false }
def o374 : Obs := { bars := [⟨11, 109, 121, .R, 8, false, false⟩, ⟨14, 109, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 29, false, false⟩], walls := [], unsure := false }
def o375 : Obs := { bars := [⟨11, 106, 121, .R, 8, false, false⟩, ⟨14, 106, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 32, false, false⟩], walls := [], unsure := false }
def o376 : Obs := { bars := [⟨11, 103, 121, .R, 8, false, false⟩, ⟨14, 103, 130, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 35, false, false⟩], walls := [], unsure := false }
def o377 : Obs := { bars := [⟨11, 103, 121, .R, 8, false, false⟩, ⟨14, 103, 130, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 35, false, false⟩], walls := [], unsure := false }
def o378 : Obs := { bars := [⟨11, 103, 121, .R, 5, false, false⟩, ⟨14, 103, 127, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 35, false, false⟩], walls := [], unsure := false }
def o379 : Obs := { bars := [⟨11, 103, 124, .R, 5, false, false⟩, ⟨14, 103, 130, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 35, false, false⟩], walls := [], unsure := false }
def o380 : Obs := { bars := [⟨11, 106, 124, .R, 5, false, false⟩, ⟨14, 106, 130, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 32, false, false⟩], walls := [], unsure := false }
def o381 : Obs := { bars := [⟨11, 106, 124, .R, 2, false, false⟩, ⟨14, 106, 127, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 32, false, false⟩], walls := [], unsure := false }
def o382 : Obs := { bars := [⟨11, 103, 124, .R, 2, false, false⟩, ⟨14, 103, 127, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 35, false, false⟩], walls := [], unsure := false }
def o383 : Obs := { bars := [⟨11, 100, 124, .R, 2, false, false⟩, ⟨14, 100, 127, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o384 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o385 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 26, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o386 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 23, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o387 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o388 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o389 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o390 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o391 : Obs := { bars := [⟨11, 100, 127, .R, 2, false, false⟩, ⟨14, 100, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o392 : Obs := { bars := [⟨11, 100, 130, .R, 2, false, false⟩, ⟨14, 100, 133, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 38, false, false⟩], walls := [], unsure := false }
def o393 : Obs := { bars := [⟨11, 100, 130, .R, 5, false, false⟩, ⟨14, 100, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 38, false, false⟩], walls := [], unsure := false }
def o394 : Obs := { bars := [⟨11, 100, 130, .R, 8, false, false⟩, ⟨14, 100, 139, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 38, false, false⟩], walls := [], unsure := false }
def o395 : Obs := { bars := [⟨11, 100, 130, .R, 11, false, false⟩, ⟨14, 100, 142, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 38, false, false⟩], walls := [], unsure := false }
def o396 : Obs := { bars := [⟨11, 100, 127, .R, 11, false, false⟩, ⟨14, 100, 139, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 38, false, false⟩], walls := [], unsure := false }
def o397 : Obs := { bars := [⟨11, 100, 124, .R, 11, false, false⟩, ⟨14, 100, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o398 : Obs := { bars := [⟨11, 100, 124, .R, 14, false, false⟩, ⟨14, 100, 139, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o399 : Obs := { bars := [⟨11, 100, 124, .R, 14, false, false⟩, ⟨14, 100, 139, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o400 : Obs := { bars := [⟨11, 100, 124, .R, 14, false, false⟩, ⟨14, 100, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o401 : Obs := { bars := [⟨11, 100, 124, .R, 17, false, false⟩, ⟨14, 100, 142, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o402 : Obs := { bars := [⟨11, 100, 124, .R, 20, false, false⟩, ⟨14, 100, 145, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o403 : Obs := { bars := [⟨11, 100, 124, .R, 23, false, false⟩, ⟨14, 100, 148, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o404 : Obs := { bars := [⟨11, 100, 124, .R, 26, false, false⟩, ⟨14, 100, 151, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o405 : Obs := { bars := [⟨11, 103, 124, .R, 26, false, false⟩, ⟨14, 103, 151, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 35, false, false⟩], walls := [], unsure := false }
def o406 : Obs := { bars := [⟨11, 103, 124, .R, 26, false, false⟩, ⟨14, 103, 151, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 35, false, false⟩], walls := [], unsure := false }
def o407 : Obs := { bars := [⟨11, 106, 124, .R, 26, false, false⟩, ⟨14, 106, 151, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 32, false, false⟩], walls := [], unsure := false }
def o408 : Obs := { bars := [⟨11, 106, 121, .R, 26, false, false⟩, ⟨14, 106, 148, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 32, false, false⟩], walls := [], unsure := false }
def o409 : Obs := { bars := [⟨11, 106, 118, .R, 26, false, false⟩, ⟨14, 106, 145, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o410 : Obs := { bars := [⟨11, 106, 118, .R, 23, false, false⟩, ⟨14, 106, 142, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o411 : Obs := { bars := [⟨11, 106, 118, .R, 20, false, false⟩, ⟨14, 106, 139, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o412 : Obs := { bars := [⟨11, 106, 118, .R, 17, false, false⟩, ⟨14, 106, 136, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o413 : Obs := { bars := [⟨11, 106, 118, .R, 14, false, false⟩, ⟨14, 106, 133, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o414 : Obs := { bars := [⟨11, 106, 118, .R, 11, false, false⟩, ⟨14, 106, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o415 : Obs := { bars := [⟨11, 106, 118, .R, 8, false, false⟩, ⟨14, 106, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o416 : Obs := { bars := [⟨11, 106, 118, .R, 5, false, false⟩, ⟨14, 106, 124, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o417 : Obs := { bars := [⟨11, 106, 118, .R, 2, false, false⟩, ⟨14, 106, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o418 : Obs := { bars := [⟨11, 109, 118, .R, 2, false, false⟩, ⟨14, 109, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o419 : Obs := { bars := [⟨11, 112, 118, .R, 2, false, false⟩, ⟨14, 112, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o420 : Obs := { bars := [⟨11, 115, 118, .R, 2, false, false⟩, ⟨14, 115, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o421 : Obs := { bars := [⟨11, 118, 118, .R, 2, false, false⟩, ⟨14, 118, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 20, false, false⟩], walls := [], unsure := false }
def o422 : Obs := { bars := [⟨11, 121, 118, .R, 2, false, false⟩, ⟨14, 121, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o423 : Obs := { bars := [⟨11, 124, 118, .R, 2, false, false⟩, ⟨14, 124, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o424 : Obs := { bars := [⟨11, 127, 118, .R, 2, false, false⟩, ⟨14, 127, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o425 : Obs := { bars := [⟨11, 127, 121, .R, 2, false, false⟩, ⟨14, 127, 124, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o426 : Obs := { bars := [⟨11, 127, 124, .R, 2, false, false⟩, ⟨14, 127, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 11, false, false⟩], walls := [], unsure := false }
def o427 : Obs := { bars := [⟨11, 127, 127, .R, 2, false, false⟩, ⟨14, 127, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 11, false, false⟩], walls := [], unsure := false }
def o428 : Obs := { bars := [⟨11, 127, 130, .R, 2, false, false⟩, ⟨14, 127, 133, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 11, false, false⟩], walls := [], unsure := false }
def o429 : Obs := { bars := [⟨11, 127, 133, .R, 2, false, false⟩, ⟨14, 127, 136, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 23, false, false⟩, ⟨10, 141, 133, .U, 11, false, false⟩], walls := [], unsure := false }
def o430 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨14, 112, 145, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o431 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o432 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 17, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨118, 136, 135, 138⟩⟩], unsure := false }
def o433 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 14, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 20, false, false⟩], walls := [⟨1, ⟨115, 127, 117, 150⟩⟩, ⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o434 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 14, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 23, false, false⟩], walls := [⟨1, ⟨112, 127, 114, 150⟩⟩, ⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o435 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 23, false, false⟩], walls := [⟨1, ⟨112, 127, 114, 150⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o436 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 2, false, false⟩, ⟨8, 138, 127, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 127, 111, 150⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o437 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 5, false, false⟩, ⟨8, 138, 124, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 124, 111, 147⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o438 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 8, false, false⟩, ⟨8, 138, 121, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 121, 111, 144⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o439 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 11, false, false⟩, ⟨8, 138, 118, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 118, 111, 141⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o440 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 14, false, false⟩, ⟨8, 138, 115, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 115, 111, 138⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o441 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 17, false, false⟩, ⟨8, 138, 112, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 112, 111, 135⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o442 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 118, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 5, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 109, 111, 132⟩⟩, ⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o443 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 115, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 8, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 109, 111, 132⟩⟩, ⟨1, ⟨115, 142, 132, 144⟩⟩], unsure := false }
def o444 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 112, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 11, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 109, 111, 132⟩⟩, ⟨1, ⟨112, 142, 129, 144⟩⟩], unsure := false }
def o445 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 11, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 109, 111, 132⟩⟩, ⟨1, ⟨109, 142, 126, 144⟩⟩], unsure := false }
def o446 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 26, false, false⟩], walls := [⟨1, ⟨109, 109, 111, 132⟩⟩, ⟨1, ⟨109, 145, 126, 147⟩⟩], unsure := false }
def o447 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 23, false, false⟩], walls := [⟨1, ⟨109, 145, 126, 147⟩⟩, ⟨1, ⟨112, 109, 114, 132⟩⟩], unsure := false }
def o448 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 20, false, false⟩], walls := [⟨1, ⟨109, 145, 126, 147⟩⟩, ⟨1, ⟨115, 109, 117, 132⟩⟩], unsure := false }
def o449 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 17, false, false⟩], walls := [⟨1, ⟨109, 145, 126, 147⟩⟩, ⟨1, ⟨118, 109, 120, 132⟩⟩], unsure := false }
def o450 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 8, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 145, 126, 147⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o451 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 5, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 148, 126, 150⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o452 : Obs := { bars := [⟨7, 103, 148, .D, 5, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o453 : Obs := { bars := [⟨7, 103, 148, .D, 8, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o454 : Obs := { bars := [⟨7, 103, 148, .D, 11, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o455 : Obs := { bars := [⟨7, 103, 148, .D, 14, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o456 : Obs := { bars := [⟨7, 103, 148, .D, 17, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o457 : Obs := { bars := [⟨7, 103, 148, .D, 20, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o458 : Obs := { bars := [⟨7, 103, 148, .D, 23, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o459 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 14, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨121, 109, 123, 132⟩⟩], unsure := false }
def o460 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 11, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨124, 109, 126, 132⟩⟩], unsure := false }
def o461 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 8, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨127, 109, 129, 132⟩⟩], unsure := false }
def o462 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 2, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o463 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 5, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o464 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 8, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o465 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 11, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o466 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 14, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o467 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 17, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o468 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 20, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o469 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 23, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o470 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 26, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o471 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 29, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o472 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 32, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o473 : Obs := { bars := [⟨7, 103, 148, .D, 26, true, false⟩, ⟨12, 109, 156, .L, 2, false, false⟩, ⟨14, 126, 154, .U, 14, false, false⟩, ⟨10, 127, 106, .R, 35, true, false⟩, ⟨9, 136, 132, .L, 20, false, false⟩, ⟨8, 138, 109, .U, 5, false, false⟩], walls := [⟨1, ⟨109, 151, 126, 153⟩⟩, ⟨1, ⟨130, 109, 132, 132⟩⟩], unsure := false }
def o474 : Obs := { bars := [⟨11, 112, 153, .L, 2, false, false⟩, ⟨11, 115, 109, .R, 2, false, false⟩, ⟨11, 115, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 2, false, false⟩, ⟨11, 144, 130, .U, 2, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o475 : Obs := { bars := [⟨11, 112, 153, .L, 2, false, false⟩, ⟨11, 115, 109, .R, 2, false, false⟩, ⟨11, 115, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨11, 121, 118, .R, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 2, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o476 : Obs := { bars := [⟨11, 112, 153, .L, 2, false, false⟩, ⟨11, 115, 109, .R, 2, false, false⟩, ⟨11, 115, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 2, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 2, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o477 : Obs := { bars := [⟨11, 112, 153, .L, 5, false, false⟩, ⟨11, 115, 109, .R, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 5, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o478 : Obs := { bars := [⟨11, 112, 153, .L, 8, false, false⟩, ⟨11, 115, 109, .R, 8, false, false⟩, ⟨11, 115, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 8, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o479 : Obs := { bars := [⟨11, 112, 153, .L, 11, false, false⟩, ⟨11, 115, 109, .R, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 11, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o480 : Obs := { bars := [⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 109, .R, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 2, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o481 : Obs := { bars := [⟨11, 112, 109, .R, 14, false, false⟩, ⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 5, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o482 : Obs := { bars := [⟨11, 109, 109, .R, 14, false, false⟩, ⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o483 : Obs := { bars := [⟨11, 106, 109, .R, 14, false, false⟩, ⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o484 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 112, 153, .L, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o485 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 112, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 17, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o486 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 112, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 2, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o487 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 109, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o488 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 109, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 17, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o489 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 109, 153, .L, 17, false, false⟩, ⟨11, 112, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 17, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o490 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 109, 153, .L, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o491 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o492 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 109, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o493 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 109, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 17, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o494 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 109, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o495 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 109, 147, .L, 20, false, false⟩, ⟨11, 115, 118, .R, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o496 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 109, 147, .L, 20, false, false⟩, ⟨11, 112, 118, .R, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o497 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 109, 147, .L, 23, false, false⟩, ⟨11, 112, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o498 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o499 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o500 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 106, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o501 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 106, 147, .L, 26, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o502 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 106, 147, .L, 26, false, false⟩, ⟨11, 109, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 41, false, false⟩], walls := [], unsure := false }
def o503 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o504 : Obs := { bars := [⟨11, 100, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o505 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 109, 147, .L, 23, false, false⟩, ⟨11, 115, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o506 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 103, 153, .L, 20, false, false⟩, ⟨11, 109, 147, .L, 20, false, false⟩, ⟨11, 115, 118, .R, 20, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o507 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 103, 153, .L, 20, false, false⟩, ⟨11, 106, 147, .L, 20, false, false⟩, ⟨11, 115, 118, .R, 20, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o508 : Obs := { bars := [⟨11, 100, 153, .L, 20, false, false⟩, ⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 147, .L, 20, false, false⟩, ⟨11, 115, 118, .R, 20, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o509 : Obs := { bars := [⟨11, 100, 153, .L, 23, false, false⟩, ⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 147, .L, 23, false, false⟩, ⟨11, 115, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o510 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o511 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o512 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 106, 109, .R, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o513 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 106, 109, .R, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o514 : Obs := { bars := [⟨11, 100, 153, .L, 26, false, false⟩, ⟨11, 109, 109, .R, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 14, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o515 : Obs := { bars := [⟨11, 103, 153, .L, 26, false, false⟩, ⟨11, 109, 109, .R, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o516 : Obs := { bars := [⟨11, 103, 153, .L, 23, false, false⟩, ⟨11, 109, 109, .R, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨11, 115, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o517 : Obs := { bars := [⟨11, 103, 153, .L, 23, false, false⟩, ⟨11, 109, 109, .R, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o518 : Obs := { bars := [⟨11, 103, 153, .L, 23, false, false⟩, ⟨11, 106, 109, .R, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o519 : Obs := { bars := [⟨11, 103, 153, .L, 20, false, false⟩, ⟨11, 106, 109, .R, 20, false, false⟩, ⟨11, 112, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o520 : Obs := { bars := [⟨11, 103, 153, .L, 17, false, false⟩, ⟨11, 106, 109, .R, 17, false, false⟩, ⟨11, 112, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 118, .R, 17, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o521 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 106, 109, .R, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨11, 118, 118, .R, 14, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o522 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 106, 109, .R, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨11, 115, 118, .R, 14, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o523 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 106, 109, .R, 14, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨11, 112, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := true }
def o524 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 109, 109, .R, 14, false, false⟩, ⟨11, 112, 118, .R, 26, false, false⟩, ⟨11, 112, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := true }
def o525 : Obs := { bars := [⟨11, 103, 153, .L, 11, false, false⟩, ⟨11, 109, 109, .R, 11, false, false⟩, ⟨11, 112, 118, .R, 11, false, false⟩, ⟨11, 112, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o526 : Obs := { bars := [⟨11, 103, 153, .L, 11, false, false⟩, ⟨11, 109, 109, .R, 11, false, false⟩, ⟨11, 112, 118, .R, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o527 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 109, 109, .R, 14, false, false⟩, ⟨11, 112, 118, .R, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o528 : Obs := { bars := [⟨11, 103, 153, .L, 14, false, false⟩, ⟨11, 109, 109, .R, 14, false, false⟩, ⟨11, 115, 118, .R, 26, false, false⟩, ⟨11, 115, 147, .L, 2, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := true }
def o529 : Obs := { bars := [⟨11, 103, 153, .L, 11, false, false⟩, ⟨11, 109, 109, .R, 11, false, false⟩, ⟨11, 115, 118, .R, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 8, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o530 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨11, 115, 118, .R, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o531 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o532 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 115, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 23, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o533 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o534 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 115, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 20, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o535 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 17, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o536 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 115, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 17, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o537 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 115, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 14, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o538 : Obs := { bars := [⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 153, .L, 11, false, false⟩, ⟨11, 115, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o539 : Obs := { bars := [⟨11, 103, 109, .R, 8, false, false⟩, ⟨11, 106, 153, .L, 8, false, false⟩, ⟨11, 115, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 8, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o540 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 124, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o541 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 127, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o542 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 130, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 20, false, false⟩], walls := [], unsure := false }
def o543 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 133, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o544 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 136, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o545 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 115, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 5, false, false⟩, ⟨11, 139, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o546 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 139, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o547 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 109, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 139, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o548 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 109, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 142, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o549 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 109, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨11, 145, 118, .R, 5, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o550 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 109, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨11, 148, 118, .R, 5, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o551 : Obs := { bars := [⟨11, 103, 109, .R, 8, false, false⟩, ⟨11, 106, 153, .L, 8, false, false⟩, ⟨11, 109, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨11, 148, 118, .R, 8, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o552 : Obs := { bars := [⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 153, .L, 11, false, false⟩, ⟨11, 109, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨11, 148, 118, .R, 11, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o553 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 109, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨11, 148, 118, .R, 14, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o554 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 109, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨11, 148, 118, .R, 17, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o555 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 109, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨11, 148, 118, .R, 20, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o556 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 109, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨11, 148, 118, .R, 23, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o557 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 109, 147, .L, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨11, 148, 118, .R, 26, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o558 : Obs := { bars := [⟨11, 103, 109, .R, 29, false, false⟩, ⟨11, 106, 153, .L, 29, false, false⟩, ⟨11, 109, 147, .L, 29, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 29, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o559 : Obs := { bars := [⟨11, 103, 109, .R, 32, false, false⟩, ⟨11, 106, 153, .L, 32, false, false⟩, ⟨11, 109, 147, .L, 32, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 32, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o560 : Obs := { bars := [⟨11, 100, 109, .R, 32, false, false⟩, ⟨11, 106, 153, .L, 32, false, false⟩, ⟨11, 109, 147, .L, 32, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 32, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o561 : Obs := { bars := [⟨11, 100, 109, .R, 32, false, false⟩, ⟨11, 103, 153, .L, 32, false, false⟩, ⟨11, 109, 147, .L, 32, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 11, false, false⟩, ⟨11, 144, 130, .U, 32, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o562 : Obs := { bars := [⟨11, 100, 109, .R, 32, false, false⟩, ⟨11, 103, 153, .L, 32, false, false⟩, ⟨11, 106, 147, .L, 32, false, false⟩, ⟨9, 117, 151, .U, 11, false, false⟩, ⟨14, 120, 109, .U, 17, false, false⟩, ⟨8, 123, 145, .U, 14, false, false⟩, ⟨11, 144, 130, .U, 32, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o563 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 130, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 133, 147, 135⟩⟩], unsure := false }
def o564 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 127, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 133, 144, 135⟩⟩], unsure := false }
def o565 : Obs := { bars := [⟨12, 106, 109, .D, 2, false, false⟩, ⟨12, 106, 142, .D, 2, false, false⟩, ⟨14, 109, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 133, 144, 135⟩⟩], unsure := false }
def o566 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 133, 144, 135⟩⟩], unsure := false }
def o567 : Obs := { bars := [⟨12, 106, 109, .D, 8, false, false⟩, ⟨12, 106, 142, .D, 8, false, false⟩, ⟨14, 115, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 133, 144, 135⟩⟩], unsure := false }
def o568 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 20, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 133, 144, 135⟩⟩], unsure := false }
def o569 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o570 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o571 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o572 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o573 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o574 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 124, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 127, 141, 129⟩⟩], unsure := false }
def o575 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 26, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 127, 138, 129⟩⟩], unsure := false }
def o576 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 26, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 127, 135, 129⟩⟩], unsure := false }
def o577 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 23, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 130, 135, 132⟩⟩], unsure := false }
def o578 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 11, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 142, 138, 144⟩⟩], unsure := false }
def o579 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 124, 156, .L, 11, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 142, 141, 144⟩⟩], unsure := false }
def o580 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 11, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 142, 144, 144⟩⟩], unsure := false }
def o581 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 11, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 142, 144, 144⟩⟩], unsure := false }
def o582 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 11, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 142, 144, 144⟩⟩], unsure := false }
def o583 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 11, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 142, 144, 144⟩⟩], unsure := false }
def o584 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 130, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 130, 147, 132⟩⟩], unsure := false }
def o585 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o586 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 23, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 130, 144, 132⟩⟩], unsure := false }
def o587 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o588 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o589 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o590 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o591 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 127, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 127, 144, 129⟩⟩], unsure := false }
def o592 : Obs := { bars := [⟨12, 106, 109, .D, 5, false, false⟩, ⟨12, 106, 142, .D, 5, false, false⟩, ⟨14, 112, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o593 : Obs := { bars := [⟨12, 106, 109, .D, 8, false, false⟩, ⟨12, 106, 142, .D, 8, false, false⟩, ⟨14, 115, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o594 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 26, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 127, 147, 129⟩⟩], unsure := false }
def o595 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 29, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 124, 147, 126⟩⟩], unsure := false }
def o596 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 127, 156, .L, 29, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 124, 144, 126⟩⟩], unsure := false }
def o597 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 124, 156, .L, 29, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 124, 141, 126⟩⟩], unsure := false }
def o598 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 29, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 124, 138, 126⟩⟩], unsure := false }
def o599 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 29, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 124, 135, 126⟩⟩], unsure := false }
def o600 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 26, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 127, 135, 129⟩⟩], unsure := false }
def o601 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 23, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 130, 135, 132⟩⟩], unsure := false }
def o602 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 20, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 133, 135, 135⟩⟩], unsure := false }
def o603 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 17, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 136, 135, 138⟩⟩], unsure := false }
def o604 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 14, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o605 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 11, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o606 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o607 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o608 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o609 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o610 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o611 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o612 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 2, true, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o613 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 127, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o614 : Obs := { bars := [⟨12, 106, 109, .D, 23, false, false⟩, ⟨12, 106, 142, .D, 23, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 130, 109, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o615 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 130, 156, .L, 8, false, false⟩, ⟨14, 133, 109, .R, 2, true, false⟩, ⟨14, 135, 154, .U, 2, false, false⟩], walls := [⟨1, ⟨130, 145, 147, 147⟩⟩], unsure := false }
def o616 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 133, 109, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o617 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 133, 109, .R, 8, true, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o618 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 133, 109, .R, 11, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o619 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 2, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o620 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o621 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 8, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o622 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o623 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o624 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 133, 109, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o625 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨9, 112, 148, .D, 5, true, false⟩, ⟨14, 117, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o626 : Obs := { bars := [⟨11, 112, 139, .R, 5, false, false⟩, ⟨9, 112, 145, .D, 5, true, false⟩, ⟨14, 117, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o627 : Obs := { bars := [⟨11, 112, 139, .R, 2, false, false⟩, ⟨9, 112, 142, .D, 5, true, false⟩, ⟨14, 117, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o628 : Obs := { bars := [⟨11, 112, 139, .R, 2, false, false⟩, ⟨9, 112, 142, .R, 5, true, false⟩, ⟨14, 117, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o629 : Obs := { bars := [⟨11, 112, 139, .R, 2, false, false⟩, ⟨9, 114, 142, .U, 5, true, false⟩, ⟨14, 117, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o630 : Obs := { bars := [⟨11, 109, 139, .R, 2, false, false⟩, ⟨9, 111, 142, .U, 5, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o631 : Obs := { bars := [⟨11, 106, 139, .R, 2, false, false⟩, ⟨9, 108, 142, .U, 5, true, false⟩, ⟨14, 117, 139, .U, 8, false, false⟩], walls := [], unsure := false }
def o632 : Obs := { bars := [⟨9, 112, 132, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩, ⟨11, 117, 130, .U, 2, false, false⟩], walls := [], unsure := false }
def o633 : Obs := { bars := [⟨9, 115, 127, .D, 5, true, false⟩, ⟨11, 115, 132, .L, 2, false, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩], walls := [], unsure := false }
def o634 : Obs := { bars := [⟨11, 115, 130, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩, ⟨9, 118, 130, .R, 5, true, false⟩], walls := [], unsure := false }
def o635 : Obs := { bars := [⟨11, 115, 133, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 118, 133, .R, 5, true, false⟩], walls := [], unsure := false }
def o636 : Obs := { bars := [⟨11, 115, 133, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 118, 133, .R, 8, true, false⟩], walls := [], unsure := false }
def o637 : Obs := { bars := [⟨11, 115, 133, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 118, 133, .R, 11, true, false⟩], walls := [], unsure := false }
def o638 : Obs := { bars := [⟨9, 112, 135, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨11, 117, 133, .U, 2, false, false⟩], walls := [], unsure := false }
def o639 : Obs := { bars := [⟨9, 115, 130, .D, 11, true, false⟩, ⟨11, 115, 135, .L, 2, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩], walls := [], unsure := false }
def o640 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 11, true, false⟩], walls := [], unsure := false }
def o641 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 14, true, false⟩], walls := [], unsure := false }
def o642 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 17, true, false⟩], walls := [], unsure := false }
def o643 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 20, true, false⟩], walls := [], unsure := false }
def o644 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 23, true, false⟩], walls := [], unsure := false }
def o645 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .D, 2, false, false⟩, ⟨9, 124, 139, .R, 24, false, true⟩], walls := [], unsure := false }
def o646 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 2, false, false⟩, ⟨9, 123, 142, .U, 14, true, false⟩], walls := [], unsure := false }
def o647 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 5, false, false⟩, ⟨9, 123, 145, .U, 14, true, false⟩], walls := [], unsure := false }
def o648 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 8, false, false⟩, ⟨9, 123, 148, .U, 14, true, false⟩], walls := [], unsure := false }
def o649 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 11, false, false⟩, ⟨9, 123, 151, .U, 14, true, false⟩], walls := [], unsure := false }
def o650 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 14, false, false⟩, ⟨9, 123, 154, .U, 14, true, false⟩], walls := [], unsure := false }
def o651 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 17, false, false⟩, ⟨9, 123, 157, .U, 14, true, false⟩], walls := [], unsure := false }
def o652 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 20, false, false⟩, ⟨9, 123, 160, .U, 14, true, false⟩], walls := [], unsure := false }
def o653 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 20, false, false⟩, ⟨9, 121, 160, .D, 14, true, false⟩], walls := [], unsure := false }
def o654 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 139, .R, 20, false, false⟩, ⟨9, 118, 160, .D, 14, true, false⟩], walls := [], unsure := false }
def o655 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 139, .R, 20, false, false⟩, ⟨9, 118, 160, .D, 17, true, false⟩], walls := [], unsure := false }
def o656 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 20, false, false⟩, ⟨9, 121, 160, .D, 17, true, false⟩], walls := [], unsure := false }
def o657 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 141, .L, 20, false, false⟩, ⟨9, 120, 118, .U, 17, true, false⟩], walls := [], unsure := false }
def o658 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 141, .L, 17, false, false⟩, ⟨9, 120, 121, .U, 17, true, false⟩], walls := [], unsure := false }
def o659 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 141, .L, 14, false, false⟩, ⟨9, 120, 124, .U, 17, true, false⟩], walls := [], unsure := false }
def o660 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 141, .L, 11, false, false⟩, ⟨9, 120, 127, .U, 17, true, false⟩], walls := [], unsure := false }
def o661 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 141, .L, 8, false, false⟩, ⟨9, 120, 130, .U, 17, true, false⟩], walls := [], unsure := false }
def o662 : Obs := { bars := [⟨14, 115, 139, .R, 2, false, false⟩, ⟨11, 115, 142, .D, 8, false, false⟩, ⟨9, 124, 144, .L, 17, true, false⟩], walls := [], unsure := false }
def o663 : Obs := { bars := [⟨14, 115, 139, .R, 5, false, false⟩, ⟨11, 115, 145, .D, 8, false, false⟩, ⟨9, 124, 147, .L, 17, true, false⟩], walls := [], unsure := false }
def o664 : Obs := { bars := [⟨11, 109, 139, .R, 5, false, false⟩, ⟨9, 109, 145, .D, 17, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o665 : Obs := { bars := [⟨11, 109, 139, .R, 5, false, false⟩, ⟨9, 109, 145, .D, 14, true, false⟩, ⟨14, 117, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o666 : Obs := { bars := [⟨11, 106, 139, .R, 5, false, false⟩, ⟨9, 106, 145, .D, 14, true, false⟩, ⟨14, 117, 139, .U, 8, false, false⟩], walls := [], unsure := false }
def o667 : Obs := { bars := [⟨11, 103, 139, .R, 5, false, false⟩, ⟨9, 103, 145, .D, 14, true, false⟩, ⟨14, 117, 139, .U, 11, false, false⟩], walls := [], unsure := false }
def o668 : Obs := { bars := [⟨9, 109, 127, .R, 14, true, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨11, 117, 127, .U, 5, false, false⟩], walls := [], unsure := false }
def o669 : Obs := { bars := [⟨11, 115, 129, .L, 5, false, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨9, 117, 121, .U, 14, true, false⟩], walls := [], unsure := false }
def o670 : Obs := { bars := [⟨11, 115, 127, .D, 5, false, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨9, 121, 129, .L, 14, true, false⟩], walls := [], unsure := false }
def o671 : Obs := { bars := [⟨11, 115, 124, .D, 5, false, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨9, 121, 126, .L, 14, true, false⟩], walls := [], unsure := false }
def o672 : Obs := { bars := [⟨11, 115, 124, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨9, 118, 126, .L, 14, true, false⟩], walls := [], unsure := false }
def o673 : Obs := { bars := [⟨11, 115, 127, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨9, 118, 129, .L, 14, true, false⟩], walls := [], unsure := false }
def o674 : Obs := { bars := [⟨11, 115, 130, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩, ⟨9, 118, 132, .L, 14, true, false⟩], walls := [], unsure := false }
def o675 : Obs := { bars := [⟨11, 115, 133, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 5, false, false⟩, ⟨9, 118, 135, .L, 14, true, false⟩], walls := [], unsure := false }
def o676 : Obs := { bars := [⟨11, 115, 136, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 118, 138, .L, 14, true, false⟩], walls := [], unsure := false }
def o677 : Obs := { bars := [⟨11, 115, 136, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 118, 138, .L, 11, true, false⟩], walls := [], unsure := false }
def o678 : Obs := { bars := [⟨11, 115, 136, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 118, 138, .L, 8, true, false⟩], walls := [], unsure := false }
def o679 : Obs := { bars := [⟨11, 115, 136, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 118, 136, .D, 8, true, false⟩], walls := [], unsure := false }
def o680 : Obs := { bars := [⟨11, 115, 136, .D, 2, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 118, 136, .R, 8, true, false⟩], walls := [], unsure := false }
def o681 : Obs := { bars := [⟨9, 112, 138, .L, 8, true, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨11, 117, 136, .U, 2, false, false⟩], walls := [], unsure := false }
def o682 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨9, 118, 136, .D, 8, true, false⟩, ⟨11, 118, 141, .L, 2, false, false⟩], walls := [], unsure := false }
def o683 : Obs := { bars := [⟨14, 115, 139, .R, 2, false, false⟩, ⟨11, 115, 142, .D, 2, false, false⟩, ⟨9, 118, 142, .R, 8, true, false⟩], walls := [], unsure := false }
def o684 : Obs := { bars := [⟨14, 115, 139, .R, 2, false, false⟩, ⟨11, 115, 142, .D, 5, false, false⟩, ⟨9, 121, 142, .R, 8, true, false⟩], walls := [], unsure := false }
def o685 : Obs := { bars := [⟨14, 115, 139, .R, 2, false, false⟩, ⟨11, 115, 142, .D, 8, false, false⟩, ⟨9, 124, 142, .R, 8, true, false⟩], walls := [], unsure := false }
def o686 : Obs := { bars := [⟨14, 115, 139, .R, 5, false, false⟩, ⟨11, 115, 145, .D, 8, false, false⟩, ⟨9, 124, 145, .R, 8, true, false⟩], walls := [], unsure := false }
def o687 : Obs := { bars := [⟨14, 115, 139, .R, 5, false, false⟩, ⟨11, 115, 145, .D, 8, false, false⟩, ⟨9, 124, 145, .R, 5, true, false⟩], walls := [], unsure := false }
def o688 : Obs := { bars := [⟨14, 115, 139, .R, 8, false, false⟩, ⟨11, 115, 148, .D, 8, false, false⟩, ⟨9, 124, 148, .R, 5, true, false⟩], walls := [], unsure := false }
def o689 : Obs := { bars := [⟨11, 106, 139, .R, 8, false, false⟩, ⟨9, 108, 148, .U, 5, true, false⟩, ⟨14, 117, 139, .U, 8, false, false⟩], walls := [], unsure := false }
def o690 : Obs := { bars := [⟨9, 106, 132, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 8, false, false⟩, ⟨11, 117, 130, .U, 8, false, false⟩], walls := [], unsure := false }
def o691 : Obs := { bars := [⟨9, 106, 129, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨11, 117, 127, .U, 8, false, false⟩], walls := [], unsure := false }
def o692 : Obs := { bars := [⟨9, 106, 129, .L, 8, true, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨11, 117, 127, .U, 8, false, false⟩], walls := [], unsure := false }
def o693 : Obs := { bars := [⟨9, 103, 129, .L, 8, true, false⟩, ⟨14, 115, 141, .L, 11, false, false⟩, ⟨11, 117, 127, .U, 11, false, false⟩], walls := [], unsure := false }
def o694 : Obs := { bars := [⟨9, 103, 126, .L, 8, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 11, false, false⟩], walls := [], unsure := false }
def o695 : Obs := { bars := [⟨9, 103, 126, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 11, false, false⟩], walls := [], unsure := false }
def o696 : Obs := { bars := [⟨9, 100, 126, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 14, false, false⟩], walls := [], unsure := false }
def o697 : Obs := { bars := [⟨9, 100, 123, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 17, false, false⟩, ⟨11, 117, 121, .U, 14, false, false⟩], walls := [], unsure := false }
def o698 : Obs := { bars := [⟨9, 100, 120, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 20, false, false⟩, ⟨11, 117, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o699 : Obs := { bars := [⟨9, 100, 117, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨11, 117, 115, .U, 14, false, false⟩], walls := [], unsure := false }
def o700 : Obs := { bars := [⟨9, 115, 100, .D, 11, true, false⟩, ⟨11, 115, 117, .L, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩], walls := [], unsure := false }
def o701 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 11, true, false⟩], walls := [], unsure := false }
def o702 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 14, true, false⟩], walls := [], unsure := false }
def o703 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 17, true, false⟩], walls := [], unsure := false }
def o704 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 20, true, false⟩], walls := [], unsure := false }
def o705 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 23, true, false⟩], walls := [], unsure := false }
def o706 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 26, true, false⟩], walls := [], unsure := false }
def o707 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 29, true, false⟩], walls := [], unsure := false }
def o708 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 32, true, false⟩], walls := [], unsure := false }
def o709 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 35, true, false⟩], walls := [], unsure := false }
def o710 : Obs := { bars := [⟨11, 115, 115, .D, 14, false, false⟩, ⟨14, 115, 141, .L, 23, false, false⟩, ⟨9, 130, 115, .R, 38, true, false⟩], walls := [], unsure := false }
def o711 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨9, 106, 145, .R, 5, false, false⟩, ⟨12, 106, 151, .D, 2, true, false⟩, ⟨11, 112, 150, .L, 2, false, false⟩, ⟨14, 114, 145, .U, 5, false, false⟩], walls := [], unsure := false }
def o712 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 109, 142, .R, 2, true, false⟩, ⟨11, 112, 148, .D, 2, false, false⟩, ⟨14, 115, 150, .L, 5, false, false⟩, ⟨9, 117, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o713 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 112, 142, .R, 2, true, false⟩, ⟨11, 112, 148, .D, 5, false, false⟩, ⟨14, 118, 150, .L, 5, false, false⟩, ⟨9, 120, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o714 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 5, false, false⟩, ⟨12, 115, 142, .R, 2, true, false⟩, ⟨14, 118, 150, .L, 5, false, false⟩, ⟨9, 120, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o715 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 8, false, false⟩, ⟨12, 118, 142, .R, 2, true, false⟩, ⟨14, 121, 150, .L, 5, false, false⟩, ⟨9, 123, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o716 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨12, 121, 142, .R, 2, true, false⟩, ⟨14, 124, 150, .L, 5, false, false⟩, ⟨9, 126, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o717 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 14, false, false⟩, ⟨12, 124, 142, .R, 2, true, false⟩, ⟨14, 127, 150, .L, 5, false, false⟩, ⟨9, 129, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o718 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 17, false, false⟩, ⟨12, 127, 142, .R, 2, true, false⟩, ⟨14, 130, 150, .L, 5, false, false⟩, ⟨9, 132, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o719 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 142, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 5, false, false⟩, ⟨9, 135, 142, .U, 2, false, false⟩], walls := [], unsure := false }
def o720 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 139, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 8, false, false⟩, ⟨9, 135, 139, .U, 2, false, false⟩], walls := [], unsure := false }
def o721 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 136, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 11, false, false⟩, ⟨9, 135, 136, .U, 2, false, false⟩], walls := [], unsure := false }
def o722 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 133, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 14, false, false⟩, ⟨9, 135, 133, .U, 2, false, false⟩], walls := [], unsure := false }
def o723 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 130, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 2, false, false⟩], walls := [], unsure := false }
def o724 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 127, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 5, false, false⟩], walls := [], unsure := false }
def o725 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 124, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 8, false, false⟩], walls := [], unsure := false }
def o726 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 121, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 11, false, false⟩], walls := [], unsure := false }
def o727 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 118, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 14, false, false⟩], walls := [], unsure := false }
def o728 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 115, 130, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 17, false, false⟩, ⟨9, 135, 130, .U, 17, false, false⟩], walls := [], unsure := false }
def o729 : Obs := { bars := [⟨11, 124, 115, .R, 2, false, false⟩, ⟨14, 124, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 14, false, false⟩], walls := [], unsure := false }
def o730 : Obs := { bars := [⟨11, 121, 115, .R, 2, false, false⟩, ⟨14, 121, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 17, false, false⟩], walls := [], unsure := false }
def o731 : Obs := { bars := [⟨11, 118, 115, .R, 2, false, false⟩, ⟨14, 118, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 20, false, false⟩], walls := [], unsure := false }
def o732 : Obs := { bars := [⟨11, 115, 115, .R, 2, false, false⟩, ⟨14, 115, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 23, false, false⟩], walls := [], unsure := false }
def o733 : Obs := { bars := [⟨11, 112, 115, .R, 2, false, false⟩, ⟨14, 112, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 26, false, false⟩], walls := [], unsure := false }
def o734 : Obs := { bars := [⟨11, 109, 115, .R, 2, false, false⟩, ⟨14, 109, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 29, false, false⟩], walls := [], unsure := false }
def o735 : Obs := { bars := [⟨11, 106, 115, .R, 2, false, false⟩, ⟨14, 106, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 32, false, false⟩], walls := [], unsure := false }
def o736 : Obs := { bars := [⟨11, 103, 115, .R, 2, false, false⟩, ⟨14, 103, 118, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 35, false, false⟩], walls := [], unsure := false }
def o737 : Obs := { bars := [⟨11, 103, 115, .R, 5, false, false⟩, ⟨14, 103, 121, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 35, false, false⟩], walls := [], unsure := false }
def o738 : Obs := { bars := [⟨11, 103, 115, .R, 5, false, false⟩, ⟨14, 103, 121, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 35, false, false⟩], walls := [], unsure := false }
def o739 : Obs := { bars := [⟨11, 103, 115, .R, 5, false, false⟩, ⟨14, 103, 121, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 35, false, false⟩], walls := [], unsure := false }
def o740 : Obs := { bars := [⟨11, 103, 118, .R, 5, false, false⟩, ⟨14, 103, 124, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o741 : Obs := { bars := [⟨11, 103, 118, .R, 8, false, false⟩, ⟨14, 103, 127, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o742 : Obs := { bars := [⟨11, 103, 118, .R, 11, false, false⟩, ⟨14, 103, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 35, false, false⟩], walls := [], unsure := false }
def o743 : Obs := { bars := [⟨11, 100, 118, .R, 11, false, false⟩, ⟨14, 100, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o744 : Obs := { bars := [⟨11, 100, 121, .R, 11, false, false⟩, ⟨14, 100, 133, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o745 : Obs := { bars := [⟨11, 100, 121, .R, 14, false, false⟩, ⟨14, 100, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o746 : Obs := { bars := [⟨11, 100, 121, .R, 17, false, false⟩, ⟨14, 100, 139, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o747 : Obs := { bars := [⟨11, 100, 121, .R, 20, false, false⟩, ⟨14, 100, 142, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o748 : Obs := { bars := [⟨11, 100, 121, .R, 23, false, false⟩, ⟨14, 100, 145, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o749 : Obs := { bars := [⟨11, 100, 121, .R, 26, false, false⟩, ⟨14, 100, 148, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o750 : Obs := { bars := [⟨11, 100, 121, .R, 29, false, false⟩, ⟨14, 100, 151, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o751 : Obs := { bars := [⟨11, 100, 121, .R, 32, false, false⟩, ⟨14, 100, 154, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o752 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o753 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o754 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o755 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o756 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o757 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 23, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o758 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 26, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o759 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o760 : Obs := { bars := [⟨11, 100, 121, .R, 35, false, false⟩, ⟨14, 100, 157, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o761 : Obs := { bars := [⟨11, 100, 124, .R, 35, false, false⟩, ⟨14, 100, 160, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o762 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 32, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o763 : Obs := { bars := [⟨11, 133, 124, .R, 2, false, false⟩, ⟨14, 133, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 5, false, false⟩], walls := [], unsure := false }
def o764 : Obs := { bars := [⟨11, 133, 124, .R, 5, false, false⟩, ⟨14, 133, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 5, false, false⟩], walls := [], unsure := false }
def o765 : Obs := { bars := [⟨11, 130, 124, .R, 5, false, false⟩, ⟨14, 130, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 8, false, false⟩], walls := [], unsure := false }
def o766 : Obs := { bars := [⟨11, 127, 124, .R, 5, false, false⟩, ⟨14, 127, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 11, false, false⟩], walls := [], unsure := false }
def o767 : Obs := { bars := [⟨11, 127, 121, .R, 5, false, false⟩, ⟨14, 127, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o768 : Obs := { bars := [⟨11, 127, 118, .R, 5, false, false⟩, ⟨14, 127, 124, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o769 : Obs := { bars := [⟨11, 127, 118, .R, 5, false, false⟩, ⟨14, 127, 124, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o770 : Obs := { bars := [⟨11, 127, 121, .R, 5, false, false⟩, ⟨14, 127, 127, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o771 : Obs := { bars := [⟨11, 127, 121, .R, 8, false, false⟩, ⟨14, 127, 130, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o772 : Obs := { bars := [⟨11, 127, 121, .R, 11, false, false⟩, ⟨14, 127, 133, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o773 : Obs := { bars := [⟨11, 127, 121, .R, 14, false, false⟩, ⟨14, 127, 136, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o774 : Obs := { bars := [⟨11, 130, 121, .R, 14, false, false⟩, ⟨14, 130, 136, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 8, false, false⟩], walls := [], unsure := false }
def o775 : Obs := { bars := [⟨11, 130, 118, .R, 14, false, false⟩, ⟨14, 130, 133, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o776 : Obs := { bars := [⟨11, 130, 118, .R, 14, false, false⟩, ⟨14, 130, 133, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o777 : Obs := { bars := [⟨11, 127, 118, .R, 14, false, false⟩, ⟨14, 127, 133, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o778 : Obs := { bars := [⟨11, 127, 118, .R, 17, false, false⟩, ⟨14, 127, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o779 : Obs := { bars := [⟨11, 130, 118, .R, 17, false, false⟩, ⟨14, 130, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o780 : Obs := { bars := [⟨11, 133, 118, .R, 17, false, false⟩, ⟨14, 133, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o781 : Obs := { bars := [⟨11, 133, 115, .R, 17, false, false⟩, ⟨14, 133, 133, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o782 : Obs := { bars := [⟨11, 133, 115, .R, 20, false, false⟩, ⟨14, 133, 136, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o783 : Obs := { bars := [⟨11, 133, 115, .R, 23, false, false⟩, ⟨14, 133, 139, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o784 : Obs := { bars := [⟨11, 133, 115, .R, 23, false, false⟩, ⟨14, 133, 139, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o785 : Obs := { bars := [⟨11, 133, 115, .R, 23, false, false⟩, ⟨14, 133, 139, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o786 : Obs := { bars := [⟨11, 133, 115, .R, 20, false, false⟩, ⟨14, 133, 136, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o787 : Obs := { bars := [⟨11, 133, 115, .R, 17, false, false⟩, ⟨14, 133, 133, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o788 : Obs := { bars := [⟨11, 133, 115, .R, 14, false, false⟩, ⟨14, 133, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o789 : Obs := { bars := [⟨11, 133, 115, .R, 11, false, false⟩, ⟨14, 133, 127, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 5, false, false⟩], walls := [], unsure := false }
def o790 : Obs := { bars := [⟨11, 133, 118, .R, 11, false, false⟩, ⟨14, 133, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o791 : Obs := { bars := [⟨11, 130, 118, .R, 11, false, false⟩, ⟨14, 130, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o792 : Obs := { bars := [⟨11, 127, 118, .R, 11, false, false⟩, ⟨14, 127, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o793 : Obs := { bars := [⟨11, 124, 118, .R, 11, false, false⟩, ⟨14, 124, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o794 : Obs := { bars := [⟨11, 121, 118, .R, 11, false, false⟩, ⟨14, 121, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o795 : Obs := { bars := [⟨11, 121, 118, .R, 8, false, false⟩, ⟨14, 121, 127, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o796 : Obs := { bars := [⟨11, 121, 121, .R, 8, false, false⟩, ⟨14, 121, 130, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 17, false, false⟩], walls := [], unsure := false }
def o797 : Obs := { bars := [⟨11, 118, 121, .R, 8, false, false⟩, ⟨14, 118, 130, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 20, false, false⟩], walls := [], unsure := false }
def o798 : Obs := { bars := [⟨11, 118, 121, .R, 8, false, false⟩, ⟨14, 118, 130, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 20, false, false⟩], walls := [], unsure := false }
def o799 : Obs := { bars := [⟨11, 118, 118, .R, 8, false, false⟩, ⟨14, 118, 127, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 20, false, false⟩], walls := [], unsure := false }
def o800 : Obs := { bars := [⟨11, 115, 118, .R, 8, false, false⟩, ⟨14, 115, 127, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o801 : Obs := { bars := [⟨11, 115, 118, .R, 8, false, false⟩, ⟨14, 115, 127, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o802 : Obs := { bars := [⟨11, 112, 118, .R, 8, false, false⟩, ⟨14, 112, 127, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o803 : Obs := { bars := [⟨11, 112, 118, .R, 8, false, false⟩, ⟨14, 112, 127, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o804 : Obs := { bars := [⟨11, 112, 115, .R, 8, false, false⟩, ⟨14, 112, 124, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 26, false, false⟩], walls := [], unsure := false }
def o805 : Obs := { bars := [⟨11, 109, 115, .R, 8, false, false⟩, ⟨14, 109, 124, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 29, false, false⟩], walls := [], unsure := false }
def o806 : Obs := { bars := [⟨11, 106, 115, .R, 8, false, false⟩, ⟨14, 106, 124, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 32, false, false⟩], walls := [], unsure := false }
def o807 : Obs := { bars := [⟨11, 106, 115, .R, 5, false, false⟩, ⟨14, 106, 121, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 32, false, false⟩], walls := [], unsure := false }
def o808 : Obs := { bars := [⟨11, 103, 115, .R, 5, false, false⟩, ⟨14, 103, 121, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 35, false, false⟩], walls := [], unsure := false }
def o809 : Obs := { bars := [⟨11, 100, 115, .R, 5, false, false⟩, ⟨14, 100, 121, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 5, false, false⟩, ⟨10, 141, 115, .U, 38, false, false⟩], walls := [], unsure := false }
def o810 : Obs := { bars := [⟨11, 100, 118, .R, 5, false, false⟩, ⟨14, 100, 124, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 8, false, false⟩, ⟨10, 141, 118, .U, 38, false, false⟩], walls := [], unsure := false }
def o811 : Obs := { bars := [⟨11, 100, 121, .R, 5, false, false⟩, ⟨14, 100, 127, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o812 : Obs := { bars := [⟨11, 100, 121, .R, 5, false, false⟩, ⟨14, 100, 127, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o813 : Obs := { bars := [⟨11, 100, 121, .R, 5, false, false⟩, ⟨14, 100, 127, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o814 : Obs := { bars := [⟨11, 100, 121, .R, 5, false, false⟩, ⟨14, 100, 127, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o815 : Obs := { bars := [⟨11, 100, 121, .R, 5, false, false⟩, ⟨14, 100, 127, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o816 : Obs := { bars := [⟨11, 100, 121, .R, 8, false, false⟩, ⟨14, 100, 130, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 11, false, false⟩, ⟨10, 141, 121, .U, 38, false, false⟩], walls := [], unsure := false }
def o817 : Obs := { bars := [⟨11, 100, 124, .R, 26, false, false⟩, ⟨14, 100, 151, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o818 : Obs := { bars := [⟨11, 100, 124, .R, 29, false, false⟩, ⟨14, 100, 154, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o819 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o820 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o821 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o822 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 17, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o823 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 20, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o824 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 23, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o825 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 26, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o826 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 29, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o827 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o828 : Obs := { bars := [⟨11, 100, 124, .R, 32, false, false⟩, ⟨14, 100, 157, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o829 : Obs := { bars := [⟨11, 100, 124, .R, 29, false, false⟩, ⟨14, 100, 154, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o830 : Obs := { bars := [⟨11, 100, 124, .R, 11, false, false⟩, ⟨14, 100, 136, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o831 : Obs := { bars := [⟨11, 100, 124, .R, 8, false, false⟩, ⟨14, 100, 133, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o832 : Obs := { bars := [⟨11, 100, 124, .R, 5, false, false⟩, ⟨14, 100, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o833 : Obs := { bars := [⟨11, 100, 124, .R, 2, false, false⟩, ⟨14, 100, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 38, false, false⟩], walls := [], unsure := false }
def o834 : Obs := { bars := [⟨11, 103, 124, .R, 2, false, false⟩, ⟨14, 103, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 35, false, false⟩], walls := [], unsure := false }
def o835 : Obs := { bars := [⟨11, 106, 124, .R, 2, false, false⟩, ⟨14, 106, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 32, false, false⟩], walls := [], unsure := false }
def o836 : Obs := { bars := [⟨11, 109, 124, .R, 2, false, false⟩, ⟨14, 109, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 29, false, false⟩], walls := [], unsure := false }
def o837 : Obs := { bars := [⟨11, 112, 124, .R, 2, false, false⟩, ⟨14, 112, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 26, false, false⟩], walls := [], unsure := false }
def o838 : Obs := { bars := [⟨11, 115, 124, .R, 2, false, false⟩, ⟨14, 115, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 23, false, false⟩], walls := [], unsure := false }
def o839 : Obs := { bars := [⟨11, 118, 124, .R, 2, false, false⟩, ⟨14, 118, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 20, false, false⟩], walls := [], unsure := false }
def o840 : Obs := { bars := [⟨11, 121, 124, .R, 2, false, false⟩, ⟨14, 121, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 17, false, false⟩], walls := [], unsure := false }
def o841 : Obs := { bars := [⟨11, 124, 124, .R, 2, false, false⟩, ⟨14, 124, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 14, false, false⟩], walls := [], unsure := false }
def o842 : Obs := { bars := [⟨11, 130, 124, .R, 2, false, false⟩, ⟨14, 130, 127, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 14, false, false⟩, ⟨10, 141, 124, .U, 8, false, false⟩], walls := [], unsure := false }
def o843 : Obs := { bars := [⟨11, 130, 127, .R, 2, false, false⟩, ⟨14, 130, 130, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 17, false, false⟩, ⟨10, 141, 127, .U, 8, false, false⟩], walls := [], unsure := false }
def o844 : Obs := { bars := [⟨11, 130, 130, .R, 2, false, false⟩, ⟨14, 130, 133, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 20, false, false⟩, ⟨10, 141, 130, .U, 8, false, false⟩], walls := [], unsure := false }
def o845 : Obs := { bars := [⟨11, 130, 133, .R, 2, false, false⟩, ⟨14, 130, 136, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 23, false, false⟩, ⟨10, 141, 133, .U, 8, false, false⟩], walls := [], unsure := false }
def o846 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 2, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o847 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 5, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o848 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 8, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o849 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 11, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o850 : Obs := { bars := [⟨11, 112, 139, .R, 8, false, false⟩, ⟨14, 112, 148, .D, 14, true, false⟩, ⟨12, 139, 109, .R, 29, false, false⟩, ⟨10, 141, 139, .U, 26, false, false⟩], walls := [], unsure := false }
def o851 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 109, 153, .L, 20, false, false⟩, ⟨11, 112, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 5, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o852 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 112, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨11, 118, 118, .R, 20, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 32, false, false⟩], walls := [], unsure := false }
def o853 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 112, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 20, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o854 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 112, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 17, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o855 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o856 : Obs := { bars := [⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 153, .L, 11, false, false⟩, ⟨11, 112, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 11, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o857 : Obs := { bars := [⟨11, 103, 109, .R, 8, false, false⟩, ⟨11, 106, 153, .L, 8, false, false⟩, ⟨11, 112, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 8, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o858 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨11, 121, 118, .R, 5, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 29, false, false⟩], walls := [], unsure := false }
def o859 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 124, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 26, false, false⟩], walls := [], unsure := false }
def o860 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 127, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 23, false, false⟩], walls := [], unsure := false }
def o861 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 130, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 20, false, false⟩], walls := [], unsure := false }
def o862 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 133, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 17, false, false⟩], walls := [], unsure := false }
def o863 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 136, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 14, false, false⟩], walls := [], unsure := false }
def o864 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 142, 118, .R, 5, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨12, 153, 118, .U, 8, false, false⟩], walls := [], unsure := false }
def o865 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨11, 145, 118, .R, 5, false, false⟩, ⟨12, 153, 118, .U, 5, false, false⟩], walls := [], unsure := false }
def o866 : Obs := { bars := [⟨11, 103, 109, .R, 5, false, false⟩, ⟨11, 106, 153, .L, 5, false, false⟩, ⟨11, 112, 147, .L, 5, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 5, true, false⟩, ⟨11, 148, 118, .R, 5, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o867 : Obs := { bars := [⟨11, 103, 109, .R, 8, false, false⟩, ⟨11, 106, 153, .L, 8, false, false⟩, ⟨11, 112, 147, .L, 8, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 8, true, false⟩, ⟨11, 148, 118, .R, 8, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o868 : Obs := { bars := [⟨11, 103, 109, .R, 11, false, false⟩, ⟨11, 106, 153, .L, 11, false, false⟩, ⟨11, 112, 147, .L, 11, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 11, true, false⟩, ⟨11, 148, 118, .R, 11, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o869 : Obs := { bars := [⟨11, 103, 109, .R, 14, false, false⟩, ⟨11, 106, 153, .L, 14, false, false⟩, ⟨11, 112, 147, .L, 14, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 14, true, false⟩, ⟨11, 148, 118, .R, 14, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o870 : Obs := { bars := [⟨11, 103, 109, .R, 17, false, false⟩, ⟨11, 106, 153, .L, 17, false, false⟩, ⟨11, 112, 147, .L, 17, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 17, true, false⟩, ⟨11, 148, 118, .R, 17, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o871 : Obs := { bars := [⟨11, 103, 109, .R, 20, false, false⟩, ⟨11, 106, 153, .L, 20, false, false⟩, ⟨11, 112, 147, .L, 20, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 20, true, false⟩, ⟨11, 148, 118, .R, 20, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o872 : Obs := { bars := [⟨11, 103, 109, .R, 23, false, false⟩, ⟨11, 106, 153, .L, 23, false, false⟩, ⟨11, 112, 147, .L, 23, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 23, true, false⟩, ⟨11, 148, 118, .R, 23, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o873 : Obs := { bars := [⟨11, 103, 109, .R, 26, false, false⟩, ⟨11, 106, 153, .L, 26, false, false⟩, ⟨11, 112, 147, .L, 26, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 26, true, false⟩, ⟨11, 148, 118, .R, 26, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o874 : Obs := { bars := [⟨11, 103, 109, .R, 29, false, false⟩, ⟨11, 106, 153, .L, 29, false, false⟩, ⟨11, 112, 147, .L, 29, false, false⟩, ⟨9, 117, 151, .U, 8, false, false⟩, ⟨14, 120, 109, .U, 14, false, false⟩, ⟨8, 123, 145, .U, 8, false, false⟩, ⟨11, 144, 130, .U, 29, true, false⟩, ⟨11, 148, 118, .R, 29, false, false⟩, ⟨12, 153, 118, .U, 2, false, false⟩], walls := [], unsure := false }
def o875 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 20, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 133, 135, 135⟩⟩], unsure := false }
def o876 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 17, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 136, 135, 138⟩⟩], unsure := false }
def o877 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 14, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 139, 135, 141⟩⟩], unsure := false }
def o878 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 11, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 142, 135, 144⟩⟩], unsure := false }
def o879 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 14, true, false⟩, ⟨9, 118, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 14, false, false⟩], walls := [⟨1, ⟨118, 145, 135, 147⟩⟩], unsure := false }
def o880 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 11, true, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o881 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 8, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o882 : Obs := { bars := [⟨12, 106, 109, .D, 11, false, false⟩, ⟨12, 106, 142, .D, 11, false, false⟩, ⟨14, 118, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o883 : Obs := { bars := [⟨12, 106, 109, .D, 14, false, false⟩, ⟨12, 106, 142, .D, 14, false, false⟩, ⟨14, 121, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o884 : Obs := { bars := [⟨12, 106, 109, .D, 17, false, false⟩, ⟨12, 106, 142, .D, 17, false, false⟩, ⟨14, 124, 109, .R, 5, true, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o885 : Obs := { bars := [⟨12, 106, 109, .D, 20, false, false⟩, ⟨12, 106, 142, .D, 20, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 127, 109, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o886 : Obs := { bars := [⟨12, 106, 109, .D, 23, false, false⟩, ⟨12, 106, 142, .D, 23, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 130, 109, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o887 : Obs := { bars := [⟨12, 106, 109, .D, 26, false, false⟩, ⟨12, 106, 142, .D, 26, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 133, 109, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o888 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 127, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 5, false, false⟩, ⟨14, 136, 109, .R, 5, true, false⟩], walls := [⟨1, ⟨127, 145, 144, 147⟩⟩], unsure := false }
def o889 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨9, 124, 156, .L, 8, false, false⟩, ⟨14, 135, 154, .U, 8, false, false⟩, ⟨14, 136, 109, .R, 8, true, false⟩], walls := [⟨1, ⟨124, 145, 141, 147⟩⟩], unsure := false }
def o890 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 5, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩, ⟨14, 136, 109, .R, 11, true, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o891 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 11, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩, ⟨14, 136, 109, .R, 11, true, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o892 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 14, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩, ⟨14, 136, 109, .R, 11, true, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o893 : Obs := { bars := [⟨12, 106, 109, .D, 29, false, false⟩, ⟨12, 106, 142, .D, 29, false, false⟩, ⟨9, 121, 156, .L, 8, false, false⟩, ⟨10, 124, 121, .R, 17, true, false⟩, ⟨14, 135, 154, .U, 11, false, false⟩, ⟨14, 136, 109, .R, 11, true, false⟩], walls := [⟨1, ⟨121, 145, 138, 147⟩⟩], unsure := false }
def o894 : Obs := { bars := [⟨9, 106, 136, .R, 5, true, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨11, 117, 136, .U, 8, false, false⟩], walls := [], unsure := false }
def o895 : Obs := { bars := [⟨11, 115, 138, .L, 8, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 117, 127, .U, 5, true, false⟩], walls := [], unsure := false }
def o896 : Obs := { bars := [⟨11, 115, 136, .D, 8, false, false⟩, ⟨14, 115, 141, .L, 2, false, false⟩, ⟨9, 124, 138, .L, 5, true, false⟩], walls := [], unsure := false }
def o897 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 139, .R, 8, false, false⟩, ⟨9, 118, 148, .D, 5, true, false⟩], walls := [], unsure := false }
def o898 : Obs := { bars := [⟨14, 115, 139, .D, 2, false, false⟩, ⟨11, 118, 139, .R, 11, false, false⟩, ⟨9, 118, 151, .D, 5, true, false⟩], walls := [], unsure := false }
def o899 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 11, false, false⟩, ⟨9, 121, 151, .D, 5, true, false⟩], walls := [], unsure := false }
def o900 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 11, false, false⟩, ⟨9, 121, 151, .R, 5, true, false⟩], walls := [], unsure := false }
def o901 : Obs := { bars := [⟨14, 115, 139, .D, 5, false, false⟩, ⟨11, 121, 139, .R, 11, false, false⟩, ⟨9, 123, 151, .U, 5, true, false⟩], walls := [], unsure := false }
def o902 : Obs := { bars := [⟨14, 115, 139, .D, 8, false, false⟩, ⟨11, 124, 139, .R, 11, false, false⟩, ⟨9, 126, 151, .U, 5, true, false⟩], walls := [], unsure := false }
def o903 : Obs := { bars := [⟨9, 103, 150, .L, 5, true, false⟩, ⟨14, 115, 139, .R, 8, false, false⟩, ⟨11, 117, 148, .U, 11, false, false⟩], walls := [], unsure := false }
def o904 : Obs := { bars := [⟨9, 106, 150, .L, 5, true, false⟩, ⟨14, 115, 139, .R, 8, false, false⟩, ⟨11, 117, 148, .U, 8, false, false⟩], walls := [], unsure := false }
def o905 : Obs := { bars := [⟨9, 106, 153, .L, 5, true, false⟩, ⟨14, 115, 139, .R, 11, false, false⟩, ⟨11, 117, 151, .U, 8, false, false⟩], walls := [], unsure := false }
def o906 : Obs := { bars := [⟨9, 106, 156, .L, 5, true, false⟩, ⟨14, 115, 139, .R, 14, false, false⟩, ⟨11, 117, 154, .U, 8, false, false⟩], walls := [], unsure := false }
def o907 : Obs := { bars := [⟨9, 109, 156, .L, 5, true, false⟩, ⟨14, 115, 139, .R, 14, false, false⟩, ⟨11, 117, 154, .U, 5, false, false⟩], walls := [], unsure := false }
def o908 : Obs := { bars := [⟨9, 100, 133, .D, 5, true, false⟩, ⟨11, 100, 141, .L, 5, false, false⟩, ⟨14, 117, 139, .U, 14, false, false⟩], walls := [], unsure := false }
def o909 : Obs := { bars := [⟨11, 115, 124, .D, 5, false, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨9, 121, 124, .R, 5, true, false⟩], walls := [], unsure := false }
def o910 : Obs := { bars := [⟨9, 109, 126, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 5, false, false⟩], walls := [], unsure := false }
def o911 : Obs := { bars := [⟨9, 106, 126, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 8, false, false⟩], walls := [], unsure := false }
def o912 : Obs := { bars := [⟨9, 103, 126, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 14, false, false⟩, ⟨11, 117, 124, .U, 11, false, false⟩], walls := [], unsure := false }
def o913 : Obs := { bars := [⟨9, 103, 123, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 17, false, false⟩, ⟨11, 117, 121, .U, 11, false, false⟩], walls := [], unsure := false }
def o914 : Obs := { bars := [⟨9, 103, 120, .L, 5, true, false⟩, ⟨14, 115, 141, .L, 20, false, false⟩, ⟨11, 117, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o915 : Obs := { bars := [⟨9, 103, 120, .L, 8, true, false⟩, ⟨14, 115, 141, .L, 20, false, false⟩, ⟨11, 117, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o916 : Obs := { bars := [⟨9, 103, 120, .L, 11, true, false⟩, ⟨14, 115, 141, .L, 20, false, false⟩, ⟨11, 117, 118, .U, 11, false, false⟩], walls := [], unsure := false }
def o917 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 8, false, false⟩, ⟨12, 115, 142, .R, 2, true, false⟩, ⟨14, 121, 150, .L, 5, false, false⟩, ⟨9, 123, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o918 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨12, 118, 142, .R, 2, true, false⟩, ⟨14, 124, 150, .L, 5, false, false⟩, ⟨9, 126, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o919 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 5, false, false⟩, ⟨12, 132, 142, .U, 2, true, false⟩], walls := [], unsure := false }
def o920 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 8, false, false⟩, ⟨12, 132, 139, .U, 2, true, false⟩], walls := [], unsure := false }
def o921 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 11, false, false⟩, ⟨12, 132, 136, .U, 2, true, false⟩], walls := [], unsure := false }
def o922 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 14, false, false⟩, ⟨12, 132, 133, .U, 2, true, false⟩], walls := [], unsure := false }
def o923 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 2, true, false⟩], walls := [], unsure := false }
def o924 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 5, true, false⟩], walls := [], unsure := false }
def o925 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 8, true, false⟩], walls := [], unsure := false }
def o926 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 11, true, false⟩], walls := [], unsure := false }
def o927 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 14, true, false⟩], walls := [], unsure := false }
def o928 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 17, true, false⟩], walls := [], unsure := false }
def o929 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .R, 5, false, false⟩, ⟨9, 124, 154, .D, 17, false, false⟩, ⟨12, 142, 156, .L, 17, true, false⟩], walls := [], unsure := false }
def o930 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 106, 142, .R, 17, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 150, .L, 5, false, false⟩, ⟨9, 126, 142, .U, 17, false, false⟩], walls := [], unsure := false }
def o931 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 8, false, false⟩, ⟨9, 133, 150, .L, 17, false, false⟩, ⟨12, 135, 130, .U, 17, true, false⟩], walls := [], unsure := false }
def o932 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 8, false, false⟩, ⟨9, 133, 150, .L, 17, false, false⟩, ⟨12, 135, 130, .U, 20, true, false⟩], walls := [], unsure := false }
def o933 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .R, 8, false, false⟩, ⟨9, 124, 157, .D, 17, false, false⟩, ⟨12, 142, 159, .L, 20, true, false⟩], walls := [], unsure := false }
def o934 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .R, 5, false, false⟩, ⟨9, 124, 154, .D, 17, false, false⟩, ⟨12, 142, 156, .L, 20, true, false⟩], walls := [], unsure := false }
def o935 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨12, 106, 142, .R, 20, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 150, .L, 5, false, false⟩, ⟨9, 126, 142, .U, 17, false, false⟩], walls := [], unsure := false }
def o936 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 5, false, false⟩, ⟨9, 130, 150, .L, 17, false, false⟩, ⟨12, 132, 130, .U, 20, true, false⟩], walls := [], unsure := false }
def o937 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 11, false, false⟩, ⟨9, 136, 150, .L, 17, false, false⟩, ⟨12, 138, 130, .U, 20, true, false⟩], walls := [], unsure := false }
def o938 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .D, 11, false, false⟩, ⟨9, 136, 150, .L, 17, false, false⟩, ⟨12, 138, 130, .U, 23, true, false⟩], walls := [], unsure := false }
def o939 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 11, false, false⟩, ⟨14, 124, 148, .R, 11, false, false⟩, ⟨9, 124, 160, .D, 17, false, false⟩, ⟨12, 142, 162, .L, 23, true, false⟩], walls := [], unsure := false }
def o940 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 14, false, false⟩, ⟨12, 121, 142, .R, 2, true, false⟩, ⟨14, 127, 150, .L, 5, false, false⟩, ⟨9, 129, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o941 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 17, false, false⟩, ⟨12, 124, 142, .R, 2, true, false⟩, ⟨14, 130, 150, .L, 5, false, false⟩, ⟨9, 132, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o942 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 20, false, false⟩, ⟨12, 127, 142, .R, 2, true, false⟩, ⟨14, 133, 150, .L, 5, false, false⟩, ⟨9, 135, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o943 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 130, 142, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 5, false, false⟩, ⟨9, 138, 142, .U, 5, false, false⟩], walls := [], unsure := false }
def o944 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 130, 139, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 8, false, false⟩, ⟨9, 138, 139, .U, 5, false, false⟩], walls := [], unsure := false }
def o945 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 130, 136, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 11, false, false⟩, ⟨9, 138, 136, .U, 5, false, false⟩], walls := [], unsure := false }
def o946 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 130, 133, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 14, false, false⟩, ⟨9, 138, 133, .U, 5, false, false⟩], walls := [], unsure := false }
def o947 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 130, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 5, false, false⟩], walls := [], unsure := false }
def o948 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 127, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 8, false, false⟩], walls := [], unsure := false }
def o949 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 124, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 11, false, false⟩], walls := [], unsure := false }
def o950 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 121, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 14, false, false⟩], walls := [], unsure := false }
def o951 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 118, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 17, false, false⟩], walls := [], unsure := false }
def o952 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 115, 130, .R, 2, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 20, false, false⟩], walls := [], unsure := false }
def o953 : Obs := { bars := [⟨8, 106, 112, .D, 14, false, false⟩, ⟨10, 106, 135, .L, 14, true, false⟩, ⟨11, 112, 148, .D, 23, false, false⟩, ⟨12, 115, 130, .R, 5, true, false⟩, ⟨14, 136, 150, .L, 17, false, false⟩, ⟨9, 138, 130, .U, 20, false, false⟩], walls := [], unsure := false }

def rows0 : List Row := [
  ⟨1, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨2, 0, 0, false, .click 24 44, bd0, o1, o2⟩,
  ⟨3, 0, 0, false, .click 39 21, bd0, o2, o3⟩,
  ⟨4, 0, 0, false, .click 45 21, bd0, o3, o2⟩,
  ⟨5, 0, 0, false, .click 45 21, bd0, o2, o4⟩,
  ⟨6, 0, 0, false, .click 45 21, bd0, o4, o5⟩,
  ⟨7, 0, 0, false, .click 45 21, bd0, o5, o6⟩,
  ⟨8, 0, 0, false, .click 45 21, bd0, o6, o7⟩,
  ⟨9, 0, 0, false, .click 45 21, bd0, o7, o8⟩,
  ⟨10, 0, 0, false, .click 24 44, bd0, o8, o9⟩,
  ⟨11, 0, 0, false, .click 24 44, bd0, o9, o10⟩,
  ⟨12, 0, 0, false, .click 24 44, bd0, o10, o11⟩,
  ⟨13, 0, 0, false, .click 24 44, bd0, o11, o12⟩,
  ⟨14, 0, 0, false, .click 45 21, bd0, o12, o13⟩,
  ⟨15, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨16, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨17, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨18, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨19, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨20, 1, 0, false, .click 12 57, bd1, o18, o19⟩,
  ⟨21, 1, 0, false, .click 12 57, bd1, o19, o20⟩,
  ⟨22, 1, 0, false, .click 12 57, bd1, o20, o21⟩,
  ⟨23, 1, 0, false, .click 12 57, bd1, o21, o22⟩,
  ⟨24, 1, 0, false, .click 27 57, bd1, o22, o23⟩,
  ⟨25, 1, 0, false, .click 27 57, bd1, o23, o24⟩,
  ⟨26, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨27, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨28, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨29, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨30, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨31, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨32, 1, 0, false, .click 27 57, bd1, o30, o30⟩,
  ⟨33, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨34, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨35, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨36, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨37, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨38, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨39, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨40, 1, 0, false, .click 42 57, bd1, o37, o38⟩,
  ⟨41, 1, 0, false, .click 42 57, bd1, o38, o39⟩,
  ⟨42, 1, 1, false, .click 57 57, bd1, o39, o40⟩,
  ⟨43, 2, 0, false, .click 16 48, bd2, o40, o41⟩,
  ⟨44, 2, 0, false, .click 54 48, bd2, o41, o42⟩,
  ⟨45, 2, 0, false, .click 54 48, bd2, o42, o42⟩,
  ⟨46, 2, 0, false, .click 10 48, bd2, o42, o43⟩,
  ⟨47, 2, 0, false, .click 10 48, bd2, o43, o44⟩,
  ⟨48, 2, 0, false, .click 10 48, bd2, o44, o44⟩,
  ⟨49, 2, 0, false, .click 10 48, bd2, o44, o44⟩,
  ⟨50, 2, 0, false, .click 10 48, bd2, o44, o44⟩,
  ⟨51, 2, 0, false, .click 10 48, bd2, o44, o44⟩,
  ⟨52, 2, 0, false, .click 10 48, bd2, o44, o44⟩,
  ⟨53, 2, 0, false, .click 48 48, bd2, o44, o45⟩,
  ⟨54, 2, 0, false, .click 48 48, bd2, o45, o46⟩,
  ⟨55, 2, 0, false, .click 48 48, bd2, o46, o47⟩,
  ⟨56, 2, 0, false, .click 48 48, bd2, o47, o47⟩,
  ⟨57, 2, 0, false, .click 48 48, bd2, o47, o47⟩,
  ⟨58, 2, 0, false, .click 48 48, bd2, o47, o47⟩,
  ⟨59, 2, 0, false, .click 35 48, bd2, o47, o48⟩,
  ⟨60, 2, 0, false, .click 35 48, bd2, o48, o49⟩]
def rows1 : List Row := [
  ⟨61, 2, 0, false, .click 35 48, bd2, o49, o50⟩,
  ⟨62, 2, 0, false, .click 35 48, bd2, o50, o51⟩,
  ⟨63, 2, 0, false, .click 35 48, bd2, o51, o52⟩,
  ⟨64, 2, 0, false, .click 35 48, bd2, o52, o53⟩,
  ⟨65, 2, 0, false, .click 35 48, bd2, o53, o53⟩,
  ⟨66, 2, 0, false, .click 35 48, bd2, o53, o53⟩,
  ⟨67, 2, 0, false, .click 35 48, bd2, o53, o53⟩,
  ⟨68, 2, 0, false, .click 35 48, bd2, o53, o53⟩,
  ⟨69, 2, 0, false, .click 35 48, bd2, o53, o53⟩,
  ⟨70, 2, 2, false, .reset, bd2, o53, o0⟩,
  ⟨71, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨72, 0, 0, false, .click 24 44, bd0, o1, o2⟩,
  ⟨73, 0, 0, false, .click 39 21, bd0, o2, o3⟩,
  ⟨74, 0, 0, false, .click 45 21, bd0, o3, o2⟩,
  ⟨75, 0, 0, false, .click 45 21, bd0, o2, o4⟩,
  ⟨76, 0, 0, false, .click 45 21, bd0, o4, o5⟩,
  ⟨77, 0, 0, false, .click 45 21, bd0, o5, o6⟩,
  ⟨78, 0, 0, false, .click 45 21, bd0, o6, o7⟩,
  ⟨79, 0, 0, false, .click 45 21, bd0, o7, o8⟩,
  ⟨80, 0, 0, false, .click 24 44, bd0, o8, o9⟩,
  ⟨81, 0, 0, false, .click 24 44, bd0, o9, o10⟩,
  ⟨82, 0, 0, false, .click 24 44, bd0, o10, o11⟩,
  ⟨83, 0, 0, false, .click 24 44, bd0, o11, o12⟩,
  ⟨84, 0, 0, false, .click 45 21, bd0, o12, o13⟩,
  ⟨85, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨86, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨87, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨88, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨89, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨90, 1, 0, false, .click 12 57, bd1, o18, o19⟩,
  ⟨91, 1, 0, false, .click 12 57, bd1, o19, o20⟩,
  ⟨92, 1, 0, false, .click 12 57, bd1, o20, o21⟩,
  ⟨93, 1, 0, false, .click 12 57, bd1, o21, o22⟩,
  ⟨94, 1, 0, false, .click 27 57, bd1, o22, o23⟩,
  ⟨95, 1, 0, false, .click 27 57, bd1, o23, o24⟩,
  ⟨96, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨97, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨98, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨99, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨100, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨101, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨102, 1, 0, false, .click 27 57, bd1, o30, o30⟩,
  ⟨103, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨104, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨105, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨106, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨107, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨108, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨109, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨110, 1, 0, false, .click 42 57, bd1, o37, o38⟩,
  ⟨111, 1, 0, false, .click 42 57, bd1, o38, o39⟩,
  ⟨112, 1, 1, false, .click 57 57, bd1, o39, o40⟩,
  ⟨113, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨114, 2, 0, false, .click 35 57, bd2, o54, o55⟩,
  ⟨115, 2, 0, false, .click 35 57, bd2, o55, o56⟩,
  ⟨116, 2, 0, false, .click 35 48, bd2, o56, o57⟩,
  ⟨117, 2, 0, false, .click 35 48, bd2, o57, o58⟩,
  ⟨118, 2, 0, false, .click 35 48, bd2, o58, o59⟩,
  ⟨119, 2, 0, false, .click 35 48, bd2, o59, o60⟩,
  ⟨120, 2, 0, false, .click 35 48, bd2, o60, o61⟩]
def rows2 : List Row := [
  ⟨121, 2, 0, false, .click 16 57, bd2, o61, o62⟩,
  ⟨122, 2, 0, false, .click 35 57, bd2, o62, o63⟩,
  ⟨123, 2, 0, false, .click 10 48, bd2, o63, o64⟩,
  ⟨124, 2, 0, false, .click 16 48, bd2, o64, o63⟩,
  ⟨125, 2, 0, false, .click 54 57, bd2, o63, o65⟩,
  ⟨126, 2, 0, false, .click 54 48, bd2, o65, o66⟩,
  ⟨127, 2, 0, false, .click 54 48, bd2, o66, o67⟩,
  ⟨128, 2, 0, false, .click 54 48, bd2, o67, o68⟩,
  ⟨129, 2, 0, false, .click 29 57, bd2, o68, o69⟩,
  ⟨130, 2, 0, false, .click 10 57, bd2, o69, o69⟩,
  ⟨131, 2, 0, false, .click 35 48, bd2, o69, o69⟩,
  ⟨132, 2, 0, false, .click 54 57, bd2, o69, o69⟩,
  ⟨133, 2, 0, false, .click 48 57, bd2, o69, o69⟩,
  ⟨134, 2, 0, false, .click 16 57, bd2, o69, o69⟩,
  ⟨135, 2, 0, false, .click 35 57, bd2, o69, o68⟩,
  ⟨136, 2, 0, false, .click 48 48, bd2, o68, o67⟩,
  ⟨137, 2, 0, false, .click 48 48, bd2, o67, o66⟩,
  ⟨138, 2, 0, false, .click 48 48, bd2, o66, o65⟩,
  ⟨139, 2, 0, false, .click 48 48, bd2, o65, o70⟩,
  ⟨140, 2, 0, false, .click 48 48, bd2, o70, o71⟩,
  ⟨141, 2, 0, false, .click 29 48, bd2, o71, o72⟩,
  ⟨142, 2, 0, false, .click 16 57, bd2, o72, o73⟩,
  ⟨143, 2, 0, false, .click 29 48, bd2, o73, o74⟩,
  ⟨144, 2, 0, false, .click 16 57, bd2, o74, o75⟩,
  ⟨145, 2, 0, false, .click 29 48, bd2, o75, o76⟩,
  ⟨146, 2, 0, false, .click 16 57, bd2, o76, o77⟩,
  ⟨147, 2, 0, false, .click 10 48, bd2, o77, o78⟩,
  ⟨148, 2, 0, false, .click 10 48, bd2, o78, o79⟩,
  ⟨149, 2, 0, false, .click 10 48, bd2, o79, o80⟩,
  ⟨150, 2, 0, false, .click 10 48, bd2, o80, o81⟩,
  ⟨151, 2, 0, false, .click 10 48, bd2, o81, o82⟩,
  ⟨152, 2, 0, false, .click 35 48, bd2, o82, o83⟩,
  ⟨153, 2, 0, false, .click 35 48, bd2, o83, o84⟩,
  ⟨154, 2, 0, false, .click 35 48, bd2, o84, o85⟩,
  ⟨155, 2, 0, false, .click 35 48, bd2, o85, o86⟩,
  ⟨156, 2, 0, false, .click 35 48, bd2, o86, o87⟩,
  ⟨157, 2, 0, false, .click 35 48, bd2, o87, o88⟩,
  ⟨158, 2, 0, false, .click 35 48, bd2, o88, o89⟩,
  ⟨159, 2, 0, false, .click 35 48, bd2, o89, o90⟩,
  ⟨160, 2, 0, false, .click 35 48, bd2, o90, o91⟩,
  ⟨161, 2, 0, false, .click 48 57, bd2, o91, o92⟩,
  ⟨162, 2, 0, false, .click 10 57, bd2, o92, o93⟩,
  ⟨163, 2, 0, false, .click 54 57, bd2, o93, o94⟩,
  ⟨164, 2, 0, false, .click 35 48, bd2, o94, o94⟩,
  ⟨165, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨166, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨167, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨168, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨169, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨170, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨171, 2, 0, false, .click 48 57, bd2, o94, o93⟩,
  ⟨172, 2, 0, false, .click 16 57, bd2, o93, o92⟩,
  ⟨173, 2, 0, false, .click 54 57, bd2, o92, o91⟩,
  ⟨174, 2, 0, false, .click 10 57, bd2, o91, o94⟩,
  ⟨175, 2, 0, false, .click 10 48, bd2, o94, o95⟩,
  ⟨176, 2, 0, false, .click 16 57, bd2, o95, o96⟩,
  ⟨177, 2, 0, false, .click 29 57, bd2, o96, o97⟩,
  ⟨178, 2, 0, false, .click 54 57, bd2, o97, o98⟩,
  ⟨179, 2, 0, false, .click 29 57, bd2, o98, o99⟩,
  ⟨180, 2, 0, false, .click 54 57, bd2, o99, o100⟩]
def rows3 : List Row := [
  ⟨181, 2, 0, false, .click 29 57, bd2, o100, o101⟩,
  ⟨182, 2, 0, false, .click 54 57, bd2, o101, o102⟩,
  ⟨183, 2, 0, false, .click 35 48, bd2, o102, o103⟩,
  ⟨184, 2, 0, false, .click 48 48, bd2, o103, o104⟩,
  ⟨185, 2, 0, false, .click 48 48, bd2, o104, o105⟩,
  ⟨186, 2, 0, false, .click 35 57, bd2, o105, o105⟩,
  ⟨187, 2, 0, false, .click 48 48, bd2, o105, o106⟩,
  ⟨188, 2, 0, false, .click 35 57, bd2, o106, o107⟩,
  ⟨189, 2, 0, false, .click 35 57, bd2, o107, o108⟩,
  ⟨190, 2, 0, false, .click 35 57, bd2, o108, o109⟩,
  ⟨191, 2, 0, false, .click 35 57, bd2, o109, o110⟩,
  ⟨192, 2, 0, false, .click 35 57, bd2, o110, o111⟩,
  ⟨193, 2, 0, false, .click 35 57, bd2, o111, o112⟩,
  ⟨194, 2, 1, false, .click 35 57, bd2, o112, o113⟩,
  ⟨195, 3, 0, false, .click 34 54, bd3, o113, o114⟩,
  ⟨196, 3, 0, false, .click 57 57, bd3, o114, o115⟩,
  ⟨197, 3, 0, false, .click 34 54, bd3, o115, o116⟩,
  ⟨198, 3, 0, false, .click 34 54, bd3, o116, o117⟩,
  ⟨199, 3, 0, false, .click 34 54, bd3, o117, o118⟩,
  ⟨200, 3, 0, false, .click 34 54, bd3, o118, o119⟩,
  ⟨201, 3, 0, false, .click 34 54, bd3, o119, o119⟩,
  ⟨202, 3, 0, false, .click 34 54, bd3, o119, o119⟩,
  ⟨203, 3, 2, false, .reset, bd3, o119, o0⟩,
  ⟨204, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨205, 0, 0, false, .click 24 44, bd0, o1, o2⟩,
  ⟨206, 0, 0, false, .click 39 21, bd0, o2, o3⟩,
  ⟨207, 0, 0, false, .click 45 21, bd0, o3, o2⟩,
  ⟨208, 0, 0, false, .click 45 21, bd0, o2, o4⟩,
  ⟨209, 0, 0, false, .click 45 21, bd0, o4, o5⟩,
  ⟨210, 0, 0, false, .click 45 21, bd0, o5, o6⟩,
  ⟨211, 0, 0, false, .click 45 21, bd0, o6, o7⟩,
  ⟨212, 0, 0, false, .click 45 21, bd0, o7, o8⟩,
  ⟨213, 0, 0, false, .click 24 44, bd0, o8, o9⟩,
  ⟨214, 0, 0, false, .click 24 44, bd0, o9, o10⟩,
  ⟨215, 0, 0, false, .click 24 44, bd0, o10, o11⟩,
  ⟨216, 0, 0, false, .click 24 44, bd0, o11, o12⟩,
  ⟨217, 0, 0, false, .click 45 21, bd0, o12, o13⟩,
  ⟨218, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨219, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨220, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨221, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨222, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨223, 1, 0, false, .click 12 57, bd1, o18, o19⟩,
  ⟨224, 1, 0, false, .click 12 57, bd1, o19, o20⟩,
  ⟨225, 1, 0, false, .click 12 57, bd1, o20, o21⟩,
  ⟨226, 1, 0, false, .click 12 57, bd1, o21, o22⟩,
  ⟨227, 1, 0, false, .click 27 57, bd1, o22, o23⟩,
  ⟨228, 1, 0, false, .click 27 57, bd1, o23, o24⟩,
  ⟨229, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨230, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨231, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨232, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨233, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨234, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨235, 1, 0, false, .click 27 57, bd1, o30, o30⟩,
  ⟨236, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨237, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨238, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨239, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨240, 1, 0, false, .click 57 57, bd1, o34, o35⟩]
def rows4 : List Row := [
  ⟨241, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨242, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨243, 1, 0, false, .click 42 57, bd1, o37, o38⟩,
  ⟨244, 1, 0, false, .click 42 57, bd1, o38, o39⟩,
  ⟨245, 1, 1, false, .click 57 57, bd1, o39, o40⟩,
  ⟨246, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨247, 2, 0, false, .click 35 57, bd2, o54, o55⟩,
  ⟨248, 2, 0, false, .click 35 57, bd2, o55, o56⟩,
  ⟨249, 2, 0, false, .click 35 48, bd2, o56, o57⟩,
  ⟨250, 2, 0, false, .click 35 48, bd2, o57, o58⟩,
  ⟨251, 2, 0, false, .click 35 48, bd2, o58, o59⟩,
  ⟨252, 2, 0, false, .click 35 48, bd2, o59, o60⟩,
  ⟨253, 2, 0, false, .click 35 48, bd2, o60, o61⟩,
  ⟨254, 2, 0, false, .click 16 57, bd2, o61, o62⟩,
  ⟨255, 2, 0, false, .click 35 57, bd2, o62, o63⟩,
  ⟨256, 2, 0, false, .click 10 48, bd2, o63, o64⟩,
  ⟨257, 2, 0, false, .click 16 48, bd2, o64, o63⟩,
  ⟨258, 2, 0, false, .click 54 57, bd2, o63, o65⟩,
  ⟨259, 2, 0, false, .click 54 48, bd2, o65, o66⟩,
  ⟨260, 2, 0, false, .click 54 48, bd2, o66, o67⟩,
  ⟨261, 2, 0, false, .click 54 48, bd2, o67, o68⟩,
  ⟨262, 2, 0, false, .click 29 57, bd2, o68, o69⟩,
  ⟨263, 2, 0, false, .click 10 57, bd2, o69, o69⟩,
  ⟨264, 2, 0, false, .click 35 48, bd2, o69, o69⟩,
  ⟨265, 2, 0, false, .click 54 57, bd2, o69, o69⟩,
  ⟨266, 2, 0, false, .click 48 57, bd2, o69, o69⟩,
  ⟨267, 2, 0, false, .click 16 57, bd2, o69, o69⟩,
  ⟨268, 2, 0, false, .click 35 57, bd2, o69, o68⟩,
  ⟨269, 2, 0, false, .click 48 48, bd2, o68, o67⟩,
  ⟨270, 2, 0, false, .click 48 48, bd2, o67, o66⟩,
  ⟨271, 2, 0, false, .click 48 48, bd2, o66, o65⟩,
  ⟨272, 2, 0, false, .click 48 48, bd2, o65, o70⟩,
  ⟨273, 2, 0, false, .click 48 48, bd2, o70, o71⟩,
  ⟨274, 2, 0, false, .click 29 48, bd2, o71, o72⟩,
  ⟨275, 2, 0, false, .click 16 57, bd2, o72, o73⟩,
  ⟨276, 2, 0, false, .click 29 48, bd2, o73, o74⟩,
  ⟨277, 2, 0, false, .click 16 57, bd2, o74, o75⟩,
  ⟨278, 2, 0, false, .click 29 48, bd2, o75, o76⟩,
  ⟨279, 2, 0, false, .click 16 57, bd2, o76, o77⟩,
  ⟨280, 2, 0, false, .click 10 48, bd2, o77, o78⟩,
  ⟨281, 2, 0, false, .click 10 48, bd2, o78, o79⟩,
  ⟨282, 2, 0, false, .click 10 48, bd2, o79, o80⟩,
  ⟨283, 2, 0, false, .click 10 48, bd2, o80, o81⟩,
  ⟨284, 2, 0, false, .click 10 48, bd2, o81, o82⟩,
  ⟨285, 2, 0, false, .click 35 48, bd2, o82, o83⟩,
  ⟨286, 2, 0, false, .click 35 48, bd2, o83, o84⟩,
  ⟨287, 2, 0, false, .click 35 48, bd2, o84, o85⟩,
  ⟨288, 2, 0, false, .click 35 48, bd2, o85, o86⟩,
  ⟨289, 2, 0, false, .click 35 48, bd2, o86, o87⟩,
  ⟨290, 2, 0, false, .click 35 48, bd2, o87, o88⟩,
  ⟨291, 2, 0, false, .click 35 48, bd2, o88, o89⟩,
  ⟨292, 2, 0, false, .click 35 48, bd2, o89, o90⟩,
  ⟨293, 2, 0, false, .click 35 48, bd2, o90, o91⟩,
  ⟨294, 2, 0, false, .click 48 57, bd2, o91, o92⟩,
  ⟨295, 2, 0, false, .click 10 57, bd2, o92, o93⟩,
  ⟨296, 2, 0, false, .click 54 57, bd2, o93, o94⟩,
  ⟨297, 2, 0, false, .click 35 48, bd2, o94, o94⟩,
  ⟨298, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨299, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨300, 2, 0, false, .click 35 57, bd2, o94, o94⟩]
def rows5 : List Row := [
  ⟨301, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨302, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨303, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨304, 2, 0, false, .click 48 57, bd2, o94, o93⟩,
  ⟨305, 2, 0, false, .click 16 57, bd2, o93, o92⟩,
  ⟨306, 2, 0, false, .click 54 57, bd2, o92, o91⟩,
  ⟨307, 2, 0, false, .click 10 57, bd2, o91, o94⟩,
  ⟨308, 2, 0, false, .click 10 48, bd2, o94, o95⟩,
  ⟨309, 2, 0, false, .click 16 57, bd2, o95, o96⟩,
  ⟨310, 2, 0, false, .click 29 57, bd2, o96, o97⟩,
  ⟨311, 2, 0, false, .click 54 57, bd2, o97, o98⟩,
  ⟨312, 2, 0, false, .click 29 57, bd2, o98, o99⟩,
  ⟨313, 2, 0, false, .click 54 57, bd2, o99, o100⟩,
  ⟨314, 2, 0, false, .click 29 57, bd2, o100, o101⟩,
  ⟨315, 2, 0, false, .click 54 57, bd2, o101, o102⟩,
  ⟨316, 2, 0, false, .click 35 48, bd2, o102, o103⟩,
  ⟨317, 2, 0, false, .click 48 48, bd2, o103, o104⟩,
  ⟨318, 2, 0, false, .click 48 48, bd2, o104, o105⟩,
  ⟨319, 2, 0, false, .click 35 57, bd2, o105, o105⟩,
  ⟨320, 2, 0, false, .click 48 48, bd2, o105, o106⟩,
  ⟨321, 2, 0, false, .click 35 57, bd2, o106, o107⟩,
  ⟨322, 2, 0, false, .click 35 57, bd2, o107, o108⟩,
  ⟨323, 2, 0, false, .click 35 57, bd2, o108, o109⟩,
  ⟨324, 2, 0, false, .click 35 57, bd2, o109, o110⟩,
  ⟨325, 2, 0, false, .click 35 57, bd2, o110, o111⟩,
  ⟨326, 2, 0, false, .click 35 57, bd2, o111, o112⟩,
  ⟨327, 2, 1, false, .click 35 57, bd2, o112, o113⟩,
  ⟨328, 3, 0, false, .click 34 54, bd3, o113, o114⟩,
  ⟨329, 3, 0, false, .click 57 57, bd3, o114, o115⟩,
  ⟨330, 3, 0, false, .click 34 54, bd3, o115, o116⟩,
  ⟨331, 3, 0, false, .click 34 54, bd3, o116, o117⟩,
  ⟨332, 3, 0, false, .click 34 54, bd3, o117, o118⟩,
  ⟨333, 3, 0, false, .click 34 54, bd3, o118, o119⟩,
  ⟨334, 3, 0, false, .click 34 54, bd3, o119, o119⟩,
  ⟨335, 3, 0, false, .click 34 54, bd3, o119, o119⟩,
  ⟨336, 3, 0, false, .click 12 48, bd3, o119, o120⟩,
  ⟨337, 3, 0, false, .click 12 57, bd3, o120, o121⟩,
  ⟨338, 3, 0, false, .click 34 54, bd3, o121, o122⟩,
  ⟨339, 3, 0, false, .click 12 48, bd3, o122, o123⟩,
  ⟨340, 3, 0, false, .click 12 57, bd3, o123, o124⟩,
  ⟨341, 3, 0, false, .click 34 54, bd3, o124, o125⟩,
  ⟨342, 3, 0, false, .click 12 48, bd3, o125, o126⟩,
  ⟨343, 3, 0, false, .click 57 48, bd3, o126, o127⟩,
  ⟨344, 3, 0, false, .click 57 57, bd3, o127, o128⟩,
  ⟨345, 3, 0, false, .click 12 57, bd3, o128, o129⟩,
  ⟨346, 3, 0, false, .click 34 54, bd3, o129, o130⟩,
  ⟨347, 3, 0, false, .click 12 48, bd3, o130, o131⟩,
  ⟨348, 3, 0, false, .click 57 48, bd3, o131, o132⟩,
  ⟨349, 3, 0, false, .click 57 57, bd3, o132, o133⟩,
  ⟨350, 3, 0, false, .click 12 57, bd3, o133, o134⟩,
  ⟨351, 3, 0, false, .click 51 57, bd3, o134, o134⟩,
  ⟨352, 3, 0, false, .click 34 54, bd3, o134, o134⟩,
  ⟨353, 3, 2, false, .reset, bd3, o134, o0⟩,
  ⟨354, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨355, 0, 0, false, .click 24 44, bd0, o1, o2⟩,
  ⟨356, 0, 0, false, .click 39 21, bd0, o2, o3⟩,
  ⟨357, 0, 0, false, .click 45 21, bd0, o3, o2⟩,
  ⟨358, 0, 0, false, .click 45 21, bd0, o2, o4⟩,
  ⟨359, 0, 0, false, .click 45 21, bd0, o4, o5⟩,
  ⟨360, 0, 0, false, .click 45 21, bd0, o5, o6⟩]
def rows6 : List Row := [
  ⟨361, 0, 0, false, .click 45 21, bd0, o6, o7⟩,
  ⟨362, 0, 0, false, .click 45 21, bd0, o7, o8⟩,
  ⟨363, 0, 0, false, .click 24 44, bd0, o8, o9⟩,
  ⟨364, 0, 0, false, .click 24 44, bd0, o9, o10⟩,
  ⟨365, 0, 0, false, .click 24 44, bd0, o10, o11⟩,
  ⟨366, 0, 0, false, .click 24 44, bd0, o11, o12⟩,
  ⟨367, 0, 0, false, .click 45 21, bd0, o12, o13⟩,
  ⟨368, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨369, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨370, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨371, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨372, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨373, 1, 0, false, .click 12 57, bd1, o18, o19⟩,
  ⟨374, 1, 0, false, .click 12 57, bd1, o19, o20⟩,
  ⟨375, 1, 0, false, .click 12 57, bd1, o20, o21⟩,
  ⟨376, 1, 0, false, .click 12 57, bd1, o21, o22⟩,
  ⟨377, 1, 0, false, .click 27 57, bd1, o22, o23⟩,
  ⟨378, 1, 0, false, .click 27 57, bd1, o23, o24⟩,
  ⟨379, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨380, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨381, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨382, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨383, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨384, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨385, 1, 0, false, .click 27 57, bd1, o30, o30⟩,
  ⟨386, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨387, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨388, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨389, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨390, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨391, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨392, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨393, 1, 0, false, .click 42 57, bd1, o37, o38⟩,
  ⟨394, 1, 0, false, .click 42 57, bd1, o38, o39⟩,
  ⟨395, 1, 1, false, .click 57 57, bd1, o39, o40⟩,
  ⟨396, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨397, 2, 0, false, .click 35 57, bd2, o54, o55⟩,
  ⟨398, 2, 0, false, .click 35 57, bd2, o55, o56⟩,
  ⟨399, 2, 0, false, .click 35 48, bd2, o56, o57⟩,
  ⟨400, 2, 0, false, .click 35 48, bd2, o57, o58⟩,
  ⟨401, 2, 0, false, .click 35 48, bd2, o58, o59⟩,
  ⟨402, 2, 0, false, .click 35 48, bd2, o59, o60⟩,
  ⟨403, 2, 0, false, .click 35 48, bd2, o60, o61⟩,
  ⟨404, 2, 0, false, .click 16 57, bd2, o61, o62⟩,
  ⟨405, 2, 0, false, .click 35 57, bd2, o62, o63⟩,
  ⟨406, 2, 0, false, .click 10 48, bd2, o63, o64⟩,
  ⟨407, 2, 0, false, .click 16 48, bd2, o64, o63⟩,
  ⟨408, 2, 0, false, .click 54 57, bd2, o63, o65⟩,
  ⟨409, 2, 0, false, .click 54 48, bd2, o65, o66⟩,
  ⟨410, 2, 0, false, .click 54 48, bd2, o66, o67⟩,
  ⟨411, 2, 0, false, .click 54 48, bd2, o67, o68⟩,
  ⟨412, 2, 0, false, .click 29 57, bd2, o68, o69⟩,
  ⟨413, 2, 0, false, .click 10 57, bd2, o69, o69⟩,
  ⟨414, 2, 0, false, .click 35 48, bd2, o69, o69⟩,
  ⟨415, 2, 0, false, .click 54 57, bd2, o69, o69⟩,
  ⟨416, 2, 0, false, .click 48 57, bd2, o69, o69⟩,
  ⟨417, 2, 0, false, .click 16 57, bd2, o69, o69⟩,
  ⟨418, 2, 0, false, .click 35 57, bd2, o69, o68⟩,
  ⟨419, 2, 0, false, .click 48 48, bd2, o68, o67⟩,
  ⟨420, 2, 0, false, .click 48 48, bd2, o67, o66⟩]
def rows7 : List Row := [
  ⟨421, 2, 0, false, .click 48 48, bd2, o66, o65⟩,
  ⟨422, 2, 0, false, .click 48 48, bd2, o65, o70⟩,
  ⟨423, 2, 0, false, .click 48 48, bd2, o70, o71⟩,
  ⟨424, 2, 0, false, .click 29 48, bd2, o71, o72⟩,
  ⟨425, 2, 0, false, .click 16 57, bd2, o72, o73⟩,
  ⟨426, 2, 0, false, .click 29 48, bd2, o73, o74⟩,
  ⟨427, 2, 0, false, .click 16 57, bd2, o74, o75⟩,
  ⟨428, 2, 0, false, .click 29 48, bd2, o75, o76⟩,
  ⟨429, 2, 0, false, .click 16 57, bd2, o76, o77⟩,
  ⟨430, 2, 0, false, .click 10 48, bd2, o77, o78⟩,
  ⟨431, 2, 0, false, .click 10 48, bd2, o78, o79⟩,
  ⟨432, 2, 0, false, .click 10 48, bd2, o79, o80⟩,
  ⟨433, 2, 0, false, .click 10 48, bd2, o80, o81⟩,
  ⟨434, 2, 0, false, .click 10 48, bd2, o81, o82⟩,
  ⟨435, 2, 0, false, .click 35 48, bd2, o82, o83⟩,
  ⟨436, 2, 0, false, .click 35 48, bd2, o83, o84⟩,
  ⟨437, 2, 0, false, .click 35 48, bd2, o84, o85⟩,
  ⟨438, 2, 0, false, .click 35 48, bd2, o85, o86⟩,
  ⟨439, 2, 0, false, .click 35 48, bd2, o86, o87⟩,
  ⟨440, 2, 0, false, .click 35 48, bd2, o87, o88⟩,
  ⟨441, 2, 0, false, .click 35 48, bd2, o88, o89⟩,
  ⟨442, 2, 0, false, .click 35 48, bd2, o89, o90⟩,
  ⟨443, 2, 0, false, .click 35 48, bd2, o90, o91⟩,
  ⟨444, 2, 0, false, .click 48 57, bd2, o91, o92⟩,
  ⟨445, 2, 0, false, .click 10 57, bd2, o92, o93⟩,
  ⟨446, 2, 0, false, .click 54 57, bd2, o93, o94⟩,
  ⟨447, 2, 0, false, .click 35 48, bd2, o94, o94⟩,
  ⟨448, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨449, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨450, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨451, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨452, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨453, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨454, 2, 0, false, .click 48 57, bd2, o94, o93⟩,
  ⟨455, 2, 0, false, .click 16 57, bd2, o93, o92⟩,
  ⟨456, 2, 0, false, .click 54 57, bd2, o92, o91⟩,
  ⟨457, 2, 0, false, .click 10 57, bd2, o91, o94⟩,
  ⟨458, 2, 0, false, .click 10 48, bd2, o94, o95⟩,
  ⟨459, 2, 0, false, .click 16 57, bd2, o95, o96⟩,
  ⟨460, 2, 0, false, .click 29 57, bd2, o96, o97⟩,
  ⟨461, 2, 0, false, .click 54 57, bd2, o97, o98⟩,
  ⟨462, 2, 0, false, .click 29 57, bd2, o98, o99⟩,
  ⟨463, 2, 0, false, .click 54 57, bd2, o99, o100⟩,
  ⟨464, 2, 0, false, .click 29 57, bd2, o100, o101⟩,
  ⟨465, 2, 0, false, .click 54 57, bd2, o101, o102⟩,
  ⟨466, 2, 0, false, .click 35 48, bd2, o102, o103⟩,
  ⟨467, 2, 0, false, .click 48 48, bd2, o103, o104⟩,
  ⟨468, 2, 0, false, .click 48 48, bd2, o104, o105⟩,
  ⟨469, 2, 0, false, .click 35 57, bd2, o105, o105⟩,
  ⟨470, 2, 0, false, .click 48 48, bd2, o105, o106⟩,
  ⟨471, 2, 0, false, .click 35 57, bd2, o106, o107⟩,
  ⟨472, 2, 0, false, .click 35 57, bd2, o107, o108⟩,
  ⟨473, 2, 0, false, .click 35 57, bd2, o108, o109⟩,
  ⟨474, 2, 0, false, .click 35 57, bd2, o109, o110⟩,
  ⟨475, 2, 0, false, .click 35 57, bd2, o110, o111⟩,
  ⟨476, 2, 0, false, .click 35 57, bd2, o111, o112⟩,
  ⟨477, 2, 1, false, .click 35 57, bd2, o112, o113⟩,
  ⟨478, 3, 0, false, .click 28 54, bd3, o113, o113⟩,
  ⟨479, 3, 0, false, .click 51 57, bd3, o113, o113⟩,
  ⟨480, 3, 0, false, .click 51 48, bd3, o113, o113⟩]
def rows8 : List Row := [
  ⟨481, 3, 0, false, .click 6 48, bd3, o113, o113⟩,
  ⟨482, 3, 0, false, .click 6 57, bd3, o113, o135⟩,
  ⟨483, 3, 0, false, .click 34 54, bd3, o135, o136⟩,
  ⟨484, 3, 0, false, .click 34 54, bd3, o136, o137⟩,
  ⟨485, 3, 0, false, .click 34 54, bd3, o137, o138⟩,
  ⟨486, 3, 0, false, .click 57 48, bd3, o138, o139⟩,
  ⟨487, 3, 0, false, .click 57 48, bd3, o139, o140⟩,
  ⟨488, 3, 0, false, .click 57 48, bd3, o140, o141⟩,
  ⟨489, 3, 0, false, .click 57 48, bd3, o141, o142⟩,
  ⟨490, 3, 0, false, .click 57 48, bd3, o142, o142⟩,
  ⟨491, 3, 0, false, .click 12 48, bd3, o142, o143⟩,
  ⟨492, 3, 0, false, .click 12 48, bd3, o143, o144⟩,
  ⟨493, 3, 0, false, .click 12 48, bd3, o144, o145⟩,
  ⟨494, 3, 0, false, .click 12 48, bd3, o145, o146⟩,
  ⟨495, 3, 0, false, .click 57 57, bd3, o146, o147⟩,
  ⟨496, 3, 0, false, .click 57 57, bd3, o147, o148⟩,
  ⟨497, 3, 0, false, .click 57 57, bd3, o148, o149⟩,
  ⟨498, 3, 0, false, .click 57 57, bd3, o149, o150⟩,
  ⟨499, 3, 0, false, .click 6 57, bd3, o150, o151⟩,
  ⟨500, 3, 0, false, .click 6 57, bd3, o151, o152⟩,
  ⟨501, 3, 0, false, .click 6 57, bd3, o152, o153⟩,
  ⟨502, 3, 0, false, .click 6 57, bd3, o153, o154⟩,
  ⟨503, 3, 0, false, .click 6 57, bd3, o154, o155⟩,
  ⟨504, 3, 0, false, .click 6 57, bd3, o155, o156⟩,
  ⟨505, 3, 0, false, .click 34 54, bd3, o156, o157⟩,
  ⟨506, 3, 0, false, .click 34 54, bd3, o157, o158⟩,
  ⟨507, 3, 0, false, .click 34 54, bd3, o158, o159⟩,
  ⟨508, 3, 0, false, .click 6 57, bd3, o159, o160⟩,
  ⟨509, 3, 0, false, .click 34 54, bd3, o160, o161⟩,
  ⟨510, 3, 0, false, .click 34 54, bd3, o161, o162⟩,
  ⟨511, 3, 0, false, .click 34 54, bd3, o162, o163⟩,
  ⟨512, 3, 0, false, .click 34 54, bd3, o163, o164⟩,
  ⟨513, 3, 2, false, .reset, bd3, o164, o0⟩,
  ⟨514, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨515, 0, 0, false, .click 24 44, bd0, o1, o2⟩,
  ⟨516, 0, 0, false, .click 39 21, bd0, o2, o3⟩,
  ⟨517, 0, 0, false, .click 45 21, bd0, o3, o2⟩,
  ⟨518, 0, 0, false, .click 45 21, bd0, o2, o4⟩,
  ⟨519, 0, 0, false, .click 45 21, bd0, o4, o5⟩,
  ⟨520, 0, 0, false, .click 45 21, bd0, o5, o6⟩,
  ⟨521, 0, 0, false, .click 45 21, bd0, o6, o7⟩,
  ⟨522, 0, 0, false, .click 45 21, bd0, o7, o8⟩,
  ⟨523, 0, 0, false, .click 24 44, bd0, o8, o9⟩,
  ⟨524, 0, 0, false, .click 24 44, bd0, o9, o10⟩,
  ⟨525, 0, 0, false, .click 24 44, bd0, o10, o11⟩,
  ⟨526, 0, 0, false, .click 24 44, bd0, o11, o12⟩,
  ⟨527, 0, 0, false, .click 45 21, bd0, o12, o13⟩,
  ⟨528, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨529, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨530, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨531, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨532, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨533, 1, 0, false, .click 12 57, bd1, o18, o19⟩,
  ⟨534, 1, 0, false, .click 12 57, bd1, o19, o20⟩,
  ⟨535, 1, 0, false, .click 12 57, bd1, o20, o21⟩,
  ⟨536, 1, 0, false, .click 12 57, bd1, o21, o22⟩,
  ⟨537, 1, 0, false, .click 27 57, bd1, o22, o23⟩,
  ⟨538, 1, 0, false, .click 27 57, bd1, o23, o24⟩,
  ⟨539, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨540, 1, 0, false, .click 27 57, bd1, o25, o26⟩]
def rows9 : List Row := [
  ⟨541, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨542, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨543, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨544, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨545, 1, 0, false, .click 27 57, bd1, o30, o30⟩,
  ⟨546, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨547, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨548, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨549, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨550, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨551, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨552, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨553, 1, 0, false, .click 42 57, bd1, o37, o38⟩,
  ⟨554, 1, 0, false, .click 42 57, bd1, o38, o39⟩,
  ⟨555, 1, 1, false, .click 57 57, bd1, o39, o40⟩,
  ⟨556, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨557, 2, 0, false, .click 35 57, bd2, o54, o55⟩,
  ⟨558, 2, 0, false, .click 35 57, bd2, o55, o56⟩,
  ⟨559, 2, 0, false, .click 35 48, bd2, o56, o57⟩,
  ⟨560, 2, 0, false, .click 35 48, bd2, o57, o58⟩,
  ⟨561, 2, 0, false, .click 35 48, bd2, o58, o59⟩,
  ⟨562, 2, 0, false, .click 35 48, bd2, o59, o60⟩,
  ⟨563, 2, 0, false, .click 35 48, bd2, o60, o61⟩,
  ⟨564, 2, 0, false, .click 16 57, bd2, o61, o62⟩,
  ⟨565, 2, 0, false, .click 35 57, bd2, o62, o63⟩,
  ⟨566, 2, 0, false, .click 10 48, bd2, o63, o64⟩,
  ⟨567, 2, 0, false, .click 16 48, bd2, o64, o63⟩,
  ⟨568, 2, 0, false, .click 54 57, bd2, o63, o65⟩,
  ⟨569, 2, 0, false, .click 54 48, bd2, o65, o66⟩,
  ⟨570, 2, 0, false, .click 54 48, bd2, o66, o67⟩,
  ⟨571, 2, 0, false, .click 54 48, bd2, o67, o68⟩,
  ⟨572, 2, 0, false, .click 29 57, bd2, o68, o69⟩,
  ⟨573, 2, 0, false, .click 10 57, bd2, o69, o69⟩,
  ⟨574, 2, 0, false, .click 35 48, bd2, o69, o69⟩,
  ⟨575, 2, 0, false, .click 54 57, bd2, o69, o69⟩,
  ⟨576, 2, 0, false, .click 48 57, bd2, o69, o69⟩,
  ⟨577, 2, 0, false, .click 16 57, bd2, o69, o69⟩,
  ⟨578, 2, 0, false, .click 35 57, bd2, o69, o68⟩,
  ⟨579, 2, 0, false, .click 48 48, bd2, o68, o67⟩,
  ⟨580, 2, 0, false, .click 48 48, bd2, o67, o66⟩,
  ⟨581, 2, 0, false, .click 48 48, bd2, o66, o65⟩,
  ⟨582, 2, 0, false, .click 48 48, bd2, o65, o70⟩,
  ⟨583, 2, 0, false, .click 48 48, bd2, o70, o71⟩,
  ⟨584, 2, 0, false, .click 29 48, bd2, o71, o72⟩,
  ⟨585, 2, 0, false, .click 16 57, bd2, o72, o73⟩,
  ⟨586, 2, 0, false, .click 29 48, bd2, o73, o74⟩,
  ⟨587, 2, 0, false, .click 16 57, bd2, o74, o75⟩,
  ⟨588, 2, 0, false, .click 29 48, bd2, o75, o76⟩,
  ⟨589, 2, 0, false, .click 16 57, bd2, o76, o77⟩,
  ⟨590, 2, 0, false, .click 10 48, bd2, o77, o78⟩,
  ⟨591, 2, 0, false, .click 10 48, bd2, o78, o79⟩,
  ⟨592, 2, 0, false, .click 10 48, bd2, o79, o80⟩,
  ⟨593, 2, 0, false, .click 10 48, bd2, o80, o81⟩,
  ⟨594, 2, 0, false, .click 10 48, bd2, o81, o82⟩,
  ⟨595, 2, 0, false, .click 35 48, bd2, o82, o83⟩,
  ⟨596, 2, 0, false, .click 35 48, bd2, o83, o84⟩,
  ⟨597, 2, 0, false, .click 35 48, bd2, o84, o85⟩,
  ⟨598, 2, 0, false, .click 35 48, bd2, o85, o86⟩,
  ⟨599, 2, 0, false, .click 35 48, bd2, o86, o87⟩,
  ⟨600, 2, 0, false, .click 35 48, bd2, o87, o88⟩]
def rows10 : List Row := [
  ⟨601, 2, 0, false, .click 35 48, bd2, o88, o89⟩,
  ⟨602, 2, 0, false, .click 35 48, bd2, o89, o90⟩,
  ⟨603, 2, 0, false, .click 35 48, bd2, o90, o91⟩,
  ⟨604, 2, 0, false, .click 48 57, bd2, o91, o92⟩,
  ⟨605, 2, 0, false, .click 10 57, bd2, o92, o93⟩,
  ⟨606, 2, 0, false, .click 54 57, bd2, o93, o94⟩,
  ⟨607, 2, 0, false, .click 35 48, bd2, o94, o94⟩,
  ⟨608, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨609, 2, 0, false, .click 48 48, bd2, o94, o94⟩,
  ⟨610, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨611, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨612, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨613, 2, 0, false, .click 35 57, bd2, o94, o94⟩,
  ⟨614, 2, 0, false, .click 48 57, bd2, o94, o93⟩,
  ⟨615, 2, 0, false, .click 16 57, bd2, o93, o92⟩,
  ⟨616, 2, 0, false, .click 54 57, bd2, o92, o91⟩,
  ⟨617, 2, 0, false, .click 10 57, bd2, o91, o94⟩,
  ⟨618, 2, 0, false, .click 10 48, bd2, o94, o95⟩,
  ⟨619, 2, 0, false, .click 16 57, bd2, o95, o96⟩,
  ⟨620, 2, 0, false, .click 29 57, bd2, o96, o97⟩,
  ⟨621, 2, 0, false, .click 54 57, bd2, o97, o98⟩,
  ⟨622, 2, 0, false, .click 29 57, bd2, o98, o99⟩,
  ⟨623, 2, 0, false, .click 54 57, bd2, o99, o100⟩,
  ⟨624, 2, 0, false, .click 29 57, bd2, o100, o101⟩,
  ⟨625, 2, 0, false, .click 54 57, bd2, o101, o102⟩,
  ⟨626, 2, 0, false, .click 35 48, bd2, o102, o103⟩,
  ⟨627, 2, 0, false, .click 48 48, bd2, o103, o104⟩,
  ⟨628, 2, 0, false, .click 48 48, bd2, o104, o105⟩,
  ⟨629, 2, 0, false, .click 35 57, bd2, o105, o105⟩,
  ⟨630, 2, 0, false, .click 48 48, bd2, o105, o106⟩,
  ⟨631, 2, 0, false, .click 35 57, bd2, o106, o107⟩,
  ⟨632, 2, 0, false, .click 35 57, bd2, o107, o108⟩,
  ⟨633, 2, 0, false, .click 35 57, bd2, o108, o109⟩,
  ⟨634, 2, 0, false, .click 35 57, bd2, o109, o110⟩,
  ⟨635, 2, 0, false, .click 35 57, bd2, o110, o111⟩,
  ⟨636, 2, 0, false, .click 35 57, bd2, o111, o112⟩,
  ⟨637, 2, 1, false, .click 35 57, bd2, o112, o113⟩,
  ⟨638, 3, 0, false, .click 28 54, bd3, o113, o113⟩,
  ⟨639, 3, 0, false, .click 51 57, bd3, o113, o113⟩,
  ⟨640, 3, 0, false, .click 51 48, bd3, o113, o113⟩,
  ⟨641, 3, 0, false, .click 6 48, bd3, o113, o113⟩,
  ⟨642, 3, 0, false, .click 6 57, bd3, o113, o135⟩,
  ⟨643, 3, 0, false, .click 34 54, bd3, o135, o136⟩,
  ⟨644, 3, 0, false, .click 34 54, bd3, o136, o137⟩,
  ⟨645, 3, 0, false, .click 34 54, bd3, o137, o138⟩,
  ⟨646, 3, 0, false, .click 57 48, bd3, o138, o139⟩,
  ⟨647, 3, 0, false, .click 57 48, bd3, o139, o140⟩,
  ⟨648, 3, 0, false, .click 57 48, bd3, o140, o141⟩,
  ⟨649, 3, 0, false, .click 57 48, bd3, o141, o142⟩,
  ⟨650, 3, 0, false, .click 57 48, bd3, o142, o142⟩,
  ⟨651, 3, 0, false, .click 12 48, bd3, o142, o143⟩,
  ⟨652, 3, 0, false, .click 12 48, bd3, o143, o144⟩,
  ⟨653, 3, 0, false, .click 12 48, bd3, o144, o145⟩,
  ⟨654, 3, 0, false, .click 12 48, bd3, o145, o146⟩,
  ⟨655, 3, 0, false, .click 57 57, bd3, o146, o147⟩,
  ⟨656, 3, 0, false, .click 57 57, bd3, o147, o148⟩,
  ⟨657, 3, 0, false, .click 57 57, bd3, o148, o149⟩,
  ⟨658, 3, 0, false, .click 57 57, bd3, o149, o150⟩,
  ⟨659, 3, 0, false, .click 6 57, bd3, o150, o151⟩,
  ⟨660, 3, 0, false, .click 6 57, bd3, o151, o152⟩]
def rows11 : List Row := [
  ⟨661, 3, 0, false, .click 6 57, bd3, o152, o153⟩,
  ⟨662, 3, 0, false, .click 6 57, bd3, o153, o154⟩,
  ⟨663, 3, 0, false, .click 6 57, bd3, o154, o155⟩,
  ⟨664, 3, 0, false, .click 6 57, bd3, o155, o156⟩,
  ⟨665, 3, 0, false, .click 34 54, bd3, o156, o157⟩,
  ⟨666, 3, 0, false, .click 34 54, bd3, o157, o158⟩,
  ⟨667, 3, 0, false, .click 34 54, bd3, o158, o159⟩,
  ⟨668, 3, 0, false, .click 6 57, bd3, o159, o160⟩,
  ⟨669, 3, 0, false, .click 34 54, bd3, o160, o161⟩,
  ⟨670, 3, 0, false, .click 34 54, bd3, o161, o162⟩,
  ⟨671, 3, 0, false, .click 34 54, bd3, o162, o163⟩,
  ⟨672, 3, 0, false, .click 34 54, bd3, o163, o164⟩,
  ⟨673, 3, 1, false, .click 34 54, bd3, o164, o165⟩,
  ⟨674, 4, 0, false, .click 12 57, bd4, o165, o166⟩,
  ⟨675, 4, 0, false, .click 57 57, bd4, o166, o167⟩,
  ⟨676, 4, 0, false, .click 27 57, bd4, o167, o168⟩,
  ⟨677, 4, 0, false, .click 42 57, bd4, o168, o169⟩,
  ⟨678, 4, 0, false, .click 27 57, bd4, o169, o170⟩,
  ⟨679, 4, 0, false, .click 27 57, bd4, o170, o171⟩,
  ⟨680, 4, 0, false, .click 27 57, bd4, o171, o172⟩,
  ⟨681, 4, 0, false, .click 27 57, bd4, o172, o173⟩,
  ⟨682, 4, 0, false, .click 27 57, bd4, o173, o174⟩,
  ⟨683, 4, 0, false, .click 27 57, bd4, o174, o174⟩,
  ⟨684, 4, 0, false, .click 27 57, bd4, o174, o174⟩,
  ⟨685, 4, 0, false, .click 27 57, bd4, o174, o174⟩,
  ⟨686, 4, 0, false, .click 36 57, bd4, o174, o175⟩,
  ⟨687, 4, 0, false, .click 27 57, bd4, o175, o176⟩,
  ⟨688, 4, 0, false, .click 27 57, bd4, o176, o176⟩,
  ⟨689, 4, 0, false, .click 27 57, bd4, o176, o176⟩,
  ⟨690, 4, 0, false, .click 51 57, bd4, o176, o177⟩,
  ⟨691, 4, 0, false, .click 42 57, bd4, o177, o177⟩,
  ⟨692, 4, 0, false, .click 21 57, bd4, o177, o178⟩,
  ⟨693, 4, 0, false, .click 6 57, bd4, o178, o179⟩,
  ⟨694, 4, 0, false, .click 42 57, bd4, o179, o180⟩,
  ⟨695, 4, 0, false, .click 42 57, bd4, o180, o180⟩,
  ⟨696, 4, 0, false, .click 51 57, bd4, o180, o181⟩,
  ⟨697, 4, 0, false, .click 51 57, bd4, o181, o182⟩,
  ⟨698, 4, 0, false, .click 51 57, bd4, o182, o183⟩,
  ⟨699, 4, 0, false, .click 21 57, bd4, o183, o184⟩,
  ⟨700, 4, 0, false, .click 21 57, bd4, o184, o185⟩,
  ⟨701, 4, 0, false, .click 21 57, bd4, o185, o186⟩,
  ⟨702, 4, 0, false, .click 42 57, bd4, o186, o187⟩,
  ⟨703, 4, 0, false, .click 42 57, bd4, o187, o188⟩,
  ⟨704, 4, 0, false, .click 42 57, bd4, o188, o189⟩,
  ⟨705, 4, 0, false, .click 6 57, bd4, o189, o190⟩,
  ⟨706, 4, 0, false, .click 6 57, bd4, o190, o191⟩,
  ⟨707, 4, 0, false, .click 6 57, bd4, o191, o192⟩,
  ⟨708, 4, 0, false, .click 6 57, bd4, o192, o193⟩,
  ⟨709, 4, 0, false, .click 6 57, bd4, o193, o194⟩,
  ⟨710, 4, 0, false, .click 36 57, bd4, o194, o195⟩,
  ⟨711, 4, 0, false, .click 36 57, bd4, o195, o196⟩,
  ⟨712, 4, 0, false, .click 36 57, bd4, o196, o197⟩,
  ⟨713, 4, 0, false, .click 27 57, bd4, o197, o198⟩,
  ⟨714, 4, 0, false, .click 27 57, bd4, o198, o199⟩,
  ⟨715, 4, 0, false, .click 27 57, bd4, o199, o200⟩,
  ⟨716, 4, 0, false, .click 27 57, bd4, o200, o201⟩,
  ⟨717, 4, 0, false, .click 27 57, bd4, o201, o202⟩,
  ⟨718, 4, 0, false, .click 27 57, bd4, o202, o203⟩,
  ⟨719, 4, 0, false, .click 42 57, bd4, o203, o204⟩,
  ⟨720, 4, 0, false, .click 42 57, bd4, o204, o205⟩]
def rows12 : List Row := [
  ⟨721, 4, 0, false, .click 42 57, bd4, o205, o206⟩,
  ⟨722, 4, 0, false, .click 57 57, bd4, o206, o207⟩,
  ⟨723, 4, 0, false, .click 57 57, bd4, o207, o208⟩,
  ⟨724, 4, 1, false, .click 57 57, bd4, o208, o209⟩,
  ⟨725, 5, 0, false, .click 15 57, bd5, o209, o210⟩,
  ⟨726, 5, 0, false, .click 15 57, bd5, o210, o211⟩,
  ⟨727, 5, 0, false, .click 15 57, bd5, o211, o212⟩,
  ⟨728, 5, 0, false, .click 15 57, bd5, o212, o213⟩,
  ⟨729, 5, 0, false, .click 34 57, bd5, o213, o214⟩,
  ⟨730, 5, 0, false, .click 15 57, bd5, o214, o214⟩,
  ⟨731, 5, 0, false, .click 34 57, bd5, o214, o215⟩,
  ⟨732, 5, 0, false, .click 34 57, bd5, o215, o216⟩,
  ⟨733, 5, 0, false, .click 34 57, bd5, o216, o217⟩,
  ⟨734, 5, 0, false, .click 15 57, bd5, o217, o218⟩,
  ⟨735, 5, 2, false, .reset, bd5, o218, o209⟩,
  ⟨736, 5, 0, false, .click 12 48, bd5, o209, o219⟩,
  ⟨737, 5, 0, false, .click 31 48, bd5, o219, o220⟩,
  ⟨738, 5, 0, false, .click 50 48, bd5, o220, o221⟩,
  ⟨739, 5, 0, false, .click 52 34, bd5, o221, o221⟩,
  ⟨740, 5, 0, false, .click 49 13, bd5, o221, o221⟩,
  ⟨741, 5, 0, false, .click 20 20, bd5, o221, o221⟩,
  ⟨742, 5, 0, false, .click 9 57, bd5, o221, o222⟩,
  ⟨743, 5, 0, false, .click 31 48, bd5, o222, o223⟩,
  ⟨744, 5, 0, false, .click 12 48, bd5, o223, o224⟩,
  ⟨745, 5, 0, false, .click 53 57, bd5, o224, o225⟩,
  ⟨746, 5, 0, false, .click 53 57, bd5, o225, o226⟩,
  ⟨747, 5, 0, false, .click 53 57, bd5, o226, o227⟩,
  ⟨748, 5, 0, false, .click 53 57, bd5, o227, o228⟩,
  ⟨749, 5, 0, false, .click 53 57, bd5, o228, o229⟩,
  ⟨750, 5, 0, false, .click 53 57, bd5, o229, o230⟩,
  ⟨751, 5, 0, false, .click 34 57, bd5, o230, o231⟩,
  ⟨752, 5, 0, false, .click 34 57, bd5, o231, o232⟩,
  ⟨753, 5, 0, false, .click 34 57, bd5, o232, o233⟩,
  ⟨754, 5, 0, false, .click 15 57, bd5, o233, o234⟩,
  ⟨755, 5, 0, false, .click 15 57, bd5, o234, o235⟩,
  ⟨756, 5, 0, false, .click 15 57, bd5, o235, o236⟩,
  ⟨757, 5, 0, false, .click 15 57, bd5, o236, o237⟩,
  ⟨758, 5, 0, false, .click 15 57, bd5, o237, o238⟩,
  ⟨759, 5, 0, false, .click 15 57, bd5, o238, o239⟩,
  ⟨760, 5, 0, false, .click 15 57, bd5, o239, o240⟩,
  ⟨761, 5, 0, false, .click 15 57, bd5, o240, o241⟩,
  ⟨762, 5, 0, false, .click 15 57, bd5, o241, o242⟩,
  ⟨763, 5, 0, false, .click 15 57, bd5, o242, o243⟩,
  ⟨764, 5, 0, false, .click 15 57, bd5, o243, o244⟩,
  ⟨765, 5, 1, false, .click 15 57, bd5, o244, o245⟩,
  ⟨766, 6, 0, false, .click 26 51, bd6, o245, o246⟩,
  ⟨767, 6, 0, false, .click 39 51, bd6, o246, o247⟩,
  ⟨768, 6, 0, false, .click 39 51, bd6, o247, o248⟩,
  ⟨769, 6, 0, false, .click 39 51, bd6, o248, o246⟩,
  ⟨770, 6, 0, false, .click 54 51, bd6, o246, o249⟩,
  ⟨771, 6, 0, false, .click 54 51, bd6, o249, o250⟩,
  ⟨772, 6, 0, false, .click 60 58, bd6, o250, o251⟩,
  ⟨773, 6, 0, false, .click 60 58, bd6, o251, o252⟩,
  ⟨774, 6, 0, false, .click 60 58, bd6, o252, o253⟩,
  ⟨775, 6, 0, false, .click 60 51, bd6, o253, o254⟩,
  ⟨776, 6, 0, false, .click 60 51, bd6, o254, o255⟩,
  ⟨777, 6, 0, false, .click 17 51, bd6, o255, o256⟩,
  ⟨778, 6, 0, false, .click 17 51, bd6, o256, o257⟩,
  ⟨779, 6, 0, false, .click 10 51, bd6, o257, o258⟩,
  ⟨780, 6, 0, false, .click 10 51, bd6, o258, o259⟩]
def rows13 : List Row := [
  ⟨781, 6, 0, false, .click 10 51, bd6, o259, o260⟩,
  ⟨782, 6, 0, false, .click 10 51, bd6, o260, o261⟩,
  ⟨783, 6, 0, false, .click 10 51, bd6, o261, o262⟩,
  ⟨784, 6, 0, false, .click 10 51, bd6, o262, o263⟩,
  ⟨785, 6, 0, false, .click 10 51, bd6, o263, o264⟩,
  ⟨786, 6, 0, false, .click 10 51, bd6, o264, o265⟩,
  ⟨787, 6, 0, false, .click 39 51, bd6, o265, o266⟩,
  ⟨788, 6, 0, false, .click 10 58, bd6, o266, o267⟩,
  ⟨789, 6, 0, false, .click 10 58, bd6, o267, o268⟩,
  ⟨790, 6, 0, false, .click 10 58, bd6, o268, o269⟩,
  ⟨791, 6, 0, false, .click 10 58, bd6, o269, o270⟩,
  ⟨792, 6, 0, false, .click 10 58, bd6, o270, o271⟩,
  ⟨793, 6, 0, false, .click 10 58, bd6, o271, o272⟩,
  ⟨794, 6, 0, false, .click 10 58, bd6, o272, o273⟩,
  ⟨795, 6, 0, false, .click 10 58, bd6, o273, o274⟩,
  ⟨796, 6, 0, false, .click 10 58, bd6, o274, o275⟩,
  ⟨797, 6, 0, false, .click 10 58, bd6, o275, o276⟩,
  ⟨798, 6, 0, false, .click 10 58, bd6, o276, o277⟩,
  ⟨799, 6, 0, false, .click 10 58, bd6, o277, o278⟩,
  ⟨800, 6, 0, false, .click 39 51, bd6, o278, o279⟩,
  ⟨801, 6, 0, false, .click 39 51, bd6, o279, o280⟩,
  ⟨802, 6, 0, false, .click 32 51, bd6, o280, o281⟩,
  ⟨803, 6, 0, false, .click 32 51, bd6, o281, o282⟩,
  ⟨804, 6, 0, false, .click 32 51, bd6, o282, o283⟩,
  ⟨805, 6, 0, false, .click 32 51, bd6, o283, o284⟩,
  ⟨806, 6, 0, false, .click 32 51, bd6, o284, o285⟩,
  ⟨807, 6, 0, false, .click 32 51, bd6, o285, o286⟩,
  ⟨808, 6, 0, false, .click 32 51, bd6, o286, o287⟩,
  ⟨809, 6, 0, false, .click 32 58, bd6, o287, o288⟩,
  ⟨810, 6, 0, false, .click 32 58, bd6, o288, o289⟩,
  ⟨811, 6, 0, false, .click 32 58, bd6, o289, o290⟩,
  ⟨812, 6, 0, false, .click 32 58, bd6, o290, o291⟩,
  ⟨813, 6, 0, false, .click 32 58, bd6, o291, o292⟩,
  ⟨814, 6, 1, false, .click 32 58, bd6, o292, o293⟩,
  ⟨815, 7, 0, false, .click 22 56, bd7, o293, o294⟩,
  ⟨816, 7, 0, false, .click 45 4, bd7, o294, o295⟩,
  ⟨817, 7, 0, false, .click 49 18, bd7, o295, o296⟩,
  ⟨818, 7, 0, false, .click 49 18, bd7, o296, o297⟩,
  ⟨819, 7, 0, false, .click 49 18, bd7, o297, o298⟩,
  ⟨820, 7, 0, false, .click 45 4, bd7, o298, o299⟩,
  ⟨821, 7, 0, false, .click 22 56, bd7, o299, o300⟩,
  ⟨822, 7, 0, false, .click 22 56, bd7, o300, o301⟩,
  ⟨823, 7, 0, false, .click 22 56, bd7, o301, o302⟩,
  ⟨824, 7, 0, false, .click 22 56, bd7, o302, o303⟩,
  ⟨825, 7, 0, false, .click 39 4, bd7, o303, o304⟩,
  ⟨826, 7, 0, false, .click 49 18, bd7, o304, o305⟩,
  ⟨827, 7, 0, false, .click 49 18, bd7, o305, o306⟩,
  ⟨828, 7, 0, false, .click 49 18, bd7, o306, o307⟩,
  ⟨829, 7, 0, false, .click 45 11, bd7, o307, o308⟩,
  ⟨830, 7, 0, false, .click 45 11, bd7, o308, o309⟩,
  ⟨831, 7, 0, false, .click 45 11, bd7, o309, o310⟩,
  ⟨832, 7, 0, false, .click 8 56, bd7, o310, o311⟩,
  ⟨833, 7, 0, false, .click 8 56, bd7, o311, o312⟩,
  ⟨834, 7, 0, false, .click 8 56, bd7, o312, o313⟩,
  ⟨835, 7, 0, false, .click 8 56, bd7, o313, o314⟩,
  ⟨836, 7, 0, false, .click 8 56, bd7, o314, o315⟩,
  ⟨837, 7, 0, false, .click 39 11, bd7, o315, o316⟩,
  ⟨838, 7, 0, false, .click 39 11, bd7, o316, o317⟩,
  ⟨839, 7, 0, false, .click 59 11, bd7, o317, o318⟩,
  ⟨840, 7, 0, false, .click 59 11, bd7, o318, o318⟩]
def rows14 : List Row := [
  ⟨841, 7, 0, false, .click 49 18, bd7, o318, o319⟩,
  ⟨842, 7, 0, false, .click 49 18, bd7, o319, o320⟩,
  ⟨843, 7, 0, false, .click 49 18, bd7, o320, o321⟩,
  ⟨844, 7, 0, false, .click 59 11, bd7, o321, o322⟩,
  ⟨845, 7, 0, false, .click 59 11, bd7, o322, o323⟩,
  ⟨846, 7, 0, false, .click 59 11, bd7, o323, o324⟩,
  ⟨847, 7, 0, false, .click 59 11, bd7, o324, o325⟩,
  ⟨848, 7, 0, false, .click 59 11, bd7, o325, o326⟩,
  ⟨849, 7, 0, false, .click 59 11, bd7, o326, o327⟩,
  ⟨850, 7, 0, false, .click 59 11, bd7, o327, o328⟩,
  ⟨851, 7, 0, false, .click 59 11, bd7, o328, o329⟩,
  ⟨852, 7, 0, false, .click 59 11, bd7, o329, o330⟩,
  ⟨853, 7, 0, false, .click 59 11, bd7, o330, o331⟩,
  ⟨854, 7, 0, false, .click 59 11, bd7, o331, o332⟩,
  ⟨855, 7, 1, false, .click 59 11, bd7, o332, o333⟩,
  ⟨856, 8, 2, false, .reset, bd7, o333, o0⟩,
  ⟨857, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨858, 0, 0, false, .click 45 21, bd0, o1, o334⟩,
  ⟨859, 0, 0, false, .click 45 21, bd0, o334, o335⟩,
  ⟨860, 0, 0, false, .click 45 21, bd0, o335, o336⟩,
  ⟨861, 0, 0, false, .click 45 21, bd0, o336, o337⟩,
  ⟨862, 0, 0, false, .click 45 21, bd0, o337, o338⟩,
  ⟨863, 0, 0, false, .click 45 21, bd0, o338, o339⟩,
  ⟨864, 0, 0, false, .click 24 44, bd0, o339, o340⟩,
  ⟨865, 0, 0, false, .click 24 44, bd0, o340, o341⟩,
  ⟨866, 0, 0, false, .click 24 44, bd0, o341, o342⟩,
  ⟨867, 0, 0, false, .click 24 44, bd0, o342, o343⟩,
  ⟨868, 0, 0, false, .click 24 44, bd0, o343, o13⟩,
  ⟨869, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨870, 1, 2, false, .reset, bd1, o14, o0⟩,
  ⟨871, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨872, 0, 0, false, .click 45 21, bd0, o1, o334⟩,
  ⟨873, 0, 0, false, .click 45 21, bd0, o334, o335⟩,
  ⟨874, 0, 0, false, .click 45 21, bd0, o335, o336⟩,
  ⟨875, 0, 0, false, .click 45 21, bd0, o336, o337⟩,
  ⟨876, 0, 0, false, .click 45 21, bd0, o337, o338⟩,
  ⟨877, 0, 0, false, .click 45 21, bd0, o338, o339⟩,
  ⟨878, 0, 0, false, .click 24 44, bd0, o339, o340⟩,
  ⟨879, 0, 0, false, .click 24 44, bd0, o340, o341⟩,
  ⟨880, 0, 0, false, .click 24 44, bd0, o341, o342⟩,
  ⟨881, 0, 0, false, .click 24 44, bd0, o342, o343⟩,
  ⟨882, 0, 0, false, .click 24 44, bd0, o343, o13⟩,
  ⟨883, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨884, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨885, 1, 0, false, .click 27 57, bd1, o15, o344⟩,
  ⟨886, 1, 0, false, .click 27 57, bd1, o344, o345⟩,
  ⟨887, 1, 0, false, .click 27 57, bd1, o345, o346⟩,
  ⟨888, 1, 0, false, .click 42 57, bd1, o346, o347⟩,
  ⟨889, 1, 0, false, .click 42 57, bd1, o347, o348⟩,
  ⟨890, 1, 0, false, .click 12 57, bd1, o348, o349⟩,
  ⟨891, 1, 0, false, .click 57 57, bd1, o349, o350⟩,
  ⟨892, 1, 0, false, .click 27 57, bd1, o350, o351⟩,
  ⟨893, 1, 0, false, .click 12 57, bd1, o351, o352⟩,
  ⟨894, 1, 0, false, .click 57 57, bd1, o352, o353⟩,
  ⟨895, 1, 0, false, .click 36 57, bd1, o353, o354⟩,
  ⟨896, 1, 0, false, .click 27 57, bd1, o354, o355⟩,
  ⟨897, 1, 0, false, .click 6 57, bd1, o355, o356⟩,
  ⟨898, 1, 0, false, .click 42 57, bd1, o356, o357⟩,
  ⟨899, 1, 0, false, .click 42 57, bd1, o357, o358⟩,
  ⟨900, 1, 0, false, .click 57 57, bd1, o358, o359⟩]
def rows15 : List Row := [
  ⟨901, 1, 0, false, .click 6 57, bd1, o359, o360⟩,
  ⟨902, 1, 0, false, .click 57 57, bd1, o360, o361⟩,
  ⟨903, 1, 0, false, .click 57 57, bd1, o361, o362⟩,
  ⟨904, 1, 0, false, .click 57 57, bd1, o362, o363⟩,
  ⟨905, 1, 0, false, .click 57 57, bd1, o363, o364⟩,
  ⟨906, 1, 0, false, .click 57 57, bd1, o364, o365⟩,
  ⟨907, 1, 0, false, .click 57 57, bd1, o365, o366⟩,
  ⟨908, 1, 0, false, .click 57 57, bd1, o366, o367⟩,
  ⟨909, 1, 0, false, .click 36 57, bd1, o367, o368⟩,
  ⟨910, 1, 0, false, .click 12 57, bd1, o368, o369⟩,
  ⟨911, 1, 0, false, .click 12 57, bd1, o369, o370⟩,
  ⟨912, 1, 0, false, .click 27 57, bd1, o370, o371⟩,
  ⟨913, 1, 0, false, .click 27 57, bd1, o371, o372⟩,
  ⟨914, 1, 0, false, .click 27 57, bd1, o372, o373⟩,
  ⟨915, 1, 0, false, .click 27 57, bd1, o373, o374⟩,
  ⟨916, 1, 0, false, .click 27 57, bd1, o374, o375⟩,
  ⟨917, 1, 0, false, .click 27 57, bd1, o375, o376⟩,
  ⟨918, 1, 0, false, .click 51 57, bd1, o376, o377⟩,
  ⟨919, 1, 0, false, .click 36 57, bd1, o377, o378⟩,
  ⟨920, 1, 0, false, .click 12 57, bd1, o378, o379⟩,
  ⟨921, 1, 0, false, .click 21 57, bd1, o379, o380⟩,
  ⟨922, 1, 0, false, .click 36 57, bd1, o380, o381⟩,
  ⟨923, 1, 0, false, .click 27 57, bd1, o381, o382⟩,
  ⟨924, 1, 0, false, .click 27 57, bd1, o382, o383⟩,
  ⟨925, 1, 0, false, .click 12 57, bd1, o383, o384⟩,
  ⟨926, 1, 0, false, .click 51 57, bd1, o384, o385⟩,
  ⟨927, 1, 0, false, .click 51 57, bd1, o385, o386⟩,
  ⟨928, 1, 0, false, .click 51 57, bd1, o386, o387⟩,
  ⟨929, 1, 0, false, .click 51 57, bd1, o387, o388⟩,
  ⟨930, 1, 0, false, .click 51 57, bd1, o388, o389⟩,
  ⟨931, 1, 0, false, .click 51 57, bd1, o389, o390⟩,
  ⟨932, 1, 0, false, .click 51 57, bd1, o390, o391⟩,
  ⟨933, 1, 0, false, .click 12 57, bd1, o391, o392⟩,
  ⟨934, 1, 0, false, .click 42 57, bd1, o392, o393⟩,
  ⟨935, 1, 0, false, .click 42 57, bd1, o393, o394⟩,
  ⟨936, 1, 0, false, .click 42 57, bd1, o394, o395⟩,
  ⟨937, 1, 0, false, .click 6 57, bd1, o395, o396⟩,
  ⟨938, 1, 0, false, .click 6 57, bd1, o396, o397⟩,
  ⟨939, 1, 0, false, .click 42 57, bd1, o397, o398⟩,
  ⟨940, 1, 0, false, .click 51 57, bd1, o398, o399⟩,
  ⟨941, 1, 0, false, .click 51 57, bd1, o399, o400⟩,
  ⟨942, 1, 0, false, .click 42 57, bd1, o400, o401⟩,
  ⟨943, 1, 0, false, .click 42 57, bd1, o401, o402⟩,
  ⟨944, 1, 0, false, .click 42 57, bd1, o402, o403⟩,
  ⟨945, 1, 0, false, .click 42 57, bd1, o403, o404⟩,
  ⟨946, 1, 0, false, .click 21 57, bd1, o404, o405⟩,
  ⟨947, 1, 0, false, .click 57 57, bd1, o405, o406⟩,
  ⟨948, 1, 0, false, .click 51 57, bd1, o406, o405⟩,
  ⟨949, 1, 0, false, .click 21 57, bd1, o405, o407⟩,
  ⟨950, 1, 0, false, .click 6 57, bd1, o407, o408⟩,
  ⟨951, 1, 0, false, .click 6 57, bd1, o408, o409⟩,
  ⟨952, 1, 0, false, .click 36 57, bd1, o409, o410⟩,
  ⟨953, 1, 0, false, .click 36 57, bd1, o410, o411⟩,
  ⟨954, 1, 0, false, .click 36 57, bd1, o411, o412⟩,
  ⟨955, 1, 0, false, .click 36 57, bd1, o412, o413⟩,
  ⟨956, 1, 0, false, .click 36 57, bd1, o413, o414⟩,
  ⟨957, 1, 0, false, .click 36 57, bd1, o414, o415⟩,
  ⟨958, 1, 0, false, .click 36 57, bd1, o415, o416⟩,
  ⟨959, 1, 0, false, .click 36 57, bd1, o416, o417⟩,
  ⟨960, 1, 0, false, .click 21 57, bd1, o417, o418⟩]
def rows16 : List Row := [
  ⟨961, 1, 0, false, .click 21 57, bd1, o418, o419⟩,
  ⟨962, 1, 0, false, .click 21 57, bd1, o419, o420⟩,
  ⟨963, 1, 0, false, .click 21 57, bd1, o420, o421⟩,
  ⟨964, 1, 0, false, .click 21 57, bd1, o421, o422⟩,
  ⟨965, 1, 0, false, .click 21 57, bd1, o422, o423⟩,
  ⟨966, 1, 0, false, .click 21 57, bd1, o423, o424⟩,
  ⟨967, 1, 0, false, .click 12 57, bd1, o424, o425⟩,
  ⟨968, 1, 0, false, .click 12 57, bd1, o425, o426⟩,
  ⟨969, 1, 0, false, .click 12 57, bd1, o426, o427⟩,
  ⟨970, 1, 0, false, .click 12 57, bd1, o427, o428⟩,
  ⟨971, 1, 0, false, .click 12 57, bd1, o428, o429⟩,
  ⟨972, 1, 0, false, .click 12 57, bd1, o429, o25⟩,
  ⟨973, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨974, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨975, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨976, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨977, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨978, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨979, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨980, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨981, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨982, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨983, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨984, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨985, 1, 0, false, .click 57 57, bd1, o37, o430⟩,
  ⟨986, 1, 0, false, .click 42 57, bd1, o430, o431⟩,
  ⟨987, 1, 0, false, .click 12 57, bd1, o431, o431⟩,
  ⟨988, 1, 1, false, .click 42 57, bd1, o431, o40⟩,
  ⟨989, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨990, 2, 0, false, .click 54 57, bd2, o54, o432⟩,
  ⟨991, 2, 0, false, .click 48 48, bd2, o432, o433⟩,
  ⟨992, 2, 0, false, .click 16 48, bd2, o433, o434⟩,
  ⟨993, 2, 0, false, .click 48 48, bd2, o434, o435⟩,
  ⟨994, 2, 0, false, .click 16 48, bd2, o435, o436⟩,
  ⟨995, 2, 0, false, .click 16 57, bd2, o436, o437⟩,
  ⟨996, 2, 0, false, .click 16 57, bd2, o437, o438⟩,
  ⟨997, 2, 0, false, .click 16 57, bd2, o438, o439⟩,
  ⟨998, 2, 0, false, .click 16 57, bd2, o439, o440⟩,
  ⟨999, 2, 0, false, .click 16 57, bd2, o440, o441⟩,
  ⟨1000, 2, 0, false, .click 16 57, bd2, o441, o442⟩,
  ⟨1001, 2, 0, false, .click 54 57, bd2, o442, o443⟩,
  ⟨1002, 2, 0, false, .click 54 57, bd2, o443, o444⟩,
  ⟨1003, 2, 0, false, .click 54 57, bd2, o444, o445⟩,
  ⟨1004, 2, 0, false, .click 48 48, bd2, o445, o446⟩,
  ⟨1005, 2, 0, false, .click 10 48, bd2, o446, o447⟩,
  ⟨1006, 2, 0, false, .click 10 48, bd2, o447, o448⟩,
  ⟨1007, 2, 0, false, .click 10 48, bd2, o448, o449⟩,
  ⟨1008, 2, 0, false, .click 10 48, bd2, o449, o450⟩,
  ⟨1009, 2, 0, false, .click 48 48, bd2, o450, o451⟩,
  ⟨1010, 2, 0, false, .click 48 48, bd2, o451, o452⟩,
  ⟨1011, 2, 0, false, .click 35 57, bd2, o452, o453⟩,
  ⟨1012, 2, 0, false, .click 35 57, bd2, o453, o454⟩,
  ⟨1013, 2, 0, false, .click 35 57, bd2, o454, o455⟩,
  ⟨1014, 2, 0, false, .click 35 57, bd2, o455, o456⟩,
  ⟨1015, 2, 0, false, .click 35 57, bd2, o456, o457⟩,
  ⟨1016, 2, 0, false, .click 35 57, bd2, o457, o458⟩,
  ⟨1017, 2, 0, false, .click 35 57, bd2, o458, o459⟩,
  ⟨1018, 2, 0, false, .click 10 48, bd2, o459, o460⟩,
  ⟨1019, 2, 0, false, .click 10 48, bd2, o460, o461⟩,
  ⟨1020, 2, 0, false, .click 10 48, bd2, o461, o462⟩]
def rows17 : List Row := [
  ⟨1021, 2, 0, false, .click 35 48, bd2, o462, o463⟩,
  ⟨1022, 2, 0, false, .click 35 48, bd2, o463, o464⟩,
  ⟨1023, 2, 0, false, .click 35 48, bd2, o464, o465⟩,
  ⟨1024, 2, 0, false, .click 35 48, bd2, o465, o466⟩,
  ⟨1025, 2, 0, false, .click 35 48, bd2, o466, o467⟩,
  ⟨1026, 2, 0, false, .click 35 48, bd2, o467, o468⟩,
  ⟨1027, 2, 0, false, .click 35 48, bd2, o468, o469⟩,
  ⟨1028, 2, 0, false, .click 35 48, bd2, o469, o470⟩,
  ⟨1029, 2, 0, false, .click 35 48, bd2, o470, o471⟩,
  ⟨1030, 2, 0, false, .click 35 48, bd2, o471, o472⟩,
  ⟨1031, 2, 0, false, .click 35 48, bd2, o472, o473⟩,
  ⟨1032, 2, 1, false, .click 35 48, bd2, o473, o113⟩,
  ⟨1033, 3, 0, false, .click 57 57, bd3, o113, o474⟩,
  ⟨1034, 3, 0, false, .click 12 57, bd3, o474, o475⟩,
  ⟨1035, 3, 0, false, .click 12 57, bd3, o475, o476⟩,
  ⟨1036, 3, 0, false, .click 34 54, bd3, o476, o477⟩,
  ⟨1037, 3, 0, false, .click 34 54, bd3, o477, o478⟩,
  ⟨1038, 3, 0, false, .click 34 54, bd3, o478, o479⟩,
  ⟨1039, 3, 0, false, .click 34 54, bd3, o479, o480⟩,
  ⟨1040, 3, 0, false, .click 12 48, bd3, o480, o481⟩,
  ⟨1041, 3, 0, false, .click 12 48, bd3, o481, o482⟩,
  ⟨1042, 3, 0, false, .click 12 48, bd3, o482, o483⟩,
  ⟨1043, 3, 0, false, .click 12 48, bd3, o483, o484⟩,
  ⟨1044, 3, 0, false, .click 34 54, bd3, o484, o485⟩,
  ⟨1045, 3, 0, false, .click 34 54, bd3, o485, o486⟩,
  ⟨1046, 3, 0, false, .click 57 48, bd3, o486, o487⟩,
  ⟨1047, 3, 0, false, .click 28 54, bd3, o487, o488⟩,
  ⟨1048, 3, 0, false, .click 57 57, bd3, o488, o489⟩,
  ⟨1049, 3, 0, false, .click 28 54, bd3, o489, o490⟩,
  ⟨1050, 3, 0, false, .click 57 48, bd3, o490, o491⟩,
  ⟨1051, 3, 0, false, .click 57 57, bd3, o491, o492⟩,
  ⟨1052, 3, 0, false, .click 34 54, bd3, o492, o493⟩,
  ⟨1053, 3, 0, false, .click 34 54, bd3, o493, o494⟩,
  ⟨1054, 3, 0, false, .click 12 57, bd3, o494, o495⟩,
  ⟨1055, 3, 0, false, .click 12 57, bd3, o495, o496⟩,
  ⟨1056, 3, 0, false, .click 34 54, bd3, o496, o497⟩,
  ⟨1057, 3, 0, false, .click 34 54, bd3, o497, o134⟩,
  ⟨1058, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1059, 3, 0, false, .click 12 48, bd3, o133, o498⟩,
  ⟨1060, 3, 0, false, .click 57 48, bd3, o498, o499⟩,
  ⟨1061, 3, 0, false, .click 57 57, bd3, o499, o500⟩,
  ⟨1062, 3, 0, false, .click 12 57, bd3, o500, o501⟩,
  ⟨1063, 3, 0, false, .click 12 57, bd3, o501, o502⟩,
  ⟨1064, 3, 0, false, .click 6 57, bd3, o502, o501⟩,
  ⟨1065, 3, 0, false, .click 51 57, bd3, o501, o503⟩,
  ⟨1066, 3, 0, false, .click 51 48, bd3, o503, o504⟩,
  ⟨1067, 3, 0, false, .click 6 48, bd3, o504, o134⟩,
  ⟨1068, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1069, 3, 0, false, .click 51 57, bd3, o133, o132⟩,
  ⟨1070, 3, 0, false, .click 57 57, bd3, o132, o133⟩,
  ⟨1071, 3, 0, false, .click 28 54, bd3, o133, o505⟩,
  ⟨1072, 3, 0, false, .click 28 54, bd3, o505, o495⟩,
  ⟨1073, 3, 0, false, .click 57 48, bd3, o495, o506⟩,
  ⟨1074, 3, 0, false, .click 57 57, bd3, o506, o507⟩,
  ⟨1075, 3, 0, false, .click 57 48, bd3, o507, o508⟩,
  ⟨1076, 3, 0, false, .click 34 54, bd3, o508, o509⟩,
  ⟨1077, 3, 0, false, .click 34 54, bd3, o509, o510⟩,
  ⟨1078, 3, 0, false, .click 51 57, bd3, o510, o511⟩,
  ⟨1079, 3, 0, false, .click 6 48, bd3, o511, o512⟩,
  ⟨1080, 3, 0, false, .click 51 57, bd3, o512, o513⟩]
def rows18 : List Row := [
  ⟨1081, 3, 0, false, .click 6 48, bd3, o513, o514⟩,
  ⟨1082, 3, 0, false, .click 51 48, bd3, o514, o515⟩,
  ⟨1083, 3, 0, false, .click 28 54, bd3, o515, o516⟩,
  ⟨1084, 3, 0, false, .click 6 57, bd3, o516, o517⟩,
  ⟨1085, 3, 0, false, .click 12 48, bd3, o517, o518⟩,
  ⟨1086, 3, 0, false, .click 28 54, bd3, o518, o519⟩,
  ⟨1087, 3, 0, false, .click 28 54, bd3, o519, o520⟩,
  ⟨1088, 3, 0, false, .click 28 54, bd3, o520, o521⟩,
  ⟨1089, 3, 0, false, .click 12 57, bd3, o521, o522⟩,
  ⟨1090, 3, 0, false, .click 12 57, bd3, o522, o523⟩,
  ⟨1091, 3, 0, false, .click 34 54, bd3, o523, o523⟩,
  ⟨1092, 3, 0, false, .click 6 48, bd3, o523, o524⟩,
  ⟨1093, 3, 0, false, .click 28 54, bd3, o524, o525⟩,
  ⟨1094, 3, 0, false, .click 51 57, bd3, o525, o526⟩,
  ⟨1095, 3, 0, false, .click 34 54, bd3, o526, o527⟩,
  ⟨1096, 3, 0, false, .click 6 57, bd3, o527, o528⟩,
  ⟨1097, 3, 0, false, .click 28 54, bd3, o528, o529⟩,
  ⟨1098, 3, 2, false, .reset, bd3, o529, o113⟩,
  ⟨1099, 3, 0, false, .click 57 57, bd3, o113, o474⟩,
  ⟨1100, 3, 0, false, .click 12 57, bd3, o474, o475⟩,
  ⟨1101, 3, 0, false, .click 12 57, bd3, o475, o476⟩,
  ⟨1102, 3, 0, false, .click 34 54, bd3, o476, o477⟩,
  ⟨1103, 3, 0, false, .click 34 54, bd3, o477, o478⟩,
  ⟨1104, 3, 0, false, .click 34 54, bd3, o478, o479⟩,
  ⟨1105, 3, 0, false, .click 34 54, bd3, o479, o480⟩,
  ⟨1106, 3, 0, false, .click 12 48, bd3, o480, o481⟩,
  ⟨1107, 3, 0, false, .click 12 48, bd3, o481, o482⟩,
  ⟨1108, 3, 0, false, .click 12 48, bd3, o482, o483⟩,
  ⟨1109, 3, 0, false, .click 12 48, bd3, o483, o484⟩,
  ⟨1110, 3, 0, false, .click 34 54, bd3, o484, o485⟩,
  ⟨1111, 3, 0, false, .click 34 54, bd3, o485, o486⟩,
  ⟨1112, 3, 0, false, .click 57 48, bd3, o486, o487⟩,
  ⟨1113, 3, 0, false, .click 28 54, bd3, o487, o488⟩,
  ⟨1114, 3, 0, false, .click 57 57, bd3, o488, o489⟩,
  ⟨1115, 3, 0, false, .click 28 54, bd3, o489, o490⟩,
  ⟨1116, 3, 0, false, .click 57 48, bd3, o490, o491⟩,
  ⟨1117, 3, 0, false, .click 57 57, bd3, o491, o492⟩,
  ⟨1118, 3, 0, false, .click 34 54, bd3, o492, o493⟩,
  ⟨1119, 3, 0, false, .click 34 54, bd3, o493, o494⟩,
  ⟨1120, 3, 0, false, .click 12 57, bd3, o494, o495⟩,
  ⟨1121, 3, 0, false, .click 12 57, bd3, o495, o496⟩,
  ⟨1122, 3, 0, false, .click 34 54, bd3, o496, o497⟩,
  ⟨1123, 3, 0, false, .click 34 54, bd3, o497, o134⟩,
  ⟨1124, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1125, 3, 0, false, .click 12 48, bd3, o133, o498⟩,
  ⟨1126, 3, 0, false, .click 57 48, bd3, o498, o499⟩,
  ⟨1127, 3, 0, false, .click 57 57, bd3, o499, o500⟩,
  ⟨1128, 3, 0, false, .click 12 57, bd3, o500, o501⟩,
  ⟨1129, 3, 0, false, .click 12 57, bd3, o501, o502⟩,
  ⟨1130, 3, 0, false, .click 6 57, bd3, o502, o501⟩,
  ⟨1131, 3, 0, false, .click 51 57, bd3, o501, o503⟩,
  ⟨1132, 3, 0, false, .click 51 48, bd3, o503, o504⟩,
  ⟨1133, 3, 0, false, .click 6 48, bd3, o504, o134⟩,
  ⟨1134, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1135, 3, 0, false, .click 51 57, bd3, o133, o132⟩,
  ⟨1136, 3, 0, false, .click 28 54, bd3, o132, o530⟩,
  ⟨1137, 3, 0, false, .click 6 57, bd3, o530, o531⟩,
  ⟨1138, 3, 0, false, .click 51 57, bd3, o531, o532⟩,
  ⟨1139, 3, 0, false, .click 28 54, bd3, o532, o533⟩,
  ⟨1140, 3, 0, false, .click 6 57, bd3, o533, o534⟩]
def rows19 : List Row := [
  ⟨1141, 3, 0, false, .click 28 54, bd3, o534, o535⟩,
  ⟨1142, 3, 0, false, .click 6 57, bd3, o535, o536⟩,
  ⟨1143, 3, 0, false, .click 28 54, bd3, o536, o537⟩,
  ⟨1144, 3, 0, false, .click 28 54, bd3, o537, o538⟩,
  ⟨1145, 3, 0, false, .click 28 54, bd3, o538, o539⟩,
  ⟨1146, 3, 0, false, .click 28 54, bd3, o539, o540⟩,
  ⟨1147, 3, 0, false, .click 6 57, bd3, o540, o541⟩,
  ⟨1148, 3, 0, false, .click 6 57, bd3, o541, o542⟩,
  ⟨1149, 3, 0, false, .click 6 57, bd3, o542, o543⟩,
  ⟨1150, 3, 0, false, .click 6 57, bd3, o543, o544⟩,
  ⟨1151, 3, 0, false, .click 6 57, bd3, o544, o545⟩,
  ⟨1152, 3, 0, false, .click 57 57, bd3, o545, o546⟩,
  ⟨1153, 3, 0, false, .click 57 57, bd3, o546, o547⟩,
  ⟨1154, 3, 0, false, .click 6 57, bd3, o547, o548⟩,
  ⟨1155, 3, 0, false, .click 6 57, bd3, o548, o549⟩,
  ⟨1156, 3, 0, false, .click 6 57, bd3, o549, o550⟩,
  ⟨1157, 3, 0, false, .click 34 54, bd3, o550, o551⟩,
  ⟨1158, 3, 0, false, .click 34 54, bd3, o551, o552⟩,
  ⟨1159, 3, 0, false, .click 34 54, bd3, o552, o553⟩,
  ⟨1160, 3, 0, false, .click 34 54, bd3, o553, o554⟩,
  ⟨1161, 3, 0, false, .click 34 54, bd3, o554, o555⟩,
  ⟨1162, 3, 0, false, .click 34 54, bd3, o555, o556⟩,
  ⟨1163, 3, 2, false, .reset, bd3, o556, o0⟩,
  ⟨1164, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨1165, 0, 0, false, .click 45 21, bd0, o1, o334⟩,
  ⟨1166, 0, 0, false, .click 45 21, bd0, o334, o335⟩,
  ⟨1167, 0, 0, false, .click 45 21, bd0, o335, o336⟩,
  ⟨1168, 0, 0, false, .click 45 21, bd0, o336, o337⟩,
  ⟨1169, 0, 0, false, .click 45 21, bd0, o337, o338⟩,
  ⟨1170, 0, 0, false, .click 45 21, bd0, o338, o339⟩,
  ⟨1171, 0, 0, false, .click 24 44, bd0, o339, o340⟩,
  ⟨1172, 0, 0, false, .click 24 44, bd0, o340, o341⟩,
  ⟨1173, 0, 0, false, .click 24 44, bd0, o341, o342⟩,
  ⟨1174, 0, 0, false, .click 24 44, bd0, o342, o343⟩,
  ⟨1175, 0, 0, false, .click 24 44, bd0, o343, o13⟩,
  ⟨1176, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨1177, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨1178, 1, 0, false, .click 27 57, bd1, o15, o344⟩,
  ⟨1179, 1, 0, false, .click 27 57, bd1, o344, o345⟩,
  ⟨1180, 1, 0, false, .click 27 57, bd1, o345, o346⟩,
  ⟨1181, 1, 0, false, .click 42 57, bd1, o346, o347⟩,
  ⟨1182, 1, 0, false, .click 42 57, bd1, o347, o348⟩,
  ⟨1183, 1, 0, false, .click 12 57, bd1, o348, o349⟩,
  ⟨1184, 1, 0, false, .click 57 57, bd1, o349, o350⟩,
  ⟨1185, 1, 0, false, .click 27 57, bd1, o350, o351⟩,
  ⟨1186, 1, 0, false, .click 12 57, bd1, o351, o352⟩,
  ⟨1187, 1, 0, false, .click 57 57, bd1, o352, o353⟩,
  ⟨1188, 1, 0, false, .click 36 57, bd1, o353, o354⟩,
  ⟨1189, 1, 0, false, .click 27 57, bd1, o354, o355⟩,
  ⟨1190, 1, 0, false, .click 6 57, bd1, o355, o356⟩,
  ⟨1191, 1, 0, false, .click 42 57, bd1, o356, o357⟩,
  ⟨1192, 1, 0, false, .click 42 57, bd1, o357, o358⟩,
  ⟨1193, 1, 0, false, .click 57 57, bd1, o358, o359⟩,
  ⟨1194, 1, 0, false, .click 6 57, bd1, o359, o360⟩,
  ⟨1195, 1, 0, false, .click 57 57, bd1, o360, o361⟩,
  ⟨1196, 1, 0, false, .click 57 57, bd1, o361, o362⟩,
  ⟨1197, 1, 0, false, .click 57 57, bd1, o362, o363⟩,
  ⟨1198, 1, 0, false, .click 57 57, bd1, o363, o364⟩,
  ⟨1199, 1, 0, false, .click 57 57, bd1, o364, o365⟩,
  ⟨1200, 1, 0, false, .click 57 57, bd1, o365, o366⟩]
def rows20 : List Row := [
  ⟨1201, 1, 0, false, .click 57 57, bd1, o366, o367⟩,
  ⟨1202, 1, 0, false, .click 36 57, bd1, o367, o368⟩,
  ⟨1203, 1, 0, false, .click 12 57, bd1, o368, o369⟩,
  ⟨1204, 1, 0, false, .click 12 57, bd1, o369, o370⟩,
  ⟨1205, 1, 0, false, .click 27 57, bd1, o370, o371⟩,
  ⟨1206, 1, 0, false, .click 27 57, bd1, o371, o372⟩,
  ⟨1207, 1, 0, false, .click 27 57, bd1, o372, o373⟩,
  ⟨1208, 1, 0, false, .click 27 57, bd1, o373, o374⟩,
  ⟨1209, 1, 0, false, .click 27 57, bd1, o374, o375⟩,
  ⟨1210, 1, 0, false, .click 27 57, bd1, o375, o376⟩,
  ⟨1211, 1, 0, false, .click 51 57, bd1, o376, o377⟩,
  ⟨1212, 1, 0, false, .click 36 57, bd1, o377, o378⟩,
  ⟨1213, 1, 0, false, .click 12 57, bd1, o378, o379⟩,
  ⟨1214, 1, 0, false, .click 21 57, bd1, o379, o380⟩,
  ⟨1215, 1, 0, false, .click 36 57, bd1, o380, o381⟩,
  ⟨1216, 1, 0, false, .click 27 57, bd1, o381, o382⟩,
  ⟨1217, 1, 0, false, .click 27 57, bd1, o382, o383⟩,
  ⟨1218, 1, 0, false, .click 12 57, bd1, o383, o384⟩,
  ⟨1219, 1, 0, false, .click 51 57, bd1, o384, o385⟩,
  ⟨1220, 1, 0, false, .click 51 57, bd1, o385, o386⟩,
  ⟨1221, 1, 0, false, .click 51 57, bd1, o386, o387⟩,
  ⟨1222, 1, 0, false, .click 51 57, bd1, o387, o388⟩,
  ⟨1223, 1, 0, false, .click 51 57, bd1, o388, o389⟩,
  ⟨1224, 1, 0, false, .click 51 57, bd1, o389, o390⟩,
  ⟨1225, 1, 0, false, .click 51 57, bd1, o390, o391⟩,
  ⟨1226, 1, 0, false, .click 12 57, bd1, o391, o392⟩,
  ⟨1227, 1, 0, false, .click 42 57, bd1, o392, o393⟩,
  ⟨1228, 1, 0, false, .click 42 57, bd1, o393, o394⟩,
  ⟨1229, 1, 0, false, .click 42 57, bd1, o394, o395⟩,
  ⟨1230, 1, 0, false, .click 6 57, bd1, o395, o396⟩,
  ⟨1231, 1, 0, false, .click 6 57, bd1, o396, o397⟩,
  ⟨1232, 1, 0, false, .click 42 57, bd1, o397, o398⟩,
  ⟨1233, 1, 0, false, .click 51 57, bd1, o398, o399⟩,
  ⟨1234, 1, 0, false, .click 51 57, bd1, o399, o400⟩,
  ⟨1235, 1, 0, false, .click 42 57, bd1, o400, o401⟩,
  ⟨1236, 1, 0, false, .click 42 57, bd1, o401, o402⟩,
  ⟨1237, 1, 0, false, .click 42 57, bd1, o402, o403⟩,
  ⟨1238, 1, 0, false, .click 42 57, bd1, o403, o404⟩,
  ⟨1239, 1, 0, false, .click 21 57, bd1, o404, o405⟩,
  ⟨1240, 1, 0, false, .click 57 57, bd1, o405, o406⟩,
  ⟨1241, 1, 0, false, .click 51 57, bd1, o406, o405⟩,
  ⟨1242, 1, 0, false, .click 21 57, bd1, o405, o407⟩,
  ⟨1243, 1, 0, false, .click 6 57, bd1, o407, o408⟩,
  ⟨1244, 1, 0, false, .click 6 57, bd1, o408, o409⟩,
  ⟨1245, 1, 0, false, .click 36 57, bd1, o409, o410⟩,
  ⟨1246, 1, 0, false, .click 36 57, bd1, o410, o411⟩,
  ⟨1247, 1, 0, false, .click 36 57, bd1, o411, o412⟩,
  ⟨1248, 1, 0, false, .click 36 57, bd1, o412, o413⟩,
  ⟨1249, 1, 0, false, .click 36 57, bd1, o413, o414⟩,
  ⟨1250, 1, 0, false, .click 36 57, bd1, o414, o415⟩,
  ⟨1251, 1, 0, false, .click 36 57, bd1, o415, o416⟩,
  ⟨1252, 1, 0, false, .click 36 57, bd1, o416, o417⟩,
  ⟨1253, 1, 0, false, .click 21 57, bd1, o417, o418⟩,
  ⟨1254, 1, 0, false, .click 21 57, bd1, o418, o419⟩,
  ⟨1255, 1, 0, false, .click 21 57, bd1, o419, o420⟩,
  ⟨1256, 1, 0, false, .click 21 57, bd1, o420, o421⟩,
  ⟨1257, 1, 0, false, .click 21 57, bd1, o421, o422⟩,
  ⟨1258, 1, 0, false, .click 21 57, bd1, o422, o423⟩,
  ⟨1259, 1, 0, false, .click 21 57, bd1, o423, o424⟩,
  ⟨1260, 1, 0, false, .click 12 57, bd1, o424, o425⟩]
def rows21 : List Row := [
  ⟨1261, 1, 0, false, .click 12 57, bd1, o425, o426⟩,
  ⟨1262, 1, 0, false, .click 12 57, bd1, o426, o427⟩,
  ⟨1263, 1, 0, false, .click 12 57, bd1, o427, o428⟩,
  ⟨1264, 1, 0, false, .click 12 57, bd1, o428, o429⟩,
  ⟨1265, 1, 0, false, .click 12 57, bd1, o429, o25⟩,
  ⟨1266, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨1267, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨1268, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨1269, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨1270, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨1271, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨1272, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨1273, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨1274, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨1275, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨1276, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨1277, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨1278, 1, 0, false, .click 57 57, bd1, o37, o430⟩,
  ⟨1279, 1, 0, false, .click 42 57, bd1, o430, o431⟩,
  ⟨1280, 1, 0, false, .click 12 57, bd1, o431, o431⟩,
  ⟨1281, 1, 1, false, .click 42 57, bd1, o431, o40⟩,
  ⟨1282, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨1283, 2, 0, false, .click 54 57, bd2, o54, o432⟩,
  ⟨1284, 2, 0, false, .click 48 48, bd2, o432, o433⟩,
  ⟨1285, 2, 0, false, .click 16 48, bd2, o433, o434⟩,
  ⟨1286, 2, 0, false, .click 48 48, bd2, o434, o435⟩,
  ⟨1287, 2, 0, false, .click 16 48, bd2, o435, o436⟩,
  ⟨1288, 2, 0, false, .click 16 57, bd2, o436, o437⟩,
  ⟨1289, 2, 0, false, .click 16 57, bd2, o437, o438⟩,
  ⟨1290, 2, 0, false, .click 16 57, bd2, o438, o439⟩,
  ⟨1291, 2, 0, false, .click 16 57, bd2, o439, o440⟩,
  ⟨1292, 2, 0, false, .click 16 57, bd2, o440, o441⟩,
  ⟨1293, 2, 0, false, .click 16 57, bd2, o441, o442⟩,
  ⟨1294, 2, 0, false, .click 54 57, bd2, o442, o443⟩,
  ⟨1295, 2, 0, false, .click 54 57, bd2, o443, o444⟩,
  ⟨1296, 2, 0, false, .click 54 57, bd2, o444, o445⟩,
  ⟨1297, 2, 0, false, .click 48 48, bd2, o445, o446⟩,
  ⟨1298, 2, 0, false, .click 10 48, bd2, o446, o447⟩,
  ⟨1299, 2, 0, false, .click 10 48, bd2, o447, o448⟩,
  ⟨1300, 2, 0, false, .click 10 48, bd2, o448, o449⟩,
  ⟨1301, 2, 0, false, .click 10 48, bd2, o449, o450⟩,
  ⟨1302, 2, 0, false, .click 48 48, bd2, o450, o451⟩,
  ⟨1303, 2, 0, false, .click 48 48, bd2, o451, o452⟩,
  ⟨1304, 2, 0, false, .click 35 57, bd2, o452, o453⟩,
  ⟨1305, 2, 0, false, .click 35 57, bd2, o453, o454⟩,
  ⟨1306, 2, 0, false, .click 35 57, bd2, o454, o455⟩,
  ⟨1307, 2, 0, false, .click 35 57, bd2, o455, o456⟩,
  ⟨1308, 2, 0, false, .click 35 57, bd2, o456, o457⟩,
  ⟨1309, 2, 0, false, .click 35 57, bd2, o457, o458⟩,
  ⟨1310, 2, 0, false, .click 35 57, bd2, o458, o459⟩,
  ⟨1311, 2, 0, false, .click 10 48, bd2, o459, o460⟩,
  ⟨1312, 2, 0, false, .click 10 48, bd2, o460, o461⟩,
  ⟨1313, 2, 0, false, .click 10 48, bd2, o461, o462⟩,
  ⟨1314, 2, 0, false, .click 35 48, bd2, o462, o463⟩,
  ⟨1315, 2, 0, false, .click 35 48, bd2, o463, o464⟩,
  ⟨1316, 2, 0, false, .click 35 48, bd2, o464, o465⟩,
  ⟨1317, 2, 0, false, .click 35 48, bd2, o465, o466⟩,
  ⟨1318, 2, 0, false, .click 35 48, bd2, o466, o467⟩,
  ⟨1319, 2, 0, false, .click 35 48, bd2, o467, o468⟩,
  ⟨1320, 2, 0, false, .click 35 48, bd2, o468, o469⟩]
def rows22 : List Row := [
  ⟨1321, 2, 0, false, .click 35 48, bd2, o469, o470⟩,
  ⟨1322, 2, 0, false, .click 35 48, bd2, o470, o471⟩,
  ⟨1323, 2, 0, false, .click 35 48, bd2, o471, o472⟩,
  ⟨1324, 2, 0, false, .click 35 48, bd2, o472, o473⟩,
  ⟨1325, 2, 1, false, .click 35 48, bd2, o473, o113⟩,
  ⟨1326, 3, 0, false, .click 57 57, bd3, o113, o474⟩,
  ⟨1327, 3, 0, false, .click 12 57, bd3, o474, o475⟩,
  ⟨1328, 3, 0, false, .click 12 57, bd3, o475, o476⟩,
  ⟨1329, 3, 0, false, .click 34 54, bd3, o476, o477⟩,
  ⟨1330, 3, 0, false, .click 34 54, bd3, o477, o478⟩,
  ⟨1331, 3, 0, false, .click 34 54, bd3, o478, o479⟩,
  ⟨1332, 3, 0, false, .click 34 54, bd3, o479, o480⟩,
  ⟨1333, 3, 0, false, .click 12 48, bd3, o480, o481⟩,
  ⟨1334, 3, 0, false, .click 12 48, bd3, o481, o482⟩,
  ⟨1335, 3, 0, false, .click 12 48, bd3, o482, o483⟩,
  ⟨1336, 3, 0, false, .click 12 48, bd3, o483, o484⟩,
  ⟨1337, 3, 0, false, .click 34 54, bd3, o484, o485⟩,
  ⟨1338, 3, 0, false, .click 34 54, bd3, o485, o486⟩,
  ⟨1339, 3, 0, false, .click 57 48, bd3, o486, o487⟩,
  ⟨1340, 3, 0, false, .click 28 54, bd3, o487, o488⟩,
  ⟨1341, 3, 0, false, .click 57 57, bd3, o488, o489⟩,
  ⟨1342, 3, 0, false, .click 28 54, bd3, o489, o490⟩,
  ⟨1343, 3, 0, false, .click 57 48, bd3, o490, o491⟩,
  ⟨1344, 3, 0, false, .click 57 57, bd3, o491, o492⟩,
  ⟨1345, 3, 0, false, .click 34 54, bd3, o492, o493⟩,
  ⟨1346, 3, 0, false, .click 34 54, bd3, o493, o494⟩,
  ⟨1347, 3, 0, false, .click 12 57, bd3, o494, o495⟩,
  ⟨1348, 3, 0, false, .click 12 57, bd3, o495, o496⟩,
  ⟨1349, 3, 0, false, .click 34 54, bd3, o496, o497⟩,
  ⟨1350, 3, 0, false, .click 34 54, bd3, o497, o134⟩,
  ⟨1351, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1352, 3, 0, false, .click 12 48, bd3, o133, o498⟩,
  ⟨1353, 3, 0, false, .click 57 48, bd3, o498, o499⟩,
  ⟨1354, 3, 0, false, .click 57 57, bd3, o499, o500⟩,
  ⟨1355, 3, 0, false, .click 12 57, bd3, o500, o501⟩,
  ⟨1356, 3, 0, false, .click 12 57, bd3, o501, o502⟩,
  ⟨1357, 3, 0, false, .click 6 57, bd3, o502, o501⟩,
  ⟨1358, 3, 0, false, .click 51 57, bd3, o501, o503⟩,
  ⟨1359, 3, 0, false, .click 51 48, bd3, o503, o504⟩,
  ⟨1360, 3, 0, false, .click 6 48, bd3, o504, o134⟩,
  ⟨1361, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1362, 3, 0, false, .click 51 57, bd3, o133, o132⟩,
  ⟨1363, 3, 0, false, .click 28 54, bd3, o132, o530⟩,
  ⟨1364, 3, 0, false, .click 6 57, bd3, o530, o531⟩,
  ⟨1365, 3, 0, false, .click 51 57, bd3, o531, o532⟩,
  ⟨1366, 3, 0, false, .click 28 54, bd3, o532, o533⟩,
  ⟨1367, 3, 0, false, .click 6 57, bd3, o533, o534⟩,
  ⟨1368, 3, 0, false, .click 28 54, bd3, o534, o535⟩,
  ⟨1369, 3, 0, false, .click 6 57, bd3, o535, o536⟩,
  ⟨1370, 3, 0, false, .click 28 54, bd3, o536, o537⟩,
  ⟨1371, 3, 0, false, .click 28 54, bd3, o537, o538⟩,
  ⟨1372, 3, 0, false, .click 28 54, bd3, o538, o539⟩,
  ⟨1373, 3, 0, false, .click 28 54, bd3, o539, o540⟩,
  ⟨1374, 3, 0, false, .click 6 57, bd3, o540, o541⟩,
  ⟨1375, 3, 0, false, .click 6 57, bd3, o541, o542⟩,
  ⟨1376, 3, 0, false, .click 6 57, bd3, o542, o543⟩,
  ⟨1377, 3, 0, false, .click 6 57, bd3, o543, o544⟩,
  ⟨1378, 3, 0, false, .click 6 57, bd3, o544, o545⟩,
  ⟨1379, 3, 0, false, .click 57 57, bd3, o545, o546⟩,
  ⟨1380, 3, 0, false, .click 57 57, bd3, o546, o547⟩]
def rows23 : List Row := [
  ⟨1381, 3, 0, false, .click 6 57, bd3, o547, o548⟩,
  ⟨1382, 3, 0, false, .click 6 57, bd3, o548, o549⟩,
  ⟨1383, 3, 0, false, .click 6 57, bd3, o549, o550⟩,
  ⟨1384, 3, 0, false, .click 34 54, bd3, o550, o551⟩,
  ⟨1385, 3, 0, false, .click 34 54, bd3, o551, o552⟩,
  ⟨1386, 3, 0, false, .click 34 54, bd3, o552, o553⟩,
  ⟨1387, 3, 0, false, .click 34 54, bd3, o553, o554⟩,
  ⟨1388, 3, 0, false, .click 34 54, bd3, o554, o555⟩,
  ⟨1389, 3, 0, false, .click 34 54, bd3, o555, o556⟩,
  ⟨1390, 3, 0, false, .click 34 54, bd3, o556, o557⟩,
  ⟨1391, 3, 0, false, .click 34 54, bd3, o557, o558⟩,
  ⟨1392, 3, 0, false, .click 34 54, bd3, o558, o559⟩,
  ⟨1393, 3, 0, false, .click 12 48, bd3, o559, o560⟩,
  ⟨1394, 3, 0, false, .click 57 48, bd3, o560, o561⟩,
  ⟨1395, 3, 0, false, .click 57 57, bd3, o561, o562⟩,
  ⟨1396, 3, 1, false, .click 34 54, bd3, o562, o165⟩,
  ⟨1397, 4, 0, false, .click 6 57, bd4, o165, o563⟩,
  ⟨1398, 4, 0, false, .click 42 57, bd4, o563, o564⟩,
  ⟨1399, 4, 0, false, .click 51 57, bd4, o564, o565⟩,
  ⟨1400, 4, 0, false, .click 27 57, bd4, o565, o566⟩,
  ⟨1401, 4, 0, false, .click 27 57, bd4, o566, o567⟩,
  ⟨1402, 4, 0, false, .click 27 57, bd4, o567, o568⟩,
  ⟨1403, 4, 0, false, .click 12 57, bd4, o568, o569⟩,
  ⟨1404, 4, 0, false, .click 12 57, bd4, o569, o570⟩,
  ⟨1405, 4, 0, false, .click 51 57, bd4, o570, o571⟩,
  ⟨1406, 4, 0, false, .click 51 57, bd4, o571, o572⟩,
  ⟨1407, 4, 0, false, .click 51 57, bd4, o572, o573⟩,
  ⟨1408, 4, 0, false, .click 42 57, bd4, o573, o574⟩,
  ⟨1409, 4, 0, false, .click 42 57, bd4, o574, o575⟩,
  ⟨1410, 4, 0, false, .click 42 57, bd4, o575, o576⟩,
  ⟨1411, 4, 0, false, .click 6 57, bd4, o576, o577⟩,
  ⟨1412, 4, 0, false, .click 57 57, bd4, o577, o189⟩,
  ⟨1413, 4, 0, false, .click 6 57, bd4, o189, o190⟩,
  ⟨1414, 4, 0, false, .click 6 57, bd4, o190, o191⟩,
  ⟨1415, 4, 0, false, .click 6 57, bd4, o191, o192⟩,
  ⟨1416, 4, 0, false, .click 6 57, bd4, o192, o193⟩,
  ⟨1417, 4, 0, false, .click 36 57, bd4, o193, o578⟩,
  ⟨1418, 4, 0, false, .click 36 57, bd4, o578, o579⟩,
  ⟨1419, 4, 0, false, .click 36 57, bd4, o579, o580⟩,
  ⟨1420, 4, 0, false, .click 27 57, bd4, o580, o581⟩,
  ⟨1421, 4, 0, false, .click 27 57, bd4, o581, o582⟩,
  ⟨1422, 4, 0, false, .click 27 57, bd4, o582, o583⟩,
  ⟨1423, 4, 0, false, .click 27 57, bd4, o583, o583⟩,
  ⟨1424, 4, 2, false, .reset, bd4, o583, o0⟩,
  ⟨1425, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨1426, 0, 0, false, .click 45 21, bd0, o1, o334⟩,
  ⟨1427, 0, 0, false, .click 45 21, bd0, o334, o335⟩,
  ⟨1428, 0, 0, false, .click 45 21, bd0, o335, o336⟩,
  ⟨1429, 0, 0, false, .click 45 21, bd0, o336, o337⟩,
  ⟨1430, 0, 0, false, .click 45 21, bd0, o337, o338⟩,
  ⟨1431, 0, 0, false, .click 45 21, bd0, o338, o339⟩,
  ⟨1432, 0, 0, false, .click 24 44, bd0, o339, o340⟩,
  ⟨1433, 0, 0, false, .click 24 44, bd0, o340, o341⟩,
  ⟨1434, 0, 0, false, .click 24 44, bd0, o341, o342⟩,
  ⟨1435, 0, 0, false, .click 24 44, bd0, o342, o343⟩,
  ⟨1436, 0, 0, false, .click 24 44, bd0, o343, o13⟩,
  ⟨1437, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨1438, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨1439, 1, 0, false, .click 27 57, bd1, o15, o344⟩,
  ⟨1440, 1, 0, false, .click 27 57, bd1, o344, o345⟩]
def rows24 : List Row := [
  ⟨1441, 1, 0, false, .click 27 57, bd1, o345, o346⟩,
  ⟨1442, 1, 0, false, .click 42 57, bd1, o346, o347⟩,
  ⟨1443, 1, 0, false, .click 42 57, bd1, o347, o348⟩,
  ⟨1444, 1, 0, false, .click 12 57, bd1, o348, o349⟩,
  ⟨1445, 1, 0, false, .click 57 57, bd1, o349, o350⟩,
  ⟨1446, 1, 0, false, .click 27 57, bd1, o350, o351⟩,
  ⟨1447, 1, 0, false, .click 12 57, bd1, o351, o352⟩,
  ⟨1448, 1, 0, false, .click 57 57, bd1, o352, o353⟩,
  ⟨1449, 1, 0, false, .click 36 57, bd1, o353, o354⟩,
  ⟨1450, 1, 0, false, .click 27 57, bd1, o354, o355⟩,
  ⟨1451, 1, 0, false, .click 6 57, bd1, o355, o356⟩,
  ⟨1452, 1, 0, false, .click 42 57, bd1, o356, o357⟩,
  ⟨1453, 1, 0, false, .click 42 57, bd1, o357, o358⟩,
  ⟨1454, 1, 0, false, .click 57 57, bd1, o358, o359⟩,
  ⟨1455, 1, 0, false, .click 6 57, bd1, o359, o360⟩,
  ⟨1456, 1, 0, false, .click 57 57, bd1, o360, o361⟩,
  ⟨1457, 1, 0, false, .click 57 57, bd1, o361, o362⟩,
  ⟨1458, 1, 0, false, .click 57 57, bd1, o362, o363⟩,
  ⟨1459, 1, 0, false, .click 57 57, bd1, o363, o364⟩,
  ⟨1460, 1, 0, false, .click 57 57, bd1, o364, o365⟩,
  ⟨1461, 1, 0, false, .click 57 57, bd1, o365, o366⟩,
  ⟨1462, 1, 0, false, .click 57 57, bd1, o366, o367⟩,
  ⟨1463, 1, 0, false, .click 36 57, bd1, o367, o368⟩,
  ⟨1464, 1, 0, false, .click 12 57, bd1, o368, o369⟩,
  ⟨1465, 1, 0, false, .click 12 57, bd1, o369, o370⟩,
  ⟨1466, 1, 0, false, .click 27 57, bd1, o370, o371⟩,
  ⟨1467, 1, 0, false, .click 27 57, bd1, o371, o372⟩,
  ⟨1468, 1, 0, false, .click 27 57, bd1, o372, o373⟩,
  ⟨1469, 1, 0, false, .click 27 57, bd1, o373, o374⟩,
  ⟨1470, 1, 0, false, .click 27 57, bd1, o374, o375⟩,
  ⟨1471, 1, 0, false, .click 27 57, bd1, o375, o376⟩,
  ⟨1472, 1, 0, false, .click 51 57, bd1, o376, o377⟩,
  ⟨1473, 1, 0, false, .click 36 57, bd1, o377, o378⟩,
  ⟨1474, 1, 0, false, .click 12 57, bd1, o378, o379⟩,
  ⟨1475, 1, 0, false, .click 21 57, bd1, o379, o380⟩,
  ⟨1476, 1, 0, false, .click 36 57, bd1, o380, o381⟩,
  ⟨1477, 1, 0, false, .click 27 57, bd1, o381, o382⟩,
  ⟨1478, 1, 0, false, .click 27 57, bd1, o382, o383⟩,
  ⟨1479, 1, 0, false, .click 12 57, bd1, o383, o384⟩,
  ⟨1480, 1, 0, false, .click 51 57, bd1, o384, o385⟩,
  ⟨1481, 1, 0, false, .click 51 57, bd1, o385, o386⟩,
  ⟨1482, 1, 0, false, .click 51 57, bd1, o386, o387⟩,
  ⟨1483, 1, 0, false, .click 51 57, bd1, o387, o388⟩,
  ⟨1484, 1, 0, false, .click 51 57, bd1, o388, o389⟩,
  ⟨1485, 1, 0, false, .click 51 57, bd1, o389, o390⟩,
  ⟨1486, 1, 0, false, .click 51 57, bd1, o390, o391⟩,
  ⟨1487, 1, 0, false, .click 12 57, bd1, o391, o392⟩,
  ⟨1488, 1, 0, false, .click 42 57, bd1, o392, o393⟩,
  ⟨1489, 1, 0, false, .click 42 57, bd1, o393, o394⟩,
  ⟨1490, 1, 0, false, .click 42 57, bd1, o394, o395⟩,
  ⟨1491, 1, 0, false, .click 6 57, bd1, o395, o396⟩,
  ⟨1492, 1, 0, false, .click 6 57, bd1, o396, o397⟩,
  ⟨1493, 1, 0, false, .click 42 57, bd1, o397, o398⟩,
  ⟨1494, 1, 0, false, .click 51 57, bd1, o398, o399⟩,
  ⟨1495, 1, 0, false, .click 51 57, bd1, o399, o400⟩,
  ⟨1496, 1, 0, false, .click 42 57, bd1, o400, o401⟩,
  ⟨1497, 1, 0, false, .click 42 57, bd1, o401, o402⟩,
  ⟨1498, 1, 0, false, .click 42 57, bd1, o402, o403⟩,
  ⟨1499, 1, 0, false, .click 42 57, bd1, o403, o404⟩,
  ⟨1500, 1, 0, false, .click 21 57, bd1, o404, o405⟩]
def rows25 : List Row := [
  ⟨1501, 1, 0, false, .click 57 57, bd1, o405, o406⟩,
  ⟨1502, 1, 0, false, .click 51 57, bd1, o406, o405⟩,
  ⟨1503, 1, 0, false, .click 21 57, bd1, o405, o407⟩,
  ⟨1504, 1, 0, false, .click 6 57, bd1, o407, o408⟩,
  ⟨1505, 1, 0, false, .click 6 57, bd1, o408, o409⟩,
  ⟨1506, 1, 0, false, .click 36 57, bd1, o409, o410⟩,
  ⟨1507, 1, 0, false, .click 36 57, bd1, o410, o411⟩,
  ⟨1508, 1, 0, false, .click 36 57, bd1, o411, o412⟩,
  ⟨1509, 1, 0, false, .click 36 57, bd1, o412, o413⟩,
  ⟨1510, 1, 0, false, .click 36 57, bd1, o413, o414⟩,
  ⟨1511, 1, 0, false, .click 36 57, bd1, o414, o415⟩,
  ⟨1512, 1, 0, false, .click 36 57, bd1, o415, o416⟩,
  ⟨1513, 1, 0, false, .click 36 57, bd1, o416, o417⟩,
  ⟨1514, 1, 0, false, .click 21 57, bd1, o417, o418⟩,
  ⟨1515, 1, 0, false, .click 21 57, bd1, o418, o419⟩,
  ⟨1516, 1, 0, false, .click 21 57, bd1, o419, o420⟩,
  ⟨1517, 1, 0, false, .click 21 57, bd1, o420, o421⟩,
  ⟨1518, 1, 0, false, .click 21 57, bd1, o421, o422⟩,
  ⟨1519, 1, 0, false, .click 21 57, bd1, o422, o423⟩,
  ⟨1520, 1, 0, false, .click 21 57, bd1, o423, o424⟩,
  ⟨1521, 1, 0, false, .click 12 57, bd1, o424, o425⟩,
  ⟨1522, 1, 0, false, .click 12 57, bd1, o425, o426⟩,
  ⟨1523, 1, 0, false, .click 12 57, bd1, o426, o427⟩,
  ⟨1524, 1, 0, false, .click 12 57, bd1, o427, o428⟩,
  ⟨1525, 1, 0, false, .click 12 57, bd1, o428, o429⟩,
  ⟨1526, 1, 0, false, .click 12 57, bd1, o429, o25⟩,
  ⟨1527, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨1528, 1, 0, false, .click 27 57, bd1, o26, o27⟩,
  ⟨1529, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨1530, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨1531, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨1532, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨1533, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨1534, 1, 0, false, .click 57 57, bd1, o32, o33⟩,
  ⟨1535, 1, 0, false, .click 57 57, bd1, o33, o34⟩,
  ⟨1536, 1, 0, false, .click 57 57, bd1, o34, o35⟩,
  ⟨1537, 1, 0, false, .click 57 57, bd1, o35, o36⟩,
  ⟨1538, 1, 0, false, .click 57 57, bd1, o36, o37⟩,
  ⟨1539, 1, 0, false, .click 57 57, bd1, o37, o430⟩,
  ⟨1540, 1, 0, false, .click 42 57, bd1, o430, o431⟩,
  ⟨1541, 1, 1, false, .click 42 57, bd1, o431, o40⟩,
  ⟨1542, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨1543, 2, 0, false, .click 54 57, bd2, o54, o432⟩,
  ⟨1544, 2, 0, false, .click 48 48, bd2, o432, o433⟩,
  ⟨1545, 2, 0, false, .click 16 48, bd2, o433, o434⟩,
  ⟨1546, 2, 0, false, .click 48 48, bd2, o434, o435⟩,
  ⟨1547, 2, 0, false, .click 16 48, bd2, o435, o436⟩,
  ⟨1548, 2, 0, false, .click 16 57, bd2, o436, o437⟩,
  ⟨1549, 2, 0, false, .click 16 57, bd2, o437, o438⟩,
  ⟨1550, 2, 0, false, .click 16 57, bd2, o438, o439⟩,
  ⟨1551, 2, 0, false, .click 16 57, bd2, o439, o440⟩,
  ⟨1552, 2, 0, false, .click 16 57, bd2, o440, o441⟩,
  ⟨1553, 2, 0, false, .click 16 57, bd2, o441, o442⟩,
  ⟨1554, 2, 0, false, .click 54 57, bd2, o442, o443⟩,
  ⟨1555, 2, 0, false, .click 54 57, bd2, o443, o444⟩,
  ⟨1556, 2, 0, false, .click 54 57, bd2, o444, o445⟩,
  ⟨1557, 2, 0, false, .click 48 48, bd2, o445, o446⟩,
  ⟨1558, 2, 0, false, .click 10 48, bd2, o446, o447⟩,
  ⟨1559, 2, 0, false, .click 10 48, bd2, o447, o448⟩,
  ⟨1560, 2, 0, false, .click 10 48, bd2, o448, o449⟩]
def rows26 : List Row := [
  ⟨1561, 2, 0, false, .click 10 48, bd2, o449, o450⟩,
  ⟨1562, 2, 0, false, .click 48 48, bd2, o450, o451⟩,
  ⟨1563, 2, 0, false, .click 48 48, bd2, o451, o452⟩,
  ⟨1564, 2, 0, false, .click 35 57, bd2, o452, o453⟩,
  ⟨1565, 2, 0, false, .click 35 57, bd2, o453, o454⟩,
  ⟨1566, 2, 0, false, .click 35 57, bd2, o454, o455⟩,
  ⟨1567, 2, 0, false, .click 35 57, bd2, o455, o456⟩,
  ⟨1568, 2, 0, false, .click 35 57, bd2, o456, o457⟩,
  ⟨1569, 2, 0, false, .click 35 57, bd2, o457, o458⟩,
  ⟨1570, 2, 0, false, .click 35 57, bd2, o458, o459⟩,
  ⟨1571, 2, 0, false, .click 10 48, bd2, o459, o460⟩,
  ⟨1572, 2, 0, false, .click 10 48, bd2, o460, o461⟩,
  ⟨1573, 2, 0, false, .click 10 48, bd2, o461, o462⟩,
  ⟨1574, 2, 0, false, .click 35 48, bd2, o462, o463⟩,
  ⟨1575, 2, 0, false, .click 35 48, bd2, o463, o464⟩,
  ⟨1576, 2, 0, false, .click 35 48, bd2, o464, o465⟩,
  ⟨1577, 2, 0, false, .click 35 48, bd2, o465, o466⟩,
  ⟨1578, 2, 0, false, .click 35 48, bd2, o466, o467⟩,
  ⟨1579, 2, 0, false, .click 35 48, bd2, o467, o468⟩,
  ⟨1580, 2, 0, false, .click 35 48, bd2, o468, o469⟩,
  ⟨1581, 2, 0, false, .click 35 48, bd2, o469, o470⟩,
  ⟨1582, 2, 0, false, .click 35 48, bd2, o470, o471⟩,
  ⟨1583, 2, 0, false, .click 35 48, bd2, o471, o472⟩,
  ⟨1584, 2, 0, false, .click 35 48, bd2, o472, o473⟩,
  ⟨1585, 2, 1, false, .click 35 48, bd2, o473, o113⟩,
  ⟨1586, 3, 0, false, .click 57 57, bd3, o113, o474⟩,
  ⟨1587, 3, 0, false, .click 12 57, bd3, o474, o475⟩,
  ⟨1588, 3, 0, false, .click 12 57, bd3, o475, o476⟩,
  ⟨1589, 3, 0, false, .click 34 54, bd3, o476, o477⟩,
  ⟨1590, 3, 0, false, .click 34 54, bd3, o477, o478⟩,
  ⟨1591, 3, 0, false, .click 34 54, bd3, o478, o479⟩,
  ⟨1592, 3, 0, false, .click 34 54, bd3, o479, o480⟩,
  ⟨1593, 3, 0, false, .click 12 48, bd3, o480, o481⟩,
  ⟨1594, 3, 0, false, .click 12 48, bd3, o481, o482⟩,
  ⟨1595, 3, 0, false, .click 12 48, bd3, o482, o483⟩,
  ⟨1596, 3, 0, false, .click 12 48, bd3, o483, o484⟩,
  ⟨1597, 3, 0, false, .click 34 54, bd3, o484, o485⟩,
  ⟨1598, 3, 0, false, .click 34 54, bd3, o485, o486⟩,
  ⟨1599, 3, 0, false, .click 57 48, bd3, o486, o487⟩,
  ⟨1600, 3, 0, false, .click 28 54, bd3, o487, o488⟩,
  ⟨1601, 3, 0, false, .click 57 57, bd3, o488, o489⟩,
  ⟨1602, 3, 0, false, .click 28 54, bd3, o489, o490⟩,
  ⟨1603, 3, 0, false, .click 57 48, bd3, o490, o491⟩,
  ⟨1604, 3, 0, false, .click 57 57, bd3, o491, o492⟩,
  ⟨1605, 3, 0, false, .click 34 54, bd3, o492, o493⟩,
  ⟨1606, 3, 0, false, .click 34 54, bd3, o493, o494⟩,
  ⟨1607, 3, 0, false, .click 12 57, bd3, o494, o495⟩,
  ⟨1608, 3, 0, false, .click 12 57, bd3, o495, o496⟩,
  ⟨1609, 3, 0, false, .click 34 54, bd3, o496, o497⟩,
  ⟨1610, 3, 0, false, .click 34 54, bd3, o497, o134⟩,
  ⟨1611, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1612, 3, 0, false, .click 12 48, bd3, o133, o498⟩,
  ⟨1613, 3, 0, false, .click 57 48, bd3, o498, o499⟩,
  ⟨1614, 3, 0, false, .click 57 57, bd3, o499, o500⟩,
  ⟨1615, 3, 0, false, .click 12 57, bd3, o500, o501⟩,
  ⟨1616, 3, 0, false, .click 12 57, bd3, o501, o502⟩,
  ⟨1617, 3, 0, false, .click 6 57, bd3, o502, o501⟩,
  ⟨1618, 3, 0, false, .click 51 57, bd3, o501, o503⟩,
  ⟨1619, 3, 0, false, .click 51 48, bd3, o503, o504⟩,
  ⟨1620, 3, 0, false, .click 6 48, bd3, o504, o134⟩]
def rows27 : List Row := [
  ⟨1621, 3, 0, false, .click 6 57, bd3, o134, o133⟩,
  ⟨1622, 3, 0, false, .click 51 57, bd3, o133, o132⟩,
  ⟨1623, 3, 0, false, .click 28 54, bd3, o132, o530⟩,
  ⟨1624, 3, 0, false, .click 6 57, bd3, o530, o531⟩,
  ⟨1625, 3, 0, false, .click 51 57, bd3, o531, o532⟩,
  ⟨1626, 3, 0, false, .click 28 54, bd3, o532, o533⟩,
  ⟨1627, 3, 0, false, .click 6 57, bd3, o533, o534⟩,
  ⟨1628, 3, 0, false, .click 28 54, bd3, o534, o535⟩,
  ⟨1629, 3, 0, false, .click 6 57, bd3, o535, o536⟩,
  ⟨1630, 3, 0, false, .click 28 54, bd3, o536, o537⟩,
  ⟨1631, 3, 0, false, .click 28 54, bd3, o537, o538⟩,
  ⟨1632, 3, 0, false, .click 28 54, bd3, o538, o539⟩,
  ⟨1633, 3, 0, false, .click 28 54, bd3, o539, o540⟩,
  ⟨1634, 3, 0, false, .click 6 57, bd3, o540, o541⟩,
  ⟨1635, 3, 0, false, .click 6 57, bd3, o541, o542⟩,
  ⟨1636, 3, 0, false, .click 6 57, bd3, o542, o543⟩,
  ⟨1637, 3, 0, false, .click 6 57, bd3, o543, o544⟩,
  ⟨1638, 3, 0, false, .click 6 57, bd3, o544, o545⟩,
  ⟨1639, 3, 0, false, .click 57 57, bd3, o545, o546⟩,
  ⟨1640, 3, 0, false, .click 57 57, bd3, o546, o547⟩,
  ⟨1641, 3, 0, false, .click 6 57, bd3, o547, o548⟩,
  ⟨1642, 3, 0, false, .click 6 57, bd3, o548, o549⟩,
  ⟨1643, 3, 0, false, .click 6 57, bd3, o549, o550⟩,
  ⟨1644, 3, 0, false, .click 34 54, bd3, o550, o551⟩,
  ⟨1645, 3, 0, false, .click 34 54, bd3, o551, o552⟩,
  ⟨1646, 3, 0, false, .click 34 54, bd3, o552, o553⟩,
  ⟨1647, 3, 0, false, .click 34 54, bd3, o553, o554⟩,
  ⟨1648, 3, 0, false, .click 34 54, bd3, o554, o555⟩,
  ⟨1649, 3, 0, false, .click 34 54, bd3, o555, o556⟩,
  ⟨1650, 3, 0, false, .click 34 54, bd3, o556, o557⟩,
  ⟨1651, 3, 0, false, .click 34 54, bd3, o557, o558⟩,
  ⟨1652, 3, 0, false, .click 34 54, bd3, o558, o559⟩,
  ⟨1653, 3, 0, false, .click 12 48, bd3, o559, o560⟩,
  ⟨1654, 3, 0, false, .click 57 48, bd3, o560, o561⟩,
  ⟨1655, 3, 0, false, .click 57 57, bd3, o561, o562⟩,
  ⟨1656, 3, 1, false, .click 34 54, bd3, o562, o165⟩,
  ⟨1657, 4, 0, false, .click 27 57, bd4, o165, o584⟩,
  ⟨1658, 4, 0, false, .click 42 57, bd4, o584, o585⟩,
  ⟨1659, 4, 0, false, .click 51 57, bd4, o585, o586⟩,
  ⟨1660, 4, 0, false, .click 12 57, bd4, o586, o587⟩,
  ⟨1661, 4, 0, false, .click 51 57, bd4, o587, o588⟩,
  ⟨1662, 4, 0, false, .click 51 57, bd4, o588, o589⟩,
  ⟨1663, 4, 0, false, .click 51 57, bd4, o589, o590⟩,
  ⟨1664, 4, 0, false, .click 51 57, bd4, o590, o591⟩,
  ⟨1665, 4, 0, false, .click 36 57, bd4, o591, o592⟩,
  ⟨1666, 4, 0, false, .click 27 57, bd4, o592, o593⟩,
  ⟨1667, 4, 0, false, .click 27 57, bd4, o593, o594⟩,
  ⟨1668, 4, 0, false, .click 12 57, bd4, o594, o595⟩,
  ⟨1669, 4, 0, false, .click 42 57, bd4, o595, o596⟩,
  ⟨1670, 4, 0, false, .click 42 57, bd4, o596, o597⟩,
  ⟨1671, 4, 0, false, .click 42 57, bd4, o597, o598⟩,
  ⟨1672, 4, 0, false, .click 42 57, bd4, o598, o599⟩,
  ⟨1673, 4, 0, false, .click 6 57, bd4, o599, o600⟩,
  ⟨1674, 4, 0, false, .click 6 57, bd4, o600, o601⟩,
  ⟨1675, 4, 0, false, .click 6 57, bd4, o601, o602⟩,
  ⟨1676, 4, 0, false, .click 6 57, bd4, o602, o603⟩,
  ⟨1677, 4, 0, false, .click 6 57, bd4, o603, o604⟩,
  ⟨1678, 4, 0, false, .click 6 57, bd4, o604, o605⟩,
  ⟨1679, 4, 0, false, .click 6 57, bd4, o605, o606⟩,
  ⟨1680, 4, 0, false, .click 36 57, bd4, o606, o607⟩]
def rows28 : List Row := [
  ⟨1681, 4, 0, false, .click 36 57, bd4, o607, o608⟩,
  ⟨1682, 4, 0, false, .click 36 57, bd4, o608, o609⟩,
  ⟨1683, 4, 0, false, .click 36 57, bd4, o609, o610⟩,
  ⟨1684, 4, 0, false, .click 27 57, bd4, o610, o611⟩,
  ⟨1685, 4, 0, false, .click 27 57, bd4, o611, o612⟩,
  ⟨1686, 4, 0, false, .click 27 57, bd4, o612, o613⟩,
  ⟨1687, 4, 0, false, .click 27 57, bd4, o613, o614⟩,
  ⟨1688, 4, 0, false, .click 27 57, bd4, o614, o615⟩,
  ⟨1689, 4, 0, false, .click 42 57, bd4, o615, o616⟩,
  ⟨1690, 4, 0, false, .click 42 57, bd4, o616, o617⟩,
  ⟨1691, 4, 0, false, .click 42 57, bd4, o617, o618⟩,
  ⟨1692, 4, 0, false, .click 42 57, bd4, o618, o619⟩,
  ⟨1693, 4, 0, false, .click 57 57, bd4, o619, o620⟩,
  ⟨1694, 4, 0, false, .click 57 57, bd4, o620, o621⟩,
  ⟨1695, 4, 0, false, .click 57 57, bd4, o621, o622⟩,
  ⟨1696, 4, 0, false, .click 57 57, bd4, o622, o623⟩,
  ⟨1697, 4, 0, false, .click 57 57, bd4, o623, o624⟩,
  ⟨1698, 4, 1, false, .click 27 57, bd4, o624, o209⟩,
  ⟨1699, 5, 0, false, .click 47 57, bd5, o209, o625⟩,
  ⟨1700, 5, 0, false, .click 28 57, bd5, o625, o626⟩,
  ⟨1701, 5, 0, false, .click 28 57, bd5, o626, o627⟩,
  ⟨1702, 5, 0, false, .click 12 48, bd5, o627, o628⟩,
  ⟨1703, 5, 0, false, .click 12 48, bd5, o628, o629⟩,
  ⟨1704, 5, 0, false, .click 53 57, bd5, o629, o630⟩,
  ⟨1705, 5, 0, false, .click 53 57, bd5, o630, o631⟩,
  ⟨1706, 5, 0, false, .click 50 48, bd5, o631, o632⟩,
  ⟨1707, 5, 0, false, .click 50 48, bd5, o632, o632⟩,
  ⟨1708, 5, 0, false, .click 31 48, bd5, o632, o633⟩,
  ⟨1709, 5, 0, false, .click 31 48, bd5, o633, o634⟩,
  ⟨1710, 5, 0, false, .click 47 57, bd5, o634, o635⟩,
  ⟨1711, 5, 0, false, .click 15 57, bd5, o635, o636⟩,
  ⟨1712, 5, 0, false, .click 15 57, bd5, o636, o637⟩,
  ⟨1713, 5, 0, false, .click 31 48, bd5, o637, o638⟩,
  ⟨1714, 5, 0, false, .click 31 48, bd5, o638, o639⟩,
  ⟨1715, 5, 0, false, .click 50 48, bd5, o639, o640⟩,
  ⟨1716, 5, 0, false, .click 15 57, bd5, o640, o641⟩,
  ⟨1717, 5, 0, false, .click 15 57, bd5, o641, o642⟩,
  ⟨1718, 5, 0, false, .click 15 57, bd5, o642, o643⟩,
  ⟨1719, 5, 0, false, .click 15 57, bd5, o643, o644⟩,
  ⟨1720, 5, 0, false, .click 15 57, bd5, o644, o645⟩,
  ⟨1721, 5, 0, false, .click 9 57, bd5, o645, o644⟩,
  ⟨1722, 5, 0, false, .click 9 57, bd5, o644, o643⟩,
  ⟨1723, 5, 0, false, .click 9 57, bd5, o643, o642⟩,
  ⟨1724, 5, 0, false, .click 9 57, bd5, o642, o641⟩,
  ⟨1725, 5, 0, false, .click 31 48, bd5, o641, o646⟩,
  ⟨1726, 5, 0, false, .click 34 57, bd5, o646, o647⟩,
  ⟨1727, 5, 0, false, .click 34 57, bd5, o647, o648⟩,
  ⟨1728, 5, 0, false, .click 34 57, bd5, o648, o649⟩,
  ⟨1729, 5, 0, false, .click 34 57, bd5, o649, o650⟩,
  ⟨1730, 5, 0, false, .click 34 57, bd5, o650, o651⟩,
  ⟨1731, 5, 0, false, .click 34 57, bd5, o651, o652⟩,
  ⟨1732, 5, 0, false, .click 12 48, bd5, o652, o653⟩,
  ⟨1733, 5, 0, false, .click 47 57, bd5, o653, o654⟩,
  ⟨1734, 5, 0, false, .click 15 57, bd5, o654, o655⟩,
  ⟨1735, 5, 0, false, .click 53 57, bd5, o655, o656⟩,
  ⟨1736, 5, 0, false, .click 9 57, bd5, o656, o653⟩,
  ⟨1737, 5, 0, false, .click 47 57, bd5, o653, o654⟩,
  ⟨1738, 5, 0, false, .click 15 57, bd5, o654, o655⟩,
  ⟨1739, 5, 0, false, .click 31 48, bd5, o655, o657⟩,
  ⟨1740, 5, 0, false, .click 28 57, bd5, o657, o658⟩]
def rows29 : List Row := [
  ⟨1741, 5, 0, false, .click 28 57, bd5, o658, o659⟩,
  ⟨1742, 5, 0, false, .click 28 57, bd5, o659, o660⟩,
  ⟨1743, 5, 0, false, .click 28 57, bd5, o660, o661⟩,
  ⟨1744, 5, 0, false, .click 50 48, bd5, o661, o662⟩,
  ⟨1745, 5, 0, false, .click 53 57, bd5, o662, o663⟩,
  ⟨1746, 5, 0, false, .click 50 48, bd5, o663, o213⟩,
  ⟨1747, 5, 0, false, .click 28 57, bd5, o213, o664⟩,
  ⟨1748, 5, 0, false, .click 9 57, bd5, o664, o665⟩,
  ⟨1749, 5, 0, false, .click 53 57, bd5, o665, o666⟩,
  ⟨1750, 5, 0, false, .click 53 57, bd5, o666, o667⟩,
  ⟨1751, 5, 0, false, .click 50 48, bd5, o667, o668⟩,
  ⟨1752, 5, 0, false, .click 31 48, bd5, o668, o669⟩,
  ⟨1753, 5, 0, false, .click 31 48, bd5, o669, o670⟩,
  ⟨1754, 5, 0, false, .click 53 57, bd5, o670, o671⟩,
  ⟨1755, 5, 0, false, .click 28 57, bd5, o671, o672⟩,
  ⟨1756, 5, 0, false, .click 47 57, bd5, o672, o673⟩,
  ⟨1757, 5, 0, false, .click 47 57, bd5, o673, o674⟩,
  ⟨1758, 5, 0, false, .click 47 57, bd5, o674, o675⟩,
  ⟨1759, 5, 0, false, .click 47 57, bd5, o675, o676⟩,
  ⟨1760, 5, 0, false, .click 9 57, bd5, o676, o677⟩,
  ⟨1761, 5, 0, false, .click 9 57, bd5, o677, o678⟩,
  ⟨1762, 5, 0, false, .click 12 48, bd5, o678, o679⟩,
  ⟨1763, 5, 0, false, .click 12 48, bd5, o679, o680⟩,
  ⟨1764, 5, 0, false, .click 31 48, bd5, o680, o681⟩,
  ⟨1765, 5, 0, false, .click 50 48, bd5, o681, o682⟩,
  ⟨1766, 5, 0, false, .click 50 48, bd5, o682, o683⟩,
  ⟨1767, 5, 0, false, .click 34 57, bd5, o683, o684⟩,
  ⟨1768, 5, 0, false, .click 34 57, bd5, o684, o685⟩,
  ⟨1769, 5, 0, false, .click 53 57, bd5, o685, o686⟩,
  ⟨1770, 5, 0, false, .click 9 57, bd5, o686, o687⟩,
  ⟨1771, 5, 0, false, .click 53 57, bd5, o687, o688⟩,
  ⟨1772, 5, 0, false, .click 50 48, bd5, o688, o689⟩,
  ⟨1773, 5, 0, false, .click 50 48, bd5, o689, o690⟩,
  ⟨1774, 5, 0, false, .click 53 57, bd5, o690, o691⟩,
  ⟨1775, 5, 0, false, .click 15 57, bd5, o691, o692⟩,
  ⟨1776, 5, 0, false, .click 34 57, bd5, o692, o693⟩,
  ⟨1777, 5, 0, false, .click 53 57, bd5, o693, o694⟩,
  ⟨1778, 5, 0, false, .click 15 57, bd5, o694, o695⟩,
  ⟨1779, 5, 0, false, .click 34 57, bd5, o695, o696⟩,
  ⟨1780, 5, 0, false, .click 53 57, bd5, o696, o697⟩,
  ⟨1781, 5, 0, false, .click 53 57, bd5, o697, o698⟩,
  ⟨1782, 5, 0, false, .click 53 57, bd5, o698, o699⟩,
  ⟨1783, 5, 0, false, .click 31 48, bd5, o699, o700⟩,
  ⟨1784, 5, 0, false, .click 31 48, bd5, o700, o701⟩,
  ⟨1785, 5, 0, false, .click 15 57, bd5, o701, o702⟩,
  ⟨1786, 5, 0, false, .click 15 57, bd5, o702, o703⟩,
  ⟨1787, 5, 0, false, .click 15 57, bd5, o703, o704⟩,
  ⟨1788, 5, 0, false, .click 15 57, bd5, o704, o705⟩,
  ⟨1789, 5, 0, false, .click 15 57, bd5, o705, o706⟩,
  ⟨1790, 5, 0, false, .click 15 57, bd5, o706, o707⟩,
  ⟨1791, 5, 0, false, .click 15 57, bd5, o707, o708⟩,
  ⟨1792, 5, 0, false, .click 15 57, bd5, o708, o709⟩,
  ⟨1793, 5, 0, false, .click 15 57, bd5, o709, o710⟩,
  ⟨1794, 5, 1, false, .click 34 57, bd5, o710, o245⟩,
  ⟨1795, 6, 0, false, .click 17 51, bd6, o245, o711⟩,
  ⟨1796, 6, 0, false, .click 17 51, bd6, o711, o712⟩,
  ⟨1797, 6, 0, false, .click 10 51, bd6, o712, o713⟩,
  ⟨1798, 6, 0, false, .click 26 51, bd6, o713, o714⟩,
  ⟨1799, 6, 0, false, .click 10 51, bd6, o714, o715⟩,
  ⟨1800, 6, 0, false, .click 10 51, bd6, o715, o716⟩]
def rows30 : List Row := [
  ⟨1801, 6, 0, false, .click 10 51, bd6, o716, o717⟩,
  ⟨1802, 6, 0, false, .click 10 51, bd6, o717, o718⟩,
  ⟨1803, 6, 0, false, .click 10 51, bd6, o718, o719⟩,
  ⟨1804, 6, 0, false, .click 10 58, bd6, o719, o720⟩,
  ⟨1805, 6, 0, false, .click 10 58, bd6, o720, o721⟩,
  ⟨1806, 6, 0, false, .click 10 58, bd6, o721, o722⟩,
  ⟨1807, 6, 0, false, .click 10 58, bd6, o722, o723⟩,
  ⟨1808, 6, 0, false, .click 32 51, bd6, o723, o724⟩,
  ⟨1809, 6, 0, false, .click 32 51, bd6, o724, o725⟩,
  ⟨1810, 6, 0, false, .click 32 51, bd6, o725, o726⟩,
  ⟨1811, 6, 0, false, .click 32 51, bd6, o726, o727⟩,
  ⟨1812, 6, 0, false, .click 32 51, bd6, o727, o728⟩,
  ⟨1813, 6, 0, false, .click 60 58, bd6, o728, o728⟩,
  ⟨1814, 6, 2, false, .reset, bd6, o728, o245⟩,
  ⟨1815, 6, 2, false, .reset, bd6, o245, o0⟩,
  ⟨1816, 0, 0, false, .click 45 21, bd0, o0, o1⟩,
  ⟨1817, 0, 0, false, .click 45 21, bd0, o1, o334⟩,
  ⟨1818, 0, 0, false, .click 45 21, bd0, o334, o335⟩,
  ⟨1819, 0, 0, false, .click 45 21, bd0, o335, o336⟩,
  ⟨1820, 0, 0, false, .click 45 21, bd0, o336, o337⟩,
  ⟨1821, 0, 0, false, .click 45 21, bd0, o337, o338⟩,
  ⟨1822, 0, 0, false, .click 45 21, bd0, o338, o339⟩,
  ⟨1823, 0, 0, false, .click 24 44, bd0, o339, o340⟩,
  ⟨1824, 0, 0, false, .click 24 44, bd0, o340, o341⟩,
  ⟨1825, 0, 0, false, .click 24 44, bd0, o341, o342⟩,
  ⟨1826, 0, 0, false, .click 24 44, bd0, o342, o343⟩,
  ⟨1827, 0, 0, false, .click 24 44, bd0, o343, o13⟩,
  ⟨1828, 0, 1, false, .click 24 44, bd0, o13, o14⟩,
  ⟨1829, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨1830, 1, 0, false, .click 27 57, bd1, o15, o344⟩,
  ⟨1831, 1, 0, false, .click 27 57, bd1, o344, o345⟩,
  ⟨1832, 1, 0, false, .click 27 57, bd1, o345, o346⟩,
  ⟨1833, 1, 0, false, .click 27 57, bd1, o346, o729⟩,
  ⟨1834, 1, 0, false, .click 27 57, bd1, o729, o730⟩,
  ⟨1835, 1, 0, false, .click 27 57, bd1, o730, o731⟩,
  ⟨1836, 1, 0, false, .click 27 57, bd1, o731, o732⟩,
  ⟨1837, 1, 0, false, .click 27 57, bd1, o732, o733⟩,
  ⟨1838, 1, 0, false, .click 27 57, bd1, o733, o734⟩,
  ⟨1839, 1, 0, false, .click 27 57, bd1, o734, o735⟩,
  ⟨1840, 1, 0, false, .click 27 57, bd1, o735, o736⟩,
  ⟨1841, 1, 0, false, .click 42 57, bd1, o736, o737⟩,
  ⟨1842, 1, 0, false, .click 57 57, bd1, o737, o738⟩,
  ⟨1843, 1, 0, false, .click 57 57, bd1, o738, o739⟩,
  ⟨1844, 1, 0, false, .click 12 57, bd1, o739, o740⟩,
  ⟨1845, 1, 0, false, .click 42 57, bd1, o740, o741⟩,
  ⟨1846, 1, 0, false, .click 42 57, bd1, o741, o742⟩,
  ⟨1847, 1, 0, false, .click 27 57, bd1, o742, o743⟩,
  ⟨1848, 1, 0, false, .click 12 57, bd1, o743, o744⟩,
  ⟨1849, 1, 0, false, .click 42 57, bd1, o744, o745⟩,
  ⟨1850, 1, 0, false, .click 42 57, bd1, o745, o746⟩,
  ⟨1851, 1, 0, false, .click 42 57, bd1, o746, o747⟩,
  ⟨1852, 1, 0, false, .click 42 57, bd1, o747, o748⟩,
  ⟨1853, 1, 0, false, .click 42 57, bd1, o748, o749⟩,
  ⟨1854, 1, 0, false, .click 42 57, bd1, o749, o750⟩,
  ⟨1855, 1, 0, false, .click 42 57, bd1, o750, o751⟩,
  ⟨1856, 1, 0, false, .click 42 57, bd1, o751, o752⟩,
  ⟨1857, 1, 0, false, .click 57 57, bd1, o752, o753⟩,
  ⟨1858, 1, 0, false, .click 57 57, bd1, o753, o754⟩,
  ⟨1859, 1, 0, false, .click 57 57, bd1, o754, o755⟩,
  ⟨1860, 1, 0, false, .click 57 57, bd1, o755, o756⟩]
def rows31 : List Row := [
  ⟨1861, 1, 0, false, .click 57 57, bd1, o756, o757⟩,
  ⟨1862, 1, 0, false, .click 57 57, bd1, o757, o758⟩,
  ⟨1863, 1, 0, false, .click 57 57, bd1, o758, o759⟩,
  ⟨1864, 1, 0, false, .click 57 57, bd1, o759, o760⟩,
  ⟨1865, 1, 0, false, .click 12 57, bd1, o760, o761⟩,
  ⟨1866, 1, 0, false, .click 36 57, bd1, o761, o762⟩,
  ⟨1867, 1, 2, false, .reset, bd1, o762, o14⟩,
  ⟨1868, 1, 0, false, .click 12 57, bd1, o14, o15⟩,
  ⟨1869, 1, 0, false, .click 12 57, bd1, o15, o16⟩,
  ⟨1870, 1, 0, false, .click 12 57, bd1, o16, o17⟩,
  ⟨1871, 1, 0, false, .click 12 57, bd1, o17, o18⟩,
  ⟨1872, 1, 0, false, .click 27 57, bd1, o18, o763⟩,
  ⟨1873, 1, 0, false, .click 42 57, bd1, o763, o764⟩,
  ⟨1874, 1, 0, false, .click 27 57, bd1, o764, o765⟩,
  ⟨1875, 1, 0, false, .click 27 57, bd1, o765, o766⟩,
  ⟨1876, 1, 0, false, .click 6 57, bd1, o766, o767⟩,
  ⟨1877, 1, 0, false, .click 6 57, bd1, o767, o768⟩,
  ⟨1878, 1, 0, false, .click 57 57, bd1, o768, o769⟩,
  ⟨1879, 1, 0, false, .click 12 57, bd1, o769, o770⟩,
  ⟨1880, 1, 0, false, .click 42 57, bd1, o770, o771⟩,
  ⟨1881, 1, 0, false, .click 42 57, bd1, o771, o772⟩,
  ⟨1882, 1, 0, false, .click 42 57, bd1, o772, o773⟩,
  ⟨1883, 1, 0, false, .click 21 57, bd1, o773, o774⟩,
  ⟨1884, 1, 0, false, .click 6 57, bd1, o774, o775⟩,
  ⟨1885, 1, 0, false, .click 57 57, bd1, o775, o776⟩,
  ⟨1886, 1, 0, false, .click 27 57, bd1, o776, o777⟩,
  ⟨1887, 1, 0, false, .click 42 57, bd1, o777, o778⟩,
  ⟨1888, 1, 0, false, .click 21 57, bd1, o778, o779⟩,
  ⟨1889, 1, 0, false, .click 21 57, bd1, o779, o780⟩,
  ⟨1890, 1, 0, false, .click 6 57, bd1, o780, o781⟩,
  ⟨1891, 1, 0, false, .click 42 57, bd1, o781, o782⟩,
  ⟨1892, 1, 0, false, .click 42 57, bd1, o782, o783⟩,
  ⟨1893, 1, 0, false, .click 57 57, bd1, o783, o784⟩,
  ⟨1894, 1, 0, false, .click 57 57, bd1, o784, o785⟩,
  ⟨1895, 1, 0, false, .click 36 57, bd1, o785, o786⟩,
  ⟨1896, 1, 0, false, .click 36 57, bd1, o786, o787⟩,
  ⟨1897, 1, 0, false, .click 36 57, bd1, o787, o788⟩,
  ⟨1898, 1, 0, false, .click 36 57, bd1, o788, o789⟩,
  ⟨1899, 1, 0, false, .click 12 57, bd1, o789, o790⟩,
  ⟨1900, 1, 0, false, .click 27 57, bd1, o790, o791⟩,
  ⟨1901, 1, 0, false, .click 27 57, bd1, o791, o792⟩,
  ⟨1902, 1, 0, false, .click 27 57, bd1, o792, o793⟩,
  ⟨1903, 1, 0, false, .click 27 57, bd1, o793, o794⟩,
  ⟨1904, 1, 0, false, .click 51 57, bd1, o794, o359⟩,
  ⟨1905, 1, 0, false, .click 36 57, bd1, o359, o795⟩,
  ⟨1906, 1, 0, false, .click 12 57, bd1, o795, o796⟩,
  ⟨1907, 1, 0, false, .click 27 57, bd1, o796, o797⟩,
  ⟨1908, 1, 0, false, .click 57 57, bd1, o797, o798⟩,
  ⟨1909, 1, 0, false, .click 6 57, bd1, o798, o799⟩,
  ⟨1910, 1, 0, false, .click 27 57, bd1, o799, o800⟩,
  ⟨1911, 1, 0, false, .click 57 57, bd1, o800, o801⟩,
  ⟨1912, 1, 0, false, .click 27 57, bd1, o801, o802⟩,
  ⟨1913, 1, 0, false, .click 57 57, bd1, o802, o803⟩,
  ⟨1914, 1, 0, false, .click 6 57, bd1, o803, o804⟩,
  ⟨1915, 1, 0, false, .click 27 57, bd1, o804, o805⟩,
  ⟨1916, 1, 0, false, .click 27 57, bd1, o805, o806⟩,
  ⟨1917, 1, 0, false, .click 36 57, bd1, o806, o807⟩,
  ⟨1918, 1, 0, false, .click 27 57, bd1, o807, o808⟩,
  ⟨1919, 1, 0, false, .click 27 57, bd1, o808, o809⟩,
  ⟨1920, 1, 0, false, .click 12 57, bd1, o809, o810⟩]
def rows32 : List Row := [
  ⟨1921, 1, 0, false, .click 12 57, bd1, o810, o811⟩,
  ⟨1922, 1, 0, false, .click 51 57, bd1, o811, o812⟩,
  ⟨1923, 1, 0, false, .click 51 57, bd1, o812, o813⟩,
  ⟨1924, 1, 0, false, .click 51 57, bd1, o813, o814⟩,
  ⟨1925, 1, 0, false, .click 51 57, bd1, o814, o815⟩,
  ⟨1926, 1, 0, false, .click 42 57, bd1, o815, o816⟩,
  ⟨1927, 1, 0, false, .click 42 57, bd1, o816, o744⟩,
  ⟨1928, 1, 0, false, .click 42 57, bd1, o744, o745⟩,
  ⟨1929, 1, 0, false, .click 42 57, bd1, o745, o746⟩,
  ⟨1930, 1, 0, false, .click 42 57, bd1, o746, o747⟩,
  ⟨1931, 1, 0, false, .click 42 57, bd1, o747, o748⟩,
  ⟨1932, 1, 0, false, .click 42 57, bd1, o748, o749⟩,
  ⟨1933, 1, 0, false, .click 12 57, bd1, o749, o817⟩,
  ⟨1934, 1, 0, false, .click 42 57, bd1, o817, o818⟩,
  ⟨1935, 1, 0, false, .click 42 57, bd1, o818, o819⟩,
  ⟨1936, 1, 0, false, .click 57 57, bd1, o819, o820⟩,
  ⟨1937, 1, 0, false, .click 57 57, bd1, o820, o821⟩,
  ⟨1938, 1, 0, false, .click 57 57, bd1, o821, o822⟩,
  ⟨1939, 1, 0, false, .click 57 57, bd1, o822, o823⟩,
  ⟨1940, 1, 0, false, .click 57 57, bd1, o823, o824⟩,
  ⟨1941, 1, 0, false, .click 57 57, bd1, o824, o825⟩,
  ⟨1942, 1, 0, false, .click 57 57, bd1, o825, o826⟩,
  ⟨1943, 1, 0, false, .click 57 57, bd1, o826, o762⟩,
  ⟨1944, 1, 0, false, .click 51 57, bd1, o762, o826⟩,
  ⟨1945, 1, 0, false, .click 51 57, bd1, o826, o825⟩,
  ⟨1946, 1, 0, false, .click 51 57, bd1, o825, o824⟩,
  ⟨1947, 1, 0, false, .click 51 57, bd1, o824, o823⟩,
  ⟨1948, 1, 0, false, .click 51 57, bd1, o823, o822⟩,
  ⟨1949, 1, 0, false, .click 51 57, bd1, o822, o821⟩,
  ⟨1950, 1, 0, false, .click 51 57, bd1, o821, o820⟩,
  ⟨1951, 1, 0, false, .click 51 57, bd1, o820, o819⟩,
  ⟨1952, 1, 0, false, .click 51 57, bd1, o819, o827⟩,
  ⟨1953, 1, 0, false, .click 51 57, bd1, o827, o828⟩,
  ⟨1954, 1, 0, false, .click 36 57, bd1, o828, o829⟩,
  ⟨1955, 1, 0, false, .click 36 57, bd1, o829, o404⟩,
  ⟨1956, 1, 0, false, .click 36 57, bd1, o404, o403⟩,
  ⟨1957, 1, 0, false, .click 36 57, bd1, o403, o402⟩,
  ⟨1958, 1, 0, false, .click 36 57, bd1, o402, o401⟩,
  ⟨1959, 1, 0, false, .click 36 57, bd1, o401, o400⟩,
  ⟨1960, 1, 0, false, .click 36 57, bd1, o400, o830⟩,
  ⟨1961, 1, 0, false, .click 36 57, bd1, o830, o831⟩,
  ⟨1962, 1, 0, false, .click 36 57, bd1, o831, o832⟩,
  ⟨1963, 1, 0, false, .click 36 57, bd1, o832, o833⟩,
  ⟨1964, 1, 0, false, .click 21 57, bd1, o833, o834⟩,
  ⟨1965, 1, 0, false, .click 21 57, bd1, o834, o835⟩,
  ⟨1966, 1, 0, false, .click 21 57, bd1, o835, o836⟩,
  ⟨1967, 1, 0, false, .click 21 57, bd1, o836, o837⟩,
  ⟨1968, 1, 0, false, .click 21 57, bd1, o837, o838⟩,
  ⟨1969, 1, 0, false, .click 21 57, bd1, o838, o839⟩,
  ⟨1970, 1, 0, false, .click 21 57, bd1, o839, o840⟩,
  ⟨1971, 1, 0, false, .click 21 57, bd1, o840, o841⟩,
  ⟨1972, 1, 0, false, .click 21 57, bd1, o841, o426⟩,
  ⟨1973, 1, 0, false, .click 21 57, bd1, o426, o842⟩,
  ⟨1974, 1, 0, false, .click 12 57, bd1, o842, o843⟩,
  ⟨1975, 1, 0, false, .click 12 57, bd1, o843, o844⟩,
  ⟨1976, 1, 0, false, .click 12 57, bd1, o844, o845⟩,
  ⟨1977, 1, 0, false, .click 12 57, bd1, o845, o24⟩,
  ⟨1978, 1, 0, false, .click 27 57, bd1, o24, o25⟩,
  ⟨1979, 1, 0, false, .click 27 57, bd1, o25, o26⟩,
  ⟨1980, 1, 0, false, .click 27 57, bd1, o26, o27⟩]
def rows33 : List Row := [
  ⟨1981, 1, 0, false, .click 27 57, bd1, o27, o28⟩,
  ⟨1982, 1, 0, false, .click 27 57, bd1, o28, o29⟩,
  ⟨1983, 1, 0, false, .click 27 57, bd1, o29, o30⟩,
  ⟨1984, 1, 0, false, .click 12 57, bd1, o30, o31⟩,
  ⟨1985, 1, 0, false, .click 42 57, bd1, o31, o32⟩,
  ⟨1986, 1, 0, false, .click 42 57, bd1, o32, o846⟩,
  ⟨1987, 1, 0, false, .click 57 57, bd1, o846, o847⟩,
  ⟨1988, 1, 0, false, .click 57 57, bd1, o847, o848⟩,
  ⟨1989, 1, 0, false, .click 57 57, bd1, o848, o849⟩,
  ⟨1990, 1, 0, false, .click 57 57, bd1, o849, o850⟩,
  ⟨1991, 1, 0, false, .click 57 57, bd1, o850, o38⟩,
  ⟨1992, 1, 0, false, .click 57 57, bd1, o38, o431⟩,
  ⟨1993, 1, 1, false, .click 42 57, bd1, o431, o40⟩,
  ⟨1994, 2, 0, false, .click 35 57, bd2, o40, o54⟩,
  ⟨1995, 2, 0, false, .click 54 57, bd2, o54, o432⟩,
  ⟨1996, 2, 0, false, .click 48 48, bd2, o432, o433⟩,
  ⟨1997, 2, 0, false, .click 16 48, bd2, o433, o434⟩,
  ⟨1998, 2, 0, false, .click 48 48, bd2, o434, o435⟩,
  ⟨1999, 2, 0, false, .click 16 48, bd2, o435, o436⟩,
  ⟨2000, 2, 0, false, .click 16 57, bd2, o436, o437⟩,
  ⟨2001, 2, 0, false, .click 16 57, bd2, o437, o438⟩,
  ⟨2002, 2, 0, false, .click 16 57, bd2, o438, o439⟩,
  ⟨2003, 2, 0, false, .click 16 57, bd2, o439, o440⟩,
  ⟨2004, 2, 0, false, .click 16 57, bd2, o440, o441⟩,
  ⟨2005, 2, 0, false, .click 16 57, bd2, o441, o442⟩,
  ⟨2006, 2, 0, false, .click 54 57, bd2, o442, o443⟩,
  ⟨2007, 2, 0, false, .click 54 57, bd2, o443, o444⟩,
  ⟨2008, 2, 0, false, .click 54 57, bd2, o444, o445⟩,
  ⟨2009, 2, 0, false, .click 48 48, bd2, o445, o446⟩,
  ⟨2010, 2, 0, false, .click 10 48, bd2, o446, o447⟩,
  ⟨2011, 2, 0, false, .click 10 48, bd2, o447, o448⟩,
  ⟨2012, 2, 0, false, .click 10 48, bd2, o448, o449⟩,
  ⟨2013, 2, 0, false, .click 10 48, bd2, o449, o450⟩,
  ⟨2014, 2, 0, false, .click 48 48, bd2, o450, o451⟩,
  ⟨2015, 2, 0, false, .click 48 48, bd2, o451, o452⟩,
  ⟨2016, 2, 0, false, .click 35 57, bd2, o452, o453⟩,
  ⟨2017, 2, 0, false, .click 35 57, bd2, o453, o454⟩,
  ⟨2018, 2, 0, false, .click 35 57, bd2, o454, o455⟩,
  ⟨2019, 2, 0, false, .click 35 57, bd2, o455, o456⟩,
  ⟨2020, 2, 0, false, .click 35 57, bd2, o456, o457⟩,
  ⟨2021, 2, 0, false, .click 35 57, bd2, o457, o458⟩,
  ⟨2022, 2, 0, false, .click 35 57, bd2, o458, o459⟩,
  ⟨2023, 2, 0, false, .click 10 48, bd2, o459, o460⟩,
  ⟨2024, 2, 0, false, .click 10 48, bd2, o460, o461⟩,
  ⟨2025, 2, 0, false, .click 10 48, bd2, o461, o462⟩,
  ⟨2026, 2, 0, false, .click 35 48, bd2, o462, o463⟩,
  ⟨2027, 2, 0, false, .click 35 48, bd2, o463, o464⟩,
  ⟨2028, 2, 0, false, .click 35 48, bd2, o464, o465⟩,
  ⟨2029, 2, 0, false, .click 35 48, bd2, o465, o466⟩,
  ⟨2030, 2, 0, false, .click 35 48, bd2, o466, o467⟩,
  ⟨2031, 2, 0, false, .click 35 48, bd2, o467, o468⟩,
  ⟨2032, 2, 0, false, .click 35 48, bd2, o468, o469⟩,
  ⟨2033, 2, 0, false, .click 35 48, bd2, o469, o470⟩,
  ⟨2034, 2, 0, false, .click 35 48, bd2, o470, o471⟩,
  ⟨2035, 2, 0, false, .click 35 48, bd2, o471, o472⟩,
  ⟨2036, 2, 0, false, .click 35 48, bd2, o472, o473⟩,
  ⟨2037, 2, 1, false, .click 35 48, bd2, o473, o113⟩,
  ⟨2038, 3, 0, false, .click 57 57, bd3, o113, o474⟩,
  ⟨2039, 3, 0, false, .click 12 57, bd3, o474, o475⟩,
  ⟨2040, 3, 0, false, .click 12 57, bd3, o475, o476⟩]
def rows34 : List Row := [
  ⟨2041, 3, 0, false, .click 34 54, bd3, o476, o477⟩,
  ⟨2042, 3, 0, false, .click 34 54, bd3, o477, o478⟩,
  ⟨2043, 3, 0, false, .click 34 54, bd3, o478, o479⟩,
  ⟨2044, 3, 0, false, .click 34 54, bd3, o479, o480⟩,
  ⟨2045, 3, 0, false, .click 12 48, bd3, o480, o481⟩,
  ⟨2046, 3, 0, false, .click 12 48, bd3, o481, o482⟩,
  ⟨2047, 3, 0, false, .click 12 48, bd3, o482, o483⟩,
  ⟨2048, 3, 0, false, .click 12 48, bd3, o483, o484⟩,
  ⟨2049, 3, 0, false, .click 34 54, bd3, o484, o485⟩,
  ⟨2050, 3, 0, false, .click 34 54, bd3, o485, o486⟩,
  ⟨2051, 3, 0, false, .click 57 48, bd3, o486, o487⟩,
  ⟨2052, 3, 0, false, .click 57 57, bd3, o487, o851⟩,
  ⟨2053, 3, 0, false, .click 57 48, bd3, o851, o852⟩,
  ⟨2054, 3, 0, false, .click 6 57, bd3, o852, o853⟩,
  ⟨2055, 3, 0, false, .click 28 54, bd3, o853, o854⟩,
  ⟨2056, 3, 0, false, .click 28 54, bd3, o854, o855⟩,
  ⟨2057, 3, 0, false, .click 28 54, bd3, o855, o856⟩,
  ⟨2058, 3, 0, false, .click 28 54, bd3, o856, o857⟩,
  ⟨2059, 3, 0, false, .click 28 54, bd3, o857, o858⟩,
  ⟨2060, 3, 0, false, .click 6 57, bd3, o858, o859⟩,
  ⟨2061, 3, 0, false, .click 6 57, bd3, o859, o860⟩,
  ⟨2062, 3, 0, false, .click 6 57, bd3, o860, o861⟩,
  ⟨2063, 3, 0, false, .click 6 57, bd3, o861, o862⟩,
  ⟨2064, 3, 0, false, .click 6 57, bd3, o862, o863⟩,
  ⟨2065, 3, 0, false, .click 6 57, bd3, o863, o546⟩,
  ⟨2066, 3, 0, false, .click 6 57, bd3, o546, o864⟩,
  ⟨2067, 3, 0, false, .click 6 57, bd3, o864, o865⟩,
  ⟨2068, 3, 0, false, .click 6 57, bd3, o865, o866⟩,
  ⟨2069, 3, 0, false, .click 34 54, bd3, o866, o867⟩,
  ⟨2070, 3, 0, false, .click 34 54, bd3, o867, o868⟩,
  ⟨2071, 3, 0, false, .click 34 54, bd3, o868, o869⟩,
  ⟨2072, 3, 0, false, .click 34 54, bd3, o869, o870⟩,
  ⟨2073, 3, 0, false, .click 34 54, bd3, o870, o871⟩,
  ⟨2074, 3, 0, false, .click 34 54, bd3, o871, o872⟩,
  ⟨2075, 3, 0, false, .click 34 54, bd3, o872, o873⟩,
  ⟨2076, 3, 0, false, .click 34 54, bd3, o873, o874⟩,
  ⟨2077, 3, 0, false, .click 57 57, bd3, o874, o558⟩,
  ⟨2078, 3, 0, false, .click 34 54, bd3, o558, o559⟩,
  ⟨2079, 3, 0, false, .click 12 48, bd3, o559, o560⟩,
  ⟨2080, 3, 0, false, .click 57 48, bd3, o560, o561⟩,
  ⟨2081, 3, 0, false, .click 57 57, bd3, o561, o562⟩,
  ⟨2082, 3, 1, false, .click 34 54, bd3, o562, o165⟩,
  ⟨2083, 4, 0, false, .click 6 57, bd4, o165, o563⟩,
  ⟨2084, 4, 0, false, .click 42 57, bd4, o563, o564⟩,
  ⟨2085, 4, 0, false, .click 51 57, bd4, o564, o565⟩,
  ⟨2086, 4, 0, false, .click 27 57, bd4, o565, o566⟩,
  ⟨2087, 4, 0, false, .click 27 57, bd4, o566, o567⟩,
  ⟨2088, 4, 0, false, .click 27 57, bd4, o567, o568⟩,
  ⟨2089, 4, 0, false, .click 12 57, bd4, o568, o569⟩,
  ⟨2090, 4, 0, false, .click 12 57, bd4, o569, o570⟩,
  ⟨2091, 4, 0, false, .click 51 57, bd4, o570, o571⟩,
  ⟨2092, 4, 0, false, .click 51 57, bd4, o571, o572⟩,
  ⟨2093, 4, 0, false, .click 51 57, bd4, o572, o573⟩,
  ⟨2094, 4, 0, false, .click 42 57, bd4, o573, o574⟩,
  ⟨2095, 4, 0, false, .click 42 57, bd4, o574, o575⟩,
  ⟨2096, 4, 0, false, .click 42 57, bd4, o575, o576⟩,
  ⟨2097, 4, 0, false, .click 6 57, bd4, o576, o577⟩,
  ⟨2098, 4, 0, false, .click 6 57, bd4, o577, o875⟩,
  ⟨2099, 4, 0, false, .click 6 57, bd4, o875, o876⟩,
  ⟨2100, 4, 0, false, .click 6 57, bd4, o876, o877⟩]
def rows35 : List Row := [
  ⟨2101, 4, 0, false, .click 6 57, bd4, o877, o878⟩,
  ⟨2102, 4, 0, false, .click 6 57, bd4, o878, o879⟩,
  ⟨2103, 4, 0, false, .click 36 57, bd4, o879, o880⟩,
  ⟨2104, 4, 0, false, .click 36 57, bd4, o880, o881⟩,
  ⟨2105, 4, 0, false, .click 36 57, bd4, o881, o882⟩,
  ⟨2106, 4, 0, false, .click 27 57, bd4, o882, o883⟩,
  ⟨2107, 4, 0, false, .click 27 57, bd4, o883, o884⟩,
  ⟨2108, 4, 0, false, .click 27 57, bd4, o884, o885⟩,
  ⟨2109, 4, 0, false, .click 27 57, bd4, o885, o886⟩,
  ⟨2110, 4, 0, false, .click 27 57, bd4, o886, o887⟩,
  ⟨2111, 4, 0, false, .click 27 57, bd4, o887, o888⟩,
  ⟨2112, 4, 0, false, .click 42 57, bd4, o888, o889⟩,
  ⟨2113, 4, 0, false, .click 42 57, bd4, o889, o890⟩,
  ⟨2114, 4, 0, false, .click 57 57, bd4, o890, o205⟩,
  ⟨2115, 4, 0, false, .click 57 57, bd4, o205, o891⟩,
  ⟨2116, 4, 0, false, .click 57 57, bd4, o891, o892⟩,
  ⟨2117, 4, 0, false, .click 57 57, bd4, o892, o893⟩,
  ⟨2118, 4, 1, false, .click 42 57, bd4, o893, o209⟩,
  ⟨2119, 5, 0, false, .click 47 57, bd5, o209, o625⟩,
  ⟨2120, 5, 0, false, .click 50 48, bd5, o625, o894⟩,
  ⟨2121, 5, 0, false, .click 31 48, bd5, o894, o895⟩,
  ⟨2122, 5, 0, false, .click 31 48, bd5, o895, o896⟩,
  ⟨2123, 5, 0, false, .click 50 48, bd5, o896, o897⟩,
  ⟨2124, 5, 0, false, .click 34 57, bd5, o897, o898⟩,
  ⟨2125, 5, 0, false, .click 53 57, bd5, o898, o899⟩,
  ⟨2126, 5, 0, false, .click 12 48, bd5, o899, o900⟩,
  ⟨2127, 5, 0, false, .click 12 48, bd5, o900, o901⟩,
  ⟨2128, 5, 0, false, .click 53 57, bd5, o901, o902⟩,
  ⟨2129, 5, 0, false, .click 50 48, bd5, o902, o903⟩,
  ⟨2130, 5, 0, false, .click 28 57, bd5, o903, o904⟩,
  ⟨2131, 5, 0, false, .click 53 57, bd5, o904, o905⟩,
  ⟨2132, 5, 0, false, .click 53 57, bd5, o905, o906⟩,
  ⟨2133, 5, 0, false, .click 28 57, bd5, o906, o907⟩,
  ⟨2134, 5, 0, false, .click 50 48, bd5, o907, o908⟩,
  ⟨2135, 5, 0, false, .click 50 48, bd5, o908, o909⟩,
  ⟨2136, 5, 0, false, .click 31 48, bd5, o909, o910⟩,
  ⟨2137, 5, 0, false, .click 34 57, bd5, o910, o911⟩,
  ⟨2138, 5, 0, false, .click 34 57, bd5, o911, o912⟩,
  ⟨2139, 5, 0, false, .click 53 57, bd5, o912, o913⟩,
  ⟨2140, 5, 0, false, .click 53 57, bd5, o913, o914⟩,
  ⟨2141, 5, 0, false, .click 15 57, bd5, o914, o915⟩,
  ⟨2142, 5, 0, false, .click 15 57, bd5, o915, o916⟩,
  ⟨2143, 5, 0, false, .click 34 57, bd5, o916, o698⟩,
  ⟨2144, 5, 0, false, .click 53 57, bd5, o698, o699⟩,
  ⟨2145, 5, 0, false, .click 31 48, bd5, o699, o700⟩,
  ⟨2146, 5, 0, false, .click 31 48, bd5, o700, o701⟩,
  ⟨2147, 5, 0, false, .click 15 57, bd5, o701, o702⟩,
  ⟨2148, 5, 0, false, .click 15 57, bd5, o702, o703⟩,
  ⟨2149, 5, 0, false, .click 15 57, bd5, o703, o704⟩,
  ⟨2150, 5, 0, false, .click 15 57, bd5, o704, o705⟩,
  ⟨2151, 5, 0, false, .click 15 57, bd5, o705, o706⟩,
  ⟨2152, 5, 0, false, .click 15 57, bd5, o706, o707⟩,
  ⟨2153, 5, 0, false, .click 15 57, bd5, o707, o708⟩,
  ⟨2154, 5, 0, false, .click 15 57, bd5, o708, o709⟩,
  ⟨2155, 5, 0, false, .click 15 57, bd5, o709, o710⟩,
  ⟨2156, 5, 1, false, .click 34 57, bd5, o710, o245⟩,
  ⟨2157, 6, 2, true, .reset, bd6, o245, o0⟩,
  ⟨2158, 0, 0, true, .click 45 21, bd0, o0, o1⟩,
  ⟨2159, 0, 0, true, .click 45 21, bd0, o1, o334⟩,
  ⟨2160, 0, 0, true, .click 45 21, bd0, o334, o335⟩]
def rows36 : List Row := [
  ⟨2161, 0, 0, true, .click 45 21, bd0, o335, o336⟩,
  ⟨2162, 0, 0, true, .click 45 21, bd0, o336, o337⟩,
  ⟨2163, 0, 0, true, .click 45 21, bd0, o337, o338⟩,
  ⟨2164, 0, 0, true, .click 45 21, bd0, o338, o339⟩,
  ⟨2165, 0, 0, true, .click 24 44, bd0, o339, o340⟩,
  ⟨2166, 0, 0, true, .click 24 44, bd0, o340, o341⟩,
  ⟨2167, 0, 0, true, .click 24 44, bd0, o341, o342⟩,
  ⟨2168, 0, 0, true, .click 24 44, bd0, o342, o343⟩,
  ⟨2169, 0, 0, true, .click 24 44, bd0, o343, o13⟩,
  ⟨2170, 0, 1, true, .click 24 44, bd0, o13, o14⟩,
  ⟨2171, 1, 0, true, .click 12 57, bd1, o14, o15⟩,
  ⟨2172, 1, 0, true, .click 12 57, bd1, o15, o16⟩,
  ⟨2173, 1, 0, true, .click 12 57, bd1, o16, o17⟩,
  ⟨2174, 1, 0, true, .click 12 57, bd1, o17, o18⟩,
  ⟨2175, 1, 0, true, .click 27 57, bd1, o18, o763⟩,
  ⟨2176, 1, 0, true, .click 42 57, bd1, o763, o764⟩,
  ⟨2177, 1, 0, true, .click 27 57, bd1, o764, o765⟩,
  ⟨2178, 1, 0, true, .click 27 57, bd1, o765, o766⟩,
  ⟨2179, 1, 0, true, .click 6 57, bd1, o766, o767⟩,
  ⟨2180, 1, 0, true, .click 6 57, bd1, o767, o768⟩,
  ⟨2181, 1, 0, true, .click 57 57, bd1, o768, o769⟩,
  ⟨2182, 1, 0, true, .click 12 57, bd1, o769, o770⟩,
  ⟨2183, 1, 0, true, .click 42 57, bd1, o770, o771⟩,
  ⟨2184, 1, 0, true, .click 42 57, bd1, o771, o772⟩,
  ⟨2185, 1, 0, true, .click 42 57, bd1, o772, o773⟩,
  ⟨2186, 1, 0, true, .click 21 57, bd1, o773, o774⟩,
  ⟨2187, 1, 0, true, .click 6 57, bd1, o774, o775⟩,
  ⟨2188, 1, 0, true, .click 57 57, bd1, o775, o776⟩,
  ⟨2189, 1, 0, true, .click 27 57, bd1, o776, o777⟩,
  ⟨2190, 1, 0, true, .click 42 57, bd1, o777, o778⟩,
  ⟨2191, 1, 0, true, .click 21 57, bd1, o778, o779⟩,
  ⟨2192, 1, 0, true, .click 21 57, bd1, o779, o780⟩,
  ⟨2193, 1, 0, true, .click 6 57, bd1, o780, o781⟩,
  ⟨2194, 1, 0, true, .click 42 57, bd1, o781, o782⟩,
  ⟨2195, 1, 0, true, .click 42 57, bd1, o782, o783⟩,
  ⟨2196, 1, 0, true, .click 57 57, bd1, o783, o784⟩,
  ⟨2197, 1, 0, true, .click 57 57, bd1, o784, o785⟩,
  ⟨2198, 1, 0, true, .click 36 57, bd1, o785, o786⟩,
  ⟨2199, 1, 0, true, .click 36 57, bd1, o786, o787⟩,
  ⟨2200, 1, 0, true, .click 36 57, bd1, o787, o788⟩,
  ⟨2201, 1, 0, true, .click 36 57, bd1, o788, o789⟩,
  ⟨2202, 1, 0, true, .click 12 57, bd1, o789, o790⟩,
  ⟨2203, 1, 0, true, .click 27 57, bd1, o790, o791⟩,
  ⟨2204, 1, 0, true, .click 27 57, bd1, o791, o792⟩,
  ⟨2205, 1, 0, true, .click 27 57, bd1, o792, o793⟩,
  ⟨2206, 1, 0, true, .click 27 57, bd1, o793, o794⟩,
  ⟨2207, 1, 0, true, .click 51 57, bd1, o794, o359⟩,
  ⟨2208, 1, 0, true, .click 36 57, bd1, o359, o795⟩,
  ⟨2209, 1, 0, true, .click 12 57, bd1, o795, o796⟩,
  ⟨2210, 1, 0, true, .click 27 57, bd1, o796, o797⟩,
  ⟨2211, 1, 0, true, .click 57 57, bd1, o797, o798⟩,
  ⟨2212, 1, 0, true, .click 6 57, bd1, o798, o799⟩,
  ⟨2213, 1, 0, true, .click 27 57, bd1, o799, o800⟩,
  ⟨2214, 1, 0, true, .click 57 57, bd1, o800, o801⟩,
  ⟨2215, 1, 0, true, .click 27 57, bd1, o801, o802⟩,
  ⟨2216, 1, 0, true, .click 57 57, bd1, o802, o803⟩,
  ⟨2217, 1, 0, true, .click 6 57, bd1, o803, o804⟩,
  ⟨2218, 1, 0, true, .click 27 57, bd1, o804, o805⟩,
  ⟨2219, 1, 0, true, .click 27 57, bd1, o805, o806⟩,
  ⟨2220, 1, 0, true, .click 36 57, bd1, o806, o807⟩]
def rows37 : List Row := [
  ⟨2221, 1, 0, true, .click 27 57, bd1, o807, o808⟩,
  ⟨2222, 1, 0, true, .click 27 57, bd1, o808, o809⟩,
  ⟨2223, 1, 0, true, .click 12 57, bd1, o809, o810⟩,
  ⟨2224, 1, 0, true, .click 12 57, bd1, o810, o811⟩,
  ⟨2225, 1, 0, true, .click 51 57, bd1, o811, o812⟩,
  ⟨2226, 1, 0, true, .click 51 57, bd1, o812, o813⟩,
  ⟨2227, 1, 0, true, .click 51 57, bd1, o813, o814⟩,
  ⟨2228, 1, 0, true, .click 51 57, bd1, o814, o815⟩,
  ⟨2229, 1, 0, true, .click 42 57, bd1, o815, o816⟩,
  ⟨2230, 1, 0, true, .click 42 57, bd1, o816, o744⟩,
  ⟨2231, 1, 0, true, .click 42 57, bd1, o744, o745⟩,
  ⟨2232, 1, 0, true, .click 42 57, bd1, o745, o746⟩,
  ⟨2233, 1, 0, true, .click 42 57, bd1, o746, o747⟩,
  ⟨2234, 1, 0, true, .click 42 57, bd1, o747, o748⟩,
  ⟨2235, 1, 0, true, .click 42 57, bd1, o748, o749⟩,
  ⟨2236, 1, 0, true, .click 12 57, bd1, o749, o817⟩,
  ⟨2237, 1, 0, true, .click 42 57, bd1, o817, o818⟩,
  ⟨2238, 1, 0, true, .click 42 57, bd1, o818, o819⟩,
  ⟨2239, 1, 0, true, .click 57 57, bd1, o819, o820⟩,
  ⟨2240, 1, 0, true, .click 57 57, bd1, o820, o821⟩,
  ⟨2241, 1, 0, true, .click 57 57, bd1, o821, o822⟩,
  ⟨2242, 1, 0, true, .click 57 57, bd1, o822, o823⟩,
  ⟨2243, 1, 0, true, .click 57 57, bd1, o823, o824⟩,
  ⟨2244, 1, 0, true, .click 57 57, bd1, o824, o825⟩,
  ⟨2245, 1, 0, true, .click 57 57, bd1, o825, o826⟩,
  ⟨2246, 1, 0, true, .click 57 57, bd1, o826, o762⟩,
  ⟨2247, 1, 0, true, .click 51 57, bd1, o762, o826⟩,
  ⟨2248, 1, 0, true, .click 51 57, bd1, o826, o825⟩,
  ⟨2249, 1, 0, true, .click 51 57, bd1, o825, o824⟩,
  ⟨2250, 1, 0, true, .click 51 57, bd1, o824, o823⟩,
  ⟨2251, 1, 0, true, .click 51 57, bd1, o823, o822⟩,
  ⟨2252, 1, 0, true, .click 51 57, bd1, o822, o821⟩,
  ⟨2253, 1, 0, true, .click 51 57, bd1, o821, o820⟩,
  ⟨2254, 1, 0, true, .click 57 57, bd1, o820, o821⟩,
  ⟨2255, 1, 0, true, .click 57 57, bd1, o821, o822⟩,
  ⟨2256, 1, 0, true, .click 57 57, bd1, o822, o823⟩,
  ⟨2257, 1, 0, true, .click 57 57, bd1, o823, o824⟩,
  ⟨2258, 1, 0, true, .click 57 57, bd1, o824, o825⟩,
  ⟨2259, 1, 0, true, .click 57 57, bd1, o825, o826⟩,
  ⟨2260, 1, 0, true, .click 57 57, bd1, o826, o762⟩,
  ⟨2261, 1, 0, true, .click 51 57, bd1, o762, o826⟩,
  ⟨2262, 1, 0, true, .click 51 57, bd1, o826, o825⟩,
  ⟨2263, 1, 0, true, .click 51 57, bd1, o825, o824⟩,
  ⟨2264, 1, 0, true, .click 51 57, bd1, o824, o823⟩,
  ⟨2265, 1, 0, true, .click 51 57, bd1, o823, o822⟩,
  ⟨2266, 1, 0, true, .click 51 57, bd1, o822, o821⟩,
  ⟨2267, 1, 0, true, .click 51 57, bd1, o821, o820⟩,
  ⟨2268, 1, 0, true, .click 51 57, bd1, o820, o819⟩,
  ⟨2269, 1, 0, true, .click 51 57, bd1, o819, o827⟩,
  ⟨2270, 1, 0, true, .click 51 57, bd1, o827, o828⟩,
  ⟨2271, 1, 0, true, .click 36 57, bd1, o828, o829⟩,
  ⟨2272, 1, 0, true, .click 36 57, bd1, o829, o404⟩,
  ⟨2273, 1, 0, true, .click 36 57, bd1, o404, o403⟩,
  ⟨2274, 1, 0, true, .click 36 57, bd1, o403, o402⟩,
  ⟨2275, 1, 0, true, .click 36 57, bd1, o402, o401⟩,
  ⟨2276, 1, 0, true, .click 36 57, bd1, o401, o400⟩,
  ⟨2277, 1, 0, true, .click 36 57, bd1, o400, o830⟩,
  ⟨2278, 1, 0, true, .click 36 57, bd1, o830, o831⟩,
  ⟨2279, 1, 0, true, .click 36 57, bd1, o831, o832⟩,
  ⟨2280, 1, 0, true, .click 36 57, bd1, o832, o833⟩]
def rows38 : List Row := [
  ⟨2281, 1, 0, true, .click 21 57, bd1, o833, o834⟩,
  ⟨2282, 1, 0, true, .click 21 57, bd1, o834, o835⟩,
  ⟨2283, 1, 0, true, .click 21 57, bd1, o835, o836⟩,
  ⟨2284, 1, 0, true, .click 21 57, bd1, o836, o837⟩,
  ⟨2285, 1, 0, true, .click 21 57, bd1, o837, o838⟩,
  ⟨2286, 1, 0, true, .click 21 57, bd1, o838, o839⟩,
  ⟨2287, 1, 0, true, .click 21 57, bd1, o839, o840⟩,
  ⟨2288, 1, 0, true, .click 21 57, bd1, o840, o841⟩,
  ⟨2289, 1, 0, true, .click 21 57, bd1, o841, o426⟩,
  ⟨2290, 1, 0, true, .click 21 57, bd1, o426, o842⟩,
  ⟨2291, 1, 0, true, .click 12 57, bd1, o842, o843⟩,
  ⟨2292, 1, 0, true, .click 12 57, bd1, o843, o844⟩,
  ⟨2293, 1, 0, true, .click 12 57, bd1, o844, o845⟩,
  ⟨2294, 1, 0, true, .click 12 57, bd1, o845, o24⟩,
  ⟨2295, 1, 0, true, .click 27 57, bd1, o24, o25⟩,
  ⟨2296, 1, 0, true, .click 27 57, bd1, o25, o26⟩,
  ⟨2297, 1, 0, true, .click 27 57, bd1, o26, o27⟩,
  ⟨2298, 1, 0, true, .click 27 57, bd1, o27, o28⟩,
  ⟨2299, 1, 0, true, .click 27 57, bd1, o28, o29⟩,
  ⟨2300, 1, 0, true, .click 27 57, bd1, o29, o30⟩,
  ⟨2301, 1, 0, true, .click 12 57, bd1, o30, o31⟩,
  ⟨2302, 1, 0, true, .click 42 57, bd1, o31, o32⟩,
  ⟨2303, 1, 0, true, .click 42 57, bd1, o32, o846⟩,
  ⟨2304, 1, 0, true, .click 57 57, bd1, o846, o847⟩,
  ⟨2305, 1, 0, true, .click 57 57, bd1, o847, o848⟩,
  ⟨2306, 1, 0, true, .click 57 57, bd1, o848, o849⟩,
  ⟨2307, 1, 0, true, .click 57 57, bd1, o849, o850⟩,
  ⟨2308, 1, 0, true, .click 57 57, bd1, o850, o38⟩,
  ⟨2309, 1, 0, true, .click 57 57, bd1, o38, o431⟩,
  ⟨2310, 1, 1, true, .click 42 57, bd1, o431, o40⟩,
  ⟨2311, 2, 0, true, .click 35 57, bd2, o40, o54⟩,
  ⟨2312, 2, 0, true, .click 54 57, bd2, o54, o432⟩,
  ⟨2313, 2, 0, true, .click 48 48, bd2, o432, o433⟩,
  ⟨2314, 2, 0, true, .click 16 48, bd2, o433, o434⟩,
  ⟨2315, 2, 0, true, .click 48 48, bd2, o434, o435⟩,
  ⟨2316, 2, 0, true, .click 16 48, bd2, o435, o436⟩,
  ⟨2317, 2, 0, true, .click 16 57, bd2, o436, o437⟩,
  ⟨2318, 2, 0, true, .click 16 57, bd2, o437, o438⟩,
  ⟨2319, 2, 0, true, .click 16 57, bd2, o438, o439⟩,
  ⟨2320, 2, 0, true, .click 16 57, bd2, o439, o440⟩,
  ⟨2321, 2, 0, true, .click 16 57, bd2, o440, o441⟩,
  ⟨2322, 2, 0, true, .click 16 57, bd2, o441, o442⟩,
  ⟨2323, 2, 0, true, .click 54 57, bd2, o442, o443⟩,
  ⟨2324, 2, 0, true, .click 54 57, bd2, o443, o444⟩,
  ⟨2325, 2, 0, true, .click 54 57, bd2, o444, o445⟩,
  ⟨2326, 2, 0, true, .click 48 48, bd2, o445, o446⟩,
  ⟨2327, 2, 0, true, .click 10 48, bd2, o446, o447⟩,
  ⟨2328, 2, 0, true, .click 10 48, bd2, o447, o448⟩,
  ⟨2329, 2, 0, true, .click 10 48, bd2, o448, o449⟩,
  ⟨2330, 2, 0, true, .click 10 48, bd2, o449, o450⟩,
  ⟨2331, 2, 0, true, .click 48 48, bd2, o450, o451⟩,
  ⟨2332, 2, 0, true, .click 48 48, bd2, o451, o452⟩,
  ⟨2333, 2, 0, true, .click 35 57, bd2, o452, o453⟩,
  ⟨2334, 2, 0, true, .click 35 57, bd2, o453, o454⟩,
  ⟨2335, 2, 0, true, .click 35 57, bd2, o454, o455⟩,
  ⟨2336, 2, 0, true, .click 35 57, bd2, o455, o456⟩,
  ⟨2337, 2, 0, true, .click 35 57, bd2, o456, o457⟩,
  ⟨2338, 2, 0, true, .click 35 57, bd2, o457, o458⟩,
  ⟨2339, 2, 0, true, .click 35 57, bd2, o458, o459⟩,
  ⟨2340, 2, 0, true, .click 10 48, bd2, o459, o460⟩]
def rows39 : List Row := [
  ⟨2341, 2, 0, true, .click 10 48, bd2, o460, o461⟩,
  ⟨2342, 2, 0, true, .click 10 48, bd2, o461, o462⟩,
  ⟨2343, 2, 0, true, .click 35 48, bd2, o462, o463⟩,
  ⟨2344, 2, 0, true, .click 35 48, bd2, o463, o464⟩,
  ⟨2345, 2, 0, true, .click 35 48, bd2, o464, o465⟩,
  ⟨2346, 2, 0, true, .click 35 48, bd2, o465, o466⟩,
  ⟨2347, 2, 0, true, .click 35 48, bd2, o466, o467⟩,
  ⟨2348, 2, 0, true, .click 35 48, bd2, o467, o468⟩,
  ⟨2349, 2, 0, true, .click 35 48, bd2, o468, o469⟩,
  ⟨2350, 2, 0, true, .click 35 48, bd2, o469, o470⟩,
  ⟨2351, 2, 0, true, .click 35 48, bd2, o470, o471⟩,
  ⟨2352, 2, 0, true, .click 35 48, bd2, o471, o472⟩,
  ⟨2353, 2, 0, true, .click 35 48, bd2, o472, o473⟩,
  ⟨2354, 2, 1, true, .click 35 48, bd2, o473, o113⟩,
  ⟨2355, 3, 0, true, .click 57 57, bd3, o113, o474⟩,
  ⟨2356, 3, 0, true, .click 12 57, bd3, o474, o475⟩,
  ⟨2357, 3, 0, true, .click 12 57, bd3, o475, o476⟩,
  ⟨2358, 3, 0, true, .click 34 54, bd3, o476, o477⟩,
  ⟨2359, 3, 0, true, .click 34 54, bd3, o477, o478⟩,
  ⟨2360, 3, 0, true, .click 34 54, bd3, o478, o479⟩,
  ⟨2361, 3, 0, true, .click 34 54, bd3, o479, o480⟩,
  ⟨2362, 3, 0, true, .click 12 48, bd3, o480, o481⟩,
  ⟨2363, 3, 0, true, .click 12 48, bd3, o481, o482⟩,
  ⟨2364, 3, 0, true, .click 12 48, bd3, o482, o483⟩,
  ⟨2365, 3, 0, true, .click 12 48, bd3, o483, o484⟩,
  ⟨2366, 3, 0, true, .click 34 54, bd3, o484, o485⟩,
  ⟨2367, 3, 0, true, .click 34 54, bd3, o485, o486⟩,
  ⟨2368, 3, 0, true, .click 57 48, bd3, o486, o487⟩,
  ⟨2369, 3, 0, true, .click 57 57, bd3, o487, o851⟩,
  ⟨2370, 3, 0, true, .click 57 48, bd3, o851, o852⟩,
  ⟨2371, 3, 0, true, .click 6 57, bd3, o852, o853⟩,
  ⟨2372, 3, 0, true, .click 28 54, bd3, o853, o854⟩,
  ⟨2373, 3, 0, true, .click 28 54, bd3, o854, o855⟩,
  ⟨2374, 3, 0, true, .click 28 54, bd3, o855, o856⟩,
  ⟨2375, 3, 0, true, .click 28 54, bd3, o856, o857⟩,
  ⟨2376, 3, 0, true, .click 28 54, bd3, o857, o858⟩,
  ⟨2377, 3, 0, true, .click 6 57, bd3, o858, o859⟩,
  ⟨2378, 3, 0, true, .click 6 57, bd3, o859, o860⟩,
  ⟨2379, 3, 0, true, .click 6 57, bd3, o860, o861⟩,
  ⟨2380, 3, 0, true, .click 6 57, bd3, o861, o862⟩,
  ⟨2381, 3, 0, true, .click 6 57, bd3, o862, o863⟩,
  ⟨2382, 3, 0, true, .click 6 57, bd3, o863, o546⟩,
  ⟨2383, 3, 0, true, .click 6 57, bd3, o546, o864⟩,
  ⟨2384, 3, 0, true, .click 6 57, bd3, o864, o865⟩,
  ⟨2385, 3, 0, true, .click 6 57, bd3, o865, o866⟩,
  ⟨2386, 3, 0, true, .click 34 54, bd3, o866, o867⟩,
  ⟨2387, 3, 0, true, .click 34 54, bd3, o867, o868⟩,
  ⟨2388, 3, 0, true, .click 34 54, bd3, o868, o869⟩,
  ⟨2389, 3, 0, true, .click 34 54, bd3, o869, o870⟩,
  ⟨2390, 3, 0, true, .click 34 54, bd3, o870, o871⟩,
  ⟨2391, 3, 0, true, .click 34 54, bd3, o871, o872⟩,
  ⟨2392, 3, 0, true, .click 34 54, bd3, o872, o873⟩,
  ⟨2393, 3, 0, true, .click 34 54, bd3, o873, o874⟩,
  ⟨2394, 3, 0, true, .click 57 57, bd3, o874, o558⟩,
  ⟨2395, 3, 0, true, .click 34 54, bd3, o558, o559⟩,
  ⟨2396, 3, 0, true, .click 12 48, bd3, o559, o560⟩,
  ⟨2397, 3, 0, true, .click 57 48, bd3, o560, o561⟩,
  ⟨2398, 3, 0, true, .click 57 57, bd3, o561, o562⟩,
  ⟨2399, 3, 1, true, .click 34 54, bd3, o562, o165⟩,
  ⟨2400, 4, 0, true, .click 6 57, bd4, o165, o563⟩]
def rows40 : List Row := [
  ⟨2401, 4, 0, true, .click 42 57, bd4, o563, o564⟩,
  ⟨2402, 4, 0, true, .click 51 57, bd4, o564, o565⟩,
  ⟨2403, 4, 0, true, .click 27 57, bd4, o565, o566⟩,
  ⟨2404, 4, 0, true, .click 27 57, bd4, o566, o567⟩,
  ⟨2405, 4, 0, true, .click 27 57, bd4, o567, o568⟩,
  ⟨2406, 4, 0, true, .click 12 57, bd4, o568, o569⟩,
  ⟨2407, 4, 0, true, .click 12 57, bd4, o569, o570⟩,
  ⟨2408, 4, 0, true, .click 51 57, bd4, o570, o571⟩,
  ⟨2409, 4, 0, true, .click 51 57, bd4, o571, o572⟩,
  ⟨2410, 4, 0, true, .click 51 57, bd4, o572, o573⟩,
  ⟨2411, 4, 0, true, .click 42 57, bd4, o573, o574⟩,
  ⟨2412, 4, 0, true, .click 42 57, bd4, o574, o575⟩,
  ⟨2413, 4, 0, true, .click 42 57, bd4, o575, o576⟩,
  ⟨2414, 4, 0, true, .click 6 57, bd4, o576, o577⟩,
  ⟨2415, 4, 0, true, .click 6 57, bd4, o577, o875⟩,
  ⟨2416, 4, 0, true, .click 6 57, bd4, o875, o876⟩,
  ⟨2417, 4, 0, true, .click 6 57, bd4, o876, o877⟩,
  ⟨2418, 4, 0, true, .click 6 57, bd4, o877, o878⟩,
  ⟨2419, 4, 0, true, .click 6 57, bd4, o878, o879⟩,
  ⟨2420, 4, 0, true, .click 36 57, bd4, o879, o880⟩,
  ⟨2421, 4, 0, true, .click 36 57, bd4, o880, o881⟩,
  ⟨2422, 4, 0, true, .click 36 57, bd4, o881, o882⟩,
  ⟨2423, 4, 0, true, .click 27 57, bd4, o882, o883⟩,
  ⟨2424, 4, 0, true, .click 27 57, bd4, o883, o884⟩,
  ⟨2425, 4, 0, true, .click 27 57, bd4, o884, o885⟩,
  ⟨2426, 4, 0, true, .click 27 57, bd4, o885, o886⟩,
  ⟨2427, 4, 0, true, .click 27 57, bd4, o886, o887⟩,
  ⟨2428, 4, 0, true, .click 27 57, bd4, o887, o888⟩,
  ⟨2429, 4, 0, true, .click 42 57, bd4, o888, o889⟩,
  ⟨2430, 4, 0, true, .click 42 57, bd4, o889, o890⟩,
  ⟨2431, 4, 0, true, .click 57 57, bd4, o890, o205⟩,
  ⟨2432, 4, 0, true, .click 57 57, bd4, o205, o891⟩,
  ⟨2433, 4, 0, true, .click 57 57, bd4, o891, o892⟩,
  ⟨2434, 4, 0, true, .click 57 57, bd4, o892, o893⟩,
  ⟨2435, 4, 1, true, .click 42 57, bd4, o893, o209⟩,
  ⟨2436, 5, 0, true, .click 47 57, bd5, o209, o625⟩,
  ⟨2437, 5, 0, true, .click 50 48, bd5, o625, o894⟩,
  ⟨2438, 5, 0, true, .click 31 48, bd5, o894, o895⟩,
  ⟨2439, 5, 0, true, .click 31 48, bd5, o895, o896⟩,
  ⟨2440, 5, 0, true, .click 50 48, bd5, o896, o897⟩,
  ⟨2441, 5, 0, true, .click 34 57, bd5, o897, o898⟩,
  ⟨2442, 5, 0, true, .click 53 57, bd5, o898, o899⟩,
  ⟨2443, 5, 0, true, .click 12 48, bd5, o899, o900⟩,
  ⟨2444, 5, 0, true, .click 12 48, bd5, o900, o901⟩,
  ⟨2445, 5, 0, true, .click 53 57, bd5, o901, o902⟩,
  ⟨2446, 5, 0, true, .click 50 48, bd5, o902, o903⟩,
  ⟨2447, 5, 0, true, .click 28 57, bd5, o903, o904⟩,
  ⟨2448, 5, 0, true, .click 53 57, bd5, o904, o905⟩,
  ⟨2449, 5, 0, true, .click 53 57, bd5, o905, o906⟩,
  ⟨2450, 5, 0, true, .click 28 57, bd5, o906, o907⟩,
  ⟨2451, 5, 0, true, .click 50 48, bd5, o907, o908⟩,
  ⟨2452, 5, 0, true, .click 50 48, bd5, o908, o909⟩,
  ⟨2453, 5, 0, true, .click 31 48, bd5, o909, o910⟩,
  ⟨2454, 5, 0, true, .click 34 57, bd5, o910, o911⟩,
  ⟨2455, 5, 0, true, .click 34 57, bd5, o911, o912⟩,
  ⟨2456, 5, 0, true, .click 53 57, bd5, o912, o913⟩,
  ⟨2457, 5, 0, true, .click 53 57, bd5, o913, o914⟩,
  ⟨2458, 5, 0, true, .click 15 57, bd5, o914, o915⟩,
  ⟨2459, 5, 0, true, .click 15 57, bd5, o915, o916⟩,
  ⟨2460, 5, 0, true, .click 34 57, bd5, o916, o698⟩]
def rows41 : List Row := [
  ⟨2461, 5, 0, true, .click 53 57, bd5, o698, o699⟩,
  ⟨2462, 5, 0, true, .click 31 48, bd5, o699, o700⟩,
  ⟨2463, 5, 0, true, .click 31 48, bd5, o700, o701⟩,
  ⟨2464, 5, 0, true, .click 15 57, bd5, o701, o702⟩,
  ⟨2465, 5, 0, true, .click 15 57, bd5, o702, o703⟩,
  ⟨2466, 5, 0, true, .click 15 57, bd5, o703, o704⟩,
  ⟨2467, 5, 0, true, .click 15 57, bd5, o704, o705⟩,
  ⟨2468, 5, 0, true, .click 15 57, bd5, o705, o706⟩,
  ⟨2469, 5, 0, true, .click 15 57, bd5, o706, o707⟩,
  ⟨2470, 5, 0, true, .click 15 57, bd5, o707, o708⟩,
  ⟨2471, 5, 0, true, .click 15 57, bd5, o708, o709⟩,
  ⟨2472, 5, 0, true, .click 15 57, bd5, o709, o710⟩,
  ⟨2473, 5, 1, true, .click 34 57, bd5, o710, o245⟩,
  ⟨2474, 6, 0, true, .click 17 51, bd6, o245, o711⟩,
  ⟨2475, 6, 0, true, .click 17 51, bd6, o711, o712⟩,
  ⟨2476, 6, 0, true, .click 10 51, bd6, o712, o713⟩,
  ⟨2477, 6, 0, true, .click 10 51, bd6, o713, o917⟩,
  ⟨2478, 6, 0, true, .click 10 51, bd6, o917, o918⟩,
  ⟨2479, 6, 0, true, .click 17 58, bd6, o918, o919⟩,
  ⟨2480, 6, 0, true, .click 32 51, bd6, o919, o920⟩,
  ⟨2481, 6, 0, true, .click 32 51, bd6, o920, o921⟩,
  ⟨2482, 6, 0, true, .click 32 51, bd6, o921, o922⟩,
  ⟨2483, 6, 0, true, .click 32 51, bd6, o922, o923⟩,
  ⟨2484, 6, 0, true, .click 32 58, bd6, o923, o924⟩,
  ⟨2485, 6, 0, true, .click 32 58, bd6, o924, o925⟩,
  ⟨2486, 6, 0, true, .click 32 58, bd6, o925, o926⟩,
  ⟨2487, 6, 0, true, .click 32 58, bd6, o926, o927⟩,
  ⟨2488, 6, 0, true, .click 32 58, bd6, o927, o928⟩,
  ⟨2489, 6, 0, true, .click 4 51, bd6, o928, o928⟩,
  ⟨2490, 6, 0, true, .click 17 58, bd6, o928, o929⟩,
  ⟨2491, 6, 0, true, .click 17 58, bd6, o929, o930⟩,
  ⟨2492, 6, 0, true, .click 17 58, bd6, o930, o928⟩,
  ⟨2493, 6, 0, true, .click 10 58, bd6, o928, o931⟩,
  ⟨2494, 6, 0, true, .click 32 58, bd6, o931, o932⟩,
  ⟨2495, 6, 0, true, .click 17 58, bd6, o932, o933⟩,
  ⟨2496, 6, 0, true, .click 4 58, bd6, o933, o934⟩,
  ⟨2497, 6, 0, true, .click 17 58, bd6, o934, o935⟩,
  ⟨2498, 6, 0, true, .click 17 58, bd6, o935, o936⟩,
  ⟨2499, 6, 0, true, .click 10 58, bd6, o936, o932⟩,
  ⟨2500, 6, 0, true, .click 10 58, bd6, o932, o937⟩,
  ⟨2501, 6, 0, true, .click 32 58, bd6, o937, o938⟩,
  ⟨2502, 6, 0, true, .click 17 51, bd6, o938, o938⟩,
  ⟨2503, 6, 0, true, .click 39 51, bd6, o938, o938⟩,
  ⟨2504, 6, 0, true, .click 60 58, bd6, o938, o938⟩,
  ⟨2505, 6, 0, true, .click 17 58, bd6, o938, o939⟩,
  ⟨2506, 6, 2, true, .reset, bd6, o939, o245⟩,
  ⟨2507, 6, 0, true, .click 17 51, bd6, o245, o711⟩,
  ⟨2508, 6, 0, true, .click 17 51, bd6, o711, o712⟩,
  ⟨2509, 6, 0, true, .click 10 51, bd6, o712, o713⟩,
  ⟨2510, 6, 0, true, .click 10 51, bd6, o713, o917⟩,
  ⟨2511, 6, 0, true, .click 10 51, bd6, o917, o918⟩,
  ⟨2512, 6, 0, true, .click 10 51, bd6, o918, o940⟩,
  ⟨2513, 6, 0, true, .click 10 51, bd6, o940, o941⟩,
  ⟨2514, 6, 0, true, .click 10 51, bd6, o941, o942⟩,
  ⟨2515, 6, 0, true, .click 10 51, bd6, o942, o943⟩,
  ⟨2516, 6, 0, true, .click 10 58, bd6, o943, o944⟩,
  ⟨2517, 6, 0, true, .click 10 58, bd6, o944, o945⟩,
  ⟨2518, 6, 0, true, .click 10 58, bd6, o945, o946⟩,
  ⟨2519, 6, 0, true, .click 10 58, bd6, o946, o947⟩,
  ⟨2520, 6, 0, true, .click 32 51, bd6, o947, o948⟩]
def rows42 : List Row := [
  ⟨2521, 6, 0, true, .click 32 51, bd6, o948, o949⟩,
  ⟨2522, 6, 0, true, .click 32 51, bd6, o949, o950⟩,
  ⟨2523, 6, 0, true, .click 32 51, bd6, o950, o951⟩,
  ⟨2524, 6, 0, true, .click 32 51, bd6, o951, o952⟩,
  ⟨2525, 6, 0, true, .click 32 58, bd6, o952, o953⟩,
  ⟨2526, 6, 0, true, .click 17 51, bd6, o953, o953⟩,
  ⟨2527, 6, 0, true, .click 17 58, bd6, o953, o953⟩,
  ⟨2528, 6, 2, true, .reset, bd6, o953, o245⟩,
  ⟨2529, 6, 0, true, .click 26 51, bd6, o245, o246⟩,
  ⟨2530, 6, 0, true, .click 39 51, bd6, o246, o247⟩,
  ⟨2531, 6, 0, true, .click 39 51, bd6, o247, o248⟩,
  ⟨2532, 6, 0, true, .click 39 51, bd6, o248, o246⟩,
  ⟨2533, 6, 0, true, .click 54 51, bd6, o246, o249⟩,
  ⟨2534, 6, 0, true, .click 54 51, bd6, o249, o250⟩,
  ⟨2535, 6, 0, true, .click 60 58, bd6, o250, o251⟩,
  ⟨2536, 6, 0, true, .click 60 58, bd6, o251, o252⟩,
  ⟨2537, 6, 0, true, .click 60 58, bd6, o252, o253⟩,
  ⟨2538, 6, 0, true, .click 60 51, bd6, o253, o254⟩,
  ⟨2539, 6, 0, true, .click 60 51, bd6, o254, o255⟩,
  ⟨2540, 6, 0, true, .click 17 51, bd6, o255, o256⟩,
  ⟨2541, 6, 0, true, .click 17 51, bd6, o256, o257⟩,
  ⟨2542, 6, 0, true, .click 10 51, bd6, o257, o258⟩,
  ⟨2543, 6, 0, true, .click 10 51, bd6, o258, o259⟩,
  ⟨2544, 6, 0, true, .click 10 51, bd6, o259, o260⟩,
  ⟨2545, 6, 0, true, .click 10 51, bd6, o260, o261⟩,
  ⟨2546, 6, 0, true, .click 10 51, bd6, o261, o262⟩,
  ⟨2547, 6, 0, true, .click 10 51, bd6, o262, o263⟩,
  ⟨2548, 6, 0, true, .click 10 51, bd6, o263, o264⟩,
  ⟨2549, 6, 0, true, .click 10 51, bd6, o264, o265⟩,
  ⟨2550, 6, 0, true, .click 39 51, bd6, o265, o266⟩,
  ⟨2551, 6, 0, true, .click 10 58, bd6, o266, o267⟩,
  ⟨2552, 6, 0, true, .click 10 58, bd6, o267, o268⟩,
  ⟨2553, 6, 0, true, .click 10 58, bd6, o268, o269⟩,
  ⟨2554, 6, 0, true, .click 10 58, bd6, o269, o270⟩,
  ⟨2555, 6, 0, true, .click 10 58, bd6, o270, o271⟩,
  ⟨2556, 6, 0, true, .click 10 58, bd6, o271, o272⟩,
  ⟨2557, 6, 0, true, .click 10 58, bd6, o272, o273⟩,
  ⟨2558, 6, 0, true, .click 10 58, bd6, o273, o274⟩,
  ⟨2559, 6, 0, true, .click 10 58, bd6, o274, o275⟩,
  ⟨2560, 6, 0, true, .click 10 58, bd6, o275, o276⟩,
  ⟨2561, 6, 0, true, .click 10 58, bd6, o276, o277⟩,
  ⟨2562, 6, 0, true, .click 10 58, bd6, o277, o278⟩,
  ⟨2563, 6, 0, true, .click 39 51, bd6, o278, o279⟩,
  ⟨2564, 6, 0, true, .click 39 51, bd6, o279, o280⟩,
  ⟨2565, 6, 0, true, .click 32 51, bd6, o280, o281⟩,
  ⟨2566, 6, 0, true, .click 32 51, bd6, o281, o282⟩,
  ⟨2567, 6, 0, true, .click 32 51, bd6, o282, o283⟩,
  ⟨2568, 6, 0, true, .click 32 51, bd6, o283, o284⟩,
  ⟨2569, 6, 0, true, .click 32 51, bd6, o284, o285⟩,
  ⟨2570, 6, 0, true, .click 32 51, bd6, o285, o286⟩,
  ⟨2571, 6, 0, true, .click 32 51, bd6, o286, o287⟩,
  ⟨2572, 6, 0, true, .click 32 58, bd6, o287, o288⟩,
  ⟨2573, 6, 0, true, .click 32 58, bd6, o288, o289⟩,
  ⟨2574, 6, 0, true, .click 32 58, bd6, o289, o290⟩,
  ⟨2575, 6, 0, true, .click 32 58, bd6, o290, o291⟩,
  ⟨2576, 6, 0, true, .click 32 58, bd6, o291, o292⟩,
  ⟨2577, 6, 1, true, .click 32 58, bd6, o292, o293⟩,
  ⟨2578, 7, 0, true, .click 22 56, bd7, o293, o294⟩,
  ⟨2579, 7, 0, true, .click 45 4, bd7, o294, o295⟩,
  ⟨2580, 7, 0, true, .click 49 18, bd7, o295, o296⟩]
def rows43 : List Row := [
  ⟨2581, 7, 0, true, .click 49 18, bd7, o296, o297⟩,
  ⟨2582, 7, 0, true, .click 49 18, bd7, o297, o298⟩,
  ⟨2583, 7, 0, true, .click 45 4, bd7, o298, o299⟩,
  ⟨2584, 7, 0, true, .click 22 56, bd7, o299, o300⟩,
  ⟨2585, 7, 0, true, .click 22 56, bd7, o300, o301⟩,
  ⟨2586, 7, 0, true, .click 22 56, bd7, o301, o302⟩,
  ⟨2587, 7, 0, true, .click 22 56, bd7, o302, o303⟩,
  ⟨2588, 7, 0, true, .click 39 4, bd7, o303, o304⟩,
  ⟨2589, 7, 0, true, .click 49 18, bd7, o304, o305⟩,
  ⟨2590, 7, 0, true, .click 49 18, bd7, o305, o306⟩,
  ⟨2591, 7, 0, true, .click 49 18, bd7, o306, o307⟩,
  ⟨2592, 7, 0, true, .click 45 11, bd7, o307, o308⟩,
  ⟨2593, 7, 0, true, .click 45 11, bd7, o308, o309⟩,
  ⟨2594, 7, 0, true, .click 45 11, bd7, o309, o310⟩,
  ⟨2595, 7, 0, true, .click 8 56, bd7, o310, o311⟩,
  ⟨2596, 7, 0, true, .click 8 56, bd7, o311, o312⟩,
  ⟨2597, 7, 0, true, .click 8 56, bd7, o312, o313⟩,
  ⟨2598, 7, 0, true, .click 8 56, bd7, o313, o314⟩,
  ⟨2599, 7, 0, true, .click 8 56, bd7, o314, o315⟩,
  ⟨2600, 7, 0, true, .click 39 11, bd7, o315, o316⟩,
  ⟨2601, 7, 0, true, .click 39 11, bd7, o316, o317⟩,
  ⟨2602, 7, 0, true, .click 59 11, bd7, o317, o318⟩,
  ⟨2603, 7, 0, true, .click 59 11, bd7, o318, o318⟩,
  ⟨2604, 7, 0, true, .click 49 18, bd7, o318, o319⟩,
  ⟨2605, 7, 0, true, .click 49 18, bd7, o319, o320⟩,
  ⟨2606, 7, 0, true, .click 49 18, bd7, o320, o321⟩,
  ⟨2607, 7, 0, true, .click 59 11, bd7, o321, o322⟩,
  ⟨2608, 7, 0, true, .click 59 11, bd7, o322, o323⟩,
  ⟨2609, 7, 0, true, .click 59 11, bd7, o323, o324⟩,
  ⟨2610, 7, 0, true, .click 59 11, bd7, o324, o325⟩,
  ⟨2611, 7, 0, true, .click 59 11, bd7, o325, o326⟩,
  ⟨2612, 7, 0, true, .click 59 11, bd7, o326, o327⟩,
  ⟨2613, 7, 0, true, .click 59 11, bd7, o327, o328⟩,
  ⟨2614, 7, 0, true, .click 59 11, bd7, o328, o329⟩,
  ⟨2615, 7, 0, true, .click 59 11, bd7, o329, o330⟩,
  ⟨2616, 7, 0, true, .click 59 11, bd7, o330, o331⟩,
  ⟨2617, 7, 0, true, .click 59 11, bd7, o331, o332⟩,
  ⟨2618, 7, 1, true, .click 59 11, bd7, o332, o333⟩]

/-- 全部语料，按 seq 排。 -/
def rows : List Row := rows0 ++ rows1 ++ rows2 ++ rows3 ++ rows4 ++ rows5 ++ rows6 ++ rows7 ++ rows8 ++ rows9 ++ rows10 ++ rows11 ++ rows12 ++ rows13 ++ rows14 ++ rows15 ++ rows16 ++ rows17 ++ rows18 ++ rows19 ++ rows20 ++ rows21 ++ rows22 ++ rows23 ++ rows24 ++ rows25 ++ rows26 ++ rows27 ++ rows28 ++ rows29 ++ rows30 ++ rows31 ++ rows32 ++ rows33 ++ rows34 ++ rows35 ++ rows36 ++ rows37 ++ rows38 ++ rows39 ++ rows40 ++ rows41 ++ rows42 ++ rows43

/-- 按 **seq** 从 `want` 那一行起连着取 `len` 行。取不到就给空表——**空表会让「沿这条路一步不差」平凡为真**，
    所以每一段都另配一条 `_len` 定理钉住它到底有几步。 -/
def rowsFrom (want len : Nat) : List Row :=
  ((rows.dropWhile (fun r => r.seq != want)).take len)

end Replay
end Game
