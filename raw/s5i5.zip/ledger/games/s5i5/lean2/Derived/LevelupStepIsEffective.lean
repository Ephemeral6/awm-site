/-
# Derived/LevelupStepIsEffective —— 推论（对应 `rule/推论/levelup_step_is_effective.py`）

作废 ⇒ 局面原样 ⇒ 赢不赢原样。上一帧不是赢面，这一步之后是赢面 ⇒ 这一步一定生效了（不是作废）。
-/

import Obs.Check

namespace Game

theorem levelup_step_is_effective (w w' : World) (a : Act)
    (h : after w a = some w') (hg : isGoal w' = true) (h0 : isGoal w = false) :
    step w a ≠ .refused := by
  intro hr
  simp only [after, hr] at h
  cases h
  rw [h0] at hg
  exact Bool.noConfusion hg

end Game
