/-
# Derived/BoardUnchanged —— 推论（对应 `rule/推论/board_unchanged.py`）

一步之后盘面不变。**不用任何一条规则的内容**：`step` 每一支返回的新世界，盘面都是从旧世界抄过去的
（`{ w with bars := …, walls := … }`）。所以它不是一条独立的规则，是表示法的推论。
-/

import Step

namespace Game

theorem tryTurn_board (w w' : World) (pr pc : Nat) (ch : List (Bar × Bool)) :
    ∀ k n, tryTurn w pr pc ch k n = .ok w' → w'.board = w.board := by
  intro k n
  induction n generalizing k with
  | zero => intro h; simp [tryTurn] at h
  | succ n ih =>
    intro h
    simp only [tryTurn] at h
    split at h <;> first | exact ih _ h | (simp at h; subst h; rfl) | simp at h

theorem rotate_board (w w' : World) (K : Nat) (h : rotate w K = .ok w') : w'.board = w.board := by
  simp only [rotate] at h
  split at h
  · simp at h
  · exact tryTurn_board w w' _ _ _ 1 3 h

theorem stretch_board (w w' : World) (K : Nat) (g : Bool) (h : stretch w K g = .ok w') :
    w'.board = w.board := by
  unfold stretch at h
  split at h
  · exact Res.noConfusion h
  · split at h
    split at h
    · exact Res.noConfusion h
    split at h
    · exact Res.noConfusion h
    split at h
    · exact Res.noConfusion h
    split at h
    · exact Res.noConfusion h
    injection h with h
    subst h
    rfl

theorem board_unchanged (w w' : World) (a : Act) (h : step w a = .ok w') : w'.board = w.board := by
  cases a with
  | reset => simp [step] at h
  | click x y =>
    simp only [step] at h
    split at h
    · exact stretch_board w w' _ _ h
    · exact stretch_board w w' _ _ h
    · exact rotate_board w w' _ h
    · simp only [clickElsewhere] at h; cases h; rfl

end Game
