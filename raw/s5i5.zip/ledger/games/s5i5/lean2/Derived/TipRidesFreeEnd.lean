/-
# Derived/TipRidesFreeEnd —— 推论（对应 `rule/推论/tip_rides_free_end.py`）

尖只记「有没有」，位置由长度算出来。所以伸 3 格之后，尖还在，而且正好往自由端那边挪了 3 格——
「尖跟着自由端走」是表示法的推论，不是一条独立的规则。
-/

import Step

namespace Game

theorem tip_rides_free_end (b : Bar) (hl : 1 ≤ b.len) :
    (stretchBar b true).tip = b.tip ∧
    (stretchBar b true).tipCell = b.dir.go 3 b.tipCell.1 b.tipCell.2 := by
  refine ⟨by simp [stretchBar], ?_⟩
  cases hd : b.dir <;> simp only [stretchBar, Bar.tipCell, Dir.go, hd, if_true] <;>
    (apply Prod.ext <;> simp <;> omega)

end Game
