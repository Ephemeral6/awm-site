/-
# Derived/RotationKeepsLength —— 推论（对应 `rule/推论/rotation_keeps_length.py`）

转动只改帽的位置和方向，长度与有没有尖原样抄过去。所以「转动不改长度」不是一条独立的规则。
-/

import Step

namespace Game

theorem turnBar_keeps (pr pc : Nat) : ∀ (k : Nat) (b : Bar),
    (turnBar pr pc k b).len = b.len ∧ (turnBar pr pc k b).tip = b.tip ∧ (turnBar pr pc k b).color = b.color := by
  intro k
  induction k with
  | zero => intro b; simp [turnBar]
  | succ k ih =>
    intro b
    simp only [turnBar]
    have := ih (turnBar1 pr pc b)
    simp only [turnBar1] at this
    exact this

/-- 被转的每一根条（整串里的任何一根、转任何档）长度、尖、颜色不变。 -/
theorem rotation_keeps_length (pr pc k : Nat) (b : Bar) :
    (turnBar pr pc k b).len = b.len ∧ (turnBar pr pc k b).tip = b.tip ∧ (turnBar pr pc k b).color = b.color :=
  turnBar_keeps pr pc k b

end Game
