/-
# Rule/Turn/LegendRotatesChain —— 定义（对应 `rule/转动/legend_rotates_chain.py`）

点 K 色图例：K 色那根条（或 K 色枢纽上挂着的几根）连同整条下游，绕关节逆时针转 90°；
关节 = K 色条身体第 1 条的正中那一格（枢纽则是枢纽中心）。转到的那一档压着别的东西就接着转，
逐档的结论交给 `Rule/Refuse/RotationBlocked` 的 `verdict`。
-/

import Obj.Derive.Attach
import Rule.Refuse.RotationBlocked

namespace Game

/-- 一根条绕 `(pr, pc)` 逆时针转一档：帽那块长方形转过去，方向跟着转。 -/
def turnBar1 (pr pc : Nat) (b : Bar) : Bar :=
  let cap := b.cap.rot pr pc
  { b with r := cap.r0, c := cap.c0, dir := b.dir.ccw }

def turnBar (pr pc : Nat) : Nat → Bar → Bar
  | 0, b => b
  | k + 1, b => turnBar pr pc k (turnBar1 pr pc b)

/-- 在下游里的转 `k` 档，不在的原样。 -/
def turnAll (pr pc k : Nat) : List (Bar × Bool) → List Bar
  | [] => []
  | (b, m) :: rest => (if m then turnBar pr pc k b else b) :: turnAll pr pc k rest

/-- K 色恰好一根条时的关节：身体第 1 条的正中。 -/
def jointOf (b : Bar) : Nat × Nat :=
  match b.dir with
  | .U => (b.r - 1, b.c + 1)
  | .D => (b.r + 1, b.c + 1)
  | .L => (b.r + 1, b.c - 1)
  | .R => (b.r + 1, b.c + 1)

/-- 关节与根：有 K 色枢纽就绕枢纽中心、根是帽贴着枢纽的条；否则 K 色要恰好一根条。 -/
def pivotRoots (w : World) (K : Nat) : Option (Nat × Nat × List Bool) :=
  match w.board.hubs.find? (·.color == K) with
  | some h => some (h.r + 1, h.c + 1, w.bars.map (fun b => meetsAny b.cap h.ring))
  | none =>
    match w.bars.filter (·.color == K) with
    | [b] => some ((jointOf b).1, (jointOf b).2, w.bars.map (·.color == K))
    | _ => none

/-- 第 `k` 档的四个读数。 -/
def turnInfo (w : World) (pr pc k : Nat) (chain : List (Bar × Bool)) : Bool × Bool × Bool × Bool :=
  let moved := (chain.filter (·.2)).map (fun p => turnBar pr pc k p.1)
  let others := (chain.filter (fun p => !p.2)).map (fun p => p.1.whole)
              ++ w.board.hubs.map Hub.rect ++ w.walls.map (·.rect) ++ w.board.boxes
  (moved.any (fun b => meetsAny b.whole w.board.fixed),
   moved.any (fun b => meetsAny b.whole others),
   moved.any (fun b => !b.whole.onBoard),
   moved.any (fun b => !b.cap.onBoard))

/-- 逐档试，最多 `n` 档。 -/
def tryTurn (w : World) (pr pc : Nat) (chain : List (Bar × Bool)) : Nat → Nat → Res
  | _, 0 => .refused
  | k, n + 1 =>
    match turnInfo w pr pc k chain with
    | (fx, bl, off, co) =>
      match verdict k fx bl off co with
      | .refuse => .refused
      | .next => tryTurn w pr pc chain (k + 1) n
      | .accept => .ok { w with bars := turnAll pr pc k chain }

def rotate (w : World) (K : Nat) : Res :=
  match pivotRoots w K with
  | none => .silent
  | some (pr, pc, roots) => tryTurn w pr pc (w.bars.zip (downstream w.bars roots)) 1 3

end Game
