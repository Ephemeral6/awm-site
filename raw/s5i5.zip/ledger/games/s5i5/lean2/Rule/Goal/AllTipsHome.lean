/-
# Rule/Goal/AllTipsHome —— 定义（对应 `rule/过关/all_tips_home_advances.py`）

**赢是一个局面的性质**：所有尖都在靶心上、每个靶心上都有尖。
「这一步之后是赢面 ⇔ 这一步换关」在逐条那一层核（`Obs/Corpus.lean`）。
-/

import Obj.World

namespace Game

def tips (w : World) : List (Nat × Nat) := (w.bars.filter (·.tip)).map Bar.tipCell

def isGoal (w : World) : Bool :=
  (tips w).all (fun t => (w.board.centers).contains t) &&
  (w.board.centers).all (fun c => (tips w).contains c)

end Game
