/-
# Rule/Stretch/FreeEndMoves —— 定义（对应 `rule/伸缩/free_end_moves.py`）

点面板图标：那一色的每一根条（被框挡住的除外）自由端沿自己的长轴走 3 格，帽不动。
伸 = 自由端往 `dir` 走；缩 = 往 `dir.opp` 走。
-/

import Rule.Stretch.Mark
import Rule.Stretch.BoxStopsOneBar

namespace Game

/-- 自由端往哪边走。 -/
def freeEndDir (b : Bar) (grow : Bool) : Dir := if grow then b.dir else b.dir.opp

/-- 伸缩之后的这一根（只改长度）。 -/
def stretchBar (b : Bar) (grow : Bool) : Bar :=
  if grow then { b with len := b.len + 3 } else { b with len := b.len - 3 }

/-- 起始记账：K 色的条要么伸缩、要么被框挡住，别的条没动。 -/
def initMarks (bd : Board) (bars : List Bar) (K : Nat) (grow : Bool) : List (Bar × Mark) :=
  bars.map (fun b =>
    if b.color == K then
      (if grow && boxStops bd b then (b, .stopped) else (b, .grown (freeEndDir b grow)))
    else (b, .still))

end Game
