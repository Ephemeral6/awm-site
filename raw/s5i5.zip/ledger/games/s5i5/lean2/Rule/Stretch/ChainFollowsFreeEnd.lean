/-
# Rule/Stretch/ChainFollowsFreeEnd —— 定义（对应 `rule/伸缩/chain_follows_free_end.py`）

一根条的自由端动了（往 `d` 走 3 格），挂在它自由端外那一条上的东西——别色条的帽、任何墙——
整体往 `d` 走 3 格；被这样拖动的条，它自己自由端上挂的东西也一样，一路传下去。

实现是一个栈（和 Python 那一份一样后进先出）：每处理一张「脸」，把新挂上的条压回栈顶。
-/

import Rule.Stretch.Mark
import Obj.Derive.Attach

namespace Game

/-- 一张脸 `f`（来自 `col` 色的条，位移 `d`）：把挂上来的、还没动的条标成被拖，并交出它们的脸。 -/
def dragBars (col : Nat) (d : Dir) (f : Rect) :
    List (Bar × Mark) → List (Bar × Mark) × List (Dir × Rect × Nat)
  | [] => ([], [])
  | (b, m) :: rest =>
    let r := dragBars col d f rest
    if m.isStill && b.color != col && b.cap.meets f then
      ((b, .moved d) :: r.1, (d, b.face, b.color) :: r.2)
    else ((b, m) :: r.1, r.2)

def dragWalls (d : Dir) (f : Rect) : List (Wall × Option Dir) → List (Wall × Option Dir)
  | [] => []
  | (w, m) :: rest =>
    (if m.isNone && w.rect.meets f then (w, some d) else (w, m)) :: dragWalls d f rest

/-- 栈跑到空（`fuel` 够条数 + 1 就一定跑完：每根条最多进栈一次）。 -/
def follow : Nat → List (Dir × Rect × Nat) → List (Bar × Mark) → List (Wall × Option Dir) →
    List (Bar × Mark) × List (Wall × Option Dir)
  | 0, _, bs, ws => (bs, ws)
  | _ + 1, [], bs, ws => (bs, ws)
  | n + 1, (d, f, col) :: st, bs, ws =>
    let r := dragBars col d f bs
    follow n (r.2.reverse ++ st) r.1 (dragWalls d f ws)

/-- 每根正在伸缩的条（按条表的顺序）各跑一遍。 -/
def followFrom (fuel : Nat) : List (Bar × Mark) → List (Bar × Mark) → List (Wall × Option Dir) →
    List (Bar × Mark) × List (Wall × Option Dir)
  | [], bs, ws => (bs, ws)
  | (b, .grown d) :: rest, bs, ws =>
    let r := follow fuel [(d, b.face, b.color)] bs ws
    followFrom fuel rest r.1 r.2
  | _ :: rest, bs, ws => followFrom fuel rest bs ws

def followAll (marks : List (Bar × Mark)) (walls : List Wall) :
    List (Bar × Mark) × List (Wall × Option Dir) :=
  followFrom (marks.length + 1) marks marks (walls.map (fun w => (w, none)))

end Game
