/-
# Rule/Stretch/OthersStay —— 定义（对应 `rule/伸缩/others_stay.py`）

这一下没伸缩、没被拖的条和墙，原封不动。在模型里它就是「按账本落地」时 `still` / `stopped`
那两支：原样抄过去。
-/

import Rule.Stretch.FreeEndMoves

namespace Game

/-- 按账本把一根条落地。 -/
def settleBar (grow : Bool) : Bar × Mark → Bar
  | (b, .grown _) => stretchBar b grow
  | (b, .moved d) => b.shift d
  | (b, .still) => b
  | (b, .stopped) => b

def settleWall : Wall × Option Dir → Wall
  | (w, some d) => w.shift d
  | (w, none) => w

end Game
