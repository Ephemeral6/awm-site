/-
# Rule/Stretch/Mark —— 一步伸缩的账本（对应 `derive/step.py` 的 `Move`）

每根条在这一步里是哪一种：没动 / 在伸缩（自由端往 `d` 走）/ 被拖（整根往 `d` 走）/ 被框挡住。
每面墙：没动 / 被拖（整块往 `d` 走）。**不是规则，是记账**——规则往上面写，`Step` 读它。
-/

import Obj.World

namespace Game

inductive Mark where
  | still
  | grown (d : Dir)
  | moved (d : Dir)
  | stopped
  deriving DecidableEq, Repr

/-- 还没在动的（没动的、被框挡住的都算：它们都还可以被别人拖走）。 -/
def Mark.isStill : Mark → Bool
  | .still => true
  | .stopped => true
  | _ => false

end Game
