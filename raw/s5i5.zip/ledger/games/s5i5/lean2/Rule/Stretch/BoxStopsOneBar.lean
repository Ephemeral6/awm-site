/-
# Rule/Stretch/BoxStopsOneBar —— 定义（对应 `rule/伸缩/box_stops_one_bar.py`）

伸的那一下，新身体会长进面板或图例框的那一根条原地不动；同色别的照走。
-/

import Obj.World

namespace Game

/-- 这一根要是伸 3 格，新身体压不压框。 -/
def boxStops (bd : Board) (b : Bar) : Bool :=
  meetsAny ({ b with len := b.len + 3 }).body bd.boxes

end Game
