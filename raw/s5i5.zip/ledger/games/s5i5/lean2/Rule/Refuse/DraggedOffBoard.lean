/-
# Rule/Refuse/DraggedOffBoard —— 定义（对应 `rule/作废/dragged_off_board_refuses.py`）

被拖着走的条，落点的帽只要有一格出了盘，整步作废。
-/

import Rule.Stretch.Mark

namespace Game

def draggedOffBoard (marks : List (Bar × Mark)) : Bool :=
  marks.any (fun
    | (b, .moved d) => !(b.shift d).cap.onBoard
    | _ => false)

end Game
