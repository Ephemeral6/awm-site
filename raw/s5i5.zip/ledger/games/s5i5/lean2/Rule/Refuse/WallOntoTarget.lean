/-
# Rule/Refuse/WallOntoTarget —— 定义（对应 `rule/作废/wall_onto_target_refuses.py`）

点「伸」时，被带着走的墙原来不压靶、落点压上了靶，整步作废。

**两种读法语料分不开，这里只取了其中一种**（「伸而不是缩」；另一种是「沿墙的长轴而不是横着」）。
见 `analysis/gaps.txt`。
-/

import Obj.World

namespace Game

def wallOntoTarget (bd : Board) (grow : Bool) (ws : List (Wall × Option Dir)) : Bool :=
  grow && ws.any (fun
    | (w, some d) => meetsAny (w.shift d).rect bd.targets && !meetsAny w.rect bd.targets
    | _ => false)

end Game
