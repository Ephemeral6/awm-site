/-
# Rule/Refuse/TooShort —— 定义（对应 `rule/作废/too_short_refuses.py`）

点「缩」时，那一色只要有一根缩完身体不足 2 条，整步作废。
-/

import Obj.World

namespace Game

def tooShort (bars : List Bar) (K : Nat) (grow : Bool) : Bool :=
  !grow && bars.any (fun b => b.color == K && Nat.blt b.len 5)

end Game
