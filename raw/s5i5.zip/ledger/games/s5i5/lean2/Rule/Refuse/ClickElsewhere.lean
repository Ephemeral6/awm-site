/-
# Rule/Refuse/ClickElsewhere —— 定义（对应 `rule/作废/click_elsewhere_does_nothing.py`）

点在图标中心、图例框以外的地方：条和墙一格不动。
-/

import Obj.World

namespace Game

def clickElsewhere (w : World) : Res := .ok w

end Game
