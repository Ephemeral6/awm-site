/-
# Rule/Refuse/FixedBlocks —— 定义（对应 `rule/作废/fixed_blocks_refuses.py`）

算完之后，任何一根条或一面墙压着钉死的墙或框，整步作废。
-/

import Obj.World

namespace Game

def fixedBlocks (bd : Board) (bars : List Bar) (walls : List Wall) : Bool :=
  let bad := bd.fixed ++ bd.boxes
  bars.any (fun b => meetsAny b.whole bad) || walls.any (fun w => meetsAny w.rect bad)

end Game
