/-
# Rule/Refuse/RotationBlocked —— 定义（对应 `rule/作废/rotation_blocked_refuses.py`）

点图例逐档试：这一档压着钉死的墙 ⇒ 作废；压着别的条 / 墙 / 框 ⇒ 试下一档；
没压着但有帽出了盘 ⇒ 作废；跳过了至少一档、这一档身体出了盘 ⇒ 作废；否则转到这一档。
-/

import Obj.World

namespace Game

inductive Verdict where
  | refuse | next | accept
  deriving DecidableEq, Repr

/-- 一档的四个读数 → 结论。 -/
def verdict (k : Nat) (fixed blocked off capOff : Bool) : Verdict :=
  if fixed then .refuse
  else if blocked then .next
  else if capOff then .refuse
  else if off && Nat.blt 1 k then .refuse
  else .accept

end Game
