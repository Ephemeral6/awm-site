/-
# Rule/Refuse/LandingBlocked —— 定义（对应 `rule/作废/landing_blocked_refuses.py`）

算完之后，只要有两样东西（条、墙、枢纽）占同一格，整步作废——
包括正在伸的条的新身体压着别的条或墙：伸出去不会把挡路的顶开。
-/

import Obj.World

namespace Game

/-- 一张长方形表里有没有两块相交。 -/
def anyPairMeets : List Rect → Bool
  | [] => false
  | x :: xs => meetsAny x xs || anyPairMeets xs

def landingBlocked (bd : Board) (bars : List Bar) (walls : List Wall) : Bool :=
  anyPairMeets (bars.map Bar.whole ++ walls.map (·.rect) ++ bd.hubs.map Hub.rect)

end Game
