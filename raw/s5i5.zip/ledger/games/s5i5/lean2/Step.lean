/-
# Step —— 一步怎么走：**只做分发与排序，0 条定理**（对应 `derive/step.py`）

点面板（`stretch`）的顺序和 Python 那一份一样：
    作废/TooShort → 伸缩/BoxStopsOneBar + FreeEndMoves（起始账本）→ 伸缩/ChainFollowsFreeEnd
    → 作废/DraggedOffBoard → 作废/LandingBlocked → 作废/FixedBlocks → 作废/WallOntoTarget
    → 伸缩/OthersStay（按账本落地）
点图例：转动/LegendRotatesChain。点在别处：作废/ClickElsewhere。RESET：模型不说话（`silent`）。

**「不经过 RESET 就……」**：`silent` 那一支在 `everGoal` 里返回 `false`，所以任何「赢不了」
的定理准确的意思都是「不经过 RESET 就赢不了」。本局八关全部是「走得通」，没有用到这一句。
-/

import Obj.Derive.Click
import Rule.Stretch.ChainFollowsFreeEnd
import Rule.Stretch.OthersStay
import Rule.Refuse.TooShort
import Rule.Refuse.DraggedOffBoard
import Rule.Refuse.LandingBlocked
import Rule.Refuse.FixedBlocks
import Rule.Refuse.WallOntoTarget
import Rule.Refuse.ClickElsewhere
import Rule.Turn.LegendRotatesChain
import Rule.Goal.AllTipsHome

namespace Game

def stretch (w : World) (K : Nat) (grow : Bool) : Res :=
  if tooShort w.bars K grow then .refused else
  match followAll (initMarks w.board w.bars K grow) w.walls with
  | (bs, ws) =>
    if draggedOffBoard bs then .refused else
    if landingBlocked w.board (bs.map (settleBar grow)) (ws.map settleWall) then .refused else
    if fixedBlocks w.board (bs.map (settleBar grow)) (ws.map settleWall) then .refused else
    if wallOntoTarget w.board grow ws then .refused else
    .ok { w with bars := bs.map (settleBar grow), walls := ws.map settleWall }

def step (w : World) : Act → Res
  | .reset => .silent
  | .click x y =>
    match decode w.board x y with
    | .grow K => stretch w K true
    | .shrink K => stretch w K false
    | .rot K => rotate w K
    | .elsewhere => clickElsewhere w

end Game
