/-
# Proof/Levels —— 每一关一条定理（**自动生成，不要手改**；生成器 `lean2/export_levels.py`）

    L<n>_seg<i>_trace   沿着认证段里真人走过的第 i 段，模型**每一帧都和观测对上**
                        （只有开局那一帧是观测给的，后面全是模型自己算的）
    L<n>_seg<i>_len     那一段确实有这么多步（切歪了会得到空表，空表让上一条平凡为真）
    L<n>_winnable       这一关走得通 —— 见证是最后一段真实走法 + 过关那一脚

**明写的假设**：RESET 把局面放回这一关的开局。它不进模型；有 RESET 的关，每一段都从开局起逐帧核——
假设错了第一帧就红。**没红不构成证明**，但那是这条假设在这批语料上唯一一次有机会被驳倒。

语料：认证段 seq 2157..2618（成绩单 guid 5a5811e1-768c-422a-b686-43686fcfdb77），逐关步数与成绩单 level_actions 对上（见 analysis/corpus.txt）。
-/

import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

open Replay



/-- 第 0 关的真实开局：认证段里这一关第一行（seq 2158）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L0_start : World := o0.toWorld bd0


/-- 第 0 关第 0 段：seq 2158..2169，12 步（到过关前一步为止）。 -/
def L0_seg0 : List (Act × Obs) := (rowsFrom 2158 12).map (fun r => (r.act, r.next))

theorem L0_seg0_len : L0_seg0.length = 12 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L0_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L0_seg0_trace : traceOk (L0_start : World) L0_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2170：ACTION6:24,44）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L0_win_acts : List Act := L0_seg0.map Prod.fst ++ [.click 24 44]

theorem L0_win_acts_len : L0_win_acts.length = 13 := by decide +kernel

/-- **第 0 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L0_winnable : Winnable (L0_start : World) := ⟨L0_win_acts, by decide +kernel⟩


/-- 第 1 关的真实开局：认证段里这一关第一行（seq 2171）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L1_start : World := o14.toWorld bd1


/-- 第 1 关第 0 段：seq 2171..2309，139 步（到过关前一步为止）。 -/
def L1_seg0 : List (Act × Obs) := (rowsFrom 2171 139).map (fun r => (r.act, r.next))

theorem L1_seg0_len : L1_seg0.length = 139 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L1_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L1_seg0_trace : traceOk (L1_start : World) L1_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2310：ACTION6:42,57）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L1_win_acts : List Act := L1_seg0.map Prod.fst ++ [.click 42 57]

theorem L1_win_acts_len : L1_win_acts.length = 140 := by decide +kernel

/-- **第 1 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L1_winnable : Winnable (L1_start : World) := ⟨L1_win_acts, by decide +kernel⟩


/-- 第 2 关的真实开局：认证段里这一关第一行（seq 2311）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L2_start : World := o40.toWorld bd2


/-- 第 2 关第 0 段：seq 2311..2353，43 步（到过关前一步为止）。 -/
def L2_seg0 : List (Act × Obs) := (rowsFrom 2311 43).map (fun r => (r.act, r.next))

theorem L2_seg0_len : L2_seg0.length = 43 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L2_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L2_seg0_trace : traceOk (L2_start : World) L2_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2354：ACTION6:35,48）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L2_win_acts : List Act := L2_seg0.map Prod.fst ++ [.click 35 48]

theorem L2_win_acts_len : L2_win_acts.length = 44 := by decide +kernel

/-- **第 2 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L2_winnable : Winnable (L2_start : World) := ⟨L2_win_acts, by decide +kernel⟩


/-- 第 3 关的真实开局：认证段里这一关第一行（seq 2355）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L3_start : World := o113.toWorld bd3


/-- 第 3 关第 0 段：seq 2355..2398，44 步（到过关前一步为止）。 -/
def L3_seg0 : List (Act × Obs) := (rowsFrom 2355 44).map (fun r => (r.act, r.next))

theorem L3_seg0_len : L3_seg0.length = 44 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L3_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L3_seg0_trace : traceOk (L3_start : World) L3_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2399：ACTION6:34,54）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L3_win_acts : List Act := L3_seg0.map Prod.fst ++ [.click 34 54]

theorem L3_win_acts_len : L3_win_acts.length = 45 := by decide +kernel

/-- **第 3 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L3_winnable : Winnable (L3_start : World) := ⟨L3_win_acts, by decide +kernel⟩


/-- 第 4 关的真实开局：认证段里这一关第一行（seq 2400）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L4_start : World := o165.toWorld bd4


/-- 第 4 关第 0 段：seq 2400..2434，35 步（到过关前一步为止）。 -/
def L4_seg0 : List (Act × Obs) := (rowsFrom 2400 35).map (fun r => (r.act, r.next))

theorem L4_seg0_len : L4_seg0.length = 35 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L4_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L4_seg0_trace : traceOk (L4_start : World) L4_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2435：ACTION6:42,57）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L4_win_acts : List Act := L4_seg0.map Prod.fst ++ [.click 42 57]

theorem L4_win_acts_len : L4_win_acts.length = 36 := by decide +kernel

/-- **第 4 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L4_winnable : Winnable (L4_start : World) := ⟨L4_win_acts, by decide +kernel⟩


/-- 第 5 关的真实开局：认证段里这一关第一行（seq 2436）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L5_start : World := o209.toWorld bd5


/-- 第 5 关第 0 段：seq 2436..2472，37 步（到过关前一步为止）。 -/
def L5_seg0 : List (Act × Obs) := (rowsFrom 2436 37).map (fun r => (r.act, r.next))

theorem L5_seg0_len : L5_seg0.length = 37 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L5_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L5_seg0_trace : traceOk (L5_start : World) L5_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2473：ACTION6:34,57）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L5_win_acts : List Act := L5_seg0.map Prod.fst ++ [.click 34 57]

theorem L5_win_acts_len : L5_win_acts.length = 38 := by decide +kernel

/-- **第 5 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L5_winnable : Winnable (L5_start : World) := ⟨L5_win_acts, by decide +kernel⟩


/-- 第 6 关的真实开局：认证段里这一关第一行（seq 2474）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L6_start : World := o245.toWorld bd6


/-- 第 6 关第 0 段：seq 2474..2505，32 步（到 RESET 为止）。 -/
def L6_seg0 : List (Act × Obs) := (rowsFrom 2474 32).map (fun r => (r.act, r.next))

theorem L6_seg0_len : L6_seg0.length = 32 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L6_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L6_seg0_trace : traceOk (L6_start : World) L6_seg0 = true := by decide +kernel


/-- 第 6 关第 1 段：seq 2507..2527，21 步（到 RESET 为止）。 -/
def L6_seg1 : List (Act × Obs) := (rowsFrom 2507 21).map (fun r => (r.act, r.next))

theorem L6_seg1_len : L6_seg1.length = 21 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L6_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L6_seg1_trace : traceOk (L6_start : World) L6_seg1 = true := by decide +kernel


/-- 第 6 关第 2 段：seq 2529..2576，48 步（到过关前一步为止）。 -/
def L6_seg2 : List (Act × Obs) := (rowsFrom 2529 48).map (fun r => (r.act, r.next))

theorem L6_seg2_len : L6_seg2.length = 48 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L6_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L6_seg2_trace : traceOk (L6_start : World) L6_seg2 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2577：ACTION6:32,58）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L6_win_acts : List Act := L6_seg2.map Prod.fst ++ [.click 32 58]

theorem L6_win_acts_len : L6_win_acts.length = 49 := by decide +kernel

/-- **第 6 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L6_winnable : Winnable (L6_start : World) := ⟨L6_win_acts, by decide +kernel⟩


/-- 第 7 关的真实开局：认证段里这一关第一行（seq 2578）动作之前那一帧。**从语料读出来的，不是手写的盘。** -/
def L7_start : World := o293.toWorld bd7


/-- 第 7 关第 0 段：seq 2578..2617，40 步（到过关前一步为止）。 -/
def L7_seg0 : List (Act × Obs) := (rowsFrom 2578 40).map (fun r => (r.act, r.next))

theorem L7_seg0_len : L7_seg0.length = 40 := by decide +kernel

/-- **模型沿着这一段一步不差**：从 `L7_start`（World）起，每一步用的都是模型自己算出来的状态。 -/
theorem L7_seg0_trace : traceOk (L7_start : World) L7_seg0 = true := by decide +kernel


/-- 最后一段的走法，再加上过关那一脚（seq 2618：ACTION6:59,11）。那一脚的下一帧是下一关的盘，所以它不在段里；
    但「赢了」正是它的结果。 -/
def L7_win_acts : List Act := L7_seg0.map Prod.fst ++ [.click 59 11]

theorem L7_win_acts_len : L7_win_acts.length = 41 := by decide +kernel

/-- **第 7 关走得通**：从开局（World）照着这一串走，中途赢过（isGoal）。见证只靠最后一段 + 过关那一脚。 -/
theorem L7_winnable : Winnable (L7_start : World) := ⟨L7_win_acts, by decide +kernel⟩


end Levels
end Game
