/-
# Proof/Reachable —— 这个**局面**做不做得了：骨架（模板 `ledger/templates/lean/Reachable.lean` 原样搬）

## 本局用到了哪一半

**只用到「走得通」那一半**：八关在认证段里都通过了，每一关的 `_winnable` 由真实走法当见证
（`Proof/Levels.lean`）。**没有一关宣告「走不通」**，所以这里没有钥匙、没有防线——
写了也没有局面可以套。骨架那一条留着，并且证出来：它和本局无关，但它说明「走不通」
在这套定义下是**可以被严格说出来的**，而且和盘面多大、动作串多长无关。

## 那半句要写在明处

`everGoal` 在模型说不出话（RESET）的一支返回 `false`。所以下面的 `Unsolvable` 准确的意思是
**「不经过 RESET 就赢不了」**——`∀ as` 这个形状一个字都看不出来，所以写在这里。
-/

import Obs.Check

namespace Game

/-- 骨架：一个每走一步都保持、而且和赢面矛盾的性质 Φ，挡住一切动作串。
    **全文唯一做归纳的地方**，不枚举任何状态。 -/
theorem unsolvable_of_invariant (P : World → Prop)
    (hkeep : ∀ w w' a, P w → after w a = some w' → P w')
    (hgoal : ∀ w, P w → isGoal w = false) :
    ∀ (w : World), P w → ∀ (as : List Act), everGoal w as = false := by
  intro w hp as
  induction as generalizing w with
  | nil => simp [everGoal, hgoal w hp]
  | cons a t ih =>
    simp only [everGoal, hgoal w hp, Bool.false_or]
    cases h : after w a with
    | none => rfl
    | some w' => exact ih w' (hkeep w w' a hp h)

/-- 两句话不能同时成立。 -/
theorem not_both (w : World) (h1 : Winnable w) (h2 : Unsolvable w) : False := by
  obtain ⟨as, has⟩ := h1
  have := h2 as
  rw [has] at this
  exact Bool.noConfusion this

end Game
