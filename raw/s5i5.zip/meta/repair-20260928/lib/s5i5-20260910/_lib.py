"""s5i5 修复版读数（meta/repair-20260928，2026-09-29）。

原 archive/s5i5-20260910/concepts/_lib.py 的读数全部退出状态（它们只给计数、聚合量和整盘掩码，写不出下一步）。
退出的依据：新状态（本文件的读数 + level）逐帧决定整帧 0..62 行（重画实测逐格相同，见交回），
所以原读数在全部帧上都是新状态的函数（证据是 _scratch/s5i5-20260910/p23_render.py 的逐格重画；
另一份「按新状态分组、组内唯一」的脚本 p25_depend.py 是空证明——1137 组正好对应 1137 个不同帧，不算证据）。

读数只输出这一帧看得见的原语，每个物件打包成一个非负整数，按整数值升序（= 按坐标）排，空位填 -1：
  bars     条：帽的位置与朝向、看得见的身长、有没有尖、颜色；无帽的 3x3 枢纽单列一种朝向。
           打包 ((((((r+64)*256 + (c+64))*8 + d)*128 + L)*16 + k)*2 + tip，
           (r,c) = 帽那一排的第一格（枢纽 = 左上角），d：0 上 1 下 2 左 3 右 4 枢纽（帽指向自由端的方向），
           L = 身长（看得见的片数），k = 颜色，tip = 自由端往里一格是不是色 13。
  walls    色 1 的墙（推得动的那种）：矩形 ((t+64)*256 + (l+64))*16384 + h*128 + w。
  fixed    色 15 的死物：同一种矩形打包。
  boxes    色 2 描边的框（面板与图例）：外框、图标色、种类（0 面板两枚图标 / 1 图例一枚）、图标中心。
           ((((((((t*64+b)*64+l)*64+r)*16+k)*2+kind)*64+i1r)*64+i1c)*64+i2r)*64+i2c，面板的 i1 是前一枚（左/上）。
  diamonds 菱形中心 r*64+c（四个色 13 点围出的十字的中心）。
  burned   第 63 行色 4 的格数。
条的读法：帽 = 连续 3 格色 3；从帽往一侧长出 3 宽、L 长的同色矩形（菱形四点当透明，尖在倒数第二片的正中）。
一帧里所有条色格、帽格、尖格必须被这些条（和 3x3 枢纽）恰好覆盖一次；多种覆盖时取枢纽最少的，再取搜索序第一个。
墙：同色格按「3 厚的最长矩形」贪心分解（菱形四点当通配）。
"""
from __future__ import annotations

BG, CAP, FILL, BORDER, TIP = 5, 3, 4, 2, 13
WALL, FIXED = 1, 15
NB, NW, NF, NX, ND = 10, 3, 8, 9, 3     # 长度别取 2：生成器会把二元组当成「坐标对」拆成 _r/_c
_DIRS = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}
_DCODE = {"U": 0, "D": 1, "L": 2, "R": 3, "H": 4}

# 每关的步数预算（计数条走满 64 格要多少次 ACTION6）。反推方法：burned(next) = round(64 * n / B)，
# n = 本关（或本关重开后）第几次 ACTION6（被拒的、点在空处的都算）；对全部 run 的每一条关内转移，
# 在 B ∈ [20, 400) 里找与全部读数相容的整数，每关恰好只剩一个（草稿 p17_budget.py，逐关读数条数：
# 第 0 关 n≤14、第 1 关 n≤139、第 2 关 n≤81、第 3 关 n≤70、第 4 关 n≤50、第 5 关 n≤95、第 6 关 n≤48、第 7 关 n≤40）。
# 第 8 关是通关后的终局帧，没有关内转移，不给值。
LEVEL_CONST = {0: {"budget": 50}, 1: {"budget": 150}, 2: {"budget": 200}, 3: {"budget": 100},
               4: {"budget": 150}, 5: {"budget": 150}, 6: {"budget": 200}, 7: {"budget": 200}}

_CACHE = {}


def _memo(g, key, make):
    kk = hash(tuple(map(tuple, g)))
    ent = _CACHE.get(kk)
    if ent is None:
        if len(_CACHE) > 4000:
            _CACHE.clear()
        ent = {}
        _CACHE[kk] = ent
    if key not in ent:
        ent[key] = make()
    return ent[key]


def _comps(cells):
    cells = set(cells); out = []
    while cells:
        s = cells.pop(); st = [s]; comp = [s]
        while st:
            r, c = st.pop()
            for q in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)):
                if q in cells:
                    cells.remove(q); st.append(q); comp.append(q)
        out.append(comp)
    return out


def _boxes(g):
    b = []
    for comp in _comps([(r, c) for r in range(63) for c in range(64) if g[r][c] == BORDER]):
        rs = [x[0] for x in comp]; cs = [x[1] for x in comp]
        b.append((min(rs), max(rs), min(cs), max(cs)))
    return sorted(b)


def _inbox(bx, r, c):
    return any(t <= r <= b and l <= c <= rr for t, b, l, rr in bx)


def _diamonds(g, bx):
    out = []
    for r in range(1, 62):
        for c in range(1, 63):
            if all(g[r + dr][c + dc] == TIP for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))) and not _inbox(bx, r, c):
                out.append((r, c))
    return out


def _strip(d, r, c):
    return [(r, c + i) for i in range(3)] if d in "UD" else [(r + i, c) for i in range(3)]


def _body(k, d, r, c, L, tip):
    dr, dc = _DIRS[d]
    s = _strip(d, r, c)
    body = {}
    for j in range(1, L + 1):
        for i, (a, b) in enumerate(s):
            body[(a + dr * j, b + dc * j)] = TIP if (tip and j == L - 1 and i == 1) else k
    return s, body


def _parse(g):
    return _memo(g, "parse", lambda: _parse0(g))


def _parse0(g):
    bx = _boxes(g)
    dm = _diamonds(g, bx)
    dotset = set()
    for (r, c) in dm:
        dotset |= {(r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)}

    def col(r, c):
        if 0 <= r < 63 and 0 <= c < 64 and not _inbox(bx, r, c):
            return g[r][c]
        return None

    barcolors = {g[r][c] for r in range(63) for c in range(64) if not _inbox(bx, r, c)} - {BG, CAP, TIP, FILL, BORDER, WALL, FIXED}
    need = {(r, c) for r in range(63) for c in range(64)
            if not _inbox(bx, r, c) and (r, c) not in dotset and (g[r][c] in barcolors or g[r][c] in (CAP, TIP))}
    caps = {(r, c) for (r, c) in need if g[r][c] == CAP}
    cands = []
    for (r, c) in sorted(caps):
        for d in "UDLR":
            s = _strip(d, r, c)
            if not all(p in caps for p in s):
                continue
            dr, dc = _DIRS[d]
            first = [(a + dr, b + dc) for a, b in s]
            ks = {col(*p) for p in first if p not in dotset} - {TIP}
            if len(ks) != 1:
                continue
            k = ks.pop()
            if k not in barcolors:
                continue
            for L in range(1, 70):
                for tip in (False, True):
                    if tip and L < 2:
                        continue
                    _, body = _body(k, d, r, c, L, tip)
                    if all(p in dotset or col(*p) == v for p, v in body.items()):
                        cands.append((k, d, (r, c), L, tip))
                sl = [(a + dr * L, b + dc * L) for a, b in s]
                if not all(p in dotset or col(*p) in (k, TIP) for p in sl):
                    break
    for (r, c) in sorted(need):
        k = g[r][c]
        if k not in barcolors:
            continue
        blk = [(r + i, c + j) for i in range(3) for j in range(3)]
        if all(p in dotset or col(*p) == k for p in blk):
            cands.append((k, "H", (r, c), 3, False))

    def cells_of(cd):
        k, d, (r, c), L, tip = cd
        if d == "H":
            return frozenset({(r + i, c + j) for i in range(3) for j in range(3)} - dotset)
        s, body = _body(k, d, r, c, L, tip)
        return frozenset((set(s) | set(body)) - dotset)

    cc = [(cd, cells_of(cd)) for cd in cands]
    cc = [(cd, cs) for cd, cs in cc if cs <= need]
    by_cell = {}
    for i, (cd, cs) in enumerate(cc):
        for p in cs:
            by_cell.setdefault(p, []).append(i)
    order = sorted(need)
    best = [None]
    sols = []

    def nh(ch):
        return sum(1 for x in ch if x[1] == "H")

    def rec(covered, chosen):
        if best[0] is not None and nh(chosen) > best[0]:
            return
        first = next((p for p in order if p not in covered), None)
        if first is None:
            h = nh(chosen)
            if best[0] is None or h < best[0]:
                best[0] = h; sols.clear()
            if not sols:
                sols.append(list(chosen))
            return
        for i in by_cell.get(first, []):
            cs = cc[i][1]
            if cs & covered:
                continue
            chosen.append(cc[i][0])
            rec(covered | cs, chosen)
            chosen.pop()

    rec(frozenset(), [])
    bars_ = sorted(sols[0]) if sols else []
    return {"boxes": bx, "diamonds": dm, "dots": dotset, "bars": bars_}


def _rects(g, w, bx, dots):
    cells = {(r, c) for r in range(63) for c in range(64) if g[r][c] == w and not _inbox(bx, r, c)}
    wild = {d for d in dots if any((d[0] + a, d[1] + b) in cells for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1)))}
    left = set(cells)
    avail = cells | wild
    out = []
    while left:
        r, c = min(left)
        best = None
        for horiz in (True, False):
            if horiz:
                if not all((r + i, c) in avail for i in range(3)):
                    continue
                n = 0
                while all((r + i, c + n) in avail for i in range(3)):
                    n += 1
                cand = (r, c, 3, n)
            else:
                if not all((r, c + j) in avail for j in range(3)):
                    continue
                n = 0
                while all((r + n, c + j) in avail for j in range(3)):
                    n += 1
                cand = (r, c, n, 3)
            if best is None or cand[2] * cand[3] > best[2] * best[3]:
                best = cand
        if best is None:
            n = 0
            while (r, c + n) in avail:
                n += 1
            best = (r, c, 1, n)
        t, l, h, ww = best
        for i in range(h):
            for j in range(ww):
                left.discard((t + i, l + j))
                avail.discard((t + i, l + j))
        out.append(best)
    return sorted(out)


def _pad(xs, n):
    xs = sorted(xs)[:n]
    return tuple(xs + [-1] * (n - len(xs)))


def _pack_bar(b):
    k, d, (r, c), L, tip = b
    return (((((r + 64) * 256 + (c + 64)) * 8 + _DCODE[d]) * 128 + L) * 16 + k) * 2 + (1 if tip else 0)


def _pack_rect(rc):
    t, l, h, w = rc
    return ((t + 64) * 256 + (l + 64)) * 16384 + h * 128 + w


def _box_info(g):
    out = []
    for (t, b, l, r) in _boxes(g):
        inside = [(rr, cc) for rr in range(t + 1, b) for cc in range(l + 1, r)]
        ks = {g[rr][cc] for rr, cc in inside} - {CAP, FILL, BORDER}
        ks2 = {g[rr][cc] for rr in range(t, b + 1) for cc in range(l, r + 1)} - {CAP, FILL, BORDER}
        kk = ks or ks2
        k = kk.pop() if len(kk) == 1 else 0
        blobs = _comps([(rr, cc) for rr in range(t, b + 1) for cc in range(l, r + 1) if g[rr][cc] == k])
        cents = sorted(((min(x[0] for x in bl) + max(x[0] for x in bl)) // 2,
                        (min(x[1] for x in bl) + max(x[1] for x in bl)) // 2) for bl in blobs)
        kind = 0 if len(cents) == 2 else 1
        i1 = cents[0] if cents else (0, 0)
        i2 = cents[1] if len(cents) == 2 else i1
        out.append((t, b, l, r, k, kind, i1, i2))
    return out


def bars(g):
    """条（含枢纽），见模块说明的打包法。"""
    return _pad([_pack_bar(b) for b in _parse(g)["bars"]], NB)


def walls(g):
    """色 1 的墙矩形。"""
    p = _parse(g)
    return _pad([_pack_rect(x) for x in _rects(g, WALL, p["boxes"], p["dots"])], NW)


def fixed(g):
    """色 15 的死物矩形。"""
    p = _parse(g)
    return _pad([_pack_rect(x) for x in _rects(g, FIXED, p["boxes"], p["dots"])], NF)


def boxes(g):
    """面板与图例框。"""
    out = []
    for (t, b, l, r, k, kind, i1, i2) in _box_info(g):
        v = ((((t * 64 + b) * 64 + l) * 64 + r) * 16 + k) * 2 + kind
        v = (((v * 64 + i1[0]) * 64 + i1[1]) * 64 + i2[0]) * 64 + i2[1]
        out.append(v)
    return _pad(out, NX)


def diamonds(g):
    """菱形中心。"""
    return _pad([r * 64 + c for r, c in _parse(g)["diamonds"]], ND)


def burned(g):
    """计数条第 63 行已烧（色 4）的格数。"""
    return sum(1 for v in g[63] if v == FILL)


# ---------------------------------------------------------------------------
# 隐藏量（修订 R1 + 潜在状态例外）
#   n    本关（或本关重开后）第几次 ACTION6：纯粹数动作，被拒的、点在空处的都算（计数条按它走）。
#   x7..x14  每种条色「贴着盘边、自由端伸出盘外」那根条（按打包值排第一根）伸在盘外、看不见的片数。
#        帧上看不见（盘外），按被检验的模型推演：它的真长 = 上一帧对应那根条的真长
#        （看得见的片数 + 上一帧的 x），若这一步点的是这一色的伸/缩图标且这一步没被整步拒绝（0..62 行有变化），再加减 3；
#        x = 2 × (真长 - 这一帧看得见的片数，不小于 0) + (尖藏在盘外那截里 ? 1 : 0)。
#        尖：上一帧对应那根条看得见尖，或上一帧 x 为奇数（尖已在盘外），就算这根条带尖；这一帧看不见尖而条被裁了，最低位记 1。
#        （返工 2026-09-29：原版只记长度，尖藏盘外后转回/缩回盘内时尖就丢了，语料 seq 738、1721 两行因此对不上。）
#        对应关系：这一色在上一帧只有一根就是它，否则取帽位与朝向都相同的那根。
#        Lean 的 stepRules 独立写同一条规律（真长随伸缩走、转动与平移不改长度、按盘边裁出看得见的片数）。
HIDDEN_INIT = {"n": 0, "x7": 0, "x8": 0, "x9": 0, "x10": 0, "x11": 0, "x12": 0, "x14": 0}
_XCOLORS = (7, 8, 9, 10, 11, 12, 14)


def _edge_touch(b):
    k, d, (r, c), L, tip = b
    if d == "D":
        return r + L == 62
    if d == "U":
        return r - L == 0
    if d == "R":
        return c + L == 63
    if d == "L":
        return c - L == 0
    return False


def _first_edge(bs, k):
    cand = sorted((_pack_bar(b), b) for b in bs if b[0] == k and _edge_touch(b))
    return cand[0][1] if cand else None


def _click_kind(g, action):
    if not action.startswith("ACTION6:"):
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split("|")[0].split(","))
    except Exception:
        return None
    for (t, b, l, r, k, kind, i1, i2) in _box_info(g):
        if kind == 0 and (y, x) == i1:
            return ("shrink", k)
        if kind == 0 and (y, x) == i2:
            return ("grow", k)
        if kind == 1 and (y, x) == i1:
            return ("rot", k)
    return None


def hidden_step(h, prev, action, nxt):
    out = dict(h)
    if action.startswith("ACTION6"):
        out["n"] = h["n"] + 1
    pb, nb = _parse(prev)["bars"], _parse(nxt)["bars"]
    changed = any(prev[r][c] != nxt[r][c] for r in range(63) for c in range(64))
    ck = _click_kind(prev, action)
    for k in _XCOLORS:
        key = "x%d" % k
        e = _first_edge(nb, k)
        if e is None:
            out[key] = 0
            continue
        same = [b for b in pb if b[0] == k]
        if len(same) == 1:
            p = same[0]
        else:
            p = next((b for b in same if b[1] == e[1] and b[2] == e[2]), None)
        if p is None:
            out[key] = 0
            continue
        hx = h[key] if _first_edge(pb, k) == p else 0
        true_prev = p[3] + hx // 2
        true_tip = bool(p[4]) or (hx % 2 == 1)
        delta = 0
        if changed and ck is not None and ck[1] == k and ck[0] in ("grow", "shrink"):
            delta = 3 if ck[0] == "grow" else -3
        hid = max(0, true_prev + delta - e[3])
        out[key] = 2 * hid + (1 if (hid > 0 and true_tip and not e[4]) else 0)
    return out
