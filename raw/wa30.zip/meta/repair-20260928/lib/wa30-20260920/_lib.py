"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

L1 首批实测（1 步）：ACTION1 让「色0 顶行(1x4) + 色14 余下3行(3x4)」拼成的 4x4 块
整体上移 4 格，其余全帧不动。由此先填 CELL 与 me，待 ACTION2-5 与 L2 撞实。

L6 补充（第 0 关 555 步前实测）：甜甜圈 = 4x4 的「环+芯」物件（环色 0/3/4，芯恒色9）。
环色即状态：4=自由、3=激活/松手态、0=被抓取跟随玩家。
胶囊 = 色9 环包色2 芯的一片区域，可走上去（第 0 关步 414/416 实测）。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401  —— 常用；不用可删

CELL = 4            # 已测：玩家块边长 4，各方向移动 4
PHASE = None        # 待实测：(行相位, 列相位)
DELTA = {}          # 待实测：{"ACTION2": (d_row, d_col), …}
BG = 1              # 底色（>1000 格，see 口径；apply 抠块时涂回它）


def me(g):
    """玩家块（4x4）的 (top_row, left_col)。假设：色0「头」+色14「身」联合占据 4x4。"""
    bb = block_bbox(g)
    if bb is None:
        return None
    return (bb[0], bb[1])


def block_bbox(g):
    """玩家块联合 bbox (top, left, bottom, right)。色0∪色14 的范围。"""
    hits = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v in (0, 14)]
    if not hits:
        return None
    rows = [r for r, _ in hits]
    cols = [c for _, c in hits]
    return (min(rows), min(cols), max(rows), max(cols))


def head(g):
    """头的 (top, left)。头=色0 的 1x4 条。"""
    hits = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == 0]
    if not hits:
        return None
    return (min(r for r, _ in hits), min(c for _, c in hits))


def facing(g):
    """头朝哪个方向：'up'/'down'/'left'/'right' 或 None。
    头是横条 → 贴顶/底（up/down）；是竖条 → 贴左/右（left/right）。定位不到返回 None。"""
    bb = block_bbox(g)
    if bb is None:
        return None
    hits = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == 0]
    if not hits:
        return None
    top, left, bottom, right = bb
    rows = {r for r, _ in hits}
    cols = {c for _, c in hits}
    if len(rows) == 1:          # 横条：顶或底
        return "up" if rows.pop() == top else "down"
    if len(cols) == 1:          # 竖条：左或右
        return "left" if cols.pop() == left else "right"
    return None


def walls(g):
    """阻挡格集合。待实测：L2 朝一个方向走到不动为止，看目标区里多了什么颜色。"""
    return None


# ---- 甜甜圈与胶囊（第 0 关末实测新增）----

def donuts(g, ring=None):
    """全部「环+芯」甜甜圈。返回 [(top_row, left_col, 环色)]；ring 给定则只留该环色。
    判据：4x4 对齐块，2x2 内芯全色9，环边同色且属于 {0,3,4}。
    最底一行格（行15）的第 4 像素行是计时条（第63行），环边判据跳过它——
    终局卡第4关步2088 拖着的那颗到了 (15,11)，底边被盖住，旧判据数不到它，
    规划器以为货丢了、移动概念以为没在拖行。"""
    out = []
    for r0 in range(0, 61, CELL):
        for c0 in range(0, 61, CELL):
            if not all(g[r0 + dr][c0 + dc] == 9 for dr in (1, 2) for dc in (1, 2)):
                continue
            edge = [g[r0 + dr][c0 + dc] for dr in range(CELL) for dc in range(CELL)
                    if (dr in (0, CELL - 1) or dc in (0, CELL - 1)) and r0 + dr != 63]
            if len(set(edge)) == 1 and edge[0] in (0, 3, 4):
                if ring is None or edge[0] == ring:
                    out.append((r0, c0, edge[0]))
    return out


def capsule_bbox(g):
    """胶囊 2 芯的 bbox (top, left, bottom, right)；没有色2 返回 None。"""
    hits = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == 2]
    if not hits:
        return None
    rows = [r for r, _ in hits]
    cols = [c for _, c in hits]
    return (min(rows), min(cols), max(rows), max(cols))


def capsule_region(g):
    """胶囊整体（9环1px包住2芯）的外沿 bbox；没有色2 返回 None。"""
    bb = capsule_bbox(g)
    if bb is None:
        return None
    return (bb[0] - 1, bb[1] - 1, bb[2] + 1, bb[3] + 1)


def cell_px(g, r, c):
    """格 (r,c) 的 4x4 像素，原样抄下来。"""
    return [[g[r * CELL + a][c * CELL + b] for b in range(CELL)] for a in range(CELL)]


def occupied_cells(g):
    """被可动物件（玩家块、甜甜圈、被偷的甜甜圈、鼹鼠）盖住的格——它们底下的地形帧上看不见。"""
    occ = {(r // CELL, c // CELL) for r, c, _ in donuts(g)}
    occ |= set(stolen(g)) | set(moles(g))
    b = block_top_left(g) or me(g)
    if b is not None:
        occ.add((b[0] // CELL, b[1] // CELL))
    return occ


def _pure2_cover_fill(g, occ):
    """被盖住、但多半是巢地板的格，交回给 bg_px 第三档：
    四邻里有 **≥2 个** 已认下的巢格（可见纯2，或本轮已补进来的被盖格）的被盖格，迭代到不动点。
    为什么门槛是 2 而不是 1：巢是成片的，站在巢里的格上下左右多半有两个同类；
    而贴着巢边缘、压在地板上的甜甜圈格通常只挨着一个，被挡在门外。
    为什么要迭代：巢的一整列全被盖住时（左上巢第1列四格全是甜甜圈），
    第一轮只认得出内侧那一列，认下之后外侧那一列才凑得齐两个同类邻居；
    不迭代就会把已认下的格的外沿错涂成 9（实测第7关步1281 的 4 像素停批就是这个）。
    不用 den_cells 那种「沿被盖格连通补全」：门槛 1 的爬法会把贴着巢的地板格吸进来。
    **已知漏的那一类**：巢的一整行/一整列全被盖住，且那一行每格只碰得到一个可见纯2 时（第7关步1282，
    巢的底行 (4,1)(4,2)(4,3) 分别只碰到正上方一格），本条一格都认不下来，32 像素停批。
    试过的补法都更差，逐个量过（读数见下）：让「碰到一个可见纯2 的被盖格」当线索、再要求 ≥2 个
    （线索或可见）邻居——这一条确实认下了那一行，但它同时把贴着巢边、并排坐在地板上的甜甜圈
    整排吸进来，第7关 177→307。所以留着这个洞，别用更差的规则去堵。
    全量语料实测（1885 个腾空格 30160 像素，越小越好）：不补 1444、爬法更差、矩形补更差、
    四邻≥1 更差、四邻≥2 不迭代 1316（旧语料）、**四邻≥2 迭代 1313（采用）**、
    级联线索版 1425、级联迭代 1426、级联矩形 1490。
    采用的这条逐关都不比不补差（第5关 304→268、第7关 272→177，其余六关一格不动）；
    级联那三条在第5关更好（250）而在第7关更坏（307/308/346），不是逐关不劣，所以否决。"""
    n = 64 // CELL
    vis = {(r, c) for r in range(n) for c in range(n) if cell_pure2(g, r, c)}
    out = set()
    while True:
        add = {p for p in occ - out
               if sum(1 for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))
                      if (p[0] + dr, p[1] + dc) in vis or (p[0] + dr, p[1] + dc) in out) >= 2}
        if not add:
            return out
        out |= add


def _socket_cover_fill(g, occ):
    """被盖住、但认得出是**容器格**的格，交回给 bg_px 第三档：
    可见空位格自己的某一边**内侧像素是色2**（不是色9 边框），说明容器块在那一边还没到头，
    隔壁那一格也是容器；隔壁正被物件盖着时就这么认下来。
    读的是这一格自己的 16 个像素，不是「谁挨着谁」——所以它不是 bg_px 教训2/教训3 说的那种
    连通补全，不会把贴着容器的地板甜甜圈格吸进来。
    为什么需要它：容器格被甜甜圈盖住时一个色2/色9 都不露，腾空时被第三档涂成底色1
    （终局卡第0关步1802：容器 (7,9) 上的货被拖走，押底色1、实际是 9 边框 + 2 内芯，16 格停批）。
    `home_cells` 那套「经甜甜圈四连通补全」不能拿来当这里的判据：全量语料实测它更差
    （4168 -> 4908 错像素，第2/3/4/5/6/7/8 关都更坏），因为它把坐在地板上、恰好贴着容器的
    甜甜圈格也认成容器，腾空时涂出假的 9/2。
    全量语料实测（3995 个腾空格 / 63920 像素，越小越好，逐关列）：
      不补 224/336/160/132/128/256/64/1788/1080 = 4168
      本条 132/ 54/ 15/132/  4/192/48/1084/ 878 = 2539（逐关都不劣，第3关持平）
    已知还漏的：整块容器全被盖满时一个可见空位都没有，本条一格也认不下来（off_home_clumped 划出的那类局面）。"""
    out = set()
    for (r, c) in empty_sockets(g):
        p = cell_px(g, r, c)
        sides = {(-1, 0): [p[0][j] for j in range(1, CELL - 1)],
                 (1, 0): [p[CELL - 1][j] for j in range(1, CELL - 1)],
                 (0, -1): [p[i][0] for i in range(1, CELL - 1)],
                 (0, 1): [p[i][CELL - 1] for i in range(1, CELL - 1)]}
        for (dr, dc), vals in sides.items():
            if vals and set(vals) == {2}:
                n = (r + dr, c + dc)
                if n in occ:
                    out.add(n)
    return out


def bg_px(g, r, c):
    """格 (r,c) 的底图像素（4x4 行列表）：物件挪走之后那一格该露出什么。
    三档，越靠前越可信：
      1. 这一格没被物件盖住 —— 地形就在帧上，原样抄。
      2. 被盖住 —— **紧邻**的左右（再上下）两格都没被盖住、纹样完全一致，就抄那张。
         围栏墙格被甜甜圈压着时只能这么还原：墙的斑点不是底色也不是胶囊那套9/2，
         第3关步845/855 两次 strict 停批都是这里（押底色1、实际是墙上的2）。
         两边都要看、且要一模一样，是为了别把「夹在两堵墙中间的地板」抄成墙。
         **只认紧邻，不许跳过被占的格往外找**：第3关步886 就是跳出来的祸——
         玩家旧格是围栏内地板，沿行往两边跳过两颗甜甜圈后，左右分别落到西墙和东墙，
         两张墙斑点一模一样，于是把地板抄成了墙，12 格 strict 停批。
         全量语料复核：跳过式 384 个错像素、紧邻式 372 个（748 次腾空格），紧邻严格更好。
      3. 都不成立 —— 退回老口径：胶囊格涂「外沿9、内部2」，其余涂 BG。
         这一档的格集合 = 帧上含 2 像素的格，**再并上被盖住、但多半是巢地板的格**
         （判据见 _pure2_cover_fill：四邻有 ≥2 个已认下的巢格，迭代到不动点），
         **以及被盖住、但从可见空位格的边框认得出是容器的格**（判据见 _socket_cover_fill）。
         后半句补的是巢：巢格被甜甜圈或玩家块盖着时自己一个 2 像素都不露，腾空时就被涂成底色1，
         同一类 strict 停批出过六次。补法不沿被盖住的格往外爬——爬法（den_cells 那套）
         会把贴着巢的地板甜甜圈格吸进来，全量语料实测反而更差：
         1885 个腾空格（30160 像素）不补错 1444、爬法更差、矩形补更差、四邻≥1 更差、
         四邻≥2 迭代 1313（采用）、级联线索版 1425/1426/1490（在第7关更坏，否决）；
         迭代版逐关都不比不补差（第5关 304→268、第7关 272→177，其余六关一格不动）。
         **还剩一个已知的洞**：巢的整行全被盖住时本条认不下来（第7关步1282），见 _pure2_cover_fill。
    教训1（第1关步631）：玩家/甜甜圈离开旧块要涂回这个地形，不是一律涂底色。
    教训2（第3关步776前）：这里的格集合不用「经甜甜圈连通补全」的 capsule_cells——
    那会把贴着 2 墙的地板甜甜圈格（围栏内圈）误补成胶囊，拖行擦除时涂出假 2/9。
    教训3（同上那次实测）：教训2 对 capsule_cells 成立，对 den_cells 一样成立——
    「沿被盖住的格往外爬」这个动作本身才是病根，换个种子不治病。"""
    n = 64 // CELL
    if not (0 <= r < n and 0 <= c < n):
        return [[BG] * CELL for _ in range(CELL)]
    occ = occupied_cells(g)
    if (r, c) not in occ:
        return cell_px(g, r, c)
    got = _bg_copy(g, r, c, occ)
    if got is not None and not _copy_is_wall(*got):
        return got[0]
    return _bg_fill(g, r, c, occ)


def _copy_is_wall(pat, axis):
    """抄来的纹样里一个色2 都没有 —— 那是堵死通路的墙，而这一格上正坐着东西，
    坐得上去就不是墙，所以这一抄不作数（退第3档）。
    由来两次 strict 停批，同在终局卡第5关、同在墙缝 (6,12)：
    步2187 A5 把蹲在缝里的皮15 贼清掉、步2191 玩家拖着货从缝里西行，两次都把上下两堵墙抄成了那一格的底图。
    为什么判据是「不含色2」而不是「谁占着这一格」：围栏格也常被货压着，而围栏带色2，
    抄邻居那一档正是为它留的；第二轮量过的「被拖着的货一律不抄」就是拆了围栏那档，第2、3关都更差。
    为什么不再看「正站着玩家或鼹鼠」：第三轮装过那一条（站着的一律不抄），第四轮被步2209 打掉——
    玩家从巢格 (6,14) 东行，同行两邻本可抄出巢的色2，那条却把这一抄也否了。
    全量语料逐关复核（probe_bg_variants*.py，4821 个腾空格，逐关错像素，越小越好）：
      原样（都不拦）           132/32/0/292/80/352/96/994/976 = 2954
      站着的一律不抄            38/32/0/292/80/208/96/994/336 = 2076
      站着的+沿列墙不抄（第三轮） 38/32/0/292/80/176/96/994/336 = 2044
      **本条：不含色2 就不抄**    38/32/0/276/80/176/96/994/336 = 2028（逐关都不劣于上面三条，采用）
      只拦沿列的墙              38/32/0/292/80/176/96/994/976 = 2684（第8关更差，否决）"""
    return not any(2 in row for row in pat)


def _bg_copy(g, r, c, occ):
    """bg_px 的第 2 档单独拿出来：紧邻两格都没被盖住且纹样一致就抄那张。
    返回 (4x4 纹样, 轴)，轴 0 = 沿行抄、1 = 沿列抄；抄不出返回 None。
    拆出来是为了能在全量语料上把「抄」和「填」分开计分（见 runs 里的 bg 变体探针）。"""
    n = 64 // CELL
    for axis, (dr, dc) in enumerate(((0, 1), (1, 0))):   # 先沿行补，再沿列补
        pats = []
        for s in (-1, 1):
            rr, cc = r + dr * s, c + dc * s
            ok = 0 <= rr < n and 0 <= cc < n and (rr, cc) not in occ
            pats.append(cell_px(g, rr, cc) if ok else None)
        if pats[0] is not None and pats[0] == pats[1]:
            return pats[0], axis
    return None


def _bg_fill(g, r, c, occ, cover=None):
    """bg_px 的第 3 档单独拿出来：胶囊/巢/容器涂 9/2，其余涂底色。
    `cover` 只给探针用：换一套「被盖住的巢格」判据来逐关比分，默认就是 _pure2_cover_fill。"""
    cells = {(i // CELL, j // CELL) for i in range(64) for j in range(64) if g[i][j] == 2}
    cells |= _pure2_cover_fill(g, occ) if cover is None else cover
    covered_sockets = _socket_cover_fill(g, occ)
    cells |= covered_sockets
    out = [[BG] * CELL for _ in range(CELL)]
    if (r, c) not in cells:
        return out
    # 区分容器和巢：容器是 home_cells() 里的，巢不是
    try:
        containers = home_cells(g)
    except:
        containers = set()
    containers = set(containers) | covered_sockets
    if (r, c) in containers:
        # 容器：外沿9、内部2。**边沿判定里，被物件盖住又在 home_cells 里的邻居不算「块外」**：
        # 容器块内部两格之间那条缝是色2，只有整块的外轮廓才是色9；隔壁container被一颗甜甜圈
        # 盖得一个像素不露时，现行口径把它当块外、于是把缝画成色9。第1关步1870（tid 85c467070b9049ab）
        # 玩家从容器格走开，右邻压着一颗货，右沿三格押9实为2，3 格 strict 停批。
        # 只放 home_cells 认下的那些（它那套四连通补全在这里够用且更保守）；无条件放软反而更差。
        # 全量语料实测（4106 个腾空格 / 65696 像素，逐关列，越小越好）：
        #   现行 132/60/15/132/ 4/192/48/1084/878 = 2545
        #   无条件放软 153/32/ 0/132/ 0/198/51/1056/878 = 2500（第0/5/6关更差，否决）
        #   矩形补全 = 3521（远更差，否决）
        #   本条(home) 132/32/ 0/132/ 0/192/48/1022/872 = 2430（逐关都不劣，采用）
        def _inside(n):
            return n in cells or (n in occ and n in containers)
        for dr in range(CELL):
            for dc in range(CELL):
                edge = ((dr == 0 and not _inside((r - 1, c)))
                        or (dr == CELL - 1 and not _inside((r + 1, c)))
                        or (dc == 0 and not _inside((r, c - 1)))
                        or (dc == CELL - 1 and not _inside((r, c + 1))))
                out[dr][dc] = 9 if edge else 2
    else:
        # 巢：全是色2
        for dr in range(CELL):
            for dc in range(CELL):
                out[dr][dc] = 2
    return out


def bg_unsure(g, r, c):
    """格 (r,c) 腾空之后露出什么，bg_px **没有依据**，只是在涂底色——这种格让概念闭嘴别押。
    判据（四条全中才算「没依据」）：这一格被物件盖着、抄不出邻居纹样（第2档空）、
    第3档也没把它认成胶囊/巢/容器（返回纯底色），**但它八邻里有可见纯2 格**——
    也就是它正贴着一片胶囊/巢/容器的边，涂底色只是赌它不在那一片里。

    由来：终局卡第7关步2417（第12次意外）。左上巢的 (3,3) 被拖走的货腾空，
    四邻里只有正上方 (2,3) 是可见纯2（(3,2) 压着货、(4,3) 站着玩家、(3,4) 是地板），
    凑不够 _pure2_cover_fill 的「≥2 个同类」门槛，于是押底色1、实为巢地板色2，32 像素停批。
    这正是 _pure2_cover_fill 文档里写明、且历轮实测堵不上的那个洞。

    先试过继续改判据：把对角也算进「同类」计数（probe_bg_variants7.py，5546 个腾空格逐关错像素）：
      现行（四邻门槛2）  38/32/276/80/192/224/1381/336 = 2559
      八邻门槛2          38/32/276/80/368/224/5881/592 = 7491
      八邻门槛3          38/32/276/80/272/224/3457/352 = 4731
      四邻2 或 1正+2斜   38/32/276/80/192/224/3457/336 = 4635
    三条都在第7关成倍变坏（斜着贴巢角的地板货被整片吸进来），全否决——洞照旧留着。

    于是换个问法：不改判据，改开口范围（probe_bg_variants8.py，把走第三档且被涂成纯底色的
    5218 个腾空格按「八邻有没有可见纯2」分类）：
      八邻都没有        4729 格 / 错 828 像素 / 4675 格一格不错
      四邻有            296 格 / 错 960 像素 / 236 格一格不错
      只有对角有        193 格 / 错 400 像素 / 168 格一格不错
    后两类只占 8.8% 的格，却背了 62% 的错像素（第7关占 1088/1360）。所以在这 489 格上闭嘴：
    放弃 404 格本来押得对的，换掉 1360 个错像素。
    和 mole_may_enter 是同一种动作——把「说不准」的那一格让出来，不是预测它一定是什么。"""
    n = 64 // CELL
    if not (0 <= r < n and 0 <= c < n):
        return False
    occ = occupied_cells(g)
    if (r, c) not in occ:
        return False
    got = _bg_copy(g, r, c, occ)
    if got is not None and not _copy_is_wall(*got):
        return False
    if any(v != BG for row in _bg_fill(g, r, c, occ) for v in row):
        return False
    return any(cell_pure2(g, r + dr, c + dc)
               for dr in (-1, 0, 1) for dc in (-1, 0, 1)
               if (dr, dc) != (0, 0) and 0 <= r + dr < n and 0 <= c + dc < n)


def bbox_has(bb, r0, c0):
    """4x4 块 (r0,c0) 是否整体落在 bbox bb 内。"""
    if bb is None:
        return False
    top, left, bottom, right = bb
    return top <= r0 and c0 >= left and r0 + CELL - 1 <= bottom and c0 + CELL - 1 <= right


# ---- 鼹鼠与被偷的甜甜圈（第 1 关 560-585 步实测）----

def mole(g):
    """鼹鼠：4x4 全色12 块，每步走一格的巡逻物。返回格 (row, col) 或 None。
    只回行优先扫描的第一只——第3关起场上有多只，要全体用 moles()。"""
    out = moles(g)
    return out[0] if out else None


MOLE_COLORS = (12, 15)   # 鼹鼠的皮：第1关起是色12，第5关出现色15 的同类（见 _is_mole）
ALERT_RING = 11          # 玩家贴到它四邻格时，鼹鼠外圈 12 像素换成这个色，内芯 2x2 还是本来的皮色


def _mole_color(g, r0, c0):
    """(r0,c0) 起的 4x4 是不是鼹鼠；是就回它的皮色，不是回 None。
    两种皮：整块同色（常态），或外圈 ALERT_RING、内芯皮色（玩家正相邻时，见 mole_alert_ring_when_adjacent）。
    第5关步1090 玩家走到 (6,11)，(6,12) 的鼹鼠当场 12 个边像素 15→11，只剩内芯还是15；
    步1092 玩家退开一格，又 11→15 变回实心。只认实心的旧版在这两帧里瞎掉，后果有二：
    move_refused 不知道那一格有鼹鼠，押「玩家东移」而世界整步不动（步1091，44 格 strict 停批）；
    occupied_cells 也漏了它，bg_px 于是拿「上下两邻格纹样一致」去补玩家腾出来的走廊格，
    而走廊是墙上宽一格的缺口，上下两邻正好都是墙，把地板补成了墙（步1092，16 格 strict 停批）。
    一格宽的缺口是 bg_px 那条「两侧一致就抄」的天然陷阱，这里靠把遮挡物认全来绕开。"""
    last = 63 if r0 + CELL > 63 else r0 + CELL
    px = [(r, c0 + dc) for r in range(r0, last) for dc in range(CELL)]
    col = g[r0][c0]
    if col in MOLE_COLORS and all(g[r][c] == col for r, c in px):
        return col
    if col != ALERT_RING:
        return None
    core = {g[r][c] for r, c in px if 1 <= r - r0 <= 2 and 1 <= c - c0 <= 2}
    if len(core) != 1:
        return None
    inner = core.pop()
    if inner not in MOLE_COLORS:
        return None
    edge = [(r, c) for r, c in px if not (1 <= r - r0 <= 2 and 1 <= c - c0 <= 2)]
    return inner if all(g[r][c] == ALERT_RING for r, c in edge) else None


def alert_moles(g):
    """正穿着「警觉皮」（外圈 ALERT_RING）的鼹鼠格坐标。"""
    return [(r0 // CELL, c0 // CELL) for r0 in range(0, 61, CELL) for c0 in range(0, 61, CELL)
            if _mole_color(g, r0, c0) is not None and g[r0][c0] == ALERT_RING]


def mole_skins(g):
    """每只鼹鼠的 格坐标 -> 皮色（内芯那个色；实心时就是整块的色）。
    两种皮色的行为不一样（见 mole_alert_ring_when_adjacent），所以要分得出来。"""
    return {(r0 // CELL, c0 // CELL): _mole_color(g, r0, c0)
            for r0 in range(0, 61, CELL) for c0 in range(0, 61, CELL)
            if _mole_color(g, r0, c0) is not None}


def _is_mole(g, r0, c0):
    """(r0,c0) 起的 4x4 是不是鼹鼠：见 _mole_color，两种皮都算。
    最后一格行(像素60-63)只查前 3 行——第63行是计时条，它盖掉最下面一排鼹鼠的最后一像素行：
    第3关步955 实测，送货到(14,10)的那只走到(15,10)后 moles() 当场看不见它，
    mole_carry_above 以为「有货在搬运却没有鼹鼠」判了 FALSE。那不是规律错，是这个词瞎了。
    第二次瞎（第5关步1078-1081，反例 7f9a6ec4eee9b754 等三条）：这一关的搬运物是**色15**，
    16 像素实心块，每步走一格，路过 (4,7) 就把坐在容器上的那颗甜甜圈变成环5 挟走——
    行为和色12 那只一模一样，只是换了张皮。只认色12 的旧版于是「看见环5 却找不到鼹鼠」，
    一步打翻三条概念。教训同上一次：这个词的正确性条件是「对任意帧成立」，
    把颜色写死在里面，等于假定这一局只有一种搬运物。"""
    return _mole_color(g, r0, c0) is not None


def moles(g):
    """全部鼹鼠：所有 4x4 鼹鼠块的格坐标列表（皮色见 MOLE_COLORS，警觉皮见 _mole_color）
    （第3关实测色12 三只：两只驻扎一只巡逻搬运；第5关出现色15 一只）。"""
    return [(r0 // CELL, c0 // CELL)
            for r0 in range(0, 61, CELL) for c0 in range(0, 61, CELL) if _is_mole(g, r0, c0)]


def empty_sockets(g):
    """可见的空位格：4x4 像素里**同时**见得到色2 和色9、且没有别的颜色的格。
    盖住就数不到，所以这个函数数的是**可见的空位**，不是这一关总共有几个位。
    两次修：
    旧判据一「至少8个色9 + 至少4个色2」，第4关整关数出 0 个——那一关的容器是一片
    2x4 的连片格，相邻两格共用边框，靠内的格只剩一列色9（4个），旧门槛把整片容器判成不存在。
    旧判据二只要求「有色2、没别的颜色」，于是把纯色2 的格也收了进来。第5关步1077 打翻它：
    那一关有两块 2x2 的色2 区，(3,7)(3,8)(4,7)(4,8) 那块四周有整圈色9 边框，
    (6,13)(6,14)(7,13)(7,14) 那块 32 个像素里一个色9 都没有；把后者当容器，
    坐在 (7,14) 的那颗就被算成已归位，于是概念断言 A5 那一步换关，世界说不换
    （反例 58925d4e2a29162f）。所以**色9 边框才是容器的标志，光有色2 不算**。
    全量语料复核：新旧两种读法只在第5关那一帧上不同，四次换关帧的读数一字不变。
    已知的窄处：这条要求每一格自己看得见色9，等于假定容器不超过两格宽（宽到有内芯格的
    容器，中间那格碰不到边框会被漏掉）。见过的容器都是 2 格宽，宽的还没遇到。"""
    out = []
    for r in range(64 // CELL):
        for c in range(64 // CELL):
            vals = {g[r * CELL + i][c * CELL + j] for i in range(CELL) for j in range(CELL)}
            if 2 in vals and 9 in vals and vals <= {2, 9}:
                out.append((r, c))
    return out


def home_cells(g):
    """容器格集合的**下界**：可见空位格，加上经甜甜圈四连通补全的格。
    甜甜圈把它坐的那一格盖住之后，那一格的色2/色9 就看不见了，只能靠「贴着已知容器格」补回来。
    它是下界不是等号：容器被盖满时（可见空位为 0）这里返回空集，
    此时根本读不出容器在哪——调用方必须自己先查 empty_sockets 非空。"""
    cells = set(empty_sockets(g))
    if not cells:
        return cells
    dcells = {(r // CELL, c // CELL) for r, c, _ in donuts(g)} | set(stolen(g))
    changed = True
    while changed:
        changed = False
        for (r, c) in dcells - cells:
            if any((r + dr, c + dc) in cells for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                cells.add((r, c))
                changed = True
    return cells


def all_donut_cells(g):
    """场上全部甜甜圈所在的格（含被鼹鼠搬着的环5 那颗）。"""
    return [(r // CELL, c // CELL) for r, c, _ in donuts(g)] + list(stolen(g))


def off_home_clumped(g):
    """「在不在容器上」这一帧读不读得出来：不在 home_cells 也不在 den_cells 的甜甜圈里，
    只要有两颗四邻相接，就返回 True——它们可能正坐在一整块被盖满的容器上，单帧无从分辨。
    第7关末尾抽出：上半场 2x4 的容器块被 8 颗甜甜圈盖满，连一格色2 都露不出来，
    home_cells 补不出它，8 颗全被读成「在容器外」，而那一步世界换了关。
    甜甜圈把脚下 16 个像素盖得干干净净（环+芯，没有一个像素透出底色），所以这不是读法能修的，
    只能把这种局面划出 scope。单颗孤零零地站在容器外的，仍按「不在容器上」算。"""
    home = home_cells(g)
    den = den_cells(g)
    off = {d for d in all_donut_cells(g) if d not in home and d not in den}
    return any((r + dr, c + dc) in off for (r, c) in off for dr, dc in ((1, 0), (0, 1)))


def stolen(g):
    """被鼹鼠搬着的甜甜圈：环5+芯9 的 4x4 块（玩家动不了它）。返回格坐标列表。

    最底一行格（行15）的第 4 像素行是计时条（第63行），环边判据跳过它——和 donuts() 同一道口径。
    由来：终局卡第7关步2773，扛货的鼹鼠走到 (15,11)，它驮的那颗落到 (15,10)，
    底边被计时条涂成色4，环边「全是5」当场不成立，这个词就数不到它了；
    mole_carry_above 于是走进「货没了又找不到随行位」判了 FALSE。
    这是同一个坑的第三次：moles() 栽过两次（第3关送最后一颗、第5关换皮那次）。
    全语料 5578 张帧里，这一改只有 1 张的读数变了，就是上面这一张。"""
    out = []
    for r0 in range(0, 61, CELL):
        for c0 in range(0, 61, CELL):
            core_ok = all(g[r0 + dr][c0 + dc] == 9 for dr in (1, 2) for dc in (1, 2))
            ring = [g[r0 + dr][c0 + dc] for dr in range(CELL) for dc in range(CELL)
                    if (dr in (0, CELL - 1) or dc in (0, CELL - 1)) and r0 + dr != 63]
            if core_ok and len(set(ring)) == 1 and ring[0] == 5:
                out.append((r0 // CELL, c0 // CELL))
    return out


def capsule_cells(g):
    """胶囊格集合：有 2 芯像素的格，加上经甜甜圈 4 邻接连通补全的格。
    胶囊格被甜甜圈/鼹鼠整个盖住时 2 扫描只看得到空着的格，靠连通把盖住的格补回来。
    注意口径：donuts() 返回像素左上角，这里换算成格坐标再参与连通。"""
    base = set()
    for i in range(64):
        for j in range(64):
            if g[i][j] == 2:
                base.add((i // CELL, j // CELL))
    if not base:
        return set()
    dcells = {(r // CELL, c // CELL) for r, c, _ in donuts(g)} | set(stolen(g))
    cells = set(base)
    changed = True
    while changed:
        changed = False
        for (r, c) in dcells - cells:
            if any((r + dr, c + dc) in cells for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                cells.add((r, c))
                changed = True
    return cells


def den_cells(g):
    """巢格集合的**下界**：可见的纯色2 格，加上经甜甜圈/环5 四连通补全的格。
    与 home_cells 同构，只是种子换成 cell_pure2（纯2 是巢，2+9 才是容器——见 empty_sockets 的两次修）。
    巢被盖满时可见纯2 为 0，这里返回空集，调用方要自己当 NA 处理。
    第7关抽出：两种皮色的鼹鼠送货目的地不同（色12 送容器、色15 送巢），要分得出巢和容器才写得了那条。"""
    cells = {(r, c) for r in range(16) for c in range(16) if cell_pure2(g, r, c)}
    if not cells:
        return cells
    dcells = {(r // CELL, c // CELL) for r, c, _ in donuts(g)} | set(stolen(g))
    changed = True
    while changed:
        changed = False
        for (r, c) in dcells - cells:
            if any((r + dr, c + dc) in cells for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                cells.add((r, c))
                changed = True
    return cells


def held_new_cells(prev, action):
    """拖行甜甜圈在本步的目的格列表（格坐标）；没有拖行(环0)或动作不是四向移动返回 []。
    donuts() 给像素左上角，这里换算成格；action 用前缀匹配（装置传入的动作串可能带后缀）。
    第1关步645教训：这函数曾返回像素坐标，apply 拿格坐标去 `in` 永远不中，
    拖行步旧格一律被涂成底图，被 strict 连停三批——单位不匹配比动作串匹配更早发作。"""
    held = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]
    if len(held) != 1:
        return []
    dv = {"ACTION1": (-1, 0), "ACTION2": (1, 0),
          "ACTION3": (0, -1), "ACTION4": (0, 1)}.get((action or "")[:7])
    if dv is None:
        return []
    (r, c) = held[0]
    return [(r + dv[0], c + dv[1])]


def mole_may_enter(prev, cell):
    """玩家挪走后空出来的旧格，鼹鼠（或它驮着的那颗货）会不会走进去——prev 帧上它就在旧格的四邻就算「会」。
    由来：终局卡第4关步2064 ACTION2，旧格被四条移动概念画成底图，实则一只鼹鼠从隔壁走了进来（押1 实12）。
    语料里玩家真挪了 1564 步，鼹鼠进旧格 3 步（步1289、1290、2064），三次 prev 上它都贴着旧格；
    四邻有鼹鼠的移动步一共 29 步。所以移动概念的 apply 在这 29 类局面上不画旧格，其余照画。
    鼹鼠怎么走册子里没有，这里只是把「说不准」的那一格让出来，不是预测它一定进。

    补一条（终局卡第7关步2567，第15次意外）：盖住旧格的不一定是鼹鼠本身，也可能是它**驮着的那颗货**——
    mole_carry_above 说货画在鼹鼠正上方那一格。那一步 ACTION3 空出 (3,9)，一只贼从 (4,10) 走到 (4,9)
    并顺手拎起 (3,10) 的货，货就画进了 (3,9)，押底色1 实为环5，整格 16 格全错。
    prev 上那只贼离旧格是 2 格，旧判据够不着。所以判据从「旧格四邻有鼹鼠」扩成
    「旧格四邻、**或旧格正下方那一格的四邻**有鼹鼠」——正下方站进去，它的货就顶上来。
    不要求它当时已经驮着：这一次就是同一步里拎起来的。"""
    near = set(moles(prev)) | set(stolen(prev))
    below = (cell[0] + 1, cell[1])
    return any(abs(m[0] - cell[0]) + abs(m[1] - cell[1]) == 1 or
               abs(m[0] - below[0]) + abs(m[1] - below[1]) <= 1 for m in near)


def thief_may_strip(g, r, c):
    """拖着的货落在格 (r,c) 上，这一步会不会被打脱手——说不准就返回 True，让概念别押环色。
    判据：g 上有皮色15 的鼹鼠站在 (r,c) 或与它正相邻（曼哈顿 ≤ 1）。
    由来：终局卡第7关步2474（第13次意外）。货被从 (2,5) 拖到 (3,5)，(4,5) 蹲着一只皮15，
    环 0→3 脱了手，正好错 12 格——环的外圈是 12 格，芯的 2x2 是色9，两种环色下都一样。
    全量语料里「拖行落点紧贴皮15」共 10 次（probe_intercept.py）：那只贼当步挪了窝的 9 次货都没脱手，
    原地不动的那 1 次脱了手。分得干干净净，但**「它下一步动不动」在押注时看不出来**，
    所以这一档不去改判据，只闭嘴：芯照押，外圈 12 格让出来。
    「贼不动就出手」这件事本身写成了走闸的概念 thief_strips_drag，由它去挨打。"""
    for (mr, mc), s in (mole_skins(g) or {}).items():
        if s == 15 and abs(mr - r) + abs(mc - c) <= 1:
            return True
    return False


def drag_paint(prev, out, a, action):
    """拖行态的全套重画，画进 out（apply 的稀疏输出）：擦甜甜圈旧位、画甜甜圈新位。
    教训（第1关步646）：act --predict 逐步把 apply 输出叠加在前一帧上串链，只画不擦——
    甜甜圈旧位留残影，下一步 held_new_cells 数出两个环0 就闭嘴，玩家旧格被涂成底图，
    strict 连停数批。a = 玩家像素左上；动作串由调用方 startswith 保证。
    玩家旧格若是甜甜圈目的格，这里已画成甜甜圈，调用方要跳过底图。
    落点紧贴皮15 时只画芯、不画环外圈（见 thief_may_strip，终局卡第7关步2474 第13次意外）。"""
    held = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]   # donuts() 给像素，先换算成格
    if len(held) != 1:
        return
    dv = {"ACTION1": (-1, 0), "ACTION2": (1, 0),
          "ACTION3": (0, -1), "ACTION4": (0, 1)}.get((action or "")[:7])
    if dv is None:
        return
    (r, c) = held[0]
    if (r, c) != (a[0] // CELL, a[1] // CELL):   # 旧位=玩家旧位时反正要整格重画
        # 两道弃权闸，和玩家旧格那一格完全同口径：底图没依据（bg_unsure）不押，
        # **鼹鼠可能走进来（mole_may_enter）也不押**。
        # 第二条是终局卡第7关步2816（第18次意外，tid 8d1180dc78c937f6）补上的：
        # 玩家 (2,7) 拖着 (2,8) 那颗按 ACTION1 上行，货的旧格 (2,8) 被擦成底色1，
        # 而 (3,8) 上的皮15 贼当步北上走进了 (2,8)，16 格全押成 1、实为 15。
        # 玩家旧格早在 v10 就补过同一条闸（「鼹鼠会走进刚空出来的格」），
        # **货的旧格却一直只有 bg_unsure 这一半**——两处腾空的格，凭什么只防一处。
        # 这也是 cut_at_ghost 的 i==0 判据一直比生成器严的地方：它两条都问，生成器只问了一条。
        if not bg_unsure(prev, r, c) and not mole_may_enter(prev, (r, c)):
            bg = bg_px(prev, r, c)
            for dr in range(CELL):
                for dc in range(CELL):
                    out[(r * CELL + dr, c * CELL + dc)] = bg[dr][dc]
    nr, nc = r + dv[0], c + dv[1]
    new = paint_donut(nr, nc, 0)
    if thief_may_strip(prev, nr, nc):
        core = paint_donut(nr, nc, 9)            # 芯是色9，两种环色下都一样
        new = {k: v for k, v in new.items() if core.get(k) == v}   # 只留两种环色下相同的那几格
    out.update(new)


def paint_donut(r, c, ring):
    """格 (r,c) 的 4x4 甜甜圈图样 {(px_row,px_col): 色}：外圈环 ring、中心 2x2 芯 9。
    最底一行格（行15）的第 4 像素行被计时条盖着，不画（见 mask_timer_row）。"""
    out = {}
    for dr in range(CELL):
        for dc in range(CELL):
            out[(r * CELL + dr, c * CELL + dc)] = 9 if (dr in (1, 2) and dc in (1, 2)) else ring
    return mask_timer_row(out)


TIMER_ROW = 63


def mask_timer_row(out):
    """把 apply 输出里落在计时条那一像素行（第63行）的格去掉。
    由来：终局卡第4关步2088 玩家第一次走到最底一行格（行15，语料里此前 0 次），
    整块的第 4 像素行是计时条（色7/色4），移动概念按底图/身色押了 8 格，全落空。
    计时条自己怎么变归 timer 那一类概念管；这里只是让物件概念别对那一行开口。"""
    if out is None:
        return None
    return {k: v for k, v in out.items() if k[0] != TIMER_ROW}


def block_top_left(g):
    """拖行态的玩家块 (top,left)：色14 bbox 按头朝向还原成 4x4。
    me() 的色0∪色14 联合 bbox 在拖行时被环0甜甜圈撑大（第3关步776/785实测：
    玩家与甜甜圈不对齐时 top-left 偏到甜甜圈格，apply 把整块糊错12格）。
    头条总在 14 bbox ±1 像素内，甜甜圈环隔着一整格（4px），互不干扰。"""
    hits14 = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == 14]
    if not hits14:
        return None
    top = min(r for r, _ in hits14)
    bottom = max(r for r, _ in hits14)
    left = min(c for _, c in hits14)
    right = max(c for _, c in hits14)
    f = head_in_block(g)
    if f == "up":
        top -= 1
    elif f == "down":
        bottom += 1
    elif f == "left":
        left -= 1
    elif f == "right":
        right += 1
    else:
        return None      # 头定位不到（拖行态没见过），调用方自行退回 NA/None
    return (top, left)


def head_in_block(g):
    """玩家块内色0 头条 → 朝向 'up'/'down'/'left'/'right' 或 None。
    只认色14 身体的形状与格对齐，不去数色0 像素：抓取态甜甜圈的环也是色0，
    上一版靠「14 的 bbox 外扩一圈找 0」定位，甜甜圈贴着玩家那一侧时（拖行 offset=±1 格）
    它自己的环边正好落在外扩的那一圈里，rows/cols 都不唯一 → 返回 None，
    拖行分支整批闭嘴（第3关步855预测时实测：头朝左、货在正上方，块定位不出来）。
    玩家块恒 4x4 且格对齐（每步走整 CELL），头占其中一行/一列，色14 占另外 3 行/列——
    由 14 的 bbox 是 4x3 还是 3x4、以及它的 left/top 对不对得上格边界，就能唯一定出头在哪边。"""
    hits14 = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == 14]
    if not hits14:
        return None
    rs = [r for r, _ in hits14]
    cs = [c for _, c in hits14]
    top, bottom, left, right = min(rs), max(rs), min(cs), max(cs)
    h, w = bottom - top + 1, right - left + 1
    if h == CELL and w == CELL - 1:
        if left % CELL == 0:
            return "right"          # 14 占 [L,L+2]，头在 L+3
        if (left - 1) % CELL == 0:
            return "left"           # 14 占 [L+1,L+3]，头在 L
        return None
    if h == CELL - 1 and w == CELL:
        if top % CELL == 0:
            return "down"           # 14 占 [T,T+2]，头在 T+3
        if (top - 1) % CELL == 0:
            return "up"             # 14 占 [T+1,T+3]，头在 T
        return None
    # 最底一行格（行15）：块的第 4 像素行被计时条盖住，14 少一行（终局卡第4关步2088 第一次走到这一行）。
    if bottom == 62 and top % CELL == 0:
        if h == CELL - 1 and w == CELL - 1:
            if left % CELL == 0:
                return "right"      # 14 占 [L,L+2]×3 行，头在 L+3（底行看不见）
            if (left - 1) % CELL == 0:
                return "left"
            return None
    if bottom == 62 and h == CELL - 2 and w == CELL and (top - 1) % CELL == 0:
        return "up"                 # 14 占 [T+1,T+2]（T+3 被盖），头在 T
    return None


def cell_has2(g, r, c):
    """格 (r,c) 里有没有 2 像素（胶囊/围栏墙的斑点）；出帧算没有。"""
    if not (0 <= r <= 63 // CELL and 0 <= c <= 63 // CELL):
        return False
    return any(g[r * CELL + a][c * CELL + b] == 2 for a in range(CELL) for b in range(CELL))


def cell_pure2(g, r, c):
    """格 (r,c) 的 16 个像素**全是**色2（鼹鼠的巢那种纯色块）；出帧算不是。
    和 cell_has2 的差别是通行：杂色2（胶囊的9 边、围栏墙的底色斑）挡人，纯色2 不挡——
    见概念 color2_blocks_move_unless_pure2（第5关步1136 实测玩家整块走进 (6,13)）。"""
    if not (0 <= r <= 63 // CELL and 0 <= c <= 63 // CELL):
        return False
    return all(g[r * CELL + a][c * CELL + b] == 2 for a in range(CELL) for b in range(CELL))


def timer_px(g):
    """计时条剩余长度 = 最后一行(第63行)的色7 像素数。
    第63行是一条横贯全屏的条：左段色7、右段色4，色7 段随步数缩短，缩到 0 就没了。
    这个读法只数色7，不假设它一定连续、也不假设它一定从左端起——
    真要核对连续性，得另写一条概念拿 bbox 和这个计数对。"""
    return sum(1 for v in g[63] if v == 7)


def move_refused(prev, action, ctx=None):
    """玩家这一步会不会被挡住整步不走（挡住时 apply 该返回 None，别画一次不存在的移动）。
    四种挡：(0) 目的格是纯色5（墙）——第7关步1382 实测，玩家(7,1)往北(6,1)是纯色5，整步不走；
    (1) 目的格含色2 **但不是纯色2**——分层依据 capsule_walkable（第0/1关整块走得进，第2关起走不进）
        与 color2_blocks_move_unless_pure2（第2关起纯色2 的巢照走，第5关步1136 实测）；
    (2) 目的格上有一颗不是自己攥着的甜甜圈（环3/4/5）——那是「顶住」，玩家原地不动、靶激活，
        第0关步535/550 实测，环0(攥在手里的那颗)不算，拖行时它本来就该跟着走。
        环5（被鼹鼠扛着的那颗）同样挡人，依据 stolen_donut_blocks_move（第6关步1156 实测）：
        它不在 donuts() 里而在 stolen() 里，所以要单独并进来，漏了就会押着玩家走进鼹鼠的货里。
    (3) 玩家的目的格、或被拖甜甜圈的目的格上蹲着鼹鼠——整步不走，依据 mole_blocks_move。
    ctx 给不出 level_prev 时 (1) 保守不拦（早两关的通行是实测过的），(0)(2)(3) 照拦。"""
    dv = {"ACTION1": (-1, 0), "ACTION2": (1, 0),
          "ACTION3": (0, -1), "ACTION4": (0, 1)}.get((action or "")[:7])
    if dv is None:
        return False
    dragging = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]
    a = block_top_left(prev) if dragging else me(prev)
    if a is None:
        return False
    dst = (a[0] // CELL + dv[0], a[1] // CELL + dv[1])

    # (0) 纯色5墙：第7关步1382实测
    if 0 <= dst[0] < 16 and 0 <= dst[1] < 16:
        if all(prev[dst[0]*CELL + dr][dst[1]*CELL + dc] == 5
               for dr in range(CELL) for dc in range(CELL)):
            return True

    ms = set(moles(prev)) | set(stolen(prev))   # 鼹鼠本体 与 它扛着的环5，都是实心阻挡
    if dst in ms:
        return True                      # 撞上鼹鼠或它的货：整步不走
    if len(dragging) == 1:
        held_dst = (dragging[0][0] + dv[0], dragging[0][1] + dv[1])
        if held_dst in ms:
            return True                  # 拖着的货撞上鼹鼠/它的货：同样整步不走（第4关步962）
    if dst in {(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring != 0}:
        return True                      # 顶住一颗甜甜圈：整步不走
    lvl = ctx.get("level_prev") if ctx else None
    if lvl in (0, 1) or lvl is None:
        return False
    return (cell_has2(prev, dst[0], dst[1])
            and not cell_pure2(prev, dst[0], dst[1]))


# =====================================================================================
# 修复副本（meta/repair-20260928，2026-09-29）追加。以上部分逐字未动（除了最末 _RETIRED 的包装）。
#
# 抽象状态改成三块：
#   ① 可见读数（只看这一帧的像素）：pl（玩家格与朝向）、dn（每颗甜甜圈的格与环色，含被扛的环5）、
#      ml（每只鼹鼠的格与皮码：皮12 / 皮15 实心 / 皮15 警觉外圈11）、timer_px（原有，照旧）。
#   ② 隐藏状态 h_*（hidden_step）：本关步数 n（计时条要用）；鼹鼠按「开关那一帧的读序」编的身份槽 m0..m3，
#      每槽记 格 + 皮 + 扛着的货在哪一侧。身份靠「每步挪 ≤1 格」逐帧追（感知）；扛货的归属多数帧上看得见
#      （环5 只贴着一只鼹鼠），看不见的几种（贼夺帮手的货、贼夺玩家攥着的货后货被玩家正对着画成环3、
#      两只鼹鼠同贴一颗货）按被检验的规律推（潜在状态例外，见交回）。
#   ③ 每关常数 k_*（LEVEL_CONST）：地形位掩码（墙 / 围栏 / 容器 / 巢）与计时条预算 B。
#
# 原有的帧 → 值读数（下面 _RETIRED 那一串）不再进状态：它们都是帧的函数，而 level + k_* + pl + dn + ml + timer_px
# 定了整帧（证明脚本 meta/repair-20260928/_scratch/wa30-20260920/p_retire.py，结果写在交回里）。
# 函数本体一字未改，只是签名包成 (*a, **k)，概念文件照旧能调。
# =====================================================================================

_FACE = {"up": 0, "down": 1, "left": 2, "right": 3}
DN_SLOTS = 14          # 全语料一帧里甜甜圈（含环5）最多 13 颗（第 7 关），留一格余量
ML_SLOTS = 4           # 全语料一帧里鼹鼠最多 4 只（第 7 关）


def pl(g):
    """玩家块所在的格与朝向：(行, 列, 朝向码 0上 1下 2左 3右)。
    格 = block_top_left 的像素左上角 // CELL（拖行时 me() 的联合框会被货撑大，所以用它）；朝向 = head_in_block。
    读不出返回 (-1, -1, -1)。纯像素。"""
    b = block_top_left(g)
    f = head_in_block(g)
    if b is None or f is None:
        return (-1, -1, -1)
    return (b[0] // CELL, b[1] // CELL, _FACE[f])


def dn(g):
    """全部甜甜圈，含被鼹鼠扛着的那几颗：每颗一个整数 = 格号(r*16+c) + 256*环色（0/3/4 来自 donuts()，5 来自 stolen()），
    按格号排，不足 DN_SLOTS 颗补 -1。纯像素（环色就是这一帧环上的颜色）。"""
    out = [(r // CELL) * 16 + c // CELL + 256 * ring for r, c, ring in donuts(g)]
    out += [r * 16 + c + 256 * 5 for r, c in stolen(g)]
    out.sort(key=lambda x: x % 256)
    return tuple(out + [-1] * (DN_SLOTS - len(out)))


def ml(g):
    """全部鼹鼠：每只一个整数 = 格号 + 256*皮码，皮码 0 = 皮12 实心，1 = 皮15 实心，2 = 皮15 且外圈换成警觉色11，
    3 = 皮12 且外圈是11（mole_skins / alert_moles 的读法；全语料 0 次，留着是为了不丢信息），
    按格号排，不足 ML_SLOTS 只补 -1。纯像素。"""
    al = set(alert_moles(g))
    out = []
    for (r, c), s in mole_skins(g).items():
        k = (3 if (r, c) in al else 0) if s == 12 else (2 if (r, c) in al else 1)
        out.append(r * 16 + c + 256 * k)
    out.sort(key=lambda x: x % 256)
    return tuple(out + [-1] * (ML_SLOTS - len(out)))


# ---- 每关常数（游戏内容）----
# 地形：位 r*16+c。由各关全部帧里「没被物件盖住的格」的 16 像素签名归类（探针 _scratch/wa30-20260920/extract.py → terrain.json，
# 归类与取掩码 mkconst.py）。全语料里同一关同一格从没出现过两种签名，地形关内不变。
#   wall  = 纯色5 的格，以及第 6 关上下两片纯色4（画面外）；
#   fence = 含色2 的杂色格（既不是纯2、也不是只有 2/9 两色）——围栏 / 胶囊墙；
#   sock  = 只有 2 和 9 两色的格（容器），并上与之四连通的纯2 格（第 7、8 关 3x3 容器的中心格没有 9 边，
#           它和四周容器格连成一块；鼹鼠帮手把货送进它、玩家把货放在它上都算归位）；
#   den   = 其余纯2 格（巢）。
#   第 8 关 (1,11) 全语料从没露出来过（一只帮手一直蹲在那里），记作地板（不影响任何算出来的步）。
#   第 9 关是通关画面（WIN），没有关内步；地形抄第 8 关、B 记 0，只为字段齐全。
# B：计时条预算。计时条长 = 64 - round_half_up(n*64/B)，n = 本关已走步数（含撞墙、A5 空按）。
#   逐关在全部 run 的全部帧上扫 B ∈ [20,400)，只有下列一个值让全关每一帧都对上（an_timer.py；floor / ceil 口径无解）：
#   第0关 200（645 帧，n 到 198）、1关 70（302 帧）、2关 100（313）、3关 100（397）、4关 125（803）、5关 75（223）、
#   6关 125（368）、7关 150（1473）、8关 70（885）。
_W8 = 30878008226128279287333645982098585374975284367527805695141844342908311831040
_F8 = 18158513697557839872
_S8 = 1947111592754076088204330096656384
_D8 = 2041725355306781989746018827568584589312
LEVEL_CONST = {
    0: {"wall": 0, "fence": 0, "sock": 4652297985247205555163324710981206016, "den": 0, "B": 200},
    1: {"wall": 0, "fence": 0, "sock": 535226051666156182524816222618870950481887232, "den": 0, "B": 70},
    2: {"wall": 0, "fence": 452319750434927077568233343438225443052370734331334163334113702693610455296,
        "sock": 548071476906145878016733762522084552229575983104, "den": 0, "B": 100},
    3: {"wall": 28951776968869790222945209175389210951615363382975349226075603923914983473280,
        "fence": 193095981518380963859944304210591028841543799079721500672,
        "sock": 41410478080743382724608535262865176054509783496908437695215098470072320, "den": 0, "B": 100},
    4: {"wall": 904639500869854155136466686886441445726452903812230009851190494063704932864, "fence": 0,
        "sock": 267613025833079042000358282481486597768347648, "den": 0, "B": 125},
    5: {"wall": 10855674010438249861637600242517410633256897137174189432378638689912620062720, "fence": 0,
        "sock": 7083657810695524712448, "den": 127607834706673874359126176723036536832, "B": 75},
    6: {"wall": 115792089237316195423570985007226406215939081747436880415667120602886371803135, "fence": 0,
        "sock": 2722300473742375986328025103424779452416, "den": 1393817842556096504999948852953487079636992, "B": 125},
    7: {"wall": 1427225391960766538849823005359898476433916297216, "fence": 0,
        "sock": 773007385997187083554609734254827176105154132616254899629379219395444736,
        "den": 1509780050775756022567597137216459328330379165266381092307616724418560, "B": 150},
    8: {"wall": _W8, "fence": _F8, "sock": _S8, "den": _D8, "B": 70},
    9: {"wall": _W8, "fence": _F8, "sock": _S8, "den": _D8, "B": 0},
}


# ---- 隐藏状态 ----
# n：本关已走步数（计时条 = 64 - round(n*64/B)；同一帧、同一 timer_px 之后何时再掉一格，单帧读不出）。
# m0..m3：鼹鼠身份槽。-2 = 本关还没开始追（关卡头一帧）；-1 = 空槽 / 已被清除；
#   否则 = 格号 + 256*皮位（0 帮手皮12，1 贼皮15）+ 512*货向（0 空手，1 货在上，2 下，3 左，4 右）。
#   槽号 = 开关那一帧按读序（行优先）给鼹鼠编的号，此后逐帧追。它决定鼹鼠在一步里的行动次序（先皮12 后皮15，同皮按槽号），
#   这次序帧上读不出（鼹鼠挪动后读序会变）。
HIDDEN_INIT = {"n": 0, "m0": -2, "m1": -2, "m2": -2, "m3": -2}
_DIRV = {1: (-1, 0), 2: (1, 0), 3: (0, -1), 4: (0, 1)}
_VDIR = {v: k for k, v in _DIRV.items()}
_ORD15 = ((1, 0), (-1, 0), (0, 1), (0, -1))   # 贼在几颗相邻货里挑：下、上、右、左（本语料拟合，见交回）


def _hs_objs(g):
    p = pl(g)
    d = {x % 256: x // 256 for x in dn(g) if x >= 0}
    m = {x % 256: (1 if x // 256 in (1, 2) else 0) for x in ml(g) if x >= 0}
    return p, d, m


def _cadd(a, dv):
    r, c = a // 16 + dv[0], a % 16 + dv[1]
    return r * 16 + c if 0 <= r < 16 and 0 <= c < 16 else None


def _cdist(a, b):
    return abs(a // 16 - b // 16) + abs(a % 16 - b % 16)


def _track(mo, nm):
    """槽里的鼹鼠 → 下一帧的格（同皮、挪 ≤1 格）。先配唯一候选，迭代；剩下有歧义的取距离最小、格号最小。被清除的回 None。"""
    cand = {m[0]: [c for c, s in nm.items() if s == m[2] and _cdist(c, m[1]) <= 1] for m in mo}
    got, used = {}, set()
    changed = True
    while changed:
        changed = False
        for k, cs in cand.items():
            if k in got:
                continue
            cs2 = [c for c in cs if c not in used]
            if len(cs2) == 1:
                got[k] = cs2[0]; used.add(cs2[0]); changed = True
    for m in mo:
        if m[0] not in got:
            cs2 = sorted((c for c in cand[m[0]] if c not in used), key=lambda c: (_cdist(c, m[1]), c))
            got[m[0]] = cs2[0] if cs2 else None
            if cs2:
                used.add(cs2[0])
    return got


def hidden_step(h, prev, action, nxt):
    """只用四样东西：上一步的隐藏量、前帧、动作串、后帧。
    身份：前帧（或关头时按读序新编的）槽 → 后帧同皮、挪 ≤1 格的鼹鼠。
    归属（谁扛着哪颗货）按一步之内的行动次序推：先玩家（A5 从帮手手里拿回正对的货 → 帮手空手；鼹鼠被清除 → 槽空），
    再鼹鼠（皮12 按槽号，然后皮15 按槽号）：
      · 扛着货的：挪了 → 货跟着平移；没挪 → 后帧那格还是环5 就还扛着，变成环4 就是放下了；
        后帧那格被玩家正对着画成环3（看不出是放下还是还扛着）→ 算还扛着（见交回的「未检验」）；
      · 空手的贼：贴着「本步开头就被帮手扛着」的货（帮手已先动，按后帧位置算）→ 夺过来（看不见，货照样画环5）；
        有几颗按 下、上、右、左 挑；
      · 空手的：前帧是地上货、后帧变环5 且贴着它的那颗 → 偷了；玩家攥着的货没按 A5 就脱了手 → 贴着它的空手贼偷了；
        偷了之后同皮的下一只本步不动（跳过）。
      · 被玩家正对着的地上货被偷时画面仍是环3、看不出来；这种情形这里不推（全语料按模型数 4 次帮手、个位数贼，路线上 0 次，见交回）。"""
    out = {"n": int(h["n"]) + 1}
    pp, pd, pm = _hs_objs(prev)
    np_, nd, nm = _hs_objs(nxt)
    slots = [int(h[f"m{i}"]) for i in range(4)]
    if slots[0] == -2:
        cells = sorted(pm)[:4]
        slots = [c + 256 * pm[c] for c in cells] + [-1] * (4 - len(cells))
    mo = []
    for i, v in enumerate(slots):
        if v < 0:
            continue
        pos, skin, cd = v % 256, (v // 256) % 2, v // 512
        mo.append([i, pos, skin, _cadd(pos, _DIRV[cd]) if cd else None])
    newpos = _track(mo, nm)
    a = (action or "")[:7]
    held_p = [c for c, r in pd.items() if r == 0]
    held_n = [c for c, r in nd.items() if r == 0]
    # 玩家相：拿回帮手的货
    if a == "ACTION5" and not held_p and held_n:
        for m in mo:
            if m[2] == 0 and m[3] == held_n[0]:
                m[3] = None
    # 玩家攥着的货脱手（没按 A5）：前帧攥着的格随玩家平移后的位置
    stripped = None
    if held_p and not held_n and a != "ACTION5" and pp[0] >= 0 and np_[0] >= 0:
        dr, dc = np_[0] - pp[0], np_[1] - pp[1]
        stripped = _cadd(held_p[0], (dr, dc))
    alive = [m for m in mo if newpos.get(m[0]) is not None]
    # 本步开头各鼹鼠的货随「扛着走」推到后帧的位置（用来排除「新偷的」）
    carried0 = {m[0] for m in alive if m[3] is not None and m[2] == 0}
    order = sorted(alive, key=lambda m: (m[2], m[0]))
    expect = set()
    for m in alive:
        if m[3] is not None:
            d = (newpos[m[0]] // 16 - m[1] // 16, newpos[m[0]] % 16 - m[1] % 16)
            q = _cadd(m[3], d)
            if q is not None:
                expect.add(q)
    skip = set()
    for m in order:
        slot, pos, skin, cargo = m
        npos = newpos[slot]
        if skin in skip:
            skip.discard(skin)
            m[1] = npos
            continue
        if cargo is not None:
            if npos != pos:
                m[3] = _cadd(cargo, (npos // 16 - pos // 16, npos % 16 - pos % 16))
            else:
                r = nd.get(cargo)
                if r == 5 or r == 3:
                    pass
                else:
                    m[3] = None
            m[1] = npos
            continue
        if skin == 1 and npos == pos:
            robbed = False
            for dv in _ORD15:
                q = _cadd(pos, dv)
                vict = [o for o in alive if o is not m and o[2] == 0 and o[0] in carried0 and o[3] == q]
                if q is not None and vict:
                    vict[0][3] = None
                    m[3] = q
                    robbed = True
                    break
            if robbed:
                continue
        if npos == pos:
            new = [c for c, r in nd.items() if r == 5 and _cdist(c, pos) == 1 and c not in expect
                   and pd.get(c) in (0, 3, 4) and not any(o[3] == c for o in alive if o is not m)]
            if skin == 1 and stripped is not None and _cdist(stripped, pos) == 1 \
                    and not any(o[3] == stripped for o in alive if o is not m):
                new.append(stripped)
            if new:
                m[3] = new[0] if len(new) == 1 else sorted(new)[0]
                if m[3] == stripped:
                    stripped = None
                skip.add(skin)
        m[1] = npos
    enc = [-1] * 4
    for m in alive:
        cd = 0
        if m[3] is not None:
            cd = _VDIR.get((m[3] // 16 - m[1] // 16, m[3] % 16 - m[1] % 16), 0)
        enc[m[0]] = m[1] + 256 * m[2] + 512 * cd
    for i in range(4):
        out[f"m{i}"] = enc[i]
    return out


# ---- 让原读数退出状态 ----
_RETIRED = ("me", "block_bbox", "head", "facing", "walls", "donuts", "capsule_bbox", "capsule_region", "occupied_cells",
            "mole", "alert_moles", "mole_skins", "moles", "empty_sockets", "home_cells", "all_donut_cells",
            "off_home_clumped", "stolen", "capsule_cells", "den_cells", "mask_timer_row", "block_top_left", "head_in_block")


def _retire(f):
    def w(*a, **k):
        return f(*a, **k)
    w.__name__, w.__doc__ = f.__name__, f.__doc__
    return w


for _n in _RETIRED:
    globals()[_n] = _retire(globals()[_n])
