"""按 ACTION5 去抓一颗贴着皮15 贼的环3 货：那只贼这一步原地没动，货就抓不起来（仍是环3）；它挪了窝，货就到手（环3→环0）。"""
LEVEL = "L6"
SCOPE = ("只看以 ACTION5 开头的动作；换关、RESET 返回 NA；玩家块定位不到返回 NA；"
         "prev 上已经攥着一颗（环0）返回 NA——那一按是松手，不是抓；"
         "贴着玩家的环3 货不是恰好一颗返回 NA（贴着两颗分不清按下去抓的是哪颗）；"
         "那颗货的四邻没有皮15 的鼹鼠返回 NA——不贴贼的那 111 条归 donut_grab_toggle 管，本条不重复主张。"
         "只说那颗货到没到手，不说玩家、别的货、别的鼹鼠这一步怎么动。")
NOTE = ("v1：终局卡第7关卡在这里抽出的。2714~2716 连着三批的路线都以「抓 (0,4)」开头，"
        "按下去货偏移仍是 None——抓不起来，而那颗环3 就贴着 (1,4) 的贼。"
        "donut_grab_toggle 的 v7 早就把生成器在这种局面上闭了嘴，NOTE 写着「样本只有 1 条，"
        "说不清是贼挡住了还是别的，所以不写成新主张」；现在样本够了，把那句话兑现成可判错的主张。"
        "全语料 ACTION5 抓取局面（手上空、贴着恰好一颗环3）117 条，分栏干净、零例外："
        "不贴贼 111 条全抓起来了；贴着贼而贼原地没动 4 条全没抓起来（步2565、2566、2715、2716）；"
        "贴着贼而贼挪了窝 2 条全抓起来了（步1622、2336）。"
        "**分母要看清**：那 4 条其实是两个局面各连着两拍（2565/2566 一处、2715/2716 一处），"
        "独立局面只有 2 个；「挪了窝」那栏只有 2 条。所以这条的真实分母是 2 对 2，不是 4 对 2。"
        "它和 thief_strips_drag 是同一件事的两面：那条说拖着的货落到贼旁边、贼没挪窝就被打脱手，"
        "这条说地上的货贴着贼、贼没挪窝就抓不起来——贼不动的那一拍，它旁边那一格的货归它。"
        "**这条推不动预测**：「贼这一步动没动」要读 next 才知道，按键之前算不出来，所以不写 apply。"
        "它在规划器里只能反着用：别把贴着贼的货选成目标；真要那一颗，先用 ACTION5 正对着贼把它清掉"
        "（action5_vanishes_adjacent_mole），再回头抓。")
EVIDENCE = ["8f31f640ab234711", "7edcde3628176443", "b8bfc839bac918b9",
            "518f172a0002ae63", "389b19e58d2ca64d", "bfc9d04bf8cf6e6a"]

from _lib import CELL, block_top_left, donuts, mole_skins

THIEF_SKIN = 15
N4 = [(-1, 0), (1, 0), (0, -1), (0, 1)]


def assert_(prev, action, nxt, ctx=None):
    if (action or "") == "RESET" or not (action or "").startswith("ACTION5"):
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a = block_top_left(prev)
    if a is None:
        return "NA"
    pcell = (a[0] // CELL, a[1] // CELL)
    before = {(r // CELL, c // CELL): ring for r, c, ring in donuts(prev)}
    if any(v == 0 for v in before.values()):
        return "NA"                       # 手里有货：这一按是松手
    adj3 = [(pcell[0] + d[0], pcell[1] + d[1]) for d in N4
            if before.get((pcell[0] + d[0], pcell[1] + d[1])) == 3]
    if len(adj3) != 1:
        return "NA"
    cell = adj3[0]
    skins = mole_skins(prev) or {}
    adj_thieves = [(cell[0] + d[0], cell[1] + d[1]) for d in N4
                   if skins.get((cell[0] + d[0], cell[1] + d[1])) == THIEF_SKIN]
    if not adj_thieves:
        return "NA"
    after = {(r // CELL, c // CELL): ring for r, c, ring in donuts(nxt)}
    got = after.get(cell) == 0
    now = {q for q, s in (mole_skins(nxt) or {}).items() if s == THIEF_SKIN}
    stayed = any(q in now for q in adj_thieves)   # 贴着的贼里还有一只留在原格
    return "TRUE" if got == (not stayed) else "FALSE"
