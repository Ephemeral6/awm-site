"""计时条上还剩色7像素时这一步不会 GAME_OVER；条归零那一步的死活本条不表态。"""
LEVEL = "L5"
SCOPE = ("只看 ctx.state_next 有值、且 next 帧计时条 timer_px(nxt) 大于 0 的转移；"
         "条已经归零的那些转移返回 NA——那正是本条不敢说的地方（见 NOTE）。")
NOTE = ("v1：全语料只有 3 次 GAME_OVER（第0关步316 ACTION3、第0关步516 ACTION5、第1关步625 ACTION3），"
        "三次的 next 帧计时条都是 0；其余 990 余次转移条都还有像素、一次都没 GAME_OVER。"
        "为什么不写成双向的「条=0 当且仅当 GAME_OVER」：步316 那次 prev 的条已经是 0 而 state_prev 还是 NOT_FINISHED，"
        "也就是说存在「条=0 但还活着」的一帧（步625 却是条 1 变 0 当场就死）。"
        "两者并存说明条是像素化的粗读数，归零之后还可能剩不足一像素的余量。"
        "所以只主张安全的那半边——它恰好是规划要用的那半边：条上还剩 b 像素，就至少还能走 b 步不死"
        "（配合 timer_bar_drains 的「每步至多掉1」）。"
        "另一半（条=0 之后还能活几步）留作未知，等哪天真撞上再抽。")
EVIDENCE = ["8cc4b843fcb321f4", "0b4217474bd1606a", "100ae20440f0eea9", "417f2cced0791fac"]
# 前三条是三次 GAME_OVER（本条在它们上面返回 NA——它们是这条主张为什么只敢说一半的由来）；
# 第四条是第4关步957，条还满着、没死，本条在它上面判 TRUE。

from _lib import timer_px


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("state_next") is None:
        return "NA"
    if timer_px(nxt) == 0:
        return "NA"
    return "TRUE" if ctx["state_next"] != "GAME_OVER" else "FALSE"
