"""鼹鼠把搬运中的甜甜圈投放在环5当前所在的那一格：环5→4留在原格、投放那步鼹鼠不动。"""
LEVEL = "L6"
SCOPE = ("只看环5消失(投放)的转移；prev 帧没有环5返回 NA；RESET 返回 NA（重画不是投放）；换关返回 NA；"
         "这一步鼹鼠少了（被 ACTION5 清掉）返回 NA——那是 killed_mole_drops_cargo 的地盘；"
         "货落在（或被挪进）玩家结果帧正前方那一格、成了环3 的返回 NA——那是夺回，归 donut_take_back_from_mole。"
         "「投放格是胶囊格」只在 capsule_cells 看得见它时核（第3关的孤立小胶囊格被搬运物整格盖住时看不见，"
         "那一项不表态，仍核落地与鼹鼠停步）")
NOTE = ("v1：第1关两次投放抽出——步568(D_c落(7,4))、步587(D_a落(7,3))：挂着走的环一进胶囊格，"
        "下一步鼹鼠停一步、环5→4留在该格。两次都落在胶囊格内，未见例外。"
        "v4：改用 moles() 全体（mole() 行优先只回第一只，第3关三只色12块里搬运者是巡逻的那只），"
        "但仍在第3关步785 判 FALSE。"
        "v5：探针逐项核了步785——环5(6,1)→环4(6,1) 原格落地、三只鼹鼠一格没动，全对；"
        "唯一不成立的是 capsule_cells(prev) 里没有 (6,1)。原因是可观测性，不是规律：第3关的胶囊是孤立小格"
        "（(6,1)(7,1) 两格，四邻全是地板），那一帧 (6,1) 被搬运的甜甜圈盖住、(7,1) 被鼹鼠盖住，"
        "2 像素一个都看不见，而连通补全需要一个看得见的 2 邻格当种子——单条转移里无从判断它是不是胶囊格。"
        "所以把胶囊那一项按可观测性缩进 scope：能看见就核，看不见就不表态。"
        "跨帧事实（写在这里不走闸，留待有可核的写法）：第3关左侧 socket 就是投放点，"
        "鼹鼠步774 偷(1,6)→沿行2西行→col1南下→步784 自己踩在(6,1)上、环5在(5,1)→步785 迈到(7,1)，"
        "环随 offset(-1,0) 落进(6,1) 并变环4。鼹鼠仍是替玩家送货的那个。"
        "v6：第7关 ACTION5 清掉搬运中的皮15鼹鼠那一步，环5→4 也发生了，但那不是投放——鼹鼠没了、"
        "其余鼹鼠照常走，「投放那步鼹鼠不动」自然判 FALSE。这一片归 killed_mole_drops_cargo 管：鼹鼠数减少的步返回 NA。"
        "v7（第7关步2915，tid 53e7f15d6f32647f）：皮15 贼背着货贴着我，我按向它被挡、只转了头；贼这一步挪窝，"
        "货随它挪进我转头后的正前方那一格，当场成环3，贼没停——环5 消失了，但不在原格落地、也没鼹鼠停步，判了 FALSE。"
        "这不是投放，是夺回（donut_take_back_from_mole v4：夺回打在结果帧正前方，不要求我走成一格）。"
        "全语料里「环5 消失、落点在玩家结果帧正前方且是环3」共 4 条，4/4 都被 take_back 认领；"
        "其中第3关步2033 那种皮12 帮手正好投放在我正前方的，以前本条按「原格落地、鼹鼠停步」判 TRUE，现在让给它、返回 NA。")
EVIDENCE = ["86f44f1451976b2e", "27a54b355f9f956a", "76c0df7b8d74fcc8", "57b23c23ec6f679b",
            "31b8ac36e9979ce2", "53e7f15d6f32647f"]

from _lib import CELL, me, facing, moles, stolen, donuts, capsule_cells

DV = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}


def _front(g):
    """结果帧里玩家正前方那一格；定位不到返回 None。"""
    b, fc = me(g), facing(g)
    if b is None or fc is None:
        return None
    return (b[0] // CELL + DV[fc][0], b[1] // CELL + DV[fc][1])


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action == "RESET":
        return "NA"                # GAME_OVER 帧上搬着的环5被重画抹掉，不是投放
    before = stolen(prev)
    if not before:
        return "NA"
    if stolen(nxt):
        return "NA"                # 还在搬，不是投放步
    if not moles(prev):
        return "FALSE"
    if len(moles(nxt)) < len(moles(prev)):
        return "NA"                # 鼹鼠被清掉、货原地落地：不是投放，归 killed_mole_drops_cargo
    p = before[0]
    rings = {(r // CELL, c // CELL): k for r, c, k in donuts(nxt)}   # donuts给像素左上角
    fr = _front(nxt)
    if (fr is not None and abs(fr[0] - p[0]) + abs(fr[1] - p[1]) <= 1
            and rings.get(fr) == 3):
        return "NA"                # 货到了我正前方、成了环3：夺回，归 donut_take_back_from_mole
    landed = p in rings
    still = set(moles(prev)) & set(moles(nxt))      # 这一步一格没动的鼹鼠
    if not (landed and still):
        return "FALSE"
    cc = capsule_cells(prev)
    neigh = [(p[0] + dr, p[1] + dc) for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))]
    if p not in cc and any(n in cc for n in neigh):
        return "FALSE"             # 边上看得见胶囊、自己却不在里面：真的落在胶囊外
    return "TRUE"
