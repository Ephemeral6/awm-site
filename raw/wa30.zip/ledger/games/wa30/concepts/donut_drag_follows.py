"""被抓取的甜甜圈(环0)在四向移动的每一步随玩家移动，相对偏移（甜甜圈-玩家）保持不变。"""
LEVEL = "L6"
SCOPE = "只看四向移动且上一帧存在环0甜甜圈；换关、A5、无环0甜甜圈返回 NA"
NOTE = "v1：第0关步522-523(上拖)/537(下拖)/538-539(左拖)/552-554(右拖)抽出——偏移跨方向变化保持不变"
EVIDENCE = ["b50ab3c43c3589c0", "bc7a313e0dd51a25", "7fd8653bde2f07f1",
            "3fd81e4d67f244ea", "888d4cf6b9fe00d6", "d3934881fa7243a5",
            "ea007d8c06b51c20", "8c0887ccd2d285a3"]

from _lib import me, donuts


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.startswith("ACTION5") or action.startswith("RESET"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    held_before = [(r, c) for r, c, ring in donuts(prev) if ring == 0]
    if not held_before:
        return "NA"
    held_after = {(r, c) for r, c, ring in donuts(nxt) if ring == 0}
    if not held_after:
        return "NA"          # 本步松了手，另一条概念管
    if len(held_before) != 1 or len(held_after) != 1:
        return "NA"          # 多环0局面本概念不开口
    (pr, pc), (qr, qc) = held_before[0], next(iter(held_after))
    want = (qr - (b[0] - a[0]), qc - (b[1] - a[1]))   # 反推上一帧应处位置
    return "TRUE" if (pr, pc) == want else "FALSE"
