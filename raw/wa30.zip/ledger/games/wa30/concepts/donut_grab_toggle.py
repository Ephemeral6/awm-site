"""ACTION5 作用于贴着玩家的甜甜圈：激活态(3)→被抓取(0)，被抓取态(0)→松手态(3)；都发生在原位。"""
LEVEL = "L6"
SCOPE = "只看 ACTION5；换关返回 NA"
NOTE = "v1：第0关步521(3→0抓取)/524(0→3松手)/536/540/551/555 抽出；A5 无甜甜圈可作用时只剩倒计时 tick，返回 NA；v2：补 apply——松手把环0画成环3、抓取把贴着玩家的环3画成环0（合成帧串链：不画松手，下一步预测仍以为在拖行，第1关步651实miss40格）；v3：删「A5 步其他甜甜圈都不动」——第2关步740(玩家抓(4,2)同一转移鼹鼠把(11,8)偷成环5,鼹鼠是独立活动物)打脸，只主张被作用的甜甜圈原位变环；v4：apply 的筛选顺序反了——原来要求「全场只有一颗环3」再看贴不贴着玩家，第3关场上常有两三颗松手态散在各处，抓取分支整关闭嘴（第853步押注时预测0格）。改成先按曼哈顿距离1筛出贴着玩家的，只有恰好一颗才生成；v5：**松手即通关的那一步 apply 闭嘴**。断言那一半没动（换关本来就返回 NA），但生成那一半原来照画环3，而换关整帧重画——第4关步1076 那种转移上这 16 格必错。判据借 levelup_on_release_iff_all_seated：松手前每一颗都已坐在容器格上就换关，那一步谁也预测不了下一帧长什么样；v6：v5 的闸门要求「读得出容器」，可最后一颗填上最后一个位时可见空位恰好为 0（home_cells 返回空集、三颗连成一片让 off_home_clumped 为真），于是闭嘴的条件一条都不成立。改成读不出就闭嘴：home 为空、或 off_home_clumped 为真、或全部已归位，三者任一都不生成。认领格从 2032 降到 1648，说错 32→0；v7：**目标货贴着皮15 时抓取分支闭嘴**。终局卡第7关步2565：玩家 (3,9) 朝右，正对的环3 在 (3,10)，贼在 (4,10)，A5 按下去那颗一动没动，押环0 实为环3（12 格，第14次意外）。全语料 104 次成功抓取里，被抓那颗贴着皮15 的一次都没有，而唯一贴着的这一次没抓起来——样本只有 1 条，说不清是贼挡住了还是别的，所以不写成新主张，只是生成器不在这种局面上押。断言那一半不动：这一步既没抓也没松，assert_ 本来就返回 NA"
EVIDENCE = ["9f896d4352561dab", "677fed49a51be587", "25eac5271b445e9c",
            "867794ff614ed63d", "194bd73e0915befc", "1b091866295d964d",
            "dc7cc4e0d8f8e967", "94af4f25d90efd6a", "8f31f640ab234711"]

from _lib import donuts, me, CELL, paint_donut, home_cells, off_home_clumped, mole_skins


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    before = {(r, c): ring for r, c, ring in donuts(prev)}
    after = {(r, c): ring for r, c, ring in donuts(nxt)}
    grabbed = [p for p, ring in before.items() if ring == 3 and after.get(p) == 0]
    released = [p for p, ring in before.items() if ring == 0 and after.get(p) == 3]
    if grabbed or released:
        # 抓/松只动环色，被作用的甜甜圈位置不变；其余物件(鼹鼠)同一步怎么动不归这条管
        ok = all(p in after for p in grabbed + released)
        return "TRUE" if ok else "FALSE"
    return "NA"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION5"):
        return None
    held = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]
    if len(held) == 1:
        # 松手即通关的那一步整帧重画，这条不生成（判据同 levelup_on_release_iff_all_seated）。
        # 读不出「在不在容器上」时也不生成：容器被盖满时可见空位为 0，home_cells 返回空集，
        # 而那恰恰是最后一颗刚填上最后一个位的样子——第0关步555、第1关步688 都是这个局面。
        home = home_cells(prev)
        ds = [(r // CELL, c // CELL) for r, c, _ in donuts(prev)]
        if not home or off_home_clumped(prev) or all(d in home for d in ds):
            return None
        return paint_donut(held[0][0], held[0][1], 3)   # 松手 0→3 原位
    loose = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 3]
    a = me(prev)
    if a is None:
        return None
    adj = [(r, c) for (r, c) in loose
           if abs(r - a[0] // CELL) + abs(c - a[1] // CELL) == 1]
    if len(adj) != 1:
        return None   # 没有贴着玩家的环3，或贴着两颗分不清抓哪颗：这条不生成
    skins = mole_skins(prev) or {}
    if any(s == 15 and abs(m[0] - adj[0][0]) + abs(m[1] - adj[0][1]) == 1
           for m, s in skins.items()):
        return None   # 目标货贴着贼：这种局面下抓取没发生过（见 NOTE v7），机制未定，不押
    return paint_donut(adj[0][0], adj[0][1], 0)   # 抓取 3→0 原位
