"""玩家块能整块走进胶囊2芯格——第0/1关如此(14+12次全进)；第2关反例：唯一一次尝试(步714)被整步拒绝，第2关玩家进不去2芯格，甜甜圈不受此限(步698拖行滑入(5,8))。"""
LEVEL = "L2"
SCOPE = "只看四向移动中玩家块与2芯像素的关系；换关返回 NA；目标块不含2像素返回 NA；level 不在 {0,1,2} 返回 NA"
NOTE = "v1 声称胶囊普遍可行走，第2关步714(玩家(10,7)东移进(10,8)被拒，该关胶囊格内芯是2/1杂斑、无9边)打脸。v2 按关分层：第0关14次/第1关12次目标含2全进，第2关1次全拒。目标判定直接看帧上2像素，不用 capsule_cells 连通补全——补全会把贴着胶囊的拖行甜甜圈格误吸进胶囊(步698 prev 的(5,7)假象，该步真相是甜甜圈(5,7)->(5,8)滑入、玩家(5,6)->(5,7)留在外面)。"
EVIDENCE = ["41234dbe071dc3d2", "df01e2367a779616", "bc7a313e0dd51a25", "e630cb93de3be0f0"]

from _lib import me, CELL, capsule_bbox

MOVES = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0),
         "ACTION3": (0, -CELL), "ACTION4": (0, CELL)}


def overlap(a0, a1, bb):
    """玩家块 (a0,a1) 4x4 是否与 bbox bb 相交。"""
    if bb is None:
        return False
    top, left, bottom, right = bb
    return not (a0 + CELL - 1 < top or a0 > bottom or a1 + CELL - 1 < left or a1 > right)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in MOVES:
        return "NA"
    lvl = ctx["level_prev"] if ctx else None
    if lvl not in (0, 1, 2):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    dr, dc = MOVES[action]
    target = (a[0] + dr, a[1] + dc)
    if not all(0 <= target[0] + i < 64 and 0 <= target[1] + j < 64
               for i in range(CELL) for j in range(CELL)):
        return "NA"
    if lvl in (0, 1):
        # 这两关：整片胶囊(按2芯bbox算，含9环一带)都可行走，玩家必须进得去
        if not overlap(target[0], target[1], capsule_bbox(prev)):
            return "NA"
        return "TRUE" if b == target else "FALSE"
    # 第2关：目标块直接含2像素才算胶囊格(不用连通补全)；实测玩家进不去
    if not any(prev[target[0] + i][target[1] + j] == 2
               for i in range(CELL) for j in range(CELL)):
        return "NA"
    return "TRUE" if b != target else "FALSE"
