"""甜甜圈环 4→3（激活）发生在：玩家顶住它（原位、头转向它），或玩家移到与它同排/列紧邻且面朝它的格。"""
LEVEL = "L2"
SCOPE = "只看四向移动；换关返回 NA；场上没有甜甜圈或玩家定位不到返回 NA"
NOTE = "v1：第0关步535/550(顶住激活)/520(激活态再顶帧不变)/519+32(移到位即激活——玩家上/左移进甜甜圈紧邻格,激活发生在到达那步)抽出；v2：补 apply——到达激活分支：目的格再往前一格有环4甜甜圈就画成环3（合成帧串链：不画则 A5 抓取分支数不到环3，下一步拖行判定全歪，第2关步710实测头6格错）；v3：apply 加拖行守卫——玩家已抓着甜甜圈(有环0)时到达激活不发生（第3关步776实测：拖行北上进(7,8)，正前方(6,8)环4保持环4）；v4：apply 补顶住分支——目的格自己就是环4时玩家原地不动、那颗环4→3。断言里顶住一直算 TRUE，apply 却只画到达激活，于是每次顶住都残差 12 格；同一批里 _lib.move_refused 也补上「目的格有非环0甜甜圈就整步不走」，两处配套：一处说玩家不动，一处画靶变色；v5：到达激活那一支补上 move_refused 守卫——**走不成就没有「到达」**。旧版只问「目的格再往前一格有没有环4」，不问这一步走不走得成，于是玩家被鼹鼠/地形挡住原地不动时，它照样把前方那颗画成环3。顶住那一支不受影响，它本来就是「被挡住且激活」的唯一情形（挡住它的正是那颗靶）。全量语料复核（probe_push_refused.py）：到达激活支共开口 30 次，其中被挡的 2 次（第0关步168、第5关步1091），两次那颗都稳稳留在环4，没有一次「被挡住却真的激活了」。第5关步1091 正是当初 44 格 strict 停批的那一步"
EVIDENCE = ["ba628847466ef521", "6a380a923e286479", "621ef195e5a2703e", "82bd93bc98c9d870"]

from _lib import me, CELL, donuts, facing, block_bbox, paint_donut, move_refused

MOVES = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0),
         "ACTION3": (0, -CELL), "ACTION4": (0, CELL)}
FACE_TO = {"ACTION1": "up", "ACTION2": "down", "ACTION3": "left", "ACTION4": "right"}


def adjacent_facing(pbbox, dring, dr, dc, dir_):
    """玩家块 bbox 与甜甜圈 (dr,dc) 同轴紧邻，且朝向 dir_ 指向甜甜圈。"""
    pr, pc = pbbox[0], pbbox[1]
    if pr == dr and abs(pc - dc) == CELL:
        return (dir_ == "left" and dc < pc) or (dir_ == "right" and dc > pc)
    if pc == dc and abs(pr - dr) == CELL:
        return (dir_ == "up" and dr < pr) or (dir_ == "down" and dr > pr)
    return False


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in MOVES:
        return "NA"
    if me(prev) is None or me(nxt) is None:
        return "NA"
    before = {(r, c): ring for r, c, ring in donuts(prev)}
    after = {(r, c): ring for r, c, ring in donuts(nxt)}
    activated = [p for p, ring in before.items() if ring == 4 and after.get(p) == 3]
    if activated:
        if me(prev) == me(nxt):
            return "TRUE"          # 顶住激活
        dir_ = facing(nxt) or FACE_TO[action]
        ok = all(adjacent_facing(block_bbox(nxt), 0, dr, dc, dir_)
                 for dr, dc in activated)
        return "TRUE" if ok else "FALSE"
    pushed_on_active = [p for p, ring in before.items()
                        if ring == 3 and after.get(p) == 3 and me(prev) == me(nxt)]
    if pushed_on_active:
        return "TRUE"
    return "NA"


def apply(prev, action, ctx=None):
    dv = MOVES.get((action or "")[:7])
    if dv is None:
        return None
    a = me(prev)
    if a is None:
        return None
    if any(ring == 0 for _, _, ring in donuts(prev)):
        return None   # 拖行中到达激活不发生(第3关步776实测)
    b = (a[0] + dv[0], a[1] + dv[1])
    if b[0] < 0 or b[0] + CELL - 1 > 63 or b[1] < 0 or b[1] + CELL - 1 > 63:
        return None   # 出帧=贴边被挡，这步不生成
    ring4 = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 4]
    if (b[0] // CELL, b[1] // CELL) in ring4:
        return paint_donut(b[0] // CELL, b[1] // CELL, 3)   # 顶住激活：玩家不动，目的格那颗环4→3
    cr, cc = b[0] // CELL + dv[0] // CELL, b[1] // CELL + dv[1] // CELL
    if (cr, cc) in ring4 and not move_refused(prev, action, ctx):
        return paint_donut(cr, cc, 3)   # 到达即激活：到达格往前一格的环4 → 环3
    return None
