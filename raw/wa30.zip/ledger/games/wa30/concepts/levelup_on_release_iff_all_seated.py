"""按下 ACTION5 松手的那一步换关，当且仅当松手前场上每一颗甜甜圈都已坐在容器格上。"""
LEVEL = "L5"
SCOPE = ("只在这些条件同时成立时表态：ctx 给得出 level_prev/level_next；动作以 ACTION5 开头；"
         "prev 帧上 home_cells 非空（容器被盖满时读不出它在哪，见 NOTE）；prev 帧上至少有一颗甜甜圈；"
         "prev 帧上没有环5（鼹鼠扛着的那颗可能就在这一步投进最后一个位，换关就由它触发而不是由松手触发——"
         "那半边本条不管，要另写一条）；off_home_clumped(prev) 为假（容器外有两颗四邻相接的甜甜圈时，"
         "它们可能坐在一整块被盖满的容器上，单帧读不出「在不在容器上」）。"
         "别的动作一律 NA——换关也可以由鼹鼠投放触发（第2关步768 是 ACTION1 那一步换的关）。")
NOTE = ("v1：第4关末尾两步把「什么算赢」切开了。第1075 步 A1 把最后一颗顶进空位 (9,2)，"
        "六颗甜甜圈这时已全部坐在容器格上——**没换关**，因为那一颗还攥在手里（环0）；"
        "第1076 步 A5 一松手，当场换关。所以「归位」不是位置，是松手之后的那个状态。"
        "被鼹鼠搬着的环5 同理不算归位，写进条件里一起判。"
        "全量语料 208 条 ACTION5 转移里，home 读得出来的 205 条本条全部判 TRUE，0 反例；"
        "其中 204 条是「条件不成立且没换关」，1 条是「条件成立且换了关」——"
        "换关侧的样本只有 1 条，这个数要和 S 一起报，别拿 S=1 当它被反复检验过。"
        "读不出 home 的那 3 条（第0关步555、第1关步688 换关时可见空位为 0）留在 SCOPE 外："
        "容器被甜甜圈盖满时 empty_sockets 没有种子，home_cells 返回空集，"
        "这时候「在不在容器上」这句话本身无从判起。"
        "和 win_needs_all_donuts_home 是一对：那条说「没归位就没结束」，本条说 A5 这一步结不结束。"
        "v1 上线一步就挨了打（第5关步1077，转移 58925d4e2a29162f）：它说那一步换关，世界说不换。"
        "错的不是这句主张，是它读容器的那个词——第5关有两块色2 区，一块带整圈色9 边框，"
        "另一块 32 个像素里一个色9 都没有，旧 empty_sockets 把两块都当容器，"
        "于是坐在纯色2 区上的那颗被算成已归位。改的是 _lib.empty_sockets（要求同格同时见到色2 和色9），"
        "本条断言一个字没动：全量语料 206 条可表态的转移上，新读法 0 反例。"
        "这条是词汇表被现实修正的例子——改 _lib 不算改版、不打分，所以把由来钉在这里。"
        "v3：第7关步1670（e2185dc1f4148a99）挨打：我按的是空手 A5，帮手鼹鼠恰在这一步把它扛着的最后一颗"
        "投进 (13,14)，换关了；prev 帧有环5、且上半场 2x4 容器块被 8 颗盖满读成「全在容器外」，"
        "本条按 v2 的条件说「不换」。两处都是可观测性，不是主张错：环5 在场时换关由投放触发，"
        "被盖满的整块容器单帧读不出——都缩进 scope（新词 off_home_clumped）。主张改成只说松手那半边。")
EVIDENCE = ["54d7d8a9bbcfa89b", "94af4f25d90efd6a", "82c7ca4f09f23e2e", "576d2f85299c182c",
            "58925d4e2a29162f", "e2185dc1f4148a99"]
# 前四条是入册时的依据；第五条是第5关步1077 那条反例：它打的是词汇，不是断言。第六条是第7关步1670：
# 鼹鼠投放触发的换关 + 被盖满的容器块，v3 划出 scope。
# 第一条是第4关步1076 换关那一步（条件成立）；后三条是第0关步4/5/34 的 A5（条件不成立、没换关）。

from _lib import donuts, home_cells, stolen, off_home_clumped


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if not (action or "").startswith("ACTION5"):
        return "NA"
    home = home_cells(prev)
    if not home:
        return "NA"
    if stolen(prev):
        return "NA"                # 鼹鼠扛着的那颗可能这一步投进最后一个位：换关归它，不归松手
    ds = [(r // 4, c // 4) for r, c, _ in donuts(prev)]
    if not ds:
        return "NA"
    if off_home_clumped(prev):
        return "NA"                # 容器外的甜甜圈成片：可能是被盖满的整块容器，读不出
    cond = all(d in home for d in ds)
    up = ctx["level_prev"] != ctx["level_next"]
    return "TRUE" if cond == up else "FALSE"
