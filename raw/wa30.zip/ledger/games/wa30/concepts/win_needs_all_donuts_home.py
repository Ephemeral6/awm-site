"""帧上还看得见空位、而且还有甜甜圈没坐在容器上时，这一步不会换关。"""
LEVEL = "L5"
SCOPE = ("只在这些条件同时成立时表态：动作不是 RESET；ctx 给得出 level_prev/level_next；prev 帧上 empty_sockets 非空；"
         "prev 帧上至少有一颗**不被鼹鼠搬着的**甜甜圈（环0/3/4）不在 home_cells 里；"
         "且 off_home_clumped(prev) 为假。"
         "可见空位为 0 时返回 NA——那时候容器被盖满，读不出它在哪（见 NOTE）；"
         "环5 那颗不算数——鼹鼠可能就在这一步把它投进最后一个位（第7关步1670 就是这样换的关）；"
         "容器外有两颗四邻相接时返回 NA——它们可能坐在一整块被盖满的容器上，单帧读不出；"
         "所有可数的甜甜圈都已归位时也返回 NA——那一边正是本条不敢说的另一半。")
NOTE = ("v1：把「什么算赢」写成安全的那半边——**没归位就没结束**，而不是「归位就结束」。"
        "语料四次换关的 prev 帧本条全部返回 NA，这不是回避，是它们逐条划出的边界："
        "第0关步555、第1关步688、第3关步956 三次，prev 帧的可见空位都是 0（容器被甜甜圈盖满，"
        "连一格色2 都不剩），于是 home_cells 没有种子、补不出容器在哪；"
        "第2关步768 那次可见空位是 (8,14)(9,14) 两格，5 颗甜甜圈经四连通全部落在 home_cells 里——"
        "也就是说那一关 8 个位只填了 5 个就过了关，**「把所有位填满」不是过关条件**，"
        "把所有甜甜圈搬上容器才是。第4关同样：8 个位、6 颗甜甜圈，填满根本做不到。"
        "反过来的那半边（都归位了就当场换关）暂时写不成断言，因为它要用的正是读不出来的那个容器全集；"
        "要补上它，得先有一条概念能在容器被盖满时仍然说出容器在哪（比如拿换关前后两帧对照）。"
        "本条的用处在规划：只要还看得见空位、且还有甜甜圈在容器外，本关就一定没完，"
        "策略不能在这种局面上宣布收工。"
        "v2：第7关步1670（e2185dc1f4148a99）挨打：可见空位 (13,14) 一格、8 颗甜甜圈读成「在容器外」、"
        "本条说不换关，世界换了。两处可观测性：那 8 颗把上半场 2x4 容器块盖满了（home_cells 没种子，"
        "它们其实全在位上）；剩下那颗是环5，帮手鼹鼠这一步把它投进 (13,14) 就凑齐了。"
        "所以环5 从「没归位」的名单里划掉（它随时可能被投进位），容器外成片的局面划出 scope。"
        "v3：换记分卡那一步（925dc621464496eb）挨打——那条 RESET 把关卡从第6关退回第0关，"
        "ctx 里 level_prev != level_next，本条据此判 FALSE。但它说的是「这一步不会**换关**」，"
        "而 RESET 不是过关，是整局回到起点；关卡号变了不等于世界前进了。"
        "所以动作是 RESET 时一律 NA：重开这一步本条不表态。")
EVIDENCE = ["1b091866295d964d", "c27834518d1f788d", "1b68f7dfe996f097", "f432e786cefc03dd",
            "e2185dc1f4148a99", "925dc621464496eb"]
# 前两条是换关转移（第0关到第1关、第2关到第3关），本条在它们上面返回 NA——它们是 SCOPE 两道口子的由来；
# 后两条是第4关第1043/1046 步，空位看得见、手上那颗还在容器外、没换关，本条判 TRUE。
# 第五条是第7关步1670：鼹鼠投放凑齐 + 容器块被盖满，v2 划出 scope。

from _lib import CELL, empty_sockets, home_cells, donuts, off_home_clumped


def assert_(prev, action, nxt, ctx=None):
    if action == "RESET":
        return "NA"                # 重开/换卡不是过关：关卡号退回第0关不算「换关」（v3）
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    if not empty_sockets(prev):
        return "NA"
    ds = [(r // CELL, c // CELL) for r, c, _ in donuts(prev)]   # 环0/3/4，不含鼹鼠搬着的环5
    if not ds:
        return "NA"
    home = home_cells(prev)
    if all(d in home for d in ds):
        return "NA"
    if off_home_clumped(prev):
        return "NA"                # 容器外成片：可能是被盖满的整块容器，读不出
    return "TRUE" if ctx["level_prev"] == ctx["level_next"] else "FALSE"
