"""拖行中的甜甜圈进得去 2 芯格（胶囊/围栏墙）——玩家被同一片 2 格挡住，甜甜圈不受此限。"""
LEVEL = "L2"
SCOPE = ("只看四向移动且场上有环0(被抓)甜甜圈的转移；没有环0、或动作不是四向移动返回 NA；"
         "换关返回 NA；甜甜圈目的格出帧返回 NA；目的格在 prev 帧看不见 2 像素返回 NA"
         "（被别的物件盖住时无从判断它是不是 2 格）；**玩家自己的目的格含 2 像素返回 NA**"
         "——那是整步被拒，归 capsule_walkable 管")
NOTE = ("v1：两关三处实测——第2关步698 拖行滑入胶囊柱(5,8)（玩家(5,6)→(5,7)留在柱外）；"
        "第3关步791 拖行滑入围栏西墙(10,5)（玩家留在(10,6)）、步796 东墙(10,10)。"
        "与 capsule_walkable 配对读：同一片 2 格，玩家整步被拒、拖行的甜甜圈照进——"
        "所以这两关的送货构型都是「玩家当供货商、把货推上 2 格」，玩家自己永远不必进去。"
        "判据只核甜甜圈那一格：玩家去哪由 action* 与 capsule_walkable 各自主张。"
        "v2：第2关步714 打脸——玩家(10,7)拖着货东移，玩家自己的目的格(10,8)是 2 格，"
        "整步被世界拒掉，甜甜圈也一格没动。所以「货进得去」的前提是玩家这一步走得成："
        "玩家目的格是 2 格时这条不表态。两条概念的分工由此划清——玩家的通行性归 capsule_walkable，"
        "货的通行性归这里，而货只在玩家真的走了那一步时才跟着走")
EVIDENCE = ["27270ec876743f9e", "e630cb93de3be0f0"]

from _lib import CELL, donuts, held_new_cells, block_top_left

DV = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def has2(g, r, c):
    if not (0 <= r <= 15 and 0 <= c <= 15):
        return False
    return any(g[r * CELL + a][c * CELL + b] == 2 for a in range(CELL) for b in range(CELL))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dv = DV.get((action or "")[:7])
    if dv is None:
        return "NA"
    held = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]
    if len(held) != 1:
        return "NA"
    a = block_top_left(prev)
    if a is None:
        return "NA"
    pdst = (a[0] // CELL + dv[0], a[1] // CELL + dv[1])
    if has2(prev, *pdst):
        return "NA"                     # 玩家自己撞 2 格：整步被拒，归 capsule_walkable
    tgt = held_new_cells(prev, action)
    if not tgt:
        return "NA"
    (tr, tc) = tgt[0]
    if not (0 <= tr <= 15 and 0 <= tc <= 15):
        return "NA"
    if not has2(prev, tr, tc):
        return "NA"                     # 目的格不是看得见的 2 格：这条不表态
    after = [(r // CELL, c // CELL) for r, c, ring in donuts(nxt) if ring == 0]
    if len(after) != 1:
        return "FALSE"                  # 拖着的那颗该还在拖着
    return "TRUE" if after[0] == (tr, tc) else "FALSE"
