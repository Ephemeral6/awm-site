"""松手态(环3)的甜甜圈：玩家移开的那一步它落格为自由态(环4)并停在原地；贴着鼹鼠的那颗不表态。"""
LEVEL = "L6"
SCOPE = ("只看四向移动且上一帧存在环3甜甜圈；换关、A5、玩家没动返回 NA；"
         "上一帧有鼹鼠与它曼哈顿相邻的那颗跳过（那一步归 mole_steal_on_block 管），"
         "全部跳过则返回 NA")
NOTE = ("v1：第0关步525/541(移开即3→4落格)抽出；顶住激活态(玩家没动,环保持3)由 donut_push_activate 管；"
        "v2：补 apply——玩家走开就把所有环3画成环4原位（合成帧串链：批B里 D_b 激活后若不落格/不抓取，"
        "环3残影会让 grab_toggle 的抓取分支数错）。"
        "v3：第3关步826打脸——玩家在(6,9)松手把货留在东墙(6,10)，同一步西移走开，"
        "货没有落成环4而是直接被贴在(6,11)的鼹鼠偷走成环5。所以「松手即落格」有前提："
        "身边没有鼹鼠。鼹鼠偷取不要求环4，环3照偷；而偷取的条件(相邻且鼹鼠不动)由 mole_steal_on_block 主张。"
        "教训：送货时松手那一步若旁边已经蹲着鼹鼠，货直接进入搬运态——这对通关是好事，但这条概念管不着。"
        "这一版（终局卡第7关步3023，tid aa83ea6b71991667，第19次意外；总账里的版号以 registry 为准，"
        "v3 之后有过只改词汇的重结算）：只是 apply 过宽，assert_ 一直是对的。"
        "蹲点时玩家在容器边按上被顶住（正前方那格坐着环3 的货），**整步不走**，环3 照旧是环3；"
        "可 apply 只核了「目的格出没出帧」，就把全场环3 都画成了环4，12 格全错。"
        "assert_ 早写着「玩家没动返回 NA」，生成器却没照抄这一条——**弃权条件要两边一致**，"
        "断言闭嘴的那一片，生成器也得闭嘴。挡不挡得住不用重新发明：_lib.move_refused 的文档里就写着"
        "「挡住时 apply 该返回 None，别画一次不存在的移动」，其中第 (2) 种挡正是「顶住一颗甜甜圈」——"
        "蹲点顶着的就是这一片，所以这个洞在蹲巢策略上线之后必然会被踩到。")
EVIDENCE = ["af6c42c25158b764", "e60219827362d54b", "66902872274ab569",
            "aa83ea6b71991667"]

from _lib import me, donuts, moles, CELL, paint_donut, mask_timer_row, move_refused


def _near_mole(g, cell):
    ms = moles(g)
    return any(abs(m[0] - cell[0]) + abs(m[1] - cell[1]) <= 1 for m in ms)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.startswith("ACTION5") or action.startswith("RESET"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None or a == b:
        return "NA"
    before = {(r, c): ring for r, c, ring in donuts(prev)}
    after = {(r, c): ring for r, c, ring in donuts(nxt)}
    loose = [p for p, ring in before.items() if ring == 3]
    if not loose:
        return "NA"
    judged = 0
    for p in loose:
        if _near_mole(prev, (p[0] // CELL, p[1] // CELL)):
            continue               # 贴着鼹鼠：这一步它可能被偷，本条不表态
        judged += 1
        if after.get(p) != 4:
            return "FALSE"         # 玩家移开了，松手态甜甜圈却没落格
    return "TRUE" if judged else "NA"


def apply(prev, action, ctx=None):
    dv = {"ACTION1": (-1, 0), "ACTION2": (1, 0),
          "ACTION3": (0, -1), "ACTION4": (0, 1)}.get((action or "")[:7])
    if dv is None:
        return None
    a = me(prev)
    if a is None:
        return None
    b = (a[0] + dv[0], a[1] + dv[1])
    if b[0] < 0 or b[0] + CELL - 1 > 63 or b[1] < 0 or b[1] + CELL - 1 > 63:
        return None   # 出帧=贴边被挡=玩家没走开，环保持3
    if move_refused(prev, action, ctx):
        return None   # 整步不走=玩家没走开，环3 还是环3（顶住那一片归 donut_push_activate）
    loose = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 3
             if not _near_mole(prev, (r // CELL, c // CELL))]
    if not loose:
        return None
    out = {}
    for (r, c) in loose:
        out.update(paint_donut(r, c, 4))   # 玩家走开，环3落格为环4
    return mask_timer_row(out)      # 最底一行格的第 4 像素行是计时条，不押（终局卡第4关步2088）
