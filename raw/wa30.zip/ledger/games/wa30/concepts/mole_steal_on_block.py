"""甜甜圈挡住鼹鼠的去路：目标格有环4甜甜圈时鼹鼠停一步把它偷走(环4→5留在原格)，得手后保持抓取offset随行。"""
LEVEL = "L2"
SCOPE = "只看发生了环4→5(且位置不变)的转移；场上没有这种变化返回 NA；换关返回 NA"
NOTE = ("v1：第1关三次偷取抽出——步560(D_c,鼹鼠在其下方)、步577(D_a,下方)、步596(D_d,左侧)："
        "三次都是甜甜圈恰在鼹鼠前进目标格上，鼹鼠被挡、停一步、环4→5。与玩家同受甜甜圈阻挡，但后果是被偷。"
        "v3(已撤)：曾缩scope到第0-2关，因第3关步774判FALSE。"
        "v4：根因是词汇表 mole() 只回行优先第一只——第3关三只色12块，偷(1,6)的是巡逻在(2,6)的那只，"
        "mole() 回的是驻扎在(1,14)的那只，'鼹鼠没动'和'相邻'两项都被张冠李戴。"
        "改用 moles()：主张收成「存在一只这一步没动、且与被偷格相邻的鼹鼠」，第3关步774 满足。"
        "v4 的第二次同病（第5关步1078-1081，反例 8e40ff2ea2289865）：这一关的搬运物是**色15** 的"
        "16 像素实心块，它一路东行路过 (4,7)，把坐在容器上的那颗环4 就地变成环5 挟走——"
        "偷法和色12 那只一样，只是换了张皮，而 moles() 把颜色写死成 12，"
        "于是「找不到相邻的鼹鼠」判了 FALSE。断言没改，改的是词汇 MOLE_COLORS=(12,15)。"
        "顺带一条对策略要紧的读数：**坐在容器上的甜甜圈不是安全的**，鼹鼠照偷不误。")
EVIDENCE = ["41ee231614472a64", "97ea7f0142571be8", "93a1d15fff76a8b9", "e881e7add319310f",
            "8e40ff2ea2289865"]

from _lib import CELL, moles, stolen, donuts


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    prev_free = {(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 4}
    events = [p for p in stolen(nxt) if p in prev_free]
    if not events:
        return "NA"
    still = set(moles(prev)) & set(moles(nxt))      # 这一步没动的鼹鼠
    if not still:
        return "FALSE"
    ok = True
    for (pr, pc) in events:
        ok &= any((abs(pr - m[0]) + abs(pc - m[1])) == 1 for m in still)
    return "TRUE" if ok else "FALSE"
