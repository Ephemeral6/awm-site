"""拖着的甜甜圈落到与皮色15 鼹鼠正相邻的格上时：那只贼这一步**原地没动**，货就被打脱手（环0→环3）；它挪了窝，货照旧在手里（环0）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1/2/3/4；换关返回 NA；prev 上拖着的货不是恰好一颗（环0）返回 NA；"
         "玩家块定位不出来返回 NA；prev 或 nxt 上没有皮色15 返回 NA；"
         "nxt 上找不到「原来那颗」（既没有环0 也没有环3）返回 NA；"
         "**货的落点没有与任何皮色15 正相邻（曼哈顿 ≤ 1）时返回 NA**——离得开的那一大半不归本条管。"
         "在 scope 内断言一件事：脱手与否 ⟺ 落点旁边那只贼这一步有没有留在原格。"
         "「留在原格」按格判：nxt 里与落点相邻的皮15 格，在 prev 的皮15 格集合里也出现过。"
         "不管玩家走到哪、不管别的鼹鼠、不管货最后落在什么地形上。")
NOTE = ("终局卡第7关步2474 抽出（第13次意外，反例 tid 06a0e537f7786c3b）：玩家在 (2,4) 头朝右、"
        "拖着 (2,5) 那颗，按 ACTION2 下移。货跟着到了 (3,5)——位移一格不差，drag_donut_follows 没错——"
        "但环色 0→3，手空了。整步只错 12 格，正好是环的外圈（芯的 2x2 是色9，两种环色下都一样）。"
        "为什么是「贼没动」而不是「贼在旁边」：全量语料里「拖行落点紧贴皮15」一共 10 次"
        "（probe_intercept.py 列了全表）。其中 9 次货没脱手，那 9 次那只贼当步都挪了窝"
        "（步1285-1292 是同一只贼一路平走，步2439 是另一只）；唯一脱手的这 1 次，"
        "两只皮15 都一格没动。「旁边有贼」分不开这 10 条，「贼没动」一刀分开。"
        "读法上的取舍：鼹鼠之间没有身份，只有位置，所以「它没动」只能按格判——"
        "nxt 里那个相邻格在 prev 的皮15 集合里也在。两只贼恰好换位时这个读法会读错，语料里没见过。"
        "**这条生成不了 apply**：押注时看不出贼下一步动不动，所以它只判不画。"
        "画的那一半交给 _lib.thief_may_strip——落点紧贴皮15 时移动概念只押芯、不押环外圈。"
        "两者不冗余：一个说清了机制并挨打，一个让不确定的那 12 格闭嘴。"
        "已知的窄处：只见过 1 次脱手，脱手后货是环3（跟 A5 主动松手后的样子一样），"
        "贼有没有在下一步把它捡走、脱手的货会不会被算作「停好了」，都还没量过。")
EVIDENCE = ["06a0e537f7786c3b", "adf9ec442240e0ce", "5e2fb71151ddeb8d", "4081b226af8aa922"]
# 第1条是脱手的那一下（步2474）；后三条是贼贴身但挪了窝、货没脱手的三帧（步1286、1292、2439）。

from _lib import CELL, donuts, mole_skins, block_top_left

MOVES = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _d(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not any((action or "").startswith(m) for m in MOVES):
        return "NA"
    held = [(r // CELL, c // CELL) for r, c, ring in donuts(prev) if ring == 0]
    if len(held) != 1:
        return "NA"
    p = block_top_left(nxt)
    if p is None:
        return "NA"
    pc = (p[0] // CELL, p[1] // CELL)
    before = {m for m, s in (mole_skins(prev) or {}).items() if s == 15}
    after = {m for m, s in (mole_skins(nxt) or {}).items() if s == 15}
    if not before or not after:
        return "NA"
    still = [(r // CELL, c // CELL) for r, c, ring in donuts(nxt) if ring == 0]
    if still:
        cell, stripped = still[0], False
    else:
        loose = [(r // CELL, c // CELL) for r, c, ring in donuts(nxt) if ring == 3]
        if not loose:
            return "NA"                 # 那颗去哪了读不出来（被偷成环5、或被埋了），不归本条管
        cell, stripped = min(loose, key=lambda x: _d(x, pc)), True
    touching = [m for m in after if _d(cell, m) <= 1]
    if not touching:
        return "NA"                     # 落点旁边没贼：离得开的那一大半
    stayed = any(m in before for m in touching)
    return "TRUE" if stayed == stripped else "FALSE"
