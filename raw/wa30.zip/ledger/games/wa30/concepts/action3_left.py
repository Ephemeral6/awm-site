"""ACTION3 让玩家块（4x4 整块）左移恰好 CELL 格、行不变，或整块不动。"""
LEVEL = "L1"
SCOPE = "只看 ACTION3；换关（ctx.level_prev != level_next）返回 NA；me() 定位不到返回 NA"
NOTE = "v3：断言对象从色0 头改成整块 bbox——头随朝向换边（左移后头在左），色0 单独定位列差不是 CELL；块不动（含撞墙）也算 TRUE；v6：apply 目的块出帧（a[1]-4<0，贴左边被挡）时返回 None 不生成；v10：拖行改走 drag_paint——擦甜甜圈旧位残影、画新位（合成帧串链只画不擦，旧位留影会让下一步看到两个环0，步646实测）；v11：apply 拖行态改用 block_top_left 定位——me() 的色0∪色14 bbox 被环0甜甜圈撑大，玩家与甜甜圈不同行/列时整块糊错（第3关步785实测12格：玩家(8,9)甜甜圈(9,8)，联合bbox top-left 落到(8,8)）；v-next：apply 旧格四邻有鼹鼠/被驮货时不画旧格——鼹鼠会走进刚空出来的格（终局卡第4关步2064 ACTION2 押1实12；语料里 3 次都是 prev 贴着旧格）；v-next2：旧格底图没依据时也不押——见 _lib.bg_unsure，终局卡第7关步2417（第12次意外）教的；v-next3：拖行落点紧贴皮15 贼时只押芯不押环外圈——见 _lib.thief_may_strip 与概念 thief_strips_drag，贼原地不动那一步会把货打脱手（环0→3），终局卡第7关步2474 第13次意外；v-next4（终局卡第8关步3250，tid a3f2a39e754ef8da，第20次意外，反例打在 action4_right 上）：**assert_ 也改用 block_top_left 定位拖行态**。v11 早写明 me() 在拖行时被环0 撑歪，却只改了 apply、没改 assert_——生成器和检查器读同一个位置用了两个词。那一步人走成恰好一格、货同时被贴着落点的贼打脱手（环0→3），me(prev) 的 bbox 含货、me(nxt) 只剩人，差出来一格对角判 FALSE。四条移动概念的 assert_ 是同一段代码，一起改；这条上那个 tid 判 NA，只是登记来源"
EVIDENCE = ["bea220486f78fc4d", "9c53253544a7a8a8", "900bcacebb131111", "a3f2a39e754ef8da"]

from _lib import me, CELL, donuts, block_top_left


def _pos(g):
    """玩家块像素左上：拖行时（帧里有环0）me() 的色0∪色14 bbox 被货撑歪，改用 block_top_left。"""
    if any(ring == 0 for _, _, ring in donuts(g)):
        return block_top_left(g)
    return me(g)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION3"):
        return "NA"
    a, b = _pos(prev), _pos(nxt)
    if a is None or b is None:
        return "NA"
    d = (b[0] - a[0], b[1] - a[1])
    if d in ((0, 0), (0, -CELL)):
        return "TRUE"
    return "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION3"):
        return None
    from _lib import bg_px, bg_unsure, donuts, head_in_block, held_new_cells, drag_paint, block_top_left, move_refused, mole_may_enter, mask_timer_row
    if move_refused(prev, action, ctx):
        return None       # 玩家目的格是 2 格：整步被拒，这条不生成
    dragging = any(ring == 0 for _, _, ring in donuts(prev))
    a = block_top_left(prev) if dragging else me(prev)   # 拖行时 me() 被环0撑歪
    if a is None:
        return None
    if a[1] - CELL < 0:   # 目的块越出 64 宽帧：贴左边被挡，这步不生成
        return None
    face = head_in_block(prev) if dragging else "left"
    bg = bg_px(prev, a[0] // CELL, a[1] // CELL)
    out = {}
    drag_paint(prev, out, a, "ACTION3")   # 拖行：擦甜甜圈旧位、画新位
    cell = (a[0] // CELL, a[1] // CELL)
    if cell not in held_new_cells(prev, "ACTION3") and not mole_may_enter(prev, cell) and not bg_unsure(prev, *cell):   # 甜甜圈进旧格时那格已是甜甜圈；隔壁有鼹鼠时它可能走进来；底图没依据时（贴着巢/容器边又认不下来）这格也不押
        for dr in range(CELL):
            for dc in range(CELL):
                out[(a[0] + dr, a[1] + dc)] = bg[dr][dc]
    b = (a[0], a[1] - CELL)
    for dr in range(CELL):
        for dc in range(CELL):
            out[(b[0] + dr, b[1] + dc)] = 14
    face = face or "left"         # 拖行头不转（第1关步642实测），否则头朝移动方向
    if face == "up":
        for dc in range(CELL):
            out[(b[0], b[1] + dc)] = 0
    elif face == "down":
        for dc in range(CELL):
            out[(b[0] + CELL - 1, b[1] + dc)] = 0
    elif face == "left":
        for dr in range(CELL):
            out[(b[0] + dr, b[1])] = 0
    else:
        for dr in range(CELL):
            out[(b[0] + dr, b[1] + CELL - 1)] = 0
    return mask_timer_row(out)      # 最底一行格的第 4 像素行是计时条，不押（终局卡第4关步2088）
