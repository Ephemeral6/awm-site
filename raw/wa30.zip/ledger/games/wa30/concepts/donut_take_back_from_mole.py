"""夺回打在**结果帧**上：按下四向键后，玩家在这一帧正前方那一格（走成了就是到达格前方，没走成就是转头后的前方）
若坐着一颗刚脱离搬运的货（上一帧它是环5，或是扛着它的鼹鼠这一步刚把它挪进这一格），那它在这一帧是环3——被夺回。"""
LEVEL = "L6"
SCOPE = ("只看四向键的转移（走成一格、被挡转头、被挡没转头都算）；换关/RESET 返回 NA；拖行中(场上有环0)返回 NA；"
         "结果帧正前方那一格上一帧就坐着自由甜甜圈的返回 NA（那是 donut_push_activate 管的事）；"
         "那一格上一帧不是环5、也没有任何环5 与它正相邻（没有货能在这一步挪进来）返回 NA；"
         "那一格在这一帧空着（货被搬去了别处）返回 NA——**这是 v2 缩掉、v3 保留的那一片**。")
NOTE = ("v1：第3关步842抽出（tid 2487d3a51d07f8b6）。当时西边那只鼹鼠扛着货冻在(4,6)二十步不动，"
        "货压在围栏北墙(5,6)上；玩家从(7,6)北上到(6,6)，正前方隔一格正是那颗环5，一步夺回成环3。"
        "两件事因此成立：到达激活的靶不限于环4，环5照样吃；这条激活**穿墙**——(5,6)是围栏墙格，"
        "玩家进不去，激活照样发生。这是驮货鼹鼠卡死时唯一的解套手段，所以单独立册而不是塞进 donut_push_activate。"
        "v2（第7关步1241/1242/1243，三条反例一次打来）：色15 贼扛着货沿第10行西逃，我沿同一行西追，"
        "连着三步「走到货的隔壁格」，三步都没夺回来，货一路还是环5。三步的共同点是**货当步自己也挪了一格**："
        "prev 帧它在我到达格的正前方，nxt 帧它已经退到再前面一格，我和它在结果帧里根本不相邻。"
        "v1 的证据里鼹鼠冻了二十步，于是「到达时相邻」和「结果帧里相邻」在那一帧上分不开，v1 挑了前者，这三步说是后者。"
        "v2 缩 scope 而不是改断言，理由写的是「两种读法我还分不开，要分开得造一次『鼹鼠不动、但货被别的原因移走』，目前造不出来」。"
        "v3（第7关步1271，tid 4044786757c7d6d2）：判开了，而且不是靠我造出来的——"
        "我北上到(6,4)，正前方(5,4)在 prev 帧上**空着**，是扛货的色12 帮手这一步把货从(5,5)挪了进来，"
        "货在(5,4)当场环5→3 被夺回。「到达时相邻」在这一帧根本不成立（prev 里那格没东西），"
        "所以读法是**结果帧**：激活打在我走完之后那一格上坐着的东西上。"
        "v2 等的那个判别帧不必人为制造，它是运动物自己走出来的——分不开时缩 scope 接着打，比硬选一边强。"
        "v3 因此把断言重新写成对 nxt 的主张，并且重新有了牙齿：那一格在结果帧上还是环5（货没被夺回）就判 FALSE。"
        "apply 仍然不写：它只看 prev，判不出鼹鼠这一步会把货挪到哪。"
        "v4（第7关步2915，tid 53e7f15d6f32647f，由 mole_drop_in_capsule 的反例牵出）：我在巢边蹲点，按向贴着的贼被挡、"
        "只转了头朝下；贼这一步挪窝，把背着的环5 挪进了我转头后的正前方那一格，那颗货当场成环3，贼没停步。"
        "v3 的「结果帧」读法本来就没说过要走成一格——它说的是「我这一帧正前方坐着的东西」。"
        "全语料复核（探针 probe_front_cargo_no_move）：玩家没走成、结果帧正前方那一格这一帧才到了一颗从环5 来的货，"
        "共 4 条（第3关步2033、第7关步2407/2771/2915），4/4 环3，零例外。"
        "所以 v4 把 scope 从「走成一格」放宽到「按了四向键」：靶格 = 结果帧里玩家格 + 结果帧朝向；走成时它就是 v3 的靶格。"
        "第3关步2033 那种「皮12 帮手投放、正好落在我正前方」以前被 mole_drop_in_capsule 当环3 投放判 TRUE，"
        "现在两条概念的边界划在这里：落在我正前方的归本条（环3），落在别处的归它（环4）。")
EVIDENCE = ["2487d3a51d07f8b6",
            "68e9dcaa03e344ea", "6f4cc4500f249968", "c7f05ea2e1d9bd11",
            "4044786757c7d6d2",
            "40a5d831d6c5bd7f", "c445e55ae7f6b6f2", "cfe6bc2a60cb9ff8", "53e7f15d6f32647f"]

from _lib import me, CELL, donuts, stolen, facing

MOVES = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0),
         "ACTION3": (0, -CELL), "ACTION4": (0, CELL)}
DV = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}


def _target(nxt):
    """结果帧里玩家正前方那一格的格坐标；定位不到或出界返回 None。"""
    b = me(nxt)
    fc = facing(nxt)
    if b is None or fc is None:
        return None
    t = (b[0] // CELL + DV[fc][0], b[1] // CELL + DV[fc][1])
    if not (0 <= t[0] < 64 // CELL and 0 <= t[1] < 64 // CELL):
        return None
    return t


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if (action or "").startswith("RESET"):
        return "NA"
    if action not in MOVES:
        return "NA"
    if any(ring == 0 for _, _, ring in donuts(prev)):
        return "NA"                       # 拖行中不发生夺回
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    dv = MOVES[action]
    if (b[0] - a[0], b[1] - a[1]) not in ((0, 0), dv):
        return "NA"                       # 既没走成也没原地：不是本条认得的一步
    t = _target(nxt)
    if t is None:
        return "NA"
    if t in {(r // CELL, c // CELL) for r, c, _ in donuts(prev)}:
        return "NA"                       # 上一帧那里就坐着自由甜甜圈：归 donut_push_activate
    carried = set(stolen(prev))
    if t not in carried and not any(abs(p[0] - t[0]) + abs(p[1] - t[1]) == 1 for p in carried):
        return "NA"                       # 那一格既不是货，也没有货能在这一步挪进来
    if t in set(stolen(nxt)):
        return "FALSE"                    # 货坐在我正前方却仍是环5：没夺回来
    ring = {(r // CELL, c // CELL): k for r, c, k in donuts(nxt)}.get(t)
    if ring is None:
        return "NA"                       # 那一格这一帧空着：货被搬去了别处，本条管不着
    return "TRUE" if ring == 3 else "FALSE"
