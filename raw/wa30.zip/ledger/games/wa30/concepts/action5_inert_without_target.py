"""ACTION5 打空时（玩家四邻没有鼹鼠、没有被搬的货、没有环3 的甜甜圈，正前方那一格也不是甜甜圈），
玩家那 16 个像素一格不变，场上也不出现被抓取的甜甜圈（环0）——这一步除了倒计时以外，玩家什么也没做成。
侧邻或背后躺着一颗自由态(环4)的甜甜圈不碍事。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；换关/RESET（ctx.level_prev != level_next）返回 NA；me()/facing() 定位不到返回 NA；"
         "场上已有环0（正拖着一颗）返回 NA；玩家四邻格里有环3 甜甜圈、鼹鼠、或被搬的货，"
         "返回 NA——那几片分别归 donut_grab_toggle 与 action5_vanishes_adjacent_mole 管；"
         "正前方那一格上坐着甜甜圈（任何环）返回 NA——正对着货按 A5 是什么，语料里一条都没有，不表态。"
         "同一步别处的甜甜圈怎么变（鼹鼠捡起或放下）不归这条管，只主张玩家自己那一块和「没抓起任何东西」。")
NOTE = ("v1：第1关步1871 要「原地等鼹鼠把它背上那颗送到容器」时抽出。等待也是策略的一步，"
        "而『A5 打空等于不动』在册子里一直没人说过——不写它，规划器就只能靠左右横跳来消磨时间，"
        "那既踩得到容器空位、也可能挡了鼹鼠的路。全量语料实测：满足 scope 的转移 141 条"
        "（第0关110、第1关1、第5关9、第7关20、第8关1），141 条里玩家那 16 个像素全部一格没变、"
        "结果帧一次也没出现过环0；另有 5 条转移里别处的货变了环，逐条看都是鼹鼠自己捡起/放下，"
        "所以 scope 明写这条不管别处的货。"
        "v2：**场上有货在鼹鼠背上时 apply 闭嘴**。v1 入册即报 P=0.990（认领 1632 格说错 16），"
        "那 16 格是第7关步1670（tid e2185dc1f4148a99）：玩家按 A5 打空，同一步鼹鼠把它驮的最后一颗"
        "投进了容器，第7关直接换到第8关，整帧重画。assert_ 靠 ctx 的 level_prev != level_next 返回 NA，"
        "apply 看不到结果帧，只能从 prev 上认：驮着货的鼹鼠随时可能投进最后一个位，所以 stolen(prev) "
        "非空就不生成。这一条同时是「鼹鼠送货也能换关」的直接证据。"
        "v4（总账记 v4：v2 之后有过一版只改词汇的重结算；第7关步2919 蹲巢时抽出）：巢边总躺着环4，之前的 scope 一碰到它就闭嘴，策略只剩「按被挡的方向键」当空拍，"
        "那会把刚对准贼的头转开——蹲点要的恰恰是不转头的空拍。全语料复核（探针 probe_a5_beside_ring4）："
        "手上没货、四邻无鼹鼠/环3/环5、四邻有环4、正前方不是甜甜圈时按 A5，共 9 条（第0关6、第1关1、第7关2 …），"
        "9/9 玩家格与朝向一格不变、无环0 出现；有 3 条别处的环4 变了，逐条看都是鼹鼠在远处捡货，本条不管。"
        "所以这一版把四邻的排除从「任何甜甜圈」缩到「环3」，另加一条「正前方那一格不是甜甜圈」——"
        "正对着货按 A5 语料里一条都没有，不表态。")
EVIDENCE = ["94af4f25d90efd6a", "82c7ca4f09f23e2e", "53256910c7d00b01",
            "44f4dd499e61f606", "6aaad2383ea348c5", "e2185dc1f4148a99",
            "f2dab853f3ef59bd", "2ad63067cf430221", "2db6527337f87d09", "3a00679708765a2d",
            "b35c84acebc2ade0", "c3cd178bfac87059", "c16361d5ca46e9ac"]

from _lib import CELL, me, facing, donuts, moles, stolen, cell_px, mask_timer_row

DV = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}


def _idle_scope(prev):
    """返回玩家格 (r, c)；不在 scope 里返回 None。"""
    if donuts(prev, ring=0):
        return None
    a = me(prev)
    fc = facing(prev)
    if a is None or fc is None:
        return None
    pc = (a[0] // CELL, a[1] // CELL)
    rings = {(r // CELL, c // CELL): k for r, c, k in donuts(prev)}
    front = (pc[0] + DV[fc][0], pc[1] + DV[fc][1])
    if front in rings:
        return None                      # 正对着货：不表态
    near = [q for q, k in rings.items() if k == 3] + list(moles(prev)) + list(stolen(prev))
    for n in near:
        if abs(n[0] - pc[0]) + abs(n[1] - pc[1]) == 1:
            return None
    return pc


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    pc = _idle_scope(prev)
    if pc is None:
        return "NA"
    if donuts(nxt, ring=0):
        return "FALSE"
    return "TRUE" if cell_px(prev, pc[0], pc[1]) == cell_px(nxt, pc[0], pc[1]) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION5"):
        return None
    if stolen(prev):
        return None      # 鼹鼠驮着货：它这一步可能把最后一颗投进容器，整帧重画（第7关步1670）
    pc = _idle_scope(prev)
    if pc is None:
        return None
    return mask_timer_row({(pc[0] * CELL + dr, pc[1] * CELL + dc): prev[pc[0] * CELL + dr][pc[1] * CELL + dc]
                           for dr in range(CELL) for dc in range(CELL)})   # 行15 的第 4 像素行是计时条，它每步在变，不押
