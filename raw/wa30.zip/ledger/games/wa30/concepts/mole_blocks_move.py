"""目的格上蹲着鼹鼠时这一步整步不走：玩家停在原格，拖着的甜甜圈也停在原格。"""
LEVEL = "L2"
SCOPE = ("只看四向移动、且「玩家的目的格」或「被拖甜甜圈(环0)的目的格」上有鼹鼠的转移；"
         "其余返回 NA；换关返回 NA；玩家块定位不到返回 NA。"
         "证据目前只有「货的目的格上有鼹鼠」这一种（第4关步962）；"
         "「玩家自己撞上鼹鼠」这一支是同一句话的另一半，还没撞过，留在主张里等它被检验。")
NOTE = ("v1：第4关步962 抽出——玩家(8,8)拖着(7,8)的货西行，隧道里那只鼹鼠停在(7,7)，"
        "整帧一格没动（连计时条都没跳）。这是本局第一次看到鼹鼠当阻挡：此前鼹鼠只以「偷」出现。"
        "注意它与 mole_steal_on_block 的分工：那条说的是鼹鼠去撞货(环4)会把货偷走，"
        "这条说的是玩家拖着货去撞鼹鼠会被挡回来——环0的货没有被偷，鼹鼠也没动。"
        "同一批里 _lib.move_refused 补上鼹鼠这一支，好让 apply 在这种步上闭嘴（本步押注错了64格）。"
        "v2：断言原先比首行的主张更严——首行只说「停在原格」，代码却要求那颗货**仍是环0**（还攥在手里）。"
        "终局卡第7关步2666 打了这一处：玩家(2,7)拖着(2,8)的货南行，货的目的格(3,8)上蹲着皮15 的贼，"
        "玩家确实没动、货也确实留在(2,8)，但环从0变成3——人被挡住的同时脱了手。"
        "改法是让断言回到首行那句话：只主张两个位置不变，攥没攥住交给新概念 drag_released_by_thief_block，"
        "那条把「挡路的是不是贼」和「拖行断不断」连起来说，本条不再兼管。")
EVIDENCE = ["61d7fbe04db1e457", "628999e757ee2b48", "a1f58ce834a09cb4", "3e93fc2f55b4378a"]

from _lib import CELL, me, moles, donuts, block_top_left

MOVES = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def _held(g):
    return [(r // CELL, c // CELL) for r, c, ring in donuts(g) if ring == 0]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dv = MOVES.get((action or "")[:7])
    if dv is None:
        return "NA"
    held = _held(prev)
    a = block_top_left(prev)
    if a is None:
        return "NA"
    pcell = (a[0] // CELL, a[1] // CELL)
    targets = [(pcell[0] + dv[0], pcell[1] + dv[1])]
    if len(held) == 1:
        targets.append((held[0][0] + dv[0], held[0][1] + dv[1]))
    ms = set(moles(prev))
    if not any(t in ms for t in targets):
        return "NA"
    held_n = _held(nxt)   # noqa: F841  留着只为读者看清「脱手与否」不归这条管
    b = block_top_left(nxt)
    if b is None:
        return "NA"
    if (b[0] // CELL, b[1] // CELL) != pcell:
        return "FALSE"
    if not held:
        return "TRUE"
    # 「停在原格」按字面算：那一格上仍有一颗甜甜圈就算数，环是 0 还是 3（有没有脱手）不归这条管。
    at = {(r // CELL, c // CELL) for r, c, _ in donuts(nxt)}
    return "TRUE" if held[0] in at else "FALSE"
