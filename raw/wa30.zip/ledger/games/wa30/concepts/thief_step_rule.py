"""皮色15 的贼每步最多挪一格：两帧贼数相同时，存在一个 prev→next 的一一配对，使每一对的曼哈顿距离都 ≤1。"""
LEVEL = "L6"
SCOPE = ("只看皮色15 的鼹鼠；换关、RESET 返回 NA；两帧贼数不等（杀掉一只、或新生成）返回 NA；"
         "帧上一只贼都没有返回 NA。不主张它往哪个方向走——方向没抽出来，见 NOTE。")
NOTE = ("v1：子 agent 从全量语料抽出，原稿只在「场上恰好一只贼」时开口（510 条全 TRUE，0 反例）。"
        "入册时扩到多只：第7关常驻两只贼，只认单只等于在最需要它的关卡里全程 NA。"
        "扩法是要求存在一个一一配对让每对距离都 ≤1——两只贼时这仍是实打实的约束，不是恒真。"
        "原稿实测的分项数字（单贼语料）：驮货 31 步四邻移动 + 5 步零位移，空手 402 步 + 72 步零位移。"
        "零位移不等于被堵死：77 个零位移案例里 75 个至少有一个方向畅通，它是「不想走」不是「走不了」。"
        "方向抽不出来：驮货朝最近巢格的贪心只对 13/36，空手朝最近环4 散货 151/466，朝玩家 91/474，"
        "三个候选的「距离减少」占比都在 41~45% 之间，谁也不主导。所以这条只断言步长上界，不猜方向。"
        "这条的用处在规划器：切批时留的「鼹鼠走 i 步最多挪 i 格」那道余量，此前是语料看下来的习惯，"
        "不是册子里的规则；现在它走闸了。")
EVIDENCE = ["8e40ff2ea2289865", "5d2b6857cc98260c", "4853e810568ba207",
            "ec7f1ae6210d448d", "6f4cc4500f249968", "d3b289e396cee6fb",
            "dcef6a99e159e8d4"]

from itertools import permutations

from _lib import mole_skins

THIEF_SKIN = 15


def _thieves(g):
    return sorted(p for p, s in (mole_skins(g) or {}).items() if s == THIEF_SKIN)


def assert_(prev, action, nxt, ctx=None):
    if (action or "") == "RESET":
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = _thieves(prev), _thieves(nxt)
    if not a or len(a) != len(b):
        return "NA"      # 杀掉一只 / 新生成 / 一只都没有：配不成对，这条不说话
    if len(a) > 4:
        return "NA"      # 配对是全排列，只在小规模上算；语料里没见过 4 只以上
    for perm in permutations(b):
        if all(abs(p[0] - q[0]) + abs(p[1] - q[1]) <= 1 for p, q in zip(a, perm)):
            return "TRUE"
    return "FALSE"
