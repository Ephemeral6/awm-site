"""鼹鼠投放（环5 原格变环4）的落点由皮色决定：色12 只投进 2+9 容器格（home_cells），色15 只投进纯2 巢格（den_cells）——两种皮是帮手与贼。"""
LEVEL = "L6"
SCOPE = ("只看投放转移：prev 帧某格是环5、nxt 帧同一格是环4；换关、RESET 返回 NA。"
         "投放者 = nxt 帧里位置与 prev 相同、皮色相同、且与落点正相邻（曼哈顿 1）的那只鼹鼠；"
         "候选不是恰好一只（比如那一步鼹鼠被清除了，见 killed_mole_drops_cargo）返回 NA。"
         "落点归类只在读得出来时表态：home_cells 是容器格的下界（可见空位 + 甜甜圈连通补全），"
         "den_cells 是巢格的下界（可见纯2 + 连通补全）；落点两边都不在（容器被盖满看不见、巢被盖满看不见、"
         "第3关那种孤立小容器被盖住）返回 NA；两边都在（容器紧贴着巢）也返回 NA。"
         "在 scope 内断言：色12 的落点在容器不在巢，色15 的落点在巢不在容器；别的皮色返回 NA。")
NOTE = ("第7关步1227-1229 抽出：开局四只鼹鼠，两只色12 两只色15，各偷一颗——色12 那两只把 (12,9)、(2,7) "
        "径直送进东边的 2+9 容器 (12,12)、(2,11)，色15 那两只把 (13,8)、(3,8) 往西边的纯2 巢运，"
        "(13,8) 已落在 (14,5)。同一关同一时刻两种皮走两个方向，皮色是唯一的分界。"
        "全量语料复核（probe_drop_by_skin.py，34 次投放）：色12 落容器 18 次、读不出 9 次（第3关孤立小容器被盖住）、"
        "落巢 0 次；色15 落巢 4 次、读不出 1 次（第6关步1183，投放后巢两格全被盖住）、落容器 0 次。"
        "回头看：第1-4关全是色12，鼹鼠一直在替我送货，我却把它当贼防；第5-6关只有色15，"
        "它偷坐在容器上的那颗往巢里运（第6关步1171 从容器 (7,3) 偷走）——两关的印象合在一起才看出是皮色分了工。"
        "为什么要紧：第7关 13 颗甜甜圈、条只够 128 步，我自己一颗颗拖根本送不完；"
        "分清帮手和贼之后，正确的打法是杀掉色15、让色12 替我送。"
        "已知的窄处：色12 会不会去偷已经坐在容器上的那颗、色15 会不会偷巢里的那颗，本条不管（那是「选哪颗目标」的事）；"
        "落点归类靠两个下界词，它们瞎的时候本条只会 NA 不会 FALSE。")
EVIDENCE = ["0582bc8229ee0718", "625fefab5b72f2c7", "751428b7e07e01d6",
            "5d2b6857cc98260c", "761747b262ff59a4", "86f44f1451976b2e", "5116fc8e9992c615"]
# 前三条是第7关同一关里两种皮各自的落点；后四条是第5/6关色15 落巢、第1/4关色12 落容器。

from _lib import CELL, donuts, stolen, mole_skins, home_cells, den_cells

HELPER, THIEF = 12, 15


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if (action or "") == "RESET":
        return "NA"
    after = {(r // CELL, c // CELL): k for r, c, k in donuts(nxt)}
    drops = [cell for cell in set(stolen(prev)) - set(stolen(nxt)) if after.get(cell) == 4]
    if not drops:
        return "NA"
    sp, sn = mole_skins(prev), mole_skins(nxt)
    hc, dc = home_cells(nxt), den_cells(nxt)
    verdict = "NA"
    for cell in drops:
        cands = [m for m in sn if m in sp and sp[m] == sn[m]
                 and abs(m[0] - cell[0]) + abs(m[1] - cell[1]) == 1]
        if len(cands) != 1:
            continue
        skin = sn[cands[0]]
        in_home, in_den = cell in hc, cell in dc
        if in_home == in_den:
            continue                    # 读不出（都不在）或分不开（都在）
        if skin == HELPER:
            ok = in_home
        elif skin == THIEF:
            ok = in_den
        else:
            continue
        if not ok:
            return "FALSE"
        verdict = "TRUE"
    return verdict
