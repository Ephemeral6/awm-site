"""被 ACTION5 清除的鼹鼠若正扛着货（prev 帧有一颗环5 与它正相邻），那颗货当步原格变成环4 自由甜甜圈，不消失、不留环5。"""
LEVEL = "L6"
SCOPE = ("只看以 ACTION5 开头、且 prev 帧上玩家头朝的那一格是皮色15 鼹鼠、nxt 帧那一格不再是鼹鼠（它被清除了）的转移；"
         "玩家块或头朝向读不出来返回 NA；prev 帧上与被清除格正相邻（曼哈顿 1）的环5 不是恰好一颗返回 NA"
         "（零颗是空手、两颗分不清谁的货）；换关返回 NA。"
         "断言：那一颗在 nxt 帧原格是环4。")
NOTE = ("第7关步1229 抽出：色15 贼从 (4,5) 西行到我头朝的 (4,4)、扛着 (3,4) 那颗（偏移 (-1,0)），"
        "我按 A5，它整块消失，(3,4) 当步环5 变环4，位置一格没动。"
        "这是整局第一次对扛着货的鼹鼠下手——action5_vanishes_adjacent_mole v3 的 NOTE 里明写「货掉在哪没见过」。"
        "为什么值得在这一步做：这局才走 7 步，货要是跟着消失，RESET 重来也便宜；"
        "而第7关有两只贼都会扛货，不知道货的去向就不敢杀。"
        "已知的窄处：只见过一次；只见过偏移 (-1,0)（货在鼹鼠正上方）；被清除的只有色15。"
        "apply 只画那颗环 4→ 已知盲区同 action5 那条：鼹鼠格本身由 action5_vanishes_adjacent_mole 画。")
EVIDENCE = ["751428b7e07e01d6"]

from _lib import CELL, me, block_top_left, head_in_block, mole_skins, stolen, donuts, paint_donut

VANISH_SKIN = 15
DIRS = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}


def _cargo(prev, action):
    """被清除的那只鼹鼠扛着的那颗货的格；不在 scope 内返回 None。"""
    if not (action or "").startswith("ACTION5"):
        return None
    skins = mole_skins(prev)
    p = block_top_left(prev) or me(prev)
    if p is None:
        return None
    face = head_in_block(prev)
    if face is None:
        return None
    pc = (p[0] // CELL, p[1] // CELL)
    dv = DIRS[face]
    faced = (pc[0] + dv[0], pc[1] + dv[1])
    if skins.get(faced) != VANISH_SKIN:
        return None
    near = [s for s in stolen(prev) if abs(s[0] - faced[0]) + abs(s[1] - faced[1]) == 1]
    if len(near) != 1:
        return None
    return faced, near[0]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    got = _cargo(prev, action)
    if got is None:
        return "NA"
    faced, cargo = got
    if faced in mole_skins(nxt):
        return "NA"                     # 鼹鼠没被清除，不归本条管
    after = {(r // CELL, c // CELL): k for r, c, k in donuts(nxt)}
    return "TRUE" if after.get(cargo) == 4 else "FALSE"


def apply(prev, action, ctx=None):
    got = _cargo(prev, action)
    if got is None:
        return None
    _, cargo = got
    return paint_donut(cargo[0], cargo[1], 4)
