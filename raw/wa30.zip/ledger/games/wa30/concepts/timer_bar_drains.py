"""同一关内、非 RESET 的每一步，计时条只会缩短 0 或 1 像素，绝不回涨。"""
LEVEL = "L4"
SCOPE = ("只看同一关内(ctx.level_prev == ctx.level_next)且动作不是 RESET 的转移；"
         "换关与 RESET 那一步条会跳回满格 64，本条不管，返回 NA。")
NOTE = ("v1：第4关步957-987 实测——条从 64 一路掉到 48，掉在 957/959/961/963/965/967/969/971/973/975/977/979/"
        "981/983/985/987，即每两步掉一像素，中间那一步纹丝不动。"
        "本条只主张「至多掉1、绝不回涨」这半边：它是速率的下界包络，给规划用的是「条上还剩 b 像素 ⇒ 至少还能走 b 步」。"
        "「恰好两步掉一格」这个速率写不成单条转移的断言——一条转移看不见相位，"
        "而相位既不能从条长奇偶推出来（条=63 时既掉过也没掉过），也不在 ctx 里。"
        "所以速率留作规划时每批自己复核的读数，进不了闸；能进闸的只有这个包络。")
EVIDENCE = ["417f2cced0791fac", "a95be54d826f9c3e"]

from _lib import timer_px


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if (action or "").startswith("RESET"):
        return "NA"
    b0, b1 = timer_px(prev), timer_px(nxt)
    return "TRUE" if b1 in (b0, b0 - 1) else "FALSE"
