"""拖着的那颗货被鼹鼠挡住时，挡路的是皮15 的贼就地脱手（环0→3），是皮12 或它驮的货则仍攥着。"""
LEVEL = "L6"
SCOPE = ("只看四向移动、且场上恰好一颗环0（拖着的）货、且**那颗货的目的格**上有鼹鼠本体或被驮的货、"
         "而**玩家自己的目的格**上没有鼹鼠的转移；其余返回 NA；换关、RESET 返回 NA；玩家块定位不到返回 NA。"
         "只说拖行断不断，不说玩家动不动——位置那半句归 mole_blocks_move。")
NOTE = ("v1：终局卡第7关步2666 抽出。玩家(2,7)拖着(2,8)的货南行，货的目的格(3,8)上蹲着皮15 的贼，"
        "结果玩家没动、货也留在(2,8)，但环从0变成3——被挡住的同时脱了手。"
        "这一步是策略主动按出来的：当时想用「顶住不走」当作空等一拍，结果赔掉了拖行。"
        "**样本很薄**：全语料里这种局面只有 4 条，皮15 挡路的只有这 1 条（步2666，脱手），"
        "另外 3 条挡路的是皮12 本体（步844、步962）或皮12 驮着的那颗环5 货（步1687），三条都没脱手。"
        "所以「皮15 会让你脱手」这半句的分母是 1，「皮12 不会」这半句的分母是 3——两半都写进断言，"
        "哪一半错了都当场关闸。若后来发现真正的分界不是皮色（比如是「贼正驮着货没有」或纯粹随机），"
        "这条会在下一次同类局面上判 FALSE，那时再改。"
        "用处在规划器：拖着货时不许拿「顶住贼」当空等手段，得换个方向顶。")
EVIDENCE = ["628999e757ee2b48", "61d7fbe04db1e457", "a1f58ce834a09cb4", "3e93fc2f55b4378a"]

from _lib import CELL, block_top_left, donuts, mole_skins, moles, stolen

MOVES = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}
THIEF_SKIN = 15


def _held(g):
    return [(r // CELL, c // CELL) for r, c, ring in donuts(g) if ring == 0]


def assert_(prev, action, nxt, ctx=None):
    if (action or "") == "RESET":
        return "NA"
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dv = MOVES.get((action or "")[:7])
    if dv is None:
        return "NA"
    held = _held(prev)
    if len(held) != 1:
        return "NA"
    a = block_top_left(prev)
    if a is None:
        return "NA"
    pcell = (a[0] // CELL, a[1] // CELL)
    bodies = set(moles(prev))
    blockers = bodies | set(stolen(prev))
    if (pcell[0] + dv[0], pcell[1] + dv[1]) in blockers:
        return "NA"                       # 玩家自己也撞上了：两种挡混在一起，这条不说话
    dst = (held[0][0] + dv[0], held[0][1] + dv[1])
    if dst not in blockers:
        return "NA"
    skin = (mole_skins(prev) or {}).get(dst)      # 被驮的货那一格没有皮色，skin 是 None
    still_held = _held(nxt)
    if skin == THIEF_SKIN:
        # 脱手：环0 没了，而那一格上仍有一颗（没被谁拿走）
        at = {(r // CELL, c // CELL) for r, c, _ in donuts(nxt)}
        return "TRUE" if (not still_held and held[0] in at) else "FALSE"
    return "TRUE" if still_held == held else "FALSE"
