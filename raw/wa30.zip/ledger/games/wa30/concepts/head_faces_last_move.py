"""头（色0 条）贴在块的哪条边，就等于上一次成功移动的方向；但拖着甜甜圈(环0在场)移动时头保持抓取瞬间的朝向不转。"""
LEVEL = "L6"
SCOPE = "四向移动与 ACTION5；RESET 重画返回 NA；换关返回 NA；头定位不到返回 NA"
NOTE = ("v3：RESET 重画返回 NA——重画的头朝向是重画的产物不是移动的产物；"
        "v4：拖行头不转——第1关步642（A3左移拖D_e，实机头仍朝抓取时的右）；"
        "环0 也是色0，全帧扫描会被它污染，拖行分支改用 head_in_block（色14 定位块）；"
        "v5：补 apply，只画「被挡住时原地转头」这一种。断言早就主张移动键按下去头必朝那边（不论走没走成），"
        "apply 却一格不画，于是每一次顶住/撞墙都白送 8 格残差；更要命的是合成帧串链里头一直停在旧朝向，"
        "下一步拖行时 action2_down 按旧朝向画头，整批 strict 停在那里（第3关步855预测时发现）")
EVIDENCE = ["b522df4c37607269", "7100c3a5f5159465", "bea220486f78fc4d", "9c53253544a7a8a8", "900bcacebb131111", "db57c51de61c7087", "2d6349d985dde9cc", "3a07bb1f7788c9f3", "46be7338bdcbedad", "554d5951a5864502", "69b5767e306ad0a5", "6b31c194fefe9e3b", "98375cfd6efc4158", "c2ba860f077818fe", "ce05fdc182c2cdc3", "fb345fbf938fda0a", "76c0df7b8d74fcc8", "6e45d86bb94b541f"]

from _lib import facing, head_in_block, donuts, me, CELL, move_refused, mask_timer_row

DIRS = {"ACTION1": "up", "ACTION2": "down", "ACTION3": "left", "ACTION4": "right"}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action == "RESET":
        return "NA"                # 重画整帧，头朝向是重画的产物不是移动的产物
    held = any(ring == 0 for _, _, ring in donuts(prev))
    if held:
        f_prev = head_in_block(prev)
        f_nxt = head_in_block(nxt)
        if f_prev is None or f_nxt is None:
            return "NA"
        return "TRUE" if f_prev == f_nxt else "FALSE"   # 拖行头不转
    f_prev = facing(prev)
    f_nxt = facing(nxt)
    if f_prev is None or f_nxt is None:
        return "NA"
    # 主张：每次成功移动后，头 = 移动方向
    want = {"ACTION1": "up", "ACTION2": "down", "ACTION3": "left", "ACTION4": "right"}.get(action)
    if want is None:
        # ACTION5 等其它动作：头不变（待考）
        return "TRUE" if f_prev == f_nxt else "FALSE"
    return "TRUE" if f_nxt == want else "FALSE"


def apply(prev, action, ctx=None):
    """只画「原地转头」这一种：玩家被挡住整步不走时，块留在原处、头转向按键方向。
    走得成的那些步由 action*_up/down/left/right 自己把头画在新块上，这里不插手。"""
    want = DIRS.get((action or "")[:7])
    if want is None:
        return None
    if any(ring == 0 for _, _, ring in donuts(prev)):
        return None                      # 拖行头不转（第1关步642）
    if not move_refused(prev, action, ctx):
        return None                      # 走得成：新块的头归动作概念画
    a = me(prev)
    if a is None:
        return None
    out = {}
    for dr in range(CELL):
        for dc in range(CELL):
            edge = ((want == "up" and dr == 0) or (want == "down" and dr == CELL - 1)
                    or (want == "left" and dc == 0) or (want == "right" and dc == CELL - 1))
            out[(a[0] + dr, a[1] + dc)] = 0 if edge else 14
    return mask_timer_row(out)      # 最底一行格的第 4 像素行是计时条，不押（终局卡第4关步2088）
