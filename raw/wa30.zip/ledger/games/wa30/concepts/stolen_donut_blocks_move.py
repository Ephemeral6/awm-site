"""被鼹鼠扛着的甜甜圈（环5）和自由甜甜圈一样挡人：玩家的目的格或所拖货的目的格上有环5 时，这一步整步不走。"""
LEVEL = "L2"
SCOPE = ("只看四向移动、且「玩家的目的格」或「被拖甜甜圈(环0)的目的格」在 prev 帧上有环5 的转移；"
         "其余返回 NA；换关/RESET 返回 NA；玩家块定位不到返回 NA。"
         "只断言「这一步的移动没有发生」（玩家格不变、拖着的货格不变），"
         "不管头朝哪、不管鼹鼠这一步走到哪、也不管那颗环5 会不会同时被夺回。")
NOTE = ("为什么单独立一条：册子里管阻挡的三条各管一种——capsule_walkable / "
        "color2_blocks_move_unless_pure2 管地形，donut_push_activate 管环3/4 的甜甜圈（顶住），"
        "mole_blocks_move 管鼹鼠本体。**环5 没人管**：词汇 donuts() 只认环 0/3/4，环5 归 stolen()，"
        "于是 _lib.move_refused 的甜甜圈那一支天生看不见它。"
        "后果在第6关步1156 当场发作：玩家在(7,8)按 A2，(8,8) 上是鼹鼠扛着的那颗环5，"
        "世界整步不走只转了头，而模型押玩家走进(8,8)，32 格全错、strict 停批（tid 9bd1fb99da9cae06）。"
        "更值得记的是**它没有变成反例**：action2_down 的断言对「玩家没动」照判 TRUE，"
        "只有 apply 错了——错在生成器，检查器看不见。这正是结算里「说错却判 TRUE」那一栏在说的事。"
        "全量语料复核（probe_stolen_blocks.py）：整局 1110 条转移里，目的格上有环5 的只有这一次，"
        "走进去的零次。所以这条现在只有一条证据，是一句押得很宽的话，等着被撞。"
        "同一批里 _lib.move_refused 补上 stolen() 这一支，让四个动作概念在这种步上闭嘴；"
        "词汇改动不算版本、不打分，所以主张必须写在这里。")
EVIDENCE = ["9bd1fb99da9cae06"]

from _lib import CELL, me, block_top_left, donuts, stolen

MOVES = {"ACTION1": (-1, 0), "ACTION2": (1, 0), "ACTION3": (0, -1), "ACTION4": (0, 1)}


def _held(g):
    return [(r // CELL, c // CELL) for r, c, ring in donuts(g) if ring == 0]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    dv = MOVES.get((action or "")[:7])
    if dv is None:
        return "NA"
    held = _held(prev)
    a = block_top_left(prev) if held else me(prev)
    if a is None:
        return "NA"
    pcell = (a[0] // CELL, a[1] // CELL)
    targets = [(pcell[0] + dv[0], pcell[1] + dv[1])]
    if len(held) == 1:
        targets.append((held[0][0] + dv[0], held[0][1] + dv[1]))
    st = set(stolen(prev))
    if not any(t in st for t in targets):
        return "NA"
    held_n = _held(nxt)
    b = block_top_left(nxt) if held_n else me(nxt)
    if b is None:
        return "NA"
    if (b[0] // CELL, b[1] // CELL) != pcell:
        return "FALSE"
    return "TRUE" if held_n == held else "FALSE"
