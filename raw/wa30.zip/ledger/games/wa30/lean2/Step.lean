/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    玩家那半步（walk / drag / press 三选一）→ 鼹鼠那半步（molesAct）→ 用掉一步（tick）
    → 赢了（isGoal）/ 时间到（timeUp）/ 接着走

鼹鼠那半步只交回三样（甜甜圈、鼹鼠、手上攥没攥着），`merge` 把它们拼回玩家那半步的结果：
玩家的位置、朝向、已用步数它**碰不到**。

`RESET` 模型不描述（`.na`）：「重来之后是哪一帧」是历史，帧上读不出来。
这一支会让「赢不了」悄悄变成「**不经过 RESET** 就赢不了」——那半句写在 `Proof/Reachable.lean`。

（这里不写 `let`：`def` 里的 `let` 会让推论那一层的 `split` 进不去。）
-/

import Rule.Player.Walk
import Rule.Player.Drag
import Rule.Player.Press
import Rule.Moles.MolesAct
import Rule.Clock.TimerTick
import Rule.Clock.TimeUp
import Rule.Goal.LevelUp

namespace Game

inductive Act where
  | a1 | a2 | a3 | a4 | a5 | reset
deriving DecidableEq, Repr

inductive Res where
  | ok (s : St)
  | won (s : St)
  | over (s : St)
  | na

def Act.dir? : Act → Option Dir
  | .a1 => some .up | .a2 => some .down | .a3 => some .left | .a4 => some .right
  | _ => none

def playerPhase (b : Board) (s : St) : Act → St
  | .a5 => press s
  | .reset => s
  | a => match a.dir? with
    | some d => if s.holding then drag b s d else walk b s d
    | none => s

def merge (s1 : St) (o : List Cell × List Mole × Bool) : St :=
  { s1 with donuts := o.1, moles := o.2.1, holding := o.2.2 }

def afterStep (b : Board) (s : St) (a : Act) : St :=
  tick (merge (playerPhase b s a) (molesAct b (playerPhase b s a)))

def settle (b : Board) (s3 : St) : Res :=
  if isGoal b s3 then .won s3 else if timeUp b s3 then .over s3 else .ok s3

def step (b : Board) (s : St) (a : Act) : Res :=
  if a = .reset then .na else settle b (afterStep b s a)

end Game
