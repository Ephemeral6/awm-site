/-
# Reachable —— 一个局面做不做得了（骨架）

    Winnable   b s := ∃ as, 照着 as 走、中途赢过
    Unsolvable b s := ∀ as, 照着 as 走从没赢过

**「赢不了」在这里的准确意思是「不经过 RESET 就赢不了」**：`step` 碰到 RESET 返回 `.na`，
`everGoal` 在那一支给 `false`。这半句在这里、在 `Step.lean`、在页面上三处写明。
（这一局语料里九关全都走通了，所以没有一关要用到「赢不了」那一半；骨架照样立着、照样证过，
它是以后宣告某个局面做不了时唯一许用的形状：不变量 ⇒ 赢不了，不许枚举、不许搜索。）
-/

import Obj.World
import Obs.Check

open Game

/-- 骨架：一个每一步都保持、又和「赢」矛盾的性质 ⇒ 任何动作串都赢不了（不经过 RESET）。
    整份形式化里唯一做归纳的地方，和盘面大小、动作串长短都无关。 -/
theorem Game.unsolvable_of_invariant (b : Board) (P : St → Prop)
    (hkeep : ∀ s s' a, P s → step b s a = .ok s' → P s')
    (hwin : ∀ s a s', P s → step b s a ≠ .won s') :
    ∀ s, P s → ∀ as : List Act, everGoal step b s as = false := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    unfold everGoal
    cases hs : step b s a with
    | ok s' => exact ih s' (hkeep s s' a hp hs)
    | won s' => exact absurd hs (hwin s a s' hp)
    | over _ => rfl
    | na => rfl

/-- 两句话不能同时成立。 -/
theorem Game.not_both (b : Board) (s : St)
    (hw : ∃ as : List Act, everGoal step b s as = true)
    (hu : ∀ as : List Act, everGoal step b s as = false) : False := by
  obtain ⟨as, h⟩ := hw
  rw [hu as] at h
  exact Bool.false_ne_true h

#print axioms Game.unsolvable_of_invariant
#print axioms Game.not_both
