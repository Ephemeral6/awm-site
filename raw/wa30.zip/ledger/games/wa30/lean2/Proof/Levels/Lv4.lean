/-
# 第 4 关（`lean2/export_levels.py` 生成，不要手改）

    Lv4.trace      沿段 B 里真人走过的那条路，模型**每一帧都和观测对上**——
                     只有开局那一帧是观测给的，后面 102 帧全是模型自己算的
    Lv4.winnable   这一关走得通：见证就是那条路再加上最后那一脚（第 103 步换关）
    Lv4.rows_len   切出来的那一段恰好 103 行、都属于第 4 关、都在段 B，
                     只有最后一行是换关（空表会让逐帧核对平凡为真，这一条钉住它）

开局 seq 1091；这一关核过的步数 **102**（+ 最后换关那一步由 `winnable` 核）。
这一关里没有 RESET，所以「重置放回开局」那条假设在这一关**没被用到**。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

open Game

namespace Game.Lv4

def board : Board := Replay.board 4
def rows : List Replay.Row := Replay.slice 1091 103
def start : St := startOf (Replay.frameAt ((rows.head?.map (·.prev)).getD 0))
def play : List (Act × Seen) := Replay.playOf (rows.take 102)
def acts : List Act := Replay.actsOf rows

#eval match firstSplit step board start play 0 with
  | none   => s!"Lv4  一处都没分家（{play.length} 帧）"
  | some i => s!"Lv4  第 {i} 步分家"

end Game.Lv4

theorem Game.Lv4.rows_len :
    Replay.stepCount Game.Lv4.rows = 103 ∧
    Game.Lv4.rows.all (fun r => r.lvl == 4 && r.cert && !r.over) = true ∧
    (Game.Lv4.rows.take 102).all (fun r => r.tag == 0) = true ∧
    (Game.Lv4.rows.drop 102).all (fun r => r.tag == 1) = true := by
  decide +kernel

theorem Game.Lv4.trace :
    Game.Lv4.board.wf = true ∧
    Game.traceOk Game.step Game.Lv4.board Game.Lv4.start Game.Lv4.play = true := by
  decide +kernel

theorem Game.Lv4.winnable :
    ∃ as : List Game.Act, Game.everGoal Game.step Game.Lv4.board Game.Lv4.start as = true :=
  ⟨Game.Lv4.acts, by decide +kernel⟩

#print axioms Game.Lv4.rows_len
#print axioms Game.Lv4.trace
#print axioms Game.Lv4.winnable
