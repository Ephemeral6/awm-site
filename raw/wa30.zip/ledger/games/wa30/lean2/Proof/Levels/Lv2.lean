/-
# 第 2 关（`lean2/export_levels.py` 生成，不要手改）

    Lv2.trace      沿段 B 里真人走过的那条路，模型**每一帧都和观测对上**——
                     只有开局那一帧是观测给的，后面 75 帧全是模型自己算的
    Lv2.winnable   这一关走得通：见证就是那条路再加上最后那一脚（第 76 步换关）
    Lv2.rows_len   切出来的那一段恰好 76 行、都属于第 2 关、都在段 B，
                     只有最后一行是换关（空表会让逐帧核对平凡为真，这一条钉住它）

开局 seq 957；这一关核过的步数 **75**（+ 最后换关那一步由 `winnable` 核）。
这一关里没有 RESET，所以「重置放回开局」那条假设在这一关**没被用到**。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

open Game

namespace Game.Lv2

def board : Board := Replay.board 2
def rows : List Replay.Row := Replay.slice 957 76
def start : St := startOf (Replay.frameAt ((rows.head?.map (·.prev)).getD 0))
def play : List (Act × Seen) := Replay.playOf (rows.take 75)
def acts : List Act := Replay.actsOf rows

#eval match firstSplit step board start play 0 with
  | none   => s!"Lv2  一处都没分家（{play.length} 帧）"
  | some i => s!"Lv2  第 {i} 步分家"

end Game.Lv2

theorem Game.Lv2.rows_len :
    Replay.stepCount Game.Lv2.rows = 76 ∧
    Game.Lv2.rows.all (fun r => r.lvl == 2 && r.cert && !r.over) = true ∧
    (Game.Lv2.rows.take 75).all (fun r => r.tag == 0) = true ∧
    (Game.Lv2.rows.drop 75).all (fun r => r.tag == 1) = true := by
  decide +kernel

theorem Game.Lv2.trace :
    Game.Lv2.board.wf = true ∧
    Game.traceOk Game.step Game.Lv2.board Game.Lv2.start Game.Lv2.play = true := by
  decide +kernel

theorem Game.Lv2.winnable :
    ∃ as : List Game.Act, Game.everGoal Game.step Game.Lv2.board Game.Lv2.start as = true :=
  ⟨Game.Lv2.acts, by decide +kernel⟩

#print axioms Game.Lv2.rows_len
#print axioms Game.Lv2.trace
#print axioms Game.Lv2.winnable
