/-
# 第 8 关（`lean2/export_levels.py` 生成，不要手改）

    Lv8.trace      沿段 B 里真人走过的那条路，模型**每一帧都和观测对上**——
                     只有开局那一帧是观测给的，后面 64 帧全是模型自己算的
    Lv8.winnable   这一关走得通：见证就是那条路再加上最后那一脚（第 65 步换关）
    Lv8.rows_len   切出来的那一段恰好 65 行、都属于第 8 关、都在段 B，
                     只有最后一行是换关（空表会让逐帧核对平凡为真，这一条钉住它）

开局 seq 1457；这一关核过的步数 **64**（+ 最后换关那一步由 `winnable` 核）。
这一关里没有 RESET，所以「重置放回开局」那条假设在这一关**没被用到**。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

open Game

namespace Game.Lv8

def board : Board := Replay.board 8
def rows : List Replay.Row := Replay.slice 1457 65
def start : St := startOf (Replay.frameAt ((rows.head?.map (·.prev)).getD 0))
def play : List (Act × Seen) := Replay.playOf (rows.take 64)
def acts : List Act := Replay.actsOf rows

#eval match firstSplit step board start play 0 with
  | none   => s!"Lv8  一处都没分家（{play.length} 帧）"
  | some i => s!"Lv8  第 {i} 步分家"

end Game.Lv8

theorem Game.Lv8.rows_len :
    Replay.stepCount Game.Lv8.rows = 65 ∧
    Game.Lv8.rows.all (fun r => r.lvl == 8 && r.cert && !r.over) = true ∧
    (Game.Lv8.rows.take 64).all (fun r => r.tag == 0) = true ∧
    (Game.Lv8.rows.drop 64).all (fun r => r.tag == 1) = true := by
  decide +kernel

theorem Game.Lv8.trace :
    Game.Lv8.board.wf = true ∧
    Game.traceOk Game.step Game.Lv8.board Game.Lv8.start Game.Lv8.play = true := by
  decide +kernel

theorem Game.Lv8.winnable :
    ∃ as : List Game.Act, Game.everGoal Game.step Game.Lv8.board Game.Lv8.start as = true :=
  ⟨Game.Lv8.acts, by decide +kernel⟩

#print axioms Game.Lv8.rows_len
#print axioms Game.Lv8.trace
#print axioms Game.Lv8.winnable
