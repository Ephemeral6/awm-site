/-
# 第 3 关（`lean2/export_levels.py` 生成，不要手改）

    Lv3.trace      沿段 B 里真人走过的那条路，模型**每一帧都和观测对上**——
                     只有开局那一帧是观测给的，后面 57 帧全是模型自己算的
    Lv3.winnable   这一关走得通：见证就是那条路再加上最后那一脚（第 58 步换关）
    Lv3.rows_len   切出来的那一段恰好 58 行、都属于第 3 关、都在段 B，
                     只有最后一行是换关（空表会让逐帧核对平凡为真，这一条钉住它）

开局 seq 1033；这一关核过的步数 **57**（+ 最后换关那一步由 `winnable` 核）。
这一关里没有 RESET，所以「重置放回开局」那条假设在这一关**没被用到**。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

open Game

namespace Game.Lv3

def board : Board := Replay.board 3
def rows : List Replay.Row := Replay.slice 1033 58
def start : St := startOf (Replay.frameAt ((rows.head?.map (·.prev)).getD 0))
def play : List (Act × Seen) := Replay.playOf (rows.take 57)
def acts : List Act := Replay.actsOf rows

#eval match firstSplit step board start play 0 with
  | none   => s!"Lv3  一处都没分家（{play.length} 帧）"
  | some i => s!"Lv3  第 {i} 步分家"

end Game.Lv3

theorem Game.Lv3.rows_len :
    Replay.stepCount Game.Lv3.rows = 58 ∧
    Game.Lv3.rows.all (fun r => r.lvl == 3 && r.cert && !r.over) = true ∧
    (Game.Lv3.rows.take 57).all (fun r => r.tag == 0) = true ∧
    (Game.Lv3.rows.drop 57).all (fun r => r.tag == 1) = true := by
  decide +kernel

theorem Game.Lv3.trace :
    Game.Lv3.board.wf = true ∧
    Game.traceOk Game.step Game.Lv3.board Game.Lv3.start Game.Lv3.play = true := by
  decide +kernel

theorem Game.Lv3.winnable :
    ∃ as : List Game.Act, Game.everGoal Game.step Game.Lv3.board Game.Lv3.start as = true :=
  ⟨Game.Lv3.acts, by decide +kernel⟩

#print axioms Game.Lv3.rows_len
#print axioms Game.Lv3.trace
#print axioms Game.Lv3.winnable
