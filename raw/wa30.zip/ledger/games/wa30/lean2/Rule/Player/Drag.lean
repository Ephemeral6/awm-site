/-
# drag —— 攥着货时按方向键（规则 = 定义；Python `rule/player/drag.py`）

头不转。人去的格（可以是货让出来的那格）站得上去且空着，货去的格（可以是人让出来的那格）
进得去且空着——两样都成立就一起挪一格，否则都不动。
（不写 `let`：推论那一层要 `split` 进来。）
-/

import Obj.World
import Rule.Player.Walk

namespace Game

/-- 人从 p 去 t、货从 f 去 h，两样都走得成。 -/
def dragOk (b : Board) (s : St) (f t h : Cell) : Bool :=
  (t == f || s.freeFor b t) &&
  (h == s.player || (b.carryable h && !s.donuts.contains h && !(s.moles.any (fun m => m.pos == h))))

def drag (b : Board) (s : St) (d : Dir) : St :=
  match s.front, s.player.go d with
  | some f, some t =>
    match f.go d with
    | some h =>
      if dragOk b s f t h then
        { s with player := t, donuts := s.donuts.map (fun c => if c == f then h else c) }
      else s
    | none => s
  | _, _ => s

end Game
