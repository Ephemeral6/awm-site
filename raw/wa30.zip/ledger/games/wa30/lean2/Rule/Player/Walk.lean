/-
# walk —— 手空时按方向键（规则 = 定义；Python `rule/player/walk.py`）

头一定转过去；前面那格站得上去、上面没有甜甜圈也没有鼹鼠，就挪过去。
-/

import Obj.World

namespace Game

/-- 这一格人站得上去而且空着。 -/
def St.freeFor (b : Board) (s : St) (x : Cell) : Bool :=
  b.walkable x && !s.donuts.contains x && !(s.moles.any (fun m => m.pos == x))

def walk (b : Board) (s : St) (d : Dir) : St :=
  match s.player.go d with
  | some t => if s.freeFor b t then { s with facing := d, player := t } else { s with facing := d }
  | none => { s with facing := d }

end Game
