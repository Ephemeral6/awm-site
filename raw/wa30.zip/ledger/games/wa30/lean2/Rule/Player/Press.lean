/-
# press —— ACTION5（规则 = 定义；Python `rule/player/press.py`）

攥着就松手；手空而正前方有货就攥住（那颗要是正被鼹鼠驮着，从它背上夺下来）；
正前方是贼就把它打掉（它驮着的货原地留下）；都不是就什么也不发生。人不动、头不转。
-/

import Obj.World

namespace Game

def press (s : St) : St :=
  if s.holding then { s with holding := false } else
  match s.front with
  | none => s
  | some f =>
    if s.donuts.contains f then
      { s with holding := true,
               moles := s.moles.map (fun m => if m.load == some f then { m with cargo := none } else m) }
    else if s.moles.any (fun m => m.pos == f && m.role == .thief) then
      { s with moles := s.moles.filter (fun m => !(m.pos == f && m.role == .thief)) }
    else s

end Game
