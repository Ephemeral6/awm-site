/-
# level_up —— 什么算赢（规则 = 定义；Python `rule/goal/level_up.py`）

`isGoal` 是**状态**的性质：手上没攥着、没有鼹鼠驮着货、每一颗甜甜圈都坐在容器格上。
`step` 在一整步（玩家那半步 + 鼹鼠那半步）走完之后问它。
-/

import Obj.World

namespace Game

def isGoal (b : Board) (s : St) : Bool :=
  !s.holding && s.moles.all (fun m => m.cargo == none) && s.donuts.all (fun c => c.inMask b.home)

end Game
