/-
# moles_act —— 鼹鼠那半步（规则 = 定义；Python `rule/moles/moles_act.py`，零件在 `derive/npc.py`）

玩家动完之后，鼹鼠按名单轮流动一下：帮手先、贼后，各自按名单；
**一只偷到手后，同皮排在后面的这一步不动**。轮到的那只：

    驮着、货已到家        放下（货挪到甜甜圈名单末尾），不动
    驮着、没到家          人货两格一起沿最短路挪一格（终点：货落进一格空着的家）；没路不动
    空手、贴着目标        偷（贴着好几颗挑名单里最靠后的那颗），不动
    空手、不贴着          沿最短路朝最近的目标挪一格；没路不动

这一段**只改三样**：甜甜圈、鼹鼠、手上攥没攥着（贼会从手里夺货）——输出就是这三样，
玩家的位置和朝向它**碰不到**（`Step.lean` 把这三样拼回状态）。于是「鼹鼠那半步不挪玩家」不用证。
-/

import Obj.World
import Rule.Moles.Route
import Rule.Moles.Targets

namespace Game

def nth (ms : List Mole) : Nat → Option Mole
  | i => (ms.drop i).head?

def posIn : List Cell → Cell → Nat
  | [], _ => 0
  | y :: ys, x => if y == x then 0 else posIn ys x + 1

/-- 贴着好几颗目标时挑甜甜圈名单里最靠后的那颗。 -/
def pickLast (ds : List Cell) : List Cell → Option Cell
  | [] => none
  | x :: xs => match pickLast ds xs with
    | none => some x
    | some y => if posIn ds x ≥ posIn ds y then some x else some y

def othersMask (s : St) (m : Mole) : Nat :=
  maskOf (s.moles.map (·.pos)) ^^^ (1 <<< m.pos.idx)

def carryTurn (b : Board) (s : St) (i : Nat) (m : Mole) (o : Dir) : St :=
  match m.pos.go o with
  | none => s
  | some cc =>
    if isHome b m.role cc then
      { s with moles := s.moles.set i { m with cargo := none }, donuts := s.donuts.erase cc ++ [cc] }
    else
      let bl0 := maskOf s.donuts ||| othersMask s m ||| (1 <<< s.player.idx)
      let blocked := if bl0.testBit cc.idx then bl0 ^^^ (1 <<< cc.idx) else bl0
      let ok := fun (v : Cell) => b.walkable v && !v.inMask blocked &&
        (match v.go o with
         | some c2 => b.carryable c2 && (!c2.inMask blocked || c2 == m.pos)
         | none => false)
      let goal := fun (v : Cell) => match v.go o with
        | some c2 => isHome b m.role c2 && !s.donuts.contains c2
        | none => false
      match firstStep ok goal m.pos with
      | none => s
      | some nx =>
        match nx.go o with
        | none => s
        | some nc => { s with moles := s.moles.set i { m with pos := nx },
                              donuts := s.donuts.map (fun c => if c == cc then nc else c) }

/-- 返回（新状态，这一只偷了没有）。 -/
def seekTurn (b : Board) (s : St) (i : Nat) (m : Mole) : St × Bool :=
  let adj := Dir.order.filterMap (fun d => match m.pos.go d with
    | some c => if isTarget b s m c then some c else none
    | none => none)
  match pickLast s.donuts adj with
  | some c =>
    let ms := s.moles.map (fun mm => if mm.load == some c then { mm with cargo := none } else mm)
    let hold := if s.holding && s.front == some c then false else s.holding
    ({ s with moles := ms.set i { m with cargo := Dir.between m.pos c }, holding := hold }, true)
  | none =>
    let tmask := s.donuts.foldl (fun acc c => if isTarget b s m c then acc ||| (1 <<< c.idx) else acc) 0
    if tmask == 0 then (s, false) else
    let blocked := maskOf s.donuts ||| othersMask s m ||| (1 <<< s.player.idx)
    let ok := fun (v : Cell) => b.walkable v && !v.inMask blocked
    let goal := fun (v : Cell) => Dir.order.any (fun d => match v.go d with
      | some c => c.inMask tmask
      | none => false)
    match firstStep ok goal m.pos with
    | none => (s, false)
    | some nx => ({ s with moles := s.moles.set i { m with pos := nx } }, false)

def turnOne (b : Board) (acc : St × Bool × Bool) (i : Nat) : St × Bool × Bool :=
  match nth acc.1.moles i with
  | none => acc
  | some m =>
    if (m.role == .helper && acc.2.1) || (m.role == .thief && acc.2.2) then acc else
    match m.cargo with
    | some o => (carryTurn b acc.1 i m o, acc.2.1, acc.2.2)
    | none =>
      let r := seekTurn b acc.1 i m
      if r.2 then (r.1, acc.2.1 || m.role == .helper, acc.2.2 || m.role == .thief)
      else (r.1, acc.2.1, acc.2.2)

/-- 鼹鼠那半步的输出：（甜甜圈，鼹鼠，手上攥没攥着）。 -/
def molesAct (b : Board) (s : St) : List Cell × List Mole × Bool :=
  let idx := List.range s.moles.length
  let order := idx.filter (fun i => (nth s.moles i).map (·.role) == some .helper) ++
               idx.filter (fun i => (nth s.moles i).map (·.role) == some .thief)
  let r := order.foldl (turnOne b) (s, false, false)
  (r.1.donuts, r.1.moles, r.1.holding)

end Game
