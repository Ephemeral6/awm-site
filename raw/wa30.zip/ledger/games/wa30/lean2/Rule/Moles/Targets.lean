/-
# 目标与到家（`moles_act` 的零件；Python `derive/targets.py`）

    到家：帮手 = 容器格，贼 = 巢格
    目标：不在自己家里的货；别人驮着的只有贼抢、只抢帮手的；玩家攥着的只有贼抢
-/

import Obj.World

namespace Game

def isHome (b : Board) : Role → Cell → Bool
  | .helper, x => x.inMask b.home
  | .thief, x => x.inMask b.den

/-- 驮着 x 的那只（没有就 none）。 -/
def ownerOf (s : St) (x : Cell) : Option Mole := s.moles.find? (fun m => m.load == some x)

def isTarget (b : Board) (s : St) (m : Mole) (x : Cell) : Bool :=
  s.donuts.contains x && !isHome b m.role x &&
  (match ownerOf s x with
   | some o => m.role == .thief && o.role == .helper
   | none => if s.holding && s.front == some x then m.role == .thief else true)

end Game
