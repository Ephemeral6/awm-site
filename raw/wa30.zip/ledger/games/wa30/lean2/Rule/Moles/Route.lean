/-
# 找路（`moles_act` 的零件；Python `derive/route.py`）

从起点逐层往外展开（队列先进先出），邻格按 `Dir.order`（左、右、上、下）入队、入队时记已访问；
终点在**出队**时判，起点自己不算终点；每一格记住「它是从起点的哪个邻格走过来的」，
第一个出队的终点直接交出那一位。返回的是**第一步落在哪一格**。

燃料 `fuel` 是结构递归的保证（内核要能把它算完）：每轮出队一格或者把后半队倒过来一次，
256 格的盘上 1200 足够；燃料耗尽返回 `none`（等于「没路」），这一处会让模型说错而不是说谎——
逐帧核对会当场红。
-/

import Obj.Geometry.Dir

namespace Game

def expand (ok : Nat → Bool) (start u fs : Nat) :
    List Dir → List (Nat × Nat) → Nat → List (Nat × Nat) × Nat
  | [], back, vis => (back, vis)
  | d :: ds, back, vis =>
    match (Cell.ofIdx u).go d with
    | none => expand ok start u fs ds back vis
    | some v =>
      let vi := v.idx
      if vis.testBit vi || !ok vi then expand ok start u fs ds back vis
      else expand ok start u fs ds ((vi, if u == start then vi else fs) :: back) (vis ||| (1 <<< vi))

def bfsGo (ok goal : Nat → Bool) (start : Nat) :
    Nat → List (Nat × Nat) → List (Nat × Nat) → Nat → Option Nat
  | 0, _, _, _ => none
  | _ + 1, [], [], _ => none
  | f + 1, [], back, vis => bfsGo ok goal start f back.reverse [] vis
  | f + 1, (u, fs) :: q, back, vis =>
    if u != start && goal u then some fs
    else
      let r := expand ok start u fs Dir.order back vis
      bfsGo ok goal start f q r.1 r.2

/-- 第一步落在哪一格；没路给 `none`。 -/
def firstStep (ok goal : Cell → Bool) (start : Cell) : Option Cell :=
  (bfsGo (fun i => ok (Cell.ofIdx i)) (fun i => goal (Cell.ofIdx i)) start.idx 1200
      [(start.idx, start.idx)] [] (1 <<< start.idx)).map Cell.ofIdx

end Game
