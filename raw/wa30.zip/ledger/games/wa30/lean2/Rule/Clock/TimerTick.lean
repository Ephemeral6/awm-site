/-
# timer_tick —— 每按一次键已用步数加一（规则 = 定义；Python `rule/clock/timer_tick.py`）

条怎么画在 `Obj/Hud/Timer.lean`（`barPx`）；这一条只说「按一次键用掉一步」——方向、ACTION5、
撞墙、打空都算。
-/

import Obj.World

namespace Game

def tick (s : St) : St := { s with used := s.used + 1 }

end Game
