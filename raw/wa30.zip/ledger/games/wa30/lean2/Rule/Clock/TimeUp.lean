/-
# time_up —— 用满预算就结束（规则 = 定义；Python `rule/clock/time_up.py`）
-/

import Obj.World

namespace Game

def timeUp (b : Board) (s : St) : Bool := decide (b.budget ≤ s.used)

end Game
