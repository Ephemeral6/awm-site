/-
# Lives —— 全部语料的每一条命（段 A + 段 B），模型带着自己的状态走到底：**读数，不是定理**

一条命从开局帧起（第一帧 / 换关之后 / RESET 之后），到换关 / RESET / GAME_OVER 为止。
每一步：模型说「接着走」就逐帧比；说「时间到」就要求现实也是 GAME_OVER、而且那一帧也对上；
说「赢了」就要求这一行现实换了关。第一处对不上就停，报到那里为止核过几帧。

这一份给 `lean2/verify.py` 和 Python 那一侧的 `run_trace.py` **逐命对账**：
两份模型各自独立写，对着同一批观测，每条命「核过几帧、怎么结束」必须一字不差。
`#eval` 走的是求值器，不进可信基——段 B 九关的结论另有走内核的定理（`Proof/Levels/`）。
-/

import Obs.Replay

namespace Game
namespace Lives

open Replay

/-- （核过几帧，结局：1 赢 / 2 时间到 / 0 命断在 RESET 或语料末尾 / 9 分家） -/
def runLife (b : Board) : St → List Row → Nat → Nat × Nat
  | _, [], k => (k, 0)
  | s, r :: rs, k =>
    if r.tag == 2 then (k, 0) else
    match step b s r.act with
    | .won _ => if r.tag == 1 then (k, 1) else (k, 9)
    | .over s' => if r.over && seenEq (observe b s') (frameAt r.next) then (k + 1, 2) else (k, 9)
    | .ok s' =>
      if r.tag == 0 && !r.over && seenEq (observe b s') (frameAt r.next) then runLife b s' rs (k + 1)
      else (k, 9)
    | .na => (k, 9)

/-- 每条命开头那一行在 `rows` 里的位置。 -/
def starts : List Row → Bool → Nat → List Nat
  | [], _, _ => []
  | r :: rs, fresh, i =>
    let here := if fresh && r.tag != 2 then [i] else []
    here ++ starts rs (r.tag != 0 || r.over) (i + 1)

def report : List (Nat × Nat × Bool × Nat × Nat) :=
  (starts rows true 0).map (fun i =>
    let rs := rows.drop i
    match rs.head? with
    | none => (0, 0, false, 0, 9)
    | some r0 =>
      let res := runLife (board r0.lvl) (startOf (frameAt r0.prev)) rs 0
      (r0.seq, r0.lvl, r0.cert, res.1, res.2))

#eval report.map (fun (q, lv, c, k, e) => s!"LIFE seq={q} lvl={lv} cert={c} checked={k} end={e}")

end Lives
end Game
