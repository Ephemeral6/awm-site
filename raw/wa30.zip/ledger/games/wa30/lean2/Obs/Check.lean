/-
# Check —— 判据层：两把尺子，**0 条定理**（尺子不自证）

    traceOk   从开局起带着**自己算出来的**状态往下走，逐帧和观测比
    everGoal  照着一串动作走，中途赢过没有

两把尺子都把「一步怎么走」当参数收进来（`stp`），定理里写的是 `traceOk step …`：
尺子不认识某一个 `step`，它量的是你递给它的那一个。

`startOf`：开局那一帧 → 状态。名单按行优先（观测导出时已排好）、没人驮货、已用 0 步。
-/

import Step

namespace Game

def startOf (o : Seen) : St :=
  { player := o.player, facing := o.facing,
    holding := o.rings.any (fun r => r.2 == Ring.held.code),
    donuts := o.rings.map (·.1),
    moles := o.moles.map (fun m => { pos := m.1, role := m.2.1, cargo := none }),
    used := 0 }

def traceOk (stp : Board → St → Act → Res) (b : Board) : St → List (Act × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match stp b s a with
    | .ok s' => seenEq (observe b s') o && traceOk stp b s' rest
    | _ => false

/-- 读数用：第一处分家在第几步（none = 一处没分家）。**是读数不是定理。** -/
def firstSplit (stp : Board → St → Act → Res) (b : Board) : St → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match stp b s a with
    | .ok s' => if seenEq (observe b s') o then firstSplit stp b s' rest (i + 1) else some i
    | _ => some i

def everGoal (stp : Board → St → Act → Res) (b : Board) : St → List Act → Bool
  | _, [] => false
  | s, a :: rest =>
    match stp b s a with
    | .won _ => true
    | .ok s' => everGoal stp b s' rest
    | _ => false

/-- 读数用：沿一串动作走完之后的结局（0 接着走 / 1 赢 / 2 时间到 / 3 说不出话）。 -/
def runEnd (stp : Board → St → Act → Res) (b : Board) : St → List Act → Nat
  | _, [] => 0
  | s, a :: rest =>
    match stp b s a with
    | .won _ => 1
    | .over _ => 2
    | .na => 3
    | .ok s' => runEnd stp b s' rest

end Game
