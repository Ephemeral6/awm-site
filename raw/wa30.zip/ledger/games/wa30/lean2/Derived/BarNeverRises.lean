/-
# bar_never_rises —— 同一关里计时条只短不长（**推论**；Python `rule/clock/bar_never_rises.py`）

从 timer_tick（每步已用步数加一）和计时条的画法（`barPx`，对已用步数不增）推出来。
玩家那半步不碰已用步数，鼹鼠那半步碰不到它（`merge` 只拼回三样）。
-/

import Obj.World
import Step

open Game

theorem Game.playerPhase_used (b : Board) (s : World) (a : Act) : (playerPhase b s a).used = s.used := by
  unfold playerPhase
  split
  · unfold press
    split
    · rfl
    · split
      · rfl
      · split
        · rfl
        · split <;> rfl
  · rfl
  · split
    · rename_i d _
      split
      · unfold drag
        split
        · split
          · split <;> rfl
          · rfl
        · rfl
      · unfold walk
        split
        · split <;> rfl
        · rfl
    · rfl

theorem Game.bar_never_rises (b : Board) (s s' : St) (a : Act) (h : step b s a = .ok s') :
    barPx s'.used b.budget ≤ barPx s.used b.budget := by
  unfold step settle at h
  split at h
  · exact absurd h (by simp)
  · split at h
    · exact absurd h (by simp)
    · split at h
      · exact absurd h (by simp)
      · injection h with h
        subst h
        show barPx ((playerPhase b s a).used + 1) b.budget ≤ barPx s.used b.budget
        rw [playerPhase_used]
        unfold barPx
        exact Nat.sub_le_sub_left (Nat.div_le_div_right (by omega)) 64

#print axioms Game.playerPhase_used
#print axioms Game.bar_never_rises
