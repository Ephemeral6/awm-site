/-
# player_stride —— 玩家一步最多挪一格（**推论**；Python `rule/player/player_stride.py`）

从 walk / drag / press 三条定义推出来：前两条的玩家只落在「原地」或「沿按的方向一格」，
press 不挪人，鼹鼠那半步碰不到玩家（`Step.merge` 只拼回三样），`tick` 只改已用步数。
**它是一条定理，不是一条规则**——规则层那一份照样对着语料逐条判，两边都得站住。
-/

import Obj.World
import Step

open Game

theorem Game.walk_stride (b : Board) (s : World) (d : Dir) :
    (walk b s d).player = s.player ∨ s.player.go d = some (walk b s d).player := by
  unfold walk
  split
  · rename_i t h
    split
    · exact Or.inr (by simp [h])
    · exact Or.inl rfl
  · exact Or.inl rfl

theorem Game.drag_stride (b : Board) (s : World) (d : Dir) :
    (drag b s d).player = s.player ∨ s.player.go d = some (drag b s d).player := by
  unfold drag
  split
  · rename_i f t hf ht
    split
    · split
      · exact Or.inr (by simp [ht])
      · exact Or.inl rfl
    · exact Or.inl rfl
  · exact Or.inl rfl

theorem Game.press_keeps_player (s : World) : (press s).player = s.player := by
  unfold press
  split
  · rfl
  · split
    · rfl
    · split
      · rfl
      · split <;> rfl

theorem Game.player_stride (b : Board) (s s' : St) (a : Act) (h : step b s a = .ok s') :
    s'.player = s.player ∨ ∃ d : Dir, s.player.go d = some s'.player := by
  unfold step settle at h
  split at h
  · exact absurd h (by simp)
  · split at h
    · exact absurd h (by simp)
    · split at h
      · exact absurd h (by simp)
      · injection h with h
        subst h
        show (playerPhase b s a).player = s.player ∨ ∃ d, s.player.go d = some (playerPhase b s a).player
        unfold playerPhase
        split
        · exact Or.inl (press_keeps_player s)
        · exact Or.inl rfl
        · split
          · rename_i d _
            split
            · rcases drag_stride b s d with h1 | h1
              · exact Or.inl h1
              · exact Or.inr ⟨d, h1⟩
            · rcases walk_stride b s d with h1 | h1
              · exact Or.inl h1
              · exact Or.inr ⟨d, h1⟩
          · exact Or.inl rfl

#print axioms Game.walk_stride
#print axioms Game.drag_stride
#print axioms Game.press_keeps_player
#print axioms Game.player_stride
