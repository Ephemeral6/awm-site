"""物件盖在环上面：环框格与环心格只要落在某个物件的形状上，那一格就显示那个物件的颜色；没被盖的环框一律是色 4。

由来：全语料 360 次「环格被物件盖住」，显示的全是压它的那个物件的颜色，零例外；
3417 次「环框没被盖」，全是色 4。这条把环心从生成器的盲区里捞了出来。

v2：读法从 `shapes` 换成 `objects`，谁压谁从全序 `ZORDER` 换成偏序 `top_of`。
被打的三条（step 179/184/193）全是同一个病：那几关有同色的两个物件、还有和物件同色的家具，
`shapes` 于是**只装得下一部分物件**——它非空，但少了那个正压在环框上的物件，
这条概念就把「被盖住的环框」读成「没人盖」，然后要求它是色 4。
读法的沉默被当成了世界的否定。`objects` 按中心索引，不靠「一颜色一物件」，装得下。
两个颜色的上下关系没实测过时（`top_of` 返回 None）这一格不表态，不猜。

v3：`objects` 非空还不够 —— 它也会**部分成立**。一关里出现了它认不出的位形，
那个认不出的东西正压在一个环框上，于是这条概念又一次把「被盖住的环框」读成「没人盖」、
要求它是色 4，判 FALSE。v2 修的是「一颜色一物件」那一种部分成立，这是另一种：
形状表里根本没有能装下它的形状。改成拿 `unexplained` 对账：残料非空就整条弃权，
不再用「表非空」冒充「表是全的」。同样是自愈的门。
"""
LEVEL = "L6"
SCOPE = ("只看 next 帧上的环格（环心 + 环心的 8 邻）；光标那一格不算（光标在更上层）；"
         "两个颜色谁压谁没实测过的那一格不表态；盘上读不出环或读不出物件返回 NA；"
         "next 上有识别器解释不掉的格子（unexplained 非空）返回 NA —— 物件表这时是不全的")
NOTE = "与 zorder_fixed_order 是同一层的两半：那条说物件之间谁压谁，这条说物件与环谁压谁。"
EVIDENCE = ["bca4ef14ab259cb9", "06099fcae695af47",
            "64d1523fa62d16b6", "69fce795e80a0d1b", "8c542001704aade5",
            "a2be021b53100620"]

from _lib import (RING_EDGE, cursor, objects, ring_border, ring_centers, stamp,
                  top_of, unexplained)


def assert_(prev, action, nxt, ctx=None):
    rc = ring_centers(nxt)
    objs = objects(nxt)
    if not rc or not objs:
        return "NA"
    if unexplained(nxt):
        return "NA"
    cur = cursor(nxt)
    where = [(col, stamp(k, ctr, L)) for ctr, (k, col, L) in objs.items()]
    for p in set(rc) | set(ring_border(nxt)):
        if p == cur:
            continue
        over = [col for col, st in where if p in st]
        v = nxt[p[0]][p[1]]
        if not over:
            if p in rc:
                continue                     # 没被盖的环心显示归属色，那是别条概念的事
            if v != RING_EDGE:
                return "FALSE"
            continue
        t = top_of(over)
        if t is None:
            continue                         # 偏序定不下来：这一格不表态
        if v != t:
            return "FALSE"
    return "TRUE"
