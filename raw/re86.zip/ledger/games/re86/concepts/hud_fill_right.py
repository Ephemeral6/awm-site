"""HUD 条从最右端往左填：花掉第 k 点预算时变色的恰好是第 63 行第 (63-k+1) 列那一格，别的 HUD 格不变。"""
LEVEL = "L4"
SCOPE = "所有动作；换关返回 NA；HUD 格数没增加（如 ACTION2）时只要求整行不变"
NOTE = ("v1 带 apply（无脑主张「每步都扣一格」），在第 7 步说错 1 格而 assert_ 仍判 TRUE。"
        "撤掉 apply：什么时候扣还没量出来，生成器不该替检查器猜。")
EVIDENCE = ["53c0f3e343567397", "b944e2b3bb75cf62", "13ec64782c5d9f6b", "53284daa3bbbd062"]

from _lib import HUD_LEFT, HUD_ROW, HUD_SPENT, spent


def _row(g):
    return list(g[HUD_ROW])


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = _row(prev), _row(nxt)
    k0, k1 = spent(prev), spent(nxt)
    if k1 == k0:
        return "TRUE" if a == b else "FALSE"
    if k1 != k0 + 1:
        return "NA"                      # 一次跳多格不在本条 scope 内
    n = len(a)
    col = n - 1 - k0
    want = list(a)
    if not (0 <= col < n) or a[col] != HUD_LEFT:
        return "FALSE"
    want[col] = HUD_SPENT
    return "TRUE" if b == want else "FALSE"
