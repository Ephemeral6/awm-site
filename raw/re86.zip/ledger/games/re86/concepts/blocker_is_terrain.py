"""挡块（色 1）是地形不是物件：它一格不动，也从不被任何物件盖住——两帧的色 1 格子集合完全相同。

物件会互相叠、会被光标压住、会被盘边裁掉；挡块三样都不沾。它不动，也不让位：
物件撞上它那一步不平移而是变形（见 blocked_deforms / blocked_rect_trades），
所以挡块那几格上永远显示挡块自己的颜色，没有第二种解释。

这条是把「读法把挡块从 unexplained 里减掉」所依赖的世界事实摆到闸上：
减掉它是因为它是地形，而「它是地形」这句话必须能被推翻——挡块哪天动了一格，或者哪天被谁盖住了，
这一条当场判 FALSE，而 `unexplained` 的那一行减法也就跟着失去依据。
"""
LEVEL = "L2"
SCOPE = ("每一条转移都判，不挑动作；换关返回 NA —— 换关是整盘重画，"
         "这一条只说「一关之内挡块不动」；两帧盘上都没有挡块时返回 NA，那时它无话可说")
NOTE = ""
EVIDENCE = ["8b30f3be5302c281", "5c5f0ff11d921d13", "5899bf71833d6ca9"]

from _lib import blockers


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = blockers(prev), blockers(nxt)
    if not a and not b:
        return "NA"
    return "TRUE" if a == b else "FALSE"
