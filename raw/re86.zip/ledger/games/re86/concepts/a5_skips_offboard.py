"""ACTION5 交出去的光标，从来不落在「包围盒中心在盘外」的物件上——盘上存在这种物件时，它们被跳过。

由来：一次落空的押注。盘上读法读出三个物件，其中一个的中心落在列 0 外面；
按次序表推，两次 ACTION5 该走成三元环，实测却是二元环——中心越界的那个从头到尾没拿到过光标。
所以次序表的**候选集**不是「读法读出来的全部物件」，而是「光标画得出来的那些」。

这一条只说候选集这一层，不重复 `a5_cycle_order` 的排序主张：那一条在这一关因为 `unexplained`
非空而整关弃权，于是候选集错了也没人被判错。把它单独立出来，是让「光标画不出去的不算候选」
这句话自己去挨检验，而不是躲在另一条的弃权后面。

盘的范围：行 0 到 HUD_ROW-1，列 0 到帧宽-1。中心取 `bbox_center`，因为光标贴的是包围盒中心。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；换关返回 NA；"
         "next 帧读不出当前物件、或当前物件不在物件表里返回 NA；"
         "**盘上一个「中心越界」的物件都没有时返回 NA** —— 没有可跳过的东西时这句话是空话")
NOTE = ("v2：v1 说的是「包围盒越出盘外的物件被跳过」，被两条 ACTION5 打脸——"
        "那两帧里越界的是边角被盘沿切掉的正常物件（一个大 plus 的臂伸出了盘），"
        "中心稳稳在盘内，光标照样交给了它。所以越界与否不是判据，"
        "**中心画不画得出来**才是：催生这一条的那个物件，中心本身在列 0 外面。\n"
        "v1 的两条反例 903ee86175f2a5db、3671e5b6f3c2196c 在 v2 下返回 NA（那两帧没有中心越界的物件）。\n"
        "教训：碰上一个「读法读出来但世界不认」的东西时，先别急着把它当时看到的那个属性写进断言——"
        "越界和中心越界在催生它的那一帧里长得一模一样，是语料里别处的转移把两者分开的。")
EVIDENCE = ["8620c4e979aca397", "b09491959a147177",
            "903ee86175f2a5db", "3671e5b6f3c2196c"]

from _lib import objects, active_center, bbox_center, HUD_ROW


def _center_onboard(kind, ctr, L, w):
    r, c = bbox_center(kind, ctr, L)
    return 0 <= r < HUD_ROW and 0 <= c < w


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    w = len(nxt[0])
    objs = objects(nxt)
    if not objs:
        return "NA"
    if all(_center_onboard(k, c, L, w) for c, (k, _, L) in objs.items()):
        return "NA"
    c = active_center(nxt)
    if c is None or c not in objs:
        return "NA"
    kind, _, L = objs[c]
    return "TRUE" if _center_onboard(kind, c, L, w) else "FALSE"
