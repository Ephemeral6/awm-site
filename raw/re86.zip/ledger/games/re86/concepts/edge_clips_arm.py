"""盘边裁形状、不拦动作：平移后盘上显示的当前物件恰好是「理想形状 ∩ 盘面」，伸出盘外的部分只是没画出来。"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1~4 且帧真的变了（prev != nxt）；换关返回 NA；"
         "光标、形状或半径读不出来返回 NA；理想形状上有格子显示的是**别的物件的颜色**时返回 NA"
         "—— 物件之间的上下关系另立概念；"
         "平移后的理想形状会压到挡块（will_block 非空）时返回 NA —— 那一步根本不是平移")
NOTE = ("v2：形状不再假定是直加号，改成读拟合出来的 kind（plus/ex/diamond）；「别的十字色」改成盘上其余物件色。"
        "v3：这条概念整句话都架在「物件平移过去了」上面，而实测有一步撞上挡块、物件当场变形不平移，"
        "它照着旧位置去核对新帧，判 FALSE。**盘边是裁，挡块是挡，两回事**——这条只管裁那一半。")
EVIDENCE = ["6b4df80e7f0df5c2", "d22aec9297383843"]

from _lib import (CURSOR, DELTA, active, arm_len, cursor, kind_of, on_board,
                  shape_colors, stamp, will_block)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not any(action.startswith(f"ACTION{k}") for k in (1, 2, 3, 4)):
        return "NA"
    if prev == nxt:
        return "NA"
    d = DELTA.get(action.split()[0])
    if d is not None and will_block(prev, d):
        return "NA"
    q, L, col = cursor(nxt), arm_len(prev), active(prev)
    kind = kind_of(prev, col) if col is not None else None
    if q is None or L is None or col is None or kind is None:
        return "NA"
    other = [c for c in shape_colors(prev) if c != col]
    for (r, c) in on_board(nxt, stamp(kind, q, L)):
        v = nxt[r][c]
        if v in other:
            return "NA"
        if v not in (col, CURSOR):
            return "FALSE"
    return "TRUE"
