"""不该过关的一步就不会过关：这一步走完之后只要还有环心没被任何物件盖住，关卡号就不变。

判据的读法（`_lib.would_win`）：环心 = 3×3 色 4 环里的那一格；「盖住」= 它落在某个物件的理想形状上。
这个读法**遮挡免疫**：只看几何覆盖，不读环心那一格显示什么颜色 —— 被盖住时它显示的是盖它的颜色。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1~4；光标、形状或环心读不出来（`would_win` 返回 None）返回 NA；"
         "这一步该过关（would_win 为真）时返回 NA —— 那一半是 `all_on_target_levels_up` 的事")
NOTE = ("v2：判据从「每个物件都停在自己环心决定的落点上」改成「每个环心都被盖住」。"
        "原因：斜叉的臂走到某些位置会盖住别人的环心，环心那一格于是显示成臂的颜色，"
        "「环心颜色 = 归属色」这个读法当场失效；几何覆盖不受遮挡影响。")
EVIDENCE = ["97023537ba8dfc15", "c0508d69c7edd185", "6b4df80e7f0df5c2"]

from _lib import DELTA, would_win


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    key = next((k for k in DELTA if action.startswith(k)), None)
    if key is None:
        return "NA"
    w = would_win(prev, DELTA[key])
    if w is None or w:
        return "NA"
    return "TRUE" if ctx["level_prev"] == ctx["level_next"] else "FALSE"
