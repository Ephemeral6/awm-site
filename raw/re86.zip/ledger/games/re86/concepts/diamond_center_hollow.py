"""菱形的中心那一格从不填本色：它显示的是下面那一层（底色或家具），不是菱形自己的颜色。

`stamp` 早就把菱形的中心排除在理想形状之外，但那只是个画法约定，没人立过案。
这一条把它变成主张：**任何一帧**里，只要某个菱形不是当前物件（中心没压着光标）、
中心也没被别的物件的格子盖住，那一格就该等于「把所有物件按各自形状摆上去之后，
这一格露出来的东西」——对菱形来说就是环、家具或底色。

由来：全语料 382 条转移的 next 帧里，符合条件的菱形中心读到 170 次，**170 次全是底色，一次本色都没有**。
另外单看「光标让开的那一瞬间」，菱形 6/6 露底色（3 个不同的菱形、3 个关）。

**斜叉不在这一条里，因为斜叉不是这样。** 同样的口径下斜叉的中心本色 89 次、底色 71 次；
逐个查过帧里读得出来的候选键——形状、臂长、臂长奇偶、颜色、中心行的奇偶、本关有没有色块——
没有一个能把两堆分开：关1/关2 的斜叉臂长 11 露底色，关4 的斜叉同样臂长 11 露本色。
唯一分得干净的键是「形状+第几关」，也就是说它是物件出生时定死的属性，**单帧读不出来**。
所以斜叉一律不判（方法册「次序表要能说不知道」：分不出来就别拿一个恰好拟合的量顶上）。

这一条的用处在生成器那边：`a5_cycle_order` 原先在「光标让开的那一格」上整片弃权，
因为斜叉和菱形被并成一类「有的实心有的空心」。分开之后，菱形那一半可以说话了。
"""
LEVEL = "L0"                                   # 清点：盘上有什么、每种东西长什么样
SCOPE = ("只看 next 帧里的菱形；`unexplained` 非空返回 NA（物件表本身就不可信）；"
         "盘上没有菱形返回 NA；某个菱形是当前物件（中心压着光标）、中心被别的物件的格子盖住、"
         "或那一格该显示什么在这一帧读不出来（`top_color` 弃权，比如中心底下压着读不出归属色的环心）"
         "→ 跳过这一个；一个都不剩返回 NA。**斜叉不在 scope 内**（见 docstring）")
NOTE = ""
EVIDENCE = [
    "c54129756df0e208",   # 第 42 步 关1 ACTION5：菱形色13 让开 (30,39)，露底色
    "74284ebfef00d086",   # 第 68 步 关2 ACTION5：菱形色8 让开 (48,45)，露底色
    "181525437c21b467",   # 第 71 步 关2 ACTION5
    "e81809c011bf0719",   # 第 215 步 关1 ACTION5
    "2bf2f39a6a982303",   # 第 286 步 关2 ACTION5：菱形色8 让开 (30,18)
    "903ee86175f2a5db",   # 第 349 步 关4 ACTION5：菱形色14 让开 (18,30)，露底色
]

from _lib import active_center, objects, occluders_at, stamp, top_color, unexplained


def _check(g):
    """这一帧里读得出来的菱形中心，逐个核。返回 (判得动几个, 说错几个)。"""
    if unexplained(g):
        return 0, 0
    objs = objects(g)
    act = active_center(g)
    where = {}
    for c2, (k2, col2, l2) in objs.items():
        where[col2] = where.get(col2, set()) | stamp(k2, c2, l2)
    ok = bad = 0
    for c, (kind, _col, _ln) in objs.items():
        if kind != "diamond" or c == act:
            continue
        if occluders_at(objs, c, c):
            continue
        v = top_color(g, c, where)
        if v is None:
            continue                            # 这一帧说不准该露什么：不判
        ok += 1
        if g[c[0]][c[1]] != v:
            bad += 1
    return ok, bad


def assert_(prev, action, nxt, ctx=None):
    ok, bad = _check(nxt)
    if not ok:
        return "NA"
    return "FALSE" if bad else "TRUE"
