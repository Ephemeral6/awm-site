"""ACTION1~4 只动当前物件：其余物件的中心一格都不挪。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1~4；换关返回 NA；两帧认不出同一批「别的物件」返回 NA "
         "（形状被遮挡或被盘边裁到拟合不出来时就属于这种）")
NOTE = "v2：第 1 关有三个物件，逐个比中心，不再只比「另一个」那一个。"
EVIDENCE = ["53c0f3e343567397", "694c7083a193c96a", "b944e2b3bb75cf62", "13ec64782c5d9f6b"]

from _lib import other_centers


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not any(action.startswith(f"ACTION{k}") for k in (1, 2, 3, 4)):
        return "NA"
    a, b = other_centers(prev), other_centers(nxt)
    if not a or set(a) != set(b):
        return "NA"
    return "TRUE" if all(a[c] == b[c] for c in a) else "FALSE"
