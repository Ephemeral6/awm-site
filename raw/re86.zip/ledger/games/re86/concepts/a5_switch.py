"""ACTION5 只换光标：光标落到**某个别的物件**的中心，别的物件一个都不移动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；换关返回 NA；光标读不出来、或盘上认不出「别的物件」返回 NA。"
         "原光标那一格变成什么：按该物件的理想形状含不含中心来断言——含（直加号）就露出本色，"
         "不含（斜叉、菱形）就露出底色")
NOTE = ("v3：原来照抄「直加号和斜叉的中心都算本体」，第 41 步打死了——色 12 的斜叉让出中心，"
        "露出来的是底色。改成不再按种类硬写，直接问 stamp 含不含这一格；"
        "同一批第 42 步菱形让出中心也露底色，两种「不含中心」的形状各有一条证据。\n"
        "v2：第 1 关有三个物件，`other_center` 在「别的物件」多于一个时给不出答案，"
        "所以改成断言「光标落在其中之一的中心上」，并加断言「所有别的物件的中心一格不动」。")
EVIDENCE = ["53284daa3bbbd062", "12bc05726790eed2", "c54129756df0e208"]

from _lib import BG, CURSOR, active, cursor, other_centers, shape_of, stamp


def _vacated(g, col):
    """当前物件 col 让出中心之后，那一格该露出什么颜色；读不出来返回 None。"""
    sh = shape_of(g, col)
    if sh is None:
        return None
    kind, center, L = sh
    return col if center in stamp(kind, center, L) else BG


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    a, col = cursor(prev), active(prev)
    b = cursor(nxt)
    others = other_centers(prev)
    if a is None or b is None or col is None or not others:
        return "NA"
    if prev == nxt:
        return "TRUE"
    if b not in set(others.values()):
        return "FALSE"
    # 别的物件一个都没动（换关以外，它们的中心该原地不动）
    after = other_centers(nxt)
    for c, center in others.items():
        if c == col:
            continue
        sh = shape_of(nxt, c)
        if sh is not None and c in after and after[c] != center:
            return "FALSE"
    want = _vacated(prev, col)
    if want is not None and nxt[a[0]][a[1]] != want:
        return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION5"):
        return None
    a, col = cursor(prev), active(prev)
    others = other_centers(prev)
    if a is None or col is None or len(others) != 1:
        return None                     # 有两个「别的物件」时不知道光标去哪，闭嘴（次序另有概念管）
    want = _vacated(prev, col)
    if want is None:
        return None
    return {list(others.values())[0]: CURSOR, a: want}
