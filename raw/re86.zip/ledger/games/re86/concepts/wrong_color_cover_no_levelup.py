"""用颜色不对的物件盖住一个环心，这一步不会过关——几何盖住只是通关的一半，盖它的物件还得跟它同色。

由来：第 3 关六个环心被两个物件全部几何盖住，分组还分得对（三个归属色 12 的归一个物件、三个归属色 14 的归另一个），
但两个物件是色 6 与色 10，**那一步没有过关**（tid e41df90118bdf4c1）。
在那之前的三关，物件的颜色恰好等于环的归属色，所以「只看几何」和「还要看色」处处给出相同预测，
册子里写的是前者，而它从没被分开检验过。这就是恒真概念长什么样：满分，且什么都没说。

这一条只断言**必要条件的反面**（色不对 ⇒ 不过关），因为那是能从一帧里读出来的部分：
环心一旦被盖住，归属色就永远读不出来了（那一格显示的是盖它的颜色），
而它**刚被盖住的前一帧**一定还露着——所以只在「这一步新盖住某个环心」时开口。
充分条件（色都对上了就一定过关）由 all_on_target_levels_up 管。
"""
LEVEL = "L5"
SCOPE = ("只看平移动作 ACTION1~4；这一步没有新盖住任何环心时返回 NA（那是别的概念的事）；"
         "读不出要动的物件、读不出新盖住的环心的归属色时返回 NA；"
         "新盖住的环心归属色**全都**等于该物件颜色时也返回 NA —— 那一半是充分条件那条的地盘")
NOTE = ""
EVIDENCE = ["e41df90118bdf4c1"]

from _lib import DELTA, _moving_color, newly_covered_rings, ring_owner


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    key = next((k for k in DELTA if action.startswith(k)), None)
    if key is None:
        return "NA"
    fresh = newly_covered_rings(prev, DELTA[key])
    if not fresh:
        return "NA"
    col = _moving_color(prev)
    if col is None:
        return "NA"
    owners = [ring_owner(prev, p) for p in fresh]
    if any(o is None for o in owners):
        return "NA"
    if all(o == col for o in owners):
        return "NA"                      # 色全对上了：该不该过关不是这一条管的
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] else "FALSE"
