"""家具（色 2 的 6×6 空心方框 + 框里那块 4×4 色块）一格不动、一色不变；物件让开之后原样复原。

两句都要：色块的颜色跨帧恒定（碰它的物件变色，它自己不变），被物件盖住的家具格在物件挪开之后
显示回它本来的颜色而不是底色。第 153 步十字退出色块，(9,30) 从 12 回到 2 —— 复原那一半就是它。

这一条撑着 `top_color` 的家具层：没有它，生成器会把「物件让开的地方」一律预测成底色，
而那里露出来的是家具。所以它必须走闸，不能只藏在词汇里。

读法（`furniture`）：色 2 的格子里，四个角能凑出 6×6 的当左上角；内部 4×4 的颜色取 16 格里的多数
（臂路过时最多盖掉几格）。框被物件压掉某个角的那一帧读不出这个框，那时它就不在表里 —— 少说不错说。
"""
LEVEL = "L2"
SCOPE = ("每一步都看（也看 ACTION5）；**换关返回 NA**（整张盘会被换掉，那是 L5 的事）；"
         "prev 里一个框都读不出来（前几关没有色块）时返回 NA；"
         "只核 nxt 里没有被物件或光标占住的家具格 —— 被占住的那几格该显示物件色，那是 zorder_fixed_order 的事")
NOTE = ("v4：一次 202 条反例，全部是**词汇的伤**，不是主张的伤。第 7 关有一个家具框被盘的左边裁掉了半截，"
        "`furniture` 于是吐出列号 -1 的格；Python 的负下标从另一头绕回去，`nxt[r][-1]` 读的是最后一列，"
        "那 5 格于是每一步都「对不上」。词汇把坐标裁进盘内之后，这 202 条逐条重跑全判 TRUE。"
        "它们照硬要求 4 全部登记进 EVIDENCE——**登记的是「它们曾被摆出来打过我」，不是「我从它们推出来」**。"
        "教训：越界坐标在这个语言里不报错，它安静地读到别的地方去；凡是从读法直接生成坐标的词，"
        "出口处都得裁一次盘。\n"
        "v3：第 176 步过关那一帧打了它——667 格全帧替换，第 4 关的盘和第 3 关的家具毫无关系，"
        "而它照旧主张「家具照旧」，押注里 216 格只对了 8 格。这不是家具的事，是换关的事："
        "断言那半加「换关返回 NA」，生成器那半加和平移生成器同一道闸 `levelup_excluded`——"
        "几何上排除不掉过关就闭嘴。教训：**任何『某一块不动』的概念都得先问一句「这一步整张盘还在不在」**，"
        "不动的前提是盘还是那张盘。\n"
        "v2：apply 原来把「当前物件正要压上去」的家具格也主张成照旧（第 151 步 (9,30) 说色 2、实际色 12）——"
        "它在替平移那一条说反话。改成减掉当前物件走完这一步会占住的格子。")
EVIDENCE = ["018f14bced8226eb", "01e9e90ce54d74f4", "030af948d74c4e00",
            "07885a3903bb315c", "08765f1d173888c6", "08b22d8453ad5153",
            "09ba05cf3fc786e9", "0aa15bf010fb6aff", "0ad47e18e7cb1964",
            "0aeb7a498ed69ef9", "0af7fec4444b5270", "0d2cc11e1c5109c4",
            "0e0173395eeb691c", "0f8972139f0bdc9b", "11393e4ee2e10724",
            "116e0990f8850d0e", "12821803877a481a", "12ec5cd2d85c0523",
            "136243426391eee9", "13834d3bb61e11a4", "15d0ff98d6ddb7b2",
            "16b669b12382789b", "16f484e6f827d145", "193c9ffdcff98192",
            "19adf388e8c39ca1", "19c7cead99fb4c40", "1a71c33fb0856c98",
            "1b6264be2f94677e", "210a09dfe74501bb", "2223cc17a21d8b2f",
            "2284857d34e2e122", "2497601479d3d930", "25deb7300333dab0",
            "27a1825007307dc7", "2adac55fd71be42a", "2c75be90987b0d38",
            "2dc75d436479db0f", "2e7d2e9a6397eb52", "2f216677aae769a7",
            "2f6a8777e5b1f68e", "2f6e52f856269411", "2fd6f1143a631bf8",
            "31a8850a79475db5", "32fa6b27117852b4", "333081c0e5ce2528",
            "37beb4876a80f82b", "388b654ce37872e4", "3abda1f07404e72c",
            "3f3e95658145a02b", "4025e5d014448524", "4188590d4a71d012",
            "41cf19739d674128", "42347f11b8c28b55", "448d01393f979735",
            "453138cd2fbb4500", "46477d00ebc52b4c", "479d391ddfd6cff5",
            "4856cb8ea6563dcf", "4924e97c357fae68", "49280929fe4f1097",
            "5267b27c89b16da9", "53ef632f304d3fde", "553e1a0e7002f389",
            "56dc3dd40b5207f1", "5767eb10165a285a", "593969a2e33c88f1",
            "5982de245e61b633", "5f151d5510135700", "5f42aff9adb9a0be",
            "6141fdce0dd2396a", "614f632ff292fa96", "62cd6e661ce21ad9",
            "63142bec618249c5", "663d9d8e0bcc6921", "67df4966248d3d6b",
            "692b5adc12c821c2", "6933ef2ef9ebacde", "697c017fdcedf4c4",
            "6b61dec756c8135f", "6fb0129428ad6376", "72225fb748966350",
            "732167fe6f182eea", "75061dbcd232d29e", "7674a6c4eeae0d8c",
            "77c00f779428db50", "7930d1c3900e7cf7", "79aac4f60d789ca9",
            "7a6cb6820c5a2de0", "7def7a263c33e258", "81a7b42e4758821e",
            "82090cd05ceb4b7f", "82deb7952b4d5622", "83574aa7545b89b9",
            "8549abe37d39c4c8", "85f1b00b55a992d0", "8620c4e979aca397",
            "86289a0ba05eb306", "8637f6968df3f676", "865ca4f2ec7757f0",
            "8716b3d7fc5de5e5", "886da39d3df5ecd8", "89a418a30aedd89f",
            "8acaf16d41905db7", "8bc78b2b8cece0f1", "8be81d71285f84ff",
            "8cd42ef4b5093359", "8cfd0a7781114c4b", "8e012d0ea71fc8c1",
            "916b21201953f30f", "91f86b9146a7dc76", "92062a06c7f5182a",
            "924092c36956db83", "93c5f4fcc1d8eace", "94a90c9f784341a5",
            "976e8f61a793858e", "983d0da895bb5b5f", "985d168fb790e898",
            "9b897f82ba3ae90c", "9c6dceb1366e2654", "9c9ed0f7949aece8",
            "9e3689ea7d20dcdb", "9e9fbd15dcae4eab", "9fd2bf9b906767b6",
            "a0dbc742e23e8113", "a0e98329913dc067", "a0eb8b9610f430c0",
            "a1fae30ce5c0d428", "a2a4a230d8dff655", "a495d15746b52f03",
            "a543eca509e1daec", "a628fb34a8cc6b2c", "a90e0151eb61f73f",
            "aa0046c637a19227", "af1d012aa834793c", "b09491959a147177",
            "b0b794e975deb483", "b1c6d9a23dafa975", "b283d24758cb8623",
            "b2c97313073edb98", "b3f766be97161dc3", "b5658721fabfb709",
            "b76e9963dd7c3170", "b77f3bb3229a9a3a", "b7a0a50b70cb7488",
            "b7c4050d94054508", "ba3e089885eea14c", "ba75c2354afa0ffb",
            "bd9090424a452668", "c58d79b86c4aece3", "c68d6d5c4b2d3878",
            "c701bdd05be45596", "c7da6df96272cea8", "c7dafd174a0743a5",
            "c805237a0fb85a96", "c807dc41b4cc13bc", "c90a93d551f51d1b",
            "c924e54f9dc8711e", "c9af7609dc846527", "c9dd648a8dd97788",
            "c9fa07381fd3ca31", "caabb9d711bd1703", "cadccff568fc2a87",
            "cbf7afa0b722c244", "cc4e6cb308a3a22e", "cda40b256bea0481",
            "ce877795464eea07", "d073349661e804e0", "d1aecfb1261655f4",
            "d1e41d29f4e27306", "d215c00c1e99243e", "d381ece4d93dbd27",
            "d448c08166af34a5", "d5c0dd2a38868c72", "d866cd9abeeca87b",
            "d895bf9686846310", "d898790c9be6742d", "da250fa45cda19a6",
            "da92dd21f5c26346", "db6e2e44c2603109", "dbabfe36eab47379",
            "de84ac0873a2fd69", "dfd9dcba5d648acf", "e11cf2933b494557",
            "e2b42fc3946cbea5", "e34217f3689df06f", "e6cc2124f6193672",
            "e8f7dbe68b40e66f", "e90f165796f57d4f", "ead3a503628c11a3",
            "eb1802c715d578d5", "eb53988e7df475a3", "ebdce8d097a46304",
            "ec912837985aabb6", "edd719179f4ada1a", "ee518b222073c7c3",
            "ee9b582db5257c0a", "ef009a868bb8800d", "f00a96f603d064e5",
            "f0801c0e35bb5fdb", "f30e17b5548c5d25", "f67678eebc13b238",
            "f6de4ec4a709e915", "f83ed7b89f63abb1", "f9233ccca82c8405",
            "fab56b9a46b14e18", "fb9e1648de2185e7"]

from _lib import (DELTA, active_center, cursor, furniture, levelup_excluded,
                  objects, stamp, swatches)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"                          # 换关：整张盘换掉，这一条不管
    fur = furniture(prev)
    if not fur:
        return "NA"
    occupied = set()
    for ctr, (kind, _col, L) in objects(nxt).items():
        occupied |= stamp(kind, ctr, L) | {ctr}
    cur = cursor(nxt)
    if cur is not None:
        occupied.add(cur)
    ac = active_center(nxt)
    if ac is not None:
        occupied.add(ac)
    for p, want in fur.items():
        if p in occupied:
            continue
        if nxt[p[0]][p[1]] != want:
            return "FALSE"
    # 色块颜色本身不许变（nxt 读不出某个框时跳过那个框，不当反例）
    sw_next = swatches(nxt)
    for cells, col in swatches(prev).items():
        if cells in sw_next and sw_next[cells] != col:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """家具格里**这一帧就露着、而且这一步没有物件要压上来**的那些，下一帧照旧。

    两道减法都必要：
    - 只认「prev 里已经露着」的：物件让开之后要露出来的那些格子由平移生成器负责
      （它走 `top_color`，那里也走 `furniture`），这里不越界替它说话。
    - 还要减掉「当前物件走完这一步会占住」的格子：第 151 步十字的臂尖伸进 (9,30)，
      那一格 prev 里露着色 2，下一帧是色 12。不减这一块，这条就在替平移那一条说反话。
    """
    fur = furniture(prev)
    if not fur:
        return None
    occupied = set()
    for ctr, (kind, _col, L) in objects(prev).items():
        occupied |= stamp(kind, ctr, L) | {ctr}
    cur = cursor(prev)
    if cur is not None:
        occupied.add(cur)
    key = next((k for k in DELTA if action.startswith(k)), None)
    if key is not None:
        if not levelup_excluded(prev, DELTA[key]):
            return None                      # 几何上排除不掉过关就闭嘴：换关会把整张盘换掉
        ctr = active_center(prev)
        objs = objects(prev)
        if ctr is None or ctr not in objs:
            return None                      # 谁在动读不出来 → 减不掉，宁可不说
        kind, _col, L = objs[ctr]
        d = DELTA[key]
        q = (ctr[0] + d[0], ctr[1] + d[1])
        occupied |= stamp(kind, q, L) | {q}
    out = {p: want for p, want in fur.items()
           if p not in occupied and prev[p[0]][p[1]] == want}
    return out or None
