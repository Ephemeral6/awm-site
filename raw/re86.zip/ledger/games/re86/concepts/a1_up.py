"""ACTION1 要么让光标上移恰好 CELL 格、列不变，要么整帧不动。

v2：加一条前提——这一步不许撞上挡块。实测两步：当前物件上移会压到盘上那块实心的挡块，
结果**光标一格没动**，而物件的形状变了（被挡那条臂缩短、对面那条臂伸长同样多，格子数一格不差）。
撞上挡块那一步归 blocked_deforms 管。
`will_block` 读不出当前物件时不加这道门 —— 那是读法的沉默，不是世界说了什么。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1；换关返回 NA；光标读不出来（色0 不唯一）返回 NA；"
         "当前物件上移 CELL 后的理想形状会压到挡块（will_block 非空）时返回 NA "
         "—— 那一步物件不整体平移")
NOTE = "v1 死于两步「撞上挡块，光标不动、形状变了」的转移，和 a3_left v1 是同一种死法。"
EVIDENCE = ["53c0f3e343567397", "f248eefee9cfa2b3", "fd2cc1948c75bb92"]

from _lib import CELL, cursor, translate_apply, DELTA, will_block


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION1"):
        return "NA"
    if will_block(prev, DELTA["ACTION1"]):
        return "NA"
    a, b = cursor(prev), cursor(nxt)
    if a is None or b is None:
        return "NA"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (-CELL, 0) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION1"):
        return None
    if will_block(prev, DELTA["ACTION1"]):
        return None
    return translate_apply(prev, DELTA["ACTION1"])
