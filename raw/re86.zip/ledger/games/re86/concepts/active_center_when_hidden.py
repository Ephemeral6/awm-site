"""光标整盘不露头时，`_lib.active_center` 的兜底（「中心被别的物件压着的那一个」）指认的就是真正动了的那个物件。

由来：第 91、97 步斜叉的新中心落在另一个物件的轮廓上，`cursor()` 返回 None。
整册凡是要「当前物件是谁」的读法，这两步都得靠这条兜底，答错一次后面每一步都跟着错。
这句话原本捎在 cursor_hidden_by_object 里，但它和「被压的那一格显示什么颜色」是两件事：
一件问像素，一件问共享词汇的兜底逻辑稳不稳。混在一条里，兜底塌了会连坐掉一条本来没错的颜色主张。

判错的办法不看光标，看结果：把 prev 和 nxt 的物件表对一遍，谁的中心恰好挪了这一步的位移谁就是动了的那个；
兜底指的是不是他。挪了的物件不唯一（认不出来）就返回 NA，不猜。
"""
LEVEL = "L6"
SCOPE = ("只看平移动作 ACTION1~4；只看「光标不露头」那一类局面（cursor(prev) 非 None 时返回 NA，"
         "那是常态，由别的概念管）；换关返回 NA；一颜色一物件读得出来的关返回 NA；"
         "这一步该过关返回 NA；从 prev/nxt 的物件表里认不出「恰好挪了一格位移」的唯一物件时返回 NA")
NOTE = "v1：从 cursor_hidden_by_object v2 拆出来，只断言兜底指认得对，不管那一格是什么颜色。"
EVIDENCE = ["977d5fa4fcc7b8a2", "0ce649625cee8c21"]

from _lib import DELTA, active_center, cursor, objects, shapes, would_win


def _moved(prev, nxt, d):
    """从两张物件表里找出「中心恰好挪了 d」的那个物件；不唯一就返回 None。"""
    a, b = objects(prev), objects(nxt)
    hit = [c for c, v in a.items()
           if c not in b
           and (c[0] + d[0], c[1] + d[1]) in b
           and b[(c[0] + d[0], c[1] + d[1])] == v]
    return hit[0] if len(hit) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DELTA.get(action.split()[0] if action else "")
    if d is None:
        return "NA"
    if shapes(prev):
        return "NA"
    if cursor(prev) is not None:
        return "NA"                          # 光标露着头，不需要兜底
    if would_win(prev, d) is not False:
        return "NA"
    m = _moved(prev, nxt, d)
    if m is None:
        return "NA"
    return "TRUE" if active_center(prev) == m else "FALSE"
