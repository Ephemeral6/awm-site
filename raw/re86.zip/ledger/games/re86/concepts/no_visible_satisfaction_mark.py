"""环心一旦被物件盖住，它的归属色就不再出现在帧里：同色盖住的环与错色盖住的环，环框八格与 5×5 邻域逐格相同。

这一条说的是**观测**，不是世界的动力学：它断言「满足与否」在像素上没有可见凭据。
由来：第 161 步之后的那一帧第一次把两类环摆在一起——(18,15)(43,15)(30,27) 归属 12、被色 12 的十字盖着（同色），
(21,48)(24,33)(39,30) 归属 14、被色 10 的斜叉盖着（错色）。两类各三个环，环框八格的颜色直方图
同色 {4:19, 12:5} vs 错色 {4:18, 10:6}，差别全部来自「盖它的那条臂是什么颜色、压掉了框上哪几格」，
没有任何一格是「满足」这件事画出来的标记。

**它是 `would_win` 那个死角的名字。** 通关的充分方向（六环都被同色盖住 ⇒ 过关）没法从单帧确认，
不是因为读法不够好，而是因为要读的东西不在帧里。这也解释了 `all_on_target_levels_up` 为什么恒 NA：
它要问的前提，世界从来不显示。

**它随时可能死**：世界哪天在满足的环上画一个标记（换色、加一圈、闪一下），这一条当场变反例，
而那一天 `would_win` 的死角就没了、`all_on_target_levels_up` 就能开口了。所以它值得走闸——
它是「我们此刻为什么问不出来」的可判错版本。

读法：拿一帧里被盖住的环心，按「盖它的物件色 == 从更早的帧读到的归属色」分成同色/错色两类，
比较两类环的环框八格与 5×5 邻域**逐个位置**的颜色。归属色本身不从这一帧读（读不出来才有这条概念），
而是从本关早先环心还露着的帧读来——同一关的指纹是环心集合。
"""
LEVEL = "L7"
SCOPE = ("只看被物件盖住的环心；一帧里凑不出「同色一类 + 错色一类」（两类都要有）时返回 NA；"
         "归属色从本关早先的帧读不出来时返回 NA；ctx 缺失返回 NA（要靠它拿语料以外的关卡指纹时不行，"
         "所以这一条只用同一条转移的两帧 + 一张由 prev 自己算出来的归属色表）；"
         "nxt 帧有残料（属于某个物件却解释不掉的格子）时返回 NA —— 见 v3")
NOTE = ("v3：加了残料闸。打它的那一步上，一个十字的竖杠被另一个物件的竖杠整条压住，"
        "识别器于是把它降级成一条横线——竖杠没了，`_occupied` 就少扣了整条杠的格子，"
        "环框上那些**其实被杠盖着**的格子露了出来，被这一条当成「一个可见的标记」判了自己错。"
        "世界一格都没画错：那三格露着的本色正是识别器解释不掉的残料。\n"
        "这道闸不是「用读法的沉默盖住无知」——两者的分界线在于闸的口径："
        "`_occupied` 的语义是「盘上被物件压着的格子」，而残料按定义就是「属于某个物件却解释不掉的格子」，"
        "也就是 `_occupied` 必然漏掉的那些。输入缺了一块时弃权是诚实，不是躲反例；"
        "躲反例的写法是拿一个与主张无关的量当门。\n"
        "这一条的归属色表只能从**它自己拿到的两帧**里算，因为概念看不到语料。"
        "于是它换了个等价的问法：不比「同色 vs 错色」，改比**同一帧里被盖住的每一个环**——"
        "只要环框上『没有任何东西压着』的格子全是色 4，就说明满足与否没在框上留下痕迹。"
        "这比原来的说法弱一点（它不知道哪个是同色），但它是这一条在只有两帧时能诚实主张的全部。\n"
        "v2：第 24 步打了它。遮挡原来是**按颜色**扣的（扣掉盖住环心那个颜色的格子），"
        "而环框上那一格坐着光标，显示色 0——既不是色 4 也不是那个物件色，于是被当成了「一个可见的标记」。"
        "改成**按几何**扣：谁的理想形状盖在这一格上就扣掉，光标格也扣掉。"
        "教训写成一句：『扣掉遮挡』要按几何算，按颜色算会把贴在物件上的东西（光标）漏出来当成标记。")
EVIDENCE = ["5887452af303dcfa", "e41df90118bdf4c1", "09ba05cf3fc786e9",
            "500d67b5b7944ffa", "e181fea5c4f57d64"]

BLOCKING = False

from _lib import (BG, CURSOR, RING_EDGE, _cur_objs, cursor, ring_centers, stamp,
                  unexplained)


def _covered(g):
    """{环心: 盖住它的物件颜色集合}，只留真被盖住的。"""
    rc = ring_centers(g)
    out = {}
    for p in rc:
        cols = {col for _k, col, kind, ctr, ln in _cur_objs(g)
                if p in stamp(kind, ctr, ln) or p == ctr}
        if cols:
            out[p] = cols
    return out


def _occupied(g):
    """盘上被物件（理想形状 + 中心）或光标压着的格子 —— 按**几何**算，不按颜色算。

    按颜色算会漏：环框上那一格坐着光标时它显示色 0，既不是环框色也不是物件色，
    于是会被当成「一个可见的标记」，而那只是光标贴在物件上（见 v2）。
    """
    out = set()
    for _k, _col, kind, ctr, ln in _cur_objs(g):
        out |= stamp(kind, ctr, ln) | {ctr}
    cur = cursor(g)
    if cur is not None:
        out.add(cur)
    return out


def _ring_face(g, p, occ):
    """环框八格里**什么都没压着**的那些格子，按相对位置给出颜色。"""
    face = {}
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if (dr, dc) == (0, 0):
                continue
            q = (p[0] + dr, p[1] + dc)
            if q in occ:
                continue
            face[(dr, dc)] = g[q[0]][q[1]]
    return face


def assert_(prev, action, nxt, ctx=None):
    if unexplained(nxt):
        return "NA"                          # 识别器解释不掉的格子 = _occupied 必然漏掉的格子
    cov = _covered(nxt)
    if len(cov) < 2:
        return "NA"
    # 至少要有两个被**不同颜色**物件盖住的环，否则问不出「不同待遇」
    groups = {}
    for p, cols in cov.items():
        if len(cols) != 1:
            continue
        groups.setdefault(next(iter(cols)), []).append(p)
    if len(groups) < 2:
        return "NA"
    occ = _occupied(nxt)
    faces = []
    for col, ps in groups.items():
        for p in ps:
            f = _ring_face(nxt, p, occ)
            if any(v == BG for v in f.values()):
                return "NA"                  # 贴盘边或环框读飘了，不比
            faces.append(f)
    if not any(faces):
        return "NA"                          # 八格全被压着，一格都没露出来：问不出
    # 主张：什么都没压着的环框格全是环框色。露着**别的**颜色就是一个可见的标记，这一条当场为假。
    for f in faces:
        for v in f.values():
            if v not in (RING_EDGE, CURSOR):
                return "FALSE"
    return "TRUE"
