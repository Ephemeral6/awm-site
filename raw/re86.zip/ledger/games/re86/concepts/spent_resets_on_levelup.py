"""换关那一步，预算归零：新一关的 HUD 整行重新变回「还没花」的色 15，spent 从头数。

由来：全部 70 条转移里，spent 变小的只有两条，正好就是那两条换关转移（第 27、65 步），
别的动作一条都没让它减少过。第 2 关开局实测 HUD 64 格全是色 15。
"""
LEVEL = "L4"
SCOPE = ("只看换关的那一步（ctx.level_prev != level_next）；不换关一律 NA —— "
         "不换关时预算怎么走是 hud_delta_01 的地盘。ctx 读不出来返回 NA。"
         "**这一步把整局打完时（state_next 不是 NOT_FINISHED）返回 NA** —— "
         "没有下一关开始，也就没有新预算可发")
NOTE = ("这条把扣费审计里那件怪事解释掉了：第 0 关与第 1 关的「本关第几步 → 扣几点」表逐位相同，"
        "因为预算本来就是按关发的。\n"
        "负结果记在这里：知道了这一条，扣费规则仍然写不成概念 —— 它只依赖「本关第几步」，"
        "而 assert_ 拿不到本关步数（ctx 只给全局 step），spent(prev) 也不是充分键"
        "（同一个值既接 delta 0 又接 delta 1）。这是接口的墙，不是没找到。\n"
        "v2：打完最后一关那一步判 FALSE（29aa2e0faa1ff1c8），HUD 停在 spent=32 没有归零。"
        "v1 把「换关」和「新一关开始」当成了一回事，而通关那一步只是前者。缩 scope，不改主张。\n"
        "v2 的 apply 没跟着缩：它仍然在「该过关」的那一步预测整行 HUD 重置，所以在打完整局的那一步"
        "会预测错一整行。留着不动，因为从帧本身看不出这是不是最后一关——"
        "assert_ 靠 ctx.state_next 才躲开的坑，apply 手上没有这个字段。这一格代价记在账上。")
EVIDENCE = ["40b8606076657fe9", "726207448a510e23", "29aa2e0faa1ff1c8"]

from _lib import DELTA, HUD_LEFT, HUD_ROW, spent, would_win


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    if ctx["level_prev"] == ctx["level_next"]:
        return "NA"
    if ctx.get("state_next") not in (None, "NOT_FINISHED"):
        return "NA"                     # 整局到此为止，没有新一关，也就没有新预算
    return "TRUE" if spent(nxt) == 0 else "FALSE"


def apply(prev, action, ctx=None):
    d = DELTA.get(action.split()[0] if action else "")
    if d is None:
        return None
    if would_win(prev, d) is not True:
        return None                     # 只有该过关的那一步才敢说 HUD 会重置
    return {(HUD_ROW, c): HUD_LEFT for c in range(len(prev[HUD_ROW]))}
