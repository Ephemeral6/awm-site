"""十字撞上挡块那一步，两条杠各走各的：新位置压到挡块的那条原地不动，没压到的那条照常平移 CELL。

交点永远是「横杠的行 × 竖杠的列」，两条杠各自的长度一格不变，所以总格数不变。
挡块是**挡**（形状原地改形），盘边是**裁**（形状照旧平移、伸出去的不画），两回事，各归各的概念。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1~4 且帧真的变了；换关返回 NA；"
         "will_block 是空集（不撞）或 None（读不出当前物件）都返回 NA —— "
         "空集归 a1~a4 那几条平移概念管，None 是读法的沉默；"
         "变形前后的当前物件认不出来返回 NA；"
         "当前物件不是十字类（plus/cross）时返回 NA —— 空心矩形撞挡块是另一种变形，"
         "包围盒会跟着变，归 blocked_rect_trades 管；"
         "两条杠都被挡、或都没被挡（整体撞上但逐杠都不撞）返回 NA —— 没实测过；"
         "平移之后交点落到另一条杠外面（某条臂算成负数）返回 NA —— 也没实测过；"
         "**next 帧里长度是补出来的那几条臂不参与判错**（`_lib.unmeasured_arms`），"
         "四条臂全是补出来的返回 NA —— 交点仍然照判")
NOTE = ("v7：同一条反例（终局卡第 1094 步，ACTION4）换了修法：v6 的「掐掉整档」赔完成度，"
        "v7 改成**夹紧**——盘上本来就有第二个观测说着同一个量：**光标就是包围盒中心的一次直接观测**。"
        "把它和量得到的那条对臂放在一起，量不到底的那条臂就被夹进两格宽的区间（`_lib.pinned_arms`），"
        "取短的那个：比它短的与光标矛盾，比它长的这一帧分不出来。世界随后确认了夹出来的值"
        "（那一步押注里「横杠真长应是 15」兑现），这条转移现在逐格预测零错。"
        "主张一个字没改——改的始终是喂给它的输入。\n"
        "代价与账要一起记：`pinned_arms` 第一版对四下对称的形状返回了四元组，而它们的 L 是整数，"
        "141 条概念当场抛 TypeError，E 从 0.716 掉到 0.608；按类型分档修好后 E=0.714，"
        "比夹紧之前低 0.002——夹紧不是白拿的，它让若干格从「敢说」退回「不认领」。\n"
        "v6：终局卡第 1094 步这条律算的形状被世界驳回 3 格——不是律错，是它拿来算的**臂长是猜的**："
        "上一帧竖杠下半截整条压在别人的边下面，读法按「不对称要有证据」把它回补成了最长那条臂。"
        "全语料差分随后把这一刀的分寸量了出来：十字类当前物件的帧 324 个，某条臂是补出来的 59 个，"
        "整条臂一格都露不出来的 2 个——露着一半的 57 次没出过事，整条看不见的 2 次全错。"
        "于是只掐掉后一种（`_lib._cross_L` 那一档改成弃权），代价是 E 掉 0.002。"
        "**一条律用错了输入，看起来和这条律错了一模一样**；分辨的办法是看生成器画出去的那几格"
        "是不是全落在读不出来的那一截上。\n"
        "v5：断言从「整片形状相等」改成「交点相等 + 逐臂相等，补出来的臂跳过」。"
        "由来：竖杠整条平移到另一个物件的一条边下面，下半截一格都露不出来，"
        "`_cross_L` 按「不对称要有证据」把它回补长了 3 格，于是这条概念拿一个推出来的值判自己错。"
        "生成器一个字没动，那一步逐格预测全中——错的只是拿读不出来的那截去比。"
        "跳过的判据与 bar_len_conserved 共用 `_lib` 里同一处，不各写一份。\n"
        "v4：主张换了。v3 说的是「包围盒一格不动、交点朝动作方向移 CELL」，死于一步"
        "「横杠被挡、竖杠没被挡」的上移：交点一格没动，反倒是包围盒跟着竖杠上移了 CELL——"
        "和 v3 的话正好相反。回头看语料，v3 之前经手的 7 次撞击里被挡的**恰好全是竖杠**，"
        "于是「竖杠不动」被读成了「包围盒不动」，「横杠平移」被读成了「交点平移」。\n"
        "教训：一条律里出现「不动的那个」时，要问「不动的是这个部件，还是它恰好一直是被挡的那一个」。"
        "样本里若某个角色从没换过人，那条律里就藏着一个没被检验的等式。\n"
        "v3：补上生成器。断言一个字没动——加的是把这条律主张的新形状画回帧上的那段手续"
        "（`_lib.deform_apply`）。不加的代价不只是 E：撞挡块那一步全册只剩家具概念开口，"
        "链式假帧停在旧形状上，于是撞挡块的动作一直只能排在批尾，一批走不了两次形变。\n"
        "v1 把十字的形变律当成了所有形状的形变律，死在三步「空心矩形向右撞挡块」上："
        "矩形的包围盒从 19x19 变成 22x16，而这条说包围盒不动。"
        "教训：形变律是**按形状**分的，一条概念只说一种形状。")
EVIDENCE = ["d22aec9297383843", "921e6971bc5fb2cc", "f248eefee9cfa2b3", "fd2cc1948c75bb92",
            "a2be021b53100620", "a6a958a355b9a3ad", "6f472b2e12b8cfaf",
            "689d800edd953a0c", "a8019168932b64bc", "3b95edc0fd45b9ad",
            "65108b6f28dbf0a3"]

from _lib import (DELTA, active_center, blockers, deform_apply, objects,
                  pinned_arms, stamp, unmeasured_arms, will_block)

CROSSLIKE = ("plus", "cross")


def _bars(ctr, L):
    """把十字拆成两条杠：竖杠 (列, 行首, 行尾)、横杠 (行, 列首, 列尾)。"""
    up, dn, lf, rt = (L, L, L, L) if isinstance(L, int) else L
    r, c = ctr
    return (c, r - up, r + dn), (r, c - lf, c + rt)


def _deform(prev, d):
    """按这条律算出变形后的 (交点, 四臂长)；算不出来或落在没实测过的情形返回 None。"""
    ctr = active_center(prev)
    if ctr is None:
        return None
    objs = objects(prev)
    kind, _col, L = objs[ctr]
    if kind not in CROSSLIKE:
        return None
    L = pinned_arms(prev, ctr) or L        # 没量到底的臂按光标夹紧：律没错，别拿下界当输入
    (cv, rv0, rv1), (rh, ch0, ch1) = _bars(ctr, L)
    blk = blockers(prev)
    vhit = any((r + d[0], cv + d[1]) in blk for r in range(rv0, rv1 + 1))
    hhit = any((rh + d[0], c + d[1]) in blk for c in range(ch0, ch1 + 1))
    if vhit == hhit:
        return None
    if vhit:                                   # 竖杠钉住，横杠整条平移
        cv2, rv02, rv12 = cv, rv0, rv1
        rh2, ch02, ch12 = rh + d[0], ch0 + d[1], ch1 + d[1]
    else:                                      # 横杠钉住，竖杠整条平移
        cv2, rv02, rv12 = cv + d[1], rv0 + d[0], rv1 + d[0]
        rh2, ch02, ch12 = rh, ch0, ch1
    L2 = (rh2 - rv02, rv12 - rh2, cv2 - ch02, ch12 - cv2)
    if min(L2) < 0:
        return None
    return (rh2, cv2), L2


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DELTA.get(action.split()[0])
    if d is None:
        return "NA"
    if prev == nxt:
        return "NA"
    if not will_block(prev, d):
        return "NA"
    got = _deform(prev, d)
    if got is None:
        return "NA"
    ctr2, L2 = got
    b = active_center(nxt)
    if b is None:
        return "NA"
    kb, _colb, Lb = objects(nxt)[b]
    if kb not in CROSSLIKE:
        return "NA"
    if b != ctr2:
        return "FALSE"                     # 交点落错了地方，四条臂再对也没用
    um = unmeasured_arms(nxt, b)
    if um is None or len(um) == 4:
        return "NA"                        # 四条臂全是补出来的：这一帧定不下新形状
    Lb4 = (Lb, Lb, Lb, Lb) if isinstance(Lb, int) else Lb
    for i in range(4):
        if i in um:
            continue                       # 这条臂的长度是补出来的，不是读数，不拿它判错
        if Lb4[i] != L2[i]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """两条杠各自的去留一定，新形状就算死了——所以这条概念生成得出整片格子。"""
    d = DELTA.get(action.split()[0])
    if d is None:
        return None
    if not will_block(prev, d):
        return None
    got = _deform(prev, d)
    if got is None:
        return None
    ctr2, L2 = got
    return deform_apply(prev, "cross", ctr2, L2)
