"""物件碰色块整件改色，它和别人的上下关系不变：改色前排在谁上面，改完还排在谁上面。

图层是**物件自己的**属性，颜色只是它此刻的显示。这句话平时看不出区别，
只在生成器要画「刚改完色的这一帧」时才吃重：这一帧的直接读数（`_lib.frame_above`）
说的全是**旧颜色**和别人的次序，新颜色一格证据都没有，而退回跨关攒的 `ABOVE` 等于换了把尺，
那把尺的键（颜色）在这个世界里不稳——全语料 16 个无序颜色对里有 2 对两个方向都有证据。
所以生成器改成把旧色的次序原样搬到新色上（`_lib.recolor_order`），而搬得动靠的正是这一条。
它是那段读法的地基，所以单独写出来挨打，不藏在 `_lib` 里当默认值。

判法：当前物件这一步平移到 q、按 `swatch_hits` 恰好碰上一个色块、且颜色确实要变；
在 nxt 里 q 处认得出同形状、同新色的物件（认不出就是换了别的东西，不管）。
然后把 prev 这一帧直接量到的、带旧色的有向对逐条搬到新色上，去 nxt 这一帧的直接读数里对：
方向翻了判 FALSE，一对都没有两帧都量到的判 NA，其余判 TRUE。

由来：全语料 1171 条预跑一遍——开口 4 条全 TRUE，0 条反例，1167 条弃权。
开口少是因为「改色 + 改色前后同一对重叠都量得到」这两件事同时成立的机会本来就少；
它照样值得写：终局卡上说错的那一格，就是这条不成立时会画错的那一格。
"""
LEVEL = "L7"
SCOPE = ("只看平移动作 ACTION1~4；换关返回 NA；"
         "这一步没碰色块、碰了两个色块、或碰上的色块与本色相同返回 NA；"
         "nxt 里认不出「同形状同新色、心在 q」的物件返回 NA（认不出就不是同一件东西）；"
         "改色前后没有一对是两帧都直接量得到的返回 NA。"
         "只说方向翻没翻，不说次序是什么、也不说色块为什么会染色（那是 swatch_recolors_object）")
NOTE = ""
EVIDENCE = ["09ba05cf3fc786e9", "5a4e6e5dbfaf4745", "a1e9c129fb637100", "eccdb6e3c4a1503f"]

from _lib import DELTA, active_center, frame_above, objects, stamp, swatch_hits


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DELTA.get(action.split()[0] if action else "")
    if d is None:
        return "NA"
    ctr = active_center(prev)
    if ctr is None:
        return "NA"
    objs = objects(prev)
    if ctr not in objs:
        return "NA"
    kind, col, L = objs[ctr]
    q = (ctr[0] + d[0], ctr[1] + d[1])
    hits = swatch_hits(prev, stamp(kind, q, L))
    if len(hits) != 1:
        return "NA"
    new_col = next(iter(hits))
    if new_col == col:
        return "NA"
    o2 = objects(nxt)
    if q not in o2 or o2[q][0] != kind or o2[q][1] != new_col:
        return "NA"
    a, b = frame_above(prev), frame_above(nxt)
    seen = 0
    for (x, y) in a:
        if x == col:
            if (y, new_col) in b:
                return "FALSE"
            if (new_col, y) in b:
                seen += 1
        elif y == col:
            if (new_col, x) in b:
                return "FALSE"
            if (x, new_col) in b:
                seen += 1
    return "TRUE" if seen else "NA"
