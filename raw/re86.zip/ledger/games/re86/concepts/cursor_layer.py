"""光标不在最上层：它贴在当前物件那一层，比当前物件高的物件会把它盖掉——那一格显示的是更上层物件的颜色。

由来：第 52 步操控权切到色 12，光标该落在它的中心 (48,18)，但那一格实际显示色 9 ——
色 9 的横臂正压在那里，而 ZORDER 里色 9 在色 12 之上。整张盘上因此一个色 0 都没有。
反过来，当前物件是最上层（或那一格没人压）时，光标压得过自己的物件色（第 0 关全程如此）。
"""
LEVEL = "L6"
SCOPE = ("只看 next 帧；认不出当前物件就没法判（见下）——所以这条改从 prev 帧推当前物件：只看 ACTION5，"
         "prev 里读得出当前物件、且换人目标算得出来时才开口，其余返回 NA")
NOTE = ("这条概念本身踩着一个装置层面的坑：光标被盖住时 `cursor()` 返回 None，`active()` 跟着 None，"
        "全册依赖「当前物件」的读法一起闭嘴——所以它不能从 next 帧读当前物件，只能从 prev 帧推。")
EVIDENCE = ["09f89fd0822be128"]

from _lib import CURSOR, ZORDER, active, shape_of, shapes, stamp


def _z(col):
    return ZORDER.index(col) if col in ZORDER else 99


def _next_color(g, col):
    cols = sorted(shapes(g))
    if len(cols) < 2 or col not in cols:
        return None
    bigger = [c for c in cols if c > col]
    return bigger[0] if bigger else cols[0]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    col = active(prev)
    if col is None:
        return "NA"
    new_col = _next_color(prev, col)
    tgt = shape_of(prev, new_col) if new_col is not None else None
    if tgt is None:
        return "NA"
    q = tgt[1]
    # 换人之后，压在 q 上面的物件（新的当前物件自己不算——光标压得过自己）
    over = [c for c, (k, ctr, l) in shapes(prev).items()
            if c != new_col and q in stamp(k, ctr, l)]
    v = nxt[q[0]][q[1]]
    if not over:
        return "TRUE" if v == CURSOR else "FALSE"
    over.sort(key=_z)
    top = over[0]
    if _z(top) > _z(new_col):
        return "TRUE" if v == CURSOR else "FALSE"     # 压它的都在它下面，光标照样露头
    return "TRUE" if v == top else "FALSE"
