"""空心矩形撞挡块、而「换」出来的新短边小于 CELL+1 时，这一步世界**整帧一格不动**。

`blocked_rect_trades` 说的是撞上挡块之后怎么换边：迎面那条边缩 CELL、垂直方向补 CELL。
这一条说的是那笔交易的**下限**：缩完短边只剩 1 格，剩下的已经不是一个空心矩形（只剩一条线），
世界不接受这笔交易，也不退而求其次地平移或部分形变——它什么都不做，prev 与 nxt 逐格相同。

由来：第 1987 步 ACTION1，当前物件是 4×22 的空心矩形（包围盒 (6,9,39,60)，边长和 26），
迎面撞上挡块，按交易律该变成 1×25。世界整帧没动一格。
全语料里 will_block 为真的 67 条转移分两堆，分得干干净净：
变了的 66 条，形变**后**的短边是 4/7/10/13/16/22，全都 ≥ 4；没动的这 1 条，形变后短边是 1。
形变**前**的短边分不开两堆（4 在两堆里都出现），所以载重的是形变**后**那个数。

它只有一条正面证据，所以它最可能错在**门槛的位置**：也许下限不是「还得是个空心矩形」（≥ CELL+1），
而是别的什么。门槛写成 CELL+1 是因为边长在这个世界里恒为 3k+1，而 1 是唯一小于 4 的那个取值——
真正的分界点落在 1 和 4 之间的哪里，语料分辨不出来。要证伪它，去走一个形变后短边正好是 4 的局面
（那里它必须闭嘴、由 blocked_rect_trades 判），或者走一个形变后短边是 1 而世界**动了**的局面（当场 FALSE）。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1~4；换关返回 NA；"
         "will_block 是空集（不撞）或 None（读不出当前物件）返回 NA；"
         "当前物件读不出来、或不是矩形类（square/rect）返回 NA —— 十字归 blocked_deforms 管；"
         "**换出来的新短边 >= CELL+1 时返回 NA** —— 那是 blocked_rect_trades 的地盘，"
         "两条概念按同一个、只看 prev 就能算出来的分界线分工，谁也不许在对方那一侧说话")
NOTE = ("v1：从第 1987 步那次「生成器说错 31 格而断言一声不吭」抽出来的。"
        "被打的是 blocked_rect_trades 的生成器；它的断言开头有一行 `if prev == nxt: return NA`，"
        "把「整帧不动」这种真实结局写成了弃权，于是它恰好在自己会错的地方闭嘴。"
        "补这一条的意义就在这里：那一片不能只是从一条概念的 scope 里被切掉，"
        "得有另一条概念在那里说一句能被判错的话，否则缩 scope 就等于把盲区洗成了满分。")
EVIDENCE = ["4ceb26ea66013f2e"]

from _lib import CELL, DELTA, active_center, bbox, objects, will_block

RECTLIKE = ("square", "rect")
MIN_SIDE = CELL + 1


def _traded_sides(bb, d):
    """交易之后的两条边长。装置逐条 exec 概念文件，概念之间 import 不了，
    所以这里不引 blocked_rect_trades.predict_bbox，自己按同一条律算一遍。

    只算**边长**，不算包围盒：涨出来的那 CELL 加在哪一头（`_grow` 的就近取舍）
    不改变边长，这条概念也用不着知道。重算是件好事——两处对「交易后的短边是几」
    如果哪天算出不同的数，两条概念的分界线就会错开，其中一条当场判 FALSE。
    """
    r0, r1, c0, c1 = bb
    dr, dc = d
    h, w, n = r1 - r0 + 1, c1 - c0 + 1, abs(dr) + abs(dc)
    return (h + n, w - n) if dc else (h - n, w + n)


def _no_room(prev, d):
    """这一步的交易换不换得动。只看 prev 和动作——弃权条件不许依赖结论。

    返回 None 表示「这条概念的前提不成立」（不撞、读不出、不是矩形类），
    True 表示「撞了而且换不动」，False 表示「撞了但换得动」。
    """
    if not will_block(prev, d):
        return None
    a = active_center(prev)
    if a is None:
        return None
    ka, _col, La = objects(prev)[a]
    if ka not in RECTLIKE:
        return None
    return min(_traded_sides(bbox(ka, a, La), d)) < MIN_SIDE


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DELTA.get(action.split()[0])
    if d is None:
        return "NA"
    if _no_room(prev, d) is not True:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"


def apply(prev, action, ctx=None):
    """整帧不动 = 每一格都照旧。敢把整张盘都认领下来，是因为这条主张说的正是「什么都没发生」。

    它和别的概念在这一步会不会打架，就是这条主张对不对的另一种问法：
    要是 a1_up 之类在这里说物件动了，装置会把打架的格子丢掉并记一笔，那正是该去看的地方。
    """
    d = DELTA.get(action.split()[0])
    if d is None:
        return None
    if _no_room(prev, d) is not True:
        return None
    return {(r, c): v for r, row in enumerate(prev) for c, v in enumerate(row)}
