"""斜叉/菱形的中心那一格，只要这一步没换到它身上、也没有别的物件的形状盖过它，颜色就一步之内不变。

这条话是本局词汇 `_lib._body` 的地基：`stamp` 里斜叉与菱形的中心不算它自己的格，
可实测中心那一格常年填着本色（非当前的斜叉/菱形，中心显示本色 34 次），
所以「中心归不归它」不是形状的性质，得看帧。而「看帧」只有在那一格的颜色**属于这个物件本身**、
不是路过的臂时才作数——这一条断言的正是那件事：没人碰它，它就不变。

由来两处，方向相反，缺一处就会写错：
- 第 130/131 步（tid 701153e46943271a / 36811c2b80f6b2c7）：中心显示的本色 10，
  盖它的臂是色 6 的物件；臂走了那一格还是 10。所以那个 10 是它自己的，中心确实填着。
- 第 96 步（tid 52a6e663cf4910a2）：中心显示 8、菱形本色也是 8，但盖它的斜叉也是色 8；
  斜叉一走那一格露出底色。所以同色的臂路过和「我填着本色」在一帧里长得一模一样，分不开。
两处合起来才逼出 `_body` 现在的规矩：本色的中心算它自己的，**除非有别的同色物件的形状也盖着**。

「挖空」怎么发生的（实测同一个物件先本色后底色，改不回来）是另一件事，这一条不管；
这一条只说「没人碰就不变」，所以填着的照旧填着、挖空了的照旧空着，两半都被它约束。
"""
LEVEL = "L6"
SCOPE = ("只看这一帧里读得出来的非当前斜叉/菱形（`plus` 的中心本来就在 `stamp` 里，不在此列）；"
         "换关返回 NA；prev 里有 unexplained（认不出的东西，物件表不全）返回 NA；"
         "这一步该过关（整帧要换）返回 NA；"
         "光标这一步落到该中心上、或有别的物件的**理想形状**在 prev 或 nxt 里盖住该中心时，"
         "这一格不由它做主，跳过；一个符合条件的中心都没有时返回 NA")
NOTE = ""
EVIDENCE = ["701153e46943271a", "36811c2b80f6b2c7", "52a6e663cf4910a2"]

from _lib import (DELTA, active_center, cursor, objects, stamp,
                  unexplained, would_win)


def _covered_by_others(objs, ctr, extra_shift):
    """除自己以外，谁的理想形状盖住 ctr —— extra_shift 是「当前物件已经挪了 d」的那张表。"""
    out = set()
    for c2, (k2, _col2, l2) in objs.items():
        if c2 == ctr:
            continue
        cc = extra_shift.get(c2, c2)
        if ctr in stamp(k2, cc, l2):
            out.add(c2)
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if unexplained(prev):
        return "NA"
    d = DELTA.get(action.split()[0] if action else "")
    if d is None:
        return "NA"                                  # ACTION5 换人，另一条概念的地盘
    if would_win(prev, d) is not False:
        return "NA"
    objs = objects(prev)
    a = active_center(prev)
    if a is None:
        return "NA"
    q = (a[0] + d[0], a[1] + d[1])
    shift = {a: q}                                   # 走完这一步之后当前物件在哪
    said = False
    for ctr, (kind, _col, _L) in objs.items():
        if ctr == a or kind == "plus":
            continue
        if ctr in stamp(kind, ctr, _L):
            continue                                 # 中心本来就属于形状：不是这一条问的事
        if q == ctr or cursor(prev) == ctr:
            continue                                 # 光标压过来了
        if _covered_by_others(objs, ctr, {}) or _covered_by_others(objs, ctr, shift):
            continue                                 # 前后任一帧有别人的形状盖着：不由它做主
        said = True
        if prev[ctr[0]][ctr[1]] != nxt[ctr[0]][ctr[1]]:
            return "FALSE"
    return "TRUE" if said else "NA"


def apply(prev, action, ctx=None):
    """它敢生成的格子：那些「没人碰」的中心，照抄 prev 的颜色。"""
    d = DELTA.get(action.split()[0] if action else "")
    if d is None or unexplained(prev):
        return None
    if would_win(prev, d) is not False:
        return None
    objs = objects(prev)
    a = active_center(prev)
    if a is None:
        return None
    q = (a[0] + d[0], a[1] + d[1])
    shift = {a: q}
    out = {}
    for ctr, (kind, _col, L) in objs.items():
        if ctr == a or kind == "plus" or ctr in stamp(kind, ctr, L):
            continue
        if q == ctr or cursor(prev) == ctr:
            continue
        if _covered_by_others(objs, ctr, {}) or _covered_by_others(objs, ctr, shift):
            continue
        out[ctr] = prev[ctr[0]][ctr[1]]
    return out or None
