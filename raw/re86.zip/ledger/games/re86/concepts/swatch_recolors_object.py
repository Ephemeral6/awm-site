"""物件的任意一格碰到某个色块整个框的那一片（含色 2 的框边）时，整个物件立刻变成那个色块的颜色；一格都没碰到就不变色。

变的是**整个物件**，不是碰到的那几格：第 151 步十字最上面的臂尖伸进 (8,30) 的色块，
下一帧整个十字（含另外三条臂和中心）从 6 变成 12。也不需要中心进框——臂尖够了。
色块的颜色本身不变（家具，见 `furniture_restores`），所以这条只说物件那一边。

「离开之后保持」不在这一条里：那由「没碰到就不变色」这后半句逐步覆盖——
第 153 步十字整体退出色块，仍是 12，就是这后半句在那一步判 TRUE。

v3 把「4×4 色块本体」放宽成「6×6 区域」，因为 358921c2e7214b07 打死了窄的那个说法：
那一步十字的臂尖只落在色 12 那个框的**边**上（框行 4-9 列 28-33，臂尖在 (8,33)），
离里面的 4×4（行 5-8 列 29-32）还差一列，世界照样把整个十字从 6 染成了 12。
全语料关内平移 271 条重新对了一遍账：碰到 6×6 区域的 7 条无一例外以「颜色 = 该框的色块色」收场
（其中 2 条本来就是那个色），碰了框而不变色的 0 条，碰都没碰的 264 条一条都没变色。
所以不是断言写反了，是**触发区域画小了**——改的是 `_lib.swatch_hit` 的区域，断言一个字没动。

读法：`swatch_hit(prev, 平移后的格集)` 问这一步落到哪个色块区域上；落到两个不同色块上返回 None（没实测过），
那时这一条返回 NA。空心中心（斜叉/菱形的中心不算它的格子）正好落进区域而形状本身没碰到的情形，
也返回 NA：没实测过，不知道算不算碰到。

被打过一次（step 179）：一条斜臂正好压在某个色 2 框的角上，`_boxes` 的老读法要四个角齐全，
于是**整个框读不出来** —— 而那个物件下一步恰恰走进这个框的色块里、当场从色 14 变成色 9。
`swatch_hit` 说「没碰到色块」，这一条就要求它别变色，判 FALSE。断言没错，是读法被自己的臂蒙住了眼睛；
改的是 `_lib._boxes`（边格看不见要有解释：被谁盖着），这条只补一条依据。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1~4；换关、当前物件读不出来、平移后中心出盘、"
         "nxt 里找不到中心落在新位置的物件、同时压到两个色块区域、"
         "或只有空心中心落进区域（形状没碰到）时返回 NA")
NOTE = ("v4：框的边长不是常数，所以「区域」不再写死 6×6，改成从色块内部往外扩一圈（`_lib.box_area`）。"
        "由来：新一关的框比先前小一圈，写死 6 的读法在那里一个框都读不出来，"
        "于是那几片区域整块变成「认不出的格子」，而 `_regions` 也跟着一片区域都不返回——"
        "这一条在那一关会对所有平移都说「没碰到色块，不该变色」，说得斩钉截铁而毫无依据。"
        "断言一个字没动，改的仍是区域的边界画在哪（这是第三次了，见下）。\n"
        "v3：358921c2e7214b07 打死了「碰 4×4 本体才染色」——只碰到色 2 的框边也染。"
        "两次挨打都不在断言上：一次是框读不出来（v1），一次是触发区域画小了（v2），"
        "改的都是 `_lib`。教训：一条「碰到 X 就 Y」的规律，容易错的从来不是 Y，是 X 的边界画在哪。\n"
        "v1 的反例出在 _lib 的框读法上，不在断言上；改词汇后同一条转移判 TRUE。")
EVIDENCE = ["09ba05cf3fc786e9", "2dc75d436479db0f", "82090cd05ceb4b7f",
            "64d1523fa62d16b6", "358921c2e7214b07"]

from _lib import (DELTA, active_center, box_area, objects, on_board, stamp,
                  swatch_hit, swatches)


def _regions(g):
    """每个读得出颜色的色块，它整个框那一片格集 —— 触发染色的那一片。

    v4：框的边长不是常数（`_lib.BOX_SIZES`），所以区域从色块内部反推（`box_area`），不按 6×6 写死。
    """
    return [box_area(inner) for inner in swatches(g)]


def _hollow_only(prev, q, cells):
    """空心中心落进色块区域、而形状本身一格都没碰到 —— 这一类没实测过。"""
    if q in cells:
        return False
    return any(q in area for area in _regions(prev))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    key = next((k for k in DELTA if action.startswith(k)), None)
    if key is None:
        return "NA"
    d = DELTA[key]
    ctr = active_center(prev)
    if ctr is None:
        return "NA"
    objs = objects(prev)
    if ctr not in objs:
        return "NA"
    kind, col, L = objs[ctr]
    q = (ctr[0] + d[0], ctr[1] + d[1])
    if not on_board(prev, {q}):
        return "NA"
    cells = stamp(kind, q, L)
    if _hollow_only(prev, q, cells):
        return "NA"
    hit = swatch_hit(prev, cells)
    if hit is None and any(cells & area for area in _regions(prev)):
        return "NA"                          # 同时压到两个色块区域：没实测过
    after = objects(nxt)
    if q not in after:
        return "NA"                          # 走完之后物件读不出来（帧不动一类），这条闭嘴
    got = after[q][1]
    want = hit if hit is not None else col
    return "TRUE" if got == want else "FALSE"
