"""平移之后，当前物件新中心那一格显示的是形状序里最上面的那个的颜色；当前物件自己在最上面时露出光标色。

由来：第 91 步斜叉右移到 (48,33)、第 97 步它上移到 (39,42)，两处落点都被菱形的轮廓压着，
那一格实测都不是色 0；同一批里没被压着的另外十四步一律显示色 0。所以光标贴在当前物件那一层，
不在最上层——这与 cursor_layer 是同一件事，只是那一条靠颜色号排图层，同色多物件的关里颜色分不出高下。

第 946 步把「被压着 → 不露头」这一刀打断了：菱形左移到 (30,36)，落点压在斜叉的臂上，
那一格实测是色 0 ——菱形连同贴着它的光标一起盖在斜叉上面。在那以前动的一直是排在下面的那个，
所以「被压着」这一刀能解释全部六次；换成排在上面的那个去动，同一刀当场说错。
上下由**形状**定，与谁在动无关：全语料七类局面排出 diamond > ex > plus（见 `_lib.kind_above`）。
"""
LEVEL = "L6"
SCOPE = ("只看平移动作 ACTION1~4；ACTION5 归 a5_cycle_order / cursor_layer；"
         "换关返回 NA；一颜色一物件读得出来的关返回 NA（那是 cursor_layer 靠 ZORDER 排的地盘）；"
         "prev 里读不出当前物件、新中心出盘、新中心落在 unexplained 的格上（盘上有我认不出的东西，"
         "遮挡表就不全）、这一步该过关（整帧要换）、或压着落点的那些形状彼此排不出上下返回 NA")
NOTE = ("v3：v2 的判据是「被别的物件压着就显示压着它的那个的颜色，没被压着就显示光标色」——"
        "把「谁在上面」等同于「谁不在动」。第 946 步是反例：动的那个排在上面，光标照样露头。"
        "改成按形状序判（`_lib.kind_above`，只放直接量到的对，菱形对直加号没量过就返回 None）。"
        "生成器与断言现在共用 `_lib.cursor_cell_color` 一处判据：那一格该显示什么、判不判得出来，"
        "只在那里答一次——上一次同类事故正是两处各判一次然后分岔。"
        "v4：断言与生成器一字未动，补的是脚下那张形状序表里缺的一对。菱形对直加号原来没直接量过，"
        "于是这一对的重叠格全册弃权、路线每碰一次断一批。押了一句「若次序传递，重叠格该显示菱形的色」，"
        "走一步去看：2 格重叠全部显示菱形的色。这一次直接读数写进 `_lib.KIND_ABOVE`，新 tid 记进 EVIDENCE。"
        "同一个办法随后又量了空心矩形对直加号（矩形在上），也写进表。\n"
        "v5：再补一对 rect 压 cross。这一对是**表按名字分格**逼出来的：同一件十字撞挡块变形之后"
        "从 plus 变成 cross，rect 压 plus 那一对当场不认它，光标格弃权、批次切成单步。"
        "押了一句「这一步走完新光标那一格显示矩形的色 11、不显示光标色 0」，走一步去看："
        "整张盘一格色 0 都没有，新包围盒中心那一格是色 11。颜色序里 11 压 9 早已量过，"
        "两把尺在这一格上一致。**形状序的格子按 kind 的名字分，而世界会给同一件东西换名字**——"
        "变形不只换形状，它还把这件东西挪进了次序表的另一格。\n"
        "v6：断言的主张一字未动，改的是脚下那两把尺怎么接。原来问上下只问形状序，"
        "而形状序对**同形状**的一对返回「压不过」——那是这把尺分不出来，不是排在下面。"
        "终局卡上两个十字重叠，光标那一格因此被判成被压住、画成了对方的色，实测是光标色。"
        "现在改成 `_lib.pair_above`：形状序说不出就换颜色序，颜色序里这一帧直接量到的优先"
        "（`frame_above`），当前物件这一步碰色块改了色就把它的上下关系搬到新色上（`recolor_order`，"
        "那句话另立为概念 `recolor_keeps_zorder`）。查哪张表由 `_lib.moved_zx` 一处决定，"
        "生成器和这条概念都问它——上一次同类事故正是两处各判一次然后分岔。\n"
        "v2：`assert_` 原来拿**当前物件自己的**颜色去比被压的那一格，而同一文件的 `apply` 说该显示"
        "**遮挡物的**颜色——两者只在「压人的和被压的同色」时碰巧一致，而催生这条概念的两条 tid 恰好都出自"
        "全场一色的关，所以这处自相矛盾在语料里一次都没被撞出来（外部审查指出）。"
        "另：v1 还捎带断言「全盘没色 0 时当前物件就是那个唯一被压的」，那句测的其实是 `_lib.active_center` "
        "兜底逻辑稳不稳，与「被压的格该显示什么颜色」是两件事，已拆去 active_center_when_hidden。")
EVIDENCE = ["977d5fa4fcc7b8a2", "0ce649625cee8c21", "20bff4bc443e06a1",
            "42d623bc5954afc6", "0d73fa057eaafb05", "7e31d73675b65ed6"]

from _lib import (DELTA, active_center, bbox_center, cursor_cell_color, moved_zx,
                  objects, on_board, shapes, unexplained, would_win)


def _target(prev, action):
    """这一步光标要落到哪一格、那时的物件表、以及该用的上下对；说不清返回 (None, None, None, None)。"""
    d = DELTA.get(action.split()[0] if action else "")
    if d is None:
        return None, None, None, None
    if shapes(prev):
        return None, None, None, None                # 颜色能排图层的关，交给 cursor_layer
    a = active_center(prev)
    if a is None:
        return None, None, None, None
    objs = objects(prev)
    if a not in objs:
        return None, None, None, None
    k, col, L = objs[a]
    c0 = bbox_center(k, a, L)                        # 光标贴的是包围盒中心，未必是形状中心
    q = (c0[0] + d[0], c0[1] + d[1])
    if not on_board(prev, {q}) or q in unexplained(prev):
        return None, None, None, None
    if would_win(prev, d) is not False:
        return None, None, None, None                # 过关会换整帧，也不敢说读不出来的情形
    zx, _new_col = moved_zx(prev, k, (a[0] + d[0], a[1] + d[1]), L, col)
    if zx is None:
        return None, None, None, None                # 压到两个色块：那一帧它是什么色都说不准
    return a, objs, q, zx


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, objs, q, zx = _target(prev, action)
    if q is None:
        return "NA"
    want = cursor_cell_color(prev, objs, a, q, zx)
    if want is None:
        return "NA"                                  # 压着它的排不出上下，不猜
    return "TRUE" if nxt[q[0]][q[1]] == want else "FALSE"


def apply(prev, action, ctx=None):
    """只说新光标那一格。"""
    a, objs, q, zx = _target(prev, action)
    if q is None:
        return None
    want = cursor_cell_color(prev, objs, a, q, zx)
    return None if want is None else {q: want}
