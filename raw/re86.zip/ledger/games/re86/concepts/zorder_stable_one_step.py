"""两件物件的上下关系在一步之内不变：上一帧的重叠格说 a 盖着 b，这一帧的重叠格就不会反过来说 b 盖着 a。

图层是**物件自己的属性**，不是颜色的属性——这条说的是它一步之内不翻。
为什么要单独说这一句：生成器画重叠格时要知道谁在上，原来只有一张跨关攒出来的颜色表 `ABOVE`。
全语料 1088 张去重帧两两重叠数下来，16 个无序颜色对里有 2 对**两个方向都有证据**
（(6,10) 33 格对 48 格，(8,10) 12 格对 2 格），每个方向的证据各自成簇、坐标互不重叠。
颜色不是稳定的键：物件碰到色块会整件改色（见 `swatch_recolors_object`），
同一个颜色号在两关里未必是同一件东西。于是读法改成**这一帧直接量**（`_lib.frame_above`），
而「量到的这个次序下一帧还算数」正是生成器暗地里靠着的那句话——它就是这一条。

判法：`frame_above(prev)` 与 `frame_above(nxt)` 各是这一帧直接量到的有向对集合；
取两边都量到的那些无序对，方向一致判 TRUE，任一对翻向判 FALSE，没有共同的对判 NA。
`frame_above` 本身对「同一帧里不同格给出相反方向」的对整对丢掉，所以这里比的都是这一帧内部自洽的读数。

由来：全语料 1169 条转移预跑一遍——开口 320 条全 TRUE，0 条反例，849 条弃权（两帧没有共同的重叠对）。
"""
LEVEL = "L7"
SCOPE = ("换关（ctx.level_prev != level_next）返回 NA；"
         "prev 与 nxt 没有共同的可判定重叠颜色对时返回 NA。"
         "只说方向翻没翻，不说次序是什么、也不说次序从哪来")
NOTE = ""
EVIDENCE = ["5124d1c439fa39bf", "df7ce94b33fb7b16", "53c1390b193653c6",
            "edb1ffea31ba606d", "a758b35329088118"]

from _lib import frame_above


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a = frame_above(prev)
    b = frame_above(nxt)
    common = [p for p in a if p in b or (p[1], p[0]) in b]
    if not common:
        return "NA"
    for p in common:
        if (p[1], p[0]) in b:
            return "FALSE"
    return "TRUE"
