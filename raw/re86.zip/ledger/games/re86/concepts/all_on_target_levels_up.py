"""所有环心都被物件盖住、且每个环心都被**与它同色**的物件盖住时，关卡号 +1。

判据的读法（`_lib.would_win`）：环心 = 3×3 色 4 环里的那一格；「盖住」= 它落在某个物件的理想形状上，
这一半**遮挡免疫**；颜色那一半只在**六个环心的归属色都还露着**时才问得出来——
环心一旦被盖住，那一格显示的是盖它的颜色，归属色不再出现在帧里，而实测同色盖住与错色盖住的环
连环框和 5×5 邻域都一模一样（没有可见凭据）。所以这一条只在「盘上还没有环被盖住」那一类局面上开口，
其余一律 NA：不是懒，是这一帧真的没有那个信息。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION1~4；`would_win` 返回 None（六环里有任何一个的归属色读不出来，"
         "包括「早先就被盖住」这种）或为假时返回 NA "
         "—— 为假那一半分给 `no_levelup_unless_aligned`（几何没盖满）和 "
         "`wrong_color_cover_no_levelup`（这一步新盖住的环色不对）")
NOTE = ("v2：判据从「每个物件都停在自己环心决定的落点上」改成「每个环心都被盖住」，"
        "理由同 no_levelup_unless_aligned：归属色会被臂遮挡掉，几何覆盖不会。"
        "v3：被 e41df90118bdf4c1 打了——六个环心全被几何盖住、分组也分对了，却没过关，"
        "因为两个物件的颜色都不等于环的归属色。改的是词（`would_win` 加上「新盖住的环心必须同色」）。"
        "v4：又被 5887452af303dcfa 打了，而这次是同一个错误的第二层："
        "v3 只核**这一步新盖住**的环，理由是别的环归属色读不出来——可「读不出来」被当成了「不用管」。"
        "那一步新盖住的两个环确实同色，六环也确实盖满，于是 v3 判过关；实际没过关，"
        "因为另外三个环早先就被错色物件盖着，而那件事帧里没有凭据。"
        "教训：读不出来的条件不能悄悄当成满足，`would_win` 现在要求六个环的归属色**全部**可读，"
        "否则返回 None、这一条返回 NA。代价是它开口的局面少了很多（N 会掉）；"
        "换来的是它说的话是真的。规划器要用的那份归属色由调用方从开关帧读来，走 `owners=` 参数，"
        "那是计划的输入，不是这一条的主张。"
        "前三关物件色恰好等于归属色，所以这条概念在那三关是恒真的，S=1.000 一路满分，量的却是一个巧合。")
EVIDENCE = ["40b8606076657fe9", "e41df90118bdf4c1", "5887452af303dcfa"]

from _lib import DELTA, would_win


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    key = next((k for k in DELTA if action.startswith(k)), None)
    if key is None:
        return "NA"
    w = would_win(prev, DELTA[key])
    if w is None or not w:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
