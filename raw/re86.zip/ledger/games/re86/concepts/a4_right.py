"""ACTION4 要么让光标（当前十字中心）右移恰好 CELL 格、行不变，要么整帧不动。

v3：换成和 a1/a3 同一道门——这一步不许撞上挡块。实测三步：当前物件右移会压到挡块，
结果光标既没停住也没右移 CELL，而是斜着挪了一格多（(-1,2)、(1,1)、(-1,2)）——
空心矩形撞挡块时整个包围盒换形状，光标跟着包围盒中心走（归 blocked_rect_trades 管）。
`will_block` 读不出当前物件时不加这道门 —— 那是读法的沉默，不是世界说了什么。

v2 那道门（unexplained 非空就弃权）留着，但它已经不是承重的那一根：
它当初能盖住这三条反例，靠的是识别器认不出挡块那一片、于是整关闭嘴。
识别器学会看挡块之后残料清零，借来的沉默当场蒸发，反例原样回来。
教训：**用读法的沉默当 scope，等于把概念的有效期押在自己的近视上**；
读法一变好，概念就当场垮，而且垮在你以为早就处理过的地方。
真正的门要用世界里的条件写（这里是「会不会压到挡块」），它不会因为看得更清楚而失效。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION4；换关返回 NA；光标读不出来（色0 不唯一）返回 NA；"
         "当前物件右移 CELL 后的理想形状会压到挡块（will_block 非空）时返回 NA "
         "—— 那一步物件不整体平移；"
         "prev 或 next 上有识别器解释不掉的格子（unexplained 非空）返回 NA —— "
         "那时当前物件是谁读不出来，而这条主张说的正是当前物件的中心")
NOTE = ("v3：三条老反例被 v2 的 unexplained 门盖住，识别器把挡块认成地形之后残料清零，它们原样回来。"
        "改成 will_block 门（和 a1/a3 一致）才是按世界的条件说话。"
        "v2 的门保留，但只当作和生成器同口径的那一道，不再指望它拦挡块。")
EVIDENCE = ["13ec64782c5d9f6b",
            "a2be021b53100620", "a6a958a355b9a3ad", "6f472b2e12b8cfaf"]

from _lib import CELL, cursor, translate_apply, DELTA, unexplained, will_block


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION4"):
        return "NA"
    if will_block(prev, DELTA["ACTION4"]):
        return "NA"
    if unexplained(prev) or unexplained(nxt):
        return "NA"
    a, b = cursor(prev), cursor(nxt)
    if a is None or b is None:
        return "NA"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (0, CELL) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION4"):
        return None
    if will_block(prev, DELTA["ACTION4"]):
        return None
    return translate_apply(prev, DELTA["ACTION4"])
