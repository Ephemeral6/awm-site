"""空心矩形撞上挡块那一步：迎面那条边一格不动，背面那条边朝动作方向推进 CELL，
垂直方向的边长补上 CELL，总格数不变。

所以沿动作方向的边长缩 CELL、垂直方向的边长涨 CELL，两者之和是不变量（这一关是 38）。
涨出来的 CELL 加在哪一头，由「新包围盒的中心离旧中心最近」定——和「光标 = 包围盒中心」是同一条：
光标挪得越少越好。实测三步向右撞：19x19 → 22x16 → 25x13 → 28x10，格子数一直是 72，
右边一直钉在同一列上，左边每步推进 3，高度轮流往上、往下、往上长——正是「中心挪得最少」选出来的那一头。

这和十字的形变律不是一回事：十字撞挡块时包围盒纹丝不动（见 blocked_deforms）。

**换不动就不换**：迎面那条边缩 CELL 之后短边小于 CELL+1 时，剩下的已经不是一个空心矩形
（4 → 1，只剩一条线），这一步世界整帧不动。那种局面归 `rect_trade_needs_room` 管，这里返回 NA。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1~4；换关返回 NA；"
         "will_block 是空集（不撞）或 None（读不出当前物件）都返回 NA；"
         "变形前后的当前物件认不出来返回 NA；"
         "当前物件前后不都是矩形类（square/rect）时返回 NA —— 十字归 blocked_deforms 管；"
         "**换出来的新短边 < CELL+1 时返回 NA** —— 那一步世界整帧不动，归 rect_trade_needs_room 管")
NOTE = ("v3：第 1987 步打了它——世界**整帧一格没动**，而生成器画了一次形变、说错 31 格。"
        "断言当时没报反例，因为它开头有一行 `if prev == nxt: return NA`："
        "「整帧不动」是这个世界真实的一种结局，被写成了弃权，于是这条概念**恰好在它会错的地方闭嘴**，"
        "而生成器照说不误。这一版做了两件事：\n"
        "  1. 删掉那行弃权。撞挡块而世界没动，从此判 FALSE（这一步该由新的分界条件先 NA 掉；"
        "     分界条件之外还冻住，就是这条概念错了，该被打）。\n"
        "  2. 加上分界：`predict_bbox` 算出的新短边 < CELL+1 就返回 NA / 不生成。\n"
        "分界是从盘上量出来的，不是从结论倒推的（方法册要求弃权条件在不知道结论时就能算）："
        "全语料 will_block 为真的 67 条里，变了的 66 条形变**后**短边全 ≥ 4（4/7/10/13/16/22），"
        "没动的那 1 条形变后短边是 1。形变**前**的短边分不开两堆（4 在两边都出现），"
        "所以载重的是**形变后**那个数。\n"
        "v2：补上生成器（`_lib.deform_apply`），断言未动。`predict_bbox` 本来就把新包围盒算死了，"
        "空心矩形又由包围盒完全确定，所以这条概念一直有能力生成整片格子，只是没写。\n"
        "向右撞实测三步，向下撞实测一步（第 6 关那次 13x13 → 10x16，格数 48 不变，"
        "迎面的下边一格没动，左边外扩 3，与这条推出去的写法逐格吻合）；"
        "向左、向上仍然一次都没撞过，是按同一条几何推出去的。"
        "它们哪个错了都会在这里判 FALSE。"
        "square 也算在内：它是四边等长的 rect，读法里 square 只是排在前面先挑走了平局。")
EVIDENCE = ["a2be021b53100620", "a6a958a355b9a3ad", "6f472b2e12b8cfaf", "f47557b364685585",
            "4ceb26ea66013f2e"]

from _lib import CELL, DELTA, active_center, bbox, deform_apply, objects, will_block

RECTLIKE = ("square", "rect")
MIN_SIDE = CELL + 1        # 短边小于它就不再是一个空心矩形（只剩一条线）


def _has_room(bb, d):
    """换出来的新包围盒还够不够当一个空心矩形。只看 prev 和动作，不看结果。"""
    r0, r1, c0, c1 = predict_bbox(bb, d)
    return min(r1 - r0 + 1, c1 - c0 + 1) >= MIN_SIDE



def _grow(lo, hi, n):
    """把区间 [lo, hi] 加长 n，加在离旧中心最近的那一头。"""
    m = (lo + hi + 1) // 2
    a, b = (lo - n, hi), (lo, hi + n)
    ca, cb = (a[0] + a[1] + 1) // 2, (b[0] + b[1] + 1) // 2
    return a if abs(ca - m) <= abs(cb - m) else b


def predict_bbox(bb, d):
    """撞挡块之后的包围盒 (上, 下, 左, 右)。"""
    r0, r1, c0, c1 = bb
    dr, dc = d
    if dc:
        c0, c1 = (c0 + dc, c1) if dc > 0 else (c0, c1 + dc)
        r0, r1 = _grow(r0, r1, abs(dc))
    else:
        r0, r1 = (r0 + dr, r1) if dr > 0 else (r0, r1 + dr)
        c0, c1 = _grow(c0, c1, abs(dr))
    return (r0, r1, c0, c1)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DELTA.get(action.split()[0])
    if d is None:
        return "NA"
    if not will_block(prev, d):
        return "NA"
    a = active_center(prev)
    if a is None:
        return "NA"
    ka, _cola, La = objects(prev)[a]
    if ka not in RECTLIKE:
        return "NA"
    bba = bbox(ka, a, La)
    if not _has_room(bba, d):
        return "NA"                      # 换不动，归 rect_trade_needs_room 管
    b = active_center(nxt)
    if b is None:
        return "NA"
    kb, _colb, Lb = objects(nxt)[b]
    if kb not in RECTLIKE:
        return "NA"
    return "TRUE" if predict_bbox(bba, d) == bbox(kb, b, Lb) else "FALSE"


def apply(prev, action, ctx=None):
    """`predict_bbox` 已经把新包围盒算死，空心矩形由包围盒完全确定，所以整片格子都生成得出。

    新形状一律记成 rect（四边等长的 square 只是 rect 的一个特例，印子一模一样）。
    """
    d = DELTA.get(action.split()[0])
    if d is None:
        return None
    if not will_block(prev, d):
        return None
    a = active_center(prev)
    if a is None:
        return None
    ka, _col, La = objects(prev)[a]
    if ka not in RECTLIKE:
        return None
    bba = bbox(ka, a, La)
    if not _has_room(bba, d):
        return None                      # 换不动，这一步归 rect_trade_needs_room 说
    r0, r1, c0, c1 = predict_bbox(bba, d)
    ctr2 = ((r0 + r1 + 1) // 2, (c0 + c1 + 1) // 2)
    L2 = (ctr2[0] - r0, r1 - ctr2[0], ctr2[1] - c0, c1 - ctr2[1])
    return deform_apply(prev, "rect", ctr2, L2)
