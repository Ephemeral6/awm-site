"""ACTION2 要么让光标（当前十字中心）下移恰好 CELL 格、列不变，要么整帧不动。

v2：补上和 a1/a3/a4 同一道门——这一步不许撞上挡块。
**这道门在本局语料里一次都没响过**：全语料关内、帧真的变了的 ACTION2 共 97 步，
`will_block` 全是空集，向下撞挡块的情形至今没走进去过。
所以它不是被反例逼出来的，是按同一条机制推出去的：另外三个方向都实测过
「撞上挡块那一步物件不整体平移」（a1/a3 是光标不动，a4 是光标斜着挪），
没有理由认为向下会是例外。它哪天响了而世界照旧平移，这一改就是错的。
`will_block` 读不出当前物件时不加这道门 —— 那是读法的沉默，不是世界说了什么。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION2；换关返回 NA；光标读不出来（色0 不唯一）返回 NA；"
         "当前物件下移 CELL 后的理想形状会压到挡块（will_block 非空）时返回 NA "
         "—— 那一步物件不整体平移")
NOTE = ("v2：这道门至今零次触发，是从另外三个方向的实测推出来的，不是本方向的读数。"
        "写下来是为了让它可判错——真出现向下撞挡块而世界照旧平移的那一步，"
        "这条概念会静静地弃权而不是判 TRUE，那才是需要被看见的错。"
        "v3：断言一字未动，改的是它脚下的词汇。终局卡上这条 apply 说错过一格："
        "当前物件的中心正压在一个环心上，而形状的 stamp 不含自己的中心、光标又贴在中心上，"
        "`top_color` 于是查不出遮挡，把环心此刻显示的光标色当成归属色画了出去。"
        "物件挪开后那一格露出的是真归属色。断言全绿——它只问中心动了没有，不问生成器画了什么。"
        "改在 `_lib.ring_owner` / `_lib.top_color`：两处判「归属色读不读得出来」并成一处，读不出来就闭嘴。"
        "新 tid 记进 EVIDENCE。\n"
        "v4：断言又是一字未动，改的还是脚下的词汇。这条 apply 说错一格："
        "另一件物件正压在**某个不动物件的中心格**上，那个中心不在自己的形状里，"
        "所以「它填没填本色」只能看帧，而帧上显示的是压在上面那位的颜色——读不出来。"
        "生成器把它当成没填，让开之后画了底色，真帧露的是本色。"
        "改在 `_lib.ambiguous_centers`：它原来只认「同色的臂压在中心上」这一类歧义，"
        "现在按「有没有人盖着」写，异色盖住同样弃权。新 tid 记进 EVIDENCE。")
EVIDENCE = ["694c7083a193c96a", "dce0b2fe0ea41524", "ff149f0c2535307b",
            "acc53c23318c444d"]

from _lib import CELL, cursor, translate_apply, DELTA, will_block


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION2"):
        return "NA"
    if will_block(prev, DELTA["ACTION2"]):
        return "NA"
    a, b = cursor(prev), cursor(nxt)
    if a is None or b is None:
        return "NA"
    if prev == nxt:
        return "TRUE"
    return "TRUE" if (b[0] - a[0], b[1] - a[1]) == (CELL, 0) else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION2"):
        return None
    if will_block(prev, DELTA["ACTION2"]):
        return None
    return translate_apply(prev, DELTA["ACTION2"])
