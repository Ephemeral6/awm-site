"""HUD 上「已花掉」的格数每步只增 0 或 1，从不减少。"""
LEVEL = "L4"
SCOPE = "所有动作；换关返回 NA（换关时 HUD 可能重置）"
NOTE = "cost_a2_free v1 被打脸后剩下的、还站得住的那部分：预算是单调计数器，只是扣的时机未知。"
EVIDENCE = ["53c0f3e343567397", "628c6e26212353f5", "fa50b4bc5b6b71cf"]

from _lib import spent


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    return "TRUE" if (spent(nxt) - spent(prev)) in (0, 1) else "FALSE"
