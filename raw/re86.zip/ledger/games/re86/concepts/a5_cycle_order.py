"""ACTION5 把光标交给按次序排在当前物件后面的那个物件：主键是形状（square → rect → plus → hline → ex → diamond → cross），同形状时按颜色号从小到大，排到末尾绕回第一个。

次序的键是**形状**，不是颜色、不是位置。形状一关之内不变，所以这条只看当前这一帧就判得动，
不需要「起手帧定死」那一层，也不用把有色块的关挡在门外。

由来：全语料 41 次读得出来的 ACTION5，这张表判 41/41，零弃权；
只按形状（同形状就说不出来）判 35/41 剩 6 条弃权，颜色升序 24 对 4 错，颜色降序 17 对 11 错。

**同形状那一档还分不开两个候选**：颜色号升序和「列升序、同列再行升序」在这 41 次里给出完全相同的次序
（41/41 对 41/41）——要分开它们，得等到一对同形状的物件「颜色小的那个反而在右边」。
所以这一条两个都算，两者一致时才说话，不一致返回 NA：分不开的时候替世界挑一个，就是把巧合写成规律。

**没定过先后的形状对**见 `UNORDERED`。它们只在盘上有**三种以上**形状时才要紧：
两种形状时不论谁排前面，环都是同一个循环（[A组,B组] 和 [B组,A组] 首尾相接后一模一样），
先后不影响预测；三种起才分得出来。所以弃权也只弃在三种以上那一档。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5；换关返回 NA；认不出当前物件、认不出 next 帧的当前物件、"
         "盘上物件少于 2 个返回 NA；"
         "**出现表里没有的形状、盘上三种以上形状且其中一对没定过先后（UNORDERED）、"
         "同形状那一档的两个候选键给出不同次序、"
         "或 `unexplained` 非空（盘上有认不出的物件，物件表少一项）返回 NA**")
NOTE = ("v11：同形状不再整片弃权，形状表补上 square/rect/cross。\n"
        "起因是这一关三个物件里有两个同形状、而且三种形状全在表外，于是这一条整关一句话不说，"
        "ACTION5 那一步的链式预测每次都断在这里。补第二键（同形状按颜色号升序）之后全语料 41/41 零弃权。\n"
        "同时修掉两处真错，它们在四下对称的形状上一次都看不出来：\n"
        "  · `assert_` 拿 `cursor(nxt)` 去和物件中心比 —— 光标贴的是**包围盒**中心，"
        "不对称的 cross 两者差着好几行，这样比会把对的判成错的；改用 `active_center(nxt)`。\n"
        "  · `apply` 把光标画在新当前物件的中心上，同样该画在包围盒中心。\n"
        "教训：一条概念的断言和它的生成器可以各自引用同一个词的两种意思而长期不出事——"
        "只要世界还没给出能把两种意思分开的位形。\n"
        "v10：apply 在「光标让开的那一格」上把斜叉和菱形并成一类整片弃权（v5 立的），"
        "而这两种其实不是一回事：分开数，非当前、没被压住的菱形中心全语料 170/170 露下面那一层，"
        "斜叉却是本色 89 次、底色 71 次。菱形那一半于是可以说话了，"
        "依据是新概念 `diamond_center_hollow`（共用判据 `_lib.center_never_filled`）。"
        "斜叉照旧弃权——帧里读得出来的键一个都分不开它的两堆。"
        "教训：一条弃权规则盖着两个不同的东西时，先把它们分开数一遍再决定弃不弃。\n"
        "v9：5612e7811feb19ff 让「按颜色号升序」落空——第 4 关起手第一步 ACTION5，"
        "光标从 ex 色11 切到了 diamond 色14，升序该给 plus 色12。"
        "这一条当时**没被判 FALSE**，因为 v7/v8 把有色块的关整片挡在门外了；"
        "落空的是押注，不是断言。回头把四种候选键放在全语料上对一遍，"
        "「形状名倒序」28/28，颜色升序 25/28、中心升序 23/28——真正的键是形状。"
        "于是 v7 辛苦立起来的「次序由起手帧定死、单条转移读不出来」整个不需要了："
        "形状一关之内不变，所以它一直就在这一帧里。"
        "教训：一个读法被迫引入「这一帧里读不出来」的 epicycle 时，先怀疑主键选错了——"
        "会飘的量（颜色、位置）当主键，才需要拿起手帧去锚它；不飘的量不需要锚。\n"
        "v8：`unexplained` 非空时也返回 NA。\n"
        "v7：2bf2f39a6a982303 打死了「同色时按当前帧的中心行列序」。当时以为次序**一关之内固定**，"
        "由起手帧定，物件移动或染色都不改它——全语料 24 次 ACTION5，"
        "「关内固定」24/24 对，「当前帧行列序升」23/24，「当前帧列行序降」16/24。"
        "（v9 推翻了这个解释：那 24 次里「形状优先级」同样 24/24，而它不需要起手帧。）"
        "而『关内固定』这句话单条转移根本判不动：概念手上只有 (prev, action, nxt, ctx)，没有起手帧。"
        "所以不是把断言改对，是把 scope 缩到**读得出来**的那一片。"
        "教训：一个恰好对了 23 次的读法，可能一次都没说中真正的机制——"
        "起手时次序和位置序重合，是布局给的巧合，不是规律。\n"
        "v5：apply 在「光标让开的那一格」上说错过一格（第 143 步，说底色 5、实际本色 10）。"
        "起因是个真读不出来的东西：斜叉、菱形的中心不在理想形状里，可**有的实心、有的空心**"
        "（全语料 8 次让开：底色 7 次、本色 1 次），而光标从被选中那一刻起就压在中心上，"
        "prev 里那一格显示的是光标色，填着本色还是露着底色分不出来。"
        "所以这一格改成弃权：中心不在理想形状里、又没有别的物件盖着它时，不主张它。\n"
        "v4：同色多物件的关里 `where` 按颜色收拢，三个物件挤进同一个键，图层信息在那一步就丢了——"
        "生成器于是无条件把新中心画成光标。落点被别的物件压着时那是错的（见 cursor_hidden_by_object），"
        "改成再单独问一次 `occluders_at`。\n"
        "v3：改用按中心索引的 `objects()`；「循环长度 = 盘上物件个数」实测为 3。\n"
        "v2：apply 原来无条件把新中心主张成光标色，第 52 步说错一格——那一格被更上层的物件压着。\n"
        "v1：从 a5_switch 里分出来的：那条只说「落到某个别的物件中心」，这条说是哪一个。")
EVIDENCE = ["12bc05726790eed2", "c54129756df0e208", "09f89fd0822be128",
            "5a602e8d58d3ec98", "c19037f2789fd3e9", "74284ebfef00d086",
            "e073e2aa20ddc935", "2bf2f39a6a982303", "5612e7811feb19ff",
            "4b997c984b661392", "bb46c3b15a3b24ae", "bd44a2306eaa8189"]

from _lib import (CURSOR, active_center, bbox_center, center_never_filled,
                  objects, occluders_at, stamp, top_color, unexplained)

PRIORITY = ["square", "rect", "plus", "hline", "ex", "diamond", "cross"]

# 先后**没被观测确定过**的形状对。判据不是「有没有同场」而是「先后分不分得出来」：
# 两个物件（或两种形状）的环，正反两种排法首尾相接后是同一个循环，所以两种形状同场定不了先后；
# 要三种形状同场，或者两种形状三个物件，才把顺序逼出来。
# 已经逼出来的：plus<ex<diamond、hline<ex<diamond（三种同场）、square<cross、rect<cross（两种三个）。
UNORDERED = [
    {"cross", "diamond"}, {"cross", "ex"}, {"cross", "hline"}, {"cross", "plus"},
    {"diamond", "rect"}, {"diamond", "square"}, {"ex", "rect"}, {"ex", "square"},
    {"hline", "plus"}, {"hline", "rect"}, {"hline", "square"},
    {"plus", "rect"}, {"plus", "square"}, {"rect", "square"},
]


def _order(g):
    """盘上物件的中心，按次序排好；排不出这个次序时返回 None。

    排不出来有四种：`unexplained` 非空（盘上有 `objects` 认不出的东西，物件表本身就少了一项，
    次序无从排起——实测：一个物件停在另一个同色物件的中心上时，只读得出大的那个）；
    出现 PRIORITY 里没有的形状；盘上**三种以上**形状而其中一对的先后从没被观测确定过
    （两种形状时环唯一，先后不影响，所以不弃）；
    或者同形状那一档的两个候选键给出不同次序——它们在现有语料里从没分开过，
    真分开的那一天，就是该拿证据挑一个的那一天，不是现在猜的那一天。
    """
    if unexplained(g):
        return None
    objs = objects(g)
    kinds = {k for k, _col, _l in objs.values()}
    if any(k not in PRIORITY for k in kinds):
        return None
    if len(kinds) >= 3 and any(pair <= kinds for pair in UNORDERED):
        return None
    by_color = sorted(objs, key=lambda c: (PRIORITY.index(objs[c][0]), objs[c][1]))
    by_pos = sorted(objs, key=lambda c: (PRIORITY.index(objs[c][0]), c[1], c[0]))
    return by_color if by_color == by_pos else None


def _next_center(g, ctr):
    order = _order(g)
    if order is None or len(order) < 2 or ctr not in order:
        return None
    return order[(order.index(ctr) + 1) % len(order)]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    a = active_center(prev)
    if a is None:
        return "NA"
    q = _next_center(prev, a)
    if q is None:
        return "NA"
    b = active_center(nxt)
    if b is None:
        return "NA"                          # 认不出 next 帧的当前物件，这一步交给 cursor_layer 判
    return "TRUE" if b == q else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION5"):
        return None
    a = active_center(prev)
    if a is None:
        return None
    q = _next_center(prev, a)
    if q is None:
        return None
    objs = objects(prev)
    kind_a, _col_a, l_a = objs[a]
    kind_q, new_col, l_q = objs[q]
    cur_old = bbox_center(kind_a, a, l_a)     # 光标贴包围盒中心，不是形状中心
    cur_new = bbox_center(kind_q, q, l_q)
    where = {}
    for c2, (k2, col2, l2) in objs.items():
        st = stamp(k2, c2, l2)
        if c2 == q:
            st = st | {cur_new}              # 光标贴在**新的**当前物件那一层
        where[col2] = where.get(col2, set()) | st
    out = {}
    old_readable = (cur_old in stamp(kind_a, a, l_a)
                    or bool(occluders_at(objs, a, cur_old))
                    or center_never_filled(kind_a))  # 菱形：中心从不填本色，露的是下面那一层
    cells = [cur_new] if not old_readable else [cur_old, cur_new]
    for cell in cells:
        v = top_color(prev, cell, where)
        if v is not None:
            out[cell] = v
    if out.get(cur_new) == new_col and not occluders_at(objs, q, cur_new):
        out[cur_new] = CURSOR                # 新当前物件在这一格是最上面的 → 光标露得出来
    return out or None
