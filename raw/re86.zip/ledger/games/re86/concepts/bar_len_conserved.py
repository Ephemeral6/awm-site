"""十字两条杠的长度一步之内一格不变；读到的短值只出自遮挡——杠尖外面那一格伸出盘外，或压在别的物件身上。

`objects` 的臂长是从**画出来的**格子量的，所以它量到的是真长度的下界：
杠尖伸出盘外那截不画（盘边是裁，见 edge_clips_arm），被别的物件盖住那截也不画（换人时才露出来）。
这条把两件事合成一句能判错的话：长度变了，短的那一帧的那条杠就必须有遮挡；没有遮挡还变了，这条就死。

它是 `blocked_deforms`「两条杠各自的长度一格不变」的另一面：那一条说世界不改长度，
这一条说**读法**会把长度读小，而且只在这两种遮挡下读小。
两条合起来，规划器才敢拿一帧读到的形状当搜索的起点——读短一格，够不着的环就永远够不着。
"""
LEVEL = "L7"
SCOPE = ("只看 ACTION1~4：ACTION5 换主语，前后不是同一件东西，比长度没有意义；"
         "换关返回 NA；前后两帧的当前物件读不出来、或不都是十字类（plus/cross）返回 NA；"
         "**某条杠的长度是补出来的那一帧，这条杠不比**（`_lib.unmeasured_arms`：臂尖那一格"
         "没露出本色 = 这条臂没量到底），另一条杠照比；"
         "只管十字。矩形类也会被读残（同一件空心方框的边被别人压掉一段，"
         "会被认成两条横线），但那要另立一条，这条一句都不管它")
NOTE = ("v3：竖杠整条滑到另一个物件的一条边下面，那一帧竖杠的下半截一格都露不出来，"
        "`_cross_L` 按「不对称要有证据」把它回补成了最长那条臂的长度——于是读到的竖杠比上一帧长了 3，"
        "这条当场判 FALSE。世界没有加长任何东西：那三格在遮挡下面，长 12 还是长 15 这一帧根本读不出来。"
        "错的是拿一个**推出来的值**当读数去比。判据补在 `_lib` 里一处（`unmeasured_arms`），"
        "blocked_deforms 用的是同一处——可读性判据分两处写、然后分岔，这局已经吃过一次。\n"
        "另记一条还没解决的：回补出来的臂长同样会被生成器画出去。这一帧没打脸"
        "（多出来的三格正好压在遮挡下面），杠一旦从遮挡下面滑出来就会打脸。等它打。\n"
        "v1 的 scope 末句写的是「矩形类的边长读短没实测到过」，那句话是错的："
        "语料里存在同一件空心方框被认成两条横线、下一步又并回一件的帧。"
        "断言本身没动（非十字类照旧返回 NA），改的是那句已经被证伪的话。")
EVIDENCE = ["0f5e6599c3965018", "d42a28f46e2c5f41", "5739c38153f14010", "a8019168932b64bc"]

from _lib import HUD_ROW, active_center, objects, stamp, unmeasured_arms

CROSSLIKE = ("plus", "cross")
DIRS = ((-1, 0), (1, 0), (0, -1), (0, 1))          # 上 下 左 右，与 L 的四臂同序


def occluders(g, objs, ctr):
    """除了 ctr 这一件，别的物件占的格子。"""
    out = set()
    for k2, (kk2, _c2, l2) in objs.items():
        if k2 != ctr:
            out |= stamp(kk2, k2, l2)
    return out


def arm_hidden(g, objs, ctr, arms):
    """四条臂各自「尖再往外一格看不见」——出盘或被别的物件盖着。顺序同 DIRS。"""
    others = occluders(g, objs, ctr)
    HI, WI = min(len(g), HUD_ROW), len(g[0])
    out = []
    for (dr, dc), a in zip(DIRS, arms):
        p = (ctr[0] + dr * (a + 1), ctr[1] + dc * (a + 1))
        off = not (0 <= p[0] < HI and 0 <= p[1] < WI)
        out.append(off or p in others)
    return out


def bar_lens(g):
    """当前十字的 (竖杠长, 横杠长, 竖杠可能读短, 横杠可能读短, 竖杠是补出来的, 横杠是补出来的)；
    读不出来或不是十字返回 None。"""
    ctr = active_center(g)
    if ctr is None:
        return None
    objs = objects(g)
    if ctr not in objs:
        return None
    kind, _col, L = objs[ctr]
    if kind not in CROSSLIKE:
        return None
    arms = (L, L, L, L) if isinstance(L, int) else L
    hid = arm_hidden(g, objs, ctr, arms)
    um = unmeasured_arms(g, ctr) or set()
    return (arms[0] + arms[1] + 1, arms[2] + arms[3] + 1,
            hid[0] or hid[1], hid[2] or hid[3],
            bool({0, 1} & um), bool({2, 3} & um))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action.split()[0] not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "NA"
    a, b = bar_lens(prev), bar_lens(nxt)
    if a is None or b is None:
        return "NA"
    for i in (0, 1):
        if a[i] == b[i]:
            continue
        if a[4 + i] or b[4 + i]:
            continue                       # 这一帧这条杠的长度是补出来的，不是读数，不拿它比
        if not (a[2 + i] if a[i] < b[i] else b[2 + i]):
            return "FALSE"                 # 长度变了，短的那一帧却没有遮挡可以解释
    return "TRUE"
