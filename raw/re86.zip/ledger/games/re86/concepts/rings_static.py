"""圆环只会被十字遮挡、不会自己搬家：色 4 格子集合的每一处变化都落在十字走过的格子上（十字在环之上）。"""
LEVEL = "L0"
SCOPE = "所有动作；换关返回 NA（新关可以换一套环）；十字读不出来返回 NA"
NOTE = ("v1 声称「色4 格子一步都不动」，被 fa50b4bc5b6b71cf（第 8 步：竖臂压到环的边框上，"
        "(16,15)(18,15) 由色4 变色11）打脸。改断言：环没搬家，是被盖住了 —— "
        "所以要求「变化处 ⊆ 十字新旧位置的并」，这同时预测「臂离开后环会回来」。")
EVIDENCE = ["53c0f3e343567397", "53284daa3bbbd062", "fa50b4bc5b6b71cf"]

from _lib import cross_cells, rings


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a, b = cross_cells(prev), cross_cells(nxt)
    if a is None or b is None:
        return "NA"
    changed = rings(prev) ^ rings(nxt)
    return "TRUE" if changed <= (a | b) else "FALSE"
