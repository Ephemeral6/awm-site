"""自由平移不改变当前物件的尺寸参数 L：ACTION1~4 前后，被操控的那个物件形状参数一模一样。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1~4（ACTION5 换的是另一个物件，两个物件尺寸本来就不同）；"
         "换关返回 NA；尺寸参数读不出来返回 NA；"
         "这一步理想形状会压到挡块（will_block 非空）时返回 NA —— 那一步不是平移，是形变，"
         "归 blocked_deforms / blocked_rect_trades 管")
NOTE = ("v2：补上 will_block 那道闸，并把话从「十字」放宽到「当前物件」——代码从来就是对任何形状读 L 的，"
        "只有 docstring 还写着十字，这是主张和实现不一致，不是新主张。\n"
        "v1 死在三步「空心矩形撞挡块」上：矩形被挡住时原地改形，尺寸参数当然变。"
        "它此前一直判 TRUE 只是因为读法在那三帧上认不出当前物件是谁（地形被误拟合成物件，"
        "把当前物件的推断搅黄了），这条概念于是一直返回 NA。"
        "教训：读法一沉默，架在读法上的概念就跟着沉默，而沉默在记分卡上和「没被推翻」长得一模一样——"
        "S 高要连 NA 率一起看。")
EVIDENCE = ["97023537ba8dfc15", "c0508d69c7edd185",
            "a2be021b53100620", "a6a958a355b9a3ad", "6f472b2e12b8cfaf"]

from _lib import DELTA, arm_len, will_block


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not any(action.startswith(f"ACTION{k}") for k in (1, 2, 3, 4)):
        return "NA"
    d = DELTA.get(action.split()[0])
    if d is not None and will_block(prev, d):
        return "NA"
    a, b = arm_len(prev), arm_len(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if a == b else "FALSE"
