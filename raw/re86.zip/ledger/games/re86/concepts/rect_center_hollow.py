"""空心矩形和正方形的中心那一格从不填本色：它显示的是下面那一层（底色或家具），不是物件自己的颜色。

和菱形那一条（`diamond_center_hollow`）说的是同一件事，只是换了形状——之所以分开写而不是合并，
是因为「中心不在理想形状里」这个画法约定在**不同形状上不一定对应同一个世界事实**：
斜叉的中心同样不在 `stamp` 里，可它本色 89 次、底色 71 次，两堆分不开。
所以每种形状都要自己被量一遍才算数，一条概念只说被量过的那些。

由来：全语料 583 条转移的两侧帧里，符合条件（不是当前物件、中心没被别的物件盖住）的
空心矩形中心读到 85 次、正方形 76 次，**161 次全是下面那一层，一次本色都没有**。

用处在生成器那边：ACTION5 把光标从一个空心矩形身上交出去时，让开的那一格露什么，
`a5_cycle_order` 原先只能弃权。弃权的代价不只是少赚一格——链式假帧会把那一格留成光标色，
下一步整张盘上就有了两个光标，读法认不出当前物件，全册跟着闭嘴。
"""
LEVEL = "L0"                                   # 清点：盘上有什么、每种东西长什么样
SCOPE = ("只看 next 帧里的 rect 与 square；`unexplained` 非空返回 NA（物件表本身就不可信）；"
         "盘上没有矩形类返回 NA；某个矩形是当前物件（中心压着光标）、中心被别的物件的格子盖住、"
         "或那一格该显示什么在这一帧读不出来（`top_color` 弃权）→ 跳过这一个；一个都不剩返回 NA。"
         "**十字不在 scope 内**：它的中心是交点，本来就在理想形状里，没什么可问的；"
         "**斜叉也不在**，它那两堆到今天还分不开（见 diamond_center_hollow）")
NOTE = ""
EVIDENCE = [
    "1de488f0ddd5596a",   # next 帧里色11 rect 心(14,32) 露底色 5
    "9a2111fe03ff64bb",   # next 帧里色11 square 心(48,15) 露底色 5
    "0f5e6599c3965018",   # 第 591 步 关6：色9 rect 心(21,48) 非当前，中心露底色
]

from _lib import active_center, objects, occluders_at, stamp, top_color, unexplained

HOLLOW = ("rect", "square")


def _check(g):
    """这一帧里读得出来的矩形类中心，逐个核。返回 (判得动几个, 说错几个)。"""
    if unexplained(g):
        return 0, 0
    objs = objects(g)
    act = active_center(g)
    where = {}
    for c2, (k2, col2, l2) in objs.items():
        where[col2] = where.get(col2, set()) | stamp(k2, c2, l2)
    ok = bad = 0
    for c, (kind, _col, _ln) in objs.items():
        if kind not in HOLLOW or c == act:
            continue
        if occluders_at(objs, c, c):
            continue
        v = top_color(g, c, where)
        if v is None:
            continue                            # 这一帧说不准该露什么：不判
        ok += 1
        if g[c[0]][c[1]] != v:
            bad += 1
    return ok, bad


def assert_(prev, action, nxt, ctx=None):
    ok, bad = _check(nxt)
    if not ok:
        return "NA"
    return "FALSE" if bad else "TRUE"
