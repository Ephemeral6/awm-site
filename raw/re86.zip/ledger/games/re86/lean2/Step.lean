/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    推（上下左右）  没撞挡块 → translate；撞了：cross → blockedCross，box → blockedBox，
                   ex / diamond → na（语料里 0 次，模型不描述）；然后 recolor
    换人            active := cycle
    走完            isGoal 成立 → won，否则 ok

RESET 不在这里：它不是这一关里的一步（语料里 4 次全是整局重开），见 `notmodel/reset_restarts`。
-/

import Rule.Move.Translate
import Rule.Move.BlockedCross
import Rule.Move.BlockedBox
import Rule.Move.Recolor
import Rule.Switch.Cycle
import Rule.Goal.LevelUp

namespace Game

def push (b : Board) (p : Piece) (a : Act) : Option Piece :=
  if !hitsBlock b p a.delta.1 a.delta.2 then some (translate p a)
  else match p.kind with
    | .cross => some (blockedCross b p a)
    | .box   => some (blockedBox p a)
    | _      => none

def next (b : Board) (s : World) (a : Act) : Option World :=
  match a with
  | .switch => some { s with active := cycle s }
  | _ => match s.pieces[s.active]? with
    | none   => none
    | some p => (push b p a).map (fun q => { s with pieces := s.pieces.set s.active (recolor b q) })

def step (b : Board) (s : World) (a : Act) : Res :=
  match next b s a with
  | none    => .na
  | some s' => if isGoal b s' then .won s' else .ok s'

end Game
