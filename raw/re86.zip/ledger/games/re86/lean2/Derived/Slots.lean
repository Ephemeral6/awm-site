/-
# Derived/Slots —— 每件东西待在自己的格位上（推论，不是定义）

Python 那边有两条规则在这里**掉成了推论**：

    move/others_stay   推一下时，没被选中的那几件不变
    board/layers       图层次序一步之内不翻

这边 `World.pieces` 的**下标就是图层**，而 `next` 只用 `List.set` 改被选中那一格、
或者只改 `active`——所以两句话都是架构推出来的，不必另写定义。它们在这里是定理，
**会失败**：哪天 `next` 改成重排列表、或者顺手动了别的格，这两条当场编不过。
-/

import Obj.World
import Step

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game

/-- **move/others_stay**：推一下（非 ACTION5），件数不变，没被选中的每一格原样。 -/
theorem others_stay (b : Board) (s s' : World) (a : Act) (ha : a ≠ .switch)
    (h : next b s a = some s') :
    s'.pieces.length = s.pieces.length ∧ ∀ i, i ≠ s.active → s'.pieces[i]? = s.pieces[i]? := by
  cases a with
  | switch => exact absurd rfl ha
  | up | down | left | right =>
    simp only [next] at h
    split at h
    · simp at h
    · obtain ⟨q, _, hq⟩ := Option.map_eq_some_iff.mp h
      subst hq
      refine ⟨List.length_set, ?_⟩
      intro i hi
      exact List.getElem?_set_ne (Ne.symm hi)

/-- **board/layers**：任何一步之后，件数不变，没被选中的每一格原样（ACTION5 连被选中的那格也不动）。
    下标就是图层，所以这就是「图层不翻」。 -/
theorem layers_kept (b : Board) (s s' : World) (a : Act) (h : next b s a = some s') :
    s'.pieces.length = s.pieces.length ∧ ∀ i, i ≠ s.active → s'.pieces[i]? = s.pieces[i]? := by
  by_cases ha : a = .switch
  · subst ha
    simp only [next, Option.some.injEq] at h
    subst h
    exact ⟨rfl, fun _ _ => rfl⟩
  · exact others_stay b s s' a ha h

/-- **switch/cycle 的那一半**：ACTION5 一件东西都不改。 -/
theorem switch_keeps_pieces (b : Board) (s s' : World) (h : next b s .switch = some s') :
    s'.pieces = s.pieces := by
  simp only [next, Option.some.injEq] at h
  subst h
  rfl

#print axioms others_stay
#print axioms layers_kept
#print axioms switch_keeps_pieces
