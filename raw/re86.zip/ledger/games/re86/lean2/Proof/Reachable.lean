/-
# Proof/Reachable —— 这个**局面**做不做得了

    Winnable   b s  :=  ∃ as, 照着走中途赢过
    Unsolvable b s  :=  ∀ as, 照着走从没赢过

## 一句必须写在明处的削弱

`step` 有一支 `na`（模型说不出下一帧：斜叉 / 菱形撞挡块——语料里 0 次）。`everWon` 碰到它返回 `false`。
所以 `Unsolvable` 的准确意思是：**不经过模型说不出话的那一支，就赢不了**。
`∀ as` 这个形状一个字都看不出这一点，所以写在这里、写在页面上。
RESET 不在动作里：「重来一次回到哪」不进模型（`notmodel/reset_restarts`）。

## 骨架

`unsolvable_of_invariant`：找一个每一步都保持、且与「赢」矛盾的性质 Φ，挂上去就是不可做。
全文唯一做归纳的地方，与盘面大小、动作串长短都无关，不枚举任何状态。
这一局语料里八关全部走通，所以**这一局没有用到它**——没有哪一关需要证「走不通」。
-/

import Obj.World
import Step

namespace Game

def everWon (b : Board) : World → List Act → Bool
  | _, [] => false
  | s, a :: as => match step b s a with
    | .won _ => true
    | .ok s' => everWon b s' as
    | .na => false

def Winnable (b : Board) (s : World) : Prop := ∃ as : List Act, everWon b s as = true
def Unsolvable (b : Board) (s : World) : Prop := ∀ as : List Act, everWon b s as = false

end Game

-- 定理放在顶层（`open Game`）：装置的 `ledger/lean_check.py` 用**不带命名空间的名字**
-- 打 `#print axioms`，放在命名空间里它会报 unknown constant（装置事故，见 UNIFY-REPORT）。
open Game

theorem not_both (b : Board) (s : World) : Winnable b s → Unsolvable b s → False := by
  intro ⟨as, h⟩ hu
  rw [hu as] at h
  exact Bool.false_ne_true h

theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ s s' a, P s → step b s a = .ok s' → P s')
    (hwin : ∀ s s' a, P s → step b s a ≠ .won s') :
    ∀ s, P s → Unsolvable b s := by
  intro s hp as
  induction as generalizing s with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hs : step b s a with
    | won s' => exact absurd hs (hwin s s' a hp)
    | ok s' => exact ih s' (hkeep s s' a hp hs)
    | na => rfl

#print axioms not_both
#print axioms unsolvable_of_invariant
