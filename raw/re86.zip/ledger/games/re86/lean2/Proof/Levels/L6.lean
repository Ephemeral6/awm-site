/-
# Proof/Levels/L6 —— 第 6 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L6_play      开局到过关前一步，102 步（seq 1865 起）。模型只拿开局那一帧，后面全是自己算的
    L6_trace     沿着这条真实走法，模型每一帧都和观测对上
    L6_acts      同一串动作再加上过关那一脚，共 103 步
    L6_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L6_start` 取 `Replay.starts`（整关口径：开局补边 {'1/2': 1}；图层次序 整关重叠拼出）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L6_board : Board := Replay.boardOf 6
def L6_start : World := Replay.startOf 6
def L6_play : List (Act × Seen) := Replay.playFrom 1865 102
def L6_acts : List Act := Replay.actsFrom 1865 103

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 102 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 3 件东西。 -/
theorem L6_play_len : L6_play.length = 102 ∧ (L6_start : World).pieces.length = 3 := by
  decide +kernel
/-- 见证共 103 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L6_acts_len : L6_acts.length = 103 ∧ isGoal L6_board L6_start = false := by
  decide +kernel

#eval match firstSplit L6_board L6_start L6_play 0 with
  | none   => "L6 一处都没分家（" ++ toString L6_play.length ++ " 步）"
  | some i => "L6 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L6_trace : traceOk L6_board (L6_start : World) L6_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L6_winnable : Winnable L6_board (L6_start : World) := ⟨L6_acts, by decide +kernel⟩

#print axioms L6_play_len
#print axioms L6_acts_len
#print axioms L6_trace
#print axioms L6_winnable
