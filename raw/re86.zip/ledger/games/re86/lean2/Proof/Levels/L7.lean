/-
# Proof/Levels/L7 —— 第 7 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L7_play      开局到过关前一步，185 步（seq 1968 起）。模型只拿开局那一帧，后面全是自己算的
    L7_trace     沿着这条真实走法，模型每一帧都和观测对上
    L7_acts      同一串动作再加上过关那一脚，共 186 步
    L7_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L7_start` 取 `Replay.starts`（整关口径：开局补边 {'1/h': True}；图层次序 整关重叠拼出）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L7_board : Board := Replay.boardOf 7
def L7_start : World := Replay.startOf 7
def L7_play : List (Act × Seen) := Replay.playFrom 1968 185
def L7_acts : List Act := Replay.actsFrom 1968 186

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 185 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 2 件东西。 -/
theorem L7_play_len : L7_play.length = 185 ∧ (L7_start : World).pieces.length = 2 := by
  decide +kernel
/-- 见证共 186 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L7_acts_len : L7_acts.length = 186 ∧ isGoal L7_board L7_start = false := by
  decide +kernel

#eval match firstSplit L7_board L7_start L7_play 0 with
  | none   => "L7 一处都没分家（" ++ toString L7_play.length ++ " 步）"
  | some i => "L7 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L7_trace : traceOk L7_board (L7_start : World) L7_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L7_winnable : Winnable L7_board (L7_start : World) := ⟨L7_acts, by decide +kernel⟩

#print axioms L7_play_len
#print axioms L7_acts_len
#print axioms L7_trace
#print axioms L7_winnable
