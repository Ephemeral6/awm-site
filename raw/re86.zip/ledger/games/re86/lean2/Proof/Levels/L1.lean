/-
# Proof/Levels/L1 —— 第 1 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L1_play      开局到过关前一步，35 步（seq 1627 起）。模型只拿开局那一帧，后面全是自己算的
    L1_trace     沿着这条真实走法，模型每一帧都和观测对上
    L1_acts      同一串动作再加上过关那一脚，共 36 步
    L1_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L1_start` 取 `Replay.starts`（整关口径：开局补边 无；图层次序 整关重叠拼出）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L1_board : Board := Replay.boardOf 1
def L1_start : World := Replay.startOf 1
def L1_play : List (Act × Seen) := Replay.playFrom 1627 35
def L1_acts : List Act := Replay.actsFrom 1627 36

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 35 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 3 件东西。 -/
theorem L1_play_len : L1_play.length = 35 ∧ (L1_start : World).pieces.length = 3 := by
  decide +kernel
/-- 见证共 36 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L1_acts_len : L1_acts.length = 36 ∧ isGoal L1_board L1_start = false := by
  decide +kernel

#eval match firstSplit L1_board L1_start L1_play 0 with
  | none   => "L1 一处都没分家（" ++ toString L1_play.length ++ " 步）"
  | some i => "L1 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L1_trace : traceOk L1_board (L1_start : World) L1_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L1_winnable : Winnable L1_board (L1_start : World) := ⟨L1_acts, by decide +kernel⟩

#print axioms L1_play_len
#print axioms L1_acts_len
#print axioms L1_trace
#print axioms L1_winnable
