/-
# Proof/Levels/L4 —— 第 4 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L4_play      开局到过关前一步，64 步（seq 1754 起）。模型只拿开局那一帧，后面全是自己算的
    L4_trace     沿着这条真实走法，模型每一帧都和观测对上
    L4_acts      同一串动作再加上过关那一脚，共 65 步
    L4_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L4_start` 取 `Replay.starts`（整关口径：开局补边 {'0/3': 5}；图层次序 整关重叠拼出）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L4_board : Board := Replay.boardOf 4
def L4_start : World := Replay.startOf 4
def L4_play : List (Act × Seen) := Replay.playFrom 1754 64
def L4_acts : List Act := Replay.actsFrom 1754 65

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 64 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 3 件东西。 -/
theorem L4_play_len : L4_play.length = 64 ∧ (L4_start : World).pieces.length = 3 := by
  decide +kernel
/-- 见证共 65 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L4_acts_len : L4_acts.length = 65 ∧ isGoal L4_board L4_start = false := by
  decide +kernel

#eval match firstSplit L4_board L4_start L4_play 0 with
  | none   => "L4 一处都没分家（" ++ toString L4_play.length ++ " 步）"
  | some i => "L4 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L4_trace : traceOk L4_board (L4_start : World) L4_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L4_winnable : Winnable L4_board (L4_start : World) := ⟨L4_acts, by decide +kernel⟩

#print axioms L4_play_len
#print axioms L4_acts_len
#print axioms L4_trace
#print axioms L4_winnable
