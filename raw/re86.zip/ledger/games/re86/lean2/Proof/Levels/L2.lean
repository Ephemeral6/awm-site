/-
# Proof/Levels/L2 —— 第 2 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L2_play      开局到过关前一步，46 步（seq 1663 起）。模型只拿开局那一帧，后面全是自己算的
    L2_trace     沿着这条真实走法，模型每一帧都和观测对上
    L2_acts      同一串动作再加上过关那一脚，共 47 步
    L2_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L2_start` 取 `Replay.starts`（整关口径：开局补边 无；图层次序 帧上一对都读不到（三件同色），按本关 ACTION5 前后继 [(0, 2), (2, 1)] 倒推（相容的循环 1 个）——**这一位是拟合**）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L2_board : Board := Replay.boardOf 2
def L2_start : World := Replay.startOf 2
def L2_play : List (Act × Seen) := Replay.playFrom 1663 46
def L2_acts : List Act := Replay.actsFrom 1663 47

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 46 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 3 件东西。 -/
theorem L2_play_len : L2_play.length = 46 ∧ (L2_start : World).pieces.length = 3 := by
  decide +kernel
/-- 见证共 47 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L2_acts_len : L2_acts.length = 47 ∧ isGoal L2_board L2_start = false := by
  decide +kernel

#eval match firstSplit L2_board L2_start L2_play 0 with
  | none   => "L2 一处都没分家（" ++ toString L2_play.length ++ " 步）"
  | some i => "L2 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L2_trace : traceOk L2_board (L2_start : World) L2_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L2_winnable : Winnable L2_board (L2_start : World) := ⟨L2_acts, by decide +kernel⟩

#print axioms L2_play_len
#print axioms L2_acts_len
#print axioms L2_trace
#print axioms L2_winnable
