/-
# Proof/Levels/L0 —— 第 0 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L0_play      开局到过关前一步，19 步（seq 1607 起）。模型只拿开局那一帧，后面全是自己算的
    L0_trace     沿着这条真实走法，模型每一帧都和观测对上
    L0_acts      同一串动作再加上过关那一脚，共 20 步
    L0_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L0_start` 取 `Replay.starts`（整关口径：开局补边 无；图层次序 2 件：两种次序轮法相同，取解析顺序）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L0_board : Board := Replay.boardOf 0
def L0_start : World := Replay.startOf 0
def L0_play : List (Act × Seen) := Replay.playFrom 1607 19
def L0_acts : List Act := Replay.actsFrom 1607 20

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 19 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 2 件东西。 -/
theorem L0_play_len : L0_play.length = 19 ∧ (L0_start : World).pieces.length = 2 := by
  decide +kernel
/-- 见证共 20 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L0_acts_len : L0_acts.length = 20 ∧ isGoal L0_board L0_start = false := by
  decide +kernel

#eval match firstSplit L0_board L0_start L0_play 0 with
  | none   => "L0 一处都没分家（" ++ toString L0_play.length ++ " 步）"
  | some i => "L0 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L0_trace : traceOk L0_board (L0_start : World) L0_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L0_winnable : Winnable L0_board (L0_start : World) := ⟨L0_acts, by decide +kernel⟩

#print axioms L0_play_len
#print axioms L0_acts_len
#print axioms L0_trace
#print axioms L0_winnable
