/-
# Proof/Levels/L5 —— 第 5 关（**自动生成**，讲解在 export_levels.py 的模板里）

    L5_play      开局到过关前一步，45 步（seq 1819 起）。模型只拿开局那一帧，后面全是自己算的
    L5_trace     沿着这条真实走法，模型每一帧都和观测对上
    L5_acts      同一串动作再加上过关那一脚，共 46 步
    L5_winnable  这一关走得通——见证就是真人走过的那条路

开局 `L5_start` 取 `Replay.starts`（整关口径：开局补边 {'1/h': True}；图层次序 整关重叠拼出）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Levels

def L5_board : Board := Replay.boardOf 5
def L5_start : World := Replay.startOf 5
def L5_play : List (Act × Seen) := Replay.playFrom 1819 45
def L5_acts : List Act := Replay.actsFrom 1819 46

end Levels
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Levels

set_option maxRecDepth 100000

/-- 切出来的这一段真有 45 步（切歪了是空表，空表让 `_trace` 平凡为真），开局有 2 件东西。 -/
theorem L5_play_len : L5_play.length = 45 ∧ (L5_start : World).pieces.length = 2 := by
  decide +kernel
/-- 见证共 46 步；而且**不是因为一开局就已经赢了**（`_closed_at_start`）。 -/
theorem L5_acts_len : L5_acts.length = 46 ∧ isGoal L5_board L5_start = false := by
  decide +kernel

#eval match firstSplit L5_board L5_start L5_play 0 with
  | none   => "L5 一处都没分家（" ++ toString L5_play.length ++ " 步）"
  | some i => "L5 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差。** 只有开局那一帧是给的，后面全是模型自己算的。 -/
theorem L5_trace : traceOk L5_board (L5_start : World) L5_play = true := by decide +kernel

/-- **这一关走得通。** 见证是那条路再加上过关那一脚。 -/
theorem L5_winnable : Winnable L5_board (L5_start : World) := ⟨L5_acts, by decide +kernel⟩

#print axioms L5_play_len
#print axioms L5_acts_len
#print axioms L5_trace
#print axioms L5_winnable
