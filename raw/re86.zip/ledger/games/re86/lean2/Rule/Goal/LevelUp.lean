/-
# Rule/Goal/LevelUp —— 什么算过关（对应 `rule/goal/level_up.py`）

**赢是一个状态的性质**：每个环心都被一件与环同色的东西盖住。写成状态性质，
「这个局面还能不能赢」才有得问（`Proof/Reachable.lean`）。
斜叉 / 菱形空着的 hub 不算盖住（`mem` 里 hub 只在不空时才算它的格）。
-/

import Obj.World

namespace Game

def isGoal (b : Board) (s : World) : Bool :=
  b.rings.all (fun g => s.pieces.any (fun p => p.mem g.r g.c && p.color == g.owner))

end Game
