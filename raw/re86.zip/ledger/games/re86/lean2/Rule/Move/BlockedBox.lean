/-
# Rule/Move/BlockedBox —— 空心矩形撞挡块：换形状，周长不变（对应 `rule/move/blocked_box.py`）

迎面那条边不动、背面那条边推进 3，垂直方向长 3——**整块加在一头**，
加在让新包围盒中心离旧中心最近的那一头（一样近取下 / 右那一头）；换完短边 < 4 就整件不动。
-/

import Obj.World
import Rule.Move.Translate

namespace Game

def blockedBox (p : Piece) (a : Act) : Piece :=
  let dr := a.delta.1
  let dc := a.delta.2
  let h := p.bottom - p.top + 1
  let w := p.right - p.left + 1
  if dc ≠ 0 then
    let l2 := if dc > 0 then p.left + 3 else p.left
    let r2 := if dc > 0 then p.right else p.right - 3
    let d1 := iabs ((p.top + (p.bottom + 3) + 1) / 2 - p.cr)
    let d2 := iabs (((p.top - 3) + p.bottom + 1) / 2 - p.cr)
    let t2 := if d2 < d1 then p.top - 3 else p.top
    let b2 := if d2 < d1 then p.bottom else p.bottom + 3
    if min (h + 3) (w - 3) < 4 then p
    else { p with top := t2, left := l2, bottom := b2, right := r2,
                  hr := (t2 + b2 + 1) / 2, hc := (l2 + r2 + 1) / 2 }
  else
    let t2 := if dr > 0 then p.top + 3 else p.top
    let b2 := if dr > 0 then p.bottom else p.bottom - 3
    let d1 := iabs ((p.left + (p.right + 3) + 1) / 2 - p.cc)
    let d2 := iabs (((p.left - 3) + p.right + 1) / 2 - p.cc)
    let l2 := if d2 < d1 then p.left - 3 else p.left
    let r2 := if d2 < d1 then p.right else p.right + 3
    if min (h - 3) (w + 3) < 4 then p
    else { p with top := t2, left := l2, bottom := b2, right := r2,
                  hr := (t2 + b2 + 1) / 2, hc := (l2 + r2 + 1) / 2 }

end Game
