/-
# Rule/Move/Recolor —— 推完碰到色块就整件变色（对应 `rule/move/recolor.py`）

「碰到」= 它有一格落进某个色块整个框那一片（含框边）。碰到好几个取最上面那个（同行取左边）——
**这一支是三选一**：语料里 5 次同时碰到两个，全是同一个位形，
「上面那个赢」「颜色号大的赢」「新碰到的赢」拟合得一样好。

「碰没碰到」这里按色块那一片逐格问 `mem`；Python 那一份拿格子集合求交。两份各自独立写，
由逐帧核对对账。
-/

import Obj.World

namespace Game

def Piece.touches (p : Piece) (s : Swatch) : Bool :=
  (List.range s.size.toNat).any (fun i =>
    (List.range s.size.toNat).any (fun j => p.mem (s.top + i) (s.left + j)))

def firstTouched (ss : List Swatch) (p : Piece) : Option Swatch :=
  (ss.filter (fun s => p.touches s)).foldl
    (fun acc s => match acc with
      | none => some s
      | some t => if s.top < t.top || (s.top == t.top && s.left < t.left) then some s else acc)
    none

def recolor (b : Board) (p : Piece) : Piece :=
  match firstTouched b.swatches p with
  | some s => { p with color := s.color }
  | none   => p

end Game
