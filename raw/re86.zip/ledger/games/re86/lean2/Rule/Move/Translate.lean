/-
# Rule/Move/Translate —— 推一下、没撞上挡块：整件平移 3 格（对应 `rule/move/translate.py`）

**定义，不是定理。** 「推一下就平移」是对「推」的定义；把它写成待证的定理等于用它自己证它自己。

论域（`hitsBlock = false`）也在这里：撞上了挡块归 `BlockedCross` / `BlockedBox`，
分发写在 `Step.lean`。
-/

import Obj.World

namespace Game

/-- 平移 (dr, dc) 之后，有没有一格落在挡块上。 -/
def hitsBlock (b : Board) (p : Piece) (dr dc : Int) : Bool :=
  b.blockers.any (fun rc => p.mem (rc.1 - dr) (rc.2 - dc))

/-- 没撞上挡块：整件平移。 -/
def translate (p : Piece) (a : Act) : Piece :=
  p.shift a.delta.1 a.delta.2

end Game
