/-
# Rule/Move/BlockedCross —— 十字撞挡块：两条杠各走各的（对应 `rule/move/blocked_cross.py`）

会压到挡块的那条杠原地不动，另一条平移 3；交点 = 横杠的行 × 竖杠的列。
没有横杠（竖线）或没有竖杠（横线）时，交点只跟着那一条走。
-/

import Obj.World
import Rule.Move.Translate

namespace Game

def blockedCross (b : Board) (p : Piece) (a : Act) : Piece :=
  let dr := a.delta.1
  let dc := a.delta.2
  let hasH := decide (p.left < p.right)
  let hasV := decide (p.top < p.bottom)
  let hb := hasH && b.blockers.any (fun rc =>
    rc.1 - dr == p.hr && decide (p.left ≤ rc.2 - dc) && decide (rc.2 - dc ≤ p.right))
  let vb := hasV && b.blockers.any (fun rc =>
    rc.2 - dc == p.hc && decide (p.top ≤ rc.1 - dr) && decide (rc.1 - dr ≤ p.bottom))
  let rh := if hasH then (if hb then p.hr else p.hr + dr) else (if vb then p.hr else p.hr + dr)
  let l  := if hasH then (if hb then p.left else p.left + dc) else (if vb then p.hc else p.hc + dc)
  let rr := if hasH then (if hb then p.right else p.right + dc) else (if vb then p.hc else p.hc + dc)
  let cv := if hasV then (if vb then p.hc else p.hc + dc) else (if hb then p.hc else p.hc + dc)
  let t  := if hasV then (if vb then p.top else p.top + dr) else (if hb then p.hr else p.hr + dr)
  let bt := if hasV then (if vb then p.bottom else p.bottom + dr) else (if hb then p.hr else p.hr + dr)
  { p with top := min t rh, left := min l cv, bottom := max bt rh, right := max rr cv,
           hr := rh, hc := cv }

end Game
