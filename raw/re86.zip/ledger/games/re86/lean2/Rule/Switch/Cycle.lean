/-
# Rule/Switch/Cycle —— ACTION5：选中换到图层上面一层那件（对应 `rule/switch/cycle.py`）

`World.pieces` 按图层从下往上排，所以「上面一层」就是下标 +1，到顶绕回 0；
包围盒中心在盘外的跳过。东西一件都不改——这一句在这边**表示不出来**：
`cycle` 只返回一个下标。
-/

import Obj.World

namespace Game

def Piece.onBoard (p : Piece) : Bool :=
  decide (0 ≤ p.cr) && decide (p.cr < 63) && decide (0 ≤ p.cc) && decide (p.cc < 64)

def cycle (s : World) : Nat :=
  let n := s.pieces.length
  let cand := (List.range n).map (fun k => (s.active + k + 1) % n)
  (cand.find? (fun j => j != s.active && ((s.pieces[j]?).map Piece.onBoard).getD false)).getD s.active

end Game
