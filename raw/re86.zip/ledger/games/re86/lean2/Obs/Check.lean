/-
# Obs/Check —— 判据层：模型面对一帧观测站不站得住。**0 条定理**，尺子不自证。

## Seen：只装帧上读得出来的

一帧对应的是一组世界（纤维）：某一边读不到底（伸出盘外 / 尽头压在别的东西底下）时，
那一边只知道**下界**。所以 `SeenPiece` 每一边带一位 `k*`（读没读到底），hub 空不空是 `Option`。
**东西的次序读不出来**（下标不是身份），所以按集合比：一一配上才算对。

## 三把尺

    agree       一件预测的东西 vs 一件看到的东西（只在读得出的那几位上比）
    agreesWorld 整个状态 vs 一帧：东西一一配上；光标看得见时，选中那件的包围盒中心就在光标上
    traceOk     从开局起**带着自己算出来的状态**往下走，逐帧比——错一步后面全错，那正是要的
-/

import Step

namespace Game

structure SeenPiece where
  kind   : Kind
  color  : Nat
  top    : Int
  left   : Int
  bottom : Int
  right  : Int
  hr     : Int
  hc     : Int
  kt     : Bool
  kl     : Bool
  kb     : Bool
  kr     : Bool
  hollow : Option Bool
  deriving DecidableEq, Repr

structure Seen where
  pieces : List SeenPiece
  cursor : Option (Int × Int)
  deriving DecidableEq, Repr

/-- 一边：读到底就相等，读不到底就「模型那一边伸得不比它近」。`out` 为真表示往外是变大的那一侧。 -/
def sideOk (known : Bool) (out : Bool) (model obs : Int) : Bool :=
  if known then model == obs
  else if out then decide (obs ≤ model) else decide (model ≤ obs)

def agree (p : Piece) (o : SeenPiece) : Bool :=
  p.kind == o.kind && p.color == o.color &&
  (match o.hollow with
   | some h => p.kind == .cross || p.hollow == h
   | none   => true) &&
  (match p.kind with
   | .ex | .diamond =>
       p.hr == o.hr && p.hc == o.hc &&
       (if o.kt && o.kl && o.kb && o.kr then p.radius == o.hr - o.top
        else decide (o.hr - o.top ≤ p.radius))
   | .cross =>
       (!(decide (o.left < o.right)) || p.hr == o.hr) &&
       (!(decide (o.top < o.bottom)) || p.hc == o.hc) &&
       sideOk o.kt false p.top o.top && sideOk o.kl false p.left o.left &&
       sideOk o.kb true p.bottom o.bottom && sideOk o.kr true p.right o.right
   | .box =>
       sideOk o.kt false p.top o.top && sideOk o.kl false p.left o.left &&
       sideOk o.kb true p.bottom o.bottom && sideOk o.kr true p.right o.right)

/-- 从表里拿掉第一件配得上的。 -/
def takeMatch (p : Piece) : List SeenPiece → Option (List SeenPiece)
  | [] => none
  | o :: os => if agree p o then some os else (takeMatch p os).map (o :: ·)

def matchAll : List Piece → List SeenPiece → Bool
  | [], [] => true
  | p :: ps, os => match takeMatch p os with
    | some rest => matchAll ps rest
    | none => false
  | [], _ :: _ => false

def agreesWorld (s : World) (o : Seen) : Bool :=
  matchAll s.pieces o.pieces &&
  (match o.cursor with
   | none => true
   | some rc => match s.pieces[s.active]? with
     | some p => p.cr == rc.1 && p.cc == rc.2
     | none => false)

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。全对才是 `true`。
    **下一轮喂进去的是模型自己算出来的 `s'`**，不是观测。 -/
def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
      match step b s a with
      | .ok s' => agreesWorld s' o && traceOk b s' rest
      | _      => false

/-- 只给读数用：第一处分家在第几步（`none` = 一处都没分家）。**它是读数不是定理**。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
      match step b s a with
      | .ok s' => if agreesWorld s' o then firstSplit b s' rest (i + 1) else some i
      | _      => some i

/-- 逐条：一条真实转移。`prev` 是**从观测那一帧重新起算**的状态（每步都被拉回正轨）；
    `won` 是现实那一侧这一步过没过关（上游 meta 给的，模型看不到它）。 -/
structure Case where
  row  : Nat
  lvl  : Nat
  prev : World
  act  : Act
  next : Seen
  won  : Bool
  deriving Repr

/-- 三值：`some true` 对上 / `some false` 被这一帧证伪 / `none` 模型这一步说不出话。 -/
def stepJudge (b : Board) (c : Case) : Option Bool :=
  match step b c.prev c.act with
  | .ok s'  => some (!c.won && agreesWorld s' c.next)
  | .won _  => some c.won
  | .na     => none

end Game
