/-
# Obs/Corpus —— 逐条：每一步都从**观测到的那一帧**重新起算（**自动生成**）

用例从 `Replay.steps` 切：第 k 步的前一帧取第 k−1 步的 `full`（读全了的那几帧才有；
每关第一步取整关口径的开局），下一帧取第 k 步的 `seen`；过关那一步是 `won = true` 的用例。
前一帧读不全的那几步**不造用例**——那几步只在每关那一层（`Proof/Levels`）里被核。

三值：`some true` 对上 / `some false` 被这一帧证伪 / `none` 模型这一步说不出话。

## 和 Python 规则层的逐条对账

`pyVerdicts` 是 Python 规则层（`rule/move/*`、`rule/switch/cycle`、`rule/goal/level_up` 的预测，
拿 `derive/fiber.py` 比）在**同一批用例**上的判决。两份各自独立写：Python 用格子集合，
这里用算术。`reconcile` 要求两份逐条相同——**不许靠「它们应该一样」**。
-/

import Obj.World
import Obs.Replay

namespace Game
namespace Corpus

def build : Option World → Nat → List Replay.Step → List Case
  | _, _, [] => []
  | prev, lvl, s :: rest =>
      let p := if s.lvl == lvl then prev else some (Replay.startOf s.lvl)
      let tail := build s.full s.lvl rest
      match p with
      | some w => { row := s.seq, lvl := s.lvl, prev := w, act := s.act, next := s.seen, won := s.won } :: tail
      | none   => tail

def cases : List Case := build none 999 Replay.steps

def pyVerdicts : List (Option Bool) := [some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true, some true]

end Corpus
end Game

-- 定理放在顶层：装置的 lean_check 用不带命名空间的名字打 `#print axioms`
open Game Game.Corpus

set_option maxRecDepth 100000

theorem cases_len : (cases.map (fun c => stepJudge (Replay.boardOf c.lvl) c)).length = 303 := by
  decide +kernel

/-- 逐条：没有一条被证伪（`some false` 的条数是 0）。 -/
theorem no_false :
    ((cases.map (fun c => stepJudge (Replay.boardOf c.lvl) c)).filter (· == some false)).length = 0 := by
  decide +kernel

/-- 对上的条数与说不出话的条数，写成定理（不是 `#eval`）。 -/
theorem n_true :
    ((cases.map (fun c => stepJudge (Replay.boardOf c.lvl) c)).filter (· == some true)).length = 303 := by
  decide +kernel
theorem n_na :
    ((cases.map (fun c => stepJudge (Replay.boardOf c.lvl) c)).filter (· == none)).length = 0 := by
  decide +kernel

/-- **两份现役的判决逐条对账**：Lean 的 `step` 与 Python 的规则层在每一条上都说同一句话。 -/
theorem reconcile : cases.map (fun c => stepJudge (Replay.boardOf c.lvl) c) = pyVerdicts := by
  decide +kernel

#eval "CORPUS cases=" ++ toString cases.length

#print axioms cases_len
#print axioms no_false
#print axioms n_true
#print axioms n_na
#print axioms reconcile
