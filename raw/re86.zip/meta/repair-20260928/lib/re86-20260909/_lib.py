"""re86 的词汇表 —— 每个定义都是假设，不是装置给的事实。

盘面 64×64，底色 BG=5；最后一行 (63) 是 HUD 条，初始 64 格色 15，
每消耗 1 点预算就从最右端起把一格 15 换成色 1。

**物件（shape）**：盘上有若干个可动的对称图形，每个一种颜色。第 1 关实测出三种形状：
    plus     直加号：中心 + 上下左右四条长 L 的臂（**中心算它自己的格子**）
    ex       斜叉：  四条长 L 的对角臂（**不含中心**）
    diamond  菱形轮廓：到中心曼哈顿距离恰好 L 的一圈（**不含中心**）
**全图唯一的色 0 单点（光标）压在「当前被操控的那个物件」的中心上。**
ACTION1/2/3/4 平移当前物件 CELL=3 格（上/下/左/右）；ACTION5 换光标（换操控对象）。

**环**：3×3 的色 4 边框，中心一格是某个物件的颜色 —— 它标记那个颜色的物件该经过哪里。
落点 `targets(g, col)` = 使「该色所有环心都落在该物件格子上」的中心。

读法上的坑（都是实测撞出来的）：
  - 物件会被别的物件遮挡、会被盘边裁掉，所以中心不能用 bbox 中点，要用对称性投票（见 `_fit`）。
  - 斜叉/菱形的中心不与自己的格子相邻，所以「当前物件」不能读光标四邻的颜色，
    只能靠「拟合出来的中心 == 光标」来认。
  - 菱形轮廓的边是斜线，三个环心共线时落点不唯一（第 1 关色 13 就是），此时 targets 返回多个。
"""
from __future__ import annotations

from collections import Counter
from functools import lru_cache

from geo import cells_of  # noqa: F401

CELL = 3               # 实测：一次平移 3 格
PHASE = None           # 未量
DELTA = {              # 实测：各动作一次，各自单独一批
    "ACTION1": (-CELL, 0),
    "ACTION2": (CELL, 0),
    "ACTION3": (0, -CELL),
    "ACTION4": (0, CELL),
}

BG = 5                 # 实测：底色（>3800 格）
HUD_ROW = 63           # 实测：最后一行整行是 HUD
HUD_SPENT = 1          # 实测：HUD 上「已花掉」的格子是色 1
HUD_LEFT = 15          # 实测：HUD 上「还没花」的格子是色 15
CURSOR = 0             # 实测：全图唯一的色 0 单点 = 当前物件的中心
RING_EDGE = 4          # 实测：3×3 环的边框色（中心是某个物件的颜色）

KINDS = ("plus", "ex", "diamond", "square", "hline", "cross", "rect")
# `cross` = 四条臂各自长短的十字，L 是 (上, 下, 左, 右) 四元组。它是 `plus` 的推广：
# 四臂等长时两者印出同一批格子，靠 KINDS 里 plus 在前把平局判给 plus，所以旧读数不动。
# `rect` = 长宽各自长短的空心矩形，L 同样是 (上, 下, 左, 右)；它是 `square` 的推广，同理让 square 先挑。
# 两个都排在最后，是因为它们比谁都能装 —— 只在别的形状都装不下时才该轮到它们。
# 中心那一格取包围盒中心**向上取整**的那一格：边长是偶数时中心落在两格之间，得挑一格当锚。
DIRS4 = ((-1, 0), (1, 0), (0, -1), (0, 1))
ZORDER = (9, 13, 12)   # 旧的全序读法，保留给还在引用它的概念；新代码走 ABOVE / top_of

# 实测过的「谁压谁」，(a, b) 读作「a 压得过 b」。**这是偏序不是全序**：
# 没在这张表里的一对（含它的传递闭包）就是没实测过，`above` 返回 None、`top_of` 弃权。
# 原来写成全序 (9,13,12) 的那一版有个静默的坑：不在表里的颜色一律排到最后，
# 于是「一个已知色 + 一个未知色」会让已知色赢——而实测里色 10 压得过色 12（见 zorder_fixed_order v3）。
# (14, 9) 是押出来的一对：菱形色 14 整件移到与直加号色 9 形状重叠的落点，2 格重叠全部显示色 14。
# (11, 9) 同样是押出来的：直加号色 9 整件移到与空心矩形色 11 形状重叠的落点，那 1 格显示色 11。
# (10, 7) 与 (7, 12) 是**在现成的一帧上直接量的**：同一帧里三件物件两两重叠，
#   色7 与色10 重叠 1 格显示色 10，色7 与色12 重叠 4 格全部显示色 7，
#   同一帧里色10 压色12 那一格也和表里已有的一对一致（三对连起来无环）。
#   量它不用花一步——重叠已经摆在盘上了，缺的只是有没有人去数那几格。
ABOVE = frozenset({(9, 13), (13, 12), (9, 12), (10, 12), (11, 7), (14, 9), (11, 9),
                   (10, 7), (7, 12)})

# **被帧上的直接读数顶掉的对**——两个方向都量到过，所以这一对颜色问不出次序，`above` 一律返回 None。
# 死因留在这里，不从 ABOVE 里删（那等于把打脸的证据抹掉）：留着才看得出表错在哪、错了几对。
# 全语料 1137 张去重帧逐帧算 frame_above，5 对颜色两个方向都直接量到过：
#   (6,10)  6压10 只在第7关 6 帧 / 10压6 只在第3关 19 帧
#   (8,10)  8压10 只在第7关 3 帧 / 10压8 只在第6关 3 帧
#   (9,11)  9压11 只在第0关 1 帧 / 11压9 在第4、5关 40 帧   ← 表里有 (11,9)
#   (10,12) 10压12 在第3、6关 79 帧 / 12压10 只在第7关 6 帧  ← 表里有 (10,12)
#   (8,9)   8压9 在第4、6关 13 帧 / 9压8 **也在第6关** 3 帧
# 前四对每个方向各占各的关：换关整盘重画，同一个颜色号在两关里根本不是同一件东西。
# 第五对在**同一关内**翻了方向，那也解释得通——物件碰色块会整件改色（swatch_recolors_object），
# 改色不改次序（recolor_keeps_zorder），所以同一件东西前后挂着两个颜色号。
# 合起来是一句话：**次序是物件的属性，颜色只是会变的标签**；这张按颜色索引的表是拿标签近似物件，
# 跨关和跨变色必然失效。它还留着，是因为没被顶掉的那几对至今在 1137 帧上一次都没翻过。
ABOVE_VOID = frozenset({frozenset({6, 10}), frozenset({8, 10}), frozenset({9, 11}),
                        frozenset({10, 12}), frozenset({8, 9})})


def above(a, b, extra=frozenset()):
    """a 压不压得过 b。压得过 True，压不过 False，**没实测过 None**。

    `extra` 是**这一帧上直接量到**的对（见 `frame_above`），查它在查 `ABOVE` 之前。
    为什么给它优先：全语料 1088 张去重帧扫下来，两两重叠一共判得出 1051 格、16 个无序对，
    其中 **2 对两个方向都有证据**——(6,10) 是 33 格对 48 格，(8,10) 是 12 格对 2 格，
    而每个方向的证据各自成簇、坐标互不重叠。颜色不是稳定的图层键：物件碰到色块会整件改色，
    同一个颜色号在不同关里未必是同一件东西，这张跨关攒的表于是会把两件东西的次序混成一对。
    这一帧量到的那一格没有这个毛病——它说的就是此刻盘上谁盖着谁。

    `ABOVE_VOID` 里的那几对被帧上的读数顶掉过，表不许再替它们回答；但**这一帧量到的照旧算数**，
    所以 `extra` 查在 void 之前——「这把尺分不出来」不等于「此刻盘上分不出来」。
    """
    if a == b:
        return False
    if (a, b) in extra:
        return True
    if (b, a) in extra:
        return False
    if frozenset({a, b}) in ABOVE_VOID:
        return None
    if (a, b) in ABOVE:
        return True
    if (b, a) in ABOVE:
        return False
    return None


def top_of(cols, extra=frozenset()):
    """一堆颜色叠在同一格上，显示出来的是哪个；偏序定不下来返回 None。"""
    seen = list(dict.fromkeys(cols))
    if not seen:
        return None
    if len(seen) == 1:
        return seen[0]
    win = [a for a in seen if all(above(a, b, extra) for b in seen if b != a)]
    return win[0] if len(win) == 1 else None


# 形状之间的上下序（实测过的对，只放直接量到的，不做传递闭包）。
# 同色多物件的关里颜色分不出高下，只剩形状这一把尺；不同色的关里两把尺量到的地方彼此一致。
# ("cross", "square") 是在现成的一帧上直接数的：十字的两条杠穿过空心方块的四条边，
#   4 格重叠全部画着十字的色；同一批重叠按颜色那把尺也判十字在上，两把尺一致。
KIND_ABOVE = frozenset({("diamond", "ex"), ("ex", "plus"), ("diamond", "plus"),
                        ("rect", "plus"), ("rect", "cross"), ("cross", "square")})


def kind_above(a, b):
    """形状 a 压不压得过形状 b。压得过 True，压不过 False，**没实测过 None**。

    由来：全语料里「当前物件的落点被别人压着」的局面共七类，按 (谁在动, 压着的是谁) 去重后
    只剩两种关系——斜叉被菱形压住时那一格显示菱形的颜色（两次），直加号被斜叉压住时显示斜叉的
    颜色（四次），而**菱形**被斜叉压住时那一格是光标色，即菱形连同贴着它的光标一起盖在斜叉上。
    最后那一次是这条序被逼出来的地方：在那以前「被别人压着」这一刀能解释全部六次，
    因为动的都是排在下面的那个；换成排在上面的那个去动，同一刀当场说错。
    所以上下由**形状**定，与谁在动无关。

    菱形对直加号原来没直接量过，返回 None——那不是谦虚，是这一对的重叠格生成器整片弃权，
    路线每碰到一次就断一批。补上它的是一次**押出来**的观测：菱形整件移到与直加号形状重叠的落点，
    先押「若次序是传递的，重叠格该显示菱形的色」，再走一步去看——2 格重叠全部显示菱形的色，
    与传递闭包给出的方向一致。写进表的是这一次直接读数，不是那条传递性；
    传递性只是当时用来把这次观测变成一句能落空的话的工具。

    空心矩形对直加号是同一个办法量的第二对：直加号整件移到与矩形形状重叠的落点，那一格显示矩形的色。
    这一次两张表里都没有可借的传递闭包，押的方向没有依据——押它只是为了让这次观测能落空。

    **同一种形状返回 None 而不是 False**：原来写的是 `a == b -> False`，读起来像「自己压不过自己」，
    可这个函数问的是两件**不同**物件的上下，同形状只意味着**这把尺分不出来**，不是「排在下面」。
    这个洞在终局卡上发作过一次：两个十字重叠，光标那一格被判成「被压住」，
    于是把光标画成了对方的颜色，实际显示的是光标色。分不出来就该换另一把尺（颜色），不该替它下结论。
    """
    if a == b:
        return None
    if (a, b) in KIND_ABOVE:
        return True
    if (b, a) in KIND_ABOVE:
        return False
    return None


def pair_above(g, objs, c1, c2, extra=frozenset()):
    """两件**具体物件**的上下：先问形状序，形状序说不出（同形状、或没实测过）再问颜色序。

    颜色序里 `extra`（这一帧直接量到的、以及改色搬过来的）优先于跨关攒的 `ABOVE`，见 `above`。
    两把尺都说不出返回 None。
    """
    k1, col1, _ = objs[c1]
    k2, col2, _ = objs[c2]
    v = kind_above(k1, k2)
    if v is not None:
        return v
    return above(col1, col2, extra)


def cursor_shows(g, objs, active_ctr, cell, extra=frozenset()):
    """当前物件的光标落在 cell 上时，那一格露不露光标色。露 True，被压住 False，**判不出 None**。

    光标贴在当前物件那一层，所以这个问题就是「当前物件压不压得过盖在这一格上的那些」。
    盖着的有好几个而其中任何一对判不出来时返回 None——生成器与断言都该在这里闭嘴，
    别拿集合的迭代顺序冒充知识。判不出来的那一格由调用方整片弃权。

    问上下走 `pair_above`：形状序说不出（同形状、或没实测过）就换颜色序，
    颜色序里 `extra` 优先。原来只问形状序，而形状序对同形状的一对返回 False，
    于是「这把尺分不出来」被当成了「压不过」——两个同形状的物件重叠时光标被凭空判没。
    """
    over = occluders_at(objs, active_ctr, cell, g)
    if not over:
        return True
    if active_ctr not in objs:
        return None
    verdicts = [pair_above(g, objs, active_ctr, c2, extra) for c2 in over]
    if any(v is None for v in verdicts):
        return None
    return all(verdicts)


def cursor_cell_color(g, objs, active_ctr, cell, extra=frozenset()):
    """当前物件的光标落在 cell 上时，那一格该显示什么；判不出返回 None。

    露头就是光标色；被压住就是压着它的那个的颜色，压着它的不止一个就得先在它们之间排出上下
    （先看形状序，形状序排不出再看颜色序），排不出来一律 None，由调用方整片弃权。
    「光标露不露头」和「露不出来时显示谁」是同一个图层问题的两半，写在一处，
    免得生成器和断言各判一次然后分岔。
    """
    shows = cursor_shows(g, objs, active_ctr, cell, extra)
    if shows is None:
        return None
    if shows:
        return CURSOR
    over = sorted(occluders_at(objs, active_ctr, cell, g))
    cols = {objs[c2][1] for c2 in over}
    if len(cols) == 1:
        return cols.pop()
    win = [c2 for c2 in over
           if all(pair_above(g, objs, c2, c3, extra) for c3 in over if c3 != c2)]
    if len(win) == 1:
        return objs[win[0]][1]
    return top_of([objs[c2][1] for c2 in over], extra)



# ---------- 纯几何：理想形状 ----------

def stamp(kind, center, L):
    """以 center 为心、半径 L 的理想形状占的格子（不裁盘外，纯几何）。

    **中心那一格只有 plus 算自己的**：实测换人时，让出中心的物件——斜叉与菱形——那一格露出的是底色，
    只有直加号露出本色。所以斜叉的中心和菱形的中心一样是空的，光标只是停在那里。

    返回的是可改的 set（调用方有拿去 `|=` 的）；内部量尺走 `_stamp_f`，拿只读的那份，不复制。
    """
    return set(_stamp_f(kind, center, L))


@lru_cache(maxsize=50000)
def _stamp_f(kind, center, L):
    """`stamp` 的只读版本。纯几何、无状态，所以可以整条缓存——量 L 时同一个候选会被反复问。"""
    R, C = center
    if kind == "plus":
        out = {(R, C)}
        for dr, dc in DIRS4:
            out |= {(R + dr * k, C + dc * k) for k in range(1, L + 1)}
        return frozenset(out)
    if kind == "ex":
        out = set()
        for dr in (-1, 1):
            for dc in (-1, 1):
                out |= {(R + dr * k, C + dc * k) for k in range(1, L + 1)}
        return frozenset(out)
    if kind == "diamond":
        out = set()
        for k in range(L + 1):
            j = L - k
            out |= {(R - k, C - j), (R - k, C + j), (R + k, C - j), (R + k, C + j)}
        return frozenset(out)
    if kind == "hline":
        return frozenset((R, C + k) for k in range(-L, L + 1))
    if kind == "square":
        out = set()
        for dc in range(-L, L + 1):
            out |= {(R - L, C + dc), (R + L, C + dc)}
        for dr in range(-L + 1, L):
            out |= {(R + dr, C - L), (R + dr, C + L)}
        return frozenset(out)
    if kind == "cross":
        up, dn, lf, rt = L
        out = {(R, C)}
        for k in range(1, up + 1):
            out.add((R - k, C))
        for k in range(1, dn + 1):
            out.add((R + k, C))
        for k in range(1, lf + 1):
            out.add((R, C - k))
        for k in range(1, rt + 1):
            out.add((R, C + k))
        return frozenset(out)
    if kind == "rect":
        up, dn, lf, rt = L
        r0, r1, c0, c1 = R - up, R + dn, C - lf, C + rt
        out = set()
        for c in range(c0, c1 + 1):
            out |= {(r0, c), (r1, c)}
        for r in range(r0 + 1, r1):
            out |= {(r, c0), (r, c1)}
        return frozenset(out)
    raise ValueError(kind)


def _shell(kind, center, k):
    """第 k 圈：plus/ex/hline 是各条臂上第 k 格，diamond 是半径 k 的整圈。用来逐圈量 L。"""
    R, C = center
    if kind == "plus":
        return {(R + dr * k, C + dc * k) for dr, dc in DIRS4}
    if kind == "ex":
        return {(R + dr * k, C + dc * k) for dr in (-1, 1) for dc in (-1, 1)}
    if kind == "hline":
        return {(R, C - k), (R, C + k)}
    if kind in ("diamond", "square"):
        return _stamp_f(kind, center, k)   # 这两种形状本来就是一整圈，第 k 圈就是 L=k 的印子
    raise ValueError(kind)


CENTER_IN = {"plus": True, "hline": True, "ex": False, "diamond": False,
             "square": False, "cross": True, "rect": False}
"""中心那一格算不算这个物件自己的。前四种形状全实测过（换人时中心露出什么）。

看得出一条规律：**中心属于形状，当且仅当形状里有格子与中心四邻相接**——
plus 与 hline 的臂从中心出发，ex 的斜臂与 diamond 的轮廓都不挨着中心。这条规律本身还没单独立案。
`square`（空心方框）按这条规律填 False：它的边离中心 L 格，一格都不挨着。
**但它是推的，不是量的**——这个形状刚在新的一关出现，还没见过它让出中心那一步。
量到之前，凡是靠这一格作判断的地方都要当它是待测的。
`cross`（四臂不等长的十字）填 True：它的四条臂和 plus 一样从中心出发；
而且量到过一次——十字的交点没有光标压着时，那一格显示的是本色。"""


def ideal_cross(center, L):
    """老名字，等于 stamp('plus', ...)；留着是因为有概念引用它。"""
    return stamp("plus", center, L)


def on_board(g, cells):
    """把格子集裁到盘面之内（实测：形状伸出盘外就被裁掉，动作照样受理）。HUD 那一行不算盘面。"""
    n, m = len(g), len(g[0])
    return {(r, c) for (r, c) in cells if 0 <= r < min(n, HUD_ROW) and 0 <= c < m}


# ---------- 帧缓存 ----------

_CACHE: dict = {}


def _key(g):
    return tuple(tuple(row) for row in g)


_CACHE_CAP = 1500
"""缓存多少张帧。**这是纯效率参数，一个读数都不会因为它变**（这些函数只依赖 g）。

为什么从 400 抬到 1500：语料已有 1200+ 张不同的帧，而旧写法是「一满就整体清空」，
于是结算里 35 条概念各自把同一批帧的物件从头认一遍——缓存全程等于不存在。
实测（`runs/…/probe_cache_mem.py`）：缓存装满后同一批帧的第二遍从 12.9s 掉到 0.68s。
认物件是最贵的一步（约 13ms/帧），它被重复了 35 次。

代价也量过：装 1208 张帧、六种读数，tracemalloc 口径 547 MB，约 0.45 MB/帧。
所以上限必须是**有界**的——这一局被系统 OOM 杀过一次结算，不设上限是拿整轮结算赌内存。
1500 张对应约 700 MB；语料再涨就会开始淘汰，那时退化成部分命中，不会退回原来的全盘失效。
"""


def _memo(g, name, fn):
    k = _key(g)
    box = _CACHE.get(k)
    if box is None:
        if len(_CACHE) >= _CACHE_CAP:
            # 淘汰最老的一半，而不是整体清空：清空会让「刚问过的这一批帧」也一起没了，
            # 于是每张新帧都把上一张挤掉，命中率归零——旧写法在语料超过上限之后就是这个样子。
            for old in list(_CACHE)[: _CACHE_CAP // 2]:
                del _CACHE[old]
        box = _CACHE[k] = {}
    if name not in box:
        box[name] = fn(g)
    return box[name]


# ---------- 读帧 ----------

def _board_cells(g, col):
    lim = min(len(g), HUD_ROW)
    return {(r, c) for r in range(lim) for c, v in enumerate(g[r]) if v == col}


def cursor(g):
    """光标（当前物件中心）的 (row, col)；不唯一或没有就 None。"""
    hits = sorted(_board_cells(g, CURSOR))
    return hits[0] if len(hits) == 1 else None


def me(g):
    """模板要求的入口；本局「我」就是光标。"""
    return cursor(g)


def rings(g):
    """所有环的边框格（色 RING_EDGE）集合。"""
    return frozenset(_board_cells(g, RING_EDGE))


def _ring_centers(g):
    """{(r,c): 中心那一格当前显示的颜色}。

    环是 3×3 的色 4 轮廓，会被物件的臂压掉一部分，所以不能只数色 4 的个数。四条判据一起用：
      1. 这一格自己既不是色 4 也不是底色 —— 环心显示的是某个物件的颜色（被盖住时是盖它的颜色）；
      2. 8 邻全在盘内、且**一个底色都没有** —— 8 邻就是环框，每一格要么是色 4 要么被物件盖着；
      3. 8 邻里至少 3 个色 4 —— 一条臂最多盖掉 3 格，中心紧挨着环时两条臂最多盖掉 4 格（第 12、25 步实测）；
      4. **切比雪夫距离恰好 2 的地方不许有色 4，除非那一格是别的环的框**——
         没有前半句，横臂正好压在环上方一行时，环外那一格的一圈也没有底色，会被认成环心（第 13、26 步实测）；
         没有后半句，**两个环斜挨着（心距 3）时两个都认不出来**：彼此的框正好落在对方的距离 2 上。
         「是别的环的框」判成：那一格紧挨着某个 q，q 自己满足前三条，且 q 离 p 有 3 格以上。
         这条 3 格的门槛就是原来那个误认还挡得住的原因 —— 那时候把 p 抬出来的真环心离 p 只有 1 格。
    代价：贴着盘边的环还是认不出来 —— 还没见过，见到再说。
    **注意**：被物件盖住时，这里读到的颜色是盖它的那个物件的颜色，不是环的归属色 —— 见 `ring_owner`。
    """
    edge = _board_cells(g, RING_EDGE)
    lim = min(len(g), HUD_ROW)
    wid = len(g[0])

    def core_ok(p):
        """前三条：这一格看着像个环心。判据 4 拿它去认「别的环」，所以它自己不许再问判据 4。"""
        if p in edge or g[p[0]][p[1]] == BG:
            return False
        nb = [(p[0] + a, p[1] + b) for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b]
        if not all(0 <= q[0] < lim and 0 <= q[1] < wid for q in nb):
            return False
        if any(g[q[0]][q[1]] == BG for q in nb):
            return False
        return sum(1 for q in nb if q in edge) >= 3

    core = set()
    for (r, c) in edge:
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                p = (r + dr, c + dc)
                if p in core:
                    continue
                if core_ok(p):
                    core.add(p)

    out = {}
    for p in core:
        ring2 = [(p[0] + a, p[1] + b)
                 for a in range(-2, 3) for b in range(-2, 3)
                 if max(abs(a), abs(b)) == 2]
        ok = True
        for x in ring2:
            if x not in edge:
                continue
            # 这一格是色 4：只有当它是**另一个**环的框时才放过（那个环的心离 p 有 3 格以上）
            if not any(q in core
                       and max(abs(q[0] - p[0]), abs(q[1] - p[1])) >= 3
                       for q in [(x[0] + a, x[1] + b)
                                 for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b]):
                ok = False
                break
        if ok:
            out[p] = g[p[0]][p[1]]
    return out


def ring_centers(g):
    return _memo(g, "rc", _ring_centers)


def ring_border(g):
    """所有环的边框格（按环心的 8 邻推出来，不管现在有没有被物件盖住）。"""
    def calc(gg):
        out = set()
        for (r, c) in ring_centers(gg):
            out |= {(r + a, c + b) for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b}
        return frozenset(out)
    return _memo(g, "rb", calc)


def shape_colors(g):
    """盘上可能是物件的颜色：不是底色、不是环框、不是光标，且去掉只以环心形式出现的颜色。"""
    def calc(gg):
        lim = min(len(gg), HUD_ROW)
        h = Counter(gg[r][c] for r in range(lim) for c in range(len(gg[0])))
        rc = Counter(ring_centers(gg).values())
        out = []
        for col, n in h.items():
            if col in (BG, RING_EDGE, CURSOR):
                continue
            if n - rc.get(col, 0) > 0:
                out.append(col)
        return tuple(sorted(out))
    return _memo(g, "cols", calc)


def _fit(shape, board):
    """从可见格子拟合 (kind, center, L)。

    中心用对称性投票，不用 bbox 中点 —— 遮挡与盘边裁切会把 bbox 拽歪：
      plus    中心行 = 格子最多的那一行（中心行有 2L 格，别的行只有 1 格），中心列同理
      ex      中心 = 「格子最多的那条 r-c 斜线」与「格子最多的那条 r+c 斜线」的交点
      diamond 中心 = 「格子最多的两条 r-c 斜线」取中、「格子最多的两条 r+c 斜线」取中（四条边的中线交点）
      rect    上下边所在的两行、左右边所在的两列由票数定，中心取包围盒中心向上取整（候选自带 L）
    然后逐个验证，按「(不在理想形状上的格子数, 理想形状里没被看到的格子数)」取最省的一个。
    **这里不出 `cross` 候选**：它靠「哪几格看不见」定臂长，而这一路读法手上没有遮挡信息
    （只有这一个颜色的可见格），于是任何一条被别人压住的臂尖都会被读成真的短臂。
    四臂不等长的十字只由 `objects` 那一路认——它有 `filled`，分得开「被盖住」和「本来就没有」。
    代价是这一路碰上真的不等长十字会拟合成一个过大的直加号；`shapes_total` 拿 kind 与 L 跟
    `objects` 对数，对不上就整张表不给，所以那个错读传不出去。
    允许最多 2 个格子不在理想形状上：环框被盖掉 3 格以上时环心认不出来，那一格会混进形状里。
    """
    if not shape:
        return None
    rows = Counter(r for r, _ in shape)
    cols = Counter(c for _, c in shape)
    dif = Counter(r - c for r, c in shape)
    sm = Counter(r + c for r, c in shape)
    cands = [("plus", (rows.most_common(1)[0][0], cols.most_common(1)[0][0]))]
    d = dif.most_common(1)[0][0]
    s = sm.most_common(1)[0][0]
    if (d + s) % 2 == 0:
        cands.append(("ex", ((d + s) // 2, (s - d) // 2)))
    d2 = [k for k, _ in dif.most_common(2)]
    s2 = [k for k, _ in sm.most_common(2)]
    if len(d2) == 2 and len(s2) == 2:
        a, b = sum(d2), sum(s2)
        if a % 2 == 0 and b % 2 == 0 and ((a // 2) + (b // 2)) % 2 == 0:
            rc_, sc_ = a // 2, b // 2
            cands.append(("diamond", ((rc_ + sc_) // 2, (sc_ - rc_) // 2)))
    cands.extend(_square_cands(shape))
    cands.extend(_rect_cands(shape))
    best = None
    for cand in cands:
        if len(cand) == 3:
            kind, center, L = cand
        else:
            kind, center = cand
            R, C = center
            if kind in ("plus", "square"):
                Ls = {max(abs(r - R), abs(c - C)) for r, c in shape}
            elif kind == "ex":
                Ls = {abs(r - R) for r, c in shape}
            else:
                Ls = {abs(r - R) + abs(c - C) for r, c in shape}
            L = max(Ls)
            if L < 1 or L > 40:
                continue
        st = stamp(kind, center, L)
        stray = len(shape - st)
        if stray > 2:
            continue
        miss = len({q for q in st if q in board}) - (len(shape) - stray)
        score = (stray, miss, KINDS.index(kind))
        if best is None or score < best[0]:
            best = (score, (kind, center, L))
    return None if best is None else best[1]


def shapes(g):
    """{颜色: (kind, center, L)}；拟合不出来的颜色不进这个表。"""
    def calc(gg):
        lim = min(len(gg), HUD_ROW)
        board = {(r, c) for r in range(lim) for c in range(len(gg[0]))}
        rc = set(ring_centers(gg))
        out = {}
        for col in shape_colors(gg):
            f = _fit(_board_cells(gg, col) - rc, board)
            if f is not None:
                out[col] = f
        return out
    return _memo(g, "shapes", calc)


def shape_of(g, col):
    return shapes(g).get(col)


def shapes_total(g):
    """`shapes` 那张表，**但只在它装得下盘上每一个物件时**才给；装不下就给 `{}`。

    为什么要这道门：`shapes` 是「一颜色一物件」这个假设的读法，它对每个候选颜色**分别**拟合，
    拟合不上的颜色就不进表——于是它可以**部分成立**。盘上出现和物件同色的家具时，
    那个颜色的格子里混进了家具的格子、拟合当场失败，表里就少了那个物件，而表本身还是非空的。
    凡是拿「非空」当「全都在这儿」用的地方，都会静默地读一个少了几个物件的世界：
    覆盖判据少数几个环、图层少压几层、平移只画一个物件——一个字的报错都不会有。

    这里拿它和 `objects`（按中心索引、不依赖那个假设）对数：个数、中心集合、**每个中心上的 kind 与 L**
    都得一致才认。对到 kind 与 L 那一层是后加的：只对个数和中心，一个形状被拟合成「同一个中心、
    大一圈的另一种形状」时两边照样对得上，而那种错读正是把「物件变了形」读成「物件没动」的来源。
    教训：**「只在特例下非空」的表，不能用非空来判特例成立**，要拿它跟一个不依赖那个特例的读数对数，
    而且要对到会改变结论的那一层。
    """
    sh = shapes(g)
    if not sh:
        return {}
    objs = objects(g)
    if len(sh) != len(objs):
        return {}
    if {c for _k, c, _l in sh.values()} != set(objs):
        return {}
    for _col, (k, c, l) in sh.items():
        k2, _col2, l2 = objs[c]
        if (k, l) != (k2, l2):
            return {}
    return sh


# ---------- 多物件同色的世界：按中心索引 ----------
# 一颜色一物件是个假设，它在某些关成立、某些关不成立。`shapes()` 只在成立时开口（否则返回 {}），
# 这里另开一套按**中心**索引的读法，两套并存：旧概念继续用 shapes()，读不出来就沉默；
# 装置里凡是要「盘上所有物件」的地方（图层、通关判据、生成器）都改走 `_cur_objs`，它自动选一套。

def _outer_ok(sh, own, soft):
    """最外那一圈算不算「有自己看得见的证据」。

    正常情形：这一圈里有一格是自己露着的（`sh & own`）。
    放宽的那一种：整圈**全部**由「自己露着的格」和「正显示本色的环心」组成——
    环心显示本色是零证据（它本来就是这个颜色），但整圈只由这两种格子构成时，
    没有第二个物件参与解释，往外接一圈不是凭空接，是接在自己身上。
    臂尖正好停在环心上就落在这一种里，而那正是这一关要去的位形。
    只要圈里混进一格「被别的物件盖着」，就退回严格判据——那一圈是别人撑起来的。
    """
    if sh & own:
        return True
    return bool(sh) and sh <= (own | soft)


def _max_L(kind, ctr, filled, own, board, soft=frozenset()):
    """以 ctr 为心、形状完全落在 filled 里的最大 L；量不出来返回 None。

    `filled` 是万能牌放宽后的可容格（自己的可见格 + 环心 + 光标 + 别的物件占着的格），
    `own` 是自己的可见格，`soft` 是正显示本色的环心（见 `_outer_ok`）。两条一起：
    中间某一圈整圈被别人压住可以跨过去，
    但**最外那一圈必须有自己看得见的格子**——否则就是凭空往外接，谁也没看见过。
    """
    if CENTER_IN[kind] and ctr not in filled:
        return None
    if kind == "cross":
        return _cross_L(ctr, filled, own, board, soft)
    if kind in ("diamond", "square"):
        # 空心圈的 L 必须落在「own 里真有格子的那些距离」上（判据要求 sh & own 非空），
        # 别的 k 一试就废，不必去算。这一步只是不做无用功，判据一个字没改。
        R, C = ctr
        if kind == "diamond":
            ds = {abs(r - R) + abs(c - C) for r, c in own | soft}
        else:
            ds = {max(abs(r - R), abs(c - C)) for r, c in own | soft}
        best = None
        for k in sorted(d for d in ds if 2 <= d <= 40):
            sh = _shell(kind, ctr, k) & board
            if len(sh) >= 4 and sh <= filled and _outer_ok(sh, own, soft):
                best = k
        return best
    L = 0
    for k in range(1, 41):
        sh = _shell(kind, ctr, k) & board
        if not sh or not (sh <= filled):
            break
        if _outer_ok(sh, own, soft):
            L = k
    return L if L >= 2 else None


def _cross_L(ctr, filled, own, board, soft=frozenset()):
    """四臂不等长的十字：四条臂各自量到底，返回 (上, 下, 左, 右)；站不住返回 None。

    每条臂的判据和 `_max_L` 给 plus 用的那条一样，只是逐臂独立：
    沿这个方向一格一格往外走，格子必须在 `filled` 里（自己的可见格、环心、光标、别人盖住的格），
    走到出盘或断掉为止；臂长取「这条臂上最远的、自己真看得见的那一格」——
    中间被压住可以跨过去，但最外那一格必须是自己露着的，否则就是凭空往外接。
    臂尖那一格正好是显示本色的环心时也认（`soft`，见 `_outer_ok`）：逐臂量时最外「一圈」就是一格，
    这一格是本色环心就说明没有第二个物件参与解释。不认它的代价是——
    臂尖压上环心那一步，那条臂当场少量一格，而那正是这一关要去的位形。

    四条臂里最多允许**一条**长度为 0，而且要有正面证据：那个方向第一格必须**不在 `filled` 里**
    （背景、挡块，或者出盘）。被挡块推到极限的十字就长这样——交点顶到包围盒的一条边上，
    那个方向一格臂都不剩。不给这个口子的代价是：那一步整个物件从「十字」掉成「横线」，
    包围盒从一整片缩成一行，`bbox_center` 跟着挪，于是「光标 = 包围盒中心」在一个世界完全按预期
    走完的位形上判自己错。
    口子给得这么窄有两层理由：**两条**臂都没了就是横线，而横线是实测过的形状，不该被更能装的形状顶掉；
    「第一格不在 filled 里」则挡住了「臂被别的物件盖住、于是看着像没有」那一种——
    那时「看不见」有现成的解释，判它长度为 0 是凭空断言。那一种归**整条臂被盖住**处理，见下。

    量完还有一道**回补**：短的那条臂如果一路到最长那条臂的长度为止、每一格都在 `filled` 里
    （也就是全被别的东西盖着），就按最长的算。理由是不对称要有证据：
    「看不见」有一个现成的解释（被盖住），而「臂真的短了」没有；
    不回补的实测代价是——盘上另一个物件的边正好压住一条臂的尖，装置立刻报出一个假的不对称十字。
    真长度为 0 的那条臂天然不会被回补：它的第一格不在 `filled` 里，回补第一步就断。
    **补不到最长那条就一格都不补**，不许停在半路：试过「顺着被盖住的那一串补到哪算哪」，
    全语料差分当场抓到代价——一条臂的尖外面正好连着另一个物件的一条边，那一串把臂多撑了三到六格。
    补到底才认，等于要求「不对称的那一半完全能由遮挡解释」；停在半路是拿别人的边当自己的臂。

    **整条臂一格都露不出来**（far = 0 而第一格在 `filled` 里）：这一帧定不下它有多长，整个弃权。
    早先这里也走回补（补到最长那条就按最长的算），理由与上一段同是「不对称要有证据」；
    全语料差分把这条量了出来：当前物件是十字类的帧 324 个，其中某条臂的长度是补出来的 59 个，
    而**整条臂一格都露不出来**的只有 2 个——这 2 个全都被世界打了脸（回补出来的那截画出去，
    杠一从遮挡下面滑出来就少几格）。回补对露着一半的臂 57 次没出过事，对整条看不见的臂 2 次全错，
    所以只掐掉后面这一种。弃权的代价是知道的：那一帧这个物件读不出来，退而求其次被认成别的形状，
    包围盒缩掉一大片，`active_center` 可能返回「不知道」，全册对那一帧一句话都说不出来。
    在终局卡上这是划算的——闭嘴只让批次断在这里，猜错要赔一次意外，还会把错的形状传进链式假帧。
"""
    R, C = ctr
    arms = []
    zero = 0
    hidden = set()
    for i, (dr, dc) in enumerate(DIRS4):
        far = 0
        for k in range(1, 41):
            p = (R + dr * k, C + dc * k)
            if p not in board:
                break
            if p not in filled:
                break
            if p in own or p in soft:
                far = k
        if far == 0:
            if (R + dr, C + dc) in filled:
                hidden.add(i)                # 整条臂都被别人盖着：有多长看不见，交给回补去定
            else:
                zero += 1
                if zero > 1:
                    return None              # 两条臂都没了：那是横线，不是十字
        elif far < 2:
            return None
        arms.append(far)
    mx = max(arms)
    if mx < 2:
        return None                          # 一条量得出来的臂都没有：这不是量出来的十字
    for i, (dr, dc) in enumerate(DIRS4):
        k = arms[i]
        if i in hidden:
            return None                      # 整条臂一格都露不出来：这一帧定不下它有多长
        while k < mx:
            p = (R + dr * (k + 1), C + dc * (k + 1))
            if p not in board or p not in filled:
                break
            k += 1
        if k == mx:
            arms[i] = mx
    return tuple(arms)


def _rect_cands(uncov, filled=frozenset()):
    """长宽各自长短的空心矩形：直接给出 (kind, 中心, L)，L = (上, 下, 左, 右)。

    和 `_square_cands` 同一个道理——上下两条边各占满一整行、左右两条边各占满一整列，
    所以「票数最高的两行」就是上下边所在的行，「票数最高的两列」就是左右边所在的列。
    再补一路用极值行列，防的是某一条边整条被别的物件压住投不出票。

    它比别的候选多带一个 L 出来，因为**矩形的四条边不能从中心走出去量**：
    中间是空的，从中心往外第一格就断。中心只是个锚（包围盒中心向上取整），不是量尺的原点。

    **极值那一路挡不住「整条边被压住」**：那条边一票都投不出来，极值给出的是它里面那一条线
    （左右两条边露在外面的最外端），于是候选比真身窄一圈，四条边怎么摆都站不住，整件东西读不出来。
    所以再补一路：把某一条边**往外推**，推到那一整条线不再全落在可容格 `filled` 里为止，一次只推一条。
    推出来的只是候选，站不站得住由 `_rect_ok` 判——它要求那条边整条压在**已经认下的、压得过我的物件**
    底下，而不是随便哪张万能牌。
    """
    rows = Counter(r for r, _ in uncov)
    cols = Counter(c for _, c in uncov)
    if not rows or not cols:
        return []
    base = []
    for rr in ([sorted(k for k, _ in rows.most_common(2))] +
               [[min(rows), max(rows)]]):
        for cc in ([sorted(k for k, _ in cols.most_common(2))] +
                   [[min(cols), max(cols)]]):
            if len(rr) != 2 or len(cc) != 2:
                continue
            r0, r1, c0, c1 = rr[0], rr[1], cc[0], cc[1]
            if r1 - r0 < 2 or c1 - c0 < 2:
                continue
            if (r0, r1, c0, c1) not in base:
                base.append((r0, r1, c0, c1))

    def _row_in(r, c0, c1):
        return all((r, c) in filled for c in range(c0, c1 + 1))

    def _col_in(c, r0, r1):
        return all((r, c) in filled for r in range(r0, r1 + 1))

    boxes = list(base)
    for r0, r1, c0, c1 in base:
        for k in range(1, 7):                              # 上边往外推
            if not _row_in(r0 - k, c0, c1):
                break
            boxes.append((r0 - k, r1, c0, c1))
        for k in range(1, 7):                              # 下边往外推
            if not _row_in(r1 + k, c0, c1):
                break
            boxes.append((r0, r1 + k, c0, c1))
        for k in range(1, 7):                              # 左边往外推
            if not _col_in(c0 - k, r0, r1):
                break
            boxes.append((r0, r1, c0 - k, c1))
        for k in range(1, 7):                              # 右边往外推
            if not _col_in(c1 + k, r0, r1):
                break
            boxes.append((r0, r1, c0, c1 + k))

    out = []
    for r0, r1, c0, c1 in boxes:
        if r1 - r0 < 2 or c1 - c0 < 2:
            continue
        R, C = (r0 + r1 + 1) // 2, (c0 + c1 + 1) // 2
        cand = ("rect", (R, C), (R - r0, r1 - R, C - c0, c1 - C))
        if cand not in out:
            out.append(cand)
    return out


def _rect_ok(ctr, L, filled, own, board, soft=frozenset(), hidden=frozenset()):
    """给定的空心矩形站不站得住：盘内的边格必须全在 `filled` 里，四条边各自至少露一格，
    而且**框里面一格本色都不许有**。

    「四条边各自至少露一格」这条对应 `_max_L` 里「最外那一圈必须有自己看得见的格子」，
    放宽的口子也一样（`_outer_ok`）：整条边只由自己露着的格和显示本色的环心组成时也算露过。

    「里面必须是空的」这条是拦冒充用的，代价实测过：盘上那块实心的障碍物，
    它的外轮廓恰好是一个矩形，于是 `rect` 把轮廓认成一个物件、把里面剩下的格子丢给 `unexplained`，
    凭空多出一个会改 ACTION5 循环长度的「物件」。空心是这个形状的定义的一半，不是附带描述。

    **最多允许一条边一格都没露**，条件是那一整条边压在 `hidden` 底下——`hidden` 是这一轮里
    已经认下的、压得过我（或者与我的次序没实测过）的物件占住的格子，也就是有东西**替这条边
    解释了它为什么看不见**。两条以上看不见就不认：那已经不是「被挡住」，是在拿别人的身体拼一个我。
    这个口子和 `_max_L` 里「中间某一圈整圈被压住可以跨过去」是同一条，只是矩形的边没有「中间」——
    它的四条边都是最外圈，一律按最外圈判就等于说「整条边被压住的矩形永远读不出来」。
    """
    up, dn, lf, rt = L
    R, C = ctr
    r0, r1, c0, c1 = R - up, R + dn, C - lf, C + rt
    st = stamp("rect", ctr, L) & board
    if not st or not (st <= filled):
        return False
    if any(r0 < r < r1 and c0 < c < c1 for r, c in own):
        return False
    edges = ({(r0, c) for c in range(c0, c1 + 1)},
             {(r1, c) for c in range(c0, c1 + 1)},
             {(r, c0) for r in range(r0, r1 + 1)},
             {(r, c1) for r in range(r0, r1 + 1)})
    bad = [e & board for e in edges if not _outer_ok(e & board, own, soft)]
    if not bad:
        return True
    if len(bad) > 1:
        return False
    return bool(bad[0]) and bad[0] <= hidden


def _square_cands(uncov):
    """空心方框的候选中心。

    方框的上下两条边各占满一整行（2L+1 格），左右两条边各占满一整列，
    所以「票数最高的两行」取中点给出中心行，「票数最高的两列」取中点给出中心列。
    和菱形同样的毛病：一族可能整族被别的物件压住投不出票，
    所以再补一路——用一族定出的半宽 L 配另一族的极值线反推中点。
    只出候选，站不站得住由 `_max_L` 判。
    """
    rows = Counter(r for r, _ in uncov)
    cols = Counter(c for _, c in uncov)
    if not rows or not cols:
        return []
    out = []
    r2 = sorted(k for k, _ in rows.most_common(2))
    c2 = sorted(k for k, _ in cols.most_common(2))
    if len(r2) == 2 and len(c2) == 2 and (r2[0] + r2[1]) % 2 == 0 and (c2[0] + c2[1]) % 2 == 0:
        out.append(("square", ((r2[0] + r2[1]) // 2, (c2[0] + c2[1]) // 2)))
    if len(r2) == 2 and (r2[0] + r2[1]) % 2 == 0:
        R, L = (r2[0] + r2[1]) // 2, (r2[1] - r2[0]) // 2
        if L > 0:
            out.append(("square", (R, max(cols) - L)))
            out.append(("square", (R, min(cols) + L)))
    if len(c2) == 2 and (c2[0] + c2[1]) % 2 == 0:
        C, L = (c2[0] + c2[1]) // 2, (c2[1] - c2[0]) // 2
        if L > 0:
            out.append(("square", (max(rows) - L, C)))
            out.append(("square", (min(rows) + L, C)))
    return out


def _diamond_cands(uncov):
    """菱形的候选中心。

    菱形的四条边分别落在两条 r-c 等值线和两条 r+c 等值线上，中心由这两族的中点定：
    `rc - cc` 取 r-c 那一对的中点，`rc + cc` 取 r+c 那一对的中点。
    但**其中一族可能整族被别的物件先认领掉**（同色世界里另一个物件的对角线正好压在菱形的一条边上），
    那一族就投不出票来。所以除了「两族各自的中点」，再补一路：
    用一族定出的半宽 L 配上另一族的**极值线**反推中点（`极大 - L` 或 `极小 + L`）。
    只出候选，站不站得住由 `_max_L` 判。
    """
    dif = Counter(r - c for r, c in uncov)
    sm = Counter(r + c for r, c in uncov)
    if not dif:
        return []

    def mid(cnt):
        """票数最高的两条线的中点与半宽；凑不出返回 None。"""
        v = [k for k, _ in cnt.most_common(2)]
        if len(v) < 2:
            return None
        a, b = sorted(v)
        return ((a + b) // 2, (b - a) // 2) if (b - a) % 2 == 0 else None

    md, ms = mid(dif), mid(sm)
    us = {md[0]} if md else set()
    vs = {ms[0]} if ms else set()
    if md:
        vs |= {max(sm) - md[1], min(sm) + md[1]}
    if ms:
        us |= {max(dif) - ms[1], min(dif) + ms[1]}
    return [("diamond", ((u + v) // 2, (v - u) // 2))
            for u in us for v in vs if (u + v) % 2 == 0]


def _cands(uncov, filled, g):
    """候选形状：多数是 (kind, 中心)，`rect` 是 (kind, 中心, L)——它的边量不出来，只能整个给。

    三种对称形状按对称性投票（同 `_fit`），横线按极长连续段取中点。
    """
    out = []
    rows = Counter(r for r, _ in uncov)
    cols = Counter(c for _, c in uncov)
    dif = Counter(r - c for r, c in uncov)
    sm = Counter(r + c for r, c in uncov)
    if rows and cols:
        out.append(("plus", (rows.most_common(1)[0][0], cols.most_common(1)[0][0])))
        out.append(("cross", (rows.most_common(1)[0][0], cols.most_common(1)[0][0])))
    if dif and sm:
        d, s = dif.most_common(1)[0][0], sm.most_common(1)[0][0]
        if (d + s) % 2 == 0:
            out.append(("ex", ((d + s) // 2, (s - d) // 2)))
    out.extend(_diamond_cands(uncov))
    out.extend(_square_cands(uncov))
    out.extend(_rect_cands(uncov, filled))
    wid = len(g[0])
    for r, _ in rows.most_common(3):
        run = []
        for c in range(wid + 1):
            if (r, c) in filled:
                run.append(c)
                continue
            if len(run) >= 5 and len(run) % 2 == 1:
                out.append(("hline", (r, run[len(run) // 2])))
            run = []
    seen = set()
    return [x for x in out if not (x in seen or seen.add(x))]


def _body(g, kind, ctr, L, col, others=()):
    """物件在**这一帧**实际占住的格子 = 理想形状，外加「中心那一格看起来还归它」的情形。

    `stamp` 里斜叉与菱形的中心不算它自己的，依据是它们让出中心时那一格露出底色。
    但那只是被光标碰过之后的样子：实测同一个斜叉的中心格，在这一关被选中之前一直填着本色
    （全语料里非当前的斜叉/菱形，中心显示本色 34 次、底色 118+86 次，同一个物件先本色后底色），
    也就是说中心是**被选中时挖空的，而且挖了不会填回来**。
    所以「中心归不归它」不是形状的性质，得看帧。填着本色的中心挡得住别的物件的臂——
    不算它，别的物件的臂穿过这里时就会被判成「本色断了」，那个物件的半径于是读小。

    `others` = 别的物件的 [(颜色, 形状格集)]。**同色的臂路过我的空心中心，看起来和「我填着本色」一模一样**，
    这一帧分不开，所以那时候闭嘴按空心算——多认一格会把「臂走了就露底」判成错。
    """
    st = stamp(kind, ctr, L)
    if ctr in st:
        return st
    v = g[ctr[0]][ctr[1]]
    if v not in (col, CURSOR):
        return st
    if v == col and any(c2 == col and ctr in st2 for c2, st2 in others):
        return st                            # 别人的同色臂就能解释这一格：拿不出证据
    return st | {ctr}


def _bodies(g, objs):
    """{中心: 它在这一帧实际占住的格子} —— 一次把整张物件表交给 `_body`，同色歧义才判得对。

    歧义只看别人的**理想形状**（`stamp`），不看别人的 body，所以这里不会绕回自己。
    """
    sts = {c: (col, stamp(k, c, l)) for c, (k, col, l) in objs.items()}
    return {c: _body(g, k, c, l, col, [sts[c2] for c2 in objs if c2 != c])
            for c, (k, col, l) in objs.items()}


CENTER_NEVER_FILLED = ("diamond", "rect", "square")


def center_never_filled(kind):
    """这种形状的中心格从不填本色——所以「光标让开之后露什么」不必先读 prev 就答得出来。

    菱形、空心矩形、正方形在里面，主张分别写在概念 `diamond_center_hollow`
    （非当前、没被压住的菱形中心，全语料 170/170 露下面那一层）
    与 `rect_center_hollow`（同口径下矩形 85/85、正方形 76/76）。
    **斜叉不在里面**：同样口径下它本色 89 次、底色 71 次，而帧里读得出来的键——形状、臂长、
    臂长奇偶、颜色、中心行奇偶、本关有没有色块——一个都分不开这两堆。它是物件出生时定死的属性。

    「中心不在 `stamp` 里」是画法约定，不是世界事实：同样约定下的斜叉就不是这样。
    所以每种形状都要单独量过才进这张表。
    """
    return kind in CENTER_NEVER_FILLED


def ambiguous_centers(g, objs):
    """哪些物件的中心「这一帧归不归它」判不出来 —— 拿不出证据，也拿不出反证。

    `_body` 碰到这种格子按「不归它」处理：中心显示本色，而另一个**同色**物件的臂正好压在那里，
    这一帧分不开是谁的。那是读物件时的保守选择（多认一格会把「臂走了就露底」判成错）。
    但生成器不能跟着保守——它会把这一格照下面那一层重画，而下面那一层是什么，这一帧根本没人知道。
    实测代价：那条同色的臂让开时，装置说露底色 5，真帧是本色 14；一步说错 1 格，而所有断言都判 TRUE，
    因为断言只问中心动没动，不问让开的地方露了什么。所以这些格子交给生成器整片弃权。
    中心从不填本色的形状（`center_never_filled`）不在里面：它显示本色时必定是别人的臂，没有歧义。

    **判据是「别人盖在这个中心上」，不是「盖它的人和它同色」。** 第一版只写了同色那一支，
    因为催生它的那一帧里盖住中心的正好同色；异色的物件盖上来时这一格显示的是**别人的颜色**，
    第一版在 `g[c] != col` 那里直接放过——可读不出下面填没填本色，两种情形一模一样。
    实测代价：盖着的那件让开时，装置说露底色，真帧是那个中心自己的本色；一步说错 1 格，
    断言照旧全绿。所以按「读不读得出来」写：中心不在自己形状里、又被别人的形状压着、
    而这一格显示的不是自己的本色（同色的臂那一支除外，它显示的就是本色），一律弃权。
    """
    sts = {c: (col, stamp(k, c, l)) for c, (k, col, l) in objs.items()}
    out = set()
    for c, (k, col, _l) in objs.items():
        if c in sts[c][1] or center_never_filled(k):
            continue
        over = [c2 for c2, (_col2, st2) in sts.items() if c2 != c and c in st2]
        if not over:
            continue                         # 没人压着：这一格显示什么就是什么，读得出来
        if g[c[0]][c[1]] == col:
            # 显示本色：只有同色的臂才制造歧义（异色的臂压上来就不会显示本色）
            if any(sts[c2][0] == col for c2 in over):
                out.add(c)
        elif g[c[0]][c[1]] != BG:
            out.add(c)                       # 显示别人的色：下面填没填本色，这一帧读不出来
    return out


BOX_SIZES = (5, 6)


def box_area(inner):
    """从色块内部那一小块反推整个框的格集（内部四周各扩一圈）。

    框的边长不是常数：实测见过 6（内部 4×4）和 5（内部 3×3）两种。
    所以凡是要「整个框那一片」的地方都从 inner 反推，别再把 6 写死——
    对 5×5 的框按 6×6 算，会把框外多出来的一行一列也算进触发区。
    """
    rs = [r for r, _ in inner]
    cs = [c for _, c in inner]
    return frozenset((r, c)
                     for r in range(min(rs) - 1, max(rs) + 2)
                     for c in range(min(cs) - 1, max(cs) + 2))


def _box_windows(g):
    """所有「框边里至少 60% 是 BOX_EDGE」的正方形窗口，返回 (左上行, 左上列, 边长)。

    边长不写死：实测见过 6（内部 4×4）和 5（内部 3×3）两种，两种都要试。
    判据用**比例**不用绝对格数——6 的 20 格边要 12 格，正好是 60%，所以老判据一个字没改，
    只是同一个比例也拿去问 5。没见过的边长不猜（`BOX_SIZES` 只列实测过的两种）：
    真出现第三种，它会以「认不出的格子」的形式冒出来，那时再加，别替世界回答。

    一大一小两个窗口套在同一个框上时只留大的：否则同一个框被数两遍，内部还会少算一圈。

    **窗口允许伸到盘外**：框被盘边裁掉一截时，剩下的那一段照样是框。不认它的代价是实打实的——
    裁剩下的那圈色 BOX_EDGE 会被 `objects` 拟合成一个凭空多出来的物件，而框里那块色块
    则以「认不出的格子」的形式挂在 `unexplained` 上，于是整关的生成器一格都不预测。
    裁过的窗口另判一套，比整个在盘内的**更严**：盘内那部分框边要**全部**是 BOX_EDGE，
    而且至少一条完整的框边落在盘内。理由是证据变少了——60% 那条口子是留给「框边被物件盖住」的，
    可裁剩几格时任何一小段色 BOX_EDGE 都能凑出 60%，一个大一号的假窗口还会把真窗口挤掉
    （只留大的那条规则）。放宽的代价是**沉默**（框认不出、残料非空、有人闭嘴），是响的；
    收紧的代价是**假家具**（物件让开后预测出一片本不存在的框），不响。

    用二维前缀和数个数（n×n 减内部 (n-2)×(n-2)），每个窗口常数次加减。
    """
    def calc(gg):
        lim = min(len(gg), HUD_ROW)
        wid = len(gg[0])
        ps = [[0] * (wid + 1) for _ in range(lim + 1)]
        for r in range(lim):
            row, up, cur = gg[r], ps[r], ps[r + 1]
            acc = 0
            for c in range(wid):
                acc += 1 if row[c] == BOX_EDGE else 0
                cur[c + 1] = up[c + 1] + acc

        def cnt(r0, c0, h, w):
            return ps[r0 + h][c0 + w] - ps[r0][c0 + w] - ps[r0 + h][c0] + ps[r0][c0]

        def ring(r, c, n):
            """窗口那一圈框边里，落在盘内的格数与其中 BOX_EDGE 的格数（整圈减内部，各自先裁到盘内）。"""
            def blk(r0, c0, r1, c1):
                r0, c0, r1, c1 = max(r0, 0), max(c0, 0), min(r1, lim), min(c1, wid)
                if r1 <= r0 or c1 <= c0:
                    return 0, 0
                return cnt(r0, c0, r1 - r0, c1 - c0), (r1 - r0) * (c1 - c0)
            of, af = blk(r, c, r + n, c + n)
            oi, ai = blk(r + 1, c + 1, r + n - 1, c + n - 1)
            return of - oi, af - ai

        hits = []
        for n in BOX_SIZES:
            need = -(-12 * (n - 1) // 5)        # ceil(0.6 × 边格数)，边格数 = 4(n-1)
            for r in range(lim - n + 1):
                for c in range(wid - n + 1):
                    if cnt(r, c, n, n) - cnt(r + 1, c + 1, n - 2, n - 2) >= need:
                        hits.append((r, c, n))
            # 被盘边裁掉一截的框：整格窗口伸到盘外，上面那一路扫不到它。
            for r in range(-(n - 2), lim - 1):
                for c in range(-(n - 2), wid - 1):
                    if 0 <= r <= lim - n and 0 <= c <= wid - n:
                        continue            # 整个在盘内，上面那一路已经判过
                    side = ((r >= 0 and c >= 0 and c + n <= wid)          # 上边
                            or (r + n <= lim and c >= 0 and c + n <= wid)  # 下边
                            or (c >= 0 and r >= 0 and r + n <= lim)        # 左边
                            or (c + n <= wid and r >= 0 and r + n <= lim))  # 右边
                    if not side:
                        continue
                    ok, tot = ring(r, c, n)
                    if tot and ok == tot:
                        hits.append((r, c, n))
        keep = [(r, c, n) for r, c, n in hits
                if not any(n2 > n and r2 <= r and c2 <= c
                           and r + n <= r2 + n2 and c + n <= c2 + n2
                           for r2, c2, n2 in hits)]
        return tuple(keep)
    return _memo(g, "boxwin", calc)


def _raw_boxes(g):
    """只看像素找色块框：某个 n×n 窗口的框边里至少 60% 是 BOX_EDGE。
    返回 (仍显示 BOX_EDGE 的边格, 所有这些框的内部 (n-2)×(n-2) 格)。

    和 `boxes` 是两件事，不能互相代替。`boxes` 要求「看不见的边格得有某个物件盖着」才认下这个框，
    那就得先读物件——所以物件读法里用不了它，用了会绕回自己。这里只要像素，不问遮挡。

    两半的地位不一样，这正是分开返回的理由：

    * **边格**：显示的还是家具本色，那里就**确定没有物件**（物件盖上去会显示物件的色）。
      所以它既不是待解释的格，也不是万能牌。不减掉它的实测代价：菱形的一条臂盖住某个框顶边的一格，
      剩下六格恰好拟合成一条色 2 的短横线，`objects` 凭空多读出一个物件；臂让开之后生成器
      照这条假横线把那一格画成 2，真帧是底色——一步说错 1 格，而所有断言都判 TRUE。
    * **内部**：显示的是色块色，可**同色的物件压在上面也是这个色**，这一帧分不开。
      所以它不是证据（不该拿它拟合出物件），但要当万能牌（别的物件的臂可以从上面过），
      待遇和环心一样。不这么办的实测代价：菱形蹭色块变成色 8 之后，色块那 16 格和它连成一片，
      `objects` 读出一条色 8 的横线当第四个物件，`assign` 于是要给一个不存在的物件派落点，
      24 种先后全报「走不到」。
    """
    def calc(gg):
        lim = min(len(gg), HUD_ROW)
        wid = len(gg[0])
        edges, inner = set(), set()
        for r, c, n in _box_windows(gg):
            edge = [(r + a, c + b) for a in range(n) for b in range(n)
                    if a in (0, n - 1) or b in (0, n - 1)]
            edges |= {p for p in edge
                      if 0 <= p[0] < lim and 0 <= p[1] < wid and gg[p[0]][p[1]] == BOX_EDGE}
            inner |= {(r + 1 + a, c + 1 + b) for a in range(n - 2) for b in range(n - 2)
                      if 0 <= r + 1 + a < lim and 0 <= c + 1 + b < wid}
        return frozenset(edges), frozenset(inner)
    return _memo(g, "rawbox", calc)


def _objects(g):
    """从最上面一层往下剥：先只认「自己完全露着」的物件，再拿它们当遮挡物去认下面那一层。

    「别的东西盖住了，所以这一格看不见本色」这句话，只有在那个「别的东西」**是一个已经认下的物件**时才成立。
    早先的写法把「凡是别的颜色的格子」都当成万能牌，于是任何一块别色的家具都能替一个根本不存在的形状
    圆场——盘上出现与物件同色的装饰块时，装置会凭空多读出一个物件，而多读出来的物件会改掉
    ACTION5 的循环长度，也就是把读法的毛病算进判据里。
    每一轮的 `filled` 都是旧写法的子集，所以这一改只会读得更少、不会凭空读多。
    """
    lim = min(len(g), HUD_ROW)
    board = {(r, c) for r in range(lim) for c in range(len(g[0]))}
    rc = set(ring_centers(g))
    cur = cursor(g)
    cols = shape_colors(g)
    by_col = {c: _board_cells(g, c) for c in cols}
    furn, inner = _raw_boxes(g)       # 框边=确定没物件；内部 4×4=分不出来（见 `_raw_boxes`）
    blk = blockers(g)                 # 挡块是地形，不是物件（见概念 blocker_is_terrain）：
    # 不减掉它的代价是——挡块那几行本来长度都是偶数、凑不成横线，可某个物件的臂贴着它走过时，
    # 那一行的连续段被凑成奇数长度，装置当场把地形拟合成一条横线物件。
    # 凭空多一个物件会改掉 ACTION5 的循环长度，也就是把读法的毛病算进判据里，而 `unexplained` 不报警。
    known = {c: set() for c in cols}   # 上一轮认下的物件按颜色盖住的格子

    def read_col(col, size, relax):
        """认一种颜色：返回（挑中的物件, 它自己还剩几格没解释）。

        `relax=True` 时不查图层表，把**所有**已认下的物件都当万能牌——只在严格那一遍
        解释不完自己的格子时才试，而且要它解释得**更多**才作数（见调用处）。
        """
        S = by_col[col] - rc - furn - inner - blk
        filled = set(S) | rc | inner  # 环心与色块内部是万能牌：它们显示盖它的颜色，压没压着分不出来
        # 量尺子时，**正显示本色的环心**是一种半证据：它本来就显示这个颜色，单看它等于没看见，
        # 但整条边/整圈只由它和自己露着的格构成时，没有第二个物件参与解释（见 `_outer_ok`）。
        # 不给这个口子的代价：臂尖正好停在环心上时那条臂少量一格——而「臂尖停在环心上」
        # 正是要去的位形，不是罕见巧合。它不进 S：那是欠账表，环心不欠谁。
        soft = by_col[col] & rc
        hid = set()       # 已经认下的、压得过我的物件占住的格：它们替我看不见的那一段作证
        for c2 in cols:
            if c2 == col or (not relax and above(col, c2)):
                continue
            # 只有**已经认下的物件**盖住的格才是万能牌，而且它得压得过我：
            # 实测里我压得过它的那种颜色，它不可能替我的格子圆场（`above` 返回 None 的
            # 那些对是没实测过，照旧当万能牌用——那是无知，不是已知的「盖不住」）。
            # 不加这一句的代价：两条十字的横臂共线时，压在**上面**那条会把下面那条盖住的格
            # 当成自己被盖住的臂，往外多量一截，读出一个不存在的不对称十字。
            filled |= known[c2]
            hid |= known[c2]
        if cur is not None:
            filled.add(cur)       # 光标那一格也是万能牌：它压着的本色看不见
        uncov = set(S)
        picks, chosen, sz = [], [], dict(size)
        mlc = {}          # (kind,ctr) -> L。这一轮里 filled/S/board 都不变，量尺没必要重算 8 遍
        for _ in range(8):
            if not uncov:
                break
            best = None
            for cand in _cands(uncov, filled, g):
                if len(cand) == 3:
                    kind, ctr, L = cand          # rect：候选自带 L
                    if not _rect_ok(ctr, L, filled, S, board, soft, hid):
                        continue
                else:
                    kind, ctr = cand
                    if (kind, ctr) in mlc:
                        L = mlc[(kind, ctr)]
                    else:
                        L = mlc[(kind, ctr)] = _max_L(kind, ctr, filled, S, board, soft)
                    if L is None:
                        continue
                st = stamp(kind, ctr, L) & board
                if any(st <= prev_st for prev_st in chosen):
                    continue    # 已被某个收下的形状整个包住 —— 它不是独立物件，是那个形状的一部分
                gain = len(st & uncov)
                if gain == 0:
                    continue
                score = (-gain, KINDS.index(kind))
                if best is None or score < best[0]:
                    best = (score, (kind, ctr, L), st)
            if best is None:
                break
            kind, ctr, L = best[1]
            if sz.get(ctr, 0) >= len(best[2]):
                break           # 同一个中心已经收下不小于它的形状，别覆盖
            picks.append((ctr, kind, L, len(best[2])))
            sz[ctr] = len(best[2])
            chosen.append(best[2])
            uncov -= best[2]
        return picks, uncov

    out = {}
    for _round in range(4):
        out, size = {}, {}
        for col in cols:
            picks, left = read_col(col, size, False)
            if left:
                # 图层表是跨关攒的、按颜色索引的，而这个世界里物件会改色——同一对颜色在两关里
                # 可以给出相反的答案。所以「表说我压得过他」不许当成定论：它挡住的那些万能牌
                # 若能让我**多解释自己的几格**，那就是这一帧在反对这张表。
                # 为什么这个放宽买不来假物件：多认的格只从 `uncov`（我自己的格）里算，
                # 而当初立这条挡的那种毛病（臂顺着别人多量一截）多盖的全是**别人**的格，
                # 自己一格都不多解释，因此永远换不到这一次重读。
                picks2, left2 = read_col(col, size, True)
                if len(left2) < len(left):
                    picks = picks2
            for ctr, kind, L, n in picks:
                out[ctr] = (kind, col, L)
                size[ctr] = n
        nxt = {c: set() for c in cols}
        for ctr, bd in _bodies(g, out).items():
            nxt[out[ctr][1]] |= bd & board
        if nxt == known:
            break
        known = nxt
    return out


def objects(g):
    """{中心: (kind, 颜色, L)} —— 盘上所有物件，同色的也分得开。

    做法：每种颜色的格子（除掉环心）里反复挑「完全落在这些格子里、又能盖住最多还没被解释的格子」的形状，
    直到没有还没被解释的格子、或者挑不出来为止。挑不出来剩下的那些格子由 `unexplained` 报出来 —— 那是警报。
    """
    return _memo(g, "objs", _objects)


def unexplained(g):
    """哪些本该属于某个物件的格子，`objects` 解释不了。非空就是「盘上有我认不出的东西」。

    家具（色块与它的色 2 框）要减掉：它不是物件，认不出它不算读法有洞。
    第 4 关一开盘这个数是 180 = 5 个框的边 100 格 + 5 块色块 80 格，全部是家具。

    **挡块（色 1）也要减掉**：它是地形，不是物件。全语料里色 1 在盘上只出现过一种格子集合，
    一格没变过，也从没被任何物件盖住过——它不动，也不让别人穿过去（见概念 blocker_is_terrain）。
    把它算成「认不出的物件」的代价是实打实的：`translate_apply` 见到 unexplained 非空就整片闭嘴，
    于是有挡块的那几关，全册的生成器一格都不预测，E 的分母涨、分子不涨。
    读法说「我看不懂这块」和世界说「这块是地形」是两回事，这里改的是前者。
    """
    def calc(gg):
        rc = set(ring_centers(gg))
        lim = min(len(gg), HUD_ROW)
        board = {(r, c) for r in range(lim) for c in range(len(gg[0]))}
        left = set()
        for col in shape_colors(gg):
            left |= _board_cells(gg, col) - rc
        for bd in _bodies(gg, objects(gg)).values():
            left -= bd & board
        left -= set(furniture(gg))
        left -= blockers(gg)
        return frozenset(left)
    return _memo(g, "unexp", calc)


def occluders(g, ctr):
    """除了以 ctr 为心的那个物件，还有哪些物件的格子正盖在 ctr 这一格上。"""
    out = set()
    for c2, (k2, _col2, l2) in objects(g).items():
        if c2 != ctr and ctr in stamp(k2, c2, l2):
            out.add(c2)
    return out


def unmeasured_arms(g, ctr):
    """十字四条臂里，哪几条的长度是**补出来的**、不是量出来的（顺序同 DIRS4）；不是十字返回 None。

    判据只有一句：**臂尖那一头看不到底，这条臂就没量到底。** 三种看不到底：
      · 臂尖那一格没露出本色（被别人盖着，`_cross_L` 跨过去数出来的长度是猜的）；
      · 臂尖再往外一格已经出盘——盘边是裁不是挡（`edge_clips_arm`），
        画到盘边为止不代表臂就到此为止，真长度只有下界；
      · 臂尖再往外一格被别的物件盖着——臂可能在那底下接着长，看不见而已。

    后两种是**读数本身的上界不存在**，和第一种「中间那一截看不见」是同一件事的两头。
    那个值是推出来的一个猜测，对规划器有用，但它不是读数。凡是拿臂长跨帧相比、
    或者拿臂长重画下一帧的，落在这几条臂上的格子都不许算成读数。

    这条判据只问「这个值读不读得出来」，不问「盖住它的是谁」——
    同一个坑上一次是弃权表按催生它的那一帧的巧合写判据，这一次不重犯。
    """
    objs = objects(g)
    if ctr not in objs:
        return None
    kind, col, L = objs[ctr]
    if kind not in ("plus", "cross"):
        return None
    arms = (L, L, L, L) if isinstance(L, int) else L
    lim, wid = min(len(g), HUD_ROW), len(g[0])
    others = set()
    for c2, (k2, _c2, l2) in objs.items():
        if c2 != ctr:
            others |= stamp(k2, c2, l2)
    out = set()
    for i, (dr, dc) in enumerate(DIRS4):
        p = (ctr[0] + dr * arms[i], ctr[1] + dc * arms[i])
        if not (0 <= p[0] < lim and 0 <= p[1] < wid) or g[p[0]][p[1]] != col:
            out.add(i)
            continue
        q = (p[0] + dr, p[1] + dc)
        if not (0 <= q[0] < lim and 0 <= q[1] < wid) or q in others:
            out.add(i)
    return out


def bbox(kind, ctr, L):
    """理想形状的包围盒 (上, 下, 左, 右)。纯几何，不裁盘、不看帧。"""
    cells = _stamp_f(kind, ctr, L)
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    return (min(rs), max(rs), min(cs), max(cs))


def bbox_center(kind, ctr, L):
    """理想形状包围盒的中心那一格，行列各取 (min+max+1)//2（边长是偶数时靠下靠右的那一格）。

    对四下对称的形状（plus/ex/diamond/square/hline）它就等于形状自己的中心；
    只有四条边各自长短的 cross 和 rect 才和中心分得开。
    """
    r0, r1, c0, c1 = bbox(kind, ctr, L)
    return ((r0 + r1 + 1) // 2, (c0 + c1 + 1) // 2)


def can_bbox_center_be(g, kind, ctr, L, p):
    """把没量到底的臂当成**下界**之后，这件物件的包围盒中心有没有可能正落在 p 上。

    读到的臂长在没量到底的那一头只是下界（`unmeasured_arms` 的三种：臂尖没露本色、
    臂尖再往外出了盘、臂尖再往外被别人盖着）。包围盒中心是两头之差算出来的，
    有一头是下界，中心就不再是一格而是一段范围——问「等不等于」会在那种帧上必然答错，
    该问的是「可不可能等于」。**量到底的那几头照旧钉死**，所以这仍是一句能判错的话，
    不是「怎么都行」：四条臂都量到底时它就退回严格相等。

    只有 plus / cross 走这条宽路（`unmeasured_arms` 也只认这两种）；别的形状照旧严格相等。
    包围盒的行范围是 ctr-上臂 .. ctr+下臂，所以中心行 = ctr + (下臂-上臂+1)//2，
    要它等于 t 就是要 下臂-上臂 ∈ {2t-1, 2t}；列同理。
    """
    un = unmeasured_arms(g, ctr) or set()
    if not un:
        return bbox_center(kind, ctr, L) == p
    arms = (L, L, L, L) if isinstance(L, int) else L
    for axis, (lo, hi) in enumerate(((0, 1), (2, 3))):
        t = p[axis] - ctr[axis]
        v0 = arms[hi] - arms[lo]
        if not any(v == v0 or (v > v0 and hi in un) or (v < v0 and lo in un)
                   for v in (2 * t - 1, 2 * t)):
            return False
    return True


def active_center(g):
    """当前被操控的物件的中心。

    **光标指的是包围盒的中心，不是形状的中心**——四下对称的形状两者重合，看不出区别；
    十字被挡变形之后交点偏到一边、包围盒纹丝不动，光标跟着包围盒走。所以这里先按包围盒中心认人。
    旧读法（光标恰好落在某个物件的中心上）留作退路：包围盒中心认不出唯一一个时才用它。
    同色多物件的关里还有一种：中心被别的物件压住，光标整张盘都不露头（见概念 cursor_hidden_by_object）——
    这时当前物件就是「光标那一格被别的物件压着」的那一个；这样的物件不唯一就闭嘴，别猜。
    **被压的是包围盒中心那一格，不是形状中心那一格**：这两处早先写成了两句话，
    上面那一路按包围盒认人、退路按形状中心认人，四下对称的形状里两者重合，所以从来没分过岔；
    十字被挡变形之后交点偏到一边，退路当场认不出人——盘上有一个中心明明白白被压着，它却说「不知道」。
    同一个可读性判据分两处写、然后分岔，这一局已经吃过第三次了。
    「压着」要求那个物件**真的显示在**这一格上（这一格的颜色就是它的颜色）：
    两条十字互相穿过对方的中心时，两边的中心都「有别人的格子盖着」，可只有一边真的被盖住，
    另一边露着自己的本色——把它也算进来，两个候选一样多，认人当场弃权，全册跟着对那一帧闭嘴。
    **严格相等认不出人时，再按下界认一次**（`can_bbox_center_be`）：臂被挡住没量到底的那一头
    读出来短了一截，算出的包围盒心跟着偏，而世界把光标放在理想形状的包围盒心上，两者当场差一格。
    这一路只在严格那一路一个人都没认出来时才走，唯一命中才算数——认得宽一点，别认得多一点。
    """
    p = cursor(g)
    objs = objects(g)
    if p is not None:
        hit = [c for c, (k, _col, L) in objs.items() if bbox_center(k, c, L) == p]
        if len(hit) == 1:
            return hit[0]
        if not hit:
            loose = [c for c, (k, _col, L) in objs.items()
                     if can_bbox_center_be(g, k, c, L, p)]
            if len(loose) == 1:
                return loose[0]
        return p if p in objs else None
    lim, wid = min(len(g), HUD_ROW), len(g[0])
    hid = []
    for c, (k, _col, L) in objs.items():
        q = bbox_center(k, c, L)
        if not (0 <= q[0] < lim and 0 <= q[1] < wid):
            continue
        v = g[q[0]][q[1]]
        if any(col2 == v for c2, (k2, col2, l2) in objs.items()
               if c2 != c and q in stamp(k2, c2, l2)):
            hid.append(c)
    return hid[0] if len(hid) == 1 else None


def _cur_objs(g):
    """[(键, 颜色, kind, 中心, L)] —— 一颜色一物件成立时键是颜色（旧语义），否则键是中心。

    走 `shapes_total` 不走 `shapes`：后者可以**部分成立**（有与物件同色的家具时少装几个物件），
    那时它非空但不全，这里会静默地少报几个物件。
    """
    sh = shapes_total(g)
    if sh:
        return [(col, col, k, c, l) for col, (k, c, l) in sh.items()]
    return [(c, col, k, c, l) for c, (k, col, l) in objects(g).items()]


def _cur_stamps(g):
    """[(颜色, 形状格子集)]，当前帧。图层计算用。"""
    return [(col, stamp(k, c, l)) for _, col, k, c, l in _cur_objs(g)]


def active(g):
    """当前被操控的物件颜色 = 拟合中心恰好等于光标的那个；认不出来返回 None。

    颜色只有在「一颜色一物件」成立时才当得起物件的**键**，所以这里走 `shapes_total`：
    表装不下全部物件时一律返回 None，让靠颜色当键的概念闭嘴，而不是拿一个歧义的键接着算。
    """
    p = cursor(g)
    if p is None:
        return None
    hit = [col for col, (_, c, _) in shapes_total(g).items() if c == p]
    return hit[0] if len(hit) == 1 else None


def active_color(g):
    """老名字。"""
    return active(g)


BLOCKER = 1
"""**假设**：这个颜色的实心块挡得住物件——物件想平移到压着它的位置时，那一步不是纯平移。

它没走过闸（`_lib` 里的东西都没有），替它挨打的是引用 `will_block` 的那几条概念：
它们靠这个谓词决定什么时候闭嘴、什么时候开口，谓词划错了地方，它们就会在别处判错。
盘边不在里面：盘边是**裁**（形状照旧平移，伸出去的部分不画），不是**挡**。"""


def cur_shape(g):
    """当前物件的 (kind, 中心, L)；读不出来返回 None。"""
    c = active_center(g)
    if c is None:
        return None
    k, _col, L = objects(g)[c]
    return (k, c, L)


def blockers(g):
    """盘上所有挡块格。"""
    return frozenset(_board_cells(g, BLOCKER))


def will_block(g, delta):
    """当前物件整体按 delta 平移之后，理想形状会压到哪些挡块格；当前物件读不出来返回 None。

    空集 = 这一步平移不会撞上任何挡块。**返回 None 和返回空集是两回事**，别拿 `if not …` 一把捞。
    """
    sh = cur_shape(g)
    if sh is None:
        return None
    kind, (r, c), L = sh
    return frozenset(stamp(kind, (r + delta[0], c + delta[1]), L) & blockers(g))


def arm_len(g):
    """当前物件的半径 L；读不出来返回 None。"""
    col = active(g)
    if col is None:
        return None
    return shape_of(g, col)[2]


def kind_of(g, col=None):
    col = active(g) if col is None else col
    sh = shape_of(g, col) if col is not None else None
    return None if sh is None else sh[0]


def shape_cells(g, col):
    """物件 col 按理想形状生成、裁到盘内的全部格子（含中心；中心那一格可能是光标）。"""
    sh = shape_of(g, col)
    if sh is None:
        return None
    kind, center, L = sh
    return on_board(g, stamp(kind, center, L) | {center})


def cross_cells(g):
    """老名字：当前物件占的全部格子（含中心光标）。"""
    col = active(g)
    return None if col is None else shape_cells(g, col)


def arms(g):
    """老名字：当前物件除中心以外的格子，按方向分不再有意义，这里只返回一个集合。"""
    cs = cross_cells(g)
    if cs is None:
        return None
    return cs - {cursor(g)}


def other_centers(g):
    """{颜色: 中心}，只含**不是**当前物件的那些。"""
    col = active(g)
    return {c: sh[1] for c, sh in shapes_total(g).items() if c != col}


def other_center(g):
    """老名字：另一个物件的中心；恰好只有一个「别的物件」时才给答案。"""
    o = other_centers(g)
    return list(o.values())[0] if len(o) == 1 else None


def spent(g):
    """HUD 上已花掉的格数（色 1 的个数，只看 HUD_ROW 这一行）。"""
    return sum(1 for v in g[HUD_ROW] if v == HUD_SPENT)


def walls(g):
    """阻挡格集合。实测到第 1 关为止没撞出阻挡：盘边只裁形状不拦动作。"""
    return None


BOX_EDGE = 2           # 实测：色块外框的颜色（6×6 空心方框，里面 4×4 是色块本体）


def _boxes(g):
    """{(左上角行, 左上角列): 内部 (n-2)×(n-2) 的格集} —— 盘上的色 BOX_EDGE 方框。

    每个 n×n 位置看它那圈框边：至少 60% 还是色 2，**而且每一格不是色 2 的边格都被某个物件
    的形状盖着**（有解释才认）。内部取左上角 +(1,1) 起的 (n-2)×(n-2)。
    边长 n 由 `_box_windows` 逐个框给出，不是常数——要「整个框那一片」就用 `box_area(inner)` 反推。

    原来只认四个角（「四个角同时被压掉没见过」），漏了一种要命的情形：**一条斜臂正好压在角上**。
    那时整个框读不出来 → `swatches` 里没有它 → `swatch_hit` 说「没碰到色块」，
    而物件下一步恰恰走进这个框的色块里、当场变色。于是「碰到色块才变色」被自己的臂蒙住眼睛，
    变成一条反例。教训与 `shapes_total` 那条同源：**读法的沉默会被当成世界的否定**，
    所以「看不见」要有解释（被谁盖着），不能只是「没看见」。

    只给格集，不给颜色 —— 颜色读法见 `swatches`，因为内部可能正被物件盖着。
    """
    lim = min(len(g), HUD_ROW)
    wid = len(g[0])
    occ = set()
    for ctr, (k, _col, Ln) in objects(g).items():
        occ |= stamp(k, ctr, Ln)
    cur = cursor(g)
    if cur is not None:
        occ.add(cur)
    out = {}
    for r, c, n in _box_windows(g):     # 「边上至少 60% 还是色 2」等价于「不是色 2 的边格不超过 40%」
        bad = [(r + a, c + b) for a in range(n) for b in range(n)
               if (a in (0, n - 1) or b in (0, n - 1))
               and 0 <= r + a < lim and 0 <= c + b < wid
               and g[r + a][c + b] != BOX_EDGE]
        if any(p not in occ for p in bad):
            continue
        out[(r, c)] = frozenset((r + 1 + a, c + 1 + b)
                                for a in range(n - 2) for b in range(n - 2)
                                if 0 <= r + 1 + a < lim and 0 <= c + 1 + b < wid)
        if not out[(r, c)]:
            del out[(r, c)]          # 内部整块在盘外：认下它也读不出色块色
    return out


def boxes(g):
    return _memo(g, "boxes", _boxes)


def swatches(g):
    """{内部 4×4 格集: 色块颜色}；读不出来的框不进表。

    颜色取内部 16 格里**出现最多**的那个：物件的臂路过时最多盖掉其中几格，多数还是色块本色。
    并列（盖掉一半以上）就读不出来，那个框这一帧不进表——宁可少说。
    """
    out = {}
    for cells in boxes(g).values():
        hist = {}
        for (r, c) in cells:
            v = g[r][c]
            hist[v] = hist.get(v, 0) + 1
        top = sorted(hist.items(), key=lambda kv: -kv[1])
        if len(top) > 1 and top[0][1] == top[1][1]:
            continue
        out[cells] = top[0][0]
    return out


def swatch_hits(g, cells):
    """`cells` 压到了哪些色块**区域**，返回它们的颜色集合（一个都没压到就是空集）。

    区域是整个框那一片，**包括色 2 的边**，不只是里面那块色。
    由来：一次平移只有臂尖落在框的边上、离色块本体还差一格，世界照样把整个物件染成了那个颜色。
    框的边长不是常数（见 `box_area`），所以区域从内部反推，不按 6×6 写死。

    读不出颜色的框不算数（不在 `swatches` 里），那是「看不见」不是「不存在」。

    **为什么要这个而不只是 `swatch_hit`**：调用方必须分得清「一个色块都没压到」和
    「压到两个、说不清染成哪个」。这两件事在 `swatch_hit` 里都是 None，
    于是生成器把后者当成前者，照旧色画了整整一段路，每步说错几十格而断言全绿。
    问「碰没碰到」用这个函数的长度，问「染成什么色」才用 `swatch_hit`。
    """
    hit = set()
    for inner, col in swatches(g).items():
        if cells & box_area(inner):
            hit.add(col)
    return hit


def swatch_hit(g, cells):
    """`cells` 这组格子压到了哪个色块**区域**上，返回那个色块的颜色；说不出来返回 None。

    说不出来有**两种**，返回值一样，所以要问染色以外的事就别用它（用 `swatch_hits`）：
    一个色块都没压到；或者同时压到两个不同色块——那时染成哪个色没有可分辨的实测。

    全语料关内平移 336 条里，压到 0 个框的 329 条一条都没变色，压到 1 个框的 5 条全部染成那个框的色，
    压到 2 个框的 2 条（另有 1 条因残料被筛掉，共 3 次）全部落在**同一个位形**上，
    结果都是同一个框赢。一种局面采三次分不出规则：「上面那个框赢」「颜色数大的赢」「扫描序在前的赢」
    三条都拟合得同样好。所以这里不排次序——次序表要能说不知道。
    """
    hit = swatch_hits(g, cells)
    return hit.pop() if len(hit) == 1 else None



def furniture(g):
    """{格子: 它本来的颜色} —— 家具层：色块本体，加上色 2 的框。

    家具会被物件盖住、物件让开之后**原样复原**（实测：色 2 的框被十字压过又露出来，还是色 2）。
    没有它，`top_color` 会在物件让开的地方一律预测底色，而那里露出来的是家具。
    环框（色 4）不在这里：它有自己的概念 `rings_static`。
    框的边长不是常数，所以整片区域从 `box_area(inner)` 反推，别写死 6。

    **只给盘内的格**：框被盘边裁掉一截时 `box_area` 会反推出盘外的坐标，
    而负的行列在 Python 里会从另一头绕回来——那一格于是被拿去和盘另一侧的像素比，一比就「不符」。
    读法产出的每一个坐标都要先裁到盘内，别把「盘外」交给下游去发现。
    """
    lim = min(len(g), HUD_ROW)
    wid = len(g[0])
    out = {}
    for inner in boxes(g).values():
        for p in box_area(inner):
            if p not in inner and 0 <= p[0] < lim and 0 <= p[1] < wid:
                out[p] = BOX_EDGE
    for cells, col in swatches(g).items():
        for p in cells:
            if 0 <= p[0] < lim and 0 <= p[1] < wid:
                out[p] = col
    return out


def near_ring(g, cell, radius=1):
    """cell 是否紧挨着（切比雪夫距离 ≤ radius）任何一个环框格。

    用途：物件腾出来的格子若在环身上，底下露出来的不是底色 —— 生成器就该闭嘴。
    """
    r, c = cell
    for (rr, cc) in rings(g):
        if abs(rr - r) <= radius and abs(cc - c) <= radius:
            return True
    return False


# ---------- 落点与通关 ----------

def ring_owner(g, p):
    """环心 p 的归属色；被物件盖住时读不出来（返回 None）。

    盖住 = p 落在某个物件的理想形状上。此时那一格显示的是盖它的颜色，不是归属色 ——
    盖它的正好是它的主人（那就是通关时该有的样子）也一样分不出来，所以一律 None。
    归属色既用来规划路线，也是通关条件的一半（见 `would_win`）：几何盖住还不够，盖它的物件得跟它同色。
    正因为盖住之后就读不出来，这件事只能在**它刚被盖住的前一帧**问。

    遮挡表走 `_cur_objs` 而不是 `shapes`：`shapes` 只在「一颜色一物件」时非空，
    而盘上有与物件同色的家具（色块一类）时它就是空的——那时这个函数会一路走到最后，
    把**盖它的那个颜色**当成归属色返回。这个 bug 让 would_win 在一整关里都以为归属色读得出来。

    光标那一格单独挡一道：光标是色 0，而色 0 从来不是任何物件的颜色，
    所以「环心显示色 0」只可能是光标压在上面，归属色一格证据都没留下。
    形状的 `stamp` 未必含它自己的中心，光标又恰好贴在中心上，
    于是「被物件盖住」那一条查不到它——不补这一句，被光标压着的环心会把色 0 当成归属色报出去。
    """
    rc = ring_centers(g)
    if p not in rc:
        return None
    if rc[p] == CURSOR:
        return None
    for _key, _col, kind, center, L in _cur_objs(g):
        if p in stamp(kind, center, L) or p == center:
            return None
    return rc[p]


def owned_rings(g, col):
    """归属色读得出来、且归属为 col 的环心。"""
    return tuple(sorted(p for p in ring_centers(g) if ring_owner(g, p) == col))


def targets(g, col):
    """规划用：使「col 的（读得出来的）环心都落在这个物件的格子上」的中心们（可能不唯一）。

    用的是对称性：环心 w 落在以 p 为心的形状上 ⟺ p 落在以 w 为心的同形状上。
    所以候选 = 各个环心各自撒一个形状，取交集。
    **这是路线规划的辅助读数，不是通关判据** —— 环心被盖住时它会漏掉那个环。
    """
    sh = shape_of(g, col)
    if sh is None:
        return ()
    kind, _, L = sh
    want = list(owned_rings(g, col))
    if not want:
        return ()
    cand = None
    for w in want:
        s = stamp(kind, w, L) | {w}
        cand = s if cand is None else (cand & s)
    lim = min(len(g), HUD_ROW)
    return tuple(sorted(p for p in cand
                        if 0 <= p[0] < lim and 0 <= p[1] < len(g[0])
                        and set(want) <= stamp(kind, p, L)))


def aligned(g, col):
    """物件 col 是否已经盖住了它（读得出来的）全部环心；读不出来返回 None。"""
    sh = shape_of(g, col)
    ts = targets(g, col)
    if sh is None or not ts:
        return None
    return sh[1] in ts


def covered_rings(g, moved=None):
    """哪些环心被某个物件的格子盖住了。

    `moved=(col, center)` 表示把物件 col 的中心当成 center 来算（用来问「走完这一步之后」）。
    这个读数**遮挡免疫**：只看几何覆盖，不读环心那一格显示什么颜色。
    **它是通关的必要条件，不是充分条件**——还要盖它的物件跟它同色，见 `would_win`。
    只数物件自己的格子：斜叉与菱形的中心不算它们的格子（见 `stamp`），所以环心正好落在那两种物件的中心上
    算不算盖住，这里的答案是「不算」——没实测过，等哪天真撞上，`no_levelup_unless_aligned` 会先叫。
    """
    out = set()
    rc = ring_centers(g)
    for key, col, kind, center, L in _cur_objs(g):
        if moved is not None and key == moved[0]:
            center = moved[1]
        st = stamp(kind, center, L)
        out |= {p for p in rc if p in st}
    return out


def win_now(g):
    """当前是不是「每个环心都被某个物件盖住」；盘上读不出环或物件时返回 None。

    **这只是通关的几何那一半，不是通关条件本身**——见 `would_win` 的说明。
    """
    rc = ring_centers(g)
    if not rc or not _cur_objs(g):
        return None
    return len(covered_rings(g)) == len(rc)


def after_move(g, d):
    """当前物件平移 d 之后，(键, 中心) 的新读数；读不出来返回 None。

    键的含义跟着 `_cur_objs` 走：一颜色一物件时是颜色，同色多物件时是原来的中心。
    同色多物件那一路走 `active_center`，因为光标可能正被别的物件压着（见概念 cursor_hidden_by_object）——
    这时 `cursor` 返回 None 而当前物件仍然认得出来。
    """
    if shapes_total(g):
        p = cursor(g)
        if p is None:
            return None
        col = active(g)
        if col is None:
            return None
        return col, (p[0] + d[0], p[1] + d[1])
    p = active_center(g)
    if p is None:
        return None
    return p, (p[0] + d[0], p[1] + d[1])


def newly_covered_rings(g, d):
    """这一步之后**新**被盖住的环心：在 g 里还露着（所以归属色读得出来），走完这一步被盖住。

    「新盖住」这件事之所以值钱：环心一旦被盖住，归属色就永远读不出来了（那一格显示的是盖它的颜色），
    而它**刚被盖住的前一帧**一定还露着。所以要问「盖它的物件颜色对不对」，只有这一帧问得出来。
    """
    mv = after_move(g, d)
    if mv is None:
        return None
    before = covered_rings(g)
    return tuple(sorted(covered_rings(g, moved=mv) - before))


def _moving_color(g):
    """这一步要动的那个物件的颜色；读不出来返回 None。"""
    if shapes_total(g):
        return active(g)
    a = active_center(g)
    objs = objects(g)
    return objs[a][1] if a in objs else None


def covering_color(g, p, d=None):
    """走完这一步之后，盖住环心 p 的那个物件是什么颜色；没人盖或说不准返回 None。"""
    mv = after_move(g, d) if d is not None else None
    hit = set()
    for key, col, kind, center, L in _cur_objs(g):
        if mv is not None and key == mv[0]:
            center = mv[1]
        if p in stamp(kind, center, L):
            hit.add(col)
    return hit.pop() if len(hit) == 1 else None


def would_win(g, d, owners=None):
    """平移 d 之后这一步是不是该过关。读不出来返回 None。

    两个条件都要：**几何上**每个环心都被物件盖住，**而且**每个环心都被**与它同色**的物件盖住。

    颜色这一半是被打出来的：曾经有一关，六个环心全被几何盖住（三个归属色 A 的被一个物件盖住、
    三个归属色 B 的被另一个盖住，分组还分对了），但两个物件的颜色都不在归属色里，那一步**没有过关**。
    在那之前的每一关，物件的颜色恰好等于环的归属色，所以「只看几何」和「还要看色」给出的预测处处相同，
    册子里写的是前者，而它从没被分开检验过——这就是恒真概念长什么样。

    **死角是世界层面的，不是读法不够好**：环心一旦被盖住，那一格显示的是盖它的颜色，
    归属色不再出现在帧里；实测同色盖住与错色盖住的环，环框和 5×5 邻域一模一样，没有可见凭据。
    所以「盘上还有没有色不对的环」这句话，从一帧里问不出来。第二次被打出来的就是这一条：
    六环全被盖住、这一步新盖住的两个都同色，却没过关——因为另外三个早先就被错色盖着了。

    于是这个函数分两条路走：
    - `owners=None`（概念走这条）：只有**所有**环心的归属色都在 g 里读得出来时才敢下判断，
      否则返回 None。概念只看得见 (prev, action, nxt)，它没有别的信息来源，装不知道就是不知道。
    - `owners={环心: 归属色}`（规划器走这条）：调用方从更早的帧里读来的归属色。
      开关那一帧六个环都还露着，所以规划器读得到；这不是概念的主张，是计划的输入，
      对不对由押注去核。
    """
    mv = after_move(g, d)
    rc = ring_centers(g)
    if mv is None or not rc:
        return None
    if len(covered_rings(g, moved=mv)) != len(rc):
        return False
    known = {}
    for p in rc:
        own = owners.get(p) if owners else ring_owner(g, p)
        if own is None:
            return None                      # 归属色读不出来：不猜，也不只核新盖住的那几个
        known[p] = own
    for p, own in known.items():
        cov = covering_color(g, p, d)
        if cov is None:
            return None
        if cov != own:
            return False
    return True


def levelup_excluded(g, d):
    """能不能**纯凭几何**排除掉「平移 d 这一步会过关」。排得掉返回 True。

    生成器要的只是这一半。`would_win` 的完整判断有一个世界层面的死角（归属色被盖住后帧里没有凭据），
    于是它在第 3 关之后的绝大多数局面上返回 None；生成器要是拿「排除不了」当闭嘴的理由，
    就会在**整整一关**里一格都不画——那不是谨慎，那是把「我不知道有没有过关」记成「我什么都不必说」，
    E 掉下去、说错也跟着掉，无知被记成了成绩。

    几何覆盖不受遮挡影响（`covered_rings` 只看理想形状），所以「环心有没有盖满」一帧就答得出来。
    没盖满 ⇒ 一定不过关 ⇒ 帧不会整张换掉 ⇒ 照常画。盖满了才闭嘴，那种局面语料里屈指可数。
    """
    mv = after_move(g, d)
    rc = ring_centers(g)
    if mv is None or not rc:
        return False
    return len(covered_rings(g, moved=mv)) != len(rc)


# ---------- 生成器 ----------

def _z(col):
    return ZORDER.index(col) if col in ZORDER else 99


def frame_above(g):
    """这一帧上**直接量到**的「谁压谁」：两件物件的理想形状交叠的那几格，显示的是谁的颜色。

    只放这一帧数得出来的对。一对在这一帧的不同格上给出相反方向就整对丢掉——那把尺在这里失效，
    挑多数就是替世界拿主意。交集格显示第三个颜色（光标色、第三件物件的色）的不投票。

    这是**观测**，不是表：`ABOVE` 是跨关攒出来的，而物件碰到色块会整件改色，
    同一个颜色号在两关里未必是同一件东西。量它不用花一步——重叠已经摆在盘上了。

    **光标那一格也是一次读数，而且是这一帧最常见的一次。** 光标贴在当前物件那一层
    （走过闸的 `cursor_hidden_by_object`），所以当它落在别人的理想形状里时：
    露出光标色 = 当前物件压得过那位，显示那位的本色 = 那位压得过当前物件。
    原来这一格被当成「第三个颜色」丢掉了，而两件**同形状**的物件相交时它常常是唯一的交点——
    形状序对同形状说不出话，颜色序又因为这一格没投票而空着，于是全册对新光标那一格弃权，
    批次被钉在两步。丢掉的不是噪声，是这一帧唯一说得出口的那句话。
    """
    def calc(gg):
        objs = objects(gg)
        items = list(objs.items())
        votes = {}
        for i in range(len(items)):
            c1, (k1, col1, l1) = items[i]
            st1 = stamp(k1, c1, l1)
            for j in range(i + 1, len(items)):
                c2, (k2, col2, l2) = items[j]
                if col1 == col2:
                    continue
                for (r, c) in st1 & stamp(k2, c2, l2):
                    if not (0 <= r < len(gg) and 0 <= c < len(gg[0])):
                        continue
                    v = gg[r][c]
                    if v == col1:
                        votes.setdefault((col1, col2), set()).add(0)
                    elif v == col2:
                        votes.setdefault((col1, col2), set()).add(1)
        p = cursor(gg)
        ctr = active_center(gg)
        if p is not None and ctr in objs:
            mine = objs[ctr][1]
            for c2, (k2, col2, l2) in objs.items():
                if c2 == ctr or col2 == mine:
                    continue
                if p not in stamp(k2, c2, l2):
                    continue
                v = gg[p[0]][p[1]]
                if v == CURSOR:
                    votes.setdefault((mine, col2), set()).add(0)
                elif v == col2:
                    votes.setdefault((mine, col2), set()).add(1)
        out = set()
        for (a, b), s in votes.items():
            if s == {0}:
                out.add((a, b))
            elif s == {1}:
                out.add((b, a))
        return frozenset(out)
    return _memo(g, "fabove", calc)


def recolor_order(g, old_col, new_col):
    """把这一帧直接量到的、关于 `old_col` 的上下关系，原样搬到 `new_col` 头上。

    生成器要画「这个物件碰了色块、整件从 old_col 变成 new_col」之后的那一帧，
    可这一帧的直接读数（`frame_above`）说的全是 old_col 和别人的次序，新颜色一格证据都没有——
    退回跨关攒的 `ABOVE` 就等于换了把尺，而那把尺的键（颜色）在这个世界里不稳。

    搬过来靠的是一句话：**改色不改图层**（图层是物件自己的属性，颜色只是它此刻的显示）。
    这句话不是自明的，所以它单独写成了一条走闸的概念（`recolor_keeps_zorder`）；
    这里只是把它用起来。old_col == new_col（没碰色块）时它退化成空集，一个字都不多说。
    """
    if old_col == new_col:
        return frozenset()
    out = set()
    for (a, b) in frame_above(g):
        if a == old_col:
            out.add((new_col, b))
        elif b == old_col:
            out.add((a, new_col))
    return frozenset(out)


def moved_zx(g, kind, ctr_new, L, col):
    """当前物件挪/变形到 (kind, ctr_new, L) 之后，画那一帧该用的有向上下对，以及它那时的颜色。

    返回 `(zx, new_col)`；压到两个色块时返回 `(None, None)`——染成哪个色没有可分辨的实测。
    `zx` = 这一帧直接量到的（`frame_above`）+ 改色之后搬过来的（`recolor_order`）。

    单写这一个函数是因为**同一个量在两处各算一次就会分岔**：生成器画整片格子、
    概念只画光标那一格，两边要是各自决定「查哪张次序表」，迟早在某一帧上给出不同的颜色，
    而断言全绿、只有逐格预测会疼。
    """
    hits = swatch_hits(g, stamp(kind, ctr_new, L))
    if len(hits) > 1:
        return None, None
    new_col = hits.pop() if hits else col
    return frame_above(g) | recolor_order(g, col, new_col), new_col


def top_color(g, cell, where, extra=None):
    """在「各物件按 where 摆放」的假想局面里，cell 这一格该显示什么颜色；说不准返回 None。

    图层从上到下：物件（彼此按 `ABOVE` 偏序，`top_of` 定不下来就闭嘴；光标贴在当前物件那一层）
    > 环（框是色 4、心是归属色） > 家具（色块与它的色 2 框） > 底色。
    说不准的有两处：**此刻正被压着、挪开之后要露出来的环心**（归属色被盖住时读不出来），
    以及**两个颜色的上下关系没实测过**的重叠格。

    `where` 是 {颜色: 形状格子集}，调用方自己算好（用来问「走完这一步之后」）。

    环心那一条交给 `ring_owner` 去答，不再自己数遮挡：这里原来只查 `_cur_stamps`，
    而形状的 `stamp` 未必含它自己的中心、光标又正贴在中心上，于是「物件的中心恰好压在环心上」
    这一类局面查不出遮挡，把环心此刻显示的**光标色**当成归属色画了出去——
    生成器说错一格，而断言全绿（断言只问中心动了没有）。两处判「读不读得出来」，只该有一处。

    `extra` 给调用方补这一帧读不到的有向对（当前物件改了色时用 `recolor_order` 搬过来）；
    不给就只用这一帧直接量到的那些。
    """
    if extra is None:
        extra = frame_above(g)
    over = [c for c, st in where.items() if cell in st]
    if over:
        return top_of(over, extra)
    if cell in ring_border(g):
        return RING_EDGE
    if cell in ring_centers(g):
        return ring_owner(g, cell)           # 读不出来（被压着 / 光标贴着）就闭嘴
    fur = furniture(g)
    if cell in fur:
        return fur[cell]                     # 家具层：物件让开之后原样复原（见 furniture_restores）
    return BG


def pinned_arms(g, ctr):
    """当前物件的四条臂，其中没量到底的那几条夹到「与光标相容的最短长度」。

    读法量到的臂长在没量到底的那一头只是下界。光标是包围盒心的一次**直接观测**
    （见概念 cursor_is_bbox_center），把它和量到底的那条对臂放在一起，
    对面那条没量到底的臂就被夹进一个只有两格宽的区间：中心公式 (min+max+1)//2 让相邻两个长度
    给出同一个中心，所以夹得到的是两个值，不是一个。取其中**短的那个**——
    比它短的与光标矛盾，比它长的这一帧分不出来；分不出来的那一截照旧按「没量到底」不认领。

    只夹当前物件：光标只说了它一个人的包围盒心，别人的臂它一个字没说。
    一条轴上两头都没量到底时不夹（一个方程两个未知数），照还读到的下界。

    由来：十字被挡变形后左臂整截藏在别人身下，读到 14 其实是 15。
    按 14 重画，变形律算出的新交点、新臂尖、新光标位置一起偏一格——**律没错，喂给它的输入是下界**。
    这个病此前已经在同一条律上发作过一次，那一次的处理是掐掉最没把握的一档；
    这一次把光标这条现成的约束用上，不掐反而夹得更紧。
    """
    objs = objects(g)
    if ctr not in objs:
        return None
    _kind, _col, L = objs[ctr]
    if isinstance(L, int):
        return L                             # 四下对称的形状：四条臂本来就一样长，夹不出新东西，
                                             # 也不许把它变成四元组——下游按整数用它
    arms = list((L, L, L, L) if isinstance(L, int) else L)
    un = unmeasured_arms(g, ctr) or set()
    p = cursor(g)
    if not un or p is None or active_center(g) != ctr:
        return tuple(arms)
    for axis, (lo, hi) in enumerate(((0, 1), (2, 3))):
        if lo in un and hi in un:
            continue
        t = p[axis] - ctr[axis]
        cand = (2 * t - 1, 2 * t)
        if lo in un:
            ok = [v for v in cand if arms[hi] - v >= arms[lo]]
            if ok:
                arms[lo] = arms[hi] - max(ok)
        elif hi in un:
            ok = [v for v in cand if arms[lo] + v >= arms[hi]]
            if ok:
                arms[hi] = arms[lo] + min(ok)
    return tuple(arms)


def arm_upper(g, ctr):
    """四条臂长度的**上界**（顺序同 DIRS4）；夹不住的那条是 None（这一帧没有上界）。

    和 `pinned_arms` 是同一把尺的两头：那边取与光标相容的最短，这边取最长。
    两头合起来才是这一帧对臂长知道的全部——而**区间常常宽度为 0**：
    读到的长度本身是下界，光标给的两个候选里比它短的那个当场出局，剩下一个值就定死了。

    用处只有一个：**弃权要弃在区间上，不是弃在下界之外的一切**。
    按下界之外一律不认领，会把「明明已经定死了的那几格」也扔掉；
    代价不是分数，是链式预测每一步都留着几格空白，批次因此被切成单步。
    （由来：十字的一条臂正好顶在盘边上，读到的长度与光标夹出来的上界相等——
    也就是说它已经定死了——而生成器照旧整条不认领，一批只走得了一步。）

    上界有**两个来源**，取更紧的那个：
      · **看得见的挡**：臂只能长在「露着自己本色」或者「被别人盖住」的格子上。
        沿着射线往外走，第一格露着别的东西（底色、环、家具）的地方就是硬停——
        臂是连着的，它到不了那一格，也就到不了更外面。这一个对**每件物件**都成立，
        不管它是不是当前那件；走到盘边为止都没遇上挡的，这一头照旧没有上界（盘边是裁不是挡）。
      · **光标**：只对当前物件成立（光标只说了它一个人的包围盒心）。
    第一个来源是后补的：原来只有光标那一条，于是**不动的那件物件**的没量到底的臂
    永远没有上界，生成器在它臂尖外面整条射线上不认领——而它挪开之后露出来的那一格
    其实只有两种可能，早就被盘上现成的东西夹死了。
    """
    objs = objects(g)
    if ctr not in objs:
        return None
    _kind, _col, L = objs[ctr]
    if isinstance(L, int):
        return (L, L, L, L)                  # 四下对称：读到的就是它，没有没量到底的一说
    arms = list(L)
    un = unmeasured_arms(g, ctr) or set()
    out = [None if i in un else arms[i] for i in range(4)]
    if not un:
        return tuple(out)
    lim, wid = min(len(g), HUD_ROW), len(g[0])
    others = set()
    for c2, (k2, _c2, l2) in objs.items():
        if c2 != ctr:
            others |= stamp(k2, c2, l2)
    p = cursor(g)
    for i in un:                             # 来源一：看得见的挡（每件物件都算）
        dr, dc = DIRS4[i]
        k = arms[i]
        blocked = False
        while True:
            q = (ctr[0] + dr * (k + 1), ctr[1] + dc * (k + 1))
            if not (0 <= q[0] < lim and 0 <= q[1] < wid):
                break                        # 走到盘边都没遇上挡：这一头没有上界
            v = g[q[0]][q[1]]
            if v != _col and q not in others and q != p:
                blocked = True
                break
            k += 1
        if blocked:
            out[i] = k if out[i] is None else min(out[i], k)
    if p is None or active_center(g) != ctr:
        return tuple(out)
    for axis, (lo, hi) in enumerate(((0, 1), (2, 3))):   # 来源二：光标（只对当前物件）
        if lo in un and hi in un:
            continue                         # 一个方程两个未知数：这条轴上给不出上界
        t = p[axis] - ctr[axis]
        cand = (2 * t - 1, 2 * t)
        if lo in un:
            ok = [v for v in cand if arms[hi] - v >= arms[lo]]
            if ok:
                v = arms[hi] - min(ok)
                out[lo] = v if out[lo] is None else min(out[lo], v)
        elif hi in un:
            ok = [v for v in cand if arms[lo] + v >= arms[hi]]
            if ok:
                v = arms[lo] + max(ok)
                out[hi] = v if out[hi] is None else min(out[hi], v)
    return tuple(out)


def unreadable_beyond(g, objs, moved=None):
    """越过某条「没量到底」的臂之后、又还没超过它上界的那些格子——这一帧谁都读不出那儿有没有东西。

    `moved = (旧心, 新心, 新臂长)`：当前物件这一步挪走了，它的射线要从新位置画；
    别人原地不动，从自己的心画。臂长与上界都按**这一帧**的读数（读数就是在这一帧上取的）。

    这一条原来只对当前物件做，于是**不动的那件**的没量到底的臂一直在替生成器背书：
    它的臂尖被当前物件盖着，读数短了一截，生成器就把当前物件让开之后露出来的那一格
    判成了底色——实测那儿是它的本色。**「读数是下界」对盘上每一件东西都成立，
    不只对正在动的那一件。**
    """
    out = set()
    for c2, (_k2, _col2, l2) in objs.items():
        un = unmeasured_arms(g, c2)
        if not un:
            continue
        base, L2 = c2, l2
        if moved and c2 == moved[0]:
            base, L2 = moved[1], moved[2]
        hi_of = arm_upper(g, c2) or (None, None, None, None)
        arms = (L2, L2, L2, L2) if isinstance(L2, int) else L2
        for i in un:
            dr, dc = DIRS4[i]
            top = hi_of[i]
            k = arms[i] + 1
            while on_board(g, {(base[0] + dr * k, base[1] + dc * k)}) and (top is None or k <= top):
                out.add((base[0] + dr * k, base[1] + dc * k))
                k += 1
    return out


def _translate_apply_obj(g, d):
    """同色多物件世界里的平移生成器。与 `translate_apply` 一字不差的图层规矩，只是物件按中心索引。

    光标那一格单独算：它贴在**包围盒的中心**上，不在形状自己的中心上（见概念 cursor_is_bbox_center）。
    四下对称的形状两者重合，所以这一处写错了也能一路全对几百步；
    十字被挡变形成不对称之后当场分岔——实测代价是每一步稳定说错 2 格：
    把光标画在交点上，又把交点那一格画成了物件本色。断言全绿，因为断言不问生成器画了什么。

    **量不到底的那条臂，射线上超出新臂尖的格子一律不认领**（`unmeasured_arms`）：
    读到的臂长在那一头只是下界，按下界重画会把世界随后画出来的真臂那一截判成底色。
    这条裁剪只裁**新位置**的射线：不确定的只是「新的臂能伸多远」，旧位置那一片让开之后是什么，
    和臂长无关。实测这类错落在「物件从盘边往里挪一步、被裁掉的那截露出来」的那一步上。
    """
    ctr = active_center(g)
    if ctr is None:
        return None
    objs = objects(g)
    kind, col, L = objs[ctr]
    if kind in ("plus", "cross"):
        L = pinned_arms(g, ctr) or L         # 没量到底的臂先按光标夹紧，别拿下界当读数
        objs = dict(objs)
        objs[ctr] = (kind, col, L)
    q = (ctr[0] + d[0], ctr[1] + d[1])
    cur_old = bbox_center(kind, ctr, L)      # 光标的旧位置：包围盒中心，未必是 ctr
    cur_new = bbox_center(kind, q, L)        # 平移之后的包围盒中心
    if not on_board(g, {q}) or not on_board(g, {cur_new}):
        return None
    if not levelup_excluded(g, d):
        return None                          # 几何上排除不掉过关就闭嘴：过关会换整帧
    where = {}
    bodies = _bodies(g, objs)
    zx, new_col = moved_zx(g, kind, q, L, col)
    if zx is None:
        return None                          # 压到两个色块：染成哪个色没有可分辨的实测，整步闭嘴
    for c2, (k2, col2, l2) in objs.items():
        if c2 == ctr:
            st = stamp(k2, q, l2) | {cur_new}  # 光标贴在当前物件那一层
            col2 = new_col                   # 碰到色块 → 整个物件换色
        else:
            st = bodies[c2]                  # 不动的物件：填着本色的中心也挡得住别人的臂
        where[col2] = where.get(col2, set()) | st
    old = on_board(g, stamp(kind, ctr, L) | {cur_old})
    new_cells = on_board(g, stamp(kind, q, L) | {cur_new})
    out = {}
    for cell in old | new_cells:
        v = top_color(g, cell, where, zx)
        if v is not None:
            out[cell] = v
    for cell in ambiguous_centers(g, objs):
        if cell != ctr:
            out.pop(cell, None)              # 那一格下面是什么，这一帧没人知道（见 ambiguous_centers）
    for cell in unreadable_beyond(g, objs, (ctr, q, L)):
        out.pop(cell, None)                  # 谁的臂没量到底，谁臂尖外面那一段就不认领——
                                             # 是长是短这一帧读不出来；上界之外是定死的，照旧认领
    v = cursor_cell_color(g, objs, ctr, cur_new, zx)
    if v is None:
        out.pop(cur_new, None)               # 光标格排不出上下（见 cursor_cell_color）
    else:
        out[cur_new] = v
    return out


def deform_apply(g, kind2, ctr2, L2):
    """生成器用：当前物件**原地变形**成 (kind2, ctr2, L2) 之后，它敢主张的那些格子。

    和 `_translate_apply_obj` 同一套图层规矩，区别只有一条：新形状由调用方给，
    而不是「同一个形状挪了 d」。撞挡块的两条形变律各自算得出新形状（十字：包围盒不动、交点移 CELL；
    空心矩形：迎面边钉住、`predict_bbox`），缺的只是把新形状画回帧上的这段手续。
    没有它，撞挡块那一步全册只剩家具概念开口，E 一格不涨；更贵的是链式假帧停在旧形状上，
    这一批从那一步之后每一步都在搬一个已经不存在的形状——所以撞挡块的步一直只能放在批尾。

    「排除不掉过关就闭嘴」这道门这里自己算，不走 `levelup_excluded`：
    那一条问的是「平移 d 之后」，而这里形状本身换了，环心覆盖要按新形状数。
    """
    if unexplained(g):
        return None
    ctr = active_center(g)
    if ctr is None:
        return None
    objs = objects(g)
    kind, col, L = objs[ctr]
    if kind in ("plus", "cross"):
        L = pinned_arms(g, ctr) or L         # 没量到底的臂先按光标夹紧，别拿下界当读数
        objs = dict(objs)
        objs[ctr] = (kind, col, L)
    cur_old = cursor(g) or bbox_center(kind, ctr, L)   # 光标的旧位置是看得见的，不用算
    cur_new = bbox_center(kind2, ctr2, L2)
    new_st = stamp(kind2, ctr2, L2)
    if not on_board(g, {ctr2}) or not on_board(g, {cur_new}):
        return None
    rc = ring_centers(g)
    if not rc:
        return None                          # 读不出环心就排除不掉过关
    covered = set()
    for c2, (k2, _col2, l2) in objs.items():
        st2 = new_st if c2 == ctr else stamp(k2, c2, l2)
        covered |= {p for p in rc if p in st2}
    if len(covered) == len(rc):
        return None                          # 几何上排除不掉过关：过关会换整帧
    zx, new_col = moved_zx(g, kind2, ctr2, L2, col)
    if zx is None:
        return None                          # 压到两个色块：染成哪个没有可分辨的实测
    where = {}
    bodies = _bodies(g, objs)
    for c2, (k2, col2, l2) in objs.items():
        if c2 == ctr:
            st = new_st | {cur_new}          # 光标贴在当前物件那一层
            col2 = new_col
        else:
            st = bodies[c2]
        where[col2] = where.get(col2, set()) | st
    old = on_board(g, stamp(kind, ctr, L) | {cur_old})
    new_cells = on_board(g, new_st | {cur_new})
    out = {}
    for cell in old | new_cells:
        v = top_color(g, cell, where, zx)
        if v is not None:
            out[cell] = v
    for cell in ambiguous_centers(g, objs):
        if cell != ctr:
            out.pop(cell, None)              # 那一格下面是什么，这一帧没人知道
    for cell in unreadable_beyond(g, objs, (ctr, ctr2, L2)):
        out.pop(cell, None)                  # 谁的臂没量到底，谁臂尖外面那一段就不认领
    v = cursor_cell_color(g, objs, ctr, cur_new, zx)
    if v is None:
        out.pop(cur_new, None)
    else:
        out[cur_new] = v
    return out


def occluders_at(objs, active_ctr, cell, g=None):
    """在 objs 里，除了 active_ctr 那个物件之外，还有谁的格子盖在 cell 上。

    同色多物件的关里 `where` 按颜色收拢，图层信息在那一步就丢了，所以要单独问一次。

    给了 `g` 就按 `_body` 算「这一帧实际占住的格」（填着本色的中心也算它的），
    不给就只按理想形状 `stamp` 算。两者的差只在「中心那一格」上，
    问的是不同的问题：形状上归谁 / 这一帧看起来归谁。
    """
    if g is None:
        return {c2 for c2, (k2, _col2, l2) in objs.items()
                if c2 != active_ctr and cell in stamp(k2, c2, l2)}
    bodies = _bodies(g, objs)
    return {c2 for c2 in objs if c2 != active_ctr and cell in bodies[c2]}


def translate_apply(g, d):
    """生成器用：把当前物件整体平移 d=(dr,dc) 后，它敢主张的那些格子。

    只算「动过的那一片」——旧形状 ∪ 新形状——每一格交给 `top_color` 按图层算。
    形状裁到盘内（实测：盘边裁形状，不拦动作）。这一步若该过关（`would_win`），整帧会被换掉，生成器闭嘴。
    一颜色一物件读不出来时（同色多物件的关）转走 `_translate_apply_obj`。

    **`unexplained` 非空就整个闭嘴**：那说明盘上有 `objects` 认不出的东西，
    而这个生成器要按「盘上有哪些物件、谁压谁」重画一整片格子——底稿缺了一个物件，画出来的每一格都是猜的。
    实测代价：两个同色物件的中心重合时（一个恰好停在另一个的心上），`objects` 只读出大的那个，
    生成器于是搬错物件，一步说错 89 格，而断言全绿——断言只问「中心动了没有」，不问盘上有几个物件。
    全语料 608 张帧里 `unexplained` 非空的 4 张，闭嘴的代价就是这 4 张。

    **量不到底的那条臂，射线上超出新臂尖的格子一律不认领**（`unmeasured_arms`）：
    臂长是下界时，这里按下界重画，超出去的那一截会被判成底色或别人的颜色，
    而世界会把真臂画在那里。这不是断言错了——断言只问中心动没动，那几格它一句话都没说；
    错的是生成器拿一个**猜出来的长度**当读数用。少认领这几格，比认领错要诚实。
    """
    if unexplained(g):
        return None
    if not shapes_total(g):
        return _translate_apply_obj(g, d)
    col, p = active(g), cursor(g)

    if col is None or p is None:
        return None
    sh = shape_of(g, col)
    if sh is None:
        return None
    kind, center, L = sh
    q = (center[0] + d[0], center[1] + d[1])
    cur_new = (p[0] + d[0], p[1] + d[1])     # 光标贴包围盒中心，平移时和形状中心同步挪
    if not on_board(g, {q}) or not on_board(g, {cur_new}):
        return None                          # 中心自己出盘：没实测过，不敢说
    if not levelup_excluded(g, d):
        return None                          # 几何上排除不掉过关就闭嘴：过关会换整帧
    if swatch_hits(g, stamp(kind, q, L)):
        return None                          # 变色要重排图层的键，这条路上没实测过：不敢画
                                             # 用 hits 不用 hit：压到两个色块时 hit 也是 None，
                                             # 那时更不敢画，别让「说不清」漏成「没碰到」
    _bd = _bodies(g, {ctr2: (k2, c2, l2) for c2, (k2, ctr2, l2) in shapes_total(g).items()})
    where = {c2: (stamp(k2, q, l2) if c2 == col else _bd[ctr2])
             for c2, (k2, ctr2, l2) in shapes_total(g).items()}
    where[col] = where[col] | {cur_new}      # 光标贴在当前物件那一层，跟它一起被更上层的物件压
    old = on_board(g, stamp(kind, center, L) | {p})
    new_cells = on_board(g, where[col])
    out = {}
    for cell in old | new_cells:
        v = top_color(g, cell, where)
        if v is not None:
            out[cell] = v
    hi_of = arm_upper(g, center) or (None, None, None, None)
    for i in (unmeasured_arms(g, center) or ()):
        dr, dc = DIRS4[i]
        reach = ((L, L, L, L) if isinstance(L, int) else L)[i]
        top = hi_of[i]
        k = reach + 1
        while on_board(g, {(q[0] + dr * k, q[1] + dc * k)}) and (top is None or k <= top):
            out.pop((q[0] + dr * k, q[1] + dc * k), None)
            k += 1                           # 弃权只弃在上界以内：上界之外那一截已经定死了
    if out.get(cur_new) == col:
        out[cur_new] = CURSOR                # 当前物件在这一格是最上面的 → 光标压得过自己的本色
    return out


# =====================================================================================
# 修复追加（2026-09-29，meta/repair-20260928，给 archive/re86-20260909/formal/Game.lean 用）
#
# 抽象状态改成三样：
#   ① 可见读数（只看这一帧）：`ink`（整帧逐色格集合的指纹）、`cursor`、`spent`（原有两条，照旧）。
#   ② 隐藏状态 h_*（`hidden_step`）：每件东西此刻的几何 + 颜色 + hub 画不画、选中的是哪件、本关第几步。
#      感知为主：几何从下一帧像素核对出来（见 `_rp_perceive`），颜色从像素读，hub 从像素读；
#      只有像素上根本看不见的部分（伸出盘外 / 压在别的东西底下的那一截）靠记忆补（潜在状态例外，见交回）。
#   ③ 每关常数 k_*（`LEVEL_CONST`）：开局布局、图层次序、斜叉 hub 被换下后画不画、预算、环 / 色块 / 挡块。
#
# 原有的帧 → 值读数（下面 _RETIRED 那一串）不再进状态：它们都是帧的函数，而 ink + cursor + spent 定了整帧
# （证明脚本：meta/repair-20260928/_scratch/re86-20260909/p_retire.py，结果写在交回里）。函数本体一字未改，
# 只是签名包成 (*a, **k)，概念文件照旧能调。
# =====================================================================================

_INK_P = (1 << 62) - 57          # 素数（2^62 以下最大的素数）
_INK_COLORS = (0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)


def ink(g):
    """整帧 64×64（含第 63 行 HUD）每种颜色占的格子，编成位掩码 Σ 2^(r*64+c)，再对素数 _INK_P 取余。
    底色 5 不记（它是其余格子的补集）。返回按 _INK_COLORS 排的 15 个整数。纯像素，不认物件。"""
    m = [0] * 16
    for r in range(64):
        row = g[r]
        for c in range(64):
            v = row[c]
            if v != BG:
                m[v] |= 1 << (r * 64 + c)
    return tuple(m[c] % _INK_P for c in _INK_COLORS)


_RETIRED = ("active", "active_center", "active_color", "arm_len", "arms", "blockers", "box_area", "boxes",
            "center_never_filled", "covered_rings", "cross_cells", "cur_shape", "frame_above", "furniture",
            "kind_of", "me", "objects", "other_center", "other_centers", "ring_border", "ring_centers", "rings",
            "shape_colors", "shapes", "shapes_total", "swatches", "top_of", "unexplained", "walls", "win_now")


def _retire(f):
    def w(*a, **k):
        return f(*a, **k)
    w.__name__, w.__doc__ = f.__name__, f.__doc__
    return w


for _n in _RETIRED:
    globals()[_n] = _retire(globals()[_n])


# ------------------------------------------------------------------ 物件（几何）
# 抄自 ledger/games/re86/objects/piece/piece.py 与 objects/parse.py（只取开局那一帧的读法要用的部分，改成私有名）。

class _RP:
    """一件会动的东西：kind ∈ cross / box / ex / diamond；top..right 是理想形状的包围盒（可伸出盘外）；
    hub：cross 是两杠交点，其余是中心；hollow：hub 那一格不画本色（cross 恒 False）。"""
    __slots__ = ("kind", "color", "top", "left", "bottom", "right", "hub", "hollow", "known")

    def __init__(self, kind, color, top, left, bottom, right, hub, hollow, known=(True, True, True, True)):
        self.kind, self.color, self.top, self.left, self.bottom, self.right = kind, color, top, left, bottom, right
        self.hub, self.hollow, self.known = tuple(hub), hollow, tuple(known)

    def key(self):
        return (self.kind, self.color, self.top, self.left, self.bottom, self.right, self.hub,
                bool(self.hollow) if self.kind != "cross" else False)

    def center(self):
        return ((self.top + self.bottom + 1) // 2, (self.left + self.right + 1) // 2)

    def body(self):
        """形状格，不含 hub（cross 的交点在杠上，照算）。"""
        R, C = self.hub
        out = set()
        if self.kind == "cross":
            out |= {(R, c) for c in range(self.left, self.right + 1)}
            out |= {(r, C) for r in range(self.top, self.bottom + 1)}
            return out
        if self.kind == "box":
            for c in range(self.left, self.right + 1):
                out.add((self.top, c))
                out.add((self.bottom, c))
            for r in range(self.top, self.bottom + 1):
                out.add((r, self.left))
                out.add((r, self.right))
        elif self.kind == "ex":
            L = R - self.top
            for k in range(1, L + 1):
                out |= {(R - k, C - k), (R - k, C + k), (R + k, C - k), (R + k, C + k)}
        else:
            L = R - self.top
            for k in range(L + 1):
                j = L - k
                out |= {(R - k, C - j), (R - k, C + j), (R + k, C - j), (R + k, C + j)}
        out.discard((R, C))
        return out

    def cells(self):
        out = self.body()
        if self.kind != "cross" and self.hollow is False:
            out.add(self.hub)
        return out


_RP_KINDS = ("cross", "box", "ex", "diamond")
_RP_NOT_PIECE = {BG, 1, 2, RING_EDGE, CURSOR}


def _rp_on(p):
    return 0 <= p[0] < HUD_ROW and 0 <= p[1] < 64


def _rp_swatch_inner(g):
    """色块内部的格（色 2 方框里那块纯色）：读物件时它们是「零证据」格。"""
    hits = []
    for n in (5, 6):
        need = -(-12 * (n - 1) // 5)
        for r in range(-(n - 2), HUD_ROW - 1):
            for c in range(-(n - 2), 63):
                edge = [(r + a, c + b) for a in range(n) for b in range(n) if a in (0, n - 1) or b in (0, n - 1)]
                inside = [p for p in edge if _rp_on(p)]
                ok = sum(1 for p in inside if g[p[0]][p[1]] == 2)
                if len(inside) == len(edge):
                    if ok >= need:
                        hits.append((r, c, n))
                else:
                    sides = [[(r, c + b) for b in range(n)], [(r + n - 1, c + b) for b in range(n)],
                             [(r + a, c) for a in range(n)], [(r + a, c + n - 1) for a in range(n)]]
                    if inside and ok == len(inside) and any(all(_rp_on(p) for p in s) for s in sides):
                        hits.append((r, c, n))
    keep = [(r, c, n) for r, c, n in hits
            if not any(n2 > n and r2 <= r and c2 <= c and r + n <= r2 + n2 and c + n <= c2 + n2 for r2, c2, n2 in hits)]
    inner = set()
    for r, c, n in keep:
        inner |= {(r + 1 + a, c + 1 + b) for a in range(n - 2) for b in range(n - 2) if _rp_on((r + 1 + a, c + 1 + b))}
    return keep, inner


def _rp_ring_centers(g):
    edge = {(r, c) for r in range(HUD_ROW) for c in range(64) if g[r][c] == RING_EDGE}

    def core_ok(p):
        if p in edge or not _rp_on(p) or g[p[0]][p[1]] == BG:
            return False
        nb = [(p[0] + a, p[1] + b) for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b]
        if not all(_rp_on(q) for q in nb) or any(g[q[0]][q[1]] == BG for q in nb):
            return False
        return sum(1 for q in nb if q in edge) >= 3

    core = set()
    for (r, c) in edge:
        for a in (-1, 0, 1):
            for b in (-1, 0, 1):
                p = (r + a, c + b)
                if p not in core and core_ok(p):
                    core.add(p)
    out = []
    for p in core:
        ring2 = [(p[0] + a, p[1] + b) for a in range(-2, 3) for b in range(-2, 3) if max(abs(a), abs(b)) == 2]
        ok = True
        for x in ring2:
            if x in edge and not any(q in core and max(abs(q[0] - p[0]), abs(q[1] - p[1])) >= 3
                                     for q in [(x[0] + a, x[1] + b) for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b]):
                ok = False
                break
        if ok:
            out.append(p)
    return sorted(out)


_RP_DIRS = {"H": (0, 1), "V": (1, 0), "D1": (1, 1), "D2": (1, -1)}


def _rp_lines(own, allowed, direction):
    dr, dc = _RP_DIRS[direction]
    if direction == "H":
        starts = [(r, 0) for r in range(HUD_ROW)]
    elif direction == "V":
        starts = [(0, c) for c in range(64)]
    elif direction == "D1":
        starts = [(0, c) for c in range(64)] + [(r, 0) for r in range(1, HUD_ROW)]
    else:
        starts = [(0, c) for c in range(64)] + [(r, 63) for r in range(1, HUD_ROW)]
    out = []
    for s in starts:
        p, seg = s, []
        while _rp_on(p):
            if p in allowed:
                seg.append(p)
            else:
                out += _rp_trim(seg, own)
                seg = []
            p = (p[0] + dr, p[1] + dc)
        out += _rp_trim(seg, own)
    return out


def _rp_trim(seg, own):
    idx = [i for i, p in enumerate(seg) if p in own]
    return [(seg[idx[0]], seg[idx[-1]], len(idx))] if len(idx) >= 2 else []


def _rp_known(p, d, allowed):
    q = (p[0] + d[0], p[1] + d[1])
    return _rp_on(q) and q not in allowed


def _rp_cands(own, allowed):
    hl, vl = _rp_lines(own, allowed, "H"), _rp_lines(own, allowed, "V")
    d1, d2 = _rp_lines(own, allowed, "D1"), _rp_lines(own, allowed, "D2")
    out = []

    def seg_ok(cells):
        return all((not _rp_on(p)) or p in allowed for p in cells)

    for (a, b, _n) in hl:
        R = a[0]
        for (t, u, _m) in vl:
            C = t[1]
            left, right, top, bottom = min(a[1], C), max(b[1], C), min(t[0], R), max(u[0], R)
            cells = [(R, c) for c in range(left, right + 1)] + [(r, C) for r in range(top, bottom + 1)]
            if not seg_ok(cells):
                continue
            known = (_rp_known((top, C), (-1, 0), allowed), _rp_known((R, left), (0, -1), allowed),
                     _rp_known((bottom, C), (1, 0), allowed), _rp_known((R, right), (0, 1), allowed))
            out.append(_RP("cross", -1, top, left, bottom, right, (R, C), False, known))
        C = (a[1] + b[1] + 1) // 2
        out.append(_RP("cross", -1, R, a[1], R, b[1], (R, C), False,
                       (True, _rp_known(a, (0, -1), allowed), True, _rp_known(b, (0, 1), allowed))))
    for (t, u, _m) in vl:
        C, R = t[1], (t[0] + u[0] + 1) // 2
        out.append(_RP("cross", -1, t[0], C, u[0], C, (R, C), False,
                       (_rp_known(t, (-1, 0), allowed), True, _rp_known(u, (1, 0), allowed), True)))

    def box(top, left, bottom, right):
        if bottom - top < 2 or right - left < 2:
            return
        p = _RP("box", -1, top, left, bottom, right, ((top + bottom + 1) // 2, (left + right + 1) // 2), True)
        if not seg_ok(p.body()):
            return
        edges = ([(top, c) for c in range(left, right + 1)], [(r, left) for r in range(top, bottom + 1)],
                 [(bottom, c) for c in range(left, right + 1)], [(r, right) for r in range(top, bottom + 1)])
        known = tuple(_rp_on(e[0]) and _rp_on(e[-1]) and any(q in own for q in e) for e in edges)
        out.append(_RP("box", -1, top, left, bottom, right, p.hub, True, known))

    def col_in(c, r0, r1):
        return all((not _rp_on((r, c))) or (r, c) in allowed for r in range(r0, r1 + 1))

    def row_in(r, c0, c1):
        return all((not _rp_on((r, c))) or (r, c) in allowed for c in range(c0, c1 + 1))

    for i, (a1, b1, _) in enumerate(hl):
        for (a2, b2, _) in hl[i + 1:]:
            if a2[0] <= a1[0] or max(a1[1], a2[1]) > min(b1[1], b2[1]):
                continue
            top, bottom, left, right = a1[0], a2[0], min(a1[1], a2[1]), max(b1[1], b2[1])
            ls, rs = [left], [right]
            for k in range(1, 8):
                if not col_in(left - k, top, bottom):
                    break
                ls.append(left - k)
            for k in range(1, 8):
                if not col_in(right + k, top, bottom):
                    break
                rs.append(right + k)
            for lx in ls:
                for rx in rs:
                    box(top, lx, bottom, rx)
    for i, (t1, u1, _) in enumerate(vl):
        for (t2, u2, _) in vl[i + 1:]:
            if t2[1] <= t1[1] or max(t1[0], t2[0]) > min(u1[0], u2[0]):
                continue
            top, bottom, left, right = min(t1[0], t2[0]), max(u1[0], u2[0]), t1[1], t2[1]
            ts, bs = [top], [bottom]
            for k in range(1, 8):
                if not row_in(top - k, left, right):
                    break
                ts.append(top - k)
            for k in range(1, 8):
                if not row_in(bottom + k, left, right):
                    break
                bs.append(bottom + k)
            for ty in ts:
                for by in bs:
                    box(ty, left, by, right)
    dvals = sorted({a[0] - a[1] for a, _b, _n in d1})
    svals = sorted({a[0] + a[1] for a, _b, _n in d2})
    centers = {((d + s) // 2, (s - d) // 2) for d in dvals for s in svals if (d + s) % 2 == 0}
    for (R, C) in centers:
        L, k = 0, 1
        while k <= 40:
            ring = [(R - k, C - k), (R - k, C + k), (R + k, C - k), (R + k, C + k)]
            if not all((not _rp_on(p)) or p in allowed for p in ring):
                break
            if any(p in own for p in ring):
                L = k
            k += 1
        if L >= 2:
            ring = [(R - L - 1, C - L - 1), (R - L - 1, C + L + 1), (R + L + 1, C - L - 1), (R + L + 1, C + L + 1)]
            kn = any(_rp_on(p) and p not in allowed for p in ring)
            out.append(_RP("ex", -1, R - L, C - L, R + L, C + L, (R, C), True, (kn,) * 4))
    dc = set()
    for i, d_1 in enumerate(dvals):
        for d_2 in dvals[i + 1:]:
            if (d_2 - d_1) % 2 == 0:
                L, m = (d_2 - d_1) // 2, (d_1 + d_2) // 2
                for s in svals:
                    for sm in (s - L, s + L):
                        if (m + sm) % 2 == 0:
                            dc.add((((m + sm) // 2, (sm - m) // 2), L))
    for i, s_1 in enumerate(svals):
        for s_2 in svals[i + 1:]:
            if (s_2 - s_1) % 2 == 0:
                L, m = (s_2 - s_1) // 2, (s_1 + s_2) // 2
                for d in dvals:
                    for dm in (d - L, d + L):
                        if (dm + m) % 2 == 0:
                            dc.add((((dm + m) // 2, (m - dm) // 2), L))
    for (R, C), L in dc:
        if L < 2:
            continue
        p = _RP("diamond", -1, R - L, C - L, R + L, C + L, (R, C), True)
        if not seg_ok(p.body()):
            continue
        outer = _RP("diamond", -1, R - L - 1, C - L - 1, R + L + 1, C + L + 1, (R, C), True).body()
        kn = any(_rp_on(q) and q not in allowed for q in outer)
        out.append(_RP("diamond", -1, R - L, C - L, R + L, C + L, (R, C), True, (kn,) * 4))
    return out


def _rp_fit_color(g, col, own, allowed):
    cands = []
    for p in _rp_cands(own, allowed):
        hub_v = g[p.hub[0]][p.hub[1]] if _rp_on(p.hub) else None
        hollow = False
        if p.kind in ("ex", "diamond", "box"):
            hollow = False if hub_v == col else (None if p.hub in allowed else True)
        q = _RP(p.kind, col, p.top, p.left, p.bottom, p.right, p.hub, hollow, p.known)
        cells = q.cells()
        if all((not _rp_on(x)) or x in allowed for x in cells):
            cands.append((q, cells))
    left, picked = set(own), []
    order = {"cross": 0, "box": 1, "ex": 2, "diamond": 3}
    while left:
        best = None
        for q, cells in cands:
            gain = len(cells & left)
            if gain:
                key = (-gain, len(cells), order[q.kind])
                if best is None or key < best[0]:
                    best = (key, q, cells)
        if best is None:
            raise ValueError(f"色 {col}：{len(left)} 格本色解释不了")
        picked.append(best[1])
        left -= best[2]
    return picked


def _rp_parse(g):
    """从零读一帧里的东西（只用在每关开局那一帧 —— 那时没有记忆）。返回 (pieces 按 (kind,color,hub) 排好, cursor)。"""
    _sw, inner = _rp_swatch_inner(g)
    soft = set(_rp_ring_centers(g)) | inner
    zeros = [(r, c) for r in range(HUD_ROW) for c in range(64) if g[r][c] == CURSOR]
    cursor_ = zeros[0] if len(zeros) == 1 else None
    by_col = {}
    for r in range(HUD_ROW):
        for c in range(64):
            if g[r][c] not in _RP_NOT_PIECE:
                by_col.setdefault(g[r][c], set()).add((r, c))
    obj_cols = {c for c, cs in by_col.items() if cs - soft}
    pieces = []
    for rnd in range(2):
        cover = {}
        for p in pieces:
            for q in p.cells():
                if _rp_on(q) and g[q[0]][q[1]] == p.color:
                    cover.setdefault(q, set()).add(p.color)
        new = []
        for col in sorted(obj_cols):
            cells = by_col[col]
            own, allowed = cells - soft, set(cells)
            if rnd == 0:
                for c2 in obj_cols:
                    if c2 != col:
                        allowed |= by_col[c2]
            else:
                allowed |= {q for q, cs in cover.items() if cs - {col}}
                allowed |= {q for q in soft if g[q[0]][q[1]] in obj_cols and g[q[0]][q[1]] != col}
            if cursor_ is not None:
                allowed.add(cursor_)
            new += _rp_fit_color(g, col, own, allowed)
        pieces = new
    pieces.sort(key=lambda p: (p.kind, p.color, p.hub))
    return pieces, cursor_


def _rp_init(g):
    """开局那一帧的全部东西（真几何）。看不见的那一截按「开局的十字四臂对称」补：
    伸出盘外的一端取对面那条臂的长度（第 3 / 4 / 6 关各有一件十字的一端伸出盘外；
    它们后来都被光标位置（= 包围盒中心）与平移后露出的格子核对过，见 LEVEL_CONST 注释）。
    hub 读不出（被光标压着）的斜叉先记「空」：它被换下之前 hub 一直压在光标底下，看不见。"""
    pcs, cur = _rp_parse(g)
    out = []
    for p in pcs:
        t, l, b, r = p.top, p.left, p.bottom, p.right
        R, C = p.hub
        kt, kl, kb, kr = p.known
        if p.kind == "cross":
            if t == b:
                C = (l + r + 1) // 2
            if l == r:
                R = (t + b + 1) // 2
            if not kt:
                t = R - (b - R)
            if not kb:
                b = R + (R - t)
            if not kl:
                l = C - (r - C)
            if not kr:
                r = C + (C - l)
            out.append(_RP("cross", p.color, t, l, b, r, (R, C), False))
        else:
            if not all(p.known):
                raise ValueError("开局有读不到底的非十字物件")
            hol = True if (p.kind != "ex" or p.hollow is None) else p.hollow
            out.append(_RP(p.kind, p.color, t, l, b, r, (R, C), hol))
    act = [i for i, p in enumerate(out) if p.center() == cur]
    if len(act) != 1:
        raise ValueError("开局认不出选中的是哪件")
    return out, act[0]


# ------------------------------------------------------------------ 感知（有记忆）

_RP_SH = ((0, 0), (-3, 0), (3, 0), (0, -3), (0, 3))
_RP_S3 = (-3, 0, 3)


def _rp_variants(m):
    """记忆里的这件东西，各部分各挪 0 / ±3 格之后的样子（只是「可能在哪」的枚举，不是「会去哪」的预测）。
    秩：0 = 原地，1 = 整件一起挪，2 = 各部分挪得不一样。十字按两条杠、方框按四条边、斜叉 / 菱形整件。"""
    out = []
    if m.kind == "cross":
        R, C = m.hub
        for vs in _RP_SH:
            for hs in _RP_SH:
                rank = 0 if vs == hs == (0, 0) else (1 if vs == hs else 2)
                out.append((_RP("cross", m.color, m.top + vs[0], m.left + hs[1], m.bottom + vs[0], m.right + hs[1],
                                (R + hs[0], C + vs[1]), False), rank))
    elif m.kind == "box":
        for a in _RP_S3:
            for b_ in _RP_S3:
                for c in _RP_S3:
                    for d in _RP_S3:
                        t, l, b, r = m.top + a, m.left + b_, m.bottom + c, m.right + d
                        if b - t < 2 or r - l < 2:
                            continue
                        rank = 0 if a == b_ == c == d == 0 else (1 if (a == c and b_ == d and (a == 0 or b_ == 0)) else 2)
                        out.append((_RP("box", m.color, t, l, b, r, ((t + b + 1) // 2, (l + r + 1) // 2), m.hollow), rank))
    else:
        for dr, dc in _RP_SH:
            out.append((_RP(m.kind, m.color, m.top + dr, m.left + dc, m.bottom + dr, m.right + dc,
                            (m.hub[0] + dr, m.hub[1] + dc), m.hollow), 0 if (dr, dc) == (0, 0) else 1))
    return out


def _rp_seen(p, g, occ):
    """p 的每一格（盘内的）要么显示 p 的颜色、要么显示遮挡色（别的东西的颜色 / 光标色）；返回露出的本色格数，不相容返回 0。"""
    seen = 0
    for (r, c) in p.body():
        if 0 <= r < HUD_ROW and 0 <= c < 64:
            v = g[r][c]
            if v == p.color:
                seen += 1
            elif v not in occ:
                return 0
    return seen


def _rp_perceive(mem, act, action, g):
    """这一帧里每件东西在哪、什么颜色、hub 画没画、选中的是哪件。
    选法：在「记忆的各部分挪 0/±3」里挑与像素相容的；先要原地或整件一起挪，再看颜色不变的、露出本色最多的、挪得最少的。
    `action` 只用来判断「光标整盘不露头时选中的还是不是原来那件」（换人的那一步才要重新认）。"""
    n = len(mem)
    cols = sorted({g[r][c] for r in range(HUD_ROW) for c in range(64)} - {1, 2, 4, 5, 15})
    out = [None] * n
    for rnd in range(2):
        prev_out = list(out)
        for s in range(n):
            occ = {0} | {mem[j].color for j in range(n) if j != s}
            if rnd == 1:
                occ |= {prev_out[j].color for j in range(n) if j != s and prev_out[j] is not None}
            best = []
            for p0, rank in _rp_variants(mem[s]):
                cost = (abs(p0.top - mem[s].top) + abs(p0.bottom - mem[s].bottom) + abs(p0.left - mem[s].left)
                        + abs(p0.right - mem[s].right) + abs(p0.hub[0] - mem[s].hub[0]) + abs(p0.hub[1] - mem[s].hub[1]))
                for col in cols:
                    p = _RP(p0.kind, col, p0.top, p0.left, p0.bottom, p0.right, p0.hub, p0.hollow)
                    seen = _rp_seen(p, g, occ)
                    if seen:
                        best.append(((rank, col != mem[s].color, -seen, cost), p))
            best.sort(key=lambda x: x[0])
            if not best or (len(best) > 1 and best[1][0] == best[0][0]):
                if rnd == 1:
                    raise ValueError(f"第 {s} 件在这一帧里没有相容的位置，或有并列的读法")
                out[s] = None       # 第一遍读不出：第二遍把别的东西新读到的颜色也算作遮挡色再读
                continue
            out[s] = best[0][1]
    for s in range(n):
        p = out[s]
        if p.kind == "cross":
            continue
        h = p.hub
        v = g[h[0]][h[1]] if _rp_on(h) else None
        occ = {0} | {out[j].color for j in range(n) if j != s and h in out[j].body()}
        hol = mem[s].hollow if (v is None or v in occ) else (v != p.color)
        out[s] = _RP(p.kind, p.color, p.top, p.left, p.bottom, p.right, p.hub, hol)
    zeros = [(r, c) for r in range(HUD_ROW) for c in range(64) if g[r][c] == CURSOR]
    if zeros:
        hit = [s for s in range(n) if out[s].center() == zeros[0]]
        a2 = hit[0] if len(hit) == 1 else (act if act in hit else None)
    elif action != "ACTION5":
        a2 = act
    else:
        hid = [s for s in range(n) if any(out[s].center() in out[j].body() for j in range(n) if j != s)]
        a2 = hid[0] if len(hid) == 1 else None
    if a2 is None:
        raise ValueError("认不出选中的是哪件")
    return out, a2


# ------------------------------------------------------------------ 编码（进 Lean 的整数）

def _rp_enc(p):
    """kind | color<<2 | hollow<<6 | (top+64)<<7 | (left+64)<<15 | (bottom+64)<<23 | (right+64)<<31 | (hubR+64)<<39 | (hubC+64)<<47"""
    v = _RP_KINDS.index(p.kind) | (p.color << 2) | ((1 if (p.kind != "cross" and p.hollow) else 0) << 6)
    for i, x in enumerate((p.top, p.left, p.bottom, p.right, p.hub[0], p.hub[1])):
        v |= (x + 64) << (7 + 8 * i)
    return v


def _rp_dec(v):
    f = [((v >> (7 + 8 * i)) & 255) - 64 for i in range(6)]
    kind = _RP_KINDS[v & 3]
    return _RP(kind, (v >> 2) & 15, f[0], f[1], f[2], f[3], (f[4], f[5]), (kind != "cross") and bool((v >> 6) & 1))


HIDDEN_INIT = {"p0": -1, "p1": -1, "p2": -1, "act": -1, "n": 0}


def hidden_step(h, prev, action, nxt):
    """p0..p2：每件东西此刻的几何（编码见 _rp_enc；-1 = 没有这一件）；act：选中的是第几件；n：本关走了几步。
    开局（act = -1）时从前一帧（开局那一帧）从零读起，之后每步：记忆 + 下一帧像素 → `_rp_perceive`。"""
    if h["act"] == -1:
        mem, act = _rp_init(prev)
    else:
        mem = [_rp_dec(h[k]) for k in ("p0", "p1", "p2") if h[k] != -1]
        act = h["act"]
    out, a2 = _rp_perceive(mem, act, action, nxt)
    enc = [_rp_enc(p) for p in out] + [-1] * (3 - len(out))
    return {"p0": enc[0], "p1": enc[1], "p2": enc[2], "act": a2, "n": h["n"] + 1}


# LEVEL_CONST（每关常数，游戏内容；由 meta/repair-20260928/_scratch/re86-20260909/mk_const.py 算出后手抄进来）
# 各键的来历（语料 = runs/re86-0907-1214/transitions.jsonl，行号从 0 数）：
#   p0..p2 / act —— 该关开局那一帧（第 0 关第 0 行、第 1 关第 27 行、第 2 关第 65 行、第 3 关第 118 行、第 4 关第 176 行、
#                   第 5 关第 443 行、第 6 关第 521 行、第 7 关第 647 行的 prev）过 `_rp_init`，与 hidden_step 开局用同一个函数。
#                   伸出盘外的十字端点按对称补：第 3 关色 6 十字右端 67、第 4 关色 12 十字右端 68、第 6 关色 7 十字下端 63；
#                   这三件后来的光标位置（包围盒中心）与左移 / 上移后露出的格子都与此相符（整关前向渲染逐帧对上）。
#   lay  —— 图层次序（从下往上的件号，第 k 位 base-4）。帧上只读得到重叠的那几对：第 0 关 9 压 11（第 199 行）、
#           第 1 关 13 压 12（第 27 行）且 9 压 13（开局帧）、第 2 关 ACTION5 的轮换次序（第 65/66 行：十字 → 斜叉 → 菱形）、
#           第 4 关轮换次序（第 348/349 行：斜叉 → 菱形 → 十字）、第 5 关 11 压 9（第 464 行）、第 6 关开局帧三对都读得到、
#           第 3 / 7 关两件（只影响重叠处的颜色，开局帧 / 第 647 行读到 12 压 10）。
#   fill —— 斜叉被换下（ACTION5）那一步之后 hub 画不画本色（第 i 位 = 第 i 件）：第 1 关不画（第 40/41 行）、第 2 关不画（第 66/67 行）、
#           第 3 关画（第 142/143 行）、第 4 关画（第 348/349 行）。菱形与方框 hub 在全部帧上都不画。
#   B    —— 预算：关内每一帧 HUD 已花格数 = round(64·n/B)（n = 本关已走步数，含 ACTION5 与原地不动的推），
#           在全部关内帧上逐帧成立（ledger/games/re86/rule/notmodel/budget_curve.py 记的拟合值，这里用整关前向渲染重核过）。
#   ring —— 环心与归属色：开局帧读；第 4 关 (33,57)、(42,54) 两个环开局被十字盖着，取整关第一次露出来的那一帧（均为 8）。
#   sw   —— 色块（外沿左上角、边长、内部颜色）：开局帧读（第 7 关 (28,-3) 那个被盘左边裁掉一截）。
#   blk  —— 挡块：开局帧的色 1 格（第 5、6 关一块 8×8 在 (28,28)，第 7 关两块 5×5 在 (1,58)、(55,34)）。
# 编码：p* 见 _rp_enc；ring = cnt | Σ (r | c<<6 | owner<<12) << (4+16j)；sw = cnt | Σ ((t+8) | (l+8)<<7 | n<<14 | color<<18) << (4+24j)；
#       blk = cnt | Σ (pat | top<<64 | left<<70) << (4+80j)，pat 的第 r 字节是块内第 r 行的 8 格。第 8 关（通关后）没有常数。
LEVEL_CONST = {
    0: {'p0': 14133915911172132, 'p1': 12012921305770028, 'p2': -1, 'act': 0, 'lay': 1, 'fill': 0, 'B': 100, 'ring': 3320711825449155593758148190455495081016, 'sw': 0, 'blk': 0},
    1: {'p0': 15821142249025188, 'p1': 14547879732390647, 'p2': 12852411243176946, 'act': 2, 'lay': 6, 'fill': 0, 'B': 100, 'ring': 13791765513181919964572890964048614283937759188026, 'sw': 0, 'blk': 0},
    2: {'p0': 13289495166498464, 'p1': 15402219770786403, 'p2': 11602247446409890, 'act': 0, 'lay': 24, 'fill': 0, 'B': 200, 'ring': 2837198338432408697571909696006058940520, 'sw': 0, 'blk': 0},
    3: {'p0': 16662281479039896, 'p1': 12431839472330154, 'p2': -1, 'act': 0, 'lay': 4, 'fill': 2, 'B': 200, 'ring': 970156295109850815806125653286, 'sw': 80307959311890568025022272904641805295313094, 'blk': 0},
    4: {'p0': 16660634342271408, 'p1': 13274625839113467, 'p2': 12443386676424686, 'act': 2, 'lay': 24, 'fill': 4, 'B': 250, 'ring': 13928726900900561949002200131731071696751789954154, 'sw': 2793207436176034345447371417048340661, 'blk': 0},
    5: {'p0': 11180024227116013, 'p1': 15806296459714980, 'p2': -1, 'act': 0, 'lay': 1, 'fill': 0, 'B': 200, 'ring': 4035015497249058434260985678155304480872, 'sw': 0, 'blk': 537464226180986736377841},
    6: {'p0': 12026104867436273, 'p1': 12449998862235292, 'p2': 10757805319500712, 'act': 2, 'lay': 36, 'fill': 0, 'B': 300, 'ring': 263344394885803459928653897881882187395507353, 'sw': 2107923225795932047121442505709893797, 'blk': 537464226180986736377841},
    7: {'p0': 16667214265988073, 'p1': 16246644650980721, 'p2': -1, 'act': 1, 'lay': 4, 'fill': 0, 'B': 400, 'ring': 3827653008803093251607057790867431171704, 'sw': 501995956775280873932205063869095691804228395406033611995959100362501077667845897395167498709484511390, 'blk': 796047400609333286587399502699251867987651703282},
}
