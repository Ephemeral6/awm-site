"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

量出来的（第 0~15 步，两关）：
  · 每关的布局都不一样，所以词汇只许写成「从帧上认出来」，不许写死坐标。
  · 场地是一块 4 色（FIELD_BG）的矩形，外面是 3 色的外框；第 0 列是一条 64 格竖条，
    自上而下被 5 色填充，一次生效点击多填若干格（**几格是关级常数，两关实测不同，故 BAR_STEP 留空**），
    换关清零；第 1 行有 win_levels 组 5 色小段，过掉一关就有一组变成 14 色。
  · 场地里有若干**箭头块**：8 色的一批和 14 色的一批，形状是「中段比两端宽」的箭头，
    成对出现（同一段行/列上一个 8 色一个 14 色）。它们是唯一受理点击的地方。
  · 场地里有一批**瓷砖**：同一关内边长相同的实色正方形（TILE 边长按关而变），彼此不相邻，
    排在等间距的网格位上。
  · 还有一批**角标**：边长比瓷砖小的同色小方块，四个一组斜贴在某个网格位的四角，
    框出一个「插槽」。**角标色是逐槽的，不是全局常数**：一关里可以有两个插槽各要一种颜色，
    而那种颜色的瓷砖场上恰好只有一块。这里曾经写死过一个 BRACKET=11，前两关都对，
    第三关有一个 12 色的插槽，于是整个插槽被漏掉、终止条件提前判成真 —— 见 win_slots_done v2。

没量出来的留 None。
"""
from __future__ import annotations

FIELD_BG = 4        # 场地底色
OUTER_BG = 3        # 外框底色
ARROW_A = 8         # 一侧箭头的颜色
ARROW_B = 14        # 另一侧箭头的颜色（也是竖条与 HUD 的空底色）
BAR_COL = 0
BAR_FILL = 5
BAR_EMPTY = 14
BAR_STEP = None     # 一次生效点击填几格：**关级常数，实测两关不同值**，从帧上算不出来 → 留空槽
                    # 角标色不设常数：逐槽认，见 layout 的 slot_mark


# ---------- 通用连通块 ----------
def _comps(g, want, skip=()):
    """4-邻接连通块：返回 [(r0, r1, c0, c1, 格数, 颜色)]，跳过 skip 里的列。"""
    h, w = len(g), len(g[0])
    seen = [[False] * w for _ in range(h)]
    out = []
    for y in range(h):
        for x in range(w):
            if seen[y][x] or x in skip:
                continue
            col = g[y][x]
            if col not in want:
                continue
            stack, blob = [(y, x)], []
            seen[y][x] = True
            while stack:
                cy, cx = stack.pop()
                blob.append((cy, cx))
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = cy + dy, cx + dx
                    if (0 <= ny < h and 0 <= nx < w and not seen[ny][nx]
                            and nx not in skip and g[ny][nx] == col):
                        seen[ny][nx] = True
                        stack.append((ny, nx))
            ys = [p[0] for p in blob]
            xs = [p[1] for p in blob]
            out.append((min(ys), max(ys), min(xs), max(xs), len(blob), col))
    out.sort()
    return out


def field(g):
    """场地矩形 (r0, r1, c0, c1)：FIELD_BG 最大连通块的 bbox。认不出返回 None。"""
    cs = [c for c in _comps(g, {FIELD_BG}, skip=(BAR_COL,))]
    if not cs:
        return None
    best = max(cs, key=lambda c: c[4])
    return best[0], best[1], best[2], best[3]


def _inside(box, r0, r1, c0, c1):
    return box[0] <= r0 and r1 <= box[1] and box[2] <= c0 and c1 <= box[3]


def arrows(g):
    """场地里的箭头块：[(颜色, r0, r1, c0, c1)]。竖条与 HUD 那一行的同色块排除在外。"""
    f = field(g)
    if f is None:
        return []
    out = []
    for r0, r1, c0, c1, n, col in _comps(g, {ARROW_A, ARROW_B}, skip=(BAR_COL,)):
        if _inside(f, r0, r1, c0, c1):
            out.append((col, r0, r1, c0, c1))
    return out


def squares(g):
    """场地里的实色正方形小块：[(边长, r0, c0, 颜色)]。箭头块与底色不算。"""
    f = field(g)
    if f is None:
        return []
    out = []
    for r0, r1, c0, c1, n, col in _comps(g, _palette(g), skip=(BAR_COL,)):
        k = r1 - r0 + 1
        if k != c1 - c0 + 1 or n != k * k:
            continue
        if not _inside(f, r0, r1, c0, c1):
            continue
        out.append((k, r0, c0, col))
    return out


def _palette(g):
    """场地里出现过的、既不是底色也不是箭头色的颜色集合。"""
    f = field(g)
    if f is None:
        return set()
    r0, r1, c0, c1 = f
    return {g[y][x] for y in range(r0, r1 + 1) for x in range(c0, c1 + 1)
            if g[y][x] not in (FIELD_BG, ARROW_A, ARROW_B)}


def layout(g):
    """认出这一关的布局：瓷砖边长、网格、瓷砖颜色表、插槽位置。

    返回 dict(tile=边长, rows=[行首…], cols=[列首…], tiles={(r,c): 色},
              slots=[(r,c)…], slot_mark={(r,c): 角标色}, arrows=[…])，认不出返回 None。
    """
    sq = squares(g)
    if not sq:
        return None
    sizes = {}
    for k, *_ in sq:
        sizes[k] = sizes.get(k, 0) + 1
    tk = max(sizes, key=lambda k: (sizes[k], k))          # 数量最多的边长 = 瓷砖
    if sizes[tk] < 4:
        return None
    tl = [s for s in sq if s[0] == tk]
    rows = sorted({s[1] for s in tl})
    cols = sorted({s[2] for s in tl})
    tiles = {}
    ri = {v: i for i, v in enumerate(rows)}
    ci = {v: i for i, v in enumerate(cols)}
    for k, r0, c0, col in tl:
        tiles[(ri[r0], ci[c0])] = col
    by = {}                                               # (角标边长, 角标色) -> {左上角…}
    for mk, r0, c0, col in (s for s in sq if s[0] < tk):
        by.setdefault((mk, col), set()).add((r0, c0))
    slots, slot_mark = [], {}
    for r0 in rows:
        for c0 in cols:
            if (ri[r0], ci[c0]) not in tiles:
                continue        # 空的网格位不是插槽：插槽是「瓷砖该待的地方」，没瓷砖能到的地方不算。
                                # 这道判别项是必需的，因为**相邻插槽共用角标**：三个横排的插槽只画四列角标，
                                # 于是夹在两个插槽中间的空位会白捡到四个角，看着像第四个插槽。
                                # 有一段布局正是如此（三个插槽横排 + 一个在下方），空位使 slots_done 永假、
                                # 过关那一刻必定判错。
            for (mk, col), have in sorted(by.items()):
                want = {(r0 - mk, c0 - mk), (r0 - mk, c0 + tk),
                        (r0 + tk, c0 - mk), (r0 + tk, c0 + tk)}
                if want <= have:
                    slots.append((ri[r0], ci[c0]))
                    slot_mark[(ri[r0], ci[c0])] = col
                    break
    return {"tile": tk, "rows": rows, "cols": cols, "tiles": tiles,
            "slots": slots, "slot_mark": slot_mark, "arrows": arrows(g)}


# ---------- 点击 ----------
def _xy(action):
    """从 'ACTION6:x,y' 抽出 (row, col)；不是带坐标的动作返回 None。"""
    if ":" not in action:
        return None
    try:
        x, y = (int(v) for v in action.split(":", 1)[1].split(","))
    except ValueError:
        return None
    return (y, x)


def hit_arrow(g, action):
    """点击落在哪个箭头块里：返回 (颜色, r0, r1, c0, c1)，没落在任何箭头里返回 None。"""
    rc = _xy(action)
    if rc is None:
        return None
    for col, r0, r1, c0, c1 in arrows(g):
        if r0 <= rc[0] <= r1 and c0 <= rc[1] <= c1:
            return (col, r0, r1, c0, c1)
    return None


def arrow_dir(g, block):
    """箭头指向哪边：外接框四条边里，箭头色**填充比例最小**的那条边。返回 (dr, dc)。

    箭头块是个缺了一角的方块：指向那一侧的边线只在中段有色，两端缺；其余三条边是满的。
    这里曾经用颜色代替指向（8 色一个方向、14 色另一个方向），在三段布局上都对，
    第四段布局上塌了 —— 那里的 8 色箭头指「下」，而 8 色在前三段一直意味着「左」。
    颜色只是指向的影子：8 色恒为「左或下」、14 色恒为「右或上」，
    一旦同一条链上出现的是竖直的一对箭头，颜色就说不出符号了。见 belt_rot_a / belt_rot_b v4。
    """
    col, r0, r1, c0, c1 = block

    def frac(cells):
        return sum(1 for y, x in cells if g[y][x] == col) / len(cells)

    edges = {
        (-1, 0): [(r0, x) for x in range(c0, c1 + 1)],
        (1, 0): [(r1, x) for x in range(c0, c1 + 1)],
        (0, -1): [(y, c0) for y in range(r0, r1 + 1)],
        (0, 1): [(y, c1) for y in range(r0, r1 + 1)],
    }
    return min(edges, key=lambda d: frac(edges[d]))


# ---------- 竖条 ----------
def bar_prefix(g):
    """竖条是不是「前 n 格填、后面全空」；是就返回 n，不是返回 None。"""
    col = [g[y][BAR_COL] for y in range(len(g))]
    n = 0
    while n < len(col) and col[n] == BAR_FILL:
        n += 1
    if any(v != BAR_EMPTY for v in col[n:]):
        return None
    return n


# ---------- 过关计数那排细条 ----------
#
# 第 1 行上排着一串**等宽等距**的细条，一条对应一关：已过的染 HUD_DONE、还没过的染 HUD_TODO，
# 而且已过的总是靠左的一段前缀。总条数就是这一局总共有几关。
# 第 0 列（竖条）的颜色恰好也落在这两色里，必须排掉——不排掉的话宽度不齐，
# 整排读不出来，而「读不出」在账面上长得像「没说错」。
# 它让册子能回答一个原先答不出的问题：**这一关是不是最后一关**。
# 从前 level_up_resets_bar 就是因为答不出这个问题，在赢下最后一关那一步说错了 17 格；
# 那时我写的理由是「帧上看不出总共有几关」，而这排细条一直在帧上，是我没去读。
HUD_ROW = 1
HUD_DONE = 14
HUD_TODO = 5


def hud_ticks(g):
    """第 1 行那排过关计数细条：[(色, c0, c1)]；形态认不出返回 []。"""
    row = g[HUD_ROW]
    segs, i = [], 0
    while i < len(row):
        j = i
        while j + 1 < len(row) and row[j + 1] == row[i]:
            j += 1
        segs.append((row[i], i, j))
        i = j + 1
    ts = [s for s in segs if s[0] in (HUD_DONE, HUD_TODO) and s[1] > BAR_COL]
    if len(ts) < 2:
        return []
    if len({c1 - c0 + 1 for _c, c0, c1 in ts}) != 1:
        return []                       # 宽度不齐
    if len({ts[k + 1][1] - ts[k][2] - 1 for k in range(len(ts) - 1)}) != 1:
        return []                       # 间距不齐
    return ts


def levels_total(g):
    """这一局总共几关；细条认不出返回 None。"""
    ts = hud_ticks(g)
    return len(ts) or None


def levels_cleared(g):
    """已过几关；细条认不出、或已过的那些不是靠左的一段前缀，返回 None。"""
    ts = hud_ticks(g)
    if not ts:
        return None
    flags = [c == HUD_DONE for c, _a, _b in ts]
    n = 0
    while n < len(flags) and flags[n]:
        n += 1
    if any(flags[n:]):
        return None                     # 不是前缀：这排细条不是这么编码的
    return n


def is_last_level(g):
    """现在这一关是最后一关吗；读不出返回 None。"""
    tot, done = levels_total(g), levels_cleared(g)
    if tot is None or done is None:
        return None
    return done + 1 == tot


# ---------- 传送带（belt）：一个箭头驱动哪一串网格位，按什么次序 ----------
#
# 假设（实测三段布局：矩形环、矩形环+两条直线绕回带、两个斜角环共用两位）：
# 瓷砖排在一条条**首尾相接的闭合链**上。从任一位起、朝任一相邻位走，规则是
#   优先直走；走不动就转 45°；再走不动转 90°（同一档里顺时针那边优先）；
#   都走不动就「绕回」——沿反方向退到这一段直线的另一端（首尾相接的直线带）。
#   回到起点就成链；退到的不是起点，这条路不成链。
# 八个方向都要试，因为链会走对角线（斜角环的斜边）。
#
# 箭头**不再假定对准某条网格行/列**：它只是链外面的一个把手，
# 认哪条链靠「离箭头块最近的那条链」。方向由**箭头自己的形状**说（belt_rot_a / belt_rot_b v4）：
# 指向与这条链规范次序第一步同向就前移一位，反向就后移一位。曾经这里写的是「按箭头颜色分」，
# 三段布局都对，第四段布局有一对竖直箭头，颜色就说不出符号了 —— 见 arrow_dir 的注解。
_DIRS8 = ((0, 1), (1, 1), (1, 0), (1, -1),
          (0, -1), (-1, -1), (-1, 0), (-1, 1))   # 东 东南 南 西南 西 西北 北 东北，顺时针


def _cands(d):
    """从方向 d 出发的候选方向：直走、±45°、±90°；同一档里顺时针优先。不含掉头。"""
    i = _DIRS8.index(d)
    return (d, _DIRS8[(i + 1) % 8], _DIRS8[(i - 1) % 8],
            _DIRS8[(i + 2) % 8], _DIRS8[(i - 2) % 8])


def _trace(occupied, start, d):
    """按上面的规则走一圈，返回走过的网格位列表；走不成环返回 None。"""
    order = [start]
    seen = {start}
    cur = start
    while len(order) <= len(occupied):
        moved = False
        for cand in _cands(d):
            nxt = (cur[0] + cand[0], cur[1] + cand[1])
            if nxt not in occupied:
                continue
            if nxt == start:
                return order if len(order) >= 4 else None
            if nxt in seen:
                continue
            order.append(nxt)
            seen.add(nxt)
            cur, d = nxt, cand
            moved = True
            break
        if moved:
            continue
        back = (-d[0], -d[1])                         # 绕回：退到这一段的另一端
        run = cur
        while (run[0] + back[0], run[1] + back[1]) in occupied:
            run = (run[0] + back[0], run[1] + back[1])
        if run == start:
            return order if len(order) >= 4 else None
        return None
    return None


def _ok(order):
    """一条候选链合不合格。走出来的链会抄近路（直走那一位已访问过时被迫转弯），
    所以要把成品当闭链再验一遍：
      · 相邻两位要么是 8-邻接，要么是同一直线上的两端（绕回），绕回最多一处；
      · 8-邻接的段上，方向变化不许超过 90°（两档）。
    """
    n = len(order)
    if n < 4:
        return False
    steps = []
    for i in range(n):
        a, b = order[i], order[(i + 1) % n]
        dr, dc = b[0] - a[0], b[1] - a[1]
        if (dr, dc) in _DIRS8:
            steps.append((dr, dc))
        elif dr == 0 or dc == 0 or abs(dr) == abs(dc):
            steps.append(None)                        # 绕回：同一直线上的跳跃
        else:
            return False
    if steps.count(None) > 1:
        return False
    for i in range(n):
        a, b = steps[i], steps[(i + 1) % n]
        if a is None or b is None:
            continue
        ia, ib = _DIRS8.index(a), _DIRS8.index(b)
        if min((ia - ib) % 8, (ib - ia) % 8) > 2:
            return False
    return True


def _gap_split(coords):
    """网格坐标里的**大间隙**：返回一批索引 i，表示第 i 与 i+1 两条网格线之间被拉开了。

    等距网格返回空集。判据：相邻间距大于最小间距的两倍。
    """
    d = [b - a for a, b in zip(coords, coords[1:])]
    if not d:
        return set()
    base = min(d)
    return {i for i, x in enumerate(d) if x > base * 2}


MIN_RUN = 3
"""极大直线段要多长才当候选。**这是个还在被世界改的常数，不是设计参数。**

原本写 4，凭的是「太短的段当带会到处误认」这个担心——而不是任何一段布局的读数。
有一段布局出现了长 3 的直线段单独当带（两个按钮各驱动它的一个方向，逐位一格不差），
`_runs` 因为 4 这个门槛根本没把它列成候选，于是那两个按钮被距离配给了包着它的长环，
两条概念一起判 FALSE。真正在筛掉误认的是 `_free_end_runs` 的自由端判据，不是长度。

为什么停在 3 而不是干脆去掉门槛：长 2 的段「首尾相接旋转」和「两位对调」是同一个置换，
从帧上分不开，而对调另有出处（见 hub_swap 那一类）。所以 2 这一档不是没证据，是**不可判别**，
去掉门槛等于替它选了一种读法。哪天有长 2 的段需要当带，看到的会是「该动的没动」。
"""


def _runs(occupied):
    """全部极大直线段（同行连续 / 同列连续），长度 >= MIN_RUN：[(轴, 固定坐标, (位…递增))]。"""
    out = []
    for axis in (0, 1):
        for k in sorted({p[axis] for p in occupied}):
            line = sorted(p for p in occupied if p[axis] == k)
            cur = [line[0]]
            for p in line[1:]:
                if p[1 - axis] == cur[-1][1 - axis] + 1:
                    cur.append(p)
                else:
                    if len(cur) >= MIN_RUN:
                        out.append((axis, k, tuple(cur)))
                    cur = [p]
            if len(cur) >= MIN_RUN:
                out.append((axis, k, tuple(cur)))
    return out


def _gapped_chains(occupied, rows, cols):
    """**跨过大间隙的直线段不自绕回**，而与同向同长的其它跨隙直线段首尾相接成一条闭链。

    主张：等距网格上，一条直线带自己首尾相接（走到头从另一头回来）；
    网格被大间隙切开时，带子改为串到同向的下一条线上去——像一行字写到头接着写下一行，
    最后一行接回第一行。判别项是网格坐标等不等距，几何上可核。

    这条判别项目前只有一段布局支持（那段布局两轴各有一道大间隙，横竖两对直线各接成一条长 20 的闭链），
    而三段等距布局上它一次都不触发、输出逐位不变。它是本词汇里最弱的一环：
    下一段不等距的布局若把它打掉，看到的会是「另一条平行线也跟着动了 / 该动的没动」。
    """
    if not rows or not cols:
        return []
    gaps = {0: _gap_split(rows), 1: _gap_split(cols)}
    out = []
    grouped = {}
    for axis, k, seg in _runs(occupied):
        span = range(seg[0][1 - axis], seg[-1][1 - axis])      # 段内跨过的网格线区间
        if not any(i in gaps[1 - axis] for i in span):
            continue                                           # 没跨隙：照旧自绕回
        grouped.setdefault((axis, len(seg)), []).append((k, seg))
    for (axis, _n), items in grouped.items():
        if len(items) < 2:
            continue
        chain = []
        for _k, seg in sorted(items):
            chain.extend(seg)
        out.append(_canon(chain))
    return out


def _free_end_runs(occupied, rows, cols):
    """**自绕回的直线带**：一条极大直线段自己首尾相接成环，条件有两条，都能从几何上核。

    (i) 至少有一头是**自由端**——那一头在占位图里没有段外的邻居。
        两头都接着别的轨道时，内容会顺着轨道拐弯走下去，不会在这一段里自己绕回；
        所以矩形环、菱形环的直边**不是**带（它们的两头都是拐角），
        而单独一条横带（两头都空）、以及蛇形链末端那一段（一头空）是带。
    (ii) 不跨过网格坐标里的大间隙。跨隙的段改与同向同长的段首尾相接，见 _gapped_chains。

    条件 (i) 是这一版新加的判别项。它的由来：有一段布局里，一条长 5 的直线段
    同时也是一条更长的链的一部分（链嵌套），而旧代码按「被真包含就丢掉」把它删了，
    于是对准它的那两个箭头认错了链。两头都接着轨道 / 至少一头是自由端，
    正是「侧边」和「带」的区别，在前几段布局上逐位复核过。
    """
    gaps = {0: _gap_split(rows or []), 1: _gap_split(cols or [])}
    out = []
    for axis, _k, seg in _runs(occupied):
        span = range(seg[0][1 - axis], seg[-1][1 - axis])
        if any(i in gaps[1 - axis] for i in span):
            continue                                   # 跨隙：交给 _gapped_chains
        inside = set(seg)
        free = 0
        for end in (seg[0], seg[-1]):
            nb = [(end[0] + d[0], end[1] + d[1]) for d in _DIRS8]
            if not any(q in occupied and q not in inside for q in nb):
                free += 1
        if free:
            out.append(_canon(list(seg)))
    return out


def _components(occupied):
    """占位图的 4-邻接连通块：[{网格位…}]。"""
    left = set(occupied)
    out = []
    while left:
        start = left.pop()
        comp = {start}
        stack = [start]
        while stack:
            p = stack.pop()
            for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                q = (p[0] + d[0], p[1] + d[1])
                if q in left:
                    left.discard(q)
                    comp.add(q)
                    stack.append(q)
        out.append(comp)
    return out


def _path_chains(occupied):
    """**开放路径首尾相接**：一整个连通块是一条路径、**且两个自由端反向同轴**时，两端接起来成一条环。

    判据纯几何、不容置疑：块里每一位的 4-邻居数都 <= 2，且恰有两位只有一个邻居；
    再加一条——两个端点的**自由朝向**（背对路径内部的那一侧）必须反向且同轴。

    由来：有一段布局的占位图既没有二维回路、也不是直线，_trace 走到死头就返回 None，
    于是整关一条链都认不出来（只认出其中一条直线段），而世界一次点击搬动了整块的内容。
    直线带自绕回其实就是这条规则在「路径恰好是直的」时的特例。

    反向同轴那一条是后来补的，代价是一条反例。有一段布局的连通块是个 L：
    横臂八位、竖臂三位，也是一条合格的简单路径，于是这里照样把它接成一条长 10 的环。
    世界从来没有整条搬动过它——两条直臂各自独立地动，端点那一跳一次都没发生。
    差别读得出来：会绕回的那些，两个自由端朝向相反且在同一根轴上（长蛇一头朝东一头朝西，
    直线段更是天然如此）；L 的两个自由端一头朝东一头朝南，垂直。
    绕回那一跳本身要是一次**连贯的平移**，两端就必须这样对着；对不上，它就只是两条带碰巧连在一起。
    这条判据不是为 L 量身定做的：它在带自绕回那条规则里本来就成立（直线段的两端天然反向同轴），
    只是从前没有需要写出来的场合。
    """
    out = []
    for comp in _components(occupied):
        if len(comp) < 4:
            continue
        deg = {p: sum(1 for d in ((1, 0), (-1, 0), (0, 1), (0, -1))
                      if (p[0] + d[0], p[1] + d[1]) in comp) for p in comp}
        if any(v > 2 for v in deg.values()):
            continue                                   # 有分叉或交叉：不是路径
        ends = sorted(p for p, v in deg.items() if v == 1)
        if len(ends) != 2:
            continue                                   # 0 个端点 = 闭环，交给 _trace
        order = [ends[0]]
        seen = {ends[0]}
        while True:
            nxt = [q for d in ((1, 0), (-1, 0), (0, 1), (0, -1))
                   for q in [(order[-1][0] + d[0], order[-1][1] + d[1])]
                   if q in comp and q not in seen]
            if not nxt:
                break
            order.append(nxt[0])
            seen.add(nxt[0])
        if len(order) != len(comp):
            continue
        # 自由朝向 = 端点背对路径内部的那一侧；两端必须反向同轴，绕回才是一次连贯的平移。
        f0 = (order[0][0] - order[1][0], order[0][1] - order[1][1])
        f1 = (order[-1][0] - order[-2][0], order[-1][1] - order[-2][1])
        if (f0[0] + f1[0], f0[1] + f1[1]) != (0, 0):
            continue
        out.append(_canon(order))
    return out


def _cycles(occupied, rows=None, cols=None):
    """这一关全部的链，去重、过滤、按规范次序排好。链有两种来源，过滤规则不一样：

    · **走出来的**（_trace，八方向、每一位都当过起点）：会抄近路走出残片，
      所以被别的链真包含的一律丢掉。
    · **结构上算出来的**（自绕回的直线带 _free_end_runs、跨隙串接 _gapped_chains、
      开放路径首尾相接 _path_chains）：判别项写在各自的注解里，**即便被别的链真包含也保留**——
      链是会嵌套的（一条长链上的某一段直线，可以同时是一条独立的短带），
      而这三条来源各自有几何判据，不靠「谁包含谁」来筛。
    """
    traced = set()
    for start in occupied:
        for d in _DIRS8:
            if (start[0] + d[0], start[1] + d[1]) not in occupied:
                continue
            o = _canon(_trace(occupied, start, d))
            if o and _ok(o):
                traced.add(tuple(o))
    structural = set()
    for src in (_free_end_runs(occupied, rows, cols),
                _gapped_chains(occupied, rows, cols),
                _path_chains(occupied)):
        for o in src:
            if o:
                structural.add(tuple(o))
    allsets = [set(o) for o in traced | structural]
    keep = [o for o in sorted(traced)
            if not any(set(o) < t for t in allsets)]
    keep += [o for o in sorted(structural) if o not in set(keep)]
    return [list(o) for o in keep]



def _canon(order):
    """把走出来的次序摆成规范次序：从最左上那一位起，第二位取它东边那一位；
    最左上那一位没有东邻（斜边起头）时，取两个邻居里字典序小的那个 —— 只要确定就行。"""
    if not order:
        return None
    i = order.index(min(order))
    o = order[i:] + order[:i]
    if len(o) < 2:
        return o
    east = (o[0][0], o[0][1] + 1)
    if east in (o[1], o[-1]):
        if o[1] != east:
            o = [o[0]] + list(reversed(o[1:]))
    elif o[-1] < o[1]:
        o = [o[0]] + list(reversed(o[1:]))
    return o


def belts(g, lay=None):
    """{(箭头颜色, 箭头 bbox): [网格位…规范次序]}：每个箭头配离它最近的那条链。

    「最近」先比**最近一位的距离**，打平了再比**全链的平均距离**。
    要平均距离这一档是因为链会嵌套：两条链共用离箭头最近的那一位时，最小距离一样，
    此时该驱动的是整体都贴着箭头的那条（短的那条），不是只有一头贴着的那条。
    """
    lay = lay or layout(g)
    if lay is None:
        return {}
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    cyc = _cycles(set(lay["tiles"]), rows, cols)
    if not cyc:
        return {}
    half = (tk - 1) / 2.0

    def d2(p, ar, ac):
        return (rows[p[0]] + half - ar) ** 2 + (cols[p[1]] + half - ac) ** 2

    out = {}
    for col, r0, r1, c0, c1 in lay["arrows"]:
        ar, ac = (r0 + r1) / 2.0, (c0 + c1) / 2.0
        out[(col, r0, r1, c0, c1)] = min(
            cyc, key=lambda o: (min(d2(p, ar, ac) for p in o),
                                sum(d2(p, ar, ac) for p in o) / len(o)))
    return out


def driven(g, action, lay=None):
    """这一次点击驱动的**全部**链：[(位移符号, [网格位…规范次序])]。

    从前这里只认一条：离箭头最近的那条链。有一段布局把它打掉了——一次点击同时搬动了
    两个互不相连的结构（一条长 8 的直线段和一个 2x2 的环），而它们之间隔着空地，
    「一条环 ±1」这类全局候选一个都对不上，逐结构反解才出唯一解：两个位移**并行**发生、符号相同。

    规则两条：

    1. **合格** = 箭头指向与该链规范次序首步的点乘非零。垂直的链这个箭头驱动不了它。
       （这一条顺带解释了为什么那段布局里竖着的按钮只动竖臂：方环与长 8 的首步都朝东，点乘为 0。）
    2. 这个箭头驱动**它最近的那条合格链**，外加每一条**不被任何「有按钮的链」包含**的合格链。
       「有按钮的链」= 存在某个按钮，它自己最近的合格链就是这条。

    第二条是被反解逼出来的，不是设计。四种分组规则都试过，前三种都在数据上死了：
    · 「只认最近一条」——那段布局里长 8 那条整条动了，一次点击的 12 位只解释掉 4 位。
    · 「每个连通块各一条」——跨隙串接出来的链本来就横跨好几个连通块（那是它存在的理由），
      于是另一段布局 19 条转移全部变成弃权。
    · 「按距离贪心取互不相交的链」——那段布局复原了，另两段又各多取了一条**一位都没动**的链，7 条说错。
    · 「没有按钮认领的链就搭车」——差一步：还有一段布局的长 3 也谁都不认领，却一位都不动。

    分开「搭车」和「不动」的不是距离（不动的那条在 93 处，动了的那条在 361 处，反过来），
    也不是有没有按钮认领它，而是**它是不是别人的一段**：不动的那条长 3 整段落在一条被认领的长 21 里面——
    它不是一个没人管的物件，是一个被管着的物件的碎片；而动了的那条长 8 不被任何被认领的链包含。
    读成一句话：**有按钮的结构只听自己的按钮；真正独立又没配按钮的结构没有别的驱动手段，只能搭同轴驱动的车。**
    （这里也有个说得通的由来：那条长 8 上有一个插槽，它要是动不了，这一关就是死的。）

    可判错的地方很具体：哪天出现一条**独立、无按钮、却不跟着动**的链，或者一条
    **属于某条有按钮的链的碎片、却被别的按钮拖动**的链，这条就死了。
    还有一处**没有数据分开的岔**：现成的 86 条转移里，「不被有按钮的链包含」与「链上有插槽」
    这两个判据给出完全相同的答案。分开它们要一段这样的布局：有一条独立、无按钮、**不含插槽**的链。
    """
    a = hit_arrow(g, action)
    if a is None:
        return []
    # 同心环的把手另有其律，见 belt_of_click 里那段让路的注解。
    if hit_star_button(g, action) is not None or hit_hub_button(g, action):
        return []
    # 面板关另有其律：那里按钮离结构很远，「最近」没有分辨力，交给 panel_claim。
    # 这不是「说不准」，是**这句话不该由我说**——判据是整关性质，纯几何，见 panel_buttons。
    if panel_buttons(g, lay or layout(g)):
        return []
    lay = lay or layout(g)
    if lay is None:
        return []
    occ = set(lay["tiles"])
    cyc = [o for o in _cycles(occ, lay["rows"], lay["cols"]) if len(o) >= 2]
    if not cyc:
        return []
    d = arrow_dir(g, a)
    if d is None:
        return []
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    half = (tk - 1) / 2.0

    def _elig(btn, dd):
        """按钮 btn 指向 dd 时，全部合格链按距离升序：[(距离键, 符号, 链)]。"""
        br, bc = (btn[1] + btn[2]) / 2.0, (btn[3] + btn[4]) / 2.0
        out = []
        for o in cyc:
            step = (o[1][0] - o[0][0], o[1][1] - o[0][1])
            dot = dd[0] * step[0] + dd[1] * step[1]
            if dot == 0:
                continue
            ds = [(rows[p[0]] + half - br) ** 2 + (cols[p[1]] + half - bc) ** 2 for p in o]
            out.append(((min(ds), sum(ds) / len(ds)), 1 if dot > 0 else -1, o))
        out.sort(key=lambda e: e[0])
        return out

    # 谁有自己的按钮：每个按钮认领它自己最近的那条合格链。
    owned = []
    for b in buttons(g):
        if star_button(g, b, lay) is not None or hub_button(g, lay) == b:
            continue
        db = arrow_dir(g, b)
        if db is None:
            continue
        e = _elig(b, db)
        if e:
            owned.append(set(e[0][2]))

    mine = _elig(a, d)
    if not mine:
        return []
    out = [(mine[0][1], mine[0][2])]
    for _k, sense, o in mine[1:]:
        # 被某条有按钮的链整段包含 = 它是那条链的一段，不是独立物件（有按钮的链包含自己，
        # 所以这一句同时把「别人的按钮管的链」排掉了）。
        if any(set(o) <= w for w in owned):
            continue
        out.append((sense, o))
    return out


def belt_of_click(g, action, lay=None):
    """这一次点击驱动的**主**链：返回 (位移符号, [网格位…])；没点在带上返回 None。

    主链 = driven() 里离箭头最近的那一条。位移符号 +1 = 内容沿规范次序前移一位
    （新[i] = 旧[i-1]），-1 = 后移一位；符号由**箭头指向**与链走向的点乘定出来，不看颜色。

    别的连通块里同时被驱动的那些链**不在这里**——它们由 driven() 交给
    belt_parallel 那条概念去主张，因为「不止一条链在动」是一句独立的、能被单独打掉的话。

    同心环的把手一律不算带的把手：结构是嵌套的，而嵌套时该说话的是**更专**的那一层。
    同心环布局里每一条射线都是一条合格的直线段（于是也是一条合格的「带」候选），
    但那里的把手驱动的是整颗星，不是它贴着的那一条射线。所以星的词汇认出来了，带的词汇就闭嘴——
    不是「说不准」，是**这句话不该由我说**。判别项纯几何、不看关卡号，
    没有星的布局上那两句一律不认，因此这道让路对别的布局逐位不产生任何改动。

    注意两句判别的「没有」不是同一个值：hit_star_button 认不出返回 None，
    hit_hub_button 是个是非题、返回 False。写成统一的 `is not None` 会让第二句永真
    （`False is not None`），于是让路条件吞掉全部布局——实测过一次，逐关开口数全变 0。
    """
    ds = driven(g, action, lay)
    if not ds:
        return None
    if len(ds) == 1:
        return ds[0]
    lay = lay or layout(g)
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    half = (tk - 1) / 2.0
    a = hit_arrow(g, action)
    ar, ac = (a[1] + a[2]) / 2.0, (a[3] + a[4]) / 2.0
    return min(ds, key=lambda so: min((rows[p[0]] + half - ar) ** 2
                                      + (cols[p[1]] + half - ac) ** 2 for p in so[1]))


def tiles_after(g, action, lay=None):
    """按已知的动作律算出点击后的瓷砖颜色表。三种把手各走各的律，都由概念走闸打分：

      · 星的切向把手 -> star_rotate   · 星的径向把手 -> star_radial
      · 枢纽按钮     -> hub_swap      · 带上的箭头   -> belt_rot_a / belt_rot_b

    放进词汇只是为了别的概念（终止条件、规划器）不用再抄一遍。
    """
    lay = lay or layout(g)
    if lay is None:
        return None
    sb = hit_star_button(g, action, lay)
    if sb is not None:
        return star_after(lay, sb[0], sb[1], sb[2])
    if hit_hub_button(g, action, lay):
        sw = swap_pairs(set(lay["tiles"]))
        if sw:
            out = dict(lay["tiles"])
            for a, b in sw.items():
                out[a], out[b] = lay["tiles"][b], lay["tiles"][a]
            return out
    if panel_buttons(g, lay):
        pc = panel_claim(g, action, lay)
        if not pc:
            if hit_arrow(g, action) is not None:
                return None                # 面板关点在箭头上却认不出认领关系：弃权，不是「不动」
            return dict(lay["tiles"])
        out = dict(lay["tiles"])
        for sense, seg in pc:              # 各段互不相交（slot_rings 已核），位移一律读原帧
            a = [lay["tiles"][p] for p in seg]
            shifted = a[-1:] + a[:-1] if sense > 0 else a[1:] + a[:1]
            for p, col in zip(seg, shifted):
                out[p] = col
        return out
    ds = driven(g, action, lay)
    if not ds:
        if hit_arrow(g, action) is not None:
            return None            # 点在箭头上却认不出它那条带：这里说「什么都不动」是在瞎猜。
                                   # 从前这一支返回原样，于是「认不出」与「不动」在账面上长得一模一样，
                                   # 而前者是弃权、后者是一句会错的主张。规划器照着它挑按钮时
                                   # 会把「册子答不出的按钮」当成「按了没用的按钮」跳过——
                                   # 这两者的下一步恰好相反：一个该去撞，一个该绕开。
        return dict(lay["tiles"])  # 点在任何箭头之外：什么都不动（dead_click 的主张）
    out = dict(lay["tiles"])
    # 每个连通块里各有一条链在动，而且是**同时**动的：所有位移都读原帧、一起写进来。
    # 逐条依次改写 out 也行（各条链的位互不相交），但读原帧写得更明白：并行不是先后。
    for sense, order in ds:
        a = [lay["tiles"][p] for p in order]
        shifted = a[-1:] + a[:-1] if sense > 0 else a[1:] + a[:1]
        for p, col in zip(order, shifted):
            out[p] = col
    return out


def move_map(g, action, lay=None):
    """这一按在**位置**上的置换：{落点: 来源}；弃权返回 None，什么都不动返回空表。

    它和 `tiles_after` 是同一条律的两种写法——后者算「点击后每个位置是什么颜色」，
    这一条算「点击后每个位置的颜色是从哪个位置搬来的」。分出来只为一件事：
    **置换只由占位图与把手决定，不由颜色决定**，所以一关之内每个按钮的置换算一次就够，
    规划器搜十万个局面也不用把链的几何重算十万遍。
    等价性不靠嘴说：`runs/<run>/mapcheck.py` 对全部转移核对
    「按这张表搬颜色」与 `tiles_after` 一格不差，两者哪天不一致，那个探针会报出来。
    """
    lay = lay or layout(g)
    if lay is None:
        return None
    occ = set(lay["tiles"])

    def shift(seq, sense):
        """一条闭合次序上挪一位：落点 seq[i] 的颜色来自 seq[i-1]（sense>0）或 seq[i+1]。"""
        n = len(seq)
        out = {}
        for i, p in enumerate(seq):
            out[p] = seq[(i - 1) % n] if sense > 0 else seq[(i + 1) % n]
        return out

    sb = hit_star_button(g, action, lay)
    if sb is not None:
        ctr, kind, sense = sb[0], sb[1], sb[2]
        rings = star_rings(occ, ctr)
        if not rings:
            return {}
        out = {}
        if kind == "rot":
            for ring in rings:
                for j, p in enumerate(ring):
                    out[p] = ring[(j - sense) % 8]
        else:
            for ray in star_rays(rings):
                n = len(ray)
                for k, p in enumerate(ray):
                    out[p] = ray[(k - sense) % n]
        return out
    if hit_hub_button(g, action, lay):
        sw = swap_pairs(occ)
        if sw:
            out = {}
            for a, b in sw.items():
                out[a], out[b] = b, a
            return out
    if panel_buttons(g, lay):
        pc = panel_claim(g, action, lay)
        if not pc:
            if hit_arrow(g, action) is not None:
                return None
            return {}
        out = {}
        for sense, seg in pc:
            out.update(shift(seg, sense))
        return out
    ds = driven(g, action, lay)
    if not ds:
        if hit_arrow(g, action) is not None:
            return None
        return {}
    out = {}
    for sense, order in ds:
        out.update(shift(order, sense))
    return out


def apply_map(tiles, mm):
    """按位置置换搬一次颜色。mm 里没提到的位置原样不动。"""
    out = dict(tiles)
    for dst, src in mm.items():
        out[dst] = tiles[src]
    return out


def slots_done(tiles, lay):
    """每一个插槽都装着**它自己那个角标色**的瓷砖？插槽为空表返回 False。

    v2：从前这里比的是全局常数 BRACKET，两关侥幸都对，第三关有个 12 色插槽就漏判了。
    """
    slots = lay["slots"]
    return bool(slots) and all(tiles.get(s) == lay["slot_mark"][s] for s in slots)


def will_level_up(g, action, lay=None):
    """这一步之后会换关吗？—— 按概念 win_slots_done 的主张：插槽全装对就换关。

    给各条概念的 apply 当护栏：换关那一帧是新关的开局，谁也不敢预测，
    而 apply 拿不到 level_next，只能靠这条主张自己推。
    """
    lay = lay or layout(g)
    if lay is None or not lay["slots"]:
        return False
    after = tiles_after(g, action, lay)
    return bool(after) and slots_done(after, lay)


# ---------- 星形布局：同心环 + 八条射线 ----------
#
# 有一段布局既不是环也不是路径：占位图是几颗**八射线的星**——一个**空的**星心，
# 八个方向各伸出等长的一串瓷砖。它没有二维回路（_trace 走不出来），也不是路径
# （星心旁那一位有三个以上邻居），于是 _cycles 一条链都认不出来，上面整套「带」的词汇
# 在这里全部闭嘴（belt_of_click 返回 None）。**那是对的**：星不是带，硬套会把答案编出来。
# 星自己的两种动作、以及连通三颗星的枢纽互换，各由一条概念走闸。
_DIRS_CW = ((-1, 0), (-1, 1), (0, 1), (1, 1),
            (1, 0), (1, -1), (0, -1), (-1, -1))   # 北 东北 东 东南 南 西南 西 西北，顺时针


def star_centers(occupied):
    """星心：**空**的网格位，且它八个方向距离 1 的邻位全是瓷砖。纯几何，不看颜色。"""
    if not occupied:
        return []
    rs = [p[0] for p in occupied]
    cs = [p[1] for p in occupied]
    out = []
    for r in range(min(rs), max(rs) + 1):
        for c in range(min(cs), max(cs) + 1):
            if (r, c) in occupied:
                continue
            if all((r + d[0], c + d[1]) in occupied for d in _DIRS_CW):
                out.append((r, c))
    return out


def star_rings(occupied, ctr):
    """[[八位…北起顺时针]]：第 i 项是第 i+1 环。八位齐全才算一环，从 k=1 起连续。

    「八位齐全」这道判别项是有代价的，写清楚：某颗星的某一条射线比别的长时，
    多出来那一位**不算这颗星的**（它进不了任何一环）。实测里那一位恰恰是游离瓷砖，
    由枢纽按钮管，不由星的两种动作管 —— 所以这道判别项是对的，但它把「星是对称的」
    当成了前提。哪天有一颗星八条射线不等长而它们又一起动，这里第一个错。
    """
    out = []
    k = 1
    while True:
        ps = [(ctr[0] + k * d[0], ctr[1] + k * d[1]) for d in _DIRS_CW]
        if not all(p in occupied for p in ps):
            return out
        out.append(ps)
        k += 1


def stars(occupied):
    """{星心: [环…]}，只收至少有一环的。"""
    out = {}
    for ctr in star_centers(occupied):
        rings = star_rings(occupied, ctr)
        if rings:
            out[ctr] = rings
    return out


def star_rays(rings):
    """把环表转成射线表：第 j 条是 [k=1..kmax 上第 j 个方向的位]。"""
    return [[ring[j] for ring in rings] for j in range(8)]


def star_cells(occupied):
    """全部属于某颗星的网格位。"""
    return {p for rings in stars(occupied).values() for ring in rings for p in ring}


def swap_pairs(occupied):
    """{游离瓷砖: 与它互换的星上瓷砖}。

    游离瓷砖 = 不属于任何星的瓷砖。配对判据纯几何：每块游离瓷砖必须**恰好**有一块
    八邻接的星上瓷砖，而且配对不许撞车。有一块说不准就整张表返回 None（宁可闭嘴）。
    """
    st = stars(occupied)
    if not st:
        return None
    inside = {p for rings in st.values() for ring in rings for p in ring}
    loose = sorted(set(occupied) - inside)
    if not loose:
        return None
    pairs = {}
    for p in loose:
        nb = [q for d in _DIRS_CW
              for q in [(p[0] + d[0], p[1] + d[1])] if q in inside]
        if len(nb) != 1:
            return None
        pairs[p] = nb[0]
    if len(set(pairs.values())) != len(pairs):
        return None
    return pairs


def panel_buttons(g, lay=None):
    """这一关的按钮是不是一块**远处的面板**：每一个按钮到瓷砖包围盒的间隙都不小于一个瓷砖间距。

    由来：`belts` / `driven` 把按钮配给「离它最近的那条合格链」，七段布局都对。
    第八段布局塌了——那里的按钮是棋盘外一块成排的面板，面板上的按钮驱动的东西离它最远。
    实测：两个同色同指向的面板按钮，按最近位距离都该配同一条链，实际驱动的是不同的两条。
    距离在把手**贴着**结构时有分辨力，把手离开结构之后就没有了。

    判据不引进新常数：「一个瓷砖间距」是这段布局自己量出来的（相邻两行/两列原点之差）。
    也试过两条更省事的写法，都被数据打死，记在这里免得有人再试：
      · 「按钮在包围盒之内」——每一关都里外混着，前七段布局也有按钮在盒外而距离在那里照样对。
      · 「这一关认出了拐角环就让路」——拐角环在七段布局里有五段都存在（只是世界从没整体搬动它们），
        这条让路会把五段布局一起噎住。

    注意这是个**整关**性质，不是单个按钮的性质：只要还有一个按钮贴着棋盘，
    这一关的驱动关系就仍然由距离给出，别的远按钮也照旧按距离配。
    这一条是可判错的：出现一段布局，按钮全都远离棋盘、而距离认领仍然正确，它就死了。
    """
    lay = lay or layout(g)
    if lay is None:
        return False
    occ = list(lay["tiles"])
    bs = buttons(g)
    if not occ or not bs:
        return False
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    pr = rows[1] - rows[0] if len(rows) > 1 else tk
    pc = cols[1] - cols[0] if len(cols) > 1 else tk
    r0 = min(rows[p[0]] for p in occ)
    r1 = max(rows[p[0]] for p in occ) + tk - 1
    c0 = min(cols[p[1]] for p in occ)
    c1 = max(cols[p[1]] for p in occ) + tk - 1
    for b in bs:
        gr = max(r0 - b[2], b[1] - r1, 0)      # 行方向的间隙（重叠则 0）
        gc = max(c0 - b[4], b[3] - c1, 0)
        if gr < pr and gc < pc:
            return False                        # 有一个按钮贴着棋盘 -> 不是面板关
    return True


def _runs4(occupied, minlen):
    """四朝向（→ ↓ ↘ ↙）的极大直线段，长度 >= minlen：[(朝向, [网格位…])]。"""
    out = []
    for d in ((0, 1), (1, 0), (1, 1), (1, -1)):
        for p in sorted(occupied):
            if (p[0] - d[0], p[1] - d[1]) in occupied:
                continue
            s = [p]
            q = (p[0] + d[0], p[1] + d[1])
            while q in occupied:
                s.append(q)
                q = (q[0] + d[0], q[1] + d[1])
            if len(s) >= minlen:
                out.append((d, s))
    return out


def elbow_rings(occupied, minlen=None):
    """两段极大直线段**共用拐角**（前一段的尾端就是后一段的首端）接成的一条路径：
    [(拐角位, [网格位…从一个自由端走到另一个自由端])]。

    和 _path_chains 的 L 不是一回事：那里认的是「一整个连通块是一条路径」，
    两个自由端垂直的一律不接（有一段布局的 L 形连通块从没整体搬动过，那条判据是拿一条反例换来的）。
    这里认的是**密占位里面**两段极大直线段共用拐角——连通块的度数早就 > 2，那条路走不通。
    这种拐角在七段布局里有五段都存在，所以它单独不构成任何主张；构成主张的是 slot_rings。
    """
    rr = _runs4(occupied, minlen or MIN_RUN)
    out = []
    for da, a in rr:
        for db, b in rr:
            if da == db or a[-1] != b[0]:
                continue
            out.append((a[-1], a + b[1:]))
    return out


def slot_rings(lay):
    """这一关的**插槽拐角环**：{插槽位: [网格位…从另一头走到插槽]}；不成立时返回 {}。

    四条判据一起收紧，缺一条就整个返回空表（拐角本身太常见，光有拐角什么也说明不了）：
      1. 环的一个自由端正好是一个插槽；
      2. 环上正好驮着**一块**该插槽角标色的瓷砖；
      3. 这样的环与插槽一一对应（条数等于插槽数，插槽两两不同）；
      4. 环与环互不相交（同一块瓷砖不能同时属于两条环，否则「各转一位」会自相矛盾）。

    次序一律**从自由端走向插槽**，于是「内容沿次序前移一位」= 角标瓷砖朝插槽走一位，
    符号不用再解释一遍。
    """
    slots = lay.get("slots") or []
    mark = lay.get("slot_mark") or {}
    if not slots:
        return {}
    tiles = lay["tiles"]
    out = {}
    for corner, ring in elbow_rings(set(tiles)):
        for end, other in ((ring[-1], list(ring)), (ring[0], list(reversed(ring)))):
            if end not in slots:
                continue
            m = mark.get(end)
            if m is None:
                continue
            if sum(1 for p in other if tiles[p] == m) != 1:
                continue
            if end in out and out[end] != other:
                return {}                      # 同一个插槽两条环：分不出来，整个弃权
            out[end] = other
    if sorted(out) != sorted(slots):
        return {}
    seen = set()
    for ring in out.values():
        if seen & set(ring):
            return {}
        seen |= set(ring)
    return out


def ring_mark_index(ring, lay):
    """角标瓷砖在这条环上的序号；不是恰好一块就返回 None。"""
    m = lay["slot_mark"].get(ring[-1])
    if m is None:
        return None
    idx = [i for i, p in enumerate(ring) if lay["tiles"][p] == m]
    return idx[0] if len(idx) == 1 else None


def button_rank(g, block, lay=None):
    """这个按钮所在的**一排**：同指向、且在箭头轴向上坐标相同的全部按钮，按垂直坐标升序。

    返回 ([按钮块…], 这个按钮在排里的序号)；认不出指向返回 (None, None)。
    面板上的按钮是成排摆的，一排的长度决定它认领几条环——这条排的划分不看关卡号，纯几何。
    """
    lay = lay or layout(g)
    d = arrow_dir(g, block)
    if d is None:
        return None, None
    par = 4 if d[0] == 0 else 2                # 箭头横指 -> 沿列排队；竖指 -> 沿行排队
    per = 2 if d[0] == 0 else 4

    def key(b):
        return (b[par - 1] + b[par]) / 2.0

    def pkey(b):
        return (b[per - 1] + b[per]) / 2.0

    rank = [b for b in buttons(g)
            if arrow_dir(g, b) == d and key(b) == key(block)]
    rank.sort(key=pkey)
    if block not in rank:
        return None, None
    return rank, rank.index(block)


def panel_claim(g, action, lay=None):
    """面板上这一次点击驱动的**哪几段**：[(符号, [网格位…])]；不是面板关 / 认不出返回 []。

    律和贴着把手的那一套是同一句：**角标瓷砖朝按钮指的方向沿它那条环走一位**。
    变的只是「按钮认领哪条环」和「跟着走的是整环还是一截」：

      · 一排里有几个按钮，就认领几条环——按**垂直于箭头**的那个坐标，
        按钮升序对拐角升序，逐位配对。距离在这里没有分辨力（实测两个按钮按最近位距离
        都该配同一条环，实际驱动的是不同的两条），有分辨力的是排里的次序。
      · **一排只有一个按钮**时它认领全部环，每条环整环转一位。
      · 一排有几个（= 环数）时只转**这条环固定的那一截**：环上位于「最靠左那个拐角所在网格列」
        之前的那些位。这一截与角标在哪儿无关 —— 同一条环上角标在第 4/5/6 位时窗口一模一样，
        而窗口里的颜色每按一次都换，所以边界既不是角标的函数也不是颜色的函数，是位置。
        推论（这条律最要紧的一句）：**角标不在这一截里，这一排的按钮就搬不动它**，
        点了也只是把那一截里的颜色转一圈。三条环的窗口长度实测 7 / 6 / 2。

    符号 = 箭头指向与环规范次序（自由端 -> 插槽）**首步**的点乘同号。取首步而不取拐角处的走向，
    是因为面板按钮离结构很远，「局部」无从谈起——它既不贴着直臂也不贴着竖臂。
    （贴着把手的那一套走的是相反的改法：那里必须取局部走向，见 belt_of_click。
    同一个量在两套机制里取样点不同，因为「离按钮最近的那一位」在这里根本不是它驱动的那一位。）
    实测正反两向都按过：色 14 一排的三个各驱动一条环、符号 +1；色 8 一排的对应位符号 -1；
    独自成一排的按钮一次驱动三条环整环转一位，正反两向都**闭合**（新[-1] = 旧[0]，三条环各自核过）。

    三处**已决的岔**（都是被读数判的，写下来免得重走）：
      · 后退那一截曾写成 `环首..角标位+1`，被 762078b285ab6746 打死。
      · 接着改成「环首..角标两位里靠插槽那一个」，被 2d1d73df49fe1d96 打死：那一步角标在第 1 位、
        按的是前进，角标反而退到第 0 位，而窗口是 [0..1]——固定窗口里的轮换会把角标往回搬。
        同一个按钮连按两次原地打转（第 104、105 步互为逆操作），是「截长是角标的函数」这个想法的死因。
      · 「一次点击只搅动一条环」在一排有几个按钮时成立，实测三条环各配一个，配对靠排里的次序。

    两处**数据还没分开的岔**，写在这里等那段布局出现：
      · 门槛取「拐角列的最小值」还是「插槽列的最小值」——这一关两者都等于同一列，分不开。
        要分开它们，需要一段最靠左的拐角与最靠左的插槽不在同一列的布局。
      · 认领关系可以读成「按垂直坐标最近的拐角」，也可以读成「排里的次序对拐角的次序」。
        现成的转移上两种读法给出同一个答案。分开它们要一排按钮的间距与拐角的间距**不成比例**。
    """
    lay = lay or layout(g)
    if lay is None or not panel_buttons(g, lay):
        return []
    a = hit_arrow(g, action)
    if a is None:
        return []
    d = arrow_dir(g, a)
    if d is None:
        return []
    rings = slot_rings(lay)
    if not rings:
        return []
    order = sorted(rings.values(), key=lambda r: _corner_key(r, lay, d))
    rank, i = button_rank(g, a, lay)
    if rank is None:
        return []
    if len(rank) == 1:
        picks = order
        whole = True
    elif len(rank) == len(order):
        picks = [order[i]]
        whole = False
    else:
        return []                              # 一排的长度既不是 1 也不是环数：认不出
    out = []
    for ring in picks:
        step = _ring_step_at(ring, 0)
        dot = d[0] * step[0] + d[1] * step[1]
        if dot == 0:
            continue
        sense = 1 if dot > 0 else -1
        if whole:
            seg = ring
        else:
            # 这一截是**每条环固定的一段**，与角标在哪儿无关：环上位于「最靠左那个拐角所在网格列」
            # 之前的那些位。三条环的窗口末位实测分别落在同一个网格列上，窗口外第一位也都落在下一列，
            # 而同一条环上角标在第 4/5/6 位时窗口一模一样——所以边界是位置性的，不是角标的函数。
            # 这里不写死列号：门槛取「拐角列的最小值」，从结构自己读出来。
            if d[0] != 0:
                return []          # 竖指的箭头没数据，门槛该取行还是取列说不准 -> 弃权
            lim = min(_corner_of(r)[1] for r in rings.values())
            n = sum(1 for p in ring if p[1] < lim)
            if n < 2 or [p for p in ring if p[1] < lim] != ring[:n]:
                return []          # 窗口不是环首的一段：这条规律没覆盖，弃权
            seg = ring[:n]
        out.append((sense, seg))
    return out


def _corner_of(ring):
    """环上的拐角位：走向发生变化的那一位。"""
    for i in range(1, len(ring) - 1):
        a = (ring[i][0] - ring[i - 1][0], ring[i][1] - ring[i - 1][1])
        b = (ring[i + 1][0] - ring[i][0], ring[i + 1][1] - ring[i][1])
        if a != b:
            return ring[i]
    return ring[len(ring) // 2]


def _ring_step_at(ring, i):
    j = min(max(i, 0), len(ring) - 2)
    return (ring[j + 1][0] - ring[j][0], ring[j + 1][1] - ring[j][1])


def _corner_key(ring, lay, d):
    """给环排队用的键：拐角在**垂直于箭头**那个轴上的像素坐标。"""
    c = _corner_of(ring)
    return lay["cols"][c[1]] if d[0] != 0 else lay["rows"][c[0]]


def buttons(g):
    """场地里真正的按钮块：箭头块里**最短边 >= 3** 的那些。

    第 1 行那排细条（高 1）是过关计数的 HUD，不是按钮；它一直被 arrows() 收着，
    从前无害（点不着，且 belt_of_click 会因为指向与链首步垂直而闭嘴），
    到了星形布局就必须分开——否则「场上还剩几个不属于星的按钮」会被它们顶掉。
    """
    return [b for b in arrows(g)
            if min(b[2] - b[1] + 1, b[4] - b[3] + 1) >= 3]


def star_button(g, block, lay=None):
    """这个按钮块是不是某颗星的把手：是就返回 (星心, 类型, 符号)，不是返回 None。

    判别全是几何的。**对齐**：按钮必须贴在某条射线最外那一位的外面——以那一位的像素中心
    为原点，按钮中心沿射线方向的分量为正且不超过三个瓷砖宽，垂直分量不超过一个瓷砖宽。
    这道对齐判据把星的把手和场上别的按钮分开（只按「离哪颗星近」会把远处的孤立按钮
    错配给某条斜射线）。**类型**看按钮指向与射线方向的点乘：
      · 点乘 != 0（指着背离或朝着星心）= "rad" 径向：八条射线的内容一起沿射线挪一位，
        符号 +1 = 朝外（环 k -> 环 k+1，最外一环绕回最里）。
      · 点乘 == 0（与半径垂直）= "rot" 切向：三个环一起绕星心转一位，
        符号 +1 = 内容朝顺时针（_DIRS_CW 的下一位）走。
    两种符号都由同一条更朴素的话定出来：**挨着把手那一位的内容，朝把手指的方向走**。
    """
    lay = lay or layout(g)
    if lay is None:
        return None
    occ = set(lay["tiles"])
    tk = lay["tile"]
    half = (tk - 1) / 2.0

    def pix(p):
        return (lay["rows"][p[0]] + half, lay["cols"][p[1]] + half)

    br, bc = (block[1] + block[2]) / 2.0, (block[3] + block[4]) / 2.0
    d = arrow_dir(g, block)
    for ctr, rings in sorted(stars(occ).items()):
        outer = rings[-1]
        cy, cx = pix(ctr)
        for j, q in enumerate(outer):
            qy, qx = pix(q)
            uy, ux = qy - cy, qx - cx
            n = (uy * uy + ux * ux) ** 0.5
            if n == 0:
                continue
            uy, ux = uy / n, ux / n
            vy, vx = br - qy, bc - qx
            along = vy * uy + vx * ux
            perp = abs(vy * ux - vx * uy)
            if not (0 < along <= 3 * tk and perp <= tk):
                continue
            dot = d[0] * uy + d[1] * ux
            if abs(dot) < 1e-9:
                ny, nx = pix(outer[(j + 1) % 8])
                s = 1 if d[0] * (ny - qy) + d[1] * (nx - qx) > 0 else -1
                return (ctr, "rot", s)
            return (ctr, "rad", 1 if dot > 0 else -1)
    return None


def hub_button(g, lay=None):
    """枢纽按钮：场上唯一一个不属于任何星的按钮块。恰好一个才返回，零个或多个返回 None。"""
    lay = lay or layout(g)
    if lay is None or not stars(set(lay["tiles"])):
        return None
    free = [b for b in buttons(g) if star_button(g, b, lay) is None]
    return free[0] if len(free) == 1 else None


def _in_block(rc, b):
    return b[1] <= rc[0] <= b[2] and b[3] <= rc[1] <= b[4]


def hit_star_button(g, action, lay=None):
    """点击落在某颗星的把手上 -> (星心, 类型, 符号)；否则 None。"""
    rc = _xy(action)
    if rc is None:
        return None
    lay = lay or layout(g)
    if lay is None:
        return None
    for b in buttons(g):
        if _in_block(rc, b):
            return star_button(g, b, lay)
    return None


def hit_hub_button(g, action, lay=None):
    """点击落在枢纽按钮上？"""
    rc = _xy(action)
    if rc is None:
        return False
    hb = hub_button(g, lay)
    return hb is not None and _in_block(rc, hb)


def star_after(lay, ctr, kind, sense):
    """一次星动作之后的瓷砖颜色表（只改这颗星的位，别处照抄）。"""
    tiles = dict(lay["tiles"])
    rings = star_rings(set(lay["tiles"]), ctr)
    if not rings:
        return tiles
    if kind == "rot":
        for ring in rings:
            old = [lay["tiles"][p] for p in ring]
            for j, p in enumerate(ring):
                tiles[p] = old[(j - sense) % 8]
    else:
        for ray in star_rays(rings):
            old = [lay["tiles"][p] for p in ray]
            n = len(ray)
            for k, p in enumerate(ray):
                tiles[p] = old[(k - sense) % n]
    return tiles


def paint(lay, tiles):
    """把瓷砖颜色表摊成逐像素的 {(y, x): 色}，给各条概念的 apply 用。"""
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for (r, c), col in tiles.items():
        y, x = rows[r], cols[c]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out

