"""箭头指向与它那条带的规范次序**反向**时，带上的瓷砖颜色整体沿次序前移一格（新[i] = 旧[i+1] 循环）。

规范次序由 _lib.belts 走出来：从带上最左上那一位起、第二位在它东边（没有东邻就取字典序小的邻居）。
「反向」= 箭头指向与次序第一步的点乘为负。物理上这两条（本条与 belt_rot_b）说的是同一件事：
**内容朝箭头指的方向挪一位**；分成两条只是因为符号相反、各自都要能被单独打掉。
"""
LEVEL = "L1"
SCOPE = ("只看点中箭头、_lib 认得出这条带、且箭头指向与次序首步反向的 ACTION6；"
         "同向交给 belt_rot_b；指向与首步垂直返回 NA；换关返回 NA；布局认不出返回 NA")
NOTE = ("v2：apply 在「这一步会换关」时闭嘴（scope 本来就写着换关 NA，但 apply 读不到 level_next，"
        "靠 win_slots_done 的主张自己推）。"
        "v3 的 EVIDENCE 里多出来的那几条不是新证据，是**假反例登记**："
        "把带追踪器从「直线+90°」推广到「直线+45°+90°」时，中途那一版会抄近路走出残缺的链，"
        "于是这条概念在旧布局上集体判 FALSE。追踪器补上「闭链方向变化不超 90°、最多一处绕回、"
        "去掉被真包含的残片」三道判据后，它在这几条上都判 TRUE —— 断言一个字没改，是眼睛坏了又修好。"
        "v4：真被打掉了一次。从前这条概念的适用范围写的是「点中 8 色箭头」，三段布局都对。"
        "第四段布局里有一对**竖直**的箭头，8 色那个指「下」，而这条链的规范次序第一步正是「下」，"
        "于是内容朝次序前进而不是后退，断言判 FALSE（880d3f2543be6cea）。"
        "查下来颜色从来就不是方向：8 色恒为「左或下」、14 色恒为「右或上」，"
        "在前三段布局里每条链的第一步都是「东」，所以「左」总是反向、「右」总是同向，颜色看着像在管方向。"
        "方向真正写在箭头**形状**里（缺角那一侧就是指向，见 _lib.arrow_dir）。"
        "断言体一个字没改，改的是适用范围：从「按颜色分」改成「按指向与次序首步的点乘符号分」。"
        "880d3f2543be6cea 留在 EVIDENCE 里作为逼出 v4 的那条证据，如今它落进 belt_rot_b 的范围，本条判 NA。"
        "教训：一个二值特征在头几段布局上与真判据同步，是最贵的巧合——"
        "它让适用范围看起来被验证过 43 次，其实一次都没被单独考过。"
        "v5：又被打了一次，打的还是**链**不是断言（2051cbf0c4890e52、b3e198cf1ff8a453）。"
        "第五段布局的占位图是一条 21 位的开放蛇形路径：没有二维回路，也不是直线，"
        "_trace 走到死头返回 None，整关只认出其中一条长 5 的直线段，于是驱动整条蛇的那个箭头被配错了链。"
        "词汇补两条判据后这两条都判 TRUE：开放路径首尾相接成环（_lib._path_chains，"
        "判据是连通块里每一位的 4-邻居数都 <= 2 且恰有两个端点，纯几何）；"
        "自绕回的直线带至少要有一头是自由端（_lib._free_end_runs）—— 后一条是为了区分"
        "「独立的带」和「闭环的一条侧边」，侧边两头都接着拐角，带至少有一头空着。"
        "断言体一个字没改。五段布局全部 57 条同关转移逐格复核零错。"
        "警告留在这里：这一关**同一位可以属于两条链**（行 0 那五位既是独立短带、又是长链的一段），"
        "所以箭头配链现在多了一档打平判据（最小距离相同就比全链平均距离，见 _lib.belts）。"
        "这一档只在链嵌套时起作用，是本条概念目前最没被考过的地方——"
        "下一段布局若有箭头贴在两条嵌套链的**中间**而不是短带的一头，它就会认错。"
        "v6：第六段布局又打了一次，打的**还是链**——第三次了，而且这次是我自己预先押错的。"
        "占位图是个 L：横臂八位加两位竖臂。我押它首尾相接成一条长 10 的闭环，"
        "并把落空条件写进了押注（「若整条竖臂不参与，那就是 L 不是一条环」）。"
        "世界回了 9 格帧差而不是四十来格，反解出来唯一解是**竖臂那三位自己转了一格**"
        "（(0,0),(1,0),(2,0) 的 3-轮换；第三位看不见是因为两头同色）。"
        "真凶不在断言也不在配链判据，而在 `_lib.MIN_RUN`：极大直线段要长 >= 4 才当候选，"
        "这条竖臂长 3，于是它根本没被列出来，两个竖着的按钮被距离配给了包着它的长环。"
        "门槛改成 3 之后这两条都判到位。**这不是假反例，是真证据**："
        "它证伪的是「哪些直线段够格当带」这个一直没被单独考过的常数。"
        "顺带查明的一件事更要紧：第五段布局的长蛇**同时**有两种读法都是真的——"
        "整条 21 位当一条环（6 条转移），行 0 那段长 5 的直线段自己当一条带（4 条转移），"
        "所以「L 会拆、蛇不拆」这个我一度以为的矛盾根本不存在，两段布局都是同一套嵌套。"
        "247e318364df83f9 是本条被披露的那一条，登记在此；门槛改对之后它的符号是 +1，"
        "落进 belt_rot_b 的范围，本条在它上面判 NA（同 880d3f2543be6cea 的先例）。")
EVIDENCE = ["4c0c8a2fb6aacffa", "02bfcf1d72c29687", "09374ed9704ebd30", "bd5b41b5e8042186",
            "880d3f2543be6cea", "2051cbf0c4890e52", "b3e198cf1ff8a453",
            "247e318364df83f9"]

from _lib import belt_of_click, layout, will_level_up


def _belt(prev, action):
    lay = layout(prev)
    if lay is None:
        return None, None
    b = belt_of_click(prev, action, lay)
    if b is None or b[0] > 0:
        return None, None
    return lay, b[1]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, order = _belt(prev, action)
    if order is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    a = [lay["tiles"][p] for p in order]
    b = [lay2["tiles"][p] for p in order]
    return "TRUE" if b == a[1:] + a[:1] else "FALSE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None                    # 换关那一帧是新关的开局，这条概念不敢说
    lay, order = _belt(prev, action)
    if order is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    a = [lay["tiles"][p] for p in order]
    shifted = a[1:] + a[:1]
    out = {}
    for (r, c), col in zip(order, shifted):
        y, x = rows[r], cols[c]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out
