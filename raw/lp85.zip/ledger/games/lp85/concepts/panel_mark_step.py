"""每一次面板点击之后，每条插槽拐角环上**仍然恰好一块角标瓷砖**；角标落在这次点击驱动的那一截里
的环上它沿次序挪了恰好一位，其余的环上（没被驱动的，以及被驱动但角标不在那一截里的）一位没挪。

这句话是这一关规划器的全部状态：如果它成立，整关的局面只需要记「三块角标瓷砖各在自己那条环的第几位」，
而不是整张 69 格的布局——搜索空间从天文数字塌成环长之积。
它也是**目标可达性**的前提：过关要三块角标同时停在三条环的末位（末位就是插槽），
而每次点击只让它们各挪一位，于是「还差几位」是个能算的量。

可判错处很具体：出现一次点击让某块角标挪了两位、或者环上多出/少掉一块角标色瓷砖，这条就死了；
角标在窗口外却被那一排搬动了，也死。

「角标不在那一截里就不动」不是补丁，是这一关最要紧的那句话的另一半：
一排里的按钮只搅动每条环上一段**固定**的窗口（见 _lib.panel_claim），角标出了窗口，
那一排就再也搬不动它，只有独自成一排的按钮（整环转）才搬得动。
规划器要是不知道这一条，会以为每个按钮永远可用——那正是它算出一条走不通的路线的原因。
"""
LEVEL = "L6"
SCOPE = ("只看面板关（_lib.panel_buttons 为真）、认得出插槽拐角环、且 _lib.panel_claim "
         "认出至少一截的 ACTION6；认不出返回 NA；换关返回 NA；布局认不出返回 NA；"
         "点击前后占位图变了返回 NA")
NOTE = ("v1。「挪一位」写成「新序号 ∈ {(k+1) mod L, (k-1) mod L}」而不是「等于 k+符号」，"
        "因为一截的长度是「环首到角标位后一位」，角标恰在序号 0 时那一截只有两位，"
        "反向转它会把角标送到序号 1 —— 方向上是前进。方向由 panel_rank_rot / panel_all_rot 那两条负责，"
        "这一条只负责「每次恰好一位、而且不多不少还是一块」，那才是规划器真正依赖的不变量。")
EVIDENCE = ["6147a88d5fcac7e0", "5e3e508f0d9efa07"]

from _lib import (layout, panel_buttons, panel_claim, hit_arrow,
                  slot_rings, ring_mark_index)


def _state(lay):
    """{插槽位: (环长, 角标序号)}；有一条环认不出角标就返回 None。"""
    rings = slot_rings(lay)
    if not rings:
        return None
    out = {}
    for slot, ring in rings.items():
        k = ring_mark_index(ring, lay)
        if k is None:
            return None
        out[slot] = (len(ring), k)
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    la = layout(prev)
    if la is None or not panel_buttons(prev, la):
        return "NA"
    if hit_arrow(prev, action) is None:
        return "NA"
    pc = panel_claim(prev, action, la)
    if not pc:
        return "NA"
    lb = layout(nxt)
    if lb is None or set(lb["tiles"]) != set(la["tiles"]):
        return "NA"
    sa, sb = _state(la), _state(lb)
    if sa is None or sb is None:
        return "FALSE"          # 环上不再是恰好一块角标：这条概念说了它不会这样
    if sorted(sa) != sorted(sb):
        return "NA"             # 插槽集合变了：不是同一段布局，这条不管
    driven_seg = {}                     # 环首 -> 这一按在那条环上驱动的那一截
    for _s, seg in pc:
        driven_seg[seg[0]] = seg
    rings = slot_rings(la)
    for slot in sa:
        n, k0 = sa[slot]
        _n1, k1 = sb[slot]
        seg = driven_seg.get(rings[slot][0])
        # 只有「这条环被驱动」**而且**「角标就在那一截里」，角标才该动。
        if seg is not None and k0 < len(seg):
            if k1 not in ((k0 + 1) % len(seg), (k0 - 1) % len(seg)):
                return "FALSE"
        elif k1 != k0:
            return "FALSE"
    return "TRUE"
