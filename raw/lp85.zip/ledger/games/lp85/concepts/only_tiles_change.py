"""同一关里，除了第 0 列的竖条和瓷砖位覆盖的格子，屏幕上其余每一格都不变。

包括外框底色、顶部那排 HUD 小段、场地底色、箭头块本身、四角的角标。
角标不变这一条尤其要被撞：插槽固定不动是「把某块瓷砖转进插槽」这条路线的全部前提。
"""
LEVEL = "L0"
SCOPE = "只看 ACTION6；换关返回 NA；布局认不出返回 NA"
NOTE = "接替撤册的 static_rest：瓷砖位从写死坐标改成从帧上认。v2：apply 在「这一步会换关」时闭嘴（scope 本来就写着换关 NA，但 apply 读不到 level_next，靠 win_slots_done 的主张自己推）。"
EVIDENCE = ["4c0c8a2fb6aacffa", "9a72d206f4ac15a2"]

from _lib import BAR_COL, layout, will_level_up


def _free(prev):
    lay = layout(prev)
    if lay is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    covered = set()
    for r, c in lay["tiles"]:
        y, x = rows[r], cols[c]
        for dy in range(tk):
            for dx in range(tk):
                covered.add((y + dy, x + dx))
    return [(y, x) for y in range(len(prev)) for x in range(len(prev[0]))
            if x != BAR_COL and (y, x) not in covered]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    free = _free(prev)
    if free is None:
        return "NA"
    for y, x in free:
        if prev[y][x] != nxt[y][x]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6"):
        return None
    if will_level_up(prev, action):
        return None
    free = _free(prev)
    if free is None:
        return None
    return {(y, x): prev[y][x] for y, x in free}
