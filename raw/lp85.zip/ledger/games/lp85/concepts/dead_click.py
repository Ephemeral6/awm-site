"""点击没落在任何箭头块里，整帧一格不动：屏幕上除了箭头，没有别的地方受理点击。

第 0 关的两个箭头之外、第 1 关的六个箭头之外，都撞过。
"""
LEVEL = "L2"
SCOPE = "只看 ACTION6 且落点在全部箭头块之外；换关返回 NA；点不出坐标返回 NA"
NOTE = "v2：把「哪两块是按钮」从写死坐标改成从帧上认（8 色/14 色连通块），第 1 关新出现的六个箭头才不会把它打成反例。"
EVIDENCE = ["868d1479da76e839", "dfe44e4621db7e3b", "96a87d750c230ccb", "11bc826c957c2bd8",
            "1c1dab3886f724a0", "948fad354a9d2c90", "e08a17df00a6bd8d", "6fc19b2d28ad8144"]

from _lib import _xy, hit_arrow


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6") or _xy(action) is None:
        return "NA"
    if hit_arrow(prev, action) is not None:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6") or _xy(action) is None:
        return None
    if hit_arrow(prev, action) is not None:
        return None
    return {(y, x): v for y, row in enumerate(prev) for x, v in enumerate(row)}
