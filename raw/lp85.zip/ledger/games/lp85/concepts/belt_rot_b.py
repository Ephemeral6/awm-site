"""箭头指向与它那条带的规范次序**同向**时，带上的瓷砖颜色整体沿次序后移一格（新[i] = 旧[i-1] 循环）。

与 belt_rot_a 严格互逆：那条管反向，这条管同向。「同向」= 箭头指向与次序第一步的点乘为正。
"""
LEVEL = "L1"
SCOPE = ("只看点中箭头、_lib 认得出这条带、且箭头指向与次序首步同向的 ACTION6；"
         "反向交给 belt_rot_a；指向与首步垂直返回 NA；换关返回 NA；布局认不出返回 NA")
NOTE = ("v2：apply 在「这一步会换关」时闭嘴，同 belt_rot_a。"
        "v3 多出来的 tid 是假反例登记：带追踪器推广到 45° 转弯时中途那一版走出残缺的链，"
        "修好后这条概念在它们上面判 TRUE，断言一个字没改。详见 belt_rot_a 的 NOTE。"
        "v4：适用范围从「点中 14 色箭头」改成「指向与次序首步同向」，理由见 belt_rot_a 的 v4 —— "
        "颜色只是指向的影子，第四段布局的竖直箭头把它拆穿了。断言体一个字没改。"
        "另外 896385d8d2ea36b3 是真反例，但打的不是这条断言而是**链**："
        "第四段布局里两条平行直线其实首尾相接成一条长 20 的闭链，"
        "旧的追踪器把它认成两条长 10，于是点一次「另一条线也在动」，判 FALSE。"
        "决定性证据是那一步的两个接缝位：一条线末位的颜色出现在另一条线首位上，"
        "两个接缝的颜色各不相同，不是撞巧。链的判别项（网格坐标等不等距）写在 _lib._gapped_chains 里。"
        "880d3f2543be6cea 是从 belt_rot_a 的范围里划过来的：它是一条竖直链上的同向点击。"
        "v5：第六段布局打了一次，打的又是**链**不是断言，详见 belt_rot_a 的 v6——"
        "`_lib.MIN_RUN` 那个「直线段要长 >= 4 才当候选」的门槛把一条长 3 的竖臂挡在候选之外，"
        "两个竖着的按钮于是被距离配给了包着它的长环。门槛改成 3 之后逐格到位。"
        "d4e2c1c2f0ce5e5c 是本条被披露的那一条，登记在此；改对之后它的符号是 -1，"
        "落进 belt_rot_a 的范围，本条在它上面判 NA。"
        "另有一处**改词汇时差点造出来的假反例**记在这里当教训：把门槛降到 3 之后，"
        "同心环那一关每条射线（长 3）也成了合格的带候选，`belt_of_click` 当场在 6 条"
        "**已结算**的星形转移上开了口——那里的真相是整颗星旋转，不是某一条射线平移。"
        "是先跑了逐关「谁开口」的探针才发现的，没有让它进结算。"
        "补的判据是让路：点击被星的词汇认出来时带的词汇一律闭嘴（结构嵌套时该说话的是更专的那一层）。"
        "v5 又挨了三条（6147a88d5fcac7e0、1264c889cbe2e802、5e3e508f0d9efa07），登记在此；"
        "打的还是**链**——准确说是这一次连「谁驱动谁」一起打掉了。第七段布局的按钮是棋盘外"
        "一块成排的面板，`belts`/`driven` 的「配离它最近的那条合格链」在那里没有分辨力，"
        "配出来的链跟实际动的毫无关系。断言一个字没改：`_lib.panel_buttons` 为真时"
        "带的词汇一律让路，本条在这三条上判 NA。"
        "这是同一条让路手续的第二次使用（第一次是同心环），而两次的判别项不同："
        "星那次看的是结构，这次看的是**按钮离结构有多远**。")
EVIDENCE = ["9a72d206f4ac15a2", "21b19cf8a88da2a6", "28905e8225d8f3b5", "d8c0a4818ed40e9d",
            "896385d8d2ea36b3", "880d3f2543be6cea",
            "d4e2c1c2f0ce5e5c",
            "6147a88d5fcac7e0", "1264c889cbe2e802", "5e3e508f0d9efa07"]

from _lib import belt_of_click, layout, will_level_up


def _belt(prev, action):
    lay = layout(prev)
    if lay is None:
        return None, None
    b = belt_of_click(prev, action, lay)
    if b is None or b[0] < 0:
        return None, None
    return lay, b[1]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, order = _belt(prev, action)
    if order is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    a = [lay["tiles"][p] for p in order]
    b = [lay2["tiles"][p] for p in order]
    return "TRUE" if b == a[-1:] + a[:-1] else "FALSE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, order = _belt(prev, action)
    if order is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    a = [lay["tiles"][p] for p in order]
    shifted = a[-1:] + a[:-1]
    out = {}
    for (r, c), col in zip(order, shifted):
        y, x = rows[r], cols[c]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out
