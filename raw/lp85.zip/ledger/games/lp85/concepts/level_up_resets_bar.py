"""换关**到一个真的还要打的新关**那一步，第 0 列的竖条清零：新关重新从 0 格开始记生效点击。

所以竖条量的是「本关花了几次」，不是整局花了几次。
赢下最后一关那一步不算换关：那一步之后没有新关可开始，竖条停在原地不动。
"""
LEVEL = "L4"
SCOPE = ("只看换关（ctx.level_prev != level_next）**而且关后还在打**（state_next 不是 WIN / GAME_OVER）"
         "的转移；终局那一步返回 NA；条子形态认不出返回 NA")
NOTE = ("v2：补 apply。它是唯一敢对换关那一帧开口的概念——只开口第 0 列，别的格子（新关的布局）谁也预测不了。"
        "v3：被赢下最后一关那一步打死，缩 scope。读数很干净：七次真换关，竖条前后是 "
        "30→0 / 7→0 / 15→0 / 6→0 / 9→0 / 15→0 / 6→0；终局那一步是 17→17，"
        "既没清零、连这一次点击本身都没记上——终局那一帧是冻住的，不是新关的第 0 帧。"
        "所以清零不是「关号变了」的后果，是「新关开始了」的后果，而终局关号也变（7→8）却没有第 8 关。"
        "**没被这条读数分开的**：这里写的门槛是「关后还在打」，落选的是「关后的关号还小于总关数」"
        "（本局两者只在这一条转移上有分歧，而它们在这条上给同一个答案）。"
        "要分开它们，需要一条换关同时掉进 GAME_OVER 的转移——前者会弃权，后者仍要求清零。"
        "这不是我判断不出，是数据没有。"
        "v4：**上一版的 NOTE 里有一句是错的，就是这一版要收回的那句。**"
        "v3 写着「apply 故意不跟着缩」，理由是「册子从帧上看不出总共有几关，"
        "于是分不出这一按打完一关还是打完整局；缩它得靠 ctx 里的 state_next，那是答案」，"
        "还把那 17 格说错记成「一个真实盲区的价钱」。"
        "那个理由不成立：第 1 行一直排着过关计数的细条，`_lib.buttons` 的注释里就写着它是什么，"
        "只是没有概念去读它。读出来之后（新概念 hud_counts_levels，八条细条、逐关已过数 0..7、"
        "全部转移点击前那一帧与上游关号一条不差），「是不是最后一关」变成**点击前就能算的量**，"
        "于是 apply 可以正当地闭嘴，用的是事前读数而不是答案。那 17 格不是盲区，是没去读。"
        "教训：宣布一件事「册子原理上看不出」之前，先把词汇里已有的注解翻一遍——"
        "「看不出」和「我没去读」在账面上长得一模一样（都是一条概念在某类转移上说错），"
        "而前者该记成边界、后者该去干活。我差点把后者写成前者存进去。")
EVIDENCE = ["eb0fe73a8be3965b", "e7cfe2e643548420"]

from _lib import BAR_COL, BAR_EMPTY, bar_prefix, will_level_up, is_last_level

TERMINAL = ("WIN", "GAME_OVER")


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx["level_prev"] == ctx["level_next"]:
        return "NA"
    if ctx.get("state_next") in TERMINAL:
        return "NA"                 # 没有新关要开始，这条概念的主语不存在
    b = bar_prefix(nxt)
    if b is None:
        return "NA"
    return "TRUE" if b == 0 else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6"):
        return None
    if not will_level_up(prev, action):
        return None
    if is_last_level(prev) is not False:
        return None            # 最后一关（或细条读不出）：那一按之后没有新关，帧是冻住的，不开口
    return {(y, BAR_COL): BAR_EMPTY for y in range(len(prev))}
