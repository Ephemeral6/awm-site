"""一次点击只搅动被点中那个把手管的那些位：点星的把手，这颗星以外一块不动；点枢纽按钮，没参与互换的一块不动。

「管的那些位」由把手的种类定，全是几何算出来的，不看颜色：
星的把手（切向或径向）管这颗星三个环上那 24 位；枢纽按钮管 `_lib.swap_pairs` 里那几对。
别的两颗星、游离瓷砖、插槽、以及被点那颗星射线之外的空网格位，全部原样。

这条概念的用处不在它自己对不对，而在它是**结构认错时第一个喊出来的**。
它的前身 off_belt_static 两次都是这个角色：断言一个字没改，垮的每次都是「带」认错了。
这里同理——它判 FALSE 时先怀疑星、射线、或互换配对认错了，别急着怀疑「一次点击只搅动一个结构」本身。
"""
LEVEL = "L1"
SCOPE = ("只看点中星的把手或枢纽按钮的 ACTION6；两者都没点中（含点在空处、点在过关计数那排细条上）返回 NA；"
         "换关返回 NA；布局认不出或网格位变了返回 NA；枢纽按钮那一支里 swap_pairs 说不准返回 NA。")
NOTE = ("v1。作用域故意写得比 star_rotate / star_radial / hub_swap 三条合起来更宽一点："
        "那三条各自只管「自己那些位算对了没有」，谁都没说别处不动，"
        "于是「一次点击的影响范围有多大」这件事在册子里本来没有任何一条概念管——"
        "而它恰恰是规划器最依赖的一条（三颗星能不能各自独立地规划，全看这一条真不真）。"
        "把它单列，是为了让它能被单独打掉：哪天按一颗星的把手连带动了另一颗星，"
        "垮的应该是这一条，而不是让另外三条一起判错、看起来像三个 bug。"
        "EVIDENCE 只抽头两次（同一颗星上的两种把手）；另一颗星的两次和枢纽那一次都是"
        "先押注后按的，留在 universe 里——「一次点击只搅动一个结构」这句话恰恰要靠"
        "**没抽进依据的那几颗星**来考，抽进来就等于自己给自己出题。")
EVIDENCE = ["4ca96717e07c1891", "d413cdf6d2f5e9db"]

from _lib import (hit_hub_button, hit_star_button, layout, paint, star_rings,
                  swap_pairs, will_level_up)


def _frozen(prev, action):
    """(lay, [这次动作不许改的位])：没点中任何把手就返回 (None, None)。"""
    lay = layout(prev)
    if lay is None:
        return None, None
    occ = set(lay["tiles"])
    sb = hit_star_button(prev, action, lay)
    if sb is not None:
        rings = star_rings(occ, sb[0])
        if not rings:
            return None, None
        mine = {p for ring in rings for p in ring}
        return lay, [p for p in occ if p not in mine]
    if hit_hub_button(prev, action, lay):
        sw = swap_pairs(occ)
        if not sw:
            return None, None
        moved = set(sw) | set(sw.values())
        return lay, [p for p in occ if p not in moved]
    return None, None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, off = _frozen(prev, action)
    if off is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    for p in off:
        if lay["tiles"][p] != lay2["tiles"][p]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, off = _frozen(prev, action)
    if off is None:
        return None
    return paint(lay, {p: lay["tiles"][p] for p in off})
