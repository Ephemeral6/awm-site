"""还有插槽没装上**它自己角标色**的瓷砖，关卡就绝不会变 —— 除了配齐插槽，没有别的过关方式。

这是 win_slots_done 的否定面，也是它更值钱的一半：正向那条一关只撞一次，
这条每一步都在撞。有别的过关触发（走够步数、点某个隐藏格、条子填满自动过），它当场是反例。
"""
LEVEL = "L5"
SCOPE = "只看 ACTION6 且算出来还有插槽没配对的转移；布局或插槽认不出返回 NA"
NOTE = ("v2：插槽配对从「全局角标色」改成「逐槽角标色」——词汇 layout 从前只认一种角标色，"
        "漏掉了一整个插槽，于是这条概念在那一步误判成 NA（该说话的时候没说话）。断言结构没动。")
EVIDENCE = ["4c0c8a2fb6aacffa", "6fc19b2d28ad8144", "7bb065c9c290f634"]

from _lib import layout, slots_done, tiles_after


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6") or ctx is None:
        return "NA"
    lay = layout(prev)
    if lay is None or not lay["slots"]:
        return "NA"
    after = tiles_after(prev, action, lay)
    if after is None or slots_done(after, lay):
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] else "FALSE"
