"""第 1 行那排等宽等距的细条是**过关计数**：染成 14 色的是已过的关，染成 5 色的是还没过的，
已过的总是靠左的一段前缀，条数总和就是这一局总共有几关。
所以从任何一帧都能读出「已过几关 / 共几关」，进而读出「这一关是不是最后一关」。

**落进终止态（WIN / GAME_OVER）的那一帧是例外：它的计数显示不再更新。**
细条停在「已过 7」不往前走，竖条停在原地不清零，两者是同一件事。
（不是整帧冻住——那一帧的瓷砖照常动过；全帧一格不变的转移在语料里只有关 0 的空点。）
这个例外**与那一帧站在转移的哪一侧无关**：它当点击后那一侧读不得，当点击前那一侧同样读不得。

可判错处很具体：任何一侧读得出的帧，已过条数和上游给的那一侧关号不一致，或者已过的那些不是
靠左的一段前缀，这条就死了。它不是装饰——它是册子回答「这一关是不是最后一关」的唯一依据，
而那个问题决定了换关那一步该不该预测竖条清零。
"""
LEVEL = "L4"
SCOPE = ("只看细条形态认得出（_lib.hud_ticks 非空、宽度与间距齐、已过的是前缀）的转移；"
         "认不出或上游没给关号返回 NA；"
         "**站在终止态（WIN / GAME_OVER）那一侧的帧不查**——它的计数显示没有重绘；"
         "两侧都是终止帧时整条返回 NA；"
         "「总关数中途不变」只在两侧都不是终止帧时查（跨卡换局时总关数本可以不同）")
NOTE = ("v2。反例 250a…（换卡那一步，动作 RESET）：上游给 level_prev=8，而点击前那一帧正是"
        "赢局那一帧，细条读出「已过 7」、竖条读出 17，于是判 FALSE。实测三帧读数："
        "赢局前 已过7/竖条16 → 赢那一按 已过7/竖条17 → 换卡后 已过0/竖条0。"
        "所以死因不是细条读错，是**那一帧的计数显示压根没重绘**——v1 里已经写着这个例外，"
        "但只写成了「点击后那一侧」，因为我当时只见过终止帧当 next 的转移。"
        "**把例外写成单侧的条件，等到同一帧成为另一侧的输入，它就复活了。**"
        "v2 改成按侧独立判：每一侧读得出就各出一个判决，有一侧不符即 FALSE，两侧都读不出才 NA。"
        "\nv1。由来是一次说错：level_up_resets_bar 在赢下最后一关那一步预测竖条清零，说错 17 格，"
        "我当时给的理由是「册子从帧上看不出总共有几关，所以分不出打完一关和打完整局」。"
        "那个理由是错的——这排细条一直在帧上，`_lib.buttons` 的注释里甚至点名说它是过关计数，"
        "只是从来没有概念去读它。**「册子看不出」和「我没去读」在账面上长得一模一样**，"
        "都表现为一条概念在某一类转移上说错；分辨它们的办法是去翻词汇里已有的注解。"
        "第一版探针把第 0 列（竖条）也当成细条收进来了，那一格颜色恰好也在这两色里，"
        "于是宽度不齐、整排读不出，而读不出在账面上又长得像没说错——所以探针必须单独打出"
        "「读不出多少条」，否则 0 条不符是空的。"
        "读数：八条细条宽 4、间距 1；逐关已过数 0/1/2/3/4/5/6/7，全部 120 条转移点击前那一帧"
        "读出的已过数与上游关号一条不差；点击后那一帧只有终局那一条不符，就是冻住的那一帧。")
EVIDENCE = ["4c0c8a2fb6aacffa", "d8c0a4818ed40e9d", "8b5150ef2eecebd4",
            "896385d8d2ea36b3", "791bf114422842a3", "4ca96717e07c1891",
            "d4e2c1c2f0ce5e5c", "6147a88d5fcac7e0", "e7cfe2e643548420",
            "250e7d954246bcc6"]

from _lib import (hud_ticks, levels_cleared, levels_total, is_last_level,
                  will_level_up, HUD_ROW, HUD_DONE)

TERMINAL = ("WIN", "GAME_OVER")


def _side(done, level):
    """一侧的判决：读不出或上游没给关号就不表态（None）。"""
    if done is None or level is None:
        return None
    return done == level


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    frozen_prev = ctx.get("state_prev") in TERMINAL
    frozen_next = ctx.get("state_next") in TERMINAL
    if frozen_prev and frozen_next:
        return "NA"                     # 两侧都是没重绘的帧，这条概念没有主语

    verdicts = []
    if not frozen_prev:
        verdicts.append(_side(levels_cleared(prev), ctx["level_prev"]))
    if not frozen_next:
        verdicts.append(_side(levels_cleared(nxt), ctx["level_next"]))
    if not frozen_prev and not frozen_next:
        tp, tn = levels_total(prev), levels_total(nxt)
        verdicts.append(None if (tp is None or tn is None) else tp == tn)

    if False in verdicts:
        return "FALSE"
    if True in verdicts:
        return "TRUE"
    return "NA"


def apply(prev, action, ctx=None):
    """换关那一步，下一条细条从「未过」染成「已过」。

    最后一关不敢说：赢下它那一帧是冻住的，细条不往前走。这里正是 is_last_level 的用处——
    它让这条概念在事前（只看点击前那一帧）就知道该闭嘴，而不是靠 ctx 里的答案免责。
    """
    if not action.startswith("ACTION6"):
        return None
    if not will_level_up(prev, action):
        return None
    if is_last_level(prev) is not False:
        return None                     # 是最后一关、或读不出：不开口
    ts = hud_ticks(prev)
    done = levels_cleared(prev)
    if not ts or done is None or done >= len(ts):
        return None
    _c, c0, c1 = ts[done]
    return {(HUD_ROW, c): HUD_DONE for c in range(c0, c1 + 1)}
