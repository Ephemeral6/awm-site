"""点中一个箭头时，不在它**驱动的那几条链**上的瓷砖一块都不动。

一次点击驱动哪几条链由 _lib.driven 定（最近的那条，加上每一条不被任何有按钮的链包含的同轴链）；
链与链共用的那几位由最近的那条说了算。
"""
LEVEL = "L1"
SCOPE = "只看点中箭头、且 _lib 认得出这条带的 ACTION6；换关返回 NA；布局认不出返回 NA"
NOTE = ("v2：apply 在「这一步会换关」时闭嘴，同 belt_rot_a。"
        "v3 多出来的 tid 是假反例登记：带追踪器推广到 45° 转弯时中途那一版走出残缺的链，"
        "修好后这条概念在它们上面判 TRUE，断言一个字没改。详见 belt_rot_a 的 NOTE。"
        "v4：这条概念是**链认错时第一个喊出来的**。第四段布局里两条平行直线首尾相接成一条长 20 的闭链，"
        "旧追踪器认成两条长 10，于是「不在这条带上的瓷砖」里混进了另外半条带，"
        "一点就有十来位在动，判 FALSE（896385d8d2ea36b3、880d3f2543be6cea）。"
        "断言一个字没改：链修对之后这两条都判 TRUE。"
        "留个记号：这条概念的价值恰恰在于它是**链结构的探针**——它判 FALSE 时，"
        "先怀疑带认错了，别急着怀疑「一次点击只搅动一条带」这个主张本身。"
        "v5：上面这个记号第二次兑现。第五段布局的占位图既没有二维回路也不是直线，"
        "是一条 21 位的开放蛇形路径，_trace 走到死头就返回 None，于是整关只认出其中一条长 5 的直线段；"
        "点在驱动整条蛇的那个箭头上时，「带外」里混进了另外 16 位，一点就是 16 位在动，判 FALSE"
        "（2051cbf0c4890e52、b3e198cf1ff8a453）。断言又是一个字没改：词汇补上"
        "「开放路径首尾相接成环」（_lib._path_chains）与「自绕回的直线带要有自由端」（_lib._free_end_runs）之后，"
        "这两条都判 TRUE，且五段布局全部 57 条同关转移逐格复核零错。"
        "顺带记一条更一般的：链是会**嵌套**的——这一关行 0 那五位既是一条独立的短带，"
        "也是那条长 21 的链上的一段。旧代码「被真包含就丢掉」把短带删了，"
        "所以「谁包含谁」不能当筛链的判据。"
        "v6：**这一次不是眼睛坏了，是主张本身错了。**前五版这条概念每次判 FALSE 都是链认错，"
        "断言一个字没改就能修好；这一次 38ed5b575e1e9981 打掉的是「一次点击只搅动一条带」——"
        "第六段布局里一次点击**同时**转了两条互不相连的链（一条长 8 的直线段和一个 2x2 的方环），"
        "48 位在动，「带外」里落着整条长 8。逐结构反解出唯一解：两个位移并行发生、符号相同。"
        "改法是把「那条带」换成「它驱动的那几条链」（_lib.belt_of_click -> _lib.driven），"
        "守恒的形式一个字没变，变的是被守恒排除掉的那个集合。"
        "所以这条概念现在还兼一个新差事：它也是**驱动关系**认错时第一个喊出来的——"
        "从前它只探链的形状，现在它连「谁跟着谁一起动」一起探。"
        "顺带记一条：分组规则试了四种（只认最近一条 / 每个连通块各一条 / 按距离贪心取互不相交 / "
        "没人认领就搭车），前三种都被现成的转移打死，第四种差一步。"
        "详见 _lib.driven 的注解，那里记着每一种是被哪一段布局的哪个读数打死的。"
        "v6 挨了两条（1264c889cbe2e802、5e3e508f0d9efa07），登记在此；"
        "**上面那个记号第三次兑现**——判 FALSE 的又是划分，不是主张。"
        "第七段布局的按钮是棋盘外一块成排的面板，driven 的「配最近的那条合格链」在那里"
        "没有分辨力，于是「被驱动的那几条链」整个是错的，「链外」里落着实际在动的三条环。"
        "决定性的读数是次序而不是距离：面板上三个按钮按垂直于箭头的坐标升序，"
        "正好对上三条环的拐角按同一坐标升序；按最近位距离则有两个按钮配到同一条环，实际不是。"
        "断言又是一个字没改：`_lib.panel_buttons` 为真时 driven 让路，本条在这两条上判 NA，"
        "面板那一套的同一句话由 off_panel_static 讲。")

EVIDENCE = ["4c0c8a2fb6aacffa", "9a72d206f4ac15a2", "02bfcf1d72c29687",
            "09374ed9704ebd30", "bd5b41b5e8042186",
            "896385d8d2ea36b3", "880d3f2543be6cea",
            "2051cbf0c4890e52", "b3e198cf1ff8a453",
            "38ed5b575e1e9981",
            "1264c889cbe2e802", "5e3e508f0d9efa07"]

from _lib import driven, layout, will_level_up


def _split(prev, action):
    lay = layout(prev)
    if lay is None:
        return None, None
    ds = driven(prev, action, lay)
    if not ds:
        return None, None
    on = set()
    for _sense, order in ds:
        on |= set(order)
    off = [p for p in lay["tiles"] if p not in on]
    return lay, off


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, off = _split(prev, action)
    if off is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    for p in off:
        if lay["tiles"][p] != lay2["tiles"][p]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, off = _split(prev, action)
    if off is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for r, c in off:
        y, x = rows[r], cols[c]
        col = lay["tiles"][(r, c)]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out
