"""面板关点中一个箭头时，不在这次点击**驱动的那几截**上的瓷砖一块都不动。

守恒式的话，作用是给「驱动关系认对没有」当报警器：认领配错了，被驱动的划分就错，
于是「划分之外」立刻有东西在动。它判 FALSE 的第一嫌疑是**认领错了**，第二才是主张本身错。
"""
LEVEL = "L1"
SCOPE = ("只看面板关（_lib.panel_buttons 为真）、点中箭头、且 _lib.panel_claim 认出"
         "至少一截的 ACTION6；认不出返回 NA；换关返回 NA；布局认不出返回 NA；"
         "点击前后占位图变了返回 NA")
NOTE = ("v1。同族的 off_belt_static 讲的是把手贴着结构那一套里的同一件事；"
        "两条分开写而不是合并，因为两套机制的「被驱动的那几截」是两个不同的函数，"
        "合成一条会让「哪一套算错了」读不出来。")
EVIDENCE = ["6147a88d5fcac7e0"]

from _lib import layout, panel_buttons, panel_claim, hit_arrow, will_level_up


def _split(prev, action):
    lay = layout(prev)
    if lay is None or not panel_buttons(prev, lay):
        return None, None
    if hit_arrow(prev, action) is None:
        return None, None
    pc = panel_claim(prev, action, lay)
    if not pc:
        return None, None
    on = set()
    for _sense, seg in pc:
        on |= set(seg)
    return lay, [p for p in lay["tiles"] if p not in on]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    lay, off = _split(prev, action)
    if off is None:
        return "NA"
    lb = layout(nxt)
    if lb is None or set(lb["tiles"]) != set(lay["tiles"]):
        return "NA"
    return "TRUE" if all(lb["tiles"][p] == lay["tiles"][p] for p in off) else "FALSE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, off = _split(prev, action)
    if off is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for (r, c) in off:
        y, x = rows[r], cols[c]
        col = lay["tiles"][(r, c)]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out
