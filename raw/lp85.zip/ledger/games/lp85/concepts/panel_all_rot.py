"""面板上**独自成一排**的按钮：它一次驱动全部插槽拐角环，每条环**整环**沿次序挪一位。

同一块面板上，成排的按钮各管一条环、独自一个的管全部——「一排有几个」决定它认领几条环。
这条和 panel_rank_rot 是同一句律的两个口径（角标瓷砖朝按钮指的方向沿它那条环走一位），
分成两条概念写，因为「独自一个就管全部」这一句能被单独打掉：
出现一个独自成排的按钮只驱动一条环，它就死了。
"""
LEVEL = "L1"
SCOPE = ("只看面板关（_lib.panel_buttons 为真）、点中箭头、且这个按钮所在的一排"
         "只有它一个的 ACTION6；一排有多个的交给 panel_rank_rot；"
         "认不出插槽拐角环 / 认不出排返回 NA；换关返回 NA；布局认不出返回 NA；"
         "点击前后占位图变了返回 NA")
NOTE = ("v1。只断言「每条环各转一位」，不断言「别处不动」——后者是 off_panel_static。"
        "整环转一位是闭环：实测三条环的末位内容都绕回了环首（新[0] = 旧[-1]），"
        "所以这里的环真的是环，不是两头开口的轨道。")
EVIDENCE = ["5e3e508f0d9efa07"]

from _lib import (layout, panel_buttons, panel_claim, hit_arrow,
                  button_rank, slot_rings, will_level_up)


def _segs(prev, action):
    lay = layout(prev)
    if lay is None or not panel_buttons(prev, lay):
        return None, None
    a = hit_arrow(prev, action)
    if a is None:
        return None, None
    rings = slot_rings(lay)
    rank, _i = button_rank(prev, a, lay)
    if not rings or rank is None or len(rank) != 1:
        return None, None
    pc = panel_claim(prev, action, lay)
    if len(pc) != len(rings):
        return None, None
    return lay, pc


def _shifted(colors, sense):
    return colors[-1:] + colors[:-1] if sense > 0 else colors[1:] + colors[:1]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    lay, pc = _segs(prev, action)
    if pc is None:
        return "NA"
    lb = layout(nxt)
    if lb is None or set(lb["tiles"]) != set(lay["tiles"]):
        return "NA"
    for sense, ring in pc:
        want = _shifted([lay["tiles"][p] for p in ring], sense)
        if any(lb["tiles"][p] != c for p, c in zip(ring, want)):
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, pc = _segs(prev, action)
    if pc is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for sense, ring in pc:
        for (r, c), col in zip(ring, _shifted([lay["tiles"][p] for p in ring], sense)):
            y, x = rows[r], cols[c]
            for dy in range(tk):
                for dx in range(tk):
                    out[(y + dy, x + dx)] = col
    return out
