"""每一个插槽都装上**它自己角标色**的瓷砖那一步，关卡当场 +1 —— 这就是「赢」。

角标色逐槽而定：一关里可以有两个插槽各要一种颜色，那种颜色的瓷砖场上恰好只有一块。
「装上」按被点箭头那条带旋转一格算出来（_lib.tiles_after），所以这条概念说的是
「这一步之后的布局满足目标」而不是「这一步之前就满足」；插槽自己不动（only_tiles_change）。
"""
LEVEL = "L5"
SCOPE = "只看 ACTION6 且算出来每个插槽都配上自己角标色的转移；布局或插槽认不出返回 NA；其余情形返回 NA（否定式在 no_win_without_slots）"
NOTE = ("v2：被 7bb065c9c290f634 打了 —— 那一步算出来「插槽装满」而关卡没动。"
        "查下来不是主张错，是眼睛瞎：词汇 layout 只收一种角标色的小方块，"
        "第三段布局有个另一色角标的插槽被整槽漏掉，剩下那一个装对了就误判成过关。"
        "改成逐槽角标色之后这条概念在那一步返回 NA（还没配齐），断言结构没动。"
        "教训：终止条件里任何一个「全体」量词，都要先问清全体是从哪认出来的。"
        "v3：38ed5b575e1e9981 又是同一处记法打的——算出来「插槽装满」而关卡没动，"
        "而且这一次它是**押注的落空条件**：我照着 tiles_after 预言这一按就过关，世界不认。"
        "断言又是一个字没改，坏的又是它依赖的词汇：那一步一次点击同时转了两条链，"
        "而当时的 tiles_after 只知道其中一条，于是算出一个从没发生过的局面，"
        "在那个局面上两个插槽恰好都配齐了。词汇修好（_lib.driven）之后这一步的真实后续里"
        "插槽只配齐一个，这条概念返回 NA。"
        "记号：这条概念判 FALSE 的第一嫌疑永远是「算后续那一步算错了」，不是「装满不等于赢」——"
        "它是 tiles_after 的下游，tiles_after 错一格它就整句错。")
EVIDENCE = ["eb0fe73a8be3965b", "7bb065c9c290f634", "38ed5b575e1e9981"]


from _lib import layout, slots_done, tiles_after


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    lay = layout(prev)
    if lay is None or not lay["slots"]:
        return "NA"
    after = tiles_after(prev, action, lay)
    if after is None or not slots_done(after, lay):
        return "NA"
    if ctx is None:
        return "NA"
    return "TRUE" if ctx["level_next"] == ctx["level_prev"] + 1 else "FALSE"
