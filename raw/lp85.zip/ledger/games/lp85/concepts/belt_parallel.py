"""点中一个箭头时，除了离它最近的那条链，每一条**独立而无按钮**的同轴链也在同一步里跟着挪一位。

「独立而无按钮」= 它不被任何「有按钮的链」整段包含（有按钮 = 存在某个按钮，它自己最近的合格链就是这条）。
「同轴」= 箭头指向与该链规范次序首步的点乘非零。跟着挪的方向和主链一样：内容朝箭头指的方向走一位。
判别项全在 _lib.driven 里，它返回这一次点击驱动的全部链，第一条是主链，其余就是本条概念管的。

这条概念只在「一次点击驱动两条以上的链」时开口，其余一律 NA——
主链自己那一位由 belt_rot_a / belt_rot_b 管，带外不动由 off_belt_static 管，本条只管**附带的那几条**。

读成一句话：有按钮的结构只听自己的按钮；真正独立又没配按钮的结构没有别的驱动手段，只能搭同轴驱动的车。
"""
LEVEL = "L6"
SCOPE = ("只看点中箭头、且 _lib.driven 认出两条以上被驱动的链的 ACTION6；"
         "只驱动一条（或一条都认不出）返回 NA；换关返回 NA；布局认不出返回 NA；"
         "点击前后占位图变了返回 NA")
NOTE = ("v1：从 38ed5b575e1e9981 一条转移上读出来的，所以它此刻的 N 会是 0——"
        "主张还没在任何一条没引用过的转移上被考过，别把 S 当成它站住了。"
        "由来：那一步一次点击同时转了两条互不相连的链（一条长 8 的直线段和一个 2x2 的方环），"
        "48 位在动。当时册子只知道最近的那一条，于是算出一个从没发生过的局面，"
        "在那个局面上两个插槽恰好都配齐，我照着它押注「这一按就过关」，落空。"
        "分组规则是逐结构反解试出来的，四种里三种被现成的转移打死："
        "「只认最近一条」漏掉长 8 那条（12 位只解释 4 位）；"
        "「每个连通块各一条」把跨隙串接的链整个排除（另一段布局 19 条转移全变弃权）；"
        "「按距离贪心取互不相交」多取了一位都不动的链（7 条说错）；"
        "「没人认领就搭车」差一步——还有一段布局的长 3 也没人认领却一位都不动，"
        "而它整段落在一条有按钮的长 21 里面，是碎片不是物件。"
        "两处已知的未决之处，都写在这里免得日后当成已验证："
        "（1）现成的转移里「不被有按钮的链包含」与「链上有插槽」给出完全相同的答案，"
        "分开它们要一段有「独立、无按钮、不含插槽的链」的布局；"
        "（2）「并行」（各链都读点击前那一帧）与「接力」（一条推另一条）在这里**分不开**，"
        "因为被同时驱动的两条链互不相交；要分开得有一段布局里两条同时被驱动的链共用一位。"
        "这两条都不是我判断不出，是数据没有；哪一天有了，本条会在那里开口。"
        "v1 挨了两条反例（6147a88d5fcac7e0、1264c889cbe2e802），登记在此；打的不是断言，"
        "是**驱动关系的适用前提**。第七段布局的按钮是棋盘外一块成排的面板，"
        "面板上的按钮驱动的环离它最远——实测两个同色同指向的面板按钮按最近位距离都该配同一条环，"
        "实际驱动的是不同的两条。距离在把手贴着结构时有分辨力，把手离开结构之后就没有了，"
        "于是 driven 认出来的「附带的那几条链」全是凭空的。"
        "断言一个字没改：`_lib.panel_buttons` 认出面板关之后 driven 一律让路（返回空），"
        "本条在这两条转移上判 NA。那一关的律由 panel_rank_rot / panel_all_rot 两条新概念接手，"
        "「一排有几个按钮就认领几条环、独自一个就认领全部」——那正是本条讲的『不止一条在动』"
        "在面板机制里的对应物，只是认领规则完全不同。")
EVIDENCE = ["38ed5b575e1e9981",
            "6147a88d5fcac7e0", "1264c889cbe2e802"]

from _lib import driven, layout, will_level_up


def _extras(prev, action):
    """(布局, [(符号, 链)…]) —— 只含附带的那几条；不够两条就 (None, None)。"""
    lay = layout(prev)
    if lay is None:
        return None, None
    ds = driven(prev, action, lay)
    if len(ds) < 2:
        return None, None
    return lay, ds[1:]


def _shifted(colors, sense):
    # 符号约定与 belt_rot_a/b 一致：sense<0 时内容沿次序前移一格（新[i]=旧[i+1]）。
    return colors[1:] + colors[:1] if sense < 0 else colors[-1:] + colors[:-1]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, extras = _extras(prev, action)
    if extras is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    for sense, order in extras:
        a = [lay["tiles"][p] for p in order]
        b = [lay2["tiles"][p] for p in order]
        if b != _shifted(a, sense):
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None                    # 换关那一帧是新关的开局，这条概念不敢说
    lay, extras = _extras(prev, action)
    if extras is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for sense, order in extras:
        a = [lay["tiles"][p] for p in order]
        for (r, c), col in zip(order, _shifted(a, sense)):
            y, x = rows[r], cols[c]
            for dy in range(tk):
                for dx in range(tk):
                    out[(y + dy, x + dx)] = col
    return out
