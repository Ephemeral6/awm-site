"""点在**枢纽按钮**（不属于任何星的那个把手）上时，每一块游离瓷砖与它唯一那块八邻接的星上瓷砖交换颜色，全部同时发生。

游离瓷砖 = 不属于任何星的瓷砖（`_lib.swap_pairs`：每块游离瓷砖必须恰有一块八邻接的星上瓷砖，
配对还不许撞车，否则整张表返回 None）。这条律是**自逆**的：连点两次回到原样。

它的分量在于**它是星与枢纽之间唯一的通道**。这一关的目标位全在枢纽上，而目标色的瓷砖每颗星各有一块、
一块都不在枢纽上；星自己那两种动作（star_rotate / star_radial）只在自己那颗星的位上搬东西，
永远搬不进枢纽。所以在按这个按钮之前，「只用星的动作能不能通关」这个问题的答案已经是**不能**——
正是这个数数逼出了「一定还有别的机制」，而这个孤零零待在空角落里的按钮是唯一的候选。
先立主张再按，按下去动了 6 位：三对同时互换，一格不差。
"""
LEVEL = "L1"
SCOPE = ("只看点中枢纽按钮（_lib.hit_hub_button）的 ACTION6；"
         "场上认不出星、或不属于星的按钮不止一个时 hub_button 返回 None，本条判 NA；"
         "swap_pairs 说不准（有游离瓷砖的八邻接星上瓷砖不唯一）也判 NA；"
         "换关返回 NA；布局认不出或网格位变了返回 NA。"
         "只断言**参与互换的那些位**；别处不动那件事是 off_star_static 的主张。")
NOTE = ("v1。这条概念是先有主张后有证据的那一种，记一下来由，因为它改变了往后该怎么挑动作："
        "颜色计数（目标色恰好三块、每颗星一块）+ 目标位置（三个插槽全在枢纽上）+ "
        "星的两种动作的作用域（只动自己那颗星），三件已经在册的事合起来推出「本关不可能只用星的动作通关」。"
        "于是那一次点击不是在试一个假设，是在**检验一个已经推出来的必然**——"
        "若这个按钮也搬不动枢纽上的瓷砖，那就该立一条阻断主张，而不是继续找搬法。"
        "教训：花一次动作去撞新结构时，挑那种「不管结果如何都能定案」的一次。")
EVIDENCE = ["d7f2f2195366ba87"]

from _lib import hit_hub_button, layout, paint, swap_pairs, will_level_up


def _pairs(prev, action):
    """(lay, {甲: 乙} 互换表)：点中枢纽按钮且配对说得准才返回。"""
    lay = layout(prev)
    if lay is None:
        return None, None
    if not hit_hub_button(prev, action, lay):
        return None, None
    sw = swap_pairs(set(lay["tiles"]))
    if not sw:
        return None, None
    return lay, sw


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, sw = _pairs(prev, action)
    if sw is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    for a, b in sw.items():
        if lay2["tiles"][a] != lay["tiles"][b] or lay2["tiles"][b] != lay["tiles"][a]:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, sw = _pairs(prev, action)
    if sw is None:
        return None
    mine = {}
    for a, b in sw.items():
        mine[a] = lay["tiles"][b]
        mine[b] = lay["tiles"][a]
    return paint(lay, mine)
