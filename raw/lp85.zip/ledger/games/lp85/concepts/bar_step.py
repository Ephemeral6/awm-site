"""第 0 列的竖条只记生效的点击：点中箭头时前缀不减少，点空时一格不变。

**每次填几格是关级常数，而且带四舍五入，所以生效点击也可能一格不填** ——
量下来三段布局的填充率分别是「一次 5 格」「一次 1 格」「一次 0.8 格」：
前缀 = round(填充率 × 本关生效点击数)。率小于 1 时，隔几次就有一次点了却不长
（0.8 的那一段在本关第 3、第 8 次点击上塌陷，逐位吻合）。
所以「严格变长」是错的，只有「不减少」站得住。

填充率是关级常数，(prev, action) 里没有任何东西能算出它，本关走过几次也不在 ctx 里，
因此这条概念只断言方向，不断言速率；速率是空槽，等某一关的帧上找出可读的来源再补。
条子于是只读得出「花过没花过、还有多远到底」，读不出剩余预算的绝对值。
"""
LEVEL = "L4"
SCOPE = "只看 ACTION6；换关返回 NA；条子不是「上段连续填满、下段全空」时返回 NA"
NOTE = ("v3：被 d8c0a4818ed40e9d 打掉了「一次填 BAR_STEP=5 格」。改成只断言方向，不再声称步长。"
        "v4：又被 934626e53de9c152 / 0a05396bdf93d2cf 打掉了「点中就**严格**变长」——"
        "这两步点中了箭头、带也转了，前缀却一格没动。查下来不是漏判：这一段布局的填充率是 0.8，"
        "round(0.8k) 在 k=3、k=8 上与前一格相同。改成「不减少」。"
        "教训：把一条量化规律降格成方向时，别顺手把「严格」留下——率可以小于 1，"
        "「每次都动」和「从不后退」是两件事。接替撤册的 bar_counts_effective。")
EVIDENCE = ["4c0c8a2fb6aacffa", "868d1479da76e839", "d8c0a4818ed40e9d",
            "934626e53de9c152", "0a05396bdf93d2cf"]

from _lib import BAR_COL, bar_prefix, hit_arrow, will_level_up


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    a, b = bar_prefix(prev), bar_prefix(nxt)
    if a is None or b is None:
        return "NA"
    if hit_arrow(prev, action) is not None:
        return "TRUE" if b >= a else "FALSE"
    return "TRUE" if b == a else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION6"):
        return None
    if will_level_up(prev, action):
        return None                    # 换关这一步的竖条交给 level_up_resets_bar
    if hit_arrow(prev, action) is not None:
        return None                    # 会变长，但变多少这条概念不知道 —— 不敢说就闭嘴
    return {(y, BAR_COL): prev[y][BAR_COL] for y in range(len(prev))}
