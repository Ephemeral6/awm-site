"""面板上**一排有几个按钮就认领几条环**的那种按钮：它只把自己认领的那一条插槽拐角环上
**一段固定的窗口**（环首到「最靠左那个拐角所在网格列」之前的那些位）沿次序整体挪一位；
环上其余的位一块都不动。

这一截与角标在哪儿无关。最要紧的推论：**角标不在这个窗口里，这一排的按钮就搬不动它**，
点了也只是把窗口里的颜色转一圈——所以这种按钮不是「随时能把角标推一位」的工具，
它只在角标恰好落在窗口里时才是。

认领关系不是距离——按最近位距离，这一排里两个不同的按钮都该配同一条环，
实际驱动的是不同的两条。有分辨力的是**排里的次序**：按钮按垂直于箭头那个坐标升序，
对拐角按同一个坐标升序，逐位配对。
"""
LEVEL = "L1"
SCOPE = ("只看面板关（_lib.panel_buttons 为真）、点中箭头、且这个按钮所在的一排"
         "长度等于插槽拐角环条数、认领到恰好一段的 ACTION6；"
         "一排只有一个按钮的交给 panel_all_rot；认不出插槽拐角环 / 认不出排 / "
         "认不出角标序号返回 NA；换关返回 NA；布局认不出返回 NA")
NOTE = ("v1。断言只管认领的那一截，不管别处——「别处一块都不动」是 off_panel_static 那条独立的话，"
        "两件事分开，打掉一条不牵连另一条。"
        "「那一截的长度是环首到角标位后一位」是从两条转移反解出来的：一条的角标在序号 0，动了 2 位；"
        "另一条的角标在序号 5，动了 7 位。等价的读法是「角标前进一位，被它挤掉的那一位跑到环首」，"
        "两种读法给出同一个置换，这里写成置换。"
        "v2：被 762078b285ab6746 打死，而那正是这条概念自己 NOTE 里点名的判决性实验——"
        "反向（色 8）那一排第一次被按。v1 的截法「环首..角标位+1」对正反两向都用，"
        "于是反向时它要求角标后一位也参与轮换；实际那一位一格都没动。"
        "决定性读数：角标在第 5 位，变动位是 [1..5]，第 6 位前后同色同位。"
        "改法是让这一截量到「角标两位里靠插槽的那一个」（`_lib.panel_claim` 里的 `far = max(k, k+sense)`），"
        "正向的行为一个字没变（那时 far = k+1），反向从量到 k+1 变成量到 k。"
        "**没被这条读数分开的**：`环首..角标位` 与 `环首+1..角标位` 在那条环上逐格相同，"
        "因为它第 0 位和第 1 位恰好同色（都是 9 色）。这里写的是前者；"
        "要判它，需要一条第 0、1 位不同色的环上的后退点击。这不是我判断不出，是数据没有。"
        "v3：被 2d1d73df49fe1d96 打死，而这一次死的不是截法的**端点**，是「截长是角标的函数」"
        "这个想法本身。那一步角标在第 1 位、按的是前进，角标反而**退到第 0 位**；"
        "紧接着同一个按钮再按一次又回到第 1 位——第 104、105 步互为逆操作，原地打转，"
        "这是任何「角标朝按钮指的方向前进一位」的读法都出不来的。"
        "把三条环上八次一排点击的**实际变动窗口**摆成一张表才看出来：同一条环上角标在第 4/5/6 位时"
        "窗口一模一样，而三条环的窗口末位落在同一个网格列上、窗口外第一位落在下一列。"
        "所以窗口是**每条环固定**的一段位置，既不是角标的函数也不是颜色的函数"
        "（窗口里的颜色每按一次都换，边界不动）。门槛写成「拐角列的最小值」而不是写死那个列号。"
        "由此得到这一关最要紧的一句：角标出了窗口，这一排就再也搬不动它，只有整环那个按钮搬得动。"
        "教训（比这条概念本身值钱）：我把「角标动了一位」当成了「按钮把角标推了一位」。"
        "前三次读数里角标恰好都落在窗口内，两种读法给出同一个答案；"
        "**是我挑的动作让它们分不开**——我一直在角标附近按。"
        "判决性的那一按（角标在窗口外时按同一个按钮）成本和别的按钮一样，我却一次没试过。"
        "而 v1、v2 两次改版都只动端点、没动「截长由角标定」这个前提，"
        "所以两次都在同一个坑里换姿势。"
        "所以「反解出唯一解」要问清唯一是在多大的动作集合上唯一——"
        "只按过窗口内、只按过一个方向，就只在那一小片上唯一。")
EVIDENCE = ["6147a88d5fcac7e0", "1264c889cbe2e802", "762078b285ab6746",
            "2d1d73df49fe1d96"]

from _lib import (layout, panel_buttons, panel_claim, hit_arrow, buttons,
                  button_rank, slot_rings, will_level_up)


def _seg(prev, action):
    """(布局, 符号, 那一截)；不属于这条概念的情形返回 (None, None, None)。"""
    lay = layout(prev)
    if lay is None or not panel_buttons(prev, lay):
        return None, None, None
    a = hit_arrow(prev, action)
    if a is None:
        return None, None, None
    rings = slot_rings(lay)
    rank, _i = button_rank(prev, a, lay)
    if not rings or rank is None or len(rank) == 1:
        return None, None, None
    if len(rank) != len(rings):
        return None, None, None
    pc = panel_claim(prev, action, lay)
    if len(pc) != 1:
        return None, None, None
    return lay, pc[0][0], pc[0][1]


def _shifted(colors, sense):
    return colors[-1:] + colors[:-1] if sense > 0 else colors[1:] + colors[:1]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION6"):
        return "NA"
    lay, sense, seg = _seg(prev, action)
    if seg is None:
        return "NA"
    lb = layout(nxt)
    if lb is None:
        return "NA"
    if set(lb["tiles"]) != set(lay["tiles"]):
        return "NA"                     # 占位图变了：这条概念只讲位置上的置换
    want = _shifted([lay["tiles"][p] for p in seg], sense)
    return "TRUE" if all(lb["tiles"][p] == c for p, c in zip(seg, want)) else "FALSE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None                     # 换关那一帧是新关的开局，这条概念不敢说
    lay, sense, seg = _seg(prev, action)
    if seg is None:
        return None
    tk, rows, cols = lay["tile"], lay["rows"], lay["cols"]
    out = {}
    for (r, c), col in zip(seg, _shifted([lay["tiles"][p] for p in seg], sense)):
        y, x = rows[r], cols[c]
        for dy in range(tk):
            for dx in range(tk):
                out[(y + dy, x + dx)] = col
    return out
