"""点在某颗星的**切向**把手上时，这颗星三个环的内容一起绕星心转一位，转向是「挨着把手那一位的内容朝把手指的方向走」。

星形布局（`_lib.stars`）是这样一个东西：一个**空的**星心，八个方向各伸出等长的一串瓷砖。
第 k 环 = 星心朝八个方向各走 k 步的那八位。切向把手贴在某条射线最外那一位的外面，
指向与该处半径**垂直**（点乘为 0）——这一位与另一位的区别不看颜色也不看位置，只看指向与半径的点乘，
判别项写在 `_lib.star_button` 里。转向由更朴素的一句话定：挨着把手那一位的内容朝把手指的方向走。

这条与 star_radial 说的是同一件事的两半：**离把手最近的那块瓷砖朝把手指的方向走，它脚下的结构驮着其余的走**。
分成两条只因为脚下的结构不同（环 / 射线），各自都要能被单独打掉。
"""
LEVEL = "L1"
SCOPE = ("只看点中切向把手（_lib.hit_star_button 判 kind == 'rot'）的 ACTION6；"
         "径向把手交给 star_radial，枢纽按钮交给 hub_swap；"
         "换关返回 NA；布局认不出或网格位变了返回 NA。"
         "只断言**这颗星自己那些位**的颜色；星外一块不动那件事是 off_star_static 的主张。")
NOTE = ("v1。这一段布局的占位图既不是环也不是路径，`_lib._cycles` 一条链都认不出来，"
        "于是整套「带」的词汇在这里全部闭嘴（belt_of_click 返回 None），三条带概念判 NA。"
        "**那是对的，也是故意的**：星不是带，把星硬接进 belts() 会让那三条概念开始在第五关的转移上开口，"
        "而它们的断言（沿一条一维链平移一位）在这里根本不成立——那会在已经结算过的 tid 上凭空造出反例。"
        "所以新结构走新命名空间，宁可多写三条概念。"
        "EVIDENCE 只抽第一颗星上那一次：另一颗星上的切向把手是**先押注后按**的，"
        "把它也抄进依据会让「它当时是被预言中的」这件事在账上消失——"
        "抽进 EVIDENCE 的转移就退出 universe，不再算 S 也不再算 E。"
        "依据要写抽出主张的那几条，不写主张考及格的那几条。")
EVIDENCE = ["4ca96717e07c1891"]

from _lib import hit_star_button, layout, paint, star_after, star_rings, will_level_up


def _rot(prev, action):
    """(lay, 星心, 符号)：点中切向把手才返回，否则 (None, None, None)。"""
    lay = layout(prev)
    if lay is None:
        return None, None, None
    sb = hit_star_button(prev, action, lay)
    if sb is None or sb[1] != "rot":
        return None, None, None
    return lay, sb[0], sb[2]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, ctr, sense = _rot(prev, action)
    if ctr is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    rings = star_rings(set(lay["tiles"]), ctr)
    if not rings:
        return "NA"
    pred = star_after(lay, ctr, "rot", sense)
    for ring in rings:
        for p in ring:
            if pred[p] != lay2["tiles"][p]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None                    # 换关那一帧是新关的开局，这条概念不敢说
    lay, ctr, sense = _rot(prev, action)
    if ctr is None:
        return None
    rings = star_rings(set(lay["tiles"]), ctr)
    if not rings:
        return None
    pred = star_after(lay, ctr, "rot", sense)
    mine = {p: pred[p] for ring in rings for p in ring}
    return paint(lay, mine)            # 只填这颗星的位
