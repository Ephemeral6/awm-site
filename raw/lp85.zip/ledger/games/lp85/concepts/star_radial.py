"""点在某颗星的**径向**把手上时，这颗星八条射线的内容一起沿射线朝外挪一位，最外一环绕回最里。

径向把手贴在某条射线最外那一位的外面，指向与该处半径**同向**（点乘 > 0，指着背离星心）。
「朝外」= 环 1 的内容搬到环 2、环 2 搬到环 3、环 3 绕回环 1；八条射线同时、同量。
注意它转的是**射线**不是环：这与 star_rotate 恰好是同一个 3x8 环面上两个独立方向的平移，
所以这一颗星上任何一块瓷砖都能被赶到任何一个 (环, 方向)——这一条是本关规划器唯一的搬运手段。

判别项与转向都在 `_lib.star_button` 里，纯几何，不看颜色。
"""
LEVEL = "L1"
SCOPE = ("只看点中径向把手（_lib.hit_star_button 判 kind == 'rad'）的 ACTION6；"
         "切向把手交给 star_rotate，枢纽按钮交给 hub_swap；"
         "换关返回 NA；布局认不出或网格位变了返回 NA。"
         "只断言**这颗星自己那些位**的颜色；星外一块不动那件事是 off_star_static 的主张。")
NOTE = ("v1。「朝外」这个符号是从把手指向与半径的点乘正负算出来的，不是数出来的："
        "实测的两个径向把手都指着背离星心，所以 -1 那一侧（指着星心的径向把手）"
        "**这一关一次都没出现过**，是本条概念最没被考过的地方。"
        "哪天有个径向把手指着星心而内容并不朝里挪，第一个垮的是这里。"
        "EVIDENCE 只抽第一颗星上那一次；另一颗星上的径向把手是先押注后按的，留在 universe 里当考题。")
EVIDENCE = ["d413cdf6d2f5e9db"]

from _lib import hit_star_button, layout, paint, star_after, star_rings, will_level_up


def _rad(prev, action):
    """(lay, 星心, 符号)：点中径向把手才返回，否则 (None, None, None)。"""
    lay = layout(prev)
    if lay is None:
        return None, None, None
    sb = hit_star_button(prev, action, lay)
    if sb is None or sb[1] != "rad":
        return None, None, None
    return lay, sb[0], sb[2]


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    lay, ctr, sense = _rad(prev, action)
    if ctr is None:
        return "NA"
    lay2 = layout(nxt)
    if lay2 is None or set(lay2["tiles"]) != set(lay["tiles"]):
        return "NA"
    rings = star_rings(set(lay["tiles"]), ctr)
    if not rings:
        return "NA"
    pred = star_after(lay, ctr, "rad", sense)
    for ring in rings:
        for p in ring:
            if pred[p] != lay2["tiles"][p]:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if will_level_up(prev, action):
        return None
    lay, ctr, sense = _rad(prev, action)
    if ctr is None:
        return None
    rings = star_rings(set(lay["tiles"]), ctr)
    if not rings:
        return None
    pred = star_after(lay, ctr, "rad", sense)
    mine = {p: pred[p] for ring in rings for p in ring}
    return paint(lay, mine)
