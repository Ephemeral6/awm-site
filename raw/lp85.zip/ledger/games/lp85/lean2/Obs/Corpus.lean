/-
# Obs/Corpus —— **模型面对全部真实转移**，逐条（自动生成；生成器 `lean2/export_replay.py`）

从 `Obs/Replay.lean` 切，不另存一份轨迹。

    corpus_agrees   动作不是 RESET 的那 199 行，每一行都从**观测到的那一帧**起算一步，
                    和看到的下一帧对上（换关的 16 行模型必须说 `won`，其余必须**不**说 `won`）
    corpus_marked   不接手的行（RESET）恰好 1 行 —— 标记的条数钉在明处

这一层每一步都被拉回正轨，所以它比每关那一层弱；它的价值在于**覆盖全部 199 行**，
包括成绩单没认证的那一段（每关那一层只用认证段）。
-/

import Obj.World
import Obs.Check
import Obs.Replay

set_option maxRecDepth 100000

/-- 一行转移，按这一帧读到的盘判。RESET 那一行不判（`act = none`），由 `corpus_marked` 数。 -/
def rowOk (s : Replay.Step) : Bool :=
  match s.act with
  | none => true
  | some a => agrees (Replay.boardAt s.board) s.prev a s.next

/-- 语料里**每一行**，模型的 `step` 都和观测对上。 -/
theorem corpus_agrees : Replay.steps.all rowOk = true := by
  decide +kernel

#print axioms corpus_agrees

/-- 不接手的行恰好 1 行，接手的恰好 199 行。 -/
theorem corpus_marked :
    (Replay.steps.filter (fun s => s.act.isNone)).length = 1 ∧
    (Replay.steps.filter (fun s => s.act.isSome)).length = 199 := by
  decide +kernel

#print axioms corpus_marked

/-- 语料里每一行动作之前的那个世界，它的盘上每个按钮的接线都是 `0..n-1` 的一个排列
    （n = 这张盘的格数），而且颜色恰好 n 个。这是 `Derived/ColorsConserved.lean` 那条推论的前提 `wf`，
    在真实的世界上逐个核。 -/
theorem wf_all_boards :
    Replay.steps.all (fun s => (fun (w : World) =>
      w.colors.length == w.board.cells.length &&
      w.board.buttons.all (fun b => b.perm.isPerm (List.range w.board.cells.length))) (Replay.worldOf s)) = true := by
  decide +kernel

#print axioms wf_all_boards

/-- **读数，不是定理**：按分支数一遍（给 `verify.py` 和 Python 那边的读数逐条对账用）。
    won = 模型说赢了的行；dead = 点空的行；press = 点中按钮且没赢的行；bad = 对不上的 seq。 -/
def branchOf (s : Replay.Step) : String :=
  match s.act with
  | none => "mark"
  | some a =>
    match step (Replay.boardAt s.board) s.prev a with
    | .won => "won"
    | .ok _ =>
      match a with
      | .click x y => if (hit (Replay.boardAt s.board) y x).isNone then "dead" else "press"

#eval "RECON " ++ String.intercalate ";" (Replay.steps.map (fun s =>
  toString s.seq ++ ":" ++ branchOf s ++ ":" ++ (if rowOk s then "ok" else "BAD")))

#eval "CORPUS rows=" ++ toString Replay.steps.length ++ " boards=" ++ toString Replay.boards.length

