/-
# Obs/Check —— **判据层**：两把尺子，**0 条定理**（尺子不自证）

    agrees    **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比
    traceOk   **一整条路**对不对：只有开局是观测给的，**后面全是模型自己算的**

一个「每步单独看都对、走两步就和现实分家」的模型，在 `agrees` 那里满分，在 `traceOk` 这里过不了。

## 观测里有什么

只有颜色（`Colors`）。竖条不进模型，所以不比；版面是 `step` 的只读参数，所以也不比——
「版面在一关之内不变」由 Python 那边 `rule/world/board_static.py` 逐条核（183 条同关转移），
导出器在导出每一步时再核一次（下一帧的版面不等于这一帧的就停下报错）。

「换关」那一步的下一帧是另一张盘，观测写成 `none`；模型那一侧必须说 `won`。两个方向都要对上：
模型说 `won` 而现实没换关 ⇒ 判错；现实换关而模型没说 `won` ⇒ 判错。
-/

import Obj.World
import Step

def agrees (bd : Board) (prev : Colors) (a : Act) (next : Option Colors) : Bool :=
  match step bd prev a, next with
  | .won, none => true
  | .ok s, some o => s == o
  | _, _ => false

/-- 从 `s` 出发沿 `play` 走，每一步都和当时看到的那一帧比。**下一轮喂进去的是模型自己算出来的 `s'`**，
    不是观测到的那一帧。中间错一步，后面全错——那正是要的。 -/
def traceOk (bd : Board) : Colors → List (Act × Colors) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    match step bd s a with
    | .ok s' => s' == o && traceOk bd s' rest
    | .won => false

/-- 同一把尺子，开局给成一个 `World`（版面 + 颜色）。每关那一层用它。 -/
def World.traceOk (w : World) (play : List (Act × Colors)) : Bool :=
  _root_.traceOk w.board w.colors play

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (bd : Board) : Colors → List (Act × Colors) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    match step bd s a with
    | .ok s' => if s' == o then firstSplit bd s' rest (i + 1) else some i
    | .won => some i
