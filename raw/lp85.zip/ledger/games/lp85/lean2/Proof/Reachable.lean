/-
# Proof/Reachable —— 这个**局面**做不做得了：骨架、两把钥匙、每把一张对照盘

真实的 8 关在认证段里全被走通过（`Proof/Levels.lean` 各有一条 `_winnable`），
所以这一份**不用在真实关卡上**。它存在的理由是：「走不通」要能被**证**出来，
而不是「我试了很多路都没赢」——零件先备好，用手造的小盘演示每把钥匙，并配上防线。

## 唯一的骨架

    找一个性质 Φ：每点一下都还成立，而且满足 Φ 的颜色不是目标。
    那么从满足 Φ 的局面出发，**任何一串点击都赢不了**。

对动作串做归纳，与盘面多大、串多长无关，**不枚举任何状态**。

## 两把钥匙，理由真的不同

    钥匙一 · 缺色   某个插槽要的颜色场上一块都没有。点击只是**换位置**（接线是置换），
                   块数守恒（`Derived/ColorsConserved`），所以那种颜色永远不会出现。
    钥匙二 · 冻格   某个插槽那一格没有任何按钮会搬它，而它现在的颜色不对。
                   颜色场上**有**也没用——搬不过去。

钥匙二的盘上钥匙一的前提**不成立**（那种颜色场上有）：两把钥匙不会在同一处一起失效。

## 这句「赢不了」的准确范围

模型没有 RESET 这一支，也没有预算（竖条不进模型）。所以 `Unsolvable` 的准确意思是
「**不考虑预算、不经过 RESET**，任何点击串都赢不了」。RESET 只把局面放回这一关的开局，
从开局走不通就帮不上忙；预算只会让事情更难——这半句写在这里、`Step.lean` 和页面上三处。
-/

import Obj.World
import Step
import Derived.ColorsConserved

/-! ## 一、骨架 -/

theorem unsolvable_of_invariant (w : World) (P : Colors → Prop)
    (hkeep : ∀ s a, P s → P (move w.board s a))
    (hgoal : ∀ s, P s → isGoal w.board s = false)
    (h0 : P w.colors) : Unsolvable w := by
  intro as
  have main : ∀ s, P s → everWon w.board s as = false := by
    induction as with
    | nil => intro _ _; rfl
    | cons a t ih =>
      intro s hs
      have hm : P (move w.board s a) := hkeep s a hs
      have hg : isGoal w.board (move w.board s a) = false := hgoal _ hm
      simp only [everWon, step, hg]
      exact ih _ hm
  exact main _ h0

#print axioms unsolvable_of_invariant

/-- 目标要求第 `sl.cell` 格是 `sl.mark`。 -/
theorem goal_needs (w : World) (sl : Slot) (hs : sl ∈ w.board.slots)
    (hg : isGoal w.board w.colors = true) : w.colors[sl.cell]? = some sl.mark := by
  simp only [isGoal, Bool.and_eq_true, List.all_eq_true] at hg
  have := hg.2 sl hs
  simpa using this

#print axioms goal_needs

/-! ## 二、钥匙一 · 缺色 -/

/-- 缺色：颜色恰好 n 个，而插槽 `sl` 要的那种颜色一块都没有。 -/
def MissingColor (n : Nat) (sl : Slot) (s : Colors) : Prop := s.length = n ∧ s.count sl.mark = 0

/-- 走不坏：缺的颜色点一下还是缺（块数守恒），颜色个数也不变（接线是 0..n-1 的排列）。 -/
theorem missing_keep (w : World) (sl : Slot) (hwf : ∀ b ∈ w.board.buttons, b.wf w.colors.length) :
    ∀ s a, MissingColor w.colors.length sl s → MissingColor w.colors.length sl (move w.board s a) := by
  intro s a ⟨hl, hc⟩
  have hw' : (World.mk w.board s).wf := by
    intro b hb; rw [show (World.mk w.board s).colors = s from rfl, hl]; exact hwf b hb
  refine ⟨?_, ?_⟩
  · cases a with
    | click x y =>
      simp only [move]
      split
      · exact hl
      · rename_i b hb
        simp only [pressPermutes, List.length_map]
        rw [List.Perm.length_eq (hwf b (List.mem_of_find?_eq_some hb)), List.length_range]
  · have := colors_conserved (World.mk w.board s) a sl.mark hw'
    simp only at this
    rw [this, hc]

#print axioms missing_keep

theorem missing_no_goal (w : World) (sl : Slot) (hs : sl ∈ w.board.slots) :
    ∀ s, MissingColor w.colors.length sl s → isGoal w.board s = false := by
  intro s ⟨_, hc⟩
  cases hg : isGoal w.board s with
  | false => rfl
  | true =>
    have h1 := goal_needs (World.mk w.board s) sl hs hg
    have hmem : sl.mark ∈ s := List.mem_of_getElem? h1
    have := List.count_pos_iff.mpr hmem
    omega

#print axioms missing_no_goal

/-- **钥匙一挂上骨架**：接线良构、有一个插槽要的颜色场上一块都没有 ⇒ 这一关走不通。 -/
theorem unsolvable_missing (w : World) (sl : Slot) (hs : sl ∈ w.board.slots)
    (hwf : ∀ b ∈ w.board.buttons, b.wf w.colors.length) (h0 : w.colors.count sl.mark = 0) : Unsolvable w :=
  unsolvable_of_invariant w (MissingColor w.colors.length sl)
    (missing_keep w sl hwf) (missing_no_goal w sl hs) ⟨rfl, h0⟩

#print axioms unsolvable_missing

/-! ## 三、钥匙二 · 冻格 -/

/-- 第 k 格被每个按钮原地留着：接线在 k 上是不动点，而且接线长度都是 n。 -/
def Frozen (bd : Board) (n k : Nat) : Prop := ∀ b ∈ bd.buttons, b.perm.length = n ∧ b.perm[k]? = some k

/-- 冻格的不变量：颜色恰好 n 个，第 k 格（k < n）不是 m。 -/
def WrongFrozen (n k m : Nat) (s : Colors) : Prop := s.length = n ∧ k < n ∧ s[k]? ≠ some m

theorem frozen_keep (w : World) (k m : Nat) (hf : Frozen w.board w.colors.length k) :
    ∀ s a, WrongFrozen w.colors.length k m s → WrongFrozen w.colors.length k m (move w.board s a) := by
  intro s a ⟨hl, hk, hne⟩
  cases a with
  | click x y =>
    simp only [move]
    split
    · exact ⟨hl, hk, hne⟩
    · rename_i b hb
      have ⟨hlen, hfix⟩ := hf b (List.mem_of_find?_eq_some hb)
      refine ⟨by simp [pressPermutes, hlen], hk, ?_⟩
      have hsk : s[k]? = some (s.getD k 0) := by
        rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by omega)]
        simp
      simp only [pressPermutes, List.getElem?_map, hfix, Option.map_some]
      rw [← hsk]
      exact hne

#print axioms frozen_keep

theorem frozen_no_goal (w : World) (sl : Slot) (hs : sl ∈ w.board.slots) :
    ∀ s, WrongFrozen w.colors.length sl.cell sl.mark s → isGoal w.board s = false := by
  intro s ⟨_, _, hne⟩
  cases hg : isGoal w.board s with
  | false => rfl
  | true => exact absurd (goal_needs (World.mk w.board s) sl hs hg) hne

#print axioms frozen_no_goal

/-- **钥匙二挂上骨架**：插槽那一格没有按钮会搬它、而它现在的颜色不对 ⇒ 走不通。 -/
theorem unsolvable_frozen (w : World) (sl : Slot) (hs : sl ∈ w.board.slots)
    (hf : Frozen w.board w.colors.length sl.cell) (hk : sl.cell < w.colors.length)
    (hne : w.colors[sl.cell]? ≠ some sl.mark) : Unsolvable w :=
  unsolvable_of_invariant w (WrongFrozen w.colors.length sl.cell sl.mark)
    (frozen_keep w _ _ hf) (frozen_no_goal w sl hs) ⟨rfl, hk, hne⟩

#print axioms unsolvable_frozen

/-! ## 四、手造的盘与防线

每把钥匙一张「用得上」的盘，外加一张**只差一处**的对照盘，配三条：

    _winnable          对照盘确实赢得了（给一条真路线，让内核算）
    _closed_at_start   而且不是因为它一开始就通
    _not_<钥匙>        而且那把钥匙的前提在对照盘上**真的不成立**（不是「我没证出来」）

盘面都是一行：按钮的框是 (0..3, 0..3)，点 (1, 1) 就点中它。 -/

def sceneGrid : Grid := { tile := 4, rows := [10], cols := [10, 16, 22] }
def swapBtn (p : List Nat) : Button := { r0 := 0, r1 := 3, c0 := 0, c1 := 3, dr := 0, dc := 1, perm := p }

/-- 钥匙一的盘：两格，按钮把两格对调，插槽 0 要色 5——而场上没有 5。 -/
def missingScene : World :=
  { board := { grid := sceneGrid, cells := [(0, 0), (0, 1)], buttons := [swapBtn [1, 0]],
               slots := [{ cell := 0, mark := 5 }] },
    colors := [1, 2] }

/-- 只差一处：第 1 格是 5。 -/
def missingNear : World := { missingScene with colors := [1, 5] }

theorem missingScene_unsolvable : Unsolvable (missingScene : World) :=
  unsolvable_missing missingScene { cell := 0, mark := 5 } (by decide)
    (by intro b hb; simp [missingScene] at hb; subst hb; exact List.isPerm_iff.mp (by decide)) (by decide)

theorem missingNear_winnable : Winnable (missingNear : World) := ⟨[.click 1 1], by decide⟩
theorem missingNear_closed_at_start : isGoal missingNear.board (missingNear : World).colors = false := by decide
theorem missingNear_not_missing : (missingNear : World).colors.count 5 ≠ 0 := by decide

#print axioms missingScene_unsolvable
#print axioms missingNear_winnable
#print axioms missingNear_closed_at_start
#print axioms missingNear_not_missing

/-- 钥匙二的盘：三格，按钮只对调第 1、2 格，插槽 0 要色 5——5 在场上，但搬不到第 0 格。 -/
def frozenScene : World :=
  { board := { grid := sceneGrid, cells := [(0, 0), (0, 1), (0, 2)], buttons := [swapBtn [0, 2, 1]],
               slots := [{ cell := 0, mark := 5 }] },
    colors := [1, 5, 2] }

/-- 只差一处：按钮改成对调第 0、1 格。 -/
def frozenNear : World :=
  { frozenScene with board := { frozenScene.board with buttons := [swapBtn [1, 0, 2]] } }

theorem frozenScene_unsolvable : Unsolvable (frozenScene : World) :=
  unsolvable_frozen frozenScene { cell := 0, mark := 5 } (by decide)
    (by intro b hb; simp [frozenScene] at hb; subst hb; decide) (by decide) (by decide)

/-- 钥匙一在钥匙二的盘上用不上：5 在场上。两把钥匙的理由真的不同。 -/
theorem frozenScene_not_missing : (frozenScene : World).colors.count 5 ≠ 0 := by decide

theorem frozenNear_winnable : Winnable (frozenNear : World) := ⟨[.click 1 1], by decide⟩
theorem frozenNear_closed_at_start : isGoal frozenNear.board (frozenNear : World).colors = false := by decide
theorem frozenNear_not_frozen : ¬ Frozen (frozenNear : World).board 3 0 := by
  intro h
  have := (h (swapBtn [1, 0, 2]) (by simp [frozenNear, frozenScene])).2
  simp [swapBtn] at this

#print axioms frozenScene_unsolvable
#print axioms frozenScene_not_missing
#print axioms frozenNear_winnable
#print axioms frozenNear_closed_at_start
#print axioms frozenNear_not_frozen
