/-
# Proof/Levels —— 每一关一条定理（**自动生成，不要手改**；生成器 `lean2/export_levels.py`）

    L<n>_trace      沿成绩单认证的那段真实走法，模型**每一帧**都和观测对上（外加这一段的长度）
    L<n>_route      那一段走法再加上过关那一脚：走完它，模型说「赢了」（外加动作条数）
    L<n>_winnable   这一关走得通 —— 见证就是那一段真实走法

只有开局那一帧是观测给的（`Replay.worldOf`），后面每一步都是模型自己算的。
每关核过的步数 = `_trace` 的长度 + 过关那一脚，写在每条定理的注释里，也落在 `lean2/readings.json`。

这一局 8 关全部有 `_winnable`，没有 `_unsolvable`；「走不通」的零件与防线在 `Proof/Reachable.lean`，
用在手造的盘上，不用在真实关卡上——真实的每一关在认证段里都被走通过。
-/

import Obj.World
import Step
import Obs.Check
import Obs.Replay

set_option maxRecDepth 100000

/-- 每一关那一张盘在 `Replay.boards` 里的下标（认证段）。 -/
def levelIx : Nat → Nat
  | 0 => 0
  | 1 => 1
  | 2 => 2
  | 3 => 3
  | 4 => 4
  | 5 => 5
  | 6 => 6
  | 7 => 7
  | _ => 0

/-- **两个口径相等**：认证段里每一行读到的盘，都是它那一关的那一张。 -/
theorem frames_read_level_board :
    (Replay.steps.filter (fun s => s.cert)).all (fun s => s.board == levelIx s.lvl) = true := by
  decide +kernel

#print axioms frames_read_level_board

/-! ## 第 0 关：认证段 seq 122..126，4 步走完、第 5 步过关 -/

/-- 第 0 关的真实开局：seq 122 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L0_start : World := Replay.worldOf (Replay.bySeq 122)

/-- 开局之后、过关之前的 4 步：(动作, 看到的下一帧颜色)。 -/
def L0_play : List (Act × Colors) := Replay.playFrom 122 4

/-- 这一关的全部动作，5 下，最后一下过关。 -/
def L0_acts : List Act := Replay.actsFrom 122 5

#eval match firstSplit L0_start.board L0_start.colors L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（4 步），而且这条路确实有 4 步（空表会让它平凡为真）。 -/
theorem L0_trace : (L0_start : World).traceOk L0_play = true ∧ L0_play.length = 4 := by
  decide +kernel

#print axioms L0_trace

/-- 那 5 下点完，模型说「赢了」；动作恰好 5 下。 -/
theorem L0_route :
    everWon (L0_start : World).board L0_start.colors L0_acts = true ∧ L0_acts.length = 5 := by
  decide +kernel

#print axioms L0_route

/-- **第 0 关走得通。** 核过的步数：4 + 1。 -/
theorem L0_winnable : Winnable (L0_start : World) := ⟨L0_acts, L0_route.1⟩

#print axioms L0_winnable

/-! ## 第 1 关：认证段 seq 127..134，7 步走完、第 8 步过关 -/

/-- 第 1 关的真实开局：seq 127 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L1_start : World := Replay.worldOf (Replay.bySeq 127)

/-- 开局之后、过关之前的 7 步：(动作, 看到的下一帧颜色)。 -/
def L1_play : List (Act × Colors) := Replay.playFrom 127 7

/-- 这一关的全部动作，8 下，最后一下过关。 -/
def L1_acts : List Act := Replay.actsFrom 127 8

#eval match firstSplit L1_start.board L1_start.colors L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（7 步），而且这条路确实有 7 步（空表会让它平凡为真）。 -/
theorem L1_trace : (L1_start : World).traceOk L1_play = true ∧ L1_play.length = 7 := by
  decide +kernel

#print axioms L1_trace

/-- 那 8 下点完，模型说「赢了」；动作恰好 8 下。 -/
theorem L1_route :
    everWon (L1_start : World).board L1_start.colors L1_acts = true ∧ L1_acts.length = 8 := by
  decide +kernel

#print axioms L1_route

/-- **第 1 关走得通。** 核过的步数：7 + 1。 -/
theorem L1_winnable : Winnable (L1_start : World) := ⟨L1_acts, L1_route.1⟩

#print axioms L1_winnable

/-! ## 第 2 关：认证段 seq 135..150，15 步走完、第 16 步过关 -/

/-- 第 2 关的真实开局：seq 135 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L2_start : World := Replay.worldOf (Replay.bySeq 135)

/-- 开局之后、过关之前的 15 步：(动作, 看到的下一帧颜色)。 -/
def L2_play : List (Act × Colors) := Replay.playFrom 135 15

/-- 这一关的全部动作，16 下，最后一下过关。 -/
def L2_acts : List Act := Replay.actsFrom 135 16

#eval match firstSplit L2_start.board L2_start.colors L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（15 步），而且这条路确实有 15 步（空表会让它平凡为真）。 -/
theorem L2_trace : (L2_start : World).traceOk L2_play = true ∧ L2_play.length = 15 := by
  decide +kernel

#print axioms L2_trace

/-- 那 16 下点完，模型说「赢了」；动作恰好 16 下。 -/
theorem L2_route :
    everWon (L2_start : World).board L2_start.colors L2_acts = true ∧ L2_acts.length = 16 := by
  decide +kernel

#print axioms L2_route

/-- **第 2 关走得通。** 核过的步数：15 + 1。 -/
theorem L2_winnable : Winnable (L2_start : World) := ⟨L2_acts, L2_route.1⟩

#print axioms L2_winnable

/-! ## 第 3 关：认证段 seq 151..162，11 步走完、第 12 步过关 -/

/-- 第 3 关的真实开局：seq 151 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L3_start : World := Replay.worldOf (Replay.bySeq 151)

/-- 开局之后、过关之前的 11 步：(动作, 看到的下一帧颜色)。 -/
def L3_play : List (Act × Colors) := Replay.playFrom 151 11

/-- 这一关的全部动作，12 下，最后一下过关。 -/
def L3_acts : List Act := Replay.actsFrom 151 12

#eval match firstSplit L3_start.board L3_start.colors L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（11 步），而且这条路确实有 11 步（空表会让它平凡为真）。 -/
theorem L3_trace : (L3_start : World).traceOk L3_play = true ∧ L3_play.length = 11 := by
  decide +kernel

#print axioms L3_trace

/-- 那 12 下点完，模型说「赢了」；动作恰好 12 下。 -/
theorem L3_route :
    everWon (L3_start : World).board L3_start.colors L3_acts = true ∧ L3_acts.length = 12 := by
  decide +kernel

#print axioms L3_route

/-- **第 3 关走得通。** 核过的步数：11 + 1。 -/
theorem L3_winnable : Winnable (L3_start : World) := ⟨L3_acts, L3_route.1⟩

#print axioms L3_winnable

/-! ## 第 4 关：认证段 seq 163..171，8 步走完、第 9 步过关 -/

/-- 第 4 关的真实开局：seq 163 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L4_start : World := Replay.worldOf (Replay.bySeq 163)

/-- 开局之后、过关之前的 8 步：(动作, 看到的下一帧颜色)。 -/
def L4_play : List (Act × Colors) := Replay.playFrom 163 8

/-- 这一关的全部动作，9 下，最后一下过关。 -/
def L4_acts : List Act := Replay.actsFrom 163 9

#eval match firstSplit L4_start.board L4_start.colors L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（8 步），而且这条路确实有 8 步（空表会让它平凡为真）。 -/
theorem L4_trace : (L4_start : World).traceOk L4_play = true ∧ L4_play.length = 8 := by
  decide +kernel

#print axioms L4_trace

/-- 那 9 下点完，模型说「赢了」；动作恰好 9 下。 -/
theorem L4_route :
    everWon (L4_start : World).board L4_start.colors L4_acts = true ∧ L4_acts.length = 9 := by
  decide +kernel

#print axioms L4_route

/-- **第 4 关走得通。** 核过的步数：8 + 1。 -/
theorem L4_winnable : Winnable (L4_start : World) := ⟨L4_acts, L4_route.1⟩

#print axioms L4_winnable

/-! ## 第 5 关：认证段 seq 172..190，18 步走完、第 19 步过关 -/

/-- 第 5 关的真实开局：seq 172 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L5_start : World := Replay.worldOf (Replay.bySeq 172)

/-- 开局之后、过关之前的 18 步：(动作, 看到的下一帧颜色)。 -/
def L5_play : List (Act × Colors) := Replay.playFrom 172 18

/-- 这一关的全部动作，19 下，最后一下过关。 -/
def L5_acts : List Act := Replay.actsFrom 172 19

#eval match firstSplit L5_start.board L5_start.colors L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（18 步），而且这条路确实有 18 步（空表会让它平凡为真）。 -/
theorem L5_trace : (L5_start : World).traceOk L5_play = true ∧ L5_play.length = 18 := by
  decide +kernel

#print axioms L5_trace

/-- 那 19 下点完，模型说「赢了」；动作恰好 19 下。 -/
theorem L5_route :
    everWon (L5_start : World).board L5_start.colors L5_acts = true ∧ L5_acts.length = 19 := by
  decide +kernel

#print axioms L5_route

/-- **第 5 关走得通。** 核过的步数：18 + 1。 -/
theorem L5_winnable : Winnable (L5_start : World) := ⟨L5_acts, L5_route.1⟩

#print axioms L5_winnable

/-! ## 第 6 关：认证段 seq 191..195，4 步走完、第 5 步过关 -/

/-- 第 6 关的真实开局：seq 191 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L6_start : World := Replay.worldOf (Replay.bySeq 191)

/-- 开局之后、过关之前的 4 步：(动作, 看到的下一帧颜色)。 -/
def L6_play : List (Act × Colors) := Replay.playFrom 191 4

/-- 这一关的全部动作，5 下，最后一下过关。 -/
def L6_acts : List Act := Replay.actsFrom 191 5

#eval match firstSplit L6_start.board L6_start.colors L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（4 步），而且这条路确实有 4 步（空表会让它平凡为真）。 -/
theorem L6_trace : (L6_start : World).traceOk L6_play = true ∧ L6_play.length = 4 := by
  decide +kernel

#print axioms L6_trace

/-- 那 5 下点完，模型说「赢了」；动作恰好 5 下。 -/
theorem L6_route :
    everWon (L6_start : World).board L6_start.colors L6_acts = true ∧ L6_acts.length = 5 := by
  decide +kernel

#print axioms L6_route

/-- **第 6 关走得通。** 核过的步数：4 + 1。 -/
theorem L6_winnable : Winnable (L6_start : World) := ⟨L6_acts, L6_route.1⟩

#print axioms L6_winnable

/-! ## 第 7 关：认证段 seq 196..200，4 步走完、第 5 步过关 -/

/-- 第 7 关的真实开局：seq 196 那一行动作之前的那一帧。**从语料读出来的**，不是手写的盘。 -/
def L7_start : World := Replay.worldOf (Replay.bySeq 196)

/-- 开局之后、过关之前的 4 步：(动作, 看到的下一帧颜色)。 -/
def L7_play : List (Act × Colors) := Replay.playFrom 196 4

/-- 这一关的全部动作，5 下，最后一下过关。 -/
def L7_acts : List Act := Replay.actsFrom 196 5

#eval match firstSplit L7_start.board L7_start.colors L7_play 0 with
  | none   => "L7  一处都没分家（共 " ++ toString L7_play.length ++ " 步）"
  | some i => "L7  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条路一步不差**（4 步），而且这条路确实有 4 步（空表会让它平凡为真）。 -/
theorem L7_trace : (L7_start : World).traceOk L7_play = true ∧ L7_play.length = 4 := by
  decide +kernel

#print axioms L7_trace

/-- 那 5 下点完，模型说「赢了」；动作恰好 5 下。 -/
theorem L7_route :
    everWon (L7_start : World).board L7_start.colors L7_acts = true ∧ L7_acts.length = 5 := by
  decide +kernel

#print axioms L7_route

/-- **第 7 关走得通。** 核过的步数：4 + 1。 -/
theorem L7_winnable : Winnable (L7_start : World) := ⟨L7_acts, L7_route.1⟩

#print axioms L7_winnable

