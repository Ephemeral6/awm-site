/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    点击 (x, y) → 落在哪个按钮里（按板上的次序找第一个）
      · 一个都没落中 → DeadClick
      · 落中按钮 b   → PressPermutes b
    然后看算出来的颜色：满足 isGoal → won，否则 → ok

每一支都是 `Rule/` 里的一个 `def`。这一份不加任何新说法。
-/

import Obj.World
import Rule.Click.PressPermutes
import Rule.Click.DeadClick
import Rule.Win.WinIffSlots

def hit (bd : Board) (y x : Nat) : Option Button :=
  bd.buttons.find? (fun b => b.hits y x)

/-- 这一下之后的颜色（还没判赢）。 -/
def move (bd : Board) (s : Colors) : Act → Colors
  | .click x y =>
    match hit bd y x with
    | none => deadClick s
    | some b => pressPermutes b s

def step (bd : Board) (s : Colors) (a : Act) : Res :=
  if isGoal bd (move bd s a) then .won else .ok (move bd s a)

/-- 沿一串动作走，**中途赢过一次**就是 `true`。 -/
def everWon (bd : Board) : Colors → List Act → Bool
  | _, [] => false
  | s, a :: rest =>
    match step bd s a with
    | .won => true
    | .ok s' => everWon bd s' rest

/-- 这一关走得通：存在一串点击，走着走着赢了。 -/
def Winnable (w : World) : Prop := ∃ as : List Act, everWon w.board w.colors as = true

/-- 这一关走不通：**任何**一串点击都赢不了。
    模型里没有 RESET 这一支、也没有预算（竖条不进模型），所以这句话的准确意思是：
    「在不考虑预算的前提下，不经过 RESET 也赢不了」——而 RESET 只把局面放回这一关的开局，
    从开局走不通的话它帮不上忙；预算只会让事情更难，不会更容易。 -/
def Unsolvable (w : World) : Prop := ∀ as : List Act, everWon w.board w.colors as = false
