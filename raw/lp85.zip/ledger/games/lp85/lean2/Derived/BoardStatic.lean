/-
# Derived/BoardStatic —— 一关之内版面不变（对应 `rule/world/board_static.py`）

**身份：推论（由架构推出）。** Python 那边它是一条每步要判的规则（183 条同关转移，判错 0）；
在这里它不需要被判——`step` 只拿颜色进、只吐颜色出，`Board` 是只读参数，
「走一步版面变了」**表示不出来**。

这一条定理把那句「表示不出来」落成一句可以被引用的话：把一步写成 `World → World`，
走完之后的版面就是原来那张。它几乎是同义反复——**这正是它的意思**：
这件事的全部内容都在架构里，不在任何一条规则里。
-/

import Obj.World
import Step

/-- 把一步写成世界到世界：赢了就没有下一个世界（下一帧是另一张盘，模型不描述）。 -/
def World.next (w : World) (a : Act) : Option World :=
  match step w.board w.colors a with
  | .ok s => some { board := w.board, colors := s }
  | .won => none

theorem board_static (w w' : World) (a : Act) (h : w.next a = some w') : w'.board = w.board := by
  unfold World.next at h
  split at h
  · cases h; rfl
  · cases h

#print axioms board_static
