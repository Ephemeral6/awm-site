/-
# Derived/ColorsConserved —— 走一步，每种颜色各有几块不变（对应起点册子 `panel_mark_step`）

**身份：推论。** 起点册子里 `panel_mark_step` 是一条每步要判的概念：「每条插槽拐角环上仍然恰好一块
角标瓷砖」。它其实不是一条独立的规律：只要接线是一张**真正的置换**（每一格恰好被搬去一次），
颜色就只是换了位置，每种颜色各有几块一块不多、一块不少——角标色那一块当然也还在。

前提 `wf`（每个按钮的接线是 `0..n-1` 的一个排列，n = 格数 = 颜色个数）不是白给的：
它是盘面的良构性，对语料里每一个真实的世界由 `Obs/Corpus.lean` 的 `wf_all_boards` 让内核逐个核过。
放在那边是为了依赖方向：推论只依赖规则与架构，不依赖语料。
-/

import Obj.World
import Step

/-- 接线是 `0..n-1` 的一个排列。 -/
def Button.wf (b : Button) (n : Nat) : Prop := b.perm.Perm (List.range n)

/-- 盘上每个按钮的接线都是排列，而且颜色恰好 n 个。 -/
def World.wf (w : World) : Prop := ∀ b ∈ w.board.buttons, b.wf w.colors.length

/-- **点一下，每种颜色的块数不变**（`move` 是 `step` 判赢之前的那一半）：
    点空当然不变；点中按钮是按一张排列搬颜色。 -/
theorem colors_conserved (w : World) (a : Act) (c : Nat) (hwf : w.wf) :
    (move w.board w.colors a).count c = w.colors.count c := by
  have key : ∀ s : List Nat, (List.range s.length).map (fun i => s.getD i 0) = s := by
    intro s
    induction s with
    | nil => rfl
    | cons x t ih =>
      rw [List.length_cons, List.range_succ_eq_map, List.map_cons, List.map_map]
      simp only [List.getD_cons_zero, Function.comp_def, List.getD_cons_succ]
      rw [ih]
  cases a with
  | click x y =>
    simp only [move]
    split
    · rfl
    · rename_i b hb
      have hw : b.wf w.colors.length := hwf b (List.mem_of_find?_eq_some hb)
      unfold pressPermutes
      have hp : (b.perm.map (fun i => w.colors.getD i 0)).Perm
          ((List.range w.colors.length).map (fun i => w.colors.getD i 0)) := List.Perm.map _ hw
      rw [key] at hp
      exact hp.count_eq c

#print axioms colors_conserved
