/-
# Rule/Click/DeadClick —— 点空：什么都不变（对应 `rule/click/dead_click.py`）

定义。Python 那一条判的是**整个 World** 相等（颜色、竖条、版面）；这里状态只有颜色，
版面本来就碰不到，竖条不进模型——所以剩下的就是「颜色原样」。
-/

import Obj.World

def deadClick (s : Colors) : Colors := s
