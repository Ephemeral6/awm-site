/-
# Rule/Click/PressPermutes —— 点中按钮：颜色按它的接线搬一次（对应 `rule/click/press_permutes.py`）

**这是一个定义，不是一条定理。** 「点中按钮就按置换搬颜色」是对**点中按钮**的定义；
写成待证的定理，就是用它自己证它自己。

第 k 格的新颜色 = 旧的第 `perm[k]` 格的颜色。置换没提到的格——接线里 `perm[k] = k`——原样不动，
所以起点册子里那几条「别处不动」（off_*_static）在这里不是另外的话，是同一个定义的另一半。
-/

import Obj.World

def pressPermutes (b : Button) (s : Colors) : Colors :=
  b.perm.map (fun i => s.getD i 0)
