/-
# Rule/Win/WinIffSlots —— 什么算赢（对应 `rule/win/win_iff_slots.py`）

定义：**每一个插槽那一格上都是它自己角标色的瓷砖**，而且至少有一个插槽。
这是一个**状态**的性质（不是一个转移事件），所以「这个局面赢不赢得了」才问得出来。

Python 那一条是一个等价（过关 ⟺ 装对）；在模型里它变成 `step` 的一个分支：
算出来的颜色满足 `isGoal` 就返回 `won`，否则返回新状态。两半都由语料那一层逐条核
（`Obs/Corpus.lean`：换关的那几步模型必须说 `won`，没换关的那几步模型必须**不**说 `won`）。
-/

import Obj.World

def isGoal (bd : Board) (s : Colors) : Bool :=
  !bd.slots.isEmpty && bd.slots.all (fun sl => s[sl.cell]? == some sl.mark)
