/-
# Check —— 判据层：模型算出来的和看到的一样吗（**0 条定理**，尺子不自证）

`Seen` 只装**帧上看得见的**：棋子、看得见的替身（**按集合比**：谁是第几个替身帧上读不出）、
环、车（按集合比）、游标。不装计数条（不进模型，见 `bar_ticks`），不装地形（在 `Board`，一关不变）。

    traceOk   从开局起**带着自己算出来的状态**往下走，逐帧和观测比。
              只有开局是观测给的，后面全是模型自己算的——错一步，后面全错，那正是要的。
-/
import Step

namespace G50t

structure Seen where
  me     : Cell
  ghosts : List Cell
  walker : Option Cell
  carts  : List Cell
  cursor : Nat
deriving DecidableEq, Repr

def setEq (xs ys : List Cell) : Bool :=
  xs.all (ys.contains ·) && ys.all (xs.contains ·)

/-- 看得见的替身：没被棋子盖住的那些。 -/
def visible (s : World) : List Cell :=
  (s.ghosts.map (·.pos)).filter (· != s.me)

def seenOk (s : World) (o : Seen) : Bool :=
  s.me == o.me && setEq (visible s) o.ghosts && s.walker == o.walker
    && setEq s.carts o.carts && s.hud.cursor == o.cursor

def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, [] => true
  | s, (a, o) :: rest =>
    let s' := step b s a
    seenOk s' o && traceOk b s' rest

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，不是定理。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | s, (a, o) :: rest, i =>
    let s' := step b s a
    if seenOk s' o then firstSplit b s' rest (i + 1) else some i

end G50t
