/-
# 第 5 关 —— 一关一条结论：**走得通**（自动生成：`python lean2/export_levels.py`，不要手改）

认证段 seq 720–768：开局那一帧是 seq 720 的前一帧；48 步真实走法（不含过关那一脚），
最后一脚 seq 768 走进终点格。

    L5_trace     沿着真实走法，模型**每一帧都和观测对上**（只有开局是观测给的，后面全是模型自己算的）
    L5_winnable  这一关走得通，见证 = 那 48 步 + 过关那一脚

逐帧核对比的是 `Seen`：棋子、看得见的替身（按集合）、环、车（按集合）、游标。**不比计数条**（不进模型）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

-- 定理放在根命名空间：装置的 lean_check 用裸名字 `#print axioms <名字>` 去查
open G50t

set_option maxRecDepth 100000

def L5_board : Board := board16

def L5_start : World := initWorld board16

/-- 模型的开局就是那一帧读到的：棋子在起点、车都在家、没有替身、游标 0。 -/
theorem L5_start_seen : seenOk (L5_start : World) seen16 = true := by decide +kernel

def L5_play : List (Act × Seen) := playRange 720 768

/-- 钉住切片：**空表会让下一条平凡为真**，所以步数单独证一遍（连同开局是哪一个 World）。 -/
theorem L5_len : L5_play.length = 48 ∧ (L5_start : World) = initWorld board16 :=
  ⟨by decide +kernel, rfl⟩

/-- **模型沿着真实走法一步不差**，48 步。 -/
theorem L5_trace : traceOk board16 (L5_start : World) L5_play = true := by decide +kernel

def L5_acts : List Act := actsRange 720 769

/-- **这一关走得通。** 见证是真实走法（49 下，连过关那一脚）；「赢」= 某一刻棋子站在终点格上。 -/
theorem L5_winnable : L5_acts.length = 49 ∧ Winnable board16 (L5_start : World) :=
  ⟨by decide +kernel, L5_acts, by decide +kernel⟩

#eval match firstSplit board16 L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

#print axioms L5_start_seen
#print axioms L5_len
#print axioms L5_trace
#print axioms L5_winnable
