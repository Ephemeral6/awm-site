/-
# 第 1 关 —— 一关一条结论：**走得通**（自动生成：`python lean2/export_levels.py`，不要手改）

认证段 seq 542–572：开局那一帧是 seq 542 的前一帧；30 步真实走法（不含过关那一脚），
最后一脚 seq 572 走进终点格。

    L1_trace     沿着真实走法，模型**每一帧都和观测对上**（只有开局是观测给的，后面全是模型自己算的）
    L1_winnable  这一关走得通，见证 = 那 30 步 + 过关那一脚

逐帧核对比的是 `Seen`：棋子、看得见的替身（按集合）、环、车（按集合）、游标。**不比计数条**（不进模型）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

-- 定理放在根命名空间：装置的 lean_check 用裸名字 `#print axioms <名字>` 去查
open G50t

set_option maxRecDepth 100000

def L1_board : Board := board12

def L1_start : World := initWorld board12

/-- 模型的开局就是那一帧读到的：棋子在起点、车都在家、没有替身、游标 0。 -/
theorem L1_start_seen : seenOk (L1_start : World) seen12 = true := by decide +kernel

def L1_play : List (Act × Seen) := playRange 542 572

/-- 钉住切片：**空表会让下一条平凡为真**，所以步数单独证一遍（连同开局是哪一个 World）。 -/
theorem L1_len : L1_play.length = 30 ∧ (L1_start : World) = initWorld board12 :=
  ⟨by decide +kernel, rfl⟩

/-- **模型沿着真实走法一步不差**，30 步。 -/
theorem L1_trace : traceOk board12 (L1_start : World) L1_play = true := by decide +kernel

def L1_acts : List Act := actsRange 542 573

/-- **这一关走得通。** 见证是真实走法（31 下，连过关那一脚）；「赢」= 某一刻棋子站在终点格上。 -/
theorem L1_winnable : L1_acts.length = 31 ∧ Winnable board12 (L1_start : World) :=
  ⟨by decide +kernel, L1_acts, by decide +kernel⟩

#eval match firstSplit board12 L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

#print axioms L1_start_seen
#print axioms L1_len
#print axioms L1_trace
#print axioms L1_winnable
