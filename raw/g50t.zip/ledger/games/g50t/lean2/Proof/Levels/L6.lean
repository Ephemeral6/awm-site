/-
# 第 6 关 —— 一关一条结论：**走得通**（自动生成：`python lean2/export_levels.py`，不要手改）

认证段 seq 769–811：开局那一帧是 seq 769 的前一帧；42 步真实走法（不含过关那一脚），
最后一脚 seq 811 走进终点格。

    L6_trace     沿着真实走法，模型**每一帧都和观测对上**（只有开局是观测给的，后面全是模型自己算的）
    L6_winnable  这一关走得通，见证 = 那 42 步 + 过关那一脚

逐帧核对比的是 `Seen`：棋子、看得见的替身（按集合）、环、车（按集合）、游标。**不比计数条**（不进模型）。
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

-- 定理放在根命名空间：装置的 lean_check 用裸名字 `#print axioms <名字>` 去查
open G50t

set_option maxRecDepth 100000

def L6_board : Board := board17

def L6_start : World := initWorld board17

/-- 模型的开局就是那一帧读到的：棋子在起点、车都在家、没有替身、游标 0。 -/
theorem L6_start_seen : seenOk (L6_start : World) seen17 = true := by decide +kernel

def L6_play : List (Act × Seen) := playRange 769 811

/-- 钉住切片：**空表会让下一条平凡为真**，所以步数单独证一遍（连同开局是哪一个 World）。 -/
theorem L6_len : L6_play.length = 42 ∧ (L6_start : World) = initWorld board17 :=
  ⟨by decide +kernel, rfl⟩

/-- **模型沿着真实走法一步不差**，42 步。 -/
theorem L6_trace : traceOk board17 (L6_start : World) L6_play = true := by decide +kernel

def L6_acts : List Act := actsRange 769 812

/-- **这一关走得通。** 见证是真实走法（43 下，连过关那一脚）；「赢」= 某一刻棋子站在终点格上。 -/
theorem L6_winnable : L6_acts.length = 43 ∧ Winnable board17 (L6_start : World) :=
  ⟨by decide +kernel, L6_acts, by decide +kernel⟩

#eval match firstSplit board17 L6_start L6_play 0 with
  | none   => "L6  一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6  第 " ++ toString i ++ " 步分家"

#print axioms L6_start_seen
#print axioms L6_len
#print axioms L6_trace
#print axioms L6_winnable
