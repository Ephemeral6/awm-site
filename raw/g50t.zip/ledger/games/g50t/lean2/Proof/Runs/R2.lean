/-
# 未认证段 · 第 2 关的一段（seq 71–136，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，65 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R2_start : World := initWorld board2

theorem R2_start_seen : seenOk (R2_start : World) seen2 = true := by decide +kernel

def R2_play : List (Act × Seen) := playRange 71 137

theorem R2_len : R2_play.length = 65 ∧ (R2_start : World) = initWorld board2 :=
  ⟨by decide +kernel, rfl⟩

theorem R2_trace : traceOk board2 (R2_start : World) R2_play = true := by decide +kernel

#eval match firstSplit board2 R2_start R2_play 0 with
  | none   => "R2  一处都没分家（共 " ++ toString R2_play.length ++ " 步）"
  | some i => "R2  第 " ++ toString i ++ " 步分家"

#print axioms R2_start_seen
#print axioms R2_len
#print axioms R2_trace
