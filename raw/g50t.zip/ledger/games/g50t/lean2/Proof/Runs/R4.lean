/-
# 未认证段 · 第 4 关的一段（seq 170–269，以 RESET 收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，99 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R4_start : World := initWorld board4

theorem R4_start_seen : seenOk (R4_start : World) seen4 = true := by decide +kernel

def R4_play : List (Act × Seen) := playRange 170 270

theorem R4_len : R4_play.length = 99 ∧ (R4_start : World) = initWorld board4 :=
  ⟨by decide +kernel, rfl⟩

theorem R4_trace : traceOk board4 (R4_start : World) R4_play = true := by decide +kernel

#eval match firstSplit board4 R4_start R4_play 0 with
  | none   => "R4  一处都没分家（共 " ++ toString R4_play.length ++ " 步）"
  | some i => "R4  第 " ++ toString i ++ " 步分家"

#print axioms R4_start_seen
#print axioms R4_len
#print axioms R4_trace
