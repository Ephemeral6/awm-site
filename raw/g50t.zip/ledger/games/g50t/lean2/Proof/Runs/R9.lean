/-
# 未认证段 · 第 6 关的一段（seq 471–480，以 RESET 收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，9 步。

**这一段紧接在一次 RESET 之后。** 它的开局用的是 `initWorld`（这一关的开局），所以「RESET 把局面放回开局」这条不进模型的假设在这里有一次被驳倒的机会：假设错了，`R9_start_seen` 第一帧就对不上。**没红不构成证明。**
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R9_start : World := initWorld board9

theorem R9_start_seen : seenOk (R9_start : World) seen9 = true := by decide +kernel

def R9_play : List (Act × Seen) := playRange 471 481

theorem R9_len : R9_play.length = 9 ∧ (R9_start : World) = initWorld board9 :=
  ⟨by decide +kernel, rfl⟩

theorem R9_trace : traceOk board9 (R9_start : World) R9_play = true := by decide +kernel

#eval match firstSplit board9 R9_start R9_play 0 with
  | none   => "R9  一处都没分家（共 " ++ toString R9_play.length ++ " 步）"
  | some i => "R9  第 " ++ toString i ++ " 步分家"

#print axioms R9_start_seen
#print axioms R9_len
#print axioms R9_trace
