/-
# 未认证段 · 第 4 关的一段（seq 270–319，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，49 步。

**这一段紧接在一次 RESET 之后。** 它的开局用的是 `initWorld`（这一关的开局），所以「RESET 把局面放回开局」这条不进模型的假设在这里有一次被驳倒的机会：假设错了，`R5_start_seen` 第一帧就对不上。**没红不构成证明。**
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R5_start : World := initWorld board5

theorem R5_start_seen : seenOk (R5_start : World) seen5 = true := by decide +kernel

def R5_play : List (Act × Seen) := playRange 270 320

theorem R5_len : R5_play.length = 49 ∧ (R5_start : World) = initWorld board5 :=
  ⟨by decide +kernel, rfl⟩

theorem R5_trace : traceOk board5 (R5_start : World) R5_play = true := by decide +kernel

#eval match firstSplit board5 R5_start R5_play 0 with
  | none   => "R5  一处都没分家（共 " ++ toString R5_play.length ++ " 步）"
  | some i => "R5  第 " ++ toString i ++ " 步分家"

#print axioms R5_start_seen
#print axioms R5_len
#print axioms R5_trace
