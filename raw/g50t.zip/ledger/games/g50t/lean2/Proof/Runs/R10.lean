/-
# 未认证段 · 第 6 关的一段（seq 481–523，以通关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，42 步。

**这一段紧接在一次 RESET 之后。** 它的开局用的是 `initWorld`（这一关的开局），所以「RESET 把局面放回开局」这条不进模型的假设在这里有一次被驳倒的机会：假设错了，`R10_start_seen` 第一帧就对不上。**没红不构成证明。**
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R10_start : World := initWorld board10

theorem R10_start_seen : seenOk (R10_start : World) seen10 = true := by decide +kernel

def R10_play : List (Act × Seen) := playRange 481 524

theorem R10_len : R10_play.length = 42 ∧ (R10_start : World) = initWorld board10 :=
  ⟨by decide +kernel, rfl⟩

theorem R10_trace : traceOk board10 (R10_start : World) R10_play = true := by decide +kernel

#eval match firstSplit board10 R10_start R10_play 0 with
  | none   => "R10  一处都没分家（共 " ++ toString R10_play.length ++ " 步）"
  | some i => "R10  第 " ++ toString i ++ " 步分家"

#print axioms R10_start_seen
#print axioms R10_len
#print axioms R10_trace
