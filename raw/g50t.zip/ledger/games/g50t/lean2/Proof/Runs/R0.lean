/-
# 未认证段 · 第 0 关的一段（seq 1–39，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，38 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R0_start : World := initWorld board0

theorem R0_start_seen : seenOk (R0_start : World) seen0 = true := by decide +kernel

def R0_play : List (Act × Seen) := playRange 1 40

theorem R0_len : R0_play.length = 38 ∧ (R0_start : World) = initWorld board0 :=
  ⟨by decide +kernel, rfl⟩

theorem R0_trace : traceOk board0 (R0_start : World) R0_play = true := by decide +kernel

#eval match firstSplit board0 R0_start R0_play 0 with
  | none   => "R0  一处都没分家（共 " ++ toString R0_play.length ++ " 步）"
  | some i => "R0  第 " ++ toString i ++ " 步分家"

#print axioms R0_start_seen
#print axioms R0_len
#print axioms R0_trace
