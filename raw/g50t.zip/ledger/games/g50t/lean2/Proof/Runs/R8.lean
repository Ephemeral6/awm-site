/-
# 未认证段 · 第 6 关的一段（seq 394–470，以 RESET 收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，76 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R8_start : World := initWorld board8

theorem R8_start_seen : seenOk (R8_start : World) seen8 = true := by decide +kernel

def R8_play : List (Act × Seen) := playRange 394 471

theorem R8_len : R8_play.length = 76 ∧ (R8_start : World) = initWorld board8 :=
  ⟨by decide +kernel, rfl⟩

theorem R8_trace : traceOk board8 (R8_start : World) R8_play = true := by decide +kernel

#eval match firstSplit board8 R8_start R8_play 0 with
  | none   => "R8  一处都没分家（共 " ++ toString R8_play.length ++ " 步）"
  | some i => "R8  第 " ++ toString i ++ " 步分家"

#print axioms R8_start_seen
#print axioms R8_len
#print axioms R8_trace
