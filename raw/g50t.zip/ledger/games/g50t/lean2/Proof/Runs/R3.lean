/-
# 未认证段 · 第 3 关的一段（seq 137–169，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，32 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R3_start : World := initWorld board3

theorem R3_start_seen : seenOk (R3_start : World) seen3 = true := by decide +kernel

def R3_play : List (Act × Seen) := playRange 137 170

theorem R3_len : R3_play.length = 32 ∧ (R3_start : World) = initWorld board3 :=
  ⟨by decide +kernel, rfl⟩

theorem R3_trace : traceOk board3 (R3_start : World) R3_play = true := by decide +kernel

#eval match firstSplit board3 R3_start R3_play 0 with
  | none   => "R3  一处都没分家（共 " ++ toString R3_play.length ++ " 步）"
  | some i => "R3  第 " ++ toString i ++ " 步分家"

#print axioms R3_start_seen
#print axioms R3_len
#print axioms R3_trace
