/-
# 未认证段 · 第 1 关的一段（seq 40–70，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，30 步。


-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R1_start : World := initWorld board1

theorem R1_start_seen : seenOk (R1_start : World) seen1 = true := by decide +kernel

def R1_play : List (Act × Seen) := playRange 40 71

theorem R1_len : R1_play.length = 30 ∧ (R1_start : World) = initWorld board1 :=
  ⟨by decide +kernel, rfl⟩

theorem R1_trace : traceOk board1 (R1_start : World) R1_play = true := by decide +kernel

#eval match firstSplit board1 R1_start R1_play 0 with
  | none   => "R1  一处都没分家（共 " ++ toString R1_play.length ++ " 步）"
  | some i => "R1  第 " ++ toString i ++ " 步分家"

#print axioms R1_start_seen
#print axioms R1_len
#print axioms R1_trace
