/-
# 未认证段 · 第 5 关的一段（seq 331–393，以过关收尾）（自动生成：`python lean2/export_levels.py`）

这一段**不是**成绩单认证的那一段，所以它不给「这一关走得通」当见证；它只做一件事：
**模型从这一关的开局起自己算，逐帧和观测对上**，62 步。

**这一段紧接在一次 RESET 之后。** 它的开局用的是 `initWorld`（这一关的开局），所以「RESET 把局面放回开局」这条不进模型的假设在这里有一次被驳倒的机会：假设错了，`R7_start_seen` 第一帧就对不上。**没红不构成证明。**
-/
import Obj.World
import Obs.Replay
import Proof.Reachable

open G50t

set_option maxRecDepth 100000

def R7_start : World := initWorld board7

theorem R7_start_seen : seenOk (R7_start : World) seen7 = true := by decide +kernel

def R7_play : List (Act × Seen) := playRange 331 394

theorem R7_len : R7_play.length = 62 ∧ (R7_start : World) = initWorld board7 :=
  ⟨by decide +kernel, rfl⟩

theorem R7_trace : traceOk board7 (R7_start : World) R7_play = true := by decide +kernel

#eval match firstSplit board7 R7_start R7_play 0 with
  | none   => "R7  一处都没分家（共 " ++ toString R7_play.length ++ " 步）"
  | some i => "R7  第 " ++ toString i ++ " 步分家"

#print axioms R7_start_seen
#print axioms R7_len
#print axioms R7_trace
