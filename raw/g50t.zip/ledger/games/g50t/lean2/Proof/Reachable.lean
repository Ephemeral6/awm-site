/-
# Reachable —— 这个局面走得通 / 走不通

    Winnable   b w  :=  ∃ as, 照着走中途赢过（某一刻棋子站在终点格上）
    Unsolvable b w  :=  ∀ as, 照着走从没赢过

## 模型描述不了的那一支，削弱写在明处

动作里**没有 RESET**（`Act` 只有四个方向键和换一盘）。所以这里的 `Unsolvable` 准确的意思是
**「不经过 RESET 就赢不了」**。RESET 把局面放回开局，而「开局」是历史不是状态，模型不描述它。
这一句要和定理一起读，不许含糊过去。

## 骨架（与盘面大小无关，不枚举、不搜索）

    找一个每步都保持、又和「赢」矛盾的性质 Φ ⇒ 从满足 Φ 的局面出发怎么走都赢不了。

本局**七关都有真人走通的见证**（`Proof/Levels/`），没有一关宣告不可做；
骨架留在这里，是给「这一关走不通」那种话**唯一**允许的说法。
-/
import Obj.World
import Step

-- 定理放在根命名空间：装置的 lean_check 用裸名字 `#print axioms <名字>` 去查，查不到命名空间里的
open G50t

def everGoal (b : Board) : World → List Act → Bool
  | w, []      => isGoal b w
  | w, a :: as => isGoal b w || everGoal b (step b w a) as

def Winnable (b : Board) (w : World) : Prop := ∃ as : List Act, everGoal b w as = true

def Unsolvable (b : Board) (w : World) : Prop := ∀ as : List Act, everGoal b w as = false

theorem not_both (b : Board) (w : World) : Winnable b w → Unsolvable b w → False := by
  intro ⟨as, h⟩ hu
  rw [hu as] at h
  exact Bool.false_ne_true h

/-- 骨架：Φ 每步保持、Φ 下不是目标 ⇒ 从满足 Φ 的局面出发，任何动作串都赢不了。
    对动作串做归纳，`generalizing w` 是要害。 -/
theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w a, P w → P (step b w a))
    (hgoal : ∀ w, P w → isGoal b w = false) :
    ∀ w, P w → Unsolvable b w := by
  intro w hp as
  induction as generalizing w with
  | nil => simp [everGoal, hgoal w hp]
  | cons a t ih => simp [everGoal, hgoal w hp, ih (step b w a) (hkeep w a hp)]

#print axioms not_both
#print axioms unsolvable_of_invariant
