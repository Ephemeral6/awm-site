/-
# goal_is_levelup（`rule/什么算赢/goal_is_levelup.py`）—— **定义**

「赢」是一个**状态**性质：棋子站在终点格上。不是一个转移事件——
写成事件的话没有任何一个状态是目标，「这个局面走不走得通」就无从问起。
走进终点格的那一步由 `meStepsIfFree` 管（终点格进得去），走进去之后这个状态就是赢。
-/
import Obj.Board.Board
import Obj.World

namespace G50t

def isGoal (b : Board) (s : World) : Bool :=
  b.at s.me == .goal

end G50t
