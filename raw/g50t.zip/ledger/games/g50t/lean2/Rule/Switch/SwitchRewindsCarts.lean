/-
# switch_rewinds_carts（`rule/换一盘/switch_rewinds_carts.py`）—— **定义**

换一盘那一步：弹簧车回家；闩车回到这一盘开局时那一格，除非此刻它的按钮正被压着（那就不动）。
-/
import Obj.Board.Rail

namespace G50t

def switchRewindsCarts (tr : Track) (occ0 : List Cell) (pos roundPos : Cell) : Cell :=
  match tr.kind with
  | .spring => tr.home
  | .latch  => if occ0.contains tr.button then pos else roundPos
  | .other  => pos

end G50t
