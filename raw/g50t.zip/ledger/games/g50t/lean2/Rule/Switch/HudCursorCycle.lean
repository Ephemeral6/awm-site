/-
# hud_cursor_cycle（`rule/换一盘/hud_cursor_cycle.py`）—— **定义**

ACTION5：游标进一格，到头绕回 0。方向键不动游标（`Step` 里直接不碰它）。
-/
import Obj.Panel.Hud

namespace G50t

def hudCursorCycle (h : Hud) : Hud :=
  { h with cursor := (h.cursor + 1) % h.n }

end G50t
