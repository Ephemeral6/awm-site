/-
# switch_restarts_round（`rule/换一盘/switch_restarts_round.py`）—— **定义**

换一盘：刚录完的这一盘变成一个新替身；棋子、所有替身回起点格，环回它的起点，
这一盘从第 0 步重新数。**游标绕回第 0 槽时，所有带子一起清掉**（`wrap = true`）。
-/
import Obj.Board.Board
import Obj.World

namespace G50t

def switchRestartsRound (b : Board) (s : World) (wrap : Bool) : List Ghost :=
  if wrap then []
  else s.ghosts.map (fun g => { g with pos := b.start }) ++ [⟨b.start, s.tape⟩]

end G50t
