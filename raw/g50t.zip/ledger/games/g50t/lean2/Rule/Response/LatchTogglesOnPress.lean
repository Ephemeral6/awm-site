/-
# latch_toggles_on_press（`rule/世界怎么回应/latch_toggles_on_press.py`）—— **定义**

闩车：按钮上升沿 → 在家和前一格之间翻一次；其余不动。
-/
import Obj.Derive.Track

namespace G50t

def latchTogglesOnPress (tr : Track) (occ0 occ1 : List Cell) (pos : Cell) : Cell :=
  if occ1.contains tr.button && !(occ0.contains tr.button) then tr.other pos else pos

end G50t
