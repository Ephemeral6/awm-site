/-
# spring_follows_button（`rule/世界怎么回应/spring_follows_button.py`）—— **定义**

弹簧车：按钮上升沿 → 前一格；下降沿 → 回家；其余不动。
-/
import Obj.Board.Rail

namespace G50t

def springFollowsButton (tr : Track) (occ0 occ1 : List Cell) (pos : Cell) : Cell :=
  if occ1.contains tr.button && !(occ0.contains tr.button) then tr.fwd
  else if occ0.contains tr.button && !(occ1.contains tr.button) then tr.home
  else pos

end G50t
