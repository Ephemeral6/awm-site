/-
# ghosts_replay_tapes（`rule/替身与环/ghosts_replay_tapes.py`）—— **定义**

每个替身在这一盘的第 `t` 步放自己带子里的第 `t` 个动作（进不去就原地，但那一下照样用掉）；
带子放完就停住。过门那一半用 `portalNeedsRisingEdge`，在 `Step` 里接上。
-/
import Obj.Derive.Cells

namespace G50t

def ghostsReplayTapes (b : Board) (carts : List Cell) (t : Nat) (g : Ghost) : Ghost :=
  match g.tape[t]? with
  | some d => { g with pos := tryGo b carts g.pos d }
  | none   => g

end G50t
