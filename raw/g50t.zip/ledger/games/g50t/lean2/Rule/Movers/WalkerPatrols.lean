/-
# walker_patrols（`rule/替身与环/walker_patrols.py`）—— **定义**

环只在棋子挪了窝的那一步走：直走 > 唯一的侧路 > 掉头 > 原地。
岔路口（直走不通、两侧都通）Python 那边闭嘴；这里**选不出就原地**——
那一支在语料里一次都没走到，模型在那里说的话没有被检验过（写在明处）。
被压掉那一半（落脚那格同一步被车挪进来）在 `Step` 里接上，因为它要等车挪完。
-/
import Obj.Derive.Cells

namespace G50t

def sides : Dir → List Dir
  | .up | .down => [.left, .right]
  | .left | .right => [.up, .down]

def canGo (b : Board) (carts : List Cell) (w : Cell) (d : Dir) : Bool :=
  match w.go d with
  | some y => enterable b carts y
  | none => false

/-- 环这一步朝哪走；`none` = 原地。 -/
def walkerChoice (b : Board) (carts : List Cell) (w : Cell) : Option Dir → Option Dir
  | some h =>
    if canGo b carts w h then some h else
    match (sides h).filter (canGo b carts w) with
    | [d] => some d
    | [] => if canGo b carts w h.back then some h.back else none
    | _ => none
  | none =>
    match [Dir.up, Dir.down, Dir.left, Dir.right].filter (canGo b carts w) with
    | [d] => some d
    | _ => none

def walkerPatrols (b : Board) (carts : List Cell) (w : Option Cell) (h : Option Dir) :
    Option Cell × Option Dir :=
  match w with
  | none => (none, h)
  | some x =>
    match walkerChoice b carts x h with
    | some d => ((x.go d).orElse (fun _ => some x), some d)
    | none => (some x, h)

end G50t
