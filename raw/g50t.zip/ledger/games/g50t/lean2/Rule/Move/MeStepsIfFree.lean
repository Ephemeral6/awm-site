/-
# me_steps_if_free（`rule/一步怎么走/me_steps_if_free.py`）—— **定义**

方向键：目标格进得去就挪过去，进不去（墙、车、出界）就原地。
这是对「方向键」的**定义**，不是一条待证的定理。
-/
import Obj.Derive.Cells

namespace G50t

def meStepsIfFree (b : Board) (s : World) (d : Dir) : Cell :=
  tryGo b s.carts s.me d

end G50t
