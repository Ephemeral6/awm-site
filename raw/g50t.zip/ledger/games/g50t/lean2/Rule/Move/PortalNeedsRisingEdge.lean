/-
# portal_needs_rising_edge（`rule/一步怎么走/portal_needs_rising_edge.py`）—— **定义**

一个活物这一步**挪进了**一扇门（`p1 ≠ p0` 且 `p1` 是门）：同网按钮这一步有上升沿就落到搭档那扇，
否则停在门里。棋子和替身用的是同一条（Python 那边替身这一半写在 `derive/history.py` 里）。
-/
import Obj.Derive.Links

namespace G50t

def portalNeedsRisingEdge (b : Board) (occ0 occ1 : List Cell) (p0 p1 : Cell) : Cell :=
  if p1 = p0 then p1 else
  match linkOf b p1 with
  | some (other, trig) => if rising occ0 occ1 trig then other else p1
  | none => p1

end G50t
