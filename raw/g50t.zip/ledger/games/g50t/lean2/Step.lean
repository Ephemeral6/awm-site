/-
# Step —— 一步怎么走：**只做分发，0 条定理**

每一条规则都是 `Rule/` 下的一个 `def`；这里只把它们按先后接起来：

    方向键   棋子挪（meStepsIfFree）→ 替身放带子（ghostsReplayTapes）
             → 棋子挪了窝的话环走一格（walkerPatrols）
             → 按新旧两帧谁压着按钮，车挪（springFollowsButton / latchTogglesOnPress）
             → 环落脚那格被车挪进来就被压掉
             → 挪进门的活物看上升沿过门（portalNeedsRisingEdge）
             → 棋子挪了窝就把这一下录进这一盘的带子
    ACTION5  游标进一格（hudCursorCycle）→ 录完这一盘、全体回起点（switchRestartsRound）
             → 车回去（switchRewindsCarts）

「这一步谁压着按钮」用的是**替身、环挪完之后、过门之前**的位置。
这个次序是模型的一部分；它错了，`Proof/Levels` 里的逐帧核对会在第一处用到它的地方红。
-/
import Rule.Move.MeStepsIfFree
import Rule.Move.PortalNeedsRisingEdge
import Rule.Movers.GhostsReplayTapes
import Rule.Movers.WalkerPatrols
import Rule.Response.SpringFollowsButton
import Rule.Response.LatchTogglesOnPress
import Rule.Switch.SwitchRestartsRound
import Rule.Switch.SwitchRewindsCarts
import Rule.Switch.HudCursorCycle
import Rule.Win.GoalIsLevelup

namespace G50t

def cartsAfter (occ0 occ1 : List Cell) : List Track → List Cell → List Cell
  | tr :: ts, p :: ps =>
    (match tr.kind with
     | .spring => springFollowsButton tr occ0 occ1 p
     | .latch  => latchTogglesOnPress tr occ0 occ1 p
     | .other  => p) :: cartsAfter occ0 occ1 ts ps
  | _, _ => []

def cartsRewound (occ0 : List Cell) : List Track → List Cell → List Cell → List Cell
  | tr :: ts, p :: ps, q :: qs => switchRewindsCarts tr occ0 p q :: cartsRewound occ0 ts ps qs
  | _, _, _ => []

def crush (carts : List Cell) : Option Cell → Option Cell
  | some x => if carts.contains x then none else some x
  | none => none

def hopAll (b : Board) (occ0 occ1 : List Cell) (before after : List Ghost) : List Ghost :=
  List.zipWith (fun g0 g => { g with pos := portalNeedsRisingEdge b occ0 occ1 g0.pos g.pos }) before after

def moveStep (b : Board) (s : World) (d : Dir) : World :=
  let me1 := meStepsIfFree b s d
  let g1 := s.ghosts.map (ghostsReplayTapes b s.carts s.t)
  let wh := if me1 = s.me then (s.walker, s.heading) else walkerPatrols b s.carts s.walker s.heading
  let occ0 := occupied s
  let occ1 := me1 :: (g1.map (·.pos) ++ wh.1.toList)
  let carts1 := cartsAfter occ0 occ1 b.tracks s.carts
  let me2 := portalNeedsRisingEdge b occ0 occ1 s.me me1
  { s with me := me2,
           ghosts := hopAll b occ0 occ1 s.ghosts g1,
           walker := crush carts1 wh.1,
           heading := wh.2,
           carts := carts1,
           tape := if me2 = s.me then s.tape else s.tape ++ [d],
           t := s.t + 1 }

def switchStep (b : Board) (s : World) : World :=
  let h := hudCursorCycle s.hud
  let carts1 := cartsRewound (occupied s) b.tracks s.carts s.round
  { me := b.start,
    ghosts := switchRestartsRound b s (h.cursor == 0),
    walker := b.walker0,
    carts := carts1,
    hud := h,
    tape := [],
    t := 0,
    heading := none,
    round := carts1 }

def step (b : Board) (s : World) : Act → World
  | .mv d   => moveStep b s d
  | .switch => switchStep b s

/-- 一关的开局：棋子在起点，车都在家，一个替身都没有，游标 0。 -/
def initWorld (b : Board) : World :=
  { me := b.start, ghosts := [], walker := b.walker0,
    carts := b.tracks.map (·.home), hud := ⟨b.slots, 0⟩,
    tape := [], t := 0, heading := none, round := b.tracks.map (·.home) }

end G50t
