/-
# ghosts_never_outnumber_slots —— **推论**（起点册子里的一条概念，这里证出来，不再每帧去测）

起点册子那条说：「看得见的替身永远不比已用掉的槽多」。在模型里它是更强的一句等式：

    替身个数 = 游标值，而且游标 < 槽数

**它不是一条独立的规则**：它是 `switchRestartsRound`（换一盘多一个替身、绕回时清空）
和 `hudCursorCycle`（游标 +1 模 n）两个定义一起推出来的，方向键一步两样都不碰。
撤册之后它不再面对语料；语料那一侧的读数是撤册前留下的（起点册子的 EVIDENCE：3 条）。
-/
import Obj.World
import Step

-- 定理放在根命名空间：装置的 lean_check 用裸名字 `#print axioms <名字>` 去查
open G50t

def slotsInv (s : World) : Prop := s.ghosts.length = s.hud.cursor ∧ s.hud.cursor < s.hud.n

theorem ghosts_match_slots (b : Board) (s : World) (a : Act) :
    slotsInv s → slotsInv (step b s a) := by
  intro ⟨hg, hc⟩
  cases a with
  | mv d =>
    refine ⟨?_, hc⟩
    simp [step, moveStep, hopAll, hg]
  | switch =>
    simp only [step, switchStep, slotsInv, hudCursorCycle, switchRestartsRound]
    have hn : 0 < s.hud.n := by omega
    refine ⟨?_, Nat.mod_lt _ hn⟩
    by_cases hw : (s.hud.cursor + 1) % s.hud.n = 0
    · simp [hw]
    · have hlt : s.hud.cursor + 1 < s.hud.n := by
        rcases Nat.lt_or_ge (s.hud.cursor + 1) s.hud.n with h | h
        · exact h
        · have : s.hud.cursor + 1 = s.hud.n := by omega
          rw [this, Nat.mod_self] at hw
          exact absurd rfl hw
      simp [Nat.mod_eq_of_lt hlt, hg]

#print axioms ghosts_match_slots
