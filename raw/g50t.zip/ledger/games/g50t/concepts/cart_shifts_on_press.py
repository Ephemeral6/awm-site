"""两种小车两种机关：非换枚的一步里，色 8 的小车是弹簧——它的按钮格从没活物到有活物就沿轨道朝按钮进 1 格、从有到没有就退 1 格；色 11 的小车按一下就沿轨道挪 1 格（朝按钮或背离按钮都见过），松开不动；其余情况都不动。**「活物」含那个自己会走的环，它压上按钮照样算按下。**"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4（ACTION5 另论，见 switch_rewinds_carts）；换关返回 NA；prev/nxt 的按钮集合对不上或场上没有小车返回 NA。"
         "apply 只认领「棋子自己一脚踩上一个还没被踩的按钮」这一种触发：棋子这一步的落点由 me+target+free 算得出，"
         "落在按钮上就一定有人，与幽灵无关；画旧格（整块变地板色，连轨道线一起消失）和新格（色 11 是通体实心 5×5；"
         "色 8 是通体轨道色、只在背离按钮那条边中间两格露牙，牙边由 path[1]→path[2] 定，算不出就只画旧格）。"
         "「幽灵踩出来的按」和「松开退回」两种 apply 都闭嘴：幽灵下一步落在哪是它自己那盘录像带定的，单帧 + 当前动作算不出——"
         "棋子从弹簧按钮上走开的那一步，也可能当场冒出一个新幽灵替它踩着（tid c5ce02d101a453ec），车根本不退。")
NOTE = ("v1 说所有小车都是弹簧，死于第 79 步：棋子从色 11 的按钮上走开，色 11 的小车留在原地。"
        "v2 反过来说所有小车都是棘轮，在自己的依据上就判错：第 13 步棋子从色 8 的按钮上走开，色 8 的小车退了 1 格。"
        "两条各自只对一种颜色成立，所以 v3 按颜色分开写。v2 的 NOTE 里那句「此前每一次松开都发生在 ACTION5」是没查语料就写的——第 13 步就是反例。"
        "v4 交出的是色 11 的**方向**：第 210 步一辆离按钮 2 格的色 11 小车被按下，它不是再进 1 格，而是退回了 3 格远的那个位置。"
        "所以「棘轮只进不退」错了，现在只敢说「按一下挪 1 格」。两个还分不开的读法："
        "(a) 色 11 只有两个位置，每按一下在两者之间翻转；(b) 它进到贴着按钮就弹回最远端。"
        "分开它们要一条长轨道：小车离按钮 ≥3 格时连按两次——(a) 说它回原位，(b) 说它继续进。"
        "还没分开的：色 8 的弹簧只在第 0/1 关见过，色 11 只在第 2/4 关见过；「按颜色」和「按关卡」在语料里仍是一回事。"
        "v5 只加 apply，不动主张：像素读法来自影子册 cart_apply（另一双眼睛在全量语料上摊开每一次「某辆车挪了」的旧格/新格逐格比出来的），"
        "在 13 条「棋子自己踩按钮」的转移上认领 650 格、说错 0 格。它同时报回两条："
        "一是幽灵这一步的挪动方向常常和当前动作的 DELTA 不一致（例 tid 0194f5aaba5fa803：动作 ACTION2，幽灵却往右挪），"
        "所以「幽灵踩的按钮」这条触发路径整条放弃；二是它照抄 v3 判据时撞上了 v4 这条反例——同一条证据两双眼睛各自撞到一次。"
        "留一个自己知道的不对称：apply 在色 11 被踩那一步只画 path[1]（朝按钮），而 assert_ 允许 {朝按钮, 背离按钮} 两格。"
        "apply 比检查器敢说一步，所以它画错时 assert_ 抓不到，只会在结算的「说错却判 TRUE」里露出来——那正是该看的地方。"
        "方向为什么定不下来，v5 之后在 switch_rewinds_carts 的 NOTE 里查清了：每辆车只有两个相邻格（关卡开局那格 home、"
        "和朝按钮走 1 步那格），色 11 每按一次在两格间翻一次。所以「朝按钮还是背离按钮」等价于「它此刻在 home 还是在近格」，"
        "而这一点帧上读不出来（两格离按钮多远随关卡变，8/9 格的也有）。apply 认领的那 13 次都是带子/关卡开头的第一次按，"
        "车正好在 home，所以次次朝按钮——赌赢的，不是读出来的。\n"
        "v6 只加一条实测，主张不动：此前所有轨道都只有 2 格，「按下那一个上升沿进 1 格」和「按住就一直往前走」"
        "在语料里是同一件事，分不开。新关卡给了 4 格长的轨道，于是拿一辆色 8 的车做了这件事——"
        "踩上按钮（车进 1 格），再连发三次撞墙的空动作（人不动、按钮一直踩着、不产生新的上升沿）。"
        "三步里车一格没挪。所以弹簧认的是**边沿**不是**电平**：按住不等于一路推到底，一次按下就只有 1 格。"
        "这一步也顺手把「弹簧只在第 0/1 关见过」那句话作废了——它在新关卡上照样成立，"
        "「按颜色分」和「按关卡分」终于不再是一回事。色 11 那边的 (a)/(b) 仍然没分开：那要的是"
        "同一个色 11 按钮在长轨道上连按两次，而这一关够得着的按钮里一个色 11 都没有。\n"
        "v7→v8 是被反例逼出来的，而这条反例正是我押的那一注：第 360 步那个色 14 的环走上一个色 11 的按钮格，"
        "车从 home 挪了 1 格，可 v7 判 FALSE——因为 `_lib.occupied` 当时只认棋子和幽灵，"
        "算出来 press=False、release=False，于是它要求车原地不动。所以主张要宽一格：**按钮认的是「格上盖着活物」，"
        "而那个环也是活物。** 修在词汇里（`occupied` 加上环），主张写在这句 docstring 里——"
        "词汇不打分，只有写成主张才会被后面每一条转移复核。\n"
        "这件事把「够得着的按钮里一个色 11 都没有」那句也作废了：我够不着，但那个环够得着，而它的节拍是我的步数"
        "（见 [[walker_steps_when_i_step]]）。第 361 步它从 (1,3) 走开，车留在原处不退——棘轮「松开不动」在色 11 的长轨道上又对了一次。\n"
        "v8 之后补一条实测，主张不动：v4 留下的 (a)/(b) 终于分开了。那两个读法是 (a) 色 11 只有两个位置、每按一下在两者之间翻转，"
        "(b) 它进到贴着按钮就弹回最远端；分开它们要的是「同一个色 11 按钮在长轨道上连按两次」。"
        "第 360 步那个环第一次踩下，车从 home 朝按钮进 1 格；第 366 步它第二次踩下同一个按钮，"
        "车**退回了 home**，没有继续朝按钮走。所以是 (a)：色 11 就在 home 和相邻那一格之间来回翻，"
        "轨道再长也只用这两格。这条实测是白捡的——按钮不是我踩的，是那个环替我按了两次，"
        "而 v4 当时写「这一关够得着的按钮里一个色 11 都没有，所以分不开」，错在把「我够得着」当成了「有人够得着」。")
EVIDENCE = ["2dafc257f319eafc", "27ef16fa5b3544fd", "1bae748fcb7f57d2", "7786f07037bbbbba", "0194f5aaba5fa803", "e7b63bda550a0ed1", "019a2f5f804790d8", "dafe0ff56ea9d494",
            "0c9e647f07f006f5", "406629e7e4093826", "6321e48fa048f4e7", "9ba87d8c8ca88931", "c5ce02d101a453ec",
            "fcef001bb505abd5", "e4ac5f321482360f", "dba0ef55155e66ed", "0e3f5f24ebcfa155",
            "4069e2eb200a9612"]

from _lib import CELL, DIRS, FLOOR_COLOR, PIECE, cart_states, free, me, target

SPRING, RATCHET = 8, 11
_OPP = {"U": "D", "D": "U", "L": "R", "R": "L"}


def _pairs(prev, nxt):
    a = {s["button"]: s for s in cart_states(prev)}
    b = {s["button"]: s for s in cart_states(nxt)}
    if set(a) != set(b) or not a:
        return None
    return [(a[k], b[k]) for k in a]


def _expected(s0, s1):
    """按颜色算 nxt 里小车允许出现在哪些格；算不出返回 None。"""
    p = s0["path"]
    if len(p) < 2:
        return None
    step = (p[1][0] - p[0][0], p[1][1] - p[0][1])
    fwd = p[1]
    back = (p[0][0] - step[0], p[0][1] - step[1])
    press = s1["pressed"] and not s0["pressed"]
    release = s0["pressed"] and not s1["pressed"]
    if press:
        return {fwd} if s0["color"] == SPRING else {fwd, back}
    if release and s0["color"] == SPRING:
        return {back}
    return {s0["cart"]}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "NA"
    pairs = _pairs(prev, nxt)
    if pairs is None:
        return "NA"
    for s0, s1 in pairs:
        if s0["color"] not in (SPRING, RATCHET):
            return "NA"
        want = _expected(s0, s1)
        if want is None:
            return "NA"
        if s1["cart"] not in want:
            return "FALSE"
    return "TRUE"


def _dir(a, b):
    dr, dc = b[0] - a[0], b[1] - a[1]
    for d, (ddr, ddc) in DIRS.items():
        if (ddr * CELL, ddc * CELL) == (dr, dc):
            return d
    return None


def _away_edge(path):
    """新格（= path[1]）该往哪条边露牙：牙在「继续朝按钮走」的反面；算不出（轨道太短或新格是转弯点）返回 None。"""
    if len(path) < 3:
        return None
    d_in, d_out = _dir(path[0], path[1]), _dir(path[1], path[2])
    if d_in != d_out or d_out is None:
        return None
    return _OPP[d_out]


def _spring_shape(edge):
    grid = [[SPRING] * PIECE for _ in range(PIECE)]
    if edge in ("U", "D"):
        r = 0 if edge == "U" else PIECE - 1
        for j in (1, 3):
            grid[r][j] = FLOOR_COLOR
    elif edge in ("L", "R"):
        c = 0 if edge == "L" else PIECE - 1
        for i in (1, 3):
            grid[i][c] = FLOOR_COLOR
    else:
        return None
    return grid


def _paint(out, tl, grid):
    for i in range(PIECE):
        for j in range(PIECE):
            out[(tl[0] + i, tl[1] + j)] = grid[i][j]


def apply(prev, action, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return None
    a = me(prev)
    if a is None:
        return None
    t = target(a, action)
    if t is None or not free(prev, t):
        return None
    out = {}
    for s in cart_states(prev):
        if s["color"] not in (SPRING, RATCHET) or s["pressed"] or s["button"] != t:
            continue                      # 只认棋子这一步亲自踩上的、原先没人踩的按钮
        p = s["path"]
        if len(p) < 2:
            continue
        _paint(out, s["cart"], [[FLOOR_COLOR] * PIECE for _ in range(PIECE)])
        if s["color"] == RATCHET:
            _paint(out, p[1], [[RATCHET] * PIECE for _ in range(PIECE)])
        else:
            edge = _away_edge(p)
            if edge is not None:
                _paint(out, p[1], _spring_shape(edge))
    return out or None
