"""这一步没有任何一辆小车挪动过，那个色 14 的环就不会从帧上消失——被挡住不致命，只有动着的车才杀得死它。"""
LEVEL = "L6"
SCOPE = ("看全部动作；换关返回 NA；prev 里没有（或有不止一个）色 14 的环返回 NA；"
         "prev→nxt 之间任何一辆小车挪了位置就返回 NA（那一步交给 walker_walks_alone）。"
         "不带 apply：它下一步往哪走单帧算不出来。")
NOTE = ("由来：第 322 步那个环整个消失，同一步有一辆弹簧车正弹回它要去的那一格——"
        "但那条转移分不开两件事：「它挪进去之后被车压死」和「它被车挡住、当场就没命」。"
        "两种读法给出的打法完全相反：前者只要把车挪开的时机排对就行，后者意味着它一撞上挡路的东西就没了、"
        "这一关的时序窗口只有一步宽。\n"
        "第 332~333 步把它们分开了：环停在 (1,8)，它要去的那一格停着一辆纹丝没动的小车，全场零帧差"
        "（只有计数条跳了一格），环还在。所以**被挡住 = 原地等着**，它会一直等到我把路让开。"
        "这条一成立，这一关就从「一步宽的时序窗口」变成「我慢慢来，它等着」。\n"
        "写成「没有车动过就不会消失」而不是「被挡住会等」，是因为「它下一格是哪一格」单帧读不出来"
        "（walker_walks_alone 的 v1 正是死在这上面）：挡没挡住我判不了，有没有车在动我判得了。"
        "代价是它对「车在动」的那些步一律闭嘴——那一半留给 walker_walks_alone 的消失条款。")
EVIDENCE = ["6484be2c2277ac68", "e39ca270af1a51eb", "10f5f3df27a0e89c", "318b647f5a416482"]

from _lib import cart_states, walker


def _fleet(g):
    return sorted((s["cart"], s["color"]) for s in cart_states(g))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if walker(prev) is None:
        return "NA"
    if _fleet(prev) != _fleet(nxt):
        return "NA"
    return "TRUE" if walker(nxt) is not None else "FALSE"
