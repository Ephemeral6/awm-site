"""ACTION1..4 让棋子移动 iff 目标 5×5 区整块在场地 bbox 内、不含色 0、且其中的轨道色都落在居中 3×3（按钮）或中心十字（轨道线）上；否则棋子原地不动。目标格是传送门时另论（portal_teleport）。"""
LEVEL = "L2"
SCOPE = "只看 ACTION1..4；换关返回 NA；me() 定位不到返回 NA；目标格是传送门（portal_color 非 None）返回 NA、apply 闭嘴。apply 只填棋子旧区与新区两块共 50 格（旧区还原成地板，新区画成带孔的棋子）；目标区是终点格时 apply 闭嘴——那一步整屏重画，这条概念生成不了；旧区是轨道尽头格（按钮）、或旧区底下压着看不见的幽灵、或目标格上站着幽灵（可能和它换位）时，apply 只画新区那 25 格"
NOTE = ("v2：v1 只把 0 当墙，被走进小车格（8 旗形）帧不变的转移推翻；按钮 8（3×3 居中）实测可踩，幽灵 2 实测可穿。"
        "v3：轨道线上的 8 可穿，小车形状的 8 不可穿。"
        "v4 只改 apply：走进终点格那一步会整屏重画，旧版 apply 照画 50 格，等于用一条 L2 的概念去预测一件 L5 的事；"
        "assert_ 本来就在换关处返回 NA，现在让生成器也一起闭嘴——口径对齐，别让检查器说不知道、生成器却在瞎画。"
        "v5：第 3 关走进传送门格（7×7 同色边框套着的格）棋子落在别处，这条只管普通格，传送门那一步交给 portal_teleport。"
        "v6 只改 apply：第 177 步从轨道尽头格（按钮）走开，把旧区全画成地板错了 10 格——底下压着按钮，"
        "而棋子站着时中心孔露的是地板色，prev 里读不出来。旧区是尽头格时这条闭嘴，那一格交给 button_shape_at_rail_end。"
        "v7 只改 apply：第 18 步从一格走开，露出来的是幽灵（24 格），错在幽灵藏在棋子底下看不见。"
        "能算出来的是『看得见的幽灵比游标指着的替身序号少』——少了就说明有幽灵被盖着，那时旧区一律闭嘴。"
        "（v6 用 cart_states 认尽头格，漏掉第 3 关那条没有小车的轨道；改用词汇 rail_dead_ends，按出入口数认。）"
        "v8 只改 apply：第 224 步我走进一个**站着幽灵**的格子，那个幽灵同一拍走进了我刚腾出来的格子——"
        "我们换了位。apply 把旧区画成地板，错 24 格（幽灵那一圈；中心孔透出来的还是地板色，所以错的是 24 不是 25）。"
        "**错的不是「我去哪」，是「我走了以后那一格归谁」**：腾出来的格子不一定是空的，"
        "同一拍别的东西可以搬进来，而那是 [[ghost_follows_me]] 管的事，这条 L2 的概念算不出来。"
        "所以目标格上站着幽灵时，旧区不主张。为什么只挡这一种：全局语料 653 条里 apply 开口 597 次，"
        "画错的只有这一次，而「走进幽灵格」总共只发生过两次（另一次第 17 步，幽灵那一拍走开了，旧区侥幸画对）。"
        "**没挡住的残余风险写在这里**：幽灵从别的方向搬进我腾出的格子，同样会打脸，只是语料里还没发生过；"
        "真要挡干净得先知道幽灵下一拍去哪，那就不是这条概念了。")
EVIDENCE = ["b19bf4ec67244c44", "4d52d389c36ad889", "29a43bd35dbe6b35", "7614e277022cc74b", "eb5465c19e3567a7", "4b3c02d0f59043c2", "27ef16fa5b3544fd", "066d312159d35991", "f0cb844c2d374c9e", "5863c45421a432c2", "383d307a1441bb7c", "a4cd0ed377e3f740", "ab030b2e3fd507c6"]

from _lib import me, target, free, goal_cell, portal_color, ghosts, hud_cursor, rail_dead_ends, PIECE, ME_COLOR, FLOOR_COLOR


def _moves(prev, action):
    a = me(prev)
    if a is None:
        return None, None, None
    t = target(a, action)
    return a, t, free(prev, t)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "NA"
    a, t, ok = _moves(prev, action)
    b = me(nxt)
    if a is None or b is None:
        return "NA"
    if portal_color(prev, t) is not None:
        return "NA"
    expect = t if ok else a
    return "TRUE" if b == expect else "FALSE"


def apply(prev, action, ctx=None):
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return None
    a, t, ok = _moves(prev, action)
    if a is None:
        return None
    if ok and t == goal_cell(prev):
        return None
    if portal_color(prev, t) is not None:
        return None
    out = {}
    if not ok:
        for i in range(PIECE):
            for j in range(PIECE):
                out[(a[0] + i, a[1] + j)] = prev[a[0] + i][a[1] + j]
        return out
    for i in range(PIECE):
        for j in range(PIECE):
            out[(a[0] + i, a[1] + j)] = FLOOR_COLOR
    k = hud_cursor(prev)
    if ((k is not None and len(ghosts(prev)) < k)
            or any(tl == a for tl, _, _ in rail_dead_ends(prev))
            or t in ghosts(prev)):
        out = {}          # 旧区归谁这条算不出来：底下压着按钮、压着看不见的幽灵，
                          # 或者目标格那个幽灵同一拍搬进来跟我换了位。只画新区。
    for i in range(PIECE):
        for j in range(PIECE):
            out[(t[0] + i, t[1] + j)] = FLOOR_COLOR if (i, j) == (2, 2) else ME_COLOR
    return out
