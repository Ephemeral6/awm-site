"""走进一个传送门格那一步，同色按钮**在这一步里从没人踩变成有人踩**（上升沿）时棋子才被传到同色的另一扇门；按钮原本就被踩着（一直按住）或整步没人踩，棋子就停在走进的那格里。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；换关返回 NA；目标格不是传送门、或目标格不可进（free 为假）返回 NA；"
         "同色传送门不恰好两个返回 NA；me() 定位不到返回 NA。"
         "「踩没踩着」用 pressed_colors 读，它现在从轨道尽头格认按钮，所以盖在棋子/幽灵底下的按钮也数得进来。"
         "apply 只认领**按钮在 prev 里就已经被踩着**那一种：那时这一步不可能有上升沿，棋子一定是普通地走进门里，"
         "画两块（旧区腾空、门那格画成带孔的棋子）；旧区底下压着东西（尽头格的按钮、藏在棋子底下的幽灵）时旧区那块闭嘴。"
         "上升沿那一种 apply 闭嘴：谁会在这一步踩上按钮，单帧算不出。")
NOTE = ("v1 的依据只有一条，而且按钮是幽灵在同一步踩上的，所以「按住才传」和「本来就传」分不开。"
        "v2 押大的：进门就传、按钮无关——**第 188 步当场被判错**：第 4 关一对没人碰过的色 15 门，"
        "棋子走进 (6,7) 就停在门里，对面那格一格没变（预测错 24 格）。所以按钮是传送的必要条件，这是这一条 v2→v3 的内容，"
        "而它是用一次落空换来的：没有 v2 那一押，v1 会一直在这一步返回 NA，看上去毫发无损。\n"
        "v3 死在第 268 步：色 15 的按钮被一个停住的幽灵**踩了两步**，我照 v3 走进门，一格没传，"
        "预测错 24 格（押对面那格出现棋子，实际那里还是地板）。三条语料摆在一起，读法只剩一种：\n"
        "  第 166 步（第 3 关）prev 没人踩、nxt 有人踩（一个幽灵那一步正好落到按钮上）→ 传了；\n"
        "  第 188 步 前后都没人踩 → 没传；\n"
        "  第 268 步 前后都踩着（幽灵停在上面不动）→ 没传。\n"
        "所以门认的是**这一步之内的上升沿**，不是「按住」——和这一局的色 11 小车一样，按钮在这个世界里是脉冲触发的，"
        "不是开关。v3 那句「那一步结束时按钮被踩着」在三条语料上都成立，但它把 268 这种「本来就踩着」也算了进去，"
        "这才是它多出来的、错的那一半。\n"
        "还分不开的两种读法：(a) 门只在踩下的**那一步**通（我押的是这个，第 166 步是同一步内发生的）；"
        "(b) 踩下之后门开着若干步、而 268 步那次是因为开过头已经关了。分开它们要一次「第 t 步有人踩上按钮、第 t+1 步我才进门」的实验。\n"
        "这条也是 _lib 里 pressed_colors 修好之后才说得出话的：它原先用 buttons() 找按钮，而按钮的 3×3 一被踩就整块盖住，"
        "看得见的按钮按定义都没人踩，于是这个词在任何一帧上都返回空集——这条概念 100% 的 NA 率不是没遇上机会，是眼睛闭着。"
        "代价直接写在这一局的路线上：第 4 关第三盘带子我特意把进门推迟两步「不赌同一步内的先后」，"
        "而正确的打法恰恰相反——要和踩下那一步撞在一起。")
EVIDENCE = ["f0cb844c2d374c9e", "191730b8ebdd5e54", "5fd3fe83f1ed27fe"]

from _lib import (FLOOR_COLOR, ME_COLOR, PIECE, free, ghosts, hud_cursor, me, portal_color,
                  portals, pressed_colors, rail_dead_ends, target)

MOVES = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _pair(g, action):
    """(走开的格, 门的对面那格, 门色)；不是走进传送门返回 (None, None, None)。"""
    a = me(g)
    if a is None:
        return None, None, None
    t = target(a, action)
    c = portal_color(g, t)
    if c is None or not free(g, t):
        return None, None, None
    same = [p for p, col in portals(g) if col == c]
    if len(same) != 2:
        return None, None, None
    return a, (same[0] if same[1] == t else same[1]), c


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in MOVES:
        return "NA"
    a, other, c = _pair(prev, action)
    b = me(nxt)
    if a is None or b is None:
        return "NA"
    rising = c not in pressed_colors(prev) and c in pressed_colors(nxt)
    return "TRUE" if b == (other if rising else target(a, action)) else "FALSE"


def apply(prev, action, ctx=None):
    if action not in MOVES:
        return None
    a, other, c = _pair(prev, action)
    if a is None or c not in pressed_colors(prev):
        return None                      # 只画「按住着进门」那一种：这一步不会有上升沿，门不通
    t = target(a, action)
    out = {}
    k = hud_cursor(prev)
    hidden = k is not None and len(ghosts(prev)) < k
    if not hidden and not any(tl == a for tl, _, _ in rail_dead_ends(prev)):
        for i in range(PIECE):
            for j in range(PIECE):
                out[(a[0] + i, a[1] + j)] = FLOOR_COLOR
    for i in range(PIECE):
        for j in range(PIECE):
            out[(t[0] + i, t[1] + j)] = FLOOR_COLOR if (i, j) == (2, 2) else ME_COLOR
    return out
