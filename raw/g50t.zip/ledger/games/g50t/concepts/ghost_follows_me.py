"""幽灵（色 2 的 5×5 带孔块）只跟着棋子的有效移动走：棋子这一步没挪窝，可见幽灵集合一格不变；棋子挪了窝，prev 里的每个幽灵在 nxt 里要么原地、要么恰好平移一个 DELTA、要么走进了一步之内的某扇传送门而落在同色的另一扇上——除非它落在棋子新位置上被盖住（幽灵可增：新幽灵是又一盘录像带开播）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4（ACTION5 换枚会清场，另论）；换关返回 NA；me() 定位不到返回 NA；"
         "某个幽灵一步之内有传送门而那扇门的同色伙伴不恰好是一扇时返回 NA（配不出对，落点就算不出）。"
         "不带 apply：新幽灵出现在哪一格要靠录像带，单帧算不出")
NOTE = ("v1 漏了遮挡：第 17 步棋子走进幽灵所在格，幽灵的 2 环被 9 环整块盖掉，ghosts(nxt) 空了一个；"
        "第 18 步棋子走开它又原样露出来。所以「幽灵消失」不等于「幽灵没了」——棋子新位置那一格是盲点。\n"
        "第 472~476 步量到两件这条断言不出、但整关路线全靠它的事，记在这里：\n"
        "  1) 幽灵是从**本关起点格**重放**动作串**的，不是重放我走过的坐标——那盘带子录的是「下、下、左」，"
        "换枚之后它从起点格走出 (5,4)→(6,4)→(6,3)，和我录的时候走的是同一串动作。\n"
        "  2) **带子放完之后它永久停在最后那一格，而且一直算「踩着」**：它停在色 11 的按钮格上，"
        "此后每一步 cart_states 都报 pressed=True，闩车不再翻（没有新的上升沿）。"
        "本关要一个替身一直按住一个按钮、好让另一个替身从那扇门过去，靠的就是这一条。\n"
        "两条都进不了断言：带子多长、带子里第几个动作，都是隐藏状态，单条转移看不见——"
        "这条概念只管得住「每个幽灵每步至多平移一个 DELTA」，而「原地不动」本来就在它允许的范围里。"
        "所以这两条是拿最后那一张终局卡去赌的：赌输了，卡上当场停。\n"
        "v3：第 495 步判 FALSE，而这条反例是我自己在同一张押注里同时押下的两句互相矛盾的话——"
        "一句押「那个幽灵这一拍会走进传送门、落在 (2,2)」，另一句押「这一批没有概念会因为幽灵判错」。"
        "两句不可能同真：幽灵从 (4,3) 一步到 (2,2) 跨了三格，v2 的「至多平移一个 DELTA」必然被打。"
        "装置替我挑出了矛盾的那一半。**幽灵和棋子一样过得了传送门**，这是整关三替身路线的最后一个未知量，"
        "值得写进主张而不是缩成 NA：落点集合加上「它一步之内那些传送门的同色伙伴」。\n"
        "教训（方法，不是世界事实）：一条押注里并列的几句话要自己先对一遍，"
        "「我预测世界会做 X」和「册子一条都不会被打」常常是同一件事的两面——世界做了册子没见过的事，册子就该被打。"
        "押注落空不等于判断错；这一注主要的那半句赢了，输的是那句顺手加上的「一切照旧」。")
EVIDENCE = ["4d52d389c36ad889", "7614e277022cc74b", "eb5465c19e3567a7", "0194f5aaba5fa803", "066d312159d35991",
            "c0853c403fdd42c2"]

from _lib import me, ghosts, DELTA, portals

_SHIFTS = [(0, 0)] + list(DELTA.values())


def _partner(g, tl, color):
    """同色传送门恰好另有一扇时返回它，否则 None。"""
    same = [p for p, c in portals(g) if c == color and p != tl]
    return same[0] if len(same) == 1 else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    g0, g1 = set(ghosts(prev)), set(ghosts(nxt))
    if a == b:
        return "TRUE" if g0 == g1 else "FALSE"
    door = {p: c for p, c in portals(prev)}
    for p in g0:
        landing = [(p[0] + d[0], p[1] + d[1]) for d in _SHIFTS]
        for q in list(landing):
            if q in door:
                far = _partner(prev, q, door[q])
                if far is None:
                    return "NA"
                landing.append(far)
        if not any(q in g1 or q == b for q in landing):
            return "FALSE"
    return "TRUE"
