"""ACTION1..4 之后棋子要么恰好平移 DELTA[action]（上/下/左/右各 6 格），要么原地不动；目标格是传送门时另论（portal_teleport）。"""
LEVEL = "L1"
SCOPE = "只看 ACTION1..4；换关返回 NA；me() 在 prev 或 nxt 定位不到返回 NA；目标格是传送门（portal_color 非 None）返回 NA"
NOTE = ("v2：第 3 关走进一个 7×7 同色边框套着的格，棋子出现在同色的另一个边框格里——既不是平移 6 也不是不动。"
        "平移这条只管普通格，传送门那一步交给 portal_teleport。")
EVIDENCE = ["b19bf4ec67244c44", "4d52d389c36ad889", "29a43bd35dbe6b35", "7614e277022cc74b", "f0cb844c2d374c9e"]

from _lib import me, target, portal_color, PIECE


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "NA"
    a, b = me(prev), me(nxt)
    if a is None or b is None:
        return "NA"
    t = target(a, action)
    if portal_color(prev, t) is not None:
        return "NA"
    return "TRUE" if b == a or b == t else "FALSE"
