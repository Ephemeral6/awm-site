"""换枚（ACTION5）那一步之后场上一个幽灵都看不见：所有幽灵被收回本关起点格、压在新棋子底下，下一步才各自从头回放；prev 里有那个色 14 的环时 nxt 里它还在（它也被放回本关起点格，见 NOTE）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION5；换关返回 NA；me(nxt) 定位不到返回 NA。prev 里没有环（或不止一个）时环那一句不主张。"
         "不带 apply（起点格单帧读不出来，画不出棋子落点）")
NOTE = ("语料里第 1 关第二次换枚之后，前两枚的幽灵在下一步同时出现在离起点 1 格的两个位置——不是只有最新那枚在回放，"
        "是全部录像并行从头放。这一条只断言换枚那一帧的「看不见」，回放的并行性由 ghost_follows_me 逐步管。\n"
        "v2：第 471 步量到换枚也把那个色 14 的环放回本关起点格——它从 (9,0) 一步回到 (9,3)，"
        "和 RESET 那一步（第 467 步，(7,0)→(9,3)）的落点是同一格；[[walker_walks_alone]] 的「一步至多一格」被它打了，"
        "改的是那条的 scope。为什么这一格值得单独写进来：**换枚把棋子、幽灵、环三样一起放回开局相位**，"
        "于是每一盘录像带都是从同一个相位开始录的——录带子时环第几步走到哪一格，最后一遍放的时候它还在那一格。"
        "本关要三个替身同一拍分别踩住三个按钮，这一条就是时刻表能排得出来的前提。"
        "「回到起点格」进不了断言（开局那一帧不在单条转移里，和 [[reset_clears_the_level]] 同一个限制），"
        "这里只断言可判错的那一半：换枚之后环还在场上。")
EVIDENCE = ["95ffa56005ec2f95", "49fdde45fee8e15c", "e7b63bda550a0ed1", "b59c529599b0ddd1",
            "966d4a556fea3558"]

from _lib import me, ghosts, walker


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != "ACTION5":
        return "NA"
    if me(nxt) is None:
        return "NA"
    if ghosts(nxt):
        return "FALSE"
    if walker(prev) is not None and walker(nxt) is None:
        return "FALSE"
    return "TRUE"
