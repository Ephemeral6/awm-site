"""走进终点格就过关：终点格 = 场上那个「5×5 只有中心像素是 9、其余全是地板，且四周边框围了一圈 9（左侧留开口）」的格；棋子这一步的目标区正是它且可进 ⇒ 关卡 +1（整屏重画）；否则关卡不变。"""
LEVEL = "L5"
SCOPE = "看全部动作（ACTION5 不指向终点，按「不进 ⇒ 不过关」判）；prev 里找不到唯一终点格返回 NA；me() 定位不到返回 NA；ctx 缺关卡号返回 NA。不带 apply：过关那一帧整屏重画，册子生成不了"
NOTE = ""
EVIDENCE = ["6ab23b681713daa2", "7587265a9a814f56", "95ffa56005ec2f95"]

from _lib import me, target, free, goal_cell


def entering_goal(prev, action):
    """这一步的目标区是不是终点格且可进。"""
    gc = goal_cell(prev)
    a = me(prev)
    if gc is None or a is None:
        return None
    t = target(a, action)
    if t is None:
        return False
    return t == gc and free(prev, t)


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") is None or ctx.get("level_next") is None:
        return "NA"
    hit = entering_goal(prev, action)
    if hit is None:
        return "NA"
    want = ctx["level_prev"] + 1 if hit else ctx["level_prev"]
    return "TRUE" if ctx["level_next"] == want else "FALSE"
