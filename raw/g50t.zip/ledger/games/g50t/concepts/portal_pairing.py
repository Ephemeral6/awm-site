"""同色传送门按**轨道网络**配对：把一种轨道色的像素 4-连通连成网，一张网上恰好两扇同色门时它们互为搭档，而且只有**这张网上**的按钮在这一步被踩出上升沿（prev 里露着且没人踩、nxt 里有人踩），走进其中一扇才会被送到另一扇；别的网上的按钮踩出上升沿，这一对门不动。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1..4；换关返回 NA；目标格不是传送门、或目标格不可进（free 为假）返回 NA；"
         "me() 在 prev 或 nxt 里定位不到返回 NA；"
         "目标门所在的那张轨道网上，除它以外的同色门不恰好一扇（零扇或两扇以上）返回 NA——"
         "活物的 5×5 会盖住轨道把一张网切断，这种局面下网络读不准，宁可闭嘴。"
         "上升沿只认**两帧读法**：按钮格在 prev 帧里露着（buttons 或 rail_dead_ends 认得出）、prev 无人踩、nxt 有人踩；"
         "按住不放、整步没人踩、或踩的是别的网上的按钮，都不算触发。")
NOTE = ("v2。v1 被第 464 步 (tid 13e9330917c43ad8) 判 FALSE 推翻，两处读法同时错，一并换掉：\n"
        "（一）**配对规则错**。v1 用竖井几何（同行/列、隔两格、中间格不可进）配对，那是从第166/309步两次真实传送"
        "反推的 n=2 规则。第 464 步真实传送 (4,2)→(2,2) 竖井规则也答对了，但第 445 步把它打死了："
        "那一步环踩出了色 15 的上升沿，我走进门 (6,8)，竖井规则说搭档是 (8,8)，结果没传，我留在 (6,8)。"
        "改用轨道网络之后这一行自洽了：色 15 在本关有两张互不相连的网，"
        "一张带按钮 (0,8) 和门 (6,8)/(8,8)，另一张带按钮 (4,0) 和门 (2,2)/(4,2)；环踩的 (4,0) 只开它自己那一对。"
        "语料里九次走进门的转移，轨道网络读法全部答对，不需要动用入门方向。\n"
        "（二）**上升沿读法错**。v1 用单帧 `pressed_colors` 读踩没踩。它对被盖住的角落按钮是双盲的："
        "`buttons()` 认形状，按钮的 3×3 被 5×5 活物盖住就整个消失；`rail_dead_ends()` 只收恰好一个轨道出口的格，"
        "而 (4,0) 是两个出口的拐角，本来就不收。于是第 464 步环站上 (4,0) 时 `pressed_colors` 两帧都读空，"
        "v1 只能判「不触发」，而世界传送了。改成两帧读法：按钮在 prev 里还露着的时候记下它，nxt 里被占了就是上升沿。\n"
        "（三）沿路被推翻、留在这里不删的两条：一是「(4,0) 不是按钮，只是形状像」——第 464 步证伪，它是真按钮，"
        "环踩它开了 (2,2)/(4,2)；二是「垂直于竖井轴入门不传送、顺着轴才传送」——n=1 的临时解释，"
        "第 464 步同样是垂直入门却传送了，轨道网络读法把它整条替掉。\n"
        "旧概念 portal_teleport（v4）没动：它的 scope 限死在同色门恰好两扇的关卡，那里两张网各只有一张，"
        "单帧读法碰巧够用；但它那句「踩没踩用 pressed_colors 读」在本关是不成立的，别往外推。\n"
        "EVIDENCE 里第166/309/464步是三次真实传送，第188/268/393/409/435/445步是「没触发、留在原地」；"
        "第268步和第309步是一对对照（同一扇门 (6,7)、同一个动作、同一个出发格）：268 是按住不放没传，309 是上升沿传了，"
        "「要上升沿不要按住」这一半就是从这一对逼出来的。")
EVIDENCE = ["f0cb844c2d374c9e", "191730b8ebdd5e54", "5fd3fe83f1ed27fe", "34b9d8530f996002",
            "d3bede0d00d18409", "77364eed816a90a1", "6aaa8ddd04769ae5",
            "f873662dca94686a", "13e9330917c43ad8"]

from _lib import (FLOOR_COLOR, ME_COLOR, PIECE, buttons, free, ghosts, hud_cursor, me, occupied,
                  portal_color, portals, rail_dead_ends, target)

MOVES = ("ACTION1", "ACTION2", "ACTION3", "ACTION4")


def _ring(tl):
    """一格的 7×7 外圈像素坐标：门的边框画在这一圈上，轨道从这一圈接出去。"""
    lo0, hi0, lo1, hi1 = tl[0] - 1, tl[0] + PIECE, tl[1] - 1, tl[1] + PIECE
    return [(r, c) for r in range(lo0, hi0 + 1) for c in range(lo1, hi1 + 1)
            if r in (lo0, hi0) or c in (lo1, hi1)]


def _block(tl):
    """一格的 5×5 内部像素坐标：按钮的 3×3 落在这里面。"""
    return [(tl[0] + i, tl[1] + j) for i in range(PIECE) for j in range(PIECE)]


def _net(g, tl, color):
    """tl 这扇门所在的轨道网：从门的外圈上的同色像素起，在同色像素上 4-连通洪水填充。"""
    H, W = len(g), len(g[0])
    pix = {(r, c) for r in range(H) for c in range(W) if g[r][c] == color}
    stack = [p for p in _ring(tl) if p in pix]
    seen = set(stack)
    while stack:
        r, c = stack.pop()
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (r + dr, c + dc)
            if n in pix and n not in seen:
                seen.add(n)
                stack.append(n)
    return seen


def _partner(g, tl, color):
    """同一张网上除 tl 以外的同色门；不恰好一扇返回 None。"""
    net = _net(g, tl, color)
    if not net:
        return None
    others = [p for p, c in portals(g)
              if c == color and p != tl and any(q in net for q in _ring(p))]
    return others[0] if len(others) == 1 else None


def _fired(prev, nxt, tl, color):
    """这张网上有按钮被踩出上升沿：prev 里露着且没人踩、nxt 里有人踩。"""
    net = _net(prev, tl, color)
    seen = list(buttons(prev)) + [(p, c) for p, c, _ in rail_dead_ends(prev)]
    for p, c in seen:
        if c != color or not any(q in net for q in _block(p)):
            continue
        if not occupied(prev, p) and occupied(nxt, p):
            return True
    return False


def _pair(g, action):
    """(走开的格, 目标门格, 搭档门格, 门色)；不是走进可进的传送门、或搭档定不出，返回四个 None。"""
    a = me(g)
    if a is None:
        return None, None, None, None
    t = target(a, action)
    c = portal_color(g, t)
    if c is None or not free(g, t):
        return None, None, None, None
    other = _partner(g, t, c)
    if other is None:
        return None, None, None, None
    return a, t, other, c


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in MOVES:
        return "NA"
    a, t, other, c = _pair(prev, action)
    b = me(nxt)
    if a is None or b is None:
        return "NA"
    return "TRUE" if b == (other if _fired(prev, nxt, t, c) else t) else "FALSE"


def apply(prev, action, ctx=None):
    """只画「这一步不会有上升沿」的那一种：网上的按钮在 prev 里已经被踩住了，门不通，人进门格。

    上升沿要两帧才读得出，apply 只有 prev，所以敢画的只有「按住不放」这一半；
    prev 里网上按钮没人踩时，下一帧可能有人踩上去（传送）也可能没有，闭嘴。
    """
    if action not in MOVES:
        return None
    a, t, other, c = _pair(prev, action)
    if a is None:
        return None
    net = _net(prev, t, c)
    seen = list(buttons(prev)) + [(p, cc) for p, cc, _ in rail_dead_ends(prev)]
    held = [p for p, cc in seen
            if cc == c and any(q in net for q in _block(p)) and occupied(prev, p)]
    if not held:
        return None
    out = {}
    k = hud_cursor(prev)
    hidden = k is not None and len(ghosts(prev)) < k
    if not hidden and not any(p == a for p, _, _ in rail_dead_ends(prev)):
        for i in range(PIECE):
            for j in range(PIECE):
                out[(a[0] + i, a[1] + j)] = FLOOR_COLOR
    for i in range(PIECE):
        for j in range(PIECE):
            out[(t[0] + i, t[1] + j)] = FLOOR_COLOR if (i, j) == (2, 2) else ME_COLOR
    return out
