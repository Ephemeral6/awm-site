"""RESET 那一步把本关清干净：场上一个幽灵都不剩，每辆小车最多沿自己的轨道挪 1 格（它回的是这一关开局那一格，见 NOTE），prev 里有那个色 14 的环时 nxt 里它还在。"""
LEVEL = "L5"
SCOPE = ("只看 action == 'RESET'，别的动作返回 NA；"
         "prev 或 nxt 读不出棋子、或读不出格网原点时返回 NA（那不是一张场地帧）；"
         "ctx 说这一步跨了关（level_prev != level_next）时返回 NA——那不是「清干净本关」；"
         "prev/nxt 的按钮集合对不上、或场上没有小车时只判幽灵那一半。"
         "prev 里没有环（或不止一个）时环那一句不主张。"
         "不带 apply：整屏重画，这条生成不了。"
         "「回到开局那一格」不在断言里——开局那一帧不在 (prev, action, nxt) 里，见 NOTE。")
NOTE = ("由来：第 268 步我用 RESET 换一整条计数条，顺手把这一关的局面读了个遍——"
        "棋子回起点格、幽灵清零、HUD 三个槽全新、计数条满、三辆小车各挪了 1 格。"
        "前四件分别归 hud_cursor_cycle 和 bar_cost 管，这一条管幽灵和小车。\n"
        "我真正在用的模型比这条断言强：**RESET 让每辆小车回到它这一关开局那一格（home）**。"
        "它进不了断言，因为「开局那一格」要翻这一关的第一帧，assert_ 只看得见一步。"
        "但它在这一步上兑现过一次，而且兑现得很贵：色 11 的 2 号车这一关开局在 (4,6)，"
        "我此前一直看见它在 (4,5)，就以为 (4,6) 天然是空的——RESET 一按，它回到 (4,6) 把路堵上，"
        "整条路线得重排。**「我一直看见的位置」不等于「它的 home」**，这是这一条留下的教训。\n"
        "还不知道的：RESET 之后重放的带子还在不在（HUD 说槽全新，等于带子没了）；"
        "RESET 算不算「换关」（关卡号没变，所以 bar_cost 和 hud_cursor_cycle 都得为它单开一支）。\n"
        "v2：第 467 步的 RESET 把那个色 14 的环从 (7,0) 送回 (9,3)，跨了五格——[[walker_walks_alone]] 的"
        "「一步至多一格」当场判 FALSE，而错的是那条的 scope：环回的也是 home，和小车同一件事。"
        "所以环从那条出 scope、进这一条。这里只敢断言**它还在场上**：位置同样要翻这一关第一帧，断言看不见。"
        "为什么这半句值得写：我要用的三个替身里有一个得靠这个环替我踩按钮，"
        "RESET 一按它就没了的话，整条路线不成立——这是一句**路线依赖的、能被判错的**话。\n"
        "v3：换终局卡那一步也记成 RESET，而它的 prev 是「全通关」那张庆祝画面——上面没有格网、"
        "没有棋子，原点读不出来，于是词汇表把庆祝图案读成了 26 辆车和 2 个幽灵，"
        "环那一句在垃圾读数上判 FALSE（prev「有环」、nxt 没有）。**错的不是主张，是两条没写出来的前提**："
        "一、prev 得是一张读得出格网和棋子的场地帧；二、RESET 得落回同一关。"
        "这两条都破了还硬判，等于拿词汇崩掉的读数当证据。两条都写进 scope，判 NA。"
        "教训和 [[walker_walks_alone]] 那次同源：连续性主张只对**世界自己往前走**的那种步成立，"
        "整屏重建的那种步要先划出去——这一次连「屏上还是不是这个世界」都得先问一句。")
EVIDENCE = ["694451c614edcf16", "df245505d3d9d2bb", "4a12ad47fae4120d"]

from _lib import cart_states, ghosts, me, origin, walker

MAX_SHIFT = 1


def _pairs(prev, nxt):
    a = {s["button"]: s for s in cart_states(prev)}
    b = {s["button"]: s for s in cart_states(nxt)}
    if set(a) != set(b) or not a:
        return None
    return [(a[k], b[k]) for k in a]


def assert_(prev, action, nxt, ctx=None):
    if action != "RESET":
        return "NA"
    # 前提一：两头都得是读得出格网和棋子的场地帧。庆祝画面上没有格网，
    # 词汇表会把画面上的图案读成一堆车和幽灵——在那种读数上判对错，判的是词汇不是世界。
    for g in (prev, nxt):
        if origin(g) is None or me(g) is None:
            return "NA"
    # 前提二：RESET 得落回同一关。跨关的那一下不是「把本关清干净」，是换了一整个场地。
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ghosts(nxt):
        return "FALSE"
    if walker(prev) is not None and walker(nxt) is None:
        return "FALSE"
    pairs = _pairs(prev, nxt)
    if pairs is None:
        return "TRUE"
    for s0, s1 in pairs:
        p = s0["path"]
        if len(p) < 2:
            continue
        step = (p[1][0] - p[0][0], p[1][1] - p[0][1])
        ok = {s0["cart"],
              (s0["cart"][0] + step[0], s0["cart"][1] + step[1]),
              (s0["cart"][0] - step[0], s0["cart"][1] - step[1])}
        if s1["cart"] not in ok:
            return "FALSE"
    return "TRUE"
