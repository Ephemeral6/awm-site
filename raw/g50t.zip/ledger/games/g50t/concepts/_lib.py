"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测（L0/L1）：
    棋子 = 24 格色 9 的 5×5 带中心孔的块；步长 6（5 格块 + 1 格缝）。
    场地 = 色 5 的那片区域；棋子只在场地里走，目标区出场地 bbox 的动作不受理（帧不变、底行不扣）。
    底行（row 63）= 计数条：受理一次移动，右端一格 9→1。
    幽灵 = 24 格色 2 的 5×5 带孔块（前一枚棋子的录像）。
几何工具从 geo 拿，那里没有世界断言。
"""
from __future__ import annotations

from geo import cells_of, components, bbox  # noqa: F401

CELL = 6               # 步长
PIECE = 5              # 棋子边长
PHASE = None           # 未用
DELTA = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0), "ACTION3": (0, -CELL), "ACTION4": (0, CELL)}
ME_COLOR = 9
GHOST_COLOR = 2
FLOOR_COLOR = 5
VOID_COLOR = 0
BAR_ROW = 63


def _ring_blocks(g, color):
    """color 的 24 格 5×5 带中心孔块清单，返回 [(top, left)]。

    原先这里还有一道「行号 ≥ 7 才算，用来排除 HUD」的闸，第 466 步证伪并拆掉：
    本关格行 0 就落在像素行 2–6，棋子走进格行 0 之后 me() 直接读空，
    origin() 于是退回按场地 bbox 猜原点、整张表错位一像素，六条概念一起读崩。
    HUD 的槽是 3×3 的环（8 格），本来就过不了「24 格、5×5 外框」这一关，那道行号闸是多余的。
    """
    out = []
    for comp in components(cells_of(g, color)):
        if len(comp) != PIECE * PIECE - 1:
            continue
        t, b, l, r = bbox(comp)
        if b - t != PIECE - 1 or r - l != PIECE - 1:
            continue
        out.append((t, l))
    return sorted(out)


def me(g):
    """棋子的 (top_row, left_col)；找不到或不唯一返回 None。"""
    blocks = _ring_blocks(g, ME_COLOR)
    return blocks[0] if len(blocks) == 1 else None


def ghosts(g):
    """幽灵块的 (top,left) 清单。"""
    return _ring_blocks(g, GHOST_COLOR)


WALKER_COLOR = 14


def walker(g):
    """自己会走的那个环（色 14，和棋子同形状）的 (top,left)；没有或不唯一返回 None。"""
    blocks = _ring_blocks(g, WALKER_COLOR)
    return blocks[0] if len(blocks) == 1 else None


def arena(g):
    """场地 bbox = 色 5 格子的 (top, bottom, left, right)。"""
    return bbox(cells_of(g, FLOOR_COLOR))


def target(pos, action):
    """pos 按 action 平移后的 (top, left)；非移动动作返回 None。"""
    d = DELTA.get(action)
    if d is None or pos is None:
        return None
    return (pos[0] + d[0], pos[1] + d[1])


def in_arena(g, pos):
    """5×5 目标区是否整块落在场地 bbox 内。"""
    a = arena(g)
    if a is None or pos is None:
        return False
    t, b, l, r = a
    return t <= pos[0] and pos[0] + PIECE - 1 <= b and l <= pos[1] and pos[1] + PIECE - 1 <= r


def window(g, pos):
    """5×5 目标区里出现的颜色集合。"""
    return {g[pos[0] + i][pos[1] + j] for i in range(PIECE) for j in range(PIECE)
            if 0 <= pos[0] + i < len(g) and 0 <= pos[1] + j < len(g[0])}


RAIL_COLOR = 8
RAIL_COLORS = (8, 11, 15)   # 同一套「按钮 3×3 + 轨道细线 + 小车 5×5」的结构，实测有三种颜色；11 是第 2 关、15 是第 3 关才露面的


def rail_cells(g, pos, color=RAIL_COLOR):
    """目标 5×5 区里某个轨道色的格子（相对坐标 (i, j)）。"""
    return {(i, j) for i in range(PIECE) for j in range(PIECE)
            if 0 <= pos[0] + i < len(g) and 0 <= pos[1] + j < len(g[0])
            and g[pos[0] + i][pos[1] + j] == color}


BUTTON_SHAPE = frozenset((i, j) for i in range(1, 4) for j in range(1, 4))
CROSS = frozenset((i, 2) for i in range(PIECE)) | frozenset((2, j) for j in range(PIECE))
PASSABLE_RAIL = BUTTON_SHAPE | CROSS   # 按钮 3×3 + 过格中心的轨道线：不挡；其余形状（小车）挡


def button_at(g, pos, color=None):
    """目标区里某个轨道色含居中 3×3 且都落在按钮+中心十字上 —— 按钮（可踩）。color=None 时任一色算数。"""
    for c in (RAIL_COLORS if color is None else (color,)):
        r = rail_cells(g, pos, c)
        if BUTTON_SHAPE <= r and r <= PASSABLE_RAIL:
            return True
    return False


def free(g, pos):
    """目标区可进入：在场地内、不含 0、且每种轨道色的格子都落在按钮 3×3 或中心十字（轨道线）上；别的形状（小车）是实体。"""
    if not in_arena(g, pos) or VOID_COLOR in window(g, pos):
        return False
    return all(rail_cells(g, pos, c) <= PASSABLE_RAIL for c in RAIL_COLORS)


def accepted(g, pos, action):
    """动作受理：目标区在场地 bbox 内（受理 ≠ 生效）。"""
    return in_arena(g, target(pos, action))


def bar(g):
    """计数条剩余：底行里色 9 的格数。"""
    return sum(1 for v in g[BAR_ROW] if v == ME_COLOR)


SPENT_COLOR = 1


def bar_spent(g):
    """计数条花掉的格数：底行里色 1 的格数（第 4 关起底行最右格是别的颜色，数 9 会少 1）。"""
    return sum(1 for v in g[BAR_ROW] if v == SPENT_COLOR)


def walls(g):
    """阻挡格集合：色 0（假设）。"""
    return frozenset(cells_of(g, VOID_COLOR))


# ---- 格位几何：格 (i,j) 左上 = 原点 + 6·(i,j)，中心 = 左上 + (2,2) ----
# 原点 = 棋子左上角对 6 取余（棋子永远站在格点上；格网从帧顶/帧左铺起，HUD 那几格不是地板、自然不可进）；
# 早先用「场地 bbox 左上角 +1」，第 3 关起地板不再是一整块矩形（终点格和小车各带自己的地板边），bbox 左上角就偏了 1 格；
# 再早先取余后加 6，第 4 关格网从第 2 列铺起，加 6 又偏了一格。
def origin(g):
    m = me(g)
    if m is None:
        a = arena(g)
        return None if a is None else (a[0] + 1, a[2] + 1)
    return (m[0] % CELL, m[1] % CELL)


def cell_tl(g, ij):
    o = origin(g)
    return None if o is None else (o[0] + CELL * ij[0], o[1] + CELL * ij[1])


def to_cell(g, pos):
    """(top,left) 像素 → 格位 (i,j)；不在格点上返回 None。"""
    o = origin(g)
    if o is None or pos is None:
        return None
    dr, dc = pos[0] - o[0], pos[1] - o[1]
    if dr % CELL or dc % CELL:
        return None
    return (dr // CELL, dc // CELL)


# ---- 轨道与小车：小车 = 某格里 8 不全落在 PASSABLE_RAIL 上的 5×5；轨道 = 过格中心的 8 线；按钮 = 轨道尽头那格 ----
DIRS = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}


def _at(g, r, c):
    return g[r][c] if 0 <= r < len(g) and 0 <= c < len(g[0]) else None


def rail_exits(g, tl, color=RAIL_COLOR):
    """格 tl 的四条边界中线格 (中心 ±3) 哪些是该轨道色 —— 轨道从哪边进出。"""
    cr, cc = tl[0] + 2, tl[1] + 2
    return {d for d, (dr, dc) in DIRS.items() if _at(g, cr + 3 * dr, cc + 3 * dc) == color}


def carts(g):
    """场上所有小车的 ((top,left), color)：按格扫描，5×5 里某个轨道色不全在按钮/十字上。"""
    o = origin(g)
    a = arena(g)
    if o is None:
        return []
    out = []
    r = o[0]
    while r + PIECE - 1 <= a[1]:
        c = o[1]
        while c + PIECE - 1 <= a[3]:
            for col in RAIL_COLORS:
                rc = rail_cells(g, (r, c), col)
                if rc and not rc <= PASSABLE_RAIL:
                    out.append(((r, c), col))
            c += CELL
        r += CELL
    return out


def rail_path(g, cart_tl, color=RAIL_COLOR):
    """从小车格沿轨道走到尽头，返回 [(top,left) …]（含小车格与尽头格）；走不出去返回 [cart_tl]。"""
    path = [cart_tl]
    came = None
    cur = cart_tl
    for _ in range(64):
        exits = rail_exits(g, cur, color) - ({came} if came else set())
        if len(exits) != 1:
            break
        d = exits.pop()
        dr, dc = DIRS[d]
        cur = (cur[0] + CELL * dr, cur[1] + CELL * dc)
        path.append(cur)
        came = {"U": "D", "D": "U", "L": "R", "R": "L"}[d]
    return path


def occupied(g, tl):
    """格 tl 上盖着一个 5×5 的活物：棋子、幽灵，或那个自己会走的环。
    环也算，是第 360 步逼出来的：它站上一个按钮格，那辆车照样挪了（见 cart_shifts_on_press v8）。"""
    return tl == me(g) or tl in ghosts(g) or tl == walker(g)


def cart_states(g):
    """每辆小车：{cart, color, button, path, pressed}。button = 轨道尽头格；pressed = 尽头格上有活物（棋子/幽灵/环）。"""
    out = []
    for ct, col in carts(g):
        p = rail_path(g, ct, col)
        out.append({"cart": ct, "color": col, "button": p[-1], "path": p, "pressed": occupied(g, p[-1])})
    return out


def buttons(g):
    """场上所有按钮格：[((top,left), color)]。"""
    out = []
    for tl in _cells(g):
        for c in RAIL_COLORS:
            if button_at(g, tl, c):
                out.append((tl, c))
    return out


def pressed_colors(g):
    """哪些轨道色至少有一个按钮被棋子/幽灵踩着。
    只用 buttons() 读会永远读出空集：按钮的 3×3 被踩它的 5×5 整块盖住，看得见的按钮按定义都没人踩。
    所以再从轨道尽头格认一遍——格缝像素盖不住，站在上面也量得出（rail_dead_ends 的读法）。"""
    return ({c for tl, c in buttons(g) if occupied(g, tl)}
            | {c for tl, c, _ in rail_dead_ends(g) if occupied(g, tl)})


# ---- 传送门：某格四周 7×7 边框一圈 24 个像素全是同一种轨道色（第 3 关起出现，两个一对、由同色按钮的轨道连着）----
def portals(g):
    """[((top,left), color)]，按格扫描。"""
    out = []
    for tl in _cells(g):
        rs = range(tl[0] - 1, tl[0] + PIECE + 1)
        cs = range(tl[1] - 1, tl[1] + PIECE + 1)
        edge = [(r, c) for r in rs for c in cs
                if r in (tl[0] - 1, tl[0] + PIECE) or c in (tl[1] - 1, tl[1] + PIECE)]
        for col in RAIL_COLORS:
            if all(_at(g, r, c) == col for r, c in edge):
                out.append((tl, col))
    return out


def portal_color(g, tl):
    """格 tl 是传送门则返回它的颜色，否则 None。"""
    for p, c in portals(g):
        if p == tl:
            return c
    return None


def rail_dead_ends(g):
    """[(格 tl, 轨道色, 唯一那侧)]：某轨道色只有一侧出入口的格 —— 轨道的尽头。
    出入口读的是格缝上的像素（中心 ±3），棋子/幽灵的 5×5 盖不住格缝，所以站在上面也量得出。
    排除：小车格（小车自己也只占一侧）、传送门格、四邻有传送门的格（门框像素落在格缝上，和轨道线分不开）。
    尽头格长什么样不是这个词的事，交给概念断言。"""
    ps = {p for p, _ in portals(g)}
    cart_tls = {c for c, _ in carts(g)}
    out = []
    for tl in _cells(g):
        if tl in ps or tl in cart_tls:
            continue
        if any((tl[0] + CELL * dr, tl[1] + CELL * dc) in ps for dr, dc in DIRS.values()):
            continue
        for c in RAIL_COLORS:
            ex = rail_exits(g, tl, c)
            if len(ex) == 1:
                out.append((tl, c, ex.pop()))
    return out
# ---- 终点格：5×5 里只有中心像素是 9、其余是地板，四周边框一圈 9（左边留开口） ----
GOAL_BORDER_MIN = 15   # 7×7 边框 24 个像素里至少这么多个 9


def _cells(g):
    """场地里所有格的 (top,left)。"""
    o, a = origin(g), arena(g)
    if o is None:
        return []
    out = []
    r = o[0]
    while r + PIECE - 1 <= a[1]:
        c = o[1]
        while c + PIECE - 1 <= a[3]:
            out.append((r, c))
            c += CELL
        r += CELL
    return out


def _border_nines(g, tl):
    rs = range(tl[0] - 1, tl[0] + PIECE + 1)
    cs = range(tl[1] - 1, tl[1] + PIECE + 1)
    edge = [(r, c) for r in rs for c in cs
            if r in (tl[0] - 1, tl[0] + PIECE) or c in (tl[1] - 1, tl[1] + PIECE)]
    return sum(1 for r, c in edge if _at(g, r, c) == ME_COLOR)


def goal_cell(g):
    """终点格 (top,left)；找不到或不唯一返回 None。"""
    out = []
    for tl in _cells(g):
        w = [(i, j) for i in range(PIECE) for j in range(PIECE)]
        if _at(g, tl[0] + 2, tl[1] + 2) != ME_COLOR:
            continue
        if any(_at(g, tl[0] + i, tl[1] + j) != FLOOR_COLOR for i, j in w if (i, j) != (2, 2)):
            continue
        if _border_nines(g, tl) >= GOAL_BORDER_MIN:
            out.append(tl)
    return out[0] if len(out) == 1 else None


HUD_ROW, HUD_COL0, HUD_STRIDE, HUD_LINE_ROW = 1, 1, 4, 5


def hud_slots(g):
    """每个槽的状态：'active'（9 环）/ 'spent'（2 环）/ 'fresh'（1 实心）；槽从左起连续排，**第一个认不出的块就是 HUD 的右端**。

    原先的停法是「遇到全 0 的块才停」，第 467 步证伪：本关场地从像素列 13 起（前几关更靠右或那几列是空的），
    扫描于是径直走出 HUD、走进地板，把地板块记成 None 接着扫，读出 16 个槽——
    hud_cursor_cycle 的 RESET 支要求重置后是 ['active'] + ['fresh']×(n-1)，n=16 时永远对不上，判 FALSE。
    全语料 940 帧里，没有一帧在 None 之后还跟着真槽，所以「认不出就停」只改掉读崩的那 155 帧。
    """
    out = []
    c = HUD_COL0
    while c + 2 < len(g[0]):
        blk = [g[HUD_ROW + i][c + j] for i in range(3) for j in range(3)]
        ring = blk[:4] + blk[5:]
        if all(v == 9 for v in ring) and blk[4] == 0:
            out.append("active")
        elif all(v == 2 for v in ring) and blk[4] == 0:
            out.append("spent")
        elif all(v == 1 for v in blk):
            out.append("fresh")
        else:
            break
        c += HUD_STRIDE
    return out


def hud_cursor(g):
    """下划线（第 5 行三格 9）指着第几个槽；找不到返回 None。"""
    for k in range(len(hud_slots(g))):
        c = HUD_COL0 + k * HUD_STRIDE
        if all(g[HUD_LINE_ROW][c + j] == 9 for j in range(3)):
            return k
    return None
