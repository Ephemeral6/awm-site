"""ACTION5 让 HUD 光标进到下一个槽：不回绕时旧槽变 spent、新槽变 active；回绕到第 0 槽时全部槽重置为 [active, fresh, fresh…]。RESET 那一步和回绕一样把槽全部重置、光标回 0。ACTION1..4 不改 HUD。"""
LEVEL = "L6"
SCOPE = "看全部动作（含 RESET）；换关返回 NA；HUD 槽列表为空或光标找不到返回 NA"
NOTE = ("v2：第 268 步 RESET 推翻 v1——v1 把 RESET 归进「非 ACTION5，所以 HUD 不许动」那一支，"
        "而重开本关把 ['spent','spent','active'] 光标 2 一次复位成 ['active','fresh','fresh'] 光标 0，"
        "和换枚回绕那一步长得一模一样。所以这一条现在说：让 HUD 复位的有两件事——换枚绕到头，和 RESET。\n"
        "第 467 步的 RESET 判 FALSE，但主张一个字没改，是词汇 `hud_slots` 读崩了：它的停法是「扫到全 0 的 3×3 才停」，"
        "而本关场地从像素列 13 起，扫描径直走出 HUD 走进地板，把地板块记成 None 接着扫，读出 16 个槽；"
        "RESET 那一支要求复位成 ['active'] + ['fresh']×(n−1)，n=16 时永远对不上。"
        "改成「第一个认不出的块就是 HUD 右端」——全语料 940 帧里没有一帧在 None 之后还跟着真槽，只改掉读崩的 155 帧。\n"
        "**两步之内同一个陷阱踩了两次**：第 466 步是 `_ring_blocks` 的行号闸、这一步是 `hud_slots` 的停法，"
        "都是「按像素行列写死的边界」在本关的场地位置上失效。凡是拿绝对行列号划 HUD 与场地的读法，"
        "换一关就会崩，而它一定伪装成某条概念判 FALSE。")
EVIDENCE = ["0da82ced88c614e6", "b59c529599b0ddd1", "29a43bd35dbe6b35", "b19bf4ec67244c44",
            "694451c614edcf16", "df245505d3d9d2bb"]

from _lib import hud_slots, hud_cursor


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    s0, s1 = hud_slots(prev), hud_slots(nxt)
    k0, k1 = hud_cursor(prev), hud_cursor(nxt)
    if not s0 or k0 is None or k1 is None:
        return "NA"
    if action == "RESET":
        return "TRUE" if (s1, k1) == (["active"] + ["fresh"] * (len(s0) - 1), 0) else "FALSE"
    if action != "ACTION5":
        return "TRUE" if (s0, k0) == (s1, k1) else "FALSE"
    n = len(s0)
    if k1 != (k0 + 1) % n:
        return "FALSE"
    if k1 == 0:
        expect = ["active"] + ["fresh"] * (n - 1)
    else:
        expect = list(s0)
        expect[k0] = "spent"
        expect[k1] = "active"
    return "TRUE" if s1 == expect else "FALSE"
