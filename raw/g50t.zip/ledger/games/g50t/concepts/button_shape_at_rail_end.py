"""轨道的尽头格（某个轨道色只从一侧进出的那格）只要没有棋子、幽灵、自己会走的那个环或小车占着，画的就是：居中 3×3 是该轨道色、通向轨道那一侧的边界中点像素也是该轨道色，其余 15 格是地板色。"""
LEVEL = "L6"
SCOPE = ("看全部动作；换关返回 NA；场上找不到尽头格返回 NA；"
         "尽头格上盖着活物（occupied：棋子/幽灵/那个自己会走的环）或被小车占着（carts 认出的格）时这一格跳过"
         "——都盖住了，底下长什么样这条不主张；"
         "传送门格本身、以及四邻里有传送门的格都跳过（7×7 边框的像素落在格缝上，和轨道线长得一样，"
         "光看格缝分不出这一侧是轨道还是门框：实测第 4 关门左边那格因此被误当成死端）。"
         "apply 画两种情形：棋子这一步从一个尽头格走成功了、或者在尽头格上换枚（ACTION5 必定把棋子挪走且收走全部幽灵），"
         "那一格腾出来之后的 25 格；"
         "看得见的幽灵比已用掉的替身少（说明有幽灵藏在棋子底下）时**走动那一支**闭嘴——那一格腾出来露的是幽灵，不是按钮")
NOTE = ("由来：第 177 步棋子从色 11 的尽头格走开，move_iff_free 的 apply 把腾出来的 5×5 全画成地板，错 10 格"
        "（3×3 按钮 + 一格轨道臂）。棋子站在上面时中心孔露的是地板色，所以从 prev 的像素读不出底下压着按钮。"
        "能读出来的是轨道拓扑：出入口看的是格缝上的像素（中心 ±3），棋子的 5×5 盖不住格缝，站在上面也照样量得出。"
        "这条概念的用处是拿两种读法互相对：拓扑（只有一侧出口）说哪一格是按钮，形状（居中 3×3 + 一条臂）说按钮长什么样；"
        "对不上就是反例。词汇 rail_exits / carts / portals 此前只被概念之间互相引用，没跟帧上另一种读法对过。"
        "v1 只认『小车沿轨道走到头那格』，因此第 3 关那种没有小车的轨道（尽头是按钮、另一头是两个传送门）整条漏掉，"
        "第 148 步棋子从色 15 的按钮上走开就没人画——v2 改成直接按出入口数认尽头，不再要求有小车。"
        "v3 补的是一个『该开口却闭嘴』的缺口：独立审计在冻结语料上发现，棋子经**换枚**离开尽头格的 8 次里，"
        "腾出来那 25 格与这条的图案逐像素零误差，而 apply 因为只认 ACTION1..4 全程沉默（少认 8×25=200 格）。"
        "换枚这一支比走动那一支更干净：那一步所有幽灵都被收走，不存在『腾出来露的是幽灵』。"
        "同一份审计也点出证据面窄：整局只见过 12 个按钮位置、颜色只有 8/11/15、全是单臂，双臂或偏心的形状排除不了。\n"
        "v4：第 360 步判 FALSE，因为那个色 14 的环走上了一个按钮格，而『盖住了就不主张』当时只认棋子和幽灵。"
        "环压着按钮时露出来的也是它的环，不是按钮图案，所以这一格照样该跳过。修在词汇 `occupied` 里，"
        "主张随之宽一格；被同一条反例逼出来的另一半（环压着按钮算不算按下）在 [[cart_shifts_on_press]] v8。\n"
        "第 466 步判 FALSE，但主张没错，是词汇读崩了：`_ring_blocks` 当时还有一道「像素行号 ≥ 7 才算块，用来排除 HUD」"
        "的闸，而本关的格行 0 就落在像素行 2–6。棋子走进格行 0（去踩色 8 的按钮）那一步 `me()` 读空，"
        "`origin()` 退回按场地 bbox 猜原点、整张格网错位一像素，于是 `rail_dead_ends` 报出六个根本不在格点上的「死端」，"
        "拿它们去比图案当然处处不符。拆掉那道行号闸之后同一条转移零不符——HUD 的槽是 3×3 的环（8 格），"
        "本来就过不了「24 格、5×5 外框」这一关，行号闸是多余的。教训：**一个只在场上某个角落才失效的词汇读法，"
        "会以「某条概念判 FALSE」的样子报出来，而挨打的那条概念可能一点错都没有**——反例先查词汇再改主张。")
EVIDENCE = ["5863c45421a432c2", "a4cd0ed377e3f740", "c5ce02d101a453ec",
            "e7b63bda550a0ed1", "95ffa56005ec2f95", "49fdde45fee8e15c", "674c3f1d24e8c83d",
            "c3ce0e210c3fdde2", "f47f0546f2516a6a", "deb01929c523e199", "6452b34f774d6ecc",
            "4069e2eb200a9612", "1c76ff953c5aa531"]

from _lib import (FLOOR_COLOR, PIECE, free, ghosts, goal_cell, hud_cursor, me, occupied,
                  portal_color, rail_dead_ends, target)

ARM = {"U": (0, 2), "D": (PIECE - 1, 2), "L": (2, 0), "R": (2, PIECE - 1)}


def _pattern(color, d):
    """尽头格 5×5 的应有样子：{(i, j): 颜色}。"""
    out = {(i, j): FLOOR_COLOR for i in range(PIECE) for j in range(PIECE)}
    for i in range(1, 4):
        for j in range(1, 4):
            out[(i, j)] = color
    out[ARM[d]] = color
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    ends = [e for e in rail_dead_ends(nxt) if not occupied(nxt, e[0])]
    if not ends:
        return "NA"
    for tl, color, d in ends:
        for (i, j), v in _pattern(color, d).items():
            if nxt[tl[0] + i][tl[1] + j] != v:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    a = me(prev)
    if a is None:
        return None
    ends = {tl: (color, d) for tl, color, d in rail_dead_ends(prev)}
    if a not in ends:
        return None
    color, d = ends[a]
    pat = {(a[0] + i, a[1] + j): v for (i, j), v in _pattern(color, d).items()}
    if action == "ACTION5":
        return pat              # 换枚必定把棋子挪回起点格，而且这一步所有幽灵都被收走，尽头格露出的就是干净的按钮
    if action not in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return None
    k = hud_cursor(prev)
    if k is not None and len(ghosts(prev)) < k:
        return None
    t = target(a, action)
    if t is None or not free(prev, t) or portal_color(prev, t) is not None or t == goal_cell(prev):
        return None
    return pat
