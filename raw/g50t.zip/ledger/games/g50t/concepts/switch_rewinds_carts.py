"""换枚（ACTION5）那一步，小车最多挪 1 格：色 8 的，换枚前按钮被踩着就沿轨道朝远离按钮的方向挪恰好 1 格、没被踩着就不动；色 11 的，被踩着就不动、没被踩着可能不动也可能朝任一方向挪 1 格（挪去哪这条概念读不出来，见 NOTE）。"""
LEVEL = "L6"
SCOPE = ("只看 ACTION5；换关返回 NA；prev/nxt 的按钮集合对不上、场上没有小车、或某辆车的颜色不是 8/11 返回 NA。"
         "色 11 那一支弱：只禁止「挪 2 格以上」和「跳到轨道外」，不说方向。不带 apply。")
NOTE = ("v1 只说「不动或退 1」，两边都不冒险。v2 加了「换枚那一刻被踩着」的情形：色 8 每次都退、色 11 那次不退。"
        "v3 死于回绕那一步（一辆没被踩着的色 11 朝按钮挪了 1 格，不是背离），于是把方向交出去、换回两句硬的："
        "色 8 没被踩着一定不动、色 11 没被踩着一定挪。v4 死于紧接着的下一次换枚（tid 77a020f688714a33）："
        "一辆没被踩着的色 11 在同样的位置上**一格没动**。和 v3 死的那一步比，两帧上（颜色、车在哪、按钮有没有人踩）一模一样，"
        "结果相反——所以这件事的原因不在帧上，是隐藏状态。v4 只留下帧上判得出的那部分。\n"
        "隐藏状态是什么，语料已经指得很清楚，三件观测拼出来的：\n"
        "  1) 每辆车（两种颜色都是）一辈子只在两个相邻格出现过，一格是关卡开局那一格（叫它 home），另一格是它朝按钮走 1 步的那格。"
        "这两格离按钮多远不固定：某一关是 8/9 格，另几关是 2/3、3/4 格——所以「离按钮几格」不能当状态读。\n"
        "  2) 色 8 是弹簧：按钮有人踩就在近格，松开就回 home。换枚会把所有按钮松开（幽灵全收走、棋子回起点格），"
        "所以色 8 在换枚后一定在 home——这正好等于「被踩着就退 1 格、没被踩着就不动」，两种说法在语料上一格不差。\n"
        "  3) 色 11 是闩：每按一次翻一次（home↔近格），松开不动。换枚那一步它的表现只有一种读法装得下全部 4 次："
        "**换枚把这盘带子里的翻转全部撤销，让车回到这盘带子开始时所在的那一格**（带子开始 = 上一次换枚之后那一帧），"
        "唯一的例外是换枚那一刻它的按钮还被踩着，那就不撤。第 195 步（带子里翻过一次 → 撤回 home）、"
        "第 203 步（翻过一次但还踩着 → 不撤）、第 225 步（带子里被幽灵翻过一次，而带子开始时它就在近格 → 撤回近格，"
        "看上去像「朝按钮挪」）、第 235 步（这盘带子里没人碰过它 → 一格不动）都对得上。这就是概念名字里那个 rewind。\n"
        "为什么它进不了断言：「这盘带子开始时在哪」要翻历史，assert_ 只看得见一步的 prev/action/nxt。"
        "所以它现在是我下注时用的模型，不是走过闸的主张——每次换枚我把三辆车的落点逐个写进押注，"
        "预测偏一格 --strict 当场停批，这是它眼下唯一挨打的地方。能把它变成走闸主张的实验："
        "同一盘带子里把同一个色 11 的按钮踩**两次**（偶数次）再换枚——「撤销」说车不动，"
        "「换枚必翻一次」说车会翻；再踩三次，两种读法又分开。这个实验值 4~6 步，本关计数条还剩 36 格（≈72 步），"
        "排在通关之后。\n"
        "顺带记一条别的：色 11 的按下方向（翻到另一格）在帧上也读不出来，因为「哪一格是 home」读不出来。"
        "cart_shifts_on_press 的 apply 在这件事上是在赌「被踩之前车在 home」——它认领过的 13 次里次次都成立（都是关卡/带子开头那次按），"
        "但那是赌赢了，不是读出来的。")
EVIDENCE = ["95ffa56005ec2f95", "49fdde45fee8e15c", "e7b63bda550a0ed1", "b59c529599b0ddd1",
            "674c3f1d24e8c83d", "c3ce0e210c3fdde2", "6452b34f774d6ecc", "442cb3c726bc79df",
            "9b811083dd89bdbf", "77a020f688714a33"]

from _lib import cart_states

SPRING, RATCHET = 8, 11


def _pairs(prev, nxt):
    a = {s["button"]: s for s in cart_states(prev)}
    b = {s["button"]: s for s in cart_states(nxt)}
    if set(a) != set(b) or not a:
        return None
    return [(a[k], b[k]) for k in a]


def _expected(s0):
    """按颜色与踩压状态算 nxt 里这辆车允许出现在哪些格；算不出返回 None。"""
    p = s0["path"]
    if len(p) < 2:
        return None
    step = (p[1][0] - p[0][0], p[1][1] - p[0][1])
    fwd = p[1]                                              # 朝按钮 1 格
    back = (p[0][0] - step[0], p[0][1] - step[1])           # 背离按钮 1 格
    if s0["color"] == SPRING:
        return {back} if s0["pressed"] else {s0["cart"]}
    return {s0["cart"]} if s0["pressed"] else {s0["cart"], fwd, back}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action != "ACTION5":
        return "NA"
    pairs = _pairs(prev, nxt)
    if pairs is None:
        return "NA"
    for s0, s1 in pairs:
        if s0["color"] not in (SPRING, RATCHET):
            return "NA"
        want = _expected(s0)
        if want is None:
            return "NA"
        if s1["cart"] not in want:
            return "FALSE"
    return "TRUE"
