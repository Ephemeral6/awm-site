"""ACTION6 点在空处（既不在任何**料**的 6x6 命中框里，也不在任何 2x2 空位标记里）：不受理，整帧一格不变，计数条也不花。"""
LEVEL = "L2"
SCOPE = "只看带坐标的 ACTION6；换关返回 NA；点击格落在任何料的 6x6 命中框或任何 2x2 标记里返回 NA。"
NOTE = ("v2：v1 把「料」写成了「砖」。第 195 步点在料架上一个 4x4 **空心环**上，"
        "它既不是砖也不是标记，于是这条概念断言「不受理、整帧不动」——实际帧差 20 格，"
        "环被选中了，当场判 FALSE。"
        "错的不是这句话的意思，是它依赖的那个词：那一关之前每一关的料架上恰好只有砖，"
        "于是「料 = 砖」看起来像定义，其实是那几关的偶然。改用 [[pieces]] 之后这句话原样成立。"
        "这条概念是个**排除式主张**，而排除式主张的危险正在这里——"
        "它的 scope 由「我认得出的东西」划定，我认不出的东西会自动掉进它声称管的那一片。")
EVIDENCE = ["86b7b02fc701b39d", "b82678a8c5e082c5", "ce21d75425a0f59e",
            "9c299e93a3539d03", "ced2f09be7feb56a", "12408f8b05feb77d"]

from _lib import click, hole_at, piece_near


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not str(action).startswith("ACTION6"):
        return "NA"
    rc = click(action)
    if rc is None:
        return "NA"
    if piece_near(prev, rc) is not None:
        return "NA"
    if hole_at(prev, rc) is not None:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"


def apply(prev, action, ctx=None):
    """不受理的一步没有任何格子改变——这条概念不认领任何格子，但它把'什么都不变'说清楚了。"""
    return None
