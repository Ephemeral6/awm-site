"""ACTION6 点在**已经被选中**的那块砖上：环退回底色，砖本身不动，计数条一格不花——免费取消选中。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；prev 里没有选中砖返回 NA；"
         "点击格落在的那块砖不是被选中的那块（或不落在任何砖的 6x6 命中框里）返回 NA。")
NOTE = ("第 44 步测出来的：swap 的 scope 把「点中的就是选中的那块」排除掉并注明「没测过」，"
        "这一步就是去撞那句话。结果它不是 swap 也不是不受理：它是 ACTION5 的免费版本。"
        "所以取消选中有两条路，一条收费一条免费——见 [action5_costs]。")
EVIDENCE = ["32d454c832588f87"]

from _lib import BG, brick_near, bricks, click, holes, ring_cells, selected, used


def _plan(prev, action):
    """点中的就是选中的那块砖时返回 sel，否则 None。"""
    if not str(action).startswith("ACTION6"):
        return None
    sel = selected(prev)
    if sel is None:
        return None
    hit = brick_near(prev, click(action))
    if hit is None:
        return None
    return sel if hit[0] == sel else None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    sel = _plan(prev, action)
    if sel is None:
        return "NA"
    if selected(nxt) is not None:
        return "FALSE"
    if bricks(nxt) != bricks(prev):
        return "FALSE"
    if holes(nxt) != holes(prev):
        return "FALSE"
    return "TRUE" if used(nxt) == used(prev) else "FALSE"


def apply(prev, action, ctx=None):
    sel = _plan(prev, action)
    if sel is None:
        return None
    return {cell: BG for cell in ring_cells(*sel)}
