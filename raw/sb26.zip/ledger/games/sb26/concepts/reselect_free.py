"""有砖被选中时 ACTION6 点在**棋盘框外**（料架）另一块砖上：选中环挪到被点的那块，两块砖一格不动，免费。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；prev 里没有选中砖返回 NA；"
         "点击格不落在任何砖的 6x6 命中框内返回 NA；点中的就是选中的那块砖本身返回 NA（那是 [[unpick]]）；"
         "选中砖与被点砖不是双双落在棋盘外框**外部**时返回 NA——框内那半是 [[swap]]。")
NOTE = ("它是 [[swap]] v1 的 6 条反例逼出来的：料架那一排点另一块砖，帧差恰好 40 格"
        "（旧环 20 格灭、新环 20 格亮），砖位与砖色全同、空位标记全同、计数条一格不动。"
        "所以「有砖在手时点另一块砖」不是一个动作而是两个：框内换色收费，框外改选免费。"
        "这条概念要紧的后果是**料架排不动**：先前想用 23 次相邻交换遍历料架的 24 种排列，"
        "实际上一次也没换成，白花了 5 格计数条（见 journal 的事故行）。"
        "要改料架的排列只能借棋盘做中转，一次对调要 3 格计数。"
        "还没测的：选中框内的砖去点框外的砖（或反过来）——跨框点击一次都没发生过，那时这两条概念都返回 NA。")
EVIDENCE = ["16de5723172fd609", "54475046114dd478", "7a120bb2f53d8cfd",
            "8871f81405747b7f", "9ffdb051c080082b", "b588920a5ee3067d"]

from _lib import (BG, RING, brick_near, bricks, click, holes, in_box,
                  ring_cells, selected, used)


def _plan(prev, action):
    """返回 (sel, tgt) 或 None。"""
    if not str(action).startswith("ACTION6"):
        return None
    sel = selected(prev)
    if sel is None:
        return None
    bs = bricks(prev)
    if sel not in bs:
        return None
    hit = brick_near(prev, click(action))
    if hit is None:
        return None
    tgt = hit[0]
    if tgt == sel:
        return None
    if in_box(prev, sel) or in_box(prev, tgt):
        return None
    return (sel, tgt)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    _sel, tgt = p
    if bricks(nxt) != bricks(prev):
        return "FALSE"
    if holes(nxt) != holes(prev):
        return "FALSE"
    if selected(nxt) != tgt:
        return "FALSE"
    return "TRUE" if used(nxt) == used(prev) else "FALSE"


def apply(prev, action, ctx=None):
    p = _plan(prev, action)
    if p is None:
        return None
    sel, tgt = p
    out = {cell: BG for cell in ring_cells(*sel)}
    for cell in ring_cells(*tgt):
        out[cell] = RING
    return out
