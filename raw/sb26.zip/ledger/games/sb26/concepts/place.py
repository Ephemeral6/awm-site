"""ACTION6 点在一个 2x2 空位标记上、而此刻有料被选中：那块料整体搬到该空位（占以标记为中心的 4x4），
原地留下一个 2x2 空位标记，环消失，计数条恰好多一格。
"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；prev 里没有选中的料返回 NA；"
         "点击格不落在任何 2x2 空位标记内返回 NA。")
NOTE = ("v2：把「砖」换成 [[pieces]]，并按料的种类画落点——实心砖 16 格全上色，"
        "空心指路环只有外圈 12 格上色、正中 2x2 是底色。"
        "第 196 步把一个环从料架搬进板上的空位，53 格帧差逐格对上："
        "料架那边 12 格环身退底色 + 20 格选中环退底色 + 4 格新标记，"
        "落点那边 12 格上色 + 正中 4 格由标记色变底色，加上计数条 1 格。"
        "值得记的是**正中那 4 格的方向**：搬砖时标记 2→砖色，搬环时标记 2→底色。"
        "所以「落点变成料的颜色」这句话本身就藏着「料是实心的」这个没说出口的前提。")
EVIDENCE = ["81cdf36b5cb55961", "92130422ed298775", "e2b9d19ebd90e181"]

from _lib import (BG, HOLE, USED, bar_row, brick_cells, click, hole_at,
                  holes, piece_cells, pieces, ring_cells, selected, used)


def _plan(prev, action):
    """返回 (sel, kind, color, hole) 或 None —— 这条概念管不管这一步。"""
    if not str(action).startswith("ACTION6"):
        return None
    sel = selected(prev)
    if sel is None:
        return None
    got = pieces(prev).get(sel)
    if got is None:
        return None
    kind, color = got
    hole = hole_at(prev, click(action))
    if hole is None:
        return None
    return (sel, kind, color, hole)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    sel, kind, color, hole = p
    want = dict(pieces(prev))
    del want[sel]
    want[(hole[0] - 1, hole[1] - 1)] = (kind, color)
    if pieces(nxt) != want:
        return "FALSE"
    want_holes = set(holes(prev))
    want_holes.discard(hole)
    want_holes.add((sel[0] + 1, sel[1] + 1))
    if holes(nxt) != want_holes:
        return "FALSE"
    if selected(nxt) is not None:
        return "FALSE"
    return "TRUE" if used(nxt) == used(prev) + 1 else "FALSE"


def apply(prev, action, ctx=None):
    p = _plan(prev, action)
    if p is None:
        return None
    sel, kind, color, hole = p
    out = {}
    for cell in ring_cells(*sel):                       # 选中环退回底色
        out[cell] = BG
    for cell in brick_cells(*sel):                      # 料离场：整个 4x4 退底色
        out[cell] = BG
    for dr in range(2):                                 # 中心 2x2 变空位标记
        for dc in range(2):
            out[(sel[0] + 1 + dr, sel[1] + 1 + dc)] = HOLE
    out[(bar_row(prev), 63 - used(prev))] = USED        # 计数条多一格
    out.update(piece_cells(kind, color, hole[0] - 1, hole[1] - 1))   # 料落位，压掉重叠
    return out
