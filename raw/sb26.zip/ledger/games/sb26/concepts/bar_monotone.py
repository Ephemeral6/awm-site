"""同一次关卡尝试内，计数条只增不减且每步最多多一格：used(nxt) - used(prev) 只会是 0 或 1。撤销也不会把它退回去。"""
LEVEL = "L4"
SCOPE = ("除 RESET 以外的所有动作；换关返回 NA；**动作是 RESET 时返回 NA**——"
         "重开这一关会把计数条清零，那不是「减」，那是这一次尝试结束了，见 [[reset_refills]]。")
NOTE = ("v1 写的是「所有动作」，被 da5277b10c34003c（RESET）打掉：计数条从 49 格直接回到 0。"
        "这条反例本身是好消息，也是这一局策略的支点——它说明这个会耗尽的资源是**可再生的**，"
        "而再生的手续（RESET）在没通过任何一关时不花任何东西。所以「省着花计数条」从来没有必要，"
        "真正稀缺的只有墙上时钟。单调性仍然成立，但它的适用范围是「一次尝试之内」，不是「一整局之内」。")
EVIDENCE = ["183bbcb8aa67f763", "81cdf36b5cb55961", "da5277b10c34003c"]

from _lib import used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if str(action).upper().startswith("RESET"):
        return "NA"
    d = used(nxt) - used(prev)
    return "TRUE" if d in (0, 1) else "FALSE"
