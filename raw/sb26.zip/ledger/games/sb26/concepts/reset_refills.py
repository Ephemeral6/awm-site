"""RESET 把这一关整个退回开局态：计数条清零、一块料都不在板上、料架上的料数正好等于目标位数，而已通过的关卡数不变。"""
LEVEL = "L4"
SCOPE = ("只看动作 RESET；别的动作返回 NA。"
         "**换卡之后的 RESET 不归这条管**：关卡号倒退（level_next < level_prev）说明退的不是「本关」"
         "而是整局——已通关数也清零了，那是另一条手续，见 [[recard_resets_all]]，这里返回 NA。"
         "**不声称料回到哪几个具体位置、也不声称目标位有几个**——那两样按关变。"
         "认不出板（`boards` 返回空）时，只核前三件事，不核料架数与目标位数是否相等。"
         "**未验证**：会话内的 RESET 语料里只有两条，一条在 0 通关、一条在 7 通关时，"
         "「已通过的关卡数不变」这两个点上都成立，中间的点没测过。")
NOTE = ("这一条是这一局的策略支点，所以单独立册：它说明「收费动作」的代价是**可再生**的。"
        "手续本身不花计数条（计数条清零了），也不减少已通关数，所以把 64 格全烧掉再重开是**零成本**的。"
        "它也是 [[bar_monotone]] v1 唯一的反例：那条概念说计数条只增不减，"
        "而这一步让它从 49 格回到 0。两条概念现在分工：单调性管一次尝试之内，这一条管尝试与尝试之间。"
        "**v2 为什么改**：v1 把开局态写成了一张写死的表——四块砖、哪四个坐标、哪四个颜色、"
        "板上恰好四个空位——那全是第 0 关的样子。它的 N 一直是 0（语料里只有一条 RESET，"
        "而那条在它自己的 EVIDENCE 里），所以**它从来没在任何 held-out 转移上开过口**，"
        "错了也不会有任何东西报错。v2 只留跨关还成立的四件事。"
        "**v3 为什么改**：v2 的子声称写的是「料架上的**砖**数 = 目标位数」——又是那个老病："
        "第 7 关重开时料架上是 6 块砖加 2 个指路环，6 ≠ 8 当场判 FALSE。"
        "「砖」在这里从没当过定义，世界的类别一直是**料**（能被拿起的 4x4，实心或空心）；"
        "同一家族已经发作三次（选中/放置/点空处，然后是这条）。改成 [[pieces]] 后这句原样成立。"
        "**v4 为什么改**：换卡之后的 RESET 是同一名动作的另一条手续——它退回的不是本关，是整局"
        "（第 7 关 → 第 0 关，已通关数清零）。v3 的「已通过的关卡数不变」在那儿当场判 FALSE。"
        "同一个动作、两种语义、分界线在**会话还活着没有**，能从帧外看到的信号只有关卡号倒没倒退。"
        "整局归零那半搬进 [[recard_resets_all]]，这条只管会话内的重开。")
EVIDENCE = ["da5277b10c34003c", "b3c7d55b7e50bf1d", "415bbaa294f9148f"]

from _lib import boards, on_board, pieces, used


def assert_(prev, action, nxt, ctx=None):
    if not str(action).upper().startswith("RESET"):
        return "NA"
    if ctx is not None:
        lv_p, lv_n = ctx.get("level_prev"), ctx.get("level_next")
        if lv_p is not None and lv_n is not None and lv_n < lv_p:
            return "NA"        # 关卡号倒退 = 换卡后的整局归零，见 [[recard_resets_all]]
    if used(nxt) != 0:
        return "FALSE"
    if any(on_board(nxt, tl) for tl in pieces(nxt)):
        return "FALSE"
    bd = boards(nxt)
    if bd:
        slots = [e for entries in bd.values() for e in entries]
        rack = [tl for tl in pieces(nxt) if not on_board(nxt, tl)]
        if len(rack) != len(slots):
            return "FALSE"
    if ctx is None:
        return "TRUE"
    return "TRUE" if ctx["level_prev"] == ctx["level_next"] else "FALSE"
