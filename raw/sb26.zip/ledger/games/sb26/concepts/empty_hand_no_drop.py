"""手上没砖时点空位标记：不受理，整帧一格不变。空位只有在有砖被选中时才接客。"""
LEVEL = "L2"
SCOPE = "只看带坐标的 ACTION6；换关返回 NA；prev 里有选中砖返回 NA；点击格不落在任何 2x2 标记里返回 NA。"
NOTE = ""
EVIDENCE = ["acb394801b1ce38b"]

from _lib import click, hole_at, selected


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not str(action).startswith("ACTION6"):
        return "NA"
    if selected(prev) is not None:
        return "NA"
    if hole_at(prev, click(action)) is None:
        return "NA"
    return "TRUE" if prev == nxt else "FALSE"
