"""ACTION6 点在一块料上、而此刻没有料被选中：那块料被套上一圈色0 环，盘面别处（料、空位、计数条）一格不动。

这是「选中免费」这条的正文。
"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；prev 里已有选中的料返回 NA；"
         "点击格不落在任何一块料的 4x4 内返回 NA。")
NOTE = ("v2：把「砖」换成 [[pieces]]。第 195 步点在料架上一个 4x4 空心环上，环被选中了——"
        "手续跟选中一块砖分毫不差，可这条概念当时只认实心砖，整步返回 NA、一句话没说。"
        "**它没被判错，它是被放过了**：同一步上 [[reject_void]] 才是那个开口挨打的。"
        "两条概念共用一个错词，一条判错关闸、一条静默——静默那条更难发现。")
EVIDENCE = ["17cf1ff91b2a537a", "13f4292e68b19d49", "12408f8b05feb77d"]

from _lib import RING, click, holes, piece_at, pieces, ring_cells, selected, used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not str(action).startswith("ACTION6"):
        return "NA"
    if selected(prev) is not None:
        return "NA"
    hit = piece_at(prev, click(action))
    if hit is None:
        return "NA"
    (t, l), _kind, _v = hit
    if selected(nxt) != (t, l):
        return "FALSE"
    if pieces(nxt) != pieces(prev):
        return "FALSE"
    if holes(nxt) != holes(prev):
        return "FALSE"
    return "TRUE" if used(nxt) == used(prev) else "FALSE"


def apply(prev, action, ctx=None):
    if not str(action).startswith("ACTION6"):
        return None
    if selected(prev) is not None:
        return None
    hit = piece_at(prev, click(action))
    if hit is None:
        return None
    (t, l), _kind, _v = hit
    return {cell: RING for cell in ring_cells(t, l)}
