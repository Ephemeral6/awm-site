"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

这一局没有会走动的玩家，只有「砖」和「空位」，所以模板里的 CELL/DELTA/me/walls 全部留空。
量出来的词：

    BG=4 底色；HOLE=2 空位标记色（2x2 一块）；RING=0 选中环色（6x6 空心边框）；
    USED=3 计数条里已用格的颜色；BAR_ROW=53 计数条所在行；
    SLOT_EMPTY=5 上排显示面板里空槽内部的颜色；BOARD_EDGE=8 棋盘外框色。

    bricks(g)   全部 4x4 实心单色砖 -> {(top_row,left_col): 色}（**几何认砖，不用颜色白名单**）
    holes(g)    全部 2x2 空位标记 -> {(top_row,left_col)}（不含计数条那一行）
    selected(g) 被色0 环套住的那块砖的 (top_row,left_col)，没有则 None
    bar_row(g)  计数条所在行（从帧里找，不写死）；used(g) 计数条里色3 的格数
    on_board(g,rc) rc 在计数条上方（棋盘那一侧）吗？—— 料架在下方。旧名 in_box 是它的别名
    panel_order(g) 上排面板各框的边框色，按列从左到右 —— **目标顺序**，按关变，必须量不能写死
    box_order(g)   棋盘那一侧的砖色，按阅读顺序（先行后列）—— 拿去和 panel_order 比
    slot_order(g)  棋盘那一侧全部目标位按阅读顺序 -> [(row,col,色 或 None)]，空位记 None
    link_rings(g)  **指路环**：4x4 空心、内部是底色的那种框 -> {(row,col): 环色}，(row,col) 是它占的位
    pieces(g)      **能被拿起的料** -> {(top,left): (kind, 色)}，kind ∈ brick/link；砖不是唯一的料
    piece_at / piece_near(g,rc)  点击格落在哪块料的 4x4 / 6x6 命中框里
    piece_cells(kind,色,top,left) 一块料落在那儿时那 16 格该是什么颜色
    boards(g)      棋盘那一侧的每一块**板** -> {框色: [(row,col,kind,色) 按阅读顺序]}，kind ∈ brick/empty/link
    nested_order(g) 目标位的**嵌套阅读顺序**取色 -> 元组或 None，见下面那一段

**两个从第 0 关留下来的常数已经退役**：`BOARD_EDGE`（棋盘框色）与 `NONBRICK`（非砖色名单）
都是那一关的偶然——另一关的棋盘分上下两排、框线两种颜色，而且有一块砖的颜色正好等于第 0 关的框色。
它们还留在文件里只是为了不改动依赖它们的旧概念源码，新词一个都不许再用它们。

砖与空位的几何关系（假设）：一块砖占 4x4；它离场后原地留下一个 2x2 空位标记，
标记 = 砖的正中 2x2，即 (top+1,left+1)；反过来，把砖放进标记 (t,l) 后砖占 (t-1,l-1) 起的 4x4。
"""
from __future__ import annotations

from geo import bbox, cells_of, components  # noqa: F401

CELL = None            # 这一局没有步长
PHASE = None
DELTA = {}             # 这一局的动作不是位移

BG = 4
HOLE = 2
RING = 0
USED = 3
BAR_ROW = 53
SLOT_EMPTY = 5
BOARD_EDGE = 8

#: 不可能是砖的颜色（底色、标记、环、计数、面板空槽、棋盘外框）
NONBRICK = frozenset({BG, HOLE, RING, USED, SLOT_EMPTY, BOARD_EDGE})


def bricks(g):
    """4x4 实心单色砖 -> {(top_row, left_col): 色}。

    **不用颜色白名单认砖，用几何认**：砖 = 4x4 实心单色块，且不落在上排显示面板的 bbox 里
    （面板每个框的内部也正好是 4x4 实心，那不是砖）。

    为什么不能用白名单：`NONBRICK` 是从某一关量出来的排除名单，而各关的砖色与结构色会互换。
    实测吃过一次：某一关的料架最左边有一块砖，颜色恰好等于另一关的棋盘框色，于是它被排除名单
    挡掉，整块砖在册子眼里不存在——而它正是那一关凑齐目标序列缺的那一块。
    颜色白名单认物件 = 把一关的偶然写成跨关的定义。
    """
    bx = panel_bbox(g)
    out = {}
    for v in {u for row in g for u in row}:
        for comp in components(cells_of(g, v)):
            if len(comp) != 16:
                continue
            t, b, l, r = bbox(comp)
            if (b - t, r - l) != (3, 3):
                continue
            if bx is not None and bx[0] <= t and b <= bx[1] and bx[2] <= l and r <= bx[3]:
                continue
            out[(t, l)] = v
    return out


def bar_row(g):
    """计数条所在行：整行 64 格全是「未用/已用」两色的那一行；找不到退回写死的 BAR_ROW。"""
    for r, row in enumerate(g):
        if len(row) == 64 and all(v in (HOLE, USED) for v in row):
            return r
    return BAR_ROW


def holes(g):
    """2x2 空位标记 -> {(top_row, left_col)}；计数条那一行排除在外。"""
    br = bar_row(g)
    out = set()
    cs = [(r, c) for (r, c) in cells_of(g, HOLE) if r != br]
    for comp in components(cs):
        if len(comp) != 4:
            continue
        t, b, l, r = bbox(comp)
        if (b - t, r - l) == (1, 1):
            out.add((t, l))
    return out


def ring_box(g):
    """选中环的 bbox (top,bottom,left,right)；没有环返回 None。环是 6x6 空心边框 20 格。"""
    for comp in components(cells_of(g, RING)):
        if len(comp) != 20:
            continue
        t, b, l, r = bbox(comp)
        if (b - t, r - l) == (5, 5):
            return (t, b, l, r)
    return None


def selected(g):
    """被环套住的砖的 (top_row, left_col)；没有返回 None。砖在环内偏移 (+1,+1)。"""
    box = ring_box(g)
    if box is None:
        return None
    t, _b, l, _r = box
    return (t + 1, l + 1)


def used(g):
    """计数条里色3 的格数。"""
    return sum(1 for v in g[bar_row(g)] if v == USED)


def click(action):
    """从动作串 "ACTION6:x,y" 取出点击格 (row, col) = (y, x)；不带坐标返回 None。"""
    s = str(action)
    if ":" not in s:
        return None
    try:
        x, y = (int(v) for v in s.split(":", 1)[1].split(","))
    except Exception:                                   # noqa: BLE001
        return None
    return (y, x)


def brick_at(g, rc):
    """点击格 rc 落在哪块砖的 4x4 里 -> ((top,left), 色)；不在任何砖里返回 None。"""
    if rc is None:
        return None
    r, c = rc
    for (t, l), v in bricks(g).items():
        if t <= r < t + 4 and l <= c < l + 4:
            return ((t, l), v)
    return None


def hole_at(g, rc):
    """点击格 rc 落在哪个 2x2 空位标记里 -> (top,left)；不在任何标记里返回 None。"""
    if rc is None:
        return None
    r, c = rc
    for (t, l) in holes(g):
        if t <= r < t + 2 and l <= c < l + 2:
            return (t, l)
    return None


def brick_cells(top, left):
    """(top,left) 起那块砖的 16 个格子。"""
    return [(top + dr, left + dc) for dr in range(4) for dc in range(4)]


def brick_near(g, rc):
    """点击格 rc 落在哪块砖的 **6x6 命中框**（砖外扩一圈）里 -> ((top,left), 色)；否则 None。

    实测：点砖正上方一格的底色格也算点中了那块砖，所以命中框比砖本身大一圈。
    """
    if rc is None:
        return None
    r, c = rc
    for (t, l), v in bricks(g).items():
        if t - 1 <= r < t + 5 and l - 1 <= c < l + 5:
            return ((t, l), v)
    return None


def box_box(g):
    """棋盘外框（色8 空心矩形）的 bbox (top,bottom,left,right)；没有返回 None。

    **上排面板里的色 8 要排除**：面板各框的边框色是按关变的，某一关的面板里就有一个色 8 的框，
    若把它一起算进 bbox，棋盘外框会被撑到把面板包进来，`in_box` 随之全错。
    """
    bx = panel_bbox(g)
    cs = cells_of(g, BOARD_EDGE)
    if bx is not None:
        t, b, l, r = bx
        cs = [(rr, cc) for (rr, cc) in cs if not (t <= rr <= b and l <= cc <= r)]
    if not cs:
        return None
    return bbox(cs)


def panel_bbox(g):
    """上排显示面板（底色 SLOT_EMPTY 的那块矩形）的 bbox (top,bottom,left,right)；没有返回 None。"""
    cs = cells_of(g, SLOT_EMPTY)
    if not cs:
        return None
    return bbox(cs)


def panel_order(g):
    """上排面板里各个空心方框的**边框色**序列 -> 元组。

    这是「目标顺序」的读法：框的个数与颜色按关变，所以必须从帧里量，不能写死。
    面板可能不止一排：某一关的面板是**两排一模一样的框**（列对齐同色），目标是其中
    一排的长度——两排重复是显示方式，不是目标翻倍，所以排与排完全相同时只取一排。
    排与排不同时按行拼接整段返回（没见过这个场面，读法是按行续上去的猜法，真遇到先停）。
    """
    bx = panel_bbox(g)
    if bx is None:
        return ()
    t, b, l, r = bx
    boxes = []
    for v in {u for row in g for u in row} - {BG, SLOT_EMPTY}:
        for comp in components(cells_of(g, v)):
            if len(comp) != 20:
                continue
            if not all(t <= rr <= b and l <= cc <= r for (rr, cc) in comp):
                continue
            ct, cb, cl, cr = bbox(comp)
            if (cb - ct, cr - cl) != (5, 5):
                continue
            boxes.append((ct, cl, v))
    boxes.sort()
    rows = {}
    for (ct, cl, v) in boxes:
        rows.setdefault(ct, []).append(v)
    if not rows:
        return ()
    seqs = [tuple(rows[ct]) for ct in sorted(rows)]
    first = seqs[0]
    if all(s == first for s in seqs):
        return first
    out = []
    for s in seqs:
        out.extend(s)
    return tuple(out)


def box_order(g):
    """棋盘那一侧的砖，按**阅读顺序**（先行后列）的颜色序列 -> 元组。没砖返回空元组。

    单排棋盘时「先行后列」等于「从左到右」，所以这跟旧的按列排在单排关卡上同值；
    多排棋盘（某一关的空位分成上下两排）才分得开，那时按列排会把两排交错，读出来是错的。
    """
    on = [(t, l, v) for (t, l), v in bricks(g).items() if on_board(g, (t, l))]
    on.sort()
    return tuple(v for _t, _l, v in on)


def slot_order(g):
    """棋盘那一侧全部**目标位**按阅读顺序 -> [(row,col,色 或 None)]。

    目标位 = 空位标记（还空着）+ 已经落了砖的位（砖的正中 2x2 就是那个位）。
    空着的位色记 None。拿它跟 panel_order 比，才知道还差哪一格。
    """
    out = []
    for (t, l) in holes(g):
        if on_board(g, (t, l)):
            out.append((t, l, None))
    for (t, l), v in bricks(g).items():
        if on_board(g, (t, l)):
            out.append((t + 1, l + 1, v))
    out.sort()
    return out


def on_board(g, rc):
    """rc 在计数条**上方**吗？—— 也就是在棋盘那一侧，而不是下面的料架那一排。

    实测过的判别：料架整排砖在计数条下方，全部目标位在计数条上方，两关都如此。
    早先用的判别是「落在棋盘外框（某个固定色的空心矩形）内部」，那个定义只在单排棋盘的
    那一关成立：另一关的棋盘分上下两排、两排的框线还是不同颜色，外框根本不是一个矩形，
    而且那一关有一块砖的颜色就等于框线色，会把外框的 bbox 撑到把料架也圈进来。
    「在计数条哪一侧」不依赖任何一关的框长什么样。
    """
    if rc is None:
        return False
    return rc[0] < bar_row(g)


#: 旧名字，留着不改依赖它的概念源码；含义见 on_board
in_box = on_board


def link_rings(g):
    """**指路环** -> {(row, col): 环色}；(row,col) 是它占住的那个目标位（环的正中 2x2）。

    形状判据：一个 4x4 窗口，外圈 12 格同色 v（v != 底色），内部 2x2 全是底色。
    砖是 4x4 **实心**，所以环和砖形状上分得开；选中环是 6x6 二十格，也分得开。

    **环不一定长在板上**：某一关的料架最后一个位上放着的就是一个环——指路环是一件**要你自己
    拿去放的料**，放在哪，被指的那块板就在读序里插在哪。所以这个词返回全帧的环（含料架上的），
    「只算板上的」那道过滤放在使用处（`_slot_items`）。

    为什么要有这个词：某一关的棋盘分成上下两块，上面那块少了一个位——那个位上不是空位标记，
    而是这么一个环，环底下还有一根同色竖管**把上面那块板的框线打穿**，接到下面那块板上。
    环色恰好等于下面那块板的框色。它不是装饰：它说「读到这里，先把那块板整排读完」。

    不用连通块找它：环、竖管、下面那块板的框线是**同一个连通块**（这就是它想表达的意思），
    所以只能按形状扫窗口。
    """
    out = {}
    n = len(g)
    for t in range(n - 3):
        for l in range(len(g[t]) - 3):
            v = g[t][l]
            if v == BG:
                continue
            border = [(t + dr, l + dc) for dr in range(4) for dc in range(4)
                      if dr in (0, 3) or dc in (0, 3)]
            if any(g[r][c] != v for (r, c) in border):
                continue
            if any(g[t + dr][l + dc] != BG for dr in (1, 2) for dc in (1, 2)):
                continue
            out[(t + 1, l + 1)] = v
    return out


def pieces(g):
    """能被拿起的**料** -> {(top_row, left_col): (kind, 色)}；kind 'brick' = 4x4 实心，'link' = 4x4 空心指路环。

    **砖不是唯一的料。** 实测：某一关的料架上摆着一个 4x4 空心环，点它，它照样被套上
    6x6 选中框；再点一个空位，它照样搬过去、原地留 2x2 标记、计数条照样吃一格——
    整套手续和砖一模一样，只是落下去的形状是空心的（正中 2x2 是底色，所以那个位
    随后被 `link_rings` 认成指路环）。

    在这个词出现之前，册子里三条概念（选中、放置、点空处不受理）全都把「料」写成
    `bricks`，于是「点在环上」被判成「点在空处」，当场吃了一条反例。
    教训跟颜色白名单那次同类：**用一关里恰好只有一种料，去定义「料」**。
    """
    out = {(t, l): ("brick", v) for (t, l), v in bricks(g).items()}
    for (r, c), v in link_rings(g).items():
        out[(r - 1, c - 1)] = ("link", v)
    return out


def piece_cells(kind, color, top, left):
    """一块料落在 (top,left) 起的 4x4 上时，那 16 格分别该是什么颜色 -> {(r,c): 色}。"""
    out = {}
    for dr in range(4):
        for dc in range(4):
            edge = dr in (0, 3) or dc in (0, 3)
            out[(top + dr, left + dc)] = color if (kind == "brick" or edge) else BG
    return out


def piece_at(g, rc):
    """点击格 rc 落在哪块料的 4x4 里 -> ((top,left), kind, 色)；不在任何料里返回 None。"""
    if rc is None:
        return None
    r, c = rc
    for (t, l), (kind, v) in pieces(g).items():
        if t <= r < t + 4 and l <= c < l + 4:
            return ((t, l), kind, v)
    return None


def piece_near(g, rc):
    """点击格 rc 落在哪块料的 **6x6 命中框**（料外扩一圈）里 -> ((top,left), kind, 色)；否则 None。"""
    if rc is None:
        return None
    r, c = rc
    for (t, l), (kind, v) in pieces(g).items():
        if t - 1 <= r < t + 5 and l - 1 <= c < l + 5:
            return ((t, l), kind, v)
    return None


def _slot_items(g):
    """棋盘那一侧全部目标位 -> [(row, col, kind, 色, 占地格子集合)]。

    位坐标一律取「正中 2x2 的左上角」：空位标记本身就是它，砖与指路环都是 (top+1, left+1)。
    """
    items = []
    for (t, l) in holes(g):
        if on_board(g, (t, l)):
            foot = {(t + dr, l + dc) for dr in range(2) for dc in range(2)}
            items.append((t, l, "empty", None, foot))
    for (t, l), v in bricks(g).items():
        if on_board(g, (t, l)):
            foot = {(t + dr, l + dc) for dr in range(4) for dc in range(4)}
            items.append((t + 1, l + 1, "brick", v, foot))
    for (r, c), v in link_rings(g).items():
        if not on_board(g, (r, c)):
            continue
        foot = {(r - 1 + dr, c - 1 + dc) for dr in range(4) for dc in range(4)}
        items.append((r, c, "link", v, foot))
    return items


def boards(g):
    """棋盘那一侧的每一块**板** -> {框色: [(row, col, kind, 色) 按阅读顺序]}。

    一块板 = 一个被单色框围起来的底色区域。**认板不按行、也不按框的形状，按「底色连通块」**：
    每个目标位贴着哪一块底色，它就属于哪块板；那块底色四周挨着最多的那个颜色就是这块板的框色。

    为什么不按行分组：某一关里一板一行，看着像「排」；下一关里两块板**并排在同一行**，
    按行分组会把它们并成一排，顺序就再也读不出来了。行是那一关的偶然，「被同一个框围着」不是。
    为什么不按框的连通块认框：指路环底下那根管子会把上下两块板的框线连成同一个连通块
    （管子还把上面那块板的框线打穿），框在几何上根本不是一个干净的矩形边界；而底色区域是。

    **投票只许框投，摆在板上的东西没有票**：板上的砖、指路环、选中环都紧贴着底色，
    它们的颜色会混进多数票里。实测语料里已经发生过一次——某一关下面那块板的框色票
    84 票里有 16 票是一块**自身颜色恰好等于框色**的在场砖投的，这次没翻票只是因为
    那块板小（位少，砖投得出的票封顶低于框线的票数）。位一多就会翻，而翻了不报错：
    位被分给错的板，`nested_order` 照样吐出一个自信的顺序，`assert_` 分不出
    「板分错了」和「顺序真摆错了」。所以把票源限死在「不属于任何目标位占地、也不是选中环」的格子上。
    """
    items = _slot_items(g)
    if not items:
        return {}
    occupied = set()
    for (_r, _c, _kind, _v, foot) in items:
        occupied |= foot
    comps = components(cells_of(g, BG))
    owner = {}
    for i, comp in enumerate(comps):
        for cell in comp:
            owner[cell] = i
    frame_votes = {}
    for i, comp in enumerate(comps):
        votes = {}
        for (r, c) in comp:
            for (rr, cc) in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if not (0 <= rr < len(g) and 0 <= cc < len(g[rr])):
                    continue
                if (rr, cc) in owner or (rr, cc) in occupied:
                    continue
                if g[rr][cc] == RING:
                    continue
                votes[g[rr][cc]] = votes.get(g[rr][cc], 0) + 1
        frame_votes[i] = votes

    out = {}
    seen_comp = {}
    for (r, c, kind, v, foot) in items:
        # 选中环会把砖整圈包住，砖的四邻一格全是环色、一格底色都挨不上。
        # 环是量出来的词，允许把它吸收进占地，再往外找底色。不吸收就会整帧弃读。
        for _ in range(3):
            shell = set()
            for (fr, fc) in foot:
                for (rr, cc) in ((fr - 1, fc), (fr + 1, fc), (fr, fc - 1), (fr, fc + 1)):
                    if (rr, cc) in foot:
                        continue
                    if 0 <= rr < len(g) and 0 <= cc < len(g[rr]):
                        shell.add((rr, cc))
            if shell and all(g[rr][cc] == RING for (rr, cc) in shell):
                foot = foot | shell
            else:
                break
        touching = set()
        for (fr, fc) in foot:
            for (rr, cc) in ((fr - 1, fc), (fr + 1, fc), (fr, fc - 1), (fr, fc + 1)):
                if (rr, cc) in foot:
                    continue
                if (rr, cc) in owner:
                    touching.add(owner[(rr, cc)])
        if len(touching) != 1:
            return {}                      # 位贴着两块底色或没贴着 -> 认不出板，别硬猜
        i = touching.pop()
        votes = frame_votes[i]
        if not votes:
            return {}
        fc_color = max(votes.items(), key=lambda kv: kv[1])[0]
        if seen_comp.setdefault(fc_color, i) != i:
            return {}                      # 两块板同一个框色 -> 环指过来分不清是哪块
        out.setdefault(fc_color, []).append((r, c, kind, v))
    for k in out:
        out[k].sort()
    return out


def nested_order(g):
    """目标位的**嵌套阅读顺序**取色 -> 元组（空位记 None）；读不出来返回 None。

    读法：从**起读板**开始，按阅读顺序走它的位；遇到指路环，就先把环色所指的那块板整块读完，
    再回来接着走。起读板 = 没有任何环指向它的那块板；**每块板都被某个环指着时**（两块板互相
    各插一个对方的环），没有这样的板，就从**最左上**的那块板起读（某一关的过关摆法就是这样：
    环9 插在板8 的末位、环8 插在板9 的末位，从板8 起读，展开进板9，环8 指回板8 时停——
    读序恰好是面板一排）。**同一块板可以被读不止一次**：有一关两个同色环同指一块板，
    面板比全部位数还长，长出的那截就是那块板又出现了一遍。
    环指回**当前展开路径上**的板时不再整段报错，而是**原地停**（那截不再产出读数）——
    「成环」在两个互相指的板上不是死局，是读法自然停下来的地方。

    返回 None 的几种情形（= 我不知道该怎么读，别硬猜）：认不出板；有**两块以上**的板没被任何环
    指到（不知道从哪块起读）；指路环的环色不对应任何一块板；读完之后**还有板没被读到**
    （它排在哪我没有依据，硬拼出来的顺序会变成一条不可判错的主张）。
    """
    bd = boards(g)
    if not bd:
        return None
    pointed = {v for slots in bd.values() for (_r, _c, kind, v) in slots if kind == "link"}
    roots = [k for k in bd if k not in pointed]
    if len(roots) > 1:
        return None
    if len(roots) == 1:
        start = roots[0]
    else:
        # 每块板都被环指着：从最左上那块起读。认板用「排序后第一块」——
        # bd 的键是框色不是位置，所以按各板第一个位的 (row, col) 排。
        start = min(bd, key=lambda k: min((r, c) for (r, c, _k, _v) in bd[k]))
    reached = {start}
    out = []

    def emit(key, path):
        if len(path) > len(bd):
            raise ValueError("嵌套太深")
        for (_r, _c, kind, v) in bd[key]:
            if kind == "link":
                if v not in bd:
                    raise ValueError("环指不到任何一块板")
                if v in path:
                    continue                    # 指回路径上的板：原地停，这截不再产出读数
                reached.add(v)
                emit(v, path | {v})
            else:
                out.append(v)

    try:
        emit(start, {start})
    except (ValueError, RecursionError):
        return None
    if reached != set(bd):
        return None
    return tuple(out)




def ring_cells(top, left):
    """套在 (top,left) 起的 4x4 砖外面的那圈环的 20 个格子。"""
    t, l = top - 1, left - 1
    return [(t + dr, l + dc) for dr in range(6) for dc in range(6)
            if dr in (0, 5) or dc in (0, 5)]


def me(g):
    """这一局没有会走动的玩家块。"""
    return None


def walls(g):
    """这一局没有阻挡语义。"""
    return None
