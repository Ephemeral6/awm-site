"""砖只搬不生不灭：任何一步之后，全图 4x4 实心砖的颜色多重集与之前完全相同。"""
LEVEL = "L1"
SCOPE = "所有动作；换关返回 NA（换关会换一套砖）。"
NOTE = ""
EVIDENCE = ["81cdf36b5cb55961", "183bbcb8aa67f763"]

from _lib import bricks


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    a = sorted(bricks(prev).values())
    b = sorted(bricks(nxt).values())
    return "TRUE" if a == b else "FALSE"
