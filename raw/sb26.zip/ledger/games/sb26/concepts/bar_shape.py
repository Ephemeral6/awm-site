"""计数条永远是同一个形状：行53 从最右端 col63 起向左连续 k 格是色3，左边其余 64-k 格全是色2，中间不留空洞。"""
LEVEL = "L4"
SCOPE = "所有动作；换关返回 NA（换关后计数条可能重置，没测过）。"
NOTE = ""
EVIDENCE = ["b6f2d85b568c9e0b", "7bccbb338bb6c2ac"]

from _lib import BAR_ROW, HOLE, USED, used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    k = used(nxt)
    row = nxt[BAR_ROW]
    for c in range(64):
        want = USED if c >= 64 - k else HOLE
        if row[c] != want:
            return "FALSE"
    return "TRUE"
