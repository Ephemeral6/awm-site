"""ACTION5 是「取消选中」：它让计数条从最右端往左多吃一格，并把当前那圈色0 环退回底色（砖本身不动）；屏幕其余每一格不变。"""
LEVEL = "L4"
SCOPE = ("只看 ACTION5；换关返回 NA；计数条已满（used>=64）返回 NA（没测过）。"
         "**`apply` 在「这一按会过关」时闭嘴**：目标位的嵌套读序已等于面板序时，整屏都会被换掉，"
         "这条概念只管没过关那一路；`assert_` 那边由「换关返回 NA」挡住同一件事。")
NOTE = ("v2：v1 说的是「只改计数条那一格」，在 f13e20580a79f061 上吃反例——那一步发 ACTION5 时"
        "有一块砖被选中，21 格帧差里 20 格是环退回底色。所以 ACTION5 不是空转，是取消选中，"
        "只不过前三次发它时本来就没有选中，看起来才像空转。"
        "**v3 改两处，都是「一关的偶然被写死」这一类**："
        "① 计数条行号原先取写死的常数，现在从帧里量（`bar_row`）——常数是第 0 关量出来的；"
        "② `apply` 原先在过关那一步照样声称「只动 1 格」，而那一步实际帧差六七百格，"
        "于是每过一关它就贡献 1~2 格**说错**。E 只数说对的，说错多少 E 不掉，"
        "所以这种错会一直挂在那儿不被任何数字追着跑——得自己去看「说错」那一栏。")
EVIDENCE = ["b6f2d85b568c9e0b", "b3148795af9da860", "f13e20580a79f061", "b87542f100f6577f"]

from _lib import BG, USED, bar_row, nested_order, panel_order, ring_cells, selected, used


def _cells(prev):
    k = used(prev)
    if k >= 64:
        return None
    out = {(bar_row(prev), 63 - k): USED}
    sel = selected(prev)
    if sel is not None:
        for cell in ring_cells(*sel):
            out[cell] = BG
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if str(action) != "ACTION5":
        return "NA"
    want = _cells(prev)
    if want is None:
        return "NA"
    for r in range(len(prev)):
        for c in range(len(prev[r])):
            expect = want.get((r, c), prev[r][c])
            if nxt[r][c] != expect:
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if str(action) != "ACTION5":
        return None
    got = nested_order(prev)
    if got is not None and got == panel_order(prev):
        return None          # 这一按会过关，整屏换掉，不是我管的那一路
    return _cells(prev)
