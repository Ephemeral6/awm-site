"""关卡只会在 ACTION5 那一步前进：动作不是 ACTION5 时，关卡号只会不动或倒退，绝不前进。"""
LEVEL = "L5"
SCOPE = ("所有动作；没有 ctx（拿不到关卡号）返回 NA。"
         "只管「非 ACTION5 不**前进**」这一半；ACTION5 什么时候换关见 [[submit_matches_panel]]。"
         "**RESET 不例外**：会话还活着时它退回本关开局态，关卡号不动（见 [[reset_refills]]）。"
         "关卡号**倒退**只在换卡之后的 RESET 上见过一次——整局归零（见 [[recard_resets_all]]）；"
         "倒退不是前进，本条在那儿照判 TRUE。")
NOTE = ("这一条是 [[win_not_board_full]] 撤册后留下来的真正内容。那条概念说的是「过关不会发生在"
        "棋盘四位全满的那一步」，被第 140 步打掉了——恰恰是棋盘全满那一步过的关，"
        "只不过它的检查器读 `nxt`（已经是下一关的布局，四位不满）因而返回 NA，侥幸没露。"
        "撤了它以后，「填满棋盘本身不过关」这句话仍然对，但正确的说法不是「棋盘满不是过关条件」，"
        "而是「换关要另按一次提交键」——那才是当初那 57 条转移真正证明了的东西。"
        "把主张挪到动作类别上，它就变成了一句管全部转移的话，而不是一句只管某种构型的话。"
        "**v2 为什么改**：换卡那条 RESET（整局归零）把 v1 的「关卡数一格不动」打掉了——"
        "第 7 关直接回到第 0 关，动得还不小。但打掉的只是「不动」这一半；"
        "主张里真正要害的那半——**前进只跟着提交键**——原样成立：没有任何非 ACTION5 动作让关卡前进过。"
        "倒退是另一件事（换卡的手续），单独立了 [[recard_resets_all]] 去管，不混在这条里。")
EVIDENCE = ["7bccbb338bb6c2ac", "7798487515ce216d", "401db47141ccaf7f",
            "63dc3df8719aef50", "93e24a63a6f61017", "da5277b10c34003c",
            "40b129c05e38ec2d", "415bbaa294f9148f"]


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if str(action).startswith("ACTION5"):
        return "NA"
    if ctx.get("level_next") is None or ctx.get("level_prev") is None:
        return "NA"
    return "TRUE" if ctx["level_next"] <= ctx["level_prev"] else "FALSE"
