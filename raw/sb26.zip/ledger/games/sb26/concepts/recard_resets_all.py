"""换卡之后的那一次 RESET 把整局退回第 0 关的开局态：关卡号归零、计数条清零、一块料都不在板上、料架上的料数正好等于目标位数。"""
LEVEL = "L4"
SCOPE = ("只看动作 RESET；别的动作返回 NA。没有 ctx、或关卡号拿不到，返回 NA。"
         "只管**关卡号倒退**的那次 RESET（level_next < level_prev）——那是会话已被回收、"
         "世界换了新卡之后的整局归零；会话还活着时 RESET 退回的是本关（关卡号不动），"
         "那件事见 [[reset_refills]]，这里返回 NA。"
         "倒退但没回到第 0 关，判 FALSE。"
         "**不声称上一局的东西去了哪**——换卡是一次切断，prev 帧属于已经结束的那一局。"
         "**未验证**：语料里只有一条这样的 RESET（终局卡上场那一步，第 7 关 → 第 0 关），"
         "「中途换卡」「GAME_OVER 后换卡」都没见过。")
NOTE = ("这条是换卡那一步逼出来的：上场的瞬间整屏 1074 格帧差，把两条旧概念同时打翻——"
        "[[reset_refills]] 的「已通过的关卡数不变」和 levelup_only_by_submit 的「关卡数一格不动」。"
        "值得记的是分界线长什么样：**同一个 RESET，两种语义，凭帧里的任何东西都分不出来**，"
        "能用的信号只有关卡号倒没倒退。装置技能里早写着「会话被回收时它才退回整局归零」，"
        "但那句话在本册子里没有对应物——直到这条转移发生，它才从一句文档变成一个可判错的对象。"
        "「同一动作名在不同会话状态下是两件手续」这个形状，别的局大概率也有。")
EVIDENCE = ["415bbaa294f9148f"]

from _lib import boards, on_board, pieces, used


def assert_(prev, action, nxt, ctx=None):
    if not str(action).upper().startswith("RESET"):
        return "NA"
    if ctx is None:
        return "NA"
    lv_p, lv_n = ctx.get("level_prev"), ctx.get("level_next")
    if lv_p is None or lv_n is None:
        return "NA"
    if lv_n >= lv_p:
        return "NA"            # 会话还活着：退回本关，不归这条管，见 [[reset_refills]]
    if lv_n != 0:
        return "FALSE"
    if used(nxt) != 0:
        return "FALSE"
    if any(on_board(nxt, tl) for tl in pieces(nxt)):
        return "FALSE"
    bd = boards(nxt)
    if bd:
        slots = [e for entries in bd.values() for e in entries]
        rack = [tl for tl in pieces(nxt) if not on_board(nxt, tl)]
        if len(rack) != len(slots):
            return "FALSE"
    return "TRUE"
