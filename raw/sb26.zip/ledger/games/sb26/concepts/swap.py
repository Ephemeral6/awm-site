"""有砖被选中时 ACTION6 点在**棋盘框内**另一块砖上：两块砖当场交换颜色（位置不动），环消失，计数条恰好多一格。"""
LEVEL = "L1"
SCOPE = ("只看带坐标的 ACTION6；换关返回 NA；prev 里没有选中砖返回 NA；"
         "点击格不落在任何砖的 6x6 命中框内返回 NA；点中的就是选中的那块砖本身返回 NA（没测过）；"
         "**选中砖与被点砖不是双双落在棋盘外框内部时返回 NA**——框外（料架）的同一动作是另一条概念；"
         "**未验证的边界（照实登记，不当成已知）**：命中转移里 used(prev) 最大只到 48/64，"
         "计数条满格附近一个样本都没有，所以「恰好多一格」在满格时会怎样这条概念说不了；"
         "砖位贴着框线内壁的情形也没有样本（四个砖位离框线都有十几格余量）。")
NOTE = ("v1 只说「点在另一块砖上」，被 6 条反例打掉：那 6 条全在料架那一排，"
        "计数条一格不动、帧差 40 格、两块砖原地不动，只是选中环从这块挪到那块——免费改选，不是交换。"
        "v2 因此把这条概念缩到棋盘外框内部（`_lib.in_box`），框外那半交给 [[reselect_free]]。"
        "**判别条件已经测掉了**：曾经分不清「框内才收费换色」和「6x6 命中框贴着才收费换色」两种读法"
        "（棋盘间距 6，相邻砖的命中框是连着的；料架间距 8，命中框之间空两列）。"
        "转移 cdc0b91a338e6916 分开了它们：选中棋盘位1、点棋盘位3，两个命中框隔着六列，照样当场换色、"
        "收费一格、环灭。所以判别条件是「在框内」。"
        "审查提了一条保留意见并记在这里：那一步中间的位2 当时是空的，所以它不是控制变量意义上"
        "最干净的实验；我的看法是命中框相邻与否纯粹是几何的，跟中间位上有没有砖无关，所以这个"
        "反驳不成立——但意见留档，等哪天位2 有砖时再点一次非相邻的位，就能把这条保留也消掉。"
        "命中框取 6x6 是因为第 22 步点的是砖正上方那格底色，仍被判成点中了那块砖。"
        "**跨框点击（选中框内的砖去点框外的砖，或反过来）语料里 0 个样本**，这条概念和 "
        "[[reselect_free]] 在那上面双双返回 NA，是一片确认过的无人区。")
EVIDENCE = ["a6faf5f9ce0389e8", "6fde4e1bafd94081",
            "16de5723172fd609", "54475046114dd478", "7a120bb2f53d8cfd",
            "8871f81405747b7f", "9ffdb051c080082b", "b588920a5ee3067d"]

from _lib import (BAR_ROW, BG, USED, brick_cells, brick_near, bricks, click,
                  holes, in_box, ring_cells, selected, used)


def _plan(prev, action):
    """返回 (sel, sel_color, tgt, tgt_color) 或 None。"""
    if not str(action).startswith("ACTION6"):
        return None
    sel = selected(prev)
    if sel is None:
        return None
    bs = bricks(prev)
    if sel not in bs:
        return None
    hit = brick_near(prev, click(action))
    if hit is None:
        return None
    (tgt, tgt_color) = hit
    if tgt == sel:
        return None
    if not (in_box(prev, sel) and in_box(prev, tgt)):
        return None
    return (sel, bs[sel], tgt, tgt_color)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    p = _plan(prev, action)
    if p is None:
        return "NA"
    sel, sel_c, tgt, tgt_c = p
    want = dict(bricks(prev))
    want[sel] = tgt_c
    want[tgt] = sel_c
    if bricks(nxt) != want:
        return "FALSE"
    if holes(nxt) != holes(prev):
        return "FALSE"
    if selected(nxt) is not None:
        return "FALSE"
    return "TRUE" if used(nxt) == used(prev) + 1 else "FALSE"


def apply(prev, action, ctx=None):
    p = _plan(prev, action)
    if p is None:
        return None
    sel, sel_c, tgt, tgt_c = p
    out = {}
    for cell in ring_cells(*sel):
        out[cell] = BG
    out[(BAR_ROW, 63 - used(prev))] = USED
    for cell in brick_cells(*sel):
        out[cell] = tgt_c
    for cell in brick_cells(*tgt):
        out[cell] = sel_c
    return out
