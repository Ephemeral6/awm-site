"""ACTION7 的效果只有三种形状，没有第四种：整帧不变；或恰好 32 格变化，且要么是一块砖挪回一个空位
（位置集合换掉一个元素、两处空位标记互换），要么是两块砖把颜色换回去（位置集合一格不动）。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION7；换关返回 NA；prev 里有砖被选中返回 NA（没测过手上有砖时撤销）。"
         "计数条不由这条概念管，见 [[undo_free]]。**不声称撤销的对象是哪一次改动**——"
         "「最近一次」需要历史，而单条转移里没有历史；这条概念只判形状，判不了指向。")
NOTE = ("v1 说撤销退回的是「搬砖」，要求位置集合换掉一个元素，被转移 a3f0b4542518958c 打掉："
        "那一步撤掉的是前一步的**框内换色**（[[swap]]），棋盘位1 由 9 退回 14、位3 由 14 退回 9，"
        "四块砖的位置一个都没动，帧差照样恰好 32 格。"
        "所以撤销的对象不是「搬砖」而是「最近一次收费的改动」——而收费的改动有两种"
        "（[[place]] 搬砖、[[swap]] 换色），撤销就有两种形状，各占 32 格：搬砖是 16+16 格分处两地，"
        "换色是 16+16 格原地对调。"
        "v2 因此改成判形状而不判指向：**枚举全部合法形状，多出一种就是反例**。"
        "这样它仍然能被打错（第三种形状、或者 32 之外的格数、或者砖色多重集变了），"
        "但不再声称自己知道被撤的是哪一步——那件事要靠 ctx 之外的历史，单条转移判不了。"
        "v1 的另一半（能连撤至少 4 层、且一格不花）在第 50-53 步四连按里测过，那半仍然成立。")
EVIDENCE = ["183bbcb8aa67f763", "322e78b686153edb", "5bdfb2ec99f32b43",
            "227b5fd93a1d166e", "680854b06968f97b", "091a8fb579c9fd16",
            "a3f0b4542518958c"]

from collections import Counter

from _lib import bricks, holes, selected


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if str(action) != "ACTION7":
        return "NA"
    if selected(prev) is not None:
        return "NA"
    if prev == nxt:
        return "TRUE"
    d = sum(1 for r in range(len(prev)) for c in range(len(prev[0]))
            if prev[r][c] != nxt[r][c])
    if d != 32:
        return "FALSE"
    bp, bn = bricks(prev), bricks(nxt)
    if Counter(bp.values()) != Counter(bn.values()):
        return "FALSE"
    if selected(nxt) is not None:
        return "FALSE"
    gone = set(bp) - set(bn)
    came = set(bn) - set(bp)
    if not gone and not came:
        # 形状二：撤换色。位置一格没动，恰好两个位上的颜色对调。
        moved = [k for k in bp if bp[k] != bn[k]]
        if len(moved) != 2:
            return "FALSE"
        a, b = moved
        if not (bp[a] == bn[b] and bp[b] == bn[a]):
            return "FALSE"
        return "TRUE" if holes(nxt) == holes(prev) else "FALSE"
    # 形状一：撤搬砖。恰好一块砖换了位置，空位标记个数不变。
    if len(gone) != 1 or len(came) != 1:
        return "FALSE"
    return "TRUE" if len(holes(nxt)) == len(holes(prev)) else "FALSE"
