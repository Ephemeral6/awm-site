"""ACTION7 从不消耗计数条：无论它这一步是被禁用（整帧不变）还是真的把上一次搬砖退回去，used 都一格不涨。"""
LEVEL = "L1"
SCOPE = "只看 ACTION7；换关返回 NA。"
NOTE = ""
EVIDENCE = ["80681062bbecbede", "183bbcb8aa67f763"]

from _lib import used


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not str(action).startswith("ACTION7"):
        return "NA"
    return "TRUE" if used(nxt) == used(prev) else "FALSE"
