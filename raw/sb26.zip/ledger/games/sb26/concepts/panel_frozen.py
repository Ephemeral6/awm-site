"""上排显示面板（行 0..7）是只读的：任何一步之后那 8 行一格不变，砖也永远不落在那里。"""
LEVEL = "L1"
SCOPE = "所有动作；换关返回 NA（换关会换一套显示）。"
NOTE = ""
EVIDENCE = ["ced2f09be7feb56a", "7bccbb338bb6c2ac"]

PANEL_ROWS = range(0, 8)


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    for r in PANEL_ROWS:
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"
