/-
# Levels —— 每一关一条定理（自动生成：`python lean2/export_levels.py`，不要手改）

    L<n>_len           这一段到底有几步（切歪了会得到空表，而空表让下一条平凡为真）
    L<n>_trace         沿着认证那一段的真实走法，**只有开局是观测给的**，模型每一帧都和观测对上
    L<n>_observed_win  观测到的过关那一步：模型在同一个局面上按同一个键，也说「过关」
    L<n>_winnable      这一关走得通 —— 见证就是那条路再加过关那一脚

后两条（`_winnable` / `_unsolvable`）不能同时有（`Proof/Reachable.lean` 的 `not_both`）；
这一局八关全都有 `_winnable`，所以没有一关是「两样都没有」的缺口。

见证取自**成绩单认证的那一段**（guid 7138129b-704a-43e0-a929-fd0808ed1c56）。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

set_option maxRecDepth 100000

-- 定理放在根命名空间：装置的公理表探针（ledger/lean_check.py）按裸名 `#print axioms`。
open Game


/-! ## 第 0 关 —— 认证段 seq 301–309：走 8 步、第 9 步按提交过关 -/

def L0_layout : Layout := Replay.layoutAt 0

/-- 第 0 关的真实开局：**从语料里读出来的**（seq 301 的前一帧），不是手写的盘。 -/
def L0_start : World := Replay.worldAt (Replay.bySeq 301).prev

/-- 开局到过关前一步，8 步，每步配观测到的下一帧。 -/
def L0_play : List (Act × World) := Replay.playFrom 301 8

theorem L0_len : (L0_play.map Prod.snd : List World).length = 8 := by decide

#eval match firstSplit L0_layout L0_start L0_play 0 with
  | none   => "L0 一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 8 帧全是模型自己算的。 -/
theorem L0_trace : traceOk L0_layout (L0_start : World) L0_play = true := by decide

/-- 观测到的过关那一步（seq 309）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L0_observed_win : (Replay.bySeq 309).obs = Replay.ObsIx.levelUp ∧
    step L0_layout (Replay.worldAt (Replay.bySeq 309).prev : World) (Replay.bySeq 309).act = Res.won := by
  decide

/-- **第 0 关走得通。** 见证：上面那 8 步，再加过关那一脚（提交）。 -/
theorem L0_winnable : Winnable L0_layout (L0_start : World) :=
  ⟨L0_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L0_len
#print axioms L0_trace
#print axioms L0_observed_win
#print axioms L0_winnable

/-! ## 第 1 关 —— 认证段 seq 310–324：走 14 步、第 15 步按提交过关 -/

def L1_layout : Layout := Replay.layoutAt 1

/-- 第 1 关的真实开局：**从语料里读出来的**（seq 310 的前一帧），不是手写的盘。 -/
def L1_start : World := Replay.worldAt (Replay.bySeq 310).prev

/-- 开局到过关前一步，14 步，每步配观测到的下一帧。 -/
def L1_play : List (Act × World) := Replay.playFrom 310 14

theorem L1_len : (L1_play.map Prod.snd : List World).length = 14 := by decide

#eval match firstSplit L1_layout L1_start L1_play 0 with
  | none   => "L1 一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 14 帧全是模型自己算的。 -/
theorem L1_trace : traceOk L1_layout (L1_start : World) L1_play = true := by decide

/-- 观测到的过关那一步（seq 324）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L1_observed_win : (Replay.bySeq 324).obs = Replay.ObsIx.levelUp ∧
    step L1_layout (Replay.worldAt (Replay.bySeq 324).prev : World) (Replay.bySeq 324).act = Res.won := by
  decide

/-- **第 1 关走得通。** 见证：上面那 14 步，再加过关那一脚（提交）。 -/
theorem L1_winnable : Winnable L1_layout (L1_start : World) :=
  ⟨L1_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L1_len
#print axioms L1_trace
#print axioms L1_observed_win
#print axioms L1_winnable

/-! ## 第 2 关 —— 认证段 seq 325–339：走 14 步、第 15 步按提交过关 -/

def L2_layout : Layout := Replay.layoutAt 2

/-- 第 2 关的真实开局：**从语料里读出来的**（seq 325 的前一帧），不是手写的盘。 -/
def L2_start : World := Replay.worldAt (Replay.bySeq 325).prev

/-- 开局到过关前一步，14 步，每步配观测到的下一帧。 -/
def L2_play : List (Act × World) := Replay.playFrom 325 14

theorem L2_len : (L2_play.map Prod.snd : List World).length = 14 := by decide

#eval match firstSplit L2_layout L2_start L2_play 0 with
  | none   => "L2 一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 14 帧全是模型自己算的。 -/
theorem L2_trace : traceOk L2_layout (L2_start : World) L2_play = true := by decide

/-- 观测到的过关那一步（seq 339）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L2_observed_win : (Replay.bySeq 339).obs = Replay.ObsIx.levelUp ∧
    step L2_layout (Replay.worldAt (Replay.bySeq 339).prev : World) (Replay.bySeq 339).act = Res.won := by
  decide

/-- **第 2 关走得通。** 见证：上面那 14 步，再加过关那一脚（提交）。 -/
theorem L2_winnable : Winnable L2_layout (L2_start : World) :=
  ⟨L2_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L2_len
#print axioms L2_trace
#print axioms L2_observed_win
#print axioms L2_winnable

/-! ## 第 3 关 —— 认证段 seq 340–354：走 14 步、第 15 步按提交过关 -/

def L3_layout : Layout := Replay.layoutAt 3

/-- 第 3 关的真实开局：**从语料里读出来的**（seq 340 的前一帧），不是手写的盘。 -/
def L3_start : World := Replay.worldAt (Replay.bySeq 340).prev

/-- 开局到过关前一步，14 步，每步配观测到的下一帧。 -/
def L3_play : List (Act × World) := Replay.playFrom 340 14

theorem L3_len : (L3_play.map Prod.snd : List World).length = 14 := by decide

#eval match firstSplit L3_layout L3_start L3_play 0 with
  | none   => "L3 一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 14 帧全是模型自己算的。 -/
theorem L3_trace : traceOk L3_layout (L3_start : World) L3_play = true := by decide

/-- 观测到的过关那一步（seq 354）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L3_observed_win : (Replay.bySeq 354).obs = Replay.ObsIx.levelUp ∧
    step L3_layout (Replay.worldAt (Replay.bySeq 354).prev : World) (Replay.bySeq 354).act = Res.won := by
  decide

/-- **第 3 关走得通。** 见证：上面那 14 步，再加过关那一脚（提交）。 -/
theorem L3_winnable : Winnable L3_layout (L3_start : World) :=
  ⟨L3_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L3_len
#print axioms L3_trace
#print axioms L3_observed_win
#print axioms L3_winnable

/-! ## 第 4 关 —— 认证段 seq 355–371：走 16 步、第 17 步按提交过关 -/

def L4_layout : Layout := Replay.layoutAt 4

/-- 第 4 关的真实开局：**从语料里读出来的**（seq 355 的前一帧），不是手写的盘。 -/
def L4_start : World := Replay.worldAt (Replay.bySeq 355).prev

/-- 开局到过关前一步，16 步，每步配观测到的下一帧。 -/
def L4_play : List (Act × World) := Replay.playFrom 355 16

theorem L4_len : (L4_play.map Prod.snd : List World).length = 16 := by decide

#eval match firstSplit L4_layout L4_start L4_play 0 with
  | none   => "L4 一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 16 帧全是模型自己算的。 -/
theorem L4_trace : traceOk L4_layout (L4_start : World) L4_play = true := by decide

/-- 观测到的过关那一步（seq 371）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L4_observed_win : (Replay.bySeq 371).obs = Replay.ObsIx.levelUp ∧
    step L4_layout (Replay.worldAt (Replay.bySeq 371).prev : World) (Replay.bySeq 371).act = Res.won := by
  decide

/-- **第 4 关走得通。** 见证：上面那 16 步，再加过关那一脚（提交）。 -/
theorem L4_winnable : Winnable L4_layout (L4_start : World) :=
  ⟨L4_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L4_len
#print axioms L4_trace
#print axioms L4_observed_win
#print axioms L4_winnable

/-! ## 第 5 关 —— 认证段 seq 372–390：走 18 步、第 19 步按提交过关 -/

def L5_layout : Layout := Replay.layoutAt 5

/-- 第 5 关的真实开局：**从语料里读出来的**（seq 372 的前一帧），不是手写的盘。 -/
def L5_start : World := Replay.worldAt (Replay.bySeq 372).prev

/-- 开局到过关前一步，18 步，每步配观测到的下一帧。 -/
def L5_play : List (Act × World) := Replay.playFrom 372 18

theorem L5_len : (L5_play.map Prod.snd : List World).length = 18 := by decide

#eval match firstSplit L5_layout L5_start L5_play 0 with
  | none   => "L5 一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 18 帧全是模型自己算的。 -/
theorem L5_trace : traceOk L5_layout (L5_start : World) L5_play = true := by decide

/-- 观测到的过关那一步（seq 390）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L5_observed_win : (Replay.bySeq 390).obs = Replay.ObsIx.levelUp ∧
    step L5_layout (Replay.worldAt (Replay.bySeq 390).prev : World) (Replay.bySeq 390).act = Res.won := by
  decide

/-- **第 5 关走得通。** 见证：上面那 18 步，再加过关那一脚（提交）。 -/
theorem L5_winnable : Winnable L5_layout (L5_start : World) :=
  ⟨L5_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L5_len
#print axioms L5_trace
#print axioms L5_observed_win
#print axioms L5_winnable

/-! ## 第 6 关 —— 认证段 seq 391–407：走 16 步、第 17 步按提交过关 -/

def L6_layout : Layout := Replay.layoutAt 6

/-- 第 6 关的真实开局：**从语料里读出来的**（seq 391 的前一帧），不是手写的盘。 -/
def L6_start : World := Replay.worldAt (Replay.bySeq 391).prev

/-- 开局到过关前一步，16 步，每步配观测到的下一帧。 -/
def L6_play : List (Act × World) := Replay.playFrom 391 16

theorem L6_len : (L6_play.map Prod.snd : List World).length = 16 := by decide

#eval match firstSplit L6_layout L6_start L6_play 0 with
  | none   => "L6 一处都没分家（共 " ++ toString L6_play.length ++ " 步）"
  | some i => "L6 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 16 帧全是模型自己算的。 -/
theorem L6_trace : traceOk L6_layout (L6_start : World) L6_play = true := by decide

/-- 观测到的过关那一步（seq 407）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L6_observed_win : (Replay.bySeq 407).obs = Replay.ObsIx.levelUp ∧
    step L6_layout (Replay.worldAt (Replay.bySeq 407).prev : World) (Replay.bySeq 407).act = Res.won := by
  decide

/-- **第 6 关走得通。** 见证：上面那 16 步，再加过关那一脚（提交）。 -/
theorem L6_winnable : Winnable L6_layout (L6_start : World) :=
  ⟨L6_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L6_len
#print axioms L6_trace
#print axioms L6_observed_win
#print axioms L6_winnable

/-! ## 第 7 关 —— 认证段 seq 408–424：走 16 步、第 17 步按提交过关 -/

def L7_layout : Layout := Replay.layoutAt 7

/-- 第 7 关的真实开局：**从语料里读出来的**（seq 408 的前一帧），不是手写的盘。 -/
def L7_start : World := Replay.worldAt (Replay.bySeq 408).prev

/-- 开局到过关前一步，16 步，每步配观测到的下一帧。 -/
def L7_play : List (Act × World) := Replay.playFrom 408 16

theorem L7_len : (L7_play.map Prod.snd : List World).length = 16 := by decide

#eval match firstSplit L7_layout L7_start L7_play 0 with
  | none   => "L7 一处都没分家（共 " ++ toString L7_play.length ++ " 步）"
  | some i => "L7 第 " ++ toString i ++ " 步分家"

/-- **模型沿着这条路一步不差**：只有开局那一帧是观测给的，后面 16 帧全是模型自己算的。 -/
theorem L7_trace : traceOk L7_layout (L7_start : World) L7_play = true := by decide

/-- 观测到的过关那一步（seq 424）：模型在那一帧上按同一个键，也说「过关」。 -/
theorem L7_observed_win : (Replay.bySeq 424).obs = Replay.ObsIx.levelUp ∧
    step L7_layout (Replay.worldAt (Replay.bySeq 424).prev : World) (Replay.bySeq 424).act = Res.won := by
  decide

/-- **第 7 关走得通。** 见证：上面那 16 步，再加过关那一脚（提交）。 -/
theorem L7_winnable : Winnable L7_layout (L7_start : World) :=
  ⟨L7_play.map Prod.fst ++ [Act.submit], by decide⟩

#print axioms L7_len
#print axioms L7_trace
#print axioms L7_observed_win
#print axioms L7_winnable

