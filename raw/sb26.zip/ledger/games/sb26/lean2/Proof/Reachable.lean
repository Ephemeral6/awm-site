/-
# Reachable —— 这个**局面**做不做得了

    Winnable   L w  :=  ∃ as, 照着走中途赢过
    Unsolvable L w  :=  ∀ as, 照着走从没赢过

## 明写的削弱（三处都写：这里、`Step.lean`、页面）

`step` 在撤销、重开、跨侧点料那几支返回 `Res.unknown`，`everWon` 在那一支返回 `false`。
所以 `Unsolvable` 的准确意思是：**不经过撤销、重开、跨侧点料就赢不了**。
`∀ as` 这个形状一个字都看不出来，所以写在这里。

## 这一局八关全都走得通

语料是通关局，每一关都有 `L<n>_winnable`（`Proof/Levels.lean`），所以这一份里**没有任何一关的「走不通」**。
这一份只放骨架和一把钥匙，钥匙配三条防线，用两张手造的小盘讲清楚它在说什么 ——
**骨架与规模无关，不枚举任何状态**。

动作不用限死：这一局的动作不是位移，点在 64×64 之外的格只是「点空处」，不会「一步跨过去」。
-/

import Obj.World
import Step
import Derived.LevelOnlyBySubmit

-- 定理放在根命名空间：装置的公理表探针按裸名 `#print axioms`。
open Game

/-- 从 `w` 出发照着 `as` 走，中途有没有哪一步过了关。说不出话的那一支算没赢。 -/
def everWon (L : Layout) : World → List Act → Bool
  | _, [] => false
  | w, a :: rest =>
    match step L w a with
    | Res.won => true
    | Res.ok w' => everWon L w' rest
    | Res.unknown => false

def Winnable (L : Layout) (w : World) : Prop := ∃ as : List Act, everWon L w as = true

def Unsolvable (L : Layout) (w : World) : Prop := ∀ as : List Act, everWon L w as = false

/-- 两句话不能同时成立。 -/
theorem not_both (L : Layout) (w : World) (h1 : Winnable L w) (h2 : Unsolvable L w) : False := by
  obtain ⟨as, h⟩ := h1
  rw [h2 as] at h
  cases h

/-! ## 骨架：不变量 ⇒ 赢不了（全文唯一做归纳的地方） -/

theorem unsolvable_of_invariant (L : Layout) (P : World → Prop)
    (hkeep : ∀ w w' a, P w → step L w a = Res.ok w' → P w')
    (hwin : ∀ w a, P w → step L w a ≠ Res.won) :
    ∀ w : World, P w → Unsolvable L w := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everWon]
    cases hstep : step L w a with
    | won => exact absurd hstep (hwin w a hp)
    | unknown => rfl
    | ok w' => exact ih w' (hkeep w w' a hp hstep)

/-! ## 钥匙：版面上起读板不是恰好一块 ⇒ 读序永远读不出 ⇒ 永远赢不了

这把钥匙是**版面**上的性质，所以「每一步保持」是白给的（版面在状态之外，一步碰不到它）；
要干活的只有「与目标矛盾」那一半。 -/

/-- 钥匙 Φ。写成「局面的性质」（骨架要 `World → Prop`），但它只看版面 —— 局面那个参数不用。 -/
abbrev NoSingleRoot (L : Layout) (_w : World) : Prop := (L.boards.filter (fun b => b.root)).length ≠ 1

/-- 走不坏：版面不在状态里，一步碰不到它。 -/
theorem no_root_keep (L : Layout) :
    ∀ w w' a, NoSingleRoot L w → step L w a = Res.ok w' → NoSingleRoot L w' :=
  fun _ _ _ h _ => h

theorem reading_none (L : Layout) (w : World) (h : NoSingleRoot L w) : reading L w = none := by
  unfold reading
  split
  · rename_i r hr
    simp only [NoSingleRoot, hr] at h
    exact absurd rfl h
  · rfl

/-- 与目标矛盾：能产出「过关」的只有提交（`level_only_by_submit`），而读序读不出时提交不过关。 -/
theorem no_root_no_win (L : Layout) :
    ∀ w a, NoSingleRoot L w → step L w a ≠ Res.won := by
  intro w a h hs
  have := level_only_by_submit L w a hs
  subst this
  simp only [step, Submit.apply, isGoal, reading_none L w h] at hs
  cases hs

/-- 挂上骨架：这一条没有证明体，三样东西拼起来而已。 -/
theorem unsolvable_no_root (L : Layout) (w : World) (h : NoSingleRoot L w) : Unsolvable L w :=
  unsolvable_of_invariant L (NoSingleRoot L) (no_root_keep L) (no_root_no_win L) w h

/-! ## 防线：两张只差一处的小盘

    sceneOK     一块起读板一个位，料架上一块砖，面板要那块砖的颜色 —— 赢得了
    sceneStuck  **只改一处**：那块板的角标没了（root := false）—— 按钥匙赢不了

三条缺一不可：对照盘赢得了（`_winnable`）、不是一开始就通（`_closed_at_start`）、
钥匙的前提在对照盘上**真的不满足**（`_not_key`）—— 最后一条把「钥匙套不上」钉在
「前提不满足」，而不是「没找到证明」。 -/

def sceneOK : Layout :=
  { target := [9], boards := [{ frame := 8, root := true, slots := [⟨10, 10⟩] }], rack := [⟨58, 10⟩] }

def sceneStuck : Layout :=
  { target := [9], boards := [{ frame := 8, root := false, slots := [⟨10, 10⟩] }], rack := [⟨58, 10⟩] }

def sceneStart : World :=
  { pieces := [(⟨58, 10⟩, { kind := Kind.brick, color := 9 })], sel := none, used := 0 }

/-- 对照盘赢得了：点料架上的砖、点板上的空位、提交。 -/
theorem sceneOK_winnable : Winnable sceneOK (sceneStart : World) :=
  ⟨[Act.click ⟨58, 10⟩, Act.click ⟨10, 10⟩, Act.submit], by decide⟩

/-- 对照盘不是一开始就通：开局按提交不过关。 -/
theorem sceneOK_closed_at_start : isGoal sceneOK (sceneStart : World) = false := by decide

/-- 钥匙的前提在对照盘上真的不满足。 -/
theorem sceneOK_not_key : ¬ NoSingleRoot sceneOK (sceneStart : World) := by decide

/-- 只差一处的那张盘：**任何走法都赢不了**（不经过撤销、重开、跨侧点料）。 -/
theorem sceneStuck_unsolvable : Unsolvable sceneStuck (sceneStart : World) :=
  unsolvable_no_root sceneStuck sceneStart (by decide)

/-- 同一串走法在只差一处的那张盘上赢不了 —— 与上面那条 `_winnable` 放在一起看。 -/
theorem sceneStuck_same_moves : everWon sceneStuck (sceneStart : World)
    [Act.click ⟨58, 10⟩, Act.click ⟨10, 10⟩, Act.submit] = false := by decide

#print axioms not_both
#print axioms unsolvable_of_invariant
#print axioms no_root_keep
#print axioms reading_none
#print axioms no_root_no_win
#print axioms unsolvable_no_root
#print axioms sceneOK_winnable
#print axioms sceneOK_closed_at_start
#print axioms sceneOK_not_key
#print axioms sceneStuck_unsolvable
#print axioms sceneStuck_same_moves
