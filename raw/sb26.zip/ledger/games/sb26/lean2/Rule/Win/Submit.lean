/-
# submit（对应 `rule/win/submit.py`）—— **定义**

按提交：读序等于面板（`isGoal`）⟺ 过关；不等时选中消失、计数条 +1、别的一格不变。
「过关」是一个 `Res.won`，**不带下一帧** —— 下一关长什么样模型不描述（编一个出来比说不知道更糟）。
-/

import Obj.Derive.Reading

namespace Game
namespace Submit

def apply (L : Layout) (w : World) : Res :=
  if isGoal L w then Res.won
  else Res.ok { w with sel := none, used := w.used + 1 }

end Submit
end Game
