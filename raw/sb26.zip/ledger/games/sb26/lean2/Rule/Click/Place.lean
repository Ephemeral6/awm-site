/-
# place（对应 `rule/click/place.py`）—— **定义**

手上有料（在位 `s`）时点中一个空位 `t`：两位互换内容，选中消失，计数条 +1。
-/

import Obj.Derive.Hit
import Obj.Derive.Moves

namespace Game
namespace Place

def scope (_L : Layout) (w : World) (t : Cell) : Bool :=
  w.sel.isSome && w.sel != some t && (w.pieceAt t).isNone

def apply (w : World) (s t : Cell) : World :=
  { pieces := exchange w.pieces s t, sel := none, used := w.used + 1 }

end Place
end Game
