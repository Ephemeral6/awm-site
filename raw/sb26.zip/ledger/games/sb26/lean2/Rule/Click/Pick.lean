/-
# pick（对应 `rule/click/pick.py`）—— **定义**

手上没料时点中一块料：选中它，别的一格不变。
`t` 是点中的那一位（由 `hit` 给出）。
-/

import Obj.Derive.Hit

namespace Game
namespace Pick

def scope (_L : Layout) (w : World) (t : Cell) : Bool :=
  w.sel.isNone && (w.pieceAt t).isSome

def apply (w : World) (t : Cell) : World :=
  { w with sel := some t }

end Pick
end Game
