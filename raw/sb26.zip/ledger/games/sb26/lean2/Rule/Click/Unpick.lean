/-
# unpick（对应 `rule/click/unpick.py`）—— **定义**

手上有料时点中它自己：取消选中，别的一格不变（免费）。
-/

import Obj.Derive.Hit

namespace Game
namespace Unpick

def scope (_L : Layout) (w : World) (t : Cell) : Bool :=
  w.sel == some t

def apply (w : World) : World :=
  { w with sel := none }

end Unpick
end Game
