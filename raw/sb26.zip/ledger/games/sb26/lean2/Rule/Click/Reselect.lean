/-
# reselect（对应 `rule/click/reselect.py`）—— **定义**

选中的料在料架上、点中料架上另一块料：选中挪过去，料不动（免费）。
-/

import Obj.Derive.Hit

namespace Game
namespace Reselect

def scope (L : Layout) (w : World) (t : Cell) : Bool :=
  match w.sel with
  | some s => s != t && (w.pieceAt t).isSome && !L.onBoard s && !L.onBoard t
  | none => false

def apply (w : World) (t : Cell) : World :=
  { w with sel := some t }

end Reselect
end Game
