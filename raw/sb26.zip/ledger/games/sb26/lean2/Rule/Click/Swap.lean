/-
# swap（对应 `rule/click/swap.py`）—— **定义**

选中的料在板上、点中板上另一块料：两位互换内容，选中消失，计数条 +1。
和 `place` 用同一个算子 `exchange`。
-/

import Obj.Derive.Hit
import Obj.Derive.Moves

namespace Game
namespace Swap

def scope (L : Layout) (w : World) (t : Cell) : Bool :=
  match w.sel with
  | some s => s != t && (w.pieceAt t).isSome && L.onBoard s && L.onBoard t
  | none => false

def apply (w : World) (s t : Cell) : World :=
  { pieces := exchange w.pieces s t, sel := none, used := w.used + 1 }

end Swap
end Game
