/-
# void_click（对应 `rule/click/void_click.py`）—— **定义**

点空处（哪一位的命中框都不中）：世界一格不变，选中不丢。
-/

import Obj.Derive.Hit

namespace Game
namespace VoidClick

def scope (L : Layout) (w : World) (c : Cell) : Bool :=
  (hit L w c).isNone

def apply (w : World) : World := w

end VoidClick
end Game
