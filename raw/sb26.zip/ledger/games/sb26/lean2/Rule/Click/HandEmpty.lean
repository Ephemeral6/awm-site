/-
# hand_empty（对应 `rule/click/hand_empty.py`）—— **定义**

手上没料时点中一个空位：不受理，世界一格不变。
-/

import Obj.Derive.Hit

namespace Game
namespace HandEmpty

def scope (_L : Layout) (w : World) (t : Cell) : Bool :=
  w.sel.isNone && (w.pieceAt t).isNone

def apply (w : World) : World := w

end HandEmpty
end Game
