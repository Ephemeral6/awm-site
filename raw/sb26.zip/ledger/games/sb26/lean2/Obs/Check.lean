/-
# Check —— **判据层**：两把尺子，**0 条定理**（尺子不自证）

    agrees    一条转移：从**观测到的那一帧**算一步，和看到的下一帧比（三值）
    traceOk   一整条路：只有开局是观测给的，**后面全是模型自己算的**，逐帧比

两把尺子都只在这里定义一次；逐条（`Obs/Corpus.lean`）和每关（`Proof/Levels.lean`）都从这里拿。
`agrees` 把模型当参数传进来，破坏测试可以换一个坏模型去量同一份语料。
-/

import Step

namespace Game

/-- 三值：对上了 / 对不上 / 模型说不出话。**`na` 不是 `yes`。** -/
inductive Verdict where
  | yes
  | no
  | na
deriving DecidableEq, Repr, Inhabited

/-- 观测到的结果：同一关的下一帧（读成世界），或者换关了（下一帧是另一张盘 / 终局画面）。 -/
inductive Obs where
  | same (w : World)
  | levelUp
deriving DecidableEq, Repr, Inhabited

/-- 一条转移对不对。**每一支都对上一种观测**，没有「算不出来就算它对」那一支。 -/
def agrees (f : Layout → World → Act → Res) (L : Layout) (w : World) (a : Act) (o : Obs) : Verdict :=
  match f L w a, o with
  | Res.ok w', Obs.same v => if w'.same v then Verdict.yes else Verdict.no
  | Res.won, Obs.levelUp => Verdict.yes
  | Res.unknown, _ => Verdict.na
  | _, _ => Verdict.no

/-- 从 `w` 出发沿 `play` 走，每一步都和当时看到的那一帧比。下一轮喂进去的是**模型算出来的**状态。 -/
def traceOk (L : Layout) : World → List (Act × World) → Bool
  | _, [] => true
  | w, (a, o) :: rest =>
    match step L w a with
    | Res.ok w' => w'.same o && traceOk L w' rest
    | _ => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。它是读数不是定理。 -/
def firstSplit (L : Layout) : World → List (Act × World) → Nat → Option Nat
  | _, [], _ => none
  | w, (a, o) :: rest, i =>
    match step L w a with
    | Res.ok w' => if w'.same o then firstSplit L w' rest (i + 1) else some i
    | _ => some i

end Game
