/-
# Corpus —— 模型面对**每一条**真实转移（第三条腿的 ①）

每一步都从**观测到的那一帧**起算一步，和看到的下一帧比（`agrees`，三值）。
数据全部从 `Obs/Replay.lean` 切 —— 这里一个字面量都不存。

`#eval` 那几行是**读数**（走求值器，不进可信基）；结论另写成走内核的定理（`decide`）。
`verdictBy` 把模型当参数：破坏测试换一个坏模型量同一份语料，这几条定理就该编不过。
-/

import Obj.World
import Obs.Replay

set_option maxRecDepth 100000

namespace Game
namespace Corpus

open Replay in
def verdictBy (f : Layout → World → Act → Res) (s : Replay.Step) : Verdict :=
  agrees f (layoutAt s.lvl) (worldAt s.prev) s.act (obsOf s.obs)

def count (f : Layout → World → Act → Res) (v : Verdict) : Nat :=
  (Replay.steps.filter (fun s => verdictBy f s == v)).length

#eval "CORPUS yes=" ++ toString (count step Verdict.yes) ++ " no=" ++ toString (count step Verdict.no) ++
  " na=" ++ toString (count step Verdict.na) ++ " of " ++ toString Replay.steps.length

-- 逐条判决，给 `verify.py` 和 Python 那一份对账用（读数，不是定理）。
#eval "VERDICTS " ++ String.intercalate "," (Replay.steps.map (fun s =>
  toString s.seq ++ ":" ++ (match verdictBy step s with
    | Verdict.yes => "y" | Verdict.no => "n" | Verdict.na => "a")))

end Corpus
end Game

-- 定理放在根命名空间：装置的公理表探针按裸名 `#print axioms`。
open Game

/-- **模型没被语料驳倒**：全部收进来的真实转移上，判「对不上」的一条都没有。走内核。 -/
theorem corpus_no_mismatch : Corpus.count step Verdict.no = 0 := by decide

/-- 对上了多少条（与上面那条放在一起看：0 判错不是因为模型全在闭嘴）。 -/
theorem corpus_yes : Corpus.count step Verdict.yes = 413 := by decide

/-- 模型说不出话的多少条（撤销与会话内重开 —— 要历史，不进模型；`verify.py` 拿它和 Python 那两条规则的论域对账）。 -/
theorem corpus_na : Corpus.count step Verdict.na = 10 := by decide

#print axioms corpus_no_mismatch
#print axioms corpus_yes
#print axioms corpus_na
