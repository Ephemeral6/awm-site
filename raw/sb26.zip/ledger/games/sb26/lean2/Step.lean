/-
# Step —— 一步怎么走：**只做分发，0 条定理**

点击按「点中了什么 × 手上有没有料」分给七条规则；提交给 `Submit`；
撤销、重开、跨侧点料（语料 0 次）→ `Res.unknown`：**模型在那一步说不出话**。

说不出话的那几支会**悄悄削弱**「赢不了」：`Unsolvable` 的准确意思是
「**不经过撤销、重开、跨侧点料**就赢不了」（见 `Proof/Reachable.lean`）。
-/

import Rule.Click.Pick
import Rule.Click.HandEmpty
import Rule.Click.VoidClick
import Rule.Click.Unpick
import Rule.Click.Place
import Rule.Click.Swap
import Rule.Click.Reselect
import Rule.Win.Submit

namespace Game

def clickStep (L : Layout) (w : World) (c : Cell) : Res :=
  match hit L w c with
  | none => Res.ok (VoidClick.apply w)
  | some t =>
    if Pick.scope L w t then Res.ok (Pick.apply w t)
    else if HandEmpty.scope L w t then Res.ok (HandEmpty.apply w)
    else if Unpick.scope L w t then Res.ok (Unpick.apply w)
    else match w.sel with
      | none => Res.unknown
      | some s =>
        if Place.scope L w t then Res.ok (Place.apply w s t)
        else if Swap.scope L w t then Res.ok (Swap.apply w s t)
        else if Reselect.scope L w t then Res.ok (Reselect.apply w t)
        else Res.unknown

def step (L : Layout) (w : World) : Act → Res
  | Act.click c => clickStep L w c
  | Act.submit => Submit.apply L w
  | Act.undo => Res.unknown
  | Act.reset => Res.unknown

end Game
