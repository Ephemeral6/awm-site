/-
# pieces_conserved（对应 `rule/invariant/pieces_conserved.py`）—— **推论**

「料不生不灭」：唯一改料的算子 `exchange` 只改位、不改料，所以一步之后
「料的清单（去掉位号）」逐项相等 —— 比多重集相等还强。对所有局面证。
-/

import Obj.World
import Step

-- 定理放在根命名空间：装置的公理表探针按裸名 `#print axioms`。
open Game

/-- 互换只改位、不改料（对任意局面的料表）。 -/
theorem exchange_pieces (w : World) (a b : Cell) :
    (exchange w.pieces a b).map Prod.snd = w.pieces.map Prod.snd := by
  simp [exchange, Function.comp_def]

theorem pieces_conserved (L : Layout) (w w' : World) (a : Act) (h : step L w a = Res.ok w') :
    w'.pieces.map Prod.snd = w.pieces.map Prod.snd := by
  cases a with
  | click c =>
    simp only [step, clickStep] at h
    split at h
    · cases h; rfl
    · split at h
      · cases h; rfl
      · split at h
        · cases h; rfl
        · split at h
          · cases h; rfl
          · split at h
            · cases h
            · split at h
              · cases h; exact exchange_pieces _ _ _
              · split at h
                · cases h; exact exchange_pieces _ _ _
                · split at h
                  · cases h; rfl
                  · cases h
  | submit =>
    simp only [step, Submit.apply] at h
    split at h
    · cases h
    · cases h; rfl
  | undo => simp [step] at h
  | reset => simp [step] at h

#print axioms exchange_pieces
#print axioms pieces_conserved
