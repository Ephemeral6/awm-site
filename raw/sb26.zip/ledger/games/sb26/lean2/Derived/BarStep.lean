/-
# bar_step（对应 `rule/invariant/bar_step.py`）—— **推论**

「同一次尝试之内计数条每步要么不动、要么 +1」不是一条独立的规则：
`Step` 里每一支要么原样留着 `used`，要么 `+1`。这里对**所有**版面、局面、动作证它 ——
不是对语料证。重开那一步在模型里是 `unknown`（不产生下一个局面），所以不在这句话里。
-/

import Obj.World
import Step

-- 定理放在根命名空间：装置的公理表探针（ledger/lean_check.py）按裸名 `#print axioms`。
open Game

theorem bar_step (L : Layout) (w w' : World) (a : Act) (h : step L w a = Res.ok w') :
    w'.used = w.used ∨ w'.used = w.used + 1 := by
  cases a with
  | click c =>
    simp only [step, clickStep] at h
    split at h
    · cases h; exact Or.inl rfl
    · split at h
      · cases h; exact Or.inl rfl
      · split at h
        · cases h; exact Or.inl rfl
        · split at h
          · cases h; exact Or.inl rfl
          · split at h
            · cases h
            · split at h
              · cases h; exact Or.inr rfl
              · split at h
                · cases h; exact Or.inr rfl
                · split at h
                  · cases h; exact Or.inl rfl
                  · cases h
  | submit =>
    simp only [step, Submit.apply] at h
    split at h
    · cases h
    · cases h; exact Or.inr rfl
  | undo => simp [step] at h
  | reset => simp [step] at h

#print axioms bar_step
