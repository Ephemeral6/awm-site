/-
# level_only_by_submit（对应 `rule/invariant/level_only_by_submit.py`）—— **推论**

「只有提交能过关」：`Step` 里唯一产出 `Res.won` 的一支是提交。对所有局面证。
-/

import Obj.World
import Step

-- 定理放在根命名空间：装置的公理表探针按裸名 `#print axioms`。
open Game

theorem level_only_by_submit (L : Layout) (w : World) (a : Act) (h : step L w a = Res.won) :
    a = Act.submit := by
  cases a with
  | click c =>
    simp only [step, clickStep] at h
    split at h
    · cases h
    · split at h
      · cases h
      · split at h
        · cases h
        · split at h
          · cases h
          · split at h
            · cases h
            · split at h
              · cases h
              · split at h
                · cases h
                · split at h
                  · cases h
                  · cases h
  | submit => rfl
  | undo => simp [step] at h
  | reset => simp [step] at h

#print axioms level_only_by_submit
