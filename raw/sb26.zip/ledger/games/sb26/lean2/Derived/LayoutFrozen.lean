/-
# layout_frozen（对应 `rule/invariant/layout_frozen.py`）—— **推论**

它有两半：

1. **「走一步版面不变」—— 表示不出来，不用证。** `step : Layout → World → Act → Res`，
   返回值里没有 `Layout`。Python 那一侧对着语料核的 target / boards / rack 三位，
   在这里根本不在状态里。
2. **「料只落在版面给出的位上」—— 要证。** 版面不变，还得料不跑到版面之外去：
   一步之后，每块料的位、以及选中的那一位，仍然都在 `L.locs` 里。下面这条对所有局面证。
-/

import Obj.World
import Step

-- 定理放在根命名空间：装置的公理表探针按裸名 `#print axioms`。
open Game

/-- 料和选中都落在版面给出的位上。 -/
def WellPlaced (L : Layout) (w : World) : Prop :=
  (∀ x ∈ w.pieces, x.1 ∈ L.locs) ∧ (∀ s, w.sel = some s → s ∈ L.locs)

theorem hit_mem (L : Layout) (w : World) (c t : Cell) (h : hit L w c = some t) : t ∈ L.locs :=
  List.mem_of_find?_eq_some h

theorem exchange_mem (L : Layout) (w : World) (a b : Cell)
    (hp : ∀ x ∈ w.pieces, x.1 ∈ L.locs) (ha : a ∈ L.locs) (hb : b ∈ L.locs) :
    ∀ x ∈ exchange w.pieces a b, x.1 ∈ L.locs := by
  intro x hx
  simp only [exchange, List.mem_map] at hx
  obtain ⟨y, hy, rfl⟩ := hx
  simp only [swapCell]
  split
  · exact hb
  · split
    · exact ha
    · exact hp y hy

theorem layout_frozen (L : Layout) (w w' : World) (a : Act)
    (hw : WellPlaced L w) (h : step L w a = Res.ok w') : WellPlaced L w' := by
  obtain ⟨hp, hs⟩ := hw
  cases a with
  | click c =>
    simp only [step, clickStep] at h
    split at h
    · cases h; exact ⟨hp, hs⟩
    · rename_i t ht
      have htm := hit_mem L w c t ht
      split at h
      · cases h
        refine ⟨hp, ?_⟩
        intro s hs'
        simp only [Pick.apply] at hs'
        cases hs'; exact htm
      · split at h
        · cases h; exact ⟨hp, hs⟩
        · split at h
          · cases h
            refine ⟨hp, ?_⟩
            intro s hs'
            simp [Unpick.apply] at hs'
          · split at h
            · cases h
            · rename_i s hsel
              have hsm := hs s hsel
              split at h
              · cases h
                refine ⟨exchange_mem L w s t hp hsm htm, ?_⟩
                intro s' hs'
                simp [Place.apply] at hs'
              · split at h
                · cases h
                  refine ⟨exchange_mem L w s t hp hsm htm, ?_⟩
                  intro s' hs'
                  simp [Swap.apply] at hs'
                · split at h
                  · cases h
                    refine ⟨hp, ?_⟩
                    intro s' hs'
                    simp only [Reselect.apply] at hs'
                    cases hs'; exact htm
                  · cases h
  | submit =>
    simp only [step, Submit.apply] at h
    split at h
    · cases h
    · cases h
      refine ⟨hp, ?_⟩
      intro s hs'
      simp at hs'
  | undo => simp [step] at h
  | reset => simp [step] at h

#print axioms hit_mem
#print axioms exchange_mem
#print axioms layout_frozen
