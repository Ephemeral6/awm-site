"""光标框住的那一串里，ACTION1 让每一格的**形状相位** +1，ACTION2 让它 -1（模 7），
所在的形状族始终不变。

这是 wheels 那条「具体环」主张里活下来的部分。第 4 关证明：同一个字形可以同时落在两个不同的
具体环上（同一张卡、同一个形状族），所以「按哪个具体位图接下去」不由字形单独决定；
但「形状怎么走」由字形单独决定，而且与在第几关、在答题条上还是在图例里都无关。
这一关的整条路线是靠这条算出来的——每一格要按几下，只看相位差。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1 / ACTION2；换关那一步（level_prev != level_next）返回 NA；"
         "光标框住的那一串定位不到返回 NA。串里某一格**动作前**的字形不在已量到的三个形状族里，"
         "这一格不判——那是还没量过的形状。整串一格都判不了返回 NA。"
         "动作前认得、动作后落到三族之外，判 FALSE：那正是这条概念说不会发生的事。")
NOTE = "v1。它不写 apply：相位定形状不定朝向，逐格像素由 wheels 那张具体表负责。"
EVIDENCE = ["dd40169d930aefd1", "93c30c6a8cac41d1", "74834dc113fab332",
            "bdb98cb0c06174a6", "29dce1d86b3fe2c8"]

from _lib import focus_run, glyph, phase


def assert_(prev, action, nxt, ctx=None):
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action not in ("ACTION1", "ACTION2"):
        return "NA"
    run = focus_run(prev)
    if not run:
        return "NA"
    d = 1 if action == "ACTION1" else -1
    said = False
    for r0, c0 in run:
        a = phase(glyph(prev, r0, c0))
        if a is None:
            continue
        said = True
        b = phase(glyph(nxt, r0, c0))
        if b is None:
            return "FALSE"
        if b != (a[0], (a[1] + d) % 7):
            return "FALSE"
    return "TRUE" if said else "NA"
