"""每个字形槽固定着一个二面体变换 t：槽里显示的就是 t 作用在「本相位的标准形状」上的样子。
光标框住的那一串里，ACTION1 让每一格的相位 +1、ACTION2 -1，而 t 一格不变——
所以后继 = t(下一相位的标准形状)。t 不是直接看得见的，它由「哪些变换能把标准形状变成当前字形」定：
当前字形不对称时 t 唯一，后继就整格说得出来；字形有对称性时 t 不唯一，这时只说**所有候选都一致的那些格**
（那些格正是被对称性固定住的）。

这条取代了 v1-v6 的手工环表。环表的毛病是它把「这个槽在哪条环上」当成字形的属性去查，
而具体环是**槽**的属性——于是每换一个槽就可能撞出一条没量到的边，每撞一次就得补一次表。
换成取向之后，同一件事有了机制：两个槽显示同一个对称字形却走向不同后继，是因为它们的 t 不同，
而对称让这两个 t 都能画出同一个字形。可判错性没有降低，反而更硬：
真值必须落在几何算出的候选集里（这是纯几何的预言，没有任何拟合参数）。

这条概念不主张 t 是什么，只主张 t 在一步之内不变。哪天世界让同一个槽换了取向，它当场变反例。
"""
LEVEL = "L6"
SCOPE = ("只看 ACTION1 / ACTION2；换关那一步（level_prev != level_next）返回 NA；"
         "**这一按之后答题条就处处与目标同余**（win_rule 说那一刻这一关就结束）也返回 NA——"
         "赢了之后的版面整块重画，这条概念对它没有发言权，而 apply 拿不到 ctx，只能自己算出来；"
         "光标框住的那一串定位不到返回 NA；串里只要有一格的相位读不出来（形状不在已量到的族里），"
         "整串返回 NA——那一格的候选集算不出来，连「这一按会不会赢」都判不了。"
         "候选唯一的格说整格，候选不唯一的格只说候选们一致的那些格；一格都说不出就返回 NA。")
NOTE = ("v7：第二次在终局卡上被同一件事绊倒之后换了写法。v1-v6 是一张越补越大的环表，"
        "被推翻的方式每次都一样：同一个字形在一个新槽里走到了表里没有的地方。"
        "改成按二面体取向算候选之后，这件事从「表不全」变成「对称性使 t 不唯一」，"
        "而真值落在候选集里是纯几何的必然。全量语料 297 条实测边：真值 297 条全在候选集里，"
        "候选唯一的 118 条全说对；候选不唯一时按位取交，说得出 5923/7425 位、说错 0 位。"
        "顺带否掉了一个更强的猜想：同一串里的槽共用一个取向——6 条实测反例，取向是逐槽的。"
        "v6：环表的沉默判据从「落在两条以上结构上」改成「各结构说法不一或有端点」；"
        "开口从 215 涨到 236 条、零反例，但一撞上新槽（824440c24202d011）就又被推翻，"
        "这次的推翻直接催生了 v7。"
        "v5：它对着一个正好完成本关的按键照常预测，而世界把整块版面换掉了。病根是 assert_ 靠 ctx "
        "躲开了换关那一步、apply 却拿不到 ctx，同一条概念在「判」和「说」两种用法下 scope 不一样。"
        "改成自己把这一按的结果算出来，再拿 win_rule 那条读法问一句「这就赢了吗」，赢了就闭嘴。"
        "v4：字形 x1ca7ca7 的后继不是环表说的那个——已量到的边都同意，不等于没有没量到的。"
        "v3：光标框住的是一整串槽，不是一格；而且串可以在图例上，不在答题条上。")
EVIDENCE = ["159b930324806832", "a071d0035fa0697e",
            "50213178202d90ba", "907d478dbc412006",
            "208be4a4d04b4d3f", "1d7eefe68ee96710",
            "820b623680952045",
            "eeffe6377ed1869b", "e2b5095fdcc439b7", "69bf34dd636db150",
            "dd40169d930aefd1", "93c30c6a8cac41d1", "74834dc113fab332",
            "29dce1d86b3fe2c8", "e366c18298f6bbb5",
            "d4d110e6546b04a4", "a1b828d9bed5850b", "824440c24202d011"]

from _lib import (CELL, INK, SHAPE_FAMILIES, board, dihedral, focus_run,  # noqa: E402
                  glyph, phase, shapes)

RING = 7            # 形状环恰好 7 元且闭合（shape_step 背的书）
NB = CELL * CELL


def _cands(v, action):
    """这个字形按一下可能变成哪些字形：把标准形状变成 v 的每个变换，各自作用到下一相位上。
    相位读不出来返回 None。"""
    p = phase(v)
    if p is None:
        return None
    fam, i = p
    j = (i + 1) % RING if action == "ACTION1" else (i - 1) % RING
    here = dihedral(SHAPE_FAMILIES[fam][i])
    there = dihedral(SHAPE_FAMILIES[fam][j])
    return {there[k] for k in here if here[k] == v}


def _paint(prev, r0, c0, bits):
    """把一个槽里的若干位画成格子：bits 是 {位序: 0/1}。"""
    bg = prev[r0 - 1][c0]                 # 槽外一圈的框色（字形上方那一行）
    return {(r0 + i // CELL, c0 + i % CELL): (INK if b else bg) for i, b in bits.items()}


def _wins(prev, guess):
    """这一按之后答题条是不是就处处与目标同余了。是的话这一关当场结束（win_rule），
    而结束之后整块版面重画，这条概念对它没有发言权。
    候选都是同一个形状的不同朝向，而这里只比形状，所以随便取一个候选都不影响判断。"""
    g = [list(row) for row in prev]
    for r0, c0, v in guess:
        for (r, c), col in _paint(prev, r0, c0,
                                 {i: (v >> (NB - 1 - i)) & 1 for i in range(NB)}).items():
            g[r][c] = col
    want, b = shapes(g), board(g)
    if want is None or b is None or len(want) != len(b["answer"]):
        return False
    return all(a in w for a, w in zip(b["answer"], want))


def _step(prev, action, ctx):
    """返回 {(行, 列): 颜色}；条件不满足返回 None。"""
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if action not in ("ACTION1", "ACTION2"):
        return None
    run = focus_run(prev)
    if not run:
        return None
    guess, cells = [], {}
    for r0, c0 in run:
        v = glyph(prev, r0, c0)
        cs = _cands(v, action)
        if not cs:
            return None                   # 相位读不出来：连「会不会赢」都判不了，整串闭嘴
        guess.append((r0, c0, next(iter(cs))))
        bits = {}
        for i in range(NB):
            b = {(x >> (NB - 1 - i)) & 1 for x in cs}
            if len(b) == 1:
                bits[i] = b.pop()
        cells.update(_paint(prev, r0, c0, bits))
    if not cells or _wins(prev, guess):
        return None
    return cells


def assert_(prev, action, nxt, ctx=None):
    got = _step(prev, action, ctx)
    if got is None:
        return "NA"
    for (r, c), col in got.items():
        if nxt[r][c] != col:
            return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    return _step(prev, action, ctx)
