"""角标（色 0）永远是框住焦点那一串的一个矩形边框：上沿在串顶上方 4 行、下沿在串顶下方 8 行、
左右正好到串的两端（首槽左列到末槽右列），上下沿内侧再各补两个端格。帧上没有别的色 0 格子。

它把「角标」从一堆散点变成一个由串的位置与长度算得出的形状——串长 1 时 14 格，串长 2 时 28 格，
所以移动一次的帧差是两个形状的对称差，这一关那些 28/42/57 的帧差就是这么来的。
"""
LEVEL = "L0"
SCOPE = ("每一步同时看 prev 和 nxt 两帧；两帧都读不出焦点时返回 NA。"
         "注意焦点本身是**从角标框里**读出来的（框内的槽），所以这条概念不检验『框住的是哪一串』，"
         "只检验『框的形状由那一串唯一决定』——框可以只有四个角、可以高矮不同、可以只盖住半串，"
         "那些都会让它判 FALSE。")
NOTE = "v1。"
EVIDENCE = ["155912380b6a3bc4", "13c8810c29e35dff", "eeffe6377ed1869b"]

from _lib import bracket, cursor_cells, focus_run


def _ok(g):
    run = focus_run(g)
    if not run:
        return None
    return cursor_cells(g) == bracket(run)


def assert_(prev, action, nxt, ctx=None):
    a, b = _ok(prev), _ok(nxt)
    if a is None and b is None:
        return "NA"
    if a is False or b is False:
        return "FALSE"
    return "TRUE"
