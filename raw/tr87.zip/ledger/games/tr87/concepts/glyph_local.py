"""ACTION1 / ACTION2 除了计数条那一行以外，帧差完全落在光标框住的那 25 格里。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1 / ACTION2；换关（level_prev != level_next）返回 NA；光标定位不到返回 NA。"
         "第 HUD_ROW 行（计数条）整行豁免——那一行归 budget_bar 管。"
         "只断言『改动的范围』，不断言改成什么（那是 wheel 那条的事）。整帧不动也算 TRUE。")
NOTE = ("v2：v1 说帧差全落在 25 格里，被 19 条转移打脸——每两步计数条会多吃一格，"
        "那一格不在光标格里。改法是把计数条那一行明确排除出去，主张缩成『字形带上的局部性』。"
        "v3：字形位的坐标改成从帧上识别，不再用第 0 关量的那套常数。")
EVIDENCE = ["159b930324806832", "a071d0035fa0697e", "059da38e50a87eed", "0d63bb9218324457",
            "07d254ea1ec70a9a", "10ec300a5a365c3c", "16766090fb20992f", "1f3645ece5e8a566",
            "2efaf3e6be5f2e10", "340c9e34f43f95e9", "3d9605d530efdfb7", "4f70af86f594fdff",
            "57ad7cf61454eded", "5c8c1bef43279964", "60a52d9f2d39b8fb", "67de766302c2137c",
            "84a8b5e839aec20b", "9963e97e721e761d", "c14289f00b53e7a0", "c696a434aacf2499",
            "d6db3f94b3391cd1", "f0f989a8e1ab6abc", "fb4e03fa5831694b"]

from _lib import HUD_ROW, cell_box, cursor


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in ("ACTION1", "ACTION2"):
        return "NA"
    i = cursor(prev)
    if i is None:
        return "NA"
    box = cell_box(prev, i)
    if box is None:
        return "NA"
    for r in range(len(prev)):
        if r == HUD_ROW:
            continue
        for c in range(len(prev[0])):
            if prev[r][c] != nxt[r][c] and (r, c) not in box:
                return "FALSE"
    return "TRUE"
