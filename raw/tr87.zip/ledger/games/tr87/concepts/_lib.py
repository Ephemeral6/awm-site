"""tr87 的本局词汇 —— 每个定义都是假设。

v2：第 0 关量出来的那套绝对坐标（长条在第几行、字形位在哪几列、图例三行两列）
在第 1 关全部失效——关与关之间版面会变。所以这一版不写坐标，只写**版面的识别规则**：

  * 「字形槽」= 一块 5x5，内部只有 {框色, INK}，四周一圈（含四角）全是框色，且至少一个 INK 点亮。
  * 槽按所在行成组。**整行同色的恰好两行**是题面行与答题行；谁是谁不看光标，看颜色在图例里
    担什么角色：题面色当过某条规则的键色，答题色只当过值色、从没当过键色。
  * 色 0 的角标（光标）围住某一个字形槽（`focus`）。它不一定在答题条上——有的关里它围在图例上。
  * 剩下的行是**图例**。一行里可以摆好几条规则，靠**列距**断句：相邻槽距 GAP_RUN 是同一串，
    距 GAP_ARROW 是「箭头」（键串到值串），再宽就是下一条规则。一条规则 = 一串同色的键
    -> 一串另一种同色的值。
  * 第 HUD_ROW 行是一条计数条，不参与版面识别。

v3：规则的值不一定就是答题色。有的关里图例分两级——题面色 -> 中间色 -> 答题色，
题面要连着改写两次才落到答题条上。所以「读题」不再是一次匹配，而是**沿颜色链反复改写**，
直到序列变成答题色且正好铺满答题条（`parses`）。第 0~2 关是这条链只有一跳的特例。

v4：光标不一定停在答题条上——有的关里它围住的是**图例**里的一个字形。所以版面识别不再靠光标
认行（那是循环论证：先用光标找答题行，再用答题行解释光标），改成先用颜色在图例里的角色定下
题面行与答题行，光标只报它围住的是哪一个槽（`focus`）。`cursor` 仍然只在焦点落在答题条上时给索引。

v5：角标框住的不是一个槽，是**一整串**——同一行里列距 GAP_RUN 相连的一组槽。`focus` 仍报串头，
新增 `focus_cells`（整串）与 `runs_of`（帧上所有串，按阅读序）。图例里一条规则 = 一个键串 + 一个值串，
它们各自是一个可以被光标框住的整体。

尚未量的：关与关之间「识别规则」本身是否还成立；颜色链会不会超过两跳；
字形环一共有几个形状族（已见到三族：环 {0,1,2,8} / {3,4,7} / {5,6,9} 各自共用一条形状序列，
族与族之间不通）——族是不是由框色决定，没量过。
"""
from __future__ import annotations

INK = 5                                  # 点阵的点亮色
CURSOR_COLOR = 0                         # 角标（光标）的颜色
CELL = 5                                 # 字形边长
HUD_ROW = 63                             # 最后一行：一条 64 格的计数条
HUD_EMPTY = 1                            # 计数条还没被吃掉的格子的颜色
HUD_FULL = 4                             # 已被吃掉的格子的颜色（从右往左长）
GAP_RUN = 7                              # 图例里同一串内相邻槽的列距
GAP_ARROW = 10                           # 键串与值串之间的列距（「箭头」）；更宽 = 下一条规则
BRACKET_UP = 4                           # 角标上沿在串顶上方第几行
BRACKET_DOWN = 8                         # 角标下沿在串顶下方第几行

# 光标索引沿答题行的移动量（实测：带环绕）
DELTA = {"ACTION3": -1, "ACTION4": +1}
PHASE = None                             # 本局用不上折叠相位


def glyph(g, top, left):
    """把 (top,left) 起的 5x5 点阵读成一个 25 位整数（行优先，点亮=1）。越界返回 None。"""
    if top < 0 or left < 0 or top + CELL > len(g) or left + CELL > len(g[0]):
        return None
    v = 0
    for r in range(CELL):
        row = g[top + r]
        for c in range(CELL):
            v = v * 2 + (1 if row[left + c] == INK else 0)
    return v


def slots(g):
    """帧上所有字形槽 [(top, left, 框色, 位图)]，按 (top, left) 排序。

    识别是局部的，所以会捞到「假槽」：跨在两个真槽之间的 5x5 窗口，有时也恰好
    满足「一圈同色 + 内部只有框色与 INK」。真槽互不重叠，所以同一行里从左往右
    贪心丢掉与已收槽重叠的——等宽区间上这个贪心就是「留得最多」的那个解。
    """
    n, m = len(g), len(g[0])
    out = []
    for r in range(1, n - CELL):
        gt, gb = g[r - 1], g[r + CELL]
        for c in range(1, m - CELL):
            fc = gt[c - 1]
            if fc == INK or gt[c + CELL] != fc or gb[c - 1] != fc or gb[c + CELL] != fc:
                continue
            if any(gt[c + j] != fc or gb[c + j] != fc for j in range(CELL)):
                continue
            ok, lit = True, False
            for i in range(CELL):
                row = g[r + i]
                if row[c - 1] != fc or row[c + CELL] != fc:
                    ok = False
                    break
                for j in range(CELL):
                    x = row[c + j]
                    if x == INK:
                        lit = True
                    elif x != fc:
                        ok = False
                        break
                if not ok:
                    break
            if ok and lit:
                out.append((r, c, fc, glyph(g, r, c)))
    kept, last = [], {}
    for r, c, fc, v in sorted(out):
        if r in last and c - last[r] < CELL:
            continue                   # 与同一行已收的槽重叠 —— 真槽不会重叠，这是假槽
        last[r] = c
        kept.append((r, c, fc, v))
    return kept


_CACHE = {}


def board(g):
    """读版面。返回 dict，读不出来返回 None。

    键：ans_row / ans_cols / ans_color / prompt_row / prompt_cols / key_color /
        answer / prompt / legend（[(键位图, [值位图…])]）/ cursor（答题位索引，0 起）。
    """
    key = tuple(map(tuple, g))
    if key in _CACHE:
        return _CACHE[key]
    b = _board(g)
    if len(_CACHE) > 64:
        _CACHE.clear()
    _CACHE[key] = b
    return b


def _rules_of(rows, skip):
    """把 skip 之外的每一行切成规则 [(键色, 键串, 值色, 值串)]。"""
    out = []
    for r in sorted(rows):
        if r in skip:
            continue
        chunk = []
        for cell in rows[r] + [None]:
            if chunk and (cell is None or cell[0] - chunk[-1][0] > GAP_ARROW):
                kc = chunk[0][1]
                ks = [v for _, fc, v in chunk if fc == kc]
                rest = chunk[len(ks):]
                if rest and len({fc for _, fc, _ in rest}) == 1:
                    out.append((kc, tuple(ks), rest[0][1], tuple(v for _, _, v in rest)))
                chunk = []
            if cell is not None:
                chunk.append(cell)
    return out


def _board(g):
    rows = {}
    for r, c, fc, v in slots(g):
        rows.setdefault(r, []).append((c, fc, v))
    if not rows:
        return None
    # 整行同色的两行 = 题面行与答题行。谁是谁不看光标，看颜色在图例里担什么角色：
    # 题面色当过某条规则的键色，答题色只当过值色、从没当过键色。
    solid = [r for r in rows if len({fc for _, fc, _ in rows[r]}) == 1]
    if len(solid) != 2:
        return None
    pick = None
    for prompt_row, ans_row in ((solid[0], solid[1]), (solid[1], solid[0])):
        legend = _rules_of(rows, {prompt_row, ans_row})
        ks = {kc for kc, _, _, _ in legend}
        vs = {vc for _, _, vc, _ in legend}
        kc, ac = rows[prompt_row][0][1], rows[ans_row][0][1]
        if kc in ks and ac in vs and ac not in ks:
            if pick is not None:
                return None                       # 两种指派都说得通 —— 读不出来
            pick = (prompt_row, ans_row, legend, kc, ac)
    if pick is None:
        return None
    prompt_row, ans_row, legend, key_color, ans_color = pick

    ans_cols = [c for c, _, _ in rows[ans_row]]
    # 光标：色 0 的角标框住的是**一整串**字形槽（可以框在图例上，不一定在答题条上）
    cur = [(r, c) for r in range(len(g)) for c in range(len(g[0]))
           if g[r][c] == CURSOR_COLOR and r != HUD_ROW]
    focus, focus_cells = None, None
    if cur:
        r0, r1 = min(r for r, _ in cur), max(r for r, _ in cur)
        c0, c1 = min(c for _, c in cur), max(c for _, c in cur)
        boxed = sorted((r, c) for r in rows for c, _, _ in rows[r]
                       if r0 <= r and r + CELL - 1 <= r1 and c0 <= c and c + CELL - 1 <= c1)
        if boxed:
            focus, focus_cells = boxed[0], boxed
    return {"ans_row": ans_row, "ans_cols": ans_cols, "ans_color": ans_color,
            "prompt_row": prompt_row, "prompt_cols": [c for c, _, _ in rows[prompt_row]],
            "key_color": key_color,
            "answer": [v for _, _, v in rows[ans_row]],
            "prompt": [v for _, _, v in rows[prompt_row]],
            "rules": legend,
            "legend": [(ks, vs) for kc, ks, vc, vs in legend
                       if kc == key_color and vc == ans_color],
            "focus": focus,
            "focus_cells": focus_cells,
            "cursor": (ans_cols.index(focus[1])
                       if focus is not None and focus[0] == ans_row
                       and focus[1] in ans_cols else None)}


def cursor(g):
    """光标停在第几个答题字形位（0 起）；读不出来返回 None。"""
    b = board(g)
    return None if b is None else b["cursor"]


def cursor_cells(g):
    """光标（色 0）占的格子集合，frozenset[(行, 列)]。"""
    return frozenset((r, c) for r in range(len(g)) for c in range(len(g[0]))
                     if g[r][c] == CURSOR_COLOR and r != HUD_ROW)


def runs_of(g):
    """帧上所有「串」：同一行里列距恰好 GAP_RUN 相连的一组槽，[[(行, 列)…]…]，按阅读序。"""
    rows = {}
    for r, c, fc, v in slots(g):
        rows.setdefault(r, []).append(c)
    out = []
    for r in sorted(rows):
        cur = []
        for c in sorted(rows[r]):
            if cur and c - cur[-1] != GAP_RUN:
                out.append([(r, x) for x in cur])
                cur = []
            cur.append(c)
        if cur:
            out.append([(r, x) for x in cur])
    return out


def focus_run(g):
    """光标框住的那一整串槽 [(行, 列)…]；读不出来返回 None。"""
    b = board(g)
    return None if b is None else b["focus_cells"]


def bracket(run):
    """框住整串 run 的角标该占的格子 frozenset[(行, 列)]。run 是 [(行, 列)…]（槽的左上角）。"""
    if not run:
        return None
    r0 = run[0][0]
    c0, c1 = run[0][1], run[-1][1] + CELL - 1
    top, bot = r0 - BRACKET_UP, r0 + BRACKET_DOWN
    out = {(top, c) for c in range(c0, c1 + 1)}
    out |= {(bot, c) for c in range(c0, c1 + 1)}
    out |= {(top + 1, c0), (top + 1, c1), (bot - 1, c0), (bot - 1, c1)}
    return frozenset(out)


def focus_cycle(g):
    """焦点可以停的那些串，按阅读序。焦点在答题条上时是答题条的各格（各自成串），
    否则是图例里的各个串（每条规则的键串与值串各一个）。读不出来返回 None。"""
    b = board(g)
    if b is None or b["focus"] is None:
        return None
    if b["focus"][0] == b["ans_row"]:
        return [[(b["ans_row"], c)] for c in b["ans_cols"]]
    return [run for run in runs_of(g) if run[0][0] not in (b["ans_row"], b["prompt_row"])]


def ans_cols(g):
    b = board(g)
    return None if b is None else b["ans_cols"]


def cell_box(g, i):
    """第 i 个答题字形位占的 25 格 frozenset[(行, 列)]；读不出来返回 None。"""
    b = board(g)
    if b is None or not (0 <= i < len(b["ans_cols"])):
        return None
    r0, c0 = b["ans_row"], b["ans_cols"][i]
    return frozenset((r0 + r, c0 + c) for r in range(CELL) for c in range(CELL))


def word_ans(g):
    """答题行上每个字形位的位图列表。"""
    b = board(g)
    return None if b is None else b["answer"]


def word_prompt(g):
    """题面行上每个字形位的位图列表。"""
    b = board(g)
    return None if b is None else b["prompt"]


def legend(g):
    """图例的全部规则 [(键色, (键位图…), 值色, (值位图…)), …]，顺序 = 从上到下、从左到右。"""
    b = board(g)
    return None if b is None else b["rules"]


def me(g):
    """『我』= 光标框住的那个答题字形位的左上角 (行, 列)。定位不到返回 None。"""
    b = board(g)
    if b is None or b["cursor"] is None:
        return None
    return (b["ans_row"], b["ans_cols"][b["cursor"]])


def walls(g):
    """本局没量到「阻挡」这种东西；留 None，别让概念引用它。"""
    return None


def hud_filled(g):
    """计数条上已变成 HUD_FULL 的格数。"""
    return sum(1 for c in range(len(g[0])) if g[HUD_ROW][c] == HUD_FULL)


def _to_grid(v):
    return [[(v >> (CELL * CELL - 1 - (r * CELL + c))) & 1 for c in range(CELL)] for r in range(CELL)]


def _to_bits(m):
    v = 0
    for row in m:
        for x in row:
            v = v * 2 + x
    return v


def dihedral(v):
    """位图 -> {变换名: 位图}，8 个二面体变换（rot0..rot3，各再配一个左右翻）。"""
    out, cur = {}, _to_grid(v)
    for k in range(4):
        out[f"rot{k}"] = _to_bits(cur)
        out[f"rot{k}+flip"] = _to_bits([[cur[r][CELL - 1 - c] for c in range(CELL)] for r in range(CELL)])
        cur = [[cur[CELL - 1 - c][r] for c in range(CELL)] for r in range(CELL)]
    return out


def congruent(v):
    """v 的二面体等价类（8 个像去重后的 frozenset）——「形状相同、朝向不论」。"""
    return frozenset(dihedral(v).values())


# 字形环上的**形状**只有几条固定序列，一条叫一个「形状族」。已量到三族，每族 7 个形状、循环。
# 每族只记一个代表位图，相位就是它在族里的下标；同一个形状可以有好几个具体环（朝向不同的实例），
# 所以「相位」比「具体环」弱，也比它稳：具体环是**槽**的属性，形状族与相位是**字形**的属性。
SHAPE_FAMILIES = [
    [0x012FCA1, 0x1F4A13F, 0x118F6B7, 0x1B5395B, 0x0E47D0E, 0x118EE3F, 0x1C23887],
    [0x04A92A4, 0x172109D, 0x1D80037, 0x158561F, 0x110476A, 0x17AF415, 0x1B8D63B],
    [0x04FC63F, 0x1F8FD4E, 0x072FE9C, 0x1FADE3F, 0x1F4A5E1, 0x04FD7E4, 0x1E9C72F],
]

_PHASE = {}
for _f, _seq in enumerate(SHAPE_FAMILIES):
    for _i, _v in enumerate(_seq):
        _PHASE[congruent(_v)] = (_f, _i)


def phase(v):
    """字形的 (形状族, 相位)；不在已量到的三族里返回 None。"""
    return None if v is None else _PHASE.get(congruent(v))


def _rewrite(seq, rules, cap):
    """把序列 seq 按 rules（同一个键色、同一个值色的一组 (键串, 值串)）切段改写一次。
    返回所有结果（长度不超过 cap）。"""
    out = set()

    def walk(i, acc):
        if len(acc) > cap:
            return
        if i == len(seq):
            out.add(tuple(acc))
            return
        for ks, vs in rules:
            m = len(ks)
            if i + m > len(seq):
                continue
            if all(seq[i + t] in congruent(ks[t]) for t in range(m)):
                walk(i + m, acc + list(vs))

    walk(0, [])
    return out


def parses(g):
    """题面沿颜色链反复改写，直到变成答题色且正好铺满答题条；返回所有可能的值串
    set[tuple[位图]]。每一步的匹配都是**逐格二面体同余**，不看朝向。"""
    b = board(g)
    if b is None:
        return None
    n = len(b["ans_cols"])
    byk = {}
    for kc, ks, vc, vs in b["rules"]:
        if ks and vs:
            byk.setdefault((kc, vc), []).append((ks, vs))
    out, frontier, seen = set(), {(b["key_color"], tuple(b["prompt"]))}, set()
    for _ in range(4):                       # 颜色链最多走 4 跳
        nxt = set()
        for col, seq in frontier:
            if (col, seq) in seen:
                continue
            seen.add((col, seq))
            if col == b["ans_color"]:
                if len(seq) == n:
                    out.add(seq)
                continue
            for (kc, vc), rules in byk.items():
                if kc != col:
                    continue
                for res in _rewrite(seq, rules, 2 * n):
                    nxt.add((vc, res))
        frontier = nxt
        if not frontier:
            break
    return out


def shapes(g):
    """答题条每一格要的形状（一个二面体等价类）；切法不唯一或读不出来返回 None。

    这是 win_rule / win_prev 共用的判据：题面被切成段，每段换成规则的值串，
    首尾接起来正好铺满答题条；每一格只被规定形状，不规定朝向。
    """
    ps = parses(g)
    if not ps or len(ps) != 1:
        return None
    return [congruent(v) for v in next(iter(ps))]


def _gaps(g):
    """答题条每一格离目标形状还差几下 ACTION1（0..6）；读不出来那一格给 None。
    整块读不出来（图例关的切法不唯一等）返回 None。"""
    want, b = shapes(g), board(g)
    if want is None or b is None or len(want) != len(b["answer"]):
        return None
    out = []
    for v, w in zip(b["answer"], want):
        p = phase(v)
        if p is None:
            out.append(None)
            continue
        fam, i = p
        tgt = [k for k, s in enumerate(SHAPE_FAMILIES[fam]) if congruent(s) == w]
        out.append(None if len(tgt) != 1 else (tgt[0] - i) % len(SHAPE_FAMILIES[fam]))
    return out


def focus_gap_0(g):
    """光标框住的那一串里第 1 格离目标还差几下 ACTION1；不在答题条上或读不出来返回 None。"""
    return _focus_gap(g, 0)


def focus_gap_1(g):
    """同上，第 2 格；串里没有第 2 格返回 None。"""
    return _focus_gap(g, 1)


def _focus_gap(g, k):
    gaps, b = _gaps(g), board(g)
    if gaps is None or b is None or not b["focus_cells"]:
        return None
    cells = [c for r, c in b["focus_cells"] if r == b["ans_row"] and c in b["ans_cols"]]
    if len(cells) <= k:
        return None
    return gaps[b["ans_cols"].index(cells[k])]


def _focus_phase(g, k, part):
    b = board(g)
    if b is None or not b["focus_cells"] or len(b["focus_cells"]) <= k:
        return None
    r0, c0 = b["focus_cells"][k]
    p = phase(glyph(g, r0, c0))
    return None if p is None else p[part]


def focus_fam_0(g):
    """光标框住的那一串里第 1 格是哪个形状族；读不出来返回 None。"""
    return _focus_phase(g, 0, 0)


def focus_fam_1(g):
    """同上，第 2 格。"""
    return _focus_phase(g, 1, 0)


def focus_phase_0(g):
    """光标框住的那一串里第 1 格的形状相位（0..6）；读不出来返回 None。

    图例关上「这一按会不会过关」全看图例各串的相位，而别的读数一格都不反映它。
    """
    return _focus_phase(g, 0, 1)


def focus_phase_1(g):
    """同上，第 2 格。"""
    return _focus_phase(g, 1, 1)


def rest_wrong_n(g):
    """答题条上**不在光标里**、且还没与目标同余的格数；读不出来返回 None。

    win_rule 说这一关在答题条处处同余那一刻结束，所以「这一按会不会过关」= 这个数是 0
    且焦点那几格按完之后差为 0。差 1 下和差 2 下的版面在别的读数上可以一模一样，所以要单独读出来。
    """
    gaps, b = _gaps(g), board(g)
    if gaps is None or b is None:
        return None
    boxed = {c for r, c in (b["focus_cells"] or []) if r == b["ans_row"]}
    return sum(1 for c, d in zip(b["ans_cols"], gaps) if c not in boxed and d != 0)
