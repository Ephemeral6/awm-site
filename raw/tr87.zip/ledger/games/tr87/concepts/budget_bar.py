"""第 63 行是一条 64 格的计数条：每走满 2 步，它从右端多吃掉一格（色 1 变色 4），别的格子不动。"""
LEVEL = "L4"
SCOPE = ("只看第 0 关（level_prev == level_next == 0）；换关返回 NA；ctx 没给 step 返回 NA。"
         "断言：走完第 s 步之后，计数条右端恰好有 s//2 格是 HUD_FULL，其余是 HUD_EMPTY；"
         "并且这一行在这一步里最多只多吃一格。别的关是否也这么算，这条不管。")
NOTE = ""
EVIDENCE = ["a071d0035fa0697e", "59594427f77b7b7d", "84a8b5e839aec20b", "0d63bb9218324457"]

from _lib import HUD_EMPTY, HUD_FULL, HUD_ROW


def _shape(row, k):
    """整行是否恰好『右端 k 格 HUD_FULL，左边全 HUD_EMPTY』。"""
    n = len(row)
    return all(row[c] == (HUD_FULL if c >= n - k else HUD_EMPTY) for c in range(n))


def _want(ctx):
    if ctx is None or ctx.get("level_prev") != 0 or ctx.get("level_next") != 0:
        return None
    s = ctx.get("step")
    return None if s is None else s


def assert_(prev, action, nxt, ctx=None):
    s = _want(ctx)
    if s is None:
        return "NA"
    if not _shape(prev[HUD_ROW], (s - 1) // 2):
        return "NA"          # 起点就不是这个形状，这条概念说不上话
    return "TRUE" if _shape(nxt[HUD_ROW], s // 2) else "FALSE"


def apply(prev, action, ctx=None):
    s = _want(ctx)
    if s is None:
        return None
    n = len(prev[HUD_ROW])
    k = s // 2
    if not _shape(prev[HUD_ROW], (s - 1) // 2):
        return None
    return {(HUD_ROW, c): (HUD_FULL if c >= n - k else HUD_EMPTY) for c in range(n)}
