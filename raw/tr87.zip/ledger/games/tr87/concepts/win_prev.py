"""过关那一步的前一帧，答题条除了光标框住的那一格，其余各格都已经与目标形状同余——
也就是说，过关是被最后那一拨凑齐的，凑齐的位置正是光标所在。

「目标形状」用 `_lib.shapes`：题面按图例规则沿颜色链反复改写，每一轮切成段、每段逐格与某条规则的
键串同余、换成该规则的值串，改到序列变成答题色且正好铺满答题条；每格只定形状不定朝向。
这条只在换关那一步上开口，是 win_rule 那句话的另一半：
win_rule 说「还在关里 ⇒ 还没凑齐」，这条说「过关那一下 ⇒ 差的正好是光标这一格」。
"""
LEVEL = "L5"
SCOPE = ("只看 level_next != level_prev 的那一步；同关内、版面读不出来、题面改写路径不唯一、"
         "光标定位不到，一律返回 NA。")
NOTE = ("v4：跟着 `_lib` v3 把读法推广成沿颜色链反复改写；主张本身没变。"
        "v3 里我把第三次换关那条 tid 也塞进了 EVIDENCE——那不是反例，是它预言对的一步，"
        "抄进依据只会把唯一能考它的转移变成自证，N 当场归零。撤回。")
EVIDENCE = ["e04145f02107a379", "1d1c8494ebecf05c"]

from _lib import board, shapes


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") == ctx.get("level_next"):
        return "NA"
    want = shapes(prev)
    b = board(prev)
    if want is None or b is None or b["cursor"] is None or len(want) != len(b["answer"]):
        return "NA"
    i = b["cursor"]
    return "TRUE" if all(a in w for j, (a, w) in enumerate(zip(b["answer"], want)) if j != i) else "FALSE"
