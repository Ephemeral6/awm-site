"""ACTION3 / ACTION4 只把色 0 光标在答题行的字形位上左移 / 右移一格（带环绕），帧上别处一格不变。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3 / ACTION4；换关（level_prev != level_next）返回 NA；"
         "版面或光标读不出来（cursor 返回 None）返回 NA。断言两件事的合取："
         "光标索引按 ±1 mod（答题格数）变，"
         "且帧差（第 HUD_ROW 行豁免，那行归 budget_bar 管）只发生在光标离开的格与新占的格上。")
NOTE = ("v2：v1 忘了计数条——每两步它会多吃一格，落在光标之外。把那一行排除出去。"
        "v3：v1/v2 把「5 个字形位」和它们的列写死在词汇里，那是第 0 关的读数；"
        "换关后版面变了，主张改成对识别出来的答题行成立，格数由帧决定。")
EVIDENCE = ["844589af5a2f4ba8", "59594427f77b7b7d", "3a4e7b9188702ddd", "1ab85c03eecdd733"]

from _lib import CURSOR_COLOR, DELTA, HUD_ROW, ans_cols, cursor, cursor_cells


def _moved(prev, d):
    """光标格子按索引 ±d 平移后的新格子集合；算不出来返回 None。"""
    i = cursor(prev)
    cols = ans_cols(prev)
    if i is None or cols is None:
        return None
    j = (i + d) % len(cols)
    off = cols[j] - cols[i]
    return i, j, frozenset((r, c + off) for r, c in cursor_cells(prev))


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action not in DELTA:
        return "NA"
    got = _moved(prev, DELTA[action])
    if got is None:
        return "NA"
    i, j, want = got
    if cursor(nxt) != j:
        return "FALSE"
    old = cursor_cells(prev)
    if cursor_cells(nxt) != want:
        return "FALSE"
    changed = {(r, c) for r in range(len(prev)) for c in range(len(prev[0]))
               if r != HUD_ROW and prev[r][c] != nxt[r][c]}
    return "TRUE" if changed <= (old | want) else "FALSE"


def apply(prev, action, ctx=None):
    if action not in DELTA:
        return None
    got = _moved(prev, DELTA[action])
    if got is None:
        return None
    _i, _j, want = got
    out = {}
    # 光标腾出来的格子恢复成本行的底色（取同一行第 0 列作样本，那里不属于任何字形带）
    for r, c in cursor_cells(prev) - want:
        out[(r, c)] = prev[r][0]
    for r, c in want:
        out[(r, c)] = CURSOR_COLOR
    return out
