"""一步之内，除了焦点串占的格子、角标占的格子、和计数条那一行，帧上其余每一格都不变。

这是「什么可以动」那句话的可判错形式。它把两类关卡合成一句：答题条关里图例一格不动，
图例关里题面与答题条一格不动——变的永远只有**角标此刻框住的那一串**，加上角标自己。
世界哪天在别处改了一格（比如按一下连带改了别的规则、或者背景自己动了），它当场变反例。
"""
LEVEL = "L2"
SCOPE = ("换关那一步（level_prev != level_next）返回 NA——那一步整块版面重画，这条不管；"
         "前后两帧里只要有一帧版面读不出来、或焦点串定位不到，返回 NA。"
         "『可以动的格子』取前后两帧的并集：角标会移动，移动前后占的格子都算它的。")
NOTE = ("v1。它不写 apply：它说的是「哪些格子不变」，而完成度只数**帧差格**里被说对的，"
        "说对一格没变不进分子；写了反而会在真变了的格子上说错。册子里也没有别的概念读它。")
EVIDENCE = ["155912380b6a3bc4", "eeffe6377ed1869b", "29dce1d86b3fe2c8"]

from _lib import CELL, HUD_ROW, board, cursor_cells


def _free(g, b):
    """这一帧上允许变的格子。"""
    out = set(cursor_cells(g))
    for r0, c0 in b["focus_cells"]:
        out |= {(r0 + r, c0 + c) for r in range(CELL) for c in range(CELL)}
    return out


def assert_(prev, action, nxt, ctx=None):
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    a, b = board(prev), board(nxt)
    if a is None or b is None or a["focus_cells"] is None or b["focus_cells"] is None:
        return "NA"
    free = _free(prev, a) | _free(nxt, b)
    for r in range(len(prev)):
        if r == HUD_ROW:
            continue
        pr, nr = prev[r], nxt[r]
        if pr == nr:
            continue
        for c in range(len(pr)):
            if pr[c] != nr[c] and (r, c) not in free:
                return "FALSE"
    return "TRUE"
