"""语料里的任何一帧，答题条都不会处处与目标形状同余——处处同余的那一刻这一关就结束了，所以那一帧永远看不到。

目标形状怎么读（`_lib.shapes`）：把题面行当成一串符号，按图例规则**反复改写**——
每一轮把它切成若干段，每段逐格与某条规则的键串同余，换成那条规则的值串；
规则的键色决定它管哪一轮（有的关是题面色直接换成答题色，有的关中间还要过一种颜色），
改到序列变成答题色且正好铺满答题条为止。第 j 格要的形状 = 第 j 个值，**只定形状不定朝向**
（这一格显示它的哪个二面体像，由这一格能拨出来的字形决定，不由规则决定）。
这条概念是那句「答对就过关」的可判错影子：它说的是「还在关里 ⇒ 还没答对」，
等价于「答对 ⇒ 一定过关」；世界哪天让我在关里看到一条处处同余的答题条，它当场变反例。
"""
LEVEL = "L5"
SCOPE = ("看每条转移的 prev 与 next 两帧；版面读不出来、或题面的改写路径不是恰好一条"
         "（改不出来、或有多条且末串不同），返回 NA——那说明这条读法在那一帧上没给出目标形状。")
NOTE = ("v3：读法从「一轮改写」推广成「沿颜色链反复改写」（`_lib` v3）。主张本身没变，"
        "变的是它在哪些帧上开得了口——新出现的那种两级图例，以前 shapes() 返回 None、这条只能 NA。")
EVIDENCE = ["e04145f02107a379", "50213178202d90ba", "335dd78a980589da",
            "aada9f567b025048", "907d478dbc412006"]

from _lib import board, shapes


def _all_match(g):
    """这一帧的答题条是不是处处与目标同余；读不出来返回 None。"""
    want = shapes(g)
    b = board(g)
    if want is None or b is None or len(want) != len(b["answer"]):
        return None
    return all(a in w for a, w in zip(b["answer"], want))


def assert_(prev, action, nxt, ctx=None):
    seen = [x for x in (_all_match(prev), _all_match(nxt)) if x is not None]
    if not seen:
        return "NA"
    return "FALSE" if any(seen) else "TRUE"
