"""焦点（角标框住的那一串）在「可停的串」之间循环走位：ACTION4 走到阅读序的下一串，
ACTION3 走到上一串，都带环绕；可停的串是答题条上的各格（焦点在答题条上时），
或图例里的各个串（每条规则的键串与值串各算一个，焦点在图例上时）。

「什么可以动」不是这个世界的常量：前几关能动的是答案，这一关能动的是规则册子本身。
这条概念要说的正是这件事——焦点集合由版面结构给出，不由「答题条」这个身份写死。
"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3 / ACTION4；换关那一步（level_prev != level_next）返回 NA；"
         "版面读不出来、焦点定位不到、或焦点不在它自己那份『可停的串』名单里，返回 NA——"
         "最后这种情形说明名单构造错了，那是读版面的事，不是这条概念的主张。")
NOTE = ("v1。它与 cursor_lr 说的是同一件事的两个切面：cursor_lr 说答题条上的索引怎么加减，"
        "这一条说焦点在哪一串上。焦点落在图例里时 cursor_lr 整关沉默，这一条照常开口。"
        "apply 里画的角标形状与 cursor_shape 是同一条假设（都从 _lib.bracket 来）："
        "形状错了，两条会一起垮。")
EVIDENCE = ["155912380b6a3bc4", "2386de62b1968551", "fe1d42ffb4d0c6ef"]

from _lib import BRACKET_UP, CURSOR_COLOR, DELTA, board, bracket, focus_cycle


def _want(prev, action, ctx):
    """返回焦点该去的那一串 [(行, 列)…]；说不出来返回 None。"""
    if ctx is not None and ctx.get("level_prev") != ctx.get("level_next"):
        return None
    if action not in DELTA:
        return None
    a = board(prev)
    if a is None or a["focus"] is None:
        return None
    cyc = focus_cycle(prev)
    if not cyc:
        return None
    heads = [run[0] for run in cyc]
    if a["focus"] not in heads:
        return None
    return cyc[(heads.index(a["focus"]) + DELTA[action]) % len(heads)]


def assert_(prev, action, nxt, ctx=None):
    want = _want(prev, action, ctx)
    if want is None:
        return "NA"
    b = board(nxt)
    if b is None or b["focus"] is None:
        return "NA"
    return "TRUE" if b["focus"] == want[0] else "FALSE"


def apply(prev, action, ctx=None):
    want = _want(prev, action, ctx)
    if want is None:
        return None
    a = board(prev)
    old, new = bracket(a["focus_cells"]), bracket(want)
    r0, c0 = a["focus_cells"][0]
    bg = prev[r0 - BRACKET_UP][c0 - 1]     # 角标左外一格：这一关的底色
    out = {cell: bg for cell in old - new}
    out.update({cell: CURSOR_COLOR for cell in new})
    return out
