/-
# Derived/FrameRest —— 「别处一位都不动」是**推论**，不是一条独立的规则

对应 Python `rule/step/frame_rest.py`。在 Python 那一侧它是一条要逐条判的规则（上界）；
在 Lean 这一侧，`step` 本来就只改该改的那一位，于是它是 `Step.lean` 的定义推出来的定理。

分几半：
  · **题面、答题色、焦点种类、底板**：`step` 的结果只带 `St`，`Board` 它碰不到——
    这一半**表示不出来**，不用证；底板在 Lean 里连名字都没有；
  · 左右键：答题条和图例一格都不动（`frameRest_move`）；
  · 上下键：焦点不动（`frameRest_turn_focus`），另一种站整个不动，同一种站里焦点以外的每一站不动
    （`frameRest_turn_answer` / `frameRest_turn_legend`）；
  · 每一串的颜色不动（`frameRest_colors`）。Python 那一条还说位置不动：位置在 Lean 里没有。

「对下标 i ≠ n，改第 n 个不碰第 i 个」这种列表小引理**写成证明里的 `have`**，不单独立定理：
装置的 `lean_check` 要求每条定理的语句里出现 `World` / `step` / `isGoal`（跟这一局有关），
一条关于任意列表的引理过不了这一关——而它也确实不是关于这一局的话。
-/

import Obj.World
import Step

theorem step_ok {w : World} {a : Act} {s : St} (h : step w a = .ok s) : s = after w a := by
  unfold step at h
  split at h
  · cases h
  · cases h; rfl

/-- 左右键：答题条与图例一格不动。 -/
theorem frameRest_move (w : World) (a : Act) (s : St) (ha : a = .a3 ∨ a = .a4)
    (h : step w a = .ok s) : s.answer = w.st.answer ∧ s.legend = w.st.legend := by
  rw [step_ok h]
  rcases ha with rfl | rfl <;> exact ⟨rfl, rfl⟩

/-- 上下键：焦点不动。 -/
theorem frameRest_turn_focus (w : World) (a : Act) (s : St) (ha : a = .a1 ∨ a = .a2)
    (h : step w a = .ok s) : s.focus = w.st.focus := by
  rw [step_ok h]
  rcases ha with rfl | rfl <;> simp only [after, phaseStep] <;> split <;> rfl

/-- 上下键、焦点在答题条上：图例不动，答题条上焦点以外的每一格不动。 -/
theorem frameRest_turn_answer (w : World) (a : Act) (s : St) (ha : a = .a1 ∨ a = .a2)
    (hm : w.board.legendMode = false) (h : step w a = .ok s) :
    s.legend = w.st.legend ∧ ∀ i, i ≠ w.st.focus → s.answer[i]? = w.st.answer[i]? := by
  have ne : ∀ (l : List Shape) (n i : Nat) (f : Shape → Shape), i ≠ n → (modifyAt l n f)[i]? = l[i]? := by
    intro l
    induction l with
    | nil => intro n i f _; rfl
    | cons x xs ih =>
      intro n i f hi
      cases n with
      | zero => cases i with
        | zero => exact absurd rfl hi
        | succ i => rfl
      | succ n => cases i with
        | zero => rfl
        | succ i =>
          simp only [modifyAt, List.getElem?_cons_succ]
          exact ih n i f (fun e => hi (by rw [e]))
  rw [step_ok h]
  constructor
  · rcases ha with rfl | rfl <;> simp [after, phaseStep, hm]
  · intro i hi
    rcases ha with rfl | rfl <;>
      simp only [after, phaseStep, hm, Bool.false_eq_true, ↓reduceIte] <;>
      exact ne _ _ _ _ hi

/-- 上下键、焦点在图例上：答题条不动，焦点所在那条规则以外的每一条不动。 -/
theorem frameRest_turn_legend (w : World) (a : Act) (s : St) (ha : a = .a1 ∨ a = .a2)
    (hm : w.board.legendMode = true) (h : step w a = .ok s) :
    s.answer = w.st.answer ∧ ∀ k, k ≠ w.st.focus / 2 → s.legend[k]? = w.st.legend[k]? := by
  have ne : ∀ (l : List LegendRule) (n i : Nat) (f : LegendRule → LegendRule), i ≠ n →
      (modifyAt l n f)[i]? = l[i]? := by
    intro l
    induction l with
    | nil => intro n i f _; rfl
    | cons x xs ih =>
      intro n i f hi
      cases n with
      | zero => cases i with
        | zero => exact absurd rfl hi
        | succ i => rfl
      | succ n => cases i with
        | zero => rfl
        | succ i =>
          simp only [modifyAt, List.getElem?_cons_succ]
          exact ih n i f (fun e => hi (by rw [e]))
  rw [step_ok h]
  constructor
  · rcases ha with rfl | rfl <;> simp [after, phaseStep, hm]
  · intro k hk
    rcases ha with rfl | rfl <;>
      simp only [after, phaseStep, hm, ↓reduceIte] <;>
      exact ne _ _ _ _ hk

/-- 每一步之后，图例里每一串的颜色都不动（上下键改的只是形状）。 -/
theorem frameRest_colors (w : World) (a : Act) (s : St) (h : step w a = .ok s) :
    s.legend.map (fun r => (r.key.color, r.val.color)) =
      w.st.legend.map (fun r => (r.key.color, r.val.color)) := by
  have keep : ∀ (l : List LegendRule) (n : Nat) (f : LegendRule → LegendRule),
      (∀ r, (f r).key.color = r.key.color ∧ (f r).val.color = r.val.color) →
      (modifyAt l n f).map (fun r => (r.key.color, r.val.color)) = l.map (fun r => (r.key.color, r.val.color)) := by
    intro l
    induction l with
    | nil => intro n f _; rfl
    | cons x xs ih =>
      intro n f hf
      cases n with
      | zero => simp [modifyAt, (hf x).1, (hf x).2]
      | succ n =>
        simp only [modifyAt, List.map_cons]
        rw [ih n f hf]
  have tr : ∀ (i : Nat) (up : Bool) (r : LegendRule),
      (turnRule i up r).key.color = r.key.color ∧ (turnRule i up r).val.color = r.val.color := by
    intro i up r
    unfold turnRule
    split <;> exact ⟨rfl, rfl⟩
  rw [step_ok h]
  cases a <;> simp only [after] <;> try rfl
  all_goals
    simp only [phaseStep]
    split
    · exact keep _ _ _ (tr _ _)
    · rfl

#print axioms step_ok
#print axioms frameRest_move
#print axioms frameRest_turn_focus
#print axioms frameRest_turn_answer
#print axioms frameRest_turn_legend
#print axioms frameRest_colors
