/-
# Step —— 一步怎么走：**只做分发，0 条定理**

    after w a   按一下之后的 St（照规则层的两条定义）
    step  w a   按完之后答对了 ⇒ `won`；否则 ⇒ `ok` 新的 St

结果类型里**没有编出来的分支**：
  · 过关之后下一关长什么样，模型说不出来 ⇒ `won` 不带下一帧；
  · RESET 不是一个 `Act` ⇒ 模型不描述「重来」。于是后面每一句「走不通」的准确意思都是
    **「不经过重来就走不通」**——这半句写在 `Proof/Reachable.lean` 和页面上。
  · 计数条不进模型 ⇒ 这里没有「预算用尽」那一支。语料里计数条从没吃满过，
    这一支在这批语料上**没有被检验过**，写在 gaps 里。
-/

import Rule.Step.FocusStep
import Rule.Step.PhaseStep
import Rule.Win.Goal

inductive Act where
  | a1 | a2 | a3 | a4
deriving Repr, DecidableEq, BEq

inductive Res where
  | ok (s : St)
  | won
deriving Repr, DecidableEq, BEq

def after (w : World) : Act → St
  | .a1 => phaseStep w true
  | .a2 => phaseStep w false
  | .a3 => { w.st with focus := focusStep w false }
  | .a4 => { w.st with focus := focusStep w true }

def step (w : World) (a : Act) : Res :=
  if isGoal ⟨w.board, after w a⟩ then .won else .ok (after w a)
