/-
# Obs/Check —— 判据层：两把尺子。**0 条定理**，尺子不自证。

    agreesWith f c    **一条转移**对不对：从观测到的那一帧起算一步，和看到的下一帧比
    traceWith  f w p  **一整条路**对不对：只有开局是观测给的，后面带着**自己算出来的**状态往下走

两把尺子都把 `step` 当参数收进来（`agreesWith step`、`traceWith step`）：
定理的语句里于是写着它考的是哪一个 `step`，而不是藏在一个名字后面。

## 观测只装帧上看得见的

`St` 里的三样（答题条形状、图例、焦点站号）全是帧上读得出来的；朝向、计数条、底板都不在里面，
所以尺子不会去比一位帧上没有、或模型不描述的信息。
-/

import Step

/-- 观测到的下一帧：还在这一关（读出来的 St），或者已经换关（下一帧是另一张盘）。 -/
inductive Post where
  | st (s : St)
  | levelUp
deriving Repr, DecidableEq, BEq

/-- 语料里的一条转移。 -/
structure Case where
  seq  : Nat
  w    : World
  act  : Act
  post : Post
deriving Repr

/-- 一条转移：模型算出来的和看到的一样吗。**每一支都对上一种观测**，没有「算不出来就算它对」。 -/
def agreesWith (f : World → Act → Res) (c : Case) : Bool :=
  match f c.w c.act, c.post with
  | .won, .levelUp => true
  | .ok s, .st o => s == o
  | _, _ => false

/-- 一整条路。**要害在 `⟨w.board, s⟩`**：下一轮喂进去的是模型自己算出来的状态。 -/
def traceWith (f : World → Act → Res) : World → List (Act × St) → Bool
  | _, [] => true
  | w, (a, o) :: rest =>
      match f w a with
      | .ok s => s == o && traceWith f ⟨w.board, s⟩ rest
      | .won => false

/-- **只给读数用**：第一处分家在第几步（`none` = 一处都没分家）。`#eval` 走求值器，它不是定理。 -/
def firstSplit (f : World → Act → Res) : World → List (Act × St) → Nat → Option Nat
  | _, [], _ => none
  | w, (a, o) :: rest, i =>
      match f w a with
      | .ok s => if s == o then firstSplit f ⟨w.board, s⟩ rest (i + 1) else some i
      | .won => some i
