/-
# Obs/Corpus —— 模型面对真实转移，逐条（自动生成：`python lean2/export_corpus.py`）

数据全在 `Obs/Replay.lean`，这里只按 seq 切段。共 12 段、429 条转移（不接手的 1 条不在这里，
在 `Replay.skipped` 里带着理由）。

    corpus_s<段>_L<关>   那一段里每一条：从观测到的那一帧起算一步，和看到的下一帧（或「换关了」）对上

**这是三条腿里分量轻的那一条**：每一步都被拉回观测。分量重的是 `Proof/Levels.lean` 的 `_trace`。
-/

import Obs.Replay

-- 内核算几十条转移会爆默认的递归深度。**它是独立一条命令**，夹在文档注释和定理之间会变成语法错误。
-- 爆的时候 Lean 报一行错然后照常往下编，公理表里多出 sorryAx——所以公理表覆盖率照核。
set_option maxRecDepth 200000

/-- 第 0 段、第 0 关：seq 1..59，59 条。 -/
theorem corpus_s0_L0 : (casesIn 1 59).length = 59 ∧ (casesIn 1 59).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L0

/-- 第 0 段、第 1 关：seq 60..140，81 条。 -/
theorem corpus_s0_L1 : (casesIn 60 140).length = 81 ∧ (casesIn 60 140).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L1

/-- 第 0 段、第 2 关：seq 141..216，76 条。 -/
theorem corpus_s0_L2 : (casesIn 141 216).length = 76 ∧ (casesIn 141 216).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L2

/-- 第 0 段、第 3 关：seq 217..253，37 条。 -/
theorem corpus_s0_L3 : (casesIn 217 253).length = 37 ∧ (casesIn 217 253).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L3

/-- 第 0 段、第 4 关：seq 254..286，33 条。 -/
theorem corpus_s0_L4 : (casesIn 254 286).length = 33 ∧ (casesIn 254 286).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L4

/-- 第 0 段、第 5 关：seq 287..310，24 条。 -/
theorem corpus_s0_L5 : (casesIn 287 310).length = 24 ∧ (casesIn 287 310).all (agreesWith step) = true := by
  decide

#print axioms corpus_s0_L5

/-- 第 1 段、第 0 关：seq 312..325，14 条。 -/
theorem corpus_s1_L0 : (casesIn 312 325).length = 14 ∧ (casesIn 312 325).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L0

/-- 第 1 段、第 1 关：seq 326..350，25 条。 -/
theorem corpus_s1_L1 : (casesIn 326 350).length = 25 ∧ (casesIn 326 350).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L1

/-- 第 1 段、第 2 关：seq 351..371，21 条。 -/
theorem corpus_s1_L2 : (casesIn 351 371).length = 21 ∧ (casesIn 351 371).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L2

/-- 第 1 段、第 3 关：seq 372..392，21 条。 -/
theorem corpus_s1_L3 : (casesIn 372 392).length = 21 ∧ (casesIn 372 392).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L3

/-- 第 1 段、第 4 关：seq 393..406，14 条。 -/
theorem corpus_s1_L4 : (casesIn 393 406).length = 14 ∧ (casesIn 393 406).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L4

/-- 第 1 段、第 5 关：seq 407..430，24 条。 -/
theorem corpus_s1_L5 : (casesIn 407 430).length = 24 ∧ (casesIn 407 430).all (agreesWith step) = true := by
  decide

#print axioms corpus_s1_L5

/- **读数**（不是定理）：每一条的判决，给 `verify.py` 和 Python 那一侧逐条对账。
   （文档注释不许挂在 `#eval` 上，那是语法错误——实测撞过一次。
    这句话里也不能写出文档注释的开头记号：Lean 的块注释会嵌套，写出来就又开了一层——也撞过一次。） -/
#eval "CORPUS " ++ toString (rows.map (fun r => (r.seq, agreesWith step (caseOf r))))
