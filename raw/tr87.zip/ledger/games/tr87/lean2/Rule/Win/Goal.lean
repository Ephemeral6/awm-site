/-
# Rule/Win/Goal —— 什么算答对（**定义**）

对应 Python `rule/win/win_exact.py`（主张）与 `derive/target.py`（Python 那一侧的算法）。
两份**各自独立写**，逐条对账在 `Obs/Corpus.lean` ⇄ `run_rules.py` 的判决之间做。

    目标 = 题面沿图例的颜色链反复改写：一轮里把序列从左到右切段，每段等于同一对（键色, 值色）
           下某条规则的键串，换成它的值串；序列颜色从键色变成值色；改到答题色为止。
    答对 = 答题条的形状序列 ∈ 目标。

最多改几轮：图例里出现过的颜色种数 + 1（与 Python 同一个上界）。

`isGoal` 是**状态**的性质，不是「过关」这个事件——于是「这个局面可不可做」问得出来。
-/

import Obj.World

/-- 一轮改写的全部结果。`fuel` 取序列长度就够：每一段至少吃掉一格。 -/
def rewriteAll (rules : List (List Shape × List Shape)) : Nat → List Shape → List (List Shape)
  | _, [] => [[]]
  | 0, _ :: _ => []
  | fuel + 1, s :: ss =>
      rules.flatMap (fun kv =>
        if !kv.1.isEmpty && kv.1.isPrefixOf (s :: ss) then
          (rewriteAll rules fuel ((s :: ss).drop kv.1.length)).map (fun rest => kv.2 ++ rest)
        else [])

/-- 图例里出现过的（键色, 值色）对，去重。 -/
def colorPairs (l : Legend) : List (Nat × Nat) := (l.map (fun r => (r.key.color, r.val.color))).eraseDups

def groupRules (l : Legend) (p : Nat × Nat) : List (List Shape × List Shape) :=
  (l.filter (fun r => r.key.color == p.1 && r.val.color == p.2)).map (fun r => (r.key.shapes, r.val.shapes))

/-- 一轮：颜色已经是答题色的收下；其余的按每一对键色相同的（键色, 值色）改写一次。 -/
def chainRound (l : Legend) (ac : Nat) (fr : List (Nat × List Shape)) :
    List (List Shape) × List (Nat × List Shape) :=
  (fr.filterMap (fun cs => if cs.1 == ac then some cs.2 else none),
   fr.flatMap (fun cs =>
     if cs.1 == ac then []
     else (colorPairs l).flatMap (fun p =>
       if p.1 == cs.1 then (rewriteAll (groupRules l p) cs.2.length cs.2).map (fun r => (p.2, r))
       else [])))

def chain (l : Legend) (ac : Nat) : Nat → List (Nat × List Shape) → List (List Shape)
  | 0, _ => []
  | k + 1, fr =>
      match chainRound l ac fr with
      | (out, nxt) => out ++ chain l ac k nxt

def legendColors (l : Legend) : List Nat := ((colorPairs l).flatMap (fun p => [p.1, p.2])).eraseDups

def targets (w : World) : List (List Shape) :=
  chain w.st.legend w.board.ansColor ((legendColors w.st.legend).length + 1)
    [(w.board.prompt.color, w.board.prompt.shapes)]

/-- **答对**：答题条 ∈ 目标。 -/
def isGoal (w : World) : Bool := (targets w).contains w.st.answer
