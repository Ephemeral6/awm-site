/-
# Rule/Step/PhaseStep —— 上下键：焦点那一串里每一格的相位 ±1（模 7），族不变（**定义**）

对应 Python `rule/step/phase_step.py`。

焦点在答题条上：改答题条的第 `focus` 格。
焦点在图例上：第 `focus / 2` 条规则；`focus` 是偶数改它的键串，奇数改它的值串。
-/

import Obj.World

/-- 相位 +1（up）或 −1，族不变。 -/
def shiftShape (s : Shape) (up : Bool) : Shape :=
  s / 7 * 7 + (if up then (s % 7 + 1) % 7 else (s % 7 + 6) % 7)

/-- 只改第 n 个。自己写一份，不依赖标准库里参数次序换过几次的 `List.modify`。 -/
def modifyAt {α : Type} : List α → Nat → (α → α) → List α
  | [], _, _ => []
  | x :: xs, 0, f => f x :: xs
  | x :: xs, n + 1, f => x :: modifyAt xs n f

def turnRun (r : Run) (up : Bool) : Run := { r with shapes := r.shapes.map (fun s => shiftShape s up) }

def turnRule (i : Focus) (up : Bool) (r : LegendRule) : LegendRule :=
  if i % 2 == 0 then { r with key := turnRun r.key up } else { r with val := turnRun r.val up }

def phaseStep (w : World) (up : Bool) : St :=
  if w.board.legendMode then
    { w.st with legend := modifyAt w.st.legend (w.st.focus / 2) (turnRule w.st.focus up) }
  else
    { w.st with answer := modifyAt w.st.answer w.st.focus (fun s => shiftShape s up) }
