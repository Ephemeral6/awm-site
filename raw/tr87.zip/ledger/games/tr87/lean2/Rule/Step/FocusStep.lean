/-
# Rule/Step/FocusStep —— 左右键：焦点沿「可停的各站」走一站（**定义**）

对应 Python `rule/step/focus_step.py`。

    ACTION4（fwd = true）   下一站；走到最后一站之后绕回第 0 站
    ACTION3（fwd = false）  上一站；在第 0 站时绕到最后一站

「站的种类不变」不在这里：种类住在 `Board`，`step` 碰不到它（见 `Obj/World.lean`）。
-/

import Obj.World

def focusStep (w : World) (fwd : Bool) : Focus :=
  if fwd then (w.st.focus + 1) % w.nStops
  else (w.st.focus + w.nStops - 1) % w.nStops
