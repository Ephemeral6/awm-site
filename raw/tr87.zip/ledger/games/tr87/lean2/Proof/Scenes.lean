/-
# Proof/Scenes —— 两把钥匙各套在一张盘上，每张盘配三条防线

两张盘都是**第 0 关真实开局只改一处**（`Levels.L0_start`，从语料的帧里读出来的）：

    scene1   题面第 0 格换成形状 2——图例里没有一条规则的键是它     ⇒ 钥匙一（读不出目标）
    scene2   答题条第 0 格换成形状 0（族 0）——目标第 0 格要的是族 2  ⇒ 钥匙二（族守恒）

每把钥匙三条防线（一个「对谁都说走不通」的判据也能满绿，所以缺一不可）：

    L0 走得通          只差一处的那张盘确实赢得了（`Levels.L0_winnable`，见证是真人走过的路）
    L0 不是一开局就通   `L0_closed_at_start`
    L0 上钥匙套不上     `L0_not_noTarget` / `L0_not_famLock` —— 钥匙套不上是因为**前提不满足**，
                        不是「前提满足而没找到证明」

**「走不通」的准确意思是「不经过重来就走不通」**（见 `Proof/Reachable.lean` 文件头）。

这两张盘是**手造的教学盘**，不是语料里的局面：真人六关全过了，语料里没有一张走不通的盘。
-/

import Obj.World
import Proof.Reachable
import Proof.Levels

/-- 第 0 关开局，只把题面第 0 格换成形状 2。 -/
def scene1 : World :=
  { L0_start with board := { L0_start.board with prompt := ⟨L0_start.board.prompt.color, 2 :: L0_start.board.prompt.shapes.tail⟩ } }

/-- 第 0 关开局，只把答题条第 0 格换成形状 0。 -/
def scene2 : World :=
  { L0_start with st := { L0_start.st with answer := 0 :: L0_start.st.answer.tail } }

theorem scene1_noTarget : NoTarget (scene1 : World) := by decide
theorem scene1_unsolvable : Unsolvable (scene1 : World) := unsolvable_noTarget scene1 scene1_noTarget

theorem scene2_famLock : FamLock (scene2 : World) := by decide
theorem scene2_unsolvable : Unsolvable (scene2 : World) := unsolvable_famLock scene2 scene2_famLock

/-- 防线：只差一处的那张盘不是一开局就通的。 -/
theorem L0_closed_at_start : isGoal (L0_start : World) = false := by decide

/-- 防线：钥匙一在只差一处的那张盘上**前提不满足**（目标不是空的）。 -/
theorem L0_not_noTarget : ¬ NoTarget (L0_start : World) := by decide

/-- 防线：钥匙二在只差一处的那张盘上**前提不满足**（有一个目标和答题条同族）。 -/
theorem L0_not_famLock : ¬ FamLock (L0_start : World) := by decide

/-- 两张教学盘都**确实**和 L0 开局只差一处（不是看起来像）。 -/
theorem scenes_one_edit :
    (scene1 : World).st = L0_start.st ∧ scene1.board.ansColor = L0_start.board.ansColor ∧
    scene1.board.prompt.shapes.tail = L0_start.board.prompt.shapes.tail ∧
    scene1.board.prompt.shapes.head? ≠ L0_start.board.prompt.shapes.head? ∧
    (scene2 : World).board = L0_start.board ∧ scene2.st.answer.tail = L0_start.st.answer.tail ∧
    scene2.st.answer.head? ≠ L0_start.st.answer.head? := by
  decide

#print axioms scene1_noTarget
#print axioms scene1_unsolvable
#print axioms scene2_famLock
#print axioms scene2_unsolvable
#print axioms L0_closed_at_start
#print axioms L0_not_noTarget
#print axioms L0_not_famLock
#print axioms scenes_one_edit
