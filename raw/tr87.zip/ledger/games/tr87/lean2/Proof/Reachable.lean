/-
# Proof/Reachable —— 这个**局面**做不做得了：定义、骨架、两把钥匙

**这一份一条语料都不用**（只依赖 `step` 与 `isGoal`）。钥匙套到具体的盘上是 `Proof/Scenes.lean` 的事。

## 合法的一步

`Act` 只有这一局真有的四个动作（上下左右），**没有任意位移**，所以不需要另写 `legal`：
类型本身就把「一步跨到目标」这种事排除了。

## 「走不通」的准确意思：**不经过重来就走不通**

`step` 里没有 RESET（它不是一个 `Act`），也没有「计数条吃满」那一支（计数条不进模型）。所以

    Unsolvable w  =  ∀ as, everGoal step w as = false

说的是「**只按上下左右、不经过重来**，任何按法都答不对」。重来之后回到开局，
而开局本身就是被判「走不通」的那张盘——但这一句是关于游戏的说法，**模型里没有它**，写在这里不证。

## 骨架（全文唯一做归纳的地方）

找一个每一步都保持、且和「答对」矛盾的性质 Φ：从满足 Φ 的局面出发，任何按法都赢不了。
和盘面多大、按多少下都无关，不枚举任何状态。
-/

import Obj.World
import Step
import Derived.FrameRest

/-- 沿着 `as` 按下去，中途有没有哪一下过关。 -/
def everGoal (f : World → Act → Res) : World → List Act → Bool
  | _, [] => false
  | w, a :: as =>
      match f w a with
      | .won => true
      | .ok s => everGoal f ⟨w.board, s⟩ as

def Winnable (w : World) : Prop := ∃ as : List Act, everGoal step w as = true

/-- **不经过重来**，任何按法都答不对。 -/
def Unsolvable (w : World) : Prop := ∀ as : List Act, everGoal step w as = false

theorem not_both (w : World) (h1 : Winnable w) (h2 : Unsolvable w) : False := by
  obtain ⟨as, h⟩ := h1
  rw [h2 as] at h
  exact Bool.false_ne_true h

/-- **骨架**：Φ 每步都保持、且满足 Φ 时这一步不可能过关 ⇒ 从满足 Φ 的局面出发走不通。 -/
theorem unsolvable_of_invariant (P : World → Prop)
    (hkeep : ∀ (w : World) (a : Act) (s : St), P w → step w a = .ok s → P ⟨w.board, s⟩)
    (hwin : ∀ (w : World) (a : Act), P w → step w a ≠ .won) :
    ∀ w : World, P w → Unsolvable w := by
  intro w hp as
  induction as generalizing w with
  | nil => rfl
  | cons a t ih =>
    simp only [everGoal]
    cases hs : step w a with
    | won => exact absurd hs (hwin w a hp)
    | ok s => exact ih ⟨w.board, s⟩ (hkeep w a s hp hs)

/-! ## 两把钥匙都要用的一件事：焦点在答题条上时，图例一步之内不动，所以目标不动 -/

theorem after_legend (w : World) (a : Act) (hm : w.board.legendMode = false) :
    (after w a).legend = w.st.legend := by
  cases a <;> simp [after, phaseStep, hm]

theorem targets_congr (w w' : World) (hb : w.board = w'.board) (hl : w.st.legend = w'.st.legend) :
    targets w = targets w' := by
  unfold targets
  rw [hb, hl]

theorem isGoal_iff (w : World) : isGoal w = true ↔ w.st.answer ∈ targets w := by
  unfold isGoal
  simp

/-! ## 钥匙一：**读不出目标**（图例冻住了，而题面照它改写不出答题色）

    Φ₁ w  :=  焦点在答题条上  ∧  目标集合是空的

焦点在答题条上 ⇒ 图例一格都动不了（`after_legend`）⇒ 目标一步之内不变 ⇒ 永远是空的；
空的目标里没有任何一条答题条。**这把钥匙和答题条长什么样无关**：答题条随便怎么拨都没用。 -/

abbrev NoTarget (w : World) : Prop := w.board.legendMode = false ∧ targets w = []

theorem noTarget_keep : ∀ (w : World) (a : Act) (s : St), NoTarget w → step w a = .ok s →
    NoTarget ⟨w.board, s⟩ := by
  intro w a s ⟨hm, ht⟩ h
  refine ⟨hm, ?_⟩
  rw [step_ok h, targets_congr ⟨w.board, after w a⟩ w rfl (after_legend w a hm)]
  exact ht

theorem noTarget_no_win : ∀ (w : World) (a : Act), NoTarget w → step w a ≠ .won := by
  intro w a ⟨hm, ht⟩ h
  unfold step at h
  split at h
  · rename_i hg
    rw [isGoal_iff, targets_congr ⟨w.board, after w a⟩ w rfl (after_legend w a hm), ht] at hg
    exact absurd hg (List.not_mem_nil)
  · cases h

theorem unsolvable_noTarget (w : World) (h : NoTarget w) : Unsolvable w :=
  unsolvable_of_invariant NoTarget noTarget_keep noTarget_no_win w h

/-! ## 钥匙二：**族守恒**（每一个目标都至少有一格和答题条不同族）

    Φ₂ w  :=  焦点在答题条上  ∧  答题条每一格都是合法形状（< 21）
              ∧  每一个目标的「族序列」都 ≠ 答题条的「族序列」

上下键只改相位、不改族（`shiftShape_fam`）⇒ 答题条的族序列永远不变；图例不动 ⇒ 目标不变。
**这把钥匙和上一把的理由不同**：目标可以是非空的、也可以离答对只差一两下相位——
差的是「族」这一位，而没有任何一下能改它。 -/

def fams (l : List Shape) : List Nat := l.map (fun s => s / 7)

/-- 焦点在答题条上时，按一下之后答题条的族序列不变、每一格仍是合法形状。
    用到的几条小引理（相位挪一下族不变、改一格不碰别的格）写成这里的 `have`：
    它们说的是任意自然数、任意列表，不是这一局的话（装置 `lean_check` 也按这个判）。 -/
theorem after_answer_ok (w : World) (a : Act) (hm : w.board.legendMode = false)
    (hlt : ∀ x ∈ w.st.answer, x < 21) :
    fams (after w a).answer = fams w.st.answer ∧ ∀ x ∈ (after w a).answer, x < 21 := by
  have shiftShape_fam : ∀ (s : Nat) (up : Bool), shiftShape s up / 7 = s / 7 := by
    intro s up
    cases up
    · show (s / 7 * 7 + (s % 7 + 6) % 7) / 7 = s / 7
      omega
    · show (s / 7 * 7 + (s % 7 + 1) % 7) / 7 = s / 7
      omega
  have shiftShape_lt : ∀ (s : Nat) (up : Bool), s < 21 → shiftShape s up < 21 := by
    intro s up h
    cases up
    · show s / 7 * 7 + (s % 7 + 6) % 7 < 21
      omega
    · show s / 7 * 7 + (s % 7 + 1) % 7 < 21
      omega
  have modifyAt_forall : ∀ (l : List Nat) (n : Nat) (f : Nat → Nat),
      (∀ x, x < 21 → f x < 21) → (∀ x ∈ l, x < 21) → ∀ x ∈ modifyAt l n f, x < 21 := by
    intro l
    induction l with
    | nil => intro n f _ _ x hx; simp [modifyAt] at hx
    | cons y ys ih =>
      intro n f hf hl x hx
      cases n with
      | zero =>
        simp only [modifyAt, List.mem_cons] at hx
        rcases hx with rfl | hx
        · exact hf y (hl y (by simp))
        · exact hl x (by simp [hx])
      | succ n =>
        simp only [modifyAt, List.mem_cons] at hx
        rcases hx with rfl | hx
        · exact hl x (by simp)
        · exact ih n f hf (fun z hz => hl z (by simp [hz])) x hx
  have modifyAt_map : ∀ (l : List Nat) (n : Nat) (f : Nat → Nat),
      (∀ x, f x / 7 = x / 7) → (modifyAt l n f).map (fun s => s / 7) = l.map (fun s => s / 7) := by
    intro l
    induction l with
    | nil => intro n f _; rfl
    | cons y ys ih =>
      intro n f hf
      cases n with
      | zero => simp [modifyAt, hf y]
      | succ n =>
        simp only [modifyAt, List.map_cons]
        rw [ih n f hf]
  cases a
  case a3 => exact ⟨rfl, hlt⟩
  case a4 => exact ⟨rfl, hlt⟩
  all_goals
    simp only [after, phaseStep, hm, Bool.false_eq_true, ↓reduceIte]
    exact ⟨modifyAt_map _ _ _ (fun x => shiftShape_fam x _),
           modifyAt_forall _ _ _ (fun x hx => shiftShape_lt x _ hx) hlt⟩

abbrev FamLock (w : World) : Prop :=
  w.board.legendMode = false ∧ (∀ x ∈ w.st.answer, x < 21) ∧
  ∀ t ∈ targets w, fams t ≠ fams w.st.answer

theorem famLock_keep : ∀ (w : World) (a : Act) (s : St), FamLock w → step w a = .ok s →
    FamLock ⟨w.board, s⟩ := by
  intro w a s ⟨hm, hlt, hne⟩ h
  rw [step_ok h]
  obtain ⟨hf, hlt'⟩ := after_answer_ok w a hm hlt
  refine ⟨hm, hlt', ?_⟩
  intro t ht
  rw [targets_congr ⟨w.board, after w a⟩ w rfl (after_legend w a hm)] at ht
  show fams t ≠ fams (after w a).answer
  rw [hf]
  exact hne t ht

theorem famLock_no_win : ∀ (w : World) (a : Act), FamLock w → step w a ≠ .won := by
  intro w a ⟨hm, hlt, hne⟩ h
  unfold step at h
  split at h
  · rename_i hg
    rw [isGoal_iff, targets_congr ⟨w.board, after w a⟩ w rfl (after_legend w a hm)] at hg
    exact hne _ hg (after_answer_ok w a hm hlt).1
  · cases h

theorem unsolvable_famLock (w : World) (h : FamLock w) : Unsolvable w :=
  unsolvable_of_invariant FamLock famLock_keep famLock_no_win w h

#print axioms not_both
#print axioms unsolvable_of_invariant
#print axioms after_legend
#print axioms targets_congr
#print axioms isGoal_iff
#print axioms noTarget_keep
#print axioms noTarget_no_win
#print axioms unsolvable_noTarget
#print axioms after_answer_ok
#print axioms famLock_keep
#print axioms famLock_no_win
#print axioms unsolvable_famLock
