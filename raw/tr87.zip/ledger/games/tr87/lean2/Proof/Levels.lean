/-
# Proof/Levels —— 每一关一条定理（自动生成：`python lean2/export_levels.py`）

见证路线只取**成绩单认证的那一段**（第 1 段）。每一关两条：

    L<n>_trace      沿真人走过的那条路，模型**每一帧**都和观测对上——只有开局是观测给的，
                    后面全是模型自己算的。长度写在同一条定理里（路切歪成空表会让它平凡为真）
    L<n>_winnable   这一关走得通：见证 = 那条路 + 过关那一脚

`_unsolvable` 一条都没有：六关在语料里都通过了，这是结论，不是缺口。

每关核过的步数（逐帧对上的那一段，不含过关那一脚）：L0 13 · L1 24 · L2 20 · L3 20 · L4 13 · L5 23

这一段里**没有一次重来**（交叉检查：计数条一关之内从没往回掉；RESET 只在这一段的开头那一下，不在任何一关中间），
所以这里用不上「重来一次放回开局」那条假设——它在这一份里**没有出场**，也就没有被检验过。
-/

import Obj.World
import Obs.Replay
import Proof.Reachable

-- 独立一条命令（夹在文档注释和定理之间会变成语法错误）；爆深度时 Lean 只报一行然后照常往下编。
set_option maxRecDepth 200000

/-- 第 0 关的真实开局：认证段 seq 312 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L0_start : World := worldOf (rowAt 312)

/-- 开局到过关前一步，13 步（seq 312..324）。 -/
def L0_play : List (Act × St) := pathIn 312 324

/-- 过关那一脚（seq 325）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L0_win : Act := (rowAt 325).act

#eval match firstSplit step L0_start L0_play 0 with
  | none   => "L0  一处都没分家（共 " ++ toString L0_play.length ++ " 步）"
  | some i => "L0  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 13 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L0_trace : L0_play.length = 13 ∧ traceWith step (L0_start : World) L0_play = true := by
  decide

/-- **第 0 关走得通。** 见证 = 那 13 步 + 过关那一脚。 -/
theorem L0_winnable : Winnable (L0_start : World) :=
  ⟨L0_play.map Prod.fst ++ [L0_win], by decide⟩

#print axioms L0_trace
#print axioms L0_winnable

/-- 第 1 关的真实开局：认证段 seq 326 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L1_start : World := worldOf (rowAt 326)

/-- 开局到过关前一步，24 步（seq 326..349）。 -/
def L1_play : List (Act × St) := pathIn 326 349

/-- 过关那一脚（seq 350）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L1_win : Act := (rowAt 350).act

#eval match firstSplit step L1_start L1_play 0 with
  | none   => "L1  一处都没分家（共 " ++ toString L1_play.length ++ " 步）"
  | some i => "L1  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 24 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L1_trace : L1_play.length = 24 ∧ traceWith step (L1_start : World) L1_play = true := by
  decide

/-- **第 1 关走得通。** 见证 = 那 24 步 + 过关那一脚。 -/
theorem L1_winnable : Winnable (L1_start : World) :=
  ⟨L1_play.map Prod.fst ++ [L1_win], by decide⟩

#print axioms L1_trace
#print axioms L1_winnable

/-- 第 2 关的真实开局：认证段 seq 351 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L2_start : World := worldOf (rowAt 351)

/-- 开局到过关前一步，20 步（seq 351..370）。 -/
def L2_play : List (Act × St) := pathIn 351 370

/-- 过关那一脚（seq 371）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L2_win : Act := (rowAt 371).act

#eval match firstSplit step L2_start L2_play 0 with
  | none   => "L2  一处都没分家（共 " ++ toString L2_play.length ++ " 步）"
  | some i => "L2  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 20 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L2_trace : L2_play.length = 20 ∧ traceWith step (L2_start : World) L2_play = true := by
  decide

/-- **第 2 关走得通。** 见证 = 那 20 步 + 过关那一脚。 -/
theorem L2_winnable : Winnable (L2_start : World) :=
  ⟨L2_play.map Prod.fst ++ [L2_win], by decide⟩

#print axioms L2_trace
#print axioms L2_winnable

/-- 第 3 关的真实开局：认证段 seq 372 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L3_start : World := worldOf (rowAt 372)

/-- 开局到过关前一步，20 步（seq 372..391）。 -/
def L3_play : List (Act × St) := pathIn 372 391

/-- 过关那一脚（seq 392）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L3_win : Act := (rowAt 392).act

#eval match firstSplit step L3_start L3_play 0 with
  | none   => "L3  一处都没分家（共 " ++ toString L3_play.length ++ " 步）"
  | some i => "L3  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 20 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L3_trace : L3_play.length = 20 ∧ traceWith step (L3_start : World) L3_play = true := by
  decide

/-- **第 3 关走得通。** 见证 = 那 20 步 + 过关那一脚。 -/
theorem L3_winnable : Winnable (L3_start : World) :=
  ⟨L3_play.map Prod.fst ++ [L3_win], by decide⟩

#print axioms L3_trace
#print axioms L3_winnable

/-- 第 4 关的真实开局：认证段 seq 393 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L4_start : World := worldOf (rowAt 393)

/-- 开局到过关前一步，13 步（seq 393..405）。 -/
def L4_play : List (Act × St) := pathIn 393 405

/-- 过关那一脚（seq 406）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L4_win : Act := (rowAt 406).act

#eval match firstSplit step L4_start L4_play 0 with
  | none   => "L4  一处都没分家（共 " ++ toString L4_play.length ++ " 步）"
  | some i => "L4  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 13 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L4_trace : L4_play.length = 13 ∧ traceWith step (L4_start : World) L4_play = true := by
  decide

/-- **第 4 关走得通。** 见证 = 那 13 步 + 过关那一脚。 -/
theorem L4_winnable : Winnable (L4_start : World) :=
  ⟨L4_play.map Prod.fst ++ [L4_win], by decide⟩

#print axioms L4_trace
#print axioms L4_winnable

/-- 第 5 关的真实开局：认证段 seq 407 那一帧（**从语料的帧里读出来的**，不是手写的盘）。 -/
def L5_start : World := worldOf (rowAt 407)

/-- 开局到过关前一步，23 步（seq 407..429）。 -/
def L5_play : List (Act × St) := pathIn 407 429

/-- 过关那一脚（seq 430）。它的下一帧是下一关的盘，观测对不上，所以不在路里。 -/
def L5_win : Act := (rowAt 430).act

#eval match firstSplit step L5_start L5_play 0 with
  | none   => "L5  一处都没分家（共 " ++ toString L5_play.length ++ " 步）"
  | some i => "L5  第 " ++ toString i ++ " 步分家"

/-- **模型沿这条 23 步的路一步不差**：只有开局是观测给的，后面全是它自己算的。 -/
theorem L5_trace : L5_play.length = 23 ∧ traceWith step (L5_start : World) L5_play = true := by
  decide

/-- **第 5 关走得通。** 见证 = 那 23 步 + 过关那一脚。 -/
theorem L5_winnable : Winnable (L5_start : World) :=
  ⟨L5_play.map Prod.fst ++ [L5_win], by decide⟩

#print axioms L5_trace
#print axioms L5_winnable

