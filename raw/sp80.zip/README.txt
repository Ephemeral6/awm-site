Raw files of sp80, unedited, paths relative to the bench repository.
Lean: leanprover/lean4:v4.34.0 (lean-toolchain). To re-check: lean archive/sp80-20260923/formal/Game.lean, with
'#print axioms consistent' and '#print axioms faithful' appended (see VERIFY-recheck-20261023.json).
VERIFY.json is the record made at sealing; VERIFY-recheck-20261023.json is the 2026-10-23 re-check.
