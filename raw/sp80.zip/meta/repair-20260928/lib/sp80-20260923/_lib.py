"""这一局的词汇表 —— **每个定义都是假设，不是装置给的事实**。

实测来的读法（sp80）：整帧 64x64 是一张逻辑棋盘折叠而成。**第 0~2 关**每个逻辑格 4x4 像素、
相位 (0, 0)、16x16 格；**第 3 关起格子变成 3x3 像素、相位 (2, 2)、20x20 格**（第 1180 步换关后实测：
球/发射器/杆都只有 3 像素高，两侧各 2 像素墙，HUD 在像素行 0、其下一条 1 像素的地板）。
所以 CELL 与 PHASE 不再是常量，由 `geometry(g)` 从帧上量：球（色6）从不移动、每关都有，
它的包围盒边长就是格子边长，它的左上角对格子边长取模就是相位。
行 0 那一条 64 像素是 HUD（色14 剩余 / 色0 已耗），不属于棋盘内容；第 1、2 关它在像素行 63。

玩家块 me：色9 的连通块，一条横杆。返回像素坐标 (top_row, left_col)。
walls 仍是 None：撞出来的边界还没和帧上的任何颜色对上。
"""
from __future__ import annotations

from geo import cells_of  # noqa: F401

CELL = 4               # 第 0~2 关实测：所有物件的边长与所有位移都是 4 的倍数。**第 3 关是 3**，用 cell_size(g)
PHASE = (0, 0)         # 第 0~2 关实测：物件 bbox 的行/列起点都 ≡ 0 (mod 4)。第 3 关是 (2, 2)，用 geometry(g)
DELTA = {              # 第 0~2 关实测：每个动作让色9 横杆移动的像素位移（未被挡住时）。新概念用 delta(g, action)
    "ACTION1": (-4, 0),
    "ACTION2": (4, 0),
    "ACTION3": (0, -4),
    "ACTION4": (0, 4),
    "ACTION5": (0, 0),
}
STEP = {               # 每个动作让色9 移动的**逻辑格**位移（行, 列），与格子边长无关
    "ACTION1": (-1, 0),
    "ACTION2": (1, 0),
    "ACTION3": (0, -1),
    "ACTION4": (0, 1),
    "ACTION5": (0, 0),
}

HUD_ROW = 0            # 实测：第 0 关的 HUD 在像素行 0。**第 1 关它在像素行 63**——
                       # 这个常量只对第 0 关成立，新概念请改用 hud_row(g) 现场找。
PLAYER = 9             # 实测：只有色9 的格子会随 ACTION1-4 移动
UNSEL = 8              # 实测：未选中的块
UNSEL2 = 15            # 第 4 关实测（第 1240、1247 步）：**未选中的块不止一种颜色**。
                       # 那一关的三格拐角块没被选中时是色15，被点中变色9，放下又变回色15；
                       # 三根横杆放下变回的仍是色8。所以「未选中色」是每一块自己的属性，不是全局一个值。
                       # 第 1247 步的账：点中宽5 杆的同时拐角块退回色15，
                       # 色8∪色9 从 15 格掉到 12 格（看着像凭空少了三格），
                       # 而色8∪色9∪色15 前后都是 15 格——加上它，守恒才成立。
BALL = 6               # 实测：球
LAUNCHER = 4           # 实测：发射器，紧贴着球
CUP = 11               # 实测：杯
FLOOR = 1              # 实测：地板/墙。第 0~1 关是最底下一行，第 2~3 关是最上面一行，
                       # 第 4 关是「最上面一行 + 最左边一列」两条——它总是垫在杯或发射器的背后。
BOARD = 16            # 第 0~2 关实测：16x16 逻辑格。第 3 关是 20x20，用 geometry(g)
PIECE = (UNSEL, PLAYER, LAUNCHER, UNSEL2)   # 「块格」：未选中（两种颜色）、选中，以及**嵌在杆里的**发射器格。
                       # 第 3 关实测（第 1182 步）：有一根宽7 的杆中间嵌着一格色4，点它整根变色9、
                       # 挪它色4 跟着走——所以色4 既可能是球边上那个静物，也可能是某根杆的一格。
                       # 拿它做 4-连通时会把球边上的静物也算进来，那只会让连通区变大，不会让它变小。
INVENTORY_L1 = 11      # 第 1 关的家当：宽5 + 宽3 + 宽3。走闸的那条是 level1_inventory_at_most_11

# 每一关的家当（棋子逻辑格总数），拿**杯口列集合**当关卡指纹——它帧上读得出来，
# 而 ctx 里的 level 在 _lib 这一层拿不到。实测：
#   第 0 关 杯口 (5, 11)    一块 宽5                     = 5
#   第 1 关 杯口 (4, 8, 12) 三块 宽5 + 宽3 + 宽3          = 11
#   第 2 关 杯口 (2, 7, 13) 四块 宽6 + 宽6 + 宽5 + 宽4    = 21
#   第 3 关 杯口 (3, 9, 13, 17) 宽5 + 宽5 + 宽3 + 宽3 + 宽4 + 宽4 = 24（帧上数的；带9 那根 888·4·888 里的色4 不算块）
#   第 4 关 杯口 (2, 6, 12, 16) 宽4 + 宽3 + 宽5 + 一个三格拐角块 = 15（帧上数的，第 1240 步）
#   第 5 关 杯口 (2, 9, 17) 宽5杆（中间那格色4 不算）+ 竖4杆 + 两个三格拐角块 = 4+4+3+3 = 14
#           （probe86 在这一关的 163 帧上数过：155 帧可见 14 格、8 帧 13 格，最大值 14）
# 这是一张假设表：新关卡进来时它答不上来，nothing_hidden 就返回 False（变哑，不乱说）。
# 每进一关要补一行——补之前先在帧上数一遍，别照着上一关猜。
INVENTORY_BY_MOUTHS = {
    (5, 11): 5,
    (4, 8, 12): 11,
    (2, 7, 13): 21,
    (3, 9, 13, 17): 24,
    (2, 6, 12, 16): 15,
    (2, 9, 17): 14,
}

# 每一关色4（发射器格）的家当，同一张杯口指纹。为什么要单独一张：
# 上面那张只清点色 8/15/9，而**发射器格嵌在杆里、会跟着杆一起被压住**——
# 压住一格色4 不改变 8/15/9 的计数，于是「可见恰好等于家当」照样成立，夹子就说没人被压住。
# 实测（probe_color4_inventory.py，扫全部 2030 个 tid 的 prev 与 next）：
#   (5, 11) 恒 1 · (4, 8, 12) 恒 1 · (2, 7, 13) 恒 3 · (2, 6, 12, 16) 恒 2
#   (3, 9, 13, 17) 678 帧 2、6 帧 1 · (2, 9, 17) 737 帧 2、6 帧 1
# 只有那两关出现过「少一格」，而少的那几帧正是有东西被压住的帧——取最大值当家当。
LAUNCHER_BY_MOUTHS = {
    (5, 11): 1,
    (4, 8, 12): 1,
    (2, 7, 13): 3,
    (3, 9, 13, 17): 2,
    (2, 6, 12, 16): 2,
    (2, 9, 17): 2,
}

# 每一关各块的宽度（逻辑格），同样拿杯口列集合当关卡指纹。帧上数出来的：
#   第 0 关 (5,)            第 1 关 (5, 3, 3)
#   第 2 关 (6, 6, 5, 4)    第 3 关 (5, 5, 7, 4, 4)
# 第 3 关那根宽7 中间嵌着一格色4（发射器），它跟着整根走，所以算进宽里；
# 也正因为它，色8 的格数（24）比宽度之和（25）少一格。
# 和 INVENTORY_BY_MOUTHS 一样是假设表，新关卡进来时答不上来 → solo_widths 返回空集合（变哑，不乱说）。
PIECE_WIDTHS_BY_MOUTHS = {
    (5, 11): (5,),
    (4, 8, 12): (5, 3, 3),
    (2, 7, 13): (6, 6, 5, 4),
    (3, 9, 13, 17): (5, 5, 7, 4, 4),
    (2, 6, 12, 16): (4, 3, 5),
    # 第 4 关 (2, 6, 12, 16) 只列三根横杆，**那个三格拐角块故意不列**（第 1242 步补的）。
    # 理由不是「它没有宽度」，是这张表只被 solo_widths 用，而 solo_widths 只被
    # 「某一条**单逻辑行的整齐矩形**会不会其实是两块粘在一起」这个问题用。
    # 拐角块横跨两个逻辑行，它一旦落进某个连通区，那个连通区就不是单行矩形了，
    # 问题本身在那里问不出口。把它的 2 或 1 写进来只会让 3+2=5 这种和把宽5 也判成「拼得出来」，
    # 白白让读法变哑。三根杆的两两之和是 7/8/9/12，所以 3、4、5 都只可能是一整块。
}


def _sums(widths):
    """widths 这个多重集里，取 ≥2 块能拼出来的宽度之和的集合。"""
    reach = {0: 0}                      # 和 → 用了几块
    for w in widths:
        for s, k in list(reach.items()):
            if reach.get(s + w, 99) > k + 1:
                reach[s + w] = k + 1
    return {s for s, k in reach.items() if k >= 2}


def _solo_widths(b):   # 修复 2026-09-29：退出状态（改成私有名），见文件末尾「退出状态的原读数」
    """本关里「宽度一报出来就知道是一整块」的那些宽度。

    由来：块并排时在帧上并成一条，块与块的边界看不见（action6_click_selects_that_piece v2 的四条反例）。
    但如果一条段的宽度在本关的块宽清单里、又拼不出来（不等于任何两块以上的宽度之和），
    那它只可能是一整块。第 1 关是 {3, 5}（3+3=6、3+5=8、5+5=10 都不是块宽）；
    第 2、3 关最窄两块之和都大于最宽的一块，所以每个宽度都是独一无二的。
    关卡指纹不在表里返回空集合。
    """
    ws = PIECE_WIDTHS_BY_MOUTHS.get(tuple(sorted(cup_mouths(b))))
    if not ws:
        return set()
    bad = _sums(ws)
    return {w for w in set(ws) if w not in bad}


def _cells(g, color):
    return [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == color]


def geometry(g):
    """从帧上量格子：返回 (cell, row0, col0, nrows, ncols)。量不出（没有球）返回 None。

    尺子是球（色6）：它从不移动、每关都在、是一个正方形的格子。取所有球里最小的那一块的
    包围盒边长当 cell；它的左上角对 cell 取模当相位。第 0~2 关量出 (4, 0, 0, 16, 16)，第 3 关 (3, 2, 2, 20, 20)。
    """
    pts = _cells(g, BALL)
    if not pts:
        return None
    # 按连通块分开：同一个球的像素在行列上都连续；不同球之间至少隔一格
    rows = sorted({r for r, _ in pts})
    cols = sorted({c for _, c in pts})
    # 取第一个球：行上第一段连续、列上第一段连续
    r0 = rows[0]
    r1 = r0
    while r1 + 1 in set(rows):
        r1 += 1
    c0 = min(c for r, c in pts if r == r0)
    c1 = c0
    rowset = {c for r, c in pts if r == r0}
    while c1 + 1 in rowset:
        c1 += 1
    cell = min(r1 - r0 + 1, c1 - c0 + 1)
    if cell <= 0:
        return None
    row0, col0 = r0 % cell, c0 % cell
    n = len(g)
    return (cell, row0, col0, (n - row0) // cell, (len(g[0]) - col0) // cell)


def cell_size(g):
    """这一帧的格子边长（像素）；量不出返回 None。"""
    geo = geometry(g)
    return None if geo is None else geo[0]


def delta(g, action):
    """这一帧上某个动作让色9 移动的像素位移；量不出格子返回 None。"""
    cell = cell_size(g)
    a = action.split(":")[0]
    if cell is None or a not in STEP:
        return None
    dr, dc = STEP[a]
    return (dr * cell, dc * cell)


def _me(g):   # 修复 2026-09-29：退出状态
    """玩家横杆的 (top_row, left_col)；找不到色9 返回 None。"""
    pts = _cells(g, PLAYER)
    if not pts:
        return None
    return (min(p[0] for p in pts), min(p[1] for p in pts))


def _me_box(g):   # 修复 2026-09-29：退出状态
    """玩家横杆的 (r0, r1, c0, c1, 格数)；找不到返回 None。"""
    pts = _cells(g, PLAYER)
    if not pts:
        return None
    return (min(p[0] for p in pts), max(p[0] for p in pts),
            min(p[1] for p in pts), max(p[1] for p in pts), len(pts))


def logical(g, lr, lc):
    """逻辑格 (lr, lc) 的颜色：取它 4x4 像素里的众数。逻辑行 0 被 HUD 压着，读出来无意义。"""
    from collections import Counter
    vals = [g[lr * CELL + dr][lc * CELL + dc] for dr in range(CELL) for dc in range(CELL)]
    return Counter(vals).most_common(1)[0][0]


def walls(g):
    """阻挡格集合。待实测：边界还没和帧上任何颜色对上，不猜着填。"""
    return None


def hud_row(g):
    """HUD 那条像素行（整行只有色14/色0）。第 0 关是 0，第 1 关是 63。找不到返回 None。"""
    for r in (0, len(g) - 1):
        if all(v in (14, 0) for v in g[r]):
            return r
    return None


def board(g):
    """逻辑棋盘：每格取 cell x cell 像素的众数，**跳过 HUD 那条像素行**；格子边长与相位由 geometry(g) 现量。

    第 0~2 关是 16x16，第 3 关是 20x20。量不出格子时退回 CELL=4、相位 (0,0)。
    与 logical() 的差别就在跳过 HUD 那一句：logical() 会把 HUD 的颜色读进逻辑行 0（第 0 关）
    或逻辑行 15（第 1 关），压掉那一行真正的棋盘内容。
    """
    from collections import Counter
    hud = hud_row(g)
    geo = geometry(g)
    if geo is None:
        cell, row0, col0, nr, nc = CELL, 0, 0, len(g) // CELL, len(g[0]) // CELL
    else:
        cell, row0, col0, nr, nc = geo
    out = []
    for lr in range(nr):
        line = []
        for lc in range(nc):
            vals = [g[row0 + lr * cell + dr][col0 + lc * cell + dc]
                    for dr in range(cell) for dc in range(cell)
                    if row0 + lr * cell + dr != hud]
            line.append(Counter(vals).most_common(1)[0][0] if vals else 12)
        out.append(line)
    return out


def _nothing_hidden(g):   # 修复 2026-09-29：退出状态
    """这一帧上有没有块被别的块压住？没有 → True；可能有 → False；判不了 → None。

    由来：块之间会重叠（pieces_overlap_no_blocking），压住的那几格从帧上读不出来。
    夹子的上半条是「可见格数不会多于本关的家当」，下半条是「帧上读到的是下限」；
    两边一夹，**可见恰好等于家当 = 一格没被压住**。

    家当按关卡不同。关卡在 g 上读不到（ctx 才有），所以拿**杯口的列集合**当关卡的指纹：
    每一关的杯口位置各不相同，帧上直接读得出来。这是一张实测表，也是一个假设——
    见 INVENTORY_BY_MOUTHS。指纹不在表里就返回 False（宁可哑，不可乱说）。
    没有色8 的关（只有一块）压不住谁，直接 True。

    谁需要它：凡是要宣告「某一格现在空出来了」的 apply。腾出的格子底下若压着一块色8，
    它露出来的是色8 而不是背景色——这条读法就是那句话敢不敢说的前提。

    v2 的由来（第 1147 步）：v1 里写死 INVENTORY_L1 = 11，进第 2 关后可见 21 格，
    这条一律返回 False，靠它的四条方向 apply 就再也不肯说「我腾出来的格子变背景色」。
    **assert_ 一条没错，S 一格没掉，坏的只有生成器**——而一批动作是按
    「上一步之后世界该长这样」连着算的，于是第 1146 步少擦一格，第 1147 步就把
    色9 当成了 7 格宽，--strict 在那里停批。写死的关卡常量不会让分数难看，只会让册子变哑。

    第 1247 步又补一次同样的教训：那一步起「可见的未选中块」要连色15 一起数（见 UNSEL2）。
    只数色8 的话，拐角块一被放下这条就返回 False，四条方向 apply 当场全哑。

    v3 的由来（第 3031 步，第三次同样的教训）：夹子只清点色 8/15/9，
    而**发射器格（色4）嵌在杆里，也会被压住**——压住一格色4 不改变这三色的计数，
    等式照样成立，这条就说「没人被压住」。那一步 ACTION4 腾出来的 9 格
    露出的是色4 而不是背景色 12，靠它的 apply 押 12 实 4，--strict 停批。
    assert_ 仍判 TRUE，S 一格没掉——**坏的又只有生成器**，和 v2 一模一样的失效面。
    v3 把色4 的家当也夹进来（LAUNCHER_BY_MOUTHS）。
    代价照实说：色4 被压住时这条返回 False，四条方向 apply 对腾出来的格子闭嘴，
    批内预测链在那里就断，要靠缩短批长（每批从真帧重起）穿过去。
    闭嘴是对的——帧上读不出被压住的那一格是什么颜色，敢说就是乱说。
    """
    b = board(g)
    if hud_row(g) is None:
        return None
    fp = tuple(sorted(cup_mouths(b)))
    want4 = LAUNCHER_BY_MOUTHS.get(fp)
    if want4 is None:
        return False
    if sum(v == LAUNCHER for row in b for v in row) != want4:
        return False
    vis8 = sum(v in (UNSEL, UNSEL2) for row in b for v in row)
    vis9 = sum(v == PLAYER for row in b for v in row)
    if vis8 == 0:
        return True
    want = INVENTORY_BY_MOUTHS.get(fp)
    if want is None:
        return False
    return vis8 + vis9 == want


def _piece_spans(b):   # 修复 2026-09-29：退出状态
    """棋盘 b 上所有块的横段 [(行, 左列, 右列, 颜色), ...]，同色相邻才并成一段。

    假设：每一块都是一条横杆，所以「一段」就是「一块」。这条假设在有遮挡时不成立
    （两块重叠会少格、同行相接会并段），所以用它的概念要自己核可见格数。
    """
    out = []
    for r, row in enumerate(b):
        c = 0
        while c < len(row):
            if row[c] in (PLAYER, UNSEL):
                v, l = row[c], c
                while c + 1 < len(row) and row[c + 1] == v:
                    c += 1
                out.append((r, l, c, v))
            c += 1
    return out


def _sel_piece_pixels(g):   # 修复 2026-09-29：退出状态
    """选中那一块在**像素**上占的格子：(色9 的像素集合, 杆里嵌着的色4 像素集合)。

    由来（第 3 关，第 1181~1183 步）：有一根杆中间嵌着一格色4，它跟着整根一起走。
    只按色9 算，这一格会被当成「腾出来的空格」而宣告成背景色——生成器就错一格。
    读法：取色9 的包围盒，盒子里的色4 像素算这根杆自己的。第 0~2 关色9 是实心的一条，盒子里没有色4，
    所以这个读法在那三关上退化成「就是色9 那些格」，一格不差。
    没有色9 返回 (None, None)。
    """
    a = _cells(g, PLAYER)
    if not a:
        return (None, None)
    pts = set(a)
    r0, r1 = min(r for r, _ in a), max(r for r, _ in a)
    c0, c1 = min(c for _, c in a), max(c for _, c in a)
    lau = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
           if g[r][c] == LAUNCHER}
    return (pts, lau)


def piece_run(b, r, c):
    """棋盘 b 上含 (r, c) 的**块格连续段** (左列, 右列)；(r, c) 不是块格返回 None。

    和 piece_spans 的差别：这里色8/色9/色4 一视同仁（PIECE），因为一根杆里可能嵌着一格色4，
    按同色分段会把它切成两截（第 3 关那根宽7 的杆就是 999·4·999）。
    一条段不一定是一块——两块并排时在帧上并成一条，见 solo_widths。
    """
    if not (0 <= r < len(b) and 0 <= c < len(b[0])) or b[r][c] not in PIECE:
        return None
    l = c
    while l - 1 >= 0 and b[r][l - 1] in PIECE:
        l -= 1
    rr = c
    while rr + 1 < len(b[r]) and b[r][rr + 1] in PIECE:
        rr += 1
    return (l, rr)


def click_cell(g, action):
    """ACTION6:x,y 点中的逻辑格 (行, 列)；解析不出、量不出格子、或落在棋盘外返回 None。

    坐标是像素 (x=列, y=行)；逻辑格由 geometry(g) 现量的格子边长与相位换算，**不写死 //4**。
    """
    if ":" not in action:
        return None
    try:
        x, y = [int(v) for v in action.split(":", 1)[1].split(",")]
    except ValueError:
        return None
    geo = geometry(g)
    if geo is None:
        return None
    cell, row0, col0, nr, nc = geo
    if y < row0 or x < col0:
        return None
    r, c = (y - row0) // cell, (x - col0) // cell
    if not (0 <= r < nr and 0 <= c < nc):
        return None
    return (r, c)


def _sel_span(b):   # 修复 2026-09-29：退出状态
    """选中块（色9）的 (行, 左列, 右列)；没有色9 返回 None。"""
    pts = [(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == PLAYER]
    if not pts:
        return None
    return (min(p[0] for p in pts), min(p[1] for p in pts), max(p[1] for p in pts))


def ball_col(b):
    """球（色6）所在的逻辑列；没有球返回 None。"""
    for r, row in enumerate(b):
        for c, v in enumerate(row):
            if v == BALL:
                return c
    return None


def ball_cell(b):
    """球的 (行, 列)；没有球返回 None。"""
    for r, row in enumerate(b):
        for c, v in enumerate(row):
            if v == BALL:
                return (r, c)
    return None


def launcher_cell(b):
    """发射器（色4）的 (行, 列)；没有返回 None。"""
    for r, row in enumerate(b):
        for c, v in enumerate(row):
            if v == LAUNCHER:
                return (r, c)
    return None


def travel_dir(b):
    """球前进的行方向：+1 往行号大的方向，-1 往行号小的方向。

    假设：球从发射器里射出，所以前进方向是「背离发射器」。
    两关实测都符合（第 0 关发射器在球上方、球向下；第 1 关发射器在球下方、球向上）。
    读不出球或发射器返回 None。

    v2：符号反了一版。第一版写成 `1 if bc[0] < lc[0] else -1`，把「球在发射器上方」
    算成了向下，两关同时读反；后果是 blocking_bar 每一次都往空的那一侧扫，
    对全部 120 次 ACTION5 返回 None，靠它的概念全判 NA——**分数不会变难看，只会变哑**。
    """
    bc, lc = ball_cell(b), launcher_cell(b)
    if bc is None or lc is None:
        return None
    if bc[0] == lc[0]:
        return None
    return -1 if bc[0] < lc[0] else 1


def _runs(cols):
    """把列号集合压成连续区间列表。"""
    cs = sorted(cols)
    out, s = [], None
    for i, c in enumerate(cs):
        if s is None:
            s = c
        if i + 1 == len(cs) or cs[i + 1] != c + 1:
            out.append((s, c))
            s = None
    return out


def _cup_blobs(b):
    """色11 的四连通块，每块是一个格子集合。"""
    cells = {(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == CUP}
    out = []
    while cells:
        seed = cells.pop()
        comp, stack = {seed}, [seed]
        while stack:
            r, c = stack.pop()
            for nb in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if nb in cells:
                    cells.discard(nb)
                    comp.add(nb)
                    stack.append(nb)
        out.append(comp)
    return out


def cup_mouth_cells(b):
    """杯口的**格**集合：每个杯是 5 格、包围盒 2x3 或 3x2，盒子里缺的那一格就是口。

    由来（2026-09-18，第 4 关）：旧读法假设「杯占两行、杯身那行有色11 而獠牙那行没有的列就是口」，
    这在第 0~3 关成立，因为那四关的杯全是横着排的。第 4 关多出一个**竖着、口朝右**的杯
    （3 行 2 列），旧读法把它和另外三个杯混在一起挑「杯身行/獠牙行」，读出来的是列 {1, 2}，全错。
    新读法不问方向：口就是包围盒里缺的那一格。
    验过（runs/.../probe32）：第 0~3 关共 2583 帧，新读法给出的列集合和旧读法**逐帧相同**，
    一帧不差；第 4 关给出 (2,6) (2,12) (2,16) (12,2)，和帧上看到的四个缺口一致。
    任何一个杯不是「5 格 + 2x3/3x2 包围盒 + 正好缺一格」就整个返回空集合（变哑，不乱说）。
    """
    out = set()
    blobs = _cup_blobs(b)
    if not blobs:
        return set()
    for comp in blobs:
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        h, w = max(rs) - min(rs) + 1, max(cs) - min(cs) + 1
        if len(comp) != 5 or (h, w) not in ((2, 3), (3, 2)):
            return set()
        box = {(r, c) for r in range(min(rs), max(rs) + 1)
               for c in range(min(cs), max(cs) + 1)}
        miss = box - comp
        if len(miss) != 1:
            return set()
        out |= miss
    return out


def cup_mouths(b):
    """杯口的**列**集合。

    只在所有杯都横着排（口朝上或朝下）时才是个有意义的量——竖着开口的杯的「列」说明不了它在哪一行。
    要口在哪一格用 cup_mouth_cells。读不出返回空集合。
    """
    return {c for _, c in cup_mouth_cells(b)}


def move_limit(b, side):
    """**已被推翻**（第 1556 步 949cf952b7b9b9af）：这条把界读成全局的，而杯其实只挡自己那一圈。
    留档不再引用，改用 shift_blocked。

    块往 side（'1'上 '2'下 '3'左 '4'右）能走到的**逻辑格**极限：近缘落在这个值上就动不了。

    读法：从这一侧最外面数起，第一条含球色6/杯色11 的连续带（按行或按列）；
    带最外那一条线上的每一个球/杯格，再往外一格必须是地板色1 或发射器色4——**背后有墙**才算界，
    否则这一侧没有界，只剩棋盘边缘。界 = 带的内缘 ± 2 格。

    由来（2026-09-18，第 1272 步反例 82511392b258b0b0）：拐角块左缘停在逻辑列4 上按 ACTION3 不动，
    而当时四条移动概念的左右界写的都是「棋盘最左/最右那一格」。第 4 关多出一个横躺在左侧、
    口朝右的杯（行11-13、列1-2），它背后是一整列地板（列0）——这是贴着左边、背后有墙的一条带。
    「贴着边」不够：第 2 关的杯也占着列1-3，可它们背后（列0）什么都没有，块照样走到列0。
    runs/.../probe42 在全部 966 条 ACTION1-4 转移上逐条对过：四个方向 0 错，
    并且在第 0~3 关给出的界与旧的三条像素公式逐关相同（第 0 关上界行3 / 下界行11 / 左0 / 右15 …）。

    副产品：旧册子记着一笔「上留一格（+1+cell）、下留两格（-2*cell）」的不对称，说是解释不了。
    那是像素公式写出来的假象——换成逻辑格，两侧都是 2 格，块的近缘总是停在带的内缘外**隔一格**处。
    """
    n, m = len(b), len(b[0])
    if side in "12":
        lines = [r for r in range(n) if any(v in (BALL, CUP) for v in b[r])]
        span = n
    else:
        lines = [c for c in range(m) if any(b[r][c] in (BALL, CUP) for r in range(n))]
        span = m
    if not lines:
        return None
    if side in "13":
        s, end = lines[0], lines[0]
        for i in lines[1:]:
            if i != end + 1:
                break
            end = i
        outer = s - 1
    else:
        s, end = lines[-1], lines[-1]
        for i in reversed(lines[:-1]):
            if i != end - 1:
                break
            end = i
        outer = s + 1
    if not 0 <= outer < span:
        return None
    if side in "12":
        nb = [(outer, c) for c in range(m) if b[s][c] in (BALL, CUP)]
    else:
        nb = [(r, outer) for r in range(n) if b[r][s] in (BALL, CUP)]
    if not all(b[r][c] in (FLOOR, LAUNCHER) for r, c in nb):
        return None
    return end + 2 if side in "13" else end - 2


def _forbidden_cells(b):   # 修复 2026-09-29：退出状态
    """件的格子不许落进来的那一批逻辑格。三样东西造出来（2026-09-18 改写，见 shift_blocked）：

    甲、墙（色1）本身。
    乙、每个杯格的八邻光环：切比雪夫距离不大于 1 的九格。**这条是局部的**。
    丙、球所在那一行的上下各一行，**整行不分列**。球只挡横带不挡竖带。
    """
    n, m = len(b), len(b[0])
    bad = set()
    for r in range(n):
        for c in range(m):
            v = b[r][c]
            if v == FLOOR:
                bad.add((r, c))
            elif v == CUP:
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        bad.add((r + dr, c + dc))
            elif v == BALL:
                for dr in (-1, 0, 1):
                    for cc in range(m):
                        bad.add((r + dr, cc))
    return bad


def shift_blocked(g, side):
    """选中的块往 side（'1'上 '2'下 '3'左 '4'右）挪一格，会不会被挡住。读不出返回 None。

    挡住 = 挪过去之后，块的任何一格落在界外、落在墙上、落进杯格的八邻光环、
    或落进球那一行的上下一行里。只要有一格犯规，整块就不动。

    由来（2026-09-18，第 1556 步反例 949cf952b7b9b9af）：原先的 move_limit 把界读成
    「从这一侧最外面数起第一条背靠墙的球/杯带，界＝带的内缘 ± 2」，那是一条**全局**的读法。
    第 6 关右侧的杯在行9-11、列17-18，背后就是墙，它给出的右界是列15；
    可竖4杆停在行3-6 上，从列4 一连右移 12 格走到了列16——它根本够不着那口杯。
    换成「杯是局部光环、球是全局横带」之后，probe83 在全部 991 条去重方向键转移上逐条对过：
    该动的动了、该挡的挡住了，0 错 0 弃权（旧读法在同一批里错 1 条）。
    两条读法在第 0~4 关给出的结果处处相同，差别只在「件够不着那口杯」的那些位置上，
    而这种位置只有第 6 关才有——所以旧读法不是被新证据修正的，是一直错、直到第 6 关才撞上。

    这条改动的份量不在动作概念上，在**摆法空间**上：probe65/probe73 那两次两亿多摆法的穷举
    都是在旧读法那个长方形（行3..15、列4..15）里跑的，四个口凑不齐这个结论随之作废。
    """
    geo = geometry(g)
    if geo is None:
        return None
    b = board(g)
    cells = [(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == PLAYER]
    if not cells:
        return None
    d = {"1": (-1, 0), "2": (1, 0), "3": (0, -1), "4": (0, 1)}.get(side)
    if d is None:
        return None
    bad = _forbidden_cells(b)
    n, m = len(b), len(b[0])
    for r, c in cells:
        rr, cc = r + d[0], c + d[1]
        if not (0 <= rr < n and 0 <= cc < m):
            return True
        if (rr, cc) in bad:
            return True
    return False


def limit_cell(g, side):
    """**已被推翻**（第 1556 步 949cf952b7b9b9af），留档不再引用，改用 shift_blocked。

    把 move_limit 的界和棋盘边缘并起来：帧 g 上块往 side 能走到的逻辑格极限。
    没有背靠墙的带时界就是棋盘边缘那一格；量不出格子返回 None。
    上/左取两者中更靠里的（max），下/右取更靠里的（min）。
    """
    geo = geometry(g)
    if geo is None:
        return None
    _cell, _r0, _c0, nr, nc = geo
    lim = move_limit(board(g), side)
    edge = 0 if side in "13" else (nr - 1 if side == "2" else nc - 1)
    if lim is None:
        return edge
    return max(edge, lim) if side in "13" else min(edge, lim)


def _piece_cell_box(g):   # 修复 2026-09-29：退出状态
    """色9 块占的**逻辑格**包围盒 (顶, 底, 左, 右)；读不出返回 None。"""
    geo = geometry(g)
    if geo is None:
        return None
    cell, r0, c0, _nr, _nc = geo
    pts = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER]
    if not pts:
        return None
    return ((min(p[0] for p in pts) - r0) // cell, (max(p[0] for p in pts) - r0) // cell,
            (min(p[1] for p in pts) - c0) // cell, (max(p[1] for p in pts) - c0) // cell)


def _blocking_bar(b):   # 修复 2026-09-29：退出状态
    """球沿前进方向撞上的第一根「杆」：(行, 左列, 右列)。

    杆 = 那一行里**连续的一段块格**，色8 和色9 一视同仁（相邻两块拼成一根）。
    只取盖住球列的那一段；路上没有块返回 None。
    """
    d = travel_dir(b)
    bc = ball_cell(b)
    if d is None or bc is None:
        return None
    r = bc[0] + d
    while 0 <= r < len(b):
        row = b[r]
        if row[bc[1]] in (PLAYER, UNSEL):
            l = bc[1]
            while l - 1 >= 0 and row[l - 1] in (PLAYER, UNSEL):
                l -= 1
            rr = bc[1]
            while rr + 1 < len(row) and row[rr + 1] in (PLAYER, UNSEL):
                rr += 1
            return (r, l, rr)
        r += d
    return None


# ---- 并步检测（HUD 阶梯通道）------------------------------------------------
# 由来（2026-09-22，第 227 步）：上游超时重试把两次应用并成一条转移（66b96f1e8e6d195f：
# 一次 ACTION2 的标签下色9 挪了两格、HUD 掉了 4 格，而阶梯单步最多掉 3 格；
# 前后步 226、228 都是正常 1 格）。世界事实「一次按键走一档」没有被推翻——是动作标签撒了谎。
# 「一次按键最多走一档」是 hud_budget_per_level_ladder 的主张（全语料 0 反例），
# 所以「next 落在两步可达、一步不可达处，或预算不降反升」就证得这条记录**不是单步记录**：
# 对一切「单步效果」类主张不可判，该判 NA 而不是 FALSE（判 FALSE 冤枉世界，判 TRUE 说谎）。

BUDGET_BY_LEVEL = {0: 30, 1: 45, 2: 100, 3: 120, 4: 100, 5: 120}   # 每关步数预算（hud_budget_per_level_ladder 量出）
HUD_COLOR = 14
HUD_FULL = 64

_TICK_CACHE = {}


def tick_jump(prev, nxt, level):
    """这条记录的 HUD 是否证得「跳了不止一档」——即它不是单步记录。

    返回 True = 证得并步或坏记录（预算回升也算）；False = 单步或零步；
    None = HUD 读不出（prev 的读数不在这关的阶梯上、level 不在表里）——调用方按自己的规则走。

    只在「同关、非 RESET」的记录上调用；RESET 与换关各概念自己在前面就判了 NA。
    """
    if level not in BUDGET_BY_LEVEL:
        return None
    if level not in _TICK_CACHE:
        B = BUDGET_BY_LEVEL[level]
        lad = [HUD_FULL - round(HUD_FULL * k / B) for k in range(B + 1)]
        succ = {}
        for k in range(B):
            succ.setdefault(lad[k], set()).add(lad[k + 1])
        two = {}
        for h, ss in succ.items():
            t = set()
            for x in ss:
                t |= succ.get(x, set())
            two[h] = t
        _TICK_CACHE[level] = (succ, two)
    succ, two = _TICK_CACHE[level]
    h1 = sum(row.count(HUD_COLOR) for row in prev)
    h2 = sum(row.count(HUD_COLOR) for row in nxt)
    if h1 not in succ:
        return None
    if h2 in succ[h1]:
        return False
    if h2 in two[h1]:
        return True
    if h2 in succ:          # 在阶梯上、但一步两步都到不了：更大的跳档
        return True
    if h2 > h1:             # 不在阶梯上、预算还回升：坏记录
        return True
    return None


# ---- 块的包围盒 -------------------------------------------------------------
# 由来（2026-09-22，第 351 步）：点在逻辑格 (14,9) 这个**空格**上，
# 占 (14,10)(15,9)(15,10) 的那块色15 拐角块被选中了——(14,9) 正是它包围盒缺的那个角。
# 所以「点哪格选哪块」的正确读法是「点进哪块的包围盒就选哪块」；
# 前四关全是横杆，包围盒等于块本身，两种读法给的答案一样，所以一直看不出差别。

def _color_blobs(b, colors=PIECE):   # 修复 2026-09-29：退出状态
    """棋盘 b 上的同色 4-连通块：[(颜色, frozenset((行,列))), ...]。只认 colors 里的颜色。

    同色才连通：并排的两根色8 杆仍会被并成一块（帧上本来就分不开，见 piece_spans 的注）；
    杆里嵌的那格色4 会自成一块，它的包围盒只有一格，不会把整根杆罩进去。
    """
    seen = set()
    out = []
    for r in range(len(b)):
        for c in range(len(b[0])):
            v = b[r][c]
            if v not in colors or (r, c) in seen:
                continue
            comp, stack = set(), [(r, c)]
            while stack:
                rr, cc = stack.pop()
                if (rr, cc) in comp:
                    continue
                if not (0 <= rr < len(b) and 0 <= cc < len(b[0])):
                    continue
                if b[rr][cc] != v:
                    continue
                comp.add((rr, cc))
                stack += [(rr + 1, cc), (rr - 1, cc), (rr, cc + 1), (rr, cc - 1)]
            seen |= comp
            out.append((v, frozenset(comp)))
    return out


def blobs_covering(b, cell, colors=PIECE):
    """包围盒罩住 cell 的那些块 [(颜色, 格集合), ...]；cell 自己是不是块格都算。"""
    r, c = cell
    hits = []
    for v, comp in _color_blobs(b, colors):
        rs = [p[0] for p in comp]
        cs = [p[1] for p in comp]
        if min(rs) <= r <= max(rs) and min(cs) <= c <= max(cs):
            hits.append((v, comp))
    return hits


# =============================================================================================
# 修复（meta/repair-20260928，2026-09-29）补的读数与隐藏状态。以上部分除「退出状态」的改名外逐字未动。
#
# 一、新读数 color_masks(g)：逻辑棋盘（board(g)，格子边长与相位由 geometry(g) 从球身上量、跳过 HUD 像素行）
#     上每种颜色占的格集合，编成整数位掩码：格 (行 r, 列 c) 占第 r*32+c 位（棋盘最大 20x20，32 够用）。
#     顺序固定为 COLOR_MASK_COLORS = (1, 4, 6, 8, 9, 11, 13, 15)；色12 是背景，不编。
#     全语料 11k 帧实测：逻辑格内像素全同色（0 次不纯），棋盘上只出现过这 8 色加背景 12（13 只在 WIN 帧）。
#     所以这 8 个掩码 + geometry 就是整张逻辑棋盘，一格不丢。它只报「这一帧每格什么颜色」，是纯感知原语。
#
# 二、隐藏状态（修订 R1 + 「潜在状态例外」）：件的完整布局。
#     件会互相重叠，被选中件（色9，画在最上）压住的那几格帧上看不见；未选中件从不自己动，
#     所以「被压住的格原来是什么」只能靠历史记住。h 里存：
#       h_sel            选中件的下标（-1 = 本关还没切过件）
#       h_p0..h_p4       各件锚点（件的包围盒左上角）编成 行*32+列；空槽 -1
#       h_s0..h_s4       各件形状：相对锚点的格掩码（同样 行*32+列 编码）；空槽 -1
#       h_f0..h_f4       各件里嵌着的色4 格（相对锚点）；空槽 -1
#     hidden_step 只做两件事：
#       ① 本关第一次（h_sel < 0）从 prev 帧切件：色8/9/15 与「四邻挨着这三色的色4」的四连通块，
#          按块里最小位（行优先的第一格）排序。关首帧各件互不相接（6 关实测块数 1/3/4/5/4/4 与家当表一致）。
#       ② 用 nxt 帧里看得见的色9 更新：ACTION1-4 之后，选中件的新锚点 = 让「形状去掉色4 格」恰好等于 nxt 的色9 格集合的那个位置
#          （找不到就不动）；其余动作之后，谁的「形状去掉色4 格」在当前锚点上恰好等于 nxt 的色9 格集合，谁就是选中件。
#       未选中件的锚点原样保留——这就是被检验的模型（「未选中件不动」），Lean 的 stepRules 里独立写了同一条。
#     它不读动作的后果：不算落点、不判挡不挡、不判点中谁，只从 nxt 帧读「色9 现在在哪、是哪一块」。
#     nxt 里没有色9（第 0 关预算耗尽那一帧杆变色8）时 h 原样不动。
#
# 三、退出状态的原读数（改成下划线开头的私有名，函数体逐字未动，生成器不再把它们当读数）：
#     solo_widths、me、me_box、nothing_hidden、piece_spans、sel_piece_pixels、sel_span、
#     forbidden_cells、piece_cell_box、blocking_bar、color_blobs —— 共 11 个。
#     证明它们是新状态的函数：_scratch/sp80-20260923/proof_dropped.py 逐帧（全语料 2611 张不同帧）按
#     (color_masks, geometry, hud_row) 分组（比新状态全体更粗的键，不含 level 与 h），11 个原读数组内全部唯一
#     （1892 组，组内不唯一 0）。结果在 proof_dropped.txt。
#     其余原读数（ball_cell、ball_col、board、cell_size、cup_mouth_cells、cup_mouths、geometry、hud_row、
#     launcher_cell、travel_dir）原样保留在状态里，它们在关内不变，Lean 原样保留。
#     没有 LEVEL_CONST。
# =============================================================================================

STRIDE = 32
COLOR_MASK_COLORS = (1, 4, 6, 8, 9, 11, 13, 15)
_ROW = (1 << STRIDE) - 1


def color_masks(g):
    """逻辑棋盘上 8 种颜色各自的格掩码（位 = 行*32+列），顺序见 COLOR_MASK_COLORS。量不出格子返回 None。"""
    if geometry(g) is None:
        return None
    b = board(g)
    ms = {c: 0 for c in COLOR_MASK_COLORS}
    for r, row in enumerate(b):
        for c, v in enumerate(row):
            if v in ms:
                ms[v] |= 1 << (r * STRIDE + c)
    return tuple(ms[c] for c in COLOR_MASK_COLORS)


def _dil4(m):
    return m | (m << 1) | (m >> 1) | (m << STRIDE) | (m >> STRIDE)


def _low_index(m):
    return (m & -m).bit_length() - 1


def _anchor(comp):
    """格掩码的包围盒左上角（编成 行*32+列）。"""
    r = _low_index(comp) // STRIDE
    cols, x = 0, comp
    while x:
        cols |= x & _ROW
        x >>= STRIDE
    return r * STRIDE + _low_index(cols)


def _segment(cm):
    """关首帧切件（与 Lean 的 segment 同一算法）：返回 h 字典；超过 5 块或读不出返回 None。"""
    m1, m4, m6, m8, m9, m11, m13, m15 = cm
    body = m8 | m9 | m15
    pm = body | (m4 & _dil4(body))
    h = {"sel": -1}
    for i in range(5):
        h[f"p{i}"] = h[f"s{i}"] = h[f"f{i}"] = -1
    i = 0
    while pm:
        if i >= 5:
            return None
        comp = pm & -pm
        while True:
            nx = _dil4(comp) & pm
            if nx == comp:
                break
            comp = nx
        pm ^= comp
        p = _anchor(comp)
        h[f"p{i}"], h[f"s{i}"], h[f"f{i}"] = p, comp >> p, (comp & m4) >> p
        if h["sel"] < 0 and comp & m9:
            h["sel"] = i
        i += 1
    return h


HIDDEN_INIT = {"sel": -1, **{f"{k}{i}": -1 for k in "psf" for i in range(5)}}


def hidden_step(h, prev, action, nxt):
    h = dict(h)
    if h["sel"] < 0:
        cm0 = color_masks(prev)
        seg = _segment(cm0) if cm0 is not None else None
        if seg is None:
            return h
        h = seg
    cm = color_masks(nxt)
    if cm is None or cm[4] == 0 or h["sel"] < 0:
        return h
    nine = cm[4]
    a = action.split("|")[0].split(":")[0]
    if a in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        i = h["sel"]
        body = h[f"s{i}"] & ~h[f"f{i}"]
        p = _low_index(nine) - _low_index(body)
        if p >= 0 and (body << p) == nine:
            h[f"p{i}"] = p
        return h
    for i in [h["sel"]] + list(range(5)):
        if h[f"p{i}"] >= 0 and ((h[f"s{i}"] & ~h[f"f{i}"]) << h[f"p{i}"]) == nine:
            h["sel"] = i
            break
    return h
