"""ACTION5 若这一按换了选中的块（交棒），接手的是「沿球的行进方向离发射器最近」的那一块。

只断言**交给谁**，不断言**什么时候**交棒——触发条件至今没找出来
（action5_handoff_swaps_width 的 NOTE 里记着 28 个特征的机械分离器搜索全军覆没）。

来由：第 6 关（level 5）第 1543 步买来的。当时选中肘A（(10,6)(11,6)(11,7)，全盘最靠下、
离盘顶的发射器最远），按下 ACTION5 帧差 64 格：肘A 三格由色9 退回色15、
竖杆四格由色8 变色9、掉一格预算。竖杆当时行 3-6，是离盘顶发射器最近的那一块。
交棒的目标是最近那块，不是最靠下那一块——第 6 关球朝下走、发射器在盘顶，
两个读法在这里第一次分得开。老概念 action5_handoff_goes_to_lowest_other 只在第 1 关开口
（那一关发射器在盘底、球朝上，最靠下就是最近），在这条转移上返回 NA，没挨打。

v1 挨了 11 条反例，全是「选中的块盖住球所在的列、这一按实为发射（帧差只有预算那一两格）」
被我当成交棒判了错：v1 在选中的块不是最近那块时就开口断言必定交棒，而世界照样发射。
v2 改成事后口径——**只在选中的块前后真的换了时才开口**，谁触发交棒不再由这条管。

弯件（纯色15 的块）是这条读法的真实边界，不是我省事。三种花样互相矛盾：
  第 1282 步 弯件在行 12-13（全盘最靠下）却被跳过，接手的是行 10 的直杆；
  第 1305 步 弯件在行 13-14（同样最靠下）却接了棒；
  第 2794 步 弯件**根本不是最近的那块**（它在行 5-6，最近的直杆在行 4），却接了棒。
所以**候选里只要有一块弯件，本条就不表态**（v5；v4 只豁免「最近的是弯件」，被第三种花样打死）。
语料里这样的转移上它 21 条全中（同关、可读、选中真的换了、候选里没有弯件的共 21 条）。

「块」按四邻连通块切，不按行切：第 4 关以后有竖杆和弯件这种跨行的块，按行切会把一块拆成几段。
整块只有色4 的不算块（那是球边上那颗孤零发射器）。
判错的样子：某一发 ACTION5 换了选中的块，最近的候选是直杆，而接手的不是它。
"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION5，且前后同关；前后任一侧 state 是 GAME_OVER 返回 NA。"
    "第 2 关返回 NA（handoff 规则不同：优先覆盖球列的杆，不是最近的杆）。"
    "只在「前后两帧各能读出恰好一个含色9 的块，且这两个块的占格集合不同」时开口"
    "（没换＝发射或空按，本条不表态）。"
    "「块」＝色8/色9/色15/色4 的四邻连通块，且块里至少有一格色8/色9/色15。"
    "候选＝除交出的那一块以外的所有块；「最近」按 _lib.travel_dir 读出的球行进方向算："
    "球朝下取块的最小行最小者、球朝上取块的最大行最大者。"
    "**候选里只要有一块是弯件（整块颜色只有色15）就返回 NA**——有弯件在场时交棒去哪读不出来。"
    "最近的候选并列多块时取列号最大的那一块。"
    "帧上读不出球、读不出方向、读不出恰好一个含色9 的块，一律返回 NA。"
)
NOTE = (
    "v5（2026-09-20）。v4 被第 5 关第 2794 步打死（31b060c2f13d859c）："
    "候选三块——行4-7列14 的直杆（最小行 4，最近）、行5-6列9-10 的弯件、行10列9-13 的直杆，"
    "世界把棒交给了**弯件**，而弯件既不是最近的、也不是最靠下的。"
    "v4 的弯件豁免只管「最近的候选是弯件」，这一条从旁边绕了过去。"
    "试过三条别的路，全部留档为负结果："
    "(一)「盖球列优先」（交棒给盖住球所在列的块，有多块时取最近）——它能解释第 2794 步和"
    "第 2 关的步2033，却被步963（第1关，盖球列的更近却没接棒）、步1305、步2482 打死，TRUE 29/FALSE 3；"
    "(二)「盖球列优先且弯件不豁免」TRUE 32/FALSE 5；"
    "(三)「交棒在固定清单上轮转」——按 (行,列) 极值的 7 种排法 × 正反两向共 14 种全部有反例，"
    "最好的一种 22 对 11 错，轮转假设排除。"
    "所以「最近」仍是唯一零反例的读法，v5 只把弯件豁免放宽到「在场即闭口」："
    "全语料 TRUE 21 / FALSE 0，闭口 11 条是「候选里有弯件」。"
    "代价说清楚：**第 5 关从此整关闭口**（那一关盘上始终有弯件），第 5 关的交棒进了残差。\n"
    "v3（2026-09-19）。v2 被第 2 关的 handoff 打死：4d1792b244118398（步2033），"
    "球朝上、候选3个块、按最大行规则应交给行12列2-5，实际交给了行10列9-14（覆盖球列9和14）。"
    "第 2 关的 handoff 机制与其他关不同，v3 把第 2 关排除出 scope。"
    "v2（2026-09-18）。v1 口径是事前的（选中的不是最近那块 ⟹ 必交棒），"
    "被 11 条「其实是发射」的转移打死：078a611d329c2c4c、8e72f52ea28f3490、"
    "b55259fc1235d996、10ad74e259e9dece、0fa06678c0654f0c、916cc9774011fa32、"
    "103bcb704db8a689、689d0e111856dfcc、a12292aaaa8b2dfc、de8b753b5b65bd23、"
    "ffd4449adb5892bc。v2 退到事后口径，并把弯件最近的局面划出 scope。"
)
EVIDENCE = [
    "228e5b1efecdb3ad",   # 步1543 第6关：选中肘A，接手竖杆（行3-6，离盘顶发射器最近）
    "8946dde2e977987d",   # 步348 第1关：行4 c5-9 交给行6 c7-9（球朝上，行6 更靠下＝更近）
    "46365f248f0716e9",   # 步932 第1关：行9 c8-10 交给行12 c5-9
    # 以下 11 条是打死 v1 的反例：选中的块不是最近那块，世界却照样发射（帧差只剩预算格）。
    # v2 退到事后口径后它们全部返回 NA —— 本条不再对「什么时候交棒」表态。
    "078a611d329c2c4c", "8e72f52ea28f3490", "b55259fc1235d996", "10ad74e259e9dece",
    "0fa06678c0654f0c", "916cc9774011fa32", "103bcb704db8a689", "689d0e111856dfcc",
    "a12292aaaa8b2dfc", "de8b753b5b65bd23", "ffd4449adb5892bc",
    # v3 的反例：第 2 关 handoff 不遵循「最近」规则，优先选覆盖球列的杆
    "4d1792b244118398",   # 步2033 第2关：行8→行10（行10覆盖球列9和14，行12虽更近但不覆盖）
    # v4 的反例：第 5 关弯件不是最近的那块却接了棒。v5 在它上面判 NA（候选里有弯件）。
    "31b060c2f13d859c",   # 步2794 第5关：交出行14-15列7-8，接手行5-6列9-10（弯件），最近的是行4-7列14
]

from _lib import PIECE, PLAYER, UNSEL, UNSEL2, board, travel_dir
from geo import components

REAL = (UNSEL, PLAYER, UNSEL2)


def _pieces(b):
    """色8/9/15/4 的四邻连通块，去掉只有色4 的那种（孤零发射器）。"""
    cells = [(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v in PIECE]
    out = []
    for comp in components(cells):
        if any(b[r][c] in REAL for r, c in comp):
            out.append(frozenset(comp))
    return out


def _sel(b, ps):
    s = [k for k in ps if any(b[r][c] == PLAYER for r, c in k)]
    return s[0] if len(s) == 1 else None


def _bent(b, k):
    """整块只有色15（弯件没被选中时的颜色）。"""
    return all(b[r][c] == UNSEL2 for r, c in k)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx is not None:
        if ctx.get("level_prev") != ctx.get("level_next"):
            return "NA"
        if ctx.get("level_prev") == 2:
            return "NA"
        if "GAME_OVER" in (ctx.get("state_prev"), ctx.get("state_next")):
            return "NA"
    bp, bn = board(prev), board(nxt)
    if bp is None or bn is None:
        return "NA"
    pp, pn = _pieces(bp), _pieces(bn)
    cur, got = _sel(bp, pp), _sel(bn, pn)
    if cur is None or got is None or cur == got:
        return "NA"
    d = travel_dir(bp)
    if d is None:
        return "NA"
    cand = [k for k in pp if k != cur]
    if not cand:
        return "NA"
    if any(_bent(bp, k) for k in cand):
        return "NA"
    if d == 1:
        key = [min(r for r, _ in k) for k in cand]
        best = min(key)
    else:
        key = [max(r for r, _ in k) for k in cand]
        best = max(key)
    near = [k for k, v in zip(cand, key) if v == best]
    if 1 < len(near):
        m = max(max(c for _, c in k) for k in near)
        near = [k for k in near if max(c for _, c in k) == m]
        if 1 < len(near):
            return "NA"
    return "TRUE" if got == near[0] else "FALSE"
