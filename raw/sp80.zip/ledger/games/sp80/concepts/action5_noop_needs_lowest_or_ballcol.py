"""第 1 关的 ACTION5 若没换选中，那色9 要么是帧上最靠下的块，要么盖住球所在的列。

这是单向的必要条件，不是「什么时候交棒」的充要规则：只断言空按那一侧。
交棒那一侧（接手的是谁）还没找到零反例的读法，留在残差里，这条概念对它返回 NA。

来由：把 ACTION5 当「开枪」找了 41 个几何特征、9 个计数器特征，都切不开交棒与空按。
换个问法——不问「什么时候交棒」，问「按完之后选中的是谁」——「交给最靠下的块」
在干净帧上 43/49 成立。六个反例里五个是空按，其中四个的色9 都盖着球列。
于是把那条双向规则削成这一侧的必要条件：空按 ⟹ 最靠下 或 盖球列。

判错的样子：出现一次空按，色9 既不是最靠下的块、也没盖住球列。
"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION5，且前后都在第 1 关；前后任一侧 state 是 GAME_OVER 返回 NA。"
    "只在**空按**（色9 的段按前按后完全一样）上开口，交棒返回 NA。"
    "块有遮挡时返回 NA：第 1 关存货是 5+3+3=11 格（见 level1_inventory_at_most_11），"
    "可见格数不是 11 或读不出正好 3 段，就说明有块重叠（见 pieces_overlap_no_blocking），"
    "此时「一段=一块」的读法失效，不开口。帧上没有球（色6）也返回 NA。"
)
NOTE = (
    "v1。EVIDENCE 只挑 4 条，两类各两条：步556/步644 是只靠「盖球列」撑住的"
    "（色9 不是最靠下），步385/步964 是只靠「最靠下」撑住的（色9 没盖球列）。"
    "其余 26 条空按全部留作 held-out——全塞进来 N 就是 0，S 会变 UNMEASURABLE，"
    "action5_handoff_swaps_width 的 v1 已经踩过一次。"
    "步964 是活押注当场跑出来的那一发（帧差只有 1 格：一个预算格）。"
)
EVIDENCE = [
    "8e72f52ea28f3490",   # 步556 色9(4,9,11) 最靠下是(5,3,7) —— 靠盖球列
    "10ad74e259e9dece",   # 步644 色9(9,8,10) 最靠下是(10,0,4) —— 靠盖球列
    "4e5dceca706785c4",   # 步385 色9(4,11,13) 是最靠下，没盖球列
    "51c4e5724b864f75",   # 步964 色9(9,5,9) 是最靠下，没盖球列
]

from _lib import board, piece_spans, sel_span, ball_col, PLAYER, UNSEL

INVENTORY = 11   # 第 1 关三块共 11 逻辑格
NPIECES = 3


def _read(g):
    """返回 (三块的段, 色9 的段, 球列)；读不干净返回 None。"""
    b = board(g)
    sp = piece_spans(b)
    if len(sp) != NPIECES:
        return None
    if sum(s[2] - s[1] + 1 for s in sp) != INVENTORY:
        return None
    cur = sel_span(b)
    if cur is None:
        return None
    bc = ball_col(b)
    if bc is None:
        return None
    return ([(r, l, rr) for r, l, rr, _ in sp], cur, bc)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx is not None:
        if ctx.get("level_prev") != 1 or ctx.get("level_next") != 1:
            return "NA"
        if "GAME_OVER" in (ctx.get("state_prev"), ctx.get("state_next")):
            return "NA"
    a = _read(prev)
    if a is None:
        return "NA"
    spans_a, cur, bc = a
    after = sel_span(board(nxt))
    if after is None:
        return "NA"
    if after != cur:
        return "NA"          # 交棒：这条概念不管
    lowest = max(spans_a, key=lambda s: (s[0], s[1]))
    if cur == lowest:
        return "TRUE"
    if cur[1] <= bc <= cur[2]:
        return "TRUE"
    return "FALSE"
