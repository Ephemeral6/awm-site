"""点中一块没选中的块（色8 或色15），它就变成选中的那块，原来选中的退回它自己那种未选中色；点别处整个棋盘不动。

ACTION6 的坐标是像素 (x, y)；换算成逻辑格要用本帧量出来的格子边长与相位（_lib.click_cell），不是写死的 //4。
这条把「选谁」从一件要碰运气的事变成一个可以直接下达的指令：
以前换选中块只能靠 ACTION5 交棒（而交棒给谁由局面决定，见 action5_handoff_goes_to_lowest_other），
现在任何一块都能点名选中，摆法的搜索空间因此完全打开。

v5 为什么改：第 6 关的 a5ddf442802a5b51（步1560）把 v4 打成反例。那一刻选中的是一根**竖**的 4x1 杆，
它跨 4 个逻辑行，v4 押它退回色15，实际整根退回色8。所以「跨几行」不是判据，**直的还是拐的**才是：
一块占一行、或占一列，都是直的，退回色8；既跨行又跨列（拐角块）才退回色15。
v4 之所以一直对，是因为在此之前退选过的直块全是横的，占一行，两种读法给的答案一样。

v4 为什么改：「未选中」不是一种颜色，是每一块自己的属性——横杆放下退回色8，第 4 关那个跨两个逻辑行的
拐角块放下退回色15（步1247）。所以「原来选中的退回色8」这一句要改成「退回它自己那种未选中色」，
哪一种由它的形状定。点中色15 的块（步1240）也是选中：
被选中的是含点中那格的色15 四连通块（它和色8 靠颜色就分得开，不必再问 solo_widths）。

v2 为什么缩口：v1 把「帧上一条同色连续段」当成「一块」，被四条转移打脸——
步484 第 4 带上色8 连着一整条 c3-c10，点 c4 之后变成选中的只有 c3-c5；
步710 同一带连着 c0-c7，点 c0 之后变成选中的是 c0-c4（宽5）。
也就是说**块紧挨着排的时候，在帧上并成一条，块与块的边界看不见**，而且拼接顺序两种都出现过
（c3-c10 是「宽3 在左」，c0-c7 是「宽5 在左」），单看一帧分不出来。
这件事本身是个发现：块没有因为并排而失去身份，点击照样只选中它自己那一块；
但「一段 = 一块」这个读法在并排时失效，所以只在段宽拼不出来的时候才开口。
nothing_hidden 拦不住这件事：三块并排也是 11 格全可见，它照样说「没遮挡」。

来由：clicks.py 把语料里每一次 ACTION6 都译回逻辑格、再看那一格当时是什么。
第 1 关 96 次点击分得干干净净——点中未选中块 76 次，76 次都把那一块变成了选中；
点中杯、球、发射器、地板、空地、以及已经选中的那一块共 20 次，20 次整帧不动。

判错的样子：点中一条宽度拼不出来的未选中段而它没被整段选中（或别的格子跟着变了、或老色9 退回的颜色不对），
或者点在别处而棋盘变了。
"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION6 且坐标解析得出；其它动作返回 NA。"
    "任一侧 state 是 GAME_OVER 或换关返回 NA。"
    "点到棋盘外、或帧上量不出格子（没有球）返回 NA。"
    "有块被遮挡（nothing_hidden 不为 True）时返回 NA。"
    "点中色4（球边上的发射器，或嵌在某根杆里的那一格）返回 NA：没试过，不猜。"
    "点中的是色8 块、而它所在的**块格连续段**（色8/色9/色4/色15 一视同仁）的宽度不在 _lib.solo_widths 里时返回 NA："
    "块并排时在帧上并成一条，边界看不见，说不清该有哪几格变色。"
    "点中的是色15 块时，被选中的是含那一格的色15 四连通块。"
    "点中的那一格**不是块格**时：若它落在恰好一块色15 的包围盒内，被选中的是那一块（第 5 关实测，"
    "拐角块包围盒缺的那个角一样能点中，_lib.blobs_covering）；"
    "若它谁的包围盒都不沾，主张整个棋盘不动；"
    "若罩住它的包围盒不止一个、或罩住它的是色8/色4 的块，返回 NA——没试过，不猜。"
    "老色9 退回的颜色：它只占一行、或只占一列（直块）是色8，既跨行又跨列（拐块）是色15。"
)
NOTE = ("v6（2026-09-22）：第 5 关的 4b5c70487ea5767d（第351 步）把 v5 打成反例。点的是逻辑格 (14,9)，"
        "那一格是**空的**（色12），v5 据此押整个棋盘不动；实际占 (14,10)(15,9)(15,10) 的那块色15 拐角块"
        "变成了色9，老色9（拐块）退回色15，棋盘动了 54 格。(14,9) 正是那块拐角块包围盒缺的那个角——"
        "所以命中判定按**包围盒**算，不按块格算。前四关全是横杆，包围盒等于块本身，两种读法给的答案一样，"
        "这条差别要到有拐角块、而且恰好点在缺角上时才露头。"
        "改法：点在非块格上时先查包围盒（_lib.blobs_covering），恰好罩住一块色15 就选那一块；"
        "谁都不沾才主张棋盘不动。主张因此变强了，不是缩了口。\n"
        "v5（2026-09-18）：第 6 关的 a5ddf442802a5b51（第1560 步）把 v4 打成反例。那一刻选中的是竖着的 4x1 杆，"
        "v4 按「跨 4 个逻辑行」押它退回色15，实际整根退回色8。改法：把「跨几行」换成「直还是拐」——"
        "占一行或占一列都算直块退回色8，既跨行又跨列才退回色15。v4 一直没挨打，是因为此前退选过的直块全是横的。\n"
        "v4（2026-09-18）：第 4 关的 e30d71d08571e535（第1247 步）把 v3 打成反例。那一刻拐角块是色9、"
        "点中宽5 杆，v3 押拐角块退回色8，实际退回色15。改法：老色9 退回的颜色按它的形状定（一个逻辑行→8，否则→15）；"
        "点中色15 也算选中（bc8b1fee828db588，第1240 步：点拐角块，三格一起变色9）。"
        "主张的骨架（点中未选中块→它变选中、老的退回、别处不动）一字未动，动的是「未选中色」这个词的含义。\n"
        "v3（2026-09-17）：第 3 关的 bef42d0c06b4a4e8（第1182 步）把 v2 打成反例。三处都是写死的读数："
        "(1) 坐标换逻辑格写死 //4，第 3 关一格是 3 像素、相位 (2,2)，算出来的格子整个偏掉；"
        "(2) 「段」按同色连续算，而第 3 关那根宽7 的杆中间嵌着一格色4，被切成 3+3 两截；"
        "(3) 宽度白名单写死 (3,5)，那是第 1 关的两种块宽。"
        "改法：坐标走 _lib.click_cell（从球身上量格子）、段走 _lib.piece_run（色8/色9/色4 一视同仁）、"
        "白名单走 _lib.solo_widths（本关块宽清单里拼不出来的那些宽度：第1 关 {3,5}、第2 关 {4,5,6}、第3 关 {4,5,7}）。"
        "预期的 next 也跟着改：段里那一格色4 不变色9，它跟着杆走但不是色8/色9。"
        "主张一个字没动，动的全是读法。\n"
        "v2：连续段宽度不是 3 或 5 时缩为 NA；并排的块在帧上并成一条，一段不等于一块。")
EVIDENCE = [
    "fc91e158ccd37821",  # 步910 点 (9,17) 即格 (4,2)，那里是未选中块，点完它被选中
    "065d295378ded8bf",  # 步917 同一个点法
    "61750eb60a38667c",  # 步908 点 (41,61) 落在发射器上，整帧不动
    "5a65087ea34919db",  # 步484 打脸 v1：段 c3-c10 是宽3+宽5 并排，点 c4 只选中 c3-c5
    "4b163d08c8145c65",  # 步491 打脸 v1：段 c2-c9，点 c3 只选中 c2-c4
    "784c5ac0ac3a016c",  # 步710 打脸 v1：段 c0-c7，点 c0 选中 c0-c4（宽5 在左）
    "fb496f267d8e27f7",  # 步1073 打脸 v1：段 c6-c13，点 c8 只选中 c6-c10
    "bef42d0c06b4a4e8",  # 步1182 打脸 v2：第 3 关，点中的是那根中间嵌着色4 的宽7 杆
    "e30d71d08571e535",  # 步1247 打脸 v3：第 4 关，点中宽5 杆，拐角块退回的是色15 不是色8
    "bc8b1fee828db588",  # 步1240 第 4 关：点中色15 的拐角块，三格一起变色9
    "a5ddf442802a5b51",  # 步1560 打脸 v4：第 6 关，选中的竖4杆退回的是色8 不是色15
    "4b5c70487ea5767d",  # 步351 打脸 v5：第 5 关，点在拐角块包围盒缺的那个角（空格）上，照样选中了它
]

from _lib import (LAUNCHER, PLAYER, UNSEL, UNSEL2, blobs_covering,  # noqa: E402
                  board, click_cell, nothing_hidden, piece_run, solo_widths)


def _comp_of_color(b, r, c):
    """含 (r, c) 的同色四连通块。"""
    col = b[r][c]
    out, stack = set(), [(r, c)]
    while stack:
        p = stack.pop()
        if p in out:
            continue
        out.add(p)
        pr, pc = p
        for n in ((pr - 1, pc), (pr + 1, pc), (pr, pc - 1), (pr, pc + 1)):
            if 0 <= n[0] < len(b) and 0 <= n[1] < len(b[0]) and b[n[0]][n[1]] == col:
                stack.append(n)
    return out


def _rest_color(b):
    """老色9 放下退回的颜色：直块（占一行或占一列）是色8，拐块是色15；没有色9 返回 None。"""
    rows = {r for r, row in enumerate(b) for v in row if v == PLAYER}
    cols = {c for row in b for c, v in enumerate(row) if v == PLAYER}
    if not rows:
        return None
    return UNSEL if (len(rows) == 1 or len(cols) == 1) else UNSEL2


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION6"):
        return "NA"
    if ctx:
        if "GAME_OVER" in (ctx.get("state_prev"), ctx.get("state_next")):
            return "NA"
        if ctx.get("level_prev") != ctx.get("level_next"):
            return "NA"
    if nothing_hidden(prev) is not True:
        return "NA"
    cell = click_cell(prev, action)
    if cell is None:
        return "NA"
    r, c = cell
    b, bn = board(prev), board(nxt)
    if not (0 <= r < len(b) and 0 <= c < len(b[0])):
        return "NA"
    if b[r][c] == LAUNCHER:
        return "NA"
    if b[r][c] not in (UNSEL, UNSEL2):
        cov = blobs_covering(b, (r, c), (UNSEL, UNSEL2, LAUNCHER))
        if not cov:
            return "TRUE" if bn == b else "FALSE"
        if len(cov) > 1:
            return "NA"                 # 两块的包围盒都罩住它：说不清选哪块
        vcov, comp = cov[0]
        if vcov != UNSEL2:
            return "NA"                 # 直块的包围盒就是它自己，缺角只在拐块上出现过
        picked = set(comp)
    elif b[r][c] == UNSEL2:
        picked = _comp_of_color(b, r, c)
    else:
        run = piece_run(b, r, c)
        if run is None:
            return "NA"
        if run[1] - run[0] + 1 not in solo_widths(b):
            return "NA"
        picked = {(r, cc) for cc in range(run[0], run[1] + 1) if b[r][cc] != LAUNCHER}
    rest = _rest_color(b)
    want = [list(row) for row in b]
    for rr in range(len(want)):
        for cc in range(len(want[0])):
            if want[rr][cc] == PLAYER:
                want[rr][cc] = rest
    for rr, cc in picked:
        want[rr][cc] = PLAYER
    return "TRUE" if bn == [list(row) for row in want] else "FALSE"
