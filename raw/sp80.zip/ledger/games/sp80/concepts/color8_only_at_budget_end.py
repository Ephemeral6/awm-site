"""第0 关里色8 只在「ACTION5 把预算走到 0」那一步出现：任何一步，次帧里有色8 当且仅当这一步是 ACTION5 且它让 HUD 的色14 格数归零。"""
LEVEL = "L5"
SCOPE = "只看第0 关（level_prev 是 0）的非 RESET 转移；换关或别的关返回 NA。断言的是次帧里色8 的有无，不管色8 长在哪。"
NOTE = ("v1。由来：216 步、168 条不同转移、300 多帧里，色8 只出现过一次——第216 步 431411666abf5782，"
        "ACTION5 把 HUD 从 2 格走到 0 格，整条横杆 80 个像素由色9 变色8，位置没动，随即 GAME_OVER。"
        "十四次 ACTION5 的预算位置 k 分别是 4,12,4,4,16,22,10,11,12,13,14,25,27,29，只有 k=29 那次有反应；"
        "k=29 的另外四步都是方向键，次帧色8 都是 0 像素。所以候选只剩两个，我押的是预算这一个。"
        "另一个候选是位置：第216 步横杆在逻辑 (行10,列0)，而这个位置此前一次都没按过 ACTION5。"
        "两者用一批就能分开——在 k=9 时把横杆挪到 (10,0) 按 ACTION5："
        "若变色8，这条概念当场垮，说明是位置不是预算；若不变，这条活下来。"
        "写下它就是为了让世界替我在这两个读法之间选一个。"
        "v2：世界选了预算。第226 步在 (10,0) 按 ACTION5、k=9，帧差只有 HUD 的 2 格，横杆没变色"
        "（4446609d6695cd79）。位置那一支排除。v2 补上 apply：把「哪些格子变色8」也说出来——"
        "所有色9 的格子原地变色8——这样下一次它错了会当场停批，而不是等结算才知道。"
        "v3：一进第1 关就挨了六条反例（第342-347 步全部）。原因是第1 关的开局帧里本来就站着两块色8："
        "逻辑 (行4, 列2-4) 和 (行6, 列7-9)，各 3 格宽，预算还满着（HUD=64）。"
        "所以「色8 = 预算耗尽时横杆的变色」这个读法只在第0 关成立，v3 把它明写进条件：level_prev 必须是 0。"
        "这两块静态色8 是第1 关的新物件，值得单写一条概念——它们不挡路（横杆从上面走过去，"
        "第344 步横杆盖住 (行6,列7-9) 那块时它整块消失、第345 步横杆挪开又原样回来，"
        "说明色8 是画在色9 底下的静态格子，不是被吃掉）。那条概念还没写，别拿这条冒充。")
EVIDENCE = ["431411666abf5782", "deabd8e0afb4e173", "e1faa111c8d1857a", "43eff7310e4b2a7e",
            "4446609d6695cd79",
            "bc565444d1820eed", "1960b16f0b2957dd", "fd953a1c1397057f",
            "44d3162eabfe0652", "0c9fb124f7e2da97", "61b08fc1a9a0d4af"]

ALT = 8
BAR = 9
HUD = 14
BUDGET, FULL = 30, 64
LADDER = [FULL - round(FULL * k / BUDGET) for k in range(BUDGET + 1)]   # 与 hud_is_30_step_budget 同一把尺，那边跑不通这边也该跟着垮


def _hud(g):
    return sum(row.count(HUD) for row in g)


def _fires(prev, action, nxt):
    return action.startswith("ACTION5") and _hud(prev) > 0 and _hud(nxt) == 0


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != 0:
        return "NA"
    if ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action == "RESET":
        return "NA"
    has8 = any(ALT in row for row in nxt)
    return "TRUE" if has8 == _fires(prev, action, nxt) else "FALSE"


def apply(prev, action, ctx=None):
    """只在「这一步 ACTION5 会把预算走到 0」时开口，说色9 的格子原地变色8。"""
    if ctx is None or ctx.get("level_prev") != 0:
        return None
    if not action.startswith("ACTION5"):
        return None
    h = _hud(prev)
    if h == 0:
        return None
    if h not in LADDER or LADDER.index(h) != BUDGET - 1:
        return None
    return {(r, c): ALT for r, row in enumerate(prev)
            for c, v in enumerate(row) if v == BAR}
