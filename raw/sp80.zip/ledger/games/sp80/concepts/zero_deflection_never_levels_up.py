"""球前方整条路上一个件格都没有（零偏折）时，ACTION5 从不推进关卡。

球从发射器出发沿固定方向走，路上没有任何件格可撞，就是一次没有偏折的自由落体。
这条主张：这样的一按，世界绝不换关——哪怕落点所在的列正好是顶口那一列。

判错的样子：某一发 ACTION5，按下之前球的整条前路上一个件格都没有，而世界换了关。

它和在册的换关判据在**一处**顶牛：判据里 `find_hit` 返回 None 的那一支会把该列记进
`landed_cols`，也就是把「自由落体落进顶口列」算成接住了。语料上两者从不冲突——
顶口之外还有侧口要喂，单独一支自由落体覆盖不了，所以判据在那些局面上照样判负。
真要分开这两种读法，得有一张「只剩一个顶口、球正对着它、路上一根杆都没有」的盘面。
"""
LEVEL = "L5"
SCOPE = (
    "只看 ACTION5（含带参数的形式）。ctx 里读不到 level_prev/level_next 返回 NA。"
    "帧上读不出球、或球所在的列上读不出发射器、或发射器和球同一行（读不出方向）返回 NA。"
    "球前方路上有件格（色8/9/15）时返回 NA——那一类归偏折的概念管，这条只说零偏折那一半。"
    "件格的口径**不含嵌在杆里的发射器格（色4）**：色4 在本局是件自带的记号，它跟着件走，"
    "但它本身挡不挡球没有独立证据，所以这条概念只拿三种确定的件色做判定。"
)
NOTE = (
    "v2（2026-09-23）：反例 042f7c6362a72dff——第 5 关带记号的横杆 H5 横在球列上，恰好是记号格（色4）"
    "压在球列那一格，v1 的件格口径不含色4，于是判「零偏折」，而世界换了关。同一发的 21 帧流水动画实读："
    "主球正是落在这一格顶上分成两股沿面流的——嵌在件里的色4 挡球，有了独立证据。"
    "改法：色4 且四邻有件色（色8/9/15）即算件格；球列上游那个孤立发射器不贴件色，不受影响。"
    "改后这条在 042f 上判 NA（有偏折，不归本条管）。\n"
    "v1（2026-09-20）。由来有两头。"
    "一头是现场：第 2907 步，球所在的那一列被清空之后按 ACTION5，帧逐格不变、计量条一格没熄"
    "（所以不是预算见底），世界直接判 GAME_OVER。"
    "另一头是普查：全语料 2022 条去重转移里 187 条 ACTION5 能读出球与方向，"
    "其中零偏折 49 条（第 0 关 20、第 1 关 25、第 5 关 4），**换关 0 条**；"
    "有偏折的 138 条里换关 14 条。零偏折这一栏里还有 3 条是 GAME_OVER。"
    "另一个会话用略宽的口径独立数过同一件事，方向一致。"
)
EVIDENCE = [
    "16582ddf80d1e2cf",   # 步5   第 0 关，零偏折，没换关
    "431411666abf5782",   # 步216 第 0 关，零偏折，GAME_OVER
    "0de5c2090093ad6c",   # 步1955 第 1 关，零偏折，没换关
    "d2c0f3882f39ab10",   # 步1973 第 1 关，零偏折，GAME_OVER
    "e6ff78b07744afde",   # 步2907 第 5 关，零偏折，GAME_OVER（现场那一发）
    "042f7c6362a72dff",   # v2 反例：记号格压球列，v1 误判零偏折；改后判 NA
]

from _lib import board, PLAYER, UNSEL, UNSEL2, LAUNCHER, BALL   # noqa: E402

BODY = (PLAYER, UNSEL, UNSEL2)


def _zero_deflection(b):
    """球沿行进方向的整条前路上有没有件格。读不出返回 None，有件格返回 False。"""
    balls = [(r, c) for r, row in enumerate(b)
             for c, v in enumerate(row) if v == BALL]
    if len(balls) != 1:
        return None
    br, bc = balls[0]
    lau = [r for r, row in enumerate(b) if row[bc] == LAUNCHER]
    if not lau:
        return None
    lr = min(lau, key=lambda r: abs(r - br))
    if lr == br:
        return None
    d = -1 if br < lr else 1
    r = br + d
    while 0 <= r < len(b):
        if b[r][bc] in BODY:
            return False
        if b[r][bc] == LAUNCHER and any(
                0 <= r + dr < len(b) and 0 <= bc + dc < len(b[0]) and b[r + dr][bc + dc] in BODY
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
            return False      # v2：嵌在件里的记号格（色4 贴着件色）也挡球
        r += d
    return True


def assert_(prev, action, nxt, ctx=None):
    if not str(action).startswith("ACTION5"):
        return "NA"
    if not ctx:
        return "NA"
    lp, ln = ctx.get("level_prev"), ctx.get("level_next")
    if lp is None or ln is None:
        return "NA"
    b = board(prev)
    if not b:
        return "NA"
    z = _zero_deflection(b)
    if z is not True:
        return "NA"
    return "TRUE" if lp == ln else "FALSE"
