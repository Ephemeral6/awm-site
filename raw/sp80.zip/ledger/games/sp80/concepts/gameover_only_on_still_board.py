"""GAME_OVER 那一步必定满足两条之一：HUD 归零（预算用尽），或棋盘一格没动；两条都不满足却 GAME_OVER 就是反例。"""
LEVEL = "L5"
SCOPE = "只看 state_prev=NOT_FINISHED 且 state_next=GAME_OVER 的转移；其余一律 NA。ctx 里没有 state 时返回 NA（预测口径下 state 全 None）。"
NOTE = ("v2：v1 说「GAME_OVER 只发生在棋盘无变化的那一步」，被第96步 deabd8e0 推翻——"
        "那一步横杆下移 4 行（帧差 162 格）却 GAME_OVER，因为 HUD 正好走到 0。"
        "所以这一局有两个死因，不是一个：(1) 预算用尽（HUD=0，见 hud_is_30_step_budget，k=30）；"
        "(2) 棋盘连续若干步不动——第62-66 步连续 5 次不动死在第 5 次，而 HUD 当时还剩 32 格（k=15），"
        "预算远没用尽。第53-55 步连续 3 次不动（撞上界）没事，所以那个阈值在 4 或 5。"
        "assert_ 看不到历史，数不了「连续几次」，只能把每条转移上可验的那部分写出来：死的那一步"
        "要么 HUD 归零、要么棋盘没动。这是个 OR，比 v1 弱，但它仍可判错——"
        "哪天出现「HUD 还有、棋盘也动了、却 GAME_OVER」，它当场垮掉，那说明还有第三个死因。"
        "v3：第371 步 4c486995 把 v2 打成反例——那一步是这条命的第5 次 ACTION5，棋盘确实一格没动，"
        "帧差只有 1 格 (列23,行63)。垮掉的是「棋盘 = 像素行1-63」这个写死的口径："
        "第0 关的 HUD 画在像素行0，第1 关画在像素行63，v2 于是把第1 关的 HUD 变化当成了棋盘变化。"
        "v3 改成从帧上认 HUD：整行只由色14 与色0 两种颜色组成的那一行就是 HUD 行，其余行才是棋盘。"
        "两关的 HUD 行都满足这条，而棋盘行里从没有一行只由 14 和 0 组成。"
        "教训与 reset_restores_level0_layout v4 同源：凡是把某一关的行号写进代码的地方，换关就是一次处刑。")
EVIDENCE = ["4adba876c01b9f5d", "deabd8e0afb4e173", "4c4869959c80008f"]

HUD = 14
OFF = 0


def _hud_rows(g):
    """HUD 行：整行只由色14 与色0 组成。棋盘行里没有这种行。"""
    return {r for r, row in enumerate(g) if set(row) <= {HUD, OFF}}


def assert_(prev, action, nxt, ctx=None):
    if not ctx:
        return "NA"
    if ctx.get("state_prev") != "NOT_FINISHED" or ctx.get("state_next") != "GAME_OVER":
        return "NA"

    hud = _hud_rows(prev) | _hud_rows(nxt)
    if not hud:
        return "NA"
    if sum(nxt[r].count(HUD) for r in hud) == 0:
        return "TRUE"
    for r in range(len(prev)):
        if r in hud:
            continue
        if prev[r] != nxt[r]:
            return "FALSE"
    return "TRUE"
