"""同一关里的 ACTION5 从不挪动棋子：除预算条外，要么整帧一格不动，要么只是选中归属在**块色**之间换了换——色8、色15（另一种未选中色）与色9 合起来占的格子集合一格不变，别的颜色一格不变。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION5、且前后两帧 state 都是 NOT_FINISHED、前后同关的转移；"
         "换关（包括通关那一步）、掉命那一步（state_next 不是 NOT_FINISHED）、RESET、别的动作返回 NA。"
         "预算条 = 前后任一帧取色14 的格子，它每一步都在掉，不参与比较。"
         "断言三句同时成立：(一) 色8∪色15∪色9 的格子集合前后完全相同；"
         "(二) 除预算条与这三色以外的每一格颜色前后完全相同；"
         "(三) 色9 的格子集合要么前后完全相同（空按），要么与原来的不相同（换了归属）——"
         "这一句是废话，写出来是为了让前两句单独承担全部风险。"
         "**这条不声称棒子交给谁**，只声称交棒不会让任何棋子动一步、不会凭空多出或少掉棋子格。")
NOTE = ("v6（2026-09-20，apply 那道「过关就闭嘴」的闸原先是死的）：v4/v5 用 "
        "`from <另一条概念> import _win` 借判据，而装置的加载器把概念执行成 `concept_<名字>` 模块，"
        "既不按文件名注册进 sys.modules，也不把 concepts/ 放上 sys.path。"
        "于是这句 import 只在「碰巧有别的东西把 concepts/ 垫上 sys.path」时才成功——"
        "`bet --policy` 会（规划器自己插了路径），`bet --predict` 直接给动作串就不会。"
        "同一条概念因此在不同入口给出不同的 apply，两边都不报错、都不进 PENDING。"
        "实测：第 2652 步之后那批手写动作串的押注里，本条对最后一发 ACTION5 预测了 3916 格，"
        "而按册子那一发过关、整帧重画——闸根本没关上。"
        "v6 改成裸 import 失败就按文件路径把邻居执行一遍并缓存。主张、assert_、EVIDENCE 未动。\n"
        "v5（2026-09-20，同一处 apply 借来的 WIN 再换一次）：v4 调的 "
        "levelup_iff_deflection_tree_feeds_every_mouth 第 2652 步吃了硬反例已 retire，"
        "改调 levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup._win，语义不变。\n"
        "v4（2026-09-20，只换 apply 借来的那条 WIN）：原先调 "
        "levelup_iff_every_branch_tries_slide_first._win，那条第 2638 步吃了硬反例已 retire；"
        "改调同族活下来的 levelup_iff_deflection_tree_feeds_every_mouth._win，语义不变。\n"
        "v3（2026-09-19，只动 apply 不动主张）：SCOPE 里「换关（包括通关那一步）返回 NA」这句"
        "原先只有 assert_ 兑现（它能读 ctx 的 level_next），apply 读不到 ctx 里的下一关，"
        "于是在过关那一发上照常预测「除棋子与预算条外一格不变」——而过关会把整帧重画。"
        "改法：apply 先调 levelup_iff_every_branch_tries_slide_first._win(prev)，判 True 就返回 None。"
        "主张、assert_、EVIDENCE 未动。\n"
        "v2（2026-09-18）：第 1276 步 36bc3e59c3664c67 当场推翻 v1——第 4 关那个三格拐角块"
        "被选中时是色9、交棒出去以后变回色15（不是色8），于是「色8∪色9 守恒」少了三格。"
        "**这条教训 _lib.UNSEL2 在第 1247 步就记下了，这条概念没跟着改，拖了 29 步才挨打**："
        "词汇表改了不算改版、不重新评分，所以它的更新不会自动传到引用它的主张上。"
        "v2 把两种未选中色一起算进守恒集合，主张的分量没变（仍是「交棒不挪棋子」），"
        "只是把「块」的定义从写死的两色换成 _lib 的 UNSEL/UNSEL2/PLAYER。"
        "判错的样子没变：某一发 ACTION5 让块格集合多出或少掉一格、或者某个块挪了位置。\n"
        "v1。这条是从 action5_passes_bar_to_next_block 的残骸里救出来的那一半。"
        "那条概念三版三打，死在「交给谁」上：追棋子身份之后看清同一对棋子会来回传棒"
        "（第447 步 P2@r4,c11-13 → P1@r9,c5-9，第452 步 P1@r7,c3-7 → 回 P2@r4,c11-13），"
        "任何 a*行+列 的线性次序都要求非整数权重，那是拟合不是规律。"
        "但它断言里的另一半——**守恒**——从来没被打过：v1/v2/v3 一路上 30 多条交棒样本里，"
        "色8∪色9 的格子集合一次都没变过，交棒只换颜色不换位置。"
        "**把这一半单独立出来，是因为我的打法整个压在它身上**："
        "既然交棒不挪棋子，那就不必解出次序也能让世界判一次——摆好布局，连按 ACTION5，"
        "棒子传到次序最大的那枚就会出现空按，而空按那一下布局与第一下完全相同，"
        "于是那一下就是世界对这个布局的判决（赢没赢归 win_bridges_marked_gap 管）。"
        "这条概念要是被打，上面那句「连按不改变布局」就垮了，我得回去重新想怎么让世界开口。"
        "所以它虽然弱，却是眼下最该被检验的一条。")
EVIDENCE = ["8946dde2e977987d", "b08ef3c54d67465d", "a2617915504f71e8", "c9119ab89cba4915",
            "f55b62ddfe619240", "5b2fe9ae7c40f9e3", "4c9a785169b673d3", "eeda3cd6c2bd86d5",
            "52974bb226f19ea6", "bf259ae2ef4f9fff",
            # 空按的那一侧
            "078a611d329c2c4c", "1d9a5203047033f0", "495ff7b1847ed9e7", "0285c9aa51de98c8",
            # v1 的死因：拐角块交棒回色15
            "36bc3e59c3664c67"]

from _lib import PLAYER, UNSEL, UNSEL2

BAR = PLAYER
BLOCKS = (UNSEL, UNSEL2, PLAYER)
BUDGET = 14
ALIVE = "NOT_FINISHED"


def _pts(g, colors):
    return {(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v in colors}


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if ctx.get("state_prev") != ALIVE or ctx.get("state_next") != ALIVE:
        return "NA"

    if _pts(prev, BLOCKS) != _pts(nxt, BLOCKS):
        return "FALSE"

    for r in range(len(prev)):
        for c in range(len(prev[0])):
            a, b = prev[r][c], nxt[r][c]
            if a == b:
                continue
            if a == BUDGET or b == BUDGET:
                continue          # 预算条每步都在掉，不归这条概念管
            if a in BLOCKS and b in BLOCKS:
                continue          # 只换归属，这条允许
            return "FALSE"
    return "TRUE"


_BORROWED = []


def _levelup(prev):
    """册子对「这一发会不会过关」的说法。读不出来就当作「不会」，保持原有发言范围不变。

    **不敢只写 `from … import`**：装置的加载器把概念执行成 `concept_<名字>` 模块，
    既不按文件名注册进 sys.modules，也不把 concepts/ 放上 sys.path——
    于是概念之间互相 import 只在「碰巧有别的东西（比如 --policy 导进来的规划器）
    把 concepts/ 垫上 sys.path」时才成功。同一条概念因此会在不同入口给出不同的 apply，
    而两边都不报错。所以裸 import 失败就按文件路径把邻居执行一遍，结果缓存住。
    """
    if not _BORROWED:
        _BORROWED.append(_load_win())
    win = _BORROWED[0]
    if win is None:
        return None
    try:
        return win(prev)
    except Exception:       # noqa: BLE001
        return None


def _load_win():
    name = "levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup"
    try:
        mod = __import__(name)
        return mod._win
    except Exception:       # noqa: BLE001
        pass
    try:
        import importlib.util
        from pathlib import Path
        p = Path(__file__).with_name(name + ".py")
        spec = importlib.util.spec_from_file_location("_borrowed_" + name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod._win
    except Exception:       # noqa: BLE001
        return None


def apply(prev, action, ctx=None):
    """只敢生成它确定不变的那部分：棋子以外、预算条以外的每一格。

    先问册子这一发会不会换关——SCOPE 明写「换关（包括通关那一步）返回 NA」，
    而 apply 看不见 level_next，只能靠通关判据自己问一次；不问的话，
    它会在过关那一发上把整张重画的帧预测成「除棋子外一格不变」。
    """
    if not action.startswith("ACTION5"):
        return None
    if _levelup(prev) is True:
        return None
    return {(r, c): prev[r][c]
            for r in range(len(prev)) for c in range(len(prev[0]))
            if prev[r][c] not in BLOCKS and prev[r][c] != BUDGET}
