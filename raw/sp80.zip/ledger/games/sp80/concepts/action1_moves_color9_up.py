"""ACTION1：色9 棋子整体上移恰好一个格子；但只要挪过去之后有一格落在界外、落在墙上、落进某个杯格的八邻光环、或落进球那一行的上下一行里，整帧棋盘就不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION1；换关返回 NA；色9 块定位不到、帧上量不出格子（没有球）返回 NA。"
         "只断言色9 占据的格子，不管它腾出来的格子变成什么颜色，也不管 HUD。")
NOTE = ("v12（2026-09-18）：界的读法整个换掉，四条移动概念一起改。由来是 action4 在第 1556 步挨的"
        "那条反例 949cf952b7b9b9af：第 6 关竖4杆停在行3-6，从列4 一连按了 12 次 ACTION4 走到列16，"
        "而 v11 的读法（右侧背靠墙的杯带在列17-18，界＝17 减 2 ＝列15）说第 12 次该不动。"
        "错在把界读成**全局**的：那口杯在行9-11，竖4杆在行3-6，根本够不着它。"
        "新读法见 _lib.shift_blocked——杯只挡自己的八邻光环（局部），球挡整条横带（全局），墙与界外照旧。"
        "这一条本身没挨打，改它是因为四条移动概念共用同一句读法（方法册「一族概念共用同一个写死的常量」）；"
        "probe83 在全部 991 条去重方向键转移上逐条对过：该动的动了、该挡的挡住了，0 错 0 弃权，"
        "旧读法在同一批上错 1 条。第 0~4 关上两种读法处处相同，所以这一版不改任何一关的旧读数。\n"
        "v11（2026-09-18）：界的公式从像素搬进逻辑格，并加上「背靠墙」这道门槛，四个方向合成 _lib.move_limit 一条。"
        "由来是 action3 在第 1272 步挨的那条反例（82511392b258b0b0）——左右界原先写的是棋盘边缘，"
        "而第 4 关有一条横躺在左侧、背后垫着一整列地板的杯，它也是界。"
        "这一条本身没挨打，改它是因为四条移动概念共用同一句读法（方法册「一族概念共用同一个写死的常量」）。"
        "probe42 在 966 条 ACTION1-4 转移上逐条对过：新读法四向 0 错，"
        "而且在第 0~3 关给出的界与 v10 的像素公式逐关相同（第 0 关上界仍是逻辑行3）。"
        "顺带销掉 v9 留下的那笔账：「上留一格、下留两格」的不对称是像素公式的假象，"
        "换成逻辑格两侧都是 2 格——块的近缘总停在带的内缘外隔一个空格处。\n"
        "v10（2026-09-18）：上界不再由「路上最近的那个球或杯」定，改由**最靠上那一条连续带**定。"
        "由来是第 1242 步的反例 db0fce5b0e199ce5：第 4 关有一个横躺在半腰的杯（逻辑行11-13、列1-2），"
        "而挨按的那块在列9-10、顶在像素行41。v9 数「上方任意一行里有没有色6/色11」，不问列，"
        "于是把那个杯的底行40 当成天花板，押「到顶了不该动」——世界照旧把它整体上挪了一格。"
        "probe33 量过：平移 -cell 后和 next 逐像素相同，差 0 格，**主张那一半一个字没错，错的只有界的公式**。\n"
        "为什么是「带」而不是「同列」：probe34 试过只数落在色9 自己列跨度里的球/杯——它一条不错，"
        "但在 423 条里哑掉 69 条，而那些哑掉的里头有第 0 关「块停住了、可它那几列上方根本没有球」的情形，"
        "说明挡住它的不是正上方那个物件，是**场地的天花板**。probe35 量了「最外那条带」："
        "第 0~3 关 422 条与 v9 逐条相同（对422 错0 哑0），第 4 关那条反例判对。"
        "第 0~3 关两种读法本来就是同一个东西——那四关的球/杯要么全贴顶要么全贴底，只有一条带。\n"
        "v9（2026-09-17）：上界换了写法，和 action2 的下界合成同一个公式。"
        "v7/v8 说的是「色9 与色1 地板之间的空隙恰好 3~11 格」；这句话在第 3 关站不住："
        "第 3 关的杆一进关就停在离地板 13 格的地方（逻辑行5，地板在逻辑行19），而且色1 在帧上出现两处"
        "（棋盘下沿像素行59-63，还有 HUD 底下像素行1 那一条），_floor 取 min/max 直接读反。"
        "**这一条还没在第 3 关上按过 ACTION1**，是先手改的：它和 action3 挨的那两条反例同源——"
        "都是把某一关量到的数字当成世界常量。\n"
        "v8（2026-09-17）：apply 的「腾出的格子变背景色12」加了前提 _lib.nothing_hidden(prev)——"
        "可见的色8+色9 格数正好等于家当，就是一格没被压住。第345 步那一帧正是「压着」的情形，v8 在它上面照旧沉默。\n"
        "v7：第1 关把 v4 的「顶行 12」打成反例（61b08fc1a9a0d4af，第347 步横杆顶行已在 16 却还在往上按，没动）。"
        "改法不是把 12 换成 16，那只会在第2 关再挨一次；改成从帧上量。"
        "v7 同时砍掉了「腾出的格子变背景色12」那半句在无遮挡之外的部分："
        "第345 步横杆从逻辑行 6 挪到行 5，腾出的格子里有 3 格变回色8（那儿本来就有一块静态色8），不是色12。")
EVIDENCE = ["1e9951e4688db504", "c712b5f6eb956ee5", "773b321373b96c23", "8ef7ad059a5fc65c",
            "25545c20dd72380a", "33467734ea490571", "61b08fc1a9a0d4af",
            "db0fce5b0e199ce5"]   # 第1242 步 第4 关：半腰那个杯不是天花板，v9 在这里判错

from _lib import LAUNCHER, PLAYER, cell_size, nothing_hidden, sel_piece_pixels, shift_blocked

BG = 12


def _pts(g):
    return {(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION1"):
        return "NA"
    a, b = _pts(prev), _pts(nxt)
    if not a or not b:
        return "NA"
    cell = cell_size(prev)
    blk = shift_blocked(prev, "1")
    if cell is None or blk is None:
        return "NA"

    if blk:                                # 挪过去会犯规：不动
        return "TRUE" if b == a else "FALSE"
    return "TRUE" if b == {(r - cell, c) for r, c in a} else "FALSE"


def apply(prev, action, ctx=None):
    """认领这块棋子将要占据的格子；只有确认没有块被压住时，才替腾出的格子说话。"""
    if not action.startswith("ACTION1"):
        return None
    a, lau = sel_piece_pixels(prev)
    if not a:
        return None
    cell = cell_size(prev)
    blk = shift_blocked(prev, "1")
    if cell is None or blk is None:
        return None
    if blk:
        out = {p: PLAYER for p in a}
        out.update({p: LAUNCHER for p in lau})
        return out
    out = {(r - cell, c): PLAYER for r, c in a}
    out.update({(r - cell, c): LAUNCHER for r, c in lau})
    if nothing_hidden(prev):
        for p in (a | lau) - {(r - cell, c) for r, c in (a | lau)}:
            out[p] = BG
    return out
