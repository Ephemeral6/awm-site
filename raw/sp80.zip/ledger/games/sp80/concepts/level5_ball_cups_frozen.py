"""第 5 关内部走一步，球（色6）和杯（色11）占的逻辑格一模一样，一格都不变。

判错的样子：第 5 关里有哪一步让球挪了位、或让某个杯口被填上/多出来，这条当场判 FALSE 关闸。

写它的理由：第 5 关的穷举（227,346,532 个四件摆位）把「球固定在发射器正下方、只向下落」
和「杯口集合由帧读出、与件的位置无关」当成前提用了。这两句话原本只写在
runs 里的推导文档 PRUNE_NECESSITY.md 的抬头上——那是我自己发明的世界事实，一次闸都没走过。
本条把它硬化成走闸的对象：穷举的结论有多强，取决于这句话能不能被打死。

注意它**不管色 4**：第 5 关有一块横件（H5）自己带着一个色 4 的记号格，会跟着件走，
色 4 的格子集合本来就在变。发射器那一格另说，不在本条的断言里。
"""
LEVEL = "L6"
SCOPE = ("只看 ctx.level_prev 与 level_next 都是 5 的转移；换关、别的关、RESET 返回 NA。"
         "只看 board(g) 给的逻辑格（它跳过 HUD 那条像素行），只查色 6 与色 11 两种颜色。"
         "board() 量不出格子（geometry 退化）时两帧的行列数对不上，返回 NA。")
NOTE = ("看门狗式的不变量：判 TRUE 只说明这一步没把球打出去、没动到杯，判 FALSE 才是我要的消息。\n"
        "  入册时（2026-09-21，第 3608 步）第 5 关已有 497 条转移，球只出现在 (1,9)、"
        "发射器只出现在 (0,9)（exhaust_full.out 首行是同一批语料上另跑的清点）。"
        "本条不引用那个清点，它自己在每条新转移上重判。")
EVIDENCE = [
    "601f8363f41c26e6",   # 步1355 ACTION1
    "423e040ee87c17ae",   # 步1489 ACTION1
    "4e60b86f18824dd7",   # 步1519 ACTION1
    "d1333d96add32ac0",   # 步2491 ACTION5（终局卡上第一次到第 5 关的那一发）
    "27ec65a487c82f83",   # 步2796 ACTION5（三条几何全真的那一发）
]

from _lib import board

FROZEN = (6, 11)


def _cells(frame, color):
    b = board(frame)
    return frozenset((r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == color)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if ctx.get("level_prev") != 5 or ctx.get("level_next") != 5:
        return "NA"
    if action == "RESET":
        return "NA"
    bp, bn = board(prev), board(nxt)
    if len(bp) != len(bn) or len(bp[0]) != len(bn[0]):
        return "NA"
    for color in FROZEN:
        if _cells(prev, color) != _cells(nxt, color):
            return "FALSE"
    return "TRUE"
