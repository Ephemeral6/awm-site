"""一发 ACTION5 推进关卡 ⟺ 从每个球出发、在每根挡路杆的**两端各分出一支**的那棵轨迹树，
每一支的落点都恰好落在某个杯口上（跑出棋盘左右边界的支不算），**且**每个杯口都至少接到一支，
**并且**树上每一跳（球到第一根杆、以及一支从一根杆走到下一根杆）之间的空行数都 ≥ 2。

判错的样子：某一发 ACTION5，上面这套算下来判「赢」，世界却留在同一关（或反过来）。

读法逐条（全部从帧上量，不写死任何关卡的行列）：
- 方向 d：球背离它自己那一格发射器（同列、最近的一格色4）的行方向。
- 杆：一行里色8/色9/色4 的极大连续段，段里至少有一格色8 或色9。
- 一支从行 r、列 c 出发，沿 d 找第一根**盖住列 c** 的杆（行 hr，列 [l, rr]）；
  净空 = |hr - r| - 1；中途那些不盖住列 c 的杆不参与计数。
- 到杆之后分两支，落到列 l-1 与列 rr+1（仍在行 hr），继续沿 d 走。
  出界（列 < 0 或 ≥ 棋盘宽）的那一支**消失，不算失败**。
- 路上再没有盖住本列的杆时，这一支的落点就是当前列；杯口由 _lib.cup_mouths 读。
"""
LEVEL = "L5"
SCOPE = (
    "只看 ACTION5（含带参数的形式）。ctx 里读不到 level_prev/level_next 时返回 NA。"
    "帧上读不出球（色6）、读不出球那一列的发射器（色4）、读不出方向、读不出杯口（色11 两行）时返回 NA。"
    "不区分 state：GAME_OVER 那一侧照样开口——语料里的 GAME_OVER 有两种来源"
    "（HUD 余额见底、以及一发失败的 ACTION5 直接判死），后者恰恰是 W 该判假的负例，"
    "把它们一律 scope 掉会白丢 9 条证据、并且抹掉唯一能钉死净空阈值的那一条。"
    "轨迹树的深度上限 40；超了返回 NA（语料里没有触发过）。"
    "杆里嵌着的那一格色4 算不算杆的一部分：本条按「算」写（色8/9/4 一视同仁），"
    "第 1239 步已经把这个自由度打掉了——那一发按「算」判赢、按「色4 是个洞」判不赢，世界给了过关。\n"
    "**杯的形状闸**：所有色11 连通块必须都是 5 格、包围盒 2 行 3 列、且落在同一对行上，否则返回 NA。"
    "理由不是怕输，是本条的读法只比较**列**：它把「落点」和「杯口」都化约成一个列号，"
    "这只有在所有杯都横着排在同一对行、口朝同一个方向时才说得通。"
    "第 4 关出现了一个 3 行 2 列、口朝右的杯，球也改成朝上走，横向行进本条根本不会算——"
    "那一片是空白，不是本条管得了的地方。闸由 `_cups_uniform` 在代码里核，不是只写在这段话里。"
)
NOTE = (
    "v3（2026-09-18）：在 150 条 ACTION5 上零错（TP 7 / FP 0 / TN 143 / FN 0，去重前；"
    "去重后 7 条推进只有 5 个不同 tid，三条推进的 tid 相同）。三个合取项缺一不可，各由一条转移钉住：\n"
    "  · 去掉「每支落点都是杯口」（只留杯口全覆盖）→ 步1166/1169/1160 变假阳："
    "那三盘每个杯口都接到球，但还有一支落在杯口之外的地板上。\n"
    "  · 去掉「每个杯口都接到一支」（只留每支落点是杯口）→ 22 条假阳（首条步459）。\n"
    "  · 去掉净空 ≥ 2 → 步1213/1214 与步268 变假阳。\n"
    "净空阈值被语料**双边夹死**在 2：取 1 时步268（球在行1、杆在它下面第 2 行、两端正对两个杯口）"
    "变假阳；取 3 时步977/1040/1078/1180 变假阴（它们的最小净空恰好是 2）。\n"
    "净空必须逐跳算：只管第一跳（球到第一根杆）时步1213/1214 变假阳——那两盘第一跳净空 3、"
    "后面几跳是 0 和 1。净空也必须只对「盖住本列的那根杆」计数：改成「沿途任何一行有杆就截断计数」后"
    "步1180 变假阴。\n"
    "出界的支必须放过：把出界记成失败后步1180 变假阴（它有两支出界，一支从最左那根杆的左端、"
    "一支从最右那根杆的右端）。\n"
    "**分支是必须的**：不分叉、只滑向某一端的四种读法（恒左/恒右/近端/远端）全部做不到零错，"
    "最好的一种仍有 32 条假阳（近端，配「每球都被接住、出界放过」）；"
    "配「杯口全覆盖」则一条正例都判不出来（单支路线覆盖不了两个以上的杯口），7 条推进全成假阴。\n"
    "已知没检验到的地方：语料里只有 4 关、每关的杯口数是 2/3/3/4，"
    "「每个杯口都接到一支」和「杯口数 ≤ 支数」在这些盘上没被分开过；"
    "另外语料里没有一盘是「某支落在杯口外的地板、但那个落点列恰好也是另一个杯口的列」，"
    "所以「落点列属于杯口集合」与「这一支被那个杯口接住」也没被分开。\n"
    "v2（2026-09-18）：加了 `_cups_uniform` 这道形状闸，并把第 1239 步（第 3 关过关、"
    "按本条预先算出来的摆法打的）记进 EVIDENCE。主张与阈值一个字没动，只是把「本条管哪一片」"
    "从 SCOPE 的散文落成了代码——第 4 关的杯不是横着排在同一对行上的，本条在那里应当闭嘴，"
    "而不是拿 cup_mouths 读出来的一串错列号硬判。"
)
EVIDENCE = [
    # 7 条推进（5 个不同 tid；步977/1040/1078 内容相同，撞成同一条）
    "30ce5262c037c052",   # 步341  第0关 杆[6,10] 在行11
    "0f0424d565dbfcf3",   # 步627  第0关 杆[6,10] 在行9
    "b2c501360c22b7c4",   # 步977/1040/1078 第0关 杆[6,10] 在行4，最小净空 2
    "cd5d98ddc8fb0622",   # 步1145 第1关 三根杆，落点 4/8/12 = 三个杯口
    "521cd1e24b71fa92",   # 步1180 第2关 三球四杆，两支出界，落点 2/7/13
    # 钉住净空阈值 = 2 的那一条：几何和赢的那几盘一样，只是杆贴着球近了一行
    "394a7aeaa0957a72",   # 步268  第0关 杆[6,10] 在行3，净空 1 → 没推进（当场 GAME_OVER）
    # 钉住「逐跳净空」的两条负例（第一跳净空 3，后面几跳 0/1）
    "e30d7df41a0b1820",   # 步1213
    "537ad3ad03303775",   # 步1214
    # 钉住「每支落点都得是杯口」的三条：杯口全覆盖了，但有一支落在列15 的地板上
    "71a0ab7a40ec7e96",   # 步1160
    "e5d5fbe4af8a1468",   # 步1166
    "a7c73f5937996356",   # 步1169
    # 一支都没被接住 / 只接住一部分
    "5b315c29d57fbd51",   # 步1155
    "34cca9c3a12d9c3c",   # 步1035 杆不盖球列，球直落地板
    "5b2fe9ae7c40f9e3",   # 步459  每支都落进杯口，但有杯口空着
    # 按本条预先算出来的摆法打的那一发：第 3 关，四个杯口全喂到，世界给了过关
    "61dbb129637800bd",   # 步1239 第3关 五杆重摆，落点 3/9/13/17
]

from _lib import PIECE, PLAYER, UNSEL, BALL, LAUNCHER, CUP, board, cup_mouths

MIN_CLEARANCE = 2      # 每一跳之间至少要空出这么多行。语料把它双边夹死在 2
MAX_DEPTH = 40         # 轨迹树的深度上限，防病态帧上打转


def _bars(b):
    """所有杆：(行, 左, 右)。色8/色9/色4 连成一段，段里至少有一格色8 或色9 才算杆。"""
    out = []
    for r, row in enumerate(b):
        c = 0
        while c < len(row):
            if row[c] in PIECE:
                l = c
                while c + 1 < len(row) and row[c + 1] in PIECE:
                    c += 1
                if any(v in (UNSEL, PLAYER) for v in row[l:c + 1]):
                    out.append((r, l, c))
            c += 1
    return out


def _balls(b):
    return [(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == BALL]


def _dir_of(b, br, bc):
    """这个球的行进方向：背离同列最近的那一格色4。读不出返回 None。"""
    lau = [r for r, row in enumerate(b) if row[bc] == LAUNCHER]
    if not lau:
        return None
    lr = min(lau, key=lambda r: abs(r - br))
    if lr == br:
        return None
    return -1 if br < lr else 1


def _cups_uniform(b):
    """所有杯都是「同一对行上、2 行 3 列的 5 格块」时才 True。

    本条只比较列号，这只有在杯全都横着排、口朝同一个方向时才说得通。
    第 4 关有一个 3 行 2 列、口朝右的杯，这里返回 False，本条就整条返回 NA。
    """
    cells = {(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == CUP}
    if not cells:
        return False
    rowspans = set()
    while cells:
        seed = cells.pop()
        comp, stack = {seed}, [seed]
        while stack:
            r, c = stack.pop()
            for nb in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if nb in cells:
                    cells.discard(nb)
                    comp.add(nb)
                    stack.append(nb)
        rs = [r for r, _ in comp]
        cs = [c for _, c in comp]
        if len(comp) != 5 or max(rs) - min(rs) != 1 or max(cs) - min(cs) != 2:
            return False
        rowspans.add((min(rs), max(rs)))
    return len(rowspans) == 1


def _win(g):
    """这一帧按本条读法算不算赢；读不出来返回 None。"""
    b = board(g)
    if not b or not b[0]:
        return None
    nrows, ncols = len(b), len(b[0])
    if not _cups_uniform(b):
        return None                     # 杯不是横着排的同一对行 → 本条的列比较不成立
    mouths = set(cup_mouths(b))
    if not mouths:
        return None
    balls = _balls(b)
    if not balls:
        return None
    byrow = {}
    for r, l, rr in _bars(b):
        byrow.setdefault(r, []).append((l, rr))

    landings = []
    for br, bc in balls:
        d = _dir_of(b, br, bc)
        if d is None:
            return None
        stack = [(br, bc, 0)]
        while stack:
            r, c, depth = stack.pop()
            if depth > MAX_DEPTH:
                return None
            hit, rr_ = None, r + d
            while 0 <= rr_ < nrows:
                for (l, right) in byrow.get(rr_, ()):
                    if l <= c <= right:
                        hit = (rr_, l, right)
                        break
                if hit is not None:
                    break
                rr_ += d
            if hit is None:
                landings.append(c)          # 这一支落到底了
                continue
            hr, l, right = hit
            if abs(hr - r) - 1 < MIN_CLEARANCE:
                return False                # 净空不够，这一发废了
            for e in (l - 1, right + 1):
                if 0 <= e < ncols:          # 出界的支消失，不算失败
                    stack.append((hr, e, depth + 1))
    if not all(c in mouths for c in landings):
        return False
    return mouths <= set(landings)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx is None:
        return "NA"
    lp, ln = ctx.get("level_prev"), ctx.get("level_next")
    if lp is None or ln is None:
        return "NA"
    try:
        w = _win(prev)
    except Exception:
        return "NA"
    if w is None:
        return "NA"
    return "TRUE" if w == (lp != ln) else "FALSE"
