"""ACTION1~4 不改变选中件（色9）的格数：搬动只挪位置，不造格也不吃格。

判错的样子：某一条 ACTION1~4 的转移，prev 和 next 的色9 格数不相等——
搬一下棋子把选中件的格子搬没了或者搬出来了。
"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION1/2/3/4（含带参数的形式），只数色9（PLAYER，选中件）的格数。"
    "换关（ctx.level_prev != ctx.level_next）返回 NA——换关是整盘重画。"
    "这一步进 GAME_OVER 返回 NA——预算耗尽那一步盘面会改色。"
    "prev 或 next 任一侧 board() 读不出来返回 NA。\n"
    "**明确不管色8、色15、色4**：v1 把它们一起数进去，被 122 条反例打死，见 NOTE。"
)
NOTE = (
    "v1（2026-09-20，入册即挨打）：主张是「`_lib.PIECE` 四色（8/9/4/15）的总格数守恒」，"
    "1331 条 ACTION1~4 里 **122 条反例**。\n"
    "  这条概念本来是被一次事故逼出来的：第 2804 步我把一件往下搬到和另一件四邻相接，"
    "而策略读盘是按**四邻连通块**切件的，于是 5 格那件和 3 格那件被读成一个 8 格的块——"
    "同一张盘，件数从 4 变 3，**没有任何东西报错**。我的整个摆位计划（目标摆法、动作串、"
    "发射件下标）全按件下标走，地基就这么换掉了，要到下一批才以「随机搜索找不到 4 件的摆法」"
    "的面目崩出来，看上去像搜索运气不好。我想用「总格数守恒」把「件数少了一个」钉成"
    "「两件贴上了」而不是「哪件没了」。\n"
    "\n"
    "v2（2026-09-20，缩 scope 到只数色9）：**反例打的不是主张，是词汇。**"
    "逐色数一遍（probe_piece_conservation.py）：122 条全都是色8 的格数在变，色4 另有 2 条，"
    "而**色9 在 1331 条里 0 条不守恒**。\n"
    "  也就是说词汇表里那条 `UNSEL = 8  # 实测：未选中的块` 站不住。"
    "色8 的格数在搬动中来回变（3↔6↔8↔5↔…），一块棋子不会这样；"
    "另一条在册概念 color8_only_at_budget_end 说色8 只在预算耗尽时出现——"
    "两件事合起来看，色8 更像**预算条**一类的读数，不是未选中的棋子；"
    "未选中的棋子色是 15（UNSEL2）。这个词从来没被评过分（改 `_lib` 不算改版），"
    "是这条概念第一次把它和帧上另一种读法对上，才对出反例。\n"
    "  **我没有顺手去改 `_lib.UNSEL`**：它被一批在册概念引用着，比赛中动它等于同时改动一批"
    "概念的地基，而现在正卡在第 5 关的实验上。这条记在这里，留给下一次专门审词汇的时候动。\n"
    "  v2 缩到只数色9 之后，这条仍然够用来认出并块事故："
    "色9 守恒 + 连通块数变少 = 两件贴上了。策略的 _unmerge 用的就是这一条。\n"
    "  下面 EVIDENCE 里那 122 条是 v1 的反例，原样登记；它们在 v2 的读法下全部判 TRUE。"
)
EVIDENCE = [
    # v2 的正面依据：摆位的三步，其中第 2804 步就是并块那一步（件数 4 变 3，色9 格数不变）
    "4985e522950f8ddd",   # 步2803 ACTION2
    "703b060e8b855e45",   # 步2804 ACTION2  **并块那一步**
    "bcad153daa94ae33",   # 步2805 ACTION2
    # v1 的 122 条反例（色8 的格数在变），原样登记
    "fd953a1c1397057f",   # 步344 ACTION1
    "44d3162eabfe0652",   # 步345 ACTION1
    "73df6557fe1cd750",   # 步352 ACTION1
    "94a55e6143d96599",   # 步362 ACTION1
    "db0ec60f368db97d",   # 步365 ACTION4
    "9bd7b81679fd99c6",   # 步366 ACTION4
    "5f9b82a4a805b084",   # 步367 ACTION4
    "ac59045a8e560e77",   # 步380 ACTION1
    "a3f19ed538548ad4",   # 步382 ACTION4
    "48272b6282ae34af",   # 步383 ACTION4
    "1610aafb3eb86f7d",   # 步384 ACTION4
    "da064d2e39aa6740",   # 步391 ACTION1
    "9b46e4f09087627f",   # 步392 ACTION1
    "52d77018b08864a0",   # 步396 ACTION1
    "197794acc94b1689",   # 步397 ACTION4
    "1773029f8abe740d",   # 步398 ACTION4
    "77fa3b4e91f92dfe",   # 步415 ACTION4
    "d75a04e99bc7102f",   # 步430 ACTION4
    "5a2590bd265874f3",   # 步431 ACTION4
    "f5c2eaea1f88b3c2",   # 步432 ACTION4
    "2d6ec7f401f49296",   # 步458 ACTION1
    "ed6c52547eefd7cd",   # 步481 ACTION1
    "8b895786a786eb50",   # 步482 ACTION4
    "fac911b62c9953da",   # 步499 ACTION1
    "ff5d54a3f53155fc",   # 步507 ACTION1
    "d17badbf7a0b993a",   # 步508 ACTION4
    "491014514fb344b8",   # 步520 ACTION1
    "78e787a3bbae2dce",   # 步524 ACTION2
    "1c346bf616c5adf3",   # 步526 ACTION2
    "ca8e2305258353a4",   # 步527 ACTION2
    "6141fc784a229176",   # 步541 ACTION3
    "5f7de3b38bf086c8",   # 步542 ACTION3
    "3b09f9ff0f38b134",   # 步545 ACTION1
    "31fc7f50d8a1b215",   # 步550 ACTION2
    "b32a70e4c2fa42a2",   # 步558 ACTION2
    "0e3e7d7427f1ef68",   # 步573 ACTION1
    "794d82b948c9e4ce",   # 步574 ACTION1
    "66ac119bd2a97a29",   # 步575 ACTION1
    "15a28ac1734375f6",   # 步578 ACTION1
    "11c203ff85a7d60a",   # 步599 ACTION1
    "ebefa5dfcd85eee2",   # 步602 ACTION4
    "894b9309d5e0e210",   # 步603 ACTION4
    "3ed605d3c8af720f",   # 步604 ACTION4
    "c64f3c32fad00ab1",   # 步605 ACTION2
    "b932be0b0462c56e",   # 步706 ACTION1
    "ed8eaf1d801ffb3e",   # 步707 ACTION4
    "9655f1ecf43e0dc6",   # 步724 ACTION3
    "dae4895df793b587",   # 步725 ACTION3
    "e500de5c7836075a",   # 步726 ACTION3
    "2b4cecb41a188fb8",   # 步735 ACTION1
    "08cab9fffe2ed018",   # 步736 ACTION4
    "a377f4416afc7663",   # 步741 ACTION4
    "7220b9472c8cb50a",   # 步742 ACTION4
    "cedd139f3c940f76",   # 步743 ACTION4
    "e4dfc7e7237901ed",   # 步744 ACTION4
    "dbe7627e70a5bd20",   # 步745 ACTION4
    "17ac421ffa6da1c8",   # 步747 ACTION4
    "e91d623921f766a3",   # 步757 ACTION4
    "a784e8dd18137aa1",   # 步758 ACTION4
    "ec3c3f2becd51cb0",   # 步759 ACTION4
    "5d02bab61f195f49",   # 步761 ACTION3
    "332fb1c0a5a8919f",   # 步762 ACTION3
    "a71dae001e44110b",   # 步764 ACTION3
    "761db0cad964b484",   # 步769 ACTION4
    "f9f925e57b6f153b",   # 步770 ACTION4
    "e37391ee17c8dbc2",   # 步800 ACTION1
    "f510615b9c3bbc6a",   # 步801 ACTION4
    "cf2199777110fbe0",   # 步802 ACTION4
    "d18cf0de7c4a6aa1",   # 步804 ACTION4
    "8fbe03a8f5d8ffcb",   # 步842 ACTION1
    "3075072fd05ea049",   # 步860 ACTION1
    "60fea33f1a08b496",   # 步950 ACTION1
    "fb5b380bb787537d",   # 步998 ACTION2
    "7361da76c17f04a9",   # 步1000 ACTION1
    "72381bce363f27e8",   # 步1025 ACTION1
    "1875eb37f2d390ba",   # 步1026 ACTION1
    "323bdf8c616d102a",   # 步1027 ACTION1
    "d528524bf1596e1e",   # 步1128 ACTION1
    "3bcfc85a72e5f3e9",   # 步1129 ACTION1
    "1fa2ee0b4fe81ba9",   # 步1130 ACTION1
    "be40c27138b13d62",   # 步1131 ACTION4
    "837eec5455d74ae2",   # 步1132 ACTION4
    "d2bb51a0266fe210",   # 步1133 ACTION4
    "c6cab1bb307817cc",   # 步1188 ACTION3
    "c76e6a417a47008c",   # 步1189 ACTION3
    "37b3d2fd899d77f1",   # 步1193 ACTION1
    "ba8deff7231a542c",   # 步1194 ACTION1
    "c6ee515c31d089ec",   # 步1208 ACTION2
    "1e4e9a7833ed7a0f",   # 步1211 ACTION2
    "9c9ff6dce35e9cbf",   # 步1212 ACTION2
    "a1d3d3b449a391c8",   # 步1231 ACTION1
    "cded616a2e584abe",   # 步1232 ACTION1
    "0ab35004787f7654",   # 步1320 ACTION3
    "1f8c9dd46a75fed8",   # 步1321 ACTION3
    "1be5c417a28cb789",   # 步1323 ACTION4
    "68c2b4c9c8283b77",   # 步1325 ACTION4
    "73e41f2b0696020e",   # 步1326 ACTION4
    "fbdf3df1be9f6ab8",   # 步1327 ACTION4
    "88fbd07bbc4d6543",   # 步1341 ACTION4
    "fb22e313e311d5ca",   # 步1342 ACTION4
    "eb5b64ef4fd48b57",   # 步1343 ACTION2
    "a1825174090ea993",   # 步1405 ACTION2
    "3b58cdd2ac8c87ab",   # 步1406 ACTION2
    "628898fbfdb115a9",   # 步1424 ACTION1
    "495c11926358a05c",   # 步1425 ACTION1
    "9dbe42491bdd11b8",   # 步1476 ACTION1
    "ab223cae5a573cf7",   # 步1478 ACTION3
    "e2b4b2b4356e7f58",   # 步1550 ACTION4
    "a7dbab8449eea763",   # 步1555 ACTION4
    "f1533510cc117ee4",   # 步2007 ACTION1
    "3ea4aee4922a4a2d",   # 步2008 ACTION1
    "29ac80b264913990",   # 步2024 ACTION2
    "d2361f02bdf9c8ae",   # 步2025 ACTION2
    "5a0c5dceb7e11861",   # 步2420 ACTION2
    "d3ae6e8193ba1e1f",   # 步2421 ACTION2
    "ea120ec67efcdb4d",   # 步2423 ACTION2
    "cf1766f6f4f52b8e",   # 步2424 ACTION2
    "673e6cbec5ad7d56",   # 步2441 ACTION1
    "85b3f48eea1e948d",   # 步2442 ACTION1
    "33af8a336d24ee20",   # 步2664 ACTION1
    "29f2236ec1f55ea7",   # 步2665 ACTION3
    "04a17b3705b4ef81",   # 步2666 ACTION3
]


def assert_(prev, action, nxt, ctx=None):
    from _lib import board, PLAYER

    if not action.startswith(("ACTION1", "ACTION2", "ACTION3", "ACTION4")):
        return "NA"
    m = ctx or {}
    if m.get("level_prev") != m.get("level_next"):
        return "NA"
    if m.get("state") == "GAME_OVER" and m.get("state_prev") != "GAME_OVER":
        return "NA"

    bp, bn = board(prev), board(nxt)
    if bp is None or bn is None:
        return "NA"

    np_ = sum(1 for row in bp for v in row if v == PLAYER)
    nn = sum(1 for row in bn for v in row if v == PLAYER)
    return "TRUE" if np_ == nn else "FALSE"
