"""第 5 关一次真发射（ACTION5 且盘面不动、或换关）换关，当且仅当射流水流模型判四个杯口全被喂到、且水流之间不交叉。

水流模型（两段 31/32 帧流水动画逐帧读出，与两段动画 0 帧不一致、含每个杯的填满时刻）：
源 = 固定球正下方一格 + 带记号横杆记号格正下方第二格（记号下方常驻第二个球，只在动画中间帧可见）。
头每帧走一格，四种：
- 下落：脚下空就下移。脚下是件：若左右恰有一侧被**同一件**堵着（这一件的内角），就朝另一侧出横向射流；
  否则左右空的各出一个沿面流。脚下是墙/地板就停。
- 沿面流：脚下空就落；否则前方空就前移；否则停。——所以横杆两端会把水漏下去。
- 射流：不看脚下，前方空就一直走；撞墙停；撞件就在自己那一列上下各分一股「爬」。
- 爬：侧前方一空就回到射流朝原方向走；否则沿竖向继续。——所以竖 4 的杆把一股射流劈成上下相隔 5 行的两股。
- 头走进杯口格（三面是杯壁的空格）即填满该杯。

判错的样子：模型判四口全中且无交叉的一发没换关；或模型判有口没喂到的一发换了关。
"""
LEVEL = "L5"
SCOPE = ("只看 ACTION5（含带参数）且 ctx.level_prev == 5。"
         "同关而盘面（逐格，跳过 HUD）变了 = 交棒不是发射 → NA；"
         "件分解不唯一或分解不出四件 → NA；"
         "水流有横向交叉（射流/沿面流/爬走进已湿的格；下落穿湿格动画实测照走，不算）或踩到未实测情形（落在杯壁上）→ NA："
         "交叉时水怎么走没有实测，只有一条旁证（一发射流穿两道水柱的四口全中摆法没换关）。")
NOTE = ("v1（2026-09-23）：由两段动画读出，模型在全语料第 5 关 ACTION5 上唯一的四口全中预测是一发射流横穿两道落柱的摆法，"
        "它没换关——所以交叉情形判 NA，不敢表态。")
EVIDENCE = ["7ce313918231c8c0", "8280dbecec88ac4c", "79cc69db3c2b3c4e", "fc3874df5b03797c", "9ed255f012ab6b31"]

from _lib import board

SHAPES = {
    'V4': [(0, 0), (1, 0), (2, 0), (3, 0)],
    'H5': [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4)],
    'E15': [(0, 0), (1, 0), (1, 1)],
    'E9': [(0, 1), (1, 0), (1, 1)],
}
PIECE_COLORS = {8, 9, 15}
EMPTY, CUP, N = 12, 11, 20


def _unwrap(g):
    while isinstance(g[0][0], list):
        g = g[0]
    return g


def _decompose(b):
    core = {(r, c) for r in range(N) for c in range(N) if b[r][c] in PIECE_COLORS}
    cells = set(core)
    for r in range(N):
        for c in range(N):
            if b[r][c] == 4 and any((r + dr, c + dc) in core for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
                cells.add((r, c))
    cands = {}
    for name, sh in SHAPES.items():
        cands[name] = []
        for r in range(N):
            for c in range(N):
                cs = [(r + dr, c + dc) for dr, dc in sh]
                if all(x in cells for x in cs):
                    if name == 'H5' and (b[r][c] == 4 or b[r][c + 4] == 4):
                        continue
                    cands[name].append(frozenset(cs))
    sols = []
    for v in cands['V4']:
        for h in cands['H5']:
            for e in cands['E15']:
                for f in cands['E9']:
                    if v | h | e | f == cells:
                        sols.append({'V4': v, 'H5': h, 'E15': e, 'E9': f})
    return sols


def _free(b, r, c):
    return 0 <= r < N and 0 <= c < N and b[r][c] == EMPTY


def _step(b, owner, kind, r, c, d, unsure):
    if kind == 'fall':
        if _free(b, r + 1, c):
            return [('fall', r + 1, c, 0)]
        if r + 1 >= N or (r + 1, c) not in owner:
            if r + 1 < N and b[r + 1][c] == CUP:
                unsure.append('fall_on_cup')
            return []
        bo = owner[(r + 1, c)]
        lf, rf = _free(b, r, c - 1), _free(b, r, c + 1)
        if owner.get((r, c - 1)) == bo and rf:
            return [('jet', r, c + 1, 1)]
        if owner.get((r, c + 1)) == bo and lf:
            return [('jet', r, c - 1, -1)]
        return ([('surf', r, c - 1, -1)] if lf else []) + ([('surf', r, c + 1, 1)] if rf else [])
    if kind == 'surf':
        if _free(b, r + 1, c):
            return [('fall', r + 1, c, 0)]
        return [('surf', r, c + d, d)] if _free(b, r, c + d) else []
    if kind == 'jet':
        if _free(b, r, c + d):
            return [('jet', r, c + d, d)]
        if (r, c + d) not in owner:
            return []
        return ([('climb', r - 1, c, (d, -1))] if _free(b, r - 1, c) else []) + \
               ([('climb', r + 1, c, (d, 1))] if _free(b, r + 1, c) else [])
    dh, dv = d
    if _free(b, r, c + dh):
        return [('jet', r, c + dh, dh)]
    return [('climb', r + dv, c, d)] if _free(b, r + dv, c) else []


def feed(b):
    """返回 (杯口集合, 被喂到的杯口集合, 不确定标记列表)；分解不唯一返回 None。"""
    dec = _decompose(b)
    if len(dec) != 1:
        return None
    dec = dec[0]
    owner = {x: nm for nm, cs in dec.items() for x in cs}
    mouths = set()
    for r in range(N):
        for c in range(N):
            if b[r][c] == EMPTY and sum(1 for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))
                                         if 0 <= r + dr < N and 0 <= c + dc < N and b[r + dr][c + dc] == CUP) >= 3:
                mouths.add((r, c))
    srcs = [(r + 1, c) for r in range(N) for c in range(N) if b[r][c] == 6]
    mr, mc = sorted(dec['H5'])[2]
    if mr + 2 < N and b[mr + 1][mc] in (EMPTY, 6) and (mr + 2, mc) not in srcs:
        srcs.append((mr + 2, mc))
    unsure, fed, wet = [], set(), set()
    heads = []
    for r, c in srcs:
        if not _free(b, r, c):
            continue
        if (r, c) in mouths:
            fed.add((r, c))
            continue
        wet.add((r, c)); heads.append(('fall', r, c, 0))
    visited = {(h[1], h[2], h[0], h[3]) for h in heads}
    for _ in range(100):
        if not heads:
            break
        nxt = []
        for k, r, c, d in heads:
            nxt += _step(b, owner, k, r, c, d, unsure)
        heads = []
        for k, r, c, d in nxt:
            if (r, c, k, d) in visited:
                continue
            visited.add((r, c, k, d))
            if (r, c) in mouths:
                fed.add((r, c)); continue
            if (r, c) in wet and k != 'fall':   # 下落穿过湿格动画里实测过（照走），横向的没测过
                unsure.append('cross')
            wet.add((r, c)); heads.append((k, r, c, d))
    return mouths, fed, unsure


def assert_(prev, action, nxt, ctx=None):
    if not ctx or ctx.get("level_prev") != 5 or not str(action).startswith("ACTION5"):
        return "NA"
    b0 = board(_unwrap(prev))
    leveled = ctx.get("level_next") != ctx.get("level_prev")
    if not leveled:
        b1 = board(_unwrap(nxt))
        if any(b0[r][c] != b1[r][c] for r in range(1, N) for c in range(N)):
            return "NA"
    res = feed(b0)
    if res is None:
        return "NA"
    mouths, fed, unsure = res
    all_fed = len(mouths) == 4 and fed == mouths
    if unsure:
        return "NA"
    return "TRUE" if all_fed == leveled else "FALSE"
