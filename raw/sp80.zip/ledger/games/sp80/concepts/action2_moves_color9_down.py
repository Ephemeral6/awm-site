"""ACTION2：色9 棋子整体下移恰好一个格子、没压着别的块时腾出的格子变背景色12；但只要挪过去之后有一格落在界外、落在墙上、落进某个杯格的八邻光环、或落进球那一行的上下一行里，整帧棋盘就不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION2；换关返回 NA；色9块定位不到、帧上量不出格子（没有球）返回 NA。"
         "断言只管色9占据的格子与它腾出的格子，不管 HUD。"
         "ctx 为 None 或 level 字段缺失时返回 NA；"
         "HUD 阶梯证得这条记录跳了不止一档（并步记录，见 _lib.tick_jump）返回 NA——"
         "单步效果类主张对它不可判。")
NOTE = ("v15（2026-09-22）：加并步闸。由来是 66b96f1e8e6d195f（第 227 步）：上游超时重试把两次 ACTION2 "
        "应用并成一条转移——帧上色9 一次挪了 8 像素行（两格），HUD 一次掉了 4 格（第0 关阶梯单步最多掉 3 格），"
        "而前后步 226、228 都是正常 1 格。世界事实「一次 ACTION2 = 1 格」没有被推翻——是动作标签撒了谎。"
        "这条记录对「单步效果」类主张不可判：判 FALSE 冤枉世界，判 TRUE 说谎，"
        "按 HUD 阶梯把它认出来（next 落在两步可达、一步不可达处，或预算回升）判 NA。"
        "检测器在 _lib.tick_jump，四条概念共用；顺带把 ctx 缺 level 字段的记录也明确排除出 scope。\n"
        + "v10（2026-09-18）：界的读法整个换掉，四条移动概念一起改。由来是 action4 在第 1556 步挨的"
        "那条反例 949cf952b7b9b9af：第 6 关竖4杆在行3-6 从列4 一连右移 12 格走到列16，"
        "而 v9 的读法（右侧背靠墙的杯带在列17-18，界＝列15）说第 12 次该不动——"
        "错在把界读成**全局**的，那口杯在行9-11，竖4杆够不着它。"
        "新读法见 _lib.shift_blocked：杯只挡自己的八邻光环（局部），球挡整条横带（全局），墙与界外照旧。"
        "这一条本身没挨打，是先手改的——四条移动概念共用同一句读法。"
        "probe83 在全部 991 条去重方向键转移上逐条对过：0 错 0 弃权；旧读法在同一批上错 1 条。"
        "第 0~4 关上两种读法处处相同。\n"
        "v9（2026-09-18）：界的公式从像素搬进逻辑格，并加上「背靠墙」这道门槛，四个方向合成 _lib.move_limit 一条。"
        "由来是 action3 在第 1272 步挨的那条反例（82511392b258b0b0），四条移动概念共用同一句读法，一起改。"
        "两处实质变化：(1) 判贴界改用块的**底缘**而不是顶缘——对只占一行的杆两者相同，"
        "对第 4 关那个跨两行的拐角块，底缘才是朝下那一侧的近缘，这是镜像该有的写法（语料里还分不开）；"
        "(2) 「往上留两个格子」和 action1 的「往下留一个格子加一个格」在逻辑格里是同一个数——"
        "v8 NOTE 里记的那笔「上下常数不对称、解释不了」的账，是像素公式写出来的假象，这一版销掉。"
        "probe42 在 966 条 ACTION1-4 转移上逐条对过：四向 0 错，第 0~3 关的界与旧公式逐关相同。\n"
        "v8（2026-09-18）：下界不再由「路上最近的那个球或杯」定，改由**最靠下那一条连续带**定，"
        "跟 action1 的上界同一个改法。**这一条还没在第 4 关上按过 ACTION2**，是先手改的："
        "第 4 关有一个横躺在半腰的杯（逻辑行11-13、列1-2），它已经在第 1242 步把 action1 的上界打成反例；"
        "下界这边一模一样——一块在半腰以上的杆往下按时，v7 会拿那个杯的顶行当地板，"
        "把「还能往下走好几格」算成「到底了」。probe35 在全语料上量过两种读法："
        "第 0~3 关 180 条 ACTION2 逐条相同（对180 错0 哑0），那四关的球/杯要么全贴顶要么全贴底、只有一条带，"
        "两种读法本来就是同一个东西；分家只发生在第 4 关。\n"
        "v7（2026-09-17）：把写死的 CELL=4 换成从帧上量的格子边长（_lib.cell_size），"
        "「两个逻辑行」也跟着按量出来的边长算。**这一条还没在第 3 关上按过 ACTION2**，是先手改的："
        "它和 action3 挨的那两条反例（117fe4bdb8dee1a7、dcf2fd5665dead9f）同源——第 3 关一格是 3 像素。"
        "下界公式本身一个字没动，第 3 关上它说的是「杯沿像素行53 往上两格 = 像素行47 = 逻辑行15」。\n"
        "v6（2026-09-17）：apply 的「腾出的格子变背景色12」加了前提 _lib.nothing_hidden(prev)——"
        "块能互相重叠，色9 从一块色8 身上滑走时腾出的格子露的是色8 不是背景色。"
        "assert_ 只管色9 的格子集合，一个字没改。\n"
        "v5（2026-09-17）：v4 把下界钉死成顶行 44，那是第0 关量的。第1 关球在下、杯沿在上，"
        "第648 步 bec285838dae16f6 从顶行44 又下了一行（帧差 98 格，正常走），"
        "紧接着第649-651 步 a44beede5bd57bae / 7823eaf0bb348b8b / fdcced4db39373b2 在顶行48 三下全是空动作（只掉 HUD）。"
        "所以下界不是一个常数，是随场地走的。"
        "第0 关下方是杯（色11 顶行52），52-8=44，与 v4 量到的一致；第1 关下方是球（色6 顶行56），56-8=48。"
        "两关一个公式，v4 的读数没被推翻，只是被并进来了。\n"
        "v4 原文：v3 把边界写成「位置没变也算通过」，等于自动兜底、几乎判不了错。"
        "v4 改成明说下界在顶行 44——横杆进不了行48-51，而色11 在行52 才开始，中间隔着一整逻辑行，"
        "所以下界不是「被色11挡住」，是另一回事，还没解释。")
EVIDENCE = ["017d005c12ec628e", "b9e15149f0fe7169", "81f4e9dd8e8a3e63", "12067f0d0e2b07a1",
            "bec285838dae16f6", "a44beede5bd57bae", "7823eaf0bb348b8b", "fdcced4db39373b2",
            "66b96f1e8e6d195f"]  # 第 227 步并步记录（两次应用被并成一条），tick_jump 证得后判 NA

from _lib import LAUNCHER, PLAYER, cell_size, nothing_hidden, sel_piece_pixels, shift_blocked, tick_jump  # noqa: E402

BG = 12


def _pts(g):
    return {(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION2"):
        return "NA"
    if ctx is None:
        return "NA"
    lp = ctx.get("level_prev")
    ln = ctx.get("level_next")
    if lp is None or ln is None:
        return "NA"
    if lp != ln:
        return "NA"
    if tick_jump(prev, nxt, lp) is True:
        return "NA"                        # 并步记录：单步主张不适用
    a, b = _pts(prev), _pts(nxt)
    if not a or not b:
        return "NA"
    cell = cell_size(prev)
    blk = shift_blocked(prev, "2")
    if cell is None or blk is None:
        return "NA"

    if blk:                                # 挪过去会犯规：不动
        return "TRUE" if b == a else "FALSE"
    return "TRUE" if b == {(r + cell, c) for r, c in a} else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION2"):
        return None
    a, lau = sel_piece_pixels(prev)
    if not a:
        return None
    cell = cell_size(prev)
    blk = shift_blocked(prev, "2")
    if cell is None or blk is None:
        return None
    if blk:
        out = {p: PLAYER for p in a}
        out.update({p: LAUNCHER for p in lau})
        return out
    out = {(r + cell, c): PLAYER for r, c in a}
    out.update({(r + cell, c): LAUNCHER for r, c in lau})
    if nothing_hidden(prev):
        for p in (a | lau) - {(r + cell, c) for r, c in (a | lau)}:
            out[p] = BG
    return out
