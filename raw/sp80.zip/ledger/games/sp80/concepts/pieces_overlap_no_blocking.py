"""第 1 关的块能互相重叠：色8 不挡色9，色9 照样移进去，被压住的色8 格在帧上就不见了。"""
LEVEL = "L2"
SCOPE = ("只看第 1 关内部（level_prev 与 level_next 都是 1）的 ACTION1/2/3/4；"
         "换关、RESET、别的动作返回 NA；色9 在前后帧不是一条完整横杆（单行、列连续）返回 NA；"
         "色9 撞到场地边界没动（前后位置一样）返回 NA——那是边界，不是块挡块。"
         "只断言「移了一格」，不断言被压住的块怎么了。")
NOTE = ("v1。来由：第 950 步把选中的宽5 从 行6 c7-c11 往上推两格，第二格正撞上 行4 那条"
        "由两个宽3 拼成的 c5-c10 实体。结果既不是被拦住，也不是把对方推走，而是直接叠上去："
        "帧差里 (28,16) 8→9，末帧只剩 行4 c5-c6（色8）与 行4 c7-c11（色9），可见 7 格。"
        "**这一条同时是观测模型**：第 1 关的三块共 11 格，可见格数少于 11 就说明有块被压住了，"
        "过去所有拿「可见段的宽度」下的结论，在可见格数不足 11 的帧上都不作数——"
        "语料里步414/429/459/521/579 那几次交棒就是这种帧。"
        "注意 bar_arena_is_9x12 只 scope 在第 0 关，第 1 关的场地边界至今没有概念管；"
        "所以这里把「撞边界没动」排除在 scope 外，不拿它当反例。")
EVIDENCE = [
    "60fea33f1a08b496",   # 步950 ACTION1：色9 宽5 从 行5 推到 行4，叠在 c5-c10 那条实体上
]

from _lib import CELL, PLAYER

_DELTA = {"ACTION1": (-CELL, 0), "ACTION2": (CELL, 0),
          "ACTION3": (0, -CELL), "ACTION4": (0, CELL)}


def _bar(g):
    pts = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER]
    if not pts:
        return None
    r0, r1 = min(p[0] for p in pts), max(p[0] for p in pts)
    c0, c1 = min(p[1] for p in pts), max(p[1] for p in pts)
    if r1 - r0 + 1 != CELL:
        return None
    if len(pts) != (r1 - r0 + 1) * (c1 - c0 + 1):
        return None
    return (r0, c0, c1)


def _overlaps(g, r0, c0, c1, color=8):
    return any(g[r][c] == color
               for r in range(r0, r0 + CELL) for c in range(c0, c1 + 1)
               if 0 <= r < len(g) and 0 <= c < len(g[0]))


def assert_(prev, action, nxt, ctx=None):
    d = _DELTA.get(action.split(":")[0])
    if d is None:
        return "NA"
    if ctx and (ctx.get("level_prev") != 1 or ctx.get("level_next") != 1):
        return "NA"
    a, b = _bar(prev), _bar(nxt)
    if a is None or b is None:
        return "NA"
    if a == b:
        return "NA"                            # 没动：可能是边界，本条不管
    tgt = (a[0] + d[0], a[1] + d[1], a[2] + d[1])
    # 只在「目标位置压着别的块」时开口——那正是块挡块该发生的地方
    if not _overlaps(prev, tgt[0], tgt[1], tgt[2]):
        return "NA"
    return "TRUE" if b == tgt else "FALSE"
