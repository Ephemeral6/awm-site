"""GAME_OVER 只有两种来路：预算条走到 0，或者动作是 ACTION5。别的动作在预算没见底时从不致死。

来由：deaths.py 把语料里 16 次 GAME_OVER 按 HUD 那条预算像素（色14）分开看，分得极干净——
9 次是 HUD 从 2 变 0（ACTION1/2/4/5 都有，跟摆法无关，就是钱花光了）；
另外 7 次全是 ACTION5 打出来的，而且打的时候预算还很宽裕（剩 34、19、41、16、26、53、49）。
没有第三种。

这条的用处是把「死」拆成两笔账：一笔是预算，可以靠 RESET 补；
另一笔是开火本身，补不了，只能少打。后一笔的规律 countshots.py 已经量出来了——
自上一次 RESET／换关／死亡以来的第 5 发 ACTION5 必死，7/7，前 4 发从不因此死，从来没有第 6 发；
但那条规律要数「第几发」，是一条帧上看不见的隐藏状态，单看一条转移判不出来，所以这里只落盘能判的这一半。

判错的样子：出现一次 GAME_OVER，动作不是 ACTION5，而 HUD 上的预算还没归零。
"""
LEVEL = "L5"
SCOPE = (
    "只在 state_next 是 GAME_OVER 的转移上开口；其余一律返回 NA。"
    "读不出 HUD 那条像素行时返回 NA。"
)
NOTE = "v1"
EVIDENCE = [
    "4adba876c01b9f5d",  # 步66  ACTION5 打死的，当时预算还剩 34
    "394a7aeaa0957a72",  # 步268 ACTION5 打死的，还剩 19
    "55f789d2e39c06f5",  # 步918 ACTION5 打死的，还剩 53
    "e3c9baef8734146d",  # 步1036 ACTION5 打死的，还剩 49
    "deabd8e0afb4e173",  # 步96  ACTION2，预算 2 变 0
    "f04f6931dba8b800",  # 步126 ACTION2，预算 2 变 0
    "27ae7078c40b1b21",  # 步850 ACTION1，预算 2 变 0
]

from _lib import hud_row  # noqa: E402

FUEL = 14


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("state_next") != "GAME_OVER":
        return "NA"
    r = hud_row(nxt)
    if r is None:
        return "NA"
    if action.startswith("ACTION5"):
        return "TRUE"
    return "TRUE" if sum(1 for v in nxt[r] if v == FUEL) == 0 else "FALSE"
