"""方向键挪块时，别的件不挡路：目标格压在别的件上，块照样整体挪过去。

这条把 `_lib.forbidden_cells` 的沉默说成一句能被判错的话。那个词只放了三样东西——
墙、杯格的八邻光环、球那一行的上下一行——**一个字都没提别的件**。
沉默不等于主张：在它被写成概念之前，「件挡不挡件」既没被证实也没被推翻，
而摆法空间的大小直接取决于这个答案。

由来：第 5 关的摆位穷举里，我自己加了一条「两件格子不许重叠」，据此跳掉了 250 多万个摆位。
那条规则不在册子里，是写扫描时一并杜撰的世界事实。回头问语料：
全部方向键转移里有 165 条「选中块的目标格压在别的件的格子上」（第 1/2/3/4/5 关都有），
**165 条全都照常移动，一条都没被挡住**。
"""
LEVEL = "L2"
SCOPE = ("只看 ACTION1/2/3/4；换关返回 NA；帧上没有选中块返回 NA；"
         "目标格没有压在别的件上返回 NA（那种情形由 shift_blocked 那几条概念管）；"
         "shift_blocked 判「被挡」（撞墙、撞光环、撞球的横带、出界）时返回 NA——"
         "那时候不动是别的原因，这条概念不认领")
NOTE = ("v2：删掉 apply。v1 的 apply 按**逻辑格**坐标返回，而装置逐格对答案用的是帧的"
        "像素坐标，于是认领 528 格、说对 0 格。这条本来就是不变量式的主张，生成不了整帧，"
        "只留 assert_。")
EVIDENCE = ["fd953a1c1397057f", "73df6557fe1cd750", "94a55e6143d96599",
            "ac59045a8e560e77", "da0574b3417d4834", "da064d2e39aa6740",
            "52d77018b08864a0", "a1739e5dcaa5cee2"]

from _lib import board, shift_blocked, PLAYER, UNSEL, UNSEL2, LAUNCHER

OTHER = (UNSEL, UNSEL2, LAUNCHER)
DIRS = {"ACTION1": (-1, 0), "ACTION2": (1, 0),
        "ACTION3": (0, -1), "ACTION4": (0, 1)}


def _sel(b):
    return {(r, c) for r, row in enumerate(b)
            for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    d = DIRS.get(str(action).split(":")[0])
    if d is None:
        return "NA"
    bp = board(prev)
    bn = board(nxt)
    if not bp or not bn:
        return "NA"
    sel = _sel(bp)
    if not sel:
        return "NA"
    blocked = shift_blocked(prev, str(action)[-1])
    if blocked is None or blocked:
        return "NA"
    others = {(r, c) for r, row in enumerate(bp)
              for c, v in enumerate(row) if v in OTHER}
    dest = {(r + d[0], c + d[1]) for r, c in sel}
    if not ((dest - sel) & others):
        return "NA"
    return "TRUE" if _sel(bn) == dest else "FALSE"
