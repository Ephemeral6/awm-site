"""RESET 把第0关棋盘复位：像素行1-63 逐格等于「横杆（色9 或色8）搬回行16-19列12-31 并恢复成色9、它原先占的格子变背景色12、其余格子照旧」，HUD 行0 满格色14。"""
LEVEL = "L5"
SCOPE = "只看第0 关（level_prev 是 0）的 RESET；换关或别的关返回 NA。逐格断言像素行1-63 与像素行0。"
NOTE = ("v2：v1 写成「除 9/14/0 外每种颜色的格子集合不变」，在三条 RESET 上全判 FALSE —— "
        "漏了背景色12：横杆归位时它腾出的格子变12、HOME 处的12 变9，色12 的集合当然会变。"
        "凡是有背景色的世界，「某色集合不变」这种写法都会自打脸，v2 改成逐格说清。"
        "由来：语料 5 条不同 RESET，色9 每次都回到行16-19 列12-31，HUD 每次回满 64 格，"
        "帧差里从没出现过色4/色6/色11/色1 的格子。写它是因为 RESET 是残差最大的几条转移（188-209 格无人解释），"
        "而规划器少不了它：GAME_OVER 之后只有 RESET 能继续。"
        "v3：v2 只认色9 是横杆，在 7bd666e43a5f17fd 上判 FALSE——那次 RESET 是从"
        "「横杆已变成色8」的局面上发的（第216 步之后），它腾出的 80 个格子该变背景，"
        "v2 却以为色8 不是横杆、该原样留着。教训是这条概念里藏着一个没走过闸的等式"
        "「横杆 = 色9」，色8 一出现它就不成立了。v3 把横杆定义成「色9 或色8」，"
        "并明说复位后恢复成色9。"
        "v4：第1 关的第一条 RESET（841b5772074b77ed）把它打成反例，理所当然——HOME 那张表和"
        "「棋盘上只有一块会动的东西」这两条都是第0 关的。这条 RESET 的实测是："
        "色9 回到像素行36-39 列20-39（逻辑 行9,列5-9），两块色8 回到 (逻辑行4,列2-4) 与 (逻辑行6,列7-9)，"
        "HUD 回满 64 格且画在像素行63（第0 关画在行0）。也就是说 RESET 复位的是**本关自己的开局布局**，"
        "不是某张固定的表。v4 只做一件事：缩回第0 关（level_prev 必须是 0）。"
        "缩掉的那一片值得单写一条——而且那条概念有个额外的用处：它能把每块色8 / 色9 的**开局列**"
        "从帧上定出来，而开局列正是 action5_hands_off_at_limit_row 现在写不进去的那半条规律。")
EVIDENCE = ["80317bcf68610445", "2d3ba4cadcc82613", "ee2ff99bf845ac90", "7bd666e43a5f17fd",
            "841b5772074b77ed"]

from _lib import PLAYER

HUD = 14
BG = 12
ALT = 8
HOME = {(r, c) for r in range(16, 20) for c in range(12, 32)}


def _expected(prev, r, c):
    if (r, c) in HOME:
        return PLAYER
    return BG if prev[r][c] in (PLAYER, ALT) else prev[r][c]


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != 0:
        return "NA"
    if ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if action != "RESET":
        return "NA"

    if any(v != HUD for v in nxt[0]):
        return "FALSE"
    for r in range(1, len(prev)):
        for c in range(len(prev[0])):
            if nxt[r][c] != _expected(prev, r, c):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    if ctx is None or ctx.get("level_prev") != 0:
        return None
    if action != "RESET":
        return None
    out = {(0, c): HUD for c in range(len(prev[0]))}
    for r in range(1, len(prev)):
        for c in range(len(prev[0])):
            out[(r, c)] = _expected(prev, r, c)
    return out
