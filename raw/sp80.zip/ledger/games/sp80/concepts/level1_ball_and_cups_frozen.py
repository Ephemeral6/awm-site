"""第1关内部走一步，球（色6）和杯（色11）占的格子一模一样，一格都不变。

由来：全语料 1381 张第1关的帧里，球恒为 16 像素、杯恒为 240 像素。
写成概念是为了当看门狗——第1关若有哪一发真把球打进了杯，
球或杯占的格子必然要变，那一步这条当场判 FALSE 关闸，逼我去看。
"""
LEVEL = "L6"
SCOPE = ("只看 level_prev 与 level_next 都是 1 的转移；换关、RESET、别的关返回 NA。"
         "只看 16x16 棋盘，HUD 那一列像素不算。")
NOTE = ("看门狗式的不变量：它判 TRUE 只说明这一步没得分，"
        "判 FALSE 才是我要的消息。1381 帧里一次没被推翻。")
EVIDENCE = ["daa233c0bfaee222", "323bdf8c616d102a", "b2998165755135f6"]

from _lib import board


def _cells(frame, color):
    b = board(frame)
    return frozenset((r, c) for r in range(16) for c in range(16) if b[r][c] == color)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if ctx.get("level_prev") != 1 or ctx.get("level_next") != 1:
        return "NA"
    if action == "RESET":
        return "NA"
    for color in (6, 11):
        if _cells(prev, color) != _cells(nxt, color):
            return "FALSE"
    return "TRUE"
