"""第0 关的 HUD 是 30 步预算在 64 格上的进度条：本关走了 k 步时色14 恰好 64 - round(64k/30) 格，每个非 RESET 动作让 k 加一。"""
LEVEL = "L4"
SCOPE = ("只看第0 关的非 RESET 动作；level_prev 不是 0、或换关，返回 NA；"
         "prev 的色14 格数不在这条阶梯上（说明 k 读不出来）返回 NA；k 已到 30 返回 NA；"
         "HUD 证得这条记录跳了不止一档（并步记录，见 _lib.tick_jump）返回 NA——"
         "一次按键走一档，跳两档的记录不是单步记录。")
NOTE = ("v11（2026-09-22）：加并步闸。由来是 66b96f1e8e6d195f（第 227 步）：上游超时重试把两次 ACTION2 "
        "应用并成一条转移——HUD 一次掉 4 格（62→58，阶梯单步最多掉 3 格），色9 一次挪两格，"
        "而前后步 226、228 都正常。世界事实「一步一档」没有被推翻——是动作标签撒了谎，"
        "这条记录对单步主张不可判，按 _lib.tick_jump 认出来判 NA。BUDGET 表随迁 _lib 单一来源。\n"
        + "v6（2026-09-20，apply 那道「过关就闭嘴」的闸原先是死的）：v4/v5 用 "
        "`from <另一条概念> import _win` 借判据，而装置把概念执行成 `concept_<名字>` 模块，"
        "不按文件名注册 sys.modules、也不把 concepts/ 放上 sys.path——这句 import 只在别的东西"
        "碰巧垫了路径时才成功（`bet --policy` 会，`bet --predict` 给动作串不会），"
        "同一条概念在不同入口给出不同的 apply 而两边都不报错。"
        "v6 改成裸 import 失败就按文件路径执行邻居并缓存。主张、assert_、EVIDENCE 未动。\n"
        "v5（2026-09-20，同一处 apply 借来的 WIN 再换一次）：v4 借的 "
        "levelup_iff_deflection_tree_feeds_every_mouth 在第 2652 步吃了硬反例已 retire，"
        "改借 levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup._win，语义不变。\n"
        "v4（2026-09-20，只换 apply 借来的那条 WIN）：原先问 levelup_iff_every_branch_tries_slide_first，"
        "那条第 2638 步吃了硬反例已 retire，改问同族活下来的 "
        "levelup_iff_deflection_tree_feeds_every_mouth._win，语义不变。\n"
        "v3（2026-09-19，只动 apply 不动主张）：终局卡第 0 关的最后一发 ACTION5 上报了 64 格意外，"
        "背书的是本条——assert_ 在那一步判 NA（它读得到 level_next 已经不是 0 了），"
        "但 apply 判不了：链式预测喂进来的 ctx 里 level_next 是 None，被 `not in (0, None)` 放行，"
        "于是它照第 0 关的阶梯预测 HUD 那一行还是色14，而过关把整行换成了色1。"
        "改法和同一天的 action5_noop / action5_never_moves_pieces 一样：apply 先问"
        " levelup_iff_every_branch_tries_slide_first._win(prev)，判 True 就闭嘴。"
        "**三条概念踩的是同一个坑**：SCOPE 里「换关返回 NA」这句话，assert_ 兑现得了，apply 兑现不了——"
        "assert_ 事后看得见 level_next，apply 事前看不见，它只能自己去问通关判据。\n"
        "v1。由来：第67-96 步一口气把 HUD 从 64 走到 0，逐格记下 31 个读数，"
        "和 64 - round(64k/30) 逐项相同（31/31）。先前把它读成「每步扣2、偶尔扣3」，"
        "那只是取整的表象——扣3 落在 k=4,12,19,27，间隔 8/7/8，不是等间隔，"
        "所以「每8步扣一次3」那个读法是错的。"
        "这条概念的真正用处是它给出了本关的硬预算：**30 步**。任何通关路线必须在 30 步内走完。"
        "k 靠 prev 的 HUD 读数反查（阶梯上 31 个值两两不同，可反查）。"
        "v2：进第1 关就挨了两条反例（bc565444d1820eed 第342 步 64→63、0c9fb124f7e2da97 第346 步 58→57），"
        "30 步那把尺预测的是 64→62、58→55。第342-347 步这六步的实测 HUD 是 64,63,61,60,58,57,55，"
        "逐步扣 1,2,1,2,1,2，平均 1.5 格/步。用 64 - round(64k/B) 去套，B=43/44/45 六项全中，B=42 与 B=46 都在第一步就出局——"
        "也就是说第1 关的预算比第0 关宽得多，但眼下还分不清是 43、44 还是 45，帧上也读不出 B。"
        "所以 v2 只做一件事：把这条概念缩回第0 关（level_prev 必须是 0）。"
        "缩了就不再声称管第1 关——第1 关的预算等读数够了再单写一条，不在这里拿一个猜的 B 冒充实测。"
        "顺带记一笔：第1 关的 HUD 画在像素行 63、而且色0 在左色14 在右，"
        "所以原来的 apply 往行 0 写格子在第1 关也是错的，一并被缩掉了。")
EVIDENCE = ["2338c5d606dcef13", "699783077c514a22", "8579ccdd93b00b20", "94be2cbd2bd07e9b",
            "deabd8e0afb4e173", "bc565444d1820eed", "0c9fb124f7e2da97",
            "66b96f1e8e6d195f"]   # 第 227 步并步记录（两次应用被并成一条），tick_jump 证得后判 NA

from _lib import BUDGET_BY_LEVEL, tick_jump   # noqa: E402

BUDGET = BUDGET_BY_LEVEL[0]
HUD = 14
FULL = 64
LADDER = [FULL - round(FULL * k / BUDGET) for k in range(BUDGET + 1)]


def _hud(g):
    return sum(row.count(HUD) for row in g)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    lp = ctx.get("level_prev")
    ln = ctx.get("level_next")
    if lp is None or ln is None:
        return "NA"
    if lp != 0:
        return "NA"
    if lp != ln:
        return "NA"
    if action == "RESET":
        return "NA"
    if tick_jump(prev, nxt, lp) is True:
        return "NA"                        # 并步记录：单步主张不适用
    h = _hud(prev)
    if h not in LADDER:
        return "NA"
    k = LADDER.index(h)
    if k >= BUDGET:
        return "NA"
    return "TRUE" if _hud(nxt) == LADDER[k + 1] else "FALSE"


_BORROWED = []


def _levelup(prev):
    """册子对「这一发会不会过关」的说法。读不出来就当作「不会」，保持原有发言范围不变。

    **不敢只写 `from … import`**：装置的加载器把概念执行成 `concept_<名字>` 模块，
    既不按文件名注册进 sys.modules，也不把 concepts/ 放上 sys.path，
    概念之间互相 import 因此时灵时不灵（见 NOTE v5）。裸 import 失败就按文件路径执行邻居。"""
    if not _BORROWED:
        _BORROWED.append(_load_win())
    win = _BORROWED[0]
    if win is None:
        return None
    try:
        return win(prev)
    except Exception:       # noqa: BLE001
        return None


def _load_win():
    name = "levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup"
    try:
        mod = __import__(name)
        return mod._win
    except Exception:       # noqa: BLE001
        pass
    try:
        import importlib.util
        from pathlib import Path
        p = Path(__file__).with_name(name + ".py")
        spec = importlib.util.spec_from_file_location("_borrowed_" + name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod._win
    except Exception:       # noqa: BLE001
        return None


def apply(prev, action, ctx=None):
    """SCOPE 的「换关返回 NA」在 apply 里没法靠 ctx 兑现——链式预测时 level_next 还不知道，
    是 None，而 None 被当成「没换关」放行。所以这里改问册子的通关判据：
    它说这一发会把关卡推过去，本条就闭嘴（第 2512 步 b2c501360c22b7c4 的 64 格意外就是这么来的：
    过关那一发把 HUD 整行从色14 换成了色1，而本条照着第 0 关的阶梯预测它还是色14）。"""
    if ctx is None or ctx.get("level_prev") != 0 or ctx.get("level_next") not in (0, None):
        return None
    if action == "RESET":
        return None
    if _levelup(prev) is True:
        return None
    h = _hud(prev)
    if h not in LADDER:
        return None
    k = LADDER.index(h)
    if k >= BUDGET:
        return None
    left = LADDER[k + 1]
    return {(0, c): (HUD if c < left else 0) for c in range(len(prev[0]))}
