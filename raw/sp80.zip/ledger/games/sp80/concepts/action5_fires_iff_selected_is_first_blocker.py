"""ACTION5 只要色9 既在「沿球的行进方向离发射器最近」的那一行、又盖住球所在的列，就一定是发射（选中块不变），不会交棒。

这是**充分条件**，不是充要：色9 不满足这两条时本条返回 NA。
反过来那一侧（什么时候一定交棒）语料里还切不干净，留在残差里。

来由：第 1134 步花一发子弹买来的。当时色9 是 带4[c8-c12]，盖住球列 c10 但不是最靠下
（带6[c8-c10] 在它下面），结果不是发射而是交棒——帧差 130 格 =
80 格 9→8（宽5 让出选中）加 48 格 8→9（带6 那块接手）加 2 格 HUD。
按上一版读法（action5_noop_needs_lowest_or_ballcol 的「盖球列」支）本该发射，所以那一支不充分。

把 52 发干净帧的第 1 关 ACTION5 交叉制表（probe3.txt / probe4.txt）：
  「最靠下」单用      34 发射 / 1 交棒（那一条是步452，色9 带7[c3-c7] 不盖球列）
  「盖球列」单用      29 发射 / 7 交棒
  两条**同时**成立    25 发射 / 0 交棒   ← 本条
判错的样子：某一发 ACTION5，色9 既最靠下又盖住球列，却换了选中块。
"""
LEVEL = "L1"
SCOPE = (
    "只看 ACTION5，且前后同关；前后任一侧 state 是 GAME_OVER 返回 NA。"
    "只在「色9 在离发射器最近的那一行 且 盖住球列」时开口，其余一律 NA——这是充分条件，不管交棒那一侧。"
    "「离发射器最近」：先用 _lib.travel_dir 读球的行进方向（背离发射器的那一侧），"
    "球朝下（+1）取全盘杆的最小行，球朝上（-1）取最大行；选中杆在那一行即算最近，同行有几根都算。"
    "段的切法：色8/色9/色4 连成一段，段里至少有一格色8 或色9 才算杆——"
    "色4 也算进来是因为一根杆中间可能嵌着一格发射器（第 3 关那根宽7 的），按同色切会被拦腰截断。"
    "块有遮挡（_lib.nothing_hidden 不为 True）时返回 NA：重叠时「一段=一块」失效，"
    "段的端点与归属都不可信（见 pieces_overlap_no_blocking）。"
    "帧上读不出球（色6）、读不出发射器（色4）、读不出方向、读不出恰好一段色9，一律返回 NA。"
)
NOTE = (
    "v5（2026-09-18）：把「全盘最靠下」换成「沿球的行进方向离发射器最近」。"
    "**v4 在第 3 关第 1213 步当场挨打**（e30d7df41a0b1820）：选中 行10[c4-c8] 既是最靠下、"
    "又盖住球列 c7，按 v4 该发射，世界却交棒给了 行5[c7-c11]——离发射器最近的那一根。"
    "第 3 关是第一关把两个读法分开的：发射器在盘顶（行0）、球朝下，最靠下＝离发射器最远。"
    "前三关分不开——第 0 关全盘只有一根杆，第 1/2 关发射器在盘底、球朝上，两个读法给同一根。"
    "所以「最靠下」一直是个**被关卡布局掩住的常量**，撑了四版才露出来。"
    "全语料试跑（probe22.txt，149 条 ACTION5）：v4 TRUE 48 / FALSE 1；"
    "v5 TRUE 48 / FALSE 0，那条反例转成 NA（选中的不是最近那根）；"
    "同时试了去掉「盖球列」那一支（只留「最近」）：步452 当场判 FALSE，所以两支都得留。"
    "「最近」用行号取极值（同行多根都算），比 v4 的 (行,左列) tie-break 开口更大，"
    "在语料上两者同为 FALSE 0，取开口大的那个。\n"
    "v4（2026-09-18）：把「只管第 1 关」这道 scope 去掉，主张一个字没动。"
    "当时的理由是：第 2 关第 1180 步那一发赢球的 ACTION5，选中的杆根本不盖球列"
    "（选中 行10[c10-c15]，球在 c1，盖住 c1 的是 行8[c0-c5]），照样发射，"
    "所以 v3 的物理解释「球路上第一块挡路的才放得出球」连必要条件都不是。"
    "那一条判断至今仍成立；v4 错的是另一半——它以为撑住这条概念的是「最靠下」这个几何写法。"
    "顺带把两处写死的第 1 关常量删了：INVENTORY=11 / NPIECES=3 换成 _lib.nothing_hidden，"
    "段的切法从 _lib.piece_spans（按同色切）换成本文件的 _bars（色8/9/4 一视同仁）。"
    "**文件名里的 first_blocker 已经名不副实**（主张从来没提过「第一块」），改名要走撤册，留着当个记号。\n"
    "v2。v1 写成了充要（「发射 ⟺ 下方没有别的块盖球列」），挨了 15 条反例："
    "语料里有 11 发交棒，下方并没有人盖球列——步452 色9 最靠下却交棒、"
    "步378/469/534/932/961/985 色9 是唯一盖住球列的块却交棒。"
    "所以交棒那一侧还有没读出来的东西，v2 退回只说发射这一侧。"
    "v1 那 15 条反例在 v2 下全部判 NA（probe5.txt 逐条核过）："
    "其中 14 条色9 不是最靠下，步452 那条最靠下但不盖球列。"
    "缩了 scope 就不再声称管交棒那一片——那一片现在是残差，没人管。"
)
EVIDENCE = [
    # v5 的由来：第 3 关第 1213 步，v4 在它上面判 FALSE。v5 判 NA——
    # 选中的 行10[c4-c8] 不是离发射器最近的那一根（行5 才是），所以本条对它不开口。
    "e30d7df41a0b1820",   # 步1213
    # v4 的关键依据：第 2 关唯一一发赢球的 ACTION5，选中的杆不盖球列却照样发射，
    # 「球路上第一块」连必要条件都不是。它换了关，本条在它上面判 NA。
    "521cd1e24b71fa92",   # 步1180
    # 支持这条主张的正例（挑形状不同的几条，probe4.txt）
    "1d9a5203047033f0",   # 步514  色9 带9[c8-c12]，其余 带4[c5-c7] 带4[c9-c11]
    "358aa6f83e24d547",   # 步647  色9 带11[c8-c10]，其余 带4[c5-c7] 带10[c0-c4]
    "3c69f8ca8a12dbd7",   # 步663  色9 带12[c10-c12]，同带左边还有 带12[c5-c9]
    "48f80d4d437d41a0",   # 步1101 色9 带10[c7-c11]，其余 带4[c9-c11] 带7[c6-c8]
    # 以下 15 条是 v1 挨的反例，登记在此；v2 在它们上面判 NA（scope 之外）
    "020bedb9e8a329c3",   # 步1074
    "250a1fa10509a5b0",   # 步911
    "2cda359ee55f075b",   # 步424
    "46365f248f0716e9",   # 步932
    "478942c324598319",   # 步378
    "4c9a785169b673d3",   # 步961
    "57c4b8b3d74797ea",   # 步963
    "8946dde2e977987d",   # 步394
    "96d8c6f5c46d2d71",   # 步939
    "bf259ae2ef4f9fff",   # 步534
    "c5c8cc0cc5d27303",   # 步973
    "c9119ab89cba4915",   # 步447
    "e756cdffac79a418",   # 步985
    "eeda3cd6c2bd86d5",   # 步483
    "f55b62ddfe619240",   # 步452   唯一一条「最靠下但不盖球列」的交棒
]

from _lib import PIECE, PLAYER, UNSEL, board, ball_col, nothing_hidden, travel_dir


def _bars(b):
    """所有杆：(行, 左, 右)。色8/色9/色4 连成一段，段里至少有一格色8 或色9 才算杆。"""
    out = []
    for r, row in enumerate(b):
        c = 0
        while c < len(row):
            if row[c] in PIECE:
                l = c
                while c + 1 < len(row) and row[c + 1] in PIECE:
                    c += 1
                if any(v in (UNSEL, PLAYER) for v in row[l:c + 1]):
                    out.append((r, l, c))
            c += 1
    return out


def _sel(b):
    """恰好一段含色9 时返回那一段，否则 None。"""
    s = [x for x in _bars(b) if PLAYER in b[x[0]][x[1]:x[2] + 1]]
    return s[0] if len(s) == 1 else None


def _read(g):
    b = board(g)
    if nothing_hidden(g) is not True:
        return None
    sp = _bars(b)
    if not sp:
        return None
    cur = _sel(b)
    if cur is None:
        return None
    bc = ball_col(b)
    if bc is None:
        return None
    d = travel_dir(b)
    if d is None:
        return None
    return (sp, cur, bc, d)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx is not None:
        if ctx.get("level_prev") != ctx.get("level_next"):
            return "NA"
        if "GAME_OVER" in (ctx.get("state_prev"), ctx.get("state_next")):
            return "NA"
    a = _read(prev)
    if a is None:
        return "NA"
    spans, cur, bc, d = a
    # 离发射器最近的那一行：球朝下走（d=+1）时发射器在上方，最近＝行号最小
    near_row = min(s[0] for s in spans) if d == 1 else max(s[0] for s in spans)
    if cur[0] != near_row:
        return "NA"
    if not cur[1] <= bc <= cur[2]:
        return "NA"
    after = _sel(board(nxt))
    if after is None:
        return "NA"
    return "TRUE" if after == cur else "FALSE"
