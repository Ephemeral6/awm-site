"""每一关的 HUD 是本关步数预算 B 在 64 格上的进度条，B 按关是 30/45/100/120/100/120：非 RESET 的一步把色14 计数从 64-round(64k/B) 推到 64-round(64(k+1)/B)。"""
LEVEL = "L4"
SCOPE = ("只看非 RESET 且不换关、且非 ACTION6 的动作；RESET、ACTION6、换关（level_prev != level_next）、"
         "level_prev 不在 0..5 这张表里、或 prev 的色14 计数不落在本关阶梯上，一律返回 NA。"
         "「不在阶梯上」那一格是真的弃权：k 反查不出来就没资格表态。"
         "ACTION6（点击选择）不消耗预算。"
         "HUD 证得这条记录跳了不止一档（并步记录，见 _lib.tick_jump）返回 NA——"
         "一次按键走一档，跳两档的记录不是单步记录。")
NOTE = ("v3（2026-09-22）：加并步闸。由来是 66b96f1e8e6d195f（第 227 步）：上游超时重试把两次应用"
        "并成一条转移，HUD 一次掉 4 格（第0 关阶梯单步最多掉 3 格）。这条记录对「一步一档」的主张不可判——"
        "它不是单步记录，按 _lib.tick_jump（与 succ 同一副阶梯造出来的两步可达集）认出来判 NA。"
        "顺带把 BUDGET 表搬进 _lib（BUDGET_BY_LEVEL）单一来源，四条概念共用。\n"
        "v2（2026-09-21）。缩 scope：ACTION6（点击选择）不消耗预算，295d4a032fb2a0b7 反例。\n"
        "v1（2026-09-20）。由来是一次量错。我先前手里只有两个数：第 0 关的 30（hud_is_30_step_budget，"
        "它自己的 v2 已经把自己缩回第 0 关）和一个下界 64（hud_drops_at_most_one_from_level2，"
        "它只敢断言『每步最多掉 1』，因为从单条转移反查不出 k 的奇偶）。"
        "排最后一关的摆位路线时我一直拿 64 当预算用——那是下界，不是预算。\n"
        "量法分两步，中间拐过一次弯：\n"
        "甲、先拿 hud == 64 - ceil(k/p) 去拟合周期 p，六关全不中，连第 0 关（公式已知）都只对每段的 k=0 那一条。"
        "一个拟合在**已知答案的那一关**也不中，错的就不是参数而是前提——我默认『每个非 RESET 动作都扣预算』，"
        "而这个前提从没量过。\n"
        "乙、改成直接量跌幅，按 (关, 动作) 交叉：跌幅与动作种类无关（同一关里 ACTION1 到 ACTION5 的"
        "跌0/跌1 比例一致），前提成立；ACTION6 例外，它不扣预算。而阶梯形式是 round 不是 ceil。换回 round 后逐关搜 B，"
        "六关各自唯一、各自全中：30/45/100/120/100/120，读数 806/969/225/416/482/395 条，无一例外，"
        "也没有第二个 B 能全中（所以不是区间，是点）。\n"
        "为什么 assert_ 不直接按 k 判：概念只拿得到一条 (prev, action, nxt)，拿不到『进本关第几步』，"
        "而 B=120 的阶梯上一个 h 最多对应两个 k，反查不出来。所以改判等价的后继形式："
        "hud(nxt) 必须属于 succ(hud(prev))。这个写法在 B=100 的关上有 28 个 h 的 succ 是单元素、"
        "B=120 的关上有 8 个，落在那些位置的转移才是真检验（逐关 786/955/65/31/137/33 条）；"
        "别的位置它退化成『掉 0 或掉 1』，和 hud_drops_at_most_one_from_level2 同强度。"
        "全语料 TRUE 3229 / FALSE 0 / NA 172。\n"
        "这条概念的用处是给路线一把尺：最后一关的预算是 **120 步**，不是我一直在用的 64。")
EVIDENCE = ["1e9951e4688db504",   # 第0 关 64->62，succ 单元素
            "bc565444d1820eed",   # 第1 关 64->63，succ 单元素
            "32f13981fbcdb338",   # 第2 关 64->63，succ 单元素
            "117fe4bdb8dee1a7",   # 第3 关 64->63，succ 单元素
            "bc8b1fee828db588",   # 第4 关 64->63，succ 单元素
            "c913060e12aead3f",   # 第5 关 64->63，succ 单元素
            "d8e4ec0190070b42",   # 第5 关 RESET：scope 外，判 NA
            "295d4a032fb2a0b7",   # ACTION6:9,17 不消耗预算，判 NA
            "66b96f1e8e6d195f"]   # 第 227 步并步记录（两次应用被并成一条），tick_jump 证得后判 NA

from _lib import BUDGET_BY_LEVEL as BUDGET, tick_jump   # noqa: E402

HUD = 14
FULL = 64


def _hud(g):
    """整帧数色14 的格数。

    故意不走 _lib.hud_row：那个词把 HUD 定位到某一行，本局已有三条概念从它取值，
    彼此核对等于没检验过它。整帧计数是帧上的另一种读法——两者对不上时，对不上的那条就是反例。
    （而且 HUD 不在同一行上：第 0 关画在像素行 0，第 1 关画在行 63。）
    """
    return sum(row.count(HUD) for row in g)


_SUCC = {}


def _succ(level):
    """succ(h) = 阶梯上紧跟在 h 后面的那些值。h 对应多个 k 时是多元素。"""
    if level not in _SUCC:
        B = BUDGET[level]
        lad = [FULL - round(FULL * k / B) for k in range(B + 1)]
        s = {}
        for k in range(B):
            s.setdefault(lad[k], set()).add(lad[k + 1])
        _SUCC[level] = s
    return _SUCC[level]


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    lv = ctx.get("level_prev")
    ln = ctx.get("level_next")
    if lv is None or ln is None:
        return "NA"
    if lv not in BUDGET:
        return "NA"
    if ln != lv:
        return "NA"
    if action == "RESET":
        return "NA"
    if action.startswith("ACTION6"):
        return "NA"
    if tick_jump(prev, nxt, lv) is True:
        return "NA"                        # 并步记录：单步主张不适用
    s = _succ(lv)
    h = _hud(prev)
    if h not in s:
        return "NA"
    return "TRUE" if _hud(nxt) in s[h] else "FALSE"
