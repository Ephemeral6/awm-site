"""第0 关里色1（地板）、色4、色6、色11（两个杯子）一个像素都不会变；像素行1-63 上会变的格子，新旧颜色只可能落在 色9、色8、背景色12 这三种里。"""
LEVEL = "L6"
SCOPE = "只看第0 关（ctx.level_prev 与 level_next 都是 0）；换关返回 NA。只管像素行1-63，不管 HUD 行0。"
NOTE = ("v2：v1 说「像素行1-63 上只会出现色9 和色12 的互换」，被第216 步 431411666abf5782 推翻——"
        "那一步整条横杆由色9 变色8。v1 是当探测器写的，它按设计垮在了自己要抓的那一步："
        "216 步里第一次冒出第五种变化，而那一步就是通关机制第一次露面的地方。"
        "v2 把色8 收进可变颜色集合，其余不动：四个静物仍然一格不许变，"
        "而且不许再冒出第六种颜色。它照样是探测器——下一次有新东西露面，它会再垮一次，"
        "那正是我要的信号。"
        "由来保留：色1、色4、色6、色11 在 300 多帧里一个像素没动过；"
        "横杆够不着它们，中间隔着进不去的行2 与行12（见 bar_arena_is_9x12）。")
EVIDENCE = ["a756cbef0189f3ec", "078d7601451d3933", "1e9951e4688db504", "4adba876c01b9f5d",
            "431411666abf5782"]

STATIC = (1, 4, 6, 11)
MUTABLE = (9, 8, 12)


def assert_(prev, action, nxt, ctx=None):
    if ctx and (ctx.get("level_prev") != 0 or ctx.get("level_next") != 0):
        return "NA"
    for r in range(1, len(prev)):
        for c in range(len(prev[0])):
            a, b = prev[r][c], nxt[r][c]
            if a == b:
                continue
            if a in STATIC or b in STATIC:
                return "FALSE"
            if a not in MUTABLE or b not in MUTABLE:
                return "FALSE"
    return "TRUE"
