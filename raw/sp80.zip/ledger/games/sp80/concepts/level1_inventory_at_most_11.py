"""第 1 关帧上可见的色8 加色9 从来不超过 11 格——三块（宽5 + 宽3 + 宽3）就这么多，少了是被压住不是没了。"""
LEVEL = "L7"
SCOPE = ("只看第 1 关（level_prev 与 level_next 都是 1）的转移；换关、RESET、第 0 关返回 NA。"
         "同时对 prev 和 next 两帧断言。不断言少的那几格在哪——只断言总数不会多。")
NOTE = ("v1。第 1 关的家当是固定的三块：一条宽5、两条宽3，共 11 逻辑格（inv 量过）。"
        "步950 实测块能互相重叠（见 pieces_overlap_no_blocking），所以可见格数可以少于 11——"
        "最少的一次是这一批之后的 7 格。这条概念立的是相反方向的那一半：**永远不会多**。"
        "它是观测模型：11 是家当的上限，帧上读到的是下限；两边一夹，"
        "「可见 11 格」才等于「没有块被压住、宽度可以照读」。"
        "L7 这一格在 gaps 里一直是空槽，这是第一条。")
EVIDENCE = [
    "60fea33f1a08b496",   # 步950 叠块之后只剩 7 格可见
    "296fd9db8fc1895a",   # 步951 三块叠在 行4，ACTION5 空按，仍是 7 格
]

CELL = 4
TOTAL = 11


def _hud_row(g):
    for r in (0, len(g) - 1):
        if all(v in (14, 0) for v in g[r]):
            return r
    return None


def _visible(g):
    hud = _hud_row(g)
    n = len(g) // CELL
    cnt = 0
    for lr in range(n):
        for lc in range(n):
            vals = [g[lr * CELL + dr][lc * CELL + dc]
                    for dr in range(CELL) for dc in range(CELL)
                    if lr * CELL + dr != hud]
            if not vals:
                continue
            best = max(set(vals), key=vals.count)
            if best in (8, 9):
                cnt += 1
    return cnt


def assert_(prev, action, nxt, ctx=None):
    if action == "RESET":
        return "NA"
    if not ctx or ctx.get("level_prev") != 1 or ctx.get("level_next") != 1:
        return "NA"
    return "TRUE" if _visible(prev) <= TOTAL and _visible(nxt) <= TOTAL else "FALSE"
