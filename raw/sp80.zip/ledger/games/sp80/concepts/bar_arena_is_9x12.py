"""横杆的可达位置恰好是逻辑行3-11 乘左列0-11 这 108 个：任何一帧里色9 的顶行都在像素行12-44、左缘都在像素列0-44。"""
LEVEL = "L2"
SCOPE = "只看第0 关；色9 定位不到返回 NA。断言的是 prev 与 nxt 两帧里横杆所处的位置，不管这一步动没动。"
NOTE = ("v1。由来：四面围墙各自实测过——上界（ACTION1 在左列0/3/5/7 四处不动）、"
        "下界（ACTION2 在左列3/11 两处不动）、左界（ACTION3 在左列0 不动）、"
        "右界（ACTION4 在左列11 不动，第138 步帧差3 格全在 HUD）。"
        "上下两面只在部分列上按过，但不必再补：横杆宽5 格，占左列 L 到 L+4。"
        "上界已在左列0/3/5/7 验过，它们合起来盖住列0-11；任何 L 在 0-11 的横杆都至少有一格落在这段里，"
        "所以上界处处挡得住。下界已验的两处盖住列3-7 与列11-15，把 L=0 到 11 逐个代进去，"
        "每一个的 L 到 L+4 都至少和其中一段相交，所以下界也处处挡得住。"
        "这条概念的份量在于它说清了一件事：横杆够不着色6（行1）也够不着杯子（行13-14），"
        "中间隔着它进不去的行2 和行12。配合 only_the_bar_ever_moves，"
        "第0 关的全部可变状态就只剩这 108 个位置加一个步数计数器。")
EVIDENCE = ["078d7601451d3933", "1e9951e4688db504", "c712b5f6eb956ee5", "d6594d1cd0e9e4dd"]

BAR = 9
TOP, BOTTOM = 12, 44
LEFT, RIGHT = 0, 44


def _box(g):
    pts = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == BAR]
    if not pts:
        return None
    return min(p[0] for p in pts), min(p[1] for p in pts)


def assert_(prev, action, nxt, ctx=None):
    if ctx and (ctx.get("level_prev") != 0 or ctx.get("level_next") != 0):
        return "NA"
    for g in (prev, nxt):
        b = _box(g)
        if b is None:
            return "NA"
        r, c = b
        if not (TOP <= r <= BOTTOM and LEFT <= c <= RIGHT):
            return "FALSE"
    return "TRUE"
