"""ACTION4：色9 整体右移恰好一个格子、没压着别的块时腾出的格子变背景色12；但只要挪过去之后有一格落在界外、落在墙上、落进某个杯格的八邻光环、或落进球那一行的上下一行里，整帧棋盘就不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION4；换关返回 NA；色9块定位不到、或帧上量不出格子（没有球）返回 NA。"
         "断言只管色9占据的格子与它腾出的格子，不管 HUD。")
NOTE = ("v7 兑现（第 1557-1559 步）：押注说竖4杆从列16 还能再右移两格到列18、第三次才被列19 那道墙挡住，"
        "而被推翻的旧读法说这三次一次都不该动（它的右界是列15）。世界给的是 72 格、73 格、1 格——"
        "前两次整体右移恰好一格，第三次整帧棋盘不动只掉 HUD。三条转移 78130c492912935d、"
        "c4aa20a217553139、ee9fdeb6e33c24a7 已进 EVIDENCE。\n"
        "v7（2026-09-18）：界的读法整个换掉，四条移动概念一起改，由来是**这一条自己挨的打**——"
        "第 1556 步反例 949cf952b7b9b9af。第 6 关竖4杆停在行3-6，从列4 一连按了 12 次 ACTION4，"
        "一格不落地走到列16；而 v6 的读法（右侧背靠墙的杯带在列17-18，界＝17 减 2 ＝列15）说第 12 次该不动。"
        "错在把界读成**全局**的：那口杯在行9-11，竖4杆在行3-6，根本够不着它。"
        "新读法见 _lib.shift_blocked——杯只挡自己的八邻光环（局部），球挡整条横带（全局）。"
        "probe83 在全部 991 条去重方向键转移上逐条对过：该动的动了、该挡的挡住了，0 错 0 弃权；"
        "旧读法在同一批上错 1 条，就是这条反例。\n"
        "这一条的代价不在概念上：probe65/probe73 那两次两亿多摆法的穷举都跑在旧读法那个长方形里，"
        "「第 6 关四个口凑不齐」这个结论跟着作废，要在新的摆法空间里重跑。\n"
        "v5（2026-09-18）：界的公式从像素搬进逻辑格，并加上「背靠墙」这道门槛，"
        "四条移动概念的四个方向合成 _lib.move_limit 一条。"
        "由来是 action3 在第 1272 步挨的那条反例（82511392b258b0b0）：第 4 关有一条横躺在左侧、"
        "背后垫着一整列地板的杯，它也是界，而这一族原先把左右界写成「棋盘最左/最右那一格」。"
        "**这一条还没在第 4 关上挨过打**，是先手改的——同一句读法写在四个文件里，"
        "等它自己挨打再改，等于明知会错还押一次（方法册「一族概念共用同一个写死的常量」）。"
        "probe42 在 966 条 ACTION1-4 转移上逐条对过：新读法四向 0 错，"
        "而且在第 0~3 关给出的右界与旧公式逐关相同（仍是棋盘最右一格）——"
        "那几关右边没有背靠墙的球/杯带，move_limit 返回 None，退回棋盘边缘。"
        "同时把「贴界」的判定改用块的**右缘**（原先就是 max(c)，逻辑格里同义），"
        "第 4 关那个跨两行的拐角块也照此取整块的最右一列。\n"
        "v4（2026-09-17）：和 action3 一起改。v3 说「右移 4 列」、「右缘到像素列63 才算到边」，"
        "两句都是第 0~2 关的读数：第 3 关一个格子是 3 像素、棋盘最右一格止于像素列61（列62-63 是墙）。"
        "这一条**还没在第 3 关上挨过打**（进关后一次右移都没按过），改它是因为 action3 的两条反例"
        "（117fe4bdb8dee1a7、dcf2fd5665dead9f）证明这一族四条概念踩的是同一个写死的常量——"
        "等它自己挨打再改，等于明知会错还押一次。格子边长与棋盘右缘都改从帧上量（_lib.geometry）。"
        "主张没让步：右移仍是恰好一个格子、到边仍是整帧不动。\n"
        "v3（2026-09-17）：apply 原先无条件宣告腾出的格子变背景色12。块能互相重叠，"
        "色9 从一块色8 身上滑走时，腾出的格子露出来的是那块色8——这句话在有遮挡时是假的，"
        "而 assert_ 只管色9 的格子集合，照样判 TRUE，只有链式逐格预测能把它照出来。"
        "改法：这句话加一道前提 _lib.nothing_hidden(prev)。断言一个字没改。\n"
        "v2：v1 只说「必右移4列」，右缘到列63 那一侧从没被考过（语料里到了 c44-63 就换动作了）。"
        "v2 把边界明说出来，当时那是一句押出去的话。"
        "v3 兑现：第138 步在右缘上按 ACTION4，实测帧差 3 格——全在 HUD，棋盘一格没动（078d7601451d3933）。"
        "由来值得记：在这之前我朝右按过 46 次、S 一直是 1.000，却一次都没按在右缘上——"
        "动作次数多不等于边界被考过。")
EVIDENCE = ["a756cbef0189f3ec", "a9aa3fd1c18d99f6", "9f6996b027d185d5", "408d9b58e8879fa7",
            "078d7601451d3933", "949cf952b7b9b9af",
            "78130c492912935d", "c4aa20a217553139", "ee9fdeb6e33c24a7"]

from _lib import LAUNCHER, PLAYER, cell_size, nothing_hidden, sel_piece_pixels, shift_blocked

BG = 12


def _pts(g):
    return {(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION4"):
        return "NA"
    a, b = _pts(prev), _pts(nxt)
    if not a or not b:
        return "NA"
    cell = cell_size(prev)
    blk = shift_blocked(prev, "4")
    if cell is None or blk is None:
        return "NA"

    if blk:                                # 挪过去会犯规：不动
        return "TRUE" if b == a else "FALSE"
    return "TRUE" if b == {(r, c + cell) for r, c in a} else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION4"):
        return None
    a, lau = sel_piece_pixels(prev)
    if not a:
        return None
    cell = cell_size(prev)
    blk = shift_blocked(prev, "4")
    if cell is None or blk is None:
        return None
    if blk:
        out = {p: PLAYER for p in a}
        out.update({p: LAUNCHER for p in lau})
        return out
    out = {(r, c + cell): PLAYER for r, c in a}
    out.update({(r, c + cell): LAUNCHER for r, c in lau})
    if nothing_hidden(prev):
        for p in (a | lau) - {(r, c + cell) for r, c in (a | lau)}:
            out[p] = BG
    return out
