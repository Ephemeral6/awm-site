"""方向键让选中件整体挪一格，**当且仅当** _lib.shift_blocked 说没被挡住；说被挡住时棋盘逐格不变。

这条是写给词汇表的：shift_blocked 被四条动作概念共用，可它们都只说「挪一格或者整帧不动」，
两头都对，于是 shift_blocked 自己从来没被判错过。这里把它和帧上另一种读法（棋盘到底变没变、
选中件到底挪没挪）对上，对不上就是反例。

判错的样子：shift_blocked 说没挡住而选中件没挪成（或挪得不是一格），
或者它说挡住了而棋盘变了。
"""
LEVEL = "L2"
SCOPE = (
    "只看不带参数的 ACTION1/2/3/4（ACTION5、ACTION6、RESET 返回 NA）。"
    "换关（ctx 的 level_prev 与 level_next 不同）返回 NA——换关会整盘换掉。"
    "ctx 为 None 或 level 字段缺失返回 NA。"
    "HUD 阶梯证得这条记录跳了不止一档（并步记录，见 _lib.tick_jump）返回 NA——"
    "单步效果类主张对它不可判。"
    "shift_blocked 读不出（geometry 读不出、或帧上没有色9 的选中件）返回 NA。"
    "prev 与 nxt 读不出棋盘、或两帧棋盘尺寸不同，返回 NA。"
    "只比**棋盘**（board 已跳过 HUD 那条像素行），不比整帧——HUD 每一步都在掉格，"
    "拿整帧比会把预算的消耗读成棋盘变了。"
)
NOTE = (
    "v6（2026-09-22）：加并步闸。由来是 66b96f1e8e6d195f（第 227 步）：上游超时重试把两次 ACTION2 "
    "应用并成一条转移——色9 一次挪两格、HUD 一次掉 4 格（阶梯单步最多 3 格），前后步都正常。"
    "是动作标签撒了谎，不是 shift_blocked 错；这条记录对单步效果类主张不可判，"
    "按 _lib.tick_jump（四条概念共用的 HUD 阶梯检测）认出来判 NA。\n"
    "v1（2026-09-20）。由来：第 2909、2910 步连按两次下移，盘面最下方那一件"
    "（三格 L，当时离杯墙还隔着一整行空地）两次都整帧不变。"
    "shift_blocked 的 forbidden_cells 里写着「每个杯格的八邻光环」，正好把那一行算成禁区，"
    "世界和它逐字一致。那一批是这个词第一次被按在明处，但**当时没有任何概念会因为它错而判 FALSE**——"
    "所以补这一条。settle 的词汇表审计点名的就是这种：两条概念都从同一个词取值再互相核对，"
    "S=1 不等于这个词被检验过。"
)
EVIDENCE = [
    "7a3a246812cb77bc",   # 第 2909 步 ACTION2：杯光环挡住，棋盘不变
    "f3ccb405d1f07e66",   # 第 2910 步 ACTION2：同上，只掉了 HUD 一格
    "66b96f1e8e6d195f",   # 第 227 步并步记录（两次应用被并成一条），tick_jump 证得后判 NA
]

from _lib import board, shift_blocked, PLAYER, tick_jump   # noqa: E402

SIDE = {"ACTION1": ("1", (-1, 0)), "ACTION2": ("2", (1, 0)),
        "ACTION3": ("3", (0, -1)), "ACTION4": ("4", (0, 1))}


def _sel(b):
    return {(r, c) for r, row in enumerate(b)
            for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    lp = ctx.get("level_prev")
    ln = ctx.get("level_next")
    if lp is None or ln is None:
        return "NA"
    if lp != ln:
        return "NA"
    if tick_jump(prev, nxt, lp) is True:
        return "NA"                        # 并步记录：单步主张不适用
    hit = SIDE.get(str(action))
    if hit is None:
        return "NA"
    side, d = hit
    blocked = shift_blocked(prev, side)
    if blocked is None:
        return "NA"
    a, b = board(prev), board(nxt)
    if not a or not b or len(a) != len(b) or len(a[0]) != len(b[0]):
        return "NA"
    sa, sb = _sel(a), _sel(b)
    if not sa:
        return "NA"
    if blocked:
        return "TRUE" if a == b else "FALSE"
    return "TRUE" if sb == {(r + d[0], c + d[1]) for r, c in sa} else "FALSE"
