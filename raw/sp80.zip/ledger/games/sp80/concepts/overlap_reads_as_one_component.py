"""两件重叠时，判赢读法把它们当成同一个连通块——重叠能造出真的内拐角。

换言之：色4/8/9/15 这些块格的四连通分量，是**渲染之后**的分量，不是「件」。
两件挨在一起或叠在一起，渲染出来连成一片，读法就只看得见一块。
所以复合形状的凹角，在判赢读法的 same_piece 判据眼里，和单件自带的凹角没有区别。

这条要紧的地方在于它是一条**关于量具的断言**，不是关于世界的：
判赢读法 _win_grid 喂侧口走的是 same_piece 分支（水偏折落脚后，只有下一格的块与刚绕过的那格
属于同一连通块时才准水平滑去够侧口）。若件与连通块一一对应，一个 L 件只给得出一个内角；
而它们不对应，重叠拼出来的轮廓就能给出更多内角。

判错的样子：某一帧上两件的格子四邻相接（或重叠），而 _components 给它们不同的编号。

由来：步3603 的盘上，选中的肘块压在横杆右端、又与竖杆和另一肘块连成一片，
_components 认出 1 个块共 13 格，颜色 {4,8,9,15} 四色混在同一块里；
阳性对照取第 5 关开局（步2673 的 next），同一函数认出 4 个块，各自单色。
"""
LEVEL = "L2"
SCOPE = (
    "只对 prev 这一侧的帧说话，与动作无关——它断言的是读法本身的口径，不是世界的转移。"
    "帧里读不出逻辑盘返回 NA；盘上块格（色4/8/9/15）少于 2 格返回 NA（没有两件可谈）。"
    "块格四邻相接算相接；色4 只有四邻挨着真块格时才算块格，与 _components 的口径一致。"
    "不谈这些格子分别属于哪一件——世界的件表我们看不见，本条只谈渲染后的连通分量。"
)
NOTE = (
    "v1（2026-09-21）：写它是因为第 5 关的规划器把所有重叠摆位当废候选扔了"
    "（plan_lv5.py 第 86 行：两件重叠就抛异常），于是「全空间 845,130,792 个摆法判赢 0」"
    "量的其实是一个**不含重叠**的子空间。而在册判赢读法认的杯口是顶口列 1 个、侧口格 3 个，"
    "喂侧口要三个内拐角，两个 L 件不重叠时只给得出两个——那个 0 的来历很可能就在这里。"
    "重叠合法是步3601/3602/3603 三步实弹押出来的：推得动、被盖的格显示成盖上去那件的颜色、"
    "底下那件其余格一格不动。"
)
EVIDENCE = [
    "55eedbcfbac6cc56",   # 步3603 复合块：_components 认出 1 块 13 格，四色混在一起
    "582a970a380a7c0e",   # 步3602 把选中件推上横杆右端，重叠成形
    "cf1f6d6cfdc1f30a",   # 步3601 重叠的第一步
    "fd497acd9897d02c",   # 步2673 阳性对照：无重叠时同一函数认出 4 个单色块
]

from _lib import board

PIECE = {4, 8, 9, 15}
REAL = {8, 9, 15}          # 真块格；色4 只有挨着真块格时才算


def _block_cells(b):
    core = {(r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v in REAL}
    out = set(core)
    for r, row in enumerate(b):
        for c, v in enumerate(row):
            if v == 4 and any((r + dr, c + dc) in core
                              for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
                out.add((r, c))
    return out


def _comp_id(cells):
    cid, i = {}, 0
    for seed in sorted(cells):
        if seed in cid:
            continue
        stack = [seed]
        cid[seed] = i
        while stack:
            r, c = stack.pop()
            for nb in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if nb in cells and nb not in cid:
                    cid[nb] = i
                    stack.append(nb)
        i += 1
    return cid


def assert_(prev, action, nxt, ctx=None):
    b = board(prev)
    if not b or not b[0]:
        return "NA"
    cells = _block_cells(b)
    if len(cells) < 2:
        return "NA"
    cid = _comp_id(cells)
    for (r, c) in cells:
        for nb in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
            if nb in cells and cid[nb] != cid[(r, c)]:
                return "FALSE"
    return "TRUE"
