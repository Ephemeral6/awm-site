"""ACTION5 与 ACTION6:x,y 都不搬动棋盘上的东西：像素行1-63 上「这一格是不是背景色12」逐格与上一帧相同——它们至多给已有物件换个颜色，从不改变任何物件的位置或形状。"""
LEVEL = "L1"
SCOPE = "只看 ACTION5 与 ACTION6；换关返回 NA。只断言像素行1-63（棋盘），不管像素行0（HUD）。"
NOTE = ("v7（2026-09-20，apply 那道「过关就闭嘴」的闸原先是死的）：v5/v6 用 "
        "`from <另一条概念> import _win` 借判据，而装置的加载器把概念执行成 `concept_<名字>` 模块，"
        "既不按文件名注册进 sys.modules，也不把 concepts/ 放上 sys.path。"
        "这句 import 只在别的东西碰巧把 concepts/ 垫上 sys.path 时才成功（`bet --policy` 会，"
        "`bet --predict` 直接给动作串不会）——同一条概念在不同入口给出不同的 apply，两边都不报错。"
        "v7 改成裸 import 失败就按文件路径把邻居执行一遍并缓存。主张、assert_、EVIDENCE 未动。\n"
        "v6（2026-09-20，同一处 apply 借来的 WIN 再换一次）：v5 借的 "
        "levelup_iff_deflection_tree_feeds_every_mouth 在第 2652 步吃了硬反例已 retire；"
        "改借同族活下来的 levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup._win，语义仍是同一句：判 True 就闭嘴。"
        "借的那个名字带 try/except 兜着，读不出来就当「不会过关」，所以换人不改本条的发言范围。\n"
        "v5（2026-09-20，只换 apply 借来的那条 WIN，不动主张）：原先问的是 "
        "levelup_iff_every_branch_tries_slide_first，那条在第 2638 步吃了硬反例已 retire；"
        "改问同族里活下来的 levelup_iff_deflection_tree_feeds_every_mouth._win，"
        "语义还是同一句：判 True 就闭嘴。\n"
        "v4（2026-09-19，只动 apply 不动主张）：SCOPE 第一句「换关返回 NA」原先只有 assert_ 兑现了，"
        "apply 照样对每一发 ACTION5 发言，把「这一发过关、整帧重画」预测成「背景格一格不动」。"
        "终局卡第一批就要撞上它（策略摆好之后那一发按册子会过关）。"
        "改法是把那句散文变成一个可调用的谓词：apply 先问 "
        "levelup_iff_deflection_tree_feeds_every_mouth._win(prev)，判 True 就闭嘴。"
        "主张、assert_、EVIDENCE 一个字没动，改的只是「它在哪些情形下肯生成」。\n"
        "v3：v2 说「像素行1-63 逐格与上一帧相同」，被第216 步 431411666abf5782 推翻——"
        "那一步 ACTION5 把整条横杆 80 个像素从色9 变成色8，位置一格没动。"
        "色8 是这一局第一次出现的第五种变化，216 步里只此一次。"
        "v3 退到仍站得住的那一层：动作不搬东西，只可能换颜色。这一层照样可判错——"
        "哪天 ACTION5 或 ACTION6 让某个物件挪了位、或者凭空多出/抹掉一格，它当场垮。"
        "颜色那一层我另写了 color8_only_at_budget_end 去押，不混进这一条。"
        "v2 的由来保留：第67-71 步在色6中心、色4中心、色11两杯、纯背景各点一次，五处全无反应；"
        "点击坐标只试过 x=列/y=行 这一种读法。")
EVIDENCE = ["16582ddf80d1e2cf", "4d83b854eace150e", "ef1f16653b984d18", "5c60e716415781eb",
            "2dacad82bf3d3428", "381c19e30cff8781", "aad09c12f74f685f", "2338c5d606dcef13",
            "45829d38e878a9fb", "431411666abf5782"]

BG = 12


_BORROWED = []


def _levelup(prev):
    """册子对「这一发会不会过关」的说法。读不出来（返回 None / 抛异常）就当作「不会」，
    保持本条原有的发言范围不变——这一句只用来把明知会换关的那一发从 apply 里摘出去。

    **不敢只写 `from … import`**：装置的加载器把概念执行成 `concept_<名字>` 模块，
    既不按文件名注册进 sys.modules，也不把 concepts/ 放上 sys.path，
    概念之间互相 import 因此时灵时不灵（见 NOTE v6）。裸 import 失败就按文件路径执行邻居。"""
    if not _BORROWED:
        _BORROWED.append(_load_win())
    win = _BORROWED[0]
    if win is None:
        return None
    try:
        return win(prev)
    except Exception:       # noqa: BLE001
        return None


def _load_win():
    name = "levelup_iff_branch_tree_feeds_every_mouth_v2_sidecup"
    try:
        mod = __import__(name)
        return mod._win
    except Exception:       # noqa: BLE001
        pass
    try:
        import importlib.util
        from pathlib import Path
        p = Path(__file__).with_name(name + ".py")
        spec = importlib.util.spec_from_file_location("_borrowed_" + name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod._win
    except Exception:       # noqa: BLE001
        return None


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not (action.startswith("ACTION5") or action.startswith("ACTION6")):
        return "NA"
    for r in range(1, len(prev)):
        for c in range(len(prev[0])):
            if (prev[r][c] == BG) != (nxt[r][c] == BG):
                return "FALSE"
    return "TRUE"


def apply(prev, action, ctx=None):
    """只敢生成背景格：非背景格的颜色这一条说不准（见第216 步）。

    但先问一句册子「这一发会不会把关卡推过去」——会的话整帧重画，
    而本条的 SCOPE 第一句就把换关排除在外了。散文写在 SCOPE 里 assert_ 读得到、apply 读不到，
    于是 apply 会在它自己声明不管的情形上照常发言，把「过关」预测成「一格没动」。
    """
    if not (action.startswith("ACTION5") or action.startswith("ACTION6")):
        return None
    if action.startswith("ACTION5") and _levelup(prev) is True:
        return None
    return {(r, c): BG for r, row in enumerate(prev) if r >= 1
            for c, v in enumerate(row) if v == BG}
