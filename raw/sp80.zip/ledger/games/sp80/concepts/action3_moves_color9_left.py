"""ACTION3：色9 整体左移恰好一个格子、没压着别的块时腾出的格子变背景色12；但只要挪过去之后有一格落在界外、落在墙上、落进某个杯格的八邻光环、或落进球那一行的上下一行里，整帧棋盘就不动。"""
LEVEL = "L1"
SCOPE = ("只看 ACTION3；换关返回 NA；色9块定位不到、或帧上量不出格子（没有球）返回 NA。"
         "断言只管色9占据的格子与它腾出的格子，不管 HUD。")
NOTE = ("v7（2026-09-18）：界的读法整个换掉，四条移动概念一起改。由来是 action4 在第 1556 步挨的"
        "那条反例 949cf952b7b9b9af：第 6 关竖4杆在行3-6 从列4 一连右移 12 格走到列16，"
        "而 v6 那条读法（背靠墙的带、内缘外隔一格）给出的右界是列15。"
        "v6 的对错各占一半：它说对了「背后有墙的杯也是界」（第 1272 步那条反例仍然成立，"
        "新读法在那一格上照旧判该挡——杯格的八邻光环把列3 盖住了），"
        "错的是把这个界读成**整块棋盘一条线**。新读法见 _lib.shift_blocked："
        "杯只挡自己的八邻光环（局部），球挡整条横带（全局），墙与界外照旧。"
        "probe83 在全部 991 条去重方向键转移上逐条对过：0 错 0 弃权；v6 在同一批上错 1 条。\n"
        "v6（2026-09-18）：第 4 关把 v5 打成反例（82511392b258b0b0，第1272 步）——"
        "拐角块左缘停在逻辑列4 上按 ACTION3，帧差只剩 HUD 一格，而 v5 说「还没贴着最左列，该走」。"
        "第 4 关有一个横躺在左侧、口朝右的杯（逻辑行11-13、列1-2），它背后垫着一整列地板（列0）。"
        "改法不是把左界改成列4——那又是拿一关的读数冒充世界常量——而是把上下界那条读法镜像过来，"
        "四个方向合成 _lib.move_limit 一条：**背靠墙的那条带，内缘外隔一个空格**。"
        "「贴着边」不够：第 2 关的杯也占着列1-3，可它们背后（列0）什么都没有，块照样走到列0——"
        "分开这两种情形的是带背后有没有地板色1 或发射器色4。"
        "先在语料上对过再入册（方法册「新读法换旧读法先在全语料上逐帧对一遍」）："
        "probe37 先试了「最靠左那条列带」，第 0~3 关错了一百多条（横穿球/杯所在的列本来就是常事），当场出局；"
        "probe42 的「背靠墙的带」在 966 条 ACTION1-4 转移上四向 0 错，"
        "并且在第 0~3 关给出的界与旧公式逐关相同（左界仍是逻辑列0、右界仍是最右一格）。\n"
        "v5（2026-09-17）：第 3 关把 v4 打成两条反例（117fe4bdb8dee1a7 第1181 步、dcf2fd5665dead9f 第1183 步）。"
        "v4 说「左移 4 列」、「左缘在像素列0 才算到边」，两句都是第 0~2 关的读数冒充世界常量："
        "第 3 关一个格子是 3 像素，棋盘从像素列2 起（列0-1 是墙），所以杆左移 3 像素、到像素列2 就到头。"
        "改法不是把 4 换成 3——那只会在下一关再挨一次——而是把这两个数都从帧上量。"
        "主张本身一个字没让步：左移仍是**恰好一个格子**，到界仍是**整帧棋盘不动**，两种情形各自可判错。\n"
        "v4（2026-09-17）：apply 的「腾出的格子变背景色12」加了前提 _lib.nothing_hidden(prev)——"
        "块能互相重叠，色9 从一块色8 身上滑走时腾出的格子露的是色8 不是背景色。assert_ 没改。\n"
        "v3：v2 只说「必左移4列」，在第75步 d6594d1c 上被推翻——横杆左缘到列0 后再按 A3 不动。"
        "v2 的写法还有个毛病：把边界写成「位置没变也算通过」等于自动兜底，几乎判不了错。"
        "v3 改成把边界条件明说出来（左缘是否到头），两种情形各自可判错。")
EVIDENCE = ["2d6ceafa975d9292", "d6594d1c1ef648a6", "16c32eccb9fe6598", "2f221e223156b4c7",
            "117fe4bdb8dee1a7", "dcf2fd5665dead9f",
            "82511392b258b0b0"]   # 第1272 步 第4 关：左边那个背靠地板的杯也是界，v5 在这里判错

from _lib import LAUNCHER, PLAYER, cell_size, nothing_hidden, sel_piece_pixels, shift_blocked

BG = 12


def _pts(g):
    return {(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER}


def assert_(prev, action, nxt, ctx=None):
    if ctx and ctx["level_prev"] != ctx["level_next"]:
        return "NA"
    if not action.startswith("ACTION3"):
        return "NA"
    a, b = _pts(prev), _pts(nxt)
    if not a or not b:
        return "NA"
    cell = cell_size(prev)
    blk = shift_blocked(prev, "3")
    if cell is None or blk is None:
        return "NA"

    if blk:                                # 挪过去会犯规：不动
        return "TRUE" if b == a else "FALSE"
    return "TRUE" if b == {(r, c - cell) for r, c in a} else "FALSE"


def apply(prev, action, ctx=None):
    if not action.startswith("ACTION3"):
        return None
    a, lau = sel_piece_pixels(prev)
    if not a:
        return None
    cell = cell_size(prev)
    blk = shift_blocked(prev, "3")
    if cell is None or blk is None:
        return None
    if blk:
        out = {p: PLAYER for p in a}
        out.update({p: LAUNCHER for p in lau})
        return out
    out = {(r, c - cell): PLAYER for r, c in a}
    out.update({(r, c - cell): LAUNCHER for r, c in lau})
    if nothing_hidden(prev):
        for p in (a | lau) - {(r, c - cell) for r, c in (a | lau)}:
            out[p] = BG
    return out
