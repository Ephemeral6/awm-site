"""state 变 GAME_OVER 的那一步，要么次帧 HUD 的色14 格数归零，要么这一步的动作是 ACTION5——方向键 ACTION1-4 除了把预算打到 0 以外杀不死人。"""
LEVEL = "L5"
SCOPE = ("只看同关、上一帧 state 是 NOT_FINISHED 的非 RESET 转移；换关或上一帧已经 GAME_OVER 返回 NA。"
         "方向键那一支断的是双向：致死当且仅当次帧 HUD 归零。"
         "ACTION5/ACTION6 那一支只断一个方向：HUD 归零必致死；ACTION5 在 HUD 没归零时也能致死，这条概念不管它为什么。")
NOTE = ("v1。由来：语料里 8 次 GAME_OVER。六次是预算耗尽（第96/126/156/186/216/246 步，次帧 HUD=0，"
        "动作分别是 ACTION2/ACTION2/ACTION4/ACTION2/ACTION5/ACTION5）。另外两次不是："
        "第66 步 ACTION5，次帧 HUD 还有32 格；第268 步 ACTION5，次帧 HUD 还有17 格。"
        "这两次的共同点是——按下它时，这条命（自上一次 RESET 起）的 ACTION5 已经是第5 次。"
        "第52-66 步那条命按了5 次 A5 死在第5 次；第23-51 步那条命按了4 次 A5 活着；"
        "第247-268 步这条命按到第5 次当场死。所以真正的规律是「一条命只给4 次 ACTION5，第5 次立刻死」，"
        "但那个次数计数器在帧上一个像素都看不见——第5 次按下时帧差只有 HUD 的2 格。"
        "这是本局第一个确认的隐藏状态：assert_ 只拿得到 (prev, action, next)，数不出「这是第几次」，"
        "所以这条概念只写落得到帧上的那半句。剩下那半句的可判错形式我还没找到，不假装它已经走过闸。"
        "顺带推翻过两个读法：「连续5 步棋盘不变就死」——第67-71 步同样连续5 步棋盘没动（全是点击）却活着；"
        "「连续5 次 ACTION5 才死」——第268 步这条命的5 次 A5 中间隔着 ACTION3，照样死。"
        "v2：第1 关把同一个数又量了一遍——第354 步 RESET 之后 ACTION5 落在第360、363、364、369、371 步，"
        "第5 次（4c4869959c80008f）当场 GAME_OVER，次帧 HUD 还剩 40 格，而且第360 步那次是**成功交棒**、照样计数。"
        "两关同一个 4，说明这个计数器不是第0 关的局部设定。v2 只做一件事：把 level_prev==0 那道栅栏拆掉，"
        "让这条概念也在第1 关及以后受检——方向键那一支「致死当且仅当 HUD 归零」在第1 关还一次都没被考过，"
        "那正是它最可能垮掉的地方。")
EVIDENCE = ["4adba876c01b9f5d", "394a7aeaa0957a72", "deabd8e0afb4e173",
            "88a8d10f95386044", "431411666abf5782", "4c4869959c80008f"]

HUD = 14
DEAD = "GAME_OVER"
ALIVE = "NOT_FINISHED"


def _hud(g):
    return sum(row.count(HUD) for row in g)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None:
        return "NA"
    if ctx.get("level_prev") != ctx.get("level_next"):
        return "NA"
    if action == "RESET":
        return "NA"
    if ctx.get("state_prev") != ALIVE:
        return "NA"

    died = ctx.get("state_next") == DEAD
    broke = _hud(nxt) == 0

    if action[:7] in ("ACTION1", "ACTION2", "ACTION3", "ACTION4"):
        return "TRUE" if died == broke else "FALSE"
    if broke and not died:
        return "FALSE"
    if died and not broke and not action.startswith("ACTION5"):
        return "FALSE"
    return "TRUE"
