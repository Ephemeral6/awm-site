"""第 1 关的 ACTION5 若换了选中的块，接手那块的宽度必与交出那块不同（宽5 换宽3、宽3 换宽5）。"""
LEVEL = "L1"
SCOPE = ("只看第 1 关内部的 ACTION5（换关或 GAME_OVER 返回 NA）；"
         "前后帧的色9 必须各自是一条完整的横杆（单行、列连续），否则返回 NA；"
         "色9 横杆前后完全一样（空按）返回 NA。只断言宽度，不断言接手的是哪一块、"
         "也不断言什么时候会发生交棒——触发条件至今没找出来。")
NOTE = ("v1。交棒的**触发条件**用 28 个特征做过机械分离器搜索，零个零反例分离器；"
        "但**接手方**这一条从第 348 步到第 932 步 19 次交棒无一例外。"
        "其中 5 次（步414/429/459/521/579）发生在有遮挡的帧上——可见块格数不足 11，"
        "相邻同色块并成一段会让宽度读歪——那 5 次也对得上，所以这里不缩 scope，"
        "但真挨打时先怀疑遮挡帧。"
        "另：交棒是纯换色，占用格集合前后不变，没有任何块移动过（见 action5_never_moves_pieces）。"
        "本条是撤册的 action5_hands_off_at_limit_row（v4 被 46365f248f0716e9 打死）的替代品："
        "那条猜的是「交出方或接手方之一贴在极限行上」，步932 两块都不在极限行；"
        "宽度读法在同一条转移上仍然成立。")
EVIDENCE = [
    "8946dde2e977987d",   # 步348 行4 c5-c9 宽5 → 行6 c7-c9 宽3（宽5 交宽3 的第一例）
    "c9119ab89cba4915",   # 步447 行4 c11-c13 宽3 → 行9 c5-c9 宽5（反方向的第一例）
    "46365f248f0716e9",   # 步932 行9 c8-c10 宽3 → 行12 c5-c9 宽5（打死了上一条概念）
]
# 语料里另有 14 次交棒（步360/378/394/407/424/452/469/483/534/571/911 与
# 四次遮挡帧 414/429/459/521/579）故意**不**写进 EVIDENCE：
# 全塞进来 N 就是 0，这条概念一格 held-out 都没有，S 变 UNMEASURABLE（v1 已经踩过一次）。
# 留在外面才算分。

from _lib import CELL, PLAYER


def _bar(g):
    """色9 横杆的 (像素行起, 像素列起, 宽度格数)；不是一条完整横杆就返回 None。"""
    pts = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v == PLAYER]
    if not pts:
        return None
    r0, r1 = min(p[0] for p in pts), max(p[0] for p in pts)
    c0, c1 = min(p[1] for p in pts), max(p[1] for p in pts)
    if r1 - r0 + 1 != CELL:                       # 不止一行高 → 不是单块横杆
        return None
    if len(pts) != (r1 - r0 + 1) * (c1 - c0 + 1):  # 有洞 → 列不连续
        return None
    w = c1 - c0 + 1
    if w % CELL:
        return None
    return (r0, c0, w // CELL)


def assert_(prev, action, nxt, ctx=None):
    if not action.startswith("ACTION5"):
        return "NA"
    if ctx:
        if ctx.get("level_prev") != 1 or ctx.get("level_next") != 1:
            return "NA"
        if "GAME_OVER" in (ctx.get("state_prev"), ctx.get("state_next")):
            return "NA"
    a, b = _bar(prev), _bar(nxt)
    if a is None or b is None:
        return "NA"
    if a == b:
        return "NA"                                # 空按：选中的还是同一块同一处
    return "TRUE" if a[2] != b[2] else "FALSE"
