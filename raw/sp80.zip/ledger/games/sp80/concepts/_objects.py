"""sp80 的对象层（R9 口径）：帧 -> 类型化对象；每关常数；隐藏量；回画。

读法总纲
--------
棋盘是像素帧上一张 n×m 的格盘（每关的格边长与相位不同，HUD 占掉一整行像素）。
盘上有两类东西：**不动的地形**（墙/杯/球/球边上的发射器）和**会动的件**。
件是刚体，形状取自本关的一小张形状表；件身涂两种颜色（细件一色、粗件另一色），
被选中的那一件整块换成第三种颜色；件里可能嵌着一格发射器色。

`parse` 把一帧化成：HUD 余额（整数）+ 件的摆放表（kind/行/列/是否选中）。
摆放表由**精确覆盖**解出来：把帧上所有件色格分解成本关形状表的一组摆放，
再用 `_render_check` 逐格回画核对。分解不唯一（件可以互相重叠）时返回 None ——
那一帧的件的身份帧上读不出来，不是「没有件」。

隐藏量两个，都不进 keyEq：
  k     —— 进本关以来走了几步。HUD 余额是它的函数（余额 = 64 - ⌈64k/B⌉ 的整数写法）。
  shots —— 进本关以来按了几次 ACTION5。语料里第 5 次必定「换关或死」。
两者都由 seed 从 (前态, 后态) 反解。

consts 里带 cell/phR/phC（格边长与相位）：点击动作的坐标是**像素**的，规则段要把它折回格盘，
而规则段只许读 Consts —— 不放进来就只能在规则里硬编几何，那是偷带世界数据。
"""
from __future__ import annotations

# ------------------------------------------------------------------ 颜色 ----
BALL, CUP, FLOOR, LAU, EMPTY, HUDC = 6, 11, 1, 4, 12, 14
SEL, THIN, FAT = 9, 8, 15

# ------------------------------------------------------------------ 形状 ----
# (格偏移, 嵌在件里的发射器格偏移)
H3 = (((0, 0), (0, 1), (0, 2)), ())
H4 = (((0, 0), (0, 1), (0, 2), (0, 3)), ())
H5 = (((0, 0), (0, 1), (0, 2), (0, 3), (0, 4)), ())
H6 = (((0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5)), ())
H7L = (((0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6)), ((0, 3),))
H5L = (((0, 0), (0, 1), (0, 2), (0, 3), (0, 4)), ((0, 2),))
V4 = (((0, 0), (1, 0), (2, 0), (3, 0)), ())
E9 = (((0, 0), (1, 0), (1, 1)), ())
EA = (((0, 0), (0, 1), (1, 1)), ())
EB = (((0, 1), (1, 0), (1, 1)), ())


def ucol_of(shape):
    """件没被选中时的颜色：包围盒有一边只有一格的是细件，否则是粗件。"""
    off = shape[0]
    rs = [r for r, _ in off]
    cs = [c for _, c in off]
    return THIN if min(max(rs) - min(rs) + 1, max(cs) - min(cs) + 1) <= 1 else FAT


LEVELS = [
    dict(cell=4, phase=(0, 0), n=16, m=16, hud=0, budget=30,
         shapes=[H5], init=[(0, 4, 3, True)]),
    dict(cell=4, phase=(0, 0), n=16, m=16, hud=63, budget=45,
         shapes=[H3, H5], init=[(0, 4, 2, False), (0, 6, 7, False), (1, 9, 5, True)]),
    dict(cell=4, phase=(0, 0), n=16, m=16, hud=63, budget=100,
         shapes=[H4, H5, H6], init=[(0, 5, 2, False), (1, 7, 10, False), (2, 8, 2, False), (2, 10, 9, True)]),
    dict(cell=3, phase=(2, 2), n=20, m=20, hud=0, budget=120,
         shapes=[H5, H7L, H4], init=[(0, 5, 5, True), (0, 5, 12, False), (1, 9, 2, False),
                                     (2, 10, 14, False), (2, 13, 12, False)]),
    dict(cell=3, phase=(2, 2), n=20, m=20, hud=63, budget=100,
         shapes=[H4, H3, H5, EA], init=[(0, 6, 9, False), (1, 10, 6, False), (2, 10, 13, True), (3, 13, 10, False)]),
    dict(cell=3, phase=(2, 2), n=20, m=20, hud=0, budget=120,
         shapes=[V4, E9, H5L, EB], init=[(0, 4, 14, False), (1, 5, 9, True), (2, 10, 7, False), (3, 14, 9, False)]),
]
# 关的指纹：(盘宽, 球格坐标) —— 地形不动，球的位置就够认关
FINGERPRINT = {
    (16, ((1, 9),)): 0,
    (16, ((14, 10),)): 1,
    (16, ((14, 1), (14, 9), (14, 14))): 2,
    (20, ((1, 7),)): 3,
    (20, ((18, 6), (18, 14))): 4,
    (20, ((1, 9),)): 5,
}
MAX_SHOTS = 5          # 一次关卡尝试里第 5 发 ACTION5 必定换关或死（语料 20/20）

HIDDEN = {"k": 0, "shots": 0}
NAMES = {"pieces": "Piece", "consts.init": "Piece", "consts.shapes": "Shape"}
TYPES = {
    "consts.mouths": "List Pos", "consts.balls": "List Pos",
    "consts.shapes.cells": "List Pos", "consts.shapes.lau": "List Pos",
}


# ------------------------------------------------------------------ 读帧 ----
def _hud_row(g):
    for r in (0, len(g) - 1):
        if all(v in (HUDC, 0) for v in g[r]):
            return r
    return None


def _board(g, cell, phase, n, m, hud):
    from collections import Counter
    r0, c0 = phase
    out = []
    for lr in range(n):
        line = []
        for lc in range(m):
            vals = [g[r0 + lr * cell + dr][c0 + lc * cell + dc]
                    for dr in range(cell) for dc in range(cell)
                    if r0 + lr * cell + dr != hud]
            line.append(Counter(vals).most_common(1)[0][0] if vals else EMPTY)
        out.append(line)
    return out


def identify(g):
    """(关号, 格盘)；认不出返回 None。"""
    hud = _hud_row(g)
    if hud is None:
        return None
    for lv, C in enumerate(LEVELS):
        if C["hud"] != hud:
            continue
        b = _board(g, C["cell"], C["phase"], C["n"], C["m"], hud)
        balls = tuple(sorted((r, c) for r, row in enumerate(b) for c, v in enumerate(row) if v == BALL))
        if FINGERPRINT.get((C["n"], balls)) == lv:
            return lv, b
    return None


def _terrain(b):
    n, m = len(b), len(b[0])
    balls = {(r, c) for r in range(n) for c in range(m) if b[r][c] == BALL}
    walls = {(r, c) for r in range(n) for c in range(m) if b[r][c] == FLOOR}
    cups = {(r, c) for r in range(n) for c in range(m) if b[r][c] == CUP}
    lau = {(r, c) for r in range(n) for c in range(m) if b[r][c] == LAU
           and any((r + dr, c + dc) in balls for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)))}
    return walls, cups, balls, lau


def cells_at(shape, r, c):
    return frozenset((r + dr, c + dc) for dr, dc in shape[0])


def lau_at(shape, r, c):
    return frozenset((r + dr, c + dc) for dr, dc in shape[1])


def _render_check(b, lv, placed):
    """把一组摆放画回格盘，逐格核对可见颜色。"""
    C = LEVELS[lv]
    shapes, n, m = C["shapes"], C["n"], C["m"]
    sel = [p for p in placed if p[3]]
    if len(sel) != 1:
        return False
    ki, sr, sc, _ = sel[0]
    selbody = cells_at(shapes[ki], sr, sc) - lau_at(shapes[ki], sr, sc)
    sellau = lau_at(shapes[ki], sr, sc)
    cover = {}
    for ki2, r, c, s in placed:
        if s:
            continue
        sh = shapes[ki2]
        for p in cells_at(sh, r, c) - lau_at(sh, r, c):
            cover.setdefault(p, set()).add(ucol_of(sh))
        for p in lau_at(sh, r, c):
            cover.setdefault(p, set()).add(LAU)
    for r in range(n):
        for c in range(m):
            p, v = (r, c), b[r][c]
            if p in selbody:
                if v != SEL:
                    return False
            elif p in sellau:
                if v != LAU:
                    return False
            elif p in cover:
                if v not in cover[p]:
                    return False
            elif v in (THIN, SEL, FAT):
                return False
    return True


def decompose(b, lv, limit=2):
    """格盘上的件色格分解成本关形状表的一组摆放；返回解列表（最多 limit 个）。"""
    C = LEVELS[lv]
    n, m, shapes = C["n"], C["m"], C["shapes"]
    kinds = [k for k, _, _, _ in C["init"]]
    _, _, _, slau = _terrain(b)
    c9 = frozenset((r, c) for r in range(n) for c in range(m) if b[r][c] == SEL)
    c4 = frozenset((r, c) for r in range(n) for c in range(m) if b[r][c] == LAU) - slau
    vis = frozenset((r, c) for r in range(n) for c in range(m) if b[r][c] in (THIN, FAT))
    if not c9:
        return []
    sels = []
    for ki in set(kinds):
        sh = shapes[ki]
        for r in range(-4, n):
            for c in range(-4, m):
                if cells_at(sh, r, c) - lau_at(sh, r, c) == c9 and lau_at(sh, r, c) <= c4:
                    sels.append((ki, r, c))
    sols = []
    for ski, sr, sc in sels:
        rest = list(kinds)
        rest.remove(ski)
        selall = cells_at(shapes[ski], sr, sc)
        need = (vis | c4) - selall
        cands = {}
        for ki in set(rest):
            sh = shapes[ki]
            lst = []
            for r in range(-4, n):
                for c in range(-4, m):
                    cs = cells_at(sh, r, c)
                    if any(not (0 <= p[0] < n and 0 <= p[1] < m) for p in cs):
                        continue
                    lcs = lau_at(sh, r, c)
                    ok = all(p in selall or b[p[0]][p[1]] in (THIN, FAT) for p in cs - lcs) and \
                        all(p in selall or p in c4 for p in lcs)
                    if ok:
                        lst.append((r, c))
            cands[ki] = lst

        def rec(remaining, placed, covered):
            if len(sols) >= limit:
                return
            un = need - covered
            if not remaining:
                if not un:
                    cand = tuple(sorted(placed + [(ski, sr, sc, True)]))
                    if _render_check(b, lv, cand) and cand not in sols:
                        sols.append(cand)
                return
            if un:
                tgt = min(un)
                opts = [(ki, r, c) for ki in set(remaining) for (r, c) in cands[ki]
                        if tgt in cells_at(shapes[ki], r, c)]
            else:
                opts = [(ki, r, c) for ki in set(remaining) for (r, c) in cands[ki]]
            seen = set()
            for ki, r, c in opts:
                if (ki, r, c) in seen:
                    continue
                seen.add((ki, r, c))
                r2 = list(remaining)
                r2.remove(ki)
                rec(r2, placed + [(ki, r, c, False)], covered | cells_at(shapes[ki], r, c))
        rec(rest, [], frozenset())
    return sols


_PC = {}


def parse(g):
    """帧 -> 对象。pieces 分解不唯一 / 认不出关 时给 None（读不到，不比）。"""
    h = hash(tuple(tuple(r) for r in g))
    if h in _PC:
        return dict(_PC[h])
    hud = _hud_row(g)
    bud = sum(row.count(HUDC) for row in g) if hud is not None else None
    idr = identify(g)
    pieces = None
    if idr is not None:
        lv, b = idr
        sols = decompose(b, lv)
        if len(sols) == 1:
            pieces = [dict(kind=k, r=r, c=c, sel=s) for k, r, c, s in sols[0]]
    out = {"budget": bud, "pieces": pieces}
    _PC[h] = out
    return dict(out)


# -------------------------------------------------------------- 每关常数 ----
_STATIC = {}       # 关 -> (静态格盘, 一张干净像素帧)


def _static_of(lv, frames):
    """把任意一帧上的件擦掉，留下这一关不动的地形。"""
    if lv in _STATIC:
        return _STATIC[lv]
    C = LEVELS[lv]
    for g in frames:
        idr = identify(g)
        if idr is None or idr[0] != lv:
            continue
        b = idr[1]
        sols = decompose(b, lv)
        if len(sols) != 1:
            continue
        occ = set()
        for ki, r, c, s in sols[0]:
            occ |= cells_at(C["shapes"][ki], r, c)
        st = [[EMPTY if (r, c) in occ else b[r][c] for c in range(C["m"])] for r in range(C["n"])]
        _STATIC[lv] = (st, g)
        return _STATIC[lv]
    return None


def consts(frames_by_level):
    out = {}
    for lv in sorted(x for x in frames_by_level if isinstance(x, int) and 0 <= x < len(LEVELS)):
        C = LEVELS[lv]
        n, m = C["n"], C["m"]
        got = _static_of(lv, frames_by_level[lv])
        if got is None:
            continue
        st = got[0]
        walls = {(r, c) for r in range(n) for c in range(m) if st[r][c] == FLOOR}
        cups = {(r, c) for r in range(n) for c in range(m) if st[r][c] == CUP}
        balls = sorted((r, c) for r in range(n) for c in range(m) if st[r][c] == BALL)
        lau = [(r, c) for r in range(n) for c in range(m) if st[r][c] == LAU]
        # 件身不许碰的格：墙、杯的八邻、球所在的三行
        bad = set(walls)
        for (r, c) in cups:
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    bad.add((r + dr, c + dc))
        for (r, c) in balls:
            for dr in (-1, 0, 1):
                for cc in range(m):
                    bad.add((r + dr, cc))
        # 水走不过的静态格
        solid = [[st[r][c] != EMPTY for c in range(m)] for r in range(n)]
        mouths = sorted((r, c) for r in range(n) for c in range(m)
                        if st[r][c] == EMPTY and sum(
                            1 for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))
                            if 0 <= r + dr < n and 0 <= c + dc < m and st[r + dr][c + dc] == CUP) >= 3)
        # 行进方向：球背离同列最近的那一格发射器（发射器在球上方 -> 球往下走）
        br, bc = balls[0]
        same = [r for (r, c) in lau if c == bc]
        near = min(same, key=lambda r: abs(r - br)) if same else None
        grav = -1 if (near is not None and br < near) else 1
        out[lv] = {
            "n": n, "m": m, "cell": C["cell"], "phR": C["phase"][0], "phC": C["phase"][1],
            "grav": grav, "quota": C["budget"], "maxShots": MAX_SHOTS,
            "blocked": [[(r, c) in bad for c in range(m)] for r in range(n)],
            "solid": solid,
            "mouths": mouths,
            "balls": balls,
            "shapes": [{"cells": sorted(sh[0]), "lau": sorted(sh[1]), "ucol": ucol_of(sh)}
                       for sh in C["shapes"]],
            "init": [{"kind": k, "r": r, "c": c, "sel": s} for k, r, c, s in sorted(C["init"])],
        }
    return out


# ------------------------------------------------------------------ 回画 ----
def render(state, level, cs):
    """对象 -> 像素帧（只报不拦：量对象层丢了多少帧上的信息）。"""
    got = _STATIC.get(level)
    if got is None or state.get("pieces") is None:
        return []
    st, sample = got
    C = LEVELS[level]
    cell, (pr, pc), n, m, hud = C["cell"], C["phase"], C["n"], C["m"], C["hud"]
    grid = [[st[r][c] for c in range(m)] for r in range(n)]
    ps = list(state["pieces"])
    for p in [q for q in ps if not q["sel"]] + [q for q in ps if q["sel"]]:
        sh = C["shapes"][p["kind"]]
        body = cells_at(sh, p["r"], p["c"]) - lau_at(sh, p["r"], p["c"])
        for (r, c) in body:
            if 0 <= r < n and 0 <= c < m:
                grid[r][c] = SEL if p["sel"] else ucol_of(sh)
        for (r, c) in lau_at(sh, p["r"], p["c"]):
            if 0 <= r < n and 0 <= c < m:
                grid[r][c] = LAU
    out = [list(row) for row in sample]
    for r in range(n):
        for c in range(m):
            for dr in range(cell):
                rr = pr + r * cell + dr
                if rr == hud or not (0 <= rr < len(out)):
                    continue
                for dc in range(cell):
                    ccx = pc + c * cell + dc
                    if 0 <= ccx < len(out[rr]):
                        out[rr][ccx] = grid[r][c]
    bud = state.get("budget")
    if bud is not None and 0 <= hud < len(out):
        w = len(out[hud])
        out[hud] = [HUDC if i < bud else 0 for i in range(w)]
    return out
