"""第0 关按 ACTION5 推进关卡，当且仅当横杆左列是 6 且所在行不小于 4；别的列、或左列是6 但行小于4，关卡都不动。"""
LEVEL = "L5"
SCOPE = "只看 level_prev 是 0 的非 RESET 转移；其余返回 NA。横杆读作色9 与色8 的并集的左上格位。"
NOTE = ("v3（2026-09-17）：行的下界从 9 降到 4，由第977 步 b2c501360c22b7c4 逼出来——"
        "(行4,左列6) 按下去世界判过关，而 v2 替行4 到行8 押的「负」正好在这里落空。"
        "v2 给行下界编的理由（横杆离杯沿越近球走的路越短）是错的：三次过关分别在行 11、行 9、行 4。"
        "真正的下界是球和横杆之间要隔得开——球在行 1，行4 时中间隔 2 个空行，行3 只隔 1 个，"
        "这和 ball_lands_in_cup_one_past_long_side v3 的「自由行不小于 2」是同一件事，"
        "两条概念从两种不同的读法（这条读色8∪色9 的左上格、那条读色9 连续块）给出同一个下界。"
        "这是第三版；再挨一次打就按方法册「第三版还挨打」撤册。\n"
        "v2 原文：v1 说「只有 (行11,左列6) 赢」，被第627 步 0f0424d565dbfcf3 打脸——"
        "同样的左列6、行9，也赢。所以赢法不是一个点，是「左列6」这一列条件加上一个行的下界。"
        "行的下界卡在 9：第268 步 394a7aeaa0957a72 是 (行3,左列6)，判负；行4 到行8 的左列6 从没试过，"
        "这条概念替它们押「负」，谁先去试谁就能把它再推翻一次。\n"
        "v1 原文：由来：第341 步 30ce5262c037c052——横杆在 (行11,左列6) 按 ACTION5，关卡 0 变 1，"
        "帧差 1168 格（整张图上下翻转）。同一批里紧挨着的两次交卷是对照："
        "(行11,左列4) af1b613bff14cc9d 与 (行11,左列5) cd6d956d123bb9d3，帧差都只有 HUD 的2 格。"
        "全局 24 次 ACTION5 落在约 20 个位置上，只有这一个位置有反应。"
        "为什么是 (11,6)：杯A 占列4-6、杯B 占列10-12，横杆正好5 格宽占列6 到10——"
        "左端压在杯A 的右腿上、右端压在杯B 的左腿上，正好架满两个杯子之间的空当；"
        "行11 是横杆能到的、离杯子最近的一行。"
        "这条概念只敢断言第0 关。背后的规律至少有三种读法，第1 关会把它们分开："
        "（甲）横杆左端在左杯右腿、右端在右杯左腿；（乙）横杆中心落在所有杯子的对称中心（第0 关是列8）；"
        "（丙）就是「离杯子最近的那一行 + 某个固定列」。第1 关有三个杯子占列3-5、7-9、11-13，"
        "甲在那儿放不下（相邻两腿只隔2 格，横杆5 格太宽），乙给出左列6，丙未知——"
        "所以下一关第一次交卷该押乙。"
        "代价记一笔：找到它花了341 步。此前我用「108 个可达位置全到过、关卡没动」把整个位置维度划掉了，"
        "而真相是「到过」不等于「在那儿按过 ACTION5」——ACTION5 当时只在8 个位置按过。")
EVIDENCE = ["30ce5262c037c052", "af1b613bff14cc9d", "cd6d956d123bb9d3",
            "4446609d6695cd79", "ad17d2f26aeadec7",
            "0f0424d565dbfcf3", "394a7aeaa0957a72",
            "ba6d27ab8ad336b2", "1ce42c41b0d1010d",
            "b2c501360c22b7c4"]

BAR = (9, 8)
CELL = 4
WIN_COL = 6
WIN_ROW_MIN = 4


def _bar(g):
    pts = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v in BAR]
    if not pts:
        return None
    return (min(p[0] for p in pts) // CELL, min(p[1] for p in pts) // CELL)


def assert_(prev, action, nxt, ctx=None):
    if ctx is None or ctx.get("level_prev") != 0:
        return "NA"
    if action == "RESET":
        return "NA"
    b = _bar(prev)
    if b is None:
        return "NA"
    advanced = ctx.get("level_next") != ctx.get("level_prev")
    fires = action.startswith("ACTION5") and b[1] == WIN_COL and b[0] >= WIN_ROW_MIN
    return "TRUE" if advanced == fires else "FALSE"
