/-
# Reachable —— 这个**局面**做不做得了

    Winnable   b w  :=  ∃ as, 每一下都合法 ∧ 照着走中途过关
    Unsolvable b w  :=  ∀ as, 每一下都合法 → 照着走从没过关

**合法的一下**：除 RESET 以外的动作。RESET 不进模型（「开局长什么样」是历史）。

**一条要写在明处的削弱**：`everWon` 在模型说不出话的那一支（RESET、一发没过关的水之后）返回 false。
所以任何 `Unsolvable` 的真实意思都是「**不经过说不出话的那一支，就赢不了**」。
本局六关在这批语料上**全部走得通**（`Proof/Levels.lean`），没有一关用到 `Unsolvable`；
骨架照模板原样留着——它是「赢不了」唯一被允许的证法（不变量 + 归纳，不枚举、不搜索）。
-/
import Obs.Check
import Obj.World

namespace Game

def Act.legal : Act → Bool
  | .reset => false
  | _ => true

def Winnable (b : Board) (w : World) : Prop :=
  ∃ as : List Act, (∀ a ∈ as, a.legal = true) ∧ everWon b w as = true

def Unsolvable (b : Board) (w : World) : Prop :=
  ∀ as : List Act, (∀ a ∈ as, a.legal = true) → everWon b w as = false

end Game

-- 定理放在根命名空间：装置的 `ledger/lean_check.py` 按**短名**逐条 `#print axioms`。
open Game

/-- 两句话不能同时成立。 -/
theorem not_both (b : Board) (w : World) : Winnable b w → Unsolvable b w → False := by
  intro ⟨as, hl, hw⟩ hu
  have := hu as hl
  rw [this] at hw
  exact Bool.false_ne_true hw

/-- 骨架：一个每走一步都保持、而且和「过关」矛盾的性质 P ⇒ 从满足 P 的局面出发怎么走都赢不了。
    **全文唯一做归纳的地方**，与盘面大小、动作串长短都无关。 -/
theorem unsolvable_of_invariant (b : Board) (P : World → Prop)
    (hkeep : ∀ w w' a, a.legal = true → P w → step b w a = Res.ok w' → P w')
    (hwin : ∀ w a, P w → step b w a ≠ Res.won) :
    ∀ (w : World), P w → Unsolvable b w := by
  intro w hp as
  induction as generalizing w with
  | nil => intro _; rfl
  | cons a t ih =>
    intro hall
    simp only [everWon]
    cases hstep : step b w a with
    | won => exact absurd hstep (hwin w a hp)
    | silent => rfl
    | ok w' =>
      exact ih w' (hkeep w w' a (hall a (by simp)) hp hstep)
              (fun c hc => hall c (by simp [hc]))

#print axioms not_both
#print axioms unsolvable_of_invariant
