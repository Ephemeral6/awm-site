/-
# Levels —— **每一关一条定理**（`lean2/export_levels.py` 生成，不要手改；讲解在生成器文件头）

见证段：成绩单认证的那一段（guid 84782af3-5382-4aba-a9d9-839a3840aae3，seq 233–371）。

    L<n>_trace      沿真实走法，模型每一帧都和观测对上（只有开局那一帧是观测给的）
    L<n>_winnable   这一关走得通——见证就是那条真实走法
    L<n>_len        每一段的长度钉死（空表会让 `traceOk` 平凡为真）

每关核过的步数：L0 3+1，L1 7+1，L2 10+1，L3 38+1，L4 37+1，L5 37+1（逐帧核对的步数 + 过关那一发）。
-/
import Obs.Replay
import Proof.Reachable
import Obj.World

-- 定义住在 `Game.Levels` 里；**定理放在根命名空间**：装置的 `ledger/lean_check.py` 按短名逐条 `#print axioms`。
namespace Game.Levels
end Game.Levels
open Game Game.Replay Game.Levels

set_option maxRecDepth 100000

/-! ## 第 0 关：3 步逐帧核对 + 过关那一发（seq 234–237） -/

namespace Game.Levels

/-- 第 0 关的真实开局：**从认证段这一关第一帧读出来的**（seq 234 那一步动作之前的那一帧）。 -/
def L0_start : World := worldOf (bySeq 234)

/-- 开局到过关前一步，3 步：每一步配上它下一帧看得见的样子。 -/
def L0_play : List (Act × Seen) := playFrom 234 3

/-- 真人走过的整串动作，4 下，最后一下是过关那一发。 -/
def L0_acts : List Act := actsFrom 234 4

end Game.Levels

/-- 钉住这一段：逐帧核对 3 步、动作 4 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L0_len : L0_play.length = 3 ∧ L0_acts.length = 4 ∧
    L0_acts.take 3 = L0_play.map Prod.fst ∧ (L0_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 3 帧全是模型自己算的。 -/
theorem L0_trace : traceOk (boardOf 0) (L0_start : World) L0_play = true := by decide +kernel

/-- **第 0 关走得通。** 见证就是上面那条真实走法。 -/
theorem L0_winnable : Winnable (boardOf 0) (L0_start : World) :=
  ⟨L0_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 0) L0_start L0_play 0 with
  | none => "L0 一处没分家（" ++ toString L0_play.length ++ " 步）"
  | some i => "L0 第 " ++ toString i ++ " 步分家"

#print axioms L0_len
#print axioms L0_trace
#print axioms L0_winnable

/-! ## 第 1 关：7 步逐帧核对 + 过关那一发（seq 238–245） -/

namespace Game.Levels

/-- 第 1 关的真实开局：**从认证段这一关第一帧读出来的**（seq 238 那一步动作之前的那一帧）。 -/
def L1_start : World := worldOf (bySeq 238)

/-- 开局到过关前一步，7 步：每一步配上它下一帧看得见的样子。 -/
def L1_play : List (Act × Seen) := playFrom 238 7

/-- 真人走过的整串动作，8 下，最后一下是过关那一发。 -/
def L1_acts : List Act := actsFrom 238 8

end Game.Levels

/-- 钉住这一段：逐帧核对 7 步、动作 8 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L1_len : L1_play.length = 7 ∧ L1_acts.length = 8 ∧
    L1_acts.take 7 = L1_play.map Prod.fst ∧ (L1_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 7 帧全是模型自己算的。 -/
theorem L1_trace : traceOk (boardOf 1) (L1_start : World) L1_play = true := by decide +kernel

/-- **第 1 关走得通。** 见证就是上面那条真实走法。 -/
theorem L1_winnable : Winnable (boardOf 1) (L1_start : World) :=
  ⟨L1_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 1) L1_start L1_play 0 with
  | none => "L1 一处没分家（" ++ toString L1_play.length ++ " 步）"
  | some i => "L1 第 " ++ toString i ++ " 步分家"

#print axioms L1_len
#print axioms L1_trace
#print axioms L1_winnable

/-! ## 第 2 关：10 步逐帧核对 + 过关那一发（seq 246–256） -/

namespace Game.Levels

/-- 第 2 关的真实开局：**从认证段这一关第一帧读出来的**（seq 246 那一步动作之前的那一帧）。 -/
def L2_start : World := worldOf (bySeq 246)

/-- 开局到过关前一步，10 步：每一步配上它下一帧看得见的样子。 -/
def L2_play : List (Act × Seen) := playFrom 246 10

/-- 真人走过的整串动作，11 下，最后一下是过关那一发。 -/
def L2_acts : List Act := actsFrom 246 11

end Game.Levels

/-- 钉住这一段：逐帧核对 10 步、动作 11 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L2_len : L2_play.length = 10 ∧ L2_acts.length = 11 ∧
    L2_acts.take 10 = L2_play.map Prod.fst ∧ (L2_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 10 帧全是模型自己算的。 -/
theorem L2_trace : traceOk (boardOf 2) (L2_start : World) L2_play = true := by decide +kernel

/-- **第 2 关走得通。** 见证就是上面那条真实走法。 -/
theorem L2_winnable : Winnable (boardOf 2) (L2_start : World) :=
  ⟨L2_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 2) L2_start L2_play 0 with
  | none => "L2 一处没分家（" ++ toString L2_play.length ++ " 步）"
  | some i => "L2 第 " ++ toString i ++ " 步分家"

#print axioms L2_len
#print axioms L2_trace
#print axioms L2_winnable

/-! ## 第 3 关：38 步逐帧核对 + 过关那一发（seq 257–295） -/

namespace Game.Levels

/-- 第 3 关的真实开局：**从认证段这一关第一帧读出来的**（seq 257 那一步动作之前的那一帧）。 -/
def L3_start : World := worldOf (bySeq 257)

/-- 开局到过关前一步，38 步：每一步配上它下一帧看得见的样子。 -/
def L3_play : List (Act × Seen) := playFrom 257 38

/-- 真人走过的整串动作，39 下，最后一下是过关那一发。 -/
def L3_acts : List Act := actsFrom 257 39

end Game.Levels

/-- 钉住这一段：逐帧核对 38 步、动作 39 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L3_len : L3_play.length = 38 ∧ L3_acts.length = 39 ∧
    L3_acts.take 38 = L3_play.map Prod.fst ∧ (L3_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 38 帧全是模型自己算的。 -/
theorem L3_trace : traceOk (boardOf 3) (L3_start : World) L3_play = true := by decide +kernel

/-- **第 3 关走得通。** 见证就是上面那条真实走法。 -/
theorem L3_winnable : Winnable (boardOf 3) (L3_start : World) :=
  ⟨L3_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 3) L3_start L3_play 0 with
  | none => "L3 一处没分家（" ++ toString L3_play.length ++ " 步）"
  | some i => "L3 第 " ++ toString i ++ " 步分家"

#print axioms L3_len
#print axioms L3_trace
#print axioms L3_winnable

/-! ## 第 4 关：37 步逐帧核对 + 过关那一发（seq 296–333） -/

namespace Game.Levels

/-- 第 4 关的真实开局：**从认证段这一关第一帧读出来的**（seq 296 那一步动作之前的那一帧）。 -/
def L4_start : World := worldOf (bySeq 296)

/-- 开局到过关前一步，37 步：每一步配上它下一帧看得见的样子。 -/
def L4_play : List (Act × Seen) := playFrom 296 37

/-- 真人走过的整串动作，38 下，最后一下是过关那一发。 -/
def L4_acts : List Act := actsFrom 296 38

end Game.Levels

/-- 钉住这一段：逐帧核对 37 步、动作 38 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L4_len : L4_play.length = 37 ∧ L4_acts.length = 38 ∧
    L4_acts.take 37 = L4_play.map Prod.fst ∧ (L4_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 37 帧全是模型自己算的。 -/
theorem L4_trace : traceOk (boardOf 4) (L4_start : World) L4_play = true := by decide +kernel

/-- **第 4 关走得通。** 见证就是上面那条真实走法。 -/
theorem L4_winnable : Winnable (boardOf 4) (L4_start : World) :=
  ⟨L4_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 4) L4_start L4_play 0 with
  | none => "L4 一处没分家（" ++ toString L4_play.length ++ " 步）"
  | some i => "L4 第 " ++ toString i ++ " 步分家"

#print axioms L4_len
#print axioms L4_trace
#print axioms L4_winnable

/-! ## 第 5 关：37 步逐帧核对 + 过关那一发（seq 334–371） -/

namespace Game.Levels

/-- 第 5 关的真实开局：**从认证段这一关第一帧读出来的**（seq 334 那一步动作之前的那一帧）。 -/
def L5_start : World := worldOf (bySeq 334)

/-- 开局到过关前一步，37 步：每一步配上它下一帧看得见的样子。 -/
def L5_play : List (Act × Seen) := playFrom 334 37

/-- 真人走过的整串动作，38 下，最后一下是过关那一发。 -/
def L5_acts : List Act := actsFrom 334 38

end Game.Levels

/-- 钉住这一段：逐帧核对 37 步、动作 38 下、两者走的是同一条路、开局是本关第 0 步（预算满格）。
    切歪了会得到空表，而**空表会让「一步不差」平凡为真**——这一条就是防那个的。 -/
theorem L5_len : L5_play.length = 37 ∧ L5_acts.length = 38 ∧
    L5_acts.take 37 = L5_play.map Prod.fst ∧ (L5_start : World).k = 0 := by decide +kernel

/-- **模型沿这条路一步不差**：只有开局那一帧是观测给的，后面 37 帧全是模型自己算的。 -/
theorem L5_trace : traceOk (boardOf 5) (L5_start : World) L5_play = true := by decide +kernel

/-- **第 5 关走得通。** 见证就是上面那条真实走法。 -/
theorem L5_winnable : Winnable (boardOf 5) (L5_start : World) :=
  ⟨L5_acts, by decide +kernel, by decide +kernel⟩

#eval match firstSplit (boardOf 5) L5_start L5_play 0 with
  | none => "L5 一处没分家（" ++ toString L5_play.length ++ " 步）"
  | some i => "L5 第 " ++ toString i ++ " 步分家"

#print axioms L5_len
#print axioms L5_trace
#print axioms L5_winnable

/-! ## 明写的假设：RESET 把局面放回开局——给它一次被驳倒的机会

认证段开头那一步（seq 233）是 RESET。之后的第 0 关，这里**不从认证段读到的开局起算**，
而从语料里第一次见到的第 0 关开局（seq 1 那一帧，另一段）起算，逐帧和认证段的观测比。
假设要是错的，第一帧就对不上。**没红不构成证明**——那只是这条假设在这批语料上唯一一次被驳倒的机会。 -/

theorem L0_after_reset_trace :
    traceOk (boardOf 0) (worldOf (bySeq 1) : World) (playFrom 234 3) = true := by decide +kernel

#print axioms L0_after_reset_trace

