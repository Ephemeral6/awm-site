/-
# Corpus —— **逐条**：模型面对每一条真实转移（从 `Obs/Replay.lean` 切，不另存语料）

每一步都从**这一帧读到的**局面起算一步，和看到的下一帧比。三值，不是两值：

    yes   模型说的就是这样
    no    模型说的不是这样
    na    模型这一步说不出话

判法：

    模型算出一个局面   → 下一帧有看得见的样子：对上 yes；对不上时，这一帧**有件被压住**（occluded）判 na，否则 no
    模型说「过关」     → 这一步真过关了 yes，否则 no
    模型说不出话       → na；**例外**：真过关了、而水流模型明说「不过关」（some false），那是 no

「有件被压住判 na」是**纤维**的口径：一帧读不全被压住的那一截，它对应的是一组局面；
从帧重新起算时拿到的只是其中一个（可见的那一份），对不上不等于模型错了——
带着状态从开局走的 `Proof/Levels.lean` 替这几步说话。
-/
import Obs.Replay
import Proof.Reachable

namespace Game
namespace Corpus
open Replay

/-- 0 = yes，1 = no，2 = na -/
def verdict (s : Step) : Nat :=
  let b := boardOf s.lvl
  let w := worldOf s
  let won := s.kind == 1 || s.kind == 2
  match step b w s.act with
  | .ok w' =>
    match s.next with
    | some o => if seenEq (seenOf b w') o then 0 else if s.occluded then 2 else 1
    | none => if won then 1 else 2
  | .won => if won then 0 else 1
  | .silent => if won && s.act == .fire && fireOutcome b w == some false then 1 else 2

def count (v : Nat) : Nat := (steps.filter (fun s => verdict s == v)).length

/-- 为什么说不出话（只给读数用）。 -/
def naWhy (s : Step) : String :=
  match step (boardOf s.lvl) (worldOf s) s.act with
  | .ok _ => if s.occluded then "occluded" else "no-next-frame"
  | .won => "?"
  | .silent => if s.act == .reset then "reset" else "fire-miss"

#eval s!"CORPUS steps={steps.length} yes={count 0} no={count 1} na={count 2}"
-- 逐步的判决，给 `verify.py` 和 Python 那一侧的读数逐条对账用。
#eval "VERDICTS " ++ String.intercalate "," ((steps.map (fun s => s!"{s.seq}:{verdict s}")))
-- 水流模型在每一发 ACTION5 上的结论：Lean 这一份与 Python 那一份（`derive/flow.py`）各自独立写，
-- `verify.py` 逐发对账（T 过关 / F 不过关 / N 说不出话）。
#eval "FIRES " ++ String.intercalate ","
  ((steps.filter (fun s => s.act == .fire)).map (fun s =>
    s!"{s.seq}:" ++ (match fireOutcome (boardOf s.lvl) (worldOf s) with
      | some true => "T" | some false => "F" | none => "N")))
#eval "NA " ++ String.intercalate "," (((steps.filter (fun s => verdict s == 2)).map (fun s => s!"{s.seq}:{naWhy s}")))

end Corpus
end Game

-- 定理放在根命名空间：装置的 `ledger/lean_check.py` 按**短名**逐条 `#print axioms`。
open Game Game.Replay Game.Corpus

set_option maxRecDepth 100000

/-- **模型没被这批语料驳倒**：371 条真实转移里判 no 的一条都没有。走内核，不是 `#eval`。 -/
theorem corpus_no_false : (steps.filter (fun s => verdict s == 1)).length = 0 := by
  decide +kernel

/-- 对上的条数（读数钉成定理：改了模型，这个数一变就编不过）。 -/
theorem corpus_yes : (steps.filter (fun s => verdict s == 0)).length = 353 := by
  decide +kernel

#print axioms corpus_no_false
#print axioms corpus_yes
