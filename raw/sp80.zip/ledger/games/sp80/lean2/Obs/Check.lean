/-
# Check —— **判据层**：两把尺子，0 条定理（尺子不自证）

    agrees   一条转移对不对：从**观测到的那一帧**起算一步，和看到的下一帧比
    traceOk  一整条路对不对：只有开局那一帧是观测给的，**后面全是模型自己算的**

一个「每步单独看都对、走两步就和现实分家」的模型，在 `agrees` 那里是满分，在 `traceOk` 这里过不了。
这一局尤其如此：件会互相压住，被压住的那一截帧上读不出——从帧重新起算的 `agrees`
不知道底下压着什么；带着状态从开局走的 `traceOk` 知道。

## 看得见的是什么（`Seen`）

件那一层每一格的颜色（`layer`，按格比、不按顺序比）+ 预算条亮几像素。
版面不在里面：它在 `Board` 里、不会变（导出器核过每一帧读到的版面都等于本关那一张）。
-/
import Step
import Obj.Composite.Ladder

namespace Game

structure Seen where
  layer : List (Pos × Nat)
  hud : Nat
deriving DecidableEq, Repr

def seenOf (b : Board) (w : World) : Seen := ⟨layer w, hudOf b.budget w.k⟩

/-- 看得见的两份相等：预算相同，件层的格集合相同、每格颜色相同（**按集合比**——帧上读不出顺序）。 -/
def seenEq (a o : Seen) : Bool :=
  a.hud == o.hud && a.layer.length == o.layer.length &&
  o.layer.all (fun pc => a.layer.contains pc)

/-- 带着模型自己算出来的状态往下走，每一步都和那一帧看到的比。 -/
def traceOk (b : Board) : World → List (Act × Seen) → Bool
  | _, [] => true
  | w, (a, o) :: rest =>
      match step b w a with
      | .ok w' => seenEq (seenOf b w') o && traceOk b w' rest
      | _ => false

/-- **只给读数用**：第一处分家在第几步（none = 一处没分家）。它是读数不是定理。 -/
def firstSplit (b : Board) : World → List (Act × Seen) → Nat → Option Nat
  | _, [], _ => none
  | w, (a, o) :: rest, i =>
      match step b w a with
      | .ok w' => if seenEq (seenOf b w') o then firstSplit b w' rest (i + 1) else some i
      | _ => some i

/-- 沿一串动作走，中途有没有哪一步过关。说不出话那一支按「没过」算——
    所以一切「赢不了」都只是「不经过说不出话的那一支就赢不了」。 -/
def everWon (b : Board) : World → List Act → Bool
  | _, [] => false
  | w, a :: rest =>
      match step b w a with
      | .won => true
      | .ok w' => everWon b w' rest
      | .silent => false

end Game
