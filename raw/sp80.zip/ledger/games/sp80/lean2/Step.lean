/-
# Step —— 一步怎么走：**只做分发，0 条定理**

每一个动作交给它那条规则的定义；预算那一档（`tick`）每个动作都走。

    方向键  → Rule/Move/ArrowShifts（挪不动那一支在 Rule/Move/ArrowBlocked）
    点击    → Rule/Move/ClickSelects（放下的件的颜色在 Rule/Respond/RestColor）
    ACTION5 → Rule/Win/FireWins：过关给 `won`；没过关**说不出话**（选中谁说不出来）
    RESET   → **说不出话**：「开局长什么样」是历史，不是当前状态的函数

`Res` 的三支：

    ok w     模型算出了下一个局面
    won      过关了——下一帧是另一关的盘，模型不描述它
    silent   模型说不出话

**`silent` 那一支会削弱「赢不了」**：`everWon` 在那一支返回 false，于是任何
「∀ as, everWon … = false」的意思都是「**不经过 RESET、也不经过一发没过关的水**，就赢不了」。
本局六关全部是「走得通」，没有一条「走不通」的定理用到这一支；这半句仍写在这里、
`Proof/Reachable.lean` 和页面三处。
-/
import Rule.Move.ArrowShifts
import Rule.Move.ClickSelects
import Rule.Respond.HudTicks
import Rule.Win.FireWins

namespace Game

inductive Act where
  | up | down | left | right
  | fire
  | click (x y : Nat)
  | reset
deriving DecidableEq, Repr

inductive Res where
  | ok (w : World)
  | won
  | silent
deriving DecidableEq, Repr

def step (b : Board) (w : World) : Act → Res
  | .up => .ok (tick (arrowStep b w .up))
  | .down => .ok (tick (arrowStep b w .down))
  | .left => .ok (tick (arrowStep b w .left))
  | .right => .ok (tick (arrowStep b w .right))
  | .click x y => .ok (tick (clickStep b w x y))
  | .fire => match fireStep b w with
    | .won => .won
    | .silent => .silent
  | .reset => .silent

end Game
