/-
# ClickMissStill —— **推论**：点击没点中任何件，局面不变（对应 `rule/一步怎么走/click_elsewhere_is_still.py`）

Python 那边它是一条独立的规则（有论域、有读数：本批语料 1 条）；
重排成定义之后，它**不是一条独立的规则**——它就是 `clickStep` 那个 `match` 的 `none` 那一支。
所以它住在这里，是一条定理，不是一个 `def`。
-/
import Rule.Move.ClickSelects
import Obj.World

-- 定理放在根命名空间：装置的 `ledger/lean_check.py` 按**短名**逐条 `#print axioms`。
open Game

theorem click_miss_still (b : Board) (w : World) (x y : Nat)
    (h : hit w (b.grid.cellOfPixel x y) = none) : clickStep b w x y = w := by
  unfold clickStep
  rw [h]

#print axioms click_miss_still
