/-
# VacatedShowsEmpty —— **推论**：没有任何件压着、也不是版面的格，画出来就是空地 12
（对应 `rule/世界怎么回应/vacated_cells_show_background.py`）

Python 那边它是一条独立的规则：选中件挪走后腾出来的格露出空地（前提是底下没压着件）。
在模型里它不是一条规则——它是 `colorAt` 的定义推出来的：腾出来的格不在挪过之后的选中件里，
底下又没有别的件，那它就谁都不占，画出来只能是 12。

「底下有没有压着件」在这里是前提 `hfree`；Python 那条规则用「可见件表和本关开局一样大」代替它
（帧上读不出底下压着什么）——两边说的是同一句话，差别只在前提从哪里来。
-/
import Obj.Composite.Render

-- 定理放在根命名空间：装置的 `ledger/lean_check.py` 按**短名**逐条 `#print axioms`。
open Game

theorem vacated_shows_empty (b : Board) (w : World) (p : Pos)
    (hstatic : staticColor b p = none)
    (hfree : ∀ pc ∈ w.pieces, pc.cells.contains p = false ∧ pc.marks.contains p = false) :
    colorAt b w p = 12 := by
  have aux : ∀ ps : List Piece,
      (∀ pc ∈ ps, pc.cells.contains p = false ∧ pc.marks.contains p = false) → topColor p ps = none := by
    intro ps
    induction ps with
    | nil => intro _; rfl
    | cons pc rest ih =>
      intro h
      have h1 := h pc (by simp)
      have hc : p ∉ pc.cells := by simpa using h1.1
      have hm : p ∉ pc.marks := by simpa using h1.2
      have ih' := ih (fun x hx => h x (List.mem_cons_of_mem _ hx))
      cases rest with
      | nil => simp [topColor, paint, hc, hm]
      | cons q rest' =>
        simp only [topColor] at ih' ⊢
        rw [ih']
        simp [paint, hc, hm]
  unfold colorAt
  rw [hstatic, aux w.pieces hfree]

#print axioms vacated_shows_empty
