/-
# ClickSelects —— 点中一件：它成为选中件、画到最上面；原选中件放下（对应 `rule/一步怎么走/click_selects_hit_piece.py`）

**定义**：`hit` 给出下标 `i` 时，把第 `i` 件挪到最后（选中、最上面），原来的最后一件放下
（`putDown`，按形状定颜色）、排在它下面；没点中时局面原样。
-/
import Obj.Board.Board
import Obj.Composite.Hit
import Rule.Respond.RestColor

namespace Game

def clickStep (b : Board) (w : World) (x y : Nat) : World :=
  match hit w (b.grid.cellOfPixel x y) with
  | none => w
  | some i =>
    match w.pieces[i]?, w.pieces.getLast? with
    | some tgt, some old =>
      let rest := (w.pieces.dropLast.zipIdx.filter (fun (_, j) => j != i)).map (·.1)
      { w with pieces := rest ++ [putDown old, tgt] }
    | _, _ => w

end Game
