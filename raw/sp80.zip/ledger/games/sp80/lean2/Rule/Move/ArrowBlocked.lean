/-
# ArrowBlocked —— 方向键挪不动时，整张盘不变（对应 `rule/一步怎么走/arrow_blocked_is_still.py`）

**这是定义，不是定理**：「挪不动」由 `blocked`（禁区）定义；挪不动的那一支，局面原样返回。
本批语料里这一支**一次都没走到**（Python 那边 |scope| = 0：没人撞过禁区）——这一点写在明处。
-/
import Obj.Composite.Forbidden
import Obj.World

namespace Game

/-- 选中件朝 `f` 挪一格挪不动时给 some（原样的局面）；挪得动给 none。 -/
def stillIfBlocked (b : Board) (w : World) (f : Pos → Pos) : Option World :=
  match w.pieces.getLast? with
  | none => some w
  | some sel => if blocked b sel f then some w else none

end Game
