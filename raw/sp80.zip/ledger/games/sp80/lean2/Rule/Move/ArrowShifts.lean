/-
# ArrowShifts —— 方向键挪得动时，选中件整体挪一格（对应 `rule/一步怎么走/arrow_shifts_selected.py`）

**定义**：选中件（最后一件）连同记号整体挪一格，仍是最后一件（仍画在最上面）；别的件一格不动。
别的件不挡路——`blocked` 只看禁区，这一句是这个定义的一部分，不是另一条规则。
-/
import Rule.Move.ArrowBlocked
import Obj.World
import Obj.Pieces.Piece

namespace Game

inductive Dir where
  | up | down | left | right
deriving DecidableEq, Repr

def Dir.f : Dir → Pos → Pos
  | .up => (· - 64)
  | .down => (· + 64)
  | .left => (· - 1)
  | .right => (· + 1)

def arrowStep (b : Board) (w : World) (d : Dir) : World :=
  match stillIfBlocked b w d.f with
  | some w' => w'
  | none => { w with pieces := w.pieces.dropLast ++ (w.pieces.getLast?.map (·.shift d.f)).toList }

end Game
