/-
# FireWins —— 一发水过关 ⟺ 水流模型说每个杯口都喂到、没有落空（对应 `rule/什么算赢什么算砸/fire_wins_iff_all_mouths_fed.py`）

**这是「赢」的定义**，不是一条待证的定理。

没过关的那一发：**模型说不出话**。理由写在明处——没过关的一发之后，选中件有时换给别的件
（交棒），有时不换；什么时候换没读出来（`rule/说了但不进模型/handoff_goes_to_nearest.py`）。
编一个「不换」出来比说「不知道」更糟。
-/
import Obj.Composite.Flow

namespace Game

/-- 一发水的三种结果。 -/
inductive Fire where
  | won
  | silent
deriving DecidableEq, Repr

def fireStep (b : Board) (w : World) : Fire :=
  match fireOutcome b w with
  | some true => .won
  | _ => .silent

end Game
