/-
# HudTicks —— 每一个动作（点击也算）本关步数加一（对应 `rule/世界怎么回应/hud_ticks_every_action.py`）

**定义**：`k ↦ k + 1`。预算条亮几像素是 `k` 画出来的样子（`Obj/Composite/Ladder.lean`）。
-/
import Obj.World

namespace Game

def tick (w : World) : World := { w with k := w.k + 1 }

end Game
