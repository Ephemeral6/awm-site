/-
# RestColor —— 放下的件画成什么色由形状定（对应 `rule/世界怎么回应/deselected_rest_color_by_shape.py`）

**定义**：直件（只占一行或只占一列）放下画 8，拐件画 15。用在点击换选中那一步。
-/
import Obj.Pieces.Piece

namespace Game

def restBent (cs : List Pos) : Bool := !(straight cs)

/-- 把一件放下：它的 `bent` 按形状重算。 -/
def putDown (pc : Piece) : Piece := { pc with bent := restBent pc.cells }

end Game
